<?php
namespace App\Http\Controllers\it_support\Stocks_Assets;
use App\Http\Controllers\Controller;
use App\Models\RequestPurchaseModel;
use App\Models\CompanyModel;
use App\Models\VendorCategoryModel;
use App\Models\StaffModel;
use App\Models\StockAssetModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;

class RequestPR extends Controller
{
    public function index(Request $request){return view('content.it_support.stocks_assets.request_pr');}
    public function dashboard(): JsonResponse
    {
        $requestedCount = RequestPurchaseModel::query()->where('status', 0)->count();
        $requestedSpend = RequestPurchaseModel::query()->whereIn('status', [0, 1, 2, 4])->sum('estimated_cost');
        $committedSpend = RequestPurchaseModel::query()->whereIn('status', [1, 2, 4])->sum('estimated_cost');
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => ['requested_count' => (int) $requestedCount,'requested_spend' => (float) $requestedSpend,'committed_spend' => (float) $committedSpend,],
        ]);
    }
    public function list(Request $request): JsonResponse
    {
         $status = $request->input('status', '');
        $requesterId = $request->input('requester_id', 'all');
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $search = trim((string) $request->input('search', ''));
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        $query = RequestPurchaseModel::query()->from('egc_it_request_purchase_request as pr')
            ->join('egc_it_stock_asset as stock','pr.item_id','=','stock.sno')
            ->leftJoin('egc_company as company','pr.company_id','=','company.sno')
            ->join('egc_it_vendor_category as vendor','pr.vendor_id','=','vendor.sno')
            ->leftJoin('egc_staff as staff','pr.requester_id','=','staff.sno')
           ->select(['pr.*','stock.item_name',])
           ->addSelect(DB::raw('CASE WHEN pr.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . ' ELSE company.company_name END AS company_name'));
        $vendorNameColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','name',]);
        if ($vendorNameColumn) {
            $query->addSelect(DB::raw("vendor.{$vendorNameColumn} as vendor_category_name"));
        } else {
            $query->addSelect(DB::raw("'-' as vendor_category_name"));
        }
        $staffNameColumn = $this->findColumn('egc_staff',['staff_name','employee_name','name','full_name',]);
        if ($staffNameColumn) {
            $query->addSelect(DB::raw("staff.{$staffNameColumn} as requester_name"));
        } else {
            $firstName = Schema::hasColumn('egc_staff','first_name');
            $lastName = Schema::hasColumn('egc_staff','last_name');
            if ($firstName && $lastName) {
                $query->addSelect(DB::raw("CONCAT(staff.first_name, ' ', staff.last_name) as requester_name"));
            } elseif ($firstName) {
                $query->addSelect(DB::raw("staff.first_name as requester_name"));
            } else {
                $query->addSelect(DB::raw("'-' as requester_name"));
            }
        }
        if ($requesterId !== 'all' &&$requesterId !== '') {
            $query->where('pr.requester_id',(int) $requesterId);
        }
        if ($search !== '') {
          $searchTerm = $search;
          $normalizedPR = preg_replace('/^PR[\s-]*/i','',trim($searchTerm));
          $query->where(function ($q) use ($searchTerm, $normalizedPR, $vendorNameColumn, $staffNameColumn, $generalCompanyName) {
              $like = '%' . $searchTerm . '%';
              $q->where('stock.item_name', 'LIKE', $like)->orWhere('company.company_name', 'LIKE', $like)
                  ->orWhere('pr.sno', 'LIKE', $like)
                  ->orWhere('pr.justification', 'LIKE', $like);
              if ($normalizedPR !== '' && ctype_digit($normalizedPR)) {
                  $prId = (int) $normalizedPR;
                  $q->orWhere('pr.sno', $prId);
              }
              if ($vendorNameColumn) {
                  $q->orWhere("vendor.{$vendorNameColumn}",'LIKE',$like);
              }
              if ($staffNameColumn) {
                  $q->orWhere("staff.{$staffNameColumn}",'LIKE',$like);
              } else {
                  $hasFirst = Schema::hasColumn('egc_staff','first_name');
                  $hasLast = Schema::hasColumn('egc_staff','last_name');
                  if ($hasFirst && $hasLast) {
                      $q->orWhereRaw("CONCAT(staff.first_name, ' ', staff.last_name) LIKE ?",[$like]);
                  } elseif ($hasFirst) {
                      $q->orWhere('staff.first_name', 'LIKE', $like);
                  } elseif ($hasLast) {
                      $q->orWhere('staff.last_name', 'LIKE', $like);
                  }
              }
              $q->orWhere(function ($companyQuery) use ($searchTerm,$generalCompanyName) {
                  $companyQuery->where('pr.company_id', 0)->whereRaw('? LIKE ?', [$generalCompanyName, '%' . $searchTerm . '%']);
              });
          });
      }
        $prs = $query->orderByDesc('pr.sno')->paginate($perPage);
        $data = collect($prs->items())->map(function ($pr) {return $this->formatPurchaseRequest($pr);})->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $prs->currentPage(),
                'last_page' => $prs->lastPage(),
                'per_page' => $prs->perPage(),
                'total' => $prs->total(),
                'from' => $prs->firstItem(),
                'to' => $prs->lastItem(),
            ],
        ]);
    }
    public function masters(): JsonResponse
{
    $items = StockAssetModel::query()->where('status', '!=', 2)->where('egc_it_stock_asset.quantity','<',5)->orderBy('item_name')->get(['sno','item_name','company_id','quantity','reorder_level',])->map(function ($item) {
            return [
                'sno' => (int) $item->sno,'item_name' => $item->item_name,'company_id' => $item->company_id? (int) $item->company_id: null,
                'quantity' => (float) ($item->quantity ?? 0),
                'reorder_level' => (float) ($item->reorder_level ?? 0),
            ];
        })->values();
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $companies = CompanyModel::query()->where('status', 0)->orderBy('company_name')->get(['sno', 'company_name'])
            ->map(function ($company) {
                return [
                    'sno' => (int) $company->sno,
                    'company_name' => $company->company_name,
                ];
            })->values();
        if ($generalSetting) {
            $companies->prepend(['sno' => 0,'company_name' => $generalSetting->title ?? '-',]);
        }
    $vendorNameColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','name']);
    $vendors = collect();
    if ($vendorNameColumn) {
        $vendorQuery = VendorCategoryModel::query();
        if (Schema::hasColumn('egc_it_vendor_category','status')) {
            $vendorQuery->where('status', 0);
        }
        $vendors = $vendorQuery
            ->whereNotNull($vendorNameColumn)->where($vendorNameColumn,'!=','')->orderBy($vendorNameColumn)->get(['sno',$vendorNameColumn,])
            ->map(function ($vendor) use ($vendorNameColumn) {
                return ['sno' => (int) $vendor->sno,'vendor_category_name' =>$vendor->{$vendorNameColumn},];
            })->values();
    }
    $staffNameColumn = $this->findColumn(
    'egc_staff',
    ['staff_name', 'employee_name', 'name', 'full_name']
);

$requesters = collect();

$requesterQuery = StaffModel::query();

if (Schema::hasColumn('egc_staff', 'status')) {
    $requesterQuery->where('status', 0);
}

if ($staffNameColumn) {
    $requesters = $requesterQuery
        ->orderBy($staffNameColumn)
        ->get(['sno', $staffNameColumn])
        ->map(function ($staff) use ($staffNameColumn) {
            return [
                'sno' => (int) $staff->sno,
                'requester_name' => $staff->{$staffNameColumn},
            ];
        })->values();
} else {
    $hasFirst = Schema::hasColumn('egc_staff', 'first_name');
    $hasLast = Schema::hasColumn('egc_staff', 'last_name');
    if ($hasFirst && $hasLast) {
        $requesters = $requesterQuery->orderBy('first_name')->get(['sno', 'first_name', 'last_name'])->map(function ($staff) {
          return ['sno' => (int) $staff->sno,'requester_name' => trim($staff->first_name . ' ' . $staff->last_name),];
})->values();
    } elseif ($hasFirst) {
        $requesters = $requesterQuery->orderBy('first_name')->get(['sno', 'first_name'])->map(function ($staff) {return ['sno' => (int) $staff->sno,'requester_name' => $staff->first_name,];})->values();
    }
}
    $types = collect([
        ['sno' => 1,'type_name' => 'Consumable',],
        ['sno' => 2,'type_name' => 'Spare Part',],
        ['sno' => 3,'type_name' => 'Cable',],
        ['sno' => 4,'type_name' => 'Peripheral',],
        ['sno' => 5,'type_name' => 'Stationery',],
    ]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => [
            'items' => $items,
            'companies' => $companies,
            'vendors' => $vendors,
            'requesters' => $requesters,
            'types' => $types,
        ],
    ]);
}
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            [
                'item_id' => ['required','integer','exists:egc_it_stock_asset,sno',],
                'type_id' => ['required','integer',],
                'quantity' => ['required','numeric','gt:0',],
                'estimated_cost' => ['required','numeric','min:0',],
                'vendor_id' => ['nullable','integer','exists:egc_it_vendor_category,sno',],
                'justification' => ['required','string','max:1000',],
                 'company_id' => ['required','integer','min:0',function ($attribute, $value, $fail) {
                  if ((int) $value === 0) {
                    return;
                    }
                    if (!DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists())
                      {
                        $fail('The selected company is invalid.');
                        }
                        },
                        ],
            ],
            [
                'item_id.required' =>  'Item is required.',
                'item_id.exists' => 'Selected item is invalid.',
                'type_id.required' =>   'Purchase type is required.',
                'quantity.required' => 'Quantity is required.',
                'quantity.gt' =>'Quantity must be greater than zero.',
                'estimated_cost.required' =>'Estimated cost is required.',
                'estimated_cost.min' => 'Estimated cost cannot be negative.',
                'vendor_id.exists' => 'Selected vendor is invalid.',
                'justification.required' => 'Justification is required.',
                'justification.max' => 'Justification cannot exceed 1000 characters.',
                'requester_id.required' =>'Requester is required.',
                'requester_id.exists' =>'Selected requester is invalid.',
                'company_id.required' => 'Company is required.',
                'company_id.exists' =>'Selected company is invalid.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            $stock = StockAssetModel::query()->where('sno', $request->item_id)->where('status', '!=', 2)->first();
            if (!$stock) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'Selected stock item was not found.',
                ], 404);
            }
            $companyId = (int) $stock->company_id;
            $userId = $request->user()?->user_id ?? 1;
           $staff = StaffModel::query()->where('sno', $userId)->where('login_access', 1)->first();
          if (!$staff) {
              return response()->json([
                  'success' => false,
                  'status' => 422,
                  'message' => 'No staff record found for the logged-in user.',
              ], 422);
          }
          $requesterId = (int) $staff->sno;
            $purchaseRequest = DB::transaction(function () use ($request,$stock,$companyId,$userId,$requesterId) {
                $pr = new RequestPurchaseModel();
                $pr->item_id = (int) $stock->sno;
                $pr->type_id = (int) $request->type_id;
                $pr->quantity = (float) $request->quantity;
                $pr->estimated_cost =(float) $request->estimated_cost;
                $pr->vendor_id = $request->filled('vendor_id')? (int) $request->vendor_id: null;
                $pr->requester_id = $requesterId;
                $pr->justification =trim($request->justification);
                $pr->company_id = $companyId;
                $pr->status = 0;
                $pr->created_by = $userId;
                $pr->updated_by = $userId;
                $pr->save();
                return $pr;
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>
                    'Purchase Request raised successfully.',
                'data' => [
                    'pr_id' => (int) $purchaseRequest->sno,
                    'pr_number' =>
                        $this->prNumber($purchaseRequest->sno),
                ],
            ]);
        } catch (\Throwable $e) {

            Log::error('Purchase Request Creation Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>
                    'Unable to raise Purchase Request.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function show($id): JsonResponse
    {
        $pr = $this->getPurchaseRequest($id);
        if (!$pr) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Purchase Request not found.',
            ], 404);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $this->formatPurchaseRequest($pr),
        ]);
    }
    public function approve(Request $request,$id): JsonResponse
    {    $userId = $request->user()?->user_id ?? 1;
        try {
                $result = DB::transaction(function () use ($id,$userId) {
                $pr = RequestPurchaseModel::query()->where('sno', $id)->lockForUpdate()->first();
                if (!$pr) {
                    throw new \RuntimeException('Purchase Request not found.');
                }
                if ((int) $pr->status !== 0) {
                    throw new \RuntimeException('Only Requested Purchase Requests can be approved.');
                }
                $stock = StockAssetModel::query()->where('sno', $pr->item_id)->where('status', '!=', 2)->lockForUpdate()->first();
                if (!$stock) {
                    throw new \RuntimeException('Stock item linked to this Purchase Request was not found.');
                }
                $stock->quantity =(float) $stock->quantity +(float) $pr->quantity;
                $stock->updated_by =$userId;
                $stock->save();
                $pr->status = 1;
                $pr->updated_by =$userId;
                $pr->save();
                return $pr;
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>
                    'Purchase Request approved and stock quantity updated.',
                'data' => [
                    'pr_id' => (int) $result->sno,
                    'status' => 1,
                ],
            ]);

        } catch (\Throwable $e) {
            Log::error('Purchase Request Approval Error',['pr_id' => $id,'message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => $e->getMessage(),
            ], 422);
        }
    }
    public function reject(Request $request,$id): JsonResponse
    {   $userId = $request->user()?->user_id ?? 1;
        try {
            $pr = RequestPurchaseModel::query()->where('sno', $id)->first();
            if (!$pr) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' =>
                        'Purchase Request not found.',
                ], 404);
            }
            if ((int) $pr->status !== 0) {
                return response()->json([
                    'success' => false,
                    'status' => 422,
                    'message' =>
                        'Only Requested Purchase Requests can be rejected.',
                ], 422);
            }
            $pr->status = 3;
            $pr->updated_by = $userId;
            $pr->save();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' =>
                    'Purchase Request rejected successfully.',
            ]);

        } catch (\Throwable $e) {
            Log::error('Purchase Request Reject Error',['pr_id' => $id,'message' => $e->getMessage(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' =>
                    'Unable to reject Purchase Request.',
            ], 500);
        }
    }
    public function markOrdered(Request $request, $id): JsonResponse
    {
        return $this->changeStatus($request,$id,1,2,'Purchase Request marked as Ordered.');
    }
    public function markReceived(Request $request, $id): JsonResponse
    {
        return $this->changeStatus($request,$id,2,4,'Purchase Request marked as Received.');
    }
    private function changeStatus(Request $request,$id,int $expectedStatus,int $newStatus,string $message): JsonResponse {
        $userId = $request->user()?->user_id ?? 1;
        try {
            $pr = RequestPurchaseModel::query()->where('sno', $id)->first();
            if (!$pr) {
                return response()->json([
                    'success' => false,
                    'status' => 404,
                    'message' => 'Purchase Request not found.',
                ], 404);
            }
            if ((int) $pr->status !== $expectedStatus) {
                return response()->json([
                    'success' => false,
                    'status' => 422,
                    'message' => 'Invalid Purchase Request status transition.',
                ], 422);
            }
            $pr->status = $newStatus;
            $pr->updated_by = $userId;
            $pr->save();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => $message,
                'data' => [
                    'pr_id' => (int) $pr->sno,
                    'status' => $newStatus,
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('Purchase Request Status Error', [
                'pr_id' => $id,
                'message' => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to update Purchase Request status.',
            ], 500);
        }
    }
    private function getPurchaseRequest($id)
    {
        $query = RequestPurchaseModel::query()->from('egc_it_request_purchase_request as pr')
            ->leftJoin('egc_it_stock_asset as stock','pr.item_id','=','stock.sno')
            ->leftJoin('egc_company as company','pr.company_id','=','company.sno')->select(['pr.*','stock.item_name','company.company_name',]);
        $vendorColumn = $this->findColumn('egc_it_vendor_category',['vendor_category_name','vendor','name',]);
        if ($vendorColumn) {
            $query->leftJoin('egc_it_vendor_category as vendor','pr.vendor_id','=','vendor.sno');
            $query->addSelect(DB::raw("vendor.{$vendorColumn} as vendor_category_name"));
        } else {
            $query->addSelect(DB::raw("'-' as vendor_category_name"));
        }
        $staffColumn = $this->findColumn('egc_staff',['staff_name','employee_name','name','full_name',]);
        if ($staffColumn) {
            $query->leftJoin('egc_staff as staff','pr.requester_id','=','staff.sno');
            $query->addSelect(
                DB::raw("staff.{$staffColumn} as requester_name"));
        } else {
            $query->addSelect(DB::raw("'-' as requester_name"));
        }
        return $query->where('pr.sno', $id)->first();
    }
    private function formatPurchaseRequest($pr): array
    {
        return [
            'sno' => (int) $pr->sno,
            'pr_number' => $this->prNumber($pr->sno),
            'item_id' =>  (int) $pr->item_id,
            'item_name' =>$pr->item_name ?? '-',
            'type_id' =>   (int) $pr->type_id,
            'quantity' => (float) $pr->quantity,
            'estimated_cost' =>  (float) ($pr->estimated_cost ?? 0),
            'vendor_id' =>$pr->vendor_id !== null? (int) $pr->vendor_id: null,
            'vendor_category_name' =>$pr->vendor_category_name ?? 'Any vendor',
            'requester_id' =>(int) $pr->requester_id,
            'requester_name' => $pr->requester_name ?? '-',
            'company_id' =>(int) $pr->company_id,
            'company_name' => $pr->company_name ?? '-',
            'justification' =>$pr->justification ?? '',
            'status' =>(int) $pr->status,
            'status_text' =>$this->statusText($pr->status),
            'created_at' =>$pr->created_at,
            'updated_at' => $pr->updated_at,
        ];
    }
    private function statusText($status): string
    {
        return match ((int) $status) {0 => 'Requested',1 => 'Approved',2 => 'Ordered',3 => 'Rejected',4 => 'Received',default => 'Unknown',
};
    }
    private function prNumber($id): string
    {
        return 'PR-' . str_pad((string) $id,4,'0',STR_PAD_LEFT);
    }
    private function findColumn(string $table,array $columns): ?string {
        foreach ($columns as $column) {
            if (Schema::hasColumn($table, $column)) {
                return $column;
            }
        }
        return null;
    }
    public function delete($id): JsonResponse
{
    try {
        DB::transaction(function () use ($id) {
            $pr = RequestPurchaseModel::query()->where('sno', $id)->lockForUpdate()->first();
            if (!$pr) {
                throw new \RuntimeException('Purchase Request not found.');
            }
            $pr->delete();
        });
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Purchase Request deleted successfully.',
        ]);

    } catch (\RuntimeException $e) {
        return response()->json([
            'success' => false,
            'status' => 404,
            'message' => $e->getMessage(),
        ], 404);

    } catch (\Throwable $e) {
        Log::error('Purchase Request Delete Error', ['pr_id' => $id,'message' => $e->getMessage(),]);
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => 'Unable to delete Purchase Request.',
        ], 500);
    }
}
}
