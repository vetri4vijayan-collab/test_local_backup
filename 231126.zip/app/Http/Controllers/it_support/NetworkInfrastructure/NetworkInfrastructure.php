<?php
namespace App\Http\Controllers\it_support\NetworkInfrastructure;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\NetworkInfrastructureModel;
use App\Models\CompanyModel;
use App\Models\TicketRequestModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Schema;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
class NetworkInfrastructure extends Controller
// in this the self functions and Private variables and functions are refered from the brower website name -> stack overflow -> you can also use it
{
    public function index()
{
    return view('content.it_support.network_infractructure.network_infractructure');
}
    public function getDevices(Request $request): JsonResponse
    {
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $search = trim((string) $request->input('search', ''));
        $status = $request->input('status');
        $typeId = $request->input('type_id');
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $generalCompanyName = $generalSetting->title ?? '-';
        $query = NetworkInfrastructureModel::query()->from('egc_it_network_infrastructure')
        ->join('egc_it_network_type','egc_it_network_infrastructure.type_id','=','egc_it_network_type.sno')
        ->join('egc_locations','egc_it_network_infrastructure.location','=','egc_locations.sno')
        ->leftJoin('egc_company','egc_it_network_infrastructure.company_id','=','egc_company.sno')
        ->where('egc_it_network_infrastructure.status', '!=', 2)->select('egc_it_network_infrastructure.*','egc_it_network_type.network_type','egc_locations.area','egc_company.company_name')
        ->addSelect(DB::raw('CASE WHEN egc_it_network_infrastructure.company_id = 0 THEN ' . DB::getPdo()->quote($generalCompanyName) . ' ELSE egc_company.company_name END AS company_name'));
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('egc_it_network_infrastructure.device_name','LIKE','%' . $search . '%')
                ->orWhere('egc_it_network_infrastructure.ip_address','LIKE','%' . $search . '%')
                ->orWhere('egc_it_network_infrastructure.subnet','LIKE','%' . $search . '%')
                ->orWhere('egc_it_network_type.network_type','LIKE','%' . $search . '%')
                ->orWhere('egc_locations.area','LIKE','%' . $search . '%')
                ->orWhere('egc_company.company_name','LIKE','%' . $search . '%');
            });
        }
        if ($status !== null && $status !== '') {
            $query->where(
                'egc_it_network_infrastructure.status',
                (int) $status
            );
        }
        if ($typeId !== null && $typeId !== '') {
            $query->where('egc_it_network_infrastructure.type_id',(int) $typeId);
        }
        $devices = $query->orderByDesc('egc_it_network_infrastructure.sno')->paginate($perPage);
        $data = collect($devices->items())->map(function ($device) {
                return $this->formatDevice($device);
            })->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $devices->currentPage(),
                'last_page' => $devices->lastPage(),
                'per_page' => $devices->perPage(),
                'total' => $devices->total(),
                'from' => $devices->firstItem(),
                'to' => $devices->lastItem(),
            ],
        ]);
    }
    public function dashboard(): JsonResponse
    {
        $baseQuery = NetworkInfrastructureModel::query()->where('status', '!=', 2);
        $total = (clone $baseQuery)->count();
        $up = (clone $baseQuery)->where('status', 0)->count();
        $down = (clone $baseQuery)->where('status', 1)->count();
        $maintenance = (clone $baseQuery)->where('status', 3)->count();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'total' => (int) $total,
                'up' => (int) $up,
                'down' => (int) $down,
                'maintenance' => (int) $maintenance,
                'health_percentage' => $total > 0
                    ? round(($up / $total) * 100, 2)
                    : 0,
            ],
        ]);
    }
    public function subnets(): JsonResponse
    {
        $subnets = NetworkInfrastructureModel::query()->from('egc_it_network_infrastructure')->where('egc_it_network_infrastructure.status', '!=', 2)->select(
                'subnet',
                DB::raw('COUNT(*) as device_count'),
                DB::raw('SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) as up_count'),
                DB::raw('SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as down_count'),
                DB::raw('SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) as maintenance_count')
            )->whereNotNull('subnet')->where('subnet', '!=', '')->groupBy('subnet')->orderBy('subnet')->get();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $subnets,
        ]);
    }
    public function show($id): JsonResponse
    {
        $device = $this->getDevice($id);
        if (!$device || (int) $device->status === 2) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Infrastructure device not found.',
            ], 404);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $this->formatDevice($device),
        ]);
    }
    public function add(Request $request): JsonResponse
    {
        $validator = Validator::make(
            $request->all(),
            [
                'device_name' => ['required','string','max:255',],
                'type_id' => ['required','integer','exists:egc_it_network_type,sno',],
                'status' => ['required','integer','in:0,1,3',],
                'ip_address' => ['required','string','max:255',],
                'subnet' => ['required','string','max:255',],
                'location' => ['required','integer','exists:egc_locations,sno',],
                'company_id' => [
                    'required',
                    'integer',
                    'min:0',
                    function ($attribute, $value, $fail) {
                        if ((int) $value === 0) {
                            return;
                        }

                        if (!DB::table('egc_company')
                            ->where('sno', $value)
                            ->where('status', 0)
                            ->exists()) {
                            $fail('The selected company is invalid.');
                        }
                    },
                ],
            ],
            [
                'device_name.required' => 'Device name is required.',
                'type_id.required' => 'Device type is required.',
                'type_id.exists' => 'Selected device type is invalid.',
                'status.required' => 'Status is required.',
                'status.in' => 'Selected status is invalid.',
                'ip_address.required' => 'IP address is required.',
                'subnet.required' => 'Subnet is required.',
                'location.required' => 'Location is required.',
                'location.exists' => 'Selected location is invalid.',
                'company_id.required' => 'Company is required.',
                'company_id.exists' => 'Selected company is invalid.',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        DB::beginTransaction();
        try {
            $userId = $request->user()->userId ?? 1;
            $device = new NetworkInfrastructureModel();
            $device->device_name = trim($request->device_name);
            $device->type_id = (int) $request->type_id;
            $device->status = (int) $request->status;
            $device->ip_address = trim($request->ip_address);
            $device->subnet = trim($request->subnet);
            $device->location = (int) $request->location;
            $device->company_id = (int) $request->company_id;
            $device->created_by = $userId;
            $device->updated_by = $userId;
            $device->save();
            DB::commit();
            $savedDevice = $this->getDevice($device->sno);
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Infrastructure device added successfully.',
                'data' => [
                    'device_id' => (int) $device->sno,
                    'device' => $this->formatDevice($savedDevice),
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error(
                'Network Infrastructure Store Error',
                [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]
            );
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Could not add infrastructure device.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
   public function toggleStatus($id, Request $request): JsonResponse
{
    $device = NetworkInfrastructureModel::find($id);
    if (!$device || (int) $device->status === 2) {
        return response()->json([
            'success' => false,
            'status' => 404,
            'message' => 'Infrastructure device not found.',
        ], 404);
    }
    try {
        $userId = $request->user()->userId ?? 1;
        if ((int) $device->status === 3) {
            $device->status = 0;
        } else {
            $device->status = (int) $device->status === 0 ? 1 : 0;
        }
        $device->updated_by = $userId;
        $device->save();
        $updatedDevice = $this->getDevice($device->sno);
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Device monitoring status updated successfully.',
            'data' => $this->formatDevice($updatedDevice),
        ]);
    } catch (\Throwable $e) {
        Log::error('Network Infrastructure Status Error', [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'device_id' => $id,
        ]);
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => 'Unable to update device status.',
            'error' => config('app.debug')
                ? $e->getMessage()
                : null,
        ], 500);
    }
}
    public function delete(Request $request,$id): JsonResponse
    {  $userId =  $request->user()->userId ?? 1;
        $device = NetworkInfrastructureModel::find($id);
        if (!$device) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Infrastructure device not found.',
            ], 404);
        }
        try {
            $device->status = 2;
            $device->updated_by = $userId;
            $device->save();
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Infrastructure device deleted successfully.',
            ]);
        } catch (\Throwable $e) {
            Log::error('Network Infrastructure Delete Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to delete infrastructure device.',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null,
            ], 500);
        }
    }
    public function listTypes(): JsonResponse
    {
        $types = DB::table('egc_it_network_type')->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','network_type',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $types,
        ]);
    }
    public function listLocations(): JsonResponse
    {
        $locations = DB::table('egc_locations')->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','area',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $locations,
        ]);
    }
     public function listCompanies(): JsonResponse
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $companies = DB::table('egc_company')->where('status', 0)->orderBy('company_name', 'ASC')->get(['sno', 'company_name']);
        if ($generalSetting) {
            $companies->prepend((object) [
                'sno' => 0,
                'company_name' => $generalSetting->title,
            ]);
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $companies,
        ]);
    }
    private function getDevice($id)
    {
        return NetworkInfrastructureModel::query()->from('egc_it_network_infrastructure')
            ->join('egc_it_network_type','egc_it_network_infrastructure.type_id','=','egc_it_network_type.sno')
            ->join('egc_locations','egc_it_network_infrastructure.location','=','egc_locations.sno')
            ->leftJoin('egc_company','egc_it_network_infrastructure.company_id','=','egc_company.sno')
            ->where('egc_it_network_infrastructure.sno', $id)
            ->select('egc_it_network_infrastructure.*','egc_it_network_type.network_type','egc_locations.area','egc_company.company_name')->first();
    }
    private function formatDevice($device): array
    {
        $status = (int) $device->status;
        $statusText = match ($status) {0 => 'Up',1 => 'Down',3 => 'Maintenance',default => 'Unknown',};
        return [
            'sno' => (int) $device->sno,
            'device_name' => $device->device_name,
            'type_id' => (int) $device->type_id,
            'network_type' => $device->network_type ?? '-',
            'status' => $status,
            'status_text' => $statusText,
            'ip_address' => $device->ip_address,
            'subnet' => $device->subnet,
            'location' => (int) $device->location,
            'area' => $device->area ?? '-',
            'company_id' => (int) $device->company_id,
            'company_name' => $device->company_name ?? '-',
            'can_raise_ticket' => $status === 1,
            'created_by' => $device->created_by,
            'updated_by' => $device->updated_by,
            'created_at' => $device->created_at,
            'updated_at' => $device->updated_at,
        ];
    }
    public function listTicketCategories(): JsonResponse
{
    $categories = DB::table('egc_it_asset_category')->where('status', 0)->orderBy('category_name', 'ASC')->get(['sno','category_name',]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $categories,
    ]);
}
public function listTicketBranches(): JsonResponse
{
    $branches = DB::table('egc_branch')->where('status', 0)->orderBy('sno', 'ASC')->get(['sno','branch_name',]);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $branches,
    ]);
}
public function listTicketRequesters(): JsonResponse
{
   $requesters = StaffModel::query()->where('status', 0)->orderBy('staff_name', 'ASC')->get(['sno', 'staff_name']);
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $requesters,
    ]);
}
public function listTicketAssignees(): JsonResponse
{
    $staffColumn = 'staff_name';
    if (Schema::hasColumn('egc_staff', 'staff_name')) {
      $staffColumn = 'staff_name';
    } elseif (Schema::hasColumn('egc_staff', 'employee_name')) {
        $staffColumn = 'employee_name';
    } elseif (Schema::hasColumn('egc_staff', 'name')) {
        $staffColumn = 'name';
    }
    $employees = StaffModel::query()->when(Schema::hasColumn('egc_staff', 'status'),fn ($q) => $q->where('status', 0))->orderBy('sno', 'ASC')->get(['sno',$staffColumn,])
        ->map(function ($row) use ($staffColumn) {return ['sno' => (int) $row->sno,'staff_name' => $row->{$staffColumn},];})->values();
    return response()->json([
        'success' => true,
        'status' => 200,
        'data' => $employees,
    ]);
}

 public function listTicketAssets(): JsonResponse
    {
        $assets = DB::table('egc_it_asset_management')->where('status', '!=', 4)->orderBy('make', 'ASC')->get(['sno','make',]);
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $assets,
        ]);
    }

public function createTicket(Request $request): JsonResponse
{
    $validator = Validator::make(
        $request->all(),
        [
            'title' => ['required','string','max:255',],

            'description' => ['nullable','string',],
            'category_id' => ['required','integer','exists:egc_it_asset_category,sno',],
            'priority' => ['required','integer',],
            'company_id' => [
                    'required',
                    'integer',
                    'min:0',
                    function ($attribute, $value, $fail) {
                        if ((int) $value === 0) {
                            return;
                        }

                        if (!DB::table('egc_company')
                            ->where('sno', $value)
                            ->where('status', 0)
                            ->exists()) {
                            $fail('The selected company is invalid.');
                        }
                    },
                ],
            'branch_id' => ['required','integer','exists:egc_branch,sno',],
            'requester_id' => ['required','integer','exists:egc_staff,sno',],
            'assignee_id' => ['required','integer','exists:egc_staff,sno',],
            'asset_id' => ['required','integer','exists:egc_it_asset_management,sno',],
        ],
        [
            'title.required' => 'Ticket title is required.',
            'category_id.required' => 'Ticket category is required.',
            'category_id.exists' => 'Selected ticket category is invalid.',
            'priority.required' => 'Ticket priority is required.',
            'company_id.required' => 'Company is required.',
            'company_id.required' => 'Company is required.',
            'branch_id.required' => 'Branch is required.',
            'requester_id.required' => 'Requester is required.',
            'assignee_id.required' => 'Assignee is required.',
            'asset_id.required' => 'Asset is required.',
        ]
    );

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'status' => 422,
            'message' => 'Validation failed.',
            'errors' => $validator->errors(),
        ], 422);
    }
    DB::beginTransaction();
    try { $lastTicket = TicketRequestModel::query()->whereNotNull('ticket_number')->orderByDesc('sno')->lockForUpdate()->first();
            $nextNumber = 1;
            if ($lastTicket && preg_match('/(\d+)$/', $lastTicket->ticket_number, $matches)) {
                $nextNumber = ((int) $matches[1]) + 1;
            }
            $ticketNumber = 'TKT-' . str_pad($nextNumber,4,'0',STR_PAD_LEFT);
        $userId = $request->user()->userId ?? 1;
        $ticket = new TicketRequestModel();
        $ticket->title = trim($request->title);
        $ticket->ticket_number = trim($request->ticket_number);
        $ticket->description = $request->filled('description')? trim($request->description): null;
        $ticket->category_id = (int) $request->category_id;
        $ticket->priority = (int)$request->priority;
        $ticket->company_id = (int) $request->company_id;
        $ticket->branch_id = $request->filled('branch_id')? (int) $request->branch_id: null;
        $ticket->requester_id = $request->filled('requester_id')? (int) $request->requester_id: null;
        $ticket->assignee_id = $request->filled('assignee_id')? (int) $request->assignee_id: null;
        $ticket->asset_id = $request->filled('asset_id')? (int) $request->asset_id: null;
        $ticket->created_by = $userId;
        $ticket->updated_by = $userId;
        $ticket->save();
        DB::commit();
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Ticket raised successfully.',
            'data' => [
                'ticket_id' => (int) $ticket->sno,
            ],
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        Log::error('Raise Ticket Error',['message' => $e->getMessage(),'file' => $e->getFile(),'line' => $e->getLine(),]);
        return response()->json([
            'success' => false,
            'status' => 500,
            'message' => 'Unable to raise ticket.',
            'error' => config('app.debug')
                ? $e->getMessage()
                : null,
        ], 500);
    }
}
}
