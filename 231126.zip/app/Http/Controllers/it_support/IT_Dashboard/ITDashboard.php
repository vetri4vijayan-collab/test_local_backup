<?php
namespace App\Http\Controllers\it_support\IT_Dashboard;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;
class ITDashboard extends Controller
{
    private const TICKET_STATUS = [
        0 => 'In Progress',
        1 => 'Open',
        3 => 'On Hold',
        4 => 'Resolved',
        5 => 'Closed',
    ];
    private const ASSET_STATUS_IN_STOCK = 0;
    private const ASSET_STATUS_ASSIGNED = 1;
    private const NETWORK_DOWN = 1;
    private const NETWORK_UP = 0;
    public function index()
    {
              return view('content.it_support.it_dashboard.it_dashboard');
    }
    private function hasTable(string $table): bool
    {
        return Schema::hasTable($table);
    }
    private function hasColumn(string $table,string $column): bool {
        return $this->hasTable($table) && Schema::hasColumn($table, $column);
    }
    private function safeCount(string $table, ?string $column = null,$value = null): int {
        if (!$this->hasTable($table)) {
            return 0;
        }
        $query = DB::table($table);
        if ($column !== null) {
            if (!$this->hasColumn($table, $column)) {
                return 0;
            }
            $query->where($column, $value);
        }
        return (int) $query->count();
    }
    public function dashboard(): JsonResponse
    {
        $ticketTable = 'egc_it_raise_ticket';
        $ticketQuery = $this->hasTable($ticketTable) ? DB::table($ticketTable)->where('status', '!=', 2) : null;
        $ticketTotal = $ticketQuery? (clone $ticketQuery)->count() : 0;
        $ticketStats = [];
        foreach (self::TICKET_STATUS as $status => $label) {
            $ticketStats[] = ['status' => $status,'label' => $label,'count' => $ticketQuery ? (clone $ticketQuery)->where('status', $status)->count(): 0,];
        }
        $openTickets = $ticketQuery ? (clone $ticketQuery)->whereIn('status', [1])->count(): 0;
        $assetTable = 'egc_it_asset_management';
        $assetQuery = $this->hasTable($assetTable) ? DB::table($assetTable)->where('status', '!=', 2): null;
        $totalAssets = $assetQuery ? (clone $assetQuery)->count(): 0;
        $inStock = $assetQuery ? (clone $assetQuery)->where('status', self::ASSET_STATUS_IN_STOCK)->count(): 0;
        $assignedAssets = $assetQuery ? (clone $assetQuery)->where('status', self::ASSET_STATUS_ASSIGNED)->count(): 0;
        $stockTable = 'egc_it_stock_asset';
        $lowStock = 0;
        $stockItems = [];
        if ($this->hasColumn($stockTable, 'quantity') && $this->hasColumn($stockTable, 'reorder_level')) {
            $stockQuery = DB::table($stockTable)
                ->whereColumn('quantity','<=','reorder_level');
            if ($this->hasColumn($stockTable, 'status')) {
                $stockQuery->where('status', '!=', 2);
            }
            $lowStock = (clone $stockQuery)->count();
            $stockItems = (clone $stockQuery)
                ->select('sno','item_name','quantity','reorder_level')->limit(10)->get();
        }
        $prTable = 'egc_it_request_purchase_request';
        $pendingPR = 0;
        $requestedSpend = 0;
        $committedSpend = 0;
        if ($this->hasTable($prTable)) {
            $prQuery = DB::table($prTable);
            $pendingPR = (clone $prQuery)->where('status', 0)->count();
            if ($this->hasColumn($prTable, 'estimated_cost')) {
                $requestedSpend = (clone $prQuery)->whereIn('status', [0, 1, 2, 4])->sum('estimated_cost');
                $committedSpend = (clone $prQuery)->whereIn('status', [1, 2, 4])->sum('estimated_cost');
            }
        }
        $licenceTable = 'egc_it_licence';
        $renewingCount = 0;
        $renewingProducts = [];
        $annualisedCost = 0;
        $monthlyRunRate = 0;
        if ($this->hasTable($licenceTable)) {
            $licenceQuery = DB::table($licenceTable)->where('status', 0);
            $today = today()->toDateString();
            $next30Days = today()->addDays(30)->toDateString();
            if ($this->hasColumn($licenceTable, 'renewal_date')) {
                $renewingQuery = (clone $licenceQuery)->whereNotNull('renewal_date')->whereBetween('renewal_date', [$today,$next30Days]);
                $renewingCount = (clone $renewingQuery)->count();
                $renewingProducts = (clone $renewingQuery)->select('sno','product_name','renewal_date','cost','billing_cycle_id')->orderBy('renewal_date')->get();
            }
            if ($this->hasColumn($licenceTable, 'cost')) {
                $licences = (clone $licenceQuery)->get();
                foreach ($licences as $licence) {
                    $cost = (float) ($licence->cost ?? 0);
                    if ((int) $licence->billing_cycle_id === 1) {
                        $monthlyRunRate += $cost / 12;
                        $annualisedCost += $cost;
                    } else {
                        $monthlyRunRate += $cost;
                        $annualisedCost += $cost * 12;
                    }
                }
            }
        }
        $networkTable = 'egc_it_network_infrastructure';
        $networkDown = 0;
        $networkUp = 0;
        $networkTotal = 0;
        if ($this->hasTable($networkTable)) {
            $networkQuery = DB::table($networkTable)->where('status', '!=', 2);
            $networkTotal = (clone $networkQuery)->count();
            $networkDown = (clone $networkQuery)->where('status', self::NETWORK_DOWN)->count();
            $networkUp = (clone $networkQuery)->where('status', self::NETWORK_UP)->count();
        }
        $assetsByCategory = [];
        if ($this->hasTable($assetTable) && $this->hasTable('egc_it_asset_category')) {
            $assetsByCategory = DB::table($assetTable . ' as a')
                ->leftJoin('egc_it_asset_category as c','c.sno','=','a.category_id')->where('a.status', '!=', 2)
                ->selectRaw("COALESCE(c.category_name, 'Uncategorized')as category_name,COUNT(a.sno) as total")->groupBy('c.category_name')->orderByDesc('total')->get();
        }
        $recentActivity = $this->getRecentActivity();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'tickets' => ['total' => $ticketTotal,'open' => $openTickets,'by_status' => $ticketStats,],
                'assets' => ['total' => $totalAssets,'in_stock' => $inStock,'assigned' => $assignedAssets,'by_category' => $assetsByCategory,],
                'stock' => ['low_stock' => $lowStock,'items' => $stockItems,],
                'purchase_requests' => ['pending' => $pendingPR,'requested_spend' => round((float) $requestedSpend,2),'committed_spend' => round((float) $committedSpend,2),],
                'licences' => [
                    'renewing_count' => $renewingCount,
                    'renewing_products' => $renewingProducts,
                    'monthly_run_rate' => round($monthlyRunRate,2),
                    'annualised_cost' => round($annualisedCost,2),
                ],
                'network' => ['total' => $networkTotal,'up' => $networkUp,'down' => $networkDown,],
                'recent_activity' => $recentActivity,
            ],
        ]);
    }
   private function getRecentActivity(): array
    {
        $activities = [];
        $lastSevenDays = Carbon::now()->subDays(7);
        $ticketTable = 'egc_it_raise_ticket';
        if ($this->hasColumn($ticketTable, 'created_at') && $this->hasColumn($ticketTable, 'title')) {
            $tickets = DB::table($ticketTable)
                ->where('status', '!=', 2)
                ->where('created_at', '>=', $lastSevenDays)
                ->select('sno','title','created_at','status')->orderByDesc('created_at')->get();
            foreach ($tickets as $ticket) {
                $activities[] = [
                    'reference' => $ticket->title ?: 'Untitled Ticket',
                    'activity' => 'Ticket activity',
                    'module' => 'Tickets',
                    'created_at' => $ticket->created_at,
                    'timestamp' => strtotime($ticket->created_at),
                ];
            }
        }
        $prTable = 'egc_it_request_purchase_request';
        $stockTable = 'egc_it_stock_asset';
        if ($this->hasColumn($prTable, 'created_at')) {
            $prQuery = DB::table($prTable . ' as pr')->leftJoin($stockTable . ' as stock','pr.item_id','=','stock.sno')
                ->where('pr.created_at', '>=', $lastSevenDays)->select('pr.sno','pr.created_at','pr.status','stock.item_name')->orderByDesc('pr.created_at');
            $prs = $prQuery->get();
            foreach ($prs as $pr) {
                $activities[] = [
                    'reference' => $pr->item_name ?: 'Unknown Item',
                    'activity' => match ((int) $pr->status) {
                        0 => 'Purchase request raised',
                        1 => 'Purchase request approved',
                        2 => 'Purchase request ordered',
                        4 => 'Purchase request received',
                        default => 'Purchase request updated',
                    },
                    'module' => 'Purchase Requests',
                    'created_at' => $pr->created_at,
                    'timestamp' => strtotime($pr->created_at),
                ];
            }
        }
        usort(
            $activities,
            fn ($a, $b) =>
                $b['timestamp'] <=> $a['timestamp']
        );
        $activities = array_slice($activities, 0, 50);
        foreach ($activities as &$activity) {
            $activity['time_ago'] = Carbon::parse($activity['created_at'])->diffForHumans();
        }
        unset($activity);
        return $activities;
    }
    public function chartData(Request $request): JsonResponse
    {
        $type = $request->input('type', 'monthly');
        if (!in_array($type, ['monthly', 'daily'], true)) {
            $type = 'monthly';
        }
        $labels = [];
        $ticketCounts = [];
        $assetCounts = [];
        $purchaseCounts = [];
        $periods = $type === 'daily' ? 30 : 12;
        for ($i = $periods - 1; $i >= 0; $i--) {
            if ($type === 'daily') {
                $date = today()->subDays($i);
                $start = $date->copy()->startOfDay();
                $end = $date->copy()->endOfDay();
                $labels[] = $date->format('d M');
            } else {
                $date = today()->startOfMonth()->subMonths($i);
                $start = $date->copy()->startOfMonth();
                $end = $date->copy()->endOfMonth();
                $labels[] = $date->format('M Y');
            }
            $ticketCounts[] = $this->periodCount('egc_it_raise_ticket',$start,$end);
            $assetCounts[] = $this->periodCount('egc_it_asset_management',$start,$end);
            $purchaseCounts[] = $this->periodCount('egc_it_request_purchase_request',$start,$end);
        }
        return response()->json([
            'success' => true,
            'data' => [
                'labels' => $labels,
                'tickets' => $ticketCounts,
                'assets' => $assetCounts,
                'purchase_requests' => $purchaseCounts,
                'type' => $type,
            ],
        ]);
    }
    private function periodCount(string $table,Carbon $start,Carbon $end): int {

        if (!$this->hasColumn($table, 'created_at')) {
            return 0;
        }
        return (int) DB::table($table)->where('status','!=',2)->whereBetween('created_at', [$start->toDateTimeString(),$end->toDateTimeString(),])->count();
    }
}
