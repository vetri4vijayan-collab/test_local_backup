<?php

namespace App\Http\Controllers\it_support\Asset_Validation;

use App\Http\Controllers\Controller;
use App\Models\AssetValidationCycleModel;
use App\Models\AssetValidationItemModel;
use App\Models\CompanyModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class AssetValidation extends Controller
{
    private const CYCLE_IN_PROGRESS = 0;
    private const CYCLE_COMPLETED = 1;
    private const CYCLE_DELETED = 2;
    private const ITEM_NOT_CHECKED = 0;
    private const ITEM_VERIFIED = 1;
    private const ITEM_MISSING = 3;
    private const ITEM_DAMAGED = 4;
    private const ASSET_TABLE = 'egc_it_stock_asset';
    private const CATEGORY_TABLE = 'egc_it_stock_category';
    private const COMPANY_TABLE = 'egc_company';
    public function index()
    {
        return view('content.it_support.asset_validation.asset_validation');
    }
    private function findColumn(string $table, array $columns): ?string
    {
        foreach ($columns as $column) {
            if (Schema::hasColumn($table, $column)) {
                return $column;
            }
        }

        return null;
    }
    private function userId(Request $request): int
    {
        return (int) ($request->user()->userId ?? 1);
    }
    private function cycleStatusText(int $status): string
    {
        return match ($status) {
            self::CYCLE_IN_PROGRESS => 'In Progress',
            self::CYCLE_COMPLETED => 'Completed',
            self::CYCLE_DELETED => 'Deleted',
            default => 'Unknown',
        };
    }
    private function itemStatusText(int $status): string
    {
        return match ($status) {
            self::ITEM_NOT_CHECKED => 'Not checked',
            self::ITEM_VERIFIED => 'Verified',
            self::ITEM_MISSING => 'Missing',
            self::ITEM_DAMAGED => 'Damaged',
            default => 'Unknown',
        };
    }
    private function categoryName($categoryId): string
    {
        if (!$categoryId) {
            return 'All categories';
        }
        if (!Schema::hasTable(self::CATEGORY_TABLE)) {
            return 'All categories';
        }
        $nameColumn = $this->findColumn(self::CATEGORY_TABLE,['stock_category', 'name']);

        if (!$nameColumn) {
            return 'All categories';
        }
        return (string) (DB::table(self::CATEGORY_TABLE)->where('sno', $categoryId)->value($nameColumn) ?? 'All categories');
    }
    private function cycleStats(int $cycleId): array
    {
        $items = AssetValidationItemModel::query()->where('cycle_id', $cycleId);
        $total = (clone $items)->count();
        $verified = (clone $items)->where('status', self::ITEM_VERIFIED)->count();
        $discrepancies = (clone $items)->whereIn('status', [self::ITEM_MISSING,self::ITEM_DAMAGED,])->count();
        return [
            'total' => (int) $total,
            'verified' => (int) $verified,
            'discrepancies' => (int) $discrepancies,
            'progress_text' => $verified . '/' . $total,
        ];
    }
    private function formatCycle($cycle): array
    {
       $companyName = '-';
        if ((int) $cycle->company_id === 0) {
            $helper = new \App\Helpers\Helpers();
            $generalSetting = $helper->general_setting_data();
            $companyName = $generalSetting->title ?? '-';
        } else {
            $companyName = DB::table(self::COMPANY_TABLE)->where('sno', $cycle->company_id)->value('company_name') ?? '-';
        }
        $stats = $this->cycleStats((int) $cycle->sno);
        return [
            'sno' => (int) $cycle->sno,
            'cycle_name' => (string) $cycle->cycle_name,
            'company_id' => (int) $cycle->company_id,
            'company_name' => $companyName ?? '-',
            'audit_date' => $cycle->audit_date? date('Y-m-d', strtotime($cycle->audit_date)): null,
            'category_id' => $cycle->category_id? (int) $cycle->category_id: null,
            'stock_category' => $this->categoryName($cycle->category_id),
            'status' => (int) $cycle->status,
            'status_text' => $this->cycleStatusText((int) $cycle->status),
            'total' => $stats['total'],
            'verified' => $stats['verified'],
            'discrepancies' => $stats['discrepancies'],
            'progress_text' => $stats['progress_text'],
        ];
    }
    public function dashboard(): JsonResponse
    {
        $active = AssetValidationCycleModel::query()->where('status', self::CYCLE_IN_PROGRESS)->count();
        $completed = AssetValidationCycleModel::query()->where('status', self::CYCLE_COMPLETED)->count();
        $total = AssetValidationCycleModel::query()->whereIn('status', [self::CYCLE_IN_PROGRESS,self::CYCLE_COMPLETED,])->count();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'in_progress' => (int) $active,
                'completed' => (int) $completed,
                'total' => (int) $total,
            ],
        ]);
    }
   public function masters(): JsonResponse
    {
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();
        $companies = CompanyModel::query()->where('status', 0)->orderBy('company_name', 'ASC')->get(['sno', 'company_name']);
        if ($generalSetting) {
            $companies->prepend((object) ['sno' => 0,'company_name' => $generalSetting->title ?? '-',]);
        }
        $categories = collect();
        if (Schema::hasTable(self::CATEGORY_TABLE)) {
            $categoryNameColumn = $this->findColumn(self::CATEGORY_TABLE,['stock_category', 'name']);
            if ($categoryNameColumn) {
                $categoryQuery = DB::table(self::CATEGORY_TABLE);
                if (Schema::hasColumn(self::CATEGORY_TABLE, 'status')) {
                    $categoryQuery->where('status', 0);
                }
                $categories = $categoryQuery->whereNotNull($categoryNameColumn)->orderBy($categoryNameColumn)->get(['sno', $categoryNameColumn])
                    ->map(fn ($category) => [
                        'sno' => (int) $category->sno,
                        'stock_category' => $category->{$categoryNameColumn},
                    ])
                    ->values();
            }
        }
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'companies' => $companies->map(fn ($company) => [
                    'sno' => (int) $company->sno,
                    'company_name' => $company->company_name,
                ])->values(),
                'categories' => $categories,
            ],
        ]);
    }
    public function list(Request $request): JsonResponse
    {
        $search = trim((string) $request->input('search', ''));
        $status = $request->input('status', 'all');
        $perPage = (int) $request->input('perpage', 25);
        $allowedPerPage = [5, 10, 25, 100, 500];
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 25;
        }
        $query = AssetValidationCycleModel::query()->whereIn('status', [self::CYCLE_IN_PROGRESS,self::CYCLE_COMPLETED,]);
        if ($status !== 'all' && $status !== '') {
            $query->where('status', (int) $status);
        }
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('cycle_name', 'LIKE', '%' . $search . '%');
                $q->orWhereIn('company_id', function ($sub) use ($search) {
                    $sub->select('sno')->from(self::COMPANY_TABLE)->where('company_name','LIKE','%' . $search . '%');
                });
            });
        }
        $cycles = $query->orderByDesc('sno')->paginate($perPage);
        $data = collect($cycles->items())->map(fn ($cycle) => $this->formatCycle($cycle))->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => $data,
            'pagination' => [
                'current_page' => $cycles->currentPage(),
                'last_page' => $cycles->lastPage(),
                'per_page' => $cycles->perPage(),
                'total' => $cycles->total(),
                'from' => $cycles->firstItem(),
                'to' => $cycles->lastItem(),
            ],
        ]);
    }
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'cycle_name' => ['required', 'string', 'max:255'],
            'company_id' => ['required','integer','min:0',
            function ($attribute, $value, $fail) {
                if ((int) $value === 0) {
                    return;
                }
                if (
                    !DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists()) {
                    $fail('The selected company is invalid.');
                }
            },
        ],
            'audit_date' => ['required', 'date'],
            'category_id' => ['nullable','integer','exists:egc_it_stock_category,sno',],
        ], [
            'cycle_name.required' => 'Cycle name is required.',
            'company_id.required' => 'Company is required.',
            'company_id.exists' => 'Selected company is invalid.',
            'audit_date.required' => 'Audit date is required.',
            'category_id.exists' => 'Selected category is invalid.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            $cycle = DB::transaction(function () use ($request) {
                $cycle = AssetValidationCycleModel::create([
                    'cycle_name' => trim($request->cycle_name),
                    'company_id' => (int) $request->company_id,
                    'audit_date' => $request->audit_date,
                    'category_id' => $request->filled('category_id')? (int) $request->category_id: null,
                    'status' => self::CYCLE_IN_PROGRESS,
                    'created_by' => $this->userId($request),
                    'updated_by' => $this->userId($request),
                ]);

                $assetQuery = DB::table(self::ASSET_TABLE)->where('company_id', $cycle->company_id);
                if (Schema::hasColumn(self::ASSET_TABLE, 'status')) {
                    $assetQuery->where('status', '!=', 2);
                }
               if ($cycle->category_id !== null) {
                    $assetQuery->where('stock_category_id',$cycle->category_id);
                }
                $assetIds = $assetQuery->pluck('sno');
                  foreach ($assetIds as $assetId) {
                    AssetValidationItemModel::create([
                        'cycle_id'  => $cycle->sno,
                        'asset_id'  => $assetId,
                        'status'    => self::ITEM_NOT_CHECKED,
                        'audit_note' => null,
                        'created_by' => $this->userId($request),
                        'updated_by' => $this->userId($request),
                    ]);
                }

                return $cycle;
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Validation cycle created successfully.',
                'data' => [
                    'cycle' => $this->formatCycle($cycle),
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('Asset validation cycle creation failed', [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => config('app.debug')
                    ? $e->getMessage()
                    : 'Unable to create validation cycle.',
            ], 500);
        }
    }
    public function show($id): JsonResponse
    {
        $cycle = AssetValidationCycleModel::query()->where('sno', $id)->whereIn('status', [self::CYCLE_IN_PROGRESS,self::CYCLE_COMPLETED,])->first();
        if (!$cycle) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Validation cycle not found.',
            ], 404);
        }
        $items = AssetValidationItemModel::query()->where('cycle_id', $cycle->sno)->orderBy('sno')->get();
        $assetTable = self::ASSET_TABLE;
        $assetTagColumn = $this->findColumn($assetTable,['asset_tag', 'asset_code', 'tag_number', 'asset_number']);
        $assetNameColumn = $this->findColumn($assetTable,['asset_name', 'item_name', 'name']);
        $assetCategoryColumn = $this->findColumn($assetTable,['stock_category_id']);
        $locationColumn = $this->findColumn($assetTable,['location', 'location_name', 'asset_location']);
        $assignedColumn = $this->findColumn($assetTable,['assigned_to', 'assigned_user', 'user_name', 'custodian']);
        $formattedItems = $items->map(function ($item) use (
            $assetTable,
            $assetTagColumn,
            $assetNameColumn,
            $assetCategoryColumn,
            $locationColumn,
            $assignedColumn
        ) {
            $asset = DB::table($assetTable)->where('sno', $item->asset_id)->first();
            $categoryName = 'Uncategorized';
            if ($asset &&$assetCategoryColumn &&!empty($asset->{$assetCategoryColumn})) {
                $categoryName = $this->categoryName($asset->{$assetCategoryColumn});
            }
            return [
                'sno' => (int) $item->sno,
                'asset_id' => (int) $item->asset_id,
                'asset_tag' => $asset && $assetTagColumn? ($asset->{$assetTagColumn} ?? '-'): 'Asset #' . $item->asset_id,
                'asset_name' => $asset && $assetNameColumn? ($asset->{$assetNameColumn} ?? '-'): '-',
                'stock_category' => $categoryName,
                'location' => $asset && $locationColumn? ($asset->{$locationColumn} ?? '-'): '-',
                'assigned_to' => $asset && $assignedColumn? ($asset->{$assignedColumn} ?? 'Unassigned'): 'Unassigned',
                'status' => (int) $item->status,
                'status_text' => $this->itemStatusText((int) $item->status),
                'audit_note' => $item->audit_note ?? '',
            ];
        })->values();
        return response()->json([
            'success' => true,
            'status' => 200,
            'data' => [
                'cycle' => $this->formatCycle($cycle),
                'items' => $formattedItems,
            ],
        ]);
    }
    public function update(Request $request, $id): JsonResponse
    {
        $cycle = AssetValidationCycleModel::query()->where('sno', $id)->where('status', self::CYCLE_IN_PROGRESS)->first();
        if (!$cycle) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Editable validation cycle not found.',
            ], 404);
        }
        $validator = Validator::make($request->all(), [
            'cycle_name' => ['required', 'string', 'max:255'],
            'company_id' => ['required','integer','min:0',
            function ($attribute, $value, $fail) {
                if ((int) $value === 0) {
                    return;
                }
                if (
                    !DB::table('egc_company')->where('sno', $value)->where('status', 0)->exists()) {
                    $fail('The selected company is invalid.');
                }
            },
        ],
            'audit_date' => ['required', 'date'],
            'category_id' => ['nullable','integer','exists:egc_it_stock_category,sno',],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            DB::transaction(function () use ($request, $cycle) {
                $oldCompanyId = (int) $cycle->company_id;
                $oldCategoryId = $cycle->category_id? (int) $cycle->category_id: null;
                $newCompanyId = (int) $request->company_id;
                $newCategoryId = $request->filled('category_id')? (int) $request->category_id: null;
                $scopeChanged = $oldCompanyId !== $newCompanyId|| $oldCategoryId !== $newCategoryId;
                $cycle->cycle_name = trim($request->cycle_name);
                $cycle->company_id = $newCompanyId;
                $cycle->audit_date = $request->audit_date;
                $cycle->category_id = $newCategoryId;
                $cycle->updated_by = $this->userId($request);
                $cycle->save();
                if ($scopeChanged) {
                    if (AssetValidationItemModel::query()->where('cycle_id', $cycle->sno)->where('status', '!=', self::ITEM_NOT_CHECKED)->exists())
                       {
                        throw ValidationException::withMessages(['category_id' =>'Company or scope cannot change after auditing has started.',]);
                    }
                    AssetValidationItemModel::query()->where('cycle_id', $cycle->sno)->delete();
                    $assets = DB::table(self::ASSET_TABLE)->where('company_id', $newCompanyId);
                    if (Schema::hasColumn(self::ASSET_TABLE, 'status')) {
                        $assets->where('status', '!=', 2);
                    }
                    if ($newCategoryId !== null) {
                        $assets->where('stock_category_id',$newCategoryId);
                    }
                    foreach ($assets->pluck('sno') as $assetId) {
                        AssetValidationItemModel::create([
                            'cycle_id' => $cycle->sno,
                            'asset_id' => $assetId,
                            'status' => self::ITEM_NOT_CHECKED,
                            'audit_note' => null,
                            'created_by' => $this->userId($request),
                            'updated_by' => $this->userId($request),
                        ]);
                    }
                }
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Validation cycle updated successfully.',
                'data' => [
                    'cycle' => $this->formatCycle($cycle->fresh()),
                ],
            ]);
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            Log::error('Asset validation cycle update failed', ['cycle_id' => $id,'message' => $e->getMessage(),]);
            return response()->json([
                'success' => false,
                'status' => 500,
                'message' => 'Unable to update validation cycle.',
            ], 500);
        }
    }
    public function audit(Request $request, $cycleId, $itemId): JsonResponse
    {
        $validator = Validator::make($request->all(), ['status' => ['required','integer','in:1,3,4',],'audit_note' => ['nullable', 'string', 'max:2000'],], [
            'status.in' =>'Audit result must be Verified, Missing, or Damaged.',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }
        try {
            $result = DB::transaction(function () use ($request,$cycleId,$itemId) {
                $cycle = AssetValidationCycleModel::query()->where('sno', $cycleId)->lockForUpdate()->first();
                if (!$cycle ||(int) $cycle->status !== self::CYCLE_IN_PROGRESS) {
                    throw new \RuntimeException('Only in-progress cycles can be audited.');
                }
                $item = AssetValidationItemModel::query()->where('cycle_id', $cycleId)->where('sno', $itemId)->lockForUpdate()->first();
                if (!$item) {
                    throw new \RuntimeException('Audit item not found.');
                }
                $item->status = (int) $request->status;
                $item->audit_note = trim((string) $request->input('audit_note', '')) ?: null;
                $item->updated_by = $this->userId($request);
                $item->save();
                $total = AssetValidationItemModel::query()->where('cycle_id', $cycleId)->count();
                $allVerified = $total > 0 &&!AssetValidationItemModel::query()->where('cycle_id', $cycleId)->where('status', '!=', self::ITEM_VERIFIED)->exists();
                $cycle->status = $allVerified? self::CYCLE_COMPLETED: self::CYCLE_IN_PROGRESS;
                $cycle->updated_by = $this->userId($request);
                $cycle->save();
                return ['cycle' => $cycle,'item' => $item,];
            });
            return response()->json([
                'success' => true,
                'status' => 200,
                'message' => 'Audit result saved successfully.',
                'data' => ['cycle' => $this->formatCycle($result['cycle']->fresh()),
                    'item' => [
                        'sno' => (int) $result['item']->sno,
                        'status' => (int) $result['item']->status,
                        'status_text' => $this->itemStatusText((int) $result['item']->status),
                        'audit_note' => $result['item']->audit_note,
                    ],
                ],
            ]);
        } catch (\Throwable $e) {
            Log::error('Asset validation audit failed', [
                'cycle_id' => $cycleId,
                'item_id' => $itemId,
                'message' => $e->getMessage(),
            ]);
            return response()->json([
                'success' => false,
                'status' => 422,
                'message' => $e->getMessage(),
            ], 422);
        }
    }
    public function Delete($id,Request $request): JsonResponse
    {
        $cycle = AssetValidationCycleModel::query()->where('sno', $id)->whereIn('status', [self::CYCLE_IN_PROGRESS,self::CYCLE_COMPLETED,])->first();
        if (!$cycle) {
            return response()->json([
                'success' => false,
                'status' => 404,
                'message' => 'Validation cycle not found.',
            ], 404);
        }
        $cycle->status = self::CYCLE_DELETED;
        $cycle->updated_by = $this->userId($request);
        $cycle->save();
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Validation cycle deleted successfully.',
        ]);
    }
}
