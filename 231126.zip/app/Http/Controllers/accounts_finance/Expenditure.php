<?php


namespace App\Http\Controllers\accounts_finance;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CompanyModel;
use App\Models\PaymenttypeModel;
use App\Models\PaymentmodeModel;
use App\Models\CredentialModel;
// use App\Models\ChartofAccountModel;
use App\Models\StateModel;
use App\Models\CategoriesModel;
use App\Models\CommonExpenditureModel;


class Expenditure extends Controller
{
  
public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $typefilter = $request->typefilter ?? '';
        $categoryfilter = $request->categoryfilter ?? '';
        $companyfilter = $request->companyfilter ?? '';
        $from_date_filter = $request->from_date ?? '';
        $to_date_filter = $request->to_date ?? '';
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        
        $level = CommonExpenditureModel::where('egc_acc_common_expenditure.status', '!=', 2)
      ->select('egc_acc_common_expenditure.*','egc_company.company_name','egc_acct_payment_mode.payment_mode','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_acc_common_expenditure.company_id', 'egc_company.sno')
      ->join('egc_acct_payment_mode', 'egc_acc_common_expenditure.payment_mode_id', 'egc_acct_payment_mode.sno')
      ->join('egc_acct_categories', 'egc_acc_common_expenditure.category_id', 'egc_acct_categories.sno');

        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('payment_mode', 'LIKE', "%{$search_filter}%");
                      
              });
          }
          $general_setting=$helper->general_setting_data();
          if($typefilter){
            $level->where('egc_acc_common_expenditure.payment_type', 'LIKE', $typefilter);
          }
          if($categoryfilter){
            $level->where('egc_acc_common_expenditure.category_id', 'LIKE', $categoryfilter);
          }
          
          if($companyfilter != ''){
          if($companyfilter == '0'){
             $level->where('egc_acc_common_expenditure.company_id','LIKE', $companyfilter);
          }else{
            $level->where('egc_acc_common_expenditure.company_id', 'LIKE', $companyfilter);
          }
        }
      
        if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $level->whereBetween('egc_acc_common_expenditure.date', [$fromDate, $toDate]);
        }
       $level=$level->orderBy('sno', 'desc')->paginate($perpage);
        if ($request->ajax()) {

            $data = $level->map(function ($item) use ($helper) {   
                $general_setting=$helper->general_setting_data();
              if($item->company_id == 0){
                    $item->company_name=$general_setting->title;                      
                }
                return [
                    'sno' => $item->sno,
                    'payment_status' => $item->payment_status,
                    'date' => $item->date,
                    'company' => $item->company_name,
                    'payment_mode' => $item->payment_mode,
                    'payment_type' => $item->payment_type,
                    'category' => $item->categories,
                    'amount' => $item->amount,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });
        
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }

        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
   
        $mode_list = PaymentmodeModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $category_list = CategoriesModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $total_amount = CommonExpenditureModel::where('egc_acc_common_expenditure.status', '!=', 2)
         ->sum('egc_acc_common_expenditure.amount');
         $monthlyExpense=CommonExpenditureModel::where('egc_acc_common_expenditure.status', '!=', 2)
        ->whereYear('egc_acc_common_expenditure.date',now()->year)
        ->whereMonth('egc_acc_common_expenditure.date',now()->month)
        ->sum('egc_acc_common_expenditure.amount');
         $lastmonth=CommonExpenditureModel::where('egc_acc_common_expenditure.status', '!=', 2)
        ->whereYear('egc_acc_common_expenditure.date',now()->year)
        ->whereMonth('egc_acc_common_expenditure.date', now()->subMonth()->month)
        ->sum('egc_acc_common_expenditure.amount');
         $pending=CommonExpenditureModel::where('egc_acc_common_expenditure.payment_status', '!=', 1)
         ->where('egc_acc_common_expenditure.status', '!=', 2)
        ->count('egc_acc_common_expenditure.sno');
        return view('content.accounts_finance.common_expenditure.common_expense', [
          'level' => $level,
          'perpage' => $perpage,
          'company_list' => $company_list,
          'total_amount' => $total_amount,
          'monthlyExpense' =>$monthlyExpense,
          'lastmonth' =>$lastmonth,
          'pending' =>$pending,
          'mode_list' => $mode_list,
          'category_list' => $category_list,
          'search_filter' => $search_filter
        ]);
    }

    
    
    // public function list()
    // {
    //     $knowledge_level = CredentialModel::where('status', 0)->orderBy('sno', 'desc')->get();

    //     return response([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $knowledge_level,
    //     ], 200);
    // }

    public function Add(Request $request)
    {
    
        $validator = Validator::make($request->all(), [
            
            'payment_mode' => 'required|exists:egc_acct_payment_mode,sno',
            'category_type' => 'required|exists:egc_acct_categories,sno',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $company_name =$request->company_name ?? 0;
            
            $payment_mode =$request->input('payment_mode');
            $category=$request->input('category_type');
            $payment_type = $request->payment_type;
            $amount =$request->amount;
                          
            $chk = CommonExpenditureModel::where('company_id', ucwords($company_name))->where('category_id',ucwords($category))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Category has been  already created!',
                ]);
            } else {
                
                $add_category = new CommonExpenditureModel();
                $add_category->company_id = $company_name;
                $add_category->payment_type = $payment_type;
                $add_category->payment_mode_id = $payment_mode;
                $add_category->category_id = $category;
                $add_category->date = $request->date_acct;
                $add_category->amount = $amount;
              
                $add_category->vendor = $request->vendor;
                $add_category->reference = $request->reference;
                $add_category->created_by = 1;
                $add_category->updated_by = 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Categories added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Categories!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

    public function Edit($id)
    {
        
        $data = CommonExpenditureModel::where('egc_acc_common_expenditure.status', '!=', 2)
      ->select('egc_acc_common_expenditure.*','egc_company.company_name','egc_acct_payment_mode.payment_mode','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_acc_common_expenditure.company_id', 'egc_company.sno')
      ->join('egc_acct_payment_mode', 'egc_acc_common_expenditure.payment_mode_id', 'egc_acct_payment_mode.sno')
      ->join('egc_acct_categories', 'egc_acc_common_expenditure.category_id', 'egc_acct_categories.sno')
      ->orderBy('egc_acc_common_expenditure.sno', 'desc')->where('egc_acc_common_expenditure.sno', $id)->first();
       

      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Common Expenditure not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'category' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $category = $request->category;
            $company = $request->company;
            $type = $request->type;
            $mode = $request->mode;
            $vendor = $request->vendor;
            $notes = $request->notes;
            $amount = $request->amount;
            $date = $request->date;
            

            $upd_CourseCategoryModel = CommonExpenditureModel::where('sno', $id)->first();

             $chk = CommonExpenditureModel::where('company_id', ucwords($company))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Category has been  already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->category_id = $category;
            $upd_CourseCategoryModel->company_id = $company;
            $upd_CourseCategoryModel->payment_type = $type;
            $upd_CourseCategoryModel->payment_mode_id = $mode;
            $upd_CourseCategoryModel->vendor = $vendor;
            $upd_CourseCategoryModel->notes = $notes;
            $upd_CourseCategoryModel->amount = $amount;
            $upd_CourseCategoryModel->date = $date;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($Id)
    {
        $upd_CourseCategoryModel = CommonExpenditureModel::where('sno', $Id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = CommonExpenditureModel::where('sno', $id)->first();
       
        $upd_CourseCategoryModel->payment_status = $request->input('payment_status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
