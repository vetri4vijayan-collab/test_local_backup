<?php


namespace App\Http\Controllers\accounts_finance;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CompanyModel;
use App\Models\PaymenttypeModel;
use App\Models\PaymentmodeModel;
use App\Models\CredentialModel;
use App\Models\ChartofAccountModel;
use App\Models\StateModel;
use App\Models\CategoriesModel;
use App\Models\DailyaccountsModel;


class DailyAccounts extends Controller
{
  
public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $typefilter = $request->typefilter ?? '';
        $categoryfilter = $request->categoryfilter ?? '';
        $companyfilter = $request->companyfilter ?? '';
        $from_date_filter = $request->from_date ?? '';
        $to_date_filter = $request->to_date ?? '';
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        
        $level = DailyaccountsModel::where('egc_finc_daily_account.status', '!=', 2)
      ->select('egc_finc_daily_account.*','egc_company.company_name','egc_acct_payment_mode.payment_mode','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_finc_daily_account.company_id', 'egc_company.sno')
      ->join('egc_acct_payment_mode', 'egc_finc_daily_account.payment_mode_id', 'egc_acct_payment_mode.sno')
      ->join('egc_acct_categories', 'egc_finc_daily_account.category_id', 'egc_acct_categories.sno');

        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('payment_mode', 'LIKE', "%{$search_filter}%");
                      
              });
          }
          $general_setting=$helper->general_setting_data();
          if($typefilter){
            $level->where('egc_finc_daily_account.account_type', 'LIKE', $typefilter);
          }
          if($categoryfilter){
            $level->where('egc_finc_daily_account.category_id', 'LIKE', $categoryfilter);
          }
          
          if($companyfilter != ''){
          if($companyfilter == '0'){
             $level->where('egc_finc_daily_account.company_id','LIKE', $companyfilter);
          }else{
            $level->where('egc_finc_daily_account.company_id', 'LIKE', $companyfilter);
          }
        }
      
        if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $level->whereBetween('egc_finc_daily_account.date', [$fromDate, $toDate]);
        }
      
       $level=$level->orderBy('sno', 'ASC')->paginate($perpage);
       
        if ($request->ajax()) {
            $runningAmount = 0;
            $data = $level->getCollection()->map(function ($item) use ($helper, &$runningAmount) {
                $general_setting = $helper->general_setting_data();
                if ($item->company_id == 0) {
                    $item->company_name = $general_setting->title;
                }
                if ($item->credit_or_debit == 1) {
                    $runningAmount += $item->amount;
                } elseif ($item->credit_or_debit == 2) {
                    $runningAmount -= $item->amount;
                }
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'date' => $item->date,
                    'company' => $item->company_name,
                    'account_type' => $item->account_type,
                    'payment_mode' => $item->payment_mode,
                    'credit_or_debit' => $item->credit_or_debit,
                    'category' => $item->categories,
                    'amount' => $item->amount,
                    'running_amount' => $runningAmount,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }

        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
   
        $mode_list = PaymentmodeModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $category_list = CategoriesModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    
        return view('content.accounts_finance.daily_accounts.daily_accounts', [
          'level' => $level,
          'perpage' => $perpage,
          'company_list' => $company_list,
          'mode_list' => $mode_list,
          'category_list' => $category_list,
          'search_filter' => $search_filter
        ]);
    }

    
    

    public function Add(Request $request)
    {
    
 
        $validator = Validator::make($request->all(), [
           
            'payment_mode' => 'required|exists:egc_acct_payment_mode,sno',
            'category_type' => 'required|exists:egc_acct_categories,sno',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $company_name =$request->company_name ?? 0;
            
            $payment_mode =$request->input('payment_mode');
            $category=$request->input('category_type');
            $account_type = $request->payment_type;
            $amount =$request->amount;
            $amt = DailyaccountsModel::orderBy('amount', 'desc')->first();
            if($account_type == 'Income'){
                $credit_or_debit=1;
            }
            else if($account_type == 'Expense'){
                $credit_or_debit=2;
            }
            
            $chk = DailyaccountsModel::where('company_id', ucwords($company_name))->where('category_id',ucwords($category))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Category has been  already created!',
                ]);
            } else {
                
                $add_category = new DailyaccountsModel();
                $add_category->company_id = $company_name;
                $add_category->account_type = $account_type;
                $add_category->payment_mode_id = $payment_mode;
                $add_category->credit_or_debit = $credit_or_debit;
                $add_category->category_id = $category;
                $add_category->date = $request->date_acct;
                $add_category->amount = $amount;
                $add_category->vendor_id = $request->vendor;
                $add_category->reference = $request->reference;
                $add_category->created_by = 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Categories added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Categories!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

    public function Edit($id)
    {
        
        $data = DailyaccountsModel::where('egc_finc_daily_account.status', '!=', 2)
      ->select('egc_finc_daily_account.*','egc_company.company_name','egc_acct_payment_mode.payment_mode','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_finc_daily_account.company_id', 'egc_company.sno')

      ->join('egc_acct_payment_mode', 'egc_finc_daily_account.payment_mode_id', 'egc_acct_payment_mode.sno')
      ->join('egc_acct_categories', 'egc_finc_daily_account.category_id', 'egc_acct_categories.sno')
      ->orderBy('egc_finc_daily_account.sno', 'desc')->where('egc_finc_daily_account.sno', $id)->first();
       

      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Daily Accounts not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {
        

        $validator = Validator::make($request->all(), [
            'category' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $category = $request->category;
            $company = $request->company;
            $type = $request->type;
            $mode = $request->mode;
            $vendor = $request->vendor;
            $notes = $request->notes;
            $amount = $request->amount;
            $date = $request->date;
            

            $upd_CourseCategoryModel = DailyaccountsModel::where('sno', $id)->first();



             $chk = DailyaccountsModel::where('company_id', ucwords($company))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Category has been  already assigned!',
                        'data' => null,

                    ], 200);
                } 
            }
            

            $upd_CourseCategoryModel->category_id = $category;
            $upd_CourseCategoryModel->company_id = $company;
            $upd_CourseCategoryModel->account_type = $type;
            // $upd_CourseCategoryModel->credit_or_debit = $credit_or_debit;
            $upd_CourseCategoryModel->payment_mode_id = $mode;
            $upd_CourseCategoryModel->vendor_id = $vendor;
            $upd_CourseCategoryModel->notes = $notes;
            $upd_CourseCategoryModel->amount = $amount;
            $upd_CourseCategoryModel->date = $date;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($Id)
    {
        $upd_CourseCategoryModel = DailyaccountsModel::where('sno', $Id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = DailyaccountsModel::where('sno', $id)->first();
        

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
