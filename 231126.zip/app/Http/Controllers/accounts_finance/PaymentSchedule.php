<?php


namespace App\Http\Controllers\accounts_finance;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CompanyModel;
use App\Models\PaymenttypeModel;
use App\Models\PaymentmodeModel;
use App\Models\CredentialModel;
// use App\Models\ChartofAccountModel;
use App\Models\StateModel;
use App\Models\CategoriesModel;
use App\Models\PaymentscheduleModel;


class Paymentschedule extends Controller
{
  
public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $typefilter = $request->typefilter ?? '';
        $payeefilter = $request->payeefilter ?? '';
        $companyfilter = $request->companyfilter ?? '';
        $from_date_filter = $request->from_date ?? '';
        $to_date_filter = $request->to_date ?? '';
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        
        $level = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '!=', 2)
      ->select('egc_acc_payment_schedule.*','egc_company.company_name','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_acc_payment_schedule.company_id', 'egc_company.sno')

      ->join('egc_acct_categories', 'egc_acc_payment_schedule.category_id', 'egc_acct_categories.sno');

        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('title', 'LIKE', "%{$search_filter}%");
                      
              });
          }
          $general_setting=$helper->general_setting_data();
          if($typefilter){
            $level->where('egc_acc_payment_schedule.status','LIKE', $typefilter);
          }
          if($payeefilter){
            $level->where('egc_acc_payment_schedule.payee_type', 'LIKE', $payeefilter);
          }
          
          if($companyfilter != ''){
          if($companyfilter == '0'){
             $level->where('egc_acc_payment_schedule.company_id','LIKE', $companyfilter);
          }else{
            $level->where('egc_acc_payment_schedule.company_id', 'LIKE', $companyfilter);
          }
        }
      
        if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $level->whereBetween('egc_acc_payment_schedule.due_date', [$fromDate, $toDate]);
        }
       $level=$level->orderBy('sno', 'desc')->paginate($perpage);

       
       
        if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {   
                $general_setting=$helper->general_setting_data();
              if($item->company_id == 0){
                    $item->company_name=$general_setting->title;                      
                }
                $check=$item->status;
           
                if($check==0){
                  $current_date = now();
                 $payment_date=$item->due_date;
                 
                if($current_date>$payment_date){
                    $item->status=3;  
                }
                }
                return [
                    'sno' => $item->sno,
                    'title'=>$item->title,
                    'status' => $item->status,
                    'due_date' => $item->due_date,
                    'company' => $item->company_name,
                    'payee_type' => $item->payee_type,
                    'recurrence' => $item->recurrence,
                    'vendor' => $item->vendor,
                    'category' => $item->categories,
                    'amount' => $item->amount,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });
        
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }
        
            $overdue_amount = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
                    ->whereYear('egc_acc_payment_schedule.due_date',now()->year)
                    ->whereMonth('egc_acc_payment_schedule.due_date',now()->subMonth()->month)
                    ->sum('egc_acc_payment_schedule.amount');
      
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
   
        $mode_list = PaymentmodeModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $category_list = CategoriesModel::where('status', 0)->where('account_type','=','Expense')->orderBy('sno', 'ASC')->get();

        $pending_amount = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
        ->whereYear('egc_acc_payment_schedule.due_date',now()->year)
        ->whereMonth('egc_acc_payment_schedule.due_date',now()->month)
         ->sum('egc_acc_payment_schedule.amount');

         $pending_subpara = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
         ->whereYear('egc_acc_payment_schedule.due_date',now()->year)
        ->whereMonth('egc_acc_payment_schedule.due_date',now()->month)
         ->count('egc_acc_payment_schedule.sno');

        $paid_amount = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 1)
         ->sum('egc_acc_payment_schedule.amount');

         $paid_subpara = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 1)
         ->count('egc_acc_payment_schedule.sno');

        // $overdue_amount = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 3)
        //  ->sum('egc_acc_payment_schedule.amount');

         $overdue_subpara = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
         ->whereYear('egc_acc_payment_schedule.due_date',now()->year)
         ->whereMonth('egc_acc_payment_schedule.due_date',now()->subMonth()->month)
         ->count('egc_acc_payment_schedule.sno');

         $upcoming_amount = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
            ->whereBetween('egc_acc_payment_schedule.due_date', [
            now()->toDateTimeString(), 
            now()->addDays(7)->toDateTimeString()
            ])
         ->sum('egc_acc_payment_schedule.amount');

         $upcoming_para = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '=', 0)
            ->whereBetween('egc_acc_payment_schedule.due_date', [
            now()->toDateTimeString(), 
            now()->addDays(7)->toDateTimeString()
            ])
         ->count('egc_acc_payment_schedule.sno');


        return view('content.accounts_finance.payment_schedule.payment_schedule', [
          'level' => $level,
          'perpage' => $perpage,
          'company_list' => $company_list,
          'pending_amount' => $pending_amount,
          'overdue_amount' =>$overdue_amount,
          'paid_amount' =>$paid_amount,
          'pending_subpara' =>$pending_subpara,
          'paid_subpara' =>$paid_subpara,
          'overdue_subpara' =>$overdue_subpara,
          'upcoming_amount' =>$upcoming_amount,
          'upcoming_para' =>$upcoming_para,
          'mode_list' => $mode_list,
          'category_list' => $category_list,
          'search_filter' => $search_filter
        ]);
    }

    
    
    // public function list()
    // {
    //     $knowledge_level = CredentialModel::where('status', 0)->orderBy('sno', 'desc')->get();

    //     return response([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $knowledge_level,
    //     ], 200);
    // }

    public function Add(Request $request)
    {

        
        $validator = Validator::make($request->all(), [
            
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $company_name =$request->company_name ?? 0;
            
            $category_type =$request->category_type;
           
            $payee_type = $request->payee_type;
            $amount =$request->amount;
                          
            $chk = PaymentscheduleModel::where('company_id', ucwords($company_name))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Schedule has been  already created!',
                ]);
            } else {
                
                $add_category = new PaymentscheduleModel();

                $add_category->company_id = $company_name;
                $add_category->title = $request->title;
                $add_category->payee_type = $request->payee_type;
                $add_category->category_id = $category_type;
                $add_category->due_date = $request->date_acct;
                $add_category->amount = $amount;
                $add_category->vendor = $request->vendor;
                $add_category->recurrence = $request->recurrence_type;
                $add_category->created_by = 1;
                $add_category->updated_by = 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Schedule added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Schedule!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

    public function Edit($id)
    {
        
        $data = PaymentscheduleModel::where('egc_acc_payment_schedule.status', '!=', 2)
      ->select('egc_acc_payment_schedule.*','egc_company.company_name','egc_acct_categories.categories')
      ->leftJoin('egc_company', 'egc_acc_payment_schedule.company_id', 'egc_company.sno')
      ->join('egc_acct_categories', 'egc_acc_payment_schedule.category_id', 'egc_acct_categories.sno')
      ->orderBy('egc_acc_payment_schedule.sno', 'desc')->where('egc_acc_payment_schedule.sno', $id)->first();
       

      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Payment Schedule not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'category' => 'required|max:255',
            'company' => 'required|max:255',
            'payee_type' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $category = $request->category;
            $company = $request->company;
            $payee_type = $request->payee_type;
            $recurrence = $request->recurrence;
            $vendor = $request->vendor;
            $title = $request->title;
            $amount = $request->amount;
            $due_date = $request->due_date;
            

            $upd_CourseCategoryModel = PaymentscheduleModel::where('sno', $id)->first();

             $chk = PaymentscheduleModel::where('company_id', ucwords($company))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Category has been  already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->category_id = $category;
            $upd_CourseCategoryModel->company_id = $company;
            $upd_CourseCategoryModel->payee_type = $payee_type;
            $upd_CourseCategoryModel->recurrence = $recurrence;
            $upd_CourseCategoryModel->vendor = $vendor;
            $upd_CourseCategoryModel->title = $title;
            $upd_CourseCategoryModel->amount = $amount;
            $upd_CourseCategoryModel->due_date = $due_date;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = PaymentscheduleModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = PaymentscheduleModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
