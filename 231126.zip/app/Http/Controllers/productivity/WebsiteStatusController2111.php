<?php

namespace App\Http\Controllers\productivity;

use App\Services\Productivity\ProductivityAccessService;
use App\Services\Productivity\WebsiteStatusMonitorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

class WebsiteStatusController extends ProductivityBaseController
{
    private const TABLE = 'egc_tool_website_status';
    private const WEBSITE_FOR = ['In-house', 'Client'];
    private const INTERNAL_CHECK_INTERVAL = 1;

    public function __construct(
        ProductivityAccessService $access,
        protected WebsiteStatusMonitorService $monitor
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.website_status.index');
    }

 
    public function lookups(Request $request): JsonResponse
    {
        $this->ensureReadable($request);

        $canSelectAll = $this->access->isGroupAdmin($request) || $this->access->isAuditor($request);
        $currentCompanyId = $this->access->companyId($request);
        $companies = collect();

        if ($canSelectAll || $currentCompanyId === 0) {
            $mainTitle = trim((string) DB::table('egc_general_settings')->where('sno', 1)->value('title'));
            $companies->push([
                'sno' => 0,
                'company_name' => $mainTitle !== '' ? $mainTitle : 'Main Company',
                'is_main' => true,
            ]);
        }

        $companyQuery = DB::table('egc_company')
            ->where('status', 0)
            ->where('sno', '>', 0)
            ->orderBy('company_name');

        if (!$canSelectAll) {
            if ($currentCompanyId !== null && $currentCompanyId > 0) {
                $companyQuery->where('sno', $currentCompanyId);
            } else {
                $companyQuery->whereRaw('1 = 0');
            }
        }

        $companyRows = $companyQuery->get(['sno', 'company_name'])->map(fn ($company) => [
            'sno' => (int) $company->sno,
            'company_name' => (string) $company->company_name,
            'is_main' => false,
        ]);

        $companies = $companies->concat($companyRows)->values();

        return response()->json([
            'status' => 200,
            'data' => [
                'companies' => $companies,
                'can_select_company' => $canSelectAll,
                'current_company_id' => $currentCompanyId,
                'website_for' => self::WEBSITE_FOR,
            ],
        ]);
    }

    public function data(Request $request): JsonResponse
    {
        $this->ensureReadable($request);
        $query = $this->baseQuery($request);
        $this->applyFilters($query, $request);

        $summaryQuery = $this->baseQuery($request);
        $summary = [
            'total' => (clone $summaryQuery)->count(),
            'up' => (clone $summaryQuery)->where('w.health_status', 'Up')->count(),
            'down' => (clone $summaryQuery)->where('w.health_status', 'Down')->count(),
            'unknown' => (clone $summaryQuery)->where('w.health_status', 'Unknown')->count(),
        ];

        $perPage = min(max((int) $request->input('per_page', 10), 5), 500);
        $rows = $query
            ->orderByRaw("CASE w.health_status WHEN 'Down' THEN 0 WHEN 'Unknown' THEN 1 ELSE 2 END")
            ->orderBy('w.website_name')
            ->paginate($perPage);

        return response()->json([
            'status' => 200,
            'data' => $rows->items(),
            'current_page' => $rows->currentPage(),
            'last_page' => max(1, $rows->lastPage()),
            'per_page' => $rows->perPage(),
            'total' => $rows->total(),
            'summary' => $summary,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403, 'You do not have permission to add monitored websites.');

        $data = $request->validate([
            'website_name' => ['required', 'string', 'max:180'],
            'website_url' => ['required', 'string', 'max:2000'],
            'company_id' => ['required', 'integer', 'min:0'],
            'website_for' => ['required', 'in:In-house,Client'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ]);

        $companyId = $this->normaliseCompanyId((int) $data['company_id'], $request);
        $url = $this->normaliseUrl($data['website_url']);
        $now = now();

        $id = DB::table(self::TABLE)->insertGetId([
            'company_id' => $companyId,
            'website_name' => trim($data['website_name']),
            'website_url' => $url,
            'website_for' => $data['website_for'],
            'notes' => $this->nullableString($data['notes'] ?? null),
            'health_status' => 'Unknown',
            'http_status_code' => null,
            'response_time_ms' => null,
            'last_checked_at' => null,
            'last_success_at' => null,
            'last_error' => null,
            'check_interval_minutes' => self::INTERNAL_CHECK_INTERVAL,
            'next_check_at' => $now,
            'is_active' => 1,
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $record = $this->findRow($id, $request);
        $this->audit($request, 'Website Status', 'website_created', 'website', (int) $id, null, (array) $record);

        return response()->json([
            'status' => 201,
            'message' => 'Website added to the monitoring list. Its first status check will run automatically.',
            'data' => $record,
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403, 'You do not have permission to edit monitored websites.');
        $before = $this->findRawScoped($id, $request);

        $data = $request->validate([
            'website_name' => ['required', 'string', 'max:180'],
            'website_url' => ['required', 'string', 'max:2000'],
            'company_id' => ['required', 'integer', 'min:0'],
            'website_for' => ['required', 'in:In-house,Client'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ]);

        $companyId = $this->normaliseCompanyId((int) $data['company_id'], $request);
        $url = $this->normaliseUrl($data['website_url']);
        $isActive = true;
        $urlChanged = rtrim((string) $before->website_url, '/') !== rtrim($url, '/');

        $update = [
            'company_id' => $companyId,
            'website_name' => trim($data['website_name']),
            'website_url' => $url,
            'website_for' => $data['website_for'],
            'notes' => $this->nullableString($data['notes'] ?? null),
            'check_interval_minutes' => self::INTERNAL_CHECK_INTERVAL,
            'is_active' => $isActive ? 1 : 0,
            'updated_by' => $this->uid(),
            'updated_at' => now(),
        ];

        if ($urlChanged || (int) $before->is_active === 0) {
            $update['next_check_at'] = now();
        }

        if ($urlChanged || (int) $before->is_active === 0) {
            $update['health_status'] = 'Unknown';
            $update['http_status_code'] = null;
            $update['response_time_ms'] = null;
            $update['last_error'] = null;
            $update['last_checked_at'] = null;
            $update['last_success_at'] = null;
        }

        DB::table(self::TABLE)->where('sno', $id)->update($update);
        $record = $this->findRow($id, $request);
        $this->audit($request, 'Website Status', 'website_updated', 'website', $id, (array) $before, (array) $record);

        return response()->json([
            'status' => 200,
            'message' => 'Website details updated successfully.',
            'data' => $record,
        ]);
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403, 'You do not have permission to remove monitored websites.');
        $before = $this->findRawScoped($id, $request);

        DB::table(self::TABLE)->where('sno', $id)->update([
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
            'updated_at' => now(),
        ]);

        $this->audit($request, 'Website Status', 'website_deleted', 'website', $id, (array) $before, null);
        return response()->json(['status' => 200, 'message' => 'Website removed from monitoring.']);
    }

    public function checkNow(Request $request, int $id): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403, 'You do not have permission to run a website check.');
        $this->findRawScoped($id, $request);

        try {
            $this->monitor->checkNow($id);
            return response()->json([
                'status' => 200,
                'message' => 'Website status checked.',
                'data' => $this->findRow($id, $request),
            ]);
        } catch (Throwable $exception) {
            report($exception);
            return response()->json([
                'status' => 422,
                'message' => $exception->getMessage() ?: 'Unable to check this website.',
            ], 422);
        }
    }

    public function statuses(Request $request): JsonResponse
    {
        $this->ensureReadable($request);
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:500'],
            'ids.*' => ['required', 'integer', 'min:1'],
        ]);

        $query = DB::table(self::TABLE . ' as w')
            ->whereNull('w.deleted_at')
            ->whereIn('w.sno', array_values(array_unique(array_map('intval', $data['ids']))));
        $this->applyWebsiteScope($query, $request);

        $rows = $query->get([
            'w.sno',
            'w.health_status',
            'w.http_status_code',
            'w.response_time_ms',
            'w.last_checked_at',
            'w.last_success_at',
            'w.last_error',
            'w.is_active',
            'w.next_check_at',
        ]);

        $summaryQuery = DB::table(self::TABLE . ' as w')->whereNull('w.deleted_at');
        $this->applyWebsiteScope($summaryQuery, $request);
        $summary = [
            'total' => (clone $summaryQuery)->count(),
            'up' => (clone $summaryQuery)->where('w.health_status', 'Up')->count(),
            'down' => (clone $summaryQuery)->where('w.health_status', 'Down')->count(),
            'unknown' => (clone $summaryQuery)->where('w.health_status', 'Unknown')->count(),
        ];

        return response()->json(['status' => 200, 'data' => $rows, 'summary' => $summary]);
    }

    public function refreshStatuses(Request $request): JsonResponse
    {
        $this->ensureReadable($request);

        $data = $request->validate([
            'ids' => ['nullable', 'array', 'max:500'],
            'ids.*' => ['required', 'integer', 'min:1'],
        ]);

        $isGlobalScope =
            $this->access->isGroupAdmin($request) ||
            $this->access->isAuditor($request);

        if ($isGlobalScope) {
            $this->monitor->checkDueForScope(null, 3);
        } else {
            $companyId = $this->access->companyId($request);

            if ($companyId !== null) {
                $this->monitor->checkDueForScope((int) $companyId, 3);
            }
        }

        $query = DB::table(self::TABLE . ' as w')->whereNull('w.deleted_at');
        $this->applyWebsiteScope($query, $request);

        if (!empty($data['ids'])) {
            $query->whereIn('w.sno', array_values(array_unique(array_map('intval', $data['ids']))));
        }

        $rows = $query->get([
            'w.sno',
            'w.health_status',
            'w.http_status_code',
            'w.response_time_ms',
            'w.last_checked_at',
            'w.last_success_at',
            'w.last_error',
            'w.is_active',
            'w.next_check_at',
        ]);

        $summaryQuery = DB::table(self::TABLE . ' as w')->whereNull('w.deleted_at');
        $this->applyWebsiteScope($summaryQuery, $request);
        $summary = [
            'total' => (clone $summaryQuery)->count(),
            'up' => (clone $summaryQuery)->where('w.health_status', 'Up')->count(),
            'down' => (clone $summaryQuery)->where('w.health_status', 'Down')->count(),
            'unknown' => (clone $summaryQuery)->where('w.health_status', 'Unknown')->count(),
        ];

        return response()->json(['status' => 200, 'data' => $rows, 'summary' => $summary]);
    }

    private function baseQuery(Request $request)
    {
        $mainTitle = trim((string) DB::table('egc_general_settings')->where('sno', 1)->value('title'));
        if ($mainTitle === '') $mainTitle = 'Main Company';

        $query = DB::table(self::TABLE . ' as w')
            ->leftJoin('egc_company as c', function ($join) {
                $join->on('c.sno', '=', 'w.company_id')->where('c.status', 0);
            })
            ->whereNull('w.deleted_at')
            ->select('w.*')
            ->selectRaw('CASE WHEN w.company_id = 0 THEN ? ELSE COALESCE(c.company_name, ?) END AS company_name', [$mainTitle, 'Unknown company']);

        $this->applyWebsiteScope($query, $request);
        return $query;
    }

    private function applyFilters($query, Request $request): void
    {
        if ($request->filled('health_status') && in_array($request->input('health_status'), ['Up', 'Down', 'Unknown'], true)) {
            $query->where('w.health_status', $request->input('health_status'));
        }

        if ($request->filled('website_for') && in_array($request->input('website_for'), self::WEBSITE_FOR, true)) {
            $query->where('w.website_for', $request->input('website_for'));
        }

        if (($this->access->isGroupAdmin($request) || $this->access->isAuditor($request))
            && $request->has('company_id') && $request->input('company_id') !== '' && $request->input('company_id') !== 'all') {
            $query->where('w.company_id', (int) $request->input('company_id'));
        }

        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            $like = '%' . addcslashes($search, '%_\\') . '%';
            $query->where(function ($where) use ($like) {
                $where->where('w.website_name', 'like', $like)
                    ->orWhere('w.website_url', 'like', $like)
                    ->orWhere('w.notes', 'like', $like)
                    ->orWhere('c.company_name', 'like', $like)
                    ->orWhereExists(function ($mainCompany) use ($like) {
                        $mainCompany->selectRaw('1')
                            ->from('egc_general_settings as gs')
                            ->where('gs.sno', 1)
                            ->where('gs.title', 'like', $like)
                            ->whereRaw('w.company_id = 0');
                    });
            });
        }
    }

    private function applyWebsiteScope($query, Request $request): void
    {
        if ($this->access->isGroupAdmin($request) || $this->access->isAuditor($request)) {
            return;
        }

        $companyId = $this->access->companyId($request);
        if ($companyId === null) {
            $query->whereRaw('1 = 0');
            return;
        }

        $query->where('w.company_id', $companyId);
    }

    private function findRawScoped(int $id, Request $request): object
    {
        $query = DB::table(self::TABLE . ' as w')->where('w.sno', $id)->whereNull('w.deleted_at');
        $this->applyWebsiteScope($query, $request);
        $record = $query->first();
        abort_unless($record, 404, 'Website record not found.');
        return $record;
    }

    private function findRow(int $id, Request $request): object
    {
        $query = $this->baseQuery($request)->where('w.sno', $id);
        $record = $query->first();
        abort_unless($record, 404, 'Website record not found.');
        return $record;
    }

    private function ensureReadable(Request $request): void
    {
        abort_unless($request->user(), 401, 'Authentication is required.');
    }

    private function normaliseCompanyId(int $companyId, Request $request): int
    {
        if (!$this->access->isGroupAdmin($request)) {
            $currentCompanyId = $this->access->companyId($request);
            abort_unless($currentCompanyId !== null && $companyId === (int) $currentCompanyId, 403, 'You can only assign websites to your own company.');
        }

        if ($companyId === 0) {
            $mainTitle = trim((string) DB::table('egc_general_settings')->where('sno', 1)->value('title'));
            abort_unless($mainTitle !== '', 422, 'Main company title is missing in General Settings.');
            return 0;
        }

        abort_unless(DB::table('egc_company')->where('sno', $companyId)->where('status', 0)->exists(), 422, 'Selected company is not active.');
        return $companyId;
    }

    private function normaliseUrl(string $value): string
    {
        $value = trim($value);
        if ($value === '') abort(422, 'Please enter a website URL.');
        if (!preg_match('/^https?:\/\//i', $value)) $value = 'https://' . $value;

        $parts = parse_url($value);
        abort_unless(filter_var($value, FILTER_VALIDATE_URL) && $parts && !empty($parts['host']), 422, 'Please enter a valid website URL.');
        abort_unless(in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true), 422, 'Only HTTP and HTTPS URLs are supported.');
        abort_unless(!isset($parts['user']) && !isset($parts['pass']), 422, 'URLs containing embedded credentials are not supported.');

        $host = strtolower(rtrim((string) $parts['host'], '.'));
        $port = isset($parts['port']) ? (int) $parts['port'] : null;
        if ($port !== null && !in_array($port, [80, 443], true)) {
            $allowedHosts = array_map(static fn ($item) => strtolower(rtrim((string) $item, '.')), (array) config('website_status.allowed_internal_hosts', []));
            $allowedPorts = array_map('intval', (array) config('website_status.allowed_internal_ports', []));
            abort_unless(in_array($host, $allowedHosts, true) && in_array($port, $allowedPorts, true), 422, 'This custom port is not approved. Add the exact host and port to the Website Status allowlist first.');
        }

        return $value;
    }

    private function nullableString($value): ?string
    {
        $value = is_string($value) ? trim($value) : $value;
        return $value === '' ? null : $value;
    }
}
