<?php
namespace App\Http\Controllers\productivity;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Models\ManageSpentCategoryModel;
use App\Models\Productivity\Transaction;
use App\Models\Productivity\ManageBudgetModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class MoneyController extends ProductivityBaseController
{
    public function index()
    {

        $category_list = ManageSpentCategoryModel::where('status', 0)
            ->select('sno', 'category_name')
            ->orderBy('category_name', 'asc')
            ->get();
        $spent_category_list = ManageSpentCategoryModel::where('status', 0)
            ->select('sno', 'category_name')
            ->where('category_name','=','Utilities')
            ->orderBy('category_name', 'asc')
            ->get();
        $monthlyincome=Transaction::where('egc_tool_money_transactions.status', '!=', 2)
            ->where('egc_tool_money_transactions.spent_type','=','Income')
            ->whereYear('egc_tool_money_transactions.transaction_date',now()->year)
            ->whereMonth('egc_tool_money_transactions.transaction_date',now()->month)
            ->sum('egc_tool_money_transactions.amount');
        $monthlyexpense=Transaction::where('egc_tool_money_transactions.status', '!=', 2)
            ->where('egc_tool_money_transactions.spent_type','=','Expense')
            ->whereYear('egc_tool_money_transactions.transaction_date',now()->year)
            ->whereMonth('egc_tool_money_transactions.transaction_date',now()->month)
            ->sum('egc_tool_money_transactions.amount');

            $previousDate = \Carbon\Carbon::createFromDate(now()->year, now()->month, 1)
        ->subMonth();

        $savings=$monthlyincome-$monthlyexpense;
        $percent = $monthlyincome > 0
        ? ($savings / $monthlyincome) * 100
        : 0;

    $previousMonth = $previousDate->month;
    $previousYear = $previousDate->year;
    $previousQuery = Transaction::where(
            'egc_tool_money_transactions.status', '!=', 2
        )
        ->whereYear(
            'egc_tool_money_transactions.transaction_date',
            $previousYear
        )
        ->whereMonth(
            'egc_tool_money_transactions.transaction_date',
            $previousMonth
        );

    $previousHasData = (clone $previousQuery)->exists();

    $previousIncome = (clone $previousQuery)
        ->where('egc_tool_money_transactions.spent_type', 'Income')
        ->sum('egc_tool_money_transactions.amount');

    $previousExpense = (clone $previousQuery)
        ->where('egc_tool_money_transactions.spent_type', 'Expense')
        ->sum('egc_tool_money_transactions.amount');

    // Previous savings rate
    $previousPercent = $previousHasData && $previousIncome > 0
        ? (($previousIncome - $previousExpense) / $previousIncome) * 100
        : 0;


        $points = $previousHasData
            ? round($percent - $previousPercent, 2)
            : 0;
        $previousMonthName = $previousDate->format('M');
        
        
        return view('content.productivity.money.index',[
            'category_list' => $category_list,
            'monthlyincome' => $monthlyincome,
            'monthlyexpense' => $monthlyexpense,
            'spent_category_list' => $spent_category_list,
            'savings' => $savings,
            'percent' => $percent,
            'points' => $points,
            'previousMonthName' => $previousMonthName,
        ]);
    }
    
    public function data(Request $request)
    {
        if ($request->ajax()) {
            $perpage = (int) $request->get('perpage', 10);
            $perpage = in_array($perpage, [2, 10, 25, 100, 500])
                ? $perpage
                : 10;
            $level = Transaction::query()
                ->whereNull('egc_tool_money_transactions.deleted_at')
                ->where('egc_tool_money_transactions.status', 0)
                ->select('egc_tool_money_transactions.*','egc_tool_manage_spent_category.category_name as category_name','egc_acct_payment_mode.payment_mode as payment_mode')
                ->join('egc_tool_manage_spent_category','egc_tool_money_transactions.category_id','=','egc_tool_manage_spent_category.sno')
                ->join('egc_acct_payment_mode','egc_tool_money_transactions.payment_mode_id','=','egc_acct_payment_mode.sno');
            if ($request->filled('category_id')){
                $level->where(
                    'egc_tool_money_transactions.category_id',
                    $request->category_id
                );
            }
            if ($request->filled('spent_type')) $query->where('egc_tool_money_transactions.spent_type', $request->spent_type);
            if ($request->filled('search')) {
                $s = trim((string) $request->search);
                $query->where(function ($q) use ($s) {
                    $q->where('category_name', 'like', "%{$s}%");
                });
            }
            $transactions = $level->orderBy('egc_tool_money_transactions.sno','DESC')->paginate($perpage);
            $data = collect($transactions->items())->map(function ($item) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'payment_mode' => $item->payment_mode,
                    'category_name' => $item->category_name,
                    'transaction_date' => $item->transaction_date,
                    'spent_type' => $item->spent_type,
                    'amount' => $item->amount,
                    'notes' => $item->notes,
                ];
            });
            return response()->json([
                'success' => true,
                'data' => [              
                    'transactions' => $data,
                    'pagination' => [
                        'current_page' => $transactions->currentPage(),
                        'last_page' => $transactions->lastPage(),
                        'per_page' => $transactions->perPage(),
                        'total' => $transactions->total(),
                    ]
                ]
            ]);
        }
        return response()->json([
            'success' => false,
            'message' => 'Invalid request'
        ], 400);
    }

    public function account(Request $r)
    {
        $d=$r->validate([
            'company_id'=>'nullable|integer',
            'account_name'=>'required|string|max:160',
            'account_type'=>'required|string|max:80',
            'opening_balance'=>'nullable|numeric'
            ]);
        $a=DB::table('egc_tool_money_accounts')->insertGetId([
            'owner_user_id'=>$this->uid(),
            'company_id'=>$d['company_id']??$this->cid(),
            'account_name'=>$d['account_name'],
            'account_type'=>$d['account_type'],
            'opening_balance'=>$d['opening_balance']??0,
            'current_balance'=>$d['opening_balance']??0,
            'status'=>0,
            'created_at'=>now(),
            'updated_at'=>now()
            ]);
        return $this->ok(['id'=>$a],'Account created.');
    }
    
    public function transaction(Request $request)
    {
        $user = $request->user();
        $validator = Validator::make($request->all(), [
            'transaction_date' => 'required|date',
            'category' => 'required|integer|exists:egc_tool_manage_spent_category,sno',
            'mode' => 'required|integer|exists:egc_acct_payment_mode,sno',
            'note' => 'nullable|string|max:500',
            'amount' => 'required|numeric|gt:0',
            'transaction_type' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Please check the entered information.',
                'errors' => $validator->errors(),
                'data' => null
            ], 422);
        }
        try {
            $add_transaction = new Transaction();
            $add_transaction->transaction_date = $request->transaction_date;
            $add_transaction->category_id = $request->category;
            $add_transaction->amount = $request->amount;
            $add_transaction->payment_mode_id = $request->mode;
            $add_transaction->spent_type = ucfirst($request->transaction_type);
            $add_transaction->notes = $request->note;
            $add_transaction->created_by = $user->user_id;
            $add_transaction->updated_by = $user->user_id;

            $add_transaction->save();
            return response()->json([
                'success' => true,
                'message' => 'Transaction added successfully!',
                'data' => $add_transaction
            ], 200);

        } catch (\Throwable $e) {
            \Log::error('Transaction save failed', [
                'error' => $e->getMessage(),
                'user_id' => $user->user_id
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Could not add the transaction!',
            ], 500);
        }
    }

    public function budget(Request $request)
    {
        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
            'budget_month'=>'required',
            'budget_year'=>'required',
            'budget_amount'=>'required|numeric|gt:0',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {            
                $add_budget = new ManageBudgetModel();
                $add_budget->month = $request->budget_month;
                $add_budget->year = $request->budget_year;
                $add_budget->category_id = $request->category_id;
                $add_budget->budget_amount = $request->budget_amount;               
                $add_budget->created_by = $request->user_id ?? 1;
                $add_budget->updated_by = $request->user_id ?? 1;                
                $add_budget->save();
                if ($add_budget) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Budget added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Budget!',
                    ]);
                }            
            // return $result;
            //  return redirect()->back();
        }
    }
    public function commitment(Request $r)
    {
        $d=$r->validate([
            'company_id'=>'nullable|integer',
            'commitment_name'=>'required|string|max:180',
            'due_date'=>'required|date',
            'amount'=>'required|numeric|min:0',
            'recurrence'=>'nullable|string|max:40',
            'status'=>'nullable|in:pending,paid,cancelled'
            ]);
        $id=DB::table('egc_tool_money_commitments')->insertGetId([
            'owner_user_id'=>$this->uid(),
            'company_id'=>$d['company_id']??$this->cid(),
            'commitment_name'=>$d['commitment_name'],
            'due_date'=>$d['due_date'],
            'amount'=>$d['amount'],
            'recurrence'=>$d['recurrence']??null,
            'status'=>$d['status']??'pending',
            'created_at'=>now(),
            'updated_at'=>now()
            ]);
        return $this->ok(['id'=>$id],'Commitment saved.');
    }

    public function AddCategory(Request $request)
    {
        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [           
            'category_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $category_name =$request->input('category_name');
            
            $chk = ManageSpentCategoryModel::where('category_name', ucwords($category_name))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Category has been  already created!',
                ]);
            } else {
                
                $add_category = new ManageSpentCategoryModel();
                $add_category->category_name = $category_name;
                $add_category->spent_type = $request->spent_type;                
                $add_category->created_by = $request->user()->user_id ?? 1;
                $add_category->updated_by = $request->user()->user_id ?? 1;                
                $add_category->save();
                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Category added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Category!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

    public function UpdateCategory($id, Request $request)
    {            
        $user_id = $request->user()->user_id;
            $validator = Validator::make($request->all(), [
                'category_name' => 'required|max:255',

            ]);

            if ($validator->fails()) {
                return response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => $validator->messages()->get('*'),
                    'data' => null,
                ], 200);
            } else {
                $category_name = $request->input('category_name');
                $upd_CategoryModel = ManageSpentCategoryModel::where('sno', $id)->first();      
                $upd_CategoryModel->category_name = $category_name;
                $upd_CategoryModel->spent_type = $request->spent_type;
                $upd_CategoryModel->updated_by = $request->user()->user_id ?? 1;                
                $upd_CategoryModel->update();
                if ($upd_CategoryModel) {
                    $result = response([
                        'status' => 200,
                        'message' => 'Successfully Updated!',
                        'error_msg' => null,
                        'data' => null,
                    ], 200);
                } else {
                    $result = response([
                        'status' => 401,
                        'message' => 'Incorrect format input feilds',
                        'error_msg' => 'Incorrect format input feilds',
                        'data' => null,
                    ], 401);
                }
                return $result;
            }
        // return redirect()->back();
    }
    
    public function CategoryStatus($id, Request $request): JsonResponse
    {
        try {
            $upd_CategoryModel = ManageSpentCategoryModel::where('sno', $id)->first();
            if (!$upd_CategoryModel) {
                return response()->json([
                    'success' => false,
                    'message' => 'Category not found!'
                ], 404);
            }
            $upd_CategoryModel->status =((int) $upd_CategoryModel->status === 1) ? 0 : 1;
            $upd_CategoryModel->save();
            return response()->json([
                'success' => true,
                'message' => 'Category status updated successfully!',
                'status' => (int) $upd_CategoryModel->status
            ]);

        } catch (Throwable $e) {
            Log::error('Category status update failed.', [
                'id' => $id,
                'exception' => $e
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Could not update the Category!'
            ], 500);
        }
    }
    
    public function Category(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
            'search' => ['nullable', 'string', 'max:150'],
            'status' => ['nullable', 'integer'],
        ]);
        
        try {
            $page = (int) ($validated['page'] ?? 1);
            $perpage = (int) ($validated['perpage'] ?? 25);
            $search = trim((string) ($validated['search'] ?? ''));
            $name = 'category_name';
            $query = DB::table('egc_tool_manage_spent_category')
                ->whereIn('status', [0, 1])
                ->select(['sno','category_name','spent_type','status',])
                ->orderBy('status')
                ->orderBy($name);
            if ($search !== '') {
                $query->where($name, 'like', "%{$search}%");
            }
            if (array_key_exists('status', $validated) && $validated['status'] !== null) {
                $query->where('status', (int) $validated['status']);
            }        
            if ($request->filled('spent_type')) $query->where('spent_type', $request->spent_type);

            $paginated = $query->paginate($perpage,['*'],'page',$page);
            return response()->json([
                'success' => true,
                'data' => collect($paginated->items())->map(fn ($item) => [
                    'id' => (int) $item->sno,
                    'category_name' => (string) $item->category_name,
                    'spent_type' => (string) $item->spent_type,
                    'status' => (int) $item->status,
                    'status_label' => (int) $item->status === 0
                        ? 'Active'
                        : 'Inactive',
                ])->values(),
                'pagination' => [
                    'current_page' => $paginated->currentPage(),
                    'last_page' => $paginated->lastPage(),
                    'per_page' => $paginated->perPage(),
                    'total' => $paginated->total(),
                ],
            ]);

        } catch (Throwable $e) {
            Log::error('Category list loading failed.', [
                'exception' => $e,
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Category list could not be loaded.',
            ], 500);
        }
    }
    
    public function monthlyChart(Request $request): JsonResponse
    {
        $period = $request->period ?? 'year';
        $query = DB::table('egc_tool_money_transactions')
            ->where('status', '!=', 2);
        if ($period === 'month') {
            $startDate = now()->startOfMonth();
            $endDate = now()->endOfMonth();
            $query->whereBetween('transaction_date', [
                $startDate,
                $endDate
            ]);
            $groupBy = 'DAY(transaction_date)';
        } elseif ($period === 'quarter') {
            $startDate = now()->startOfQuarter();
            $endDate = now()->endOfQuarter();

            $query->whereBetween('transaction_date', [
                $startDate,
                $endDate
            ]);
            $groupBy = 'MONTH(transaction_date)';
        } else {
            $startDate = now()->startOfYear();
            $endDate = now()->endOfYear();
            $query->whereBetween('transaction_date', [
                $startDate,
                $endDate
            ]);
            $groupBy = 'MONTH(transaction_date)';
        }

        $rows = $query
            ->selectRaw("
                {$groupBy} as period,
                SUM(CASE WHEN spent_type = 'Income'
                    THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN spent_type = 'Expense'
                    THEN amount ELSE 0 END) as total_expense
            ")
            ->groupByRaw($groupBy)
            ->orderByRaw($groupBy)
            ->get()
            ->keyBy('period');

        if ($period === 'month') {
            $labels = [];
            $income = [];
            $expense = [];
            $days = now()->daysInMonth;
            for ($i = 1; $i <= $days; $i++) {
                $labels[] = $i;
                $income[] = (float) ($rows[$i]->total_income ?? 0);
                $expense[] = (float) ($rows[$i]->total_expense ?? 0);
            }

        } else {
            $labels = $period === 'quarter'
                ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            $income = [];
            $expense = [];
            if ($period === 'quarter') {
                $quarterStart = now()->startOfQuarter()->month;
                for ($i = 0; $i < 3; $i++) {
                    $month = $quarterStart + $i;
                    $income[] = (float) ($rows[$month]->total_income ?? 0);
                    $expense[] = (float) ($rows[$month]->total_expense ?? 0);
                }
                $labels = array_slice($labels, $quarterStart - 1, 3);

            } else {
                for ($i = 1; $i <= 12; $i++) {
                    $income[] = (float) ($rows[$i]->total_income ?? 0);
                    $expense[] = (float) ($rows[$i]->total_expense ?? 0);
                }
            }
        }
        return response()->json([
            'status' => true,
            'data' => [
                'labels' => $labels,
                'income' => $income,
                'expense' => $expense
            ]
        ]);
    }   

    
    public function expenseCategoryChart(Request $request): JsonResponse
    {
        $month = (int) $request->input('month', now()->month);
        $year = (int) $request->input('year', now()->year);
        
        if ($month < 1 || $month > 12 || $year < 2000 || $year > 2100) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid month or year'
            ], 422);
        }
        $startDate = Carbon::createFromDate($year, $month, 1)
        ->startOfMonth()
        ->toDateString();
        $endDate = Carbon::createFromDate($year, $month, 1)
            ->endOfMonth()
            ->toDateString();
            $query = DB::table('egc_tool_money_transactions as t')
                ->leftJoin(
                    'egc_tool_manage_spent_category as c',
                    'c.sno',
                    '=',
                    't.category_id'
                )
                ->where('t.status', '!=', 2)
                ->where('t.spent_type', 'Expense')
                ->whereBetween('t.transaction_date', [
                    $startDate,
                    $endDate
                ]);

        $rows = $query
            ->selectRaw("
                COALESCE(c.category_name, 'Uncategorized') as category_name,
                SUM(t.amount) as total_amount
            ")
            ->groupBy('c.sno', 'c.category_name')
            ->orderByDesc('total_amount')
            ->get();

        $total = $rows->sum('total_amount');

        return response()->json([
            'status' => true,
            'data' => [
                'labels' => $rows->pluck('category_name')->values(),
                'values' => $rows->pluck('total_amount')
                    ->map(fn($amount) => (float) $amount)
                    ->values(),
                'total' => (float) $total,
                'month' => $month,
                'year' => $year
            ]
        ]);
    }


    
    
    public function SavingsChart(Request $request): JsonResponse
    {
        
        $year = (int) $request->input('year', now()->year);
        $currentMonth = (int) $request->input('month', now()->month);
        if ($currentMonth < 1 || $currentMonth > 12 ||
            $year < 2000 || $year > 2100) {

            return response()->json([
                'status' => false,
                'message' => 'Invalid month or year'
            ], 422);
        }
        $rows = DB::table('egc_tool_money_transactions')
            ->where('status', '!=', 2)
            ->whereYear('transaction_date', $year)
            ->selectRaw("
                MONTH(transaction_date) as month,
                SUM(CASE WHEN spent_type = 'Income'
                    THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN spent_type = 'Expense'
                    THEN amount ELSE 0 END) as total_expense
            ")
            ->groupByRaw('MONTH(transaction_date)')
            ->get()
            ->keyBy('month');

        $labels = [
            'Jan', 'Feb', 'Mar', 'Apr',
            'May', 'Jun', 'Jul', 'Aug',
            'Sep', 'Oct', 'Nov', 'Dec'
        ];
        $savings = [];
        for ($i = 1; $i <= 12; $i++) {
            $income = (float) ($rows[$i]->total_income ?? 0);
            $expense = (float) ($rows[$i]->total_expense ?? 0);
            $savings[] = $income > 0
                ? round((($income - $expense) / $income) * 100, 2)
                : 0;
        }
        $budgets = DB::table('egc_tool_manage_budget as b')
            ->leftJoin('egc_tool_money_transactions as t', function ($join) use ($currentMonth, $year) {

                $join->on('t.category_id', '=', 'b.category_id')
                    ->where('t.spent_type', '=', 'Expense')
                    ->where('t.status', '!=', 2)
                    ->whereMonth('t.transaction_date', $currentMonth)
                    ->whereYear('t.transaction_date', $year);
            })
            ->leftJoin(
                'egc_tool_manage_spent_category as c',
                'c.sno',
                '=',
                'b.category_id'
            )
            ->where('b.month', $currentMonth)
            ->where('b.year', $year)
            ->select(
                'b.category_id',
                'b.budget_amount',
                'c.category_name'
            )
            ->selectRaw('COALESCE(SUM(t.amount), 0) as total_expense')
            ->groupBy(
                'b.category_id',
                'b.budget_amount',
                'c.category_name'
            )
            ->get();

        $totalBudget = $budgets->sum('budget_amount');
        $hasTransaction = DB::table('egc_tool_money_transactions')
            ->where('status', '!=', 2)
            ->whereYear('transaction_date', $year)
            ->whereMonth('transaction_date', $currentMonth)
            ->exists();

        $hasData = $hasTransaction || $budgets->isNotEmpty();
        return response()->json([
            'status' => true,
            'data' => [
                'labels' => $labels,
                'savings' => $savings,
                'budgets' => $budgets,
                'total_budget' => (float) $totalBudget,
                'current_month' => $currentMonth,
                'current_year' => $year,
                'has_data' => $hasData
            ]
        ]);
    }


    
    public function monthlyDashboard(Request $request)
    {
        $month = (int) $request->month;
        $year = (int) $request->year;

        $currentQuery = Transaction::where(
                'egc_tool_money_transactions.status', '!=', 2
            )
            ->whereYear('egc_tool_money_transactions.transaction_date', $year)
            ->whereMonth('egc_tool_money_transactions.transaction_date', $month);

        $hasData = (clone $currentQuery)->exists();
        $monthlyincome = (clone $currentQuery)
            ->where('egc_tool_money_transactions.spent_type', 'Income')
            ->sum('egc_tool_money_transactions.amount');

        $monthlyexpense = (clone $currentQuery)
            ->where('egc_tool_money_transactions.spent_type', 'Expense')
            ->sum('egc_tool_money_transactions.amount');
        $savings = $monthlyincome - $monthlyexpense;
        $percent = $monthlyincome > 0
            ? ($savings / $monthlyincome) * 100
            : 0;
        $previousDate = \Carbon\Carbon::createFromDate($year, $month, 1)
            ->subMonth();
        $previousMonth = $previousDate->month;
        $previousYear = $previousDate->year;
        $previousQuery = Transaction::where('egc_tool_money_transactions.status', '!=', 2)
            ->whereYear('egc_tool_money_transactions.transaction_date',$previousYear)
            ->whereMonth('egc_tool_money_transactions.transaction_date',$previousMonth);
        $previousHasData = (clone $previousQuery)->exists();
        $previousIncome = (clone $previousQuery)
            ->where('egc_tool_money_transactions.spent_type', 'Income')
            ->sum('egc_tool_money_transactions.amount');
        $previousExpense = (clone $previousQuery)
            ->where('egc_tool_money_transactions.spent_type', 'Expense')
            ->sum('egc_tool_money_transactions.amount');
        $previousPercent = $previousHasData && $previousIncome > 0
            ? (($previousIncome - $previousExpense) / $previousIncome) * 100
            : 0;
        $points = $previousHasData
            ? round($percent - $previousPercent, 2)
            : 0;
        $previousMonthName = $previousDate->format('M');

        return response()->json([
            'status' => $hasData,
            'income' => $hasData
                ? '₹' . number_format($monthlyincome)
                : 'No Data Found',
            'expense' => $hasData
                ? '₹' . number_format($monthlyexpense)
                : 'No Data Found',
            'savings' => $hasData
                ? '₹' . number_format($savings)
                : 'No Data Found',
            'percent' => number_format($percent, 2),
            'points' => number_format($points, 2),
            'previous_month' => $previousMonthName
        ]);
    }

   
}
