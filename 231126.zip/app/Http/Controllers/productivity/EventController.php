<?php

namespace App\Http\Controllers\productivity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Models\Productivity\Event;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\ManageOrganiserModel;
use App\Models\ManageTypeModel;

class EventController extends ProductivityBaseController
{
    public function index(Request $request) { 
        $level = Event::where('egc_tool_events.status', '!=', 2)
      ->select('egc_tool_events.*','egc_tool_manage_organisers.organiser_name')
      ->join('egc_tool_manage_organisers', 'egc_tool_events.organiser_type_id', 'egc_tool_manage_organisers.sno');


       
       $level=$level->orderBy('sno', 'ASC')->get();
       
        if ($request->ajax()) {

            $data = $level->getCollection()->map(function ($item) use ($helper, &$runningAmount) {             
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'event_date' => $item->event_date,
                    'event_name' => $item->event_name,
                    'organiser_name' => $item->organiser_name,
                    'event_type' => $item->event_type,
                    'event_time' => $item->event_time,
                    'venue' => $item->venue,
                    'running_amount' => $runningAmount,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }


        $organiser_list = ManageOrganiserModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $type_list = ManageTypeModel::where('status', 0)->orderBy('sno', 'ASC')->get();

        return view('content.productivity.events.index', [
          'type_list' => $type_list,
          'organiser_list' => $organiser_list,
        
        ]); 
    
    }
    
    

public function data(Request $request)
{
    $query = Event::query()
        ->leftJoin('egc_tool_manage_organisers','egc_tool_events.organiser_type_id','=', 'egc_tool_manage_organisers.sno')
        ->whereNull('egc_tool_events.deleted_at')
        ->select('egc_tool_events.*','egc_tool_manage_organisers.organiser_name');
    if ($request->filled('status')) {
        $allowedStatuses = ['upcoming','registered','attending','attended','missed','cancelled'];
        $status = strtolower(trim($request->status));
        if (in_array($status, $allowedStatuses, true)) {
            $query->where('egc_tool_events.status', $status);
        }
    }
    if ($request->filled('event_type')) {
        $query->where('egc_tool_events.event_type',$request->event_type);
    }
    if ($request->filled('search')) {
        $searchfilter = trim((string) $request->search);
        $query->where(function ($q) use ($searchfilter) {
            $q->where(
                'egc_tool_events.event_name',
                'like',
                "%{$searchfilter}%"
            )
            ->orWhere(
                'egc_tool_manage_organisers.organiser_name',
                'like',
                "%{$searchfilter}%"
            )
            ->orWhere(
                'egc_tool_events.venue',
                'like',
                "%{$searchfilter}%"
            );
        });
    }
    $perPage = (int) $request->get('perpage', 10);
    $perPage = min(max($perPage, 1), 100);

    $rows = $query
        ->orderBy('egc_tool_events.event_date')
        ->orderBy('egc_tool_events.event_time')
        ->paginate($perPage);

    return $this->ok([
        'rows' => $rows
    ]);
}



    public function calendar(Request $request)
    {
        $request->validate(['start' => ['required', 'date'], 'end' => ['required', 'date']]);
        $query = Event::query()->whereNull('deleted_at')->whereBetween('event_date', [$request->start, $request->end]);
      
        return $this->ok($query->orderBy('event_date')->orderBy('event_time')->get());
    }

    public function show(Request $request, int $id)
    {
        $event = Event::findOrFail($id);
        abort_unless($this->access->canReadResource('event', $id, $event->owner_user_id, $event->company_id, $event->visibility), 403);
        return $this->ok($event);
    }

    public function store(Request $request)
    {
        
        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
           
            'event_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $event_name =$request->input('event_name');
            
            
                $add_events = new Event();
                $add_events->event_name = $event_name;
                $add_events->organiser_type_id = $request->organiser_names;
                $add_events->event_type_id = $request->event_type;
                $add_events->event_date = $request->event_date;
                $add_events->event_time = $request->event_time;
                $add_events->venue = $request->venue;
                $add_events->registration_type = $request->registration;
                $add_events->payment_amount = $request->event_amount;
                $add_events->description = $request->description;
                
                $add_events->created_by = $request->user()->user_id ?? 1;
                $add_events->updated_by = $request->user()->user_id ?? 1;
                
                $add_events->save();

                if ($add_events) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Event added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Event!',
                    ]);
                }
            
            // return $result;
            //  return redirect()->back();
        }
    }

    // public function store(Request $request)
    // {
    //     abort_unless($this->access->canWrite(), 403);
    //     $data = $this->validateData($request);
    //     $this->assertCompany($data['company_id'] ?? null);
    //     $event = Event::create(array_merge($data, ['company_id' => $data['company_id'] ?? $this->cid(), 'owner_user_id' => $this->uid(), 'created_by' => $this->uid(), 'updated_by' => $this->uid()]));
    //     return $this->ok($event, 'Event created.');
    // }


   
public function update(Request $request, int $id)
{

    $validator = Validator::make($request->all(), [
        'event_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 401,
            'message' => 'Incorrect format input fields',
            'error_msg' => $validator->errors(),
            'data' => null,
        ], 200);
    }

    // Find existing event
    $update_events = Event::find($id);

    if (!$update_events) {
        return response()->json([
            'status' => 404,
            'message' => 'Event not found',
            'data' => null,
        ], 404);
    }
    $update_events->event_name = $request->event_name;
    $update_events->organiser_type_id = $request->organiser_type;
    $update_events->event_type_id = $request->event_type;
    $update_events->event_date = $request->event_date;
    $update_events->event_time = $request->event_time;
    $update_events->venue = $request->venue;
    $update_events->registration_type = $request->registration;
    $update_events->payment_amount = $request->amount ?? 0.00;
    $update_events->description = $request->description;
    $update_events->updated_by = $request->user()->user_id ?? 1;

    // Save changes
    if ($update_events->save()) {

        return response()->json([
            'status' => 200,
            'message' => 'Event updated successfully!',
            'data' => $update_events,
        ], 200);

    } else {

        return response()->json([
            'status' => 500,
            'message' => 'Could not update the Event!',
            'data' => null,
        ], 500);
    }
}


    
    public function delete(Request $request, int $id)
    {
        $event = Event::findOrFail($id);
        abort_unless($this->access->canManageResource('event', $id, $event->owner_user_id), 403);
        $event->update(['deleted_at' => now(), 'updated_by' => $this->uid(), 'status' => 'Cancelled']);
        return $this->ok(null, 'Event deleted.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'event_name' => ['required', 'string', 'max:220'],
            'organisation' => ['nullable', 'string', 'max:180'],
            'event_type' => ['required', 'string', 'max:80'],
            'event_date' => ['required', 'date'],
            'event_time' => ['nullable', 'date_format:H:i'],
            'venue' => ['nullable', 'string', 'max:300'],
            'is_online' => ['nullable', 'boolean'],
            'online_link' => ['nullable', 'url', 'max:2000'],
            'payment_amount' => ['nullable', 'numeric', 'min:0'],
            
            'reminder_stage' => ['nullable', 'string', 'max:40'],
            'description' => ['nullable', 'string', 'max:10000'],
        ]);
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company event access is not permitted.');
    }

     public function AddOrganiser(Request $request)
    {

        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
           
            'organiser_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $organiser_name =$request->input('organiser_name');
            
            $chk = ManageOrganiserModel::where('organiser_name', ucwords($organiser_name))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Organiser has been  already created!',
                ]);
            } else {
                
                $add_category = new ManageOrganiserModel();
                $add_category->organiser_name = $organiser_name;
                
                $add_category->created_by = $request->user()->user_id ?? 1;
                $add_category->updated_by = $request->user()->user_id ?? 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Organiser added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Organiser!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

public function UpdateOrganiser($id, Request $request)
    {
        
    $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
            'organiser_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $organiser_name = $request->input('organiser_name');
            $upd_OrganiserModel = ManageOrganiserModel::where('sno', $id)->first();          

            $upd_OrganiserModel->organiser_name = $organiser_name;
            $upd_OrganiserModel->updated_by = $request->user()->user_id ?? 1;
            
            $upd_OrganiserModel->update();

            if ($upd_OrganiserModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    
public function OrganiserStatus($id, Request $request): JsonResponse
{
    try {

        $upd_OrganiserModel = ManageOrganiserModel::where('sno', $id)->first();

        if (!$upd_OrganiserModel) {
            return response()->json([
                'success' => false,
                'message' => 'Organiser not found!'
            ], 404);
        }

        // Toggle current status
        $upd_OrganiserModel->status =
            ((int) $upd_OrganiserModel->status === 1) ? 0 : 1;

        $upd_OrganiserModel->save();

        return response()->json([
            'success' => true,
            'message' => 'Organiser status updated successfully!',
            'status' => (int) $upd_OrganiserModel->status
        ]);

    } catch (Throwable $e) {

        Log::error('Organiser status update failed.', [
            'id' => $id,
            'exception' => $e
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Could not update the organiser!'
        ], 500);
    }
}

    // public function OrganiserStatus($id, Request $request){

    //     $upd_OrganiserModel = ManageOrganiserModel::where('sno', $id)->first();
        

    //     $upd_OrganiserModel->status = $request->input('status', 0);
    //     $upd_OrganiserModel->update();

    //     if ($upd_OrganiserModel) {
    //                 session()->flash('toastr', [
    //                     'type' => 'success',
    //                     'message' => 'Organiser updated Successfully!',
    //                 ]);
    //             } else {
    //                 session()->flash('toastr', [
    //                     'type' => 'error',
    //                     'message' => 'Could not update the Organiser!',
    //                 ]);
    //             }
    // }
    
public function Organiser(Request $request): JsonResponse
{
    $validated = $request->validate([
        'page' => ['nullable', 'integer', 'min:1'],
        'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
        'search' => ['nullable', 'string', 'max:150'],
        'status' => ['nullable', 'integer'],
    ]);

    try {

        $page = (int) ($validated['page'] ?? 1);
        $perpage = (int) ($validated['perpage'] ?? 25);
        $search = trim((string) ($validated['search'] ?? ''));

        $name = 'organiser_name';

        $query = DB::table('egc_tool_manage_organisers')
            ->whereIn('status', [0, 1])
            ->select([
                'sno',
                'organiser_name',
                'status',
            ])
            ->orderBy('status')
            ->orderBy($name);

        if ($search !== '') {
            $query->where($name, 'like', "%{$search}%");
        }

        if (array_key_exists('status', $validated) && $validated['status'] !== null) {
            $query->where('status', (int) $validated['status']);
        }

        $paginated = $query->paginate(
            $perpage,
            ['*'],
            'page',
            $page
        );

        return response()->json([
            'success' => true,

            'data' => collect($paginated->items())->map(fn ($item) => [
                'id' => (int) $item->sno,
                'organiser_name' => (string) $item->organiser_name,
                'status' => (int) $item->status,
                'status_label' => (int) $item->status === 0
                    ? 'Active'
                    : 'Inactive',
            ])->values(),

            'pagination' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'per_page' => $paginated->perPage(),
                'total' => $paginated->total(),
            ],
        ]);

    } catch (Throwable $e) {

        Log::error('Organiser list loading failed.', [
            'exception' => $e,
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Organiser list could not be loaded.',
        ], 500);
    }
}



    public function AddType(Request $request)
    {
        $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
           
            'type_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $type_name =$request->input('type_name');
            
            $chk = ManageTypeModel::where('type_name', ucwords($type_name))->where('status', '!=', 2)->first();
            
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Type has been  already created!',
                ]);
            } else {
                
                $add_category = new ManageTypeModel();
                $add_category->type_name = $type_name;
                
                $add_category->created_by = $request->user()->user_id ?? 1;
                $add_category->updated_by = $request->user()->user_id ?? 1;
                
                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Type added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Type!',
                    ]);
                }
            }
            // return $result;
            //  return redirect()->back();
        }
    }

    public function Types(Request $request): JsonResponse
    {
            $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'perpage' => ['nullable', 'integer', 'min:5', 'max:500'],
            'search' => ['nullable', 'string', 'max:150'],
            'status' => ['nullable', 'integer'],
        ]);

        try {

            $page = (int) ($validated['page'] ?? 1);
            $perpage = (int) ($validated['perpage'] ?? 25);
            $search = trim((string) ($validated['search'] ?? ''));

            $query = DB::table('egc_tool_manage_types')
                ->whereIn('status', [0, 1])
                ->select([
                    'sno',
                    'type_name',
                    'status',
                ])
                ->orderBy('status')
                ->orderBy('type_name');

            if ($search !== '') {
                $query->where('type_name', 'like', "%{$search}%");
            }
            if (isset($validated['status'])) {
                $query->where('status', (int) $validated['status']);
            }
            $paginated = $query->paginate(
                $perpage,
                ['*'],
                'page',
                $page
            );

            return response()->json([
                'success' => true,
                'data' => collect($paginated->items())->map(fn ($item) => [
                    'id' => (int) $item->sno,
                    'type_name' => (string) $item->type_name,
                    'status' => (int) $item->status,
                    'status_label' => (int) $item->status === 0
                        ? 'Active'
                        : 'Inactive',
                ])->values(),

                'pagination' => [
                    'current_page' => $paginated->currentPage(),
                    'last_page' => $paginated->lastPage(),
                    'per_page' => $paginated->perPage(),
                    'total' => $paginated->total(),
                ],
            ]);

        } catch (Throwable $e) {

            Log::error('Type list loading failed.', [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Type list could not be loaded.',
            ], 500);
        }
    }

    public function UpdateType($id, Request $request)
    {
        
    $user_id = $request->user()->user_id;
        $validator = Validator::make($request->all(), [
            'type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $type_name = $request->input('type_name');
            $upd_TypeModel = ManageTypeModel::where('sno', $id)->first();          

            $upd_TypeModel->type_name = $type_name;
            $upd_TypeModel->updated_by = $request->user()->user_id ?? 1;
            
            $upd_TypeModel->update();

            if ($upd_TypeModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    
public function TypeStatus($id, Request $request): JsonResponse
{
    try {

        $upd_TypeModel = ManageTypeModel::where('sno', $id)->first();

        if (!$upd_TypeModel) {
            return response()->json([
                'success' => false,
                'message' => 'Type not found!'
            ], 404);
        }

        // Toggle current status
        $upd_TypeModel->status =
            ((int) $upd_TypeModel->status === 1) ? 0 : 1;

        $upd_TypeModel->save();

        return response()->json([
            'success' => true,
            'message' => 'Type status updated successfully!',
            'status' => (int) $upd_TypeModel->status
        ]);

    } catch (Throwable $e) {

        Log::error('Type status update failed.', [
            'id' => $id,
            'exception' => $e
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Could not update the Type!'
        ], 500);
    }
}


public function status(Request $request, $eventId)
{
    $validated = $request->validate([
        'status' => 'required|in:upcoming,registered,attending,attended,missed,cancelled'
    ]);
    $event = Event::findOrFail($eventId);

    $event->status = $validated['status'];
    $event->save();

    return response()->json([
        'status' => 'success',
        'message' => 'Event status updated successfully'
    ]);
}


}
