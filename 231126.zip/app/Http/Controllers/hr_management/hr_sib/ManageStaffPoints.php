<?php

namespace App\Http\Controllers\hr_management\hr_sib;

use App\Http\Controllers\Controller;
use App\Models\PointsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;

class ManageStaffPoints extends Controller
{
    /**
     * List configured point rules. Category details are included for display.
     */
    public function index(Request $request)
    {
        $search = trim($request->input('search_filter', ''));
        $perpage = (int) $request->input('sorting_filter', 25);
        $perpage = in_array($perpage, [25, 50, 100, 500], true) ? $perpage : 25;

        $query = DB::table('egc_points as p')
            ->leftJoin('egc_point_category as pc', 'pc.sno', '=', 'p.point_category_id')
            ->select([
                'p.*',
                'pc.category_name',
                'pc.color as category_color',
                'pc.status as category_status',
            ])
            ->where('p.status', '!=', 2);

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('p.point_name', 'LIKE', "%{$search}%")
                    ->orWhere('p.point_key', 'LIKE', "%{$search}%")
                    ->orWhere('p.comments', 'LIKE', "%{$search}%")
                    ->orWhere('p.points', 'LIKE', "%{$search}%")
                    ->orWhere('pc.category_name', 'LIKE', "%{$search}%");
            });
        }

        if ($request->filled('status_filter') && in_array((string) $request->status_filter, ['0', '1'], true)) {
            $query->where('p.status', (int) $request->status_filter);
        }

        $list = $query->orderByDesc('p.sno')->paginate($perpage);

        if ($request->ajax()) {
            return response()->json([
                'data' => $list->items(),
                'current_page' => $list->currentPage(),
                'last_page' => $list->lastPage(),
                'total' => $list->total(),
            ]);
        }

        return view('content.hr_management.hr_sib.manage_points.staff_points');
    }

    /** Create a point rule. Only active categories can be newly assigned. */
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'point_name' => 'required|string|max:255',
            'point_key' => 'required|string|max:100',
            'point_category_id' => 'required|integer',
            'no_of_point' => ['required', 'integer', 'not_in:0'],
            'point_reason' => 'required|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'error_msg' => $validator->errors(),
            ], 422);
        }

        $categoryIsActive = DB::table('egc_point_category')
            ->where('sno', (int) $request->point_category_id)
            ->where('status', 0)
            ->exists();

        if (!$categoryIsActive) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active point category.',
                'error_msg' => ['point_category_id' => ['Please select an active point category.']],
            ], 422);
        }

        $exists = PointsModel::whereRaw('LOWER(point_key) = ?', [mb_strtolower(trim($request->point_key))])
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Point key already exists.',
            ], 409);
        }

        $userId = $request->user()?->user_id ?? 1;
        $item = PointsModel::create([
            'point_name' => trim($request->point_name),
            'point_key' => trim($request->point_key),
            'points' => $request->no_of_point,
            'point_category_id' => (int) $request->point_category_id,
            'comments' => trim($request->point_reason),
            'created_by' => $userId,
            'updated_by' => $userId,
            'status' => 0,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Points added successfully!',
            'data' => $item,
        ]);
    }

    /** Return point-rule details for editing. */
    public function Edit($id)
    {
        $item = PointsModel::where('sno', $id)
            ->where('status', '!=', 2)
            ->first();

        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Points record not found.',
            ], 404);
        }

        return response()->json([
            'status' => 200,
            'data' => $item,
        ]);
    }

    /** Update a point rule. Its existing inactive category may be retained. */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|integer',
            'point_name' => 'required|string|max:255',
            'point_key' => 'required|string|max:100',
            'point_category_id' => 'required|integer',
            'no_of_point' => ['required', 'integer', 'not_in:0'],
            'point_reason' => 'required|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'error_msg' => $validator->errors(),
            ], 422);
        }

        $item = PointsModel::where('sno', $request->edit_id)
            ->where('status', '!=', 2)
            ->first();

        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Points record not found.',
            ], 404);
        }

        $selectedCategory = DB::table('egc_point_category')
            ->where('sno', (int) $request->point_category_id)
            ->where('status', '!=', 2)
            ->first();
        $isExistingCategory = (int) $item->point_category_id === (int) $request->point_category_id;

        if (!$selectedCategory || ((int) $selectedCategory->status !== 0 && !$isExistingCategory)) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active point category.',
                'error_msg' => ['point_category_id' => ['Please select an active point category.']],
            ], 422);
        }

        $exists = PointsModel::whereRaw('LOWER(point_key) = ?', [mb_strtolower(trim($request->point_key))])
            ->where('sno', '!=', $item->sno)
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Point key already exists.',
            ], 409);
        }

        $userId = $request->user()?->user_id ?? 1;
        $item->update([
            'point_name' => trim($request->point_name),
            'point_key' => trim($request->point_key),
            'points' => $request->no_of_point,
            'point_category_id' => (int) $request->point_category_id,
            'comments' => trim($request->point_reason),
            'updated_by' => $userId,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Points updated successfully!',
            'data' => $item->fresh(),
        ]);
    }

    public function Status($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:0,1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Invalid status.',
            ], 422);
        }

        $item = PointsModel::where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Points record not found.',
            ], 404);
        }

        $item->status = (int) $request->status;
        $item->updated_by = $request->user()?->user_id ?? 1;
        $item->save();

        return response()->json([
            'status' => 200,
            'message' => (int) $item->status === 0 ? 'Points activated successfully!' : 'Points deactivated successfully!',
        ]);
    }

    public function Delete(Request $request, $id)
    {
        $item = PointsModel::where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Points record not found.',
            ], 404);
        }

        $item->status = 2;
        $item->updated_by = $request->user()?->user_id ?? 1;
        $item->save();

        return response()->json([
            'status' => 200,
            'message' => 'Points deleted successfully!',
        ]);
    }

    /** List point categories for the category-management modal. */
    public function categoryIndex(Request $request)
    {
        if (!Schema::hasTable('egc_point_category')) {
            return response()->json([
                'status' => 409,
                'message' => 'The egc_point_category table is not installed. Import the supplied SQL file first.',
            ], 409);
        }

        $search = trim($request->input('search_filter', ''));
        $perpage = (int) $request->input('sorting_filter', 25);
        $perpage = in_array($perpage, [25, 50, 100, 500], true) ? $perpage : 25;

        $query = DB::table('egc_point_category')->where('status', '!=', 2);
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('category_name', 'LIKE', "%{$search}%")
                    ->orWhere('description', 'LIKE', "%{$search}%");
            });
        }

        if ($request->filled('status_filter') && in_array((string) $request->status_filter, ['0', '1'], true)) {
            $query->where('status', (int) $request->status_filter);
        }

        $list = $query->orderByDesc('sno')->paginate($perpage);

        return response()->json([
            'data' => $list->items(),
            'current_page' => $list->currentPage(),
            'last_page' => $list->lastPage(),
            'total' => $list->total(),
        ]);
    }

    /** Active categories for the point form, with the current inactive choice included on edit. */
    public function categoryOptions(Request $request)
    {
        if (!Schema::hasTable('egc_point_category')) {
            return response()->json([
                'status' => 409,
                'message' => 'The egc_point_category table is not installed. Import the supplied SQL file first.',
            ], 409);
        }

        $selectedId = (int) $request->input('selected_id', 0);
        $query = DB::table('egc_point_category')
            ->where(function ($q) use ($selectedId) {
                $q->where('status', 0);
                if ($selectedId > 0) {
                    $q->orWhere(function ($selected) use ($selectedId) {
                        $selected->where('sno', $selectedId)->where('status', '!=', 2);
                    });
                }
            })
            ->orderBy('category_name');

        return response()->json(['data' => $query->get()]);
    }

    public function AddCategory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_name' => 'required|string|max:255',
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'description' => 'nullable|string|max:5000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'error_msg' => $validator->errors(),
            ], 422);
        }

        $categoryName = trim($request->category_name);
        $exists = DB::table('egc_point_category')
            ->whereRaw('LOWER(category_name) = ?', [mb_strtolower($categoryName)])
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Category name already exists.',
            ], 409);
        }

        $userId = $request->user()?->user_id ?? 1;
        $id = DB::table('egc_point_category')->insertGetId([
            'category_name' => $categoryName,
            'color' => strtoupper($request->color),
            'description' => $request->filled('description') ? trim($request->description) : null,
            'created_by' => $userId,
            'updated_by' => $userId,
            'created_at' => now(),
            'updated_at' => now(),
            'status' => 0,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Point category added successfully!',
            'data' => DB::table('egc_point_category')->where('sno', $id)->first(),
        ]);
    }

    public function EditCategory($id)
    {
        $item = DB::table('egc_point_category')->where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Point category not found.',
            ], 404);
        }

        return response()->json(['status' => 200, 'data' => $item]);
    }

    public function UpdateCategory(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|integer',
            'category_name' => 'required|string|max:255',
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'description' => 'nullable|string|max:5000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation failed',
                'error_msg' => $validator->errors(),
            ], 422);
        }

        $item = DB::table('egc_point_category')->where('sno', $request->edit_id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Point category not found.',
            ], 404);
        }

        $categoryName = trim($request->category_name);
        $exists = DB::table('egc_point_category')
            ->whereRaw('LOWER(category_name) = ?', [mb_strtolower($categoryName)])
            ->where('sno', '!=', $item->sno)
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Category name already exists.',
            ], 409);
        }

        DB::table('egc_point_category')->where('sno', $item->sno)->update([
            'category_name' => $categoryName,
            'color' => strtoupper($request->color),
            'description' => $request->filled('description') ? trim($request->description) : null,
            'updated_by' => $request->user()?->user_id ?? 1,
            'updated_at' => now(),
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Point category updated successfully!',
            'data' => DB::table('egc_point_category')->where('sno', $item->sno)->first(),
        ]);
    }

    public function StatusCategory($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:0,1',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Invalid category status.'], 422);
        }

        $item = DB::table('egc_point_category')->where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json(['status' => 404, 'message' => 'Point category not found.'], 404);
        }

        DB::table('egc_point_category')->where('sno', $id)->update([
            'status' => (int) $request->status,
            'updated_by' => $request->user()?->user_id ?? 1,
            'updated_at' => now(),
        ]);

        return response()->json([
            'status' => 200,
            'message' => (int) $request->status === 0
                ? 'Point category activated successfully!'
                : 'Point category deactivated successfully!',
        ]);
    }

    /** Do not delete a category while existing point rules still reference it. */
    public function DeleteCategory(Request $request, $id)
    {
        $item = DB::table('egc_point_category')->where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json(['status' => 404, 'message' => 'Point category not found.'], 404);
        }

        $isInUse = DB::table('egc_points')
            ->where('point_category_id', $id)
            ->where('status', '!=', 2)
            ->exists();

        if ($isInUse) {
            return response()->json([
                'status' => 409,
                'message' => 'This category is assigned to one or more point rules. Reassign or delete those point rules before deleting the category.',
            ], 409);
        }

        DB::table('egc_point_category')->where('sno', $id)->update([
            'status' => 2,
            'updated_by' => $request->user()?->user_id ?? 1,
            'updated_at' => now(),
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Point category deleted successfully!',
        ]);
    }

    private function findColumn($table, array $columns)
    {
        foreach ($columns as $column) {
            if (Schema::hasColumn($table, $column)) {
                return $column;
            }
        }

        return null;
    }

    /** Existing staff point history endpoint. */
    public function staffPointsLog(Request $request)
    {
        $search = trim($request->input('search_filter', ''));
        $perpage = (int) $request->input('sorting_filter', 25);
        $perpage = in_array($perpage, [25, 50, 100, 500], true) ? $perpage : 25;
        $staffNameColumn = $this->findColumn('egc_staff', ['staff_name', 'employee_name', 'name', 'full_name']);
        $helper = new \App\Helpers\Helpers();
        $generalSetting = $helper->general_setting_data();

        $query = DB::table('egc_staff_points as sp')
            ->join('egc_points', 'egc_points.sno', '=', 'sp.point_id')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'sp.staff_id')
            ->leftJoin('egc_staff as pb', 'pb.sno', '=', 'sp.point_by')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('egc_division as dv', 'dv.sno', '=', 's.division_id')
            ->leftJoin('egc_job_role as jr', 'jr.sno', '=', 's.job_role_id')
            ->select([
                'sp.sno',
                'sp.staff_id',
                'sp.point_by',
                'sp.point_id',
                'egc_points.point_name as point_title',
                'egc_points.point_key',
                'sp.points',
                'sp.reason',
                'sp.status',
                'sp.created_at',
                's.staff_id as employee_staff_id',
                's.staff_image',
                's.gender',
                's.company_type',
                's.company_id',
                's.entity_id',
                's.available_points',
                'pb.staff_name as point_by_name',
                'c.company_name',
                'e.entity_name',
                'd.department_name',
                'dv.division_name',
                'jr.job_position_name as job_role_name',
            ]);

        if ($staffNameColumn) {
            $query->addSelect("s.{$staffNameColumn} as staff_name");
        } else {
            $query->addSelect(DB::raw('NULL as staff_name'));
        }

        if ($search !== '') {
            $query->where(function ($q) use ($search, $staffNameColumn) {
                $q->where('sp.point_name', 'LIKE', "%{$search}%")
                    ->orWhere('sp.point_key', 'LIKE', "%{$search}%")
                    ->orWhere('sp.points', 'LIKE', "%{$search}%")
                    ->orWhere('pb.staff_name', 'LIKE', "%{$search}%")
                    ->orWhere('s.staff_id', 'LIKE', "%{$search}%")
                    ->orWhere('c.company_name', 'LIKE', "%{$search}%")
                    ->orWhere('e.entity_name', 'LIKE', "%{$search}%");

                if ($staffNameColumn) {
                    $q->orWhere("s.{$staffNameColumn}", 'LIKE', "%{$search}%");
                }
            });
        }

        $query->where('sp.status', '!=', 2);
        $list = $query->orderByDesc('sp.sno')->paginate($perpage);

        if ($request->ajax()) {
            $data = $list->getCollection()->map(function ($item) use ($generalSetting) {
                if ((int) $item->company_type === 1) {
                    $item->company_name = $generalSetting->title ?? '-';
                }
                return $item;
            });

            return response()->json([
                'data' => $data,
                'current_page' => $list->currentPage(),
                'last_page' => $list->lastPage(),
                'total' => $list->total(),
            ]);
        }

        return view('content.hr_management.hr_sib.manage_points.staff_points');
    }

    public function deleteStaffPointsLog(Request $request, $id)
    {
        $item = DB::table('egc_staff_points')->where('sno', $id)->where('status', '!=', 2)->first();
        if (!$item) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff points record not found.',
            ], 404);
        }

        DB::table('egc_staff_points')->where('sno', $id)->update([
            'status' => 2,
            'updated_at' => now(),
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Staff points log deleted successfully!',
        ]);
    }
}
