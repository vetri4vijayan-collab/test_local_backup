<?php
namespace App\Http\Resources\Policies;
use Illuminate\Http\Resources\Json\JsonResource;

class SubscriptionResource extends JsonResource {

    public function toArray($request): array { 
        return [
            'id'=>$this->sno,
            'subscription_name'=>$this->subscription_name,
            'provider_name'=>$this->provider_name,
            'category'=>$this->category,
            'subscription_type'=>$this->subscription_type,
            'start_date'=>$this->start_date?->toDateString(),
            'renewal_date'=>$this->renewal_date?->toDateString(),
            'billing_cycle'=>$this->billing_cycle,
            'seat_count'=>(int)$this->seat_count,
            'used_seats'=>(int)$this->used_seats,
            'unit_cost'=>$this->unit_cost,
            'annual_cost'=>$this->annual_cost,
            'currency'=>$this->currency,
            'credential_username'=>$this->credential_username,
            'status'=>(int)$this->status,
            'notes'=>$this->notes
        ]; 
    }

}
