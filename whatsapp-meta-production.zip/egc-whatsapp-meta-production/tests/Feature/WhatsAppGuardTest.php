<?php

namespace Tests\Feature;

use Tests\TestCase;

class WhatsAppGuardTest extends TestCase
{
    public function test_package_contains_compliance_routes_and_config(): void
    {
        $this->assertFileExists(base_path('config/whatsapp.php'));
        $this->assertFileExists(base_path('routes/whatsapp_meta.php'));
        $this->assertFileExists(base_path('database/migrations/2026_09_15_000001_create_egc_whatsapp_contacts_table.php'));
    }
}
