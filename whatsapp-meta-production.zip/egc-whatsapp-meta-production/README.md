# EGC ERP — WhatsApp Meta Production Integration

Additive Laravel module for Meta WhatsApp Cloud API. It is designed to coexist with the ERP's existing `/webhook_whatsapp` implementation and `egc_api_integration` configuration.

## What it provides

- Centralized Meta Cloud API client with configurable Graph API version.
- Queue-first sending for all ERP-generated messages.
- Approved-template sends outside the 24-hour customer-service window.
- Free-form text/media sends only when the ERP has a valid inbound-message window.
- Contact opt-in/opt-out and suppression controls.
- Per-recipient 24-hour window tracking.
- Idempotent message records and Meta message-ID reconciliation.
- Webhook verification + inbound/status/error/account-update ingestion.
- Template catalog, synchronization command, and template snapshotting.
- Bulk campaigns with safe recipient filtering and throttled queue dispatch.
- Scheduled reminder framework using the existing Laravel scheduler, with persisted reminder records.
- Automatic circuit breaker when Meta reports account restriction or when configured quality/error thresholds are exceeded.
- Admin dashboard for throughput, delivery, failures, template usage, conversations, and circuit-breaker state.
- Audit logs and raw Meta event storage for support/debugging.

## Important policy note

No application can guarantee that Meta will never restrict an account. This module is designed to reduce avoidable policy/rate/quality risk, but the ERP owner still must use valid opt-in, approved templates for business-initiated messaging, honor opt-outs, and use only permitted content.

Meta currently states that businesses may only contact people who supplied their mobile number and opted in, and must respect opt-out requests. Business-initiated conversations must use approved templates; free-form service replies are available within the 24-hour customer service window after a user's message. See the official WhatsApp Business Messaging Policy.

## Integration strategy

This package is intentionally additive. It does not replace the ERP's existing payment/lead WhatsApp implementation automatically. Add the routes below and migrate individual ERP events to `WhatsAppMessageService`/`DispatchWhatsAppMessageJob` one module at a time.

## Environment

```dotenv
META_WHATSAPP_ENABLED=true
META_WHATSAPP_GRAPH_VERSION=vXX.X
META_WHATSAPP_WABA_ID=your_waba_id
META_WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id
META_WHATSAPP_ACCESS_TOKEN=your_system_user_access_token
META_WHATSAPP_VERIFY_TOKEN=long-random-webhook-token
META_WHATSAPP_APP_SECRET=your_meta_app_secret
META_WHATSAPP_DEFAULT_COUNTRY_CODE=91
META_WHATSAPP_TIMEOUT=20
META_WHATSAPP_CONNECT_TIMEOUT=5
META_WHATSAPP_MAX_RETRIES=5
META_WHATSAPP_BASE_RETRY_SECONDS=10
META_WHATSAPP_THROTTLE_PER_MINUTE=60
META_WHATSAPP_DRY_RUN=false
```

`META_WHATSAPP_GRAPH_VERSION` is intentionally required as a deployment setting rather than hard-coded. Verify the currently supported Graph API version in Meta for the date of deployment.

## Installation

1. Copy the PHP/config/view files into the matching Laravel directories.
2. Merge the migration files and run `php artisan migrate`.
3. Add the route include from `routes/whatsapp_meta.php` to `routes/web.php` or directly copy its routes.
4. Add the scheduler line from `docs/scheduler.md` to `routes/console.php`.
5. Point Meta's webhook callback to `/meta/whatsapp/webhook` and configure the verify token to match `META_WHATSAPP_VERIFY_TOKEN`. The POST callback also validates Meta's `X-Hub-Signature-256` using `META_WHATSAPP_APP_SECRET`.
6. Add `/meta/whatsapp/webhook` to `VerifyCsrfToken::$except` if your route group applies Laravel's web CSRF middleware. The supplied route already removes CSRF middleware explicitly.
7. Subscribe the WABA to message/status/account update webhook fields available for your account.
8. Run `php artisan whatsapp:sync-templates` after your WABA templates are approved.
9. Run a queue worker for the `whatsapp` queue and monitor failed jobs.
10. Open `/admin/whatsapp` for the control dashboard.
11. From ERP business modules, create `egc_whatsapp_reminders` records or dispatch `WhatsAppMessageService` rather than calling Graph API directly.

## Existing ERP compatibility

The existing ERP already stores Meta credentials in `egc_api_integration` using `api_key = egc_whatsapp_meta_api_1` and fields such as `waba_id`, `access_token`, and `phone_number_id`. This module can use environment credentials or, when env credentials are incomplete, fall back to that existing row. The fallback is deliberately read-only.

The existing ERP also has `/webhook_whatsapp` and a CSRF exclusion. Do not remove that route during rollout. Use the new `/meta/whatsapp/webhook` endpoint for the new integration first, then consolidate later after validating traffic.

## Recommended rollout

1. Configure one production phone number and one test template.
2. Sync templates and verify exact template names/languages/components.
3. Run a single internal test recipient with explicit opt-in.
4. Enable one business event at a time: payment confirmation, entry acknowledgement, certificate link, reminder.
5. Start bulk campaigns with small batches and strict opt-in filtering.
6. Monitor delivery, read, failed, block, opt-out, and account-update events before increasing throughput.
