<?php

use Illuminate\Support\Facades\Schedule;

// Merge this schedule into the ERP's existing routes/console.php. Do not delete existing schedules.
Schedule::command('whatsapp:sync-templates')->dailyAt('02:20')->withoutOverlapping(10);
Schedule::command('whatsapp:dispatch-reminders --limit=250')->everyMinute()->withoutOverlapping(1);
Schedule::call(function () {
    \App\Models\WhatsAppMessage::where('status', 'queued')
        ->where('created_at', '<', now()->subHours(12))
        ->update(['status' => 'failed', 'failed_at' => now(), 'meta_error' => ['message' => 'Queue safety timeout']]);
})->hourly()->withoutOverlapping(5);
