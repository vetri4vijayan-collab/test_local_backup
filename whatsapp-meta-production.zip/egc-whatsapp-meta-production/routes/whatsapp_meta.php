<?php

use App\Http\Controllers\WhatsAppAdminController;
use App\Http\Controllers\WhatsAppWebhookController;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\VerifyCsrfToken;

Route::get('/meta/whatsapp/webhook', [WhatsAppWebhookController::class, 'verify'])->name('meta.whatsapp.webhook.verify');
Route::post('/meta/whatsapp/webhook', [WhatsAppWebhookController::class, 'receive'])
    ->withoutMiddleware([VerifyCsrfToken::class])
    ->name('meta.whatsapp.webhook.receive');

Route::middleware(['web', 'auth'])->prefix(config('whatsapp.admin_route_prefix', 'admin/whatsapp'))->name('admin.whatsapp.')->group(function () {
    Route::get('/', [WhatsAppAdminController::class, 'index'])->name('dashboard');
    Route::get('/stats', [WhatsAppAdminController::class, 'stats'])->name('stats');
    Route::get('/templates', [WhatsAppAdminController::class, 'templates'])->name('templates');
    Route::post('/templates/sync', [WhatsAppAdminController::class, 'syncTemplates'])->name('templates.sync');
    Route::post('/contacts/opt-in', [WhatsAppAdminController::class, 'optIn'])->name('contacts.opt_in');
    Route::post('/contacts/opt-out', [WhatsAppAdminController::class, 'optOut'])->name('contacts.opt_out');
    Route::post('/send/template', [WhatsAppAdminController::class, 'sendTemplate'])->name('send.template');
    Route::post('/send/service', [WhatsAppAdminController::class, 'sendService'])->name('send.service');
    Route::post('/campaigns/bulk-template', [WhatsAppAdminController::class, 'bulkTemplate'])->name('campaigns.bulk');
    Route::post('/circuit/open', [WhatsAppAdminController::class, 'openCircuit'])->name('circuit.open');
    Route::post('/circuit/close', [WhatsAppAdminController::class, 'closeCircuit'])->name('circuit.close');
});
