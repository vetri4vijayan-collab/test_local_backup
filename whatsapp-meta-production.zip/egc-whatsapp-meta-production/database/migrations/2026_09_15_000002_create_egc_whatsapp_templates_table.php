<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_templates', function (Blueprint $table) {
            $table->id('id');
            $table->string('meta_template_id', 100)->nullable()->unique();
            $table->string('name', 512);
            $table->string('language', 32);
            $table->string('category', 40)->nullable();
            $table->string('status', 40)->nullable()->index();
            $table->json('components')->nullable();
            $table->json('quality_score')->nullable();
            $table->timestamp('last_synced_at')->nullable();
            $table->timestamps();
            $table->unique(['name', 'language']);
            $table->index(['status', 'category']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_templates');
    }
};
