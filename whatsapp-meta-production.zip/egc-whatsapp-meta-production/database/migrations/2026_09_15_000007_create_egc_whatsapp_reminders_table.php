<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_reminders', function (Blueprint $table) {
            $table->id('id');
            $table->string('reminder_key', 140)->unique();
            $table->foreignId('contact_id')->constrained('egc_whatsapp_contacts')->cascadeOnDelete();
            $table->foreignId('template_id')->constrained('egc_whatsapp_templates');
            $table->timestamp('run_at')->index();
            $table->string('status', 30)->default('pending')->index();
            $table->unsignedTinyInteger('attempts')->default(0);
            $table->json('components')->nullable();
            $table->string('source', 120)->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->text('last_error')->nullable();
            $table->timestamps();
            $table->index(['status', 'run_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_reminders');
    }
};
