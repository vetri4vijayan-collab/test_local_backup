<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_messages', function (Blueprint $table) {
            $table->id('id');
            $table->foreignId('contact_id')->constrained('egc_whatsapp_contacts')->cascadeOnDelete();
            $table->foreignId('template_id')->nullable()->constrained('egc_whatsapp_templates')->nullOnDelete();
            $table->string('client_message_id', 100)->unique();
            $table->string('meta_message_id', 128)->nullable()->unique();
            $table->enum('direction', ['inbound', 'outbound'])->index();
            $table->string('message_type', 40);
            $table->string('category', 40)->nullable();
            $table->string('status', 40)->default('queued')->index();
            $table->string('source', 120)->nullable()->index();
            $table->string('campaign_key', 120)->nullable()->index();
            $table->text('body_text')->nullable();
            $table->json('payload')->nullable();
            $table->json('meta_error')->nullable();
            $table->timestamp('queued_at')->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('read_at')->nullable();
            $table->timestamp('failed_at')->nullable();
            $table->timestamps();
            $table->index(['direction', 'created_at']);
            $table->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_messages');
    }
};
