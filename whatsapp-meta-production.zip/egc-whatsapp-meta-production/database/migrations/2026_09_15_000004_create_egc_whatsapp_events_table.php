<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_events', function (Blueprint $table) {
            $table->id('id');
            $table->string('event_key', 128)->unique();
            $table->string('event_type', 64)->index();
            $table->string('message_id', 128)->nullable()->index();
            $table->string('wa_id', 64)->nullable()->index();
            $table->json('payload');
            $table->timestamp('received_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_events');
    }
};
