<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_campaigns', function (Blueprint $table) {
            $table->id('id');
            $table->string('campaign_key', 120)->unique();
            $table->string('name', 180);
            $table->foreignId('template_id')->constrained('egc_whatsapp_templates');
            $table->string('status', 40)->default('draft')->index();
            $table->unsignedInteger('total_recipients')->default(0);
            $table->unsignedInteger('queued_count')->default(0);
            $table->unsignedInteger('sent_count')->default(0);
            $table->unsignedInteger('delivered_count')->default(0);
            $table->unsignedInteger('read_count')->default(0);
            $table->unsignedInteger('failed_count')->default(0);
            $table->unsignedInteger('suppressed_count')->default(0);
            $table->json('filters')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_campaigns');
    }
};
