<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_contacts', function (Blueprint $table) {
            $table->id('id');
            $table->string('phone_e164', 32)->unique();
            $table->string('display_name', 180)->nullable();
            $table->string('wa_id', 64)->nullable()->index();
            $table->boolean('opted_in')->default(false)->index();
            $table->timestamp('opted_in_at')->nullable();
            $table->string('opt_in_source', 100)->nullable();
            $table->boolean('opted_out')->default(false)->index();
            $table->timestamp('opted_out_at')->nullable();
            $table->string('opt_out_source', 100)->nullable();
            $table->timestamp('last_user_message_at')->nullable()->index();
            $table->timestamp('window_expires_at')->nullable()->index();
            $table->timestamp('last_business_message_at')->nullable();
            $table->string('quality_hint', 40)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_contacts');
    }
};
