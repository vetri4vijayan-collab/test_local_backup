<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('egc_whatsapp_circuit_breakers', function (Blueprint $table) {
            $table->id('id');
            $table->boolean('is_open')->default(false)->index();
            $table->string('reason', 255)->nullable();
            $table->timestamp('opened_at')->nullable();
            $table->timestamp('cooldown_until')->nullable();
            $table->unsignedInteger('failure_count')->default(0);
            $table->unsignedInteger('last_window_sent')->default(0);
            $table->unsignedInteger('last_window_failed')->default(0);
            $table->timestamps();
        });

        \DB::table('egc_whatsapp_circuit_breakers')->insert([
            'is_open' => false,
            'reason' => null,
            'failure_count' => 0,
            'last_window_sent' => 0,
            'last_window_failed' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_whatsapp_circuit_breakers');
    }
};
