@extends('layouts.layoutMaster')

@section('title', 'WhatsApp Command Center')

@section('content')
<style>
    .wa-shell{--wa:#1f9d67;--wa-dark:#147a4e;--wa-soft:#eaf8f1;--ink:#172033;--muted:#7a8495;}
    .wa-shell .card{border:0;border-radius:18px;box-shadow:0 8px 30px rgba(20,32,52,.06)}
    .wa-hero{background:linear-gradient(135deg,#123a2c 0%,#176b4c 56%,#29a36f 100%);color:#fff;overflow:hidden;position:relative}
    .wa-hero:after{content:'';position:absolute;right:-80px;top:-80px;width:280px;height:280px;border-radius:50%;background:rgba(255,255,255,.08)}
    .wa-kpi{min-height:126px;position:relative;overflow:hidden}.wa-kpi .icon{width:42px;height:42px;border-radius:12px;background:var(--wa-soft);color:var(--wa);display:flex;align-items:center;justify-content:center;font-size:20px}.wa-kpi .label{color:var(--muted);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}.wa-kpi .value{font-size:28px;font-weight:800;color:var(--ink)}
    .wa-pill{display:inline-flex;gap:6px;align-items:center;border-radius:999px;padding:6px 10px;font-size:11px;font-weight:800}.wa-ok{background:#e8f7ef;color:#167247}.wa-danger{background:#fff0f0;color:#b3261e}.wa-warning{background:#fff6df;color:#9b6a00}.wa-muted{background:#f1f3f6;color:#677184}
    .wa-panel-title{font-weight:800;color:var(--ink);font-size:15px}.wa-sub{font-size:12px;color:var(--muted)}
    .wa-table{font-size:12px}.wa-table th{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:#8992a2;border-bottom:1px solid #eef1f5}.wa-table td{vertical-align:middle;border-color:#f0f2f6}
    .wa-compose .form-control,.wa-compose .form-select{border-radius:11px;min-height:42px}.wa-compose textarea{min-height:120px}
    .wa-status-dot{width:8px;height:8px;border-radius:50%;display:inline-block}.wa-status-dot.green{background:#26ad72}.wa-status-dot.red{background:#dc3545}.wa-status-dot.gray{background:#98a1af}
    .wa-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#0f172a;color:#e2e8f0;border-radius:10px;padding:12px;font-size:11px;white-space:pre-wrap;word-break:break-word}
    @media(max-width:991px){.wa-kpi .value{font-size:23px}}
</style>

<div class="wa-shell container-fluid py-2">
    <div class="card wa-hero mb-4">
        <div class="card-body p-4 p-lg-5 position-relative">
            <div class="row align-items-center position-relative" style="z-index:2">
                <div class="col-lg-8">
                    <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
                        <span class="wa-pill" style="background:rgba(255,255,255,.13);color:#fff"><span class="wa-status-dot green"></span> Meta Cloud API</span>
                        <span id="waCircuitBadge" class="wa-pill" style="background:rgba(255,255,255,.13);color:#fff">Checking safety state…</span>
                    </div>
                    <h2 class="mb-2 text-white fw-bold">WhatsApp Command Center</h2>
                    <p class="mb-0" style="color:rgba(255,255,255,.78);max-width:780px">Central monitoring, compliant template sending, 24-hour service-window control, bulk certificate delivery, and webhook-driven message reconciliation.</p>
                </div>
                <div class="col-lg-4 mt-4 mt-lg-0 text-lg-end">
                    <button id="waSyncBtn" class="btn btn-light rounded-pill px-4"><i class="mdi mdi-sync me-1"></i>Sync templates</button>
                    <button id="waPauseBtn" class="btn btn-outline-light rounded-pill px-4 ms-1"><i class="mdi mdi-pause-circle-outline me-1"></i>Pause outbound</button>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        @foreach([
          ['queued','Queued','mdi-clock-outline'],['sent_today','Sent today','mdi-send-outline'],['delivered_today','Delivered today','mdi-check-all'],['read_today','Read today','mdi-eye-outline'],['failed_today','Failed today','mdi-alert-circle-outline'],['open_windows','24h open','mdi-timer-outline'],['opted_out','Suppressed','mdi-account-cancel-outline']
        ] as $kpi)
        <div class="col-6 col-md-4 col-xl">
            <div class="card wa-kpi h-100"><div class="card-body">
                <div class="d-flex justify-content-between align-items-start"><div><div class="label">{{ $kpi[1] }}</div><div id="waKpi{{ $kpi[0] }}" class="value mt-2">{{ number_format($counts[$kpi[0]] ?? 0) }}</div></div><div class="icon"><i class="mdi {{ $kpi[2] }}"></i></div></div>
            </div></div>
        </div>
        @endforeach
    </div>

    <div class="row g-3">
        <div class="col-xl-8">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="wa-panel-title">Delivery health</div><div class="wa-sub">Outbound status trend for the selected window</div></div><span class="wa-pill wa-muted">Live webhook data</span></div>
                    <div id="waHealthChart" style="min-height:260px"></div>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="wa-panel-title">Template usage</div><div class="wa-sub">Count by template for this period</div></div></div>
                    <div id="waTemplateUsage"><div class="wa-sub">Loading…</div></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mt-1">
        <div class="col-xl-5">
            <div class="card wa-compose h-100">
                <div class="card-body">
                    <div class="wa-panel-title mb-1">Controlled sender</div>
                    <div class="wa-sub mb-3">Templates may be used to initiate/resume conversations. Free-form service messages require an open 24-hour window.</div>
                    <div class="mb-3"><label class="form-label fw-semibold">Recipient</label><input id="waPhone" class="form-control" placeholder="+919XXXXXXXXX"></div>
                    <div class="mb-3"><label class="form-label fw-semibold">Template</label><select id="waTemplate" class="form-select"><option value="">Select approved template</option></select></div>
                    <div class="mb-3"><label class="form-label fw-semibold">Components JSON</label><textarea id="waComponents" class="form-control" placeholder='[{"type":"body","parameters":[{"type":"text","text":"Krishna"}]}]'></textarea><div class="wa-sub mt-1">Paste only the component structure approved by the selected Meta template.</div></div>
                    <button id="waSendTemplate" class="btn btn-success w-100 rounded-pill"><i class="mdi mdi-send-check-outline me-1"></i>Queue template</button>
                    <hr>
                    <div class="wa-panel-title mb-1">24-hour service chat / media</div>
                    <div class="wa-sub mb-3">This route is deliberately blocked by the backend when the 24-hour window is closed.</div>
                    <div class="row g-2"><div class="col-4"><select id="waServiceType" class="form-select"><option value="text">Text</option><option value="image">Image</option><option value="video">Video</option><option value="audio">Audio</option><option value="document">Document</option></select></div><div class="col-8"><input id="waMediaUrl" class="form-control" placeholder="Public media URL or leave blank for text"></div></div>
                    <textarea id="waServiceText" class="form-control mt-2" placeholder="Service message / media caption"></textarea>
                    <button id="waSendService" class="btn btn-dark w-100 rounded-pill mt-2"><i class="mdi mdi-message-text-outline me-1"></i>Queue service message</button>
                </div>
            </div>
        </div>
        <div class="col-xl-7">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="wa-panel-title">Bulk certificate campaign</div><div class="wa-sub">One row per recipient. Every number is passed through opt-in/opt-out/template validation.</div></div><span class="wa-pill wa-warning">Maximum 5000 rows/request</span></div>
                    <input id="waCampaignName" class="form-control mb-2" placeholder="Campaign name e.g. September Certificates">
                    <select id="waCampaignTemplate" class="form-select mb-2"><option value="">Select approved certificate template</option></select>
                    <textarea id="waRecipients" class="form-control mb-2" style="min-height:220px" placeholder="One line per recipient JSON:\n{"phone":"+919XXXXXXXXX","components":[{"type":"body","parameters":[{"type":"text","text":"Krishna"}]}]}\n\nUse this for certificate URL variables, reference numbers, names, etc."></textarea>
                    <button id="waQueueBulk" class="btn btn-success rounded-pill px-4"><i class="mdi mdi-rocket-launch-outline me-1"></i>Validate & queue campaign</button>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="wa-panel-title">Recent message stream</div><div class="wa-sub">Status comes from the Meta webhook, not only the send response.</div></div><button id="waRefresh" class="btn btn-sm btn-outline-secondary rounded-pill"><i class="mdi mdi-refresh me-1"></i>Refresh</button></div>
            <div class="table-responsive"><table class="table wa-table" id="waRecentTable"><thead><tr><th>Time</th><th>Recipient</th><th>Type</th><th>Template</th><th>Status</th><th>Meta ID</th></tr></thead><tbody><tr><td colspan="6" class="text-center text-muted py-4">Loading…</td></tr></tbody></table></div>
        </div>
    </div>
</div>

<script>
(function($){
    'use strict';
    const routes = {
        stats: @json(route('admin.whatsapp.stats')),
        templates: @json(route('admin.whatsapp.templates')),
        sync: @json(route('admin.whatsapp.templates.sync')),
        sendTemplate: @json(route('admin.whatsapp.send.template')),
        sendService: @json(route('admin.whatsapp.send.service')),
        bulk: @json(route('admin.whatsapp.campaigns.bulk')),
        pause: @json(route('admin.whatsapp.circuit.open')),
        resume: @json(route('admin.whatsapp.circuit.close'))
    };
    const csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || @json(csrf_token());
    function ajax(opts){ return $.ajax(Object.assign({headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json'}}, opts)); }
    function toast(message, type='success'){ if(window.toastr){ toastr[type](message); } else { alert(message); } }
    function renderStatus(status){
        const map={queued:'wa-warning',sent:'wa-ok',delivered:'wa-ok',read:'wa-ok',failed:'wa-danger',received:'wa-ok'};
        return '<span class="wa-pill '+(map[status]||'wa-muted')+'">'+String(status||'').toUpperCase()+'</span>';
    }
    function loadTemplates(){
        return ajax({url:routes.templates}).done(r=>{
            const options=['<option value="">Select approved template</option>'];
            (r.data||[]).forEach(t=>{ if(String(t.status).toUpperCase()==='APPROVED'){ options.push('<option value="'+t.id+'">'+$('<div>').text(t.name+' · '+t.language+' · '+(t.category||'')).html()+'</option>'); }});
            $('#waTemplate,#waCampaignTemplate').html(options.join(''));
        });
    }
    function loadStats(){
        ajax({url:routes.stats}).done(r=>{
            const d=r.data||{};
            $('#waCircuitBadge').text(d.circuit_open?'OUTBOUND PAUSED':'OUTBOUND HEALTHY').toggleClass('wa-danger',!!d.circuit_open).toggleClass('wa-ok',!d.circuit_open);
            const recent=d.recent||[];
            const body=recent.length?recent.map(x=>'<tr><td>'+new Date(x.created_at).toLocaleString()+'</td><td>'+((x.contact||{}).display_name|| (x.contact||{}).phone_e164 || '—')+'</td><td>'+x.message_type+'</td><td>'+(((x.template||{}).name)||'—')+'</td><td>'+renderStatus(x.status)+'</td><td class="text-truncate" style="max-width:180px">'+(x.meta_message_id||'—')+'</td></tr>').join(''):'<tr><td colspan="6" class="text-center text-muted py-4">No messages found</td></tr>';
            $('#waRecentTable tbody').html(body);
            const t=d.templates||[];
            $('#waTemplateUsage').html(t.length?t.map(x=>'<div class="d-flex justify-content-between align-items-center py-2 border-bottom"><div><div class="fw-semibold">'+(((x.template||{}).name)||'Unknown')+'</div><div class="wa-sub">'+(((x.template||{}).language)||'')+'</div></div><strong>'+Number(x.total||0).toLocaleString()+'</strong></div>').join(''):'<div class="wa-sub">No template traffic yet.</div>');
            const dayMap={}; (d.days||[]).forEach(x=>{dayMap[x.day]=dayMap[x.day]||{}; dayMap[x.day][x.status]=Number(x.total||0);});
            const days=Object.keys(dayMap);
            $('#waHealthChart').html(days.length?'<div class="d-flex align-items-end gap-3" style="height:220px">'+days.map(day=>{const s=dayMap[day], total=(s.sent||0)+(s.delivered||0)+(s.read||0)+(s.failed||0), bad=s.failed||0, h=Math.min(100,Math.max(4,total?Math.round((total/Math.max(...days.map(k=>{const a=dayMap[k]||{};return (a.sent||0)+(a.delivered||0)+(a.read||0)+(a.failed||0)})))*100):4)); return '<div class="flex-fill text-center"><div class="bg-success-subtle rounded-top" style="height:'+h+'%;min-height:8px" title="'+total+' total, '+bad+' failed"></div><div class="small text-muted mt-2">'+day.slice(5)+'</div></div>';}).join('')+'</div>':'<div class="wa-sub py-5 text-center">No outbound traffic in the selected window.</div>');
        });
    }
    $('#waRefresh').on('click',loadStats);
    $('#waSyncBtn').on('click',function(){ const b=$(this).prop('disabled',true); ajax({url:routes.sync,type:'POST'}).done(r=>{toast(r.message||'Templates synced');loadTemplates();}).fail(x=>toast(x.responseJSON?.message||'Template sync failed','error')).always(()=>b.prop('disabled',false)); });
    $('#waSendTemplate').on('click',function(){
        let components=[]; const raw=$('#waComponents').val().trim();
        if(raw){ try{components=JSON.parse(raw);}catch(e){toast('Components JSON is invalid.','error');return;} }
        const b=$(this).prop('disabled',true);
        ajax({url:routes.sendTemplate,type:'POST',data:{phone:$('#waPhone').val(),template_id:$('#waTemplate').val(),components:components}}).done(r=>{toast(r.message||'Queued');loadStats();}).fail(x=>toast(x.responseJSON?.message||'Unable to queue template','error')).always(()=>b.prop('disabled',false));
    });
    $('#waSendService').on('click',function(){
        const type=$('#waServiceType').val(), text=$('#waServiceText').val(), url=$('#waMediaUrl').val();
        const b=$(this).prop('disabled',true);
        ajax({url:routes.sendService,type:'POST',data:{phone:$('#waPhone').val(),type:type,text:text,url:url,caption:text}}).done(r=>{toast(r.message||'Queued');loadStats();}).fail(x=>toast(x.responseJSON?.message||'Service message blocked','error')).always(()=>b.prop('disabled',false));
    });
    $('#waQueueBulk').on('click',function(){
        let recipients=[]; const lines=$('#waRecipients').val().split(/\n+/).map(x=>x.trim()).filter(Boolean);
        try{recipients=lines.map(x=>JSON.parse(x));}catch(e){toast('Each recipient must be valid JSON on its own line.','error');return;}
        const b=$(this).prop('disabled',true);
        ajax({url:routes.bulk,type:'POST',contentType:'application/json',data:JSON.stringify({name:$('#waCampaignName').val(),template_id:$('#waCampaignTemplate').val(),recipients:recipients})}).done(r=>{toast((r.message||'Campaign queued')+' Queued: '+r.queued+' Suppressed: '+r.suppressed);loadStats();}).fail(x=>toast(x.responseJSON?.message||'Campaign could not be queued','error')).always(()=>b.prop('disabled',false));
    });
    $('#waPauseBtn').on('click',function(){const reason=prompt('Why are you pausing outbound WhatsApp?','Manual safety pause'); if(!reason)return; ajax({url:routes.pause,type:'POST',data:{reason:reason}}).done(()=>{toast('Outbound WhatsApp paused','warning');loadStats();});});
    loadTemplates(); loadStats();
})(jQuery);
</script>
@endsection
