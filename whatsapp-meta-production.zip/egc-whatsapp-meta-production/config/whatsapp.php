<?php

return [
    'enabled' => (bool) env('META_WHATSAPP_ENABLED', false),
    'graph_version' => env('META_WHATSAPP_GRAPH_VERSION'),
    'waba_id' => env('META_WHATSAPP_WABA_ID'),
    'phone_number_id' => env('META_WHATSAPP_PHONE_NUMBER_ID'),
    'access_token' => env('META_WHATSAPP_ACCESS_TOKEN'),
    'verify_token' => env('META_WHATSAPP_VERIFY_TOKEN'),
    'app_secret' => env('META_WHATSAPP_APP_SECRET'),
    'default_country_code' => env('META_WHATSAPP_DEFAULT_COUNTRY_CODE', '91'),
    'timeout' => (int) env('META_WHATSAPP_TIMEOUT', 20),
    'connect_timeout' => (int) env('META_WHATSAPP_CONNECT_TIMEOUT', 5),
    'max_retries' => (int) env('META_WHATSAPP_MAX_RETRIES', 5),
    'base_retry_seconds' => (int) env('META_WHATSAPP_BASE_RETRY_SECONDS', 10),
    'throttle_per_minute' => (int) env('META_WHATSAPP_THROTTLE_PER_MINUTE', 60),
    'dry_run' => (bool) env('META_WHATSAPP_DRY_RUN', false),
    'auto_circuit_breaker' => true,
    'circuit_breaker' => [
        'hard_failures_10m' => 30,
        'delivery_failure_ratio_percent' => 35,
        'consecutive_5xx' => 8,
        'cooldown_minutes' => 60,
    ],
    'admin_route_prefix' => 'admin/whatsapp',
    'queue' => 'whatsapp',
    'timezone' => 'Asia/Kolkata',
];
