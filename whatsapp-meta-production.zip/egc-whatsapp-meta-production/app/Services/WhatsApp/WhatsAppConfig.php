<?php

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\DB;
use RuntimeException;

class WhatsAppConfig
{
    public function values(): array
    {
        $env = [
            'enabled' => config('whatsapp.enabled'),
            'graph_version' => config('whatsapp.graph_version'),
            'waba_id' => config('whatsapp.waba_id'),
            'phone_number_id' => config('whatsapp.phone_number_id'),
            'access_token' => config('whatsapp.access_token'),
            'verify_token' => config('whatsapp.verify_token'),
        ];

        $missing = collect(['waba_id', 'phone_number_id', 'access_token'])
            ->filter(fn ($key) => blank($env[$key]))
            ->values()
            ->all();

        if (!$missing) {
            return $env;
        }

        $row = DB::table('egc_api_integration')
            ->where('api_key', 'egc_whatsapp_meta_api_1')
            ->where('status', 0)
            ->orderByDesc('sno')
            ->first();

        if (!$row) {
            return $env;
        }

        $fields = json_decode($row->api_fields ?? '[]', true) ?: [];
        foreach ($fields as $field) {
            $key = $field['key'] ?? null;
            $value = $field['value'] ?? null;
            if ($key === 'waba_id' && blank($env['waba_id'])) $env['waba_id'] = $value;
            if ($key === 'phone_number_id' && blank($env['phone_number_id'])) $env['phone_number_id'] = $value;
            if ($key === 'access_token' && blank($env['access_token'])) $env['access_token'] = $value;
        }

        return $env;
    }

    public function requireConfigured(): array
    {
        $config = $this->values();
        foreach (['graph_version', 'waba_id', 'phone_number_id', 'access_token'] as $key) {
            if (blank($config[$key])) {
                throw new RuntimeException("WhatsApp Meta configuration is missing: {$key}");
            }
        }
        return $config;
    }
}
