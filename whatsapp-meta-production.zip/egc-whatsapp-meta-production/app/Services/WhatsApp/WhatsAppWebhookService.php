<?php

namespace App\Services\WhatsApp;

use App\Models\WhatsAppContact;
use App\Models\WhatsAppMessage;
use App\Models\WhatsAppEvent;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class WhatsAppWebhookService
{
    public function handle(array $payload): void
    {
        // Persist the verified callback before business processing so a transient processing
        // failure cannot erase the evidence required for reconciliation/replay diagnostics.
        $this->storeEvent(
            'callback:' . hash('sha256', json_encode($payload)),
            $payload
        );

        foreach ($payload['entry'] ?? [] as $entry) {
            foreach ($entry['changes'] ?? [] as $change) {
                $value = $change['value'] ?? [];
                $field = $change['field'] ?? 'unknown';

                $this->storeEvent('change:' . $field, $value);

                foreach ($value['messages'] ?? [] as $message) {
                    $this->handleInbound($value, $message);
                }

                foreach ($value['statuses'] ?? [] as $status) {
                    $this->handleStatus($status);
                }

                if ($field === 'account_update') {
                    $this->handleAccountUpdate($value);
                }
            }
        }
    }

    protected function handleInbound(array $value, array $message): void
    {
        $waId = (string) ($message['from'] ?? '');
        if (!$waId) return;

        $contact = WhatsAppContact::firstOrCreate(
            ['phone_e164' => '+' . preg_replace('/[^0-9]/', '', $waId)],
            ['wa_id' => $waId]
        );

        $receivedAt = isset($message['timestamp'])
            ? now()->setTimestamp((int) $message['timestamp'])
            : now();

        $contact->update([
            'wa_id' => $waId,
            'last_user_message_at' => $receivedAt,
            'window_expires_at' => $receivedAt->copy()->addHours(24),
        ]);

        $type = (string) ($message['type'] ?? 'unknown');
        $text = data_get($message, 'text.body');

        if ($type === 'text' && $this->looksLikeOptOut((string) $text)) {
            $contact->update([
                'opted_out' => true,
                'opted_out_at' => now(),
                'opt_out_source' => 'whatsapp_inbound_keyword',
            ]);
        }

        WhatsAppMessage::updateOrCreate(
            ['client_message_id' => 'inbound:' . ($message['id'] ?? Str::uuid())],
            [
                'contact_id' => $contact->id,
                'meta_message_id' => $message['id'] ?? null,
                'direction' => 'inbound',
                'message_type' => $type,
                'category' => 'service',
                'status' => 'received',
                'source' => 'meta_webhook',
                'body_text' => $text,
                'payload' => $message,
                'sent_at' => $receivedAt,
                'delivered_at' => $receivedAt,
            ]
        );
    }

    protected function handleStatus(array $status): void
    {
        $metaId = $status['id'] ?? null;
        if (!$metaId) return;

        $message = WhatsAppMessage::where('meta_message_id', $metaId)->first();
        $statusName = strtolower((string) ($status['status'] ?? ''));
        $previousStatus = $message?->status;
        if (!$message) {
            $this->storeEvent('status:' . $metaId . ':' . $statusName, $status, $metaId, $status['recipient_id'] ?? null);
            return;
        }

        $updates = [];
        $timestamp = isset($status['timestamp']) ? now()->setTimestamp((int) $status['timestamp']) : now();
        if ($statusName === 'sent') { $updates['status'] = 'sent'; $updates['sent_at'] = $timestamp; }
        if ($statusName === 'delivered') { $updates['status'] = 'delivered'; $updates['delivered_at'] = $timestamp; }
        if ($statusName === 'read') { $updates['status'] = 'read'; $updates['read_at'] = $timestamp; }
        if ($statusName === 'failed') {
            $updates['status'] = 'failed';
            $updates['failed_at'] = $timestamp;
            $updates['meta_error'] = $status['errors'] ?? $status['error'] ?? $status;
        }
        if ($updates) $message->update($updates);
        if ($message->campaign_key && $statusName && $statusName !== $previousStatus) {
            $campaign = \App\Models\WhatsAppCampaign::where('campaign_key', $message->campaign_key)->first();
            if ($campaign) {
                $column = match ($statusName) {
                    'sent' => 'sent_count',
                    'delivered' => 'delivered_count',
                    'read' => 'read_count',
                    'failed' => 'failed_count',
                    default => null,
                };
                if ($column) $campaign->increment($column);
            }
        }
        if ($statusName === 'failed') {
            $errorText = strtolower(json_encode($status['errors'] ?? $status['error'] ?? $status));
            if (str_contains($errorText, 'policy') || str_contains($errorText, 'spam') || str_contains($errorText, 'quality') || str_contains($errorText, 'restriction')) {
                app(WhatsAppGuard::class)->openCircuit('Meta returned a policy/quality/restriction-related delivery error.');
            } else {
                $this->evaluateFailureRatio();
            }
        }
        $this->storeEvent('status:' . $metaId . ':' . $statusName . ':' . now()->format('Hisv'), $status, $metaId, $status['recipient_id'] ?? null);
    }


    protected function evaluateFailureRatio(): void
    {
        $since = now()->subMinutes(10);
        $total = WhatsAppMessage::where('direction', 'outbound')->where('created_at', '>=', $since)->whereIn('status', ['sent','delivered','read','failed'])->count();
        if ($total < 20) return;
        $failed = WhatsAppMessage::where('direction', 'outbound')->where('created_at', '>=', $since)->where('status', 'failed')->count();
        $ratio = ($failed / max(1, $total)) * 100;
        if ($ratio >= (float) config('whatsapp.circuit_breaker.delivery_failure_ratio_percent', 35)) {
            app(WhatsAppGuard::class)->openCircuit('Automatic safety pause: high Meta delivery failure ratio in the last 10 minutes.');
        }
    }

    protected function handleAccountUpdate(array $value): void
    {
        $text = json_encode($value);
        $restriction = data_get($value, 'business_update') || data_get($value, 'restriction');
        if ($restriction || stripos($text, 'restrict') !== false || stripos($text, 'violation') !== false || stripos($text, 'quality') !== false) {
            app(WhatsAppGuard::class)->openCircuit('Meta account update indicates a possible restriction/quality issue.');
        }
        $this->storeEvent('account_update:' . hash('sha256', $text . microtime(true)), $value);
    }

    protected function storeEvent(string $keyPrefix, array $payload, ?string $messageId = null, ?string $waId = null): void
    {
        WhatsAppEvent::firstOrCreate(
            ['event_key' => Str::limit($keyPrefix . ':' . hash('sha256', json_encode($payload)), 128, '')],
            [
                'event_type' => Str::before($keyPrefix, ':'),
                'message_id' => $messageId,
                'wa_id' => $waId,
                'payload' => $payload,
                'received_at' => now(),
            ]
        );
    }

    protected function looksLikeOptOut(string $text): bool
    {
        $normalized = strtolower(trim($text));
        return in_array($normalized, ['stop', 'unsubscribe', 'opt out', 'optout', 'remove me', 'do not message'], true);
    }
}
