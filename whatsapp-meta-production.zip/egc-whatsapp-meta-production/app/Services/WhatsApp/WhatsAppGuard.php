<?php

namespace App\Services\WhatsApp;

use App\Models\WhatsAppContact;
use App\Models\WhatsAppTemplate;
use App\Models\WhatsAppMessage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class WhatsAppGuard
{
    public function assertCanSend(WhatsAppContact $contact, string $mode, ?WhatsAppTemplate $template = null): void
    {
        if (!config('whatsapp.enabled')) {
            throw new RuntimeException('WhatsApp sending is disabled.');
        }

        if ($contact->opted_out) {
            throw new RuntimeException('Recipient has opted out of WhatsApp messages.');
        }

        if (!$contact->opted_in) {
            throw new RuntimeException('Recipient does not have a recorded WhatsApp opt-in.');
        }

        if ($this->isCircuitOpen()) {
            throw new RuntimeException('WhatsApp circuit breaker is open. Outbound messaging is paused by the ERP safety guard.');
        }

        if ($mode === 'service') {
            if (!$contact->hasOpenServiceWindow()) {
                throw new RuntimeException('24-hour customer-service window is closed. Use an approved template instead.');
            }
            return;
        }

        if ($mode === 'template') {
            if (!$template || !$template->isApproved()) {
                throw new RuntimeException('Only an approved WhatsApp template can initiate or resume a conversation outside the 24-hour window.');
            }
            return;
        }

        throw new RuntimeException('Unsupported WhatsApp send mode.');
    }

    public function isCircuitOpen(): bool
    {
        $row = DB::table('egc_whatsapp_circuit_breakers')->orderByDesc('id')->first();
        if (!$row || !$row->is_open) return false;
        if ($row->cooldown_until && now()->gte($row->cooldown_until)) {
            $this->closeCircuit();
            return false;
        }
        return true;
    }

    public function openCircuit(string $reason): void
    {
        $until = now()->addMinutes((int) config('whatsapp.circuit_breaker.cooldown_minutes', 60));
        DB::table('egc_whatsapp_circuit_breakers')->orderByDesc('id')->limit(1)->update([
            'is_open' => true,
            'reason' => mb_substr($reason, 0, 255),
            'opened_at' => now(),
            'cooldown_until' => $until,
            'updated_at' => now(),
        ]);
        Cache::forget('egc_whatsapp:circuit_breaker');
    }

    public function closeCircuit(): void
    {
        DB::table('egc_whatsapp_circuit_breakers')->orderByDesc('id')->limit(1)->update([
            'is_open' => false,
            'reason' => null,
            'cooldown_until' => null,
            'failure_count' => 0,
            'updated_at' => now(),
        ]);
        Cache::forget('egc_whatsapp:circuit_breaker');
    }
}
