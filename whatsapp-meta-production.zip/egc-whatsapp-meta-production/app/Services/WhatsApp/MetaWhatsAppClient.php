<?php

namespace App\Services\WhatsApp;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class MetaWhatsAppClient
{
    public function __construct(private WhatsAppConfig $config)
    {
    }

    protected function http(): PendingRequest
    {
        $cfg = $this->config->requireConfigured();

        return Http::withToken($cfg['access_token'])
            ->acceptJson()
            ->asJson()
            ->timeout(config('whatsapp.timeout', 20))
            ->connectTimeout(config('whatsapp.connect_timeout', 5));
    }

    protected function graphUrl(string $path): string
    {
        $cfg = $this->config->requireConfigured();
        return 'https://graph.facebook.com/' . trim($cfg['graph_version'], '/') . '/' . ltrim($path, '/');
    }

    public function sendPayload(array $payload): array
    {
        if (config('whatsapp.dry_run')) {
            return ['id' => 'dryrun_' . bin2hex(random_bytes(8)), 'dry_run' => true, 'response' => ['messages' => [['id' => 'dryrun']]]];
        }

        $cfg = $this->config->requireConfigured();
        $response = $this->http()->post($this->graphUrl($cfg['phone_number_id'] . '/messages'), $payload);

        if ($response->successful()) {
            return $response->json() ?: [];
        }

        $json = $response->json();
        $message = data_get($json, 'error.message') ?: $response->body();
        $code = data_get($json, 'error.code');
        throw new RuntimeException("Meta WhatsApp API error [{$response->status()} / {$code}]: {$message}", $response->status());
    }

    public function listTemplates(): array
    {
        $cfg = $this->config->requireConfigured();
        $all = [];
        $url = $this->graphUrl($cfg['waba_id'] . '/message_templates?limit=250');

        do {
            $response = $this->http()->get($url);
            if (!$response->successful()) {
                $json = $response->json();
                throw new RuntimeException(data_get($json, 'error.message') ?: $response->body(), $response->status());
            }
            $json = $response->json() ?: [];
            $all = array_merge($all, $json['data'] ?? []);
            $url = data_get($json, 'paging.next');
        } while ($url);

        return $all;
    }
}
