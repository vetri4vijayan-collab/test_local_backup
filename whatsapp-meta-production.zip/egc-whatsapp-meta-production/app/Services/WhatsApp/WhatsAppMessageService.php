<?php

namespace App\Services\WhatsApp;

use App\Models\WhatsAppContact;
use App\Models\WhatsAppMessage;
use App\Models\WhatsAppTemplate;
use Illuminate\Support\Str;
use RuntimeException;

class WhatsAppMessageService
{
    public function __construct(
        private WhatsAppGuard $guard,
        private MetaWhatsAppClient $client,
    ) {
    }

    public function upsertContact(string $phone, array $attributes = []): WhatsAppContact
    {
        $phone = $this->normalizePhone($phone);
        return WhatsAppContact::updateOrCreate(['phone_e164' => $phone], $attributes);
    }

    public function recordOptIn(WhatsAppContact $contact, string $source): WhatsAppContact
    {
        $contact->update([
            'opted_in' => true,
            'opted_in_at' => now(),
            'opt_in_source' => $source,
            'opted_out' => false,
            'opted_out_at' => null,
            'opt_out_source' => null,
        ]);
        return $contact->fresh();
    }

    public function recordOptOut(WhatsAppContact $contact, string $source): WhatsAppContact
    {
        $contact->update([
            'opted_out' => true,
            'opted_out_at' => now(),
            'opt_out_source' => $source,
        ]);
        return $contact->fresh();
    }

    public function queueTemplate(
        WhatsAppContact $contact,
        WhatsAppTemplate $template,
        array $components = [],
        string $source = 'erp',
        ?string $campaignKey = null,
    ): WhatsAppMessage {
        $this->guard->assertCanSend($contact, 'template', $template);

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $contact->phone_e164,
            'type' => 'template',
            'template' => [
                'name' => $template->name,
                'language' => ['code' => $template->language],
            ],
        ];

        if ($components) {
            $payload['template']['components'] = $components;
        }

        return $this->createQueuedMessage($contact, $template, 'template', $template->category, $payload, $source, $campaignKey);
    }

    public function queueServiceText(WhatsAppContact $contact, string $text, string $source = 'erp'): WhatsAppMessage
    {
        $this->guard->assertCanSend($contact, 'service');
        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $contact->phone_e164,
            'type' => 'text',
            'text' => ['preview_url' => true, 'body' => $text],
        ];
        return $this->createQueuedMessage($contact, null, 'text', 'service', $payload, $source);
    }

    public function queueServiceMedia(WhatsAppContact $contact, string $type, string $url, ?string $caption = null, ?string $filename = null, string $source = 'erp'): WhatsAppMessage
    {
        $allowed = ['image', 'video', 'audio', 'document'];
        if (!in_array($type, $allowed, true)) {
            throw new RuntimeException('Unsupported WhatsApp media type.');
        }
        $this->guard->assertCanSend($contact, 'service');
        $media = ['link' => $url];
        if ($caption && in_array($type, ['image', 'video', 'document'], true)) $media['caption'] = $caption;
        if ($filename && $type === 'document') $media['filename'] = $filename;

        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $contact->phone_e164,
            'type' => $type,
            $type => $media,
        ];
        return $this->createQueuedMessage($contact, null, $type, 'service', $payload, $source);
    }

    protected function createQueuedMessage(WhatsAppContact $contact, ?WhatsAppTemplate $template, string $type, ?string $category, array $payload, string $source, ?string $campaignKey = null): WhatsAppMessage
    {
        $message = WhatsAppMessage::create([
            'contact_id' => $contact->id,
            'template_id' => $template?->id,
            'client_message_id' => (string) Str::uuid(),
            'direction' => 'outbound',
            'message_type' => $type,
            'category' => $category,
            'status' => 'queued',
            'source' => $source,
            'campaign_key' => $campaignKey,
            'payload' => $payload,
            'queued_at' => now(),
        ]);

        \App\Jobs\DispatchWhatsAppMessageJob::dispatch($message->id)
            ->onQueue(config('whatsapp.queue', 'whatsapp'));

        return $message;
    }

    public function sendNow(WhatsAppMessage $message): WhatsAppMessage
    {
        if ($message->status !== 'queued') return $message;

        try {
            $result = $this->client->sendPayload($message->payload ?? []);
            $metaId = data_get($result, 'messages.0.id');
            $message->update([
                'meta_message_id' => $metaId,
                'status' => 'sent',
                'sent_at' => now(),
            ]);
            $message->contact()->update(['last_business_message_at' => now()]);
            return $message->fresh();
        } catch (\Throwable $e) {
            $message->update([
                'status' => 'failed',
                'failed_at' => now(),
                'meta_error' => ['message' => $e->getMessage(), 'code' => $e->getCode()],
            ]);
            throw $e;
        }
    }

    public function normalizePhone(string $phone): string
    {
        $digits = preg_replace('/[^0-9]/', '', $phone);
        if (!$digits) throw new RuntimeException('Invalid WhatsApp phone number.');
        $cc = trim((string) config('whatsapp.default_country_code', '91'));
        if (strlen($digits) === 10 && $cc) $digits = $cc . $digits;
        return '+' . $digits;
    }
}
