<?php

namespace App\Console\Commands;

use App\Models\WhatsAppTemplate;
use App\Services\WhatsApp\MetaWhatsAppClient;
use Illuminate\Console\Command;

class SyncWhatsAppTemplates extends Command
{
    protected $signature = 'whatsapp:sync-templates';
    protected $description = 'Sync approved/pending/rejected WhatsApp templates from Meta';

    public function handle(MetaWhatsAppClient $client): int
    {
        $items = $client->listTemplates();
        foreach ($items as $item) {
            WhatsAppTemplate::updateOrCreate(
                ['name' => $item['name'] ?? '', 'language' => $item['language'] ?? 'en'],
                [
                    'meta_template_id' => $item['id'] ?? null,
                    'category' => $item['category'] ?? null,
                    'status' => $item['status'] ?? null,
                    'components' => $item['components'] ?? [],
                    'quality_score' => $item['quality_score'] ?? null,
                    'last_synced_at' => now(),
                ]
            );
        }
        $this->info('Synced ' . count($items) . ' WhatsApp templates.');
        return self::SUCCESS;
    }
}
