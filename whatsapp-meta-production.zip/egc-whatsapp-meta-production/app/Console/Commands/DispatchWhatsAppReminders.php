<?php

namespace App\Console\Commands;

use App\Models\WhatsAppReminder;
use App\Services\WhatsApp\WhatsAppMessageService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class DispatchWhatsAppReminders extends Command
{
    protected $signature = 'whatsapp:dispatch-reminders {--limit=250}';
    protected $description = 'Queue due WhatsApp reminder templates through the centralized safety layer';

    public function handle(WhatsAppMessageService $service): int
    {
        $limit = max(1, min((int) $this->option('limit'), 1000));
        $processed = 0;

        WhatsAppReminder::query()
            ->where('status', 'pending')
            ->where('run_at', '<=', now())
            ->orderBy('run_at')
            ->limit($limit)
            ->get()
            ->each(function (WhatsAppReminder $reminder) use ($service, &$processed) {
                try {
                    $message = $service->queueTemplate($reminder->contact, $reminder->template, $reminder->components ?? [], $reminder->source ?: 'reminder');
                    $reminder->update(['status' => 'queued', 'attempts' => $reminder->attempts + 1, 'sent_at' => null, 'last_error' => null]);
                    $processed++;
                } catch (\Throwable $e) {
                    $reminder->update(['status' => 'suppressed', 'attempts' => $reminder->attempts + 1, 'last_error' => $e->getMessage()]);
                }
            });

        $this->info("Processed {$processed} due reminders.");
        return self::SUCCESS;
    }
}
