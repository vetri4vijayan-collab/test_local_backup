<?php

namespace App\Jobs;

use App\Models\WhatsAppMessage;
use App\Services\WhatsApp\WhatsAppMessageService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\RateLimiter;
use Throwable;

class DispatchWhatsAppMessageJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 20;
    public int $timeout = 60;

    public function __construct(public int $messageId)
    {
    }

    public function handle(WhatsAppMessageService $service): void
    {
        $message = WhatsAppMessage::query()->find($this->messageId);
        if (!$message || $message->status !== 'queued') return;

        $key = 'egc-whatsapp-send-rate';
        if (!RateLimiter::attempt($key, max(1, (int) config('whatsapp.throttle_per_minute', 60)), fn () => true, 60)) {
            $this->release(min(30, max(5, RateLimiter::availableIn($key))));
            return;
        }

        try {
            $service->sendNow($message);
        } catch (\Throwable $e) {
            // Do not blindly retry unknown/ambiguous failures: a request may have been accepted by Meta.
            // The webhook will reconcile delivery status. Only a future operator retry should resend.
            return;
        }
    }

    public function failed(Throwable $exception): void
    {
        $message = WhatsAppMessage::query()->find($this->messageId);
        if (!$message) return;
        if ($message->status === 'queued') {
            $message->update([
                'status' => 'failed',
                'failed_at' => now(),
                'meta_error' => ['message' => $exception->getMessage(), 'code' => $exception->getCode()],
            ]);
        }
    }
}
