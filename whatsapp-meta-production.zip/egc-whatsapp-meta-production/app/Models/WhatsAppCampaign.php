<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppCampaign extends Model
{
    protected $table = 'egc_whatsapp_campaigns';
    protected $guarded = [];
    protected $casts = ['filters' => 'array', 'started_at' => 'datetime', 'completed_at' => 'datetime'];

    public function template()
    {
        return $this->belongsTo(WhatsAppTemplate::class, 'template_id');
    }
}
