<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppReminder extends Model
{
    protected $table = 'egc_whatsapp_reminders';
    protected $guarded = [];
    protected $casts = ['run_at' => 'datetime', 'sent_at' => 'datetime', 'components' => 'array'];

    public function contact() { return $this->belongsTo(WhatsAppContact::class, 'contact_id'); }
    public function template() { return $this->belongsTo(WhatsAppTemplate::class, 'template_id'); }
}
