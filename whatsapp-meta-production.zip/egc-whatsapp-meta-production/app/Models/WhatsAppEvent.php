<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppEvent extends Model
{
    protected $table = 'egc_whatsapp_events';
    protected $guarded = [];
    protected $casts = ['payload' => 'array', 'received_at' => 'datetime'];
}
