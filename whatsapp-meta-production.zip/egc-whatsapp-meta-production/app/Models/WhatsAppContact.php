<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppContact extends Model
{
    protected $table = 'egc_whatsapp_contacts';

    protected $guarded = [];

    protected $casts = [
        'opted_in' => 'boolean',
        'opted_out' => 'boolean',
        'opted_in_at' => 'datetime',
        'opted_out_at' => 'datetime',
        'last_user_message_at' => 'datetime',
        'window_expires_at' => 'datetime',
        'last_business_message_at' => 'datetime',
    ];

    public function messages()
    {
        return $this->hasMany(WhatsAppMessage::class, 'contact_id');
    }

    public function hasOpenServiceWindow(): bool
    {
        return $this->window_expires_at && $this->window_expires_at->isFuture();
    }
}
