<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsAppTemplate extends Model
{
    protected $table = 'egc_whatsapp_templates';
    protected $guarded = [];
    protected $casts = [
        'components' => 'array',
        'quality_score' => 'array',
        'last_synced_at' => 'datetime',
    ];

    public function messages()
    {
        return $this->hasMany(WhatsAppMessage::class, 'template_id');
    }

    public function isApproved(): bool
    {
        return strtoupper((string) $this->status) === 'APPROVED';
    }
}
