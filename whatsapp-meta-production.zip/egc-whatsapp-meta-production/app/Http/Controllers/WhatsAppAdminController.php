<?php

namespace App\Http\Controllers;

use App\Models\WhatsAppCampaign;
use App\Models\WhatsAppContact;
use App\Models\WhatsAppMessage;
use App\Models\WhatsAppTemplate;
use App\Services\WhatsApp\MetaWhatsAppClient;
use App\Services\WhatsApp\WhatsAppGuard;
use App\Services\WhatsApp\WhatsAppMessageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class WhatsAppAdminController extends Controller
{
    protected function authorizeAdmin(Request $request): void
    {
        $user = $request->user();
        $allowed = (bool) ($user && (
            ($user->is_admin ?? false) ||
            in_array((int) ($user->role_id ?? 0), [1, 2], true) ||
            (method_exists($user, 'hasPermission') && $user->hasPermission('whatsapp.manage'))
        ));
        abort_unless($allowed, 403, 'WhatsApp administration permission required.');
    }

    public function index(Request $request)
    {
        $this->authorizeAdmin($request);

        $counts = [
            'queued' => WhatsAppMessage::where('status', 'queued')->count(),
            'sent_today' => WhatsAppMessage::where('direction', 'outbound')->where('status', '!=', 'failed')->whereDate('created_at', today())->count(),
            'delivered_today' => WhatsAppMessage::where('status', 'delivered')->whereDate('delivered_at', today())->count(),
            'read_today' => WhatsAppMessage::where('status', 'read')->whereDate('read_at', today())->count(),
            'failed_today' => WhatsAppMessage::where('status', 'failed')->whereDate('failed_at', today())->count(),
            'open_windows' => WhatsAppContact::where('window_expires_at', '>', now())->count(),
            'opted_out' => WhatsAppContact::where('opted_out', true)->count(),
        ];

        return view('admin.whatsapp.dashboard', compact('counts'));
    }

    public function stats(Request $request)
    {
        $this->authorizeAdmin($request);
        $from = $request->date('from')?->startOfDay() ?? now()->subDays(6)->startOfDay();
        $to = $request->date('to')?->endOfDay() ?? now()->endOfDay();

        $rows = WhatsAppMessage::query()
            ->selectRaw('DATE(created_at) as day, status, COUNT(*) as total')
            ->whereBetween('created_at', [$from, $to])
            ->where('direction', 'outbound')
            ->groupBy('day', 'status')
            ->orderBy('day')
            ->get();

        $templates = WhatsAppMessage::query()
            ->selectRaw('template_id, COUNT(*) as total')
            ->whereNotNull('template_id')
            ->whereBetween('created_at', [$from, $to])
            ->groupBy('template_id')
            ->with('template:id,name,language,category,status')
            ->orderByDesc('total')
            ->limit(20)
            ->get();

        $recent = WhatsAppMessage::with(['contact:id,phone_e164,display_name', 'template:id,name,language'])
            ->latest()->limit(50)->get();

        return response()->json([
            'status' => 200,
            'data' => [
                'days' => $rows,
                'templates' => $templates,
                'recent' => $recent,
                'circuit_open' => app(WhatsAppGuard::class)->isCircuitOpen(),
            ],
        ]);
    }

    public function templates(Request $request)
    {
        $this->authorizeAdmin($request);
        return response()->json(['status' => 200, 'data' => WhatsAppTemplate::orderBy('name')->get()]);
    }

    public function syncTemplates(Request $request, MetaWhatsAppClient $client)
    {
        $this->authorizeAdmin($request);
        $templates = $client->listTemplates();
        foreach ($templates as $item) {
            WhatsAppTemplate::updateOrCreate(
                ['name' => $item['name'] ?? '', 'language' => $item['language'] ?? 'en'],
                [
                    'meta_template_id' => $item['id'] ?? null,
                    'category' => $item['category'] ?? null,
                    'status' => $item['status'] ?? null,
                    'components' => $item['components'] ?? [],
                    'quality_score' => $item['quality_score'] ?? null,
                    'last_synced_at' => now(),
                ]
            );
        }
        return response()->json(['status' => 200, 'message' => count($templates) . ' templates synced.']);
    }

    public function optIn(Request $request, WhatsAppMessageService $service)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate(['phone' => 'required|string|max:32', 'source' => 'required|string|max:100', 'display_name' => 'nullable|string|max:180']);
        $contact = $service->upsertContact($data['phone'], ['display_name' => $data['display_name'] ?? null]);
        $service->recordOptIn($contact, $data['source']);
        return response()->json(['status' => 200, 'message' => 'Opt-in recorded.']);
    }

    public function optOut(Request $request, WhatsAppMessageService $service)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate(['phone' => 'required|string|max:32', 'source' => 'required|string|max:100']);
        $contact = $service->upsertContact($data['phone']);
        $service->recordOptOut($contact, $data['source']);
        return response()->json(['status' => 200, 'message' => 'Opt-out recorded and future outbound messages suppressed.']);
    }

    public function sendTemplate(Request $request, WhatsAppMessageService $service)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate([
            'phone' => 'required|string|max:32',
            'template_id' => 'required|integer|exists:egc_whatsapp_templates,id',
            'components' => 'nullable|array',
            'source' => 'nullable|string|max:120',
        ]);
        $contact = $service->upsertContact($data['phone']);
        $template = WhatsAppTemplate::findOrFail($data['template_id']);
        $message = $service->queueTemplate($contact, $template, $data['components'] ?? [], $data['source'] ?? 'admin');
        return response()->json(['status' => 200, 'message' => 'Queued.', 'data' => $message->id]);
    }

    public function sendService(Request $request, WhatsAppMessageService $service)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate(['phone' => 'required|string|max:32', 'type' => 'required|in:text,image,video,audio,document', 'text' => 'nullable|string|max:4096', 'url' => 'nullable|url|max:2048', 'caption' => 'nullable|string|max:1024', 'filename' => 'nullable|string|max:180']);
        $contact = $service->upsertContact($data['phone']);
        if ($data['type'] === 'text') {
            abort_if(blank($data['text'] ?? null), 422, 'Text is required.');
            $message = $service->queueServiceText($contact, $data['text'], 'admin');
        } else {
            abort_if(blank($data['url'] ?? null), 422, 'A public media URL is required.');
            $message = $service->queueServiceMedia($contact, $data['type'], $data['url'], $data['caption'] ?? null, $data['filename'] ?? null, 'admin');
        }
        return response()->json(['status' => 200, 'message' => 'Queued.', 'data' => $message->id]);
    }

    public function bulkTemplate(Request $request, WhatsAppMessageService $service)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate([
            'name' => 'required|string|max:180',
            'template_id' => 'required|integer|exists:egc_whatsapp_templates,id',
            'source' => 'nullable|string|max:120',
            'recipients' => 'required|array|min:1|max:5000',
            'recipients.*.phone' => 'required|string|max:32',
            'recipients.*.components' => 'nullable|array',
        ]);

        $template = WhatsAppTemplate::findOrFail($data['template_id']);
        abort_unless($template->isApproved(), 422, 'Only approved templates can be used for bulk initiation.');

        $campaign = WhatsAppCampaign::create([
            'campaign_key' => 'WA-' . now()->format('YmdHis') . '-' . Str::upper(Str::random(6)),
            'name' => $data['name'],
            'template_id' => $template->id,
            'status' => 'running',
            'total_recipients' => count($data['recipients']),
            'started_at' => now(),
            'filters' => ['source' => $data['source'] ?? 'admin'],
        ]);

        $queued = 0;
        $suppressed = 0;
        foreach ($data['recipients'] as $recipient) {
            try {
                $contact = $service->upsertContact($recipient['phone']);
                $service->queueTemplate($contact, $template, $recipient['components'] ?? [], $data['source'] ?? 'bulk', $campaign->campaign_key);
                $queued++;
            } catch (\Throwable $e) {
                $suppressed++;
            }
        }

        $campaign->update(['queued_count' => $queued, 'suppressed_count' => $suppressed]);
        return response()->json(['status' => 200, 'message' => 'Campaign queued.', 'campaign_key' => $campaign->campaign_key, 'queued' => $queued, 'suppressed' => $suppressed]);
    }

    public function openCircuit(Request $request, WhatsAppGuard $guard)
    {
        $this->authorizeAdmin($request);
        $data = $request->validate(['reason' => 'required|string|max:255']);
        $guard->openCircuit('Admin: ' . $data['reason']);
        return response()->json(['status' => 200]);
    }

    public function closeCircuit(Request $request, WhatsAppGuard $guard)
    {
        $this->authorizeAdmin($request);
        $guard->closeCircuit();
        return response()->json(['status' => 200]);
    }
}
