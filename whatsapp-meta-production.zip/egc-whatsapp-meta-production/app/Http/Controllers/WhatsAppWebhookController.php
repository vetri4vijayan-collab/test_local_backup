<?php

namespace App\Http\Controllers;

use App\Services\WhatsApp\WhatsAppWebhookService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WhatsAppWebhookController extends Controller
{
    public function verify(Request $request)
    {
        $mode = $request->query('hub.mode', $request->query('hub_mode'));
        $token = $request->query('hub.verify_token', $request->query('hub_verify_token'));
        $challenge = $request->query('hub.challenge', $request->query('hub_challenge'));

        if ($mode === 'subscribe' && hash_equals((string) config('whatsapp.verify_token'), (string) $token)) {
            return response($challenge, 200);
        }

        return response('Forbidden', 403);
    }

    public function receive(Request $request, WhatsAppWebhookService $service): JsonResponse
    {
        $rawBody = $request->getContent();
        $signature = (string) $request->header('X-Hub-Signature-256');
        $appSecret = (string) config('whatsapp.app_secret');

        if ($appSecret === '') {
            report(new \RuntimeException('META_WHATSAPP_APP_SECRET is not configured. Webhook rejected.'));
            return response()->json(['status' => 'configuration_error'], 500);
        }

        if (!$this->isValidSignature($rawBody, $signature, $appSecret)) {
            return response()->json(['status' => 'invalid_signature'], 403);
        }

        try {
            $service->handle($request->all());
            return response()->json(['status' => 'ok']);
        } catch (\Throwable $e) {
            // Always acknowledge a verified Meta callback quickly. Failed business processing is
            // logged and the circuit breaker remains responsible for outbound safety.
            report($e);
            return response()->json(['status' => 'accepted'], 200);
        }
    }

    private function isValidSignature(string $rawBody, string $signature, string $appSecret): bool
    {
        if (!str_starts_with($signature, 'sha256=')) {
            return false;
        }

        $expected = 'sha256=' . hash_hmac('sha256', $rawBody, $appSecret);
        return hash_equals($expected, $signature);
    }
}
