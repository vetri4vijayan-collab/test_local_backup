# Scheduler

Merge, do not replace, the following into the ERP's existing `routes/console.php`:

```php
Schedule::command('whatsapp:sync-templates')->dailyAt('02:20')->withoutOverlapping(10);
Schedule::command('whatsapp:dispatch-reminders --limit=250')->everyMinute()->withoutOverlapping(1);
Schedule::call(function () {
    \App\Models\WhatsAppMessage::where('status', 'queued')
        ->where('created_at', '<', now()->subHours(12))
        ->update(['status' => 'failed', 'failed_at' => now(), 'meta_error' => ['message' => 'Queue safety timeout']]);
})->hourly()->withoutOverlapping(5);
```

Cron should execute Laravel's scheduler once per minute:

```text
* * * * * cd /path/to/erp && php artisan schedule:run >> /dev/null 2>&1
```

Run a dedicated queue worker:

```bash
php artisan queue:work --queue=whatsapp --sleep=1 --tries=1 --timeout=60
```

Use Supervisor/systemd in production so the worker is automatically restarted. Do not run outbound WhatsApp sends synchronously in HTTP requests.
