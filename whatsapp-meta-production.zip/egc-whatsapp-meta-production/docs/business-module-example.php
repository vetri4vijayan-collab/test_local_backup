<?php

// Example: from payment/certificate/training code, do not call Meta directly.

use App\Models\WhatsAppContact;
use App\Models\WhatsAppReminder;
use App\Models\WhatsAppTemplate;
use Illuminate\Support\Str;

$contact = WhatsAppContact::where('phone_e164', '+919XXXXXXXXX')->firstOrFail();
$template = WhatsAppTemplate::where('name', 'certificate_ready')->where('language', 'en')->firstOrFail();

WhatsAppReminder::firstOrCreate(
    ['reminder_key' => 'certificate:' . $certificateId],
    [
        'contact_id' => $contact->id,
        'template_id' => $template->id,
        'run_at' => now(),
        'status' => 'pending',
        'components' => [
            [
                'type' => 'body',
                'parameters' => [
                    ['type' => 'text', 'text' => $customerName],
                ],
            ],
            [
                'type' => 'button',
                'sub_type' => 'url',
                'index' => 0,
                'parameters' => [
                    ['type' => 'text', 'text' => $certificateToken],
                ],
            ],
        ],
        'source' => 'certificate_module',
    ]
);
