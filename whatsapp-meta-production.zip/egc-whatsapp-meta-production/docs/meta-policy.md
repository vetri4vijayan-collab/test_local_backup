# Meta policy and safety controls

At deployment time, review Meta's current WhatsApp Business Messaging Policy and the current developer documentation for the selected Graph API version.

The module enforces these application-level controls:

1. Outbound recipients must have a recorded opt-in and must not be opted out.
2. Business-initiated/resumed conversations are sent only through a locally synced Meta template whose status is `APPROVED`.
3. Free-form text/media endpoints require a stored 24-hour customer-service window.
4. Inbound `STOP`, `UNSUBSCRIBE`, `OPT OUT`, and similar keywords suppress future outbound sends.
5. Meta delivery/status events are stored and reconciled against the outbound message row.
6. Policy/quality/restriction-related webhook signals can automatically open the ERP circuit breaker.
7. Admins can manually pause and resume outbound traffic.
8. Bulk campaigns are queued and throttled rather than sending from one HTTP request.

These controls reduce operational risk but do not make the business automatically compliant with every possible Meta rule or local law. Template content, business vertical restrictions, opt-in wording, privacy notices, data handling, and campaign targeting remain business responsibilities.
