# Production Installation Checklist

## 1. Deploy

Copy the package files into the Laravel project, keeping the existing controllers/routes intact. This package is additive.

## 2. Environment

Configure:

```dotenv
META_WHATSAPP_ENABLED=true
META_WHATSAPP_GRAPH_VERSION=vXX.X
META_WHATSAPP_WABA_ID=...
META_WHATSAPP_PHONE_NUMBER_ID=...
META_WHATSAPP_ACCESS_TOKEN=...
META_WHATSAPP_VERIFY_TOKEN=...
META_WHATSAPP_APP_SECRET=...
META_WHATSAPP_DEFAULT_COUNTRY_CODE=91
META_WHATSAPP_TIMEOUT=20
META_WHATSAPP_CONNECT_TIMEOUT=5
META_WHATSAPP_THROTTLE_PER_MINUTE=60
META_WHATSAPP_DRY_RUN=false
```

Use the Graph API version currently supported by Meta at deployment time; do not copy an obsolete version from an older integration.

## 3. Database

```bash
php artisan migrate --force
php artisan whatsapp:sync-templates
```

## 4. Routes

Merge `routes/whatsapp_meta.php` into the application route loading path. Do not remove the existing `/webhook_whatsapp` route during the migration period.

## 5. CSRF

The supplied POST route explicitly excludes CSRF middleware. Keep the exact public webhook endpoint outside normal browser CSRF protection. Do not disable CSRF globally.

## 6. Meta Webhook

Callback URL:

```text
https://YOUR-ERP-HOST/meta/whatsapp/webhook
```

Verify token must equal `META_WHATSAPP_VERIFY_TOKEN`. The POST signature is checked against `META_WHATSAPP_APP_SECRET`; a missing app secret is a configuration error and the callback is rejected.

Subscribe the WABA to the message/status/account-update webhook fields available for the deployed Meta product/account.

## 7. Queue

Run a dedicated worker for WhatsApp:

```bash
php artisan queue:work --queue=whatsapp --sleep=1 --timeout=60
```

Run under Supervisor/systemd in production. Do not use `queue:listen` for the production worker.

## 8. Scheduler

Merge the supplied `routes/console.php` entries, then keep Laravel's scheduler alive:

```bash
* * * * * cd /path/to/erp && php artisan schedule:run >> /dev/null 2>&1
```

## 9. First rollout

Use this sequence:

1. Sync one approved utility template.
2. Record explicit opt-in for one real test contact.
3. Send one template.
4. Reply from the test phone and verify the 24-hour window is stored.
5. Send one service text and one media message inside the window.
6. Send a template after the window expires and confirm the guard chooses template mode.
7. Test an opt-out message such as `STOP` and verify suppression.
8. Test a failed Meta request and confirm the message is marked failed without blind duplicate retries.
9. Test a webhook status update and confirm the Meta message ID reconciles to the original row.
10. Run a small certificate-link campaign before any larger batch.

## 10. Bulk safety

Bulk sending is only for recipients already permitted to receive the selected template. The system suppresses opted-out contacts and requires the template to be synchronized and approved. Start with small campaigns and raise throughput only after healthy delivery/read rates are observed.

## 11. Existing ERP migration

Existing payment/lead code can continue to use its current sender during rollout. New modules should use `WhatsAppMessageService`. Once the new path is proven, migrate old direct Graph API calls one event at a time.

## 12. Secrets

Never commit the access token or Meta app secret. Use the production secret store/environment. Rotate the token using Meta's recommended process whenever a credential is exposed or operational policy requires it.
