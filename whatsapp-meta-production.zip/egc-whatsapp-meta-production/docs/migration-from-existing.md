# Migrating the ERP's existing WhatsApp sends

Your ERP already has direct Meta calls. The existing pattern reads `waba_id`, `access_token`, and `phone_number_id` from `egc_api_integration`, builds `https://graph.facebook.com/.../messages`, and sends from business controllers.

Do not remove those functions in the first deployment. Instead migrate event by event.

## Payment confirmation

Replace the direct HTTP call with:

```php
$wa = app(\App\Services\WhatsApp\WhatsAppMessageService::class);
$contact = $wa->upsertContact($customerData->cus_mobile, [
    'display_name' => $customerData->cus_name,
]);

// Record this only if the customer has explicitly opted in according to your existing consent record.
// $wa->recordOptIn($contact, 'payment_form_whatsapp_consent');

$template = \App\Models\WhatsAppTemplate::where('name', 'pay_confirm')
    ->where('language', 'en')
    ->firstOrFail();

$wa->queueTemplate($contact, $template, [
    [
        'type' => 'body',
        'parameters' => [
            ['type' => 'text', 'text' => $customerData->cus_name],
            ['type' => 'text', 'text' => (string) $payAmount],
            ['type' => 'text', 'text' => (string) ($payment_data['receipt_id'] ?? '')],
            ['type' => 'text', 'text' => date('d M Y', strtotime($pendingPayment->payment_date))],
            ['type' => 'text', 'text' => (string) $staffData->nick_name],
            ['type' => 'text', 'text' => (string) ($cug_details->staff_mobile ?? $branch_data->cre_mobile)],
        ],
    ],
]);
```

## Certificate links

Create one approved utility/marketing template in Meta for the exact certificate message and use a URL button parameter for the certificate token/link according to the template definition. Bulk sends must still be opt-in only.

## Free-form chat

Use `queueServiceText()` or `queueServiceMedia()` only after an inbound user message has opened the 24-hour service window. The backend rejects service sends after the stored `window_expires_at`.
