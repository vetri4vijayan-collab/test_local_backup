<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AiModel extends Model
{
    use HasFactory;

    protected $table = 'egc_ai_models';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'provider',
        'model_key',
        'active',
        'input_price_per_million',
        'output_price_per_million',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

}
