<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityBillModel extends Model
{
    use HasFactory;

    protected $table = 'egc_electricity_bills';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'account_id',
        'meter_id',
        'reading_id',

        'bill_no',
        'invoice_no',
        'invoice_date',

        'bill_month',
        'bill_year',

        'opening_reading',
        'closing_reading',
        'units_consumed',

        'energy_charge',
        'fixed_charge',
        'demand_charge',
        'fuel_adjustment_charge',
        'electricity_tax',
        'other_charge',
        'discount_amount',
        'penalty_amount',

        'net_amount',

        'bill_date',
        'due_date',

        'verification_status',
        'verified_by',
        'verified_at',

        'approval_status',
        'approved_by',
        'approved_at',

        'payment_request_status',
        'finance_request_id',

        'bill_document',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Electricity Account
    |--------------------------------------------------------------------------
    */

    public function account()
    {
        return $this->belongsTo(
            ElectricityAccountModel::class,
            'account_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Meter
    |--------------------------------------------------------------------------
    */

    public function meter()
    {
        return $this->belongsTo(
            ElectricityMeterModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Reading
    |--------------------------------------------------------------------------
    */

    public function reading()
    {
        return $this->belongsTo(
            ElectricityReadingModel::class,
            'reading_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Payment Request
    |--------------------------------------------------------------------------
    */

    public function paymentRequest()
    {
        return $this->belongsTo(
            PaymentRequestModel::class,
            'finance_request_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Active Bills
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Verified Bills
    |--------------------------------------------------------------------------
    */

    public function scopeVerified($query)
    {
        return $query->where('verification_status','Verified');
    }

    /*
    |--------------------------------------------------------------------------
    | Approved Bills
    |--------------------------------------------------------------------------
    */

    public function scopeApproved($query)
    {
        return $query->where('approval_status','Approved');
    }

    /*
    |--------------------------------------------------------------------------
    | Pending Finance
    |--------------------------------------------------------------------------
    */

    public function scopePendingFinance($query)
    {
        return $query->whereIn('payment_request_status',[
            'Not Created',
            'Created',
            'Sent'
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Paid Bills
    |--------------------------------------------------------------------------
    */

    public function scopePaid($query)
    {
        return $query->where('payment_request_status','Paid');
    }

    /*
    |--------------------------------------------------------------------------
    | Current Month
    |--------------------------------------------------------------------------
    */

    public function scopeCurrentMonth($query)
    {
        return $query->whereMonth('bill_date',date('m'))
                     ->whereYear('bill_date',date('Y'));
    }

    /*
    |--------------------------------------------------------------------------
    | Due Bills
    |--------------------------------------------------------------------------
    */

    public function scopeOverDue($query)
    {
        return $query

            ->whereDate('due_date','<',date('Y-m-d'))

            ->where('payment_request_status','!=','Paid');
    }

}