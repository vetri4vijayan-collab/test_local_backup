<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityReadingModel extends Model
{
    use HasFactory;

    protected $table = 'egc_electricity_readings';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'account_id',
        'meter_id',

        'reading_month',
        'reading_year',
        'reading_date',

        'opening_reading',
        'closing_reading',

        'units_consumed',

        'multiplier_factor',

        'total_units',

        'reading_source',

        'reading_status',

        'verified_by',
        'verified_at',

        'approved_by',
        'approved_at',

        'meter_photo',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Electricity Account
    |--------------------------------------------------------------------------
    */

    public function account()
    {
        return $this->belongsTo(
            ElectricityAccountModel::class,
            'account_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Meter
    |--------------------------------------------------------------------------
    */

    public function meter()
    {
        return $this->belongsTo(
            ElectricityMeterModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Bill
    |--------------------------------------------------------------------------
    */

    public function bill()
    {
        return $this->hasOne(
            ElectricityBillModel::class,
            'reading_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Active Scope
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Approved Scope
    |--------------------------------------------------------------------------
    */

    public function scopeApproved($query)
    {
        return $query->where('reading_status','Approved');
    }

    /*
    |--------------------------------------------------------------------------
    | Verified Scope
    |--------------------------------------------------------------------------
    */

    public function scopeVerified($query)
    {
        return $query->where('reading_status','Verified');
    }

    /*
    |--------------------------------------------------------------------------
    | Monthly Scope
    |--------------------------------------------------------------------------
    */

    public function scopeMonth($query,$month,$year)
    {
        return $query
                ->where('reading_month',$month)
                ->where('reading_year',$year);
    }

    /*
    |--------------------------------------------------------------------------
    | Total Units Attribute
    |--------------------------------------------------------------------------
    */

    public function getCalculatedUnitsAttribute()
    {
        return ($this->closing_reading - $this->opening_reading)
                * $this->multiplier_factor;
    }

}