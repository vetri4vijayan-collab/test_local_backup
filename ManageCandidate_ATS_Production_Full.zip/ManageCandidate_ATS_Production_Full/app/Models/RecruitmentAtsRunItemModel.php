<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RecruitmentAtsRunItemModel extends Model
{
    protected $table = 'egc_recruitment_ai_run_items';
    protected $primaryKey = 'sno';

    public const STATUS_PROCESSING = 'processing';
    public const STATUS_MATCHED = 'matched';
    public const STATUS_UNMATCHED = 'unmatched';
    public const STATUS_FAILED = 'failed';
    public const STATUS_SKIPPED = 'skipped';

    protected $fillable = [
        'run_sno',
        'applicant_sno',
        'status',
        'match_count',
        'best_match_score',
        'error_message',
        'started_at',
        'finished_at',
    ];

    protected $casts = [
        'sno' => 'integer',
        'run_sno' => 'integer',
        'applicant_sno' => 'integer',
        'match_count' => 'integer',
        'best_match_score' => 'float',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];
}
