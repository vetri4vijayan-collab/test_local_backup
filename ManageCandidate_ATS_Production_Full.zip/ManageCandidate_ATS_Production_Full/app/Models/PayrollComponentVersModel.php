<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollComponentVersModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payroll_components';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'component_code',
        'component_name',
        'category',
        'calculation_type',
        'percentage_of_component',
        'percentage_value',
        'formula_expression',
        'affects_pf',
        'affects_esi',
        'affects_pt',
        'affects_tds',
        'taxable',
        'lop_applicable',
        'variable_component',
        'include_in_ctc',
        'include_in_payslip',
        'display_order',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [

        'percentage_value' => 'float',

        'affects_pf' => 'boolean',
        'affects_esi' => 'boolean',
        'affects_pt' => 'boolean',
        'affects_tds' => 'boolean',

        'taxable' => 'boolean',
        'lop_applicable' => 'boolean',
        'variable_component' => 'boolean',

        'include_in_ctc' => 'boolean',
        'include_in_payslip' => 'boolean',
    ];

    // =====================================================
    // RELATIONS
    // =====================================================

    public function templateDetails()
    {
        return $this->hasMany(
            PayrollSalaryTemplateDetailModel::class,
            'component_sno',
            'sno'
        );
    }
}
