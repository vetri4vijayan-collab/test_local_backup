<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;

class TargetExportExcel implements FromArray, WithHeadings, WithEvents
{
    protected $entities = [];

    public function __construct()
    {
        /**
         * Dynamic Entity List
         */
        $this->entities = DB::table('et_entity')
            ->where('status', 0)
            ->orderBy('sno', 'asc')
            ->pluck('entity_name')
            ->toArray();
    }

    /**
     * Excel Heading Row
     */
    public function headings(): array
    {
        $fixedColumns = [
            'Target Month (YYYY-MM)',
            'Target Year',
            'Target Type',
            'Remarks',
        ];

        /**
         * First 4 dynamic entity columns
         */
        return array_merge($fixedColumns, $this->entities);
    }
     /**
     * Empty rows for user input
     */
    public function array(): array
    {
        $totalColumns = 4 + count($this->entities);

        return array_fill(
            0,
            100,
            array_fill(0, $totalColumns, '')
        );
    }

    /**
     * Excel Events
     */

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();

                /**
                 * Styling Header
                 */
                $highestColumn = $sheet->getHighestColumn();

                $sheet->getStyle("A1:{$highestColumn}1")
                    ->getFont()
                    ->setBold(true);

                /**
                 * Header Background Color
                 */
                $sheet->getStyle("A1:{$highestColumn}1")
                    ->getFill()
                    ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                    ->getStartColor()
                    ->setARGB('D9EAF7');

                /**
                 * Apply dropdown for Target Type
                 */
                for ($row = 2; $row <= 101; $row++) {

                    $validation = $sheet->getCell("C{$row}")->getDataValidation();

                    $validation->setType(DataValidation::TYPE_LIST);
                    $validation->setErrorStyle(DataValidation::STYLE_STOP);
                    $validation->setAllowBlank(true);
                    $validation->setShowInputMessage(true);
                    $validation->setShowErrorMessage(true);
                    $validation->setShowDropDown(true);
                    $validation->setFormula1('"Pre Sale,Post Sale,Collection"');
                }

                /**
                 * Freeze Header Row
                 */
                $sheet->freezePane('A2');

                /**
                 * Auto Width All Columns
                 */
                foreach (range('A', $highestColumn) as $column) {
                    $sheet->getColumnDimension($column)->setAutoSize(true);
                }

                /**
                 * Alignment
                 */
                $sheet->getStyle("A1:{$highestColumn}101")
                    ->getAlignment()
                    ->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);

                /**
                 * Number format for entity target columns
                 */
                $entityStartColumnIndex = 5;

                for ($i = 0; $i < count($this->entities); $i++) {

                    $columnLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($entityStartColumnIndex + $i);

                    $sheet->getStyle("{$columnLetter}2:{$columnLetter}101")
                        ->getNumberFormat()
                        ->setFormatCode('#,##0');
                }
            }
        ];
    }
}