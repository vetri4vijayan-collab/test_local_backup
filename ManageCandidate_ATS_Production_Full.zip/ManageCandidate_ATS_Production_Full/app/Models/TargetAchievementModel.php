<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TargetAchievementModel extends Model
{
    use HasFactory;
    public $table = 'egc_target_achievements';
    public $primaryKey = 'id';

    protected $fillable = [
        'entity_id',
        'branch_id',
        'year',
        'quarter',
        'month',
        'week',
        'achieved_amount',
        'pre_sale',
        'post_sale',
        'source',
        'reference_id',
        'achieved_date',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function quarters()
    {
        return $this->hasMany(QuarterTargetModel::class, 'yearly_id');
    }
}
