<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RegionModel extends Model {
    use HasFactory;
    public $table      = 'egc_region';
    public $primaryKey = 'sno';

    protected $fillable = [
        'region_name',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}