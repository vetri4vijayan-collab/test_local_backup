<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantAtsRoleAnalysisModel extends Model
{
    protected $table = 'egc_applicant_ats_role_analyses';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'applicant_sno',
        'run_sno',
        'schema_version',
        'engine',
        'model',
        'source_type',
        'source_label',
        'role_catalog_hash',
        'resume_sha256',
        'resume_chars',
        'overall_match_score',
        'best_role_score',
        'resume_quality_score',
        'match_count',
        'analysis_json',
        'processed_at',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'sno' => 'integer',
        'applicant_sno' => 'integer',
        'run_sno' => 'integer',
        'resume_chars' => 'integer',
        'overall_match_score' => 'float',
        'best_role_score' => 'float',
        'resume_quality_score' => 'float',
        'match_count' => 'integer',
        'analysis_json' => 'array',
        'processed_at' => 'datetime',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];
}
