<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffPayrollProfileModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_payroll_profile';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'pay_cycle',
        'tax_regime',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

}
