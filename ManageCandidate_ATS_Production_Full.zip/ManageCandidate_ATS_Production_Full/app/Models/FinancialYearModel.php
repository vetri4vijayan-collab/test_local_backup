<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FinancialYearModel extends Model
{
    use HasFactory;
    public $table      = 'egc_financial_year';
    public $primaryKey = 'sno';

    protected $fillable = [
        'financial_year_id	', //Finn-78987
        'financial_year_name', // quarter 1 quarter 2 , quarter 3, quarter 4
        'financial_month', //["4","5","6"] , ["7","8","9"] , ["10","11","12"] , ["1","2","3"]
        'financial_year_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
