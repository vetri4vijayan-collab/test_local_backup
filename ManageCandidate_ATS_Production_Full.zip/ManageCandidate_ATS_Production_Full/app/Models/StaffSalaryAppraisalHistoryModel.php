<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffSalaryAppraisalHistoryModel  extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_salary_appraisal_history';

    protected $primaryKey = 'sno';

    public $incrementing = true;

    protected $keyType = 'int';

    public $timestamps = true;

    protected $fillable = [

        'employee_sno',

        'salary_account_id',

        'payroll_template_sno',

        'effective_from',

        'gross_salary',

        'appraisal_type',

        'appraisal_unit',

        'appraisal_value',
        'variable_from',
        'variable_end_month',

        'appraisal_reason',

        'variable_component',

        'variable_amount',

        'variable_months',

        'processed',

        'processed_at',

        'processed_by',

        'status',

        'created_by',

        'updated_by',

    ];

    protected $casts = [

        'effective_from'   => 'date',

        'gross_salary'     => 'decimal:2',

        'appraisal_value'  => 'decimal:2',

        'variable_amount'  => 'decimal:2',

        'processed'        => 'boolean',

        'processed_at'     => 'datetime',

        'variable_months'  => 'integer',

        'status'           => 'integer',

        'appraisal_type'   => 'integer',
    ];

    /*
    |--------------------------------------------------------------------------
    | STATUS
    |--------------------------------------------------------------------------
    */

    const STATUS_ACTIVE  = 0;
    const STATUS_DELETED = 1;

    /*
    |--------------------------------------------------------------------------
    | PROCESS
    |--------------------------------------------------------------------------
    */

    const NOT_PROCESSED = 0;
    const PROCESSED     = 1;

    /*
    |--------------------------------------------------------------------------
    | APPRAISAL TYPES
    |--------------------------------------------------------------------------
    */

    const JOINING           = 0;
    const YEARLY            = 1;
    const SPECIAL           = 2;
    const PROJECT           = 3;
    const TEN_X_WARRIOR     = 5;

    /*
    |--------------------------------------------------------------------------
    | RELATIONSHIPS
    |--------------------------------------------------------------------------
    */

    public function employee()
    {
        return $this->belongsTo(
            StaffModel::class,
            'employee_sno',
            'sno'
        );
    }

    public function salaryAccount()
    {
        return $this->belongsTo(
            StaffSalaryAccountModel::class,
            'salary_account_id',
            'sno'
        );
    }

    public function payrollTemplate()
    {
        return $this->belongsTo(
            PayrollSalaryTemplateModel::class,
            'payroll_template_sno',
            'sno'
        );
    }

    public function variableComponent()
    {
        return $this->belongsTo(
            PayrollComponentModel::class,
            'variable_component',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SCOPES
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    public function scopeProcessed($query)
    {
        return $query->where('processed', self::PROCESSED);
    }

    public function scopePending($query)
    {
        return $query->where('processed', self::NOT_PROCESSED);
    }

    public function scopeEmployee($query, $employee)
    {
        return $query->where('employee_sno', $employee);
    }

    /*
    |--------------------------------------------------------------------------
    | ACCESSORS
    |--------------------------------------------------------------------------
    */

    public function getAppraisalTypeNameAttribute()
    {
        switch ($this->appraisal_type) {

            case self::JOINING:
                return 'Joining';

            case self::YEARLY:
                return 'Yearly Appraisal';

            case self::SPECIAL:
                return 'Special Appraisal';

            case self::PROJECT:
                return 'Project';

            case self::TEN_X_WARRIOR:
                return '10X Warrior';

            default:
                return 'Unknown';
        }
    }

    public function getUnitTextAttribute()
    {
        return $this->appraisal_unit ?: '-';
    }

    public function getVariableEnabledAttribute()
    {
        return $this->variable_amount > 0;
    }
}
