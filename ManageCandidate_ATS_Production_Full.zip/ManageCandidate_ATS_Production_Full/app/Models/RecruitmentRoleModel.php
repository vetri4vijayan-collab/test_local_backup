<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class RecruitmentRoleModel extends Model
{
    protected $table = 'egc_recruitment_roles';
    protected $primaryKey = 'sno';

    public $incrementing = true;
    protected $keyType = 'int';

    public const STATUS_ACTIVE = 0;
    public const STATUS_INACTIVE = 1;
    public const STATUS_DELETED = 2;

    public const SENIORITY_ENTRY = 1;
    public const SENIORITY_SENIOR = 2;
    public const SENIORITY_TEAM_LEAD = 3;
    public const SENIORITY_MANAGER = 4;
    public const SENIORITY_HEAD = 5;

    protected $fillable = [
        'role_code',
        'role_name',
        'role_family',
        'seniority_level',
        'description',
        'created_by',
        'updated_by',
        'status',
        'match_enabled',
    ];

    protected $casts = [
        'sno' => 'integer',
        'seniority_level' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
        'status' => 'integer',
        'match_enabled' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function scopeNotDeleted(Builder $query): Builder
    {
        return $query->where('status', '!=', self::STATUS_DELETED);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    public function isDeleted(): bool
    {
        return $this->status === self::STATUS_DELETED;
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            self::STATUS_ACTIVE => 'Active',
            self::STATUS_INACTIVE => 'Inactive',
            self::STATUS_DELETED => 'Deleted',
            default => 'Unknown',
        };
    }

    public function getSeniorityLabelAttribute(): string
    {
        return match ($this->seniority_level) {
            self::SENIORITY_ENTRY => 'Entry',
            self::SENIORITY_SENIOR => 'Senior',
            self::SENIORITY_TEAM_LEAD => 'Team Lead',
            self::SENIORITY_MANAGER => 'Manager',
            self::SENIORITY_HEAD => 'Head',
            default => 'Entry',
        };
    }
}
