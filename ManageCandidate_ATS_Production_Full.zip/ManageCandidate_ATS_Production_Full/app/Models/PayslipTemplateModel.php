<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayslipTemplateModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payslip_template';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'comapany_id',
        'payslip_template',
        'status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

}
