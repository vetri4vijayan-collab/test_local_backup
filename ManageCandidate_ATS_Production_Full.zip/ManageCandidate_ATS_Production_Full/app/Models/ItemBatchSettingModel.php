<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemBatchSettingModel extends Model
{
  use HasFactory;

  protected $table = 'egc_item_batch_settings';
  protected $primaryKey = 'sno';
  public $timestamps = true;
 

  protected $fillable = [
    'item_id',
    'batch_prefix',
    'expiry_required',
    'manufacture_date_required',
    'serial_tracking',
    'fifo_enabled',
    'batch_auto_generate',
    'default_bin',
    'allow_negative_stock',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
   
  ];
   


}