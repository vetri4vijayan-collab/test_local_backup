<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasscodeCategoryModel extends Model
{
    protected $table = 'egc_passcode_categories';

    protected $primaryKey = 'sno';

    public $incrementing = true;

    protected $keyType = 'int';

    public $timestamps = true;

    protected $fillable = [
        'category_code',
        'category_name',
        'icon',
        'display_order',
        'created_by',
        'updated_by',
        'status',
    ];
}