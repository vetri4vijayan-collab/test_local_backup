<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollStaffStructureModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payroll_employee_structures';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'employee_sno',
        'payroll_template_sno',
        'salary_account_id',
        'structure_code',
        'structure_name',
        'gross_salary',
        'per_day_salary',
        'per_hour_cost',
        'total_earnings',
        'total_deductions',
        'net_salary',
        'employer_contribution',
        'ctc_amount',
        'revision_no',
        'revision_reason',
        'effective_from',
        'effective_to',
        'is_current',
        'payroll_lock',
        'remarks',
        'status',
        'created_by',
        'updated_by',
    ];
}
