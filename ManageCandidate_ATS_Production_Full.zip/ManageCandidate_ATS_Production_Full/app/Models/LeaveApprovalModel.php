<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveApprovalModel extends Model
{
    use HasFactory;

    protected $table = 'egc_approval_tasks';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'request_id',
        'level_no',
        'approver_staff_id',
        'action_date',
        'approve_level',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];

     public function model()
    {
        return $this->belongsTo(AiModel::class, 'ai_model_id');
    }

}
