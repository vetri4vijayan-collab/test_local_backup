<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityAccountModel extends Model
{
    use HasFactory;

    protected $table = 'egc_electricity_accounts';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'account_code',

        'building_id',
        'entity_id',
        'branch_id',
        'location_id',

        'provider_id',
        'tariff_category_id',

        'account_name',
        'service_no',
        'consumer_no',

        'connection_type_id',
        'supply_type_id',
        'phase_type_id',
        'voltage_level_id',
        'meter_type_id',
        'billing_cycle_id',

        'sanction_load',
        'sanction_load_unit_id',

        'contract_demand',
        'contract_demand_unit_id',

        'status',

        'created_by',
        'updated_by',

        'created_at',
        'updated_at',

    ];

    /*
    |--------------------------------------------------------------------------
    | Entity
    |--------------------------------------------------------------------------
    */

    public function entity()
    {
        return $this->belongsTo(EntityModel::class,'entity_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Branch
    |--------------------------------------------------------------------------
    */

    public function branch()
    {
        return $this->belongsTo(BranchModel::class,'branch_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Location
    |--------------------------------------------------------------------------
    */

    public function location()
    {
        return $this->belongsTo(LocationModel::class,'location_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Building
    |--------------------------------------------------------------------------
    */

    public function building()
    {
        return $this->belongsTo(BuildingModel::class,'building_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Utility Provider
    |--------------------------------------------------------------------------
    */

    public function provider()
    {
        return $this->belongsTo(UtilityProviderModel::class,'provider_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Meters
    |--------------------------------------------------------------------------
    */

    public function meters()
    {
        return $this->hasMany(ElectricityMeterModel::class,'account_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Readings
    |--------------------------------------------------------------------------
    */

    public function readings()
    {
        return $this->hasMany(ElectricityReadingModel::class,'account_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Bills
    |--------------------------------------------------------------------------
    */

    public function bills()
    {
        return $this->hasMany(ElectricityBillModel::class,'account_id','sno');
    }

    /*
    |--------------------------------------------------------------------------
    | Complaints
    |--------------------------------------------------------------------------
    */

    public function complaints()
    {
        return $this->hasMany(ElectricityComplaintModel::class,'account_id','sno');
    }

}