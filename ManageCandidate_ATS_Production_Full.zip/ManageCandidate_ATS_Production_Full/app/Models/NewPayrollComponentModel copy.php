<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NewPayrollComponentModel extends Model
{
    use HasFactory;
    public $table      = "egc_payroll_components";
    public $primaryKey = 'sno';


    protected $fillable = [
        'component_name',
        'component_code',
        'type',
        'calculation_type',
        'rule_type',
        'priority',
        'default_value',
        'formula',
        'rule_id',
        'is_mandatory',
        'is_statutory',
        'show_in_payslip',
        'pf_applicable',
        'esi_applicable',
        'pt_applicable',
        'tds_applicable',
        'display_order',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}
