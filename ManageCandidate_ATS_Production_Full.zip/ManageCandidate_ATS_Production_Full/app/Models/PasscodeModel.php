<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasscodeModel extends Model
{
    protected $table = 'egc_passcodes';

    protected $primaryKey = 'sno';

    public $incrementing = true;

    protected $keyType = 'int';

    public $timestamps = true;

    protected $fillable = [
        'category_sno',
        'account_name',
        'login_url',
        'login_identifier',
        'login_password',
        'secondary_identifier',
        'access_pin',
        'company_sno',
        'entity_sno',
        'notes',
        'password_changed_at',
        'last_revealed_at',
        'last_revealed_by',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'password_changed_at' => 'datetime',
        'last_revealed_at'    => 'datetime',
        'created_at'          => 'datetime',
        'updated_at'          => 'datetime',
    ];

    protected $hidden = [
        'login_identifier',
        'login_password',
        'secondary_identifier',
        'access_pin',
    ];

    public function category()
    {
        return $this->belongsTo(
            PasscodeCategoryModel::class,
            'category_sno',
            'sno'
        );
    }
}