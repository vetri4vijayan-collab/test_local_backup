<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CorporateDocumentModel extends Model
{
    use HasFactory;

    protected $table = 'egc_corporate_documents';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'module_name',
        'reference_id',

        'entity_id',
        'branch_id',
        'location_id',
        'building_id',

        'document_category',

        'document_name',
        'document_number',

        'document_date',
        'expiry_date',

        'version_no',

        'document_path',
        'file_name',
        'file_extension',
        'file_size',

        'approval_status',

        'approved_by',
        'approved_at',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Entity
    |--------------------------------------------------------------------------
    */

    public function entity()
    {
        return $this->belongsTo(
            EntityModel::class,
            'entity_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Branch
    |--------------------------------------------------------------------------
    */

    public function branch()
    {
        return $this->belongsTo(
            BranchModel::class,
            'branch_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Location
    |--------------------------------------------------------------------------
    */

    public function location()
    {
        return $this->belongsTo(
            LocationModel::class,
            'location_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Building
    |--------------------------------------------------------------------------
    */

    public function building()
    {
        return $this->belongsTo(
            BuildingModel::class,
            'building_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Active Documents
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Approved Documents
    |--------------------------------------------------------------------------
    */

    public function scopeApproved($query)
    {
        return $query->where('approval_status','Approved');
    }

    /*
    |--------------------------------------------------------------------------
    | Expired Documents
    |--------------------------------------------------------------------------
    */

    public function scopeExpired($query)
    {
        return $query->whereNotNull('expiry_date')
                     ->whereDate('expiry_date','<',date('Y-m-d'));
    }

    /*
    |--------------------------------------------------------------------------
    | Expiring Documents
    |--------------------------------------------------------------------------
    */

    public function scopeExpiring($query,$days=30)
    {
        return $query
            ->whereNotNull('expiry_date')
            ->whereBetween(
                'expiry_date',
                [
                    date('Y-m-d'),
                    date('Y-m-d',strtotime("+{$days} days"))
                ]
            );
    }

    /*
    |--------------------------------------------------------------------------
    | Module Filter
    |--------------------------------------------------------------------------
    */

    public function scopeModule($query,$module)
    {
        return $query->where('module_name',$module);
    }

    /*
    |--------------------------------------------------------------------------
    | Reference Filter
    |--------------------------------------------------------------------------
    */

    public function scopeReference($query,$referenceId)
    {
        return $query->where('reference_id',$referenceId);
    }

    /*
    |--------------------------------------------------------------------------
    | Building Documents
    |--------------------------------------------------------------------------
    */

    public function scopeBuilding($query)
    {
        return $query->where('module_name','Building');
    }

    /*
    |--------------------------------------------------------------------------
    | Electricity Documents
    |--------------------------------------------------------------------------
    */

    public function scopeElectricity($query)
    {
        return $query->whereIn('module_name',[
            'Electricity Account',
            'Electricity Bill'
        ]);
    }

}