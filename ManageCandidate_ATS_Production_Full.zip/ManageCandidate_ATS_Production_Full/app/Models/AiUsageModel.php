<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AiUsageModel extends Model
{
    use HasFactory;

    protected $table = 'egc_ai_usages';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'ai_model_id',
        'prompt_tokens',
        'completion_tokens',
        'total_tokens',
        'input_cost',
        'output_cost',
        'total_cost',
        'usage_date',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

     public function model()
    {
        return $this->belongsTo(AiModel::class, 'ai_model_id');
    }

}
