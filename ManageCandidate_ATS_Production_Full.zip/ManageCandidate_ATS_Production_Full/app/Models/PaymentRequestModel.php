<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaymentRequestModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payment_requests';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'module_name',
        'reference_id',

        'entity_id',
        'branch_id',
        'location_id',
        'building_id',

        'vendor_id',

        'vendor_invoice_no',

        'request_no',
        'request_date',

        'request_title',

        'description',

        'request_amount',
        'tax_amount',
        'discount_amount',
        'net_amount',

        'due_date',

        'priority',

        'approval_status',

        'approved_by',
        'approved_at',

        'finance_status',

        'finance_reference_id',

        'attachment',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Entity
    |--------------------------------------------------------------------------
    */

    public function entity()
    {
        return $this->belongsTo(
            EntityModel::class,
            'entity_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Branch
    |--------------------------------------------------------------------------
    */

    public function branch()
    {
        return $this->belongsTo(
            BranchModel::class,
            'branch_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Building
    |--------------------------------------------------------------------------
    */

    public function building()
    {
        return $this->belongsTo(
            BuildingModel::class,
            'building_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Vendor
    |--------------------------------------------------------------------------
    */

    public function vendor()
    {
        return $this->belongsTo(
            VendorModel::class,
            'vendor_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Active Requests
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Pending Approval
    |--------------------------------------------------------------------------
    */

    public function scopePendingApproval($query)
    {
        return $query->where('approval_status','Pending');
    }

    /*
    |--------------------------------------------------------------------------
    | Approved Requests
    |--------------------------------------------------------------------------
    */

    public function scopeApproved($query)
    {
        return $query->where('approval_status','Approved');
    }

    /*
    |--------------------------------------------------------------------------
    | Pending Finance
    |--------------------------------------------------------------------------
    */

    public function scopePendingFinance($query)
    {
        return $query->where('finance_status','Pending');
    }

    /*
    |--------------------------------------------------------------------------
    | Processing
    |--------------------------------------------------------------------------
    */

    public function scopeProcessing($query)
    {
        return $query->where('finance_status','Processing');
    }

    /*
    |--------------------------------------------------------------------------
    | Paid
    |--------------------------------------------------------------------------
    */

    public function scopePaid($query)
    {
        return $query->where('finance_status','Paid');
    }

    /*
    |--------------------------------------------------------------------------
    | Rejected
    |--------------------------------------------------------------------------
    */

    public function scopeRejected($query)
    {
        return $query->where(function($q){

            $q->where('approval_status','Rejected')
              ->orWhere('finance_status','Rejected');

        });
    }

    /*
    |--------------------------------------------------------------------------
    | Electricity
    |--------------------------------------------------------------------------
    */

    public function electricityBill()
    {
        return $this->belongsTo(
            ElectricityBillModel::class,
            'reference_id',
            'sno'
        )
        ->where('module_name','Electricity');
    }

}