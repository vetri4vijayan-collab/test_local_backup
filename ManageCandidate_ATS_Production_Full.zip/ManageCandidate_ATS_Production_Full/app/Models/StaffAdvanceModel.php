<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffAdvanceModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_advance_amount_log';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'month',
        'year',
        'entity_id',
        'job_role_id',
        'role_id',
        'staff_id',
        'total_amount',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

}
