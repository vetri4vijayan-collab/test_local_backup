<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MetricsModel extends Model
{
    use HasFactory;
    public $table      = "egc_metrics";
    public $primaryKey = 'sno';


    protected $fillable = [
        'metrics_name',
        'metrics_score',
        'metrics_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}