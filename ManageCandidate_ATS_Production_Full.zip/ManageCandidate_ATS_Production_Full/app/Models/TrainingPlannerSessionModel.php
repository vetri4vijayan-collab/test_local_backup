<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingPlannerSessionModel extends Model
{
    protected $table = 'egc_training_planner_sessions';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'training_planner_id',
        'session_no',
        'session_date',
        'start_time',
        'end_time',
        'session_title',
        'syllabus_details',
        'syllabus_completed',
        'syllabus_completed_at',
        'trainer_notes',
        'session_status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'session_date' => 'date',
        'syllabus_completed' => 'boolean',
        'syllabus_completed_at' => 'datetime',
    ];

    public function training()
    {
        return $this->belongsTo(TrainingPlannerModel::class, 'training_planner_id', 'sno');
    }

    public function attendance()
    {
        return $this->hasMany(TrainingPlannerSessionAttendanceModel::class, 'training_session_id', 'sno');
    }
}
