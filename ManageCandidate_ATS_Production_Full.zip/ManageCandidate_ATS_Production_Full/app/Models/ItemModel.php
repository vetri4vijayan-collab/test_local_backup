<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemModel extends Model
{
  use HasFactory;

  protected $table = 'egc_items';
  protected $primaryKey = 'sno';
  public $timestamps = true;
 

  protected $fillable = [
    'item_code',
    'item_name',
    'item_short_name',
    'category_id',
    'subcategory_id',
    'brand_id',
    'item_type_id',
    'unit_id',
    'preferred_vendor_id',
    'standard_cost',
    'selling_price',
    'opening_stock',
    'opening_stock_value',
    'has_expiry',
    'has_batch',
    'has_serial_no',
    'gst_percentage',
    'hsn_code',
    'default_bin',
    'item_image',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
   
  ];
   


}