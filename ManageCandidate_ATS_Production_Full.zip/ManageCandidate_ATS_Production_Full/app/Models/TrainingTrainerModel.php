<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingTrainerModel extends Model
{
    use HasFactory;

    protected $table = 'egc_training_trainers';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'staff_id',
        'specialization',
        'expertise',
        'notes',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'staff_id' => 'integer',
        'status' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    public function staff()
    {
        return $this->belongsTo(StaffModel::class, 'staff_id', 'sno');
    }
}
