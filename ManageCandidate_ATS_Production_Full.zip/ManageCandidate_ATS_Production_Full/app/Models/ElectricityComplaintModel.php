<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricityComplaintModel extends Model
{
    use HasFactory;

    protected $table = 'egc_electricity_complaints';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'entity_id',
        'branch_id',
        'location_id',
        'building_id',

        'account_id',
        'meter_id',
        'bill_id',

        'complaint_no',

        'complaint_category',

        'complaint_title',

        'complaint_description',

        'priority',

        'assigned_to',

        'vendor_id',

        'complaint_date',

        'expected_completion',

        'completed_date',

        'complaint_status',

        'resolution',

        'resolution_cost',

        'attachment',

        'remarks',

        'created_by',
        'created_at',

        'updated_by',
        'updated_at',

        'status'

    ];

    /*
    |--------------------------------------------------------------------------
    | Entity
    |--------------------------------------------------------------------------
    */

    public function entity()
    {
        return $this->belongsTo(
            EntityModel::class,
            'entity_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Branch
    |--------------------------------------------------------------------------
    */

    public function branch()
    {
        return $this->belongsTo(
            BranchModel::class,
            'branch_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Location
    |--------------------------------------------------------------------------
    */

    public function location()
    {
        return $this->belongsTo(
            LocationModel::class,
            'location_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Building
    |--------------------------------------------------------------------------
    */

    public function building()
    {
        return $this->belongsTo(
            BuildingModel::class,
            'building_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Electricity Account
    |--------------------------------------------------------------------------
    */

    public function account()
    {
        return $this->belongsTo(
            ElectricityAccountModel::class,
            'account_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Meter
    |--------------------------------------------------------------------------
    */

    public function meter()
    {
        return $this->belongsTo(
            ElectricityMeterModel::class,
            'meter_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Bill
    |--------------------------------------------------------------------------
    */

    public function bill()
    {
        return $this->belongsTo(
            ElectricityBillModel::class,
            'bill_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Vendor
    |--------------------------------------------------------------------------
    */

    public function vendor()
    {
        return $this->belongsTo(
            VendorModel::class,
            'vendor_id',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Assigned Staff
    |--------------------------------------------------------------------------
    */

    public function assignedStaff()
    {
        return $this->belongsTo(
            StaffModel::class,
            'assigned_to',
            'sno'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Active Complaints
    |--------------------------------------------------------------------------
    */

    public function scopeActive($query)
    {
        return $query->where('status',0);
    }

    /*
    |--------------------------------------------------------------------------
    | Open Complaints
    |--------------------------------------------------------------------------
    */

    public function scopeOpen($query)
    {
        return $query->where('complaint_status','Open');
    }

    /*
    |--------------------------------------------------------------------------
    | Assigned Complaints
    |--------------------------------------------------------------------------
    */

    public function scopeAssigned($query)
    {
        return $query->where('complaint_status','Assigned');
    }

    /*
    |--------------------------------------------------------------------------
    | In Progress
    |--------------------------------------------------------------------------
    */

    public function scopeInProgress($query)
    {
        return $query->where('complaint_status','In Progress');
    }

    /*
    |--------------------------------------------------------------------------
    | Resolved
    |--------------------------------------------------------------------------
    */

    public function scopeResolved($query)
    {
        return $query->where('complaint_status','Resolved');
    }

    /*
    |--------------------------------------------------------------------------
    | Closed
    |--------------------------------------------------------------------------
    */

    public function scopeClosed($query)
    {
        return $query->where('complaint_status','Closed');
    }

    /*
    |--------------------------------------------------------------------------
    | High Priority
    |--------------------------------------------------------------------------
    */

    public function scopeHighPriority($query)
    {
        return $query->whereIn('priority',[
            'High',
            'Critical'
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Pending Complaints
    |--------------------------------------------------------------------------
    */

    public function scopePending($query)
    {
        return $query->whereNotIn('complaint_status',[
            'Resolved',
            'Closed',
            'Cancelled'
        ]);
    }

}