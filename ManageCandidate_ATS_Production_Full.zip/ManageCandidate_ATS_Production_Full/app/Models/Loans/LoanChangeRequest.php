<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanChangeRequest extends Model
{
    protected $table = 'egc_loan_change_requests';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','change_type','status','requested_by','approved_by','effective_date',
        'payload_json','remarks','approved_at','rejected_at',
    ];

    protected $casts = [
        'effective_date'=>'date','payload_json'=>'array','approved_at'=>'datetime','rejected_at'=>'datetime',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
}