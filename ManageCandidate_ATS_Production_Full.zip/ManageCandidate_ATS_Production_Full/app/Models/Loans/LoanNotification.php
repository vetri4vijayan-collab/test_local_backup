<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanNotification extends Model
{
    protected $table = 'egc_loan_notifications';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = [
        'obligation_id','rule_id','channel','recipient','scheduled_for','sent_at',
        'status','provider_message_id','error_message',
    ];

    protected $casts = ['scheduled_for'=>'datetime','sent_at'=>'datetime'];

    public function obligation() { return $this->belongsTo(LoanObligation::class, 'obligation_id', 'id'); }
}