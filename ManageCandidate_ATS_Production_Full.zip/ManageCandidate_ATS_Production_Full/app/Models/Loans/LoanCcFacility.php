<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanCcFacility extends Model
{
    protected $table = 'egc_loan_cc_facilities';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','sanctioned_limit','margin_percent','drawing_power',
        'interest_rate','renewal_date','stock_statement_day','status',
    ];

    protected $casts = [
        'sanctioned_limit'=>'decimal:2','margin_percent'=>'decimal:4','drawing_power'=>'decimal:2',
        'interest_rate'=>'decimal:4','renewal_date'=>'date','stock_statement_day'=>'integer',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function utilisations() { return $this->hasMany(LoanCcUtilisation::class, 'facility_id', 'id')->latest('as_of_date'); }
}