<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanType extends Model
{
    protected $table = 'egc_loan_types';
    protected $primaryKey = 'id';

    protected $fillable = [
        'type_code','type_name','icon','description','display_order','status',
        'created_by','updated_by',
    ];

    protected $casts = [
        'display_order' => 'integer',
        'status' => 'integer',
    ];
}