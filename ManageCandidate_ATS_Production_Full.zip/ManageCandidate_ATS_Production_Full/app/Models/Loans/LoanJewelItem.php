<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanJewelItem extends Model
{
    protected $table = 'egc_loan_jewel_items';
    protected $primaryKey = 'id';

    protected $fillable = [
        'pledge_id','item_no','description','gross_weight','net_weight','purity','release_status',
    ];

    protected $casts = [
        'item_no'=>'integer','gross_weight'=>'decimal:3','net_weight'=>'decimal:3',
    ];

    public function pledge() { return $this->belongsTo(LoanJewelPledge::class, 'pledge_id', 'id'); }
}