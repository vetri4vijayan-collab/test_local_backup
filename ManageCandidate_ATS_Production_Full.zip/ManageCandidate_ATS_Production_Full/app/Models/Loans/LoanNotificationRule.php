<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanNotificationRule extends Model
{
    protected $table = 'egc_loan_notification_rules';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','obligation_type','lead_day','channel','escalation_day','status',
        'created_by','updated_by',
    ];

    protected $casts = ['lead_day'=>'integer','escalation_day'=>'integer','status'=>'integer'];
}