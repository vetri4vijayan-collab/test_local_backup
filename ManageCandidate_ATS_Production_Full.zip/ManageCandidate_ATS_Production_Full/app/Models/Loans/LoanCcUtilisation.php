<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanCcUtilisation extends Model
{
    protected $table = 'egc_loan_cc_utilisations';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = [
        'facility_id','as_of_date','utilised_amount','interest_debit','drawing_power',
        'remarks','created_by',
    ];

    protected $casts = [
        'as_of_date'=>'date','utilised_amount'=>'decimal:2','interest_debit'=>'decimal:2','drawing_power'=>'decimal:2',
    ];

    public function facility() { return $this->belongsTo(LoanCcFacility::class, 'facility_id', 'id'); }
}