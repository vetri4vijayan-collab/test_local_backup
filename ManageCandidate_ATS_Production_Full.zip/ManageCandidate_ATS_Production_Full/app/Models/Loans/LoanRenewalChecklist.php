<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanRenewalChecklist extends Model
{
    protected $table = 'egc_loan_renewal_checklists';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','checklist_type','renewal_date','status','submitted_at','renewed_at',
        'created_by','updated_by',
    ];

    protected $casts = ['renewal_date'=>'date','submitted_at'=>'datetime','renewed_at'=>'datetime'];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function items() { return $this->hasMany(LoanRenewalChecklistItem::class, 'checklist_id', 'id'); }
}