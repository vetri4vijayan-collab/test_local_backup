<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanLender extends Model
{
    protected $table = 'egc_loan_lenders';
    protected $primaryKey = 'id';

    protected $fillable = [
        'lender_name','lender_type','branch_name','contact_person','phone','email',
        'address','status','created_by','updated_by',
    ];

    protected $casts = ['status' => 'integer'];

    public function loans()
    {
        return $this->hasMany(Loan::class, 'lender_id', 'id');
    }
}