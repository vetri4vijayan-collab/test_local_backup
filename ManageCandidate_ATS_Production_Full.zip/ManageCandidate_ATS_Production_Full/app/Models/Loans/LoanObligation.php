<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanObligation extends Model
{
    protected $table = 'egc_loan_obligations';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','schedule_line_id','obligation_type','title','due_date',
        'amount','paid_amount','balance_amount','status','action_label',
        'metadata_json','snoozed_until','completed_at','created_by','updated_by',
    ];

    protected $casts = [
        'schedule_line_id'=>'integer','due_date'=>'date','amount'=>'decimal:2',
        'paid_amount'=>'decimal:2','balance_amount'=>'decimal:2',
        'metadata_json'=>'array','snoozed_until'=>'datetime','completed_at'=>'datetime',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function scheduleLine() { return $this->belongsTo(LoanScheduleLine::class, 'schedule_line_id', 'id'); }
    public function payments() { return $this->hasMany(LoanPayment::class, 'obligation_id', 'id'); }
}