<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanDocument extends Model
{
    protected $table = 'egc_loan_documents';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = [
        'loan_id','document_name','document_type','storage_disk','storage_path',
        'mime_type','size_bytes','uploaded_by',
    ];

    protected $casts = ['size_bytes'=>'integer'];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
}