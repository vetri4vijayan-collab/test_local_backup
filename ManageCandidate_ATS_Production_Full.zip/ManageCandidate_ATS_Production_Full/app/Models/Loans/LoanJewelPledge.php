<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanJewelPledge extends Model
{
    protected $table = 'egc_loan_jewel_pledges';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','pledge_receipt_no','interest_pattern','redemption_due_date',
        'status','released_at',
    ];

    protected $casts = [
        'redemption_due_date'=>'date',
        'released_at'=>'datetime',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function items() { return $this->hasMany(LoanJewelItem::class, 'pledge_id', 'id'); }
}