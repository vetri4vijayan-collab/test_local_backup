<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MajorModel extends Model
{
    use HasFactory;
    public $table      = "egc_major";
    public $primaryKey = 'sno';


    protected $fillable = [
        'qualification_id',
        'major_name',
        'description',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}