<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollComponentNewModel extends Model
{
    use HasFactory;
    public $table      = "egc_payroll_components";
    public $primaryKey = 'id';


    protected $fillable = [
        'component_code',
        'component_name',
        'category',
        'component_type',
        'affects_pf',
        'affects_esi',
        'affects_pt',
        'affects_tds',
        'prorate_on_lop',
        'taxable',
        'display_order',
        'effective_from',
        'effective_to',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}
