<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentCheckListModel extends Model
{
    use HasFactory;
    public $table      = "egc_document_checklist";
    public $primaryKey = 'sno';


    protected $fillable = [
        'document_checklist',
        'checklist_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}