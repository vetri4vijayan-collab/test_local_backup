<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemPurchaseSettingModel extends Model
{
  use HasFactory;

  protected $table = 'egc_item_purchase_settings';
  protected $primaryKey = 'sno';
  public $timestamps = true;
 

  protected $fillable = [
    'item_id',
    'preferred_vendor_id',
    'lead_time_days',
    'minimum_order_quantity',
    'purchase_unit_price',
    'last_purchase_price',
    'currency',
    'is_preferred_vendor',
    'allow_negative_stock',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
   
  ];
   


}