<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffTenXModel extends Model
{
    use HasFactory;
    public $table = 'egc_staff_tenx_log';
    public $primaryKey = 'id';

    protected $fillable = [
        'entity_id',
        'branch_id',
        'year',
        'role_id',
        'month',
        'staff_id',
        'achieved_amount',
        'achieved_date',
        'description',
        'reference_id',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function quarters()
    {
        return $this->hasMany(QuarterTargetModel::class, 'yearly_id');
    }
}
