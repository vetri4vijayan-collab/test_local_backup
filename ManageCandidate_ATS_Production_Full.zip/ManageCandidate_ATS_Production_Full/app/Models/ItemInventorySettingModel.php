<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ItemInventorySettingModel extends Model
{
  use HasFactory;

  protected $table = 'egc_item_inventory_settings';
  protected $primaryKey = 'sno';
  public $timestamps = true;
 

  protected $fillable = [
    'item_id',
    'warehouse_id',
    'minimum_stock',
    'maximum_stock',
    'reorder_level',
    'reorder_quantity',
    'safety_stock',
    'default_bin',
    'allow_negative_stock',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
   
  ];
   


}