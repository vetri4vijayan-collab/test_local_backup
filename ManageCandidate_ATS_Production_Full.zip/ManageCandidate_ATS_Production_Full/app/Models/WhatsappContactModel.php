<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappContactModel extends Model
{
    use HasFactory;
    
    public $table = "egc_wb_contacts";
    public $primaryKey = "sno";
    
    protected $fillable = ['phone','msg_count','created_by','updated_by','status'];
    
    public function messages()
    {
        return $this->hasMany(WhatsappMessageModel::class, 'contact_id', 'sno');
    }
}
