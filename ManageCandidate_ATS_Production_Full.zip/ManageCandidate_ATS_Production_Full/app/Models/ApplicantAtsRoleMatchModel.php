<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantAtsRoleMatchModel extends Model
{
    protected $table = 'egc_applicant_ats_role_matches';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'analysis_sno',
        'applicant_sno',
        'role_sno',
        'role_code',
        'role_name',
        'role_family',
        'seniority_level',
        'match_score',
        'decision',
        'title_alignment_score',
        'skill_alignment_score',
        'experience_alignment_score',
        'responsibility_alignment_score',
        'seniority_alignment_score',
        'evidence_quality_score',
        'reason',
        'evidence_json',
        'gaps_json',
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'sno' => 'integer',
        'analysis_sno' => 'integer',
        'applicant_sno' => 'integer',
        'role_sno' => 'integer',
        'seniority_level' => 'integer',
        'match_score' => 'float',
        'title_alignment_score' => 'float',
        'skill_alignment_score' => 'float',
        'experience_alignment_score' => 'float',
        'responsibility_alignment_score' => 'float',
        'seniority_alignment_score' => 'float',
        'evidence_quality_score' => 'float',
        'evidence_json' => 'array',
        'gaps_json' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
