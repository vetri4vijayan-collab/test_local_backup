<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffTransferLogModel extends Model
{
    use HasFactory;
    public $table = 'egc_staff_transfer_logs';
    public $primaryKey = 'sno';

    protected $fillable = [
        'staff_id',
        'new_role_id',
        'old_role_id',
        'old_company_type',
        'old_company_id',
        'old_entity_id',
        'old_branch_id',
        'old_department_id',
        'old_division_id',
        'old_job_role_id',
        'new_company_type',
        'new_company_id',
        'new_entity_id',
        'new_branch_id',
        'new_department_id',
        'new_division_id',
        'new_job_role_id',
        'transfer_date',
        'transfer_reason_id',
        'transfer_reason_comment',
        'transferred_by',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

   
}
