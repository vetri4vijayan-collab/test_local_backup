<?php

namespace App\Http\Controllers\myself;

use App\Http\Controllers\Controller;
use App\Models\PasscodeModel;
use App\Models\PasscodeCategoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Services\FavIcon\FaviconService;

class PasscodeController extends Controller
{
    /* PAGE */
    public function index()
    {
        $categories = PasscodeCategoryModel::where('status', 0)
            ->orderBy('display_order')
            ->orderBy('category_name')
            ->get();

        return view(
            'content.my_self.manage_passcode.manage_passcode',
            compact('categories')
        );
    }


    /* AJAX LIST  */
    public function list(Request $request ,FaviconService $faviconService)
    {
        $page = max((int) $request->input('page', 1), 1);

        $perPage = min( max((int) $request->input('per_page', 10), 5),50);
        $search = trim($request->input('search', ''));
        $category = $request->input('category');
        $status = $request->input('status', 'all');

        $query = PasscodeModel::query()
                ->with(['category:sno,category_name,icon']);

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('account_name','LIKE', '%' . $search . '%');
                $q->orWhere('login_url','LIKE','%' . $search . '%');
                $q->orWhereHas(
                    'category',
                    function ($categoryQuery) use ($search) {
                        $categoryQuery->where('category_name','LIKE','%' . $search . '%');
                    }
                );
            });
        }
        if (!empty($category)) {
            $query->where('category_sno', $category);
        }
        if ($status !== 'all') {
            $query->where('status',(int) $status);
        }

        $query->orderByDesc('sno');

        $records = $query->paginate($perPage,['*'], 'page', $page);

        
        $data = $records->getCollection()
            ->map(function ($row) use($faviconService) {
                    $url = trim($row->login_url ?? '');

                    $favicon = null;

                    if ($url !== '') {
                        $favicon = $faviconService->getFavicon($url);
                    }

                return [
                    'sno' => $row->sno,
                    'account_name' => e($row->account_name),
                    'category_name' => $row->category->category_name ?? 'Other',
                    'category_icon' => $row->category->icon ?? 'mdi-key-outline',
                    'login_url' => $row->login_url,
                    'favicon' => $favicon,
                    'status' => $row->status,
                    'created_at' =>optional($row->created_at)->format('d M Y, h:i A'),
                    'updated_at' => optional($row->updated_at)->format('d M Y, h:i A'),
                ];
            })
            ->values();

        return response()->json([
            'status' => true,

            'data' => $data,

            'pagination' => [
                'current_page' =>
                    $records->currentPage(),

                'last_page' =>
                    $records->lastPage(),

                'per_page' =>
                    $records->perPage(),

                'total' =>
                    $records->total(),

                'from' =>
                    $records->firstItem(),

                'to' =>
                    $records->lastItem(),
            ],
        ]);
    }


    /* =====================================================
       CREATE
    ===================================================== */

    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'category_sno' => [
                    'required',
                    'integer',
                    'exists:egc_passcode_categories,sno'
                ],

                'account_name' => [
                    'required',
                    'string',
                    'max:250'
                ],

                'login_url' => [
                    'nullable',
                    'url',
                    'max:1000'
                ],

                'login_identifier' => [
                    'nullable',
                    'string',
                    'max:1000'
                ],

                'login_password' => [
                    'nullable',
                    'string',
                    'max:2000'
                ],

                // 'secondary_identifier' => [
                //     'nullable',
                //     'string',
                //     'max:1000'
                // ],

                // 'access_pin' => [
                //     'nullable',
                //     'string',
                //     'max:500'
                // ],

                'company_sno' => [
                    'nullable',
                    'integer'
                ],

                'entity_sno' => [
                    'nullable',
                    'integer'
                ],

                'notes' => [
                    'nullable',
                    'string',
                    'max:5000'
                ],

                // 'status' => [
                //     'required',
                //     'in:0,1'
                // ],
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }

        DB::beginTransaction();

        try {

            $now = now();

            $passcode = new PasscodeModel();

            $passcode->category_sno =
                $request->category_sno;

            $passcode->account_name =
                trim($request->account_name);

            $passcode->login_url =
                $request->login_url
                    ? trim($request->login_url)
                    : null;

            /*
             * ENCRYPT SENSITIVE VALUES
             */
            $passcode->login_identifier =
                $this->encryptValue(
                    $request->login_identifier
                );

            $passcode->login_password =
                $this->encryptValue(
                    $request->login_password
                );

            $passcode->secondary_identifier =
                $this->encryptValue(
                    $request->secondary_identifier
                );

            $passcode->access_pin =
                $this->encryptValue(
                    $request->access_pin
                );

            $passcode->company_sno =
                $request->company_sno ?: null;

            $passcode->entity_sno =
                $request->entity_sno ?: null;

            $passcode->notes =
                $request->notes
                    ? trim($request->notes)
                    : null;

            $passcode->status =
                (int) $request->status;

            $passcode->created_by =
                $request->user()->user_id;

            $passcode->updated_by =
                $request->user()->user_id;

            if ($request->filled('login_password')) {
                $passcode->password_changed_at =
                    $now;
            }

            $passcode->save();

            $this->logActivity(
                $passcode->sno,
                'CREATE',
                'Credential created.',$request
            );

            DB::commit();

            return response()->json([
                'status' => true,
                'message' =>
                    'Credential added successfully.',
            ]);

        } catch (\Throwable $e) {

            DB::rollBack();

            report($e);

            return response()->json([
                'status' => false,
                'message' =>
                    'Unable to save credential.',
            ], 500);
        }
    }


    /* =====================================================
       EDIT DATA
    ===================================================== */

    public function edit($id)
    {
        $passcode = PasscodeModel::find($id);

        if (!$passcode) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Credential not found.',
            ], 404);
        }

        return response()->json([
            'status' => true,

            'data' => [
                'sno' =>
                    $passcode->sno,

                'category_sno' =>
                    $passcode->category_sno,

                'account_name' =>
                    $passcode->account_name,

                'login_url' =>
                    $passcode->login_url,

                /*
                 * Decrypt ONLY for authorized edit request.
                 */
                'login_identifier' =>
                    $this->decryptValue(
                        $passcode->login_identifier
                    ),

                'secondary_identifier' =>
                    $this->decryptValue(
                        $passcode->secondary_identifier
                    ),

                'status' =>
                    $passcode->status,

                'company_sno' =>
                    $passcode->company_sno,

                'entity_sno' =>
                    $passcode->entity_sno,

                'notes' =>
                    $passcode->notes,
            ],
        ]);
    }


    /* =====================================================
       UPDATE
    ===================================================== */

    public function update(
        Request $request,
        $id
    ) {

        $passcode = PasscodeModel::find($id);

        if (!$passcode) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Credential not found.',
            ], 404);
        }

        $validator = Validator::make(
            $request->all(),
            [
                'category_sno' => [
                    'required',
                    'integer',
                    'exists:egc_passcode_categories,sno'
                ],

                'account_name' => [
                    'required',
                    'string',
                    'max:250'
                ],

                'login_url' => [
                    'nullable',
                    'url',
                    'max:1000'
                ],

                'login_identifier' => [
                    'nullable',
                    'string',
                    'max:1000'
                ],

                'login_password' => [
                    'nullable',
                    'string',
                    'max:2000'
                ],

                'secondary_identifier' => [
                    'nullable',
                    'string',
                    'max:1000'
                ],

                'access_pin' => [
                    'nullable',
                    'string',
                    'max:500'
                ],

                'notes' => [
                    'nullable',
                    'string',
                    'max:5000'
                ],

                'status' => [
                    'required',
                    'in:0,1'
                ],
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Please correct the highlighted fields.',
                'errors' =>
                    $validator->errors(),
            ], 422);
        }

        DB::beginTransaction();

        try {

            $passcode->category_sno =
                $request->category_sno;

            $passcode->account_name =
                trim($request->account_name);

            $passcode->login_url =
                $request->login_url
                    ? trim($request->login_url)
                    : null;

            $passcode->login_identifier =
                $this->encryptValue(
                    $request->login_identifier
                );

            /*
             * Password is optional during edit.
             *
             * Empty password means:
             * KEEP EXISTING PASSWORD.
             */
            if ($request->filled('login_password')) {

                $passcode->login_password =
                    $this->encryptValue(
                        $request->login_password
                    );

                $passcode->password_changed_at =
                    now();
            }

            $passcode->secondary_identifier =
                $this->encryptValue(
                    $request->secondary_identifier
                );

            $passcode->access_pin =
                $this->encryptValue(
                    $request->access_pin
                );

            $passcode->company_sno =
                $request->company_sno ?: null;

            $passcode->entity_sno =
                $request->entity_sno ?: null;

            $passcode->notes =
                $request->notes
                    ? trim($request->notes)
                    : null;

            $passcode->status =
                (int) $request->status;

            $passcode->updated_by =
                $request->user()->user_id;

            $passcode->save();

            $this->logActivity(
                $passcode->sno,
                'UPDATE',
                'Credential updated.',$request
            );

            DB::commit();

            return response()->json([
                'status' => true,
                'message' =>
                    'Credential updated successfully.',
            ]);

        } catch (\Throwable $e) {

            DB::rollBack();

            report($e);

            return response()->json([
                'status' => false,
                'message' =>
                    'Unable to update credential.',
            ], 500);
        }
    }


    /* =====================================================
       REVEAL
    ===================================================== */

    public function reveal(
        Request $request,
        $id
    ) {

        $passcode = PasscodeModel::find($id);

        if (!$passcode) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Credential not found.',
            ], 404);
        }

        $type = $request->input('type');

        if (!in_array(
            $type,
            [
                'username',
                'password',
                'secondary',
                'pin'
            ],
            true
        )) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Invalid credential type.',
            ], 422);
        }

        $column = match ($type) {
            'username' =>
                'login_identifier',

            'password' =>
                'login_password',

            'secondary' =>
                'secondary_identifier',

            'pin' =>
                'access_pin',
        };

        $value =
            $this->decryptValue(
                $passcode->{$column}
            );

        if ($type === 'password') {

            $passcode->last_revealed_at =
                now();

            $passcode->last_revealed_by =
                $request->user()->user_id;

            $passcode->save();
        }

        $this->logActivity(
            $passcode->sno,
            'REVEAL_' . strtoupper($type),
            'Credential value revealed.',$request
        );

        return response()->json([
            'status' => true,
            'value' => $value,
        ]);
    }


    /* =====================================================
       STATUS
    ===================================================== */

    public function status(
        Request $request,
        $id
    ) {

        $passcode = PasscodeModel::find($id);

        if (!$passcode) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Credential not found.',
            ], 404);
        }

        $newStatus =
            $passcode->status == 0 ? 1 : 0;

        $passcode->status =
            $newStatus;

        $passcode->updated_by =
            $request->user()->user_id;

        $passcode->save();

        $this->logActivity(
            $passcode->sno,
            'STATUS',
            $newStatus === 0
                ? 'Credential activated.'
                : 'Credential deactivated.',$request
        );

        return response()->json([
            'status' => true,

            'value' =>
                $newStatus,

            'message' =>
                $newStatus === 0
                    ? 'Credential activated.'
                    : 'Credential deactivated.',
        ]);
    }


    /* =====================================================
       DELETE
    ===================================================== */

    public function destroy($id , Request $request)
    {
        $passcode = PasscodeModel::find($id);

        if (!$passcode) {
            return response()->json([
                'status' => false,
                'message' =>
                    'Credential not found.',
            ], 404);
        }

        /*
         * Keep activity history.
         * Archive instead of physical delete.
         */
        $passcode->status = 2;

        $passcode->updated_by =
            $request->user()->user_id;

        $passcode->save();

        $this->logActivity(
            $passcode->sno,
            'DELETE',
            'Credential archived.',
            $request
        );

        return response()->json([
            'status' => true,
            'message' =>
                'Credential archived successfully.',
        ]);
    }


    /* =====================================================
       ENCRYPTION
    ===================================================== */

    private function encryptValue($value)
    {
        if ($value === null || $value === '') {
            return null;
        }

        return Crypt::encryptString($value);
    }


    private function decryptValue($value)
    {
        if (!$value) {
            return null;
        }

        try {

            return Crypt::decryptString($value);

        } catch (\Throwable $e) {

            report($e);

            return null;
        }
    }


    /* =====================================================
       ACTIVITY LOG
    ===================================================== */

    private function logActivity(
        $passcodeSno,
        $action,
        $description,$request
    ) {

        DB::table(
            'egc_passcode_activity_logs'
        )->insert([
            'passcode_sno' =>
                $passcodeSno,

            'action' =>
                $action,

            'description' =>
                $description,

            'ip_address' =>
                request()->ip(),

            'user_agent' =>
                substr(
                    request()->userAgent() ?? '',
                    0,
                    1000
                ),

            'performed_by' =>
                $request->user()->user_id,

            'created_at' =>
                now(),
        ]);
    }
}