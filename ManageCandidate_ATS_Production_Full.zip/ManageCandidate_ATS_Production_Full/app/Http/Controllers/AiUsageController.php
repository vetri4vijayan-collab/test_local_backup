<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerModel;
use App\Models\SubLedgerModel;
use App\Models\TransactionModel;
use App\Models\ProposalPayHistoryModel;
use Illuminate\Support\Facades\Http;
use App\Models\BranchModel;
use App\Models\StaffModel;
use App\Models\ProductModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use App\Models\AiUsageModel;
use App\Models\AiModel;
use App\Models\AiChatModel;
use App\Services\HuggingFace\HuggingFaceClient;
use App\Services\HuggingFace\UsageTracker;
use App\Services\HuggingFace\CostCalculator;
use PDF;

class AiUsageController extends Controller
{
    protected HuggingFaceClient $client;
    protected UsageTracker $usageTracker;
    protected CostCalculator $calculateCost;

    public function __construct(
        HuggingFaceClient $client,
        UsageTracker $usageTracker,
        CostCalculator $calculateCost,
    ) {
        $this->client = $client;
        $this->usageTracker = $usageTracker;
        $this->calculateCost = $calculateCost;
    }
    public function index()
    {
        $helper = new \App\Helpers\Helpers();
        $monthlySpend = $helper->currentMonthSpend();
        $limit = config('ai-models.monthly_limit');

        $usages = AiUsageModel::with('model')
            ->orderByDesc('created_at')
            ->paginate(20);

        return view('content.admin.ai_model.ai-usage', compact(
            'usages',
            'monthlySpend',
            'limit'
        ));
    }

    public function aichat(Request $request)
    {
        $helper = new \App\Helpers\Helpers();


        return view('content.admin.ai_model.chat');
    }

    public function chat(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:5000',
            'model'   => 'nullable|string',
        ]);
        $user_id = $request->user()->user_id ?? 1;

        $staffData = StaffModel::where('egc_staff.status', '!=', 2)
            ->select(
                'egc_staff.*',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',
            )
            ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
            ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
            ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
            ->where('egc_staff.sno', $user_id)->first();

        $model = $request->input('model', 'google/gemma-4-26B-A4B-it:novita');

        try {
            $history = AiChatModel::where('user_id', $user_id)
                ->where('status', 0)
                ->latest()
                ->limit(6)
                ->get()
                ->reverse();
            $messages = [];
            $messages[] = [
                'role' => 'system',
                'content' => "You are an ERP Assistant. You are currently helping {$staffData->staff_name}, who works as a {$staffData->job_role_name}. " .
                    "The current date is " . now()->toDateString() . "."
            ];
            foreach ($history as $chat) {
                $messages[] = ['role' => 'user', 'content' => $chat->user_message];
                $messages[] = ['role' => 'assistant', 'content' => $chat->ai_reply];
            }
            $messages[] = ['role' => 'user', 'content' => $request->message];

            // return $messages;

            $response = $this->client->chat($model, $messages);
            // return $response;

            //  $response = $this->client->chat($model, [
            //     ['role' => 'user', 'content' => $request->message]
            // ]);
            // return $response;
            if (!isset($response['usage'])) {
                return response()->json([
                    'error' => 'Invalid response from AI provider'
                ], 502);
            }

            // Track usage (billing)




            $this->usageTracker->track($model, $response['usage']);

            $aiModel = AiModel::where('model_key', $model)->first();
            $costs =   $this->calculateCost->calculate($aiModel, $response['usage']['prompt_tokens'], $response['usage']['completion_tokens']);
            AiChatModel::create([
                'user_id' => $user_id,
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'ai_model_id' => $aiModel->sno,
                'user_message' => trim($request->message),
                'ai_reply' => $response['choices'][0]['message']['content'] ?? '',
                'prompt_tokens' => $response['usage']['prompt_tokens'],
                'completion_tokens' => $response['usage']['completion_tokens'],
                'total_cost' => $costs['total_cost'], // optional, change if you want cost
            ]);

            //  Return AI message only
            return response()->json([
                'reply' => $response['choices'][0]['message']['content'] ?? '',
                'usage' => $response['usage'],
                'cached' => $response['usage']['prompt_tokens_details']['cached_tokens'] ?? 0
            ]);
        } catch (\Throwable $e) {

            Log::error('HF chat failed', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'error' => 'AI service unavailable' . $e
            ], 500);
        }
    }

    public function ChatHistoryold(Request $request)
    {
        $user_id = $request->user()->user_id ?? 0;
        $chats = AiChatModel::where('user_id', $user_id)
            ->with('model', 'user')
            ->get();
        // return $chats ;
        return view(
            'content.admin.ai_model.chat-history',
            [
                "chats" => $chats,
            ]
        );
    }

    public function ChatHistory(Request $request)
    {
        $limit = 20;
        $user_id = $request->user()->user_id ?? 0;
        $lastId = $request->get('last_id'); // for cursor pagination

        $query = AiChatModel::where('user_id', $user_id)
            ->where('status', 0)
            ->orderByDesc('sno');

        if ($lastId) {
            $query->where('sno', '<', $lastId);
        }

        $chats = $query->limit($limit)->get();

        return response()->json([
            'data' => $chats,
            'has_more' => $chats->count() === $limit,
        ]);
    }

    public function clearChatHistory($user_id, Request $request)
    {
        try {

            AiChatModel::where('user_id', $user_id)->update([
                "status" => 2,
            ]);


            //  Return message 
            return response()->json(['message' => 'All Chat cleared']);
        } catch (\Throwable $e) {
            return response()->json([
                'error' => 'chat Clear failed' . $e
            ], 500);
        }
    }
}
