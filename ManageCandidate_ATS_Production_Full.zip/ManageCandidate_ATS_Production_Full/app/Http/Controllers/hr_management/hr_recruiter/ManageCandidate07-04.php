<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\SourceModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use thiagoalessio\TesseractOCR\TesseractOCR;
use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser;
use Smalot\PdfParser\Parser as PdfParser;

class ManageCandidate extends Controller
{
  public function index(Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $major_filt = $request->major_filt ?? '';
      $qualification_filt = $request->qualification_filt ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $source_type_filt = $request->source_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $old_resume_fill = $request->old_resume_fill ?? '';
      $jobRequest = ApplicantModel::
       where('egc_applicant.status','!=',2)
      ->leftJoin('egc_job_request', 'egc_applicant.job_request_id', 'egc_job_request.sno')
      ->leftJoin('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_source', 'egc_applicant.source_id', 'egc_source.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_major', 'egc_applicant.major', 'egc_major.sno')
      ->leftJoin('egc_job_fair', 'egc_applicant.job_fair_id', 'egc_job_fair.sno')
      ->distinct('egc_applicant.sno')
      ->select(
        'egc_applicant.*',
      'egc_job_request.status as job_request_status',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_major.major_name',
      'egc_job_fair.job_fair_name',
      'egc_source.source_name as applicant_source_name',
      'egc_company.company_base_color',);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.applicant_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.mobile', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.old_data', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.email', 'LIKE', "%{$search_filter}%");
          });
      }

        if ($source_type_filt !=='') {
          if($source_type_filt =='resource'){
            $jobRequest->where('egc_applicant.job_request_id', '>',0);
          }elseif($source_type_filt =='old_data'){
             $jobRequest->where('egc_applicant.recruitment_id','>',0);
          }elseif($source_type_filt =='job_fair'){
            $jobRequest->where('egc_applicant.job_fair_id','>',0);
          }
        }
       
        
        if (!empty($exp_type_filt)) {
          $jobRequest->where(function ($query) use ($exp_type_filt) {
              $query->where(function ($q) use ($exp_type_filt) {
                  $q->where('egc_applicant.recruitment_id', 0)
                    ->where('egc_applicant.experience_id', $exp_type_filt);
              });
              $query->orWhere(function ($q) use ($exp_type_filt) {
                  $q->where('egc_applicant.recruitment_id', '>', 0);

                  if ($exp_type_filt == 1) {
                      // Fresher
                      $q->where('egc_applicant.experience_id', 2);
                  } elseif ($exp_type_filt == 2) {
                      // Experience
                      $q->where('egc_applicant.experience_id', '>=', 3);
                  }
              });

          });
        }
        if (!empty($qualification_filt)) {

          $jobRequest->where(function ($query) use ($qualification_filt) {
              
              $query->where(function ($q) use ($qualification_filt) {
                  $q->where('egc_applicant.recruitment_id', 0)
                    ->where('egc_applicant.qualification_id', $qualification_filt);
              });

             
              $query->orWhere(function ($q) use ($qualification_filt) {

                  $q->where('egc_applicant.recruitment_id', '>', 0);

                  if ($qualification_filt == 1) {
                      // UG → old_data qualification_id = 5
                      $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 5");
                  }

                  elseif ($qualification_filt == 2) {
                      // PG → 3,4
                      $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (3,4)");
                  }

                  elseif ($qualification_filt == 3) {
                      // Doctorate → 2
                      $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') = 2");
                  }

                  elseif ($qualification_filt == 'Others' || $qualification_filt == '4' || $qualification_filt == '5' || $qualification_filt == '6') {
                      // Others → 6,7
                      $q->whereRaw("JSON_EXTRACT(egc_applicant.old_data, '$.qualification_id') IN (6,7)");
                  }

              });

          });
        }

        if ($major_filt) {
            $jobRequest->where('egc_applicant.major', $major_filt);
        }

        if ($old_resume_fill !=='') {
          $jobRequest->where('egc_applicant.recruitment_id','>',0)->where('egc_applicant.recruitment_file', $old_resume_fill);
        }

        if ($date_filter == "today") {
          $todayDate = date("Y-m-d");
          $jobRequest->whereDate('egc_applicant.created_at', $todayDate);
        } elseif ($date_filter == "week") {
          $today = date('l');
          if ($today == "Sunday") {
            $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
          } else {
            $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
          }
          $jobRequest->whereBetween('egc_applicant.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
          $firstDayOfMonth = date('Y-m-01');
          $lastDayOfMonth = date('Y-m-t');
          $jobRequest->whereBetween('egc_applicant.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
          if ($from_date_filter && $to_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $jobRequest->whereBetween('egc_applicant.created_at', [$fromDate, $toDate]);
          } elseif ($from_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $jobRequest->where('egc_applicant.created_at', '>=', $fromDate);
          } elseif ($to_date_filter) {
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $jobRequest->where('egc_applicant.created_at', '<=', $toDate);
          }
        }else{
          if ($closing_date_filt) {
            $jobRequest->whereDate('egc_applicant.created_at',date('Y-m-d', strtotime($closing_date_filt)));
          }
        }

        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
           
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'data' => $item,
                  'old_data' => $item->old_data,
                  'drive_data' => $item->drive_data,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
      $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.hr_management.hr_recruiter.manage_candidate.candidate_list', [
          'jobRequest' => $jobRequest,
          'source_list' => $source_list,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
   
  }


  // public function extractCandidateData(Request $request)
  // {
  //     $request->validate([
  //         'upload_resume' => 'required|mimes:pdf,doc,docx|max:5120',
  //     ]);

  //     $file = $request->file('upload_resume');
  //     $ext = strtolower($file->getClientOriginalExtension());
  //     $text = '';

  //     // ---- Step 1: Extract text ----
  //     if ($ext === 'pdf') {
  //         $ocr = new TesseractOCR($file->getRealPath());
  //         $text = $ocr->run();
  //     } elseif (in_array($ext, ['doc', 'docx'])) {
  //         $phpWord = IOFactory::load($file->getRealPath());
  //         foreach ($phpWord->getSections() as $section) {
  //             $elements = $section->getElements();
  //             foreach ($elements as $element) {
  //                 if (method_exists($element, 'getText')) {
  //                     $text .= $element->getText() . " ";
  //                 }
  //             }
  //         }
  //     }

  //     $text = preg_replace('/\s+/', ' ', $text); // Clean text

  //     // ---- Step 2: Tokenize ----
  //     $tokenizer = new WhitespaceTokenizer();
  //     $tokens = $tokenizer->tokenize($text);

  //     $freq = new FreqDist($tokens);

  //     // ---- Step 3: Extract candidate info ----
  //     preg_match("/[A-Z][a-z]+ [A-Z][a-z]+/", $text, $name);
  //     preg_match("/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i", $text, $email);
  //     preg_match("/\+?\d{10,12}/", $text, $phone);

  //     // Optional: guess gender by simple keywords
  //     $gender = null;
  //     if (stripos($text, 'female') !== false) $gender = 2;
  //     elseif (stripos($text, 'male') !== false) $gender = 1;

  //     // Optional: extract experience in years
  //     preg_match("/(\d+)\s*(years|yrs|yr)/i", $text, $experience);

  //     // Optional: extract qualification keywords
  //     $qualification = null;
  //     if (stripos($text, 'doctorate') !== false) $qualification = 'Doctorate';
  //     elseif (stripos($text, 'postgraduate') !== false || stripos($text, 'pg') !== false) $qualification = 'PG';
  //     elseif (stripos($text, 'undergraduate') !== false || stripos($text, 'ug') !== false) $qualification = 'UG';

  //     return response()->json([
  //         'status' => 200,
  //         'data' => [
  //             'candidate_name' => $name[0] ?? '',
  //             'candidate_email' => $email[0] ?? '',
  //             'candidate_mobile' => $phone[0] ?? '',
  //             'candidate_gender' => $gender,
  //             'candidate_exper_count' => $experience[1] ?? '',
  //             'candidate_qualification' => $qualification,
  //             'tokens' => $tokens,
  //         ],
  //     ]);
  // }


  // public function extractCandidateData(Request $request)
  // {
  //     // Validate resume file
  //     $request->validate([
  //         'upload_resume' => 'required|mimes:pdf,doc,docx|max:5120',
  //     ]);

  //     $file = $request->file('upload_resume');
  //     $ext = strtolower($file->getClientOriginalExtension());
  //     $text = '';

  //     // ---- Step 1: Extract text from resume ----
  //     if ($ext === 'pdf') {
  //         $ocr = new TesseractOCR($file->getRealPath());
  //         $text = $ocr->run();
  //     } elseif (in_array($ext, ['doc', 'docx'])) {
  //         $phpWord = IOFactory::load($file->getRealPath());
  //         foreach ($phpWord->getSections() as $section) {
  //             $elements = $section->getElements();
  //             foreach ($elements as $element) {
  //                 if (method_exists($element, 'getText')) {
  //                     $text .= $element->getText() . " ";
  //                 }
  //             }
  //         }
  //     }

  //     $text = preg_replace('/\s+/', ' ', $text); // Clean up text

  //     // ---- Step 2: Tokenize the text ----
  //     $tokenizer = new WhitespaceTokenizer();
  //     $tokens = $tokenizer->tokenize($text);
  //     $freq = new FreqDist($tokens);

  //     // ---- Step 3: Extract candidate info ----
  //     preg_match("/[A-Z][a-z]+ [A-Z][a-z]+/", $text, $name);
  //     preg_match("/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i", $text, $email);
  //     preg_match("/\+?\d{10,12}/", $text, $phone);

  //     // Optional: Extract gender
  //     $gender = null;
  //     if (stripos($text, 'female') !== false) $gender = 2;
  //     elseif (stripos($text, 'male') !== false) $gender = 1;
  //     else $gender = 3; // Default to 'Others' if not found

  //     // Extract experience
  //     preg_match("/(\d+)\s*(years|yrs|yr)/i", $text, $experience);
  //     $experienceCount = isset($experience[1]) ? $experience[1] : 0;

  //     // ---- Step 4: Extract Qualification ----
  //     $qualification = null;
  //     if (stripos($text, 'doctorate') !== false) $qualification = 'Doctorate';
  //     elseif (stripos($text, 'postgraduate') !== false || stripos($text, 'pg') !== false) $qualification = 'PG';
  //     elseif (stripos($text, 'undergraduate') !== false || stripos($text, 'ug') !== false) $qualification = 'UG';

  //     // ---- Step 5: Extract marital status ----
  //     $maritalStatus = null;
  //     if (stripos($text, 'married') !== false) $maritalStatus = 1;
  //     elseif (stripos($text, 'single') !== false) $maritalStatus = 2;

  //     // ---- Step 6: Map qualification to database ----
  //     $qualificationLevelId = $this->mapQualificationToId($qualification);

  //     return response()->json([
  //         'status' => 200,
  //         'data' => [
  //             'candidate_name' => $name[0] ?? '',
  //             'candidate_email' => $email[0] ?? '',
  //             'candidate_mobile' => $phone[0] ?? '',
  //             'candidate_gender' => $gender,
  //             'candidate_exper_count' => $experienceCount,
  //             'candidate_qualification' => $qualificationLevelId,
  //             'candidate_marital_status' => $maritalStatus,
  //             'tokens' => $tokens,
  //         ],
  //     ]);
  // }
  // private function mapQualificationToId($qualification)
  // {
  //     $qualMap = [
  //         'UG' => 1,
  //         'PG' => 2,
  //         'Doctorate' => 3,
  //         'Others' => 4
  //     ];

  //     return $qualMap[$qualification] ?? 4; // Default to 'Others' if not found
  // }


  //   private function parseWithAI($text)
  // {
  //     try {
  //         $response = Http::timeout(60)
  //             ->withHeaders([
  //                 'Authorization' => 'Bearer YOUR_HF_API_KEY',
  //                 'Content-Type' => 'application/json'
  //             ])
  //             ->post('https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2', [
  //                 "inputs" => "
  //             Extract structured JSON from resume:

  //             {
  //             name:,
  //             email:,
  //             phone:,
  //             gender:,
  //             qualification:,
  //             degree:,
  //             experience_years:,
  //             marital_status:
  //             }

  //             Resume:
  //             $text
  //             "
  //             ]);

  //         if ($response->failed()) {
  //             return null;
  //         }

  //         return $response->json();

  //     } catch (\Exception $e) {
  //         \Log::error('AI Error: '.$e->getMessage());
  //         return null;
  //     }
  // }


  // private function mapAIResponse($aiResponse)
  // {
  //     if (!$aiResponse || !isset($aiResponse[0]['generated_text'])) {
  //         return [];
  //     }

  //     $generated = $aiResponse[0]['generated_text'];

  //     // Extract JSON from response
  //     preg_match('/\{.*\}/s', $generated, $matches);

  //     if (!isset($matches[0])) {
  //         return [];
  //     }

  //     $json = json_decode($matches[0], true);

  //     return [
  //         'candidate_name' => $json['name'] ?? null,
  //         'candidate_email' => $json['email'] ?? null,
  //         'candidate_mobile' => $json['phone'] ?? null,
  //         'candidate_gender' => $this->mapGender($json['gender'] ?? ''),
  //         'candidate_exper_count' => $json['experience_years'] ?? 0,
  //         'candidate_marital_status' => $this->mapMarital($json['marital_status'] ?? ''),
  //     ];
  // }


  // private function mapGender($gender)
  // {
  //     $gender = strtolower($gender);

  //     if (str_contains($gender, 'male')) return 1;
  //     if (str_contains($gender, 'female')) return 2;

  //     return 3;
  // }


  // private function mapMarital($status)
  // {
  //     $status = strtolower($status);

  //     if (str_contains($status, 'married')) return 1;
  //     if (str_contains($status, 'single')) return 2;

  //     return null;
  // }


// public function extractCandidateData(Request $request)
// {
//     $request->validate([
//         'upload_resume' => 'required|mimes:pdf,doc,docx|max:5120',
//     ]);

//     try {
//         $file = $request->file('upload_resume');
//         $text = $this->extractText($file);

//         // 🔥 STEP 1: AI
//         $aiResponse = $this->parseWithAI($text);
//         $aiData = $this->mapAIResponse($aiResponse);

//         // 🔥 STEP 2: FALLBACK
//         $fallbackData = $this->fallbackParser($text);

//         // 🔥 STEP 3: MERGE (AI priority)
//         $finalData = $this->mergeData($aiData, $fallbackData);

//         // 🔥 STEP 4: DB MATCH
//         $qualification = $this->detectQualification($text);

//         $finalData['candidate_qualification'] = $qualification['qualification_level'] ?? null;
//         $finalData['candidate_major'] = $qualification['major_sno'] ?? null;

//         return response()->json([
//             'status' => 200,
//             'data' => $finalData
//         ]);

//     } catch (\Exception $e) {
//         \Log::error($e);

//         return response()->json([
//             'status' => 500,
//             'message' => 'Resume parsing failed'.$e->getMessage()
//         ]);
//     }
// }


private function parseWithAI($text)
{


    try {
        $primaryApiKey = $this->HuggingFaceCretential(); 
        $prompt = "
                Extract ONLY valid JSON. No explanation.

                STRICT RULES:
                  1. Always return valid JSON only.
                  2. If gender is missing, you MUST infer gender from the candidate name.
                  3. Do NOT leave gender empty unless impossible to guess.
                  4. Output only: male, female, or empty string.

                {
                \"name\": \"\",
                \"email\": \"\",
                \"phone\": \"\",
                \"gender\": \"\",
                \"qualification\": \"\",
                \"degree\": \"\",
                \"experience_years\": \"\",
                \"marital_status\": \"\"
                }

                Resume:
                " . substr($text, 0, 4000); // limit tokens

        $response = Http::timeout(45)
            ->withHeaders([
                'Authorization' => 'Bearer ' . $primaryApiKey,
                'Content-Type' => 'application/json'
            ])
            ->post('https://router.huggingface.co/v1/chat/completions', [
                'model' => "meta-llama/Llama-3.1-8B-Instruct:novita", 
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'stream' =>  false
            ]);


        if ($response->failed()) {
            return null;
        }

        return $response->json();

    } catch (\Exception $e) {
        \Log::error('AI Error: '.$e->getMessage());
        return null;
    }
}
private function mapAIResponse($aiResponse)
{
    $default = [
        'candidate_name' => null,
        'candidate_email' => null,
        'candidate_mobile' => null,
        'candidate_gender' => null,
        'candidate_exper_count' => null,
        'candidate_marital_status' => null,
    ];

    if (!$aiResponse || !isset($aiResponse['choices'][0]['message']['content'])) {
        return $default;
    }

    // 🔥 Get content
    $generated = $aiResponse['choices'][0]['message']['content'];

    // 🔥 Clean it
    $generated = trim($generated);
    $generated = str_replace(["\r", "\n"], '', $generated);

    // 🔥 Decode directly (NO REGEX)
    $json = json_decode($generated, true);

    if (!$json) {
        \Log::error('AI JSON decode failed: ' . $generated);
        return $default;
    }

    return [
        'candidate_name' => $json['name'] ?? null,
        'candidate_email' => $json['email'] ?? null,
        'candidate_mobile' => $json['phone'] ?? null,
        'candidate_gender' => $this->mapGender($json['gender'] ?? ''),
        'candidate_exper_count' => (int)($json['experience_years'] ?? 0),
        'candidate_marital_status' => $this->mapMarital($json['marital_status'] ?? ''),
    ];
}

private function fallbackParser($text)
{
    // Email
    preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $text, $email);

    // Phone
    preg_match('/\+?\d{10,15}/', $text, $phone);

    // Name (top section only)
    $lines = explode("\n", $text);
    $firstLines = implode(" ", array_slice($lines, 0, 5));

    preg_match('/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $firstLines, $name);

    // Gender
    $gender = 3;
    if (preg_match('/\b(male|mr)\b/i', $text)) $gender = 1;
    elseif (preg_match('/\b(female|ms|mrs)\b/i', $text)) $gender = 2;

    // Experience
    preg_match_all('/(\d+)\+?\s*(years|yrs)/i', $text, $exp);
    $experience = !empty($exp[1]) ? max($exp[1]) : 0;

    // Marital
    $marital = null;
    if (stripos($text, 'married') !== false) $marital = 1;
    elseif (stripos($text, 'single') !== false) $marital = 2;
    else $marital = 2;

    return [
        'candidate_name' => $name[0] ?? null,
        'candidate_email' => $email[0] ?? null,
        'candidate_mobile' => $phone[0] ?? null,
        'candidate_gender' => $gender,
        'candidate_exper_count' => $experience,
        'candidate_marital_status' => $marital,
    ];
}

  private function mergeData($ai, $fallback, $text)
{
      return [
          // ✅ Name → AI + fallback
          'candidate_name' => $ai['candidate_name'] ?: $this->extractName($text) ?: $fallback['candidate_name'],

          // ✅ Email → ALWAYS from TEXT (critical fix)
          
          'candidate_email' =>$ai['candidate_email'] ?? $this->extractEmail($text),

          // ✅ Phone → ALWAYS from TEXT
        //   'candidate_mobile' =>  $ai['candidate_mobile'] ?? $this->extractPhone($text) ,
        'candidate_mobile' =>$ai['candidate_mobile']?: $this->extractPhone($text)  ,

          // ✅ Gender → AI or fallback
          'candidate_gender' => $ai['candidate_gender'] ?? $fallback['candidate_gender'] ?? 3,

          // ✅ Experience → max of both
          'candidate_exper_count' => max(
              (int)$ai['candidate_exper_count'],
              (int)$fallback['candidate_exper_count']
          ),

          // ✅ Marital
          'candidate_marital_status' => $ai['candidate_marital_status'] ?? $fallback['candidate_marital_status'],
      ];
}

private function cleanFinalData($data, $text)
{
    // ✅ Clean Email
    if (!empty($data['candidate_email'])) {
        preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $data['candidate_email'], $email);
        $data['candidate_email'] = $email[0] ?? null;
    }

    // ✅ Clean Name (remove garbage words)
    if (!empty($data['candidate_name'])) {
        $name = trim($data['candidate_name']);

        // Remove unwanted words
        $name = preg_replace('/(country|india|city|resume)/i', '', $name);

        // Keep only 2 words max
        // preg_match('/[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $name, $match);
        preg_match('/^([A-Z]\.\s*)*[A-Z][a-z]+(?:\s[A-Z][a-z]+)?/', $name, $match);

        $data['candidate_name'] = $match[0] ?? null;
    }

    // ✅ Clean Phone
    // if (!empty($data['candidate_mobile'])) {
    //     preg_match('/\+?\d{10,15}/', $data['candidate_mobile'], $phone);
    //     $data['candidate_mobile'] = $phone[0] ?? null;
    // }
    if (!empty($data['candidate_mobile'])) {
        $data['candidate_mobile'] = $this->cleanPhone($data['candidate_mobile']);
    }

    return $data;
}
private function mapGender($gender)
{
    $gender = strtolower(trim($gender));

    if (in_array($gender, ['male', 'm'])) return 1;
    if (in_array($gender, ['female', 'f'])) return 2;

    return 3;
}
private function mapMarital($status)
{
    $status = strtolower(trim($status));

    return match (true) {
        str_contains($status, 'unmarried'),
        str_contains($status, 'single'),
        str_contains($status, 'not married') => 2,

        str_contains($status, 'married') => 1,

        default => null,
    };
}

public function extractCandidateData(Request $request)
{
    $request->validate([
        'upload_resume' => 'required|mimes:pdf,doc,docx|max:5120',
    ]);
    
    try {
        $file = $request->file('upload_resume');
        $tempPath = sys_get_temp_dir() . '/' . uniqid() . '.' . $file->getClientOriginalExtension();
        $file->move(dirname($tempPath), basename($tempPath));

       
        $text = $this->extractResumeText($tempPath);
        // $text = $this->extractText($file);
      
        // return  $text;
        // STEP 1: AI
        $aiResponse = $this->parseWithAI($text);
        //   return $aiResponse; 
        $aiData = $this->mapAIResponse($aiResponse);
        //  return $aiData; 

        $fallbackData = $this->fallbackParser($text);

        $finalData = $this->mergeData($aiData, $fallbackData, $text);

        // STEP 4: CLEAN (🔥 NEW)
        $finalData = $this->cleanFinalData($finalData, $text);

        // STEP 5: QUALIFICATION
        $qualification = $this->detectQualification($text);

        $finalData['candidate_qualification'] = $qualification['qualification_sno'] ?? null;
        $finalData['candidate_major'] = $qualification['major_sno'] ?? null;
        $finalData = $this->addConfidence($finalData);

        return response()->json([
            'status' => 200,
            'data' => $finalData
        ]);

    } catch (\Exception $e) {
        \Log::error($e);

        return response()->json([
            'status' => 500,
            'message' => 'Resume parsing failed: ' . $e->getMessage()
        ]);
    } finally {
        if ($tempPath && file_exists($tempPath)) {
            unlink($tempPath);
        }
    }
}

private function extractName($text)
{
    $lines = explode("\n", $text);

    foreach (array_slice($lines, 0, 10) as $line) {

        $line = trim($line);

        // Skip noise
        if (preg_match('/(email|phone|linkedin|contact|profile)/i', $line)) {
            continue;
        }

        // ✅ ALL CAPS NAME SUPPORT
        if (preg_match('/^[A-Z\s]{3,}$/', $line)) {
            return ucwords(strtolower($line));
        }

        // ✅ Normal Name
        if (preg_match('/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)+$/', $line)) {
            return $line;
        }
    }

    return null;
}

private function extractEmail($text)
{
    preg_match_all('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $text, $matches);

    if (!empty($matches[0])) {

        foreach ($matches[0] as $email) {

            // Skip fake/system emails
            if (str_contains($email, 'example')) continue;

            return strtolower(trim($email));
        }
    }

    return null;
}

private function extractPhone($text)
{
    preg_match_all('/\+?\d[\d\s\-]{8,}\d/', $text, $matches);

    if (!empty($matches[0])) {
        return preg_replace('/\D/', '', $matches[0][0]);
    }

    return null;
}

public function detectQualification($text)
{
    $text = strtoupper($text);
    $text = preg_replace('/[^A-Z0-9\s]/', ' ', $text);

    $levels = DB::table('egc_qualification_level')->get();
    $majors = DB::table('egc_major')->where('status', 0)->get();

    // 🔥 DEGREE KEYWORDS → MAP TO DB
    $degreeMap = [
        'BTECH' => 'UG',
        'BE' => 'UG',
        'BSC' => 'UG',
        'BCOM' => 'UG',
        'BCA' => 'UG',

        'MBA' => 'PG',
        'MTECH' => 'PG',
        'MSC' => 'PG',

        'PHD' => 'Doctorate',
        'DIPLOMA' => 'Diploma'
    ];

    foreach ($degreeMap as $key => $levelName) {

        if (strpos($text, $key) !== false) {

            $level = $levels->firstWhere('qualification_level_name', $levelName);

            return [
                'qualification_sno' => $level->sno ?? null,
                'major_sno' => $this->detectMajor($text, $majors)
            ];
        }
    }

    // 🔥 MAJOR MATCH (BEST CASE)
    foreach ($majors as $major) {

        if (!$major->major_name) continue;

        if (strpos($text, strtoupper($major->major_name)) !== false) {

            return [
                'qualification_sno' => $major->qualification_id,
                'major_sno' => $major->sno
            ];
        }
    }

    return [
        'qualification_sno' => null,
        'major_sno' => null
    ];
}

private function detectMajor($text, $majors)
{
    $text = strtolower($text);

    foreach ($majors as $m) {

        $name = strtolower($m->major_name ?? '');

        if (!$name) continue;

        if (str_contains($text, $name)) {
            return $m->sno;
        }
    }

    return null;
}

private function fallbackQualification($text)
{
    $map = [
        'BTECH' => 'UG',
        'B E' => 'UG',
        'BE' => 'UG',
        'BSC' => 'UG',
        'BCA' => 'UG',
        'BCOM' => 'UG',
        'BA' => 'UG',

        'MTECH' => 'PG',
        'ME' => 'PG',
        'MSC' => 'PG',
        'MCA' => 'PG',
        'MBA' => 'PG',

        'PHD' => 'Doctorate',

        'DIPLOMA' => 'Diploma'
    ];

    foreach ($map as $key => $level) {
        if (strpos($text, $key) !== false) {
            return [
                'major_sno' => null,
                'major_name' => $key,
                'qualification_level' => $level
            ];
        }
    }

    return [
        'major_sno' => null,
        'major_name' => null,
        'qualification_level' => null
    ];
}

private function extractResumeText(string $filePath): string
    {
       
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        $text = '';
        // return $extension;
        try {

            /* ===== PDF ===== */
            if ($extension === 'pdf') {
                $parser = new PdfParser();
                $pdf = $parser->parseFile($filePath);
                $text = $pdf->getText();

                // 🔥 If empty → OCR fallback
                if (strlen(trim($text)) < 50) {
                    $text = $this->extractPdfWithOCR($filePath);
                }
            }

            /* ===== DOC / DOCX ===== */
            if (in_array($extension, ['doc', 'docx'])) {

                $phpWord = IOFactory::load($filePath);

                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {

                        if (method_exists($element, 'getText')) {
                            $text .= $element->getText() . ' ';
                        }

                        if (method_exists($element, 'getElements')) {
                            foreach ($element->getElements() as $child) {
                                if (method_exists($child, 'getText')) {
                                    $text .= $child->getText() . ' ';
                                }
                            }
                        }
                    }
                }
            }
            if(in_array($extension, ['jpg', 'jpeg', 'png',])){
                $text = $this->extractTextWithOCR($path);
            }

        } catch (\Exception $e) {
            \Log::error('Resume extraction failed: ' . $e->getMessage());
        }

        // Cleanup text
        return trim(preg_replace('/\s+/', ' ', $text));
    }

private function extractDocFallback($path)
{
    $text = '';

    try {
        // Linux server (best)
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
            $text = shell_exec("antiword " . escapeshellarg($path));
        } else {
            // Windows fallback
            $text = file_get_contents($path);
        }

    } catch (\Exception $e) {
        \Log::error('DOC Extract Error: '.$e->getMessage());
    }

    return $text;
}
private function cleanText($text)
{
    // Keep line breaks!
    $text = preg_replace('/[^\x20-\x7E\n]/', ' ', $text);

    // Normalize spaces but KEEP new lines
    $text = preg_replace('/[ \t]+/', ' ', $text);

    return trim(substr($text, 0, 8000));
}
private function extractTextWithOCR($filePath)
{
    try {
        return (new TesseractOCR($filePath))
            ->lang('eng')
            ->psm(6) // 🔥 Better layout detection
            ->run();
    } catch (\Exception $e) {
        \Log::error('OCR Error: '.$e->getMessage());
        return '';
    }
}

private function cleanPhone($phone)
{
    // Remove all non-digits
    $phone = preg_replace('/\D/', '', $phone);

    // Remove leading country code (91 for India)
    if (strlen($phone) > 10 && str_starts_with($phone, '91')) {
        $phone = substr($phone, 2);
    }

    // Keep only last 10 digits if still longer
    if (strlen($phone) > 10) {
        $phone = substr($phone, -10);
    }

    // Validate final length
    return strlen($phone) === 10 ? $phone : null;
}

private function pdfToImages($path)
{
    $images = [];
    $outputDir = storage_path('app/ocr/');

    if (!file_exists($outputDir)) {
        mkdir($outputDir, 0777, true);
    }

    $output = $outputDir . uniqid();

    // Convert PDF to PNG images
    shell_exec("pdftoppm -png " . escapeshellarg($path) . " $output");

    foreach (glob($output . "*.png") as $img) {
        $images[] = $img;
    }

    return $images;
}
private function extractPdfWithOCR($path)
{
    $text = '';

    $images = $this->pdfToImages($path);

    foreach ($images as $img) {
        $text .= ' ' . $this->extractTextWithOCR($img);
        unlink($img);
    }

    return $text;
}
private function addConfidence($data)
{
    $score = 0;

    if ($data['candidate_email']) $score += 20;
    if ($data['candidate_mobile']) $score += 20;
    if ($data['candidate_name']) $score += 15;
    if ($data['candidate_exper_count']) $score += 15;
    if ($data['candidate_qualification']) $score += 15;
    if ($data['candidate_major']) $score += 15;

    $data['confidence'] = $score; // out of 100

    return $data;
}

      private function HuggingFaceCretential(){
        $huggingApi = DB::table('egc_api_integration')->where('api_key','egc_huggingface_api_1')->where('status',0)->orderBy('sno', 'desc')->first();
          if($huggingApi){
            $apiFields = json_decode($huggingApi->api_fields, true);
            $accessToken = '';
            foreach ($apiFields as $field) {
                if ($field['key'] === 'api_key') {
                    $accessToken = $field['value'];
                }else{
                    $accessToken=null;
                }
            }
             
          }else{
            $accessToken=null;
          }
          return $accessToken;
    }


//     private function extractText($file)
// {
//     try {
//         $extension = strtolower($file->getClientOriginalExtension());
//         $path = $file->getRealPath();
//         $text = '';

//         switch ($extension) {

//             case 'pdf':
//                 // 🔥 Try normal extraction first
//                 $text = shell_exec("pdftotext " . escapeshellarg($path) . " -");

//                 // 🔥 If empty → OCR
//                 if (strlen(trim($text)) < 50) {
//                     $text = $this->extractPdfWithOCR($path);
//                 }
//                 break;

//             case 'docx':
//                 $phpWord = \PhpOffice\PhpWord\IOFactory::load($path);

//                 foreach ($phpWord->getSections() as $section) {
//                     foreach ($section->getElements() as $element) {

//                         if (method_exists($element, 'getText')) {
//                             $text .= ' ' . $element->getText();
//                         }

//                         if (method_exists($element, 'getElements')) {
//                             foreach ($element->getElements() as $child) {
//                                 if (method_exists($child, 'getText')) {
//                                     $text .= ' ' . $child->getText();
//                                 }
//                             }
//                         }
//                     }
//                 }
//                 break;

//             case 'doc':
//                 $text = $this->extractDocFallback($path);
//                 break;

//             case 'jpg':
//             case 'jpeg':
//             case 'png':
//                 // 🔥 Direct OCR for images
//                 $text = $this->extractTextWithOCR($path);
//                 break;

//             default:
//                 throw new \Exception('Unsupported format');
//         }

//         return $this->cleanText($text);

//     } catch (\Exception $e) {
//         \Log::error('Extract Error: '.$e->getMessage());
//         return '';
//     }
// }
}
