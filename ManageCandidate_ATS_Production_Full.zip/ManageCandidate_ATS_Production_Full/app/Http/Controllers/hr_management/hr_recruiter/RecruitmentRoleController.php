<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;

use App\Models\RecruitmentRoleModel;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class RecruitmentRoleController extends Controller
{
    /**
     * GET /recruitment/roles
     * AJAX endpoint for the Manage Roles table.
     */
    public function index(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'search' => ['nullable', 'string', 'max:150'],
            'family' => ['nullable', 'string', 'max:100'],
            'status' => ['nullable', 'integer', Rule::in([0, 1, 2])],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);

        $perPage = (int) ($validated['per_page'] ?? 15);
        $search = trim((string) ($validated['search'] ?? ''));

        $query = RecruitmentRoleModel::query()
            ->select([
                'sno',
                'role_code',
                'role_name',
                'role_family',
                'seniority_level',
                'description',
                'status',
                'match_enabled',
                'created_at',
                'updated_at',
            ]);

        // By default, keep deleted records out of the management list.
        if (array_key_exists('status', $validated) && $validated['status'] !== null && $validated['status'] !== '') {
            $query->where('status', (int) $validated['status']);
        } else {
            $query->whereIn('status', [
                RecruitmentRoleModel::STATUS_ACTIVE,
                RecruitmentRoleModel::STATUS_INACTIVE,
            ]);
        }

        if ($search !== '') {
            $like = '%' . addcslashes($search, '%_\\') . '%';

            $query->where(function ($q) use ($like) {
                $q->where('role_name', 'like', $like)
                    ->orWhere('role_code', 'like', $like)
                    ->orWhere('role_family', 'like', $like)
                    ->orWhere('description', 'like', $like);
            });
        }

        if (!empty($validated['family'])) {
            $query->where('role_family', $validated['family']);
        }

        $roles = $query
            ->orderBy('role_name')
            ->paginate($perPage)
            ->withQueryString();

        return response()->json([
            'success' => true,
            'data' => $roles->getCollection()->map(fn (RecruitmentRoleModel $role) => [
                'id' => $role->sno,
                'role_code' => $role->role_code,
                'role_name' => $role->role_name,
                'role_family' => $role->role_family,
                'seniority_level' => $role->seniority_level,
                'seniority_label' => $role->seniority_label,
                'description' => $role->description,
                'status' => $role->status,
                'status_label' => $role->status_label,
                'match_enabled' => (bool) $role->match_enabled,
                'created_at' => optional($role->created_at)->format('d M Y, h:i A'),
                'updated_at' => optional($role->updated_at)->format('d M Y, h:i A'),
            ])->values(),
            'meta' => [
                'current_page' => $roles->currentPage(),
                'last_page' => $roles->lastPage(),
                'per_page' => $roles->perPage(),
                'from' => $roles->firstItem(),
                'to' => $roles->lastItem(),
                'total' => $roles->total(),
            ],
        ]);
    }

    /**
     * GET /recruitment/roles/meta
     * AJAX endpoint for counters and family filter options.
     */
    public function meta(): JsonResponse
    {
        $base = RecruitmentRoleModel::query();

        $counts = [
            'active' => (clone $base)->where('status', RecruitmentRoleModel::STATUS_ACTIVE)->count(),
            'inactive' => (clone $base)->where('status', RecruitmentRoleModel::STATUS_INACTIVE)->count(),
            'deleted' => (clone $base)->where('status', RecruitmentRoleModel::STATUS_DELETED)->count(),
        ];

        $families = RecruitmentRoleModel::query()
            ->where('status', '!=', RecruitmentRoleModel::STATUS_DELETED)
            ->whereNotNull('role_family')
            ->where('role_family', '!=', '')
            ->distinct()
            ->orderBy('role_family')
            ->pluck('role_family')
            ->values();

        return response()->json([
            'success' => true,
            'counts' => $counts,
            'families' => $families,
        ]);
    }

    /**
     * POST /recruitment/roles
     * Creates a new canonical ATS role.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'role_name' => [
                'required',
                'string',
                'min:2',
                'max:150',
                'unique:egc_recruitment_roles,role_name',
            ],
            'role_family' => ['nullable', 'string', 'max:100'],
            'seniority_level' => ['required', 'integer', 'between:1,5'],
            'description' => ['nullable', 'string', 'max:5000'],
            'match_enabled' => ['nullable', 'boolean'],
        ]);

        $userId = (int) ($request->user()?->getAuthIdentifier() ?? 0);
        $roleName = $this->cleanRoleName($validated['role_name']);

        try {
            $role = DB::transaction(function () use ($validated, $roleName, $userId) {
                $role = new RecruitmentRoleModel();
                $role->role_code = $this->generateUniqueRoleCode($roleName);
                $role->role_name = $roleName;
                $role->role_family = $this->cleanNullableString($validated['role_family'] ?? null);
                $role->seniority_level = (int) $validated['seniority_level'];
                $role->description = $this->cleanNullableString($validated['description'] ?? null);
                $role->created_by = $userId;
                $role->updated_by = $userId;
                $role->status = RecruitmentRoleModel::STATUS_ACTIVE;
                $role->match_enabled = array_key_exists('match_enabled', $validated)
                    ? (bool) $validated['match_enabled']
                    : true;
                $role->save();

                return $role->fresh();
            });
        } catch (QueryException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                return response()->json([
                    'success' => false,
                    'message' => 'A role with the same name or generated role code already exists.',
                ], 422);
            }

            throw $e;
        }

        return response()->json([
            'success' => true,
            'message' => 'Role created successfully.',
            'data' => [
                'id' => $role->sno,
                'role_code' => $role->role_code,
                'role_name' => $role->role_name,
            ],
        ], 201);
    }

    /**
     * GET /recruitment/roles/{role}/edit
     */
    public function edit(int $role): JsonResponse
    {
        $roleModel = RecruitmentRoleModel::query()->findOrFail($role);

        if ($roleModel->isDeleted()) {
            return response()->json([
                'success' => false,
                'message' => 'Deleted roles cannot be edited.',
            ], 422);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $roleModel->sno,
                'role_code' => $roleModel->role_code,
                'role_name' => $roleModel->role_name,
                'role_family' => $roleModel->role_family,
                'seniority_level' => $roleModel->seniority_level,
                'description' => $roleModel->description,
                'status' => $roleModel->status,
                'match_enabled' => (bool) $roleModel->match_enabled,
            ],
        ]);
    }

    /**
     * PUT-like action implemented through POST for simple jQuery AJAX.
     * POST /recruitment/roles/{role}/update
     */
    public function update(Request $request, int $role): JsonResponse
    {
        $roleModel = RecruitmentRoleModel::query()->findOrFail($role);

        if ($roleModel->isDeleted()) {
            return response()->json([
                'success' => false,
                'message' => 'Deleted roles cannot be edited.',
            ], 422);
        }

        $validated = $request->validate([
            'role_name' => [
                'required',
                'string',
                'min:2',
                'max:150',
                Rule::unique('egc_recruitment_roles', 'role_name')->ignore($roleModel->sno, 'sno'),
            ],
            'role_family' => ['nullable', 'string', 'max:100'],
            'seniority_level' => ['required', 'integer', 'between:1,5'],
            'description' => ['nullable', 'string', 'max:5000'],
            'match_enabled' => ['nullable', 'boolean'],
        ]);

        $userId = (int) ($request->user()?->getAuthIdentifier() ?? 0);
        $roleName = $this->cleanRoleName($validated['role_name']);

        try {
            DB::transaction(function () use ($roleModel, $validated, $roleName, $userId) {
                // role_code intentionally remains immutable because it may already be referenced by ATS/API data.
                $roleModel->role_name = $roleName;
                $roleModel->role_family = $this->cleanNullableString($validated['role_family'] ?? null);
                $roleModel->seniority_level = (int) $validated['seniority_level'];
                $roleModel->description = $this->cleanNullableString($validated['description'] ?? null);
                $roleModel->updated_by = $userId;
                $roleModel->match_enabled = array_key_exists('match_enabled', $validated)
                    ? (bool) $validated['match_enabled']
                    : false;
                $roleModel->save();
            });
        } catch (QueryException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                return response()->json([
                    'success' => false,
                    'message' => 'Another role already uses that role name.',
                ], 422);
            }

            throw $e;
        }

        return response()->json([
            'success' => true,
            'message' => 'Role updated successfully.',
        ]);
    }

    /**
     * POST /recruitment/roles/{role}/toggle-status
     * Toggles Active <-> Inactive; deleted roles cannot be toggled.
     */
    public function toggleStatus(Request $request, int $role): JsonResponse
    {
        $roleModel = RecruitmentRoleModel::query()->findOrFail($role);

        if ($roleModel->isDeleted()) {
            return response()->json([
                'success' => false,
                'message' => 'Deleted roles cannot be activated or deactivated.',
            ], 422);
        }

        $userId = (int) ($request->user()?->getAuthIdentifier() ?? 0);
        $newStatus = $roleModel->status === RecruitmentRoleModel::STATUS_ACTIVE
            ? RecruitmentRoleModel::STATUS_INACTIVE
            : RecruitmentRoleModel::STATUS_ACTIVE;

        $roleModel->status = $newStatus;
        $roleModel->updated_by = $userId;
        $roleModel->save();

        return response()->json([
            'success' => true,
            'message' => $newStatus === RecruitmentRoleModel::STATUS_ACTIVE
                ? 'Role activated successfully.'
                : 'Role deactivated successfully.',
            'status' => $newStatus,
            'status_label' => $roleModel->status_label,
        ]);
    }

    /**
     * POST /recruitment/roles/{role}/delete
     * Soft delete: status = 2 and matching disabled.
     */
    public function destroy(Request $request, int $role): JsonResponse
    {
        $roleModel = RecruitmentRoleModel::query()->findOrFail($role);

        if ($roleModel->isDeleted()) {
            return response()->json([
                'success' => false,
                'message' => 'Role is already deleted.',
            ], 422);
        }

        $userId = (int) ($request->user()?->getAuthIdentifier() ?? 0);

        DB::transaction(function () use ($roleModel, $userId) {
            $roleModel->status = RecruitmentRoleModel::STATUS_DELETED;
            $roleModel->match_enabled = false;
            $roleModel->updated_by = $userId;
            $roleModel->save();
        });

        return response()->json([
            'success' => true,
            'message' => 'Role deleted successfully.',
        ]);
    }

    private function cleanRoleName(string $name): string
    {
        return preg_replace('/\s+/u', ' ', trim($name)) ?? trim($name);
    }

    private function cleanNullableString(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim($value);
        return $value === '' ? null : $value;
    }

    private function generateUniqueRoleCode(string $roleName): string
    {
        $base = Str::upper(Str::snake(Str::ascii($roleName)));
        $base = preg_replace('/[^A-Z0-9_]+/', '_', $base) ?? 'ROLE';
        $base = trim($base, '_');
        $base = substr($base ?: 'ROLE', 0, 70);

        $code = $base;
        $counter = 1;

        while (RecruitmentRoleModel::query()->where('role_code', $code)->exists()) {
            $suffix = '_' . $counter++;
            $code = substr($base, 0, 80 - strlen($suffix)) . $suffix;
        }

        return $code;
    }
}
