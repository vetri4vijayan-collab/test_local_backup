<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\Applicant;
use App\Services\ApplicantRoleService;

class ApplicantRoleController extends Controller
{

    protected $service;

    public function __construct(ApplicantRoleService $service)
    {
        $this->service = $service;
    }

    /**
     * Update Applicant Job Roles
     */
     public function updateJobRole(Request $request)
    {
        $request->validate([
            'limit' => 'nullable|integer|min:1|max:500',
            'start_sno' => 'nullable|integer|min:1'
        ]);

        $limit = $request->limit ?? 100;
        $start = $request->start_sno ?? 1;

        $query = ApplicantModel::where('sno', '>=', $start)
            ->where('status', '!=', 2)
            ->where(function ($q) {
                $q->whereNull('job_role_id')
                    ->orWhere('job_role_id', '')
                    ->orWhere('job_role_id', '[]');
            })
            ->orderBy('sno')
            ->limit($limit);

        $applicants = $query->get();

        if ($applicants->count() == 0) {

            return response()->json([
                "status" => true,
                "message" => "No applicants found.",
                "processed" => 0
            ]);

        }

        $processed = 0;
        $updated = 0;
        $failed = 0;

        foreach ($applicants as $applicant) {

            try {

                $status = $this->service->processApplicant($applicant);

                $processed++;

                if ($status) {
                    $updated++;
                }

            } catch (\Exception $e) {

                $failed++;

                Log::error("Applicant AI Error",[
                    "applicant_id"=>$applicant->applicant_id,
                    "message"=>$e->getMessage()
                ]);

            }

        }

        return response()->json([

            "status"=>true,

            "processed"=>$processed,

            "updated"=>$updated,

            "failed"=>$failed

        ]);

    }

}