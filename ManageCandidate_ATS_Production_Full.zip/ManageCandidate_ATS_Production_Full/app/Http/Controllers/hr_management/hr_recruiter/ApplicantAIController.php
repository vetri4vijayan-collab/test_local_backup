<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ApplicantModel;
use App\Services\HuggingFaceRoleMatcherService;
use App\Services\ApplicantAIService;
use Illuminate\Support\Facades\Log;

class ApplicantAIController extends Controller
{
    protected HuggingFaceRoleMatcherService $matcher;
    protected ApplicantAIService $service;

    public function __construct(
        HuggingFaceRoleMatcherService $matcher,
        ApplicantAIService $service
    ) {
        $this->matcher = $matcher;
         $this->service = $service;
    }

    /**
     * Match Single Applicant
     */
    public function match(Request $request)
    {
        $request->validate([
            'applicant_id' => 'required'
        ]);

        try {

            $applicant = ApplicantModel::where(
                'applicant_id',
                $request->applicant_id
            )->first();

            if (!$applicant) {

                return response()->json([
                    'status' => false,
                    'message' => 'Applicant not found.'
                ],404);

            }

            /*
            |--------------------------------------------------------------------------
            | Resume Text
            |--------------------------------------------------------------------------
            */

            if (empty($applicant->resume_text)) {

                $resume = $this->extractResume($applicant);

                if (!$resume) {

                    return response()->json([
                        'status'=>false,
                        'message'=>'Resume text not found.'
                    ],422);

                }

                $applicant->resume_text = $resume;

                $applicant->save();
            }

            /*
            |--------------------------------------------------------------------------
            | AI Match
            |--------------------------------------------------------------------------
            */

            $result = $this->matcher
                ->matchApplicant($applicant);

            return response()->json($result);

        } catch (\Throwable $e) {

            Log::error(

                'Applicant AI',

                [

                    'message'=>$e->getMessage(),

                    'line'=>$e->getLine(),

                    'file'=>$e->getFile()

                ]

            );

            return response()->json([

                'status'=>false,

                'message'=>$e->getMessage()

            ],500);

        }

    }

    /**
     * Resume Extraction
     */
    private function extractResume(
        ApplicantModel $applicant
    )
    {
        $drive_old = $applicant->drive_data;

        $drive_data = $drive_old
            ? json_decode($drive_old)
            : null;

        if (
            $drive_data &&
            isset($drive_data->file_id)
        ) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeTextFromDrive(
                    $drive_data->file_id
                );

        }

        if ($applicant->attachment) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeText(

                    public_path(
                        'job_applications/resume_files/' .
                        $applicant->attachment
                    )

                );

        }

        return null;
    }

     public function show(int $id)
    {
        try {

            $result = $this->service->getApplicant($id);

            if (!$result['status']) {

                return response()->json($result,404);

            }

            return response()->json([

                'status'=>true,

                'data'=>$result['data']

            ]);

        }

        catch(Throwable $e){

            \Log::error('Applicant AI View',[
                'applicant'=>$id,
                'message'=>$e->getMessage()
            ]);

            return response()->json([

                'status'=>false,

                'message'=>'Unable to load applicant.'

            ],500);

        }

    }

}