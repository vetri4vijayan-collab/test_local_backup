<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\File;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;

class JobRequest extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
  public function index(Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
      ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->select('egc_job_request.*','egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_company.company_base_color',);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%");
          });
      }

        if ($job_role_fill) {
          $jobRequest->where('egc_job_request.job_role_name', $job_role_fill);
        }
        if ($closing_date_filt) {
          $jobRequest->where('egc_job_request.closing_date', $closing_date_filt);
        }
        if ($exp_type_filt) {
          $jobRequest->whereJsonContains('egc_job_request.exp_type_ids', $exp_type_filt);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('egc_job_request.created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('egc_job_request.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('egc_job_request.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('egc_job_request.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('egc_job_request.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('egc_job_request.created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
            $applicants_count = ApplicantModel::where('job_request_id', $item->sno)
                    ->where('status', '!=', 2)
                    ->count();

            $interview_stage_count = 0;
            
            $interview_schedule = InterviewScheduleModel::where('job_request_id', $item->sno)
                ->where('status', '!=', 2)
                ->first();

            if ($interview_schedule) {
                $interview_stage_count = InterviewScheduleStageModel::where(
                        'interview_schedule_id',
                        $interview_schedule->sno
                    )
                    ->where('status', '!=', 2)
                    ->count();
            }
            
            // return $interview_schedule;
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'job_role_name' => $item->job_role_name ?? '-',
                  'min_salary' => $item->min_salary,
                  'max_salary' => $item->max_salary,
                  'vacancy_count' => $item->vacancy_count,
                  'experience' => $item->experience,
                  'experience' => $item->experience,
                  'closing_date' => $item->closing_date,
                  'last_apply_date' => $item->last_apply_date,
                  'company_base_color' => $item->company_base_color,
                  'company_name' => $item->company_name,
                  'entity_name' => $item->entity_name,
                  'skill_required' => $item->skill_required,
                  'applicants_count' => $applicants_count,
                  'exp_type_ids' => $item->exp_type_ids,
                  'data' => $item,
                  'interview_schedule_status' => $interview_stage_count > 0 ? 1 : 0,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $job_list =DB::table('egc_job_role')->where('company_id',0)->where('status','!=',2)->where('is_vissible',1)->get();
      return view('content.hr_management.hr_recruiter.job_request.job_request', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'job_list' => $job_list,
          'source_list' => $source_list,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        $interviewCategoryType = DB::table('egc_interview_category')->where('status', '!=', 2)->get();
        $interviewModeList = DB::table('egc_interview_mode')->where('status', '!=', 2)->get();

        $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
        ->select('egc_job_request.*','egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_job_role.job_position_name as job_role_name',
        'egc_company.company_name',
        'egc_entity.entity_base_color',
        'egc_company.company_base_color',)->where('egc_job_request.sno', $decodeId)->first();

        
            $schedule = InterviewScheduleModel::updateOrCreate(
            [
                'job_request_id' => $jobRequest->sno,
                'entity_id' => $jobRequest->entity_id,  
            ],
            [
                'status'      => 0,
                'created_at'  => now(),
                'created_by'  => $userId ?? 0
            ]
        );
        $lastStageId = InterviewScheduleStageModel::max('sno');
        $nextStageId = $lastStageId ? $lastStageId + 1 : 1;

        $idMerge = $decodeId . '~' . $schedule->sno . '~' . $nextStageId;
        $shareCode = base64_encode($idMerge);
        
        $url=url('/interview_login/'.$shareCode);

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          'interviewCategoryType' => $interviewCategoryType,
          'interviewModeList' => $interviewModeList,
          'jobRequest' => $jobRequest,
          'encoded' => $id,
          'url' => $url,
          'scheduleId' => $schedule->sno ,
          
      ]);
  }


 public function createInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id;
    $request->validate([
        'job_request_id' => 'required|integer',
        'entity_id'   => 'required|integer',
        'interview_stages' => 'required|array|min:1'
    ]);

    // return response()->json([
    //         'status'  => false,
    //         'message' => 'Failed to create interview schedule',
    //         'error'   => $request
    //     ], 500);
    // return $request;
    DB::beginTransaction();

    try {
         $schedule = InterviewScheduleModel::updateOrCreate(
            [
            'job_request_id' => $request->job_request_id,
            'entity_id' => is_array($request->entity_id)
                          ? ($request->entity_id[0] ?? null)
                          : $request->entity_id,
            ],
            [
            
            'status'      => 0,
            'created_at'  => now(),
            'created_by'  => $userId ?? 0
        ]);
        $firstStageShareCode = null;
       
        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id'  => $stage['interview_category_id'],
                'stage_order'            => $order + 1,
                'duration_value'         => $stage['config']['duration_value'],
                'interview_date' => date('Y-m-d', strtotime($stage['config']['interview_date'])),
                'interview_time' => date('H:i:s', strtotime($stage['config']['interview_time'])),
                'address'          => $stage['config']['address'] ?? NULL,
                'location_url'          => $stage['config']['location_url'] ?? NULL,
                'direct_interview_checklist'          => $stage['config']['checklist'] ? json_encode($stage['config']['checklist']) : NULL,
                'duration_unit'          => $stage['config']['duration_unit'],
                'mode'                   => $stage['config']['mode'],
                'call_confirmation'      => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'       => $stage['config']['immediate_notify'] ?? 0,
                'status'                 => 0,
                'created_at'             => now(),
                'created_by'             => $userId ?? 0
            ]);

             $idMerge   = $request->job_request_id . '~' . $schedule->sno . '~' . $stageModel->sno;
            $shareCode = base64_encode($idMerge);
             $shareUrl=url('/interview_login/'.$shareCode);
            $stageModel->update([
                'shareLink' => $shareUrl
            ]);

             if ($order === 0) {
                $firstStageShareCode = $shareCode;
            }
            
            foreach ($stage['questions'] as $question) {
                $questionData=InterviewQuestionModel::where('sno',$question['question_id'])->first();
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $question['question_id'], // ✅ FIX
                    'thinking_time'               => $questionData->thinking_time ?? '30 Seconds',
                    'allowed_time'                => $$questionData->allowed_time ?? '1 Minutes',
                    'retakes'                     => $$questionData->retakes ?? 3,
                    'status'                      => 0,
                    'created_at'                  => now(),
                    'created_by'                  => $userId ?? 0
                ]);
            }
        }

        

         $schedule->update([
            'share_code' => $firstStageShareCode,
            'updated_by' => $userId ?? 0,
            'updated_at' => now()
        ]);

        DB::commit();

        return response()->json([
            'status'     => true,
            'share_code' => $firstStageShareCode
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to create interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function editInterviewSchedule($encoded)
  {
      [$scheduleSno] = explode('|', base64_decode($encoded));

      $schedule = InterviewScheduleModel::where('sno', $scheduleSno)
          ->where('status', 0)
          ->first();

      $stages = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
          ->where('status', 0)
          ->orderBy('stage_order')
          ->get();
      
          $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->select('egc_job_request.*','egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_job_role.job_position_name as job_role_name',
            'egc_company.company_name',
            'egc_entity.entity_base_color',
            'egc_company.company_base_color',)->where('egc_job_request.sno', $schedule->job_request_id)->first();

      $questions = InterviewScheduleQuestionModel::whereIn(
          'interview_schedule_stage_id',
          $stages->pluck('sno')
      )->where('status', 0)->get();

        $shareCode =$schedule->share_code  ?? base64_encode($schedule->sno . '|' . time());

        $url=url('/interview_login/'.$shareCode);
        $interviewCategoryType = DB::table('egc_interview_category')->where('status', '!=', 2)->get();
        $interviewModeList = DB::table('egc_interview_mode')->where('status', '!=', 2)->get();


      return view('content.hr_management.hr_recruiter.job_request.interview_schedule_edit', [
          'schedule' => $schedule,
          'jobRequest' => $jobRequest,
          'interviewCategoryType' => $interviewCategoryType,
          'interviewModeList' => $interviewModeList,
          'stages'   => $stages,
          'url'   => $url,
          'questions'=> $questions,
          'encoded'  => $encoded
      ]);
  }


  public function updateInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id ?? 0;

    $request->validate([
        'schedule_id'    => 'required|integer',
        'job_request_id'     => 'required|integer',
        'entity_id'       => 'required|integer',
        'interview_stages'=> 'required|array|min:1'
    ]);

    DB::beginTransaction();

    try {
        $schedule = InterviewScheduleModel::where('sno', $request->schedule_id)
            ->where('status', 0)
            ->firstOrFail();

        // 🔹 Update main schedule
        $schedule->update([
            'job_request_id' => $request->job_request_id,
            'entity_id'   => $request->entity_id,
            'updated_at'  => now(),
            'updated_by'  => $userId
        ]);

        // 🔥 DELETE OLD DATA (SAFE)
        $oldStageIds = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
            ->pluck('sno');

        InterviewScheduleQuestionModel::whereIn(
            'interview_schedule_stage_id',
            $oldStageIds
        )->update(['status' => 2 ]);

        InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)->update(['status' => 2 ]);

        // 🔁 REINSERT UPDATED DATA
        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id' => $stage['interview_category_id'],
                'stage_order'           => $order + 1,
                'duration_value'        => $stage['config']['duration_value'],
                'duration_unit'         => $stage['config']['duration_unit'],
                'mode'                  => $stage['config']['mode'],
                'call_confirmation'     => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'      => $stage['config']['immediate_notify'] ?? 0,
                'status'                => 0,
                'created_at'            => now(),
                'created_by'            => $userId
            ]);

            foreach ($stage['questions'] as $qid) {
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $qid,
                    'status'                      => 0,
                    'created_at'                  => now(),
                    'created_by'                  => $userId
                ]);
            }
        }

        DB::commit();

        return response()->json([
            'status'  => true,
            'message' => 'Interview schedule updated successfully'
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to update interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function Status($id, Request $request)
  {
    $last_apply_date = $request->input('last_apply_date');
    $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }

  public function interviewQuestionsByRole(Request $request)
  {
      $job_role_id = $request->input('job_role_id');
      $interview_category_id = $request->input('interview_category_id');

      $questions = DB::table('egc_interview_question')
          ->where('job_role_id', $job_role_id)
          ->where('interview_category_id', $interview_category_id)
          ->where('status', 0)
          ->get();

      return response()->json([
          'status' => 200,
          'message' => null,
          'error_msg' => null,
          'data' => $questions
      ], 200);
  }

//   public function ApplyCandidateListByJob(Request $request){

//     $job_request_id = $request->input('request_id');
//     $decodeId = base64_decode($job_request_id);

//     $applicants = ApplicantModel::where('job_request_id', $decodeId)
//                     ->where('status', '!=', 2)
//                     ->get();

//     return response([
//       'status'    => 200,
//       'message'   => 'Successfully Fetched!',
//       'error_msg' => null,
//       'data'      => $applicants,
//     ], 200);
//   }


public function ApplyCandidateListByJob(Request $request)
{
    $job_request_id = $request->input('request_id');
    $decodeId = base64_decode($job_request_id);

    $applicants = ApplicantModel::where('job_request_id', $decodeId)
        ->where('status','!=',2)
        ->get();

    $applicants->transform(function ($item) {

        $ai = json_decode($item->ai_response, true);

        $item->overall_match_score = $ai['overall_match_score'] ?? 0;
        $item->ats_score = $ai['ats_keyword_match_score'] ?? 0;
        $item->skills_score = $ai['skills_alignment_score'] ?? 0;
        $item->experience_score = $ai['experience_relevance_score'] ?? 0;
        $item->impact_score = $ai['impact_metrics_score'] ?? 0;

        $item->summary = $ai['optimized_summary'] ?? null;

        return $item;
    });

    return response([
        'status'=>200,
        'data'=>$applicants
    ]);
}

   public function UpdateShortlistCandidate(Request $request)
    {
        $shortlistData = $request->input('shortlist_data');
        $job_request_id = $request->input('job_request_id');
        // return $shortlistData;
         $shortlist_students = [];
        foreach ($shortlistData as $data) {
            // Update attendance_check for each student based on sno
            $student = ApplicantModel::where('sno', $data['sno'])->first();
            if ($data['shortListStatus'] == 1) {
                $shortlist_students[] = $data['sno'];
                $student->applicant_status = 3;
            } else {
                $student->applicant_status = 3;
            }

            $student->shortlist_check = $data['shortListStatus'];
            $student->save();
        }
        // return $job_request_id;
        if($job_request_id){
             $upd_eventModel =  JobRequestModel::where('sno', $job_request_id)->first();
              $upd_eventModel->status  =  4;
              $upd_eventModel->Update();

            $interview_schedule = InterviewScheduleModel::where('status', '!=', 2)
            ->where('job_request_id', $job_request_id)
            ->first();

            if ($interview_schedule) {

                $interview_stage = InterviewScheduleStageModel::where('status', '!=', 2)
                    ->where('interview_schedule_id', $interview_schedule->sno)
                    ->where('stage_order', 1)
                    ->first();

                if ($interview_stage) {
                    $interview_stage->shortlist_applicant_ids = !empty($shortlist_students)
                        ? json_encode($shortlist_students)
                        : null;

                    $interview_stage->save();
                }
            }
        }
    
         return response([
            'success'    => true,
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            ], 200);
    }


     public function Add(Request $request)
    {
         // --- VALIDATION ---
          $validator = Validator::make($request->all(), [
              'job_role_name' => 'required|max:255',
              'min_salary'    => 'required|numeric',
              'max_salary'    => 'required|numeric',
          ]);

          if ($validator->fails()) {
              return response([
                  'status'    => 400,
                  'message'   => 'Incorrect format input fields',
                  'error_msg' => $validator->errors(),
                  'data'      => null
              ], 400);
          }

           

            $job_role_name = $request->job_role_name;
            $exp_type = $request->exp_type ? json_encode($request->exp_type) : null;
            $experience_year = $request->experience_year ?? 0;
            $vacancy_count = $request->vacancy_count ?? 0;
            $closing_date = $request->closing_date ? date('Y-m-d', strtotime($request->closing_date)) : null;
            $min_salary = $request->min_salary;
            $max_salary = $request->max_salary;
            $skill_tag = $request->skill_KnowledgeTag ? json_encode($request->skill_KnowledgeTag) : null;
            $special_requirements = $request->special_requirements ? json_encode($request->special_requirements) : null;
            $job_description = $request->job_description_generate ?? null;
            $branch_id = $request->user()->branch_id;
            $user_id = $request->user()->user_id;
            // Check if a job request already exists with the same job role name and closing date
            $chk = JobRequestModel::where('job_role_name', $job_role_name)
                ->where('closing_date', $closing_date)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                return response([
                    'status' => 401,
                    'message' => 'Job Request already exists!',
                    'error_msg' => 'Job Request with this role name and closing date already exists!',
                    'data' => null,
                ], 401);
            } else {
                // Generate job request ID
                $category_check = JobRequestModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = substr(date('y'), -2);
                    $job_request_id = 'JOBRQ-0001/' . $year;
                } else {
                    $data = $category_check->job_request_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $job_request_id = sprintf('JOBRQ-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                // Create a new job request entry
                $add_job_request = new JobRequestModel();
                $add_job_request->job_request_id = $job_request_id;
                $add_job_request->job_role_id = $job_role_name;
                $add_job_request->exp_type_ids = $exp_type;
                $add_job_request->experience = $experience_year;
                $add_job_request->min_salary = $min_salary;
                $add_job_request->max_salary = $max_salary;
                $add_job_request->closing_date = $closing_date;
                $add_job_request->skill_required = $skill_tag;
                $add_job_request->job_description = $job_description;
                $add_job_request->special_requirements = $special_requirements;
                $add_job_request->vacancy_count = $vacancy_count;
                $add_job_request->branch_id = 0;
                $add_job_request->company_id = 0;
                $add_job_request->entity_id = 0;
                $add_job_request->company_type = 1;
                $add_job_request->created_by = $user_id;
                $add_job_request->updated_by = $user_id;

                if ($add_job_request->save()) {

                    return response([
                        'status' => 200,
                        'message' => 'Job Request created successfully.',
                        'error_msg' => null,
                        'data' => $add_job_request,
                    ], 200);
                } else {
                    return response([
                        'status' => 500,
                        'message' => 'Could not create Job Request.',
                        'error_msg' => 'There was an error while saving the Job Request.',
                        'data' => null,
                    ], 500);
                }
            }
        // }
    }

      public function Scanner_view(Request $request)
    {
            $search_fill = $request->search_fill ?? '';
            $user_id     = $request->user()->user_id;
            $branch_id   = $request->user()->branch_id;
            $role_id   = $request->user()->role_id;
            $sno = $request->sno ?? '';
            $List_table = JobQRScannerModel::where('egc_job_qr_scanner.job_request_id',$sno)->select('egc_job_qr_scanner.*','egc_applicant.applicant_name')
            ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                     ->where('egc_applicant.job_request_id', '=', $sno); // subquery-like condition
                            })
                    ->orderBy('egc_job_qr_scanner.sno','desc')->get();
        // return $ListTable;
        return view('content.hr_management.hr_recruiter.job_request.qr_scannerTable', compact('List_table'));
    }
   
    public function MultiMap(Request $request){
        $sno = $request->sno ?? '';
        $locations = JobQRScannerModel::where('egc_job_qr_scanner.job_request_id', $sno)
                         ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                     ->where('egc_applicant.job_request_id', '=', $sno); // subquery-like condition
                            })
                        ->where('egc_job_qr_scanner.latitude','!=',NULL)
                        ->where('egc_job_qr_scanner.longitude','!=',NULL)
                        ->select('egc_job_qr_scanner.latitude', 'egc_job_qr_scanner.longitude', 'egc_job_qr_scanner.ipaddress as name','egc_applicant.applicant_name') // adjust columns
                        ->get();
        return response()->json($locations);
    }



    // public function NotAppliedListByJob(Request $request)
    // {
    //     $job_request_id = $request->input('request_id');

    //     $applicants = InterviewCandidateModel::from('egc_interview_candidate as ic')
    //         ->leftJoin('egc_applicant as ea', 'ea.candidate_id', '=', 'ic.sno')

    //         ->where('ic.status', '!=', 2)

    //         // Exclude candidates already applied to this job
    //         ->whereNotExists(function ($query) use ($job_request_id) {
    //             $query->select(DB::raw(1))
    //                 ->from('egc_applicant as ea2')
    //                 ->whereColumn('ea2.candidate_id', 'ic.sno')
    //                 ->where('ea2.job_request_id', $job_request_id);
    //         })

    //         // Latest applicant per candidate
    //         ->whereIn('ea.sno', function ($query) {
    //             $query->select(DB::raw('MAX(sno)'))
    //                 ->from('egc_applicant')
    //                 ->groupBy('candidate_id');
    //         })

    //         ->select([
    //             'ic.sno as candidate_id',
    //             'ea.sno as applicant_id',
    //             'ea.applicant_name',
    //             'ea.recruitment_id',
    //             'ea.job_request_id',
    //             'ea.job_role_id',
    //             'ea.mobile',
    //             'ea.email',
    //             'ea.gender',
    //             'ea.marital_status_id',
    //             'ea.qualification_id',
    //             'ea.major',
    //             'ea.experience_id',
    //             'ea.experience_count',
    //             'ea.source_id',
    //             'ea.marital_status_id',
    //             'ea.drive_data',
    //             'ea.old_data',
    //         ])

    //         ->orderBy('ea.applicant_name','asc')
    //         ->get();

    //     return response()->json([
    //         'status'    => 200,
    //         'message'   => 'Successfully Fetched!',
    //         'error_msg' => null,
    //         'data'      => $applicants,
    //     ]);
    // }


    public function NotAppliedListByJob(Request $request)
    {
        $job_request_id = $request->request_id;
        $offset = (int) $request->offset ?? 0;
        $limit  = 20;
        $startTime = microtime(true);
              

                //  $endTime       = microtime(true);
                // $executionTime = $endTime - $startTime;

                $query = InterviewCandidateModel::from('egc_interview_candidate as ic')
                ->join(DB::raw('
                    (
                        SELECT candidate_id, MAX(sno) AS latest_sno
                        FROM egc_applicant
                        GROUP BY candidate_id
                    ) latest
                '), 'latest.candidate_id', '=', 'ic.sno')
                ->join('egc_applicant as ea', 'ea.sno', '=', 'latest.latest_sno')
                ->leftJoin('egc_qualification_level as ql', 'ql.sno', '=', 'ea.qualification_id')
                ->where('ic.status', '!=', 2)
                ->where(function ($q) use ($job_request_id) {
                    $q->whereNull('ea.job_request_id')
                    ->orWhere('ea.job_request_id', '!=', $job_request_id);
                })
                // ->whereNotExists(function ($q) use ($job_request_id) {
                //     $q->select(DB::raw(1))
                //     ->from('egc_applicant as ea2')
                //     ->whereColumn('ea2.candidate_id', 'ic.sno')
                //     ->where('ea2.job_request_id', $job_request_id);
                // })
                ->select([
                    'ic.sno as candidate_id',
                    'ea.sno as applicant_id',
                    'ql.qualification_level_name as qualification_name',
                    'ea.applicant_name',
                    'ea.recruitment_id',
                    'ea.job_request_id',
                    'ea.job_role_id',
                    'ea.mobile',
                    'ea.email',
                    'ea.gender',
                    'ea.marital_status_id',
                    'ea.qualification_id',
                    'ea.major',
                    'ea.experience_id',
                    'ea.experience_count',
                    'ea.source_id',
                    'ea.drive_data',
                    'ea.old_data',
                ])
                ->orderBy('ea.applicant_name');

            if ($request->filled('search')) {
                $search = $request->search;
                $query->where(function ($q) use ($search) {
                    $q->where('ea.applicant_name', 'like', "%$search%")
                    ->orWhere('ea.mobile', 'like', "%$search%")
                    ->orWhere('ea.email', 'like', "%$search%");
                });
            }

            if ($request->filled('qualification')) {
                $query->where('ea.qualification_id', $request->qualification);
            }

            if ($request->filled('gender')) {
                $query->where('ea.gender', $request->gender);
            }

            if ($request->filled('experience')) {
                $query->where('ea.experience_id', $request->experience);
            }


            $data = $query
                ->offset($offset)
                ->limit($limit)
                ->get();
                $data->transform(function ($item) {

    $qualification = null;
    $item->final_experience = 'FRESHER';
$item->final_experience_type = 1;

    // ✅ 1. NEW SYSTEM (priority)
    if (!empty($item->qualification_name)) {
        $qualification = strtoupper(trim($item->qualification_name));
    }

    if (!empty($item->experience_id) && $item->experience_id == 2) {

    $item->final_experience_type = 2;

    if (!empty($item->experience_count)) {
        $item->final_experience = $item->experience_count . ' Years';
    }
}
    

    // ✅ 2. OLD DATA OVERRIDE (if exists)
    if (!empty($item->old_data)) {
        try {
            $old = json_decode($item->old_data, true);

            if (!empty($old['qualification_id'])) {

                switch ((int)$old['qualification_id']) {
                    case 5:
                        $qualification = 'UG';
                        break;
                    case 4:
                        $qualification = 'PG';
                        break;
                    case 3:
                        $qualification = 'PROFESSIONAL DEGREE';
                        break;
                    case 2:
                        $qualification = 'DOCTORATE';
                        break;
                    case 1:
                        $qualification = 'HSC';
                        break;
                    default:
                        $qualification = 'OTHERS';
                }
            }

            // 🔥 EXTRA: string fallback
            if (!empty($old['qualification_name'])) {
                $name = strtoupper($old['qualification_name']);

                if (str_contains($name, 'UG') || str_contains($name, 'BACHELOR')) {
                    $qualification = 'UG';
                } elseif (str_contains($name, 'PG') || str_contains($name, 'MASTER')) {
                    $qualification = 'PG';
                }
            }

            if (!empty($old['experience_name'])) {

            $expText = strtoupper($old['experience_name']);

            // Extract number
            if (preg_match('/\d+/', $expText, $match)) {
                $item->final_experience = $match[0] . ' Years';
                $item->final_experience_type = 2;
            } elseif (str_contains($expText, 'FRESHER')) {
                $item->final_experience = 'Fresher';
                $item->final_experience_type = 1;
            }
        }

        } catch (\Exception $e) {
            // ignore
        }
    }

    // ✅ 3. FINAL FALLBACK
    if (!$qualification) {
        $qualification = 'OTHERS';
    }

    $item->final_qualification = $qualification;

    return $item;
});

            $executionTime = microtime(true) - $startTime;

            return response()->json([
                'data' => $data,
                'next_offset' => $data->count() === $limit ? $offset + $limit : null,
                'time' => $executionTime
            ]);
        return response()->json([
            'data' => [],
            'next_offset' => $data->count() === $limit ? $offset + $limit : null,
            'time'=> $executionTime
        ]);
    
        return response()->json([
            'data' => $data,
            'next_offset' => $data->count() === $limit ? $offset + $limit : null
        ]);
    }


    public function majorListByQualification(Request $request)
    {
        $qualification_id = $request->qualification_id;
        $majorList = MajorModel::where('status', 0)->where('qualification_id', $qualification_id)->orderBy('major_name', 'asc')->get();

        return response([
        'status' => 200,
        'message' => null,
        'error_msg' => null,
        'data' => $majorList
        ], 200);
    }
     public function AddJobCandidate(Request $request)
    {
        // return $request;
       $request->validate([
            'candidate_name' => 'required',
            'candidate_mobile' => 'required',
            'candidate_email' => 'required',
            'candidate_gender'   => 'required|integer',
            'candidate_marital_status' => 'nullable|max:51200'
        ]);
        DB::beginTransaction();

        
        try {
            $resumeFile = null;
            $resumeUrl = null;
            $fullName        = $request->candidate_name;
            $mobile_no       = $request->candidate_mobile;
            $email_id        = $request->candidate_email;
            $gender          = $request->candidate_gender;
            $job_request_id  = $request->apply_job_request_id;
            $apply_applicant_id  = $request->apply_applicant_id;
            $jobRequestdata =  JobRequestModel::where('sno', $job_request_id)->first();

            $candidateData =  ApplicantModel::where('sno', $apply_applicant_id)->first();
            $job_role_id     = $jobRequestdata->job_role_id;
            $marital_status  = $request->candidate_marital_status;
            $qualification   = $request->candidate_qualification;
            $major           = $request->candidate_major;
            $OtherQualification           = $request->candidate_other_qualify;
            $exper_type      = $request->candidate_exper_type;
            $exper_count     = $request->candidate_exper_count ?? 0;
            $resume_check     = $request->resume_check ?? 0;
            $source          = $request->source_name;
            $ipAddress = $request->ip();
            $resumeText = null;
            $userId = auth()->user()->user_id;
            $drive_data=[];

            if($candidateData){
                $candidate_id = $candidateData->candidate_id;
                $candidate = InterviewCandidateModel::where('sno', $candidate_id)->first();
                $candidate->full_name =$fullName;
                // $candidate->mobile =$mobile_no;
                // $candidate->email =$email_id;
                $candidate->update();
            }else{
                $candidate = InterviewCandidateModel::updateOrCreate(
                ['mobile'    => $mobile_no],
                [
                    'full_name' => $fullName,
                    'email'     => $email_id,
                ]);

                $candidate_id = $candidate->sno;
            }
            // return $candidate;
            $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
            $year = date('y');

            if (!$lastApplicant) {
                $applicant_id = "EGCJA-0001-{$year}";
            } else {
                preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
                $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
                $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
            }

            

            if($resume_check == 0){
                
                if ($request->hasFile('upload_resume')) {
                    $file = $request->file('upload_resume');
                    $extension = $file->getClientOriginalExtension();

                    $folderPath = public_path('job_applications/resume_files/');

                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true);
                    }

                    // Unique filename
                    $resumeFile = $applicant_id . '.' . $extension;

                    $file->move($folderPath, $resumeFile);
                    $filePath = $folderPath . $resumeFile;
                    $resumeText = $this->extractResumeText($filePath);
                    
                    
                    // if (file_exists($filePath)) {
                    //     $drive_data = $this->UploadFileInDrive($resumeFile);
                    // }
                }
            }else{
                $drive_old =$candidateData->drive_data;
                $drive_data = $drive_old ? json_decode($drive_old) : null;
               if ($drive_data && !isset($drive_data->errors) && isset($drive_data->webViewLink)) {
                    $attachment_link = $drive_data->webViewLink;
                } else {
                    $attachment_link = null;
                }
                if($candidateData->resume_text){
                    $resumeText =$candidateData->resume_text;
                }else{
                    if ($drive_data && isset($drive_data->file_id)) {
                        // $resumeText = $this->extractResumeTextFromDrive($drive_data->file_id);
                        $resumeText = $this->extractResumeTextFromDrive($drive_data->file_id);
                    } else if ($candidateData->attachment) {
                        $resumeText = $this->extractResumeText(public_path('job_applications/resume_files/' . $candidateData->attachment));
                    }
                }
                
                
                $resumeFile=$candidateData->attachment;
                // $resumeText = $this->extractResumeText($attachment_link);
                
            }
            //    return $resumeText;

               function cleanUtf8($value)
                {
                    if (is_array($value)) {
                        return array_map('cleanUtf8', $value);
                    }

                    if (is_string($value)) {
                        return mb_convert_encoding($value, 'UTF-8', 'UTF-8');
                    }

                    return $value;
                }
                $resumeText  = cleanUtf8($resumeText);

                $majorData=DB::table('egc_major')->where('sno',$major)->first();

                
                if($major == 'Others'){
                    $majorName=$OtherQualification;
                }else{
                     $majorName=$majorData->major_name;
                }
               
              $applicant=ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'candidate_id'      => $candidate_id,
                'applicant_name'    => $fullName,
                'job_request_id'       => $job_request_id,
                'job_role_id'       => $job_role_id,
                'mobile'            => $mobile_no,
                'email'             => $email_id,
                'attachment'        => $resumeFile,
                'ipaddress'         => $ipAddress ?? null,
                'resume_text'       => $resumeText ?? NULL,
                'gender'            => $gender,
                'marital_status_id' => $marital_status,
                'qualification_id'  => $qualification,
                'major'             => $major,
                // 'other_qualification' => $OtherQualification ?? NULL,
                'experience_id'     => $exper_type,
                'experience_count'  => $exper_count,
                'source_id'         => $source,
                'shortlist_check'   => 1,
                'applicant_status'   => 3,
                'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
                'created_by'       => $userId,
                'updated_by'       => $userId,
            ]);
            
            //  if($applicant){
                $qualificationName = "Not provided"; 
                $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

                $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
                    ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
                    ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$job_request_id)->first();
                // $promptTemplate = "
                // Act as an ATS + hiring manager.

                // I will provide a Job Description and a Resume.

                // Analyze the resume against the job role and generate a structured evaluation using metrics.

                // Your output MUST include:

                // 1. Overall Match Score (0–100%)
                // 2. ATS Keyword Match Score (0–100%)
                // 3. Skills Alignment Score (0–100%)
                // 4. Experience Relevance Score (0–100%)
                // 5. Impact & Metrics Score (0–100%)
                // (Check if the resume includes measurable achievements like %, $, time saved, growth, efficiency gains)
                // 6. Role Responsibility Match Score (0–100%)

                // 7. Missing Keywords / Skills (list them)
                // 8. Strengths (what fits the role well)
                // 9. Weaknesses / Gaps (what may block selection)
                // 10. Top 5 Resume Improvements (specific edits)
                // 11. Rewrite 2–3 strongest bullet points in an achievement-focused format tailored to the role
                // 12. Suggest an optimized Professional Summary (3–4 lines) aligned with the job description.

                // Important Rules:
                // - Be strict and realistic like a recruiter.
                // - Highlight weak sections clearly.
                // - Suggest improvements using job-specific keywords.
                // - Output in a clean table + bullet points.
                // - Do NOT add unnecessary explanations.

                
                // Job Description is provided below:
                // {{JOB_DESCRIPTION}}
                // Resume is provided below:
                // {{RESUME_TEXT}}
                // ";

                $promptTemplate = "
                    Act as an ATS + hiring manager.

                    I will provide a Job Description and a Resume.

                    Analyze the resume against the job role and generate a structured evaluation using metrics.

                    Your output MUST include:

                    1. Overall Match Score (0–100%)
                    2. ATS Keyword Match Score (0–100%)
                    3. Skills Alignment Score (0–100%)
                    4. Experience Relevance Score (0–100%)
                    5. Impact & Metrics Score (0–100%)
                    (Check if the resume includes measurable achievements like %, $, time saved, growth, efficiency gains)
                    6. Role Responsibility Match Score (0–100%)

                    7. Missing Keywords / Skills (list them)
                    8. Strengths (what fits the role well)
                    9. Weaknesses / Gaps (what may block selection)
                    10. Top 5 Resume Improvements (specific edits)
                    11. Rewrite 2–3 strongest bullet points in an achievement-focused format tailored to the role
                    12. Suggest an optimized Professional Summary (3–4 lines) aligned with the job description.

                    Important Rules:
                    - Be strict and realistic like a recruiter.
                    - Highlight weak sections clearly.
                    - Suggest improvements using job-specific keywords.
                    - Do NOT add unnecessary explanations.

                    VERY IMPORTANT:
                    Return the response ONLY in valid JSON format using this structure:

                    {
                    \"overall_match_score\": 0,
                    \"ats_keyword_match_score\": 0,
                    \"skills_alignment_score\": 0,
                    \"experience_relevance_score\": 0,
                    \"impact_metrics_score\": 0,
                    \"role_responsibility_match_score\": 0,
                    \"missing_keywords\": [],
                    \"strengths\": [],
                    \"weaknesses\": [],
                    \"resume_improvements\": [],
                    \"rewritten_bullets\": [],
                    \"optimized_summary\": \"\"
                    }

                    Job Description is provided below:
                    {{JOB_DESCRIPTION}}

                    Resume is provided below:
                    {{RESUME_TEXT}}
                    ";

                $prompt = str_replace(
                        [
                            '{{JOB_DESCRIPTION}}',
                            '{{RESUME_TEXT}}',
                        ],
                        [
                            $jobRequest->job_description,
                            $resumeText ?? 'Resume not available',
                        ],
                        $promptTemplate
                    );
                //     $promptTemplate = "
                // You are an AI HR screening assistant.
                // Your task is to evaluate how well a candidate matches a job requirement.
                // The resume content is PRIMARY source of truth.
                // Form input data is SECONDARY.

                // Return ONLY valid JSON as below:

                // {
                // \"match_status\": 0, 
                // \"match_score\": 0, 
                // \"matched_skills\": [], 
                // \"missing_skills\": [], 
                // \"experience_analysis\": \"short sentence\", 
                // \"education_analysis\": \"short sentence\", 
                // \"overall_summary\": \"1-2 sentence professional HR summary\"
                // }

                // STRICT RULES:
                // - Resume text has higher priority than form data.
                // - If resume is empty or unreadable, base decision on form data.
                // - Do NOT overrate candidates.
                // - No markdown or extra text.
                // - Output must be valid parsable JSON.

                // JOB DETAILS:
                // Role: {{JOB_ROLE_NAME}}
                // Description: {{JOB_DESCRIPTION}}
                // Required Experience: {{REQUIRED_EXPERIENCE}}
                // Required Skills: {{REQUIRED_SKILLS}}

                // CANDIDATE DATA:
                // Name: {{FULL_NAME}}
                // Qualification: {{QUALIFICATION}}
                // Major: {{MAJOR}}
                // Experience Type: {{EXPERIENCE_TYPE}}
                // Experience Count: {{EXPERIENCE_COUNT}}
                // Resume Content: {{RESUME_TEXT}}
                // ";

                //     $prompt = str_replace(
                //         [
                //             '{{JOB_ROLE_NAME}}',
                //             '{{JOB_DESCRIPTION}}',
                //             '{{REQUIRED_EXPERIENCE}}',
                //             '{{REQUIRED_SKILLS}}',
                //             '{{FULL_NAME}}',
                //             '{{QUALIFICATION}}',
                //             '{{MAJOR}}',
                //             '{{EXPERIENCE_TYPE}}',
                //             '{{EXPERIENCE_COUNT}}',
                //             '{{RESUME_TEXT}}',
                //         ],
                //         [
                //             $jobRequest->job_role_name,
                //             $jobRequest->job_description,
                //             $jobRequest->experience,
                //             $jobRequest->required_skills,
                //             $applicant->applicant_name,
                //             $qualificationName,
                //             $majorName,
                //             $experTypeText,
                //             $applicant->experience_count,
                //             $applicant->resume_text ?? 'Resume not available',
                //         ],
                //         $promptTemplate
                //     );
                
                // $aiData = $this->getAIFromHuggingFace($prompt);
                $aiResponse = $this->getAIFromHuggingFace($prompt);
                // if (empty($aiData)) {
                //     $aiData = $this->getAiFromOpenRouter($prompt);
                // }

                // return $aiData;
                // if($aiData){
                //     ApplicantModel::where('sno', $applicant->sno)->update([
                //         'match_status' => $aiData['match_status'] ?? 0,
                //         'match_score'  => $aiData['match_score'] ?? 0,
                //         'ai_response'  => $aiData ?? null,
                //         'ai_summary'   => $aiData['overall_summary'] ?? null,
                //     ]);
                // }

                // return $aiResponse;
                ApplicantModel::where('sno', $applicant->sno)->update([
                    'ai_response' => $aiResponse
                ]);
            //  }

            //  $interview_schedule = InterviewScheduleModel::where('status', '!=', 2)
            //     ->where('job_request_id', $job_request_id)
            //     ->first();

            //     if ($interview_schedule) {

            //         $interview_stage = InterviewScheduleStageModel::where('status', '!=', 2)
            //             ->where('interview_schedule_id', $interview_schedule->sno)
            //             ->where('stage_order', 1)
            //             ->first();

            //         if ($interview_stage) {
            //             $shortlist_students = [strval($applicant->sno)];
            //             // return $shortlist_students;
            //             $interview_stage->shortlist_applicant_ids = !empty($shortlist_students)
            //                 ? json_encode($shortlist_students)
            //                 : null;

            //             $interview_stage->save();
            //         }
            //     }

            $interview_schedule = InterviewScheduleModel::where('status','!=',2)
                ->where('job_request_id',$job_request_id)
                ->first();

            if($interview_schedule){

                $interview_stage = InterviewScheduleStageModel::where('status','!=',2)
                    ->where('interview_schedule_id',$interview_schedule->sno)
                    ->where('stage_order',1)
                    ->first();

                if($interview_stage){

                    // existing shortlisted ids
                    $existing = [];

                    if(!empty($interview_stage->shortlist_applicant_ids)){
                        $existing = json_decode($interview_stage->shortlist_applicant_ids, true);
                    }

                    // ensure array
                    if(!is_array($existing)){
                        $existing = [];
                    }

                    // add new applicant if not exists
                    if(!in_array(strval($applicant->sno), $existing)){
                        $existing[] = strval($applicant->sno);
                    }

                    // save updated list
                    $interview_stage->shortlist_applicant_ids = json_encode($existing);

                    $interview_stage->save();
                }
            }
            
            // return response()->json([
            //         'status'         => 401,
            //         'message'        => 'Job application submitted successfully!',
            //         'data' => $resumeText,
            //     ]);
            $payload = [
                'applicant_id'=>$applicant->sno,
                'stage'=>'Applied',
                'job_request_id'=>$applicant->job_request_id,
                'interview_stage_id'=> 0,
                'interview_session_id'=> 0,
                'staff_id'=> 0,
                'created_by'=>$userId,
                'updated_by'=>$userId,
                
            ];
            $saveLog = $this->applicantLogCreate($payload);
            if ($applicant->email) {
                $stages = InterviewScheduleStageModel::select(
                            'egc_interview_schedule_stage.*',
                            'egc_interview_category.interview_category_name',
                            'egc_interview_mode.interview_mode_name',
                    )
                    ->join('egc_interview_schedule', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
                    ->where('egc_interview_schedule.job_request_id', $applicant->job_request_id)
                    ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
                    ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
                    ->orderBy('stage_order','asc')
                    ->first();

                $emailTemplate_id =3; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;
                $hr_mobile = $branch->hr_head_no;
                $hr_email = $branch->hr_head_mail_id;
                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }
                $interview_date = date('d-M-Y', strtotime('+3 days'));
                $dynamicSubject = str_replace('#otp', '000000', $emailTemplate->email_name);

                $content = str_replace('#candidate_name', $applicant->applicant_name ?? 'Candidate', $content);
                $content = str_replace('#interview_type', $stages->interview_category_name ?? 'Preliminary', $content);
                $content = str_replace('#interview_mode', $stages->interview_mode_name ?? 'Video', $content);
                $content = str_replace('#interview_date',$interview_date ?? '-' , $content);
                $content = str_replace('#interview_link',$stages->shareLink ?? '#', $content);
                $content = str_replace('#hr_contact',  $hr_mobile ?? '8220011465', $content);
                $content = str_replace('#hr_email',  $hr_email ?? 'hrelysiumgroups@gmail.com', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $hr_mobile,
                      'branchemail' => $hr_email, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $hr_mobile ?? '8220011465',
                  ];
        
                $to_address = $applicant->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups ';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));
               

            }
            DB::commit();

            return response()->json([
                'status'         => 200,
                'message'        => 'candidate Add successfully!',
            ]);
        }catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status'  => false,
                'message' => 'Failed to Add Candidate',
                'error'   => $e->getMessage()
            ], 500);
        }
        
        return response()->json([
            'status'         => 200,
            'message'        => 'Job application submitted successfully!',
            'application_id' => base64_encode($applicant->sno),
        ]);
    }


    public function shortenUrl($longUrl,$channelId)
    {
        $response = Http::withToken('aFLQFlykraqpANsi')
            ->post('https://chotta.link/api/url/add', [
                'url' => $longUrl
            ]);
    
        if ($response->successful() && isset($response['shorturl'])) {
            
            $shortUrl = $response['shorturl'];
            $urlId =$response['id'];
            
            $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

            $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
    
            if ($assignResponse->successful()) {
                return $response; // success
            }
        }
        
    
        return null;
    }

    // private function extractResumeText(string $filePath): string
    // {
       
    //     $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
    //     $text = '';
    //     // return $extension;
    //     try {

    //         /* ===== PDF ===== */
    //         if ($extension === 'pdf') {
    //             // return $extension;
    //             $parser = new PdfParser();
    //             $pdf = $parser->parseFile($filePath);
    //             //  return $pdf->getText();
    //             $text = $pdf->getText();
    //         }

    //         /* ===== DOC / DOCX ===== */
    //         if (in_array($extension, ['doc', 'docx'])) {

    //             $phpWord = IOFactory::load($filePath);

    //             foreach ($phpWord->getSections() as $section) {
    //                 foreach ($section->getElements() as $element) {

    //                     if (method_exists($element, 'getText')) {
    //                         $text .= $element->getText() . ' ';
    //                     }

    //                     if (method_exists($element, 'getElements')) {
    //                         foreach ($element->getElements() as $child) {
    //                             if (method_exists($child, 'getText')) {
    //                                 $text .= $child->getText() . ' ';
    //                             }
    //                         }
    //                     }
    //                 }
    //             }
    //         }

    //     } catch (\Exception $e) {
    //         \Log::error('Resume extraction failed: ' . $e->getMessage());
    //     }

    //     // Cleanup text
    //     return trim(preg_replace('/\s+/', ' ', $text));
    // }
    private function extractResumeText(string $filePath): string
    {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $text = '';

        try {
            switch ($extension) {
                case 'pdf':
                    $parser = new \Smalot\PdfParser\Parser();
                    $pdf = $parser->parseFile($filePath);
                    $text = (string) $pdf->getText();

                    if (mb_strlen(trim($text)) < 50 && method_exists($this, 'extractPdfWithOCR')) {
                        $text = (string) $this->extractPdfWithOCR($filePath);
                    }
                    break;

                case 'doc':
                case 'docx':
                    $text = $this->extractPhpWordResumeText($filePath);
                    break;

                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'webp':
                case 'bmp':
                case 'gif':
                case 'tif':
                case 'tiff':
                    if (method_exists($this, 'extractTextWithOCR')) {
                        $text = (string) $this->extractTextWithOCR($filePath);
                    }
                    break;
            }
        } catch (\Throwable $e) {
            \Log::error('Resume extraction failed', [
                'file' => $filePath,
                'extension' => $extension,
                'error' => $e->getMessage(),
            ]);
            $text = '';
        }

        return $this->normalizeResumeExtractedText($text);
    }

    private function extractPhpWordResumeText(string $filePath): string
    {
        $word = \PhpOffice\PhpWord\IOFactory::load($filePath);
        $parts = [];

        foreach ($word->getSections() as $section) {
            foreach ($section->getElements() as $element) {
                $value = $this->extractPhpWordElementText($element);
                if ($value !== '') {
                    $parts[] = $value;
                }
            }
        }

        return implode("\n", $parts);
    }

    private function extractPhpWordElementText($element): string
    {
        if ($element === null) {
            return '';
        }

        if (is_string($element) || is_numeric($element)) {
            return trim((string) $element);
        }

        $parts = [];

        if (method_exists($element, 'getText')) {
            try {
                $value = $element->getText();

                if (is_string($value) || is_numeric($value)) {
                    $value = trim((string) $value);
                    if ($value !== '') {
                        $parts[] = $value;
                    }
                } elseif (is_object($value) && $value !== $element) {
                    $nested = $this->extractPhpWordElementText($value);
                    if ($nested !== '') {
                        $parts[] = $nested;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord getText extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getElements')) {
            try {
                foreach ($element->getElements() as $child) {
                    $childText = $this->extractPhpWordElementText($child);
                    if ($childText !== '') {
                        $parts[] = $childText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord child extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getRows')) {
            try {
                foreach ($element->getRows() as $row) {
                    $rowText = $this->extractPhpWordElementText($row);
                    if ($rowText !== '') {
                        $parts[] = $rowText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord row extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if (method_exists($element, 'getCells')) {
            try {
                foreach ($element->getCells() as $cell) {
                    $cellText = $this->extractPhpWordElementText($cell);
                    if ($cellText !== '') {
                        $parts[] = $cellText;
                    }
                }
            } catch (\Throwable $e) {
                \Log::debug('PhpWord cell extraction warning', [
                    'element' => is_object($element) ? get_class($element) : gettype($element),
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return trim(implode(' ', $parts));
    }

    private function normalizeResumeExtractedText(?string $text): string
    {
        $text = (string) $text;
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text) ?? $text;
        $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;

        return trim($text);
    }

    public function extractResumeTextFromDrive(string $fileId): string
    {
        
        try {
            $filePath = $this->googleDriveService->downloadFile($fileId);

            $mime = mime_content_type($filePath);

            $extension = match ($mime) {
                'application/pdf' => 'pdf',
                'application/msword' => 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                default => throw new Exception("Unsupported MIME type: {$mime}")
            };

            $finalPath = $filePath . '.' . $extension;
            rename($filePath, $finalPath);

            $text = $this->extractResumeText($finalPath);

            unlink($finalPath);

            return $text;

        } catch (Exception $e) {
            Log::error('Resume extraction failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            return '';
        }
    }

    private function getAiFromOpenRouter($prompt)
    {
        $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 
        $primaryApiKey = '-'; 
        $maxTokens = 1000;
        $aiTimeout = 60; 

        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:free", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
      
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);
        }
        
        // return $response;
        // Parse Response
       if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            return $this->safeJsonDecode($content);
        }

       return $this->defaultAiData();
    }
    private function getAIFromHuggingFace($prompt)
    {
        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions'; 
        $primaryApiKey = $this->HuggingFaceCretential(); 
        $maxTokens = 1000;
        $aiTimeout = 60; 
        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:nebius", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
        
        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:featherless-ai",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);

            if($response->failed()){
              $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                  'Authorization' => "Bearer $primaryApiKey",
                  'Content-Type' => 'application/json',
                  "X-Title" => "JobApplicationAnalyses",
              ])->post($primaryApiUrl, [
                  'model' => "deepseek-ai/DeepSeek-R1:novita",
                  'messages' => [['role' => 'user', 'content' => $prompt]],
                  'max_tokens' => $maxTokens, 
              ]);
            }

        }
        // return $primaryApiKey ;
        if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            $content = trim($content);
            $content = preg_replace('/^```json\s*/', '', $content);
            $content = preg_replace('/^```\s*/', '', $content);
            $content = preg_replace('/\s*```$/', '', $content);
            return $content;
            // return $this->safeJsonDecode($content);
        }
        // else{
        //     return $this->getAiFromOpenRouter($prompt);
        // }


        // return $this->defaultAiData();
    }

    private function safeJsonDecode($content)
    {
        $content = trim($content);

        // Extract JSON using regex
        if (preg_match('/\{.*\}/s', $content, $matches)) {
            $json = json_decode($matches[0], true);
            if (is_array($json)) {
                return $json;
            }
        }
                        
        // Fallback
        return $this->defaultAiData();
    }

    private function defaultAiData()
    {
        return [
            'match_status' => 0,
            'match_score' => 0,
            'matched_skills' => [],
            'missing_skills' => [],
            'experience_analysis' => 'Could not evaluate',
            'education_analysis' => 'Could not evaluate',
            'overall_summary' => 'Could not evaluate',
        ];
    }


     private function UploadFileInDrive($attachment)
    {
        $uploadedFiles = [];
        $errors = [];

        if (!$attachment) {
            return ['error' => 'No attachment provided'];
        }

        $filePath = public_path('job_applications/resume_files/' . $attachment);

        // Check if the file exists on the server
        if (!file_exists($filePath)) {
            $errors[] = [
                'attachment' => $attachment,
                'error' => 'File not found on server'
            ];
            return ['errors' => $errors];  // Return errors in case file is not found
        }

        try {
            $uploadedFile = new UploadedFile(
                $filePath,
                $attachment,
                mime_content_type($filePath),
                null,
                true
            );

            // Upload the file to Google Drive
            $driveFile = $this->googleDriveService->upload(
                $uploadedFile,
                env('GOOGLE_DRIVE_FOLDER_ID') // Folder ID is taken from .env
            );

            // Check if the file was uploaded successfully
            if ($driveFile) {
                $uploadedFiles = [
                    'file_name' => $driveFile->name,
                    'file_id' => $driveFile->id,
                    'webViewLink' => $driveFile->webViewLink ?? null
                ];
            } else {
                $errors[] = ['error' => 'Google Drive upload failed'];
            }
        } catch (\Exception $e) {
            // Catch any exception during the upload process
            $errors[] = ['error' => 'Error uploading file to Google Drive: ' . $e->getMessage()];
        }

        // If there are errors, return them; otherwise, return the uploaded file details
        if (!empty($errors)) {
            return ['errors' => $errors];
        }

        return $uploadedFiles;
    }

    public function preview(Request $request, string $fileId)
    {
        return $this->googleDriveService->streamFile($fileId);
    }

    // public function getInterviewScheduleByJobId(Request $request)
    // {
    //     $request->validate([
    //         'job_request_id' => 'required|integer'
    //     ]);

    //     $schedule = InterviewScheduleModel::where('egc_interview_schedule.job_request_id', $request->job_request_id)
    //         ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
    //          ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
    //         ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
    //         ->select(
    //             'egc_interview_schedule.*',
    //             'egc_job_role.job_position_name as job_role_name',
    //             'egc_entity.entity_name',
    //             'egc_entity.entity_short_name',
    //             'egc_entity.entity_base_color',
    //             'egc_entity.entity_logo',
    //             'egc_entity.company_id',
    //         )
    //         ->first();

    //     $stages=InterviewScheduleStageModel::where('egc_interview_schedule_stage.interview_schedule_id',$schedule->sno)
    //             ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
    //             ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
    //             ->select(
    //                 'egc_interview_schedule_stage.*',
    //                 'egc_interview_category.interview_category_name',
    //                 'egc_interview_mode.interview_mode_name',
    //             )
    //             ->get();
    //     foreach($stages as $stg){
    //         $question =InterviewScheduleQuestionModel::where('egc_interview_schedule_questions.interview_schedule_stage_id',$stg->sno)
    //                     ->join('egc_interview_question','egc_interview_question.sno','=','egc_interview_schedule_questions.interview_question_id')
    //                     ->select(
    //                         'egc_interview_schedule_questions.*',
    //                         'egc_interview_question.field_name as question',
    //                         'egc_interview_question.field_option as question_options',
    //                         'egc_interview_question.field_value as question_type',
    //                         )
    //                         ->get();
    //         $stg->questions=$question;
    //     }

    //     $schedule->stages=$stages;
    //     if (!$schedule) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Schedule not found'
    //         ]);
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'data' => $schedule
    //     ]);
    // }

    public function getInterviewScheduleByJobId(Request $request)
    {
        $validated = $request->validate([
            'job_request_id' => 'required|integer'
        ]);

        $schedule = InterviewScheduleModel::query()
            ->where('egc_interview_schedule.job_request_id', $validated['job_request_id'])
            ->join('egc_job_request', 'egc_job_request.sno', '=', 'egc_interview_schedule.job_request_id')
            ->join('egc_job_role', 'egc_job_request.job_role_id', '=', 'egc_job_role.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', '=', 'egc_entity.sno')
            ->select([
                'egc_interview_schedule.*',
                'egc_job_role.job_position_name as job_role_name',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_entity.entity_base_color',
                'egc_entity.entity_logo',
                'egc_entity.company_id',
            ])
            ->first();

        if (!$schedule) {
            return response()->json([
                'status' => 404,
                'message' => 'Interview schedule not found'
            ], 404);
        }

        /** ---------------- STAGES ---------------- */
        $stages = InterviewScheduleStageModel::query()
            ->where('egc_interview_schedule_stage.interview_schedule_id', $schedule->sno)
            ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', '=', 'egc_interview_category.sno')
            ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', '=', 'egc_interview_mode.sno')
            ->select([
                'egc_interview_schedule_stage.*',
                'egc_interview_category.interview_category_name',
                'egc_interview_mode.interview_mode_name',
            ])
            ->get();

        /** ---------------- QUESTIONS (Single Query) ---------------- */
        $questions = InterviewScheduleQuestionModel::query()
            ->join(
                'egc_interview_question',
                'egc_interview_question.sno',
                '=',
                'egc_interview_schedule_questions.interview_question_id'
            )
            ->select([
                'egc_interview_schedule_questions.interview_schedule_stage_id',
                'egc_interview_schedule_questions.thinking_time',
                'egc_interview_schedule_questions.allowed_time',
                'egc_interview_schedule_questions.retakes',
                'egc_interview_question.field_name as question',
                'egc_interview_question.field_option as question_options',
                'egc_interview_question.field_value as question_type',
            ])
            ->get()
            ->groupBy('interview_schedule_stage_id');

        /** ---------------- MAP QUESTIONS TO STAGES ---------------- */
        $stages->transform(function ($stage) use ($questions) {
            $stage->questions = $questions[$stage->sno] ?? [];
            return $stage;
        });

        $schedule->stages = $stages;

        return response()->json([
            'status' => 200,
            'data' => $schedule
        ]);
    }

    private function applicantLogCreate($payload){

            $applicant=ApplicantLogModel::create([
                'applicant_id'      => $payload['applicant_id'],
                'stage'      => $payload['stage'],
                'job_request_id'    => $payload['job_request_id'],
                'interview_stage_id'       => $payload['interview_stage_id'],
                'interview_session_id'       => $payload['interview_session_id'],
                'staff_id'            => $payload['staff_id'],
                'updated_by'             => $payload['updated_by'],
                'created_by'        => $payload['created_by'],
            ]);
    }


    // Generate AI Skill Tags
    public function generateJobDescription (Request $request)
    {
        $jobRole = $request->input('job_role_name');
        $jobRoleId = $request->input('jobRoleId');
        $experience = $request->input('experience_years');
        $skills = $request->input('skills');
        $salary = $request->input('salary_range');
        $edit_id = $request->input('edit_id');

        // First try the fallback API
        $JobRequest = JobRequestModel::where('status','!=',2)
          ->where('job_role_id', $jobRoleId);
          if($edit_id){
          $JobRequest->where('sno','!=',$edit_id);
          }
          $JobRequest = $JobRequest->inRandomOrder()->first();
        $aiDescription = $JobRequest ? $JobRequest->job_description : '';
        // If fallback returns empty, use the main API
        if (empty($aiDescription)) {
          
            $aiDescription = $this->getAIFromHuggingFaceDescription($jobRole, $experience, $skills, $salary);  
           
        }
        
         

        return response()->json([
            'status' => 200,
            'data' => $aiDescription,
        ]);
    }


     private function getAIFromHuggingFaceDescription($jobRole, $experience, $skills, $salary)
    {
        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions'; 
        $primaryApiKey = $this->HuggingFaceCretential(); 
        $maxTokens = 1000;
        $aiTimeout = 60; // Consistent timeout

        // Define prompt (same as before)
        //   $prompt = "
        //     Generate a complete, professional Job Description for the role: '$jobRole'.

        //     STRICT OUTPUT RULES (FOLLOW EXACTLY):
        //     1. Return ONLY clean HTML — no markdown, no code blocks, no ```html, no ```json, no <html>, <body>, or wrapper <div>.
        //     2. The HTML MUST be compact with minimal spacing:
        //       - NO blank lines.
        //       - NO extra'\n\n' spacing between tags.
        //     3. Each section must immediately follow the previous tag without empty lines.
        //     4. The output MUST start directly with: <p><strong>Role Name</strong></p>

        //     HTML STRUCTURE TO FOLLOW (NO EXTRA SPACES, NO BLANK LINES):
        //     <p><strong>React Developer</strong></p>
        //     <h3>Job Overview</h3>
        //     <p>...</p>
        //     <h3>Key Responsibilities</h3>
        //     <ul><li>...</li></ul>
        //     <h3>Required Skills & Competencies</h3>
        //     <ul><li>...</li></ul>
        //     <h3>Qualifications</h3>
        //     <ul><li>...</li></ul>

        //     CONTENT RULES:
        //     - Use corporate, professional tone.
        //     - Use clean semantic HTML only (<p>, <h3>, <ul>, <li>).
        //     - NO extra newlines, NO indentation, NO spacing between tags.
        //     - All content must be production-ready and visually tight when inserted into a WYSIWYG editor.

        // ";

        $prompt = "
          Generate a complete, professional Job Description for the following requirements:
          - Role: '$jobRole'
          - Experience Required: $experience years
          - Required Skills: $skills
          - Salary Context: $salary

          STRICT OUTPUT RULES (MANDATORY):
            1. Return ONLY pure HTML. No markdown, no explanations.
            2. Output MUST be a SINGLE LINE string (no \\n, no line breaks).
            3. DO NOT use <br> tags anywhere.
            4. DO NOT add extra spaces between tags.
            5. Output MUST start EXACTLY with: <h4>Job Overview</h4>

          HTML STRUCTURE (FOLLOW EXACTLY):
            <h4>Job Overview</h4><p style='text-indent:25px;'>Professional summary for a $jobRole with $experience years of experience.</p><h4>Key Responsibilities</h4><ul><li>Relevant responsibility</li></ul><h4>Required Skills & Competencies</h4><ul><li>Relevant skills</li></ul><h4>Qualifications</h4><ul><li>Relevant qualifications</li></ul>

          CONTENT RULES:
            - Tone must be corporate and professional.
            - Responsibilities MUST match $experience years level (junior/mid/senior).
            - Use concise but meaningful bullet points.
            - Do NOT repeat skills unnecessarily.
            - Do NOT include placeholders like '...'.
      ";

        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobDescriptionGenerator",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:nebius", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);

        // !! FIX 2: REMOVE THIS LINE !!
        // return $response->json(); 
        
        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobDescriptionGenerator",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:featherless-ai",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);

            if($response->failed()){
              $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                  'Authorization' => "Bearer $primaryApiKey",
                  'Content-Type' => 'application/json',
                  "X-Title" => "JobDescriptionGenerator",
              ])->post($primaryApiUrl, [
                  'model' => "deepseek-ai/DeepSeek-R1:novita",
                  'messages' => [['role' => 'user', 'content' => $prompt]],
                  'max_tokens' => $maxTokens, 
              ]);
            }

        }
        
        // Parse Response
        if ($response->successful()) {
            $responseData = $response->json();
            
            if (isset($responseData['choices'][0]['message']['content'])) {
                $htmlDescription = $responseData['choices'][0]['message']['content'];
                return $htmlDescription; 
            }
        }

        return '';
    }

    private function HuggingFaceCretential(){
        $huggingApi = DB::table('egc_api_integration')->where('api_key','egc_huggingface_api_1')->where('status',0)->orderBy('sno', 'desc')->first();
          if($huggingApi){
            $apiFields = json_decode($huggingApi->api_fields, true);
            $accessToken = '';
            foreach ($apiFields as $field) {
                if ($field['key'] === 'api_key') {
                    $accessToken = $field['value'];
                }else{
                    $accessToken=null;
                }
            }
             
          }else{
            $accessToken=null;
          }
          return $accessToken;
    }


public function AddNewCandidate(Request $request)
{
    
    $request->validate([
        'candidate_name' => 'required',
        'candidate_mobile' => 'required',
        'candidate_email' => 'required',
        'candidate_gender'   => 'required|integer',
        'candidate_marital_status' => 'nullable|max:51200'
    ]);
    DB::beginTransaction();

    
    try {
        $resumeFile = null;
        $resumeUrl = null;
        $fullName        = $request->candidate_name;
        $mobile_no       = $request->candidate_mobile;
        $email_id        = $request->candidate_email;
        $gender          = $request->candidate_gender;
        $job_request_id  = $request->apply_job_request_id ?? NULL ;
        $apply_applicant_id  = $request->apply_applicant_id;
        $jobRequestdata =  JobRequestModel::where('sno', $job_request_id)->first();

        $candidateData =  ApplicantModel::where('sno', $apply_applicant_id)->first();
        $job_role_id     = NULL;
        $marital_status  = $request->candidate_marital_status;
        $qualification   = $request->candidate_qualification;
        $major           = $request->candidate_major;
        $OtherQualification           = $request->candidate_other_qualify;
        $exper_type      = $request->candidate_exper_type;
        $exper_count     = $request->candidate_exper_count ?? 0;
        $resume_check     = $request->resume_check ?? 0;
        $source          = $request->source_name;
        $description          = $request->description;
        $ipAddress = $request->ip();
        $resumeText = null;
        $userId = auth()->user()->user_id;
        $drive_data=[];

        
        $candidate = InterviewCandidateModel::updateOrCreate(
        ['mobile'    => $mobile_no],
        [
            'full_name' => $fullName,
            'email'     => $email_id,
        ]);

        $candidate_id = $candidate->sno;
        
        // return $candidate;
        $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
        $year = date('y');

        if (!$lastApplicant) {
            $applicant_id = "EGCJA-0001-{$year}";
        } else {
            preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
            $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
            $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
        }

        

            if($resume_check == 0){
                
                if ($request->hasFile('upload_resume')) {
                    $file = $request->file('upload_resume');
                    $extension = $file->getClientOriginalExtension();

                    $folderPath = public_path('job_applications/resume_files/');

                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true);
                    }

                    // Unique filename
                    $resumeFile = $applicant_id . '.' . $extension;

                    $file->move($folderPath, $resumeFile);
                    $filePath = $folderPath . $resumeFile;
                    $resumeText = $this->extractResumeText($filePath);
                    
                    
                    if (file_exists($filePath)) {
                        $drive_data = $this->UploadFileInDrive($resumeFile);
                    }
                }
            }
        

            function cleanUtf8($value)
            {
                if (is_array($value)) {
                    return array_map('cleanUtf8', $value);
                }

                if (is_string($value)) {
                    return mb_convert_encoding($value, 'UTF-8', 'UTF-8');
                }

                return $value;
            }
            $resumeText  = cleanUtf8($resumeText);

            $majorData=DB::table('egc_major')->where('sno',$major)->first();

            
            if($major == 'Others'){
                $majorName=$OtherQualification;
            }else{
                    $majorName=$majorData->major_name;
            }
            
            $applicant=ApplicantModel::create([
            'applicant_id'      => $applicant_id,
            'candidate_id'      => $candidate_id,
            'applicant_name'    => $fullName,
            'job_request_id'       => 0,
            'job_role_id'       => NULL,
            'mobile'            => $mobile_no,
            'email'             => $email_id,
            'attachment'        => $resumeFile,
            'ipaddress'         => $ipAddress ?? null,
            'resume_text'       => $resumeText ?? NULL,
            'gender'            => $gender,
            'marital_status_id' => $marital_status,
            'qualification_id'  => $qualification,
            'major'             => $major,
            // 'other_qualification' => $OtherQualification ?? NULL,
            'experience_id'     => $exper_type,
            'experience_count'  => $exper_count,
            'source_id'         => $source,
            'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
            'created_by'       => $userId,
            'updated_by'       => $userId,
            'description'       => $description,
        ]);
        
    
            $qualificationName = "Not provided"; 
            $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

            $promptTemplate = "
                Act as an ATS resume analyzer.

                I will provide a Resume.

                Analyze the resume and generate a structured evaluation using metrics.

                Your output MUST include:

                1. Overall Resume Quality Score (0–100%)
                2. ATS Keyword Strength Score (0–100%)
                3. Skills Quality Score (0–100%)
                4. Experience Quality Score (0–100%)
                5. Impact & Metrics Score (0–100%)
                (Check if the resume includes measurable achievements like %, $, time saved, growth, efficiency gains)

                6. Resume Structure & Clarity Score (0–100%)

                7. Missing Important Resume Elements (list them)
                8. Strengths of the Resume
                9. Weaknesses / Gaps in the Resume
                10. Top 5 Resume Improvements (specific edits)
                11. Rewrite 2–3 bullet points in an achievement-focused format
                12. Suggest an optimized Professional Summary (3–4 lines)

                Important Rules:
                - Be strict and realistic like a recruiter.
                - Highlight weak sections clearly.
                - Suggest improvements for a stronger resume.
                - Do NOT add unnecessary explanations.

                VERY IMPORTANT:
                Return the response ONLY in valid JSON format using this structure:

                {
                \"overall_resume_score\": 0,
                \"ats_keyword_strength_score\": 0,
                \"skills_quality_score\": 0,
                \"experience_quality_score\": 0,
                \"impact_metrics_score\": 0,
                \"resume_structure_score\": 0,
                \"missing_resume_elements\": [],
                \"strengths\": [],
                \"weaknesses\": [],
                \"resume_improvements\": [],
                \"rewritten_bullets\": [],
                \"optimized_summary\": \"\"
                }

                Resume is provided below:
                {{RESUME_TEXT}}
                ";

            $prompt = str_replace(
                [
                    '{{RESUME_TEXT}}',
                ],
                [
                    $resumeText ?? 'Resume not available',
                ],
                $promptTemplate
            );
            
            // $aiResponse = $this->getAIFromHuggingFace($prompt);

            // return $aiResponse;
            

            // ApplicantModel::where('sno', $applicant->sno)->update([
            //     'ai_response' => $aiResponse
            // ]);

        
        $payload = [
            'applicant_id'=>$applicant->sno,
            'stage'=>'New Candidate',
            'job_request_id'=>0,
            'interview_stage_id'=> 0,
            'interview_session_id'=> 0,
            'staff_id'=> 0,
            'created_by'=>$userId,
            'updated_by'=>$userId,
            
        ];
        $saveLog = $this->applicantLogCreate($payload);

        
        DB::commit();

        // return response()->json([
        //     'status'  => false,
        //     'message' => 'Failed to Add Candidate',
        //     'error'   => 'checking Candidate'
        // ], 500);

        return response()->json([
            'status'         => 200,
            'message'        => 'candidate Add successfully!',
        ]);
    }catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'status'  => false,
            'message' => 'Failed to Add Candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
    
    return response()->json([
        'status'         => 200,
        'message'        => 'Job application submitted successfully!',
        'application_id' => base64_encode($applicant->sno),
    ]);
}

}
