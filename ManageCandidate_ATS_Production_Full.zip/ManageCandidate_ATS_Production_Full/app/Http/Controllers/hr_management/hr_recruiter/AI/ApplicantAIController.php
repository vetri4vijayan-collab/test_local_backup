<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\CandidateServices\ApplicantRoleMatchingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\ApplicantModel;
use App\Services\CandidateServices\HuggingFaceRoleMatcherService;
use App\Services\CandidateServices\ApplicantAIService;
use Throwable;

class ApplicantAIController extends Controller
{
    protected ApplicantRoleMatchingService $matchingService;
    protected HuggingFaceRoleMatcherService $matcher;
    protected ApplicantAIService $service;

    public function __construct(
        ApplicantRoleMatchingService $matchingService,
        HuggingFaceRoleMatcherService $matcher,
        ApplicantAIService $service
    ) {
        $this->matchingService = $matchingService;
        $this->matcher = $matcher;
         $this->service = $service;
    }

    /**
     * AI match one applicant by egc_applicant.sno
     */
    public function matchBySno( Request $request,int $sno): JsonResponse {

        try {

            $result = $this->matchingService->matchApplicant($sno);

            return response()->json(
                $result,
                $result['status'] ? 200 : 422
            );

        } catch (Throwable $e) {

            Log::error(
                'Applicant AI Role Matching Error',
                [
                    'applicant_sno' => $sno,
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]
            );

            return response()->json([
                'status' => false,
                'message' => 'Unable to analyse applicant.',
                'err'=>$e->getMessage()
            ], 500);
        }
    }

    /**
     * Get stored AI analysis.
     */
    public function analysis(
        int $sno
    ): JsonResponse {

        try {

            $result = $this->matchingService
                ->getAnalysis($sno);

            return response()->json(
                $result,
                $result['status'] ? 200 : 404
            );

        } catch (Throwable $e) {

            Log::error(
                'Applicant AI Analysis Error',
                [
                    'applicant_sno' => $sno,
                    'message' => $e->getMessage(),
                ]
            );

            return response()->json([
                'status' => false,
                'message' => 'Unable to load AI analysis.'
            ], 500);
        }
    }

    /**
     * Bulk AI role matching.
     *
     * This is a normal authenticated web/AJAX endpoint,
     * not the old public API endpoint.
     */
    public function bulkMatch(
        Request $request
    ): JsonResponse {

        $validator = Validator::make(
            $request->all(),
            [
                'applicant_ids' => [
                    'nullable',
                    'array',
                    'max:500'
                ],

                'applicant_ids.*' => [
                    'integer',
                    'min:1'
                ],

                'batch_size' => [
                    'nullable',
                    'integer',
                    'min:1',
                    'max:10'
                ],

                'limit' => [
                    'nullable',
                    'integer',
                    'min:1',
                    'max:500'
                ],

                'force' => [
                    'nullable',
                    'boolean'
                ],
            ]
        );

        if ($validator->fails()) {

            return response()->json([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors()
            ], 422);
        }

        try {

            $result = $this->matchingService
                ->bulkMatch([
                    'applicant_ids' => $request->input(
                        'applicant_ids',
                        []
                    ),
                    'batch_size' => (int) $request->input(
                        'batch_size',
                        5
                    ),
                    'limit' => (int) $request->input(
                        'limit',
                        100
                    ),
                    'force' => (bool) $request->input(
                        'force',
                        false
                    ),
                ]);

            return response()->json(
                $result,
                $result['status'] ? 200 : 422
            );

        } catch (Throwable $e) {

            Log::error(
                'Bulk Applicant AI Matching Error',
                [
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]
            );

            return response()->json([
                'status' => false,
                'message' => 'Bulk AI matching failed.'
            ], 500);
        }
    }

        /**
     * Match Single Applicant
     */
    public function match(Request $request)
    {
        $request->validate([
            'applicant_id' => 'required'
        ]);

        try {

            $applicant = ApplicantModel::where(
                'applicant_id',
                $request->applicant_id
            )->first();

            if (!$applicant) {

                return response()->json([
                    'status' => false,
                    'message' => 'Applicant not found.'
                ],404);

            }

            /*
            |--------------------------------------------------------------------------
            | Resume Text
            |--------------------------------------------------------------------------
            */

            if (empty($applicant->resume_text)) {

                $resume = $this->extractResume($applicant);

                if (!$resume) {

                    return response()->json([
                        'status'=>false,
                        'message'=>'Resume text not found.'
                    ],422);

                }

                $applicant->resume_text = $resume;

                $applicant->save();
            }

            /*
            |--------------------------------------------------------------------------
            | AI Match
            |--------------------------------------------------------------------------
            */

            $result = $this->matcher
                ->matchApplicant($applicant);

            return response()->json($result);

        } catch (\Throwable $e) {

            Log::error(

                'Applicant AI',

                [

                    'message'=>$e->getMessage(),

                    'line'=>$e->getLine(),

                    'file'=>$e->getFile()

                ]

            );

            return response()->json([

                'status'=>false,

                'message'=>$e->getMessage()

            ],500);

        }

    }

    /**
     * Resume Extraction
     */
    private function extractResume(
        ApplicantModel $applicant
    )
    {
        $drive_old = $applicant->drive_data;

        $drive_data = $drive_old
            ? json_decode($drive_old)
            : null;

        if (
            $drive_data &&
            isset($drive_data->file_id)
        ) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeTextFromDrive(
                    $drive_data->file_id
                );

        }

        if ($applicant->attachment) {

            return app()
                ->make(\App\Http\Controllers\YourController::class)
                ->extractResumeText(

                    public_path(
                        'job_applications/resume_files/' .
                        $applicant->attachment
                    )

                );

        }

        return null;
    }

     public function show(int $id)
    {
        try {
            $result = $this->service->getApplicant($id);

            if (!$result['status']) {
                return response()->json($result,404);
            }

             $applicant = ApplicantModel::query()
                ->select([
                    'sno',
                    'applicant_id',
                    'applicant_name',
                    'question_answers',
                ])
                ->where('sno', $id)
                ->first();

            $answers = [];

            if ($applicant && !empty($applicant->question_answers)) {

                $decoded = json_decode(
                    $applicant->question_answers,
                    true
                );

                if (
                    json_last_error() === JSON_ERROR_NONE &&
                    is_array($decoded)
                ) {
                    $answers = $decoded;
                }
            }

            /* Normalize Answers*/

            $answers = collect($answers)
                ->map(function ($item) {

                    $answer = $item['answer'] ?? null;

                    if (is_array($answer)) {
                        $answer = array_values(
                            array_filter(
                                $answer,
                                fn ($value) =>
                                    $value !== null &&
                                    $value !== ''
                            )
                        );
                    }

                    return [
                        'question_id' => $item['question_id'] ?? null,
                        'question'    => $item['question'] ?? '',
                        'type'        => $item['type'] ?? '',
                        'answer'      => $answer,
                    ];
                })
                ->values()
                ->toArray();

            /*
            |--------------------------------------------------------------------------
            | Single Production Response
            |--------------------------------------------------------------------------
            */

            return response()->json([
                'status' => true,

                'data' => array_merge(
                    $result['data'],
                    [
                        'application_answers' => [
                            'has_answers' => count($answers) > 0,
                            'answer_count' => count($answers),
                            'answers' => $answers,
                        ],
                    ]
                ),
            ]);

        }

        catch(Throwable $e){

            \Log::error('Applicant AI View',[
                'applicant'=>$id,
                'message'=>$e->getMessage()
            ]);
            return response()->json([
                'status'=>false,
                'message'=>'Unable to load applicant.'
            ],500);
        }
    }

    
 /**
 * Applicant Application Questions & Answers
 */
public function applicationAnswers(int $id)
{
    try {

        $applicant = ApplicantModel::query()
            ->select([
                'sno',
                'applicant_id',
                'applicant_name',
                'question_answers',
            ])
            ->where('sno', $id)
            ->first();

        if (!$applicant) {
            return response()->json([
                'status'  => false,
                'message' => 'Applicant not found.',
            ], 404);
        }

        $answers = [];

        if (!empty($applicant->question_answers)) {

            $decoded = json_decode(
                $applicant->question_answers,
                true
            );

            if (
                json_last_error() === JSON_ERROR_NONE &&
                is_array($decoded)
            ) {
                $answers = $decoded;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Normalize answers for HR UI
        |--------------------------------------------------------------------------
        */

        $answers = collect($answers)
            ->map(function ($item) {

                $answer = $item['answer'] ?? null;

                if (is_array($answer)) {
                    $answer = array_values(
                        array_filter(
                            $answer,
                            fn ($value) =>
                                $value !== null &&
                                $value !== ''
                        )
                    );
                }

                return [
                    'question_id' => $item['question_id'] ?? null,
                    'question'    => $item['question'] ?? '',
                    'type'        => $item['type'] ?? '',
                    'answer'      => $answer,
                ];
            })
            ->values()
            ->toArray();

        return response()->json([
            'status' => true,

            'data' => [
                'applicant' => [
                    'id'   => $applicant->sno,
                    'code' => $applicant->applicant_id,
                    'name' => $applicant->applicant_name,
                ],

                'has_answers' => count($answers) > 0,

                'answer_count' => count($answers),

                'answers' => $answers,
            ],
        ]);

    } catch (\Throwable $e) {

        Log::error(
            'Applicant Application Answers',
            [
                'applicant' => $id,
                'message'   => $e->getMessage(),
                'line'      => $e->getLine(),
                'file'      => $e->getFile(),
            ]
        );

        return response()->json([
            'status'  => false,
            'message' => 'Unable to load application answers.',
        ], 500);
    }
}
}