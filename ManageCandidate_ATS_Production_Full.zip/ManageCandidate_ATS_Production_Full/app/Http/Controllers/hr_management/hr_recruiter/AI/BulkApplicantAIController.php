<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\CandidateServices\ApplicantBatchService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Throwable;

class BulkApplicantAIController extends Controller
{
    protected ApplicantBatchService $batchService;

    public function __construct(
        ApplicantBatchService $batchService
    ) {
        $this->batchService = $batchService;
    }

    /**
     * Bulk AI Role Matching
     *
     * POST /api/ai/bulk-role-matching
     */
    // public function bulkRoleMatching(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'batch_size' => 'nullable|integer|min:1|max:10',
    //         'limit' => 'nullable|integer|min:1|max:500',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Validation Failed.',
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }

    //     $batchSize = (int) $request->input('batch_size', 5);

    //     $limit = (int) $request->input('limit', 100);
    //     $offset = (int)$request->input('offset', 0);

    //     try {

    //         $result = $this->batchService->process( $batchSize, $limit, $offset );

    //         return response()->json([
    //             'status' => true,
    //             'message' => 'AI Role Matching Completed.',
    //             'data' => $result

    //         ]);

    //     } catch (Throwable $e) {
    //         \Log::error(
    //             'Bulk AI Matching Error',
    //             [
    //                 'message' => $e->getMessage(),
    //                 'line' => $e->getLine(),
    //                 'file' => $e->getFile()
    //             ]
    //         );

    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Bulk AI Matching Failed.',
    //             'error' => app()->environment('local')
    //                 ? $e->getMessage()
    //                 : null
    //         ], 500);
    //     }
    // }

    public function bulkRoleMatching(
        Request $request
    ) {

        $validator = Validator::make(
            $request->all(),
            [
                'batch_size' =>'nullable|integer|min:1|max:10',
                'limit' => 'nullable|integer|min:1|max:500',
                'last_sno' => 'nullable|integer|min:0',
                'force_reprocess' => 'nullable|boolean',
            ]
        );


        if (
            $validator->fails()
        ) {

            return response()->json(
                [
                    'status' => false,
                    'message' => 'Validation Failed.',
                    'errors' => $validator->errors()
                ],
                422
            );
        }


        $batchSize = (int) $request->input( 'batch_size',  5 );
        $limit =(int) $request->input('limit', $batchSize );
        $lastSno = (int) $request->input( 'last_sno', 0 );
        $forceReprocess = $request->boolean( 'force_reprocess', false );


        try {

            $result =  $this->batchService->process( $batchSize,  $limit, $lastSno, $forceReprocess );


            return response()->json(
                [
                    'status' =>  $result['status'] ?? true,
                    'message' =>  $result['message'] ?? 'AI Role Matching Completed.',
                    'data' => $result
                ],
                ($result['status'] ?? true)  ? 200 : 500
            );

        } catch (Throwable $e) {

            \Log::error(
                'Bulk AI Matching Error',
                [
                    'message' => $e->getMessage(),
                    'line' => $e->getLine(),
                    'file' => $e->getFile(),
                    'last_sno' => $lastSno,
                    'limit' =>  $limit,
                    'batch_size' => $batchSize
                ]
            );


            return response()->json(
                [
                    'status' => false,
                    'message' =>'Bulk AI Matching Failed.',
                    'error' => $e->getMessage()  
                ],
                500
            );
        }
    }

    public function stats()
    {
        try {
            $statistics = $this->batchService->statistics();

            return response()->json([
                'status' => true,
                'message' => 'Bulk AI statistics loaded successfully.',
                'data' => $statistics,
            ]);
        } catch (Throwable $e) {
            \Log::error('Bulk AI statistics failed', [
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to load bulk AI statistics.'.$e->getMessage(),
                'data' => [],
            ], 500);
        }
    }
}