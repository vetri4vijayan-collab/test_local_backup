<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Models\ApplicantModel;
use App\Services\CandidateServices\RecruitmentAtsRoleMatchingService;
use App\Services\CandidateServices\RecruitmentAtsRoleCatalogService;
use App\Services\CandidateServices\RecruitmentAtsRunService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Throwable;

class RecruitmentAtsRoleMatchingController extends Controller
{
    public function __construct(
        protected RecruitmentAtsRoleMatchingService $matchingService,
        protected RecruitmentAtsRunService $runService,
        protected RecruitmentAtsRoleCatalogService $roleCatalog
    ) {
    }

    public function individualShow(int $sno): JsonResponse
    {
        $this->authorizeAts();

        $applicant = ApplicantModel::query()
            ->where('sno', $sno)
            ->first();

        if (!$applicant) {
            return response()->json([
                'success' => false,
                'message' => 'Candidate not found.',
            ], 404);
        }

        $analysis = $this->matchingService->getStoredAnalysis($applicant);
        $currentRoleCatalogHash = $this->roleCatalog->getCatalogHash(
            $this->roleCatalog->getActiveRoles()
        );

        return response()->json([
            'success' => true,
            'has_analysis' => $analysis !== null,
            'data' => [
                'applicant' => [
                    'sno' => (int) $applicant->sno,
                    'applicant_id' => $applicant->applicant_id,
                    'name' => $applicant->applicant_name,
                    'email' => $applicant->email,
                    'mobile' => $applicant->mobile,
                ],
                'analysis' => $analysis
                    ? array_merge(
                        $this->matchingService->formatStoredAnalysis($applicant, $analysis),
                        [
                            'is_current' => (string) $analysis->role_catalog_hash === (string) $currentRoleCatalogHash,
                            'current_role_catalog_hash' => $currentRoleCatalogHash,
                        ]
                    )
                    : null,
            ],
        ]);
    }

    public function individualMatch(Request $request, int $sno): JsonResponse
    {
        $this->authorizeAts();

        $validated = $request->validate([
            'source_type' => [
                'nullable',
                'string',
                Rule::in(['stored', 'public_path', 'drive_link', 'resume_text']),
            ],
            'public_path' => ['nullable', 'string', 'max:2048'],
            'drive_link' => ['nullable', 'string', 'max:2048'],
            'resume_text' => ['nullable', 'string', 'max:30000'],
            'save_resume_text' => ['nullable', 'boolean'],
        ]);

        $applicant = ApplicantModel::query()
            ->where('sno', $sno)
            ->first();

        if (!$applicant) {
            return response()->json([
                'success' => false,
                'message' => 'Candidate not found.',
            ], 404);
        }

        $sourceType = (string) ($validated['source_type'] ?? 'stored');

        if ($sourceType === 'public_path' && empty($validated['public_path'])) {
            return response()->json([
                'success' => false,
                'message' => 'Public resume path is required.',
                'errors' => ['public_path' => ['Public resume path is required.']],
            ], 422);
        }

        if ($sourceType === 'drive_link' && empty($validated['drive_link'])) {
            return response()->json([
                'success' => false,
                'message' => 'Google Drive link is required.',
                'errors' => ['drive_link' => ['Google Drive link is required.']],
            ], 422);
        }

        if ($sourceType === 'resume_text' && empty(trim((string) ($validated['resume_text'] ?? '')))) {
            return response()->json([
                'success' => false,
                'message' => 'Resume text is required.',
                'errors' => ['resume_text' => ['Resume text is required.']],
            ], 422);
        }

        $sourceOverride = [
            'source_type' => $sourceType,
            'public_path' => $validated['public_path'] ?? null,
            'drive_link' => $validated['drive_link'] ?? null,
            'resume_text' => $validated['resume_text'] ?? null,
        ];

        try {
            $result = $this->matchingService->analyzeApplicant(
                $applicant,
                $sourceOverride,
                null,
                (int) ($request->user()?->getAuthIdentifier() ?? 0),
                (bool) ($validated['save_resume_text'] ?? false)
            );

            return response()->json(
                [
                    'success' => (bool) $result['status'],
                    'message' => $result['message'] ?? 'ATS analysis completed.',
                    'data' => $result['data'] ?? null,
                ],
                $result['status'] ? 200 : 422
            );
        } catch (Throwable $e) {
            Log::error('ATS individual role matching controller failure.', [
                'applicant_sno' => $sno,
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'success' => false,
                'message' => $this->safeMessage($e),
            ], 500);
        }
    }

    public function bulkStats(): JsonResponse
    {
        $this->authorizeAts();

        return response()->json([
            'success' => true,
            'data' => $this->runService->stats(),
        ]);
    }

    public function bulkStart(Request $request): JsonResponse
    {
        $this->authorizeAts();

        $maxLimit = (int) config('recruitment_ats.max_bulk_limit', 50000);
        $maxBatch = (int) config('recruitment_ats.max_batch_size', 3);
        $maxWorkers = (int) config('recruitment_ats.max_workers', 8);

        $validated = $request->validate([
            'limit' => ['required', 'integer', 'min:1', 'max:' . $maxLimit],
            'batch_size' => ['required', 'integer', 'min:1', 'max:' . $maxBatch],
            'workers' => ['required', 'integer', 'min:1', 'max:' . $maxWorkers],
            'force_reprocess' => ['nullable', 'boolean'],
        ]);

        $force = (bool) ($validated['force_reprocess'] ?? false);

        if ($force && !$this->canForceReprocess()) {
            return response()->json([
                'success' => false,
                'message' => 'Only Super Admin and Developer accounts may force a full ATS reprocess.',
            ], 403);
        }

        if ((string) config('queue.default') === 'sync') {
            return response()->json([
                'success' => false,
                'message' => 'Bulk ATS matching requires an asynchronous Laravel queue connection. Configure Redis, database, Horizon, or another async queue driver before starting a production bulk run.',
            ], 503);
        }

        try {
            $run = $this->runService->start(
                (int) ($request->user()?->getAuthIdentifier() ?? 0),
                (int) $validated['limit'],
                (int) $validated['batch_size'],
                (int) $validated['workers'],
                $force
            );

            $jobClass = \App\Jobs\hr_management\hr_recruiter\ProcessRecruitmentAtsRoleMatchingRunJob::class;
            $queue = config('recruitment_ats.queue', 'ats-role-matching');

            try {
                for ($i = 0; $i < $run->worker_count; $i++) {
                    $jobClass::dispatch((int) $run->sno)->onQueue($queue);
                }
            } catch (Throwable $dispatchException) {
                $this->runService->cancel($run->run_uuid);

                Log::error('ATS bulk queue dispatch failed.', [
                    'run_sno' => $run->sno,
                    'message' => $dispatchException->getMessage(),
                ]);

                return response()->json([
                    'success' => false,
                    'message' => 'ATS bulk run could not be queued. Please verify the queue connection and worker configuration.',
                ], 503);
            }

            return response()->json([
                'success' => true,
                'message' => 'ATS bulk role matching has been queued.',
                'data' => [
                    'run_uuid' => $run->run_uuid,
                    'target_count' => (int) $run->target_count,
                    'batch_size' => (int) $run->batch_size,
                    'workers' => (int) $run->worker_count,
                ],
            ], 202);
        } catch (Throwable $e) {
            Log::error('ATS bulk run start failed.', [
                'message' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => $this->safeMessage($e),
            ], 422);
        }
    }

    public function bulkStatus(string $run): JsonResponse
    {
        $this->authorizeAts();

        $status = $this->runService->status($run);

        if ($status === null) {
            return response()->json([
                'success' => false,
                'message' => 'ATS run not found.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $status,
        ]);
    }

    public function bulkCancel(string $run): JsonResponse
    {
        $this->authorizeAts();

        $status = $this->runService->cancel($run);

        if ($status === null) {
            return response()->json([
                'success' => false,
                'message' => 'ATS run not found.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'ATS bulk matching stop requested. The current AI request will finish, and no new candidates will be claimed.',
            'data' => $status,
        ]);
    }

    private function authorizeAts(): void
    {
        $user = auth()->user();
        $roleName = trim((string) ($user?->roledetails?->role_name ?? ''));
        $normalized = preg_replace('/\s+/u', ' ', mb_strtolower($roleName)) ?? mb_strtolower($roleName);

        if (!in_array($normalized, ['super admin', 'superadmin', 'developer'], true)) {
            abort(403, 'ATS role matching is available only to Super Admin and Developer accounts.');
        }
    }

    private function canForceReprocess(): bool
    {
        $user = auth()->user();
        $roleName = trim((string) ($user?->roledetails?->role_name ?? ''));
        $normalized = preg_replace('/\s+/u', ' ', mb_strtolower($roleName)) ?? mb_strtolower($roleName);

        return in_array($normalized, ['super admin', 'superadmin', 'developer'], true);
    }

    private function safeMessage(Throwable $e): string
    {
        if (app()->environment(['local', 'development'])) {
            return $e->getMessage();
        }

        return 'ATS role matching could not be completed. Please review the application log for details.';
    }
}
