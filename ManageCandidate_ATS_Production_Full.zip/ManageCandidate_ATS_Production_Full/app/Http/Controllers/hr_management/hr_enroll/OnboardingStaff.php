<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CompanyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\OnboardingStaffModel;
use App\Models\OnboardingEmployeeChecklistModel;

class OnboardingStaff extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();


    $data = OnboardingStaffModel::with([
        'department:sno,department_name',
        'division:sno,division_name',
        'jobRole:sno,job_position_name',
        'reportingStaff:sno,staff_name',
        'entity:sno,entity_name,entity_base_color',
        'employeeChecklists'
    ])
    ->withCount([
        'employeeChecklists as total_documents',
        'employeeChecklists as completed_documents' => function ($q) {
            $q->where('status', 1);
        }
    ])
    ->where('status', '!=', 2);

    if (!empty($search_filter)) {

        $data->where(function ($q) use ($search_filter) {

            $q->where('candidate_name', 'LIKE', "%{$search_filter}%")
            ->orWhere('mobile', 'LIKE', "%{$search_filter}%")
            ->orWhere('personal_email', 'LIKE', "%{$search_filter}%");
        });
    }

    if (!empty($company_fill)) {
        $data->where('company_id', $company_fill);
    }
    if (!empty($entity_fill)) {
        $data->where('entity_id', $entity_fill);
    }
    if (!empty($department_fill)) {
        $data->where('department_id', $department_fill);
    }

    if (!empty($division_fill)) {
        $data->where('division_id', $division_fill);
    }
    if (!empty($job_role_fill)) {
        $data->where('job_role_id', $job_role_fill);
    }
    $data = $data
        ->orderByDesc('sno')
        ->paginate($perpage);

   

    if ($request->ajax()) {

        $response = $data->getCollection()->map(function ($item) {

            $stages = [
                'Document Collection',
                'HR Evaluation',
                'Self Evaluation',
                'Training',
                'Final Evaluation'
            ];

            $currentStep = $item->onboarding_step;

            $currentIndex = array_search($currentStep, $stages);

            $completedStages = [];

            if ($currentIndex !== false) {
                $completedStages = array_slice($stages, 0, $currentIndex);
            }

            $completed = count($completedStages);
            $inprogress = $currentStep ? 1 : 0;
            $notstarted = 5 - ($completed + $inprogress);

            $progress = round(($completed / 5) * 100);

            $evaluations = [];

            foreach ($stages as $index => $stage) {

                if ($index < $currentIndex) {
                    $status = 'Completed';
                } elseif ($index == $currentIndex) {
                    $status = 'In Progress';
                } else {
                    $status = 'Not Started';
                }

                $evaluations[] = [
                    'title' => $stage,
                    'status' => $status,
                    'score' => $status == 'Completed'
                        ? rand(70,100)
                        : 0,

                    'date' => $status == 'Completed'
                        ? now()->subDays(rand(1,30))->format('d-M-Y')
                        : null,

                    'join_date' => $stage == 'Document Collection'
                        ? optional($item->doj)->format('d-M-Y')
                        : null,

                    'evaluator_name' => $item->reportingStaff->staff_name ?? 'Not Assigned',

                    'evaluator_role' => $item->jobRole->job_position_name ?? 'Evaluator',
                ];
            }

            return [

                'id' => $item->sno,

                'candidate_name' => $item->candidate_name,

                'personal_email' => $item->personal_email,

                'mobile' => $item->mobile,

                'entity_name' => $item->entity->entity_name ?? '-',

                'entity_color' => $item->entity->entity_base_color ?? '#0d6efd',

                'job_role' => $item->jobRole->job_position_name ?? '-',

                'department' => $item->department->department_name ?? '-',

                'division' => $item->division->division_name ?? '-',

                'doj' => optional($item->doj)->format('d-M-Y'),

                'onboarding_step' => $currentStep,

                'completed' => $completed,

                'inprogress' => $inprogress,

                'notstarted' => $notstarted,

                'progress' => $progress,

                'score' => $progress,

                'total_stages' => 5,

                'completed_stages' => $completedStages,

                'evaluations' => $evaluations,
            ];
        });

        return response()->json([
            'data' => $response,
            'current_page' => $data->currentPage(),
            'last_page' => $data->lastPage(),
            'total' => $data->total(),
        ]);
    }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.onboarding_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }
}
