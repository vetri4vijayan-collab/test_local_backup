<?php

namespace App\Http\Controllers\hr_management\exam_management;

use App\Http\Controllers\Controller;
use App\Models\ExamLimitIncreaseModel;
use App\Models\ExamProcessModel;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageResult extends Controller
{
    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';
        $staff_fill = $request->staff_fill ?? '';
        $role_fill = $request->role_fill ?? '';
        $exam_fill = $request->exam_fill ?? '';
        $attempt_fill = $request->attempt_fill ?? '';
        $filter_on = $request->filter_on ?? '';
        $date_filter         = $request->dt_fill_issue_rpt;
        $from_date_filter    = $request->from_date_fillter_textbox;
        $to_date_filter      = $request->to_date_fillter_textbox;
        $fin_yr_fill         = $request->fin_yr_fill ?? '';
        $branch_id   = $request->user()->branch_id; // User's branch ID
        $user_id     = $request->user()->user_id; // User's ID


        $query = DB::table('egc_exam_process')
            ->select(
                'egc_exam_process.*',
                'egc_staff.staff_name',
                'egc_staff.staff_image',
                'egc_staff.gender',
                'egc_staff.date_of_joining',
                'egc_staff.nick_name',
                'egc_branch.branch_type',
                'egc_branch.branch_name',
                'egc_branch.franchise_name',
                'egc_user_role.role_name',
                'egc_manage_exam.exam_name',
                'egc_manage_exam.level_id',
                'egc_manage_exam.duration',
                'egc_manage_exam.badge_check',
                'egc_manage_exam.exam_attempt',
                'egc_manage_exam.attempts',
                'egc_manage_exam.positive_mark',
                'egc_manage_exam.negative_mark',
                'egc_manage_exam.question_count',
                'egc_manage_exam.schedule_id',
                'egc_manage_exam.pass_mark',
                'egc_exam_schedule.duration as sch_duration',
                'egc_exam_schedule.unit',
                'egc_exam_badge.badge_name',
                'egc_exam_badge.badge_image',
                'egc_exam_category.category_name as badge_cat',
                // Get the attempt number for this specific process record
                DB::raw('(SELECT COUNT(*) FROM egc_exam_process ep 
                          WHERE ep.staff_id = egc_exam_process.staff_id 
                          AND ep.exam_id = egc_exam_process.exam_id 
                          AND ep.sno <= egc_exam_process.sno) as curattempt_count'),
            )
            ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_exam_process.staff_id')
            ->leftJoin('egc_user_role', 'egc_user_role.sno', '=', 'egc_staff.role_id') // Assuming role is on egc_staff
            ->leftJoin('egc_manage_exam', 'egc_manage_exam.sno', '=', 'egc_exam_process.exam_id')
            ->leftJoin('egc_exam_schedule', 'egc_exam_schedule.sno', '=', 'egc_manage_exam.sno')
            ->leftJoin('egc_exam_badge', 'egc_exam_badge.sno', '=', 'egc_manage_exam.badge')
            ->leftJoin('egc_branch', 'egc_branch.sno', '=', 'egc_staff.branch_id')
            ->leftJoin('egc_exam_category', 'egc_exam_category.sno', '=', 'egc_exam_badge.exam_cat_id');

        // Search filter
        if (!empty($search_fill)) {
            $query->where(function ($query) use ($search_fill) {
                $query->where('egc_staff.staff_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('egc_user_role.role_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('egc_manage_exam.exam_name', 'LIKE', "%{$search_fill}%");
            });
        }

        // Staff filter
        if ($staff_fill) {
            $query->where('egc_staff.sno', $staff_fill);
        }

        // Role filter (uncomment if used)
        if ($role_fill) {
            $query->where('egc_user_role.sno', $role_fill);
        }

        // Exam filter
        if ($exam_fill) {
            $query->where('egc_manage_exam.sno', $exam_fill);
        }

        // Attempt filter
        if ($attempt_fill) {
            $query->where('egc_manage_exam.exam_attempt', $attempt_fill);
        }

        // Date filter
        if ($date_filter === "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('egc_exam_process.created_at', $todayDate);
        } elseif ($date_filter === "week") {
            $today = date('l');
            if ($today === "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('egc_exam_process.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter === "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('egc_exam_process.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter === "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('egc_exam_process.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->whereDate('egc_exam_process.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereDate('egc_exam_process.created_at', '<=', $toDate);
            }
        }

        // Final execution with sorting and pagination

        // ->where('egc_exam_process.branch_id', $branch_id)


        if ($user_id != 0) {
            $query->where('egc_exam_process.staff_id', '>', 0);
        }
        $query =   $query->where('egc_manage_exam.status', 0)->orderByDesc('egc_exam_process.sno')->paginate($perpage);

        $lists = $query;
        return view('content.hr_management.exam_management.manage_result.list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill,
            'staff_fill' => $staff_fill,
            'role_fill' => $role_fill,
            'exam_fill' => $exam_fill,
            'attempt_fill' => $attempt_fill,
            'filter_on' => $filter_on,
            'date_filter' => $date_filter,
        ]);
    }
    public function view_report($eid, Request $request)
    {
        $helper = new \App\Helpers\Helpers();



        $decryptedValue = $helper->encrypt_decrypt($eid, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Split the decrypted string into two parts
        list($id, $user_id, $process_sno) = explode('~', $decryptedValue);

        $staff = DB::table('egc_staff')->where('sno', $user_id)->first();

       

        $edit = DB::table('egc_manage_exam')
            ->select(
                'egc_manage_exam.*',
                'egc_exam_badge.badge_image',
                'egc_exam_badge.prize_id',
                'egc_exam_badge.gift',
                'egc_exam_badge.points',
                'egc_exam_badge.promotion_id',
                'egc_job_role.job_position_name'
            )
            ->leftJoin('egc_exam_badge', 'egc_exam_badge.sno', '=', 'egc_manage_exam.badge')
            ->leftJoin('egc_job_role', 'egc_exam_badge.promotion_id', '=', 'egc_job_role.sno')
            ->where('egc_manage_exam.sno', $id)
            ->first();

        $edit->role_name = '';
        $edit->staff_names = '';
        $edit->nick_name = '';
        $edit->staff_image = '';

        if ($edit) {
            $roleData = DB::table('egc_user_role')->where('sno', $staff->role_id)->first();
            $edit->role_name = $roleData->role_name;
            $edit->staff_names = $staff->staff_name;
            $edit->nick_name = $staff->nick_name;
            $edit->staff_image = $staff->staff_image;
            $edit->staff_id = $staff->sno;
        }
        // return $edit;

        // Fetch exam process details
        $process = DB::table('egc_exam_process')
            ->select(
                'egc_exam_process.*',
                'egc_staff.staff_name',
                'egc_staff.nick_name',
            )
            ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_exam_process.staff_id')
            ->where('egc_exam_process.exam_id', $edit->sno)
            ->where('egc_exam_process.status', 2)
            ->where('egc_exam_process.sno', $process_sno)
            ->where('egc_exam_process.staff_id', $user_id)
            ->get();

        $answersMap = [];
        foreach ($process as $p) {
            $answers = json_decode($p->exam_question_answers_datas, true);

            $answersMap = [];
            if (is_array($answers)) {
                foreach ($answers as $answer) {
                    if (isset($answer['question_id'])) {
                        $answersMap[$answer['question_id']] = $answer;
                    }
                }
            }

            // Get all question_ids
            $questionIds = array_keys($answersMap);

            // Fetch questions based on these question_ids
            $questions = DB::table('egc_exam_questions')
                ->select(
                    'egc_exam_questions.sno as question_id',
                    'egc_exam_section.section_name'
                )
                ->leftJoin('egc_exam_section', 'egc_exam_section.sno', '=', 'egc_exam_questions.section_id')
                ->whereIn('egc_exam_questions.sno', $questionIds)
                ->get();

            // Group by section & count total and correct answers
            $sectionStats = [];
            foreach ($questions as $q) {
                $sectionName = $q->section_name ?? 'Unknown';

                // Initialize the section data if it doesn't exist
                if (!isset($sectionStats[$sectionName])) {
                    $sectionStats[$sectionName] = [
                        'section_name' => $sectionName,
                        'question_count' => 0,
                        'correct_count' => 0,
                    ];
                }

                // Increment the question count for the section
                $sectionStats[$sectionName]['question_count']++;

                // Check if the answer for this question is correct
                if (
                    isset($answersMap[$q->question_id]) &&
                    $answersMap[$q->question_id]['correctness'] === 'correct'
                ) {
                    $sectionStats[$sectionName]['correct_count']++;
                }
            }

            // Attach the section data to the process item
            $p->section_data = array_values($sectionStats);
        }


        $sections = [];
        foreach ($questionIds as $question) {
            $section = DB::table('egc_exam_questions')
                ->select(
                    'egc_question_bank.bank_name',
                    'egc_exam_section.section_name',
                    'egc_exam_questions.*',
                )
                ->leftJoin('egc_question_bank', 'egc_question_bank.sno', '=', 'egc_exam_questions.bank_id')
                ->leftJoin('egc_exam_section', 'egc_exam_section.sno', '=', 'egc_exam_questions.section_id')
                ->where('egc_exam_questions.sno', $question)
                ->first();

            $sections[$question] = $section;
        }

        return view('content.hr_management.exam_management.manage_result.view_result', [
            'view' => $edit,
            'id' => $decryptedValue,
            'process' => $process,
            'sections' => $sections,
            'answersMap' => $answersMap
        ]);
    }

  public function store_limit(Request $request)
    {
        $request->validate([
            'exam_id' => 'required|integer',
            'staff_id' => 'required|integer',
            'old_limit' => 'required|integer',
            'new_limit' => 'required|integer|gt:old_limit',
        ]);
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $exam = DB::table('egc_manage_exam')->where('sno', $request->exam_id)->first();
        try {
            DB::beginTransaction();
            // Insert into egc_exam_limit_increase
            ExamLimitIncreaseModel::create([
                'exam_id'   => $request->exam_id,
                'staff_id'  => $request->staff_id,
                'old_limit' => $request->old_limit,
                'new_limit' => $request->new_limit,
                'created_by' => $request->user()->user_id,
                'updated_by' => $request->user()->user_id,
            ]);
            $incre = $request->new_limit - $request->old_limit;
            $notificationData = [
                'branch_id' => $branch_id,
                'notification_content' => ' <div class="d-flex align-items-center">
                    <div class="me-3">
                        <span class="badge bg-gray-300"><i class="mdi mdi-clipboard-edit-outline fs-3 text-black"></i></span>
                    </div>
                    <div class="me-2">
                        <a href="javascript:;" class="fs-7 text-primary fw-bold">' . $exam->exam_name . '</a>
                        <div class="text-secondary fs-8  fw-bold">Assessment Limit (<span class="text-info">+ '. $incre .'</span>) Extended</div>
                    </div>
                    </div>',
                'who' => $request->staff_id,
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'status' => 0
            ];
            $notificationtype = 'Assessment';
            $newNotification = new \App\Helpers\Helpers();
 
            $newNotification->createNotificationAssessment($notificationData, $notificationtype, $request->staff_id);
            DB::commit();
            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ]);
        }
    }
    public function exam_process_delete(Request $request)
    {
 
        $request->validate([
            'exam_id' => 'required|integer',
            'staff_id' => 'required|integer',
            'Process_id' => 'required|integer',
        ]);
 
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $id = $request->Process_id;
 
        // Optional double check for security
        $exam = ExamProcessModel::where('sno', $id)->first();
 
        if (!$exam) {
            return response()->json(['status' => 404, 'message' => 'Assessment not found']);
        }
 
        // delete processes
        DB::table('egc_exam_process')->where('sno', $id)->delete();
        // Update  processes status = 3 instead of deleting
        // DB::table('egc_exam_process')->where('exam_id', $id)->update(['status' => 3]);
 
        return response()->json([
            'success' => true,
            'status' => 200,
            'message' => 'Assessment and all related records deleted successfully',
        ]);
    }
 
}
