<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\PayrollStaffStructureDetailModel;
use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollComponentVersModel;
use App\Models\PayrollSalaryTemplateModel;
use App\Models\PayrollSalaryTemplateDetailModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use App\Models\StaffModel;
use App\Models\StaffSalaryAccountModel;
use App\Models\StaffAppraisalLogModel;
use App\Models\StaffSalaryAppraisalHistoryModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Log;
use App\Services\PayrollAppraisalService;
use Illuminate\Validation\ValidationException;

class PayrollSalaryTemplate extends Controller
{



    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $templates = DB::table('egc_payroll_salary_templates')
            ->where('status', '!=', 2);

        if ($search_filter != '') {

            $templates->where(function ($q) use ($search_filter) {

                $q->where('template_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('template_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('gross_salary', 'LIKE', "%{$search_filter}%");
            });
        }

        $templates = $templates
            ->orderBy('sno', 'DESC')
            ->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $templates->map(function ($item) use ($helper) {
                // return $interview_schedule;
                return [
                    'sno' => $item->sno,
                    'template_name' => $item->template_name,
                    'template_code' => $item->template_code,
                    'gross_salary' => number_format($item->gross_salary, 2),
                    'monthly_ctc' => number_format($item->monthly_ctc, 2),
                    'effective_from' => $item->effective_from,
                    'status' => $item->status,
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $templates->currentPage(),
                'last_page' => $templates->lastPage(),
                'total' => $templates->total(),
            ]);
        }
        $components = DB::table('egc_payroll_components')
            ->select('egc_payroll_components.*', 'egc_payroll_rules.rule_code', 'egc_payroll_rules.rule_category', 'egc_payroll_rules.rule_expression')
            ->leftJoin('egc_payroll_rules', 'egc_payroll_rules.id', '=', 'egc_payroll_components.rule_id')
            ->where('egc_payroll_components.status', 0)
            ->orderBy('egc_payroll_components.component_name')
            ->get();

        return view('content.hr_management.hr_general.payroll_template.payroll_template_list', [
            'templates' => $templates,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'components' => $components,
        ]);
    }


    public function Status($id, Request $request)
    {
        $last_apply_date = $request->input('last_apply_date');
        $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
        $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status = $request->input('status', 0);
        $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
        $upd_LedgerCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function saveTemplate(Request $request)
    {
        DB::beginTransaction();
       

        try {

            $validator = Validator::make($request->all(), [
                'sno'               => 'nullable|integer',
                'template_name'     => 'required|string|max:255',
                'gross_salary'      => 'required|numeric|min:0',
                'effective_from'    => 'nullable',
                'template_type'     => 'required|string|max:100',
                'description'       => 'nullable|string',
                'details'           => 'required|array|min:1',
                'details.*.component_sno' => 'required|integer',
                'details.*.component_type' => 'required|in:earning,deduction',
                'details.*.calculation_type' => 'nullable|string',
                'details.*.percentage' => 'nullable|numeric|min:0|max:100',
                'details.*.amount' => 'nullable|numeric|min:0',

                'employer_contributions' => 'nullable|array',
                'employer_contributions.*.component_name' => 'required|string',
                'employer_contributions.*.percentage' => 'nullable|numeric',
                'employer_contributions.*.amount' => 'nullable|numeric',

            ]);
            if ($validator->fails()) {
                return response()->json([
                    'status'  => false,
                    'message' => $validator->errors()->first(),
                    'errors'  => $validator->errors()
                ], 422);
            }


            $grossSalary = (float) $request->gross_salary;
            $earningPercentage = 0;
            $totalEarnings = 0;
            $totalDeductions = 0;
            $preparedDetails = [];
            $usedComponents = [];

            //  return response()->json([
            //     'status'  => false,
            //     'message' => $request->details ,
            // ], 422);

            foreach ($request->details as $detail) {


                if (in_array($detail['component_sno'], $usedComponents)) {
                    DB::rollBack();
                    return response()->json([
                        'status' => false,
                        'message' => 'Duplicate salary component selected.'
                    ], 422);
                }
                $usedComponents[] = $detail['component_sno'];

                $component = PayrollComponentVersModel::where(
                    'sno',
                    $detail['component_sno']
                )->first();

                if (!$component) {
                    DB::rollBack();
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid salary component selected.'
                    ], 422);
                }


                $percentage = (float) ($detail['percentage'] ?? 0);
                $amount = (float) ($detail['amount'] ?? 0);

                $calculationType = $detail['calculation_type'] ?? 'fixed';

                /*
                |--------------------------------------------------------------------------
                | PERCENTAGE
                |--------------------------------------------------------------------------
                */

                if ($calculationType == 'percentage') {

                    $amount =
                        ($grossSalary * $percentage) / 100;
                }

                /*
                |--------------------------------------------------------------------------
                | FIXED / MANUAL INPUT
                |--------------------------------------------------------------------------
                */

                else if (
                    $calculationType == 'fixed' ||
                    $calculationType == 'manual_input'
                ) {

                    $amount = (float) $detail['amount'];
                }

                /*
                |--------------------------------------------------------------------------
                | FORMULA
                |--------------------------------------------------------------------------
                */

                else if ($calculationType == 'formula') {

                    $amount = (float) $detail['amount'];
                }

                if ($detail['component_type'] == 'earning') {
                    $earningPercentage += $percentage;
                    $totalEarnings += $amount;
                }

                if ($detail['component_type'] == 'deduction') {
                    $totalDeductions += $amount;
                }
                $preparedDetails[] = [
                    'component_sno'     => $component->sno,
                    'component_name'    => $component->component_name,
                    'component_type'    => $detail['component_type'],
                    'calculation_type'  => $detail['calculation_type'],
                    'percentage'        => $percentage,
                    'amount'            => round($amount, 2),
                    'payroll_rule_sno'            => $component->rule_id ?? null
                ];
            }


            if (round($earningPercentage, 2) != 100) {
                DB::rollBack();
                return response()->json([
                    'status' => false,
                    'message' => 'Total earnings percentage must equal exactly 100%.'
                ], 422);
            }

            $netSalary = $totalEarnings - $totalDeductions;
            $totalEmployerContribution = 0;

            foreach ($request->employer_contributions ?? [] as $contribution) {

                $totalEmployerContribution +=
                    (float) $contribution['amount'];
            }

            $monthlyCTC =
                $totalEarnings + $totalEmployerContribution;


            if ($request->sno) {
                $template = PayrollSalaryTemplateModel::where(
                    'sno',
                    $request->sno
                )->first();
                if (!$template) {
                    DB::rollBack();
                    return response()->json([
                        'status' => false,
                        'message' => 'Salary template not found.'
                    ], 404);
                }
                $message = 'Salary template updated successfully.';
            } else {
                $template = new PayrollSalaryTemplateModel();
                $message = 'Salary template created successfully.';
            }

            $template->template_name      = $request->template_name;
            $template->template_code      = strtoupper($request->template_code);
            $template->gross_salary       = $grossSalary;
            $template->effective_from     = $request->effective_from  ? Carbon::parse($request->effective_from)->format('Y-m-d') : null;
            $template->template_type      = $request->template_type;
            $template->description        = $request->description;
            $template->total_earnings     = round($totalEarnings, 2);
            $template->total_deductions   = round($totalDeductions, 2);
            $template->net_salary         = round($netSalary, 2);
            $template->monthly_ctc        = round($monthlyCTC, 2);
            $template->status             = 0;
            $template->save();

            // =====================================================
            // DELETE OLD DETAILS
            // =====================================================

            PayrollSalaryTemplateDetailModel::where(
                'template_sno',
                $template->sno
            )->delete();

            // =====================================================
            // INSERT DETAILS
            // =====================================================

            foreach ($preparedDetails as $detail) {

                PayrollSalaryTemplateDetailModel::create([

                    'template_sno'      => $template->sno,

                    'component_sno'     => $detail['component_sno'],

                    'component_name'    => $detail['component_name'],

                    'component_type'    => $detail['component_type'],

                    'calculation_type'  => $detail['calculation_type'],

                    'percentage'        => $detail['percentage'],

                    'amount'            => $detail['amount'],
                    'payroll_rule_sno'            => $detail['payroll_rule_sno'] ?? null,
                ]);
            }

            foreach ($request->employer_contributions ?? [] as $contribution) {

                $component = PayrollComponentVersModel::where(
                    'component_name',
                    $contribution['component_name']
                )
                    ->where('status', 0)
                    ->first();

                if (!$component) {

                    DB::rollBack();

                    return response()->json([
                        'status' => false,
                        'message' => 'Employer component not found : ' . $contribution['component_name']
                    ], 422);
                }

                PayrollSalaryTemplateDetailModel::create([

                    'template_sno' => $template->sno,

                    'component_sno' => $component->sno,

                    'component_name' => $component->component_name,

                    'component_type' => 'employer_contribution',

                    'calculation_type' => $contribution['calculation_type']  ?? 'formula',

                    'percentage' => $contribution['percentage'] ?? 0,

                    'amount' => $contribution['amount'] ?? 0,

                    'payroll_rule_sno' => $component->rule_id ?? null,

                    'employer_contribution' => 1,
                ]);
            }

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => $message,

                'data' => [

                    'template_sno' => $template->sno,

                    'template_name' => $template->template_name,

                    'net_salary' => $template->net_salary,
                ]
            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            Log::error('Payroll Template Save Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile(),
            ]);

            return response()->json([

                'status' => false,

                'message' => 'Unable to save salary template.',

                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null

            ], 500);
        }
    }




    public function staffSalaryMappingSave(Request $r)
    {

        $r->validate([
            'employee_sno' => 'required',
            'salary_structure_sno' => 'required',
            'effective_from' => 'required'
        ]);

        DB::transaction(function () use ($r) {

            // close previous active structure
            DB::table('egc_staff_salary_mapping')
                ->where('staff_id', $r->employee_sno)
                ->whereNull('effective_to')
                ->update([
                    'effective_to' => date('Y-m-d', strtotime($r->effective_from . ' -1 day')),
                    'updated_by' => $r->user()->user_id ?? 1
                ]);

            // insert new mapping
            DB::table('egc_staff_salary_mapping')
                ->insert([
                    'staff_id' => $r->employee_sno,
                    'salary_structure_sno' => $r->salary_structure_sno,
                    'effective_from' => $r->effective_from ? date('Y-m-d', strtotime($r->effective_from)) : null,
                    'change_reason' => $r->change_reason,
                    'created_by' => $r->user()->user_id ?? 1
                ]);
        });

        return response()->json([
            'status' => true
        ]);
    }

    public function edit($id)
    {
        try {

            // =====================================================
            // FETCH TEMPLATE
            // =====================================================

            $template = PayrollSalaryTemplateModel::with([

                'details.component'

            ])->where('sno', $id)->first();

            // =====================================================
            // NOT FOUND
            // =====================================================

            if (!$template) {

                return response()->json([

                    'status' => false,

                    'message' => 'Salary template not found.'

                ], 404);
            }

            // =====================================================
            // FORMAT DETAILS
            // =====================================================

            $details = [];

            if ($template->details->count() > 0) {

                foreach ($template->details as $detail) {

                    $details[] = [

                        'sno' => $detail->sno,

                        'component_sno' => $detail->component_sno,

                        'component_name' => $detail->component_name,

                        'component_type' => $detail->component_type,

                        'calculation_type' => $detail->calculation_type,

                        'percentage' => (float) $detail->percentage,

                        'amount' => (float) $detail->amount,

                        'component' => [

                            'sno' => $detail->component?->sno,

                            'component_name' => $detail->component?->component_name,

                            'component_code' => $detail->component?->component_code,

                            'category' => $detail->component?->category,

                            'calculation_type' => $detail->component?->calculation_type,
                        ]
                    ];
                }
            }

            // =====================================================
            // RESPONSE
            // =====================================================

            return response()->json([

                'status' => true,

                'message' => 'Salary template fetched successfully.',

                'data' => [

                    'sno' => $template->sno,

                    'template_name' => $template->template_name,

                    'template_code' => $template->template_code,

                    'gross_salary' => (float) $template->gross_salary,

                    'effective_from' => $template->effective_from
                        ? \Carbon\Carbon::parse($template->effective_from)
                        ->format('d-M-Y')
                        : null,

                    'template_type' => $template->template_type,

                    'description' => $template->description,

                    'total_earnings' => (float) $template->total_earnings,

                    'total_deductions' => (float) $template->total_deductions,

                    'net_salary' => (float) $template->net_salary,

                    'monthly_ctc' => (float) $template->monthly_ctc,

                    'details' => $details
                ]

            ], 200);
        } catch (\Exception $e) {

            \Log::error('Payroll Template Edit Fetch Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile(),
            ]);

            return response()->json([

                'status' => false,

                'message' => 'Unable to fetch salary template.',

                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null

            ], 500);
        }
    }


    // public function saveEmployeeStructure(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {

    //         $request->validate([

    //             'employee_sno' => 'required|integer',

    //             'gross_salary' => 'required|numeric|min:0',

    //             'effective_from' => 'required',

    //             'details' => 'required|array|min:1',
    //         ]);

    //         // OLD CURRENT STRUCTURE DISABLE

    //         PayrollStaffStructureModel::where(
    //             'employee_sno',
    //             $request->employee_sno
    //         )
    //             ->where('is_current', 1)
    //             ->update([

    //                 'is_current' => 0,
    //                 'effective_to' => date('Y-m-d', strtotime($request->effective_from . ' -1 day')),
    //             ]);

    //         $earnings = 0;
    //         $deductions = 0;
    //         $employerContribution = 0;

    //         foreach ($request->details as $detail) {

    //             if ($detail['component_type'] == 'earning') {
    //                 $earnings += $detail['calculated_amount'];
    //             } elseif ($detail['component_type'] == 'deduction') {
    //                 $deductions += $detail['calculated_amount'];
    //             } elseif ($detail['component_type'] == 'employer') {
    //                 $employerContribution += $detail['calculated_amount'];
    //             }
    //         }

    //         $netSalary = $earnings - $deductions;
    //         $ctcAmount = $earnings + $employerContribution;

    //         $structure = PayrollStaffStructureModel::create([

    //             'employee_sno' => $request->employee_sno,

    //             'payroll_template_sno' => $request->payroll_template_sno,

    //             'structure_code' => 'SAL-' . time(),

    //             'structure_name' => 'Employee Salary Structure',

    //             'gross_salary' => $request->gross_salary,

    //             'total_earnings' => $earnings,

    //             'total_deductions' => $deductions,

    //             'net_salary' => $netSalary,

    //             'employer_contribution' => $employerContribution,
    //             'ctc_amount' => $ctcAmount,

    //             'revision_reason' => $request->revision_reason,

    //             'effective_from' => Carbon::parse(
    //                 $request->effective_from
    //             )->format('Y-m-d'),

    //             'is_current' => 1,

    //             'status' => 0,

    //             'created_by' => auth()->id(),
    //         ]);

    //         foreach ($request->details as $index => $detail) {

    //             PayrollStaffStructureDetailModel::create([

    //                 'payroll_employee_structure_sno' => $structure->sno,

    //                 'payroll_component_sno' => $detail['payroll_component_sno'],

    //                 'component_type' => $detail['component_type'],

    //                 'calculation_type' => $detail['calculation_type'],

    //                 'percentage_value' => $detail['percentage_value'] ?? 0,

    //                 'fixed_amount' => $detail['calculated_amount'],

    //                 'calculated_amount' => $detail['calculated_amount'],

    //                 'display_order' => $index + 1,

    //                 'status' => 0,
    //             ]);
    //         }

    //         StaffModel::where(
    //             'sno',
    //             $request->employee_sno
    //         )
    //             ->update([
    //                 'basic_salary' => $request->gross_salary,
    //             ]);

    //         DB::commit();

    //         return response()->json([

    //             'status' => true,

    //             'message' => 'Employee salary structure saved successfully'
    //         ]);
    //     } catch (\Exception $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' => $e->getMessage()
    //         ], 500);
    //     }
    // }

    // public function saveEmployeeStructure(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {

    //         $request->validate([

    //             'employee_sno'         => 'required|integer',
    //             'gross_salary'         => 'required|numeric|min:0',
    //             'effective_from'       => 'required|date',
    //             'details'              => 'required|array|min:1',
    //         ]);

    //         /*
    //         |--------------------------------------------------------------------------
    //         | OLD CURRENT STRUCTURE DISABLE
    //         |--------------------------------------------------------------------------
    //         */

    //         $existingStructure = PayrollStaffStructureModel::where('employee_sno',$request->employee_sno )
    //                             ->whereDate('effective_from',Carbon::parse($request->effective_from)->format('Y-m-d'))
    //                             ->where('status', 0)
    //                             ->first();
    //         if ($existingStructure) {
    //             $existingStructure->update([
    //                 'payroll_template_sno' => $request->payroll_template_sno,
    //                 'gross_salary' => $request->gross_salary,
    //                 'total_earnings' => round($earnings,2),
    //                 'total_deductions' => round($deductions,2),
    //                 'net_salary' => round($netSalary,2),
    //                 'employer_contribution' => round($employerContribution,2),
    //                 'ctc_amount' => round($ctcAmount,2),
    //                 'revision_reason' =>$request->revision_reason,
    //                 'updated_by' => $request->user()->user_id ?? 0,
    //             ]);
    //             $structure = $existingStructure;
    //         } else {

    //             PayrollStaffStructureModel::where('employee_sno',$request->employee_sno)
    //                             ->where('is_current', 1)
    //                             ->update([
    //                                 'is_current'   => 0,
    //                                 'effective_to' => date( 'Y-m-d',strtotime($request->effective_from . ' -1 day')),
    //                             ]);
    //             $earnings              = 0;
    //             $deductions            = 0;
    //             $employerContribution  = 0;
    //             /*
    //             |--------------------------------------------------------------------------
    //             | CALCULATE SUMMARY
    //             |--------------------------------------------------------------------------
    //             */
    //             foreach ($request->details as $detail) {
    //                 $amount = (float) $detail['calculated_amount'];
    //                 if ($detail['component_type'] == 'earning') {
    //                     $earnings += $amount;
    //                 } elseif ($detail['component_type'] == 'deduction') {
    //                     $deductions += $amount;
    //                 } elseif ($detail['component_type'] == 'employer') {
    //                     $employerContribution += $amount;
    //                 }
    //             }
    //             $netSalary = $earnings - $deductions;
    //             /*
    //             |--------------------------------------------------------------------------
    //             | CTC
    //             |--------------------------------------------------------------------------
    //             */
    //             $ctcAmount = $earnings + $employerContribution;
    //             /*
    //             |--------------------------------------------------------------------------
    //             | CREATE STRUCTURE
    //             |--------------------------------------------------------------------------
    //             */
    //             $structure = PayrollStaffStructureModel::create([
    //                 'employee_sno'            => $request->employee_sno,
    //                 'payroll_template_sno'    => $request->payroll_template_sno,
    //                 'structure_code'          => 'SAL-' . time() . rand(100, 999),
    //                 'structure_name'          =>'Employee Salary Structure',
    //                 'gross_salary'            => $request->gross_salary,
    //                 'total_earnings'          => round($earnings, 2),
    //                 'total_deductions'        => round($deductions, 2),
    //                 'net_salary'              => round($netSalary, 2),
    //                 'employer_contribution'   =>round($employerContribution, 2),
    //                 'ctc_amount'              =>round($ctcAmount, 2),
    //                 'revision_reason'         => $request->revision_reason,
    //                 'effective_from'          => Carbon::parse($request->effective_from)->format('Y-m-d'),
    //                 'is_current'              => 1,
    //                 'status'                  => 0,
    //                 'created_by'              => auth()->id(),
    //             ]);
    //         }
    //             /*
    //             |--------------------------------------------------------------------------
    //             | SAVE DETAILS
    //             |--------------------------------------------------------------------------
    //             */

    //         $existingDetails =
    //             PayrollStaffStructureDetailModel::where(
    //                 'payroll_employee_structure_sno',
    //                 $structure->sno
    //             )
    //             ->where('status',0)
    //             ->get()
    //             ->keyBy('payroll_component_sno');
    //         $currentComponentIds = [];

    //         foreach ($request->details as $index => $detail) {

    //             foreach ($request->details as $index => $detail) {

    //             $componentId =
    //                 $detail['payroll_component_sno'];

    //             $currentComponentIds[] =
    //                 $componentId;

    //             $detailData = [

    //                 'payroll_rule_sno' =>
    //                     $detail['payroll_rule_sno'] ?? null,

    //                 'component_type' =>
    //                     $detail['component_type'],

    //                 'calculation_type' =>
    //                     $detail['calculation_type'],

    //                 'calculated_amount' =>
    //                     $detail['calculated_amount'],

    //                 'fixed_amount' =>
    //                     $detail['fixed_amount']
    //                         ?? $detail['calculated_amount'],

    //                 'percentage_value' =>
    //                     $detail['percentage_value'] ?? 0,

    //                 'include_in_ctc' =>
    //                     $detail['include_in_ctc'] ?? 1,

    //                 'include_in_gross' =>
    //                     $detail['include_in_gross'] ?? 0,

    //                 'include_in_payslip' =>
    //                     $detail['include_in_payslip'] ?? 1,

    //                 'display_order' =>
    //                     $detail['display_order']
    //                         ?? ($index + 1),

    //                 'updated_by' =>
    //                     auth()->id()
    //             ];

    //             if (
    //                 isset(
    //                     $existingDetails[$componentId]
    //                 )
    //             ) {

    //                 $existingDetails[$componentId]
    //                     ->update($detailData);

    //             } else {

    //                 PayrollStaffStructureDetailModel::create(

    //                     array_merge(
    //                         $detailData,
    //                         [

    //                             'payroll_employee_structure_sno' =>
    //                                 $structure->sno,

    //                             'payroll_component_sno' =>
    //                                 $componentId,

    //                             'status' => 0,

    //                             'created_by' =>
    //                                 auth()->id()
    //                         ]
    //                     )
    //                 );
    //             }
    //         }

    //             PayrollStaffStructureDetailModel::create([
    //                 'payroll_employee_structure_sno' => $structure->sno,
    //                 'payroll_component_sno' => $detail['payroll_component_sno'],
    //                 'payroll_rule_sno' => $detail['payroll_rule_sno'] ?? null,
    //                 'component_type' => $detail['component_type'],
    //                 'calculation_type' => $detail['calculation_type'],
    //                 'calculated_on' =>$detail['calculated_on'] ?? null,
    //                 'percentage_value' => $detail['percentage_value'] ?? 0,
    //                 'fixed_amount' => $detail['fixed_amount'] ?? $detail['calculated_amount'],
    //                 'calculated_amount' =>$detail['calculated_amount'],
    //                 'monthly_variable' =>$detail['monthly_variable'] ?? 0,
    //                 'include_in_gross' =>$detail['include_in_gross'] ?? 0,
    //                 'include_in_ctc' => $detail['include_in_ctc'] ?? 1,
    //                 'include_in_payslip' =>$detail['include_in_payslip'] ?? 1,
    //                 'display_order' =>$detail['display_order'] ?? ($index + 1),
    //                 'remarks' =>$detail['remarks'] ?? null,
    //                 'status' => 0,
    //                 'created_by' => auth()->id(),
    //             ]);
    //         }

    //         /*
    //     |--------------------------------------------------------------------------
    //     | UPDATE STAFF GROSS
    //     |--------------------------------------------------------------------------
    //     */
    //         StaffModel::where('sno',$request->employee_sno)
    //             ->update(['basic_salary' =>$request->gross_salary,]);

    //         DB::commit();

    //         return response()->json([
    //             'status' => true,
    //             'message' =>
    //             'Employee salary structure saved successfully'
    //         ]);

    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         return response()->json([
    //             'status' => false,
    //             'message' => $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function saveEmployeeStructure(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'employee_sno'   => 'required|integer',
                'salary_account_id' =>'required|integer',
                'gross_salary'   => 'required|numeric|min:0',
                'effective_from' => 'required|date',
                'details'        => 'required|array|min:1',
            ]);

            $effectiveDate = Carbon::parse($request->effective_from)->format('Y-m-d');

            $earnings = 0;
            $deductions = 0;
            $employerContribution = 0;

            foreach ($request->details as $detail) {
                $amount = (float) ($detail['calculated_amount'] ?? 0);

                if ($detail['component_type'] == 'earning') {
                    $earnings += $amount;
                } elseif ($detail['component_type'] == 'deduction') {
                    $deductions += $amount;
                } elseif ($detail['component_type'] == 'employer_contribution') {
                    $employerContribution += $amount;
                }
            }

            $netSalary = $earnings - $deductions;
            $ctcAmount = $earnings + $employerContribution;

            $structure = PayrollStaffStructureModel::where('employee_sno',$request->employee_sno)
                        ->where('salary_account_id',$request->salary_account_id)
                        ->whereDate('effective_from', $effectiveDate)
                        ->where('status', 0)
                        ->first();

            $fixedGrossSalary = $request->gross_salary;
            $workingDays = 30;
            $perDaySalary = $fixedGrossSalary / $workingDays;
            $perDaySalary = ($perDaySalary * 100) / 100;
            $perDaySalaryCost = round($perDaySalary,2);
           
            $workingHours = 8;
            $perHour = $fixedGrossSalary / (30 * $workingHours);
            $perHour = ($perHour * 100) / 100;
            $perHourCost = round($perHour,2);
           

            if ($structure) {
                $structure->update([
                    'payroll_template_sno' => $request->payroll_template_sno,
                    'gross_salary' => $request->gross_salary,
                    'per_day_salary' => $perDaySalaryCost,
                    'per_hour_cost' => $perHourCost,
                    'total_earnings' => round($earnings, 2),
                    'total_deductions' => round($deductions, 2),
                    'net_salary' => round($netSalary, 2),
                    'employer_contribution' => round($employerContribution, 2),
                    'ctc_amount' => round($ctcAmount, 2),
                    'revision_reason' => $request->revision_reason,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]);
            } else {

                PayrollStaffStructureModel::where('employee_sno',$request->employee_sno)
                ->where('salary_account_id', $request->salary_account_id)
                ->where('is_current', 1)
                ->update([
                    'is_current' => 0,
                    'effective_to' => Carbon::parse($effectiveDate)->subDay()->format('Y-m-d'),
                ]);

                $structure = PayrollStaffStructureModel::create([
                                'employee_sno' => $request->employee_sno,
                                'salary_account_id' =>$request->salary_account_id,
                                'payroll_template_sno' => $request->payroll_template_sno,
                                'structure_code' =>'SAL-' . time() . rand(100, 999),
                                'structure_name' => 'Employee Salary Structure',
                                'gross_salary' =>  $request->gross_salary,
                                'per_day_salary' => $perDaySalaryCost,
                                'per_hour_cost' => $perHourCost,
                                'total_earnings' => round($earnings, 2),
                                'total_deductions' =>round($deductions, 2),
                                'net_salary' => round($netSalary, 2),
                                'employer_contribution' => round($employerContribution, 2),
                                'ctc_amount' => round($ctcAmount, 2),
                                'revision_reason' => $request->revision_reason,
                                'effective_from' => $effectiveDate,
                                'is_current' => 1,
                                'status' => 0,
                                'created_by' => $request->user()->user_id ?? 0,
                ]);
            }

            $existingDetails =PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno',$structure->sno)
                                ->where('status', 0)
                                ->get()
                                ->keyBy('payroll_component_sno');

            $currentComponentIds = [];

            foreach ($request->details as $index => $detail) {

                $componentId =
                    $detail['payroll_component_sno'];

                $currentComponentIds[] =
                    $componentId;

                $detailData = [

                    'payroll_rule_sno' =>
                        $detail['payroll_rule_sno'] ?? null,

                    'component_type' =>
                        $detail['component_type'],

                    'calculation_type' =>
                        $detail['calculation_type'],

                    'calculated_on' =>
                        $detail['calculated_on'] ?? null,

                    'percentage_value' =>
                        $detail['percentage_value'] ?? 0,

                    'fixed_amount' =>
                        $detail['fixed_amount']
                            ?? $detail['calculated_amount'],

                    'calculated_amount' =>
                        $detail['calculated_amount'],

                    'monthly_variable' =>
                        $detail['monthly_variable'] ?? 0,

                    'include_in_gross' =>
                        $detail['include_in_gross'] ?? 0,

                    'include_in_ctc' =>
                        $detail['include_in_ctc'] ?? 1,

                    'include_in_payslip' =>
                        $detail['include_in_payslip'] ?? 1,

                    'display_order' =>
                        $detail['display_order']
                            ?? ($index + 1),

                    'remarks' =>
                        $detail['remarks'] ?? null,

                    'updated_by' =>
                        $request->user()->user_id ?? 0,
                ];

                if (
                    isset(
                        $existingDetails[$componentId]
                    )
                ) {

                    $existingDetails[$componentId]
                        ->update($detailData);

                } else {

                    PayrollStaffStructureDetailModel::create(

                        array_merge(
                            $detailData,
                            [

                                'payroll_employee_structure_sno' =>
                                    $structure->sno,

                                'payroll_component_sno' =>
                                    $componentId,

                                'status' => 0,

                                'created_by' =>
                                    $request->user()->user_id ?? 0,
                            ]
                        )
                    );
                }
            }

            PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno',$structure->sno)
            ->where('status', 0)
            ->whereNotIn('payroll_component_sno',$currentComponentIds)
            ->update([
                'status' => 2,
                'updated_by' => $request->user()->user_id ?? 0,
            ]);

            /*
            |--------------------------------------------------------------------------
            | UPDATE STAFF SALARY
            |--------------------------------------------------------------------------
            */

            $SalaryAccounts =StaffSalaryAccountModel::where('egc_staff_salary_accounts.sno',$request->salary_account_id)->first();

            $SalaryAccounts->per_day_salary =$perDaySalaryCost;
            $SalaryAccounts->per_hour_cost =$perHourCost;
            $SalaryAccounts->gross_salary =$fixedGrossSalary;
            $SalaryAccounts->update();

            $SalaryTotalGross =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('gross_salary');
            $SalaryTotalPerDay =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('per_day_salary');
            $SalaryTotalPerHr =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('per_hour_cost');

            StaffModel::where('sno',$request->employee_sno)->update([
                'basic_salary' =>$SalaryTotalGross,
                'per_day_salary' =>$SalaryTotalPerDay,
                'per_hour_cost' =>$SalaryTotalPerHr,
            ]);

            DB::commit();

            return response()->json([
                'status' => true,
                'message' =>
                    'Employee salary structure saved successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function GetEmployeeStructure($id,$salaryAccountId)
    {
        try {

            /*
            |--------------------------------------------------------------------------
            | EMPLOYEE INFO
            |--------------------------------------------------------------------------
            */

            $employee = DB::table('egc_staff_salary_accounts')
                ->join('egc_staff','egc_staff.sno','=','egc_staff_salary_accounts.staff_id')
                ->where('egc_staff.sno', $id)
                ->where('egc_staff_salary_accounts.sno', $salaryAccountId)
                ->select(
                    'egc_staff.sno',
                    'egc_staff.staff_name as employee_name',
                    'egc_staff.staff_id as employee_code',
                    'egc_staff_salary_accounts.gross_salary',
                )

                ->first();

            if (!$employee) {

                return response()->json([

                    'status' => false,

                    'message' => 'Employee not found'

                ], 404);
            }

            /*
            |--------------------------------------------------------------------------
            | CURRENT STRUCTURE
            |--------------------------------------------------------------------------
            */

            $structure = DB::table('egc_payroll_employee_structures as es')

                ->leftJoin(
                    'egc_payroll_salary_templates as st',
                    'st.sno',
                    '=',
                    'es.payroll_template_sno'
                )

                ->where('es.employee_sno', $id)
                ->where('es.salary_account_id',$salaryAccountId)
                ->where('es.is_current', 1)

                ->select(
                    'es.*',
                    'st.template_name',
                    'st.template_code'
                )

                ->first();

            /*
            |--------------------------------------------------------------------------
            | DEFAULT RESPONSE
            |--------------------------------------------------------------------------
            */

            $details = collect([]);

            /*
            |--------------------------------------------------------------------------
            | DETAILS
            |--------------------------------------------------------------------------
            */

            if ($structure) {

                $details = DB::table(
                    'egc_payroll_employee_structure_details as d'
                )

                    ->join(
                        'egc_payroll_components as c',
                        'c.sno',
                        '=',
                        'd.payroll_component_sno'
                    )

                    ->leftJoin(
                        'egc_payroll_rules as r',
                        'r.id',
                        '=',
                        'd.payroll_rule_sno'
                    )

                    ->where(
                        'd.payroll_employee_structure_sno',
                        $structure->sno
                    )

                    ->orderBy('d.display_order', 'ASC')

                    ->select(

                        'd.sno',

                        'd.payroll_component_sno',

                        'd.payroll_rule_sno',

                        'd.component_type',

                        'd.calculation_type',

                        'd.calculated_on',

                        'd.percentage_value',

                        'd.fixed_amount',

                        'd.calculated_amount',

                        'd.monthly_variable',

                        'd.include_in_gross',

                        'd.include_in_ctc',

                        'd.include_in_payslip',

                        'd.display_order',

                        'd.remarks',

                        'c.component_name',

                        'c.component_code',

                        'r.rule_name'

                    )

                    ->get();
            }

            /*
            |--------------------------------------------------------------------------
            | RESPONSE
            |--------------------------------------------------------------------------
            */

            return response()->json([

                'status' => true,

                'message' => 'Employee salary structure fetched successfully',

                'data' => [

                    'employee' => $employee,

                    'structure' => $structure,

                    'details' => $details

                ]

            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => 'Failed to fetch employee salary structure',

                'error' => $e->getMessage()

            ], 500);
        }
    }

    public function GetTemplateComponents($id)
    {
        try {

            $template = DB::table('egc_payroll_salary_templates')

                ->where('sno', $id)

                ->first();

            if (!$template) {

                return response()->json([

                    'status' => false,

                    'message' => 'Salary template not found'

                ], 404);
            }

            $details = DB::table(
                'egc_payroll_salary_template_details as d'
            )

                ->join(
                    'egc_payroll_components as c',
                    'c.sno',
                    '=',
                    'd.component_sno'
                )

                ->leftJoin(
                    'egc_payroll_rules as r',
                    'r.id',
                    '=',
                    'd.payroll_rule_sno'
                )

                ->where(
                    'd.template_sno',
                    $id
                )

                ->orderBy('c.display_order', 'ASC')

                ->select(

                    'd.*',

                    'c.component_name',

                    'c.component_code',

                    'r.rule_name',
                    'r.rule_expression',


                )

                ->get();

            return response()->json([

                'status' => true,

                'message' => 'Template fetched successfully',

                'data' => [

                    'template' => $template,

                    'details' => $details

                ]

            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => 'Failed to fetch template',

                'error' => $e->getMessage()

            ], 500);
        }
    }

    //     public function saveEmployeeStructure(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {

    //         /*
    //         |--------------------------------------------------------------------------
    //         | VALIDATION
    //         |--------------------------------------------------------------------------
    //         */

    //         $request->validate([

    //             'employee_sno' => 'required|integer',

    //             'payroll_template_sno' => 'nullable|integer',

    //             'gross_salary' => 'required|numeric|min:0',

    //             'effective_from' => 'required',

    //             'details' => 'required|array|min:1',

    //             'details.*.payroll_component_sno' => 'required|integer',

    //             'details.*.component_type' => 'required',

    //             'details.*.calculation_type' => 'required',

    //             'details.*.calculated_amount' => 'required|numeric|min:0',

    //         ]);

    //         /*
    //         |--------------------------------------------------------------------------
    //         | EMPLOYEE CHECK
    //         |--------------------------------------------------------------------------
    //         */

    //         $employee = DB::table('egc_staff')

    //             ->where('sno', $request->employee_sno)

    //             ->first();

    //         if (!$employee) {

    //             return response()->json([

    //                 'status' => false,

    //                 'message' => 'Employee not found'

    //             ], 404);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | OLD CURRENT STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         $oldStructure = PayrollStaffStructureModel::where(
    //             'employee_sno',
    //             $request->employee_sno
    //         )
    //             ->where('is_current', 1)
    //             ->first();

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CLOSE OLD STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         if ($oldStructure) {

    //             $oldStructure->update([

    //                 'is_current' => 0,

    //                 'effective_to' => Carbon::now()
    //                     ->format('Y-m-d'),

    //                 'updated_by' => $request->user()->user_id ?? 0

    //             ]);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | REVISION NUMBER
    //         |--------------------------------------------------------------------------
    //         */

    //         $revisionNo = 1;

    //         if ($oldStructure) {

    //             $revisionNo =
    //                 ($oldStructure->revision_no ?? 1) + 1;
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CALCULATE TOTALS
    //         |--------------------------------------------------------------------------
    //         */

    //         $earnings = 0;

    //         $deductions = 0;

    //         $employerContribution = 0;

    //         foreach ($request->details as $detail) {

    //             $amount = (float)
    //                 $detail['calculated_amount'];

    //             if (
    //                 $detail['component_type']
    //                 == 'earning'
    //             ) {

    //                 $earnings += $amount;
    //             }

    //             else if (
    //                 $detail['component_type']
    //                 == 'deduction'
    //             ) {

    //                 $deductions += $amount;
    //             }

    //             else if (
    //                 $detail['component_type']
    //                 == 'employer_contribution'
    //             ) {

    //                 $employerContribution += $amount;
    //             }
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | FINAL CALCULATIONS
    //         |--------------------------------------------------------------------------
    //         */

    //         $netSalary =
    //             $earnings - $deductions;

    //         $ctc =
    //             $earnings + $employerContribution;

    //         /*
    //         |--------------------------------------------------------------------------
    //         | CREATE STRUCTURE
    //         |--------------------------------------------------------------------------
    //         */

    //         $structure =
    //             PayrollStaffStructureModel::create([

    //                 'employee_sno' =>
    //                     $request->employee_sno,

    //                 'payroll_template_sno' =>
    //                     $request->payroll_template_sno,

    //                 'structure_code' =>
    //                     'SAL-' .
    //                     strtoupper(Str::random(8)),

    //                 'structure_name' =>
    //                     'Employee Salary Structure',

    //                 'gross_salary' =>
    //                     $request->gross_salary,

    //                 'total_earnings' =>
    //                     $earnings,

    //                 'total_deductions' =>
    //                     $deductions,

    //                 'net_salary' =>
    //                     $netSalary,

    //                 'employer_contribution' =>
    //                     $employerContribution,

    //                 'ctc_amount' =>
    //                     $ctc,

    //                 'revision_no' =>
    //                     $revisionNo,

    //                 'revision_reason' =>
    //                     $request->revision_reason,

    //                 'effective_from' =>
    //                     Carbon::parse(
    //                         $request->effective_from
    //                     )->format('Y-m-d'),

    //                 'is_current' => 1,

    //                 'payroll_lock' => 0,

    //                 'status' => 1,

    //                 'remarks' =>
    //                     $request->remarks,

    //                 'created_by' =>
    //                     $request->user()->user_id ?? 0,

    //                 'updated_by' =>
    //                     $request->user()->user_id ?? 0,

    //             ]);

    //         /*
    //         |--------------------------------------------------------------------------
    //         | SAVE COMPONENT DETAILS
    //         |--------------------------------------------------------------------------
    //         */

    //         foreach (
    //             $request->details as $index => $detail
    //         ) {

    //             PayrollStaffStructureDetailModel::create([

    //                 'payroll_employee_structure_sno' =>
    //                     $structure->sno,

    //                 'payroll_component_sno' =>
    //                     $detail['payroll_component_sno'],

    //                 'payroll_rule_sno' =>
    //                     $detail['payroll_rule_sno'] ?? null,

    //                 'component_type' =>
    //                     $detail['component_type'],

    //                 'calculation_type' =>
    //                     $detail['calculation_type'],

    //                 'calculated_on' =>
    //                     $detail['calculated_on'] ?? null,

    //                 'percentage_value' =>
    //                     $detail['percentage_value'] ?? 0,

    //                 /*
    //                 |--------------------------------------------------------------------------
    //                 | FIXED AMOUNT
    //                 |--------------------------------------------------------------------------
    //                 */

    //                 'fixed_amount' =>

    //                     $detail['calculation_type']
    //                     == 'fixed'

    //                     ? $detail['calculated_amount']

    //                     : 0,

    //                 /*
    //                 |--------------------------------------------------------------------------
    //                 | FINAL CALCULATED AMOUNT
    //                 |--------------------------------------------------------------------------
    //                 */

    //                 'calculated_amount' =>
    //                     $detail['calculated_amount'],

    //                 'monthly_variable' =>
    //                     $detail['monthly_variable'] ?? 0,

    //                 'include_in_gross' =>
    //                     $detail['include_in_gross'] ?? 1,

    //                 'include_in_ctc' =>
    //                     $detail['include_in_ctc'] ?? 1,

    //                 'include_in_payslip' =>
    //                     $detail['include_in_payslip'] ?? 1,

    //                 'display_order' =>
    //                     $index + 1,

    //                 'remarks' =>
    //                     $detail['remarks'] ?? null,

    //                 'status' => 1,

    //             ]);
    //         }

    //         /*
    //         |--------------------------------------------------------------------------
    //         | UPDATE STAFF GROSS SALARY
    //         |--------------------------------------------------------------------------
    //         */

    //         DB::table('egc_staff')

    //             ->where('sno', $request->employee_sno)

    //             ->update([

    //                 'gross_salary' =>
    //                     $request->gross_salary
    //             ]);

    //         DB::commit();

    //         return response()->json([

    //             'status' => true,

    //             'message' =>
    //                 'Employee salary structure saved successfully',

    //             'data' => [

    //                 'structure_sno' =>
    //                     $structure->sno,

    //                 'net_salary' =>
    //                     $netSalary,

    //                 'ctc_amount' =>
    //                     $ctc

    //             ]

    //         ]);

    //     } catch (\Illuminate\Validation\ValidationException $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' => 'Validation failed',

    //             'errors' => $e->errors()

    //         ], 422);

    //     } catch (\Exception $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' =>
    //                 'Failed to save employee salary structure',

    //             'error' => $e->getMessage()

    //         ], 500);
    //     }
    // }


    public function calculateTemplatePreview(Request $request)
    {
        $grossSalary = $request->gross_salary;

        $details = $request->details;

        $earnings = [];
        $deductions = [];

        $basic = 0;
        $da = 0;

        /*
    |--------------------------------------------------------------------------
    | EARNINGS
    |--------------------------------------------------------------------------
    */

        foreach ($details as $detail) {

            $component = DB::table('egc_payroll_components')
                ->where('sno', $detail['component_sno'])
                ->first();

            $amount = 0;

            if ($component->calculation_type == 'percentage') {

                $amount =
                    ($grossSalary * $component->percentage_value) / 100;
            }

            if ($component->calculation_type == 'fixed') {

                $amount = $detail['amount'];
            }

            if ($component->component_code == 'BASIC') {
                $basic = $amount;
            }

            if ($component->component_code == 'DA') {
                $da = $amount;
            }

            if ($component->category == 'earning') {

                $earnings[] = [
                    'component' => $component->component_name,
                    'amount' => round($amount, 2)
                ];
            }
        }

        $grossEarnings =
            collect($earnings)->sum('amount');

        /*
    |--------------------------------------------------------------------------
    | DEDUCTIONS
    |--------------------------------------------------------------------------
    */

        foreach ($details as $detail) {

            $component = DB::table('egc_payroll_components')
                ->where('sno', $detail['component_sno'])
                ->first();

            if ($component->category != 'deduction') {
                continue;
            }

            $amount = 0;

            /*
        |--------------------------------------------------------------------------
        | PF
        |--------------------------------------------------------------------------
        */

            if ($component->component_code == 'PF') {

                $pfBase = $basic + $da;

                $amount =
                    $pfBase > 15000
                    ? 1800
                    : ($pfBase * 0.12);
            }

            /*
        |--------------------------------------------------------------------------
        | ESI
        |--------------------------------------------------------------------------
        */ else if ($component->component_code == 'ESI') {

                $amount =
                    $grossEarnings <= 21000
                    ? ($grossEarnings * 0.0075)
                    : 0;
            }

            /*
        |--------------------------------------------------------------------------
        | FIXED
        |--------------------------------------------------------------------------
        */ else if ($component->calculation_type == 'fixed') {

                $amount = $detail['amount'];
            }

            $deductions[] = [

                'component' =>
                $component->component_name,

                'amount' =>
                round($amount, 2)
            ];
        }

        $totalDeduction =
            collect($deductions)->sum('amount');

        return response()->json([

            'earnings' => $earnings,

            'deductions' => $deductions,

            'gross' => round($grossEarnings, 2),

            'deduction_total' => round($totalDeduction, 2),

            'net' =>
            round(
                $grossEarnings - $totalDeduction,
                2
            )
        ]);
    }

    // public function SaveVariableAmount(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {

    //         $startMonth = Carbon::parse(
    //             $request->start_month . '-01'
    //         );

    //         $endMonth =
    //             $startMonth->copy()->addMonths(2);

    //         DB::table(
    //             'egc_payroll_variable_amounts'
    //         )->insert([

    //             'employee_sno' =>
    //             $request->employee_sno,

    //             'payroll_component_sno' =>
    //             $request->payroll_component_sno,

    //             'amount' =>
    //             $request->amount,

    //             'start_month' =>
    //             $startMonth,

    //             'end_month' =>
    //             $endMonth,

    //             'remarks' =>
    //             $request->remarks,

    //             'created_by' =>
    //             $user_id,

    //             'created_at' =>
    //             now(),

    //             'updated_at' =>
    //             now(),
    //         ]);

    //         DB::commit();

    //         return response()->json([

    //             'status' => true,

    //             'message' =>
    //             'Variable amount saved successfully'
    //         ]);
    //     } catch (\Exception $e) {

    //         DB::rollBack();

    //         return response()->json([

    //             'status' => false,

    //             'message' => $e->getMessage()

    //         ], 500);
    //     }
    // }


    public function SaveVariableAmount(Request $request)
    {
        DB::beginTransaction();
        try {

            $request->validate([
                'employee_sno' => 'required',
                'payroll_component_sno' => 'required',
                'amount' => 'required|numeric|min:0',
                'start_month' => 'required',
            ]);


            $startMonth = Carbon::createFromFormat(
                'M-Y',
                $request->start_month
            )->startOfMonth();

            $endMonth = $startMonth
                ->copy()
                ->addMonths(2)
                ->endOfMonth();
            $activeVariable = DB::table('egc_payroll_variable_amounts')
                ->where('employee_sno', $request->employee_sno)
                ->where('payroll_component_sno', $request->payroll_component_sno)
                ->whereDate('end_month', '>=', now())
                ->where('status', 0)
                ->first();

            if ($activeVariable) {
                DB::table('egc_payroll_variable_amounts')
                    ->where('sno', $activeVariable->sno)
                    ->update([
                        'amount' => $request->amount,
                        'remarks' => $request->remarks,
                        'updated_by' => $user_id,
                        'updated_at' => now(),
                    ]);
                DB::commit();
                return response()->json([
                    'status' => true,
                    'message' => 'Variable amount updated successfully'
                ]);
            }

            DB::table(
                'egc_payroll_variable_amounts'
            )->insert([
                'employee_sno' => $request->employee_sno,
                'payroll_component_sno' => $request->payroll_component_sno,
                'amount' => $request->amount,
                'start_month' => $startMonth->format('Y-m-d'),
                'end_month' => $endMonth->format('Y-m-d'),
                'remarks' => $request->remarks,
                'status' => 0,
                'created_by' => session('sno'),
                'updated_by' => session('sno'),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            DB::commit();
            return response()->json([
                'status' => true,
                'message' =>
                'Variable amount saved successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => $e->getMessage()

            ], 500);
        }
    }
    public function GetVariableAmount($employeeId)
    {
        try {

            $data = DB::table(
                'egc_payroll_variable_amounts'
            )

                ->where('employee_sno', $employeeId)

                ->where('status', 0)

                ->whereDate('end_month', '>=', now())

                ->latest('sno')

                ->first();

            return response()->json([

                'status' => true,

                'data' => $data
            ]);
        } catch (\Exception $e) {

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ], 500);
        }
    }

    // public function bulkPreview()
    // {
    //     $employees = DB::table('egc_staff as s')

    //         ->leftJoin(
    //             'egc_payroll_employee_structures as es',
    //             function ($join) {

    //                 $join->on(
    //                     'es.employee_sno',
    //                     '=',
    //                     's.sno'
    //                 )
    //                     ->where('es.is_current', 1);
    //             }
    //         )

    //         ->whereNull('es.sno')

    //         ->where('s.status', '!=', 2)

    //         ->whereIn('s.salary_type', [1, 2])

    //         ->select(
    //             's.sno',
    //             's.staff_name',
    //             's.staff_id',
    //             's.salary_type',
    //             's.basic_salary',
    //             DB::raw("
    //             CASE
    //                 WHEN s.salary_type = 1
    //                 THEN 'Template 1'
    //                 ELSE 'Template 2'
    //             END as template_name
    //         ")
    //         )

    //         ->get();

    //     return response()->json([

    //         'status' => true,

    //         'data' => $employees

    //     ]);
    // }

    public function bulkPreview(Request $request)
{
    $employees = DB::table('egc_staff as s')

        ->leftJoin(
            'egc_payroll_employee_structures as es',
            function ($join) {

                $join->on(
                    'es.employee_sno',
                    '=',
                    's.sno'
                )
                ->where('es.is_current',1);
            }
        )

        ->leftJoin(
            'egc_payroll_salary_templates as t',
            't.sno',
            '=',
            'es.payroll_template_sno'
        )

        ->where('s.status','!=',2)

        ->whereIn(
            's.salary_type',
            [1,2]
        )

        ->select(
            's.sno',
            's.staff_name',
            's.staff_id',
            's.salary_type',
            's.basic_salary',

            't.template_name as current_template',

            'es.effective_from',

            'es.effective_to',

            'es.sno as structure_sno'
        )

        ->orderBy('s.staff_name')

        ->get();

    return response()->json([
        'status'=>true,
        'data'=>$employees
    ]);
}

    public function bulkSave(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'template_type_1' => 'required|integer',
                'template_type_2' => 'required|integer',
                'effective_from' => 'required|date',
            ]);

            /*
        |--------------------------------------------------------------------------
        | STAFF LIST
        |--------------------------------------------------------------------------
        */

            $employees = StaffModel::where('status', '!=', 2)
                ->whereIn('salary_type', [1, 2])
                ->select(
                    'sno',
                    'staff_name',
                    'salary_type',
                    'basic_salary'
                )
                ->get();

            /*
            |--------------------------------------------------------------------------
            | LOAD TEMPLATE DETAILS ONCE
            |--------------------------------------------------------------------------
            */

            $template1Details = DB::table(
                'egc_payroll_salary_template_details as d'
            )
                ->join(
                    'egc_payroll_components as c',
                    'c.sno',
                    '=',
                    'd.component_sno'
                )
                ->leftJoin(
                    'egc_payroll_rules as r',
                    'r.id',
                    '=',
                    'd.payroll_rule_sno'
                )
                ->where(
                    'd.template_sno',
                    $request->template_type_1
                )
                ->orderBy('c.display_order')
                ->select(
                    'd.*',
                    'c.component_code',
                    'r.rule_expression'
                )
                ->get();

            $template2Details = DB::table(
                'egc_payroll_salary_template_details as d'
            )
                ->join(
                    'egc_payroll_components as c',
                    'c.sno',
                    '=',
                    'd.component_sno'
                )
                ->leftJoin(
                    'egc_payroll_rules as r',
                    'r.id',
                    '=',
                    'd.payroll_rule_sno'
                )
                ->where(
                    'd.template_sno',
                    $request->template_type_2
                )
                ->orderBy('c.display_order')
                ->select(
                    'd.*',
                    'c.component_code',
                    'r.rule_expression'
                )
                ->get();

            $createdCount = 0;

            foreach ($employees as $employee) {

                /*
            |--------------------------------------------------------------------------
            | SKIP IF CURRENT STRUCTURE EXISTS
            |--------------------------------------------------------------------------
            */

                $currentStructure =
                PayrollStaffStructureModel::where(
                    'employee_sno',
                    $employee->sno
                )
                ->where('is_current',1)
                ->first();

                if($currentStructure){

                    $effectiveFrom =
                        Carbon::parse(
                            $request->effective_from
                        );

                    $currentStructure->update([

                        'is_current' => 0,

                        'effective_to' =>
                            $effectiveFrom
                                ->copy()
                                ->subDay()
                                ->format('Y-m-d')
                    ]);
                }


                $templateId =
                    $employee->salary_type == 1
                    ? $request->template_type_1
                    : $request->template_type_2;

                $templateDetails =
                    $employee->salary_type == 1
                    ? $template1Details
                    : $template2Details;

                $earnings = 0;
                $deductions = 0;
                $employerContribution = 0;

                $componentAmounts = [];

                /*
            |--------------------------------------------------------------------------
            | CALCULATE EARNINGS FIRST
            |--------------------------------------------------------------------------
            */

                foreach ($templateDetails as $detail) {

                    $amount = 0;

                    if (
                        $detail->calculation_type == 'percentage'
                    ) {

                        $amount =
                            (
                                $employee->basic_salary
                                * $detail->percentage
                            ) / 100;
                    } elseif (
                        $detail->calculation_type == 'fixed'
                    ) {

                        $amount = $detail->amount;
                    }

                    if (
                        $detail->component_type == 'earning'
                    ) {

                        $earnings += $amount;
                    }



                    $componentAmounts[$detail->component_code] = $amount;
                }

                /*
            |--------------------------------------------------------------------------
            | DEDUCTIONS
            |--------------------------------------------------------------------------
            */

                foreach ($templateDetails as $detail) {

                    $amount = 0;

                                /*
                |--------------------------------------------------------------------------
                | PROCESS ONLY DEDUCTION & EMPLOYER
                |--------------------------------------------------------------------------
                */

                    if (
                        !in_array(
                            $detail->component_type,
                            ['deduction', 'employer_contribution']
                        )
                    ) {
                        continue;
                    }

                    /*
                |--------------------------------------------------------------------------
                | BASIC + DA
                |--------------------------------------------------------------------------
                */

                    $basic = $componentAmounts['BASIC'] ?? 0;
                    $da     = $componentAmounts['DA'] ?? 0;

                    /*
                |--------------------------------------------------------------------------
                | PF / EMPLOYER PF
                |--------------------------------------------------------------------------
                */

                    if ($detail->component_code == 'PF' &&
                        $detail->calculation_type !== 'fixed') {

                        $pfBase = $basic + $da;

                        $amount =
                            $pfBase > 15000
                            ? 1800
                            : ($pfBase * 0.12);
                    } elseif ($detail->component_code == 'EMPLOYER_PF' &&
                        $detail->calculation_type !== 'fixed') {

                        $pfBase = $basic + $da;

                        $amount =
                            $pfBase > 15000
                            ? 1950
                            : ($pfBase * 0.13);
                    }elseif ($detail->component_code == 'ESI'  &&
                        $detail->calculation_type !== 'fixed') {

                        $esiBase = $basic + $da;

                        // $amount =
                        //     $earnings <= 21000
                        //     ? ($earnings * 0.0075)
                        //     : 0;
                        $amount =
                            $esiBase <= 21000
                            ? ($esiBase * 0.0075)
                            : 0;
                    } elseif ($detail->component_code == 'EMPLOYER_ESI'  &&
                        $detail->calculation_type !== 'fixed') {

                            $esiBase = $basic + $da;

                        // $amount =
                        //     $earnings <= 21000
                        //     ? ($earnings * 0.0325)
                        //     : 0;
                        $amount =
                            $esiBase <= 21000
                            ? ($esiBase * 0.0325)
                            : 0;
                    }elseif ($detail->calculation_type == 'percentage') {

                        $amount =
                            ($employee->basic_salary * $detail->percentage) / 100;
                    } elseif ($detail->calculation_type == 'fixed') {

                        if($detail->component_code == 'ESI'){

                         $esiBase = $basic + $da;

                            $amount =
                                $earnings <= 21000
                                ? $detail->amount
                                : 0;
                       
                            
                        }elseif($detail->component_code == 'EMPLOYER_ESI'){
                            $esiBase = $basic + $da;

                            $amount =
                                $earnings <= 21000
                                ? $detail->amount
                                : 0;
                        }elseif ($detail->component_code == 'PT') {
                            switch (true) {

                                case $earnings <= 10000:
                                    $amount = 140;
                                    break;

                                default:
                                    $amount = 208;
                                    break;
                            }
                        }else{
                            $amount = $detail->amount;
                        }

                        
                    }

                    /*
                |--------------------------------------------------------------------------
                | FORMULA
                |--------------------------------------------------------------------------
                */ elseif (
                        $detail->calculation_type == 'formula'
                        && !empty($detail->rule_expression)
                    ) {

                        try {

                            $formula = $detail->rule_expression;

                            $formula = str_replace(
                                ['gross_salary', 'basic', 'da'],
                                [
                                    $earnings,
                                    $basic,
                                    $da
                                ],
                                $formula
                            );

                            eval("\$amount = $formula;");
                        } catch (\Exception $e) {

                            $amount = 0;
                        }
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | ROUND
                    |--------------------------------------------------------------------------
                    */

                    $amount = round($amount, 2);

                    /*
                    |--------------------------------------------------------------------------
                    | ADD TOTALS
                    |--------------------------------------------------------------------------
                    */

                    if ($detail->component_type == 'deduction') {

                        $deductions += $amount;
                    }

                    if ($detail->component_type == 'employer_contribution') {

                        $employerContribution += $amount;
                    }

                    /*
                        |--------------------------------------------------------------------------
                        | STORE COMPONENT
                        |--------------------------------------------------------------------------
                        */

                    $componentAmounts[$detail->component_code] = $amount;
                }

                $net = $earnings - $deductions;
                $ctc = $earnings + $employerContribution;

                /*
            |--------------------------------------------------------------------------
            | CREATE STRUCTURE
            |--------------------------------------------------------------------------
            */

                $structure =
                    PayrollStaffStructureModel::create([

                        'employee_sno' =>
                        $employee->sno,

                        'payroll_template_sno' =>
                        $templateId,

                        'structure_code' =>
                        'SAL-' .
                            time() .
                            rand(1000, 9999),

                        'structure_name' =>
                        'Employee Salary Structure',

                        'gross_salary' =>
                        $employee->basic_salary,

                        'total_earnings' =>
                        round($earnings, 2),

                        'total_deductions' =>
                        round($deductions, 2),

                        'net_salary' =>
                        round($net, 2),

                        'employer_contribution' =>
                        round($employerContribution, 2),

                        'ctc_amount' =>
                        round($ctc, 2),

                        'revision_reason' =>
                        $request->revision_reason,

                        'effective_from' =>
                        Carbon::parse(
                            $request->effective_from
                        )->format('Y-m-d'),

                        'is_current' => 1,

                        'status' => 0,

                        'created_by' =>
                        auth()->id(),
                    ]);

                /*
            |--------------------------------------------------------------------------
            | DETAILS
            |--------------------------------------------------------------------------
            */

                foreach (
                    $templateDetails as $index => $detail
                ) {

                    PayrollStaffStructureDetailModel::create([

                        'payroll_employee_structure_sno' =>
                        $structure->sno,

                        'payroll_component_sno' =>
                        $detail->component_sno,

                        'payroll_rule_sno' =>
                        $detail->payroll_rule_sno,

                        'component_type' =>
                        $detail->component_type,

                        'calculation_type' =>
                        $detail->calculation_type,

                        'calculated_on' =>
                        $detail->calculated_on ?? null,

                        'percentage_value' =>
                        $detail->percentage ?? 0,

                        'fixed_amount' =>
                        $detail->amount ?? 0,

                        'calculated_amount' =>
                        $componentAmounts[$detail->component_code] ?? 0,

                        'monthly_variable' =>
                        $detail->monthly_variable ?? 0,

                        'include_in_gross' =>
                        $detail->affects_gross ?? 0,

                        'include_in_ctc' =>
                        $detail->employer_contribution ? 1 : 0,

                        'include_in_payslip' => 1,

                        'display_order' =>
                        $index + 1,

                        'remarks' => null,

                        'status' => 0,
                    ]);
                }

                $createdCount++;
            }

            DB::commit();

            return response()->json([

                'status' => true,

                'message' =>
                $createdCount .
                    ' employee salary structures created successfully'

            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ], 500);
        }
    }


public function GetOTDetails(Request $request)
{
    try {

        $employeeId = $request->employee_sno;

        $month = Carbon::createFromFormat(
            'M-Y',
            $request->month
        );

        $startDate = $month->copy()->startOfMonth();
        $endDate   = $month->copy()->endOfMonth();

        $parsedDate = Carbon::createFromFormat('M-Y', $request->month);
        $monthFilter = $parsedDate->month ?? date('m');
        $yearFilter  = $parsedDate->year ?? date('Y');

        /*
        |--------------------------------------------------------------------------
        | STAFF
        |--------------------------------------------------------------------------
        */

        $staff = DB::table('egc_staff')
            ->where('sno', $employeeId)
            ->where('company_id', 2)
            ->first();
            
        

        if (!$staff) {

            return response()->json([
                'status' => false,
                'message' => 'Staff not found'
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | ATTENDANCE
        |--------------------------------------------------------------------------
        */

    
        $attendanceRecords = DB::table('egc_staff_attendance')
            ->where('staff_id', $employeeId)
            ->whereMonth('date',$monthFilter)
            ->whereYear('date',$yearFilter)
            ->whereIn('attendance',['P', 'OD'])
            ->get();

      

        /*
        |--------------------------------------------------------------------------
        | SHIFT
        |--------------------------------------------------------------------------
        */

        $shiftLogs = DB::table(
                'egc_shift_time_log as stl'
            )

            ->join(
                'egc_shift_day_times as sdt',
                'stl.change_shift_id',
                '=',
                'sdt.shift_id'
            )

            ->where(
                'stl.staff_id',
                $employeeId
            )

            ->where(
                'sdt.status',
                0
            )

            ->select(
                'stl.start_date',
                'stl.end_date',
                'sdt.day_name',
                'sdt.time_from',
                'sdt.time_to'
            )

            ->get();

        /*
        |--------------------------------------------------------------------------
        | SALES
        |--------------------------------------------------------------------------
        */

        if ($staff->department_id == 12) {
  
            return $this->getSalesOT(
                $staff,
                $attendanceRecords,
                $shiftLogs
            );

        
        }

        /*
        |--------------------------------------------------------------------------
        | PRODUCTION
        |--------------------------------------------------------------------------
        */

        if ($staff->department_id == 13) {

            return $this->getProductionOT(
                $staff,
                $attendanceRecords,
                $shiftLogs
            );
        }

        return response()->json([
            'status' => true,
            'data' => []
        ]);

    } catch (\Exception $e) {

        return response()->json([
            'status' => false,
            'message' => $e->getMessage()
        ]);
    }
}

private function getSalesOT(
    $staff,
    $attendanceRecords,
    $shiftLogs
)
{
    $result = [];
    // return   $attendanceRecords;                              
    foreach ($attendanceRecords as $attendance) {

        $date = Carbon::parse($attendance->date);
        $dayName = strtolower( $date->format('D'));
        /*
        |--------------------------------------------------------------------------
        | WEEK OFF
        |--------------------------------------------------------------------------
        */
        $isWeekOff = ($dayName == 'sun');

        if (!$isWeekOff) {
            continue;
        }
        /*
        |--------------------------------------------------------------------------
        | ATTENDANCE TYPE
        |--------------------------------------------------------------------------
        */
        if ($attendance->attendance == 'OD') {
            $actualIn =Carbon::parse( $attendance->date . ' ' .$attendance->time_start);
            $actualOut =Carbon::parse( $attendance->date .' ' .$attendance->time_end);
        }
        else {
            $actualIn =Carbon::parse($attendance->date .' ' .$attendance->in_time);
            $actualOut =Carbon::parse($attendance->date .' ' .$attendance->out_time);
        }
        $otMinutes = $actualIn->diffInMinutes($actualOut);
        $otHours = round($otMinutes / 60,2);
        $perDaySalary = $staff->per_day_salary ?? 0;
        $perHourSalary =round($perDaySalary / 8, 2);

        if ($otHours >= 3) {
            $otAmount =round($perDaySalary,2);
            $otRate =round($perDaySalary,  2);
        }
        else {
            $otAmount =round( $perHourSalary * $otHours,2 );
            $otRate =round( $perHourSalary, 2);
        }

        $result[] = [
            'date' => $date->format('d-m-Y'),
            'day' => strtoupper($dayName),
            'attendance_type' => $attendance->attendance,
            'actual_in' => $actualIn->format('h:i A'),
            'actual_out' => $actualOut->format('h:i A'),
            'ot_hours' => $otHours,
            'ot_rate' => $otRate,
            'ot_amount' => $otAmount,
            'remarks' =>'Week Off OT',
            'attendance_date' => $attendance->date
        ];
    }

    return response()->json([
        'status' => true,
        'data' => $result
    ]);
}

private function getProductionOT(
    $staff,
    $attendanceRecords,
    $shiftLogs
)
{
    $result = [];

    foreach ($attendanceRecords as $attendance) {

        if (!in_array($attendance->attendance, ['P', 'OD'])) {
            continue;
        }

        $date = Carbon::parse($attendance->date);

        $dayName = strtolower($date->format('D'));

        // Default week off = Sunday
        $isWeekOff = ($dayName == 'sun');

        $shift = null;

        if (!$isWeekOff) {

            $shift = $shiftLogs->first(function ($s) use ($date, $dayName) {

                return strtolower($s->day_name) == $dayName
                    && $date->between(
                        Carbon::parse($s->start_date),
                        $s->end_date
                            ? Carbon::parse($s->end_date)
                            : now()->addYears(5)
                    );
            });

            if (!$shift) {
                continue;
            }
        }

        if ($attendance->attendance == 'OD') {

            $actualIn = Carbon::parse(
                $attendance->date . ' ' . $attendance->time_start
            );

            $actualOut = Carbon::parse(
                $attendance->date . ' ' . $attendance->time_end
            );

        } else {

            if (
                empty($attendance->in_time) ||
                empty($attendance->out_time)
            ) {
                continue;
            }

            $actualIn = Carbon::parse(
                $attendance->date . ' ' . $attendance->in_time
            );

            $actualOut = Carbon::parse(
                $attendance->date . ' ' . $attendance->out_time
            );
        }

        $workedMinutes = $actualIn->diffInMinutes($actualOut);

        if ($isWeekOff) {

            // Entire Sunday work is OT
            $otMinutes = $workedMinutes;

            $shiftTime = 'Week Off';

        } else {

            $shiftStart = Carbon::parse(
                $attendance->date . ' ' . $shift->time_from
            );

            $shiftEnd = Carbon::parse(
                $attendance->date . ' ' . $shift->time_to
            );

            // Handle overnight shift
            if ($shiftEnd->lt($shiftStart)) {
                $shiftEnd->addDay();
            }

            $shiftMinutes = $shiftStart->diffInMinutes($shiftEnd);

            $otMinutes = $workedMinutes - $shiftMinutes;

            $shiftTime =
                date('h:i A', strtotime($shift->time_from))
                . ' - ' .
                date('h:i A', strtotime($shift->time_to));
        }

        // Minimum 30 minutes OT
        if ($otMinutes <= 30) {
            continue;
        }

        $otHours = round($otMinutes / 60, 2);

        $perDaySalary = $staff->per_day_salary ?? 0;

        $perHourSalary = round($perDaySalary / 8, 2);

        $otAmount = round(
            $perHourSalary * $otHours,
            2
        );

        $result[] = [

            'date' => $date->format('d-m-Y'),

            'day' => strtoupper($dayName),

            'attendance_type' => $attendance->attendance,

            'shift_time' => $shiftTime,

            'actual_in' => $actualIn->format('h:i A'),

            'actual_out' => $actualOut->format('h:i A'),

            'worked_hours' => round(
                $workedMinutes / 60,
                2
            ),

            'ot_hours' => $otHours,

            'ot_rate' => $perHourSalary,

            'ot_amount' => $otAmount,

            'remarks' => $isWeekOff
                ? 'Week Off OT'
                : 'Production OT',

            'attendance_date' => $attendance->date
        ];
    }

    return response()->json([
        'status' => true,
        'data' => $result
    ]);
}


// public function SaveOTPayroll(Request $request)
// {
//     DB::beginTransaction();

//     try {

//         foreach ($request->rows as $row) {

//             DB::table(
//                 'egc_payroll_ot_transactions'
//             )->insert([

//                 'payroll_month' =>
//                     $request->payroll_month,

//                 'payroll_component_sno' => 16,

//                 'employee_sno' =>
//                     $request->employee_sno,

//                 'attendance_date' =>
//                     Carbon::createFromFormat(
//                         'd-m-Y',
//                         $row['attendance_date']
//                     )->format('Y-m-d'),

//                 'ot_amount' =>
//                     $row['ot_amount'],

//                 'remarks' =>
//                     $row['remarks'],

//                 'approval_status' =>
//                     'pending',

//                 'status' => 1,

//                 'created_at' => now(),

//                 'updated_at' => now()
//             ]);
//         }

//         DB::commit();

//         return response()->json([

//             'status' => true,

//             'message' =>
//                 'OT payroll saved successfully'
//         ]);
//     }

//     catch (\Exception $e) {

//         DB::rollBack();

//         return response()->json([

//             'status' => false,

//             'message' => $e->getMessage()
//         ]);
//     }
// }

public function SaveOTPayroll(Request $request)
{


    DB::beginTransaction();

    try {

        $request->validate([
            'employee_sno' => 'required|integer',
            'payroll_month' => 'required',
            'rows' => 'required|array'
        ]);

        foreach ($request->rows as $row) {

            if(empty($row['attendance_date'])){
                continue;
            }

            $exists = DB::table(
                'egc_payroll_ot_transactions'
            )

            ->where(
                'employee_sno',
                $request->employee_sno
            )

            ->where(
                'attendance_date',
                Carbon::parse(
                    $row['attendance_date']
                )->format('Y-m-d')
            )

            ->where(
                'payroll_month',
                $request->payroll_month
            )

            ->first();

            if ($exists) {

                DB::table(
                    'egc_payroll_ot_transactions'
                )

                ->where('sno', $exists->sno)

                ->update([

                    'ot_hours' =>
                        $row['ot_hours'],

                    'ot_amount' =>
                        $row['ot_amount'],

                    'remarks' =>
                        $row['remarks'],

                    'updated_at' => now()
                ]);

                continue;
            }

            DB::table(
                'egc_payroll_ot_transactions'
            )->insert([

                'payroll_month' =>$request->payroll_month,
                'payroll_component_sno' => 16,
                'employee_sno' =>$request->employee_sno,
                'attendance_date' =>Carbon::parse( $row['attendance_date'])->format('Y-m-d'),
                'ot_days' => 1,

                'ot_hours' =>
                    $row['ot_hours'],

                'ot_amount' =>
                    $row['ot_amount'],

                'remarks' =>
                    $row['remarks'],

                'approval_status' =>
                    'pending',

                'status' => 1,

                'created_at' => now(),

                'updated_at' => now()
            ]);
        }

        DB::commit();

        return response()->json([

            'status' => true,

            'message' =>
                'OT payroll saved successfully'
        ]);
    }

    catch (\Exception $e) {

        DB::rollBack();

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()
        ]);
    }
}


    public function getEmployeeSalaryAccounts($employeeId)
    {
        $accounts =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$employeeId)
            ->leftJoin('egc_company','egc_company.sno','=','egc_staff_salary_accounts.salary_company_id')
            ->where('egc_staff_salary_accounts.status',0)
            ->get([
                'egc_staff_salary_accounts.sno',
                'egc_company.company_name',
                'egc_staff_salary_accounts.salary_company_id',
                'egc_staff_salary_accounts.salary_bank_id',
                'egc_staff_salary_accounts.gross_salary'
            ]);

        return response()->json([
            'status' => true,
            'data'   => $accounts
        ]);
    }

    // public function getHistoryEmployeeSalaryAccounts($id)
    // {
    //     try {
    //         $employee = StaffModel::where('sno', $id)
    //             ->select(
    //                 'sno',
    //                 'staff_name',
    //                 'staff_id',
    //                 'is_multiple_account',
    //                 'date_of_joining',
    //             )
    //             ->first();

    //         if (!$employee) {
    //             return response()->json([
    //                 'status' => false,
    //                 'message' => 'Employee not found'
    //             ], 404);
    //         }

    //         $accounts = StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$id)
    //             ->leftJoin('egc_company','egc_company.sno','=','egc_staff_salary_accounts.salary_company_id')
    //             ->where('egc_staff_salary_accounts.status', 0)
    //             ->orderByDesc('egc_staff_salary_accounts.is_primary')
    //             ->get([
    //                 'egc_staff_salary_accounts.sno',
    //                 'egc_staff_salary_accounts.salary_company_id',
    //                 'egc_staff_salary_accounts.salary_bank_id',
    //                 'egc_staff_salary_accounts.gross_salary',
    //                 'egc_staff_salary_accounts.per_day_salary',
    //                 'egc_staff_salary_accounts.per_hour_cost',
    //                 'egc_company.company_name',
    //                 'egc_staff_salary_accounts.is_primary'
    //             ]);

    //         $lastAppraisal =StaffAppraisalLogModel::where(
    //                 'staff_id',
    //                 $id
    //             )
    //             ->where('status',0)
    //             ->latest('appraisal_date')
    //             ->first();

    //         $history =StaffAppraisalLogModel::where('staff_id',$id)
    //             ->orderBy('effective_from','ASC')
    //             ->get();

    //         return response()->json([
    //             'status' => true,
    //             'employee' => $employee,
    //             'accounts' => $accounts,
    //             'last_appraisal' => $lastAppraisal,
    //             'history' => $history
    //         ]);

    //     } catch (\Exception $e) {

    //         return response()->json([
    //             'status' => false,
    //             'message' => $e->getMessage()
    //         ], 500);
    //     }
    // }

    public function getHistoryEmployeeSalaryAccounts($id)
    {
        try {

            $employee = StaffModel::where('sno',$id)
                ->first();

            if(!$employee){
                return response()->json([
                    'status' => false,
                    'message' => 'Employee not found'
                ]);
            }

            $history = StaffAppraisalLogModel::where(
                    'staff_id',
                    $id
                )
                ->orderBy('effective_from','asc')
                ->get();

            $currentStructure = PayrollStaffStructureModel::where(
                    'employee_sno',$id)
                ->where('is_current',1)
                ->first();

            return response()->json([
                'status' => true,

                'employee' => [
                    'sno' => $employee->sno,
                    'staff_name' => $employee->staff_name,
                    'staff_id' => $employee->staff_id,
                    'date_of_joining' => $employee->date_of_joining,
                    'profile_image_url' => $employee->profile_image_url
                ],

                'current_salary' =>
                    $currentStructure->gross_salary ??
                    $employee->basic_salary,

                'current_effective_from' =>
                    $currentStructure->effective_from ??
                    $employee->date_of_joining,

                'appraisal_history' => $history
            ]);

        } catch (\Exception $e){

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function saveSalaryRevision(Request $request){
        DB::beginTransaction();

        try {
                $request->validate([
                    'employee_sno' =>'required',
                    'salary_account_id' =>'required',
                    'revised_salary' =>'required|numeric',
                    'effective_from' =>'required|date'
                ]);
                $userId = $request->user()->user_id ?? 0;
                $salaryAccount = StaffSalaryAccountModel::findOrFail($request->salary_account_id);
                $employee =StaffModel::findOrFail($request->employee_sno);
                $oldSalary = $salaryAccount->gross_salary;
                $newSalary = $request->revised_salary;
                $perDay = round($newSalary / 30,2);
                $perHour =round($newSalary / 240,2);

                $appraisalLog = PayrollStaffAppraisalLogModel::create([
                                    'employee_sno' => $employee->sno,
                                    'salary_account_id' => $salaryAccount->sno,
                                    'current_gross_salary' => $oldSalary,
                                    'revised_gross_salary' => $newSalary,
                                    'appraisal_type' => $request->appraisal_type,
                                    'appraisal_unit' => $request->appraisal_unit,
                                    'appraisal_value' => $request->appraisal_value,
                                    'appraisal_reason' => $request->appraisal_reason,
                                    'effective_from' => $request->effective_from,
                                    'effective_to' => $request->effective_to,
                                    'created_by' =>$userId
                                ]);

                $currentStructure =PayrollStaffStructureModel::where('employee_sno',$employee->sno)
                    ->where('salary_account_id',$salaryAccount->sno)
                    ->where('is_current',1)
                    ->first();

                if($currentStructure){
                    $currentStructure->update([
                        'is_current' => 0,
                        'effective_to' =>Carbon::parse($request->effective_from)
                            ->subDay()
                            ->format('Y-m-d')
                    ]);
                }
                $newStructure =PayrollStaffStructureModel::create([
                                'employee_sno' => $employee->sno,
                                'salary_account_id' =>$salaryAccount->sno,
                                'payroll_template_sno' => $currentStructure->payroll_template_sno,
                                'structure_code' =>'SAL-'.time(),
                                'structure_name' =>'Salary Revision',
                                'gross_salary' =>$newSalary,
                                'effective_from' =>$request->effective_from,
                                'effective_to' => $request->effective_to,
                                'is_current' => 1,
                                'status' => 0,
                                'created_by' => $userId
                            ]);

                $oldDetails = PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno', $currentStructure->sno)
                                ->where('status',0)
                                ->get();

                $earnings = 0;
                $deductions = 0;
                $employerContribution = 0;

                foreach($oldDetails as $detail)
                {
                    $amount =$detail->calculated_amount;
                    if($detail->calculation_type =='percentage'){
                        $amount =($newSalary * $detail->percentage_value) / 100;
                    }

                    PayrollStaffStructureDetailModel::create([
                        'payroll_employee_structure_sno' =>$newStructure->sno,
                        'payroll_component_sno' => $detail->payroll_component_sno,
                        'payroll_rule_sno' => $detail->payroll_rule_sno,
                        'component_type' => $detail->component_type,
                        'calculation_type' => $detail->calculation_type,
                        'percentage_value' => $detail->percentage_value,
                        'fixed_amount' =>  $amount,
                        'calculated_amount' => $amount,
                        'include_in_gross' =>$detail->include_in_gross,
                        'include_in_ctc' =>$detail->include_in_ctc,
                        'include_in_payslip' => $detail->include_in_payslip,
                        'display_order' =>$detail->display_order,
                        'status' => 0,
                        'created_by' => $userId
                    ]);

                    if($detail->component_type =='earning'){
                        $earnings += $amount;
                    }
                    if( $detail->component_type =='deduction'){
                        $deductions += $amount;
                    }
                    if($detail->component_type =='employer_contribution'){
                        $employerContribution += $amount;
                    }
                }

                $newStructure->update([
                    'total_earnings' => round($earnings,2),
                    'total_deductions' =>round($deductions,2),
                    'net_salary' =>round($earnings - $deductions,2),
                    'employer_contribution' =>round($employerContribution,2),
                    'ctc_amount' =>round($earnings +$employerContribution,2)
                ]);

                $salaryAccount->update([
                    'gross_salary' =>$newSalary,
                    'per_day_salary' =>$perDay,
                    'per_hour_cost' =>$perHour,
                    'updated_by' =>$userId
                ]);

                if($salaryAccount->is_primary == 1){
                    $employee->update([
                        'basic_salary' =>$newSalary,
                        'per_day_salary' =>$perDay,
                        'per_hour_cost' =>$perHour
                    ]);
                }
                DB::commit();

            return response()->json([
                'status' => true,
                'message' =>'Salary appraisal saved successfully'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ],500);
        }
    }

    public function bulkSaveSalaryHistoryOld(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'employee_sno'      => 'required',
                'salary_account_id' => 'required',
                'history'           => 'required|array|min:1'
            ]);

            $userId = auth()->user()->user_id ?? 0;

            $employee = StaffModel::findOrFail(
                $request->employee_sno
            );

            $salaryAccount = StaffSalaryAccountModel::findOrFail(
                $request->salary_account_id
            );

            /*
            |--------------------------------------------------------------------------
            | Delete Old History
            |--------------------------------------------------------------------------
            */

            StaffAppraisalLogModel::where(
                'staff_id',
                $employee->sno
            )->delete();

            PayrollStaffStructureModel::where(
                'employee_sno',
                $employee->sno
            )
            ->where('is_history',1)
            ->delete();

            foreach($request->history as $row)
            {

                $grossSalary = $row['gross_salary'];

                $perDay = round(
                    $grossSalary / 30,
                    2
                );

                $perHour = round(
                    $grossSalary / 240,
                    2
                );

                /*
                |--------------------------------------------------------------------------
                | Appraisal Log
                |--------------------------------------------------------------------------
                */

                StaffAppraisalLogModel::create([
                    'staff_id' => $employee->sno,
                    'salary_account_id' => $salaryAccount->sno,

                    'current_gross_salary' => $grossSalary,
                    'revised_gross_salary' => $grossSalary,

                    'appraisal_type' =>
                        $row['appraisal_type'] ?? 'Joining',

                    'appraisal_reason' =>
                        $row['appraisal_reason'] ?? null,

                    'effective_from' =>
                        $row['effective_from'],

                    'effective_to' =>
                        $row['effective_to'],

                    'created_by' => $userId
                ]);

                /*
                |--------------------------------------------------------------------------
                | Clone Current Structure
                |--------------------------------------------------------------------------
                */

                $currentStructure =
                    PayrollStaffStructureModel::where(
                        'employee_sno',
                        $employee->sno
                    )
                    ->where('salary_account_id',
                        $salaryAccount->sno
                    )
                    ->where('is_current',1)
                    ->first();

                if(!$currentStructure){
                    continue;
                }

                $newStructure =
                    PayrollStaffStructureModel::create([

                        'employee_sno' =>
                            $employee->sno,

                        'salary_account_id' =>
                            $salaryAccount->sno,

                        'payroll_template_sno' =>
                            $currentStructure->payroll_template_sno,

                        'structure_code' =>
                            'HIS-'.time().rand(100,999),

                        'structure_name' =>
                            'Historical Salary',

                        'gross_salary' =>
                            $grossSalary,

                        'effective_from' =>
                            $row['effective_from'],

                        'effective_to' =>
                            $row['effective_to'],

                        'is_current' => 0,

                        'is_history' => 1,

                        'status' => 0,

                        'created_by' => $userId
                    ]);

                $details =
                    PayrollStaffStructureDetailModel::where(
                        'payroll_employee_structure_sno',
                        $currentStructure->sno
                    )
                    ->where('status',0)
                    ->get();

                foreach($details as $detail)
                {
                    $amount =
                        $detail->calculation_type == 'percentage'
                        ? ($grossSalary *
                            $detail->percentage_value) / 100
                        : $detail->fixed_amount;

                    PayrollStaffStructureDetailModel::create([
                        'payroll_employee_structure_sno' =>
                            $newStructure->sno,

                        'payroll_component_sno' =>
                            $detail->payroll_component_sno,

                        'payroll_rule_sno' =>
                            $detail->payroll_rule_sno,

                        'component_type' =>
                            $detail->component_type,

                        'calculation_type' =>
                            $detail->calculation_type,

                        'percentage_value' =>
                            $detail->percentage_value,

                        'fixed_amount' =>
                            $amount,

                        'calculated_amount' =>
                            $amount,

                        'include_in_gross' =>
                            $detail->include_in_gross,

                        'include_in_ctc' =>
                            $detail->include_in_ctc,

                        'include_in_payslip' =>
                            $detail->include_in_payslip,

                        'display_order' =>
                            $detail->display_order,

                        'status' => 0,

                        'created_by' => $userId
                    ]);
                }
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' =>
                    'Historical salary timeline saved successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ],500);
        }
    }

    public function SaveStaffAppraisal(Request $request)
    {
        return app(
            PayrollAppraisalService::class
        )->save($request);
    }

     public function createPayrollStructure(Request $request)
    {
        DB::beginTransaction();

        try {

            $request->validate([
                'employee_sno'   => 'required|integer',
                'salary_account_id' =>'required|integer',
                'gross_salary'   => 'required|numeric|min:0',
                'effective_from' => 'required|date',
                'details'        => 'required|array|min:1',
            ]);

            $effectiveDate = Carbon::parse($request->effective_from)->format('Y-m-d');

            $earnings = 0;
            $deductions = 0;
            $employerContribution = 0;

            foreach ($request->details as $detail) {
                $amount = (float) ($detail['calculated_amount'] ?? 0);

                if ($detail['component_type'] == 'earning') {
                    $earnings += $amount;
                } elseif ($detail['component_type'] == 'deduction') {
                    $deductions += $amount;
                } elseif ($detail['component_type'] == 'employer_contribution') {
                    $employerContribution += $amount;
                }
            }

            $netSalary = $earnings - $deductions;
            $ctcAmount = $earnings + $employerContribution;

            $structure = PayrollStaffStructureModel::where('employee_sno',$request->employee_sno)
                        ->where('salary_account_id',$request->salary_account_id)
                        ->whereDate('effective_from', $effectiveDate)
                        ->where('status', 0)
                        ->first();

            $fixedGrossSalary = $request->gross_salary;
            $workingDays = 30;
            $perDaySalary = $fixedGrossSalary / $workingDays;
            $perDaySalary = ($perDaySalary * 100) / 100;
            $perDaySalaryCost = round($perDaySalary,2);
           
            $workingHours = 8;
            $perHour = $fixedGrossSalary / (30 * $workingHours);
            $perHour = ($perHour * 100) / 100;
            $perHourCost = round($perHour,2);
           

            if ($structure) {
                $structure->update([
                    'payroll_template_sno' => $request->payroll_template_sno,
                    'gross_salary' => $request->gross_salary,
                    'per_day_salary' => $perDaySalaryCost,
                    'per_hour_cost' => $perHourCost,
                    'total_earnings' => round($earnings, 2),
                    'total_deductions' => round($deductions, 2),
                    'net_salary' => round($netSalary, 2),
                    'employer_contribution' => round($employerContribution, 2),
                    'ctc_amount' => round($ctcAmount, 2),
                    'revision_reason' => $request->revision_reason,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]);
            } else {

                PayrollStaffStructureModel::where('employee_sno',$request->employee_sno)
                ->where('salary_account_id', $request->salary_account_id)
                ->where('is_current', 1)
                ->update([
                    'is_current' => 0,
                    'effective_to' => Carbon::parse($effectiveDate)->subDay()->format('Y-m-d'),
                ]);

                $structure = PayrollStaffStructureModel::create([
                                'employee_sno' => $request->employee_sno,
                                'salary_account_id' =>$request->salary_account_id,
                                'payroll_template_sno' => $request->payroll_template_sno,
                                'structure_code' =>'SAL-' . time() . rand(100, 999),
                                'structure_name' => 'Employee Salary Structure',
                                'gross_salary' =>  $request->gross_salary,
                                'per_day_salary' => $perDaySalaryCost,
                                'per_hour_cost' => $perHourCost,
                                'total_earnings' => round($earnings, 2),
                                'total_deductions' =>round($deductions, 2),
                                'net_salary' => round($netSalary, 2),
                                'employer_contribution' => round($employerContribution, 2),
                                'ctc_amount' => round($ctcAmount, 2),
                                'revision_reason' => $request->revision_reason,
                                'effective_from' => $effectiveDate,
                                'is_current' => 1,
                                'status' => 0,
                                'created_by' => $request->user()->user_id ?? 0,
                ]);
            }

            $existingDetails =PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno',$structure->sno)
                                ->where('status', 0)
                                ->get()
                                ->keyBy('payroll_component_sno');

            $currentComponentIds = [];

            foreach ($request->details as $index => $detail) {

                $componentId =
                    $detail['payroll_component_sno'];

                $currentComponentIds[] =
                    $componentId;

                $detailData = [

                    'payroll_rule_sno' =>
                        $detail['payroll_rule_sno'] ?? null,

                    'component_type' =>
                        $detail['component_type'],

                    'calculation_type' =>
                        $detail['calculation_type'],

                    'calculated_on' =>
                        $detail['calculated_on'] ?? null,

                    'percentage_value' =>
                        $detail['percentage_value'] ?? 0,

                    'fixed_amount' =>
                        $detail['fixed_amount']
                            ?? $detail['calculated_amount'],

                    'calculated_amount' =>
                        $detail['calculated_amount'],

                    'monthly_variable' =>
                        $detail['monthly_variable'] ?? 0,

                    'include_in_gross' =>
                        $detail['include_in_gross'] ?? 0,

                    'include_in_ctc' =>
                        $detail['include_in_ctc'] ?? 1,

                    'include_in_payslip' =>
                        $detail['include_in_payslip'] ?? 1,

                    'display_order' =>
                        $detail['display_order']
                            ?? ($index + 1),

                    'remarks' =>
                        $detail['remarks'] ?? null,

                    'updated_by' =>
                        $request->user()->user_id ?? 0,
                ];

                if (
                    isset(
                        $existingDetails[$componentId]
                    )
                ) {

                    $existingDetails[$componentId]
                        ->update($detailData);

                } else {

                    PayrollStaffStructureDetailModel::create(

                        array_merge(
                            $detailData,
                            [

                                'payroll_employee_structure_sno' =>
                                    $structure->sno,

                                'payroll_component_sno' =>
                                    $componentId,

                                'status' => 0,

                                'created_by' =>
                                    $request->user()->user_id ?? 0,
                            ]
                        )
                    );
                }
            }

            PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno',$structure->sno)
            ->where('status', 0)
            ->whereNotIn('payroll_component_sno',$currentComponentIds)
            ->update([
                'status' => 2,
                'updated_by' => $request->user()->user_id ?? 0,
            ]);

            /*
            |--------------------------------------------------------------------------
            | UPDATE STAFF SALARY
            |--------------------------------------------------------------------------
            */

            $SalaryAccounts =StaffSalaryAccountModel::where('egc_staff_salary_accounts.sno',$request->salary_account_id)->first();

            $SalaryAccounts->per_day_salary =$perDaySalaryCost;
            $SalaryAccounts->per_hour_cost =$perHourCost;
            $SalaryAccounts->gross_salary =$fixedGrossSalary;
            $SalaryAccounts->update();

            $SalaryTotalGross =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('gross_salary');
            $SalaryTotalPerDay =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('per_day_salary');
            $SalaryTotalPerHr =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$request->employee_sno)
                                ->where('status',0)->sum('per_hour_cost');

            StaffModel::where('sno',$request->employee_sno)->update([
                'basic_salary' =>$SalaryTotalGross,
                'per_day_salary' =>$SalaryTotalPerDay,
                'per_hour_cost' =>$SalaryTotalPerHr,
            ]);

            DB::commit();

            return response()->json([
                'status' => true,
                'message' =>
                    'Employee salary structure saved successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getSalaryHistory($employee)
{
    $history = StaffSalaryAppraisalHistoryModel::query()
        ->leftJoin( 'egc_staff_salary_accounts as acc','acc.sno', '=','egc_staff_salary_appraisal_history.salary_account_id')
        ->leftJoin( 'egc_company','egc_company.sno', '=','acc.salary_company_id')
        ->leftJoin( 'egc_payroll_salary_templates as temp', 'temp.sno','=','egc_staff_salary_appraisal_history.payroll_template_sno')
        ->where( 'egc_staff_salary_appraisal_history.employee_sno', $employee)
        ->where( 'egc_staff_salary_appraisal_history.status',0)
        ->orderBy( 'egc_staff_salary_appraisal_history.effective_from','ASC')
        ->select([
            'egc_staff_salary_appraisal_history.*',
            'egc_company.company_name as account_name',
            'temp.template_name'
        ])
        ->get();
    $SalaryTotalGross =StaffSalaryAccountModel::where('egc_staff_salary_accounts.staff_id',$employee)
                                ->where('status',0)->where('is_primary',1)->sum('gross_salary');

    $pending = $history->where('processed',0)->count();

    $currentSalary = optional($history->last())->gross_salary ?? ($SalaryTotalGross ?? 0);

    return response()->json([

        'status' => true,
        'current_salary' => $currentSalary,
        'pending_history' => $pending,
        'count' => $history->count(),
        'data' => $history->map(function ($row) {
            return [
                'sno' => $row->sno,
                'employee_sno' => $row->employee_sno,
                'salary_account_id' => $row->salary_account_id,
                'payroll_template_sno' => $row->payroll_template_sno,
                'effective_from' => optional($row->effective_from)->format('Y-m'),
                'gross_salary' => (double)$row->gross_salary,
                'account_name' => $row->account_name,
                'template_name' => $row->template_name,
                'appraisal_type' => $row->appraisal_type,
                'appraisal_type_name' => $row->appraisal_type_name,
                'appraisal_unit' => $row->appraisal_unit,
                'appraisal_value' => $row->appraisal_value,
                'appraisal_reason' => $row->appraisal_reason,
                'variable_amount' => $row->variable_amount,
                'variable_months' => $row->variable_months,
                'variable_from' => $row->variable_from,
                'variable_end_month' => $row->variable_end_month,
                'processed' => (bool)$row->processed,
                'processed_at' => $row->processed_at? Carbon::parse($row->processed_at)->format('d M Y'): null
            ];
        })
    ]);
}

public function bulkSaveSalaryHistory(Request $request)
{
    $request->validate([
        'employee_sno' => 'required|integer',
        'history'         => 'required|array|min:1'
    ]);

    $userId = auth()->user()->user_id ?? 0;

    DB::beginTransaction();

    try{

        foreach($request->history as $row){

            validator($row,[
                'salary_account_id'    =>'required|integer',
                'payroll_template_sno' =>'required|integer',
                'effective_from'       =>'required|date',
                'gross_salary'         =>'required|numeric|min:1',
                'appraisal_type'       =>'required|integer',
                'appraisal_unit'       =>'nullable',
                'appraisal_value'      =>'nullable|numeric',
                'appraisal_reason'     =>'nullable|string|max:1000',
                'variable_amount'      =>'nullable|numeric|min:0',
                'variable_months'      =>'nullable|integer|min:1|max:24'
            ])->validate();

            $exists = StaffSalaryAppraisalHistoryModel::where(
                        'employee_sno',
                        $request->employee_sno
                    )
                    ->whereDate(
                        'effective_from',
                        Carbon::parse($row['effective_from'])->startOfMonth()
                    )
                    ->when(
                        !empty($row['sno']),
                        fn($q)=>$q->where('sno','!=',$row['sno'])
                    )
                    ->exists();

            if($exists){
                throw ValidationException::withMessages([
                    'effective_from'=>"Duplicate month : ".$row['effective_from']
                ]);
            }

            if(!empty($row['sno'])){

                $history=
                StaffSalaryAppraisalHistoryModel::findOrFail(
                    $row['sno']
                );

                // if($history->processed){
                //     throw ValidationException::withMessages([
                //         'processed'=>'Processed record cannot edit.'
                //     ]);
                // }

                $history->update([
                    'salary_account_id'=>$row['salary_account_id'],
                    'payroll_template_sno'=>$row['payroll_template_sno'],
                    'effective_from'=>Carbon::parse(
                        $row['effective_from']
                    )->startOfMonth(),
                    'gross_salary'=>$row['gross_salary'],
                    'appraisal_type'=>$row['appraisal_type'],
                    'appraisal_unit'=>$row['appraisal_unit'],
                    'appraisal_value'=>$row['appraisal_value'],
                    'appraisal_reason'=>$row['appraisal_reason'],
                    'variable_amount'=>$row['variable_amount'] ??0,
                    'variable_months'=>$row['variable_months'] ??0,
                    'variable_from'=>$row['variable_from'] ??0,
                    'variable_end_month'=>$row['variable_end_month'] ??0,
                    'updated_by'=>$userId

                ]);

            }else{

                StaffSalaryAppraisalHistoryModel::create([
                    'employee_sno'=>$request->employee_sno,
                    'salary_account_id'=>$row['salary_account_id'],
                    'payroll_template_sno'=>$row['payroll_template_sno'],
                    'effective_from'=>Carbon::parse(
                        $row['effective_from']
                    )->startOfMonth(),

                    'gross_salary'=>$row['gross_salary'],
                    'appraisal_type'=>$row['appraisal_type'],
                    'appraisal_unit'=>$row['appraisal_unit'],
                    'appraisal_value'=>$row['appraisal_value'],
                    'appraisal_reason'=>$row['appraisal_reason'],
                    'variable_amount'=>$row['variable_amount'] ??0,
                    'variable_months'=>$row['variable_months'] ??0,
                    'processed'=>0,
                    'status'=>0,
                    'created_by'=>$userId,
                    'updated_by'=>$userId

                ]);

            }

        }

        DB::commit();

        return response()->json([
            'status'=>true,
            'message'=>'Salary history saved successfully.'
        ]);

    }
    catch(\Exception $e){

        DB::rollBack();

        return response()->json([
            'status'=>false,
            'message'=>$e->getMessage()
        ],500);

    }
}


}
