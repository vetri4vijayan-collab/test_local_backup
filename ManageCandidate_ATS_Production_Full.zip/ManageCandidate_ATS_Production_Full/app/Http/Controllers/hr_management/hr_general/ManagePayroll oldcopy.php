<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use App\Models\CompanyModel;
use PDF;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
class ManagePayroll extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
    public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $company_fill = $request->company_fill ?? 'egc';
        $entity_fill = $request->entity_fill ?? '0';
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

        // ------------------ MONTH PARSING ------------------
        $month_filter = $request->get('month_filter', date('M-Y'));
        // return  $month_filter;
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
         
        // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
        // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

        $month = $parsedDate->month ?? date('m');
      
        $year  = $parsedDate->year ?? date('Y');
       
        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

       
        $pfPercentage = $helper->payroll_setting('pf_percentage');
        $pfDeductionAmount = $helper->payroll_setting('pf_deduction_amount');
        $PTDeductionAmount = $helper->payroll_setting('pt_deduction_amount');
        $esiPercentage = $helper->payroll_setting('esi_percentage');
        $esiLimit = $helper->payroll_setting('esi_salary_limit');

        $staff = DB::table('egc_staff as s')
        ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){
        $join->on('a.staff_id','=','s.sno')
        ->whereMonth('a.date',$month)
        ->whereYear('a.date',$year)
        ->where('a.status',0);
        })
        ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')

            ->where('s.role_id','!=',1)
            ->where('s.status',0)
            ->select(
                's.sno',
                's.staff_name as name',
                's.staff_id as staff_code',
                's.basic_salary',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_id',
                's.company_type',
                's.entity_id',
                's.gender',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',
                's.per_day_salary',
                's.casual_leave_count_per_month',
                DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
                DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),
                DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),
                DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
                DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
                // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
                // DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")
            );

            if($company_fill !== ""){
                if($company_fill == 'egc'){
                    $staff->where('s.company_type',1);
                } else {
                    if($entity_fill !== ""){
                        $staff->where('s.entity_id', $entity_fill);
                    }
                }
            }

            if ($search_filter != '') {
                $staff->where(function ($subquery) use ($search_filter) {
                    $subquery->where('s.staff_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.nick_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.mobile_no', 'LIKE', "%{$search_filter}%");
                        
                });
            }
            
            $staff=$staff->groupBy(
                        's.sno',
                        's.staff_id',
                        's.staff_name',
                        's.basic_salary',
                        's.nick_name',
                        's.mobile_no',
                        's.staff_image',
                        's.company_id',
                        's.company_type',
                        's.entity_id',
                        's.gender',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_name',
                        'egc_company.company_base_color',
                        'egc_department.department_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name',
                        's.per_day_salary',
                        's.casual_leave_count_per_month',
                    )
                    ->orderBy('s.staff_id', 'desc')
                    ->paginate($perpage);
// return $staff;
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $staff->map(function ($item) use ($helper,$month,$year,$pfPercentage,$pfDeductionAmount,$PTDeductionAmount, $esiLimit, $esiPercentage) {

            $absentDays = $item->absent_days ?? 0;

            // $lateCount = DB::table('egc_staff_attendance')
            //     ->where('staff_id',$item->sno)
            //     ->whereMonth('date',$month)
            //     ->whereYear('date',$year)
            //     ->where('status',0)
            //     ->whereNotNull('in_time')
            //     ->whereTime('in_time','>','09:30:00')
            //     ->count();

            // $lateCount = DB::table('egc_staff_attendance as att')
            // ->join('egc_staff as s','s.sno','=','att.staff_id')
            // ->join('egc_shift_day_times as sd','sd.shift_id','=','s.shift_time_id')
            // ->where('att.staff_id',$item->sno)
            // ->whereMonth('att.date',$month)
            // ->whereYear('att.date',$year)
            // ->where('att.status',0)
            // ->where('sd.status',0)
            // ->whereNotNull('att.in_time')
            // ->whereRaw("LOWER(sd.day_name) = LOWER(LEFT(DAYNAME(att.date),3))")
            // ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
            //     ->count();
            $lateCount = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->join('egc_shift_time_log as stl', function ($join) {
                    $join->on('stl.staff_id', '=', 'att.staff_id');
                })
                ->join('egc_shift_day_times as sd', function ($join) {
                    $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                        ->where('sd.status', 0);
                })
                ->where('att.staff_id', $item->sno)
                ->whereMonth('att.date', $month)
                ->whereYear('att.date', $year)
                ->where('att.status', 0)
                ->whereNotNull('att.in_time')
                // ✅ Match shift date range
                ->whereRaw("DATE(att.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
                // ✅ Match day (Mon, Tue...)
                ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))")
                // ✅ Late condition
                // ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
                // ->whereRaw("
                //     TIME_FORMAT(att.in_time, '%H:%i') > 
                //     TIME_FORMAT(ADDTIME(sd.time_from, '00:05:00'), '%H:%i')
                // ")
                ->whereRaw("
                    TIME_FORMAT(att.in_time, '%H:%i') > TIME_FORMAT(sd.time_from, '%H:%i')
                ")
                ->count();
            $allowedLeave = $item->casual_leave_count_per_month ?? 0;
            $lateAllowed = $helper->payroll_setting('late_allowed_per_month');
            $lopPerLate = $helper->payroll_setting('lop_per_late');

            // return  $allowedLeave ;

            // $lopDays = max(0,$absent - $allowedLeave);

            // absent LOP
            $absentLopDays = max(0, $absentDays - $allowedLeave);

            // late LOP
            $extraLate = max(0, $lateCount - $lateAllowed);
            $lateLopDays = $extraLate * $lopPerLate;

            // total LOP
            $totalLopDays = $absentLopDays + $lateLopDays;

            // LOP amount
            $lopAmount = $totalLopDays * $item->per_day_salary;
            // $lopAmount = $lopDays * $item->per_day_salary;
          
            $pfAmount = $pfDeductionAmount ? $pfDeductionAmount : ($item->basic_salary * $pfPercentage)/100;
            $esiAmount = 0;
            $ptAmount =$PTDeductionAmount ?? 0;
            if($esiLimit){
                if($item->basic_salary <= $esiLimit)
                $esiAmount = ($item->basic_salary * $esiPercentage)/100;
            }else{
                $esiAmount = ($item->basic_salary * $esiPercentage)/100;
            }
           
            $netSalary = $item->basic_salary - ($lopAmount + $pfAmount + $esiAmount +$ptAmount);
            $entry = DB::table('egc_payroll_entries')
            ->select('egc_payroll_entries.sno')
                ->join('egc_payroll_runs','egc_payroll_runs.sno','=','egc_payroll_entries.payroll_run_sno')
                ->where('egc_payroll_entries.staff_id',$item->sno)
                ->where('egc_payroll_runs.payroll_month',$month)
                ->where('egc_payroll_runs.payroll_year',$year)
                ->first();
            $isSaved = $entry ? true : false;
            $entryId = $entry->sno ?? null;
            // return $lateCount;

                return [
                    'sno' => $item->sno,
                    'name'=>$item->name,
                    'staff_id'=>$item->staff_code,
                    'basic_salary'=>$item->basic_salary,
                    'present_days'=>$item->present_days ?? 0,
                    'absent_days'=>$absentDays,
                    'leave_days'=>$item->leave_days ?? 0,
                    'permission_days'=>$item->permission_days ?? 0,
                    'onduty_days'=>$item->onduty_days ?? 0,
                    'late_count'=>$lateCount,
                    'lop_days'=>$totalLopDays,
                    'lop_amount'=>$lopAmount,
                    'pf_amount'=>$pfAmount,
                    'ptAmount'=>$ptAmount,
                    'esi_amount'=>$esiAmount,
                    'is_saved'=>$isSaved,
                    'entry_id'=>$entryId,
                    'net_salary'=>$netSalary,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    'base_encrypt' => encrypt($item->sno),
                    'entry_encrypt' => encrypt($entryId),
                    'short_encrypt_id' => base64_encode($item->sno),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'total' => $staff->total(),
            ]);
        }
        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = CompanyModel::where('status',0)->get();
        return view('content.hr_management.hr_general.manage_payroll.payroll_list', [
            'staff' => $staff,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'company_list' => $company_list,
            'source_list' => $source_list,
            'company_fill ' => $company_fill ,
        ]);
    }

    public function  indexNew(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $runs=DB::table('egc_payroll_runs')
            ->where('status',0)
            ->orderBy('sno','desc')
            ->get();
        
        return view('content.hr_management.hr_general.manage_payroll.payroll_list_new', [
           
            'runs' => $runs,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            
        ]);

    }
 public function Payslip($id,Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      
     
      return view('content.hr_management.hr_general.manage_payroll.payslip_print', [
          
      ]);
  }

public function create(Request $r)
{
    DB::table('egc_payroll_runs')
        ->insert([
        'payroll_month'=>$r->payroll_month,
        'payroll_year'=>$r->payroll_year,
        'run_status'=>'DRAFT',
        'created_by'=>$r->user()->user_id ?? 1
        ]);

    return response()->json(['status'=>true]);

}


public function process($runSno,Request $r)
{

    DB::transaction(function() use($runSno,$r){
        try{
            $run=DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->first();


            $employees=DB::table('egc_staff_payroll_profile')
            ->where('status','0')
            ->get();
            
            foreach($employees as $emp){

                $employeeSno=$emp->staff_id;
              
                // get salary structure
                $mapping=DB::table('egc_staff_salary_mapping')
                ->where('staff_id',$employeeSno)
                ->whereNull('effective_to')
                ->first();
                 
                if(!$mapping) continue;

                $components=DB::table('egc_salary_structure_components')
                ->where('salary_structure_sno',
                $mapping->salary_structure_sno)
                ->get();
                  
                $gross=0;
                $deduction=0;

                // create payroll entry

                $entryId=DB::table('egc_payroll_entries')
                            ->insertGetId([
                                'payroll_run_sno'=>$runSno,
                                'staff_id'=>$employeeSno,
                                'gross_salary'=>0,
                                'total_deductions'=>0,
                                'net_salary'=>0,
                                'created_by'=>$r->user()->user_id ?? 1
                            ]);

            // return $entryId;

                foreach($components as $c){

                    $amount=$c->value;
                    $type=DB::table('egc_pay_components')
                    ->where('sno',$c->component_sno)
                    ->value('component_type');
                    DB::table('egc_payroll_entry_components')
                        ->insert([
                            'payroll_entry_sno'=>$entryId,
                            'component_sno'=>$c->component_sno,
                            'amount'=>$amount,
                            'created_by'=>$r->user()->user_id ?? 1
                        ]);

                    if($type=='EARNING'){
                        $gross+=$amount;
                    }else{
                        $deduction+=$amount;
                    }
                
                }
                $net=$gross-$deduction;
                DB::table('egc_payroll_entries')
                    ->where('sno',$entryId)
                    ->update([
                        'gross_salary'=>$gross,
                        'total_deductions'=>$deduction,
                        'net_salary'=>$net
                    ]);
            }

            // finalize
            DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->update([
                'run_status'=>'FINALIZED'
            ]);
        }catch(\Exception $e){
            return response()->json([
                'status'=>false,
                'message'=>'Error processing payroll: '.$e->getMessage()
            ]);
        }
    });

    return response()->json([
    'status'=>true,
    'message'=>'Payroll processed successfully'
    ]);

}


public function indexPayslip()
{

    $payslips=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'e.sno',
            'emp.staff_name as employee_name',
            'emp.staff_id as employee_code',
            'r.payroll_month',
            'r.payroll_year',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary'
        )
        ->get();

    return view('content.hr_management.hr_general.manage_payroll.payslips',compact('payslips'));
}


public function viewpayslip ($entrySno)
{

    $data=$this->getPayslipData($entrySno);

    return view('content.hr_management.hr_general.manage_payroll.payslip_view',$data);

}


public function pdfpayslip($entrySno,Request $r)
{

    $data=$this->getPayslipData($entrySno);

    $pdf=PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_pdf',$data);

    DB::table('egc_payslip_logs')
    ->insert([
    'payroll_entry_sno'=>$entrySno,
    'generated_at'=>now(),
    'generated_by'=>$r->user()->user_id ?? 1
    ]);

    return $pdf->download('payslip.pdf');

}


private function getPayslipData($entrySno)
{

    $entry=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','emp.sno')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'emp.staff_name as name',
            'emp.staff_id as employee_code',
            'b.bank_account_no',
            'b.bank_name',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary',
            'r.payroll_month',
            'r.payroll_year'
        )
        ->where('e.sno',$entrySno)
        ->first();


    $components=DB::table('egc_payroll_entry_components as c')
        ->leftJoin('egc_pay_components as p',
        'p.sno','=','c.component_sno')
        ->select(
            'p.component_name',
            'p.component_type',
            'c.amount'
        )
        ->where('c.payroll_entry_sno',$entrySno)
        ->get();

    return [
        'entry'=>$entry,
        'components'=>$components
    ];

}


public function getPreviewData(Request $request)
{

$month = $request->month;
$year = $request->year;
 $helper = new \App\Helpers\Helpers();
$pfPercentage = $helper->payroll_setting('pf_percentage');
$esiPercentage = $helper->payroll_setting('esi_percentage');
$esiLimit = $helper->payroll_setting('esi_salary_limit');
$pfDeductionAmount = $helper->payroll_setting('pf_deduction_amount');
$PTDeductionAmount = $helper->payroll_setting('pt_deduction_amount');

$staff = DB::table('egc_staff as s')

->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){

$join->on('a.staff_id','=','s.sno')
->whereMonth('a.date',$month)
->whereYear('a.date',$year)
->where('a.status',0);

})

->where('s.status',0)
->where('s.role_id','>',1)

->select(

's.sno',
's.staff_name as name',
's.staff_id as staff_code',
's.basic_salary',
's.per_day_salary',
's.casual_leave_count_per_month',
DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),

DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),

DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),

DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
// DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

// DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")

)

->groupBy('s.sno','s.staff_id','s.staff_name','s.basic_salary','s.per_day_salary','s.casual_leave_count_per_month',)

->get();




$data = [];

foreach($staff as $row)
{

$absentDays = $row->absent_days ?? 0;
$lateCount = DB::table('egc_staff_attendance')
    ->where('staff_id',$row->sno)
    ->whereMonth('date',$month)
    ->whereYear('date',$year)
    ->where('status',0)
    ->whereNotNull('in_time')
    ->whereTime('in_time','>','09:30:00')
    ->count();

$allowedLeave = $row->casual_leave_count_per_month ?? 0;
$lateAllowed = $helper->payroll_setting('late_allowed_per_month');
$lopPerLate = $helper->payroll_setting('lop_per_late');
// $lopDays = max(0,$absent - $allowedLeave);

// absent LOP
$absentLopDays = max(0, $absentDays - $allowedLeave);


// late LOP
$extraLate = max(0, $lateCount - $lateAllowed);

$lateLopDays = $extraLate * $lopPerLate;


// total LOP
$totalLopDays = $absentLopDays + $lateLopDays;


    // LOP amount
    $lopAmount = $totalLopDays * $row->per_day_salary;

    // $lopAmount = $lopDays * $row->per_day_salary;

    // $pfAmount = ($row->basic_salary * $pfPercentage)/100;

    $pfAmount = $pfDeductionAmount ? $pfDeductionAmount : ($row->basic_salary * $pfPercentage)/100;

    $esiAmount = 0;
    $ptAmount =$PTDeductionAmount ?? 0;
    if($esiLimit){
        if($row->basic_salary <= $esiLimit)
        $esiAmount = ($row->basic_salary * $esiPercentage)/100;
    }else{
        $esiAmount = ($row->basic_salary * $esiPercentage)/100;
    }


// if($row->basic_salary <= $esiLimit)
// $esiAmount = ($row->basic_salary * $esiPercentage)/100;

$netSalary = $row->basic_salary - ($lopAmount + $pfAmount + $esiAmount + $ptAmount);

$entry = DB::table('egc_payroll_entries')
    ->join('egc_payroll_runs','egc_payroll_runs.sno','=','egc_payroll_entries.payroll_run_sno')
    ->where('egc_payroll_entries.staff_id',$row->sno)
    ->where('egc_payroll_runs.payroll_month',$month)
    ->where('egc_payroll_runs.payroll_year',$year)
    ->first();

$isSaved = $entry ? true : false;

$entryId = $entry->sno ?? null;

$data[] = [

'staff_id'=>$row->sno,
'name'=>$row->name,
'staff_code'=>$row->staff_code,

'basic_salary'=>$row->basic_salary,

'present_days'=>$row->present_days ?? 0,

'absent_days'=>$absentDays,

'leave_days'=>$row->leave_days ?? 0,

'permission_days'=>$row->permission_days ?? 0,

'onduty_days'=>$row->onduty_days ?? 0,

'late_count'=>$lateCount,

'lop_days'=>$totalLopDays,

'lop_amount'=>$lopAmount,

'pf_amount'=>$pfAmount,

'pt_amount'=>$ptAmount,

'esi_amount'=>$esiAmount,

'is_saved'=>$isSaved,
'entry_id'=>$entryId,

'net_salary'=>$netSalary

];

}

return response()->json($data);

}

public function savePayroll(Request $request)
{

    $month_filter = $request->month_filter;
    $month = $request->month;
    $year = $request->year;

    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
    $month = $parsedDate->month ?? date('m');
    $year  = $parsedDate->year ?? date('Y');
// return $request;

// prevent duplicate save

$exists = DB::table('egc_payroll_runs')

->where('payroll_month',$month)
->where('payroll_year',$year)
->where('status',0)
->exists();

if($exists)
{

return response()->json([
'status'=>false,
'message'=>'Payroll already saved for this month'
]);

}


DB::beginTransaction();

try {


// create payroll run

$runId = DB::table('egc_payroll_runs')

->insertGetId([

'payroll_month'=>$month,
'payroll_year'=>$year,
'run_type'=>'MANUAL',
'created_by'=>auth()->id()

]);


// get preview data using same logic

$preview = $this->getPreviewData($request)->getData();

// return $preview; 
foreach($preview as $row)
{


$entryId = DB::table('egc_payroll_entries')

->insertGetId([

'payroll_run_sno'=>$runId,

'staff_id'=>$row->staff_id,

'basic_salary'=>$row->basic_salary,

'per_day_salary'=>$row->basic_salary,

'present_days'=>$row->present_days,

'absent_days'=>$row->absent_days,

'allowed_leave'=>0,

'lop_days'=>$row->lop_days,

'lop_amount'=>$row->lop_amount,

'pf_amount'=>$row->pf_amount,
'pt_amount'=>$row->pt_amount,

'esi_amount'=>$row->esi_amount,

'incentive_amount'=>0,

'net_salary'=>$row->net_salary,

'created_by'=>auth()->id()

]);


// save components

    // DB::table('egc_payroll_entry_components')
    //     ->insert([
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'Basic Salary',
    //             'component_type'=>'EARNING',
    //             'amount'=>$row->basic_salary
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'LOP',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->lop_amount
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'PF',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->pf_amount
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'ESI',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->esi_amount
    //         ]
    // ]);

   // Get all active components and map by component_code
    $componentMap = DB::table('egc_pay_components')
        ->where('status', 0)
        ->pluck('sno', 'component_code');

    $components = [];

    $amountMapping = [
        'BASIC'     => $row->basic_salary,
        'LOP'       => $row->lop_amount,
        'PF'        => $row->pf_amount,
        'ESI'       => $row->esi_amount,
        'INCENTIVE' => $row->incentive_amount ?? 0,
        'PT'        => $row->pt_amount ?? 0, // if exists
    ];

    foreach ($amountMapping as $code => $amount) {

        if (!empty($amount) && isset($componentMap[$code])) {

            $components[] = [
                'payroll_entry_sno' => $entryId,
                'component_sno'     => $componentMap[$code],
                'amount'            => $amount,
                'created_by'        => auth()->id(),
                'created_at'        => now(),
                'status'            => 0
            ];
        }
    }
  
    if (!empty($components)) {
        DB::table('egc_payroll_entry_components')->insert($components);
    }
}


DB::commit();

return response()->json([
'status'=>true,
'message'=>'Payroll saved successfully'
]);

}
catch(\Exception $e)
{

DB::rollBack();

return response()->json([
'status'=>false,
'message'=>$e->getMessage()
]);

}

}

public function getCompanyBank($id,Request $request)
  {
    $entity_id = $id;
    $branch_data = DB::table('egc_company_bank_accounts')->where('status', 0)->where('company_id', $entity_id)->orderBy('sno', 'desc')->get();
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $branch_data,
    ], 200);
  }
public function getSalaryComponents(Request $request, $staff_id = null)
{
    $query = DB::table('egc_salary_components')->where('status', 1);

    if ($staff_id) {
        // Only include components assigned to staff (optional)
        $staff_components = DB::table('egc_staff_salary_components')
                            ->where('staff_id', $staff_id)
                            ->pluck('component_id')
                            ->toArray();

        $query->whereIn('sno', $staff_components);
    }

    $branch_data = $query->orderBy('sno', 'desc')->get();

    return response([
        'status' => 200,
        'data' => $branch_data,
    ]);
}

}
