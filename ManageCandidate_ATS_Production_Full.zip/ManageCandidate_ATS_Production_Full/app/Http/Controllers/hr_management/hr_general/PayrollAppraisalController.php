<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\PayrollStaffStructureDetailModel;
use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollComponentVersModel;
use App\Models\PayrollSalaryTemplateModel;
use App\Models\PayrollSalaryTemplateDetailModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use App\Models\StaffModel;
use App\Models\StaffSalaryAccountModel;
use App\Models\StaffAppraisalLogModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Log;
use App\Services\PayrollAppraisalService;
use App\Models\StaffSalaryAppraisalModel;

class PayrollAppraisalController extends Controller
{

    protected PayrollAppraisalService $service;

    public function __construct(PayrollAppraisalService $service)
    {
        $this->service = $service;
    }


    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $templates = DB::table('egc_payroll_salary_templates')
            ->where('status', '!=', 2);

        if ($search_filter != '') {

            $templates->where(function ($q) use ($search_filter) {

                $q->where('template_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('template_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('gross_salary', 'LIKE', "%{$search_filter}%");
            });
        }

        $templates = $templates
            ->orderBy('sno', 'DESC')
            ->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $templates->map(function ($item) use ($helper) {
                // return $interview_schedule;
                return [
                    'sno' => $item->sno,
                    'template_name' => $item->template_name,
                    'template_code' => $item->template_code,
                    'gross_salary' => number_format($item->gross_salary, 2),
                    'monthly_ctc' => number_format($item->monthly_ctc, 2),
                    'effective_from' => $item->effective_from,
                    'status' => $item->status,
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $templates->currentPage(),
                'last_page' => $templates->lastPage(),
                'total' => $templates->total(),
            ]);
        }
        $components = DB::table('egc_payroll_components')
            ->select('egc_payroll_components.*', 'egc_payroll_rules.rule_code', 'egc_payroll_rules.rule_category', 'egc_payroll_rules.rule_expression')
            ->leftJoin('egc_payroll_rules', 'egc_payroll_rules.id', '=', 'egc_payroll_components.rule_id')
            ->where('egc_payroll_components.status', 0)
            ->orderBy('egc_payroll_components.component_name')
            ->get();

        return view('content.hr_management.hr_general.payroll_template.payroll_template_list', [
            'templates' => $templates,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'components' => $components,
        ]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'employee_sno'         => 'required|integer',
            'salary_account_id'    => 'required|integer',
            'template'             => 'required|integer',
            'gross_salary'         => 'required|numeric|min:0',
            'effective_from'       => 'required|date',
            'appraisal_type'       => 'required',
            'appraisal_reason'     => 'nullable|string|max:500',
            'variable_amount'      => 'nullable|boolean',
            'variable_component'   => 'nullable|integer',
            'variable_value'       => 'nullable|numeric|min:0'
        ]);

        $result = $this->service->save(
            $request->all()
        );

        return response()->json($result);
    }

    public function history($employee,$salaryAccount)
    {

        $history = StaffSalaryAppraisalModel::employee($employee)
            ->salaryAccount($salaryAccount)
            ->orderBy('effective_from','DESC')
            ->get();

        return response()->json([
            'status'=>true,
            'data'=>$history
        ]);

    }

    public function show($id)
    {

        $appraisal = StaffSalaryAppraisalModel:: with([
                'employee',
                'salaryAccount',
                'template',
                'variableComponent'
            ])
            ->findOrFail($id);

        return response()->json([
            'status'=>true,
            'data'=>$appraisal
        ]);
    }

    public function destroy($id)
    {

        DB::transaction(function() use($id){
            $appraisal = StaffSalaryAppraisalModel::findOrFail($id);
            $appraisal->status=2;
            $appraisal->updated_by=session('sno');
            $appraisal->save();
        });

        return response()->json([
            'status'=>true,
            'message'=>'Appraisal removed successfully.'

        ]);

    }

    public function salaryAccounts($employee)
    {

        $accounts= StaffSalaryAccountModel::where('staff_id',$employee)
                    ->where('status',0)
                    ->get();

        return response()->json([
            'status'=>true,
            'data'=>$accounts
        ]);
    }

    public function appraisalTypes()
    {

        return response()->json([
            'status'=>true,
            'data'=>[
                [
                    'id'=>'Joining',
                    'name'=>'Joining',
                    'variable'=>0
                ],
                [
                    'id'=>1,
                    'name'=>'Yearly Appraisal',
                    'variable'=>0
                ],
                [
                    'id'=>2,
                    'name'=>'Special Appraisal',
                    'variable'=>1
                ],
                [
                    'id'=>3,
                    'name'=>'Project',
                    'variable'=>1
                ],

                [
                    'id'=>5,
                    'name'=>'10X Warrior',
                    'variable'=>1
                ]

            ]

        ]);

    }


    public function bulkSave(Request $request)
    {

        $request->validate([
            'rows'=>'required|array|min:1'
        ]);

        DB::beginTransaction();

        try{
            foreach($request->rows as $row){
                $this->service->save($row);
            }

            DB::commit();

            return response()->json([
                'status'=>true,
                'message'=>'Bulk appraisal imported successfully.'
            ]);

        }
        catch(\Exception $e){

            DB::rollBack();

            return response()->json([
                'status'=>false,
                'message'=>$e->getMessage()

            ],500);

        }

    }

    public function timeline($employee)
    {
        $history= StaffSalaryAppraisalModel::employee($employee)
                ->orderBy('effective_from','DESC')
                ->get();

        return response()->json([
            'status'=>true,
            'data'=>$history
        ]);
    }


}
