<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;

class SalaryStructure extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
  public function index(Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      


      $jobRequest = DB::table('egc_salary_structures')->where('egc_salary_structures.status','!=',2)
      ->select('egc_salary_structures.*');
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_salary_structures.structure_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_salary_structures.effective_from', 'LIKE', "%{$search_filter}%");
          });
      }

       
        
        $jobRequest=$jobRequest->orderBy('egc_salary_structures.created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
            // return $interview_schedule;
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'structure_name' => $item->structure_name ?? '-',
                  'effective_from' => $item->effective_from,
                  'data' => $item,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     $components  = DB::table('egc_pay_components')->where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.hr_management.hr_general.manage_salary_structure.salary_structure', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'components' => $components,
      ]);
  }

 
  public function Status($id, Request $request)
  {
    $last_apply_date = $request->input('last_apply_date');
    $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


public function edit($sno)
{

    $structure=DB::table('egc_salary_structures')
    ->where('sno',$sno)
    ->first();

    $components=DB::table('egc_salary_structure_components')
    ->where('salary_structure_sno',$sno)
    ->get();

    return response()->json([
        'status'=>true,
        'data'=>[
            'structure'=>$structure,
            'components'=>$components
        ]
    ]);

}


public function saveStucture(Request $request)
{
   

    DB::transaction(function() use($request){

         $user_id = $request->user()->user_id ?? 1;

        if($request->sno)
        {

            $sno=$request->sno;

            DB::table('egc_salary_structures')
            ->where('sno',$sno)
            ->update([
            'structure_name'=>$request->structure_name,
            'effective_from'=>$request->effective_from ? date('Y-m-d', strtotime($request->effective_from)) : null,
            'updated_by'=>$user_id
            ]);

            DB::table('egc_salary_structure_components')
            ->where('salary_structure_sno',$sno)
            ->update([
                'status'=>2,
            ]);

        }else
        {
            $sno=DB::table('egc_salary_structures')
                ->insertGetId([
                'structure_name'=>$request->structure_name,
                'effective_from'=>$request->effective_from ? date('Y-m-d', strtotime($request->effective_from)) : null,
                'created_by'=>$user_id  

            ]);

        }


        foreach($request->component_sno as $i=>$component)
        {

            DB::table('egc_salary_structure_components')
            ->insert([
                'salary_structure_sno'=>$sno,
                'component_sno'=>$component,
                'calculation_type'=>$request->calculation_type[$i],
                'value'=>$request->value[$i],
                'created_by'=>$user_id

            ]);

        }

    });

    return response()->json(['status'=>true]);

}


public function staffSalaryMappingEdit($employeeSno)
{
    $history=DB::table('egc_staff_salary_mapping as m')
    ->leftJoin('egc_salary_structures as s','s.sno','=','m.salary_structure_sno')
    ->where('m.staff_id',$employeeSno)
    ->select(
    's.structure_name',
    'm.effective_from',
    'm.effective_to',
    'm.change_reason'
    )
    ->orderBy('m.effective_from','desc')
    ->get();

    return response()->json([
        'history'=>$history
    ]);
}


public function staffSalaryMappingSave(Request $r)
{

    $r->validate([
    'employee_sno'=>'required',
    'salary_structure_sno'=>'required',
    'effective_from'=>'required'
    ]);

    DB::transaction(function() use($r){

        // close previous active structure
        DB::table('egc_staff_salary_mapping')
            ->where('staff_id',$r->employee_sno)
            ->whereNull('effective_to')
            ->update([
            'effective_to'=>date('Y-m-d',strtotime($r->effective_from.' -1 day')),
            'updated_by'=>$r->user()->user_id ?? 1
        ]);

        // insert new mapping
        DB::table('egc_staff_salary_mapping')
        ->insert([
            'staff_id'=>$r->employee_sno,
            'salary_structure_sno'=>$r->salary_structure_sno,
            'effective_from'=> $r->effective_from ? date('Y-m-d', strtotime($r->effective_from)) : null,
            'change_reason'=>$r->change_reason,
            'created_by'=>$r->user()->user_id ?? 1
        ]);

    });

    return response()->json([
        'status'=>true
    ]);

}

}
