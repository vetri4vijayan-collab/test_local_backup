<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\StickyNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NotesController extends ProductivityBaseController
{
    public function index() { return view('content.productivity.notes.index'); }

    public function data(Request $request)
    {
        $query = StickyNote::query()->whereNull('deleted_at')->where('status', '!=', 'trashed');
        $this->applyReadableScope($query, $request, 'note');
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('search')) {
            $s = trim((string) $request->search);
            $query->where(fn ($q) => $q->where('title', 'like', "%{$s}%")->orWhere('body', 'like', "%{$s}%")->orWhere('label', 'like', "%{$s}%"));
        }
        return $this->ok(['rows' => $query->orderByDesc('is_pinned')->orderByDesc('updated_at')->paginate(min(max((int) $request->get('per_page', 40), 10), 100))]);
    }

    public function show(Request $request, int $id)
    {
        $note = StickyNote::whereNull('deleted_at')->whereKey($id)->firstOrFail();
        abort_unless($this->access->canReadResource('note', $id, $note->owner_user_id, $note->company_id, 'Company'), 403);
        return $this->ok($note);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $this->validateData($request);
        $note = StickyNote::create(array_merge($data, ['owner_user_id' => $this->uid(), 'company_id' => $data['company_id'] ?? $this->cid(), 'created_by' => $this->uid(), 'updated_by' => $this->uid()]));
        return $this->ok($note, 'Note saved.');
    }

    public function update(Request $request, int $id)
    {
        $note = StickyNote::findOrFail($id);
        abort_unless($this->access->canManageResource('note', $id, $note->owner_user_id), 403);
        $data = $this->validateData($request);
        $note->update(array_merge($data, ['updated_by' => $this->uid()]));
        return $this->ok($note->fresh(), 'Note updated.');
    }

    public function action(Request $request, int $id)
    {
        $note = StickyNote::findOrFail($id);
        abort_unless($this->access->canManageResource('note', $id, $note->owner_user_id), 403);
        $data = $request->validate(['action' => ['required', 'in:pin,archive,trash,restore']]);
        $updates = match ($data['action']) {
            'pin' => ['is_pinned' => ! (bool) $note->is_pinned],
            'archive' => ['status' => 'archived'],
            'trash' => ['status' => 'trashed'],
            'restore' => ['status' => 'active'],
        };
        $note->update(array_merge($updates, ['updated_by' => $this->uid()]));
        return $this->ok($note->fresh(), 'Note updated.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'title' => ['nullable', 'string', 'max:220'],
            'body' => ['nullable', 'string', 'max:20000'],
            'color' => ['nullable', 'string', 'max:20'],
            'priority' => ['nullable', 'in:normal,high'],
            'reminder_at' => ['nullable', 'date'],
            'checklist' => ['nullable', 'array'],
            'label' => ['nullable', 'string', 'max:80'],
            'status' => ['nullable', 'in:active,archived,trashed'],
            'is_pinned' => ['nullable', 'boolean'],
        ]);
    }
}
