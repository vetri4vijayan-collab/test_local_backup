<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ShareController extends ProductivityBaseController
{
    public function data(Request $request)
    {
        $data = $request->validate([
            'resource_type' => ['required', 'string', 'max:80'],
            'resource_id' => ['required', 'integer', 'min:1'],
        ]);

        $meta = $this->resourceMeta($data['resource_type'], (int) $data['resource_id']);
        abort_unless($meta && $this->access->canReadResource(
            $data['resource_type'],
            (int) $data['resource_id'],
            $meta['owner_user_id'],
            $meta['company_id'],
            $meta['visibility']
        ), 403);

        return $this->ok(
            DB::table('egc_tool_share_grants')
                ->where('resource_type', $data['resource_type'])
                ->where('resource_id', $data['resource_id'])
                ->whereIn('status', ['active', 'pending'])
                ->orderByDesc('created_at')
                ->get()
        );
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'resource_type' => ['required', 'string', 'max:80'],
            'resource_id' => ['required', 'integer', 'min:1'],
            'grantee_type' => ['required', 'in:user,role,company,group'],
            'grantee_id' => ['required', 'string', 'max:120'],
            'permission' => ['required', 'in:View,Manage'],
            'expires_at' => ['nullable', 'date', 'after:now'],
        ]);

        $meta = $this->resourceMeta($data['resource_type'], (int) $data['resource_id']);
        abort_unless($meta, 404, 'Resource not found.');
        abort_unless($this->access->canManageResource(
            $data['resource_type'],
            (int) $data['resource_id'],
            $meta['owner_user_id']
        ), 403, 'You do not have permission to share this resource.');

        abort_unless($data['resource_type'] !== 'money', 422, 'My Money records are private and cannot be shared.');

        if ($data['resource_type'] === 'vault' && (int) session('egc_tool_stepup_until', 0) < now()->timestamp) {
            $request->validate(['stepup_password' => ['required', 'string', 'max:255']]);
            $user = $request->user();
            abort_unless($user && !empty($user->password) && Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');
            session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);
        }

        $crossCompany = false;
        if ($data['grantee_type'] === 'company') {
            $crossCompany = (int) $data['grantee_id'] !== (int) ($meta['company_id'] ?? -1);
        } elseif ($data['grantee_type'] === 'group') {
            $crossCompany = true;
        }

        if ($data['grantee_type'] === 'user') {
            abort_unless(
                DB::table('egc_staff')->where('sno', (int) $data['grantee_id'])->where('status', '!=', 2)->exists(),
                422,
                'Selected user is not active.'
            );
        }

        if ($data['grantee_type'] === 'company') {
            abort_unless(
                DB::table('egc_company')->where('sno', (int) $data['grantee_id'])->where('status', 0)->exists(),
                422,
                'Selected company is not active.'
            );
        }

        if ($data['grantee_type'] === 'role') {
            abort_unless(
                in_array($data['grantee_id'], ['Super Admin', 'Group Admin', 'Company Admin', 'Module Manager', 'Staff', 'Auditor'], true),
                422,
                'Invalid recipient role.'
            );
        }

        $duplicate = DB::table('egc_tool_share_grants')
            ->where('resource_type', $data['resource_type'])
            ->where('resource_id', $data['resource_id'])
            ->where('grantee_type', $data['grantee_type'])
            ->where('grantee_id', $data['grantee_id'])
            ->whereIn('status', ['active', 'pending'])
            ->exists();

        abort_if($duplicate, 409, 'This resource is already shared with the selected recipient.');

        $status = 'active';
        if ($crossCompany) {
            $status = $data['resource_type'] === 'vault'
                ? ($this->access->isSuper() ? 'active' : 'pending')
                : ($this->access->isGroupAdmin() ? 'active' : 'pending');
        }

        $id = DB::table('egc_tool_share_grants')->insertGetId([
            'resource_type' => $data['resource_type'],
            'resource_id' => $data['resource_id'],
            'owner_user_id' => $this->uid(),
            'grantee_type' => $data['grantee_type'],
            'grantee_id' => $data['grantee_id'],
            'permission' => $data['permission'],
            'status' => $status,
            'expires_at' => $data['expires_at'] ?? null,
            'requested_by' => $this->uid(),
            'approved_by' => $status === 'active' ? $this->uid() : null,
            'approved_at' => $status === 'active' ? now() : null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // In-app notification to the recipient for direct user grants.
        if ($status === 'active' && $data['grantee_type'] === 'user') {
            DB::table('egc_tool_productivity_notifications')->insert([
                'user_id' => (int) $data['grantee_id'],
                'company_id' => $meta['company_id'] ?? null,
                'module_name' => 'Sharing',
                'notification_type' => 'share',
                'title' => 'A resource was shared with you',
                'message' => ucfirst($data['resource_type']).' #'.(int) $data['resource_id'].' was shared with you with '.$data['permission'].' access.',
                'resource_type' => $data['resource_type'],
                'resource_id' => (int) $data['resource_id'],
                'action_url' => url('/productivity/'.$data['resource_type'].'/'.(int) $data['resource_id']),
                'icon' => 'share-variant-outline',
                'icon_color' => '#4A3E8E',
                'is_read' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Board shares have a dedicated table because the board canvas needs fast permission checks.
        if ($data['resource_type'] === 'board') {
            DB::table('egc_tool_board_shares')->insert([
                'board_id' => $data['resource_id'],
                'owner_user_id' => $this->uid(),
                'grantee_type' => $data['grantee_type'],
                'grantee_id' => $data['grantee_id'],
                'permission' => $data['permission'],
                'status' => $status === 'active' ? 'active' : 'pending',
                'expires_at' => $data['expires_at'] ?? null,
                'requested_by' => $this->uid(),
                'approved_by' => $status === 'active' ? $this->uid() : null,
                'approved_at' => $status === 'active' ? now() : null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $this->audit(
            $request,
            'Admin',
            'share_created',
            $data['resource_type'],
            (int) $data['resource_id'],
            null,
            null,
            ['grant_id' => $id, 'grantee_type' => $data['grantee_type'], 'permission' => $data['permission'], 'status' => $status],
            $data['resource_type'] === 'vault'
        );

        return $this->ok(
            ['id' => $id, 'status' => $status],
            $status === 'pending' ? 'Share request sent for Group Admin approval.' : 'Resource shared successfully.'
        );
    }

    public function pending(Request $request)
    {
        abort_unless($this->access->isGroupAdmin() || $this->access->isSuper(), 403);

        $query = DB::table('egc_tool_share_grants')
            ->where('status', 'pending')
            ->orderByDesc('created_at');

        // Vault approvals are intentionally restricted to Super Admins.
        if (! $this->access->isSuper()) {
            $query->where('resource_type', '!=', 'vault');
        }

        return $this->ok($query->limit(100)->get());
    }

    public function approve(Request $request, $id)
    {
        $grant = DB::table('egc_tool_share_grants')->where('sno', $id)->where('status', 'pending')->first();
        abort_unless($grant, 404, 'Share request not found.');
        abort_unless($grant->resource_type === 'vault' ? $this->access->isSuper() : $this->access->isGroupAdmin(), 403);

        DB::transaction(function () use ($grant) {
            DB::table('egc_tool_share_grants')->where('sno', $grant->sno)->update([
                'status' => 'active',
                'approved_by' => $this->uid(),
                'approved_at' => now(),
                'updated_at' => now(),
            ]);

            if ($grant->resource_type === 'board') {
                DB::table('egc_tool_board_shares')
                    ->where('board_id', $grant->resource_id)
                    ->where('grantee_type', $grant->grantee_type)
                    ->where('grantee_id', $grant->grantee_id)
                    ->where('status', 'pending')
                    ->update([
                        'status' => 'active',
                        'approved_by' => $this->uid(),
                        'approved_at' => now(),
                        'updated_at' => now(),
                    ]);
            }
        });

        $this->audit($request, 'Admin', 'share_approved', $grant->resource_type, (int) $grant->resource_id, null, null, ['grant_id' => $id]);

        return $this->ok(null, 'Share approved successfully.');
    }

    public function revoke(Request $request, $id)
    {
        $grant = DB::table('egc_tool_share_grants')->where('sno', $id)->first();
        abort_unless($grant, 404, 'Share grant not found.');
        abort_unless($this->access->isGroupAdmin() || (int) $grant->owner_user_id === $this->uid(), 403);

        DB::transaction(function () use ($grant, $id) {
            DB::table('egc_tool_share_grants')->where('sno', $id)->update([
                'status' => 'revoked',
                'updated_at' => now(),
            ]);

            if ($grant->resource_type === 'board') {
                DB::table('egc_tool_board_shares')
                    ->where('board_id', $grant->resource_id)
                    ->where('grantee_type', $grant->grantee_type)
                    ->where('grantee_id', $grant->grantee_id)
                    ->whereIn('status', ['active', 'pending'])
                    ->update(['status' => 'revoked', 'updated_at' => now()]);
            }
        });

        $this->audit($request, 'Admin', 'share_revoked', $grant->resource_type, (int) $grant->resource_id, null, null, ['grant_id' => $id], $grant->resource_type === 'vault');

        return $this->ok(null, 'Share revoked successfully.');
    }

    private function resourceMeta(string $type, int $id): ?array
    {
        $map = [
            'contact' => ['table' => 'egc_tool_contacts', 'owner' => 'owner_user_id'],
            'board' => ['table' => 'egc_tool_boards', 'owner' => 'owner_user_id'],
            'bookmark' => ['table' => 'egc_tool_bookmarks', 'owner' => 'owner_user_id'],
            'vault' => ['table' => 'egc_tool_vault_entries', 'owner' => 'owner_user_id'],
            'knowledge' => ['table' => 'egc_tool_knowledge_posts', 'owner' => 'author_user_id'],
            'portal' => ['table' => 'egc_tool_portal_apps', 'owner' => 'created_by'],
            'meeting' => ['table' => 'egc_tool_meetings', 'owner' => 'owner_user_id'],
            'task' => ['table' => 'egc_tool_tasks', 'owner' => 'owner_user_id'],
            'note' => ['table' => 'egc_tool_sticky_notes', 'owner' => 'owner_user_id'],
            'document' => ['table' => 'egc_tool_documents', 'owner' => 'owner_user_id'],
            'event' => ['table' => 'egc_tool_events', 'owner' => 'owner_user_id'],
        ];

        if (!isset($map[$type]) || !DB::getSchemaBuilder()->hasTable($map[$type]['table'])) {
            return null;
        }

        $row = DB::table($map[$type]['table'])->where('sno', $id)->first();
        if (!$row) {
            return null;
        }

        return [
            'owner_user_id' => isset($row->{$map[$type]['owner']}) ? (int) $row->{$map[$type]['owner']} : null,
            'company_id' => isset($row->company_id) ? (int) $row->company_id : null,
            'visibility' => $row->visibility ?? ($type === 'knowledge' ? ($row->audience_scope === 'Group' ? 'Group' : 'Company') : null),
        ];
    }
}
