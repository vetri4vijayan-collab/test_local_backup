<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\VaultEntry;
use App\Services\Productivity\ProductivityAccessService;
use App\Services\Productivity\ProductivityCryptoService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PassWalletController extends ProductivityBaseController
{
    public function __construct(
        ProductivityAccessService $access,
        private readonly ProductivityCryptoService $crypto,
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.passwallet.index');
    }

    public function categories(Request $request)
    {
        $query = DB::table('egc_tool_vault_categories')
            ->where('status', 0)
            ->orderBy('category_name');

        $this->applyScope($query, $request);

        return $this->ok($query->get());
    }

    public function data(Request $request)
    {
        $query = VaultEntry::query()
            ->where('status', 0)
            ->whereNull('deleted_at');

        $this->applyReadableScope($query, $request, 'vault');

        $query
            ->when($request->filled('entry_type'), fn ($q) => $q->where('entry_type', $request->string('entry_type')->toString()))
            ->when($request->filled('visibility'), fn ($q) => $q->where('visibility', $request->string('visibility')->toString()))
            ->when($request->filled('category_id'), fn ($q) => $q->where('category_id', (int) $request->input('category_id')));

        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            $query->where(function ($q) use ($search) {
                $q->where('entry_name', 'like', "%{$search}%")
                    ->orWhere('username', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $perPage = min(max((int) $request->input('per_page', 50), 10), 100);
        $rows = $query
            ->orderBy('entry_name')
            ->paginate($perPage);

        $rows->getCollection()->transform(function ($entry) {
            $entry->password_mask = '••••••••';
            $entry->notes_available = !empty($entry->notes_cipher);
            unset($entry->password_cipher, $entry->password_key_ref, $entry->notes_cipher);
            return $entry;
        });

        $rotationQuery = clone $query;

        return $this->ok([
            'rows' => $rows,
            'rotation_overdue' => $rotationQuery
                ->whereNotNull('next_rotation_at')
                ->where('next_rotation_at', '<', now())
                ->count(),
        ]);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'entry_type' => ['required', 'in:Website,System,Application,Mobile App'],
            'category_id' => ['required', 'integer', 'exists:egc_tool_vault_categories,sno'],
            'entry_name' => ['required', 'string', 'max:180'],
            'url' => ['nullable', 'url', 'max:2000'],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['required', 'string', 'max:1000'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'email' => ['nullable', 'email', 'max:180'],
            'mobile' => ['nullable', 'string', 'max:40'],
            'icon_url' => ['nullable', 'url', 'max:1000'],
            'visibility' => ['required', 'in:Private,Team,Company'],
            'rotation_days' => ['nullable', 'integer', 'min:1', 'max:3650'],
        ]);

        $encryptedPassword = $this->crypto->encrypt($data['password']);
        $encryptedNotes = !empty($data['notes']) ? $this->crypto->encrypt($data['notes']) : null;

        $rotationDays = isset($data['rotation_days']) ? (int) $data['rotation_days'] : null;
        $entry = VaultEntry::create([
            'company_id' => $data['company_id'] ?? $this->cid(),
            'owner_user_id' => $this->uid(),
            'entry_type' => $data['entry_type'],
            'category_id' => $data['category_id'],
            'entry_name' => $data['entry_name'],
            'url' => $data['url'] ?? null,
            'username' => $data['username'] ?? null,
            'password_cipher' => $encryptedPassword['cipher'],
            'password_key_ref' => $encryptedPassword['key_ref'],
            'notes_cipher' => $encryptedNotes['cipher'] ?? null,
            'email' => $data['email'] ?? null,
            'mobile' => $data['mobile'] ?? null,
            'icon_url' => $data['icon_url'] ?? null,
            'visibility' => $data['visibility'],
            'rotation_days' => $rotationDays,
            'last_rotated_at' => now(),
            'next_rotation_at' => $rotationDays ? now()->addDays($rotationDays) : null,
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'PassWallet',
            'created',
            'vault',
            $entry->sno,
            null,
            ['entry_id' => $entry->sno, 'entry_name' => $entry->entry_name, 'visibility' => $entry->visibility],
            [],
            true,
        );

        return $this->ok(['id' => $entry->sno], 'Vault entry created securely.');
    }

    public function show(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry);

        $payload = $entry->makeHidden([
            'password_cipher',
            'password_key_ref',
            'notes_cipher',
            'deleted_at',
        ])->toArray();

        $payload['has_secret'] = !empty($entry->password_cipher);
        $payload['has_notes'] = !empty($entry->notes_cipher);

        return $this->ok($payload);
    }

    public function stepUp(Request $request)
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot perform credential step-up actions.');
        $request->validate(['stepup_password' => ['required', 'string', 'max:255']]);
        $user = $request->user();
        abort_unless($user && !empty($user->password), 403, 'Step-up verification is unavailable.');
        abort_unless(Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');
        session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);
        $this->audit($request, 'PassWallet', 'step_up_verified', 'security', null, null, null, ['valid_for_minutes' => 5], true);
        return $this->ok(['verified_until' => session('egc_tool_stepup_until')], 'Step-up verification successful.');
    }

    public function reveal(Request $request, int $id)
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot reveal credentials.');
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry);
        $this->requireStepUp($request);

        $secret = $this->crypto->decrypt($entry->password_cipher, $entry->password_key_ref);

        $this->audit(
            $request,
            'PassWallet',
            'revealed',
            'vault',
            $id,
            null,
            null,
            [],
            true,
        );

        return $this->ok(['password' => $secret]);
    }

    public function update(Request $request, int $id)
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot change credentials.');
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->access->canManageResource('vault', $id, $entry->owner_user_id), 403);
        $this->requireStepUp($request);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'entry_type' => ['required', 'in:Website,System,Application,Mobile App'],
            'category_id' => ['required', 'integer', 'exists:egc_tool_vault_categories,sno'],
            'entry_name' => ['required', 'string', 'max:180'],
            'url' => ['nullable', 'url', 'max:2000'],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:1000'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'email' => ['nullable', 'email', 'max:180'],
            'mobile' => ['nullable', 'string', 'max:40'],
            'icon_url' => ['nullable', 'url', 'max:1000'],
            'visibility' => ['required', 'in:Private,Team,Company'],
            'rotation_days' => ['nullable', 'integer', 'min:1', 'max:3650'],
        ]);

        $before = [
            'entry_name' => $entry->entry_name,
            'username' => $entry->username,
            'visibility' => $entry->visibility,
            'rotation_days' => $entry->rotation_days,
        ];

        $payload = [
            'company_id' => $data['company_id'] ?? $entry->company_id,
            'entry_type' => $data['entry_type'],
            'category_id' => $data['category_id'],
            'entry_name' => $data['entry_name'],
            'url' => $data['url'] ?? null,
            'username' => $data['username'] ?? null,
            'email' => $data['email'] ?? null,
            'mobile' => $data['mobile'] ?? null,
            'icon_url' => $data['icon_url'] ?? null,
            'visibility' => $data['visibility'],
            'rotation_days' => isset($data['rotation_days']) ? (int) $data['rotation_days'] : null,
            'updated_by' => $this->uid(),
        ];

        if (array_key_exists('password', $data) && $data['password'] !== null && $data['password'] !== '') {
            DB::table('egc_tool_vault_entry_history')->insert([
                'vault_entry_id' => $entry->sno,
                'password_cipher' => $entry->password_cipher,
                'password_key_ref' => $entry->password_key_ref,
                'changed_by' => $this->uid(),
                'changed_at' => now(),
            ]);

            $encrypted = $this->crypto->encrypt($data['password']);
            $payload['password_cipher'] = $encrypted['cipher'];
            $payload['password_key_ref'] = $encrypted['key_ref'];
            $payload['last_rotated_at'] = now();
            $payload['next_rotation_at'] = !empty($data['rotation_days'])
                ? now()->addDays((int) $data['rotation_days'])
                : null;
        }

        if (array_key_exists('notes', $data)) {
            $encryptedNotes = $data['notes'] !== '' && $data['notes'] !== null
                ? $this->crypto->encrypt($data['notes'])
                : null;
            $payload['notes_cipher'] = $encryptedNotes['cipher'] ?? null;
        }

        $entry->update($payload);

        $this->audit(
            $request,
            'PassWallet',
            'updated',
            'vault',
            $id,
            $before,
            [
                'entry_name' => $entry->entry_name,
                'username' => $entry->username,
                'visibility' => $entry->visibility,
                'rotation_days' => $entry->rotation_days,
            ],
            ['secret_changed' => array_key_exists('password', $data) && $data['password'] !== null && $data['password'] !== ''],
            true,
        );

        return $this->ok(null, 'Vault entry updated securely.');
    }

    public function copyAudit(Request $request, int $id)
    {
        abort_unless(!$this->access->isAuditor(), 403, 'Auditors cannot copy credentials.');
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry);
        $this->requireStepUp($request);

        $this->audit($request, 'PassWallet', 'copied', 'vault', $id, null, null, [], true);

        return $this->ok(null, 'Credential copy access recorded.');
    }

    public function history(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry);

        return $this->ok(
            DB::table('egc_tool_vault_entry_history')
                ->where('vault_entry_id', $id)
                ->latest('changed_at')
                ->limit(5)
                ->get(['sno', 'changed_by', 'changed_at'])
        );
    }

    public function shares(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->access->canReadResource('vault', $id, $entry->owner_user_id, $entry->company_id, $entry->visibility), 403);

        return $this->ok(
            DB::table('egc_tool_share_grants')
                ->where('resource_type', 'vault')
                ->where('resource_id', $id)
                ->whereIn('status', ['active', 'pending'])
                ->orderByDesc('created_at')
                ->get()
        );
    }

    public function lockdown(Request $request, int $userId)
    {
        abort_unless($this->access->isSuper(), 403);

        DB::transaction(function () use ($userId) {
            DB::table('egc_tool_share_grants')
                ->where('resource_type', 'vault')
                ->where('grantee_type', 'user')
                ->where('grantee_id', (string) $userId)
                ->whereIn('status', ['active', 'pending'])
                ->update(['status' => 'revoked', 'updated_at' => now()]);
        });

        $this->audit($request, 'PassWallet', 'user_lockdown', 'user', $userId, null, null, [], true);

        return $this->ok(null, 'Vault access frozen for the user.');
    }

    public function generator(Request $request)
    {
        $data = $request->validate([
            'length' => ['required', 'integer', 'min:8', 'max:128'],
            'upper' => ['nullable', 'boolean'],
            'lower' => ['nullable', 'boolean'],
            'numbers' => ['nullable', 'boolean'],
            'symbols' => ['nullable', 'boolean'],
        ]);

        $chars = '';
        $chars .= ($data['upper'] ?? true) ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' : '';
        $chars .= ($data['lower'] ?? true) ? 'abcdefghijklmnopqrstuvwxyz' : '';
        $chars .= ($data['numbers'] ?? true) ? '0123456789' : '';
        $chars .= ($data['symbols'] ?? true) ? '!@#$%^&*()-_=+[]{}' : '';

        abort_if($chars === '', 422, 'At least one character set must be enabled.');

        $password = '';
        for ($i = 0; $i < (int) $data['length']; $i++) {
            $password .= $chars[random_int(0, strlen($chars) - 1)];
        }

        return $this->ok(['password' => $password]);
    }

    public function delete(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->access->canManageResource('vault', $id, $entry->owner_user_id), 403);
        $this->requireStepUp($request);

        $entry->update([
            'status' => 2,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit($request, 'PassWallet', 'deleted', 'vault', $id, null, null, [], true);

        return $this->ok(null, 'Vault entry removed.');
    }

    public function attachment(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        abort_unless($this->access->canManageResource('vault', $id, $entry->owner_user_id), 403);
        $this->requireStepUp($request);

        $data = $request->validate([
            'attachment' => ['required', 'file', 'max:20480', 'mimes:pdf,txt,csv,jpg,jpeg,png,zip'],
        ]);

        $file = $data['attachment'];
        $path = $file->store('egpk/vault/' . date('Y/m'), 's3');

        $attachmentId = DB::table('egc_tool_vault_entry_attachments')->insertGetId([
            'vault_entry_id' => $id,
            'storage_path' => $path,
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'file_size' => $file->getSize(),
            'created_by' => $this->uid(),
            'created_at' => now(),
        ]);

        $this->audit($request, 'PassWallet', 'attachment_added', 'vault', $id, null, null, ['attachment_id' => $attachmentId], true);

        return $this->ok(['id' => $attachmentId], 'Vault attachment stored securely.');
    }

    public function attachments(Request $request, int $id)
    {
        $entry = VaultEntry::findOrFail($id);
        $this->assertReadable($entry);

        return $this->ok(
            DB::table('egc_tool_vault_entry_attachments')
                ->where('vault_entry_id', $id)
                ->orderByDesc('created_at')
                ->get(['sno', 'original_name', 'mime_type', 'file_size', 'created_at'])
        );
    }

    private function assertReadable(VaultEntry $entry): void
    {
        abort_unless(
            $this->access->canReadResource('vault', $entry->sno, $entry->owner_user_id, $entry->company_id, $entry->visibility),
            403,
        );
    }

    private function requireStepUp(Request $request): void
    {
        $validUntil = (int) session('egc_tool_stepup_until', 0);
        if ($validUntil >= now()->timestamp) {
            return;
        }

        $request->validate([
            'stepup_password' => ['required', 'string', 'max:255'],
        ]);

        $user = $request->user();
        abort_unless($user && !empty($user->password), 403, 'Step-up verification is unavailable.');
        abort_unless(Hash::check($request->input('stepup_password'), $user->password), 403, 'Invalid step-up credential.');

        session(['egc_tool_stepup_until' => now()->addMinutes(5)->timestamp]);
    }
}
