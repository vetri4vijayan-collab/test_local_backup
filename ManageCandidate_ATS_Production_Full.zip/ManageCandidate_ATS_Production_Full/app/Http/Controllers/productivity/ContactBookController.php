<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Contact;
use App\Models\Productivity\ContactCategory;
use App\Models\GeneralSettingsModel;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ContactBookController extends ProductivityBaseController
{
    private array $companyNameCache = [];
    private array $relationshipNameCache = [];
    private ?string $mainCompanyNameCache = null;

    private const MODULE = 'ContactBook';
    private const RESOURCE = 'contact';

    private const VISIBILITIES = ['Private', 'Company', 'Group'];

    private const IMPORT_FIELDS = [
        'salutation'       => 'Salutation',
        'person_name'      => 'Full Name',
        'designation'      => 'Position',
        'organisation'     => 'Company / College',
        'department'       => 'Department',
        'phone_primary'    => 'Primary Phone',
        'phone_alternate'  => 'Alternate Phone',
        'email_primary'    => 'Email',
        'email_secondary'  => 'Secondary Email',
        'city'             => 'City',
        'address'          => 'Address',
        'website'          => 'Website',
        'category_name'    => 'Category',
        'tags'             => 'Tags',
        'notes'            => 'Notes',
    ];

    public function index(): \Illuminate\Contracts\View\View
    {
        return view('content.productivity.contactbook.index');
    }

    /**
     * Static/remote masters used by the ContactBook UI.
     */
    public function lookups(Request $request): JsonResponse
    {
        abort_unless($this->access->canReadResource(self::RESOURCE, 0, null, null, 'Group') || $this->access->canWrite(), 403);

        $categoryQuery = ContactCategory::query()
            ->where('status', 0)
            ->orderBy('category_name');

        $this->applyCategoryScope($categoryQuery, $request);

        $categories = $categoryQuery->get([
            'sno',
            'company_id',
            'category_name',
            'color',
        ])->map(fn ($row) => [
            'id' => (int) $row->sno,
            'name' => $row->category_name,
            'color' => $row->color ?: '#C0392B',
            'company_id' => $row->company_id !== null ? (int) $row->company_id : null,
        ])->values();

        $companyQuery = DB::table('egc_company')
            ->where('status', 0)
            ->orderBy('company_name');

        $canSelectAllCompanies = $this->access->isGroupAdmin() || $this->access->isAuditor();
        $currentCompanyId = $this->cid();

        if (!$canSelectAllCompanies && $currentCompanyId !== null) {
            $companyQuery->where('sno', $currentCompanyId);
        }

        $companyRows = $companyQuery
            ->get(['sno', 'company_name', 'company_short_name'])
            ->filter(fn ($row) => (int) $row->sno !== 0)
            ->map(fn ($row) => [
                'id' => (int) $row->sno,
                'name' => $row->company_name,
                'short_name' => $row->company_short_name ?: $row->company_name,
                'is_main' => false,
            ])
            ->values();

        $companies = collect();

        // Company/entity 0 is the ERP's main organisation. The display name is
        // always sourced from egc_general_settings.title so it stays in sync
        // with General Settings. Restricted company users only receive this
        // option when their own company context is also 0.
        if ($canSelectAllCompanies || $currentCompanyId === 0) {
            $companies->push([
                'id' => 0,
                'name' => $this->mainCompanyName(),
                'short_name' => $this->mainCompanyName(),
                'is_main' => true,
            ]);
        }

        $companies = $companies
            ->concat($companyRows)
            ->values();

        $staffQuery = DB::table('egc_staff')
            ->where('status', '!=', 2)
            ->orderBy('staff_name');

        /*
         * Group visibility intentionally exposes the active staff directory
         * so the creator can target users across Elysium companies.
         */
        if ($request->filled('company_id') && $request->company_id !== 'all') {
            $staffQuery->where('company_id', (int) $request->company_id);
        }

        $staff = $staffQuery
            ->limit(3000)
            ->get(['sno', 'staff_name', 'company_id'])
            ->map(fn ($row) => [
                'id' => (int) $row->sno,
                'name' => $row->staff_name,
                'company_id' => $row->company_id !== null ? (int) $row->company_id : null,
            ])->values();

        $relationshipTable = $this->relationshipMasterTable();

        $relationshipColumns = Schema::getColumnListing($relationshipTable);
        $relationshipSelect = ['sno', 'relationship_name'];

        if (in_array('description', $relationshipColumns, true)) {
            $relationshipSelect[] = 'description';
        }

        $relationships = DB::table($relationshipTable)
            ->where('status', 0)
            ->orderBy('relationship_name')
            ->get($relationshipSelect)
            ->map(fn ($row) => [
                'id' => (int) $row->sno,
                'name' => $row->relationship_name,
                'description' => property_exists($row, 'description') ? ($row->description ?? '') : '',
            ])->values();

        return $this->ok([
            'categories' => $categories,
            'companies' => $companies,
            'staff' => $staff,
            'relationships' => $relationships,
            'roles' => [
                ['id' => 'Super Admin', 'name' => 'Super Admin'],
                ['id' => 'Group Admin', 'name' => 'Group Admin'],
                ['id' => 'Company Admin', 'name' => 'Company Admin'],
                ['id' => 'Module Manager', 'name' => 'Module Manager'],
                ['id' => 'Staff', 'name' => 'Staff'],
                ['id' => 'Auditor', 'name' => 'Auditor'],
            ],
            'visibility' => [
                ['id' => 'Private', 'name' => 'Private', 'hint' => 'Only you and permitted shares'],
                ['id' => 'Company', 'name' => 'Company', 'hint' => 'Visible to selected company'],
                ['id' => 'Group', 'name' => 'Group', 'hint' => 'Visible to selected group users, or all group users'],
            ],
            'current_user' => [
                'id' => $this->uid(),
                'company_id' => $this->cid(),
                'role' => $this->access->role(),
            ],
        ]);
    }

    public function categories(Request $request): JsonResponse
    {
        $query = ContactCategory::query()
            ->where('status', 0)
            ->orderBy('category_name');

        $this->applyCategoryScope($query, $request);

        return $this->ok(
            $query->get(['sno', 'company_id', 'category_name', 'color'])
        );
    }

    public function data(Request $request): JsonResponse
    {
        $query = Contact::query()
            ->with('category')
            ->where('status', 0)
            ->whereNull('deleted_at');

        $this->applyReadableContactScope($query, $request);

        $this->applyFilters($query, $request);

        $totalQuery = clone $query;

        $perPage = min(max((int) $request->input('per_page', 25), 10), 100);
        $page = max((int) $request->input('page', 1), 1);

        $paginator = $query
            ->orderByDesc('is_starred')
            ->orderByRaw('LOWER(person_name)')
            ->paginate($perPage, ['*'], 'page', $page);

        $rows = collect($paginator->items())
            ->map(fn (Contact $contact) => $this->decorateContact($contact))
            ->values();

        return $this->ok([
            'rows' => $rows,
            'pagination' => [
                'current' => $paginator->currentPage(),
                'last' => $paginator->lastPage(),
                'from' => $paginator->firstItem(),
                'to' => $paginator->lastItem(),
                'total' => $paginator->total(),
                'per_page' => $paginator->perPage(),
            ],
            'stats' => [
                'total' => (clone $totalQuery)->count('egc_tool_contacts.sno'),
                'starred' => (clone $totalQuery)->where('is_starred', 1)->count('egc_tool_contacts.sno'),
                'company' => (clone $totalQuery)->where('visibility', 'Company')->count('egc_tool_contacts.sno'),
                'group' => (clone $totalQuery)->where('visibility', 'Group')->count('egc_tool_contacts.sno'),
            ],
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $contact = Contact::query()
            ->with('category')
            ->where('sno', $id)
            ->where('status', 0)
            ->first();

        if (!$contact) {
            return $this->fail('Contact not found.', 404);
        }

        abort_unless($this->canReadContact($contact), 403);

        $activity = DB::table('egc_tool_audit_logs')
            ->where('resource_type', self::RESOURCE)
            ->where('resource_id', $contact->sno)
            ->orderByDesc('created_at')
            ->limit(100)
            ->get([
                'sno',
                'action',
                'actor_user_id',
                'actor_name',
                'ip_address',
                'created_at',
                'meta_json',
            ])
            ->map(function ($row) {
                $meta = json_decode((string) $row->meta_json, true);
                return [
                    'id' => (int) $row->sno,
                    'action' => $row->action,
                    'actor_user_id' => $row->actor_user_id !== null ? (int) $row->actor_user_id : null,
                    'actor_name' => $row->actor_name ?: 'System',
                    'created_at' => $row->created_at,
                    'meta' => is_array($meta) ? $meta : [],
                ];
            });

        $knowledgePosts = collect();

        if (Schema::hasTable('egc_tool_knowledge_posts')) {
            $searchName = trim($contact->person_name);
            $knowledgePosts = DB::table('egc_tool_knowledge_posts')
                ->whereIn('status', ['published'])
                ->where(function ($q) use ($searchName, $contact) {
                    $q->where('title', 'like', '%' . $this->escapeLike($searchName) . '%')
                        ->orWhere('body_html', 'like', '%' . $this->escapeLike($searchName) . '%');

                    if ($contact->organisation) {
                        $q->orWhere('title', 'like', '%' . $this->escapeLike($contact->organisation) . '%');
                    }
                })
                ->orderByDesc('published_at')
                ->limit(20)
                ->get([
                    'sno',
                    'title',
                    'published_at',
                    'author_user_id',
                    'company_id',
                    'status',
                ])
                ->map(fn ($row) => [
                    'id' => (int) $row->sno,
                    'title' => $row->title,
                    'published_at' => $row->published_at,
                    'author_user_id' => (int) $row->author_user_id,
                    'company_id' => $row->company_id !== null ? (int) $row->company_id : null,
                ]);
        }

        $shares = $this->canManageContact($contact) ? $this->shareRows($contact->sno) : [];

        $contactData = $this->decorateContact($contact, true);

        return $this->ok([
            'contact' => $contactData,
            'activity' => $activity,
            'knowledge_posts' => $knowledgePosts,
            'shares' => $shares,
            'permissions' => [
                'manage' => $this->canManageContact($contact),
                'share' => $this->canManageContact($contact),
                'delete' => $this->canManageContact($contact),
                'restore' => $this->access->isCompanyAdmin(),
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $validated = $this->validateContact($request, false);
        $payload = $this->normalizeContactPayload($request, $validated, true);

        if (!$validated['force_duplicate']) {
            $duplicates = $this->findPotentialDuplicates($payload);
            if ($duplicates->isNotEmpty()) {
                return $this->fail(
                    'Possible duplicate contact found. Review it before saving.',
                    409,
                    ['duplicates' => $duplicates->map(fn (Contact $row) => $this->decorateContact($row, true))->values()]
                );
            }
        }

        DB::beginTransaction();

        try {
            $contact = Contact::create($payload);

            $this->audit(
                $request,
                self::MODULE,
                'created',
                self::RESOURCE,
                (int) $contact->sno,
                null,
                $contact->fresh()->toArray()
            );

            DB::commit();

            return $this->ok(
                $this->decorateContact($contact->fresh()->load('category'), true),
                'Contact created successfully.'
            );
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);

            return $this->fail('Unable to create contact. Please try again.', 500);
        }
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $contact = Contact::query()
            ->where('sno', $id)
            ->where('status', 0)
            ->first();

        if (!$contact) {
            return $this->fail('Contact not found.', 404);
        }

        abort_unless($this->canManageContact($contact), 403);

        $validated = $this->validateContact($request, true);
        $payload = $this->normalizeContactPayload($request, $validated, false);

        if (!$validated['force_duplicate']) {
            $duplicates = $this->findPotentialDuplicates($payload, $contact->sno);

            if ($duplicates->isNotEmpty()) {
                return $this->fail(
                    'Possible duplicate contact found. Review it before saving.',
                    409,
                    ['duplicates' => $duplicates->map(fn (Contact $row) => $this->decorateContact($row, true))->values()]
                );
            }
        }

        $before = $contact->toArray();

        DB::beginTransaction();

        try {
            $contact->update($payload);

            $updated = $contact->fresh()->load('category');

            $this->audit(
                $request,
                self::MODULE,
                'updated',
                self::RESOURCE,
                (int) $contact->sno,
                $before,
                $updated->toArray()
            );

            DB::commit();

            return $this->ok(
                $this->decorateContact($updated, true),
                'Contact updated successfully.'
            );
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);

            return $this->fail('Unable to update contact. Please try again.', 500);
        }
    }

    public function delete(Request $request, int $id): JsonResponse
    {
        $contact = Contact::query()->where('sno', $id)->where('status', 0)->first();

        if (!$contact) {
            return $this->fail('Contact not found.', 404);
        }

        abort_unless($this->canManageContact($contact), 403);

        $before = $contact->toArray();

        $contact->update([
            'status' => 2,
            'updated_by' => $this->uid(),
            'deleted_at' => now(),
        ]);

        $this->audit(
            $request,
            self::MODULE,
            'deactivated',
            self::RESOURCE,
            (int) $contact->sno,
            $before,
            $contact->fresh()->toArray()
        );

        return $this->ok(null, 'Contact moved to inactive records.');
    }

    public function restore(Request $request, int $id): JsonResponse
    {
        abort_unless($this->access->isCompanyAdmin(), 403);

        $contact = Contact::withTrashed()->where('sno', $id)->first();

        if (!$contact) {
            return $this->fail('Contact not found.', 404);
        }

        if (!$this->canManageContact($contact)) {
            return $this->fail('You are not permitted to restore this contact.', 403);
        }

        $contact->restore();
        $contact->update([
            'status' => 0,
            'updated_by' => $this->uid(),
            'deleted_at' => null,
        ]);

        $this->audit(
            $request,
            self::MODULE,
            'restored',
            self::RESOURCE,
            (int) $contact->sno,
            null,
            $contact->fresh()->toArray()
        );

        return $this->ok(
            $this->decorateContact($contact->fresh()->load('category'), true),
            'Contact restored successfully.'
        );
    }

    public function star(Request $request, int $id): JsonResponse
    {
        $contact = Contact::query()->where('sno', $id)->where('status', 0)->first();

        if (!$contact) {
            return $this->fail('Contact not found.', 404);
        }

        abort_unless($this->canManageContact($contact), 403);

        $contact->update([
            'is_starred' => !$contact->is_starred,
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            self::MODULE,
            'star_toggled',
            self::RESOURCE,
            (int) $contact->sno,
            null,
            ['is_starred' => (bool) $contact->is_starred]
        );

        return $this->ok([
            'starred' => (bool) $contact->is_starred,
        ], $contact->is_starred ? 'Contact added to favourites.' : 'Contact removed from favourites.');
    }

    public function duplicateCheck(Request $request): JsonResponse
    {
        abort_unless($this->access->canReadResource(self::RESOURCE, 0, null, null, 'Group') || $this->access->canWrite(), 403);

        $request->validate([
            'person_name' => 'nullable|string|max:180',
            'phone_primary' => 'nullable|string|max:40',
            'email_primary' => 'nullable|email|max:180',
            'exclude_id' => 'nullable|integer|min:1',
        ]);

        $payload = [
            'person_name' => trim((string) $request->input('person_name')),
            'phone_primary' => $this->normalizePhone($request->input('phone_primary')),
            'email_primary' => strtolower(trim((string) $request->input('email_primary'))),
            'organisation' => trim((string) $request->input('organisation')),
        ];

        $rows = $this->findPotentialDuplicates($payload, (int) $request->input('exclude_id'));

        return $this->ok(
            $rows->map(fn (Contact $row) => $this->decorateContact($row, true))->values()
        );
    }

    public function mergePreview(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'ids' => 'required|array|min:2|max:5',
            'ids.*' => 'integer|min:1',
        ]);

        $ids = array_values(array_unique(array_map('intval', $validated['ids'])));

        if (count($ids) < 2) {
            return $this->fail('Select at least two contacts.', 422);
        }

        $contacts = Contact::query()
            ->with('category')
            ->whereIn('sno', $ids)
            ->where('status', 0)
            ->get();

        foreach ($contacts as $contact) {
            abort_unless($this->canManageContact($contact), 403);
        }

        if ($contacts->count() !== count($ids)) {
            return $this->fail('One or more selected contacts are unavailable.', 404);
        }

        $fields = [
            'salutation',
            'person_name',
            'designation',
            'organisation',
            'department',
            'phone_primary',
            'phone_alternate',
            'email_primary',
            'email_secondary',
            'city',
            'address',
            'website',
            'category_id',
            'relationship_id',
            'tags',
            'notes',
            'profile_photo',
        ];

        $matrix = [];

        foreach ($fields as $field) {
            $options = $contacts->map(function (Contact $contact) use ($field) {
                $value = $field === 'tags'
                    ? $contact->tags
                    : $contact->{$field};

                if (is_array($value)) {
                    $value = implode(', ', $value);
                }

                if ($field === 'category_id') {
                    $value = optional($contact->category)->category_name;
                }

                if ($field === 'relationship_id') {
                    $value = $this->relationshipName($contact->relationship_id);
                }

                return [
                    'contact_id' => (int) $contact->sno,
                    'value' => $value,
                ];
            })->values()->all();

            $matrix[$field] = $options;
        }

        return $this->ok([
            'contacts' => $contacts->map(fn (Contact $contact) => $this->decorateContact($contact, true))->values(),
            'fields' => $matrix,
            'default_survivor_id' => (int) $contacts->first()->sno,
        ]);
    }

    public function merge(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'ids' => 'required|array|min:2|max:5',
            'ids.*' => 'integer|min:1',
            'survivor_id' => 'required|integer|min:1',
            'field_decisions' => 'nullable|array',
        ]);

        $ids = array_values(array_unique(array_map('intval', $validated['ids'])));
        $survivorId = (int) $validated['survivor_id'];

        if (!in_array($survivorId, $ids, true)) {
            return $this->fail('Invalid survivor contact.', 422);
        }

        $contacts = Contact::query()
            ->with('category')
            ->whereIn('sno', $ids)
            ->where('status', 0)
            ->get()
            ->keyBy('sno');

        if ($contacts->count() !== count($ids)) {
            return $this->fail('One or more contacts are unavailable.', 404);
        }

        foreach ($contacts as $contact) {
            abort_unless($this->canManageContact($contact), 403);
        }

        $fieldDecisions = $validated['field_decisions'] ?? [];

        DB::beginTransaction();

        try {
            /** @var Contact $survivor */
            $survivor = $contacts->get($survivorId);

            $mergeableFields = [
                'salutation',
                'person_name',
                'designation',
                'organisation',
                'department',
                'phone_primary',
                'phone_alternate',
                'email_primary',
                'email_secondary',
                'city',
                'address',
                'website',
                'category_id',
                'relationship_id',
                'tags',
                'notes',
                'profile_photo',
            ];

            $before = $survivor->toArray();
            $decisionSnapshot = [];

            foreach ($mergeableFields as $field) {
                $selectedId = (int) ($fieldDecisions[$field] ?? $survivorId);

                if (!isset($contacts[$selectedId])) {
                    continue;
                }

                $source = $contacts->get($selectedId);

                if ($field === 'tags') {
                    $survivor->tags = $source->tags ?? [];
                    $decisionSnapshot[$field] = [
                        'source_contact_id' => $selectedId,
                        'value' => $source->tags ?? [],
                    ];
                } else {
                    $survivor->{$field} = $source->{$field};
                    $decisionSnapshot[$field] = [
                        'source_contact_id' => $selectedId,
                        'value' => $source->{$field},
                    ];
                }
            }

            $survivor->updated_by = $this->uid();
            $survivor->save();

            $mergedIds = [];
            foreach ($contacts as $contact) {
                if ((int) $contact->sno === $survivorId) {
                    continue;
                }

                $mergedIds[] = (int) $contact->sno;

                $contact->update([
                    'status' => 2,
                    'updated_by' => $this->uid(),
                    'deleted_at' => now(),
                ]);

                DB::table('egc_tool_contact_merge_logs')->insert([
                    'surviving_contact_id' => $survivorId,
                    'merged_contact_id' => (int) $contact->sno,
                    'merged_by' => $this->uid(),
                    'field_decisions' => json_encode($decisionSnapshot, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                    'created_at' => now(),
                ]);
            }

            $this->audit(
                $request,
                self::MODULE,
                'merged',
                self::RESOURCE,
                $survivorId,
                $before,
                $survivor->fresh()->toArray(),
                ['merged_contact_ids' => $mergedIds]
            );

            DB::commit();

            return $this->ok(
                $this->decorateContact($survivor->fresh()->load('category'), true),
                'Contacts merged successfully.'
            );
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);

            return $this->fail('Unable to merge contacts. Please try again.', 500);
        }
    }

    public function bulk(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $validated = $request->validate([
            'ids' => 'required|array|min:1',
            'ids.*' => 'integer|min:1',
            'action' => 'required|in:category,visibility,tag,deactivate',
            'category_id' => 'nullable|integer|min:1',
            'visibility' => 'nullable|in:Private,Company,Group',
            'visibility_company_id' => 'nullable|integer|min:0',
            'visibility_user_ids' => 'nullable|array',
            'visibility_user_ids.*' => 'integer|min:1',
            'tags' => 'nullable|string|max:1000',
        ]);

        $ids = $this->ids($validated['ids']);
        $contacts = Contact::query()
            ->whereIn('sno', $ids)
            ->where('status', 0)
            ->get();

        if ($contacts->isEmpty()) {
            return $this->fail('No active contacts selected.', 422);
        }

        foreach ($contacts as $contact) {
            abort_unless($this->canManageContact($contact), 403);
        }

        $action = $validated['action'];
        $update = ['updated_by' => $this->uid()];

        if ($action === 'category') {
            $categoryId = (int) ($validated['category_id'] ?? 0);
            if (!$this->activeCategoryExists($categoryId, $request)) {
                return $this->fail('Selected category is not available.', 422);
            }
            $update['category_id'] = $categoryId;
        }

        if ($action === 'visibility') {
            $update['visibility'] = $validated['visibility'] ?? 'Private';
            $this->applyVisibilityPayload($update, $request);
        }

        if ($action === 'tag') {
            $existingTags = trim((string) ($validated['tags'] ?? ''));
            if ($existingTags === '') {
                return $this->fail('Enter at least one tag.', 422);
            }

            $newTags = $this->parseTags($existingTags);

            DB::beginTransaction();
            try {
                foreach ($contacts as $contact) {
                    $mergedTags = array_values(array_unique(array_merge($contact->tags ?? [], $newTags)));
                    $contact->tags = $mergedTags;
                    $contact->updated_by = $this->uid();
                    $contact->save();
                }

                DB::commit();
            } catch (\Throwable $e) {
                DB::rollBack();
                report($e);
                return $this->fail('Unable to add tags.', 500);
            }

            $this->audit(
                $request,
                self::MODULE,
                'bulk_tag',
                self::RESOURCE,
                null,
                null,
                null,
                ['count' => $contacts->count(), 'tags' => $newTags]
            );

            return $this->ok(['updated' => $contacts->count()], 'Tags added successfully.');
        }

        if ($action === 'deactivate') {
            $update['status'] = 2;
            $update['deleted_at'] = now();
        }

        foreach ($contacts as $contact) {
            $before = $contact->toArray();
            $contact->update($update);

            $this->audit(
                $request,
                self::MODULE,
                'bulk_' . $action,
                self::RESOURCE,
                (int) $contact->sno,
                $before,
                $contact->fresh()->toArray()
            );
        }

        return $this->ok(
            ['updated' => $contacts->count()],
            'Bulk action completed successfully.'
        );
    }

    public function searchHistory(Request $request): JsonResponse
    {
        $rows = DB::table('egc_tool_search_history')
            ->where('user_id', $this->uid())
            ->where('module_name', self::MODULE)
            ->orderByDesc('created_at')
            ->limit(12)
            ->get(['sno', 'search_text', 'created_at']);

        return $this->ok($rows);
    }

    public function saveSearch(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'search_text' => 'required|string|max:500',
        ]);

        DB::table('egc_tool_search_history')->insert([
            'user_id' => $this->uid(),
            'module_name' => self::MODULE,
            'search_text' => trim($validated['search_text']),
            'created_at' => now(),
        ]);

        return $this->ok(null, 'Search saved.');
    }

    public function exportCsv(Request $request)
    {
        return $this->streamExport($request, 'csv');
    }

    public function exportXlsx(Request $request)
    {
        return $this->streamExport($request, 'xlsx');
    }

    public function exportVcard(Request $request)
    {
        abort_unless($this->access->canExport(), 403);

        $query = Contact::query()
            ->with('category')
            ->where('status', 0)
            ->whereNull('deleted_at');

        $this->applyReadableContactScope($query, $request);
        $this->applyFilters($query, $request);

        $rows = $query
            ->orderByRaw('LOWER(person_name)')
            ->get();

        $this->audit(
            $request,
            self::MODULE,
            'export',
            self::RESOURCE,
            null,
            null,
            null,
            ['format' => 'vcard', 'row_count' => $rows->count()]
        );

        return response()->streamDownload(function () use ($rows) {
            foreach ($rows as $contact) {
                echo "BEGIN:VCARD\r\n";
                echo "VERSION:3.0\r\n";
                echo "FN:" . $this->vcardEscape($contact->person_name) . "\r\n";

                if ($contact->designation) {
                    echo "TITLE:" . $this->vcardEscape($contact->designation) . "\r\n";
                }

                if ($contact->organisation) {
                    echo "ORG:" . $this->vcardEscape($contact->organisation) . "\r\n";
                }

                if ($contact->phone_primary) {
                    echo "TEL;TYPE=CELL:" . $this->vcardEscape($contact->phone_primary) . "\r\n";
                }

                if ($contact->phone_alternate) {
                    echo "TEL;TYPE=WORK:" . $this->vcardEscape($contact->phone_alternate) . "\r\n";
                }

                if ($contact->email_primary) {
                    echo "EMAIL:" . $this->vcardEscape($contact->email_primary) . "\r\n";
                }

                if ($contact->email_secondary) {
                    echo "EMAIL;TYPE=OTHER:" . $this->vcardEscape($contact->email_secondary) . "\r\n";
                }

                if ($contact->city || $contact->address) {
                    echo "ADR:;;" . $this->vcardEscape($contact->address) . ";" . $this->vcardEscape($contact->city) . ";;;;\r\n";
                }

                if ($contact->website) {
                    echo "URL:" . $this->vcardEscape($contact->website) . "\r\n";
                }

                if ($contact->notes) {
                    echo "NOTE:" . $this->vcardEscape($contact->notes) . "\r\n";
                }

                echo "END:VCARD\r\n";
            }
        }, 'contactbook_' . now()->format('Ymd_His') . '.vcf', [
            'Content-Type' => 'text/vcard; charset=UTF-8',
        ]);
    }

    /**
     * Backward-compatible alias for older ContactBook callers.
     * New UI uses the two-step preview/commit workflow.
     */
    public function import(Request $request): JsonResponse
    {
        return $this->importPreview($request);
    }

    public function importTemplate(): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $headers = array_values(self::IMPORT_FIELDS);

        return response()->streamDownload(function () use ($headers) {
            $output = fopen('php://output', 'w');
            fputcsv($output, $headers);

            fputcsv($output, [
                'Dr.',
                'R. Karthik',
                'IT Manager',
                'Meenakshi Mills Ltd',
                'IT',
                '+91 98430 55621',
                '',
                'karthik@example.com',
                '',
                'Madurai',
                'Tirumangalam Road',
                'https://example.com',
                'Client',
                'ERP AMC;Important',
                'Optional notes',
            ]);

            fclose($output);
        }, 'contactbook_import_template.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /**
     * First-stage import: parse the file and store a short-lived preview in cache.
     * No records are inserted here.
     */
    public function importPreview(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $validated = $request->validate([
            'file' => 'required|file|max:20480|mimes:xlsx,xls,csv,txt,vcf',
        ]);

        try {
            [$rows, $headers, $source] = $this->parseImportFile($validated['file']);

            if (!$headers) {
                return $this->fail('The uploaded file has no readable header row.', 422);
            }

            if (!$rows) {
                return $this->fail('The uploaded file contains no contact rows.', 422);
            }

            $token = Str::random(48);

            $suggestedMapping = $this->suggestImportMapping($headers);
            $previewRows = array_slice($rows, 0, 25);
            $validationPreview = [];

            foreach (array_slice($previewRows, 0, 15) as $previewIndex => $sourceRow) {
                $mapped = $this->mapImportRow($sourceRow, $suggestedMapping);
                $name = trim((string) ($mapped['person_name'] ?? ''));
                $phone = trim((string) ($mapped['phone_primary'] ?? ''));
                $email = trim((string) ($mapped['email_primary'] ?? ''));

                if ($name === '') {
                    $validationPreview[] = [
                        'row' => $previewIndex + 2,
                        'status' => 'invalid',
                        'name' => '',
                        'reason' => 'Full Name is required.',
                    ];
                    continue;
                }

                $duplicateMatches = $this->findPotentialDuplicates([
                    'person_name' => $name,
                    'phone_primary' => $phone,
                    'email_primary' => $email,
                    'organisation' => trim((string) ($mapped['organisation'] ?? '')),
                ]);

                $validationPreview[] = [
                    'row' => $previewIndex + 2,
                    'status' => $duplicateMatches->isNotEmpty() ? 'duplicate' : 'ready',
                    'name' => $name,
                    'reason' => $duplicateMatches->isNotEmpty()
                        ? 'Possible duplicate found.'
                        : 'Ready to import.',
                    'matches' => $duplicateMatches->pluck('sno')->values()->all(),
                ];
            }

            Cache::put(
                'egc_contactbook_import:' . $token,
                [
                    'user_id' => $this->uid(),
                    'company_id' => $this->cid(),
                    'source' => $source,
                    'file_name' => $validated['file']->getClientOriginalName(),
                    'headers' => $headers,
                    'rows' => $rows,
                ],
                now()->addMinutes(30)
            );

            return $this->ok([
                'token' => $token,
                'source' => $source,
                'file_name' => $validated['file']->getClientOriginalName(),
                'total_rows' => count($rows),
                'headers' => $headers,
                'rows' => $previewRows,
                'validation_preview' => $validationPreview,
                'fields' => self::IMPORT_FIELDS,
                'suggested_mapping' => $suggestedMapping,
                'categories' => ContactCategory::query()
                    ->where('status', 0)
                    ->orderBy('category_name')
                    ->get(['sno', 'category_name'])
                    ->map(fn ($row) => [
                        'id' => (int) $row->sno,
                        'name' => $row->category_name,
                    ])->values(),
            ], 'Import preview ready.');
        } catch (\Throwable $e) {
            report($e);
            return $this->fail('Unable to preview the uploaded file. Please check the file format.', 422);
        }
    }

    /**
     * Second-stage import: validate mapping, detect duplicates, insert only after confirmation.
     */
    public function importCommit(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $validated = $request->validate([
            'token' => 'required|string|max:100',
            'mapping' => 'required|array',
            'defaults' => 'nullable|array',
            'defaults.category_id' => 'nullable|integer|min:1',
            'defaults.visibility' => 'nullable|in:Private,Company,Group',
            'defaults.visibility_company_id' => 'nullable|integer|min:0',
            'defaults.visibility_user_ids' => 'nullable|array',
            'defaults.visibility_user_ids.*' => 'integer|min:1',
            'duplicate_mode' => 'required|in:skip,keep,merge',
        ]);

        $cacheKey = 'egc_contactbook_import:' . $validated['token'];
        $payload = Cache::get($cacheKey);

        if (!$payload || (int) ($payload['user_id'] ?? 0) !== $this->uid()) {
            return $this->fail('Import preview expired. Please upload the file again.', 410);
        }

        $rows = $payload['rows'] ?? [];

        if (!is_array($rows)) {
            return $this->fail('Invalid import preview data.', 422);
        }

        $importRecord = DB::table('egc_tool_contact_imports')->insertGetId([
            'company_id' => $this->cid(),
            'owner_user_id' => $this->uid(),
            'source' => $payload['source'] ?? 'file',
            'file_name' => $payload['file_name'] ?? null,
            'total_rows' => count($rows),
            'status' => 'processing',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $imported = 0;
        $merged = 0;
        $skipped = 0;
        $invalid = 0;
        $report = [];

        try {
            DB::beginTransaction();

            foreach ($rows as $index => $sourceRow) {
                $rowNo = $index + 2;
                $mapped = $this->mapImportRow($sourceRow, $validated['mapping']);

                if (trim((string) ($mapped['person_name'] ?? '')) === '') {
                    $invalid++;
                    $skipped++;
                    $report[] = [
                        'row' => $rowNo,
                        'status' => 'invalid',
                        'name' => '',
                        'reason' => 'Full Name is required.',
                    ];
                    continue;
                }

                try {
                    $rowValidated = $this->validateImportContact(
                        $mapped,
                        $validated['defaults'] ?? []
                    );
                } catch (\Throwable $e) {
                    $invalid++;
                    $skipped++;
                    $report[] = [
                        'row' => $rowNo,
                        'status' => 'invalid',
                        'name' => trim((string) ($mapped['person_name'] ?? '')),
                        'reason' => $e->getMessage(),
                    ];
                    continue;
                }

                $duplicates = $this->findPotentialDuplicates($rowValidated);

                if ($duplicates->isNotEmpty()) {
                    if ($validated['duplicate_mode'] === 'skip') {
                        $skipped++;
                        $report[] = [
                            'row' => $rowNo,
                            'status' => 'duplicate',
                            'name' => $rowValidated['person_name'],
                            'reason' => 'Possible duplicate found.',
                            'matches' => $duplicates->pluck('sno')->values()->all(),
                        ];
                        continue;
                    }

                    if ($validated['duplicate_mode'] === 'merge') {
                        $target = $duplicates->first();
                        $before = $target->toArray();

                        $rowData = $this->mergeImportedContactData($target, $rowValidated);
                        $target->update($rowData);

                        $merged++;

                        $report[] = [
                            'row' => $rowNo,
                            'status' => 'merged',
                            'name' => $rowValidated['person_name'],
                            'reason' => 'Merged into existing contact #' . $target->sno,
                            'contact_id' => (int) $target->sno,
                        ];

                        $this->audit(
                            $request,
                            self::MODULE,
                            'import_merge',
                            self::RESOURCE,
                            (int) $target->sno,
                            $before,
                            $target->fresh()->toArray()
                        );

                        continue;
                    }

                }

                $contact = Contact::create($rowValidated);

                $imported++;

                $report[] = [
                    'row' => $rowNo,
                    'status' => 'imported',
                    'name' => $rowValidated['person_name'],
                    'contact_id' => (int) $contact->sno,
                ];
            }

            DB::table('egc_tool_contact_imports')
                ->where('sno', $importRecord)
                ->update([
                    'imported_rows' => $imported,
                    'merged_rows' => $merged,
                    'skipped_rows' => $skipped,
                    'status' => 'completed',
                    'report_json' => json_encode([
                        'invalid_rows' => $invalid,
                        'rows' => $report,
                    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
                    'updated_at' => now(),
                ]);

            $this->audit(
                $request,
                self::MODULE,
                'import',
                'contact_import',
                (int) $importRecord,
                null,
                null,
                [
                    'source' => $payload['source'] ?? 'file',
                    'row_count' => count($rows),
                    'imported' => $imported,
                    'merged' => $merged,
                    'skipped' => $skipped,
                    'invalid' => $invalid,
                ]
            );

            DB::commit();

            Cache::forget($cacheKey);

            return $this->ok([
                'import_id' => (int) $importRecord,
                'file_name' => $payload['file_name'] ?? null,
                'total' => count($rows),
                'imported' => $imported,
                'merged' => $merged,
                'skipped' => $skipped,
                'invalid' => $invalid,
                'report' => array_slice($report, 0, 100),
            ], 'Contacts imported successfully.');
        } catch (\Throwable $e) {
            DB::rollBack();

            DB::table('egc_tool_contact_imports')
                ->where('sno', $importRecord)
                ->update([
                    'status' => 'failed',
                    'report_json' => json_encode([
                        'error' => 'Import failed.',
                    ]),
                    'updated_at' => now(),
                ]);

            report($e);

            return $this->fail('Import failed. No partial contact batch was committed.', 500);
        }
    }

    public function importReport(Request $request, int $id)
    {
        $import = DB::table('egc_tool_contact_imports')
            ->where('sno', $id)
            ->first();

        if (!$import) {
            return $this->fail('Import report not found.', 404);
        }

        if ((int) $import->owner_user_id !== $this->uid() && !$this->access->isGroupAdmin() && !$this->access->isAuditor()) {
            return $this->fail('You are not permitted to view this report.', 403);
        }

        $report = json_decode((string) $import->report_json, true);
        $rows = is_array($report) && isset($report['rows']) && is_array($report['rows'])
            ? $report['rows']
            : [];

        $this->audit(
            $request,
            self::MODULE,
            'import_report_viewed',
            'contact_import',
            (int) $id
        );

        return response()->streamDownload(function () use ($import, $rows, $report) {
            $output = fopen('php://output', 'w');

            fputcsv($output, [
                'Row',
                'Status',
                'Name',
                'Reason',
                'Contact ID',
            ]);

            foreach ($rows as $row) {
                fputcsv($output, [
                    $row['row'] ?? '',
                    $row['status'] ?? '',
                    $row['name'] ?? '',
                    $row['reason'] ?? '',
                    $row['contact_id'] ?? '',
                ]);
            }

            if (!$rows && is_array($report) && isset($report['error'])) {
                fputcsv($output, ['', 'failed', '', $report['error'], '']);
            }

            fclose($output);
        }, 'contactbook_import_' . $id . '_report.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    /**
     * Secure Google flow:
     * - OAuth callback stores the short-lived access token in session only.
     * - Callback returns a tiny HTML postMessage page, not a full page redirect.
     * - UI then asks for Google groups/labels and starts snapshot import via AJAX.
     */
    public function googleConnect(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);

        $clientId = (string) config('services.google.client_id', env('GOOGLE_CLIENT_ID'));
        $redirect = (string) config(
            'services.google.redirect',
            env('GOOGLE_REDIRECT_URI', route('productivity.contacts.google.callback'))
        );

        if ($clientId === '' || $redirect === '') {
            return $this->googlePopupResponse(false, 'Google contact import is not configured.');
        }

        $state = Str::random(64);

        Session::put('egc_tool_google_contacts_state', $state);
        Session::put('egc_tool_google_contacts_state_expires', now()->addMinutes(10)->timestamp);

        $params = http_build_query([
            'client_id' => $clientId,
            'redirect_uri' => $redirect,
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/contacts.readonly',
            'access_type' => 'offline',
            'prompt' => 'consent',
            'state' => $state,
        ]);

        return redirect()->away('https://accounts.google.com/o/oauth2/v2/auth?' . $params);
    }

    public function googleCallback(Request $request)
    {
        $state = (string) $request->query('state');
        $expected = (string) Session::pull('egc_tool_google_contacts_state');
        $expires = (int) Session::pull('egc_tool_google_contacts_state_expires', 0);

        if (
            $state === '' ||
            $expected === '' ||
            !hash_equals($expected, $state) ||
            $expires < now()->timestamp
        ) {
            return $this->googlePopupResponse(false, 'Google contact import session expired.');
        }

        if ($request->filled('error')) {
            return $this->googlePopupResponse(false, 'Google contact import was cancelled.');
        }

        $code = (string) $request->query('code');
        $clientId = (string) config('services.google.client_id', env('GOOGLE_CLIENT_ID'));
        $clientSecret = (string) config('services.google.client_secret', env('GOOGLE_CLIENT_SECRET'));
        $redirect = (string) config(
            'services.google.redirect',
            env('GOOGLE_REDIRECT_URI', route('productivity.contacts.google.callback'))
        );

        if ($code === '' || $clientId === '' || $clientSecret === '') {
            return $this->googlePopupResponse(false, 'Google contact import is not configured correctly.');
        }

        try {
            $tokenResponse = Http::asForm()
                ->timeout(15)
                ->post('https://oauth2.googleapis.com/token', [
                    'code' => $code,
                    'client_id' => $clientId,
                    'client_secret' => $clientSecret,
                    'redirect_uri' => $redirect,
                    'grant_type' => 'authorization_code',
                ]);

            if (!$tokenResponse->successful()) {
                return $this->googlePopupResponse(false, 'Google authorization could not be completed.');
            }

            $accessToken = (string) $tokenResponse->json('access_token');

            if ($accessToken === '') {
                return $this->googlePopupResponse(false, 'Google did not return an access token.');
            }

            Session::put('egc_tool_google_contacts_access', encrypt($accessToken));
            Session::put('egc_tool_google_contacts_access_expires', now()->addMinutes(10)->timestamp);

            $groups = $this->googleGroupsFromToken($accessToken);

            Session::put('egc_tool_google_contacts_groups', $groups);

            return $this->googlePopupResponse(true, 'Google connected successfully.');
        } catch (\Throwable $e) {
            report($e);
            return $this->googlePopupResponse(false, 'Unable to complete Google authorization.');
        }
    }

    public function googleGroups(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $expires = (int) Session::get('egc_tool_google_contacts_access_expires', 0);

        if ($expires < now()->timestamp) {
            Session::forget([
                'egc_tool_google_contacts_access',
                'egc_tool_google_contacts_access_expires',
                'egc_tool_google_contacts_groups',
            ]);

            return $this->fail('Google session expired. Please connect again.', 410);
        }

        return $this->ok([
            'groups' => Session::get('egc_tool_google_contacts_groups', []),
        ]);
    }

    public function googleImport(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $validated = $request->validate([
            'group_ids' => 'nullable|array',
            'group_ids.*' => 'string|max:255',
            'category_id' => 'nullable|integer|min:1',
            'visibility' => 'required|in:Private,Company,Group',
            'visibility_company_id' => 'nullable|integer|min:0',
            'visibility_user_ids' => 'nullable|array',
            'visibility_user_ids.*' => 'integer|min:1',
            'duplicate_mode' => 'required|in:skip,keep,merge',
        ]);

        $expires = (int) Session::get('egc_tool_google_contacts_access_expires', 0);

        if ($expires < now()->timestamp) {
            return $this->fail('Google session expired. Please connect again.', 410);
        }

        $encrypted = Session::get('egc_tool_google_contacts_access');

        if (!$encrypted) {
            return $this->fail('Connect Google before importing contacts.', 422);
        }

        try {
            $accessToken = decrypt($encrypted);
        } catch (\Throwable $e) {
            Session::forget('egc_tool_google_contacts_access');
            return $this->fail('Google authorization is no longer valid. Connect again.', 410);
        }

        $categoryId = (int) ($validated['category_id'] ?? 0);

        if (!$categoryId || !$this->activeCategoryExists($categoryId, $request)) {
            return $this->fail('Select a valid ContactBook category.', 422);
        }

        $groups = array_map('strval', $validated['group_ids'] ?? []);

        try {
            $all = [];
            $pageToken = null;

            do {
                $query = [
                    'personFields' => 'names,emailAddresses,phoneNumbers,organizations,addresses,memberships',
                    'pageSize' => 1000,
                ];

                if ($pageToken) {
                    $query['pageToken'] = $pageToken;
                }

                $people = Http::withToken($accessToken)
                    ->acceptJson()
                    ->timeout(20)
                    ->get('https://people.googleapis.com/v1/people/me/connections', $query);

                if (!$people->successful()) {
                    return $this->fail('Google contacts could not be read.', 422);
                }

                $connections = $people->json('connections', []);
                $all = array_merge($all, is_array($connections) ? $connections : []);

                $pageToken = $people->json('nextPageToken');
            } while ($pageToken);

            $imported = 0;
            $merged = 0;
            $duplicates = 0;

            foreach ($all as $person) {
                if ($groups && !$this->googlePersonMatchesGroups($person, $groups)) {
                    continue;
                }

                $name = trim((string) data_get($person, 'names.0.displayName'));

                if ($name === '') {
                    continue;
                }

                $phone = trim((string) data_get($person, 'phoneNumbers.0.value'));
                $email = strtolower(trim((string) data_get($person, 'emailAddresses.0.value')));

                $row = [
                    'company_id' => $this->cid(),
                    'owner_user_id' => $this->uid(),
                    'visibility' => $validated['visibility'],
                    'visibility_company_id' => $validated['visibility'] === 'Company'
                        ? ($validated['visibility_company_id'] ?? $this->cid())
                        : null,
                    'visibility_user_ids' => $validated['visibility'] === 'Group'
                        ? (!empty($validated['visibility_user_ids']) ? array_values(array_map('intval', $validated['visibility_user_ids'])) : null)
                        : null,
                    'salutation' => null,
                    'person_name' => $name,
                    'designation' => null,
                    'organisation' => data_get($person, 'organizations.0.name'),
                    'department' => data_get($person, 'organizations.0.department'),
                    'phone_primary' => $phone !== '' ? $phone : null,
                    'phone_alternate' => null,
                    'email_primary' => $email !== '' ? $email : null,
                    'email_secondary' => null,
                    'city' => data_get($person, 'addresses.0.city'),
                    'address' => data_get($person, 'addresses.0.streetAddress'),
                    'website' => null,
                    'category_id' => $categoryId,
                    'tags_json' => null,
                    'notes' => null,
                    'profile_photo' => data_get($person, 'photos.0.url'),
                    'is_starred' => 0,
                    'status' => 0,
                    'created_by' => $this->uid(),
                    'updated_by' => $this->uid(),
                ];

                $matches = $this->findPotentialDuplicates($row);

                if ($matches->isNotEmpty()) {
                    $duplicates++;

                    if ($validated['duplicate_mode'] === 'skip') {
                        continue;
                    }

                    if ($validated['duplicate_mode'] === 'merge') {
                        $target = $matches->first();
                        $target->update($this->mergeImportedContactData($target, $row));
                        $merged++;
                        continue;
                    }
                }

                Contact::create($row);
                $imported++;
            }

            Session::forget([
                'egc_tool_google_contacts_access',
                'egc_tool_google_contacts_access_expires',
                'egc_tool_google_contacts_groups',
            ]);

            $this->audit(
                $request,
                self::MODULE,
                'google_import',
                'contact_import',
                null,
                null,
                null,
                [
                    'imported' => $imported,
                    'merged' => $merged,
                    'duplicates' => $duplicates,
                    'group_filter_count' => count($groups),
                ]
            );

            return $this->ok([
                'imported' => $imported,
                'merged' => $merged,
                'duplicates' => $duplicates,
            ], 'Google contact snapshot imported.');
        } catch (\Throwable $e) {
            report($e);
            return $this->fail('Unable to import Google contacts.', 500);
        }
    }

    /*
     * Kept for backwards compatibility with old callers.
     * Plain access-token imports are deliberately refused so secrets cannot
     * be passed through an ordinary browser request.
     */
    public function googleImportLegacy(Request $request): JsonResponse
    {
        return $this->fail(
            'Direct access-token import has been disabled. Use Google OAuth connection.',
            410
        );
    }

    private function validateContact(Request $request, bool $isUpdate): array
    {
        $rules = [
            'company_id' => 'nullable|integer|min:0',
            'owner_user_id' => 'nullable|integer|min:1',
            'visibility' => 'required|in:Private,Company,Group',
            'visibility_company_id' => 'nullable|integer|min:0',
            'visibility_user_ids' => 'nullable|array',
            'visibility_user_ids.*' => 'integer|min:1',
            'salutation' => 'nullable|string|max:20',
            'person_name' => 'required|string|max:180',
            'designation' => 'nullable|string|max:150',
            'organisation' => 'nullable|string|max:180',
            'department' => 'nullable|string|max:150',
            'phone_primary' => 'nullable|string|max:40',
            'phone_alternate' => 'nullable|string|max:40',
            'email_primary' => 'nullable|email|max:180',
            'email_secondary' => 'nullable|email|max:180',
            'city' => 'nullable|string|max:100',
            'address' => 'nullable|string|max:5000',
            'website' => 'nullable|url|max:255',
            'category_id' => 'required|integer|min:1',
            'relationship_id' => 'nullable|integer|min:1',
            'tags' => 'nullable|string|max:1000',
            'notes' => 'nullable|string|max:10000',
            'profile_photo' => 'nullable|string|max:500',
            'is_starred' => 'nullable|boolean',
            'force_duplicate' => 'nullable|boolean',
        ];

        $validated = $request->validate($rules);

        if (!$this->activeCategoryExists((int) $validated['category_id'], $request)) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'category_id' => 'Selected ContactBook category is not available.',
            ]);
        }

        if (!empty($validated['relationship_id']) && !$this->relationshipExists((int) $validated['relationship_id'])) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'relationship_id' => 'Selected relationship is not available.',
            ]);
        }

        if (array_key_exists('company_id', $validated)
            && $validated['company_id'] !== null
            && $validated['company_id'] !== ''
            && !$this->companyExists((int) $validated['company_id'])) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'company_id' => 'Selected company is not available.',
            ]);
        }

        if ($validated['visibility'] === 'Company') {
            $rawTargetCompany = $validated['visibility_company_id']
                ?? $validated['company_id']
                ?? $this->cid();

            $targetCompany = ($rawTargetCompany === null || $rawTargetCompany === '')
                ? null
                : (int) $rawTargetCompany;

            if ($targetCompany === null || $targetCompany < 0 || !$this->companyExists($targetCompany)) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_company_id' => 'Select a valid company for Company visibility.',
                ]);
            }

            if (!$this->access->isGroupAdmin()
                && $this->cid() !== null
                && $targetCompany !== $this->cid()) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_company_id' => 'You can only select your own company for Company visibility.',
                ]);
            }

            $validated['visibility_company_id'] = $targetCompany;
            $validated['visibility_user_ids'] = null;
        }

        if ($validated['visibility'] !== 'Company') {
            $validated['visibility_company_id'] = null;
        }

        if ($validated['visibility'] === 'Group') {
            $ids = $this->ids($validated['visibility_user_ids'] ?? []);

            if ($ids && count($ids) !== $this->countActiveStaffIds($ids)) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_user_ids' => 'One or more selected group members are no longer active.',
                ]);
            }

            $validated['visibility_user_ids'] = $ids ?: null;
        } else {
            $validated['visibility_user_ids'] = null;
        }

        return $validated;
    }

    private function normalizeContactPayload(Request $request, array $validated, bool $creating): array
    {
        $hasCompanyId = array_key_exists('company_id', $validated)
            && $validated['company_id'] !== null
            && $validated['company_id'] !== '';

        $companyId = $hasCompanyId
            ? (int) $validated['company_id']
            : $this->cid();

        if (!$this->access->isGroupAdmin()) {
            $companyId = $this->cid();
        }

        $ownerId = $this->uid();

        if ($this->access->isGroupAdmin() && !empty($validated['owner_user_id'])) {
            $ownerId = (int) $validated['owner_user_id'];
        }

        $payload = [
            'company_id' => $companyId,
            'owner_user_id' => $ownerId,
            'visibility' => $validated['visibility'],
            'visibility_company_id' => $validated['visibility'] === 'Company'
                ? (int) $validated['visibility_company_id']
                : null,
            'visibility_user_ids' => $validated['visibility'] === 'Group'
                ? $validated['visibility_user_ids']
                : null,
            'salutation' => $this->nullableString($validated['salutation'] ?? null),
            'person_name' => trim((string) $validated['person_name']),
            'designation' => $this->nullableString($validated['designation'] ?? null),
            'organisation' => $this->nullableString($validated['organisation'] ?? null),
            'department' => $this->nullableString($validated['department'] ?? null),
            'phone_primary' => $this->nullableString($validated['phone_primary'] ?? null),
            'phone_alternate' => $this->nullableString($validated['phone_alternate'] ?? null),
            'email_primary' => $this->nullableString($validated['email_primary'] ?? null),
            'email_secondary' => $this->nullableString($validated['email_secondary'] ?? null),
            'city' => $this->nullableString($validated['city'] ?? null),
            'address' => $this->nullableString($validated['address'] ?? null),
            'website' => $this->nullableString($validated['website'] ?? null),
            'category_id' => (int) $validated['category_id'],
            'relationship_id' => !empty($validated['relationship_id']) ? (int) $validated['relationship_id'] : null,
            'tags_json' => $this->parseTags($validated['tags'] ?? ''),
            'notes' => $this->nullableString($validated['notes'] ?? null),
            'profile_photo' => $this->nullableString($validated['profile_photo'] ?? null),
            'is_starred' => !empty($validated['is_starred']) ? 1 : 0,
            'updated_by' => $this->uid(),
        ];

        if ($creating) {
            $payload['created_by'] = $this->uid();
            $payload['status'] = 0;
            $payload['deleted_at'] = null;
        }

        return $payload;
    }

    private function applyVisibilityPayload(array &$update, Request $request): void
    {
        $visibility = (string) ($update['visibility'] ?? $request->input('visibility', 'Private'));

        if ($visibility === 'Company') {
            $rawCompanyId = $request->input('visibility_company_id');

            if ($rawCompanyId === null || $rawCompanyId === '') {
                $rawCompanyId = $request->input('company_id');
            }

            if ($rawCompanyId === null || $rawCompanyId === '') {
                $rawCompanyId = $this->cid();
            }

            $companyId = $rawCompanyId === null || $rawCompanyId === ''
                ? null
                : (int) $rawCompanyId;

            if ($companyId === null || $companyId < 0 || !$this->companyExists($companyId)) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_company_id' => 'Select a valid visibility company.',
                ]);
            }

            if (!$this->access->isGroupAdmin()
                && $this->cid() !== null
                && $companyId !== $this->cid()) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_company_id' => 'You can only select your own company for Company visibility.',
                ]);
            }

            $update['visibility_company_id'] = $companyId;
            $update['visibility_user_ids'] = null;
        } elseif ($visibility === 'Group') {
            $ids = $this->ids($request->input('visibility_user_ids', []));

            if ($ids && count($ids) !== $this->countActiveStaffIds($ids)) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'visibility_user_ids' => 'One or more selected group members are no longer active.',
                ]);
            }

            $update['visibility_company_id'] = null;
            $update['visibility_user_ids'] = $ids ?: null;
        } else {
            $update['visibility_company_id'] = null;
            $update['visibility_user_ids'] = null;
        }
    }

    private function applyFilters($query, Request $request): void
    {
        $query
            ->when($request->filled('category_id'), fn ($q) => $q->where('category_id', (int) $request->category_id))
            ->when($request->filled('visibility'), fn ($q) => $q->where('visibility', $request->visibility))
            ->when($request->filled('company_id') && $request->company_id !== 'all', fn ($q) => $q->where('company_id', (int) $request->company_id))
            ->when($request->filled('city'), fn ($q) => $q->where('city', 'like', '%' . $this->escapeLike(trim((string) $request->city)) . '%'));

        if ($request->filled('search')) {
            $search = trim((string) $request->search);
            $pattern = '%' . $this->escapeLike($search) . '%';

            $query->where(function ($q) use ($pattern) {
                $q->where('person_name', 'like', $pattern)
                    ->orWhere('organisation', 'like', $pattern)
                    ->orWhere('designation', 'like', $pattern)
                    ->orWhere('department', 'like', $pattern)
                    ->orWhere('phone_primary', 'like', $pattern)
                    ->orWhere('phone_alternate', 'like', $pattern)
                    ->orWhere('email_primary', 'like', $pattern)
                    ->orWhere('email_secondary', 'like', $pattern)
                    ->orWhere('city', 'like', $pattern)
                    ->orWhere('notes', 'like', $pattern)
                    ->orWhereJsonContains('tags_json', $search)
                    ->orWhereJsonContains('tags_json', strtolower($search));
            });
        }
    }

    private function applyReadableContactScope($query, Request $request): void
    {
        $this->applyCompanyScopeForContact($query, $request);

        if ($this->access->isGroupAdmin() || $this->access->isAuditor()) {
            return;
        }

        $uid = $this->uid();
        $companyId = $this->cid();
        $role = $this->access->role();
        $table = 'egc_tool_contacts';

        $query->where(function ($q) use ($uid, $companyId, $role, $table) {
            $q->where($table . '.owner_user_id', $uid)
                ->orWhere(function ($group) use ($uid) {
                    $group
                        ->where('visibility', 'Group')
                        ->where(function ($scope) use ($uid) {
                            $scope
                                ->whereNull('visibility_user_ids')
                                ->orWhereJsonContains('visibility_user_ids', $uid);
                        });
                })
                ->when($companyId !== null, function ($company) use ($companyId) {
                    $company->orWhere(function ($scope) use ($companyId) {
                        $scope
                            ->where('visibility', 'Company')
                            ->where(function ($target) use ($companyId) {
                                $target
                                    ->where('visibility_company_id', $companyId)
                                    ->orWhere(function ($legacy) use ($companyId) {
                                        $legacy
                                            ->whereNull('visibility_company_id')
                                            ->where('company_id', $companyId);
                                    });
                            });
                    });
                })
                ->orWhereExists(function ($share) use ($uid, $companyId, $role, $table) {
                    $share
                        ->selectRaw('1')
                        ->from('egc_tool_share_grants as sg')
                        ->where('sg.resource_type', self::RESOURCE)
                        ->whereColumn('sg.resource_id', $table . '.sno')
                        ->where('sg.status', 'active')
                        ->where(function ($grant) use ($uid, $companyId, $role) {
                            $grant
                                ->where(function ($u) use ($uid) {
                                    $u->where('sg.grantee_type', 'user')
                                        ->where('sg.grantee_id', (string) $uid);
                                })
                                ->orWhere(function ($r) use ($role) {
                                    $r->where('sg.grantee_type', 'role')
                                        ->where('sg.grantee_id', $role);
                                })
                                ->orWhere(function ($g) {
                                    $g->where('sg.grantee_type', 'group')
                                        ->where('sg.grantee_id', '0');
                                })
                                ->when($companyId !== null, function ($c) use ($companyId) {
                                    $c->orWhere(function ($companyGrant) use ($companyId) {
                                        $companyGrant
                                            ->where('sg.grantee_type', 'company')
                                            ->where('sg.grantee_id', (string) $companyId);
                                    });
                                });
                        })
                        ->where(function ($expiry) {
                            $expiry
                                ->whereNull('sg.expires_at')
                                ->orWhere('sg.expires_at', '>=', now());
                        });
                });
        });
    }

    private function applyCompanyScopeForContact($query, Request $request): void
    {
        /*
         * Admins/Auditors can use the company filter directly.
         * Standard users must not be restricted by the owning company alone because
         * a contact may be owned by Company A but explicitly visible to Company B.
         * The record-level readable scope below is the authoritative filter for them.
         */
        if ($this->access->isGroupAdmin() || $this->access->isAuditor()) {
            if ($request->filled('company_id') && $request->company_id !== 'all') {
                $query->where('egc_tool_contacts.company_id', (int) $request->company_id);
            }
        }
    }

    private function applyCategoryScope($query, Request $request): void
    {
        if ($this->access->isGroupAdmin() || $this->access->isAuditor()) {
            if ($request->filled('company_id') && $request->company_id !== 'all') {
                $companyId = (int) $request->company_id;
                $query->where(function ($q) use ($companyId) {
                    $q->where('company_id', $companyId)
                        ->orWhereNull('company_id');
                });
            }
            return;
        }

        if ($this->cid() !== null) {
            $query->where(function ($q) {
                $q->where('company_id', $this->cid())
                    ->orWhereNull('company_id');
            });
        } else {
            $query->whereNull('company_id');
        }
    }

    private function canReadContact(Contact $contact): bool
    {
        if ($this->access->isGroupAdmin() || $this->access->isAuditor()) {
            return true;
        }

        if ((int) $contact->owner_user_id === $this->uid()) {
            return true;
        }

        if ($contact->visibility === 'Group') {
            $ids = $contact->visibility_user_ids;
            return empty($ids) || in_array($this->uid(), array_map('intval', $ids), true);
        }

        if ($contact->visibility === 'Company') {
            $targetCompany = $contact->visibility_company_id !== null
                ? $contact->visibility_company_id
                : $contact->company_id;

            if ($this->cid() !== null
                && $targetCompany !== null
                && (int) $targetCompany === $this->cid()) {
                return true;
            }
        }

        return $this->activeShareExists((int) $contact->sno, 'View');
    }

    private function canManageContact(Contact $contact): bool
    {
        if ($this->access->isAuditor()) {
            return false;
        }

        if ($this->access->isGroupAdmin()) {
            return true;
        }

        if ((int) $contact->owner_user_id === $this->uid()) {
            return true;
        }

        if ($this->access->isCompanyAdmin()) {
            $companyId = $contact->company_id !== null
                ? $contact->company_id
                : $contact->visibility_company_id;

            if ($companyId !== null
                && $this->cid() !== null
                && (int) $companyId === $this->cid()) {
                return true;
            }
        }

        return $this->activeShareExists((int) $contact->sno, 'Manage');
    }

    private function activeShareExists(int $resourceId, string $permission): bool
    {
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', self::RESOURCE)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('permission', $permission)
            ->where(function ($q) {
                $uid = $this->uid();
                $companyId = $this->cid();
                $role = $this->access->role();

                $q->where(function ($u) use ($uid) {
                    $u->where('grantee_type', 'user')
                        ->where('grantee_id', (string) $uid);
                })
                    ->orWhere(function ($r) use ($role) {
                        $r->where('grantee_type', 'role')
                            ->where('grantee_id', $role);
                    })
                    ->orWhere(function ($g) {
                        $g->where('grantee_type', 'group')
                            ->where('grantee_id', '0');
                    })
                    ->when($companyId !== null, function ($c) use ($companyId) {
                        $c->orWhere(function ($company) use ($companyId) {
                            $company->where('grantee_type', 'company')
                                ->where('grantee_id', (string) $companyId);
                        });
                    });
            })
            ->where(function ($q) {
                $q->whereNull('expires_at')
                    ->orWhere('expires_at', '>=', now());
            })
            ->exists();
    }

    private function activeCategoryExists(int $categoryId, Request $request): bool
    {
        if ($categoryId <= 0) {
            return false;
        }

        $query = ContactCategory::query()
            ->where('sno', $categoryId)
            ->where('status', 0);

        $this->applyCategoryScope($query, $request);

        return $query->exists();
    }

    private function countActiveStaffIds(array $ids): int
    {
        if (!$ids) {
            return 0;
        }

        return (int) DB::table('egc_staff')
            ->whereIn('sno', $ids)
            ->where('status', '!=', 2)
            ->count();
    }

    private function mainCompanyName(): string
    {
        if ($this->mainCompanyNameCache !== null) {
            return $this->mainCompanyNameCache;
        }

        $title = trim((string) GeneralSettingsModel::query()->value('title'));

        $this->mainCompanyNameCache = $title !== ''
            ? $title
            : 'Main Company';

        return $this->mainCompanyNameCache;
    }

    private function companyExists(int $companyId): bool
    {
        if ($companyId === 0) {
            return trim((string) GeneralSettingsModel::query()->value('title')) !== '';
        }

        return $companyId > 0 && DB::table('egc_company')
            ->where('sno', $companyId)
            ->where('status', 0)
            ->exists();
    }

    private function relationshipMasterTable(): string
    {
        if (Schema::hasTable('egc_relationship')) {
            return 'egc_relationship';
        }

        return 'egc_relationship_type';
    }

    private function relationshipExists(int $relationshipId): bool
    {
        return $relationshipId > 0 && DB::table($this->relationshipMasterTable())
            ->where('sno', $relationshipId)
            ->where('status', 0)
            ->exists();
    }

    private function relationshipName(?int $relationshipId): ?string
    {
        if (!$relationshipId) {
            return null;
        }

        if ($this->relationshipNameCache === []) {
            $table = $this->relationshipMasterTable();
            $this->relationshipNameCache = DB::table($table)
                ->where('status', 0)
                ->pluck('relationship_name', 'sno')
                ->mapWithKeys(fn ($name, $id) => [(int) $id => (string) $name])
                ->all();
        }

        return $this->relationshipNameCache[(int) $relationshipId] ?? null;
    }

    private function shareRows(int $contactId): array
    {
        if (!Schema::hasTable('egc_tool_share_grants')) {
            return [];
        }

        return DB::table('egc_tool_share_grants')
            ->where('resource_type', self::RESOURCE)
            ->where('resource_id', $contactId)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn ($share) => [
                'id' => (int) $share->sno,
                'grantee_type' => $share->grantee_type,
                'grantee_id' => $share->grantee_id,
                'permission' => $share->permission,
                'status' => $share->status,
                'expires_at' => $share->expires_at,
                'approval_required' => (bool) $share->approval_required,
                'approved_at' => $share->approved_at,
                'revoked_at' => $share->revoked_at,
            ])->values()->all();
    }

    private function findPotentialDuplicates(array $payload, ?int $excludeId = null)
    {
        $phone = $this->normalizePhone($payload['phone_primary'] ?? null);
        $email = strtolower(trim((string) ($payload['email_primary'] ?? '')));
        $name = trim((string) ($payload['person_name'] ?? ''));
        $organisation = trim((string) ($payload['organisation'] ?? ''));

        $query = Contact::query()
            ->where('status', 0)
            ->whereNull('deleted_at')
            ->when($excludeId, fn ($q) => $q->where('sno', '!=', $excludeId));

        if ($phone !== '' || $email !== '' || $name !== '') {
            $query->where(function ($q) use ($phone, $email, $name, $organisation) {
                if ($phone !== '') {
                    $digits = preg_replace('/\D+/', '', $phone);

                    $q->where(function ($phoneQuery) use ($phone, $digits) {
                        $phoneQuery
                            ->where('phone_primary', $phone)
                            ->orWhere('phone_alternate', $phone);

                        if ($digits !== '') {
                            $phoneQuery
                                ->orWhereRaw(
                                    "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_primary,' ',''),'-',''),'+',''),'(',''),')','') = ?",
                                    [$digits]
                                )
                                ->orWhereRaw(
                                    "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_alternate,' ',''),'-',''),'+',''),'(',''),')','') = ?",
                                    [$digits]
                                );
                        }
                    });
                }

                if ($email !== '') {
                    $q->orWhereRaw('LOWER(email_primary) = ?', [$email])
                        ->orWhereRaw('LOWER(email_secondary) = ?', [$email]);
                }

                if ($name !== '') {
                    $q->orWhere(function ($nameQuery) use ($name, $organisation) {
                        $nameQuery
                            ->whereRaw('LOWER(person_name) = ?', [strtolower($name)]);

                        if ($organisation !== '') {
                            $nameQuery->where(function ($orgQuery) use ($organisation) {
                                $orgQuery
                                    ->where('organisation', 'like', '%' . $this->escapeLike($organisation) . '%')
                                    ->orWhereNull('organisation');
                            });
                        }
                    });
                }
            });
        }

        $this->applyReadableContactScopeForDuplicate($query);

        $directMatches = $query
            ->orderByDesc('is_starred')
            ->orderBy('person_name')
            ->limit(10)
            ->get();

        if ($directMatches->isNotEmpty() || $name === '') {
            return $directMatches;
        }

        /*
         * Second-pass fuzzy name detection for records that do not share an
         * exact phone/email/name value. This is deliberately conservative:
         * candidates are narrowed by the first/last name token before the
         * similarity threshold is evaluated in PHP.
         */
        $nameParts = preg_split('/\s+/', strtolower($name), -1, PREG_SPLIT_NO_EMPTY);
        $firstToken = $nameParts[0] ?? '';
        $lastToken = count($nameParts) > 1 ? $nameParts[count($nameParts) - 1] : $firstToken;

        $fuzzyQuery = Contact::query()
            ->where('status', 0)
            ->whereNull('deleted_at')
            ->when($excludeId, fn ($q) => $q->where('sno', '!=', $excludeId))
            ->where(function ($q) use ($firstToken, $lastToken) {
                $q->where('person_name', 'like', $firstToken . '%')
                    ->orWhere('person_name', 'like', '%' . $lastToken);
            });

        if ($organisation !== '') {
            $fuzzyQuery->where(function ($q) use ($organisation) {
                $q->where('organisation', 'like', '%' . $this->escapeLike($organisation) . '%')
                    ->orWhereNull('organisation');
            });
        }

        $this->applyReadableContactScopeForDuplicate($fuzzyQuery);

        return $fuzzyQuery
            ->orderByDesc('is_starred')
            ->orderBy('person_name')
            ->limit(50)
            ->get()
            ->filter(function (Contact $candidate) use ($name) {
                similar_text(
                    strtolower(trim($candidate->person_name)),
                    strtolower(trim($name)),
                    $percent
                );

                return $percent >= 82;
            })
            ->values()
            ->take(10);
    }

    private function applyReadableContactScopeForDuplicate($query): void
    {
        if ($this->access->isGroupAdmin() || $this->access->isAuditor()) {
            return;
        }

        $uid = $this->uid();
        $companyId = $this->cid();
        $role = $this->access->role();
        $table = 'egc_tool_contacts';

        $query->where(function ($q) use ($uid, $companyId, $role, $table) {
            $q->where($table . '.owner_user_id', $uid)
                ->orWhere(function ($group) use ($uid) {
                    $group
                        ->where('visibility', 'Group')
                        ->where(function ($scope) use ($uid) {
                            $scope->whereNull('visibility_user_ids')
                                ->orWhereJsonContains('visibility_user_ids', $uid);
                        });
                })
                ->when($companyId !== null, fn ($c) => $c->orWhere(function ($company) use ($companyId) {
                    $company
                        ->where('visibility', 'Company')
                        ->where(function ($target) use ($companyId) {
                            $target
                                ->where('visibility_company_id', $companyId)
                                ->orWhere(function ($legacy) use ($companyId) {
                                    $legacy->whereNull('visibility_company_id')
                                        ->where('company_id', $companyId);
                                });
                        });
                }))
                ->orWhereExists(function ($share) use ($uid, $companyId, $role, $table) {
                    $share
                        ->selectRaw('1')
                        ->from('egc_tool_share_grants as sg')
                        ->where('sg.resource_type', self::RESOURCE)
                        ->whereColumn('sg.resource_id', $table . '.sno')
                        ->where('sg.status', 'active')
                        ->where(function ($grant) use ($uid, $companyId, $role) {
                            $grant->where(fn ($u) => $u->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                                ->orWhere(fn ($r) => $r->where('sg.grantee_type', 'role')->where('sg.grantee_id', $role))
                                ->orWhere(fn ($g) => $g->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'))
                                ->when($companyId !== null, fn ($c) => $c->orWhere(fn ($co) => $co->where('sg.grantee_type', 'company')->where('sg.grantee_id', (string) $companyId)));
                        })
                        ->where(fn ($expiry) => $expiry->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
                });
        });
    }

    private function decorateContact(Contact $contact, bool $detailed = false): array
    {
        $tags = $contact->tags ?? [];

        return [
            'sno' => (int) $contact->sno,
            'company_id' => $contact->company_id !== null ? (int) $contact->company_id : null,
            'company_name' => $this->companyName($contact->company_id),
            'owner_user_id' => $contact->owner_user_id !== null ? (int) $contact->owner_user_id : null,
            'visibility' => $contact->visibility,
            'visibility_company_id' => $contact->visibility_company_id !== null ? (int) $contact->visibility_company_id : null,
            'visibility_company_name' => $this->companyName(
                $contact->visibility_company_id !== null
                    ? $contact->visibility_company_id
                    : $contact->company_id
            ),
            'visibility_user_ids' => array_values(array_map('intval', $contact->visibility_user_ids ?? [])),
            'salutation' => $contact->salutation,
            'person_name' => $contact->person_name,
            'designation' => $contact->designation,
            'organisation' => $contact->organisation,
            'department' => $contact->department,
            'phone_primary' => $contact->phone_primary,
            'phone_alternate' => $contact->phone_alternate,
            'email_primary' => $contact->email_primary,
            'email_secondary' => $contact->email_secondary,
            'city' => $contact->city,
            'address' => $contact->address,
            'website' => $contact->website,
            'category_id' => $contact->category_id !== null ? (int) $contact->category_id : null,
            'category_name' => optional($contact->category)->category_name,
            'category_color' => optional($contact->category)->color ?: '#C0392B',
            'relationship_id' => $contact->relationship_id !== null ? (int) $contact->relationship_id : null,
            'relationship_name' => $this->relationshipName($contact->relationship_id),
            'tags' => $tags,
            'notes' => $contact->notes,
            'profile_photo' => $contact->profile_photo,
            'is_starred' => (bool) $contact->is_starred,
            'created_at' => $contact->created_at,
            'updated_at' => $contact->updated_at,
            'initials' => $this->initials($contact->person_name),
            'detailed' => $detailed,
        ];
    }

    private function companyName(?int $companyId): ?string
    {
        if ($companyId === null) {
            return null;
        }

        if ((int) $companyId === 0) {
            return $this->mainCompanyName();
        }

        if ($this->companyNameCache === []) {
            $this->companyNameCache = DB::table('egc_company')
                ->where('status', 0)
                ->pluck('company_name', 'sno')
                ->mapWithKeys(fn ($name, $id) => [(int) $id => (string) $name])
                ->all();
        }

        return $this->companyNameCache[(int) $companyId] ?? null;
    }

    private function initials(string $name): string
    {
        $name = trim($name);

        if ($name === '') {
            return '?';
        }

        $parts = preg_split('/\s+/', $name);
        $first = mb_substr($parts[0], 0, 1);

        if (count($parts) > 1) {
            return strtoupper($first . mb_substr($parts[count($parts) - 1], 0, 1));
        }

        return strtoupper($first);
    }

    private function parseTags(?string $value): array
    {
        if (is_array($value)) {
            $values = $value;
        } else {
            $values = preg_split('/[,;]+/', (string) $value) ?: [];
        }

        $values = array_map(
            fn ($tag) => trim(preg_replace('/\s+/', ' ', (string) $tag)),
            $values
        );

        $values = array_filter($values, fn ($tag) => $tag !== '');

        return array_values(array_unique($values));
    }

    private function nullableString($value): ?string
    {
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }

    private function normalizePhone(?string $value): string
    {
        return preg_replace('/\s+/', '', trim((string) $value)) ?: '';
    }

    // private function ids($value): array  
    // {
    //     if (is_string($value)) {
    //         $value = trim($value) === '' ? [] : preg_split('/[\s,]+/', trim($value));
    //     }

    //     if (!is_array($value)) {
    //         return [];
    //     }

    //     return array_values(array_unique(array_filter(array_map('intval', $value), fn ($id) => $id > 0)));
    // }

    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $value);
    }

    private function streamExport(Request $request, string $format)
    {
        abort_unless($this->access->canExport(), 403);

        $query = Contact::query()
            ->with('category')
            ->where('status', 0)
            ->whereNull('deleted_at');

        $this->applyReadableContactScope($query, $request);
        $this->applyFilters($query, $request);

        $rows = $query->orderByRaw('LOWER(person_name)')->get();

        $this->audit(
            $request,
            self::MODULE,
            'export',
            self::RESOURCE,
            null,
            null,
            null,
            ['format' => $format, 'row_count' => $rows->count()]
        );

        if ($format === 'csv') {
            return response()->streamDownload(function () use ($rows) {
                $out = fopen('php://output', 'w');

                fputcsv($out, [
                    'Name',
                    'Designation',
                    'Organisation',
                    'Department',
                    'Primary Phone',
                    'Alternate Phone',
                    'Email',
                    'Secondary Email',
                    'City',
                    'Address',
                    'Website',
                    'Category',
                    'Relationship',
                    'Visibility',
                    'Visibility Company',
                    'Tags',
                    'Notes',
                ]);

                foreach ($rows as $contact) {
                    fputcsv($out, [
                        $contact->person_name,
                        $contact->designation,
                        $contact->organisation,
                        $contact->department,
                        $contact->phone_primary,
                        $contact->phone_alternate,
                        $contact->email_primary,
                        $contact->email_secondary,
                        $contact->city,
                        $contact->address,
                        $contact->website,
                        optional($contact->category)->category_name,
                        $this->relationshipName($contact->relationship_id),
                        $contact->visibility,
                        $this->companyName(
                            $contact->visibility_company_id !== null
                                ? $contact->visibility_company_id
                                : $contact->company_id
                        ),
                        implode(', ', $contact->tags ?? []),
                        $contact->notes,
                    ]);
                }

                fclose($out);
            }, 'contactbook_' . now()->format('Ymd_His') . '.csv', [
                'Content-Type' => 'text/csv; charset=UTF-8',
            ]);
        }

        abort_unless(class_exists(Spreadsheet::class), 503);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = [
            'Name',
            'Designation',
            'Organisation',
            'Department',
            'Primary Phone',
            'Alternate Phone',
            'Email',
            'Secondary Email',
            'City',
            'Address',
            'Website',
            'Category',
            'Relationship',
            'Visibility',
            'Visibility Company',
            'Tags',
            'Notes',
        ];

        $sheet->fromArray($headers, null, 'A1');

        $rowNo = 2;

        foreach ($rows as $contact) {
            $sheet->fromArray([[
                $contact->person_name,
                $contact->designation,
                $contact->organisation,
                $contact->department,
                $contact->phone_primary,
                $contact->phone_alternate,
                $contact->email_primary,
                $contact->email_secondary,
                $contact->city,
                $contact->address,
                $contact->website,
                optional($contact->category)->category_name,
                $this->relationshipName($contact->relationship_id),
                $contact->visibility,
                $this->companyName(
                            $contact->visibility_company_id !== null
                                ? $contact->visibility_company_id
                                : $contact->company_id
                        ),
                implode(', ', $contact->tags ?? []),
                $contact->notes,
            ]], null, 'A' . $rowNo++);

        }

        $sheet->getStyle('A1:Q1')->getFont()->setBold(true);

        foreach (range('A', 'Q') as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }

        $writer = new Xlsx($spreadsheet);

        return response()->streamDownload(
            function () use ($writer) {
                $writer->save('php://output');
            },
            'contactbook_' . now()->format('Ymd_His') . '.xlsx',
            [
                'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ]
        );
    }

    private function parseImportFile($file): array
    {
        $ext = strtolower($file->getClientOriginalExtension());

        if (in_array($ext, ['xlsx', 'xls'], true)) {
            abort_unless(class_exists(IOFactory::class), 503);

            $spreadsheet = IOFactory::load($file->getRealPath());
            $sheet = $spreadsheet->getActiveSheet();
            $raw = $sheet->toArray(null, true, true, false);

            $headers = array_map(
                fn ($header) => trim((string) $header),
                array_shift($raw) ?: []
            );

            $headers = array_values(array_filter($headers, fn ($header) => $header !== ''));

            $rows = [];

            foreach ($raw as $row) {
                $row = array_values($row);

                $mapped = [];

                foreach ($headers as $index => $header) {
                    $mapped[$header] = $row[$index] ?? null;
                }

                if (count(array_filter($mapped, fn ($value) => trim((string) $value) !== '')) > 0) {
                    $rows[] = $mapped;
                }
            }

            return [$rows, $headers, 'excel'];
        }

        if (in_array($ext, ['csv', 'txt'], true)) {
            $handle = fopen($file->getRealPath(), 'r');

            if (!$handle) {
                throw new \RuntimeException('Unable to read CSV file.');
            }

            $headers = fgetcsv($handle) ?: [];
            $headers = array_map(fn ($header) => trim((string) $header), $headers);

            $rows = [];

            while (($row = fgetcsv($handle)) !== false) {
                $row = array_pad($row, count($headers), null);
                $mapped = [];

                foreach ($headers as $index => $header) {
                    if ($header !== '') {
                        $mapped[$header] = $row[$index] ?? null;
                    }
                }

                if (count(array_filter($mapped, fn ($value) => trim((string) $value) !== '')) > 0) {
                    $rows[] = $mapped;
                }
            }

            fclose($handle);

            return [$rows, $headers, 'csv'];
        }

        $text = file_get_contents($file->getRealPath()) ?: '';
        $cards = preg_split('/END:VCARD\s*/i', $text) ?: [];

        $rows = [];

        foreach ($cards as $card) {
            if (stripos($card, 'BEGIN:VCARD') === false) {
                continue;
            }

            $rows[] = [
                'Full Name' => $this->vcardValue($card, 'FN'),
                'Primary Phone' => $this->vcardValue($card, 'TEL'),
                'Email' => $this->vcardValue($card, 'EMAIL'),
                'Company / College' => $this->vcardValue($card, 'ORG'),
                'Position' => $this->vcardValue($card, 'TITLE'),
                'City' => '',
                'Address' => '',
            ];
        }

        return [
            $rows,
            ['Full Name', 'Primary Phone', 'Email', 'Company / College', 'Position', 'City', 'Address'],
            'vcard',
        ];
    }

    private function vcardValue(string $card, string $key): ?string
    {
        if (preg_match('/^' . preg_quote($key, '/') . '(?:;[^:]*)?:([^\r\n]*)/mi', $card, $match)) {
            return trim($match[1]);
        }

        return null;
    }

    private function suggestImportMapping(array $headers): array
    {
        $result = [];

        foreach (array_keys(self::IMPORT_FIELDS) as $field) {
            $result[$field] = null;

            foreach ($headers as $header) {
                if ($this->normalizedImportKey($header) === $this->normalizedImportKey(self::IMPORT_FIELDS[$field])) {
                    $result[$field] = $header;
                    break;
                }
            }

            if ($result[$field] !== null) {
                continue;
            }

            $aliases = $this->importAliases($field);

            foreach ($headers as $header) {
                $normalizedHeader = $this->normalizedImportKey($header);

                foreach ($aliases as $alias) {
                    if ($normalizedHeader === $this->normalizedImportKey($alias)) {
                        $result[$field] = $header;
                        break 2;
                    }
                }
            }
        }

        return $result;
    }

    private function importAliases(string $field): array
    {
        return [
            'person_name' => ['Name', 'Fullname', 'Contact Name', 'Person Name'],
            'designation' => ['Position', 'Job Title', 'Title', 'Designation'],
            'organisation' => ['Organisation', 'Organization', 'Company', 'Company Name', 'College'],
            'department' => ['Dept'],
            'phone_primary' => ['Phone', 'Mobile', 'Mobile Number', 'Primary Phone'],
            'phone_alternate' => ['Alternate Phone', 'Secondary Phone'],
            'email_primary' => ['Email Address', 'Primary Email'],
            'email_secondary' => ['Secondary Email', 'Alternate Email'],
            'category_name' => ['Category', 'Contact Category'],
            'tags' => ['Tag', 'Labels'],
            'notes' => ['Note', 'Remarks'],
        ][$field] ?? [];
    }

    private function normalizedImportKey(string $value): string
    {
        return strtolower(preg_replace('/[^a-z0-9]+/', '', $value));
    }

    private function mapImportRow(array $row, array $mapping): array
    {
        $mapped = [];

        foreach (array_keys(self::IMPORT_FIELDS) as $field) {
            $sourceColumn = $mapping[$field] ?? null;

            $mapped[$field] = $sourceColumn !== null && array_key_exists($sourceColumn, $row)
                ? $row[$sourceColumn]
                : null;
        }

        return $mapped;
    }

    private function validateImportContact(array $row, array $defaults): array
    {
        $categoryId = (int) ($defaults['category_id'] ?? 0);

        $categoryName = trim((string) ($row['category_name'] ?? ''));

        if ($categoryName !== '') {
            $category = ContactCategory::query()
                ->where('status', 0)
                ->where('category_name', $categoryName)
                ->first();

            if ($category) {
                $categoryId = (int) $category->sno;
            }
        }

        if (!$categoryId || !$this->activeCategoryExists($categoryId, request())) {
            throw new \RuntimeException('A valid ContactBook category is required for this import.');
        }

        $phone = $this->nullableString($row['phone_primary'] ?? null);
        $email = $this->nullableString($row['email_primary'] ?? null);

        if ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \RuntimeException('Invalid email address.');
        }

        $visibility = $defaults['visibility'] ?? 'Private';

        $rawCompanyId = $defaults['visibility_company_id'] ?? $this->cid();

        $companyId = $visibility === 'Company'
            ? (($rawCompanyId === null || $rawCompanyId === '') ? null : (int) $rawCompanyId)
            : null;

        $groupIds = $visibility === 'Group'
            ? ($this->ids($defaults['visibility_user_ids'] ?? []) ?: null)
            : null;

        return [
            'company_id' => $this->cid(),
            'owner_user_id' => $this->uid(),
            'visibility' => $visibility,
            'visibility_company_id' => $companyId !== null ? $companyId : null,
            'visibility_user_ids' => $groupIds,
            'salutation' => $this->nullableString($row['salutation'] ?? null),
            'person_name' => trim((string) ($row['person_name'] ?? '')),
            'designation' => $this->nullableString($row['designation'] ?? null),
            'organisation' => $this->nullableString($row['organisation'] ?? null),
            'department' => $this->nullableString($row['department'] ?? null),
            'phone_primary' => $phone,
            'phone_alternate' => $this->nullableString($row['phone_alternate'] ?? null),
            'email_primary' => $email,
            'email_secondary' => $this->nullableString($row['email_secondary'] ?? null),
            'city' => $this->nullableString($row['city'] ?? null),
            'address' => $this->nullableString($row['address'] ?? null),
            'website' => $this->nullableString($row['website'] ?? null),
            'category_id' => $categoryId,
            'relationship_id' => null,
            'tags_json' => $this->parseTags($row['tags'] ?? ''),
            'notes' => $this->nullableString($row['notes'] ?? null),
            'profile_photo' => null,
            'is_starred' => 0,
            'status' => 0,
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ];
    }

    private function mergeImportedContactData(Contact $target, array $incoming): array
    {
        $update = [
            'updated_by' => $this->uid(),
        ];

        $fields = [
            'salutation',
            'person_name',
            'designation',
            'organisation',
            'department',
            'phone_primary',
            'phone_alternate',
            'email_primary',
            'email_secondary',
            'city',
            'address',
            'website',
            'category_id',
            'relationship_id',
            'notes',
            'profile_photo',
        ];

        foreach ($fields as $field) {
            if (
                ($target->{$field} === null || $target->{$field} === '') &&
                array_key_exists($field, $incoming) &&
                $incoming[$field] !== null &&
                $incoming[$field] !== ''
            ) {
                $update[$field] = $incoming[$field];
            }
        }

        $existingTags = $target->tags ?? [];
        $incomingTags = $incoming['tags_json'] ?? $incoming['tags'] ?? [];
        $incomingTags = is_array($incomingTags) ? $incomingTags : $this->parseTags((string) $incomingTags);

        if ($incomingTags) {
            $update['tags_json'] = array_values(array_unique(array_merge($existingTags, $incomingTags)));
        }

        return $update;
    }

    private function googleGroupsFromToken(string $accessToken): array
    {
        try {
            $response = Http::withToken($accessToken)
                ->acceptJson()
                ->timeout(15)
                ->get('https://people.googleapis.com/v1/contactGroups', [
                    'pageSize' => 200,
                ]);

            if (!$response->successful()) {
                return [];
            }

            return collect($response->json('contactGroups', []))
                ->map(fn ($group) => [
                    'id' => (string) data_get($group, 'resourceName'),
                    'name' => (string) data_get($group, 'name'),
                    'member_count' => (int) data_get($group, 'memberCount', 0),
                ])
                ->filter(fn ($group) => $group['id'] !== '' && $group['name'] !== '')
                ->values()
                ->all();
        } catch (\Throwable $e) {
            report($e);
            return [];
        }
    }

    private function googlePersonMatchesGroups(array $person, array $groupIds): bool
    {
        $memberships = data_get($person, 'memberships', []);

        foreach ($memberships as $membership) {
            $resourceName = (string) data_get($membership, 'contactGroupMembership.contactGroupResourceName');

            if ($resourceName !== '' && in_array($resourceName, $groupIds, true)) {
                return true;
            }
        }

        return false;
    }

    private function googlePopupResponse(bool $success, string $message)
    {
        $payload = json_encode([
            'source' => 'egpk-contactbook-google',
            'success' => $success,
            'message' => $message,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return response(
            '<!doctype html><html><head><meta charset="utf-8"><title>Google Contact Import</title></head><body>' .
            '<script>window.opener && window.opener.postMessage(' . $payload . ', window.location.origin); window.close();</script>' .
            '<p>' . e($message) . '</p></body></html>',
            $success ? 200 : 400
        )->header('Content-Type', 'text/html; charset=UTF-8');
    }

    private function vcardEscape(?string $value): string
    {
        return str_replace(
            ["\\", ";", ",", "\r", "\n"],
            ["\\\\", "\;", "\,", '', '\n'],
            (string) $value
        );
    }
}
