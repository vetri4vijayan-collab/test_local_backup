<?php
namespace App\Http\Controllers\productivity;

use App\Http\Controllers\Controller;
use App\Services\Productivity\ProductivityAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

abstract class ProductivityBaseController extends Controller
{
    public function __construct(protected ProductivityAccessService $access) {}

    protected function uid(): int { return $this->access->userId(); }
    protected function cid(): ?int { return $this->access->companyId(); }

    protected function ok($data = null, string $message = 'Success', int $code = 200): JsonResponse
    {
        return response()->json(['status' => $code, 'message' => $message, 'data' => $data], $code);
    }

    protected function fail(string $message, int $code = 422, array $extra = []): JsonResponse
    {
        return response()->json(array_merge(['status' => $code, 'message' => $message, 'data' => null], $extra), $code);
    }

    protected function ids($value): array
    {
        if (is_string($value)) $value = trim($value) === '' ? [] : preg_split('/[\s,]+/', trim($value));
        if (!is_array($value)) return [];
        return array_values(array_unique(array_filter(array_map('intval', $value), fn($v) => $v > 0)));
    }

    protected function applyScope($query, Request $request, string $column = 'company_id'): void
    {
        $this->access->applyCompanyScope($query, $request, $column);
    }

    protected function applyReadableScope($query, Request $request, string $resourceType, string $ownerColumn = 'owner_user_id', string $visibilityColumn = 'visibility', string $companyColumn = 'company_id')
    {
        $this->access->applyReadableScope($query, $request, $resourceType, $ownerColumn, $visibilityColumn, $companyColumn);
        return $query;
    }

    protected function userScoped($query, string $ownerColumn = 'owner_user_id')
    {
        if (!$this->access->isGroupAdmin() && !$this->access->isAuditor()) {
            $query->where(function($q) use ($ownerColumn) {
                $q->where($ownerColumn, $this->uid())
                  ->orWhereIn($ownerColumn, function($sub) { $sub->select('owner_user_id')->from('egc_tool_share_grants')->where('status','active')->where('grantee_type','user')->where('grantee_id',(string)$this->uid()); });
            });
        }
        return $query;
    }

    protected function parseDateTime(?string $value): ?Carbon
    {
        if (!$value) return null;
        return Carbon::parse($value);
    }

    protected function audit(Request $request, string $module, string $action, ?string $type = null, ?int $id = null, $before = null, $after = null, array $meta = [], bool $sensitive = false): void
    {
        $this->access->audit($request, $module, $action, $type, $id, $before, $after, $meta, $sensitive);
    }
}
