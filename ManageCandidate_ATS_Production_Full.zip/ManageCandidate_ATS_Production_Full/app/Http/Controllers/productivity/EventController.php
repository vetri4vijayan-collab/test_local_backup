<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Event;
use Illuminate\Http\Request;

class EventController extends ProductivityBaseController
{
    public function index() { return view('content.productivity.events.index'); }

    public function data(Request $request)
    {
        $query = Event::query()->whereNull('deleted_at');
        $this->applyReadableScope($query, $request, 'event');
        if ($request->filled('status')) $query->where('status', $request->status);
        if ($request->filled('event_type')) $query->where('event_type', $request->event_type);
        if ($request->filled('search')) {
            $s = trim((string) $request->search);
            $query->where(fn ($q) => $q->where('event_name', 'like', "%{$s}%")->orWhere('organisation', 'like', "%{$s}%")->orWhere('venue', 'like', "%{$s}%"));
        }
        return $this->ok(['rows' => $query->orderBy('event_date')->orderBy('event_time')->paginate(min(max((int) $request->get('per_page', 25), 10), 100))]);
    }

    public function calendar(Request $request)
    {
        $request->validate(['start' => ['required', 'date'], 'end' => ['required', 'date']]);
        $query = Event::query()->whereNull('deleted_at')->whereBetween('event_date', [$request->start, $request->end]);
        $this->applyReadableScope($query, $request, 'event');
        return $this->ok($query->orderBy('event_date')->orderBy('event_time')->get());
    }

    public function show(Request $request, int $id)
    {
        $event = Event::findOrFail($id);
        abort_unless($this->access->canReadResource('event', $id, $event->owner_user_id, $event->company_id, $event->visibility), 403);
        return $this->ok($event);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $this->validateData($request);
        $this->assertCompany($data['company_id'] ?? null);
        $event = Event::create(array_merge($data, ['company_id' => $data['company_id'] ?? $this->cid(), 'owner_user_id' => $this->uid(), 'created_by' => $this->uid(), 'updated_by' => $this->uid()]));
        return $this->ok($event, 'Event created.');
    }

    public function update(Request $request, int $id)
    {
        $event = Event::findOrFail($id);
        abort_unless($this->access->canManageResource('event', $id, $event->owner_user_id), 403);
        $data = $this->validateData($request);
        $this->assertCompany($data['company_id'] ?? $event->company_id);
        $event->update(array_merge($data, ['updated_by' => $this->uid()]));
        return $this->ok($event->fresh(), 'Event updated.');
    }

    public function delete(Request $request, int $id)
    {
        $event = Event::findOrFail($id);
        abort_unless($this->access->canManageResource('event', $id, $event->owner_user_id), 403);
        $event->update(['deleted_at' => now(), 'updated_by' => $this->uid(), 'status' => 'Cancelled']);
        return $this->ok(null, 'Event deleted.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'event_name' => ['required', 'string', 'max:220'],
            'organisation' => ['nullable', 'string', 'max:180'],
            'event_type' => ['required', 'string', 'max:80'],
            'event_date' => ['required', 'date'],
            'event_time' => ['nullable', 'date_format:H:i'],
            'venue' => ['nullable', 'string', 'max:300'],
            'is_online' => ['nullable', 'boolean'],
            'online_link' => ['nullable', 'url', 'max:2000'],
            'payment_amount' => ['nullable', 'numeric', 'min:0'],
            'status' => ['required', 'in:Planned,Confirmed,Completed,Cancelled'],
            'reminder_stage' => ['nullable', 'string', 'max:40'],
            'description' => ['nullable', 'string', 'max:10000'],
        ]);
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company event access is not permitted.');
    }
}
