<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Crm extends Controller
{
    public function index(){
            $user = Auth::user();
            
    
      return view('content.dashboard.hr_ultra',[
         'companies' => DB::table('egc_company')->where('status',0)->get(),
      ]);
    //   return view('content.dashboard.dashboards-crm');
    }


    public function getDashboardData(Request $request)
{
    try {

        $today = now()->toDateString();
        $company = $request->company_id ?? '';
        $entity = $request->entity_id ?? '';
        $department = $request->department_id ?? '';
        // 👨‍💼 STAFF
        // $totalStaff = DB::table('egc_staff')->where('status',0)->count() ?? 0;

        $staffQuery = DB::table('egc_staff')->where('status',0);

        if($company != ''){
          if($company == 'egc'){
             $staffQuery->where('egc_staff.company_type',1);
          }else{
            $staffQuery->where('egc_staff.company_id', 'LIKE', $company);
          }
            
        }
        if ($entity) {
          $staffQuery->where('egc_staff.entity_id', $entity);
        }

        
        if ($department) {
            $staffQuery->where('egc_staff.department_id', $department);
        }

       
        $staffIds = $staffQuery->pluck('sno');

        // ✅ ATTENDANCE
        $present = DB::table('egc_staff_attendance')
            ->whereDate('date', $today)
            ->whereIn('staff_id', $staffIds)
            ->where('attendance', 'P')
            ->where('status',0)
            ->count() ?? 0;

        // $late = DB::table('egc_staff_attendance')
        //     ->whereDate('date', $today)
        //     ->where('attendance', 'late')
        //     ->where('status',0)
        //     ->count() ?? 0;
        $late = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->join('egc_shift_time_log as stl', function ($join) {
                    $join->on('stl.staff_id', '=', 'att.staff_id');
                })
                ->join('egc_shift_day_times as sd', function ($join) {
                    $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                        ->where('sd.status', 0);
                })
                ->whereDate('att.date', $today)
                ->whereIn('att.staff_id', $staffIds)
                ->where('att.status', 0)
          
                ->whereRaw("DATE(att.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
                // ✅ Match day (Mon, Tue...)
                ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))")
                // ✅ Late condition
                ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
                ->whereRaw("
                    TIME_FORMAT(att.in_time, '%H:%i') > 
                    TIME_FORMAT(ADDTIME(sd.time_from, '00:15:00'), '%H:%i')
                ")
                // ->whereRaw("
                //     TIME_FORMAT(att.in_time, '%H:%i') > TIME_FORMAT(sd.time_from, '%H:%i')
                // ")
                ->count() ?? 0;

        $leave = DB::table('egc_staff_attendance')
            ->whereDate('date', $today)
            ->whereIn('staff_id', $staffIds)
            ->whereIn('attendance', ['L','A'])
              ->where('status',0)
            ->count() ?? 0;

        $permission = DB::table('egc_staff_attendance')
            ->whereDate('date', $today)
            ->where('attendance', 'PR')
            ->whereIn('staff_id', $staffIds)
              ->where('status',0)
            ->count() ?? 0;

        $totalStaff = $staffIds->count();

        $absent = max(0, $leave);

        

        // 🧑‍💼 RECRUITMENT
        $candidates = DB::table('egc_applicant')->where('status','!=',2)->count() ?? 0;
        $shortlisted = DB::table('egc_applicant')->where('status', '1')->where('status','!=',2)->count() ?? 0;
        $hired = DB::table('egc_applicant')->where('status', '3')->count() ?? 0;

        // 🎓 TRAINING
        $trainings = DB::table('egc_training_planner')->where('status','!=',2)->count() ?? 0;
        $ongoingTraining = DB::table('egc_training_planner')->where('status', '1')->count() ?? 0;

        // 💰 PAYROLL
        $payroll = DB::table('egc_payroll_entries_new')->sum('net_salary') ?? 0;
        $pending = DB::table('egc_payroll_entries_new')->sum('total_deductions') ?? 0;
        $processed = DB::table('egc_payroll_entries_new')->sum('total_earnings') ?? 0;

        // 👥 EMPLOYEES (SAFE FIELDS)
            $employees = DB::table('egc_staff')->where('egc_staff.status', '!=', 2)
                ->select('egc_staff.*',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_company.company_logo',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_shift_time.shift_name',
                'egc_job_role.job_position_name as job_role_name',
                )
                ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                ->leftJoin('egc_shift_time', 'egc_staff.shift_time_id', 'egc_shift_time.sno')
                ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
                ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
                ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
                ->whereIn('egc_staff.status', [0,1])
                ->latest()
                ->limit(5)
                ->get();

        return response()->json([
            'status' => true,
            'data' => compact(
                'totalStaff',
                'present',
                'late',
                'leave',
                'permission',
                'absent',
                'candidates',
                'shortlisted',
                'hired',
                'trainings',
                'ongoingTraining',
                'payroll',
                'pending',
                'processed',
                'employees'
            )
        ]);

    } catch (\Exception $e) {

        \Log::error('Dashboard Error: '.$e->getMessage());

        return response()->json([
            'status' => false,
            'data' => [],
            'message' => 'Something went wrong'.$e->getMessage()
        ]);
    }
}
}
