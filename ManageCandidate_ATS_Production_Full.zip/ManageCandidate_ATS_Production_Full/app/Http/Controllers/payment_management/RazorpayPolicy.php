<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Log;
use App\Models\CustomerModel;
use App\Models\SubLedgerModel;
use App\Models\TransactionModel;
use App\Models\ProposalPayHistoryModel;
use Illuminate\Support\Facades\Http;
use App\Models\BranchModel;
use App\Models\StaffModel;
use App\Models\ProductModel;
use App\Models\ManageProductVaiantModel;
use App\Models\ManageProductVariableModel;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use Carbon\Carbon;
use PDF;

class RazorpayPolicy extends Controller
{
  
  public function ContactUs(){
    return view('content.razorpay_policy.contact-us');
  }
  public function ShippingPolicy(){
    return view('content.razorpay_policy.shipping-policy');
  }
  public function TermsAndConditionPolicy(){
    return view('content.razorpay_policy.terms-and-conditions');
  }

  public function CancelAndRefundPolicy(){
    return view('content.razorpay_policy.cancellations-and-refunds');
  }
  public function PrivacyPolicy(){
    return view('content.razorpay_policy.privacy-refunds');
  }


}
