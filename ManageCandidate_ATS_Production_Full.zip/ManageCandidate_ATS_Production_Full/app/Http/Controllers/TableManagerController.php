<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Log;

class TableManagerController extends Controller
{

  public function index(Request $request)
  {
    return view('content.settings.Base.data.data_base');
  }
  /**
   * Get all database tables
   */
  public function getTables()
  {
    try {
      // Get all tables from database
      $tables = DB::select('SHOW TABLES');
      $tableNames = array_map('current', $tables);

      return response()->json([
        'success' => true,
        'tables' => $tableNames
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => 'Failed to fetch tables: ' . $e->getMessage()
      ], 500);
    }
  }

  /**
   * Get table data with pagination
   */
  public function getTableData(Request $request)
  {
    try {
      $table = $request->input('table');
      $page = $request->input('page', 1);
      $limit = $request->input('limit', 10);
      $offset = ($page - 1) * $limit;

      if (empty($table)) {
        throw new \Exception('Table name is required');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get table columns
      $columns = Schema::getColumnListing($table);

      // Check if table has id column
      $hasIdColumn = in_array('sno', $columns);

      // Get total records count
      $totalRecords = DB::table($table)->count();

      // Get paginated data
      $query = DB::table($table);

      // Order by id if exists, otherwise order by first column
      if ($hasIdColumn) {
        $query->orderBy('sno', 'asc');
      } else {
        $query->orderBy($columns[0], 'asc');
      }

      $data = $query->skip($offset)->take($limit)->get();

      $totalPages = ceil($totalRecords / $limit);

      return response()->json([
        'success' => true,
        'columns' => $columns,
        'data' => $data,
        'pagination' => [
          'current_page' => (int)$page,
          'total_pages' => $totalPages,
          'total_records' => $totalRecords,
          'start' => $offset + 1,
          'end' => min($offset + $limit, $totalRecords),
          'limit' => $limit
        ]
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Update single cell value
   */
  public function updateCell(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('id');
      $column = $request->input('column');
      $value = $request->input('value');

      if (empty($table) || empty($id) || empty($column)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate column exists
      if (!Schema::hasColumn($table, $column)) {
        throw new \Exception('Column does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an id column for updates');
      }

      // Update record
      $updated = DB::table($table)
        ->where('sno', $id)
        ->update([$column => $value]);

      if ($updated) {
        return response()->json([
          'success' => true,
          'message' => 'Record updated successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'No changes made or record not found'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Update entire row
   */
  public function updateRow(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('sno');
      $data = $request->input('data', []);

      if (empty($table) || empty($id) || empty($data)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an sno column for updates');
      }

      // Validate columns exist
      foreach (array_keys($data) as $column) {
        if (!Schema::hasColumn($table, $column)) {
          throw new \Exception("Column '$column' does not exist");
        }
      }

      // Update record
      $updated = DB::table($table)
        ->where('sno', $id)
        ->update($data);

      if ($updated) {
        return response()->json([
          'success' => true,
          'message' => 'Row updated successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'No changes made or record not found'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Delete record
   */
  public function deleteRecord(Request $request)
  {
    try {
      $table = $request->input('table');
      $id = $request->input('sno');

      if (empty($table) || empty($id)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate id column exists
      if (!Schema::hasColumn($table, 'sno')) {
        throw new \Exception('Table must have an id column for deletion');
      }

      // Delete record
      $deleted = DB::table($table)
        ->where('sno', $id)
        ->delete();

      if ($deleted) {
        return response()->json([
          'success' => true,
          'message' => 'Record deleted successfully'
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'Record not found'
        ], 404);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Add new record
   */
  public function addRecord(Request $request)
  {
    try {
      $table = $request->input('table');
      $data = $request->input('data', []);

      if (empty($table) || empty($data)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Validate columns exist
      foreach (array_keys($data) as $column) {
        if (!Schema::hasColumn($table, $column)) {
          throw new \Exception("Column '$column' does not exist");
        }
      }

      // Insert new record
      $id = DB::table($table)->insertGetId($data);

      if ($id) {
        return response()->json([
          'success' => true,
          'message' => 'Record added successfully',
          'id' => $id
        ]);
      } else {
        return response()->json([
          'success' => false,
          'message' => 'Failed to add record'
        ], 400);
      }
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }

  /**
   * Search table data
   */
  public function searchTable(Request $request)
  {
    try {
      $table = $request->input('table');
      $search = $request->input('search');
      $page = $request->input('page', 1);
      $limit = $request->input('limit', 10);
      $offset = ($page - 1) * $limit;

      if (empty($table) || empty($search)) {
        throw new \Exception('Missing required parameters');
      }

      // Validate table exists
      if (!Schema::hasTable($table)) {
        throw new \Exception('Table does not exist');
      }

      // Get table columns
      $columns = Schema::getColumnListing($table);

      // Build search query
      $query = DB::table($table);

      // Add search conditions for each column
      foreach ($columns as $column) {
        $query->orWhere($column, 'LIKE', "%{$search}%");
      }

      // Get total records count
      $totalRecords = $query->count();

      // Get paginated data
      $data = $query->skip($offset)->take($limit)->get();

      $totalPages = ceil($totalRecords / $limit);

      return response()->json([
        'success' => true,
        'columns' => $columns,
        'data' => $data,
        'pagination' => [
          'current_page' => (int)$page,
          'total_pages' => $totalPages,
          'total_records' => $totalRecords,
          'start' => $offset + 1,
          'end' => min($offset + $limit, $totalRecords),
          'limit' => $limit,
          'search' => $search
        ]
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'success' => false,
        'message' => $e->getMessage()
      ], 400);
    }
  }


public function addColumns()
{
    try {

        // Check created_by column
        if (!Schema::hasColumn('egc_payroll_employee_structure_details', 'created_by')) {

            Schema::table('egc_payroll_employee_structure_details', function (Blueprint $table) {
                $table->unsignedBigInteger('created_by')
                      ->nullable()
                      ->default(0)
                      ->after('updated_at');
            });
        }

        // Check updated_by column
        if (!Schema::hasColumn('egc_payroll_employee_structure_details', 'updated_by')) {

            Schema::table('egc_payroll_employee_structure_details', function (Blueprint $table) {
                $table->unsignedBigInteger('updated_by')
                      ->nullable()
                      ->default(0)
                      ->after('created_by');
            });
        }

        return response()->json([
            'status'  => true,
            'message' => 'Columns added successfully'
        ]);

    } catch (\Exception $e) {

        Log::error('Add column error: ' . $e->getMessage());

        return response()->json([
            'status'  => false,
            'message' => 'Failed to add columns',
            'error'   => $e->getMessage()
        ], 500);
    }
}
}
