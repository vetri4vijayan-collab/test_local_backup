<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\ETPLMail;
use App\Models\ChatModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\ManageTickickModel;
use App\Models\CugManagementModel;
use App\Models\OtpModel;
use App\Models\cugUser;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\ProductModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\AppointmentModel;
use App\Models\FollowupReasonModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Laravel\Sanctum\PersonalAccessToken;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

use App\Models\CallContactsModel;
use App\Models\CallTrackerModel;
use App\Models\NotificationMobileModel;
use App\Traits\NotifiableTrait;
use Illuminate\Support\Facades\Log;

class IChatController extends Controller
{
    
    public function getStaffDataList(Request $request)
    {

        $data = StaffModel::where('egc_staff.status', 0)->get();

        $staffData = $data->map(function ($item) {
            return [
                'staff_name' => $item->staff_name,
                'staff_id' => $item->staff_id,
                'staffProfileURL' => $item->profile_image_url,
            ];
        });
        
        return response()->json([
            'status' => 200,
            'message' => 'Staff data fetched successfully',
            'error_msg' => null,
            'data' => $staffData
        ]);
    }
    
}