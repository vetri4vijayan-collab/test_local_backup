<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CallTrackerModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class InternalCallTrackerController extends Controller
{
    public function sync(Request $request)
    {
        $rawBody = $request->getContent();

        if (!$this->isValidSignature($request, $rawBody)) {

            $timestamp = (string) $request->header('X-EGC-Timestamp');
            $providedSignature = (string) $request->header('X-EGC-Signature');
            $timecheck = false;
            if (abs(time() - (int) $timestamp) > 300) {
                $timecheck = true;
            }


            Log::error('Internal EGC call tracker synchronization failed', [
                'timecheck' => $timecheck,
                'timestamp' => $timestamp,
                'providedSignature' => $providedSignature,
                'timestamp_dig' => ctype_digit($timestamp),
                'external_uuid' => $request->external_uuid,
                'source' => $request->source,
                'request' => $request,
                'rawBody' => $rawBody,
            ]);

            return response()->json([
                'status' => 401,
                'message' => 'Unauthorized synchronization request.',
                'error_msg' => 'Invalid EGC synchronization signature.',
                'data' => null,
            ], 401);
        }

        $validator = Validator::make($request->all(), [
            'external_uuid' => 'required|string|max:64',
            'source_call_id' => 'required|integer|min:1',
            'source' => 'required|string|max:100',
            'source_entity_id' => 'required|integer|min:0',
            'entity_id' => 'required|integer|min:0',

            'branch_id' => 'nullable|integer|min:0',
            'branch_staff_id' => 'required|integer|min:1',
            'call_tracker_staff_id' => 'required|integer|min:1',
            'staff_phone_no' => 'required|string|max:100',

            'customer_phone_no' => 'required|string|max:100',
            'customer_name' => 'nullable|string|max:255',
            'customer_status' => 'nullable|integer',
            'customer_reason' => 'nullable|string',

            'call_start_date' => 'required|date',
            'call_end_date' => 'nullable|date',
            'call_start_time' => 'required|date_format:H:i:s',
            'call_end_time' => 'nullable|date_format:H:i:s',
            'call_duration' => [
                'required',
                'regex:/^\d{2,3}:\d{2}:\d{2}$/',
            ],

            'latitude' => 'nullable|string|max:100',
            'longitude' => 'nullable|string|max:100',
            'call_status' => 'required|integer|in:0,1,2,3,4',
            'count_status' => 'nullable|integer',
            'audio_file' => 'nullable|string|max:2000',
            'created_at' => 'nullable|date',
            'updated_at' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null,
            ], 422);
        }

        /*
         * entity_id is the routing authority.
         * For your current setup:
         *   0 = EGC
         *   1 = PhDiZone
         *   2 = Elysium Academy
         *   3 = EiBS
         *   etc.
         *
         * Do not overwrite it from the CUG table because the same CUG
         * number may be used by a source application during migration.
         */
        $entityId = (int) $request->entity_id;

        DB::beginTransaction();

        try {
            $existing = CallTrackerModel::where('external_uuid', $request->external_uuid)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                DB::commit();

                return response()->json([
                    'status' => 200,
                    'message' => 'Call tracker already synchronized.',
                    'error_msg' => null,
                    'data' => [
                        'sno' => $existing->sno,
                        'external_uuid' => $existing->external_uuid,
                        'entity_id' => $existing->entity_id,
                        'duplicated' => true,
                    ],
                ], 200);
            }

            /*
             * Resolve the global EGC CUG record from the source phone.
             * entity_id remains payload-controlled because it represents
             * the business entity that owns the source application record.
             */
            $staffPhone = $this->normalizePhone($request->staff_phone_no);

            $cug = DB::table('egc_cug_numbers')
                ->whereIn('cug_number', array_values(array_unique([
                    $request->staff_phone_no,
                    $staffPhone,
                ])))
                ->where('status', 1)
                ->orderByDesc('sno')
                ->first();

            $cugId = $cug?->sno;
            $resolvedBranchId = $cug?->branch_id ?? (int) ($request->branch_id ?? 0);

            $assignment = null;
            $caller_staff_id = null;

            if ($cugId) {
                $assignment = DB::table('egc_cug_assignments')
                    ->where('cug_id', $cugId)
                    ->where('is_current', 1)
                    ->where('status', 0)
                    // ->whereDate('start_date', '<=', $request->call_start_date)
                    // ->where(function ($query) use ($request) {
                    //     $query->whereNull('end_date')
                    //         ->orWhereDate('end_date', '>=', $request->call_start_date);
                    // })
                    // ->orderByDesc('start_date')
                    ->orderByDesc('sno')
                    ->first();

                /*
                 * Keep the record useful even if a historical call predates
                 * the current assignment. Fall back to the latest active
                 * assignment for the same CUG/staff.
                 */
                if (!$assignment) {
                    $assignment = DB::table('egc_cug_assignments')
                        ->where('cug_id', $cugId)
                        // ->where('staff_id', (int) $request->branch_staff_id)
                        ->orderByDesc('is_current')
                        ->orderByDesc('status')
                        ->orderByDesc('start_date')
                        ->orderByDesc('sno')
                        ->first();
                }
            }

            $cugAssignmentId = $assignment?->sno;
            $caller_staff_id =$assignment?->staff_id ;

            /*
             * Global contact record: one contact per phone number in EGC.
             * Individual call ownership is preserved on egc_call_tracker
             * through entity_id/staff/cug/assignment.
             */
            $customerPhoneCandidates = $this->phoneCandidates($request->customer_phone_no);

            $contact = DB::table('egc_call_contacts')
                ->whereIn('phone', $customerPhoneCandidates)
                ->orderByDesc('sno')
                ->lockForUpdate()
                ->first();

            $now = Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');

            if (!$contact) {
                $contactId = DB::table('egc_call_contacts')->insertGetId([
                    'phone' => $request->customer_phone_no,
                    'name' => $request->customer_name,
                    'staff_id' => (int) $caller_staff_id,
                    'outgoing_count' => 0,
                    'incoming_count' => 0,
                    'missed_count' => 0,
                    'rejected_count' => 0,
                    'dialed_count' => 0,
                    'last_staff_id' => (int) $caller_staff_id,
                    'created_by' => (int) $caller_staff_id,
                    'updated_by' => (int) $caller_staff_id,
                    'status' => 0,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                $contact = DB::table('egc_call_contacts')->where('sno', $contactId)->first();
            } else {
                $contactId = (int) $contact->sno;

                $contactUpdate = [
                    'last_staff_id' => (int) $caller_staff_id,
                    'updated_by' => (int) $caller_staff_id,
                    'updated_at' => $now,
                ];

                if ($request->filled('customer_name')) {
                    $contactUpdate['name'] = $request->customer_name;
                }

                DB::table('egc_call_contacts')
                    ->where('sno', $contactId)
                    ->update($contactUpdate);
            }

            /*
             * Contact counters are incremented only after the idempotency
             * check, so retries never double-count.
             */
            $counterColumn = match ((int) $request->call_status) {
                0 => 'outgoing_count',
                1 => 'incoming_count',
                2 => 'missed_count',
                3 => 'rejected_count',
                4 => 'dialed_count',
            };

            DB::table('egc_call_contacts')
                ->where('sno', $contactId)
                ->update([
                    $counterColumn => DB::raw('COALESCE(' . $counterColumn . ', 0) + 1'),
                    'updated_at' => $now,
                ]);

            $callId = DB::table('egc_call_tracker')->insertGetId([
                'contact_id' => $contactId,
                'entity_id' => $entityId,
                'branch_id' => (int) $resolvedBranchId,
                'cug_id' => $cugId,
                'cug_assignment_id' => $cugAssignmentId,
                'branch_staff_id' => (int) $caller_staff_id,
                'call_tracker_staff_id' => (int) $request->call_tracker_staff_id,
                'staff_phone_no' => $request->staff_phone_no,
                'customer_phone_no' => $request->customer_phone_no,
                'customer_name' => $request->customer_name,
                'customer_status' => (int) ($request->customer_status ?? 0),
                'customer_reason' => $request->customer_reason,
                'call_start_date' => $request->call_start_date,
                'call_end_date' => $request->call_end_date,
                'call_start_time' => $request->call_start_time,
                'call_end_time' => $request->call_end_time,
                'call_duration' => $request->call_duration,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'call_status' => (int) $request->call_status,
                'count_status' => (int) ($request->count_status ?? 1),
                'audio_file' => $request->audio_file,
                'external_uuid' => $request->external_uuid,
                'created_at' => $request->filled('created_at')
                    ? Carbon::parse($request->created_at)->format('Y-m-d H:i:s')
                    : $now,
                'updated_at' => $request->filled('updated_at')
                    ? Carbon::parse($request->updated_at)->format('Y-m-d H:i:s')
                    : $now,
            ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Call tracker synchronized successfully.',
                'error_msg' => null,
                'data' => [
                    'sno' => $callId,
                    'contact_id' => $contactId,
                    'external_uuid' => $request->external_uuid,
                    'entity_id' => $entityId,
                    'cug_id' => $cugId,
                    'cug_assignment_id' => $cugAssignmentId,
                    'branch_id' => (int) $resolvedBranchId,
                ],
            ], 200);
        } catch (\Throwable $e) {
            DB::rollBack();

            /*
             * A duplicate-key race on external_uuid is treated as an
             * already-successful synchronization when the row now exists.
             */
            if (str_contains(strtolower($e->getMessage()), 'duplicate') ||
                str_contains(strtolower($e->getMessage()), 'unique')) {
                $existing = CallTrackerModel::where('external_uuid', $request->external_uuid)->first();

                if ($existing) {
                    return response()->json([
                        'status' => 200,
                        'message' => 'Call tracker already synchronized.',
                        'error_msg' => null,
                        'data' => [
                            'sno' => $existing->sno,
                            'external_uuid' => $existing->external_uuid,
                            'entity_id' => $existing->entity_id,
                            'duplicated' => true,
                        ],
                    ], 200);
                }
            }

            Log::error('Internal EGC call tracker synchronization failed', [
                'external_uuid' => $request->external_uuid,
                'source' => $request->source,
                'entity_id' => $entityId,
                'exception' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Unable to synchronize call tracker.',
                'error_msg' => config('app.debug') ? $e->getMessage() : 'Internal synchronization error.',
                'data' => null,
            ], 500);
        }
    }


    /**
     * Receive the entity ERP heartbeat and update the main ERP's
     * current CUG assignment.
     */
    public function alive(Request $request)
    {
        $rawBody = $request->getContent();

        if (!$this->isValidSignature($request, $rawBody)) {
            return response()->json([
                'status' => 401,
                'message' => 'Unauthorized synchronization request.',
                'error_msg' => 'Invalid EGC synchronization signature.',
                'data' => null,
            ], 401);
        }

        $validator = Validator::make($request->all(), [
            'external_uuid' => 'required|string|max:64',
            'source' => 'required|string|max:100',
            'source_entity_id' => 'required|integer|min:0',
            'staff_phone_no' => 'required|string|max:100',
            'is_alive' => 'required|integer|in:0,1',
            'checked_at' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null,
            ], 422);
        }

        DB::beginTransaction();

        try {
            $staffPhoneCandidates = $this->phoneCandidates($request->staff_phone_no);

            $cug = DB::table('egc_cug_numbers')
                ->whereIn('cug_number', $staffPhoneCandidates)
                ->where('status', 1)
                ->orderByDesc('sno')
                ->lockForUpdate()
                ->first();

            if (!$cug) {
                DB::rollBack();

                return response()->json([
                    'status' => 404,
                    'message' => 'EGC CUG record not found.',
                    'error_msg' => 'No active EGC CUG record matched the staff phone number.',
                    'data' => null,
                ], 404);
            }

            $assignment = DB::table('egc_cug_assignments')
                ->where('cug_id', $cug->sno)
                ->where('is_current', 1)
                ->where('status', 0)
                ->orderByDesc('sno')
                ->lockForUpdate()
                ->first();

            if (!$assignment) {
                $assignment = DB::table('egc_cug_assignments')
                    ->where('cug_id', $cug->sno)
                    ->where('status', 0)
                    ->orderByDesc('is_current')
                    ->orderByDesc('start_date')
                    ->orderByDesc('sno')
                    ->lockForUpdate()
                    ->first();
            }

            if (!$assignment) {
                DB::rollBack();

                return response()->json([
                    'status' => 404,
                    'message' => 'EGC CUG assignment not found.',
                    'error_msg' => 'No active assignment matched the CUG record.',
                    'data' => null,
                ], 404);
            }

            $checkedAt = $request->filled('checked_at')
                ? Carbon::parse($request->checked_at)
                    ->timezone('Asia/Kolkata')
                    ->format('Y-m-d H:i:s')
                : Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');

            DB::table('egc_cug_assignments')
                ->where('sno', $assignment->sno)
                ->update([
                    'live_status' => (int) $request->is_alive,
                    'last_checking' => $checkedAt,
                ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Application heartbeat synchronized successfully.',
                'error_msg' => null,
                'data' => [
                    'cug_id' => (int) $cug->sno,
                    'cug_assignment_id' => (int) $assignment->sno,
                    'staff_id' => (int) ($assignment->staff_id ?? 0),
                    'live_status' => (int) $request->is_alive,
                    'last_checking' => $checkedAt,
                ],
            ], 200);
        } catch (\Throwable $e) {
            DB::rollBack();

            Log::error('Internal EGC application heartbeat synchronization failed', [
                'external_uuid' => $request->external_uuid,
                'source' => $request->source,
                'staff_phone_no' => $request->staff_phone_no,
                'exception' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Unable to synchronize application heartbeat.',
                'error_msg' => config('app.debug')
                    ? $e->getMessage()
                    : 'Internal heartbeat synchronization error.',
                'data' => null,
            ], 500);
        }
    }

    private function isValidSignature(Request $request, string $rawBody): bool
    {
        $secret = (string) env('EGC_SYNC_SECRET', 'EGCREP@2030LOGCALLCODESECRETHOOK657');

        if ($secret === '') {
            return false;
        }

        $timestamp = (string) $request->header('X-EGC-Timestamp');
        $providedSignature = (string) $request->header('X-EGC-Signature');

        if ($timestamp === '' || $providedSignature === '' || !ctype_digit($timestamp)) {
            return false;
        }

        /*
         * Five-minute replay window.
         */
        if (abs(time() - (int) $timestamp) > 300) {
            return false;
        }

        $expected = hash_hmac(
            'sha256',
            $timestamp . '.' . $rawBody,
            $secret
        );

        return hash_equals($expected, $providedSignature);
    }

    private function normalizePhone(string $phone): string
    {
        return preg_replace('/\D+/', '', str_replace('+91', '', trim($phone)));
    }

    private function phoneCandidates(string $phone): array
    {
        $normalized = $this->normalizePhone($phone);

        return array_values(array_unique(array_filter([
            trim($phone),
            $normalized,
            $normalized ? '+91' . $normalized : null,
            $normalized ? '0' . $normalized : null,
        ])));
    }
}
