<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LocationModel;
use App\Models\BuildingModel;
use App\Models\BuildingFloorModel;
use App\Models\LessorModel;
use App\Models\BuildingAgreementModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Models\BuildingDocumentModel;


class ManageBuilding extends Controller
{

public function index(Request $request)
{
    try {

            $page       = $request->page ?? 1;
            $perPage    = $request->per_page ?? 10;
            $search     = trim($request->search);
            $status     = $request->status;
            $ownership  = $request->ownership_type;
            $location   = $request->location_id;


        if ($request->ajax()) {

            

            /*
            |--------------------------------------------------------------------------
            | Base Query
            |--------------------------------------------------------------------------
            */

            $query = BuildingModel::select(
                        'egc_buildings.*',
                        'egc_locations.location_code',
                        'egc_locations.area as location_name',
                        'egc_lessor.lessor_name'
                    )
                    ->leftJoin(
                        'egc_locations',
                        'egc_locations.sno',
                        '=',
                        'egc_buildings.location_id'
                    )
                    ->leftJoin(
                        'egc_lessor',
                        'egc_lessor.sno',
                        '=',
                        'egc_buildings.lessor_id'
                    );

                            /*
            |--------------------------------------------------------------------------
            | Search Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($search)) {

                $query->where(function ($q) use ($search) {

                    $q->where('egc_buildings.building_name', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.building_code', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.door_no', 'LIKE', "%{$search}%")
                      ->orWhere('egc_buildings.street', 'LIKE', "%{$search}%")
                      ->orWhere('egc_locations.location_code', 'LIKE', "%{$search}%")
                      ->orWhere('egc_locations.area', 'LIKE', "%{$search}%")
                      ->orWhere('egc_lessor.lessor_name', 'LIKE', "%{$search}%");

                });

            }

            /*
            |--------------------------------------------------------------------------
            | Status Filter
            |--------------------------------------------------------------------------
            */

            if ($status !== null && $status !== '') {

                $query->where('egc_buildings.status', $status);

            }

            /*
            |--------------------------------------------------------------------------
            | Ownership Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($ownership)) {

                $query->where(
                    'egc_buildings.ownership_type',
                    $ownership
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Location Filter
            |--------------------------------------------------------------------------
            */

            if (!empty($location)) {

                $query->where(
                    'egc_buildings.location_id',
                    $location
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Sorting
            |--------------------------------------------------------------------------
            */

            $query->orderBy(
                'egc_buildings.sno',
                'DESC'
            );
                        /*
            |--------------------------------------------------------------------------
            | Dashboard Counts
            |--------------------------------------------------------------------------
            */

            $dashboard = [
                'total' => BuildingModel::count(),
                'active' => BuildingModel::where('status', 0)->count(),
                'inactive' => BuildingModel::where('status', 1)->count(),
                'owned' => BuildingModel::where('ownership_type', 1)->count(),
                'rented' => BuildingModel::where('ownership_type', 2)->count(),
            ];

            /*
            |--------------------------------------------------------------------------
            | Pagination
            |--------------------------------------------------------------------------
            */

            $totalRecords = (clone $query)->count();

            $buildings = $query
                            ->skip(($page - 1) * $perPage)
                            ->take($perPage)
                            ->get();

            /*
            |--------------------------------------------------------------------------
            | Format Table Data
            |--------------------------------------------------------------------------
            */

            $data = [];

            foreach ($buildings as $building) {

                $data[] = [

                    'id'                => $building->sno,

                    'building_code'     => $building->building_code,

                    'building_name'     => $building->building_name,

                    'location'          => $building->location_name,

                    'location_code'     => $building->location_code,

                    'lessor_name'       => $building->lessor_name,

                    'ownership_type'    => $building->ownership_type,

                    'door_no'           => $building->door_no,

                    'street'            => $building->street,

                    'status'            => $building->status,

                    'created_at'        => optional($building->created_at)
                                            ->format('d-m-Y'),

                ];

            }
                    /*
            |--------------------------------------------------------------------------
            | Return AJAX Response
            |--------------------------------------------------------------------------
            */

            return response()->json([

                'status' => true,

                'message' => 'Building list fetched successfully.',

                'dashboard' => $dashboard,

                'pagination' => [

                    'current_page' => (int)$page,

                    'per_page' => (int)$perPage,

                    'total' => $totalRecords,

                    'last_page' => ceil($totalRecords / $perPage),

                ],

                'data' => $data

            ]);

        }

        
        $locations = LocationModel::where('status', 0)
                        ->orderBy('area')
                        ->get([
                            'sno',
                            'location_code',
                            'area'
                        ]);
        $lessors = LessorModel::where('status', 0)
                        ->orderBy('lessor_name')
                        ->get([
                            'sno',
                            'lessor_name'
                        ]);

        $ownershipTypes = [
            'Owned',
            'Rented',
            'Lease',
            'Shared'
        ];


        $dashboard = [
            'total' => BuildingModel::count(),
            'active' => BuildingModel::where('status',0)->count(),
            'inactive' => BuildingModel::where('status',1)->count(),
            'owned' => BuildingModel::where('ownership_type',1)->count(),
            'rented' => BuildingModel::where('ownership_type',2)->count(),
        ];


        $entity_list = ManageEntityModel::where('status', 0)->get();
        return view('content.corporate_admin.manage_maintanence.manage_building.building_set',[
            'page_title'       => 'Manage Building',
            'location_list'        => $locations,
            'entity_list'        => $entity_list,
            'lessors'          => $lessors,
            'ownershipTypes'   => $ownershipTypes,
            'dashboard'        => $dashboard,
            'lessor_list'        => $lessors,
        ]);

    }

    catch (\Exception $e) {
        if(request()->ajax()){

            return response()->json([

                'status' => false,

                'message' => 'Something went wrong.' . $e->getMessage(),

            ],500);

        }

        return back()->with('error','Something went wrong.');

    }

}



public function SaveBuildingAgreement(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
            'building_id' => [
                'required',
                'integer',
                'exists:egc_buildings,sno',
            ],

            'floor_id' => [
                'required',
                'integer',
            ],

            'agreement_name' => [
                'required',
                'string',
                'max:255',
            ],

            'agreement_start_date' => [
                'required',
                'date',
            ],

            'agreement_end_date' => [
                'required',
                'date',
                'after_or_equal:agreement_start_date',
            ],

            'renewal_date' => [
                'nullable',
                'date',
            ],

            'agreement_amount' => [
                'required',
                'numeric',
                'min:0',
            ],

            'agreement_status' => [
                'required',
                'string',
                'max:100',
            ],

            'remarks' => [
                'nullable',
                'string',
            ],
          
            'renewal_document' => [
                'nullable',
                'array',
                'max:10',
            ],

            'renewal_document.*' => [
                'file',
                'mimes:pdf,doc,docx,jpg,jpeg,png',
                'max:5120',
            ],
        ],
        [
            'building_id.required' => 'Building is required.',
            'building_id.exists' => 'Selected building does not exist.',

            'floor_id.required' => 'Floor is required.',

            'agreement_name.required' => 'Agreement name is required.',
            'agreement_name.max' => 'Agreement name may not exceed 255 characters.',

            'agreement_start_date.required' => 'Agreement start date is required.',
            'agreement_start_date.date' => 'Enter a valid agreement start date.',

            'agreement_end_date.required' => 'Agreement end date is required.',
            'agreement_end_date.after_or_equal' =>
                'Agreement end date must be greater than or equal to start date.',

            'renewal_date.date' => 'Enter a valid renewal date.',

            'agreement_amount.required' => 'Agreement amount is required.',
            'agreement_amount.numeric' => 'Agreement amount must be a number.',
            'agreement_amount.min' => 'Agreement amount cannot be negative.',

            'agreement_status.required' => 'Agreement status is required.',

            'renewal_document.array' => 'Invalid document upload.',
            'renewal_document.max' => 'You can upload a maximum of 10 documents.',

            'renewal_document.*.file' => 'Invalid document.',
            'renewal_document.*.mimes' =>'Documents must be PDF, DOC, DOCX, JPG, JPEG or PNG.',
            'renewal_document.*.max' =>'Each document may not exceed 5 MB.',
        ]
    );

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'errors' => $validator->errors(),
        ], 422);
    }

    DB::beginTransaction();

    $uploadedFiles = [];
    $user_id=$request->user()->user_id;

    try {

        $exists = BuildingAgreementModel::where('building_id',$request->building_id)
            ->where('floor_id', $request->floor_id)
            ->where('agreement_start_date', $request->agreement_start_date)
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            DB::rollBack();
            return response()->json([
                'status' => 409,
                'message' =>
                    'An agreement already exists for this floor with the same start date.',
            ], 409);
        }
      
        $year = date('Y');
        $lastAgreement = BuildingAgreementModel::where(
                'agreement_no',
                'like',
                'AGREEMENT-' . $year . '-%'
            )
            ->orderByDesc('sno')
            ->first();

        if ($lastAgreement && !empty($lastAgreement->agreement_no)) {
            $lastNumber = (int) substr($lastAgreement->agreement_no,-4);
            $runningNumber = $lastNumber + 1;
        } else {
            $runningNumber = 1;
        }
        $agreementNo ='AGREEMENT-' . $year . '-' . str_pad($runningNumber, 4,'0',STR_PAD_LEFT );

        $agreement = new BuildingAgreementModel();
        $agreement->building_id =$request->building_id;
        $agreement->floor_id = $request->floor_id;
        $agreement->agreement_name = trim($request->agreement_name);
        $agreement->agreement_no = $agreementNo;
        $agreement->agreement_start_date = $request->agreement_start_date;
        $agreement->agreement_end_date =$request->agreement_end_date;
        $agreement->renewal_date = $request->renewal_date ?: null;
        $agreement->agreement_amount = $request->agreement_amount;
        $agreement->agreement_status =$request->agreement_status;
        $agreement->remarks =$request->remarks ? trim($request->remarks) : null;
        $agreement->created_by = $user_id?? 0;
        $agreement->updated_by =$user_id ?? 0;
        $agreement->status = 0;
        $agreement->save();


    
        if ($request->hasFile('renewal_document')) {
            $uploadPath = public_path('uploads/building/agreements');
            if (!File::exists($uploadPath)) {
                File::makeDirectory($uploadPath,0755,true);
            }

            foreach ($request->file('renewal_document')as $file) {

                if (!$file->isValid()) {
                    throw new \Exception('One of the uploaded documents is invalid.');
                }
        
                $extension =strtolower($file->getClientOriginalExtension());
                $originalName =pathinfo($file->getClientOriginalName(),PATHINFO_FILENAME);

                $safeName = Str::slug($originalName);
                if ($safeName === '') {
                    $safeName = 'document';
                }
                $fileName =$safeName .'_' .Str::uuid() .'.' .$extension;
                $file->move($uploadPath,$fileName);

                $uploadedFiles[] = $uploadPath . DIRECTORY_SEPARATOR . $fileName;
                $document = new BuildingDocumentModel();
                $document->building_id = $request->building_id;
                $document->agreement_id =$agreement->sno;
                $document->document_name = $file->getClientOriginalName();
                $document->document_path ='uploads/building/agreements/' . $fileName;
                $document->document_type =$file->getClientMimeType();
                $document->created_by =$user_id ?? 0;
                $document->status = 0;
                $document->save();
            }
        }


        DB::commit();

        return response()->json([
            'status' => 200,
            'message' => 'Agreement added successfully.',
            'agreement_id' => $agreement->sno,
            'agreement_no' => $agreement->agreement_no,
        ], 200);


    } catch (\Throwable $e) {

        DB::rollBack();

        foreach ($uploadedFiles as $uploadedFile) {
            if (File::exists($uploadedFile)) {
                File::delete($uploadedFile);
            }
        }
        Log::error(
            'Save Building Agreement Failed',
            [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'building_id' =>$request->building_id,
                'floor_id' => $request->floor_id,
                'user_id' => $user_id ?? 0,
            ]
        );

        return response()->json([
            'status' => 500,
            'message' =>
                'Unable to save agreement. Please try again.',
        ], 500);
    }
}

//     public function SaveAgreementRenewal(Request $request)
// {
//     $validator = Validator::make($request->all(), [

//         'building_id'          => 'required|exists:egc_buildings,sno',
//         'renewal_title'        => 'required|max:255',

//         'renewal_start_date'   => 'required|date',
//         'renewal_end_date'     => 'required|date|after_or_equal:renewal_start_date',
//         'renewal_due_date'     => 'required|date',

//         'renewal_amount'       => 'required|numeric|min:0',

//         'renewal_document'     => 'nullable|mimes:pdf,doc,docx,jpg,jpeg,png|max:5120',

//     ], [

//         'building_id.required'        => 'Building is required.',
//         'renewal_title.required'      => 'Renewal title is required.',
//         'renewal_start_date.required' => 'Renewal start date is required.',
//         'renewal_end_date.required'   => 'Renewal end date is required.',
//         'renewal_due_date.required'   => 'Renewal due date is required.',
//         'renewal_amount.required'     => 'Renewal amount is required.',

//     ]);

//     if ($validator->fails()) {

//         return response()->json([
//             'status' => 422,
//             'errors' => $validator->errors()
//         ]);

//     }

//     try {

//         DB::beginTransaction();

//         $exists = BuildingAgreementModel::where('building_id',$request->building_id)
//                     ->where('floor_id',$request->floor_id)
//                     ->where('renewal_start_date',$request->renewal_start_date)
//                     ->where('status','!=',2)
//                     ->exists();

//         if($exists){
//             return response()->json([
//                 'status'  => 409,
//                 'message' => 'Renewal already exists.'
//             ]);
//         }

//         $last = BuildingAgreementModel::orderBy('sno','DESC')->first();

//         if($last){
//             $lastNo = intval(substr($last->renewal_no,-4));
//             $running = $lastNo + 1;
//         }else{
//             $running = 1;
//         }
//         $renewalNo = 'AGREEMENT-'.date('Y').'-'.str_pad($running,4,'0',STR_PAD_LEFT);
//         $document = null;
//         if($request->hasFile('renewal_document')){
//             $file = $request->file('renewal_document');
//             $document = time().'_'.$file->getClientOriginalName();
//             $file->move(public_path('uploads/building/renewals'),$document);
//         }

//         $renewal = new BuildingAgreementModel();
//         $renewal->building_id                  = $request->building_id;
//         $renewal->agreement_id                 = $request->agreement_id;
//         $renewal->floor_id                     = $request->floor_id;
//         $renewal->renewal_no                  = $renewalNo;
//         $renewal->renewal_title                = trim($request->renewal_title);

//         $renewal->renewal_start_date           = $request->renewal_start_date;
//         $renewal->renewal_end_date             = $request->renewal_end_date;
//         $renewal->renewal_due_date             = $request->renewal_due_date;

//         $renewal->renewal_amount               = $request->renewal_amount;
//         $renewal->rent_increment_percentage    = $request->rent_increment_percentage;
//         $renewal->security_deposit             = $request->security_deposit;


//         $renewal->lessor_id                    = $request->lessor_id;
//         $renewal->contact_person               = $request->contact_person;
//         $renewal->contact_no                   = $request->contact_no;
//         $renewal->email                        = $request->email;

//         $renewal->renewal_document             = $document;

//         $renewal->remarks                      = $request->remarks;

//         $renewal->renewal_status               = 'Pending';

//         $renewal->created_by                   = session('user_id') ?? 0;
//         $renewal->updated_by                   = session('user_id') ?? 0;

//         $renewal->status                       = 0;

//         $renewal->save();

//         DB::commit();

//         return response()->json([
//             'status'  => 200,
//             'message' => 'Agreement renewal added successfully.'
//         ]);

//     }
//     catch(\Exception $e){

//         DB::rollBack();

//         \Log::error(__METHOD__,[

//             'message'=>$e->getMessage(),
//             'line'=>$e->getLine(),
//             'file'=>$e->getFile()

//         ]);

//         return response()->json([

//             'status'  => 500,
//             'message' => 'Something went wrong.',
//             'error'   => $e->getMessage()

//         ]);

//     }
// }

        public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'building_name'      => 'required|max:200',
            'location_id'        => 'required',
            'ownership_type'     => 'required',
            'door_no'            => 'required|max:100',
            'street'             => 'required|max:255',
            'total_floors'       => 'required|numeric|min:1',
            'builtup_area'       => 'required|numeric|min:1',
            'builtup_area_unit'  => 'required',

        ], [

            'building_name.required'     => 'Building Name is required.',
            'location_id.required'       => 'Location is required.',
            'ownership_type.required'    => 'Ownership is required.',
            'door_no.required'           => 'Door No is required.',
            'street.required'            => 'Street is required.',
            'total_floors.required'      => 'Total Floors is required.',
            'builtup_area.required'      => 'Built-up Area is required.',
            'builtup_area_unit.required' => 'Area Unit is required.',

        ]);

        if ($validator->fails()) {

            return response()->json([
                'status'  => 422,
                'errors'  => $validator->errors()
            ]);

        }

        try {

            DB::beginTransaction();

            /*
            |--------------------------------------------------------------------------
            | Duplicate Check
            |--------------------------------------------------------------------------
            */

            $exists = BuildingModel::where('building_name', $request->building_name)
                        ->where('location_id', $request->location_id)
                        ->where('status','!=',2)
                        ->exists();

            if($exists){

                return response()->json([
                    'status'=>409,
                    'message'=>'Building already exists.'
                ]);

            }

            /*
            |--------------------------------------------------------------------------
            | Generate Building Code
            |--------------------------------------------------------------------------
            */

            $location = LocationModel::find($request->location_id);

            $prefix = 'BLD';

            if($location){

                $locationCode = $location->location_code;

                $last = BuildingModel::where('location_id',$request->location_id)
                            ->orderBy('sno','DESC')
                            ->first();

                if($last){

                    $lastCode = explode('-',$last->building_code);

                    $running = intval(end($lastCode)) + 1;

                }else{

                    $running = 1;

                }

                $buildingCode = $prefix.'-'.$locationCode.'-'.str_pad($running,4,'0',STR_PAD_LEFT);

            }else{

                $buildingCode = 'BLD-0001';

            }

            /*
            |--------------------------------------------------------------------------
            | Save Building
            |--------------------------------------------------------------------------
            */

            $building = new BuildingModel();

            $building->building_code       = $buildingCode;
            $building->building_name       = $request->building_name;
            $building->location_id         = $request->location_id;
            $building->ownership_type      = $request->ownership_type;
            $building->lessor_id           = $request->lessor_id;
            $building->door_no             = $request->door_no;
            $building->street              = $request->street;
            $building->landmark            = $request->landmark;
            $building->google_map_link     = $request->google_map_link;
            $building->address             = trim(
                                                $request->door_no.', '.
                                                $request->street.', '.
                                                $request->landmark
                                            );
            $building->total_floors        = $request->total_floors;
            $building->builtup_area        = $request->builtup_area;
            $building->builtup_area_unit   = $request->builtup_area_unit;
            $building->latitude            = $request->latitude;
            $building->longitude           = $request->longitude;
            $building->remarks             = $request->remarks;
            $building->created_by          = session('user_id') ?? 0;
            $building->updated_by          = session('user_id') ?? 0;
            $building->status              = 0;

            $building->save();

            DB::commit();

            return response()->json([

                'status'  => 200,
                'message' => 'Building added successfully.'

            ]);

        }
        catch(\Exception $e){

            DB::rollBack();

            return response()->json([

                'status'  => 500,
                'message' => 'Something went wrong.',
                'error'   => $e->getMessage()

            ]);

        }

    }


    public function Update(Request $request)
{
    $validator = Validator::make($request->all(), [

        'building_id'        => 'required|exists:egc_buildings,sno',
        'building_name'      => 'required|max:200',
        'location_id'        => 'required',
        'ownership_type'     => 'required',
        'door_no'            => 'required|max:100',
        'street'             => 'required|max:255',
        'total_floors'       => 'required|numeric|min:1',
        'builtup_area'       => 'required|numeric|min:1',
        'builtup_area_unit'  => 'required',

    ], [

        'building_id.required'        => 'Building not found.',
        'building_id.exists'          => 'Invalid Building.',
        'building_name.required'      => 'Building Name is required.',
        'location_id.required'        => 'Location is required.',
        'ownership_type.required'     => 'Ownership is required.',
        'door_no.required'            => 'Door No is required.',
        'street.required'             => 'Street is required.',
        'total_floors.required'       => 'Total Floors is required.',
        'builtup_area.required'       => 'Built-up Area is required.',
        'builtup_area_unit.required'  => 'Area Unit is required.',

    ]);

    if ($validator->fails()) {

        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ]);

    }

    try {

        DB::beginTransaction();

        /*
        |--------------------------------------------------------------------------
        | Find Building
        |--------------------------------------------------------------------------
        */

        $building = BuildingModel::find($request->building_id);

        if (!$building) {

            return response()->json([
                'status'  => 404,
                'message' => 'Building not found.'
            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Duplicate Check
        |--------------------------------------------------------------------------
        */

        $exists = BuildingModel::where('building_name', $request->building_name)
                    ->where('location_id', $request->location_id)
                    ->where('status', '!=', 2)
                    ->where('sno', '!=', $request->building_id)
                    ->exists();

        if ($exists) {

            return response()->json([
                'status'  => 409,
                'message' => 'Building already exists.'
            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Update Building
        |--------------------------------------------------------------------------
        */

        $building->building_name      = $request->building_name;
        $building->location_id        = $request->location_id;
        $building->ownership_type     = $request->ownership_type;
        $building->lessor_id          = $request->ownership_type == 2 ? $request->lessor_id : null;

        $building->door_no            = $request->door_no;
        $building->street             = $request->street;
        $building->landmark           = $request->landmark;
        $building->google_map_link    = $request->google_map_link;

        $building->address = trim(implode(', ', array_filter([
            $request->door_no,
            $request->street,
            $request->landmark
        ])));

        $building->total_floors       = $request->total_floors;
        $building->builtup_area       = $request->builtup_area;
        $building->builtup_area_unit  = $request->builtup_area_unit;

        $building->latitude           = $request->latitude;
        $building->longitude          = $request->longitude;

        $building->remarks            = $request->remarks;

        $building->updated_by         = session('user_id') ?? 0;
        $building->updated_at         = now();

        $building->save();

        DB::commit();

        return response()->json([

            'status'  => 200,
            'message' => 'Building updated successfully.'

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        \Log::error('Building Update Error : ' . $e->getMessage());

        return response()->json([

            'status'  => 500,
            'message' => 'Something went wrong.',
            'error'   => $e->getMessage()

        ]);

    }
}

  public function SaveFloor(Request $request)
{
    $validator = Validator::make($request->all(), [

        'building_id'      => 'required|exists:egc_buildings,sno',
        'floor_no'         => 'required|max:50',
        'floor_name'       => 'nullable|max:150',
        'purpose'          => 'required|max:100',
        'entity_id'        => 'required',
        // 'branch_id'        => 'required',
        'floor_area'       => 'nullable|numeric|min:0',
        'area_unit'        => 'nullable|max:20',
        'occupancy_status' => 'nullable',
        'workstations'     => 'nullable|integer|min:0',
        'meeting_rooms'    => 'nullable|integer|min:0',
        'cabins'           => 'nullable|integer|min:0',
        'remarks'          => 'nullable|max:1000',

    ], [

        'building_id.required' => 'Building is required.',
        'building_id.exists'   => 'Invalid Building.',
        'floor_no.required'    => 'Floor No is required.',
        'purpose.required'     => 'Purpose is required.',
        'entity_id.required'   => 'Entity is required.',
        'branch_id.required'   => 'Branch is required.',

    ]);

    if ($validator->fails()) {

        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ]);

    }

    try {

        DB::beginTransaction();

        /*
        |--------------------------------------------------------------------------
        | Duplicate Check
        |--------------------------------------------------------------------------
        */

        $exists = BuildingFloorModel::where('building_id', $request->building_id)
                    ->where('floor_no', trim($request->floor_no))
                    ->where('status', '!=', 2)
                    ->exists();

        if ($exists) {

            return response()->json([
                'status'  => 409,
                'message' => 'Floor already exists for this building.'
            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Save Floor
        |--------------------------------------------------------------------------
        */

        $floor = new BuildingFloorModel();

        $floor->building_id       = $request->building_id;
        $floor->floor_no          = trim($request->floor_no);
        $floor->floor_name        = trim($request->floor_name);
        $floor->purpose           = $request->purpose;
        $floor->entity_id         = $request->entity_id;
        $floor->branch_id         = $request->branch_id;
        $floor->floor_area        = $request->floor_area;
        $floor->area_unit         = $request->area_unit;
        $floor->occupancy_status  = $request->occupancy_status;
        $floor->workstations      = $request->workstations ?? 0;
        $floor->meeting_rooms     = $request->meeting_rooms ?? 0;
        $floor->cabins            = $request->cabins ?? 0;
        $floor->remarks           = trim($request->remarks);

        $floor->created_by        = session('user_id') ?? 0;
        $floor->updated_by        = session('user_id') ?? 0;
        $floor->status            = 0;

        $floor->save();

        DB::commit();

        return response()->json([

            'status'  => 200,
            'message' => 'Floor added successfully.'

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        Log::error(__METHOD__, [

            'message' => $e->getMessage(),
            'line'    => $e->getLine(),
            'file'    => $e->getFile(),

        ]);

        return response()->json([

            'status'  => 500,
            'message' => 'Something went wrong.',
            'error'   => $e->getMessage()

        ]);

    }
}


    public function RenewalList($buildingId)
{
    try {

        $renewals = BuildingRenewal::select(
                        'egc_building_renewal.*',
                        'egc_building_floor.floor_no'
                    )
                    ->leftJoin(
                        'egc_building_floor',
                        'egc_building_floor.sno',
                        '=',
                        'egc_building_renewal.floor_id'
                    )
                    ->where(
                        'egc_building_renewal.building_id',
                        $buildingId
                    )
                    ->orderByDesc('egc_building_renewal.sno')
                    ->get();

        $data = [];

        foreach ($renewals as $row) {

            $data[] = [

                'id'             => $row->sno,

                'floor'          => $row->floor_no,

                'agreement_name' => $row->agreement_name,

                'start_date'     => optional($row->start_date)->format('d-M-Y'),

                'end_date'       => optional($row->end_date)->format('d-M-Y'),

                'renewal_date'   => optional($row->renewal_date)->format('d-M-Y'),

                'amount'         => number_format($row->amount,2),

                'status'         => $row->status

            ];

        }

        return response()->json([

            'status'=>true,

            'data'=>$data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status'=>false,

            'message'=>'Unable to load renewals.'

        ]);

    }
}




public function AgreementList($buildingId)
{
    try {

        $agreements = DB::table('egc_building_agreements as ba')
            ->leftJoin(
                'egc_building_floors as bf',
                'bf.sno',
                '=',
                'ba.floor_id'
            )
            ->select(
                'ba.sno',
                'ba.agreement_name',
                'ba.agreement_no',
                'ba.agreement_start_date',
                'ba.agreement_end_date',
                'ba.renewal_date',
                'ba.agreement_amount',
                'ba.agreement_status',
                'bf.floor_no'
            )
            ->where('ba.building_id', $buildingId)
            ->where('ba.status', 0)
            ->orderByDesc('ba.sno')
            ->get();

        $data = [];

        foreach ($agreements as $row) {

            $daysRemaining = null;

            if (!empty($row->agreement_end_date)) {

                $daysRemaining = now()->diffInDays(
                    $row->agreement_end_date,
                    false
                );

            }

            $data[] = [

                'id' => $row->sno,

                'floor' => $row->floor_no ?? '-',

                'agreement_name' => $row->agreement_name,

                'agreement_no' => $row->agreement_no,

                'start_date' => $row->agreement_start_date
                    ? date('d-M-Y', strtotime($row->agreement_start_date))
                    : '-',

                'end_date' => $row->agreement_end_date
                    ? date('d-M-Y', strtotime($row->agreement_end_date))
                    : '-',

                'renewal_date' => $row->renewal_date
                    ? date('d-M-Y', strtotime($row->renewal_date))
                    : '-',

                'amount' => number_format($row->agreement_amount,2),

                'status' => $row->agreement_status,

                'days_remaining' => $daysRemaining

            ];

        }

        return response()->json([

            'status' => true,

            'count' => count($data),

            'data' => $data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ]);

    }
}


public function BuildingDetailsById(Request $request)
{
    try {

        $id = $request->building_id;

        if (empty($id)) {
            return response()->json([
                'status' => false,
                'message' => 'Building id is required.'
            ]);
        }

        $building = BuildingModel::select(
                'egc_buildings.*',
                'egc_locations.location_code',
                'egc_locations.area as location_name',
                'egc_lessor.lessor_name',
                'egc_lessor.lessor_code',
                'egc_lessor.mobile_no',
                'egc_lessor.contact_person'
            )
            ->leftJoin('egc_locations','egc_locations.sno','=','egc_buildings.location_id')
            ->leftJoin('egc_lessor','egc_lessor.sno','=','egc_buildings.lessor_id')
            ->where('egc_buildings.sno',$id)
            ->where('egc_buildings.status','!=',2)
            ->first();

        if(!$building){
            return response()->json([
                'status'=>false,
                'message'=>'Building not found.'
            ]);
        }

        return response()->json([
            'status'=>true,
            'data'=>[

                'sno'               => $building->sno,
                'building_code'     => $building->building_code,
                'building_name'     => $building->building_name,

                'location_id'       => $building->location_id,
                'location_name'     => $building->location_name,
                'location_code'     => $building->location_code,

                'ownership_type'    => $building->ownership_type,

                'lessor_id'         => $building->lessor_id,
                'lessor_name'       => $building->lessor_name,
                'lessor_code'       => $building->lessor_code,
                'lessor_mobile'     => $building->mobile_no,
                'contact_person'    => $building->contact_person,

                'door_no'           => $building->door_no,
                'street'            => $building->street,
                'landmark'          => $building->landmark,
                'address'           => $building->address,
                'google_map_link'   => $building->google_map_link,

                'total_floors'      => $building->total_floors,
                'builtup_area'      => $building->builtup_area,
                'builtup_area_unit' => $building->builtup_area_unit,

                'latitude'          => $building->latitude,
                'longitude'         => $building->longitude,

                'remarks'           => $building->remarks,
                'status'            => $building->status,

                'created_at'        => optional($building->created_at)->format('d-m-Y H:i'),
                'updated_at'        => optional($building->updated_at)->format('d-m-Y H:i')
            ]
        ]);

    } catch (\Exception $e) {

        Log::error($e);

        return response()->json([
            'status'=>false,
            'message'=>'Something went wrong.',
            'error'=>$e->getMessage()
        ],500);
    }
}

public function BuildingDetails($id)
{
    try {

        $building = BuildingModel::select(
                'egc_buildings.*',
                'egc_lessor.lessor_name',
                'egc_lessor.lessor_code',
                'egc_lessor.mobile_no as lessor_mobile',
                'egc_lessor.contact_person',
            )
            ->leftJoin('egc_lessor', 'egc_lessor.sno', '=', 'egc_buildings.lessor_id')
            ->where('egc_buildings.sno', $id)
            ->first();
     

        if (!$building) {

            return response()->json([
                'status'  => false,
                'message' => 'Building not found.'
            ]);

        }

        /*
        |--------------------------------------------------------------------------
        | Statistics
        |--------------------------------------------------------------------------
        */

        $totalFloors = DB::table('egc_building_floors')
                        ->where('building_id', $id)
                        ->count();

        $occupiedFloors = DB::table('egc_building_floors')
                        ->where('building_id', $id)
                        ->where('occupancy_status', 1)
                        ->count();

        /*
        |--------------------------------------------------------------------------
        | Amenities
        |--------------------------------------------------------------------------
        */

        $amenities = DB::table('egc_building_amenities')
                        ->where('building_id', $id)
                        ->pluck('amenity_name')
                        ->toArray();

        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        $data = [

            'id' => $building->sno,

            'building_name' => $building->building_name,

            'building_code' => $building->building_code,

            'ownership_type' => $building->ownership_type,

            'status' => $building->status,

            'address' => trim($building->address),

            'location_name' => $building->city,

            'builtup_area' => round($building->builtup_area,1),

            'area_unit' => $building->builtup_area_unit,

            'entity_name' => '',

            'branch_name' => '',

            'lessor_name' => $building->lessor_name,

            'lessor_code' => $building->lessor_code,

            'lessor_mobile' => $building->lessor_mobile,

            'contact_person' => $building->contact_person,

            'total_floors' => $totalFloors,

            'occupied' => $occupiedFloors,

            'vacant' => $totalFloors - $occupiedFloors,

            'amenities' => $amenities

        ];

        return response()->json([

            'status' => true,

            'data' => $data

        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ], 500);

    }
}



public function FloorList($buildingId)
{
    try {

        $floors = DB::table('egc_building_floors as bf')
            ->select(
                'bf.sno',
                'bf.floor_no',
                'bf.floor_name',
                'egc_entity.entity_name',
                'egc_branch.branch_name',
                'bf.purpose',
                'bf.floor_area',
                'bf.area_unit',
                'bf.occupancy_status',
                'bf.workstations',
                'bf.meeting_rooms',
                'bf.cabins',
                'bf.status',
            )
            ->leftJoin('egc_entity','egc_entity.sno','=','bf.entity_id')
            ->leftJoin('egc_branch','egc_branch.sno','=','bf.branch_id')
            ->where('bf.building_id', $buildingId)
            ->orderBy('bf.sno')
            ->get();

        $data = [];

         $helper = new \App\Helpers\Helpers();
        $general_setting = $helper->general_setting_data();

        foreach ($floors as $floor) {
            

            $data[] = [

                'id' => $floor->sno,
                'floor_no' => $floor->floor_no,
                'floor_name' => $floor->floor_name,
                'purpose' => $floor->purpose,
                'entity' =>  $floor->entity_name ?? $general_setting->title,
                'branch' =>  $floor->branch_name ?? '-',
                'area' => $floor->floor_area,
                'unit' => $floor->area_unit,
                'occupancy_status' => $floor->occupancy_status,
                'workstations' => $floor->workstations,
                'meeting_rooms' => $floor->meeting_rooms,
                'cabins' => $floor->cabins,
                'status' => $floor->status
            ];

        }

        return response()->json([

            'status' => true,

            'count' => count($data),

            'data' => $data

        ]);

    } catch (\Exception $e) {

        return response()->json([

            'status' => false,

            'message' => $e->getMessage()

        ], 500);

    }
}

public function List(Request $request)
  {
   
    $buildings = BuildingModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $buildings
    ], 200);
  }
}   