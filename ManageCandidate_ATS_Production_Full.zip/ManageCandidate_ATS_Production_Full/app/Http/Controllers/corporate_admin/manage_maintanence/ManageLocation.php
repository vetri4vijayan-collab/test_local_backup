<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LocationModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ManageLocation extends Controller
{
  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $Company = LocationModel::where('egc_locations.status', '!=', 2)
      ->select('egc_locations.*','egc_region.region_name','egc_countries.name as country_name', 'egc_states.name as state_name', 'egc_cities.name as city_name')
      ->join('egc_countries', 'egc_locations.country_id', 'egc_countries.id')
      ->join('egc_states', 'egc_locations.state_id', 'egc_states.id')
      ->join('egc_region', 'egc_locations.region_id', 'egc_region.sno')
      ->join('egc_cities', 'egc_locations.city_id', 'egc_cities.id');

    if ($search_filter != '') {
      $Company->where(function ($subquery) use ($search_filter) {
        $subquery->where('egc_locations.location_code', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_locations.area', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_locations.pincode', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_countries.name', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_cities.name', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_states.name', 'LIKE', "%{$search_filter}%");
      });
    }

    $Company = $Company->orderBy('egc_locations.sno', 'asc')->paginate($perpage);

    $helper = new \App\Helpers\Helpers();
   
    if ($request->ajax()) {
      $data = $Company->map(function ($item) use ($helper) {
       
        $building_counts = DB::table('egc_buildings')->where('location_id', $item->sno)->where('status', '!=', 2)->count();
        
        return [
          'sno' => $item->sno,
          'status' => $item->status,
          'location_code' => $item->location_code,
          'building_counts' => $item->building_counts,
          'region_name' => $item->region_name,
          'area' => $item->area,
          'pincode' => $item->pincode,
          'latitude' => $item->latitude,
          'longitude' => $item->longitude,
          'country_name' => $item->country_name,
          'state_name' => $item->state_name,
          'city_name' => $item->city_name,
          'data' => $item,
          'location_encode' => base64_encode($item->sno),
          'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
        ];
      });

      $country_count = LocationModel::where('status', 0)->distinct('country_id')->count();
      $state_count = LocationModel::where('status', 0)->distinct('state_id')->count();
      $city_count = LocationModel::where('status', 0)->distinct('city_id')->count();

      return response()->json([
        'data' => $data,
        'current_page' => $Company->currentPage(),
        'last_page' => $Company->lastPage(),
        'total' => $Company->total(),
        'country_count' => $country_count,
        'state_count' => $state_count,
        'city_count' => $city_count,
      ]);
    }

   
    $country_list = DB::table('egc_countries')->where('status', 0)->orderBy('name', 'ASC')->get();
    $region_list = DB::table('egc_region')->where('status', 0)->orderBy('sno', 'ASC')->get();

    return view('content.corporate_admin.manage_maintanence.manage_location.location_list',[
          'perpage' => $perpage,
          'country_list' => $country_list,
          'region_list' => $region_list,
    ]);
  }

  public function add_location()
  {
    return view('content.corporate_admin.manage_maintanence.manage_location.add_location');
  }
  public function update_location()
  {
    return view('content.corporate_admin.manage_maintanence.manage_location.edit_location');
  }

  public function Add(Request $request)
    {
        DB::beginTransaction();

        try {

            $validator = Validator::make($request->all(), [
                'country_id'     => 'required',
                'state_id'      => 'required',
                'city_id'    => 'required',
                'location_area'     => 'required',
                'location_pincode'       => 'required',
                'region_id'           => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status'  => false,
                    'message' => $validator->errors()->first(),
                    'errors'  => $validator->errors()
                ], 422);
            }

             $user_id = $request->user()->user_id;

            $country_name = DB::table('egc_countries')
                ->where('id', $request->country_id)
                ->value('name');

            $state_name = DB::table('egc_states')
                ->where('id', $request->state_id)
                ->value('name');

            $city_name = DB::table('egc_cities')
                ->where('id', $request->city_id)
                ->value('name');

            $country_sort = DB::table('egc_countries')
                ->where('id', $request->country_id)
                ->value('sortname');

            $state_sort = DB::table('egc_states')
                ->where('id', $request->state_id)
                ->value('state_code');

            if (empty($state_sort)) {
                $state_sort = $this->getCityCode($state_name);
            }

            $city_sort = $this->getCityCode($city_name);

            $prefix = sprintf(
                'LOC-%s-%s-',
                strtoupper($country_sort),
                strtoupper($state_sort),
                // strtoupper($city_sort)
            );

            $lastLocation = LocationModel::where(
                'location_code',
                'like',
                $prefix . '%'
            )
            ->orderByDesc('sno')
            ->first();

        $nextNumber = 1;

        if ($lastLocation) {

            $lastCode = $lastLocation->location_code;

            $parts = explode('-', $lastCode);

            $nextNumber = ((int) end($parts)) + 1;
        }


        $location_code = $prefix .str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

            //  return response()->json([
            //     'status'  => false,
            //     'message' => $request->details ,
            // ], 422);

              $LocationModel = new LocationModel();

              $LocationModel->location_code      = $location_code;
              $LocationModel->country_id      = $request->country_id;
              $LocationModel->state_id      = $request->state_id;
              $LocationModel->city_id       = $request->city_id;
              $LocationModel->area     = $request->location_area;
              $LocationModel->pincode      =$request->location_pincode;
              $LocationModel->region_id        = $request->region_id;
              $LocationModel->latitude     = $request->location_latitude ?? NULL;
              $LocationModel->longitude   = $request->location_longitude ?? NULL;
              $LocationModel->created_by   = $user_id;
              $LocationModel->updated_by   = $user_id;

              $LocationModel->save();

          
            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Loaction Added Successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Unable to save Location.',
                'error' =>  $e->getMessage() 

            ], 500);
        }
    }

  public function Update(Request $request)
{
    DB::beginTransaction();

    try {

        $validator = Validator::make($request->all(), [
            'edit_id'            => 'required',
            'country_id'         => 'required',
            'state_id'           => 'required',
            'city_id'            => 'required',
            'location_area'      => 'required',
            'location_pincode'   => 'required',
            'region_id'          => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => $validator->errors()->first(),
                'errors'  => $validator->errors()
            ], 422);
        }

        $user_id = $request->user()->user_id;

        $location = LocationModel::find($request->edit_id);

        if (!$location) {
            return response()->json([
                'status' => 404,
                'message' => 'Location not found.'
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Regenerate Location Code only if Country/State changed
        |--------------------------------------------------------------------------
        */

        if (
            $location->country_id != $request->country_id ||
            $location->state_id != $request->state_id
        ) {

            $country_name = DB::table('egc_countries')
                ->where('id', $request->country_id)
                ->value('name');

            $state_name = DB::table('egc_states')
                ->where('id', $request->state_id)
                ->value('name');

            $country_sort = DB::table('egc_countries')
                ->where('id', $request->country_id)
                ->value('sortname');

            $state_sort = DB::table('egc_states')
                ->where('id', $request->state_id)
                ->value('state_code');

            if (empty($state_sort)) {
                $state_sort = $this->getCityCode($state_name);
            }

            $prefix = sprintf(
                'LOC-%s-%s-',
                strtoupper($country_sort),
                strtoupper($state_sort)
            );

            $lastLocation = LocationModel::where('location_code', 'like', $prefix . '%')
                ->where('sno', '!=', $location->sno)
                ->orderByDesc('sno')
                ->first();

            $nextNumber = 1;

            if ($lastLocation) {
                $parts = explode('-', $lastLocation->location_code);
                $nextNumber = ((int) end($parts)) + 1;
            }

            $location->location_code = $prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
        }

        /*
        |--------------------------------------------------------------------------
        | Update Details
        |--------------------------------------------------------------------------
        */

        $location->country_id = $request->country_id;
        $location->state_id = $request->state_id;
        $location->city_id = $request->city_id;
        $location->area = $request->location_area;
        $location->pincode = $request->location_pincode;
        $location->region_id = $request->region_id;
        $location->latitude = $request->location_latitude;
        $location->longitude = $request->location_longitude;
        $location->updated_by = $user_id;

        $location->save();

        DB::commit();

        return response()->json([
            'status' => 200,
            'message' => 'Location Updated Successfully.'
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'status' => 500,
            'message' => 'Unable to update Location.',
            'error' => $e->getMessage()
        ], 500);
    }
}
    
public function LoactionDetails(Request $request)
  {
      try {

        $id = $request->id ;

        $item = LocationModel::where('egc_locations.status', '!=', 2)
          ->select('egc_locations.*','egc_region.region_name','egc_countries.name as country_name', 'egc_states.name as state_name', 'egc_cities.name as city_name')
          ->join('egc_countries', 'egc_locations.country_id', 'egc_countries.id')
          ->join('egc_states', 'egc_locations.state_id', 'egc_states.id')
          ->join('egc_region', 'egc_locations.region_id', 'egc_region.sno')
          ->join('egc_cities', 'egc_locations.city_id', 'egc_cities.id')
          ->where('egc_locations.sno',$id)
          ->first();

          $helper = new \App\Helpers\Helpers();
      
          $building_counts = DB::table('egc_buildings')->where('location_id', $item->sno)->where('status', '!=', 2)->count();
          
          $data = [
            'sno' => $item->sno,
            'status' => $item->status,
            'country_id' => $item->country_id,
            'state_id' => $item->state_id,
            'city_id' => $item->city_id,
            'region_id' => $item->region_id,
            'location_code' => $item->location_code,
            'building_counts' => $item->building_counts,
            'region_name' => $item->region_name,
            'area' => $item->area,
            'pincode' => $item->pincode,
            'latitude' => $item->latitude,
            'longitude' => $item->longitude,
            'country_name' => $item->country_name,
            'state_name' => $item->state_name,
            'city_name' => $item->city_name,
            'data' => $item,
            'location_encode' => base64_encode($item->sno),
            'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
          ];

        return response()->json([
          'status'=> 200,
          'data' => $data,
          'message' => 'Location Data Get Successfully',
          'error' => null
        ]);
      } catch (\Exception $e) {
        return response()->json([
            'status' => 500,
            'data'=>null,
            'message' => 'Unable to Get Location Details.',
            'error' => $e->getMessage()
        ], 500);
      }
    
  }

   public function Status($id, Request $request)
  {

    $location =  LocationModel::where('sno', $id)->first();
    // return $location;
    $location->status = $request->input('status');
    $location->update();

    if ($location) {
      return response([
        'status'    => 200,
        'message'   => 'Location  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Location  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Location  Status!',
        'error_msg' => 'Could not, update  Location  Status!',
        'data'      => null,
      ], 200);
    }
  }

    private function getCityCode($cityName)
  {
      $cityName = strtoupper(
          preg_replace('/[^A-Za-z ]/', '', $cityName)
      );

      $words = explode(' ', trim($cityName));

      // Chennai => CHN
      if(count($words) == 1)
      {
          $name = $words[0];

          if(strlen($name) >= 3)
          {
              return substr($name,0,1)
                  . substr($name,1,1)
                  . substr($name,-1,1);
          }

          return str_pad($name,3,'X');
      }

      // New Delhi => NDL
      $code = '';

      foreach($words as $word)
      {
          $code .= substr($word,0,1);
      }

      return strtoupper(substr($code,0,3));
  }
}
