<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ElectricityAccountModel;
use App\Models\LocationModel;
use App\Models\BuildingModel;
use App\Models\BuildingFloorModel;
use App\Models\LessorModel;
use App\Models\BuildingAgreementModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Models\BuildingDocumentModel;
use App\Models\ElectricityMeterModel;

class ManageElectricity extends Controller
{

public function indexOld(Request $request)
{
    $page = $request->input('page', 1);

    $perpage = (int) $request->input('sorting_filter', 25);

    $search_filter = $request->search_filter ?? '';
    $status_filter = $request->status_filter ?? '';
    $building_filter = $request->building_filter ?? '';
    $entity_filter = $request->entity_filter ?? '';
    $branch_filter = $request->branch_filter ?? '';


    $accounts = ElectricityAccountModel::where('egc_electricity_accounts.status','!=',2 )
        ->leftJoin( 'egc_buildings', 'egc_electricity_accounts.building_id','egc_buildings.sno' )
        ->leftJoin('egc_entity', 'egc_electricity_accounts.entity_id','egc_entity.sno')
        ->leftJoin('egc_branch','egc_electricity_accounts.branch_id', 'egc_branch.sno')
        ->select(
            'egc_electricity_accounts.*',
            'egc_buildings.building_name',
            'egc_entity.entity_name',
            'egc_branch.branch_name'
        );

    if ($search_filter != '') {
        $accounts->where(function ($query) use ($search_filter) {
            $query->where('egc_electricity_accounts.account_code','LIKE', "%{$search_filter}%")
            ->orWhere('egc_electricity_accounts.account_name','LIKE', "%{$search_filter}%" )
            ->orWhere('egc_electricity_accounts.account_no','LIKE',"%{$search_filter}%")
            ->orWhere('egc_electricity_accounts.consumer_no','LIKE',"%{$search_filter}%")
            ->orWhere('egc_electricity_accounts.service_no','LIKE',"%{$search_filter}%")
            ->orWhere('egc_electricity_accounts.connection_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_electricity_accounts.contact_person','LIKE',"%{$search_filter}%")
            ->orWhere('egc_buildings.building_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_entity.entity_name','LIKE',"%{$search_filter}%")
            ->orWhere('egc_branch.branch_name','LIKE',"%{$search_filter}%");
        });
    }

    if ($status_filter !== '') {
        $accounts->where('egc_electricity_accounts.status',$status_filter );
    }

    if ($building_filter !== '') {
        $accounts->where('egc_electricity_accounts.building_id',$building_filter );
    }

    if ($entity_filter !== '') {
        $accounts->where('egc_electricity_accounts.entity_id',$entity_filter);
    }

    if ($branch_filter !== '') {
        $accounts->where('egc_electricity_accounts.branch_id',$branch_filter);
    }

    $accounts = $accounts
        ->orderBy('egc_electricity_accounts.sno','DESC')
        ->paginate($perpage);

    $active_accounts = ElectricityAccountModel::where('status',1)->count();
    $inactive_accounts = ElectricityAccountModel::where('status',0)->count();

    if ($request->ajax()) {
        $data = $accounts->map(function ($item) {
            return [
                'sno' => $item->sno,
                'account_code' => $item->account_code,
                'account_name' => $item->account_name,
                'account_no' => $item->account_no,
                'consumer_no' => $item->consumer_no,
                'service_no' => $item->service_no,
                'building_name' => $item->building_name,
                'entity_name' => $item->entity_name,
                'branch_name' => $item->branch_name,
                'connection_name' => $item->connection_name,
                'connection_type_id' => $item->connection_type,
                'tariff_category' => $item->tariff_category,
                'phase_type' => $item->phase_type,
                'sanction_load' => $item->sanction_load,
                'sanction_load_unit' => $item->sanction_load_unit,
                'contract_demand' => $item->contract_demand,
                'contract_demand_unit' => $item->contract_demand_unit,
                'voltage_level' => $item->voltage_level,
                'meter_type' => $item->meter_type,
                'billing_cycle' => $item->billing_cycle,
                'status' => $item->status,
            ];
        });


        return response()->json([
            'data' => $data,
            'current_page' => $accounts->currentPage(),
            'last_page' => $accounts->lastPage(),
            'total' => $accounts->total(),
            'perpage' => $accounts->perPage(),
            'active_accounts' => $active_accounts,
            'inactive_accounts' => $inactive_accounts,
        ]);
    }

    $building_list = DB::table('egc_buildings')
        ->where('status', '!=', 2)
        ->orderBy('building_name')
        ->get();

    $entity_list = DB::table('egc_entity')
        ->where('status', 0)
        ->orderBy('entity_name')
        ->get();

    $branch_list = DB::table('egc_branch')
        ->where('status', 0)
        ->orderBy('branch_name')
        ->get();

    $provider_list = DB::table('egc_electricity_master')
        ->where('master_type', 'provider')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $tariff_category_list = DB::table('egc_electricity_master')
        ->where('master_type', 'tariff')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $connection_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'connection_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $supply_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'supply_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $phase_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'phase')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $voltage_level_list = DB::table('egc_electricity_master')
        ->where('master_type', 'voltage')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $meter_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'meter_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $billing_cycle_list = DB::table('egc_electricity_master')
        ->where('master_type', 'billing_cycle')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    $load_unit_list = DB::table('egc_electricity_master')
        ->where('master_type', 'load_unit')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();

    return view(
        'content.corporate_admin.manage_maintanence.manage_electricity.electricity_list',
        [
            'accounts' => $accounts,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'status_filter' => $status_filter,
            'building_filter' => $building_filter,
            'entity_filter' => $entity_filter,
            'branch_filter' => $branch_filter,
            'building_list' => $building_list,
            'entity_list' => $entity_list,
            'branch_list' => $branch_list,
            'provider_list' => $provider_list,
            'tariff_category_list' => $tariff_category_list,
            'connection_type_list' => $connection_type_list,
            'supply_type_list' => $supply_type_list,
            'phase_type_list' => $phase_type_list,
            'voltage_level_list' => $voltage_level_list,
            'meter_type_list' => $meter_type_list,
            'billing_cycle_list' => $billing_cycle_list,
            'load_unit_list' => $load_unit_list,

        ]
    );
}

public function index(Request $request)
{
    $page = (int) $request->input('page', 1);

    $perpage = (int) $request->input('sorting_filter', 25);

    if ($perpage <= 0) {
        $perpage = 25;
    }

    if ($perpage > 100) {
        $perpage = 100;
    }

    $search_filter    = trim($request->search_filter ?? '');
    $status_filter    = $request->status_filter ?? '';
    $building_filter  = $request->building_filter ?? '';
    $entity_filter    = $request->entity_filter ?? '';
    $branch_filter    = $request->branch_filter ?? '';
    $dashboard_filter = $request->dashboard_filter ?? '';


    /*
    |--------------------------------------------------------------------------
    | EB ACCOUNT QUERY
    |--------------------------------------------------------------------------
    */

    $accounts = ElectricityAccountModel::query()

        ->where(
            'egc_electricity_accounts.status',
            '!=',
            2
        )

        ->leftJoin(
            'egc_buildings',
            'egc_electricity_accounts.building_id',
            '=',
            'egc_buildings.sno'
        )

        ->leftJoin(
            'egc_entity',
            'egc_electricity_accounts.entity_id',
            '=',
            'egc_entity.sno'
        )

        ->leftJoin(
            'egc_branch',
            'egc_electricity_accounts.branch_id',
            '=',
            'egc_branch.sno'
        )

        /*
         * Provider
         */
        ->leftJoin(
            'egc_electricity_master as provider_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.provider_id',
                    '=',
                    'provider_master.sno'
                )->where(
                    'provider_master.master_type',
                    '=',
                    'provider'
                );
            }
        )

        /*
         * Tariff
         */
        ->leftJoin(
            'egc_electricity_master as tariff_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.tariff_category_id',
                    '=',
                    'tariff_master.sno'
                )->where(
                    'tariff_master.master_type',
                    '=',
                    'tariff'
                );
            }
        )

        /*
         * Connection Type
         */
        ->leftJoin(
            'egc_electricity_master as connection_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.connection_type_id',
                    '=',
                    'connection_master.sno'
                )->where(
                    'connection_master.master_type',
                    '=',
                    'connection_type'
                );
            }
        )

        /*
         * Supply Type
         */
        ->leftJoin(
            'egc_electricity_master as supply_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.supply_type_id',
                    '=',
                    'supply_master.sno'
                )->where(
                    'supply_master.master_type',
                    '=',
                    'supply_type'
                );
            }
        )

        /*
         * Phase
         */
        ->leftJoin(
            'egc_electricity_master as phase_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.phase_type_id',
                    '=',
                    'phase_master.sno'
                )->where(
                    'phase_master.master_type',
                    '=',
                    'phase'
                );
            }
        )

        /*
         * Voltage
         */
        ->leftJoin(
            'egc_electricity_master as voltage_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.voltage_level_id',
                    '=',
                    'voltage_master.sno'
                )->where(
                    'voltage_master.master_type',
                    '=',
                    'voltage'
                );
            }
        )

        /*
         * Meter Type
         */
        ->leftJoin(
            'egc_electricity_master as meter_master',
            function ($join) {
                $join->on(
                    'egc_electricity_accounts.meter_type_id',
                    '=',
                    'meter_master.sno'
                )->where(
                    'meter_master.master_type',
                    '=',
                    'meter_type'
                );
            }
        )

        ->select(

            'egc_electricity_accounts.*',

            'egc_buildings.building_name',

            'egc_entity.entity_name',

            'egc_branch.branch_name',

            'provider_master.master_name as provider_name',

            'tariff_master.master_code as tariff_code',

            'tariff_master.master_name as tariff_name',

            'connection_master.master_name as connection_type_name',

            'supply_master.master_name as supply_type_name',

            'phase_master.master_name as phase_name',

            'voltage_master.master_name as voltage_name',

            'meter_master.master_name as meter_type_name'

        );


    /*
    |--------------------------------------------------------------------------
    | SEARCH
    |--------------------------------------------------------------------------
    */

    if ($search_filter !== '') {

        $accounts->where(function ($query) use ($search_filter) {

            $query

                ->where(
                    'egc_electricity_accounts.account_code',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_electricity_accounts.account_name',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_electricity_accounts.account_no',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_electricity_accounts.consumer_no',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_electricity_accounts.service_no',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_electricity_accounts.contact_person',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_buildings.building_name',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_entity.entity_name',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'egc_branch.branch_name',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'tariff_master.master_name',
                    'LIKE',
                    "%{$search_filter}%"
                )

                ->orWhere(
                    'provider_master.master_name',
                    'LIKE',
                    "%{$search_filter}%"
                );

        });
    }


    /*
    |--------------------------------------------------------------------------
    | STATUS FILTER
    |--------------------------------------------------------------------------
    */

    if ($status_filter !== '') {

        $accounts->where(
            'egc_electricity_accounts.status',
            $status_filter
        );
    }


    /*
    |--------------------------------------------------------------------------
    | BUILDING FILTER
    |--------------------------------------------------------------------------
    */

    if ($building_filter !== '') {

        $accounts->where(
            'egc_electricity_accounts.building_id',
            $building_filter
        );
    }


    /*
    |--------------------------------------------------------------------------
    | ENTITY FILTER
    |--------------------------------------------------------------------------
    */

    if ($entity_filter !== '') {

        $accounts->where(
            'egc_electricity_accounts.entity_id',
            $entity_filter
        );
    }


    /*
    |--------------------------------------------------------------------------
    | BRANCH FILTER
    |--------------------------------------------------------------------------
    */

    if ($branch_filter !== '') {

        $accounts->where(
            'egc_electricity_accounts.branch_id',
            $branch_filter
        );
    }


    /*
    |--------------------------------------------------------------------------
    | DASHBOARD FILTER
    |--------------------------------------------------------------------------
    */

    switch ($dashboard_filter) {

        case 'active':

            $accounts->where(
                'egc_electricity_accounts.status',
                0
            );

            break;


        case 'inactive':

            $accounts->where(
                'egc_electricity_accounts.status',
                1
            );

            break;

    }


    /*
    |--------------------------------------------------------------------------
    | PAGINATION
    |--------------------------------------------------------------------------
    */

    $accounts = $accounts

        ->orderBy(
            'egc_electricity_accounts.sno',
            'DESC'
        )

        ->paginate($perpage);


    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    |
    | 0 = Active
    | 1 = Inactive
    | 2 = Deleted
    |
    */

    $total_accounts = ElectricityAccountModel::where(
        'status',
        '!=',
        2
    )->count();

    $active_accounts = ElectricityAccountModel::where(
        'status',
        0
    )->count();

    $inactive_accounts = ElectricityAccountModel::where(
        'status',
        1
    )->count();


    /*
    |--------------------------------------------------------------------------
    | AJAX RESPONSE
    |--------------------------------------------------------------------------
    */

    if ($request->ajax()) {

        $data = $accounts->map(function ($item) {

            return [

                'sno' =>
                    $item->sno,

                'account_code' =>
                    $item->account_code,

                'account_name' =>
                    $item->account_name,

                'account_no' =>
                    $item->account_no,

                'consumer_no' =>
                    $item->consumer_no,

                'service_no' =>
                    $item->service_no,

                'building_name' =>
                    $item->building_name,

                'entity_name' =>
                    $item->entity_name,

                'branch_name' =>
                    $item->branch_name,

                'provider_name' =>
                    $item->provider_name,

                'tariff_code' =>
                    $item->tariff_code,

                'tariff_name' =>
                    $item->tariff_name,

                'connection_type_name' =>
                    $item->connection_type_name,

                'supply_type_name' =>
                    $item->supply_type_name,

                'phase_name' =>
                    $item->phase_name,

                'voltage_name' =>
                    $item->voltage_name,

                'meter_type_name' =>
                    $item->meter_type_name,

                'sanction_load' =>
                    $item->sanction_load,

                'sanction_load_unit_id' =>
                    $item->sanction_load_unit_id,

                'contract_demand' =>
                    $item->contract_demand,

                'contract_demand_unit_id' =>
                    $item->contract_demand_unit_id,

                'status' =>
                    $item->status,

            ];

        });


        return response()->json([

            'data' =>
                $data,

            'current_page' =>
                $accounts->currentPage(),

            'last_page' =>
                $accounts->lastPage(),

            'total' =>
                $accounts->total(),

            'perpage' =>
                $accounts->perPage(),

            'total_accounts' =>
                $total_accounts,

            'active_accounts' =>
                $active_accounts,

            'inactive_accounts' =>
                $inactive_accounts,

            /*
             * These remain 0 until the actual
             * electricity bill/complaint tables are
             * connected.
             */
            'spend_this_month' =>
                0,

            'units_this_month' =>
                0,

            'open_complaints' =>
                0,

            'bills_awaiting_verify' =>
                0,

        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | EXISTING DROPDOWNS
    |--------------------------------------------------------------------------
    */

    $building_list = DB::table('egc_buildings')

        ->where('status', '!=', 2)

        ->orderBy('building_name')

        ->get();


    $entity_list = DB::table('egc_entity')

        ->where('status', 0)

        ->orderBy('entity_name')

        ->get();


    $branch_list = DB::table('egc_branch')

        ->where('status', 0)

        ->orderBy('branch_name')

        ->get();


    /*
    |--------------------------------------------------------------------------
    | ELECTRICITY MASTER DROPDOWNS
    |--------------------------------------------------------------------------
    */

    $provider_list = DB::table('egc_electricity_master')
        ->where('master_type', 'provider')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $tariff_category_list = DB::table('egc_electricity_master')
        ->where('master_type', 'tariff')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $connection_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'connection_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $supply_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'supply_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $phase_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'phase')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $voltage_level_list = DB::table('egc_electricity_master')
        ->where('master_type', 'voltage')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $meter_type_list = DB::table('egc_electricity_master')
        ->where('master_type', 'meter_type')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $billing_cycle_list = DB::table('egc_electricity_master')
        ->where('master_type', 'billing_cycle')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    $load_unit_list = DB::table('egc_electricity_master')
        ->where('master_type', 'load_unit')
        ->where('status', 0)
        ->orderBy('sort_order')
        ->orderBy('master_name')
        ->get();


    /*
    |--------------------------------------------------------------------------
    | VIEW
    |--------------------------------------------------------------------------
    */

    return view(
        'content.corporate_admin.manage_maintanence.manage_electricity.electricity_list',
        [

            'accounts' =>
                $accounts,

            'perpage' =>
                $perpage,

            'search_filter' =>
                $search_filter,

            'status_filter' =>
                $status_filter,

            'building_filter' =>
                $building_filter,

            'entity_filter' =>
                $entity_filter,

            'branch_filter' =>
                $branch_filter,

            'building_list' =>
                $building_list,

            'entity_list' =>
                $entity_list,

            'branch_list' =>
                $branch_list,

            'provider_list' =>
                $provider_list,

            'tariff_category_list' =>
                $tariff_category_list,

            'connection_type_list' =>
                $connection_type_list,

            'supply_type_list' =>
                $supply_type_list,

            'phase_type_list' =>
                $phase_type_list,

            'voltage_level_list' =>
                $voltage_level_list,

            'meter_type_list' =>
                $meter_type_list,

            'billing_cycle_list' =>
                $billing_cycle_list,

            'load_unit_list' =>
                $load_unit_list,

        ]
    );
}

public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [

        'building_id' => [
            'required',
            'integer',
            'exists:egc_buildings,sno'
        ],

        'account_name' => [
            'required',
            'string',
            'max:200'
        ],

        'service_no' => [
            'required',
            'string',
            'max:100'
        ],

        'consumer_no' => [
            'nullable',
            'string',
            'max:100'
        ],

        'provider_id' => [
            'required',
            'integer'
        ],

        'tariff_category_id' => [
            'required',
            'integer'
        ],

        'connection_type_id' => [
            'required',
            'integer'
        ],

        'supply_type_id' => [
            'required',
            'integer'
        ],

        'phase_type_id' => [
            'required',
            'integer'
        ],

        'voltage_level_id' => [
            'nullable',
            'integer'
        ],

        'meter_type_id' => [
            'nullable',
            'integer'
        ],

        'billing_cycle_id' => [
            'nullable',
            'integer'
        ],

        'sanction_load' => [
            'nullable',
            'numeric',
            'min:0'
        ],

        'sanction_load_unit_id' => [
            'nullable',
            'integer'
        ],

        'contract_demand' => [
            'nullable',
            'numeric',
            'min:0'
        ],

        'contract_demand_unit_id' => [
            'nullable',
            'integer'
        ],

    ], [
        'building_id.required' =>'Building is required.',
        'building_id.exists' =>'Selected building is invalid.',
        'account_name.required' =>'Account Name is required.',
        'service_no.required' =>'Service Number is required.',
        'provider_id.required' =>'Electricity Provider is required.',
        'tariff_category_id.required' => 'Tariff Category is required.',
        'connection_type_id.required' =>'Connection Type is required.',
        'supply_type_id.required' =>'Supply Type is required.',
        'phase_type_id.required' =>'Phase is required.',

    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ], 422);
    }
        $userId =$request->user()->user_id;
    try {
        

        DB::beginTransaction();

        $building = DB::table('egc_buildings')
            ->where('sno', $request->building_id)
            ->where('status', '!=', 2)
            ->first();

    

        if (!$building) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'message' =>'Selected building is not active or does not exist.'
            ], 422);
        }

        $serviceNo = trim($request->service_no);

        $serviceExists = ElectricityAccountModel::where('service_no',$serviceNo)
            ->where('status', '!=', 2)
            ->exists();

        

        if ($serviceExists) {
            DB::rollBack();
            return response()->json([
                'status' => 409,
                'message' =>'This EB Service Number is already registered.'
            ], 409);
        }

        $consumerNo = !empty($request->consumer_no) ? trim($request->consumer_no) : null;
        if ($consumerNo !== null) {
            $consumerExists = ElectricityAccountModel::where('consumer_no',$consumerNo )
                ->where('status', '!=', 2)
                ->exists();

            if ($consumerExists) {
                DB::rollBack();
                return response()->json([
                    'status' => 409,
                    'message' =>'This Consumer Number is already registered.'

                ], 409);
            }
        }
        $lastAccount = ElectricityAccountModel::orderBy('sno', 'desc')->first();

        if (
            $lastAccount &&
            !empty($lastAccount->account_code)
        ) {
            preg_match(
                '/(\d+)$/',
                $lastAccount->account_code,
                $matches
            );
            $runningNo = !empty($matches[1])
                ? ((int) $matches[1] + 1)
                : 1;
        } else {
            $runningNo = 1;
        }
        $accountCode = 'EB-' . str_pad($runningNo,6, '0', STR_PAD_LEFT);

        
        $account = new ElectricityAccountModel();

        $account->account_code = $accountCode;
        $account->building_id = $request->building_id;
        $account->location_id = $building->location_id ?? null;
        $account->account_name = trim($request->account_name);
        $account->service_no = $serviceNo;
        $account->consumer_no =$consumerNo;
        $account->provider_id =  $request->provider_id;
        $account->tariff_category_id = $request->tariff_category_id;
        $account->connection_type_id = $request->connection_type_id;
        $account->supply_type_id = $request->supply_type_id;
        $account->phase_type_id = $request->phase_type_id;
        $account->voltage_level_id = $request->voltage_level_id ?: null;
        $account->meter_type_id = $request->meter_type_id ?: null;
        $account->billing_cycle_id = $request->billing_cycle_id ?: null;
        $account->sanction_load = $request->sanction_load !== null ? $request->sanction_load : null;
        $account->sanction_load_unit_id = $request->sanction_load_unit_id ?: null;
        $account->contract_demand = $request->contract_demand !== null ? $request->contract_demand : null;
        $account->contract_demand_unit_id = $request->contract_demand_unit_id ?: null;

        $account->status = 0;
        $account->created_by = $userId;
        $account->updated_by = $userId;
        $account->created_at = now();
        $account->updated_at = now();
        $account->save();

        DB::commit();

        return response()->json([
            'status' => 200,
            'message' =>'EB Account added successfully.',
            'data' => [
                'sno' => $account->sno,
                'account_code' =>$account->account_code
            ]

        ], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        Log::error(
            'Electricity Account Add Failed',
            [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' =>$e->getLine(),
                'user_id' =>$userId ?? 0,
            ]
        );
        return response()->json([
            'status' => 500,
            'message' =>'Unable to save EB Account. Please try again.'.$e->getMessage()
        ], 500);
    }
}

public function AddMeter(Request $request)
{
    $validator = Validator::make($request->all(), [

        'account_id' => [
            'required',
            'integer',
            'exists:egc_electricity_accounts,sno'
        ],

        'meter_no' => [
            'required',
            'string',
            'max:100'
        ],

        'meter_name' => [
            'required',
            'string',
            'max:200'
        ],

        'meter_type_id' => [
            'nullable',
            'integer'
        ],

        'meter_make' => [
            'nullable',
            'string',
            'max:100'
        ],

        'meter_model' => [
            'nullable',
            'string',
            'max:100'
        ],

        'serial_no' => [
            'nullable',
            'string',
            'max:100'
        ],

        'phase_type_id' => [
            'nullable',
            'integer'
        ],

        'multiplier_factor' => [
            'nullable',
            'numeric',
            'min:0.01'
        ],

        'initial_reading' => [
            'nullable',
            'numeric',
            'min:0'
        ],

        'current_reading' => [
            'nullable',
            'numeric',
            'min:0'
        ],

        'reading_unit' => [
            'nullable',
            'in:KWH,MWH'
        ],

        'installation_date' => [
            'nullable',
            'date'
        ],

        'warranty_expiry' => [
            'nullable',
            'date'
        ],

        'meter_location' => [
            'nullable',
            'string',
            'max:255'
        ],

        'max_load' => [
            'nullable',
            'numeric',
            'min:0'
        ],

        'load_unit' => [
            'nullable',
            'in:KW,KVA'
        ],

        'remarks' => [
            'nullable',
            'string'
        ],

    ], [

        'account_id.required' =>'Electricity Account is required.',
        'account_id.exists' =>'Selected Electricity Account is invalid.',
        'meter_no.required' => 'Meter Number is required.',
        'meter_name.required' => 'Meter Name is required.',
        'multiplier_factor.min' =>'Multiplier Factor must be greater than zero.',
        'reading_unit.in' =>'Invalid Reading Unit.',
        'load_unit.in' =>'Invalid Load Unit.',

    ]);


    if ($validator->fails()) {

        return response()->json([
            'status' => 422,
            'errors' => $validator->errors()
        ], 422);
    }


    try {

        DB::beginTransaction();

        $account = DB::table('egc_electricity_accounts')
            ->where('sno', $request->account_id)
            ->where('status', '!=', 2)
            ->first();


        if (!$account) {

            DB::rollBack();

            return response()->json([
                'status' => 422,
                'message' => 'Selected Electricity Account is not active or does not exist.'
            ], 422);
        }

        $meterNo = trim($request->meter_no);
        $meterName = trim($request->meter_name);
        $serialNo = $request->serial_no ? trim($request->serial_no) : null;

        $meterExists = ElectricityMeterModel::where('meter_no',$meterNo )
            ->where('status', '!=', 2)
            ->exists();


        if ($meterExists) {

            DB::rollBack();
            return response()->json([
                'status' => 409,
                'message' =>'This Meter Number is already registered.'

            ], 409);
        }

        if (!empty($serialNo)) {
            $serialExists = ElectricityMeterModel::where('serial_no', $serialNo )
                ->where('status', '!=', 2)
                ->exists();
            if ($serialExists) {

                DB::rollBack();
                return response()->json([
                    'status' => 409,
                    'message' => 'This Meter Serial Number is already registered.'
                ], 409);
            }
        }

        $initialReading = $request->initial_reading !== null ? (float) $request->initial_reading : 0;

        $currentReading = $request->current_reading !== null ? (float) $request->current_reading : 0;


        if ($currentReading < $initialReading) {
            DB::rollBack();
            return response()->json([
                'status' => 422,
                'errors' => [
                    'current_reading' => [
                        'Current Reading cannot be less than Initial Reading.'
                    ]
                ]
            ], 422);
        }


        if (!empty($request->installation_date) && !empty($request->warranty_expiry) ) {

            if (strtotime($request->warranty_expiry) < strtotime($request->installation_date)) {

                DB::rollBack();
                return response()->json([
                    'status' => 422,
                    'errors' => [
                        'warranty_expiry' => [
                            'Warranty Expiry cannot be before Installation Date.'
                        ]
                    ]
                ], 422);
            }
        }

        $meter = new ElectricityMeterModel();

        $meter->account_id = $account->sno;
        $meter->meter_no = $meterNo;
        $meter->meter_name = $meterName;
        $meter->meter_type_id = $request->meter_type_id ?: null;
        $meter->meter_make = $request->meter_make ? trim($request->meter_make): null;
        $meter->meter_model = $request->meter_model  ? trim($request->meter_model): null;
        $meter->serial_no = $serialNo;
        $meter->phase_type_id =  $request->phase_type_id ?: null;
        $meter->multiplier_factor =  $request->multiplier_factor !== null ? $request->multiplier_factor : 1.00;
        $meter->initial_reading = $initialReading;
        $meter->current_reading =$currentReading;
        $meter->reading_unit = $request->reading_unit ?: 'KWH';
        $meter->installation_date = $request->installation_date ?: null;
        $meter->warranty_expiry = $request->warranty_expiry ?: null;
        $meter->meter_location = $request->meter_location ? trim($request->meter_location) : null;
        $meter->max_load = $request->max_load !== null ? $request->max_load: 0.00;
        $meter->load_unit = $request->load_unit ?: 'KW';
        $meter->remarks = $request->remarks ? trim($request->remarks) : null;
        $meter->status = 0;
        $meter->created_by = $userId;
        $meter->updated_by = $userId;
        $meter->created_at = now();
        $meter->updated_at = now();
        $meter->save();
        DB::commit();


        return response()->json([
            'status' => 200,
            'message' => 'Electricity Meter added successfully.',
            'data' => [
                'sno' => $meter->sno,
                'meter_no' => $meter->meter_no,
                'meter_name' => $meter->meter_name,
                'account_id' => $meter->account_id
            ]
        ], 200);

    } catch (\Throwable $e) {
        DB::rollBack();
        Log::error('Electricity Meter Add Failed',
            [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'user_id' =>$userId ?? 0,
            ]
        );

        return response()->json([
            'status' => 500,
            'message' => 'Unable to save Electricity Meter. Please try again.'
        ], 500);
    }
}
    
    public function payment()
    {
        return view('content.corporate_admin.manage_maintanence.manage_electricity.electricity_payment');
    }
    public function bill()
    {
        return view('content.corporate_admin.manage_maintanence.manage_electricity.electricity_bill');
    }
}   