<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LeaseRegister extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.lease_list');
  }

  public function add()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.add_lease');
  }

  public function edit()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.edit_lease');
  }

  public function view()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.view_lease');
  }

  public function terminate_lease()
  {
    return view('content.corporate_admin.manage_maintanence.manage_lease.termination_checklist');
  }

}
