<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageTelecom extends Controller
{
    public function index()
    {
       return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_list');
    }
    public function payment()
    {
        return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_payment');
    }
    public function bill()
    {
        return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_bill');
    }
    public function account()
    {
        return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_account');
    }
    public function number()
    {
        return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_number');
    }
    public function device()
    {
        return view('content.corporate_admin.manage_maintanence.manage_telecom.telecom_device');
    }
}