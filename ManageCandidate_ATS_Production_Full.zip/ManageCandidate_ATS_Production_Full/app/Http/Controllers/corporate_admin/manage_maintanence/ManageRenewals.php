<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageRenewals extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.manage_maintanence.manage_renewals.renewals_list');
    }
    public function proposal()
    {
        return view('content.corporate_admin.manage_maintanence.manage_renewals.proposal_list');
    }
    public function negotiate()
    {
        return view('content.corporate_admin.manage_maintanence.manage_renewals.negotiate_list');
    }
    public function internal()
    {
        return view('content.corporate_admin.manage_maintanence.manage_renewals.internal_list');
    }
    public function execute()
    {
        return view('content.corporate_admin.manage_maintanence.manage_renewals.execute_list');
    }

}   