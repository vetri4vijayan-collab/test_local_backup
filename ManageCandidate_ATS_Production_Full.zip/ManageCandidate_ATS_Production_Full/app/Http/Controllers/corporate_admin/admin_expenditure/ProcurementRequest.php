<?php

namespace App\Http\Controllers\corporate_admin\admin_expenditure;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProcurementRequest extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.admin_expenditure.procurement_request.request_list');
  }

}
