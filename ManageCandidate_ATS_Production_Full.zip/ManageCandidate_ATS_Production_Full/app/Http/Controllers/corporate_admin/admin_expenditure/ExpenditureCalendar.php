<?php

namespace App\Http\Controllers\corporate_admin\admin_expenditure;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExpenditureCalendar extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.admin_expenditure.expenditure_calendar.schedule_list');
  }

}
