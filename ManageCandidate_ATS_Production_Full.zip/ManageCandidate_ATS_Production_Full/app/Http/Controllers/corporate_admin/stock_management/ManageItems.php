<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\ItemModel;
use App\Models\ItemInventorySettingModel;
use App\Models\ItemPurchaseSettingModel;
use App\Models\ItemBatchSettingModel;

class ManageItems extends Controller
{

  public function index(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $category = $request->category_filter ?? '';
    $warehouse = $request->warehouse_filter ?? '';
    $status = $request->status_filter ?? '';

    $items = ItemModel::select(

                'egc_items.sno',
                'egc_items.item_code',
                'egc_items.item_name',
                'egc_items.item_short_name',

                'egc_items.standard_cost',
                'egc_items.opening_stock',
                'egc_items.opening_stock_value',

                'egc_items.default_bin',

                'egc_items.has_expiry',

                'egc_items.status',

                'egc_item_categories.category_name',

                'egc_item_subcategories.subcategory_name',

                'egc_brands.brand_name',

                'egc_units.unit_name',

                'egc_warehouses.warehouse_name',

                'egc_item_inventory_settings.minimum_stock',

                'egc_item_inventory_settings.maximum_stock',

                'egc_item_inventory_settings.reorder_level'

            )
        ->leftJoin('egc_item_categories','egc_item_categories.sno','=', 'egc_items.category_id')
        ->leftJoin('egc_item_subcategories','egc_item_subcategories.sno','=','egc_items.subcategory_id')
        ->leftJoin('egc_units','egc_units.sno','=', 'egc_items.unit_id')
        ->leftJoin('egc_brands','egc_brands.sno','=','egc_items.brand_id' )
        ->leftJoin('egc_item_inventory_settings','egc_item_inventory_settings.item_id', '=','egc_items.sno')
        ->leftJoin('egc_warehouses','egc_warehouses.sno', '=','egc_item_inventory_settings.warehouse_id');



    $query = clone $items;

    $dashboard = [
        'total'      => (clone $query)->count(),
        'active'     => (clone $query)->where('egc_items.status',0)->count(),
        'inactive'   => (clone $query)->where('egc_items.status',1)->count(),
        'low_stock'  => (clone $query)->whereRaw('
                        egc_items.opening_stock <=
                        egc_item_inventory_settings.reorder_level
                        ')->count(),
        'expiry'     => (clone $query)->where('egc_items.has_expiry',1)->count(),
    ];



    if($search!='')
    {
        $items->where(function($q) use($search){

            $q->where('egc_items.item_name','LIKE',"%$search%")
              ->orWhere('egc_items.item_code','LIKE',"%$search%")
              ->orWhere('egc_item_categories.category_name','LIKE',"%$search%")
              ->orWhere('egc_brands.brand_name','LIKE',"%$search%");
        });
    }

    if($category!='')
        $items->where('egc_items.category_id',$category);

    if($warehouse!='')
        $items->where(
            'egc_item_inventory_settings.warehouse_id',
            $warehouse
        );

    if($status!='')
        $items->where('egc_items.status',$status);


    $items = $items
        ->orderBy('egc_items.sno','DESC')
        ->paginate($perpage);



    if($request->ajax())
    {
        $data = $items->map(function ($item) {

          $stockStatus = 'In Stock';

          if ($item->opening_stock <= 0) {

              $stockStatus = 'Out of Stock';

          } elseif ($item->opening_stock <= $item->reorder_level) {

              $stockStatus = 'Low Stock';

          }

          return [

              'sno'=>$item->sno,

              'item_code'=>$item->item_code,

              'item_name'=>$item->item_name,

              'short_name'=>$item->item_short_name,

              'category'=>$item->category_name,

              'subcategory'=>$item->subcategory_name,

              'brand'=>$item->brand_name,

              'unit'=>$item->unit_name,

              'warehouse'=>$item->warehouse_name,

              'stock'=>$item->opening_stock,

              'minimum_stock'=>$item->minimum_stock,

              'reorder_level'=>$item->reorder_level,

              // 'inventory_value'=>$item->opening_stock_value,
              'inventory_value' => round($item->opening_stock * $item->standard_cost, 2),

              'standard_cost'=>$item->standard_cost,

              'bin'=>$item->default_bin,

              'has_expiry'=>$item->has_expiry,

              'expiry_status'=>$item->has_expiry ? 'Expiry Enabled' : 'No Expiry',

              'stock_status'=>$stockStatus,

              'status'=>$item->status

          ];

      });

        return response()->json([
            'data'=>$data,
            'dashboard'=>$dashboard,
            'current_page'=>$items->currentPage(),
            'last_page'=>$items->lastPage(),
            'total'=>$items->total()

        ]);

    }


    $categories = DB::table('egc_item_categories')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();
    $brands = DB::table('egc_brands')
        ->where('status',0)
         ->orderBy('brand_name')
        ->get();



    $warehouses = DB::table('egc_warehouses')
        ->where('status',0)
        ->orderBy('warehouse_name')
        ->get();
    $units = DB::table('egc_units')
        ->where('status',0)
        ->orderBy('unit_name')
        ->get();

    $item_types = DB::table('egc_item_types')
        ->where('status',0)
        ->get();

    $vendors  = DB::table('egc_vendors')
        ->where('status',0)
        ->get();



    return view(
        'content.corporate_admin.stock_management.items_list',
        compact(
            'categories',
            'brands',
            'vendors',
            'units',
            'item_types',
            'warehouses',
            'perpage',
            'search'
        )
    );
}

public function Add(Request $request)
    {
        DB::beginTransaction();

        try {

            $validator = Validator::make($request->all(), [
                // Basic
                'item_name'             => 'required|string|max:200',
                'category_id'           => 'required|integer',
                'unit_id'               => 'required|integer',
                'item_type_id'          => 'required|integer',
                // Pricing
                'selling_price'         => 'required|numeric|min:0',
                'purchase_unit_price'   => 'nullable|numeric|min:0',
                'gst_percentage'        => 'nullable|numeric|in:0,5,12,18,28',
                'hsn_code'              => 'nullable|digits_between:4,8',
                // Inventory
                'warehouse_id'          => 'required_if:track_inventory,1',
                'opening_stock'         => 'nullable|numeric|min:0',
                // Image
                'item_image'            => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
                // Options
                'expiry_date'           => 'nullable|date',
                'batch_prefix'          => 'nullable|max:20',
                // Description
                'description'           => 'nullable|max:1000',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors()
                ],422);

            }


            

            $user_id = $request->user()->user_id ?? 0;
            if (
                ItemModel::whereRaw('LOWER(item_name)=?', [strtolower(trim($request->item_name))])
                    ->where('status',0)
                    ->exists()
            ) {
                return response()->json([
                    'status'=>false,
                    'message'=>'Item already exists.'
                ],422);
            }

            $last=ItemModel::latest('sno')->first();
            $next=1;
            if($last){
                $next=$last->sno+1;
            }

            $itemCode='ITM'.str_pad($next,6,'0',STR_PAD_LEFT);


            $imageName = null;

            if($request->hasFile('item_image')){
                $file = $request->file('item_image');
                $imageName =time().'_'.uniqid().'.'.$file->getClientOriginalExtension();

                $file->move(public_path('items'),$imageName);

            }

            $item = new ItemModel();

            $item->item_code             = $itemCode;
            $item->item_name             = strtoupper(trim($request->item_name));
            $item->category_id           = $request->category_id;
            $item->subcategory_id        = $request->subcategory_id;
            $item->brand_id              = $request->brand_id;
            $item->unit_id               = $request->unit_id;
            $item->item_type_id          = $request->item_type_id;
            $item->preferred_vendor_id   = $request->preferred_vendor_id;
            
            $item->selling_price         = $request->selling_price;

            $item->gst_percentage        = $request->gst_percentage;
            $item->hsn_code              = $request->hsn_code;

            $item->description           = $request->description;
            $item->item_image            = $imageName;

            $item->status                = 0;
            $item->created_by            = $user_id;
            $item->updated_by            = $user_id;

            $item->save();


            if ($request->track_inventory) {

                ItemInventorySettingModel::create([
                    'item_id'        => $item->sno,
                    'warehouse_id'   => $request->warehouse_id,
                    'opening_stock'  => $request->opening_stock ?? 0,
                ]);

            }

            ItemPurchaseSettingModel::create([
                'item_id'               => $item->sno,
                'preferred_vendor_id'   => $request->preferred_vendor_id,
                'purchase_unit_price'   => $request->purchase_unit_price,
                'is_preferred_vendor'   => $request->preferred_vendor_id ? 1 : 0,
            ]);


           if (
                    $request->has_batch ||
                    $request->has_expiry ||
                    $request->has_serial_no
                ) {

                    ItemBatchSettingModel::create([
                        'item_id'                   => $item->sno,
                        'batch_prefix'              => $request->batch_prefix,
                        'expiry_required'           => $request->has_expiry ? 1 : 0,
                        'default_expiry_date'       => $request->expiry_date,
                        'manufacture_date_required' => 0,
                        'serial_tracking'           => $request->has_serial_no ? 1 : 0,
                        'fifo_enabled'              => 1,
                        'batch_auto_generate'       => $request->has_batch ? 1 : 0,
                    ]);

                }

            DB::commit();

            return response()->json([
                'status'=>200,
                'message'=>'Item Added Successfully.'
            ]);

        }catch(\Exception $e){

            DB::rollBack();
            return response()->json([
                'status'=>500,
                'message'=>'Unable to save Item.',
                'error'=>$e->getMessage()
            ],500);
        }
    }


    public function getItemSubCategories(Request $request)
  {
      $validator = Validator::make($request->all(),[
          'category_id' => 'required|exists:egc_item_categories,sno'
      ]);

      if($validator->fails()){
          return response()->json([
              'status'  => false,
              'message' => $validator->errors()->first()
          ],422);
      }

      $subcategory = DB::table('egc_item_subcategories')
          ->where('category_id',$request->category_id)
          ->where('status',0)
          ->orderBy('subcategory_name')
          ->select(
              'sno',
              'subcategory_name'
          )
          ->get();

      return response()->json([
          'status' => 200,
          'data'   => $subcategory
      ]);
  }
  

}
