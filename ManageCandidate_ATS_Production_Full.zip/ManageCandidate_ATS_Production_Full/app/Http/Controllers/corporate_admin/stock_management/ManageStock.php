<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\ItemModel;
use App\Models\ItemInventorySettingModel;
use App\Models\ItemPurchaseSettingModel;
use App\Models\ItemBatchSettingModel;

class ManageStock extends Controller
{

    public function index(Request $request)
    {
        $page = $request->page ?? 1;
        $perpage = $request->sorting_filter ?? 25;

        $search = $request->search_filter ?? '';
        $category = $request->category_filter ?? '';
        $warehouse = $request->warehouse_filter ?? '';
        $status = $request->status_filter ?? '';

        $stocks = DB::table('egc_stock')
        ->select(
            'egc_stock.sno',
            'egc_stock.stock_code',
            'egc_stock.batch_no',
            'egc_stock.serial_no',
            'egc_stock.manufacture_date',
            'egc_stock.expiry_date',
            'egc_stock.available_qty',
            'egc_stock.reserved_qty',
            'egc_stock.damaged_qty',
            'egc_stock.issued_qty',
            'egc_stock.in_transit_qty',
            'egc_stock.unit_cost',
            'egc_stock.rack_location',
            'egc_stock.bin_location',
            'egc_stock.stock_status',
            'egc_stock.status',
            'egc_items.item_code',
            'egc_items.item_name',
            'egc_items.item_short_name',
            'egc_item_categories.category_name',
            'egc_brands.brand_name',
            'egc_units.unit_name',
            'egc_warehouses.warehouse_name',
            'egc_item_inventory_settings.minimum_stock',
            'egc_item_inventory_settings.maximum_stock',
            'egc_item_inventory_settings.reorder_level'
        )
        ->join('egc_items','egc_items.sno', '=','egc_stock.item_id')
        ->leftJoin('egc_item_categories','egc_item_categories.sno','=','egc_items.category_id')
        ->leftJoin('egc_brands','egc_brands.sno','=','egc_items.brand_id')
        ->leftJoin('egc_units','egc_units.sno','=','egc_items.unit_id')
        ->leftJoin('egc_warehouses','egc_warehouses.sno','=','egc_stock.warehouse_id')
        ->leftJoin('egc_item_inventory_settings','egc_item_inventory_settings.item_id','=','egc_items.sno');



        $query = clone $stocks;

        $dashboard = [

            'items' => (clone $query)
                ->where('egc_stock.status',0)
                ->count(),

            'movements' => 0,

            'cycle_counts' => 0,

            'expiry' => (clone $query)
                ->whereNotNull('egc_stock.expiry_date')
                ->whereBetween('egc_stock.expiry_date',[
                    now(),
                    now()->copy()->addDays(30)
                ])
                ->count(),

            'damage' => (clone $query)
                ->where(function($q){

                    $q->where('egc_stock.damaged_qty','>',0)
                    ->orWhereIn('egc_stock.stock_status',[3,4]);

                })
                ->count(),
            'total' => (clone $query)->count(),

            'available' => (clone $query)
                ->where('egc_stock.stock_status',0)
                ->count(),

            'reserved' => (clone $query)
                ->where('egc_stock.stock_status',1)
                ->count(),

            'below_reorder' => (clone $query)
                ->whereColumn(
                    'egc_stock.available_qty',
                    '<=',
                    'egc_item_inventory_settings.reorder_level'
                )
                ->count(),

            'expiring_30_days' => (clone $query)
                ->whereNotNull('egc_stock.expiry_date')
                ->whereBetween(
                    'egc_stock.expiry_date',
                    [now(), now()->copy()->addDays(30)]
                )
                ->count(),
        ];



        if($search!='')
        {
            $stocks->where(function($q) use($search){

                $q->where('egc_items.item_name','LIKE',"%$search%")
                ->orWhere('egc_items.item_code','LIKE',"%$search%")
                ->orWhere('egc_stock.stock_code','LIKE',"%$search%")
                ->orWhere('egc_stock.batch_no','LIKE',"%$search%")
                ->orWhere('egc_stock.serial_no','LIKE',"%$search%");
            });
        }

        if($category!='')
            $stocks->where('egc_items.category_id',$category);

        if($warehouse!='')
            $stocks->where(
                'egc_stock.warehouse_id',
                $warehouse
            );

        if($status!='')
            $stocks->where('egc_stock.stock_status',$status);

        $stocks = $stocks
             ->orderBy('egc_stock.sno','DESC')
            ->paginate($perpage);



        if($request->ajax()){
            $data = $stocks->map(function($row){

                $stockStatus='Available';
                switch($row->stock_status){
                    case 1:
                        $stockStatus='Reserved';
                        break;
                    case 2:
                        $stockStatus='Issued';
                        break;
                    case 3:
                        $stockStatus='Damaged';
                        break;
                    case 4:
                        $stockStatus='Disposed';
                        break;
                    case 5:
                        $stockStatus='Transferred';
                        break;
                }

                return [
                    'sno'=>$row->sno,
                    'stock_code'=>$row->stock_code,
                    'item_code'=>$row->item_code,
                    'item_name'=>$row->item_name,
                    'category'=>$row->category_name,
                    'brand'=>$row->brand_name,
                    'warehouse'=>$row->warehouse_name,
                    'batch_no'=>$row->batch_no,
                    'serial_no'=>$row->serial_no,
                    'available_qty'=>$row->available_qty,
                    'reserved_qty'=>$row->reserved_qty,
                    'damaged_qty'=>$row->damaged_qty,
                    'issued_qty'=>$row->issued_qty,
                    'unit'=>$row->unit_name,
                    'unit_cost'=>$row->unit_cost,
                    'stock_value'=>round(
                        $row->available_qty * $row->unit_cost,
                        2
                    ),
                    'minimum_stock'=>$row->minimum_stock,
                    'reorder_level'=>$row->reorder_level,
                    'expiry_date'=>$row->expiry_date,
                    'rack_location'=>$row->rack_location,
                    'bin_location'=>$row->bin_location,
                    'stock_status'=>$stockStatus,
                    'status'=>$row->status
                ];

            });

            return response()->json([
                'data'=>$data,
                'dashboard'=>$dashboard,
                'current_page'=>$stocks->currentPage(),
                'last_page'=>$stocks->lastPage(),
                'total'=>$stocks->total()

            ]);

        }


        $categories = DB::table('egc_item_categories')
            ->where('status',0)
            ->orderBy('sort_order')
            ->get();
        $brands = DB::table('egc_brands')
            ->where('status',0)
            ->orderBy('brand_name')
            ->get();

        $warehouses = DB::table('egc_warehouses')
            ->where('status',0)
            ->orderBy('warehouse_name')
            ->get();
        $units = DB::table('egc_units')
            ->where('status',0)
            ->orderBy('unit_name')
            ->get();

        $item_types = DB::table('egc_item_types')
            ->where('status',0)
            ->get();

        $vendors  = DB::table('egc_vendors')
            ->where('status',0)
            ->get();



        return view(
            'content.corporate_admin.stock_management.manage_stock',
            compact(
                'categories',
                'brands',
                'vendors',
                'units',
                'item_types',
                'warehouses',
                'perpage',
                'search'
            )
        );
    }
    
    public function cycle_count()
    {
        return view('content.corporate_admin.stock_management.cycle_count');
    }
    public function damage()
    {
        return view('content.corporate_admin.stock_management.damage');
    }
    public function movements()
    {
        return view('content.corporate_admin.stock_management.movements');
    }
    public function expiry()
    {
        return view('content.corporate_admin.stock_management.expiry');
    }


    public function getItems(Request $request)
    {

        $items = DB::table('egc_items')
            ->select('sno', 'item_name','item_code' )
            ->where('category_id',$request->category_id)
            ->where('status',0)
            ->orderBy('item_name')
            ->get();

        return response()->json($items);
    }

    public function Add(Request $request)
    {

        DB::beginTransaction();

        try{

            $validator = Validator::make($request->all(),[
                'category_id'=>'required',
                'item_id'=>'required',
                'warehouse_id'=>'required',
                'available_qty'=>'required|numeric|min:0.001',
                'unit_cost'=>'required|numeric|min:0',
                'manufacture_date'=>'nullable|date',
                'expiry_date'=>'nullable|date|after_or_equal:manufacture_date',
                'batch_no'=>'nullable|max:100',
                'serial_no'=>'nullable|max:150',
                'rack_location'=>'nullable|max:100',
                'bin_location'=>'nullable|max:100',
                'remarks'=>'nullable|max:1000'

            ]);

            if($validator->fails()){
                return response()->json([
                    'errors'=>$validator->errors()

                ],422);
            }

            /*
            --------------------------------------
            Generate Stock Code
            --------------------------------------
            */

            $last = DB::table('egc_stock')
                ->orderByDesc('sno')
                ->first();

            $next = $last ? ($last->sno + 1) : 1;

            $stockCode = 'STK'.str_pad($next,6,'0',STR_PAD_LEFT);

            /*
            --------------------------------------
            Duplicate Serial No
            --------------------------------------
            */

            if($request->serial_no!=''){
                $exists = DB::table('egc_stock')
                    ->where('serial_no',$request->serial_no)
                    ->where('status','!=',2)
                    ->exists();

                if($exists){
                    return response()->json([
                        'status'=>201,
                        'message'=>'Serial Number already exists.'
                    ]);

                }
            }

            DB::table('egc_stock')
            ->insert([
                'stock_code'=>$stockCode,
                'item_id'=>$request->item_id,
                'warehouse_id'=>$request->warehouse_id,
                'batch_no'=>$request->batch_no,
                'serial_no'=>$request->serial_no,
                'manufacture_date'=>$request->manufacture_date ? date('Y-m-d',strtotime($request->manufacture_date)) : NULL,
                'expiry_date'=>$request->expiry_date ? date('Y-m-d',strtotime($request->expiry_date)) : NULL,
                'available_qty'=>$request->available_qty,
                'reserved_qty'=>0,
                'damaged_qty'=>0,
                'issued_qty'=>0,
                'in_transit_qty'=>0,
                'unit_cost'=>$request->unit_cost,
                'rack_location'=>$request->rack_location,
                'bin_location'=>$request->bin_location,
                'remarks'=>$request->remarks,
                'stock_status'=>0,
                'status'=>0,
                'created_by'=>session('user_id'),
                'updated_by'=>session('user_id'),
                'created_at'=>now(),
                'updated_at'=>now()

            ]);

            /*
            --------------------------------------
            Update Item Opening Stock
            --------------------------------------
            */
            DB::table('egc_items')
                ->where('sno',$request->item_id)
                ->increment('opening_stock',$request->available_qty);

            DB::commit();

            return response()->json([
                'status'=>200,
                'message'=>'Stock Added Successfully.'

            ]);

        }

        catch(\Exception $e){
            DB::rollback();
            return response()->json([
                'status'=>500,
                'message'=>$e->getMessage()

            ]);

        }

    }

    public function view($id)
    {
        $stock = DB::table('egc_stock')
            ->select(
                'egc_stock.*',

                'egc_items.item_code',
                'egc_items.item_name',

                'egc_item_categories.category_name',

                'egc_units.unit_name',

                'egc_warehouses.warehouse_name'
            )

            ->join('egc_items','egc_items.sno','=','egc_stock.item_id')

            ->leftJoin(
                'egc_item_categories',
                'egc_item_categories.sno',
                '=',
                'egc_items.category_id'
            )

            ->leftJoin(
                'egc_units',
                'egc_units.sno',
                '=',
                'egc_items.unit_id'
            )

            ->leftJoin(
                'egc_warehouses',
                'egc_warehouses.sno',
                '=',
                'egc_stock.warehouse_id'
            )

            ->where('egc_stock.sno',$id)

            ->first();

        if(!$stock){
            return response()->json([
                'status'=>false,
                'message'=>'Stock not found.'
            ],404);
        }

        return response()->json([
            'status'=>true,
            'data'=>$stock
        ]);
    }


    public function adjustStockInfo($id)
    {
        $stock = DB::table('egc_stock')
            ->join('egc_items', 'egc_items.sno', '=', 'egc_stock.item_id')
            ->join('egc_units', 'egc_units.sno', '=', 'egc_items.unit_id')
            ->join('egc_warehouses', 'egc_warehouses.sno', '=', 'egc_stock.warehouse_id')
            ->leftJoin(
                'egc_item_inventory_settings',
                function ($join) {
                    $join->on('egc_item_inventory_settings.item_id', '=', 'egc_stock.item_id')
                        ->on('egc_item_inventory_settings.warehouse_id', '=', 'egc_stock.warehouse_id');
                }
            )
            ->select(
                'egc_stock.*',

                'egc_items.item_name',
                'egc_items.item_code',

                'egc_units.unit_name',

                'egc_warehouses.warehouse_name',

                'egc_item_inventory_settings.minimum_stock',
                'egc_item_inventory_settings.reorder_level'
            )
            ->where('egc_stock.sno', $id)
            ->where('egc_stock.status', 0)
            ->first();

        if (!$stock) {

            return response()->json([
                'status' => false,
                'message' => 'Stock not found.'
            ],404);

        }

        return response()->json([
            'status' => true,
            'data' => $stock
        ]);
    }

    public function adjustStock(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'stock_id'      => 'required|exists:egc_stock,sno',
            'counted_qty'   => 'required|numeric|min:0',
            'reason'        => 'required|string|max:255',
            'remarks'       => 'nullable|string|max:1000',

        ]);

        if ($validator->fails()) {

            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ],422);

        }

        DB::beginTransaction();

        try {

            $stock = DB::table('egc_stock')
                ->lockForUpdate()
                ->where('sno', $request->stock_id)
                ->first();

            if (!$stock) {

                DB::rollBack();

                return response()->json([
                    'status' => false,
                    'message' => 'Stock not found.'
                ],404);

            }

            $systemQty  = (float)$stock->available_qty;
            $countedQty = (float)$request->counted_qty;
            $variance   = $countedQty - $systemQty;

            /*
            |--------------------------------------------------------------------------
            | Generate Adjustment Code
            |--------------------------------------------------------------------------
            */

            $lastId = DB::table('egc_stock_adjustments')->max('sno') + 1;

            $adjustmentCode = 'ADJ' . str_pad($lastId, 6, '0', STR_PAD_LEFT);

            /*
            |--------------------------------------------------------------------------
            | Save Adjustment History
            |--------------------------------------------------------------------------
            */

            DB::table('egc_stock_adjustments')->insert([

                'adjustment_code' => $adjustmentCode,

                'stock_id'        => $stock->sno,

                'system_qty'      => $systemQty,

                'counted_qty'     => $countedQty,

                'variance_qty'    => $variance,

                'reason'          => $request->reason,

                'remarks'         => $request->remarks,

                'created_by'      => session('user_id'),

                'created_at'      => now(),

                'updated_at'      => now()

            ]);

            /*
            |--------------------------------------------------------------------------
            | Determine Stock Status
            |--------------------------------------------------------------------------
            */

            $stockStatus = 0;

            if ($countedQty <= 0) {

                $stockStatus = 2; // Issued / Empty (change according to your enum)

            }

            /*
            |--------------------------------------------------------------------------
            | Update Stock
            |--------------------------------------------------------------------------
            */

            DB::table('egc_stock')
                ->where('sno', $stock->sno)
                ->update([

                    'available_qty' => $countedQty,

                    'updated_by'    => session('user_id'),

                    'updated_at'    => now(),

                    'stock_status'  => $stockStatus

                ]);

            DB::commit();

            return response()->json([

                'status' => true,

                'message' => 'Stock adjusted successfully.'

            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([

                'status' => false,

                'message' => $e->getMessage()

            ],500);

        }
    }
}