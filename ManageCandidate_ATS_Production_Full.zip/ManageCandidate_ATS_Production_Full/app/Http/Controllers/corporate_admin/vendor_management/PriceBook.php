<?php

namespace App\Http\Controllers\corporate_admin\vendor_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PriceBook extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.vendor_management.price_book');
  }

}
