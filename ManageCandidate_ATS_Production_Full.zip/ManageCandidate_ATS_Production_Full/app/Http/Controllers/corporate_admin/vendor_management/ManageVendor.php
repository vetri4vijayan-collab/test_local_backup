<?php

namespace App\Http\Controllers\corporate_admin\vendor_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VendorModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageVendor extends Controller
{
 

  public function index(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $status = $request->status_filter ?? '';
    $category = $request->category_filter ?? '';
    $tier = $request->tier_filter ?? '';

    $vendors = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id');
        $query = clone $vendors;
        $dashboard = [
          'total' => (clone $query)->count(),
          'active' => (clone $query)->where('egc_vendors.vendor_status_id',2)->count(),
          'hold' => (clone $query)->where('egc_vendors.vendor_status_id',3)->count(),
          'blocked' => (clone $query)->where('egc_vendors.vendor_status_id',4)->count(),
          'pending' => (clone $query)->where('egc_vendors.vendor_status_id',1)->count(),
      ];
        if($search!='')
        {
            $vendors->where(function($q) use($search){

                $q->where('egc_vendors.legal_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.trade_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.vendor_code','LIKE',"%$search%")
                  ->orWhere('egc_vendors.mobile','LIKE',"%$search%")
                  ->orWhere('egc_vendors.email','LIKE',"%$search%")
                  ->orWhere('egc_vendors.gstin','LIKE',"%$search%")
                  ->orWhere('egc_vendors.pan','LIKE',"%$search%");
            });
        }


        if($status!='')
            $vendors->where('egc_vendors.vendor_status_id',$status);

        if($category!='')
            $vendors->where('egc_vendors.category_id',$category);

        if($tier!='')
            $vendors->where('egc_vendors.tier_id',$tier);


        $vendors = $vendors
            ->orderBy('egc_vendors.sno','DESC')
            ->paginate($perpage);

          if($request->ajax()){

            $data=$vendors->map(function($item){
              return [
                'sno'=>$item->sno,
                'vendor_code'=>$item->vendor_code,
                'legal_name'=>$item->legal_name,
                'trade_name'=>$item->trade_name,
                'contact_person'=>$item->contact_person,
                'mobile'=>$item->mobile,
                'email'=>$item->email,
                'category'=>$item->category_name,
                'tier'=>$item->tier_name,
                'sla'=>$item->sla_percentage,
                'rating'=>$item->rating,
                'ytd_spend'=>$item->ytd_spend,
                'status'=>$item->status_name,
                'status_id'=>$item->vendor_status_id
              ];
            });

            return response()->json([
              'data'=>$data,
              'dashboard'=>$dashboard,
              'current_page'=>$vendors->currentPage(),
              'last_page'=>$vendors->lastPage(),
              'total'=>$vendors->total()
            ]);
          }

        $categories=DB::table('egc_vendor_category')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();

        $tiers=DB::table('egc_vendor_tier')
        ->where('status',0)
        ->get();

        $payment_modes =DB::table('egc_payment_modes')
        ->where('status',0)
        ->get();

        $credit_terms  =DB::table('egc_credit_terms')
        ->where('status',0)
        ->get();

        $statuses=DB::table('egc_vendor_status')
        ->where('status',0)
        ->get();

        return view(
        'content.corporate_admin.vendor_management.vendor_list',
        compact(
        'categories',
        'payment_modes',
        'credit_terms',
        'tiers',
        'statuses',
        'perpage',
        'search'
        ));
}
  public function active_vendor(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $status = $request->status_filter ?? '';
    $category = $request->category_filter ?? '';
    $tier = $request->tier_filter ?? '';

    $vendors = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id');
        $query = clone $vendors;
        $dashboard = [
          'total' => (clone $query)->count(),
          'active' => (clone $query)->where('egc_vendors.vendor_status_id',2)->count(),
          'hold' => (clone $query)->where('egc_vendors.vendor_status_id',3)->count(),
          'blocked' => (clone $query)->where('egc_vendors.vendor_status_id',4)->count(),
          'pending' => (clone $query)->where('egc_vendors.vendor_status_id',1)->count(),
      ];
        if($search!='')
        {
            $vendors->where(function($q) use($search){

                $q->where('egc_vendors.legal_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.trade_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.vendor_code','LIKE',"%$search%")
                  ->orWhere('egc_vendors.mobile','LIKE',"%$search%")
                  ->orWhere('egc_vendors.email','LIKE',"%$search%")
                  ->orWhere('egc_vendors.gstin','LIKE',"%$search%")
                  ->orWhere('egc_vendors.pan','LIKE',"%$search%");
            });
        }


        if($status!='')
            $vendors->where('egc_vendors.vendor_status_id',$status);

        if($category!='')
            $vendors->where('egc_vendors.category_id',$category);

        if($tier!='')
            $vendors->where('egc_vendors.tier_id',$tier);


        $vendors = $vendors
            ->where('egc_vendors.vendor_status_id',2)
            ->orderBy('egc_vendors.sno','DESC')
            ->paginate($perpage);

          if($request->ajax()){

            $data=$vendors->map(function($item){
              return [
                'sno'=>$item->sno,
                'vendor_code'=>$item->vendor_code,
                'legal_name'=>$item->legal_name,
                'trade_name'=>$item->trade_name,
                'contact_person'=>$item->contact_person,
                'mobile'=>$item->mobile,
                'email'=>$item->email,
                'category'=>$item->category_name,
                'tier'=>$item->tier_name,
                'sla'=>$item->sla_percentage,
                'rating'=>$item->rating,
                'ytd_spend'=>$item->ytd_spend,
                'status'=>$item->status_name,
                'status_id'=>$item->vendor_status_id
              ];
            });

            return response()->json([
              'data'=>$data,
              'dashboard'=>$dashboard,
              'current_page'=>$vendors->currentPage(),
              'last_page'=>$vendors->lastPage(),
              'total'=>$vendors->total()
            ]);
          }

        $categories=DB::table('egc_vendor_category')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();

        $tiers=DB::table('egc_vendor_tier')
        ->where('status',0)
        ->get();

        $payment_modes =DB::table('egc_payment_modes')
        ->where('status',0)
        ->get();

        $credit_terms  =DB::table('egc_credit_terms')
        ->where('status',0)
        ->get();

        $statuses=DB::table('egc_vendor_status')
        ->where('status',0)
        ->get();

        return view(
        'content.corporate_admin.vendor_management.active_vendor_list',
        compact(
        'categories',
        'payment_modes',
        'credit_terms',
        'tiers',
        'statuses',
        'perpage',
        'search'
        ));
}

 
  public function onhold_vendor(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $status = $request->status_filter ?? '';
    $category = $request->category_filter ?? '';
    $tier = $request->tier_filter ?? '';

    $vendors = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id');
        $query = clone $vendors;
        $dashboard = [
          'total' => (clone $query)->count(),
          'active' => (clone $query)->where('egc_vendors.vendor_status_id',2)->count(),
          'hold' => (clone $query)->where('egc_vendors.vendor_status_id',3)->count(),
          'blocked' => (clone $query)->where('egc_vendors.vendor_status_id',4)->count(),
          'pending' => (clone $query)->where('egc_vendors.vendor_status_id',1)->count(),
      ];
        if($search!='')
        {
            $vendors->where(function($q) use($search){

                $q->where('egc_vendors.legal_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.trade_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.vendor_code','LIKE',"%$search%")
                  ->orWhere('egc_vendors.mobile','LIKE',"%$search%")
                  ->orWhere('egc_vendors.email','LIKE',"%$search%")
                  ->orWhere('egc_vendors.gstin','LIKE',"%$search%")
                  ->orWhere('egc_vendors.pan','LIKE',"%$search%");
            });
        }


        if($status!='')
            $vendors->where('egc_vendors.vendor_status_id',$status);

        if($category!='')
            $vendors->where('egc_vendors.category_id',$category);

        if($tier!='')
            $vendors->where('egc_vendors.tier_id',$tier);


        $vendors = $vendors
            ->where('egc_vendors.vendor_status_id',3)
            ->orderBy('egc_vendors.sno','DESC')
            ->paginate($perpage);

          if($request->ajax()){

            $data=$vendors->map(function($item){
              return [
                'sno'=>$item->sno,
                'vendor_code'=>$item->vendor_code,
                'legal_name'=>$item->legal_name,
                'trade_name'=>$item->trade_name,
                'contact_person'=>$item->contact_person,
                'mobile'=>$item->mobile,
                'email'=>$item->email,
                'category'=>$item->category_name,
                'tier'=>$item->tier_name,
                'sla'=>$item->sla_percentage,
                'rating'=>$item->rating,
                'ytd_spend'=>$item->ytd_spend,
                'status'=>$item->status_name,
                'status_id'=>$item->vendor_status_id
              ];
            });

            return response()->json([
              'data'=>$data,
              'dashboard'=>$dashboard,
              'current_page'=>$vendors->currentPage(),
              'last_page'=>$vendors->lastPage(),
              'total'=>$vendors->total()
            ]);
          }

        $categories=DB::table('egc_vendor_category')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();

        $tiers=DB::table('egc_vendor_tier')
        ->where('status',0)
        ->get();

        $payment_modes =DB::table('egc_payment_modes')
        ->where('status',0)
        ->get();

        $credit_terms  =DB::table('egc_credit_terms')
        ->where('status',0)
        ->get();

        $statuses=DB::table('egc_vendor_status')
        ->where('status',0)
        ->get();

        return view(
        'content.corporate_admin.vendor_management.onhold_vendor_list',
        compact(
        'categories',
        'payment_modes',
        'credit_terms',
        'tiers',
        'statuses',
        'perpage',
        'search'
        ));
}

 
  public function block_vendor(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $status = $request->status_filter ?? '';
    $category = $request->category_filter ?? '';
    $tier = $request->tier_filter ?? '';

    $vendors = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id');
        $query = clone $vendors;
        $dashboard = [
          'total' => (clone $query)->count(),
          'active' => (clone $query)->where('egc_vendors.vendor_status_id',2)->count(),
          'hold' => (clone $query)->where('egc_vendors.vendor_status_id',3)->count(),
          'blocked' => (clone $query)->where('egc_vendors.vendor_status_id',4)->count(),
          'pending' => (clone $query)->where('egc_vendors.vendor_status_id',1)->count(),
      ];
        if($search!='')
        {
            $vendors->where(function($q) use($search){

                $q->where('egc_vendors.legal_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.trade_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.vendor_code','LIKE',"%$search%")
                  ->orWhere('egc_vendors.mobile','LIKE',"%$search%")
                  ->orWhere('egc_vendors.email','LIKE',"%$search%")
                  ->orWhere('egc_vendors.gstin','LIKE',"%$search%")
                  ->orWhere('egc_vendors.pan','LIKE',"%$search%");
            });
        }


        if($status!='')
            $vendors->where('egc_vendors.vendor_status_id',$status);

        if($category!='')
            $vendors->where('egc_vendors.category_id',$category);

        if($tier!='')
            $vendors->where('egc_vendors.tier_id',$tier);


        $vendors = $vendors
            ->where('egc_vendors.vendor_status_id',4)
            ->orderBy('egc_vendors.sno','DESC')
            ->paginate($perpage);

          if($request->ajax()){

            $data=$vendors->map(function($item){
              return [
                'sno'=>$item->sno,
                'vendor_code'=>$item->vendor_code,
                'legal_name'=>$item->legal_name,
                'trade_name'=>$item->trade_name,
                'contact_person'=>$item->contact_person,
                'mobile'=>$item->mobile,
                'email'=>$item->email,
                'category'=>$item->category_name,
                'tier'=>$item->tier_name,
                'sla'=>$item->sla_percentage,
                'rating'=>$item->rating,
                'ytd_spend'=>$item->ytd_spend,
                'status'=>$item->status_name,
                'status_id'=>$item->vendor_status_id
              ];
            });

            return response()->json([
              'data'=>$data,
              'dashboard'=>$dashboard,
              'current_page'=>$vendors->currentPage(),
              'last_page'=>$vendors->lastPage(),
              'total'=>$vendors->total()
            ]);
          }

        $categories=DB::table('egc_vendor_category')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();

        $tiers=DB::table('egc_vendor_tier')
        ->where('status',0)
        ->get();

        $payment_modes =DB::table('egc_payment_modes')
        ->where('status',0)
        ->get();

        $credit_terms  =DB::table('egc_credit_terms')
        ->where('status',0)
        ->get();

        $statuses=DB::table('egc_vendor_status')
        ->where('status',0)
        ->get();

        return view(
        'content.corporate_admin.vendor_management.block_vendor_list',
        compact(
        'categories',
        'payment_modes',
        'credit_terms',
        'tiers',
        'statuses',
        'perpage',
        'search'
        ));
}

  public function pending_vendor(Request $request)
{
    $page = $request->page ?? 1;
    $perpage = $request->sorting_filter ?? 25;

    $search = $request->search_filter ?? '';
    $status = $request->status_filter ?? '';
    $category = $request->category_filter ?? '';
    $tier = $request->tier_filter ?? '';

    $vendors = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id');
        $query = clone $vendors;
        $dashboard = [
          'total' => (clone $query)->count(),
          'active' => (clone $query)->where('egc_vendors.vendor_status_id',2)->count(),
          'hold' => (clone $query)->where('egc_vendors.vendor_status_id',3)->count(),
          'blocked' => (clone $query)->where('egc_vendors.vendor_status_id',4)->count(),
          'pending' => (clone $query)->where('egc_vendors.vendor_status_id',1)->count(),
      ];
        if($search!='')
        {
            $vendors->where(function($q) use($search){

                $q->where('egc_vendors.legal_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.trade_name','LIKE',"%$search%")
                  ->orWhere('egc_vendors.vendor_code','LIKE',"%$search%")
                  ->orWhere('egc_vendors.mobile','LIKE',"%$search%")
                  ->orWhere('egc_vendors.email','LIKE',"%$search%")
                  ->orWhere('egc_vendors.gstin','LIKE',"%$search%")
                  ->orWhere('egc_vendors.pan','LIKE',"%$search%");
            });
        }


        if($status!='')
            $vendors->where('egc_vendors.vendor_status_id',$status);

        if($category!='')
            $vendors->where('egc_vendors.category_id',$category);

        if($tier!='')
            $vendors->where('egc_vendors.tier_id',$tier);


        $vendors = $vendors
        ->where('egc_vendors.vendor_status_id',1)
            ->orderBy('egc_vendors.sno','DESC')
            ->paginate($perpage);

          if($request->ajax()){

            $data=$vendors->map(function($item){
              return [
                'sno'=>$item->sno,
                'vendor_code'=>$item->vendor_code,
                'legal_name'=>$item->legal_name,
                'trade_name'=>$item->trade_name,
                'contact_person'=>$item->contact_person,
                'mobile'=>$item->mobile,
                'email'=>$item->email,
                'category'=>$item->category_name,
                'tier'=>$item->tier_name,
                'sla'=>$item->sla_percentage,
                'rating'=>$item->rating,
                'ytd_spend'=>$item->ytd_spend,
                'status'=>$item->status_name,
                'status_id'=>$item->vendor_status_id
              ];
            });

            return response()->json([
              'data'=>$data,
              'dashboard'=>$dashboard,
              'current_page'=>$vendors->currentPage(),
              'last_page'=>$vendors->lastPage(),
              'total'=>$vendors->total()
            ]);
          }

        $categories=DB::table('egc_vendor_category')
        ->where('status',0)
        ->orderBy('sort_order')
        ->get();

        $tiers=DB::table('egc_vendor_tier')
        ->where('status',0)
        ->get();

        $payment_modes =DB::table('egc_payment_modes')
        ->where('status',0)
        ->get();

        $credit_terms  =DB::table('egc_credit_terms')
        ->where('status',0)
        ->get();

        $statuses=DB::table('egc_vendor_status')
        ->where('status',0)
        ->get();

        return view(
        'content.corporate_admin.vendor_management.pending_vendor_list',
        compact(
        'categories',
        'payment_modes',
        'credit_terms',
        'tiers',
        'statuses',
        'perpage',
        'search'
        ));
}

 

  public function print()
  {
    return view('content.corporate_admin.vendor_management.quotation_print');
  }


  public function changeStatus(Request $request)
{
    DB::beginTransaction();

    try {

        $validator = Validator::make($request->all(), [
            'sno'    => 'required|integer|exists:egc_vendors,sno',
            'status' => 'required|integer|exists:egc_vendor_status,sno'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Failed.',
                'errors' => $validator->errors()
            ]);
        }
         $user_id = $request->user()->user_id ?? 0;
        $vendor = VendorModel::where('sno', $request->sno)->first();

        if (!$vendor) {
            return response()->json([
                'status' => 404,
                'message' => 'Vendor not found.'
            ]);
        }

        if ($vendor->vendor_status_id == $request->status) {
            return response()->json([
                'status' => 409,
                'message' => 'Vendor is already in this status.'
            ]);
        }

        DB::table('egc_vendor_status_history')->insert([
            'vendor_id'  => $vendor->sno,
            'old_status' => $vendor->vendor_status_id,
            'new_status' => $request->status,
            'reason_id'  => null,
            'remarks'    => null,
            'changed_by' => $user_id,
            'changed_at' => Carbon::now()
        ]);

        $vendor->vendor_status_id = $request->status;
        $vendor->updated_by = $user_id;
        $vendor->save();

        DB::commit();

        return response()->json([
            'status' => 200,
            'message' => 'Vendor status updated successfully.'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json([
            'status' => 500,
            'message' => 'Something went wrong.',
            'error' => $e->getMessage()
        ]);
    }
}


public function viewVendor($id)
{
    $vendor = VendorModel::select(
            'egc_vendors.*',
            'egc_vendor_category.category_name',
            'egc_vendor_tier.tier_name',
            'egc_payment_modes.payment_mode',
            'egc_credit_terms.credit_name',
            'egc_vendor_status.status_name'
        )
        ->leftJoin('egc_vendor_category','egc_vendor_category.sno','=','egc_vendors.category_id')
        ->leftJoin('egc_vendor_tier','egc_vendor_tier.sno','=','egc_vendors.tier_id')
        ->leftJoin('egc_payment_modes','egc_payment_modes.sno','=','egc_vendors.payment_mode_id')
        ->leftJoin('egc_credit_terms','egc_credit_terms.sno','=','egc_vendors.credit_term_id')
        ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id')
        ->where('egc_vendors.sno',$id)
        ->first();

    if(!$vendor){
        return response()->json([
            'status'=>404,
            'message'=>'Vendor not found'
        ]);
    }

    $bank = DB::table('egc_vendor_bank_accounts')
        ->where('vendor_id',$id)
        ->where('is_primary',1)
        ->first();

    return response()->json([
        'status'=>200,
        'vendor'=>$vendor,
        'bank'=>$bank
    ]);
}

    public function Add(Request $request)
    {
        DB::beginTransaction();

        try {

            $validator = Validator::make($request->all(), [
                'legal_name'        => 'required|max:150',
                'trade_name'        => 'required|max:150',
                'contact_person'    => 'required|max:100',
                'mobile'            => 'required|digits:10',
                'email'             => 'nullable|email',
                'gstin'             => 'required|size:15',
                'pan'               => 'required|size:10',
                'category_id'       => 'required',
                'tier_id'           => 'required',
                'payment_mode_id'   => 'required',
                'credit_term_id'    => 'required',
                'address'           => 'required',
                'bank_name'         => 'required',
                'branch_name'       => 'required',
                'account_holder'    => 'required',
                'account_number'    => 'required',
                'ifsc_code'         => 'required'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors()
                ],422);

            }

            $user_id = $request->user()->user_id ?? 0;
            if(VendorModel::where('gstin',$request->gstin)->where('status',0)->exists()){
                return response()->json([
                    'status'=>false,
                    'message'=>'GSTIN already exists.'
                ],422);
            }

            if(VendorModel::where('pan',$request->pan)->where('status',0)->exists()){
                return response()->json([
                    'status'=>false,
                    'message'=>'PAN already exists.'
                ],422);
            }

            if(VendorModel::where('mobile',$request->mobile)->where('status',0)->exists()){
                return response()->json([
                    'status'=>false,
                    'message'=>'Mobile Number already exists.'
                ],422);
            }

            $lastVendor = VendorModel::orderByDesc('sno')->first();

            $nextNumber = 1;

            if($lastVendor){
                $nextNumber = $lastVendor->sno + 1;
            }

            $vendor_code = 'VEN'.str_pad($nextNumber,6,'0',STR_PAD_LEFT);

            $vendor = new VendorModel();
            $vendor->vendor_code      = $vendor_code;
            $vendor->legal_name       = strtoupper($request->legal_name);
            $vendor->trade_name       = strtoupper($request->trade_name);
            $vendor->contact_person   = strtoupper($request->contact_person);
            $vendor->mobile           = $request->mobile;
            $vendor->email            = strtolower($request->email);
            $vendor->gstin            = strtoupper($request->gstin);
            $vendor->pan              = strtoupper($request->pan);
            $vendor->category_id      = $request->category_id;
            $vendor->tier_id          = $request->tier_id;
            $vendor->payment_mode_id  = $request->payment_mode_id;
            $vendor->credit_term_id   = $request->credit_term_id;
            $vendor->vendor_status_id = 1;
            $vendor->address          = $request->address;
            $vendor->sla_percentage   = 0;
            $vendor->rating           = 0;
            $vendor->ytd_spend        = 0;
            $vendor->remarks          = $request->remarks;
            $vendor->created_by       = $user_id;
            $vendor->updated_by       = $user_id;
            $vendor->save();

            $bank = new VendorBankAccountModel();
            $bank->vendor_id = $vendor->sno;
            $bank->bank_name = $request->bank_name;
            $bank->branch_name = $request->branch_name;
            $bank->account_holder = strtoupper($request->account_holder);
            $bank->account_number = $request->account_number;
            $bank->ifsc_code = strtoupper($request->ifsc_code);
            $bank->upi_id = $request->upi_id;
            $bank->is_primary = 1;
            $bank->status = 0;
            $bank->save();

            DB::table('egc_vendor_scorecard')->insert([
                'vendor_id'         => $vendor->sno,
                'delivery_score'    => 0.00,
                'quality_score'     => 0.00,
                'compliance_score'  => 0.00,
                'response_score'    => 0.00,
                'price_score'       => 0.00,
                'service_score'     => 0.00,
                'composite_score'   => 0.00,
                'review_date'       => now()->toDateString(),
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);


            DB::table('egc_vendor_status_history')->insert([
                'vendor_id'=>$vendor->sno,
                'old_status'=>null,
                'new_status'=>1,
                'reason_id'=>null,
                'remarks'=>'Vendor Created',
                'changed_by'=>$user_id,
                'changed_at'=>now()
            ]);

            DB::commit();

            return response()->json([
                'status'=>200,
                'message'=>'Vendor Added Successfully.'
            ]);

        }catch(\Exception $e){

            DB::rollBack();
            return response()->json([
                'status'=>500,
                'message'=>'Unable to save Vendor.',
                'error'=>$e->getMessage()
            ],500);
        }
    }

    public function edit($id)
    {
        $vendor = VendorModel::select(
                'egc_vendors.*',
                'egc_vendor_bank_accounts.bank_name',
                'egc_vendor_bank_accounts.branch_name',
                'egc_vendor_bank_accounts.account_holder',
                'egc_vendor_bank_accounts.account_number',
                'egc_vendor_bank_accounts.ifsc_code',
                'egc_vendor_bank_accounts.upi_id'
            )
            ->leftJoin(
                'egc_vendor_bank_accounts',
                'egc_vendor_bank_accounts.vendor_id',
                '=',
                'egc_vendors.sno'
            )
            ->where('egc_vendors.sno',$id)
            ->first();

        if(!$vendor){

            return response()->json([
                'status'=>404,
                'message'=>'Vendor not found.'
            ]);

        }

        return response()->json([
            'status'=>200,
            'data'=>$vendor
        ]);
    }


    public function Update(Request $request)
    {
        DB::beginTransaction();

        try{

            $validator=Validator::make($request->all(),[
                'vendor_edit_id'=>'required',
                'legal_name'=>'required',
                'trade_name'=>'required',
                'contact_person'=>'required',
                'mobile'=>'required',
                'gstin'=>'required',
                'pan'=>'required',
                'category_id'=>'required',
                'tier_id'=>'required',
                'payment_mode_id'=>'required',
                'credit_term_id'=>'required',
                'address'=>'required',
                'bank_name'=>'required',
                'branch_name'=>'required',
                'account_holder'=>'required',
                'account_number'=>'required',
                'ifsc_code'=>'required'

            ]);

            if($validator->fails()){
                return response()->json([
                    'status'=>422,
                    'message'=>$validator->errors()->first()
                ],422);

            }

            $user_id = $request->user()->user_id ?? 0;

            $vendor=VendorModel::findOrFail($request->vendor_edit_id);

            if(VendorModel::where('gstin',$request->gstin)->where('sno','!=',$vendor->sno)->exists()){
                return response()->json([
                    'status'=>422,
                    'message'=>'GSTIN already exists.'
                ]);
            }

            if(VendorModel::where('pan',$request->pan)->where('sno','!=',$vendor->sno)->exists()){
                return response()->json([
                    'status'=>422,
                    'message'=>'PAN already exists.'
                ]);
            }

            if(
                VendorModel::where('mobile',$request->mobile)
                ->where('sno','!=',$vendor->sno)
                ->exists()
            ){

                return response()->json([
                    'status'=>422,
                    'message'=>'Mobile already exists.'
                ]);

            }

            $vendor->legal_name=strtoupper($request->legal_name);
            $vendor->trade_name=strtoupper($request->trade_name);
            $vendor->contact_person=strtoupper($request->contact_person);

            $vendor->mobile=$request->mobile;
            $vendor->email=$request->email;

            $vendor->gstin=strtoupper($request->gstin);
            $vendor->pan=strtoupper($request->pan);

            $vendor->category_id=$request->category_id;
            $vendor->tier_id=$request->tier_id;
            $vendor->payment_mode_id=$request->payment_mode_id;
            $vendor->credit_term_id=$request->credit_term_id;

            $vendor->address=$request->address;
            $vendor->remarks=$request->remarks;
            $vendor->updated_by=$user_id;

            $vendor->save();

            VendorBankAccountModel::where('vendor_id',$vendor->sno)
            ->update([
                'bank_name'=>$request->bank_name,
                'branch_name'=>$request->branch_name,
                'account_holder'=>strtoupper($request->account_holder),
                'account_number'=>$request->account_number,
                'ifsc_code'=>strtoupper($request->ifsc_code),
                'upi_id'=>$request->upi_id

            ]);

            DB::commit();

            return response()->json([
                'status'=>200,
                'message'=>'Vendor Updated Successfully.'

            ]);

        }
        catch(\Exception $e){

            DB::rollBack();

            return response()->json([
                'status'=>500,
                'message'=>'Unable to update vendor.',
                'error'=>$e->getMessage()
            ],500);

        }

    }

    public function scorecard($id)
    {
        $data = DB::table('egc_vendors')
            ->leftJoin('egc_vendor_status','egc_vendor_status.sno','=','egc_vendors.vendor_status_id')
            ->leftJoin('egc_vendor_scorecard','egc_vendor_scorecard.vendor_id','=','egc_vendors.sno')
            ->select(
                'egc_vendors.legal_name',
                'egc_vendors.contact_person',
                'egc_vendors.mobile',

                'egc_vendor_status.status_name',

                'egc_vendor_scorecard.delivery_score',
                'egc_vendor_scorecard.quality_score',
                'egc_vendor_scorecard.compliance_score',
                'egc_vendor_scorecard.response_score',
                'egc_vendor_scorecard.price_score',
                'egc_vendor_scorecard.service_score',
                'egc_vendor_scorecard.composite_score',
                'egc_vendor_scorecard.disputes',
                'egc_vendor_scorecard.review_date'
            )
            ->where('egc_vendors.sno',$id)
            ->first();

        if(!$data){
            return response()->json([
                'status'=>404,
                'message'=>'Vendor not found.'
            ]);

        }

        return response()->json([
            'status'=>200,
            'data'=>$data
        ]);
    }
}
