<?php

namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageEvent extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.schedule_management.event_list');
  }
  public function calender()
  {
    return view('content.corporate_admin.schedule_management.event_calender');
  }
  public function add()
  {
    return view('content.corporate_admin.schedule_management.event_add');
  }
  public function edit()
  {
    return view('content.corporate_admin.schedule_management.event_edit');
  }
  public function day()
  {
    return view('content.corporate_admin.schedule_management.event_day_view');
  }
}
