<?php

namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ConferenceSupport extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.schedule_management.conference_support_list');
  }

  public function calendar_view()
  {
    return view('content.corporate_admin.schedule_management.conference_calendar_view');
  }


  public function day_view()
  {
    return view('content.corporate_admin.schedule_management.conference_day_view');
  }

}
