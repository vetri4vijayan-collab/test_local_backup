<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageYerd extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.Policies_and_yerd.manage_Yerd.list_yerd');
  }
}
