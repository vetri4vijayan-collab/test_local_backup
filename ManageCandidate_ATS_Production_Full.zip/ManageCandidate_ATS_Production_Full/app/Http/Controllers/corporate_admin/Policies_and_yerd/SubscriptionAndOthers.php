<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SubscriptionAndOthers extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.Policies_and_yerd.subscription_and_others.subscription_list');
  }

}
