<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RenewalCalendar extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.Policies_and_yerd.renewal_calendar.renewal_calendar_list');
  }
}
