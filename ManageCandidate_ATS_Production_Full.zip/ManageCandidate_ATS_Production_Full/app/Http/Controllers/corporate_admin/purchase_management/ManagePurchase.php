<?php

namespace App\Http\Controllers\corporate_admin\purchase_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManagePurchase extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.purchase_list');
    }

    public function pendingapproval()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.pending_approval');
    }
    public function approved()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.approved');
    }
    public function inrfq()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.inrfq');
    }
    public function onpo()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.onpo');
    }
    public function closed()
    {
        return view('content.corporate_admin.purchase_management.manage_purchase.closed');
    }
    public function print()
    {
      return view('content.corporate_admin.purchase_management.manage_purchase.purchase_quotation');
    }
}