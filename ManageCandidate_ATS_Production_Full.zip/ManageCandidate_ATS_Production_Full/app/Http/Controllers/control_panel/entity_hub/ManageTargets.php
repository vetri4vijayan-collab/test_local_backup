<?php

namespace App\Http\Controllers\control_panel\entity_hub;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;
use App\Models\TargetExportExcel;


class ManageTargets extends Controller
{



    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $year = $request->year ?? date('Y');

        $Company = DB::table('egc_entity_yearly_targets')->where('egc_entity_yearly_targets.status', '!=', 2)
            ->select(
                'egc_entity_yearly_targets.*',
                'egc_entity.entity_name',
                'egc_entity.company_id',
                'egc_entity.entity_base_url',
                'egc_entity.entity_base_color',
                'egc_entity.entity_short_name',
                'egc_entity.entity_logo',
                'egc_entity.entity_favicon',
                'egc_branch.branch_name',
            )
            ->where('egc_entity_yearly_targets.year', $year)
            ->join('egc_entity', 'egc_entity_yearly_targets.entity_id', 'egc_entity.sno')
            ->join('egc_company', 'egc_entity.company_id', 'egc_company.sno')
            ->join('egc_branch', 'egc_entity_yearly_targets.branch_id', 'egc_branch.sno');

        if ($search_filter != '') {
            $Company->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_branch.branch_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $Company = $Company->orderBy('egc_entity_yearly_targets.id', 'asc')->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Company->map(function ($item) use ($helper) {

                $quarter_count = DB::table('egc_entity_quarter_targets')->where('yearly_id', $item->id)->where('status', '!=', 2)->count();
                $quarterData = QuarterTargetModel::with([
                    'months.weeks'
                ])
                    ->where('yearly_id', $item->id)
                    ->where('status', '!=', 2)
                    ->get();
                return [
                    'sno' => $item->id,
                    'status' => $item->status,
                    'entity_name' => $item->entity_name,
                    'quarter_count' => $quarter_count,
                    'entity_logo' => $item->entity_logo,
                    'company_id' => $item->company_id,
                    'entity_favicon' => $item->entity_favicon,
                    'entity_short_name' => $item->entity_short_name,
                    'entity_base_color' => $item->entity_base_color,
                    'year' => $item->year,
                    'next_year' => (string)((int)$item->year + 1),
                    'total_target' => $item->total_target,
                    'total_pre_sale' => $item->total_pre_sale,
                    'total_post_sale' => $item->total_post_sale,
                    'data' => $item,
                    'quarterData' => $quarterData,
                    'company_encode' => base64_encode($item->id),
                    'encrypted_id' => $helper->encrypt_decrypt($item->id, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Company->currentPage(),
                'last_page' => $Company->lastPage(),
                'total' => $Company->total(),
            ]);
        }

        $entity_list = ManageEntityModel::where('status', 0)->get();

        return view('content.control_panel.entity_hub.manage_targets.targets', [
            'Company' => $Company,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'entity_list' => $entity_list,

        ]);
    }
    public function edit_target(Request $request)
    {
        $entity_list = ManageEntityModel::where('status', 0)->get();
        $week_settings = TargetWeekSettingModel::where('status', 0)
            ->orderBy('week_no')
            ->get();
        return view('content.control_panel.entity_hub.manage_targets.update_targets', compact('entity_list', 'week_settings'));
    }

    public function import(Request $request)
    {
        $file = $request->file('file_upload');

        $spreadsheet = IOFactory::load($file->getPathname());

        $sheetNames = $spreadsheet->getSheetNames();

        $year = null;

        // ✅ FIND SUMMARY SHEET
        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {

                $summarySheet = $spreadsheet->getSheet($index);
                $rows = $summarySheet->toArray();

                // 👉 adjust based on your summary format
                foreach ($rows as $row) {
                    foreach ($row as $cell) {

                        if (preg_match('/20\d{2}/', $cell, $matches)) {
                            $year = (int)$matches[0];
                            break 2;
                        }
                    }
                }
            }
        }

        if (!$year) {
            throw new \Exception('Year not found in summary sheet');
        }

        // ================= MULTI SHEET =================
        $sheets = [];
        $entityCounter = 1;

        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {
                continue;
            }

            // ✅ PASS YEAR HERE
            $sheets[$index] = new TargetSheetImport($entityCounter, $year);

            $entityCounter++;
        }

        Excel::import(new class($sheets) implements WithMultipleSheets {

            private $sheets;

            public function __construct($sheets)
            {
                $this->sheets = $sheets;
            }

            public function sheets(): array
            {
                return $this->sheets;
            }
        }, $file);

        return response()->json(['success' => true]);
    }

    public function preview(Request $request)
    {
        $data = Excel::toArray([], $request->file('file'));

        return response()->json($data[0]);
    }



    public function getData(Request $request)
    {
        $query = WeekTargetModel::with([
            'month.quarter.yearly'
        ])
            ->whereHas('month.quarter.yearly', function ($q) use ($request) {
                $q->where('year', $request->year)
                    ->where('branch_id', $request->branch_id);
            });

        $data = $query->get();

        return response()->json([
            'data' => $data,
            'is_existing' => $data->isNotEmpty() // ✅ KEY FLAG
        ]);
    }




    public function saveData(Request $request)
    {
        DB::beginTransaction();

        try {

            $yearCache = [];
            $quarterCache = [];
            $monthCache = [];

            $affectedYearIds = [];
            $affectedQuarterIds = [];
            $affectedMonthIds = [];
            $payloads = [];
            $entityId = null;

            $branch_id = $request->branch_id;
            $entity_id = $request->entity_id;
            $branchData = DB::table('egc_branch')->where('sno', $branch_id)->first();
            $erp_branch_id = $branchData ? $branchData->erp_branch_id : 1;

            foreach ($request->data as $row) {

                // $monthNumber = Carbon::parse("1 " . $row['month'])->month;
                $monthNumber = Carbon::parse("1 " . $row['month'])->month;

                // ✅ Financial Year Fix
                $actualYear = $row['year'];

                if (in_array($monthNumber, [1, 2, 3])) {
                    $actualYear = $row['year'] + 1;
                }

                $yearKey = $row['company'] . '_' . $row['year'];

                //  YEAR CACHE
                if (!isset($yearCache[$yearKey])) {
                    $yearCache[$yearKey] = YearlyTargetModel::firstOrCreate(
                        [
                            'entity_id' => $entity_id,
                            'branch_id' => $branch_id,
                            'year' => $row['year']
                        ]
                    );
                }
                $yearly = $yearCache[$yearKey];
                $affectedYearIds[$yearly->id] = $yearly->id;

                //  QUARTER CACHE
                $quarterKey = $yearly->id . '_' . $row['quarter'];



                if (!isset($quarterCache[$quarterKey])) {


                    $financial_year_id = $row['quarter'];


                    $quarterCache[$quarterKey] = QuarterTargetModel::firstOrCreate(
                        [
                            'yearly_id' => $yearly->id,
                            'quarter' => $row['quarter'],
                            'financial_year_id' => $row['quarter'],
                            'financial_year' => $actualYear,
                        ]
                    );
                }
                $quarter = $quarterCache[$quarterKey];
                $affectedQuarterIds[$quarter->id] = $quarter->id;

                //  MONTH CACHE
                $monthKey = $quarter->id . '_' . $monthNumber;



                if (!isset($monthCache[$monthKey])) {
                    $monthCache[$monthKey] = MonthTargetModel::firstOrCreate(
                        [
                            'quarter_id' => $quarter->id,
                            'month' => $monthNumber
                        ]
                    );
                }
                $month = $monthCache[$monthKey];
                $affectedMonthIds[$month->id] = $month->id;


                $weekSettings = DB::table('egc_target_week_settings')
                    ->where('status', 0)
                    ->where('week_no',$row['week'])
                    ->first();
               
                //  WEEK
                // [$startDate, $endDate] = $this->getWeekDates($monthNumber, $row['year'], $row['week']);
                // [$startDate, $endDate] = $this->getWeekDates($monthNumber, $actualYear, $row['week']);
                [$startDate, $endDate] = $this->getWeekDatesFromSetting($monthNumber, $actualYear, $weekSettings);

                WeekTargetModel::updateOrCreate(
                    [
                        'month_id' => $month->id,
                        'week' => $row['week']
                    ],
                    [
                        'percentage' => $row['percentage'],
                        'target_amount' => $row['target'],
                        'pre_sale' => $row['pre_sale'],
                        'post_sale' => $row['post_sale'],
                        'week_start_date' => $startDate,
                        'week_end_date' => $endDate
                    ]
                );


                $monthKeyForPayload = $row['company'] . '_' . $row['year'] . '_' . $monthNumber;

                if (!isset($payloads[$monthKeyForPayload])) {
                    $payloads[$monthKeyForPayload] = [
                        'entity_id' => $entity_id,
                        'branch_id' => $erp_branch_id,
                        'year' => $row['year'],
                        'month' => $monthNumber,
                        'quarter' => $financial_year_id,
                        // 'date' => Carbon::create($row['year'], $monthNumber, 1)->toDateString(),
                        'date' => Carbon::create($actualYear, $monthNumber, 1)->toDateString(),

                        'monthly_target' => 0,
                        'pre_sale' => 0,
                        'post_sale' => 0,

                        'weeks' => []
                    ];
                }


                $payloads[$monthKeyForPayload]['weeks'][] = [
                    'week' => $row['week'],
                    'percentage' => $row['percentage'],
                    'target_amount' => $row['target'],
                    'pre_sale' => $row['pre_sale'],
                    'post_sale' => $row['post_sale'],
                    'start_day' => $startDate,
                    'end_day' => $endDate,
                ];


                // ACCUMULATE TOTALS
                $payloads[$monthKeyForPayload]['monthly_target'] += $row['target'];
                $payloads[$monthKeyForPayload]['pre_sale'] += $row['pre_sale'];
                $payloads[$monthKeyForPayload]['post_sale'] += $row['post_sale'];
            }

            //  ONLY UPDATE AFFECTED DATA
            $this->updateTotalsOptimized($affectedMonthIds, $affectedQuarterIds, $affectedYearIds);

            if (!empty($payloads)) {
                $firstPayload = reset($payloads);
                $entityId = $firstPayload['entity_id'];
            }




            DB::commit();

            $this->dispatchWebhooks([
                'entity_id' => $entity_id,
                'targets' => array_values($payloads)
            ], 1, 'UPDATE_TARGET_HOOK');

            return response()->json(['status' => true]);
        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'msg' => $e->getMessage()
            ]);
        }
    }



    private function updateTotalsOptimized($monthIds, $quarterIds, $yearIds)
    {
        //  MONTH TOTALS (single query)
        $monthTotals = WeekTargetModel::whereIn('month_id', $monthIds)
            ->groupBy('month_id')
            ->selectRaw('month_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($monthTotals as $m) {
            MonthTargetModel::where('id', $m->month_id)->update([
                'target_amount' => $m->t ?? 0,
                'pre_sale' => $m->pre ?? 0,
                'post_sale' => $m->post ?? 0,
            ]);
        }

        //  QUARTER TOTALS
        $quarterTotals = MonthTargetModel::whereIn('quarter_id', $quarterIds)
            ->groupBy('quarter_id')
            ->selectRaw('quarter_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($quarterTotals as $q) {
            QuarterTargetModel::where('id', $q->quarter_id)->update([
                'target_amount' => $q->t ?? 0,
                'pre_sale' => $q->pre ?? 0,
                'post_sale' => $q->post ?? 0,
            ]);
        }

        //  YEAR TOTALS
        $yearTotals = QuarterTargetModel::whereIn('yearly_id', $yearIds)
            ->groupBy('yearly_id')
            ->selectRaw('yearly_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($yearTotals as $y) {
            YearlyTargetModel::where('id', $y->yearly_id)->update([
                'total_target' => $y->t ?? 0,
                'total_pre_sale' => $y->pre ?? 0,
                'total_post_sale' => $y->post ?? 0,
            ]);
        }
    }

    private function getWeekDatesFromSetting(
        $monthNumber,
        $year,
        $setting
    ) {

        $startDay = (int) $setting->start_day;

       

        if ($setting->end_day === 'END') {

            $endDay = Carbon::create(
                $year,
                $monthNumber
            )->endOfMonth()->day;
        } else {

            $endDay = (int) $setting->end_day;
        }

        
        $startDate = Carbon::create(
            $year,
            $monthNumber,
            $startDay
        )->toDateString();

        $endDate = Carbon::create(
            $year,
            $monthNumber,
            $endDay
        )->toDateString();

        return [$startDate, $endDate];
    }

    private function getWeekDates($monthNumber, $year, $week)
    {
        $startDay = match ($week) {
            1 => 1,
            2 => 8,
            3 => 15,
            4 => 22,
            default => 1
        };

        $endDay = match ($week) {
            1 => 7,
            2 => 14,
            3 => 21,
            4 => \Carbon\Carbon::create($year, $monthNumber)->endOfMonth()->day,
            default => 7
        };

        $start = \Carbon\Carbon::create($year, $monthNumber, $startDay)->toDateString();
        $end   = \Carbon\Carbon::create($year, $monthNumber, $endDay)->toDateString();

        return [$start, $end];
    }


    // dispatch webhook
    protected function dispatchWebhooks($broadcast, $userId = 1, $dispatchHook)
    {
        $uuid = (string) \Str::uuid();
        $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module', $dispatchHook)->where('entity_id', $broadcast['entity_id'])->first();
        if ($webhook) {
            $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => 'App\Models\YearlyTargetModel',
                'dispatchable_id' => 0,
                'message_uuid' => $uuid,
                'payload' => json_encode($broadcast),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // broadcast creation once
            broadcast(new WebhookDispatchedEvent($dispatch));

            // enqueue the job
            try {
                $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                // if (!$result['success']) {
                //     // If fails, dispatch to queue
                //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                // }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                // SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
    }


    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }



    public function saveAchievement(Request $request)
    {
        DB::beginTransaction();

        try {

            foreach ($request->data as $row) {

                $date = Carbon::parse($row['date']);

                $year = $date->year;
                $month = $date->month;


                $quarter = match (true) {
                    $month >= 4 && $month <= 6  => 1,
                    $month >= 7 && $month <= 9  => 2,
                    $month >= 10 && $month <= 12 => 3,
                    default => 4,
                };

                // $week = match (true) {
                //     $date->day <= 8  => 1,
                //     $date->day <= 14 => 2,
                //     $date->day <= 21 => 3,
                //     default          => 4,
                // };
                $week = null;

                $weekSettings = DB::table('egc_target_week_settings')
                    ->where('status', 0)
                    ->orderBy('week_no')
                    ->get();

                foreach ($weekSettings as $setting) {

                    [$startDate, $endDate] = $this->getWeekDatesFromSetting(
                        $month,
                        $year,
                        $setting
                    );

                    if (
                        $date->betweenIncluded(
                            Carbon::parse($startDate),
                            Carbon::parse($endDate)
                        )
                    ) {
                        $week = $setting->week_no;
                        break;
                    }
                }

                TargetAchievementModel::updateOrCreate(

                    // UNIQUE CONDITION
                    [
                        'entity_id'     => $request->entity_id,
                        'branch_id'     => $request->branch_id,
                        'achieved_date' => $date->format('Y-m-d'),
                    ],

                    // UPDATE DATA
                    [
                        'year'             => $year,
                        'month'            => $month,
                        'quarter'          => $quarter,
                        'week'             => $week,

                        'achieved_amount'  => $row['amount'],
                        'pre_sale'         => $row['pre_sale'],
                        'post_sale'        => $row['post_sale'],
                    ]
                );
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Achievement Saved Successfully'
            ]);
        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error($e);

            return response()->json([
                'status' => false,
                'message' => 'Save Failed'
            ]);
        }
    }


    public function getAchieveData(Request $request)
    {
        try {

            $verify_key = 'egcsecret2030datagetapierp';

            if ($request->verify_key !== $verify_key) {
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $branchId = $request->branch_id;
            $date = $request->date ?? now()->toDateString();

            // ✅ SALES AMOUNT
            $amount = TransactionModel::where('branch_id', $branchId)
                ->whereDate('transaction_date', $date)
                ->sum('credit');

            // ✅ PRESALE
            $preSale = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', '!=', 1)
                ->where('branch_id', $branchId)
                ->whereDate('created_at', $date)
                ->count();

            // ✅ POSTSALE
            $postSale = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', 1)
                ->where('branch_id', $branchId)
                ->whereDate('created_at', $date)
                ->count();

            return response()->json([
                'status' => true,
                'data' => [[
                    'amount' => $amount,
                    'pre_sale' => $preSale,
                    'post_sale' => $postSale,
                    'date' => $date
                ]]
            ]);
        } catch (\Exception $e) {

            \Log::error('Achieve API Error: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Server Error'
            ]);
        }
    }


    public function IncentiveRoles(Request $request)
    {
        $entity_id = $request->entity_id;
        $setErpRoleIds = [];
        if ($entity_id == 1) {
            $setErpRoleIds = ['11','36','14', '16', '22','15','33','35','34','32','41','42'];
        } elseif ($entity_id == 2) {
            $setErpRoleIds = ['11', '14', '15', '16', '22', '17', '19',];
        } elseif ($entity_id == 3) {
        } elseif ($entity_id == 4) {
        } elseif ($entity_id == 5) {
        }
        $user = UserRoleModel::where('status', 0)
            ->where('entity_id', $entity_id)
            ->whereIn('erp_role_id', $setErpRoleIds)
            ->orderBy('sno', 'asc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $user
        ], 200);
    }


      public function sampleTargetEntryExcel()
    {
        return Excel::download(
            new TargetExportExcel(),
            'target-entry-sample.xlsx'
        );
    }
}
