<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use App\Models\AIWebsiteModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use DateTime;
use Illuminate\Support\Facades\Cache;

class UserTimestamp extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? 'egc';
    $entity_fill = $request->entity_fill ?? '0';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
     $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', '>', 1);
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        if($company_fill !== ""){
            if($company_fill == 'egc'){
                $staffData->where('egc_staff.company_type',1);
            } else {
                if($entity_fill !== ""){
                    $staffData->where('egc_staff.entity_id', $entity_fill);
                }
            }
        }

        if ($entity_fill) {
          $staffData->where('egc_staff.entity_id', $entity_fill);
        }

        
        if ($department_fill) {
            $staffData->where('egc_staff.department_id', $department_fill);
        }

        if ($division_fill) {
            $staffData->where('egc_staff.division_id', $division_fill);
        }

        if ($job_role_fill) {
          $staffData->where('egc_staff.job_role_id', $job_role_fill);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
            }
          }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->get();
        
        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
            
           $educations = DB::table('egc_staff_education_info')
            ->select('egc_education.education')
            ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
            ->where('egc_staff_education_info.staff_id', $staff->sno) 
            ->where('egc_staff_education_info.status', 0)
            ->pluck('egc_education.education');
            $staff->education=$educations;
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                // 'current_page' => $staffData->currentPage(),
                // 'last_page' => $staffData->lastPage(),
                // 'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.control_panel.user_management.user_timestamp.user_timestamp_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }
//   public function getDailySummaryByEmployeeId(Request $request){

//         $employeeId = $request->staff_id;
//         $date =  $request->date ? date('Y-m-d', strtotime($request->date)) : null;  
        
//         $timeStaffData =StaffTimestampModel::select('staff_timestamp_reports')->where('time_sheet_date',$date)->first();

//         $StaffData=json_decode($timeStaffData->staff_timestamp_reports);
        
   
//         $filteredStaffData = array_filter($StaffData, function($staff) {
//               return $staff['employeeId'] == $employeeId;
//           });
//           $filteredStaffData = array_values($filteredStaffData);

//   }

  public function getDailySummaryByEmployeeId(Request $request)
{
    try {
        $type =  $request->type;
        $employeeId = $request->staff_id;
        $date =  $request->date ? date('Y-m-d', strtotime($request->date)) : date('Y-m-d');  

        if (!$employeeId || !$date) {
            return response()->json([
                'status' => false,
                'message' => 'staff_id and date are required.',
                'data' => []
            ]);
        }

      
        // check the Database 
        $timeStaffData = StaffTimestampModel::select('staff_timestamp_reports')
            ->where('time_sheet_date', $date)
            ->first();
        $localRecord = null;
        
        if ($timeStaffData) {
            // $decoded =$timeStaffData->staff_timestamp_reports;
            $decoded = json_decode($timeStaffData->staff_timestamp_reports, true);
           
            if (is_array($decoded)) {
                // Filter by employeeId
                foreach ($decoded as $row) {
                    // return $row['employeeId']  . '==' .$employeeId;
                    if (isset($row['employeeId']) && $row['employeeId'] == $employeeId) {
                        $localRecord = $row;
                        break;
                    }
                    
                }
            }
          
        }
        // return $localRecord;
        if ($localRecord) {
            return response()->json([
                'status' => true,
                'message' => 'Success (from local DB)',
                'data' => [$this->formatEmployeeDailyLog($localRecord)]
            ]);
        }
        // if local db not have data then check in Api
        $pageNumber = $request->pageNumber ?? 1;
        $perPage    = $request->perPage ?? 500;

        $api_url = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getDailyTrackingSummaryData";
        $api_url .= "?DateFrom={$date}&DateTo={$date}&EmployeeIds={$employeeId}&PageNumber={$pageNumber}&PageSize={$perPage}&Offset";

        $ApiData= DB::table('egc_api_integration')->where('api_key','egc_staff_timestamp_api_1')->where('status',0)->orderBy('sno', 'desc')->first();
        // return $ApiData;
        if($ApiData){
            $apiFields = json_decode($ApiData->api_fields, true);
            $bearerToken = '';
            $login_password = '';
            $login_email = '';
            foreach ($apiFields as $field) {
                if ($field['key'] === 'AuthToken') {
                    $bearerToken = $field['value'];
                } elseif ($field['key'] === 'email') {
                    $login_email = $field['value'];
                } elseif ($field['key'] === 'password') {
                    $login_password = $field['value'];
                }
            }
             
        }else{
            $login_password = '';
            $bearerToken = '';
            $login_email = '';
        }

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$bearerToken}"
        ])->get($api_url);

        if ($response->status() === 401 || $response->status() === 403) {
            $newToken = $this->refreshTimechampToken();
            if (!$newToken) {
                return response()->json([
                    'status' => false,
                    'message' => 'Token refresh failed.',
                    'data' => []
                ]);
            }
            // Retry API with new token
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$newToken}"
            ])->get($api_url);
        }

        if (!$response->successful()) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to fetch from external API.',
                'error' => $response->body()
            ]);
        }

        $json = $response->json();
        $apiData = $json['data'] ?? [];
        // return $apiData;
        if (empty($apiData)) {
            return response()->json([
                'status' => true,
                'message' => 'No logs found.',
                'data' => []
            ]);
        }

        // Pick first record
        $apiRecord = $apiData[0];

        return response()->json([
            'status' => true,
            'message' => 'Success (from API)',
            'data' => [$this->formatEmployeeDailyLog($apiRecord)]
        ]);


    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => $e->getMessage(),
            'data' => []
        ]);
    }

}
private function refreshTimechampToken()
{
    $apiData = DB::table('egc_api_integration')
        ->where('api_key', 'egc_staff_timestamp_api_1')
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();

    if (!$apiData) {
        return false;
    }

    $apiFields = json_decode($apiData->api_fields, true);

    $email = '';
    $password = '';

    foreach ($apiFields as $field) {
        if ($field['key'] === 'email') {
            $email = $field['value'];
        }
        if ($field['key'] === 'password') {
            $password = $field['value'];
        }
    }

    if (!$email || !$password) {
        return false;
    }

    $loginResponse = Http::post(
        'https://elysiumgroups.sites2.timechamp.io/swagger/api/login',
        [
            'email'    => $email,
            'password' => $password
        ]
    );

    if (!$loginResponse->successful()) {
        return false;
    }

    $loginJson = $loginResponse->json();
    $newToken = $loginJson['data']['AuthToken'] ?? null;

    if (!$newToken) {
        return false;
    }

    // Update token in api_fields
    foreach ($apiFields as &$field) {
        if ($field['key'] === 'AuthToken') {
            $field['value'] = $newToken;
        }
    }

    DB::table('egc_api_integration')
        ->where('sno', $apiData->sno)
        ->update([
            'api_fields' => json_encode($apiFields),
            'updated_at' => now()
        ]);

    return $newToken;
}
private function formatEmployeeDailyLog($log)
{
    return [
        'employeeId'       => $log['employeeId'] ?? '',
        'employeeName'     => $log['employeeName'] ?? '',
        'timesheetDate'    => $log['timesheetDate'] ?? '',
        'startDateTime'    => $log['startDateTime'] ?? null,
        'finishDateTime'   => $log['finishDateTime'] ?? null,
        'productiveTime'   => $log['productiveTime'] ?? "00:00:00",
        'nonProductiveTime'=> $log['nonProductiveTime'] ?? "00:00:00",
        'neutralTime'      => $log['neutralTime'] ?? "00:00:00",
        'awayTime'         => $log['awayTime'] ?? "00:00:00",
        'workingTime'      => $log['workingTime'] ?? "00:00:00",
        'onlineTime'       => $log['onlineTime'] ?? "00:00:00",
        'offlineTime'      => $log['offlineTime'] ?? "00:00:00",
    ];
}

public function getSummaryByEmployeeId(Request $request)
{
    try {
        $employeeId = $request->staff_id;
        $type       = $request->type ?? 'day';
        $dateInput  = $request->date ?? date('Y-m-d');

        if (!$employeeId) {
            return response()->json([
                'status' => false,
                'message' => 'staff_id is required.',
                'data' => []
            ]);
        }

        // Parse dates based on type
        switch ($type) {
            case 'week':
                if (preg_match('/(\d{4})-W(\d{1,2})/', $dateInput, $matches)) {
                    $year = intval($matches[1]);
                    $week = intval($matches[2]);
                    $start = new DateTime();
                    $start->setISODate($year, $week);
                    $end = clone $start;
                    $end->modify('+6 days');
                } else {
                    $start = new DateTime('monday this week');
                    $end   = new DateTime('sunday this week');
                }
                break;

            case 'month':
                $start = DateTime::createFromFormat('!M-Y', $dateInput);

                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid month format. Use Feb-2026.',
                        'data' => []
                    ]);
                }

                $end = clone $start;
                $end->modify('last day of this month');
                break;

            case 'year':
                $start = DateTime::createFromFormat('Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid year format. Use 2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                $end->modify('last day of December');
                break;

            case 'day':
            default:
                $start = DateTime::createFromFormat('d-M-Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid day format. Use 17-Feb-2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                break;
        }
      

        $dateFrom = $start->format('Y-m-d');
        $dateTo   = $end->format('Y-m-d');

        //   return $dateInput .': ' .$dateFrom . '-'. $dateTo ;

        // Fetch API integration token
        $apiData = DB::table('egc_api_integration')
            ->where('api_key', 'egc_staff_timestamp_api_1')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();

        if (!$apiData) {
            return response()->json([
                'status' => false,
                'message' => 'API integration not found.',
                'data' => []
            ]);
        }

        $apiFields = json_decode($apiData->api_fields, true);
        $bearerToken = '';
        foreach ($apiFields as $field) {
            if ($field['key'] === 'AuthToken') $bearerToken = $field['value'];
        }

        $pageNumber = $request->pageNumber ?? 1;
        $perPage    = $request->perPage ?? 500;

        $api_url = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getDailyTrackingSummaryData";
        $api_url .= "?DateFrom={$dateFrom}&DateTo={$dateTo}&EmployeeIds={$employeeId}&PageNumber={$pageNumber}&PageSize={$perPage}";

        // Make API request
        $response = Http::withHeaders(['Authorization' => "Bearer {$bearerToken}"])->get($api_url);

        // Handle unauthorized / refresh token
        if (in_array($response->status(), [401, 403])) {
            $newToken = $this->refreshTimechampToken();
            if (!$newToken) {
                return response()->json([
                    'status' => false,
                    'message' => 'Token refresh failed.',
                    'data' => []
                ]);
            }
            $response = Http::withHeaders(['Authorization' => "Bearer {$newToken}"])->get($api_url);
        }

        if (!$response->successful()) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to fetch from external API.',
                'error' => $response->body()
            ]);
        }

        $records = $response->json()['data'] ?? [];
        $aiUsageTime = $this->getAiUsageDuration(
            $employeeId,
            $dateFrom,
            $dateTo,
            $bearerToken
        );

        // return $aiUsageTime;

        if (empty($records)) {
            return response()->json([
                'status' => true,
                'message' => 'No records found.',
                'data' => []
            ]);
        }

        // Aggregate for week/month/year
        if ($type !== 'day') {
            $first = $records[0] ?? [];
            $last  = end($records) ?? [];

            $aggregate = [
                'employeeId'       => $employeeId,
                'employeeName'     => $first['employeeName'] ?? '',
                'timesheetDate'    => "{$dateFrom} to {$dateTo}",
                'startDateTime'    => $first['startDateTime'] ?? null,
                'finishDateTime'   => $last['finishDateTime'] ?? null,
                'productiveTime'   => $this->sumTimes(array_column($records, 'productiveTime')),
                'nonProductiveTime'=> $this->sumTimes(array_column($records, 'nonProductiveTime')),
                'neutralTime'      => $this->sumTimes(array_column($records, 'neutralTime')),
                'awayTime'         => $this->sumTimes(array_column($records, 'awayTime')),
                'workingTime'      => $this->sumTimes(array_column($records, 'workingTime')),
                'onlineTime'       => $this->sumTimes(array_column($records, 'onlineTime')),
                'offlineTime'      => $this->sumTimes(array_column($records, 'offlineTime')),
                'aiUsageTime' => $aiUsageTime,
            ];

            return response()->json([
                'status' => true,
                'message' => 'Success',
                'data' => [$aggregate]
            ]);
        }

        // Day type
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => [
                array_merge($records[0], [
                    'aiUsageTime' => $aiUsageTime
                ])
            ]
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => $e->getMessage(),
            'data' => []
        ]);
    }
}

/**
 * Sum multiple "HH:MM:SS" times safely
 */
private function sumTimes(array $times)
{
    $seconds = 0;
    foreach ($times as $time) {
        if (!$time) continue;
        [$h, $m, $s] = array_map('intval', explode(':', $time));
        $seconds += $h*3600 + $m*60 + $s;
    }
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;
    return sprintf('%02d:%02d:%02d', $h, $m, $s);
}




  public function getCompanyStaff(Request $request)
  {
      $companyId = $request->company_id;

      $staff = StaffModel::where('egc_staff.company_id', $companyId)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();

      $html = view('content.hr_management.hr_enroll.manage_staff.company_staff_list_table', compact('staff'))->render();

      return response()->json([
          'staff_html' => $html
      ]);
  }

  function staffDataById(Request $request){
    $staff_id = $request->staff_id;

      $staff = StaffModel::select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', $staff_id)
          ->first();

      return response()->json([
          'status' => 200,
          'data' => $staff
      ]);
  }


   public function updateTimestampReport(Request $request)
  {
      // Validate incoming request
      $validator = Validator::make($request->all(), [
          'date' => 'required|date', // Ensure the date is a valid date format
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status' => 401,
              'message' => 'Incorrect format input fields',
              'error_msg' => $validator->errors()->all(),
              'data' => null,
          ], 200);
      }

      // Get user_id from the request or default to 1 if not available
      $user_id = $request->user()->user_id ?? 1;

      // Get pagination parameters or default values
      $pageNumber = $request->pageNumber ?? 1;
      $perPage = $request->perPage ?? 500;
      $employee_id = $request->employee_id ?? '';
      $timestampDate = $request->date ? date('Y-m-d', strtotime($request->date)) : null;

      // Ensure timestampDate is not null or invalid
      if (is_null($timestampDate)) {
          return response()->json([
              'status' => 400,
              'message' => 'Invalid date format provided.',
          ], 200);
      }

      // Construct the API URL
      $api_url = 'https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getDailyTrackingSummaryData?DateFrom=' . $timestampDate . '&DateTo=' . $timestampDate . '&EmployeeIds=' . $employee_id . '&PageNumber=' . $pageNumber . '&PageSize=' . $perPage . '&Offset';

      try {
          // Replace with your actual bearer token
          $bearerToken = $this->refreshTimechampToken(); 

          // Send the GET request with Bearer token in Authorization header
          $response = Http::withHeaders([
              'Authorization' => 'Bearer ' . $bearerToken,
          ])->get($api_url);

          if (!$response->successful()) {
              return response()->json([
                  'status' => 500,
                  'message' => 'Failed to fetch data from external API.',
                  'error' => $response->body(),
              ], 200);
          }

          // Check if the response contains data
          $erpData = $response->json()['data'] ?? [];
          if (empty($erpData)) {
              return response()->json([
                  'status' => 404,
                  'message' => 'No data found in API response.',
              ], 200);
          }

          // Update or create the timestamp record
          StaffTimestampModel::updateOrCreate(
              ['time_sheet_date' => $timestampDate],
              [
                  'staff_timestamp_reports' => json_encode($erpData),
                  'created_by' => $user_id,
                  'updated_by' => $user_id,
              ]
          );

          return response()->json([
              'status' => 200,
              'message' => 'Staff timestamp updated successfully.',
          ]);

      } catch (\Throwable $e) {
          // Log the error for debugging
          // \Log::error('Error fetching staff timestamp: ' . $e->getMessage());
          
          return response()->json([
              'status' => 500,
              'message' => 'Something went wrong while fetching staff timestamp.',
              'error' => $e->getMessage(),
          ], 200);
      }
  }
            

    // private function getAiWebsiteSlugs()
    // {
    //     $rows = DB::table('egc_ai_websites')
    //         ->where('status', 0)
    //         ->get();

    //     $slugs = [];

    //     foreach ($rows as $row) {
    //         $decoded = json_decode($row->ai_website_slug, true);

    //         // Handle double encoded JSON
    //         if (is_string($decoded)) {
    //             $decoded = json_decode($decoded, true);
    //         }

    //         if (is_array($decoded)) {
    //             foreach ($decoded as $item) {
    //                 if (!empty($item['value'])) {
    //                     $slugs[] = strtolower(trim($item['value']));
    //                 }
    //             }
    //         }
    //     }

    //     return $slugs;
    // }

    private function getAiWebsiteSlugs()
{
    return Cache::remember('ai_website_slugs', 3600, function () {

        $rows = DB::table('egc_ai_websites')
            ->where('status', 0)
            ->get();

        $slugs = [];

        foreach ($rows as $row) {
            $decoded = json_decode($row->ai_website_slug, true);

            if (is_string($decoded)) {
                $decoded = json_decode($decoded, true);
            }

            if (is_array($decoded)) {
                foreach ($decoded as $item) {
                    if (!empty($item['value'])) {
                        $slugs[strtolower(trim($item['value']))] = true; // associative for O(1)
                    }
                }
            }
        }

        return $slugs;
    });
}


    // private function getAiUsageDuration($employeeId, $dateFrom, $dateTo, $bearerToken)
    // {
    //     $aiSlugs = $this->getAiWebsiteSlugs();

    //     if (empty($aiSlugs)) {
    //         return "00:00:00";
    //     }

    //     $apiUrl = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getTrackingApplicationsAndWebsitesStats";
    //     $apiUrl .= "?DateFrom={$dateFrom}&DateTo={$dateTo}&PageNumber=1&PageSize=200&SearchText={$employeeId}";

    //     $response = Http::withHeaders([
    //         'Authorization' => "Bearer {$bearerToken}"
    //     ])->get($apiUrl);

    //     if (!$response->successful()) {
    //         return "00:00:00";
    //     }

    //     $records = $response->json() ?? [];

    //     $totalSeconds = 0;

    //     foreach ($records as $record) {

    //         $applicationName = strtolower(trim($record['applicationName'] ?? ''));

    //         if (in_array($applicationName, $aiSlugs)) {
    //             $totalSeconds += (int) floor($record['spentTimeInSeconds'] ?? 0);
    //         }
    //     }

    //     return $this->secondsToTime($totalSeconds);
    // }


    // private function getAiUsageDuration($employeeId, $dateFrom, $dateTo, $bearerToken)
    // {
    //     $aiSlugs = $this->getAiWebsiteSlugs();
    //     // return $aiSlugs;

    //     if (empty($aiSlugs)) {
    //         return "00:00:00";
    //     }

    //     $pageNumber = 1;
    //     $pageSize   = 40; // API max
    //     $totalSeconds = 0;
    //     $totalCount = null;
    //       $records=[];    
    //     do {

    //         $apiUrl = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getTrackingApplicationsAndWebsitesStats";
    //         $apiUrl .= "?DateFrom={$dateFrom}&DateTo={$dateTo}";
    //         $apiUrl .= "&PageNumber={$pageNumber}&PageSize={$pageSize}";
    //         $apiUrl .= "&SearchText={$employeeId}";

    //        $response = Http::timeout(60)->withHeaders([
    //             'Authorization' => "Bearer {$bearerToken}"
    //         ])->get($apiUrl);

    //         if (in_array($response->status(), [401, 403])) {
    //             $newToken = $this->refreshTimechampToken();
    //             if (!$newToken) break;

    //             $bearerToken = $newToken;

    //             $response = Http::withHeaders([
    //                 'Authorization' => "Bearer {$bearerToken}"
    //             ])->get($apiUrl);
    //         }

    //         if (!$response->successful()) {
    //             break;
    //         }

    //         $records = $response->json() ?? [];

    //         if (empty($records)) {
    //             break;
    //         }

    //         // Set totalCount only once
    //         if ($totalCount === null && isset($records[0]['totalCount'])) {
    //             $totalCount = (int) $records[0]['totalCount'];
    //         }

    //         foreach ($records as $record) {

    //             $applicationName = strtolower(trim($record['applicationName'] ?? ''));
    //             if (isset($aiSlugs[$applicationName])) {
    //                 $totalSeconds += (int) floor($record['spentTimeInSeconds'] ?? 0);
    //             }
    //             // if (in_array($applicationName, $aiSlugs)) {
    //             //     $totalSeconds += (int) floor($record['spentTimeInSeconds'] ?? 0);
    //             // }
    //         }

    //         $pageNumber++;

    //         // Stop when we fetched all
    //         $fetchedSoFar = ($pageNumber - 1) * $pageSize;

    //     }  while (count($records) === $pageSize);
    //       return $records;           
    //     return $this->secondsToTime($totalSeconds);
    // }

    private function getAiUsageDuration($employeeId, $dateFrom, $dateTo, $bearerToken)
    {
        $aiSlugs = $this->getAiWebsiteSlugs();
        if (empty($aiSlugs)) return "00:00:00";

        $pageNumber = 1;
        $pageSize = 40;
        $totalSeconds = 0;
        $totalCount = null;

        do {
            $apiUrl = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getTrackingApplicationsAndWebsitesStats";
            $apiUrl .= "?DateFrom={$dateFrom}&DateTo={$dateTo}&PageNumber={$pageNumber}&PageSize={$pageSize}&SearchText={$employeeId}";

            $response = Http::timeout(60)->withHeaders([
                'Authorization' => "Bearer {$bearerToken}"
            ])->get($apiUrl);

            if (in_array($response->status(), [401, 403])) {
                $newToken = $this->refreshTimechampToken();
                if (!$newToken) break;
                $bearerToken = $newToken;
                $response = Http::withHeaders([
                    'Authorization' => "Bearer {$bearerToken}"
                ])->get($apiUrl);
            }

            if (!$response->successful()) break;

            $records = $response->json()['data'] ?? [];
            if (empty($records)) break;

            if ($totalCount === null && isset($records[0]['totalCount'])) {
                $totalCount = (int) $records[0]['totalCount'];
            }

            foreach ($records as $record) {
                $applicationName = strtolower(trim($record['applicationName'] ?? ''));
                if (isset($aiSlugs[$applicationName])) {
                    $totalSeconds += $record['spentTimeInSeconds'] ?? 0; // keep fractional seconds
                }
            }

            $pageNumber++;
            $fetchedSoFar = ($pageNumber - 1) * $pageSize;

        } while ($totalCount === null || $fetchedSoFar < $totalCount);

        return $this->secondsToTime(round($totalSeconds));
    }

    private function secondsToTime($seconds)
    {
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;

        return sprintf('%02d:%02d:%02d', $h, $m, $s);
    }

    public function getAiUsageDetails(Request $request)
    {
        $employeeId = $request->staff_id;

        $type       = $request->type ?? 'day';
        $dateInput  = $request->date ?? date('Y-m-d');

        if (!$employeeId) {
            return response()->json([
                'status' => false,
                'message' => 'staff_id is required.',
                'data' => []
            ]);
        }

        // Parse dates based on type
        switch ($type) {
            case 'week':
                if (preg_match('/(\d{4})-W(\d{1,2})/', $dateInput, $matches)) {
                    $year = intval($matches[1]);
                    $week = intval($matches[2]);
                    $start = new DateTime();
                    $start->setISODate($year, $week);
                    $end = clone $start;
                    $end->modify('+6 days');
                } else {
                    $start = new DateTime('monday this week');
                    $end   = new DateTime('sunday this week');
                }
                break;

            case 'month':
                $start = DateTime::createFromFormat('!M-Y', $dateInput);

                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid month format. Use Feb-2026.',
                        'data' => []
                    ]);
                }

                $end = clone $start;
                $end->modify('last day of this month');
                break;

            case 'year':
                $start = DateTime::createFromFormat('Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid year format. Use 2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                $end->modify('last day of December');
                break;

            case 'day':
            default:
                $start = DateTime::createFromFormat('d-M-Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid day format. Use 17-Feb-2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                break;
        }

        $dateFrom = $start->format('Y-m-d');
        $dateTo   = $end->format('Y-m-d');

        try {
            // Fetch AI website slugs
            $aiWebsites = AIWebsiteModel::where('status', 0)->get();
            $aiSlugs = [];
            foreach ($aiWebsites as $site) {
                $decoded = json_decode($site->ai_website_slug, true);
                if (is_string($decoded)) $decoded = json_decode($decoded, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $slug) {
                        if (!empty($slug['value'])) {
                            $aiSlugs[strtolower(trim($slug['value']))] = [
                                'name' => $site->ai_website_name,
                                'desc' => $slug['value'],
                                'logo' => $site->logo ? '/settings/ai/' . $site->logo : null,
                                'url'  => $site->ai_website_url
                            ];
                        }
                    }
                }
            }

            // Fetch AI usage from Timechamp
            $bearerToken = $this->getTimechampToken(); // reuse your existing function
            $pageNumber = 1;
            $pageSize = 40;
            $records = [];
            $matched = [];

            do {
                $apiUrl = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getTrackingApplicationsAndWebsitesStats";
                $apiUrl .= "?DateFrom={$dateFrom}&DateTo={$dateTo}&PageNumber={$pageNumber}&PageSize={$pageSize}&SearchText={$employeeId}";

                $response = Http::withHeaders(['Authorization' => "Bearer {$bearerToken}"])
                                ->timeout(60)
                                ->get($apiUrl);

                if (in_array($response->status(), [401, 403])) {
                    $bearerToken = $this->refreshTimechampToken();
                    if (!$bearerToken) break;
                    $response = Http::withHeaders(['Authorization' => "Bearer {$bearerToken}"])->get($apiUrl);
                }

                if (!$response->successful()) break;

                $pageRecords = $response->json()['data'] ?? [];
                foreach ($pageRecords as $r) {
                    $records[] = $r;
                    $appName = strtolower(trim($r['applicationName'] ?? ''));
                    if (isset($aiSlugs[$appName])) {
                        $matched[] = array_merge($r, ['ai_info' => $aiSlugs[$appName]]);
                    }
                }

                $pageNumber++;
            } while (count($pageRecords) === $pageSize);

            return response()->json([
                'status' => true,
                'data' => $matched
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'data' => []
            ]);
        }
    }

    function getTimechampToken()
    {
        $apiData = DB::table('egc_api_integration')
            ->where('api_key', 'egc_staff_timestamp_api_1')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();

        if (!$apiData) {
            return null;
        }

        $apiFields = json_decode($apiData->api_fields, true);
        foreach ($apiFields as $field) {
            if ($field['key'] === 'AuthToken') {
                return $field['value'];
            }
        }

        return null;
    }

    public function getApplicationUsageDetails(Request $request)
    {
        $employeeId = $request->staff_id;
        $day_type       = $request->type ?? 'day';
        $dateInput  = $request->date ?? date('Y-m-d');
        $type       = $request->type_filter; // productive | unproductive | neutral

        if (!$employeeId) {
            return response()->json([
                'status' => false,
                'message' => 'staff_id is required.',
                'data' => []
            ]);
        }

        // Parse dates based on type
        switch ($day_type) {
            case 'week':
                if (preg_match('/(\d{4})-W(\d{1,2})/', $dateInput, $matches)) {
                    $year = intval($matches[1]);
                    $week = intval($matches[2]);
                    $start = new DateTime();
                    $start->setISODate($year, $week);
                    $end = clone $start;
                    $end->modify('+6 days');
                } else {
                    $start = new DateTime('monday this week');
                    $end   = new DateTime('sunday this week');
                }
                break;

            case 'month':
                $start = DateTime::createFromFormat('!M-Y', $dateInput);

                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid month format. Use Feb-2026.',
                        'data' => []
                    ]);
                }

                $end = clone $start;
                $end->modify('last day of this month');
                break;

            case 'year':
                $start = DateTime::createFromFormat('Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid year format. Use 2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                $end->modify('last day of December');
                break;

            case 'day':
            default:
                $start = DateTime::createFromFormat('d-M-Y', $dateInput);
                if (!$start) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Invalid day format. Use 17-Feb-2026.',
                        'data' => []
                    ]);
                }
                $end = clone $start;
                break;
        }

        $dateFrom = $start->format('Y-m-d');
        $dateTo   = $end->format('Y-m-d');

        try {

            $bearerToken = $this->getTimechampToken();
            $pageNumber = 1;
            $pageSize = 40;
            $matched = [];
            $totalSeconds = 0;

            do {

                $apiUrl = "https://elysiumgroups.sites2.timechamp.io/swagger/api/activity/getTrackingApplicationsAndWebsitesStats";
                $apiUrl .= "?DateFrom={$dateFrom}&DateTo={$dateTo}";
                $apiUrl .= "&PageNumber={$pageNumber}&PageSize={$pageSize}";
                $apiUrl .= "&SearchText={$employeeId}";

                $response = Http::timeout(60)
                    ->withHeaders(['Authorization' => "Bearer {$bearerToken}"])
                    ->get($apiUrl);

                if (in_array($response->status(), [401, 403])) {
                    $bearerToken = $this->refreshTimechampToken();
                    if (!$bearerToken) break;

                    $response = Http::withHeaders([
                        'Authorization' => "Bearer {$bearerToken}"
                    ])->get($apiUrl);
                }

                if (!$response->successful()) break;

                $records = $response->json()['data'] ?? [];

                foreach ($records as $record) {

                    if (
                        strtolower($record['applicationTypeName']) === strtolower($type)
                    ) {
                        $matched[] = $record;
                        $totalSeconds += $record['spentTimeInSeconds'] ?? 0;
                    }
                }

                $pageNumber++;

            } while (count($records) === $pageSize);

            return response()->json([
                'status' => true,
                'total_seconds' => round($totalSeconds),
                'formatted_total' => $this->secondsToTime(round($totalSeconds)),
                'data' => $matched
            ]);

        } catch (\Exception $e) {

            \Log::error("Application usage error: " . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Something went wrong.',
                'data' => []
            ]);
        }
    }
  
}