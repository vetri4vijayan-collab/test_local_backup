<?php

namespace App\Http\Controllers\business_strategy;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;


class SalesMetrics extends Controller
{

    public function index(Request $request)
    {
        $page          = $request->input('page', 1);
        $perpage       = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';
        $year          = $request->year ?? date('Y');

        $entityQuery = DB::table('egc_branch')
        ->leftJoin('egc_entity_yearly_targets', function ($join) use ($year) {
            $join->on('egc_branch.sno','=','egc_entity_yearly_targets.branch_id');
            $join->where('egc_entity_yearly_targets.year', $year);
            $join->where('egc_entity_yearly_targets.status', '!=', 2);
        })

        ->join( 'egc_entity','egc_branch.entity_id','=','egc_entity.sno')
        ->where('egc_branch.status',0)
        ->select(
            'egc_branch.sno as branch_id',
            'egc_entity.sno as entity_id',
            'egc_entity.company_id',
            'egc_entity.entity_name',
            'egc_entity.entity_logo',
            'egc_entity.entity_favicon',
            'egc_entity.entity_base_color',
            'egc_entity.entity_short_name',
            'egc_entity_yearly_targets.id',
            'egc_entity_yearly_targets.total_target',
            'egc_entity_yearly_targets.total_pre_sale',
            'egc_entity_yearly_targets.total_post_sale',
            'egc_branch.branch_name'
        );

        if ($search_filter != '') {
            $entityQuery->where(function ($q) use ($search_filter) {
                $q->where('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_branch.branch_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $targets = $entityQuery
            ->orderBy('egc_entity.sno', 'asc')
            ->paginate($perpage);

        if ($request->ajax()) {

            $response = $targets->map(function ($item) use($year) {

                $item->year = $year;

                $yearlyTarget = null;
                if($item->id){
                    $yearlyTarget = YearlyTargetModel::with([
                        'quarters.months.weeks'
                    ])->find($item->id);
                }

                $quarters = $yearlyTarget ? $yearlyTarget->quarters : collect();

                /*
                |--------------------------------------------------------------------------
                | ACHIEVEMENT DATA
                |--------------------------------------------------------------------------
                */

               $achievementData = TargetAchievementModel::where('entity_id', $item->entity_id)
                ->where('branch_id', $item->branch_id)
                ->where(function ($q) use ($year) {

                    // Apr-Dec of FY start year
                    $q->where(function ($sub) use ($year) {
                        $sub->where('year', $year)
                            ->whereIn('month', [4,5,6,7,8,9,10,11,12]);
                    })

                    // Jan-Mar of next year
                    ->orWhere(function ($sub) use ($year) {
                        $sub->where('year', $year + 1)
                            ->whereIn('month', [1,2,3]);
                    });

                })
                ->where('status', '!=', 2)
                ->get();

                /*
                |--------------------------------------------------------------------------
                | ACTUAL SUMMARY
                |--------------------------------------------------------------------------
                */
                $actualAmount = $achievementData->sum('achieved_amount');
                $actualPre    = $achievementData->sum('pre_sale');
                $actualPost   = $achievementData->sum('post_sale');
                /*
                |--------------------------------------------------------------------------
                | PERFORMANCE %
                |--------------------------------------------------------------------------
                */
                $achievementPercent = 0;
                if ($item->total_target > 0) {
                    $achievementPercent = round(($actualAmount / $item->total_target) * 100,1);
                }

                /*
                |--------------------------------------------------------------------------
                | QUARTERS
                |--------------------------------------------------------------------------
                */
                if ($yearlyTarget) {
                    $quarterData =  $yearlyTarget->quarters->map(function ($quarter) use ($achievementData) {

                        /*
                        |--------------------------------------------------------------------------
                        | Convert Q1 -> 1
                        |--------------------------------------------------------------------------
                        */

                        $quarterNo = (int) str_replace('Q', '', $quarter->quarter);

                        /*
                        |--------------------------------------------------------------------------
                        | Quarter Achievement
                        |--------------------------------------------------------------------------
                        */

                        $quarterActual = $achievementData->where('quarter', $quarterNo);
                        $quarterAmount = (float) $quarterActual->sum('achieved_amount');

                        $quarterPercent = 0;

                        if ($quarter->target_amount > 0) {
                            $quarterPercent = round( ($quarterAmount / $quarter->target_amount) * 100,1);
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | MONTHS
                        |--------------------------------------------------------------------------
                        */

                        $months = $quarter->months->map(function ($month) use ($achievementData, $quarterNo) {

                            $monthActual = $achievementData
                                ->where('quarter', $quarterNo)
                                ->where('month', (int) $month->month);

                            $monthAmount = (float) $monthActual->sum('achieved_amount');

                            $monthPercent = 0;

                            if ($month->target_amount > 0) {

                                $monthPercent = round(
                                    ($monthAmount / $month->target_amount) * 100,
                                    1
                                );
                            }

                            /*
                            |--------------------------------------------------------------------------
                            | WEEKS
                            |--------------------------------------------------------------------------
                            */

                            $weeks = $month->weeks->map(function ($week) use (
                                $achievementData,
                                $quarterNo,
                                $month
                            ) {

                                $weekActual = $achievementData
                                    ->where('quarter', $quarterNo)
                                    ->where('month', (int) $month->month)
                                    ->where('week', (int) $week->week);

                                $weekAmount = (float) $weekActual->sum('achieved_amount');

                                $weekPercent = 0;

                                if ($week->target_amount > 0) {

                                    $weekPercent = round(
                                        ($weekAmount / $week->target_amount) * 100,
                                        1
                                    );
                                }

                                return [

                                    'week' => $week->week,

                                    'target_amount' => (float) $week->target_amount,
                                    'actual_amount' => $weekAmount,

                                    'pre_sale_target' => (int) $week->pre_sale,
                                    'pre_sale_actual' => (int) $weekActual->sum('pre_sale'),

                                    'post_sale_target' => (int) $week->post_sale,
                                    'post_sale_actual' => (int) $weekActual->sum('post_sale'),

                                    'achievement_percent' => $weekPercent,

                                    'week_start_date' => $week->week_start_date,
                                    'week_end_date'   => $week->week_end_date,
                                ];
                            });

                            return [

                                'month' => $month->month,

                                'target_amount' => (float) $month->target_amount,
                                'actual_amount' => $monthAmount,

                                'pre_sale_target' => (int) $month->pre_sale,
                                'pre_sale_actual' => (int) $monthActual->sum('pre_sale'),

                                'post_sale_target' => (int) $month->post_sale,
                                'post_sale_actual' => (int) $monthActual->sum('post_sale'),

                                'achievement_percent' => $monthPercent,

                                'weeks' => $weeks,
                            ];
                        });

                        return [

                            'quarter' => $quarter->quarter,

                            'target_amount' => (float) $quarter->target_amount,
                            'actual_amount' => $quarterAmount,

                            'pre_sale_target' => (int) $quarter->pre_sale,
                            'pre_sale_actual' => (int) $quarterActual->sum('pre_sale'),

                            'post_sale_target' => (int) $quarter->post_sale,
                            'post_sale_actual' => (int) $quarterActual->sum('post_sale'),

                            'achievement_percent' => $quarterPercent,

                            'months' => $months,
                        ];
                    });
                }else {
                    $quarterData = $this->buildEmptyQuarterData($year, $achievementData);
                }

                /*
                |--------------------------------------------------------------------------
                | AI PERFORMANCE STATUS
                |--------------------------------------------------------------------------
                */

                $aiStatus = 'Critical';

                if ($achievementPercent >= 100) {

                    $aiStatus = 'Excellent';
                } elseif ($achievementPercent >= 80) {

                    $aiStatus = 'Good';
                } elseif ($achievementPercent >= 60) {

                    $aiStatus = 'Average';
                }

                return [

                    'id' => $item->id,

                    'company_id'       => $item->company_id,
                    'entity_id'       => $item->entity_id,
                    'branch_id'       => $item->branch_id,
                    'entity_name'       => $item->entity_name,
                    'branch_name'       => $item->branch_name,
                    'entity_logo'       => $item->entity_logo,
                    'entity_favicon'    => $item->entity_favicon,
                    'entity_base_color' => $item->entity_base_color,
                    'entity_short_name' => $item->entity_short_name,

                    'year' => $item->year,

                    'total_target' => (float) $item->total_target,
                    'actual_amount' => (float) $actualAmount,

                    'total_pre_sale'  => (int) $item->total_pre_sale,
                    'actual_pre_sale' => (int) $actualPre,

                    'total_post_sale'  => (int) $item->total_post_sale,
                    'actual_post_sale' => (int) $actualPost,

                    'achievement_percent' => $achievementPercent,

                    'ai_status' => $aiStatus,

                    'quarters' => $quarterData,
                ];
            });

            return response()->json([

                'data' => $response,

                'current_page' => $targets->currentPage(),
                'last_page'    => $targets->lastPage(),
                'total'        => $targets->total(),

            ]);
        }

        $entity_list = ManageEntityModel::where('status', 0)->get();

        return view(
            'content.control_panel.entity_hub.manage_targets.sales_metrics',
            [
                'entity_list' => $entity_list,
                'Company' => $targets,
            ]
        );
    }

    public function edit_target(Request $request)
    {
        $entity_list = ManageEntityModel::where('status', 0)->get();
        $week_settings = TargetWeekSettingModel::where('status', 0)
            ->orderBy('week_no')
            ->get();
        return view('content.control_panel.entity_hub.manage_targets.update_targets', compact('entity_list', 'week_settings'));
    }

    public function import(Request $request)
    {
        $file = $request->file('file_upload');

        $spreadsheet = IOFactory::load($file->getPathname());

        $sheetNames = $spreadsheet->getSheetNames();

        $year = null;

        // ✅ FIND SUMMARY SHEET
        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {

                $summarySheet = $spreadsheet->getSheet($index);
                $rows = $summarySheet->toArray();

                // 👉 adjust based on your summary format
                foreach ($rows as $row) {
                    foreach ($row as $cell) {

                        if (preg_match('/20\d{2}/', $cell, $matches)) {
                            $year = (int)$matches[0];
                            break 2;
                        }
                    }
                }
            }
        }

        if (!$year) {
            throw new \Exception('Year not found in summary sheet');
        }

        // ================= MULTI SHEET =================
        $sheets = [];
        $entityCounter = 1;

        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {
                continue;
            }

            // ✅ PASS YEAR HERE
            $sheets[$index] = new TargetSheetImport($entityCounter, $year);

            $entityCounter++;
        }

        Excel::import(new class($sheets) implements WithMultipleSheets {

            private $sheets;

            public function __construct($sheets)
            {
                $this->sheets = $sheets;
            }

            public function sheets(): array
            {
                return $this->sheets;
            }
        }, $file);

        return response()->json(['success' => true]);
    }

    public function preview(Request $request)
    {
        $data = Excel::toArray([], $request->file('file'));

        return response()->json($data[0]);
    }



    public function getData(Request $request)
    {
        $query = WeekTargetModel::with([
            'month.quarter.yearly'
        ])
            ->whereHas('month.quarter.yearly', function ($q) use ($request) {
                $q->where('year', $request->year)
                    ->where('branch_id', $request->branch_id);
            });

        $data = $query->get();

        return response()->json([
            'data' => $data,
            'is_existing' => $data->isNotEmpty() // ✅ KEY FLAG
        ]);
    }




    public function saveData(Request $request)
    {
        DB::beginTransaction();

        try {

            $yearCache = [];
            $quarterCache = [];
            $monthCache = [];

            $affectedYearIds = [];
            $affectedQuarterIds = [];
            $affectedMonthIds = [];
            $payloads = [];
            $entityId = null;

            $branch_id = $request->branch_id;
            $entity_id = $request->entity_id;
            $branchData = DB::table('egc_branch')->where('sno', $branch_id)->first();
            $erp_branch_id = $branchData ? $branchData->erp_branch_id : 1;

            foreach ($request->data as $row) {

                // $monthNumber = Carbon::parse("1 " . $row['month'])->month;
                $monthNumber = Carbon::parse("1 " . $row['month'])->month;

                // ✅ Financial Year Fix
                $actualYear = $row['year'];

                if (in_array($monthNumber, [1, 2, 3])) {
                    $actualYear = $row['year'] + 1;
                }

                $yearKey = $row['company'] . '_' . $row['year'];

                //  YEAR CACHE
                if (!isset($yearCache[$yearKey])) {
                    $yearCache[$yearKey] = YearlyTargetModel::firstOrCreate(
                        [
                            'entity_id' => $entity_id,
                            'branch_id' => $branch_id,
                            'year' => $row['year']
                        ]
                    );
                }
                $yearly = $yearCache[$yearKey];
                $affectedYearIds[$yearly->id] = $yearly->id;

                //  QUARTER CACHE
                $quarterKey = $yearly->id . '_' . $row['quarter'];



                if (!isset($quarterCache[$quarterKey])) {


                    $financial_year_id = $row['quarter'];


                    $quarterCache[$quarterKey] = QuarterTargetModel::firstOrCreate(
                        [
                            'yearly_id' => $yearly->id,
                            'quarter' => $row['quarter'],
                            'financial_year_id' => $row['quarter'],
                            'financial_year' => $actualYear,
                        ]
                    );
                }
                $quarter = $quarterCache[$quarterKey];
                $affectedQuarterIds[$quarter->id] = $quarter->id;

                //  MONTH CACHE
                $monthKey = $quarter->id . '_' . $monthNumber;



                if (!isset($monthCache[$monthKey])) {
                    $monthCache[$monthKey] = MonthTargetModel::firstOrCreate(
                        [
                            'quarter_id' => $quarter->id,
                            'month' => $monthNumber
                        ]
                    );
                }
                $month = $monthCache[$monthKey];
                $affectedMonthIds[$month->id] = $month->id;

                //  WEEK
                // [$startDate, $endDate] = $this->getWeekDates($monthNumber, $row['year'], $row['week']);
                [$startDate, $endDate] = $this->getWeekDates($monthNumber, $actualYear, $row['week']);

                WeekTargetModel::updateOrCreate(
                    [
                        'month_id' => $month->id,
                        'week' => $row['week']
                    ],
                    [
                        'percentage' => $row['percentage'],
                        'target_amount' => $row['target'],
                        'pre_sale' => $row['pre_sale'],
                        'post_sale' => $row['post_sale'],
                        'week_start_date' => $startDate,
                        'week_end_date' => $endDate
                    ]
                );


                $monthKeyForPayload = $row['company'] . '_' . $row['year'] . '_' . $monthNumber;

                if (!isset($payloads[$monthKeyForPayload])) {
                    $payloads[$monthKeyForPayload] = [
                        'entity_id' => $entity_id,
                        'branch_id' => $erp_branch_id,
                        'year' => $row['year'],
                        'month' => $monthNumber,
                        'quarter' => $financial_year_id,
                        // 'date' => Carbon::create($row['year'], $monthNumber, 1)->toDateString(),
                        'date' => Carbon::create($actualYear, $monthNumber, 1)->toDateString(),

                        'monthly_target' => 0,
                        'pre_sale' => 0,
                        'post_sale' => 0,

                        'weeks' => []
                    ];
                }


                $payloads[$monthKeyForPayload]['weeks'][] = [
                    'week' => $row['week'],
                    'percentage' => $row['percentage'],
                    'target_amount' => $row['target'],
                    'pre_sale' => $row['pre_sale'],
                    'post_sale' => $row['post_sale'],
                    'start_day' => $startDate,
                    'end_day' => $endDate,
                ];


                // ACCUMULATE TOTALS
                $payloads[$monthKeyForPayload]['monthly_target'] += $row['target'];
                $payloads[$monthKeyForPayload]['pre_sale'] += $row['pre_sale'];
                $payloads[$monthKeyForPayload]['post_sale'] += $row['post_sale'];
            }

            //  ONLY UPDATE AFFECTED DATA
            $this->updateTotalsOptimized($affectedMonthIds, $affectedQuarterIds, $affectedYearIds);

            if (!empty($payloads)) {
                $firstPayload = reset($payloads);
                $entityId = $firstPayload['entity_id'];
            }




            DB::commit();

            $this->dispatchWebhooks([
                'entity_id' => $entity_id,
                'targets' => array_values($payloads)
            ], 1, 'UPDATE_TARGET_HOOK');

            return response()->json(['status' => true]);
        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'msg' => $e->getMessage()
            ]);
        }
    }



    private function updateTotalsOptimized($monthIds, $quarterIds, $yearIds)
    {
        //  MONTH TOTALS (single query)
        $monthTotals = WeekTargetModel::whereIn('month_id', $monthIds)
            ->groupBy('month_id')
            ->selectRaw('month_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($monthTotals as $m) {
            MonthTargetModel::where('id', $m->month_id)->update([
                'target_amount' => $m->t ?? 0,
                'pre_sale' => $m->pre ?? 0,
                'post_sale' => $m->post ?? 0,
            ]);
        }

        //  QUARTER TOTALS
        $quarterTotals = MonthTargetModel::whereIn('quarter_id', $quarterIds)
            ->groupBy('quarter_id')
            ->selectRaw('quarter_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($quarterTotals as $q) {
            QuarterTargetModel::where('id', $q->quarter_id)->update([
                'target_amount' => $q->t ?? 0,
                'pre_sale' => $q->pre ?? 0,
                'post_sale' => $q->post ?? 0,
            ]);
        }

        //  YEAR TOTALS
        $yearTotals = QuarterTargetModel::whereIn('yearly_id', $yearIds)
            ->groupBy('yearly_id')
            ->selectRaw('yearly_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($yearTotals as $y) {
            YearlyTargetModel::where('id', $y->yearly_id)->update([
                'total_target' => $y->t ?? 0,
                'total_pre_sale' => $y->pre ?? 0,
                'total_post_sale' => $y->post ?? 0,
            ]);
        }
    }

    private function getWeekDates($monthNumber, $year, $week)
    {
        $startDay = match ($week) {
            1 => 1,
            2 => 8,
            3 => 15,
            4 => 22,
            default => 1
        };

        $endDay = match ($week) {
            1 => 7,
            2 => 14,
            3 => 21,
            4 => \Carbon\Carbon::create($year, $monthNumber)->endOfMonth()->day,
            default => 7
        };

        $start = \Carbon\Carbon::create($year, $monthNumber, $startDay)->toDateString();
        $end   = \Carbon\Carbon::create($year, $monthNumber, $endDay)->toDateString();

        return [$start, $end];
    }


    


    public function IncentiveRoles(Request $request)
    {
        $entity_id = $request->entity_id;
        $setErpRoleIds = [];
        if ($entity_id == 1) {
        } elseif ($entity_id == 2) {
            $setErpRoleIds = ['11', '14', '15', '16', '22', '17', '19',];
        } elseif ($entity_id == 3) {
        } elseif ($entity_id == 4) {
        } elseif ($entity_id == 5) {
        }
        $user = UserRoleModel::where('status', 0)
            ->where('entity_id', $entity_id)
            ->whereIn('erp_role_id', $setErpRoleIds)
            ->orderBy('sno', 'asc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $user
        ], 200);
    }


    public function getCollectionData(Request $request)
    {
        try {

            $branchId = $request->branch_id;
            $entity_id = $request->entity_id;
            $monthFilter = $request->get('month_year', date('M-Y'));
            try {
                $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);
            } catch (\Exception $e) {
                $parsedDate = now();
            }

            $month = (int) $parsedDate->month;
            $year  = (int) $parsedDate->year;

           

            $collectionData = TargetAchievementModel::where('status','!=',2)
                                                    ->whereMonth('achieved_date',$month)
                                                    ->whereYear('achieved_date',$year)
                                                    ->where('branch_id',$branchId)
                                                    ->sum('achieved_amount');
                      
            return response()->json([
                'status' => true,
                'collection_amount' => round($collectionData,2)
            ]);
        } catch (\Exception $e) {

            \Log::error('Achieve API Error: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Server Error'
            ]);
        }
    }

    // public function getCollectionTable(Request $request)
    // {
    //     try {

    //         $entityId = $request->entity_id;
    //         $branchId = $request->branch_id;

    //         $data = TargetAchievementModel::select(
    //                 'egc_entity.entity_name',
    //                 'egc_branch.branch_name',
    //                 DB::raw('YEAR(achieved_date) as year'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=4 THEN achieved_amount ELSE 0 END) as apr'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=5 THEN achieved_amount ELSE 0 END) as may'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=6 THEN achieved_amount ELSE 0 END) as jun'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=7 THEN achieved_amount ELSE 0 END) as jul'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=8 THEN achieved_amount ELSE 0 END) as aug'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=9 THEN achieved_amount ELSE 0 END) as sep'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=10 THEN achieved_amount ELSE 0 END) as oct'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=11 THEN achieved_amount ELSE 0 END) as nov'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=12 THEN achieved_amount ELSE 0 END) as dece'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=1 THEN achieved_amount ELSE 0 END) as jan'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=2 THEN achieved_amount ELSE 0 END) as feb'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=3 THEN achieved_amount ELSE 0 END) as mar'),
    //                 DB::raw('SUM(achieved_amount) as total')
    //             )
    //             ->where('egc_target_achievements.status', '!=', 2)
    //             ->leftJoin('egc_entity','egc_target_achievements.entity_id','=','egc_entity.sno')
    //             ->leftJoin('egc_branch','egc_target_achievements.branch_id','=','egc_branch.sno')
    //             ->when($entityId, function ($q) use ($entityId) {
    //                 $q->where('egc_target_achievements.entity_id', $entityId);
    //             })
    //             ->when($branchId, function ($q) use ($branchId) {
    //                 $q->where('egc_target_achievements.branch_id', $branchId);
    //             })
    //             ->groupBy('egc_entity.entity_name','egc_branch.branch_name',DB::raw('YEAR(egc_target_achievements.achieved_date)'))
    //             ->orderBy('egc_entity.sno', 'asc')
    //             ->get();

    //         return response()->json([
    //             'status' => true,
    //             'data' => $data
    //         ]);

    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => $e->getMessage()
    //         ]);
    //     }
    // }


    public function getCollectionTable(Request $request)
    {
        try {

            $entityId = $request->entity_id;
            $branchId = $request->branch_id;

            $branches = DB::table('egc_branch')
                ->select(
                    'egc_branch.sno',
                    'egc_branch.branch_name',
                    'egc_entity.entity_name'
                )
                ->leftJoin('egc_entity', 'egc_branch.entity_id', '=', 'egc_entity.sno')
                ->when($entityId, function ($q) use ($entityId) {
                    $q->where('egc_branch.entity_id', $entityId);
                })
                ->when($branchId, function ($q) use ($branchId) {
                    $q->where('egc_branch.sno', $branchId);
                })
                ->where('egc_branch.status', 0)
                ->orderBy('egc_entity.sno', 'asc')
                ->orderBy('egc_branch.sno', 'asc')
                ->get();


            $records = TargetAchievementModel::select(
                    'branch_id',
                    'achieved_amount',
                    'achieved_date'
                )
                ->where('status', '!=', 2)
                ->when($entityId, function ($q) use ($entityId) {
                    $q->where('entity_id', $entityId);
                })
                ->when($branchId, function ($q) use ($branchId) {
                    $q->where('branch_id', $branchId);
                })
                ->orderBy('achieved_date', 'asc')
                ->get();


            $grouped = [];

            foreach ($records as $row) {

                $date = Carbon::parse($row->achieved_date);

                $monthYear = $date->format('M-Y');

                if (!isset($grouped[$monthYear])) {

                    $grouped[$monthYear] = [
                        'month_year' => $monthYear,
                        'sort_date'  => $date->format('Y-m'),
                        'branches'   => [],
                        'total'      => 0
                    ];
                }

                if (!isset($grouped[$monthYear]['branches'][$row->branch_id])) {

                    $grouped[$monthYear]['branches'][$row->branch_id] = 0;
                }

                $grouped[$monthYear]['branches'][$row->branch_id] += $row->achieved_amount;

                $grouped[$monthYear]['total'] += $row->achieved_amount;
            }


            usort($grouped, function ($a, $b) {

                return strtotime($a['sort_date']) <=> strtotime($b['sort_date']);
            });

            return response()->json([

                'status'  => true,
                'branches'=> $branches,
                'data'    => array_values($grouped)
            ]);

        } catch (\Exception $e) {

            return response()->json([

                'status' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function updateCollection(Request $request)
    {
        DB::beginTransaction();

        try {

            $user_id = $request->user()->user_id ?? 0;

            $request->validate([
                'entity_id' => 'required',
                'branch_id' => 'required',
                'month_year' => 'required',
                'amount' => 'required|numeric|min:0'
            ]);

            $parsedDate = Carbon::createFromFormat(
                'M-Y',
                $request->month_year
            );
            $month = $parsedDate->month;
            $year  = $parsedDate->year;

            if (in_array($month, [4,5,6])) {
                $quarter = 1;
            } elseif (in_array($month, [7,8,9])) {
                $quarter = 2;
            } elseif (in_array($month, [10,11,12])) {
                $quarter = 3;
            } else {
                $quarter = 4;
            }

            $achievedDate = Carbon::create(
                $year,
                $month,
                1
            )->endOfMonth();

            $financialYear = $month >= 4
                ? $year
                : $year - 1;

            $record = TargetAchievementModel::where(
                    'entity_id',
                    $request->entity_id
                )
                ->where(
                    'branch_id',
                    $request->branch_id
                )
                ->whereMonth('achieved_date', $month)
                ->whereYear('achieved_date', $year)
                ->first();

            if ($record) {

                $record->update([
                    'achieved_amount' => $request->amount,
                    'updated_by' => $user_id,
                    'updated_at' => now()
                ]);

            } else {
                TargetAchievementModel::create([

                    'entity_id' => $request->entity_id,
                    'branch_id' => $request->branch_id,

                    'year' => $year,
                    'quarter' => $quarter,
                    'month' => $month,
                    'week' => 4,

                    'achieved_amount' => $request->amount,

                    'pre_sale' => 0,
                    'post_sale' => 0,

                    'source' => 'manual',
                    'reference_id' => null,

                    'achieved_date' => $achievedDate,

                    'created_by' => $user_id,
                    'updated_by' => $user_id,

                    'status' => 0
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Collection updated successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ]);
        }
    }


//    public function comparisonChart(Request $request)
// {
//     $entityId = $request->entity_id;
//     $branchId = $request->branch_id;

//     $financialYear = (int)$request->year;

//     $current = TargetAchievementModel::where(
//             'entity_id',
//             $entityId
//         )
//         ->where('branch_id', $branchId)
//         ->where('year', $financialYear)
//         ->where('status', '!=', 2)
//         ->get();

//     $previous = TargetAchievementModel::where(
//             'entity_id',
//             $entityId
//         )
//         ->where('branch_id', $branchId)
//         ->where('year', $financialYear - 1)
//         ->where('status', '!=', 2)
//         ->get();

//     $months = [
//         4 => 'Apr',
//         5 => 'May',
//         6 => 'Jun',
//         7 => 'Jul',
//         8 => 'Aug',
//         9 => 'Sep',
//         10 => 'Oct',
//         11 => 'Nov',
//         12 => 'Dec',
//         1 => 'Jan',
//         2 => 'Feb',
//         3 => 'Mar',
//     ];

//     $labels = [];
//     $currentData = [];
//     $previousData = [];

//     foreach ($months as $monthNo => $monthName) {

//         $labels[] = $monthName;

//         $currentData[] =
//             (float) $current
//                 ->where('month', $monthNo)
//                 ->sum('achieved_amount');

//         $previousData[] =
//             (float) $previous
//                 ->where('month', $monthNo)
//                 ->sum('achieved_amount');
//     }

//     $currentTotal = array_sum($currentData);
//     $previousTotal = array_sum($previousData);

//     $growth = 0;

//     if ($previousTotal > 0) {

//         $growth = round(
//             (($currentTotal - $previousTotal)
//                 / $previousTotal) * 100,
//             2
//         );
//     }


//     $trendYears = [
//         $financialYear - 2,
//         $financialYear - 1,
//         $financialYear
//     ];

//     $trendData = [];

//     foreach ($trendYears as $fy) {

//         $total = TargetAchievementModel::where(
//                 'entity_id',
//                 $entityId
//             )
//             ->where('branch_id', $branchId)
//             ->where('year', $fy)
//             ->where('status', '!=', 2)
//             ->sum('achieved_amount');

//         $trendData[] = round($total, 2);
//     }

//     return response()->json([
//         'months' => $labels,
//         'current_year' => $financialYear,
//         'previous_year' => $financialYear - 1,
//         'current_total' => $currentTotal,
//         'previous_total' => $previousTotal,
//         'growth' => $growth,
//         'current_data' => $currentData,
//         'previous_data' => $previousData,
//         'trend_labels' => [
//             ($financialYear - 2) . '-' . ($financialYear - 1),
//             ($financialYear - 1) . '-' . ($financialYear),
//             ($financialYear) . '-' . ($financialYear + 1)
//         ],
//         'trend_data' => $trendData

//     ]);
// }

public function comparisonChart(Request $request)
{
    $entityId = $request->entity_id;
    $branchId = $request->branch_id;

    $financialYear = (int) $request->year;
    

    $months = [
        4 => 'Apr',
        5 => 'May',
        6 => 'Jun',
        7 => 'Jul',
        8 => 'Aug',
        9 => 'Sep',
        10 => 'Oct',
        11 => 'Nov',
        12 => 'Dec',
        1 => 'Jan',
        2 => 'Feb',
        3 => 'Mar',
    ];

    $current = TargetAchievementModel::where('entity_id', $entityId)
    ->where('branch_id', $branchId)
    ->where(function ($q) use ($financialYear) {
        $q->where(function ($sub) use ($financialYear) {
            $sub->where('year', $financialYear)
                ->whereIn('month', [4,5,6,7,8,9,10,11,12]);
        })->orWhere(function ($sub) use ($financialYear) {
            $sub->where('year', $financialYear + 1)
                ->whereIn('month', [1,2,3]);
        });
    })
    ->where('status', '!=', 2)
    ->get();

    $previous = TargetAchievementModel::where('entity_id', $entityId)
        ->where('branch_id', $branchId)
        ->where(function ($q) use ($financialYear) {
            $q->where(function ($sub) use ($financialYear) {
                $sub->where('year', $financialYear - 1)
                    ->whereIn('month', [4,5,6,7,8,9,10,11,12]);
            })->orWhere(function ($sub) use ($financialYear) {
                $sub->where('year', $financialYear)
                    ->whereIn('month', [1,2,3]);
            });
        })
        ->where('status', '!=', 2)
        ->get();

    $labels = [];

    $currentData = [];
    $previousData = [];
    $monthlyAchievement = [];

    foreach ($months as $monthNo => $monthName) {
        $labels[] = $monthName;
        $currentAmount = (float) $current->where('month', $monthNo)->sum('achieved_amount');
        $previousAmount =(float) $previous->where('month', $monthNo)->sum('achieved_amount');
        $currentData[] = round($currentAmount, 2);
        $previousData[] = round($previousAmount, 2);

        $monthlyAchievement[] = [
            'month' => $monthName,
            'current' => round($currentAmount, 2),
            'previous' => round($previousAmount, 2)
        ];
    }

    $currentTotal = array_sum($currentData);
    $previousTotal = array_sum($previousData);

    $growth = 0;

    if ($previousTotal > 0) {
        $growth = round( (($currentTotal - $previousTotal) /$previousTotal) * 100,2);
    }

    $growthAmount = round( $currentTotal - $previousTotal, 2);

    $trendLabels = [];
    $trendData = [];
    $yearlyBreakdown = [];

    for ($fy = $financialYear - 2; $fy <= $financialYear; $fy++) {

            $yearTotal = TargetAchievementModel::where('entity_id', $entityId)
                ->where('branch_id', $branchId)
                ->where(function ($q) use ($fy) {

                    // Apr-Dec of FY start year
                    $q->where(function ($sub) use ($fy) {
                        $sub->where('year', $fy)
                            ->whereIn('month', [4,5,6,7,8,9,10,11,12]);
                    })

                    // Jan-Mar of FY end year
                    ->orWhere(function ($sub) use ($fy) {
                        $sub->where('year', $fy + 1)
                            ->whereIn('month', [1,2,3]);
                    });

                })
                ->where('status', '!=', 2)
                ->sum('achieved_amount');

            $label = "FY {$fy}-" . ($fy + 1);

            $trendLabels[] = $label;
            $trendData[] = round($yearTotal, 2);

            $yearlyBreakdown[] = [
                'financial_year' => $label,
                'amount' => round($yearTotal, 2)
            ];
    }

    $bestMonthAmount = max($currentData);
    $bestMonthIndex = array_search($bestMonthAmount,$currentData);
    $bestMonth = $labels[$bestMonthIndex] ?? '-';


    $achievementScore = 0;
    if ($previousTotal > 0) {
        $achievementScore = min(100,max( 0,round(($currentTotal / $previousTotal) * 100,0)) );
    }

    $insight = '';
    if ($growth >= 25) {
        $insight = 'Exceptional financial growth compared to previous financial year.';
    }elseif ($growth >= 10) {
        $insight = 'Healthy business growth with strong collection performance.';
    }elseif ($growth > 0) {
        $insight ='Moderate growth observed. Additional focus can improve performance.';
    }else {
        $insight ='Collection performance declined compared to previous financial year.';
    }

    return response()->json([
        'current_total' =>round($currentTotal, 2),
        'previous_total' => round($previousTotal, 2),
        'growth' =>$growth,
        'growth_amount' => $growthAmount,
        'achievement_score' =>$achievementScore,
        'current_year' => $financialYear,
        'previous_year' =>$financialYear - 1,
        'months' => $labels,
        'current_data' =>$currentData,
        'previous_data' =>$previousData,
        'trend_labels' => $trendLabels,
        'trend_data' =>$trendData,
        'yearly_breakdown' =>$yearlyBreakdown,
        'best_month' =>$bestMonth,
        'best_month_amount' => round($bestMonthAmount, 2),
        'executive_insight' => $insight,
        'monthly_breakdown' => $monthlyAchievement
    ]);
}


    private function buildEmptyQuarterData($financialYear, $achievementData)
    {
        $structure = [
            'Q1' => [4,5,6],
            'Q2' => [7,8,9],
            'Q3' => [10,11,12],
            'Q4' => [1,2,3],
        ];

        $quarters = [];

        foreach ($structure as $quarter => $months) {

            $quarterNo = (int) str_replace('Q','',$quarter);

            $quarterActual = $achievementData->where('quarter',$quarterNo);

            $quarterData = [
                'quarter' => $quarter,

                'target_amount' => 0,
                'actual_amount' => (float)$quarterActual->sum('achieved_amount'),

                'pre_sale_target' => 0,
                'pre_sale_actual' => (int)$quarterActual->sum('pre_sale'),

                'post_sale_target' => 0,
                'post_sale_actual' => (int)$quarterActual->sum('post_sale'),

                'achievement_percent' => 0,

                'months' => []
            ];

            foreach ($months as $month) {

                $year = $month >= 4 ? $financialYear : ($financialYear + 1);

                $monthActual = $quarterActual->where('month',$month);

                $quarterData['months'][] = [

                    'month' => $month,

                    'target_amount' => 0,
                    'actual_amount' => (float)$monthActual->sum('achieved_amount'),

                    'pre_sale_target' => 0,
                    'pre_sale_actual' => (int)$monthActual->sum('pre_sale'),

                    'post_sale_target' => 0,
                    'post_sale_actual' => (int)$monthActual->sum('post_sale'),

                    'achievement_percent' => 0,

                    'weeks' => $this->buildEmptyWeeks(
                        $year,
                        $month,
                        $quarterNo,
                        $achievementData
                    ),
                ];
            }

            $quarters[] = $quarterData;
        }

        return collect($quarters);
    }

    private function buildEmptyWeeks($year, $month, $quarterNo, $achievementData)
    {
        $weeks = [];

        $lastDay = \Carbon\Carbon::create($year, $month, 1)
            ->endOfMonth()
            ->day;

        $ranges = [
            [1,7],
            [8,14],
            [15,21],
            [22,$lastDay],
        ];

        foreach ($ranges as $index => $range) {

            $weekNo = $index + 1;

            $weekActual = $achievementData
                ->where('quarter', $quarterNo)
                ->where('month', $month)
                ->where('week', $weekNo);

            $weeks[] = [

                'week' => $weekNo,

                'target_amount' => 0,
                'actual_amount' => (float)$weekActual->sum('achieved_amount'),

                'pre_sale_target' => 0,
                'pre_sale_actual' => (int)$weekActual->sum('pre_sale'),

                'post_sale_target' => 0,
                'post_sale_actual' => (int)$weekActual->sum('post_sale'),

                'achievement_percent' => 0,

                'week_start_date' => sprintf(
                    '%04d-%02d-%02d',
                    $year,
                    $month,
                    $range[0]
                ),

                'week_end_date' => sprintf(
                    '%04d-%02d-%02d',
                    $year,
                    $month,
                    $range[1]
                ),
            ];
        }

        return $weeks;
    }


    // public function comparisonFinancialYears(Request $request)
    // {
    //     $entityId = $request->entity_id;
    //     $branchId = $request->branch_id;

    //     $years = TargetAchievementModel::where('entity_id', $entityId)
    //         ->where('branch_id', $branchId)
    //         ->where('status','!=',2)
    //         ->select('year')
    //         ->distinct()
    //         ->orderBy('year')
    //         ->pluck('year')
    //         ->toArray();


    //     $financialYears = [];

    //     foreach ($years as $year) {

    //         if ($year == null) {
    //             continue;
    //         }

    //         $financialYear = $year;
    //         $janMarExists = TargetAchievementModel::where('entity_id',$entityId)
    //             ->where('branch_id',$branchId)
    //             ->where('year',$year)
    //             ->whereIn('month',[1,2,3])
    //             ->exists();

    //         if($janMarExists){
    //             $financialYear = $year - 1;
    //         }

    //         $financialYears[$financialYear] = [
    //             'value'=>$financialYear,
    //             'label'=>"FY {$financialYear}-".($financialYear+1)
    //         ];
    //     }

    //     ksort($financialYears);

    //     return response()->json([
    //         'status'=>true,
    //         'data'=>array_values($financialYears)
    //     ]);
    // }
    public function comparisonFinancialYears(Request $request)
    {
        $entityId = $request->entity_id;
        $branchId = $request->branch_id;

        $years = TargetAchievementModel::where('entity_id', $entityId)
            ->where('branch_id', $branchId)
            ->where('status', '!=', 2)
            ->select('year')
            ->distinct()
            ->orderBy('year')
            ->pluck('year')
            ->toArray();

        $financialYears = [];

        foreach ($years as $year) {

            if (!$year) {
                continue;
            }

            $financialYear = $year;

            $janMarExists = TargetAchievementModel::where('entity_id', $entityId)
                ->where('branch_id', $branchId)
                ->where('year', $year)
                ->whereIn('month', [1,2,3])
                ->exists();

            if ($janMarExists) {
                $financialYear = $year - 1;
            }

            $financialYears[$financialYear] = [
                'value' => $financialYear,
                'label' => "FY {$financialYear}-" . ($financialYear + 1),
            ];
        }

        // Always include current financial year
        $currentYear = now()->year;
        $currentMonth = now()->month;

        $currentFinancialYear = ($currentMonth >= 4)
            ? $currentYear
            : $currentYear - 1;

        if (!isset($financialYears[$currentFinancialYear])) {

            $financialYears[$currentFinancialYear] = [
                'value' => $currentFinancialYear,
                'label' => "FY {$currentFinancialYear}-" . ($currentFinancialYear + 1),
            ];

        }

        ksort($financialYears);

        return response()->json([
            'status' => true,
            'data' => array_values($financialYears)
        ]);
    }

    public function comparisonDashboard(Request $request)
    {
        $request->validate([
            'entity_id'=>'required|integer',
            'branch_id'=>'required|integer',
            'financial_years'=>'required|array|min:1'
        ]);

        

        $entityId = $request->entity_id;
        $branchId = $request->branch_id;
        $financialYears = collect($request->financial_years)
                            ->unique()
                            ->sort()
                            ->values();

            $months = [
                4=>'Apr',
                5=>'May',
                6=>'Jun',
                7=>'Jul',
                8=>'Aug',
                9=>'Sep',
                10=>'Oct',
                11=>'Nov',
                12=>'Dec',
                1=>'Jan',
                2=>'Feb',
                3=>'Mar'
            ];

            $series = [];
            $yearCards = [];
            $monthlyTable = [];
            $trendLabels = [];
            $trendData = [];

            $currentDate = Carbon::now();

            $currentFinancialYear = $currentDate->month >= 4
                ? $currentDate->year
                : $currentDate->year - 1;

            $currentMonth = $months[$currentDate->month] ?? null;
            $monthOrder = array_values($months);

            $currentMonthIndex = array_search($currentMonth, $monthOrder);

            $currentSeriesName = "FY {$currentFinancialYear}-" . ($currentFinancialYear + 1);

            foreach($financialYears as $fy){

                $records = TargetAchievementModel::where('entity_id',$entityId)
                ->where('branch_id',$branchId)
                ->where(function($q) use($fy){
                    $q->where(function($sub) use($fy){
                        $sub->where('year',$fy)
                            ->whereIn('month',[4,5,6,7,8,9,10,11,12]);
                    })->orWhere(function($sub) use($fy){
                        $sub->where('year',$fy+1)
                            ->whereIn('month',[1,2,3]);
                    });

                })
                ->where('status','!=',2)
                ->get();

                $chartData=[];
                $pointColors = [];
                $yearTotal=0;

                foreach($months as $monthNo=>$monthName){
                    $amount=(float)$records
                            ->where('month',$monthNo)
                            ->sum('achieved_amount');

                    $chartData[] = round($amount,2);
                    $monthlyTable[$monthName]["FY {$fy}-".($fy+1)] = round($amount,2);
                    $yearTotal += $amount;
                    if (
                        $fy == $currentFinancialYear &&
                        $monthName == $currentMonth
                    ) {
                        $pointColors[] = "#27e700e7";
                    } else {
                        $pointColors[] = null;
                    }

                }

                $series[]=[
                    'name'=>"FY {$fy}-".($fy+1),
                    'data'=>$chartData,
                     'colors' => $pointColors
                ];

                $yearCards[]=[
                    'financial_year'=>$fy,
                    'label'=>"FY {$fy}-".($fy+1),
                    'total'=>round($yearTotal,2)
                ];

                $trendLabels[]="FY {$fy}-".($fy+1);
                $trendData[]=round($yearTotal,2);

            }

        $bestYear = collect($yearCards)->sortByDesc('total')->first();
        $worstYear = collect($yearCards)->sortBy('total')->first();
        $average = round(collect($yearCards)->avg('total'), 2);
        $growth = 0;

        if(count($yearCards)>=2){
            $first = $yearCards[0]['total'];
            $last = end($yearCards)['total'];
            if($first>0){
                $growth = round((($last-$first)/$first)*100,2);
            }
        }
        $table=[];

        foreach($monthlyTable as $month=>$row){
            $row['month']=$month;
            $table[]=$row;
        }

        $achievement = 0;

        if ($bestYear['total'] > 0) {
            $achievement = round(
                ($yearCards[count($yearCards)-1]['total'] / $bestYear['total']) * 100,
                0
            );
        }

            $currentAnnotation = null;

            foreach ($series as $s) {
                if ($s['name'] === $currentSeriesName) {

                    $currentAnnotation = [
                        'series_name' => $currentSeriesName,
                        'series_index' => array_search($s, $series),
                        'month' => $currentMonth,
                        'month_index' => $currentMonthIndex,
                        'value' => $s['data'][$currentMonthIndex]
                    ];

                    break;
                }
            }
            

        return response()->json([
            'status'=>true,
            'months'=>array_values($months),
            'series'=>$series,
            'trend'=>[
                'labels'=>$trendLabels,
                'data'=>$trendData
            ],
            'cards'=>$yearCards,
            'best_year'=>$bestYear,
            'worst_year'=>$worstYear,
            'average_collection'=>$average,
            'overall_growth'=>$growth,
             'achievement'=>$achievement,
            'table'=>$table,
            'current_financial_year' => $currentFinancialYear,
            'current_month' => $currentMonth,
             'current_annotation' => $currentAnnotation
        ]);
    }
}
