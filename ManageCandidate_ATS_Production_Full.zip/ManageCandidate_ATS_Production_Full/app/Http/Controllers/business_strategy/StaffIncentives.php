<?php

namespace App\Http\Controllers\business_strategy;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\StaffModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Cache;


class StaffIncentives extends Controller
{

    public function index(Request $request)
    {
        $page          = $request->input('page', 1);
        $perpage       = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';
        $month          = $request->month ?? date('Y');

        

        // if ($request->ajax()) {

        //     $entityId    = $request->entity_id;
        //     $branchId    = $request->branch_id;
           
        //     $erpBranchId = $request->branch_id;
        //     $roleId      = $request->role_id;
        //     $monthYear   = $request->month_year;

        //     $entityData = DB::table('egc_entity')->where('sno',$entityId)->first();
        //     $baseurl     = $entityData ? $entityData->entity_base_url : NULL;
        //     if (!$baseurl) {
        //         return response()->json([
        //             'status' => false,
        //             'message' => 'Invalid URL'
        //         ], 422);
        //     }


        //     $verifyKey = 'egcsecret2030datagetapierp';

        //     $cacheKey = "staff_incentive_{$erpBranchId}_{$roleId}_{$monthYear}";

           

        //             $apiUrl = rtrim($baseurl, '/') .
        //                 "/api/get_incentive_by_role?" .
        //                 http_build_query([
        //                     'branch_id'  => $erpBranchId,
        //                     'verify_key' => $verifyKey,
        //                     'role_id'    => $roleId,
        //                     'month_year' => $monthYear,
        //                 ]);

        //            $response=  Http::timeout(60)
        //                 ->acceptJson()
        //                 ->get($apiUrl)
        //                 ->json();
                
            
        //     //   return  $response;

        //     if (
        //         empty($response['status']) ||
        //         empty($response['data'])
        //     ) {
        //         return response()->json([
        //             'status' => false,
        //             'message' => 'No data found',
        //             'data' => []
        //         ]);
        //     }

        //     $externalIds = collect($response['data'])
        //         ->pluck('external_uuid')
        //         ->filter()
        //         ->toArray();

        //     $staffImages = StaffModel::whereIn('sno', $externalIds)
        //         ->get()
        //         ->keyBy('sno');

        //     $data = collect($response['data'])->map(function ($staff) use ($staffImages) {

        //         $staffModel = $staffImages->get($staff['external_uuid']);

        //         $staff['staff_image'] = $staffModel
        //             ? $staffModel->profile_image_url
        //             : asset('assets/egc_images/auth/user_2.png');

        //         return $staff;
        //     })->values();

        //     return response()->json([
        //         'status' => true,
        //         'message' => 'Incentive data fetched successfully',
        //         'generated_at' => now()->format('Y-m-d H:i:s'),
        //         'total_staff' => $data->count(),
        //         'data' => $data,
        //     ]);
        // }
        if ($request->ajax()) {

            $entityId    = $request->entity_id;
            $erpBranchId = $request->branch_id;
            $roleId      = $request->role_id;
            $monthYear   = $request->month_year;

            $entityData = DB::table('egc_entity')
                ->where('sno', $entityId)
                ->first();

            $branchData = DB::table('egc_branch')
                ->where('entity_id', $entityId)
                ->where('erp_branch_id', $erpBranchId)
                ->where('status', 0)
                ->first();

            $pdfMeta = [
                'entity_id'       => $entityId,
                'branch_id'       => $branchData?->sno,
                'entity_name'     => $entityData?->entity_name,
                'entity_base_color'     => $entityData?->entity_base_color,
                'company_logo'    => $entityData?->entity_logo,
                'branch_name'     => $branchData?->branch_name,
                'signature_image' => $branchData?->cert_auth_sign,
            ];

            try {
                $date = Carbon::createFromFormat('M-Y', $monthYear);
                $month = $date->format('m');
                $year  = $date->format('Y');
            } catch (\Exception $e) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid month format'
                ], 422);
            }

            /*
            |--------------------------------------------------------------------------
            | First Check Local Database
            |--------------------------------------------------------------------------
            */

            $savedIncentives = DB::table('egc_staff_incentives')
                        ->where('entity_id', $entityId)
                        ->where('erp_branch_id', $erpBranchId)
                        ->where('erp_role_id', $roleId)
                        ->where('month', $month)
                        ->where('year', $year)
                        ->where('status', 0)
                        ->get();

            // return $savedIncentives;

            if ($savedIncentives->isNotEmpty()) {

                $staffs = StaffModel::whereIn(
                        'sno',
                        $savedIncentives->pluck('staff_id')
                    )
                    ->get()
                    ->keyBy('sno');

                $data = $savedIncentives->map(function ($row) use ($staffs) {

                    $staff = $staffs->get($row->staff_id);

                    return [
                        'external_uuid' => $row->staff_id,
                        'staff_name'    => $staff?->staff_name,
                        'role_id'       => $row->erp_role_id,
                        'staff_image'   => $staff?->profile_image_url
                            ?? asset('assets/egc_images/auth/user_2.png'),

                        'total_award' => (float) $row->total_amount,

                        'breakdown' => json_decode($row->breakdown, true) ?? [],
                        'metrics'   => json_decode($row->metrics, true) ?? [],
                        'next_update'   =>NULL,
                        'last_updated'   => $row->updated_at,
                    ];
                })->values();

                return response()->json([
                    'status' => true,
                    'isSaved' => true,
                    'message' => 'Incentive data fetched from local database',
                    'generated_at' => now()->format('Y-m-d H:i:s'),
                    'source' => 'database',
                    'total_staff' => $data->count(),
                    'data' => $data,
                    'pdf_meta' => $pdfMeta,
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | Not Found -> Call ERP API
            |--------------------------------------------------------------------------
            */

            $entityData = DB::table('egc_entity')
                ->where('sno', $entityId)
                ->first();

            $baseurl = $entityData->entity_base_url ?? null;

            if (!$baseurl) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid URL'
                ], 422);
            }

            $verifyKey = 'egcsecret2030datagetapierp';

            $apiUrl = rtrim($baseurl, '/') .
                "/api/get_incentive_by_role?" .
                http_build_query([
                    'branch_id' => $erpBranchId,
                    'verify_key' => $verifyKey,
                    'role_id' => $roleId,
                    'month_year' => $monthYear,
                ]);

            $response = Http::timeout(60)
                ->acceptJson()
                ->get($apiUrl)
                ->json();

            if (
                empty($response['status']) ||
                empty($response['data'])
            ) {
                return response()->json([
                    'status' => false,
                    'message' => 'No data found',
                    'data' => [],
                ]);
            }

            $externalIds = collect($response['data'])
                ->pluck('external_uuid')
                ->filter()
                ->toArray();

            $staffImages = StaffModel::whereIn('sno', $externalIds)
                ->get()
                ->keyBy('sno');

            $data = collect($response['data'])->map(function ($staff) use ($staffImages) {

                $staffModel = $staffImages->get($staff['external_uuid']);

                $staff['staff_image'] = $staffModel
                    ? $staffModel->profile_image_url
                    : asset('assets/egc_images/auth/user_2.png');

                return $staff;
            })->values();

            return response()->json([
                'status' => true,
                'isSaved' => false,
                'message' => 'Incentive data fetched successfully',
                'generated_at' => now()->format('Y-m-d H:i:s'),
                'source' => 'api',
                'total_staff' => $data->count(),
                'data' => $data,
                'pdf_meta' => $pdfMeta,
            ]);
        }
        $entity_list = ManageEntityModel::where('status', 0)->get();
        return view(
            'content.hr_management.hr_sib.manage_incentive.staff_incentives',
            [
                'entity_list' => $entity_list,
            ]
        );
    }

    public function edit_target(Request $request)
    {
        $entity_list = ManageEntityModel::where('status', 0)->get();
        $week_settings = TargetWeekSettingModel::where('status', 0)
            ->orderBy('week_no')
            ->get();
        return view('content.control_panel.entity_hub.manage_targets.update_targets', compact('entity_list', 'week_settings'));
    }

    public function import(Request $request)
    {
        $file = $request->file('file_upload');

        $spreadsheet = IOFactory::load($file->getPathname());

        $sheetNames = $spreadsheet->getSheetNames();

        $year = null;

        // ✅ FIND SUMMARY SHEET
        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {

                $summarySheet = $spreadsheet->getSheet($index);
                $rows = $summarySheet->toArray();

                // 👉 adjust based on your summary format
                foreach ($rows as $row) {
                    foreach ($row as $cell) {

                        if (preg_match('/20\d{2}/', $cell, $matches)) {
                            $year = (int)$matches[0];
                            break 2;
                        }
                    }
                }
            }
        }

        if (!$year) {
            throw new \Exception('Year not found in summary sheet');
        }

        // ================= MULTI SHEET =================
        $sheets = [];
        $entityCounter = 1;

        foreach ($sheetNames as $index => $sheetName) {

            if (stripos($sheetName, 'summary') !== false) {
                continue;
            }

            // ✅ PASS YEAR HERE
            $sheets[$index] = new TargetSheetImport($entityCounter, $year);

            $entityCounter++;
        }

        Excel::import(new class($sheets) implements WithMultipleSheets {

            private $sheets;

            public function __construct($sheets)
            {
                $this->sheets = $sheets;
            }

            public function sheets(): array
            {
                return $this->sheets;
            }
        }, $file);

        return response()->json(['success' => true]);
    }

    public function preview(Request $request)
    {
        $data = Excel::toArray([], $request->file('file'));

        return response()->json($data[0]);
    }



    public function getData(Request $request)
    {
        $query = WeekTargetModel::with([
            'month.quarter.yearly'
        ])
            ->whereHas('month.quarter.yearly', function ($q) use ($request) {
                $q->where('year', $request->year)
                    ->where('branch_id', $request->branch_id);
            });

        $data = $query->get();

        return response()->json([
            'data' => $data,
            'is_existing' => $data->isNotEmpty() // ✅ KEY FLAG
        ]);
    }




    public function saveData(Request $request)
    {
        DB::beginTransaction();

        try {

            $yearCache = [];
            $quarterCache = [];
            $monthCache = [];

            $affectedYearIds = [];
            $affectedQuarterIds = [];
            $affectedMonthIds = [];
            $payloads = [];
            $entityId = null;

            $branch_id = $request->branch_id;
            $entity_id = $request->entity_id;
            $branchData = DB::table('egc_branch')->where('sno', $branch_id)->first();
            $erp_branch_id = $branchData ? $branchData->erp_branch_id : 1;

            foreach ($request->data as $row) {

                // $monthNumber = Carbon::parse("1 " . $row['month'])->month;
                $monthNumber = Carbon::parse("1 " . $row['month'])->month;

                // ✅ Financial Year Fix
                $actualYear = $row['year'];

                if (in_array($monthNumber, [1, 2, 3])) {
                    $actualYear = $row['year'] + 1;
                }

                $yearKey = $row['company'] . '_' . $row['year'];

                //  YEAR CACHE
                if (!isset($yearCache[$yearKey])) {
                    $yearCache[$yearKey] = YearlyTargetModel::firstOrCreate(
                        [
                            'entity_id' => $entity_id,
                            'branch_id' => $branch_id,
                            'year' => $row['year']
                        ]
                    );
                }
                $yearly = $yearCache[$yearKey];
                $affectedYearIds[$yearly->id] = $yearly->id;

                //  QUARTER CACHE
                $quarterKey = $yearly->id . '_' . $row['quarter'];



                if (!isset($quarterCache[$quarterKey])) {


                    $financial_year_id = $row['quarter'];


                    $quarterCache[$quarterKey] = QuarterTargetModel::firstOrCreate(
                        [
                            'yearly_id' => $yearly->id,
                            'quarter' => $row['quarter'],
                            'financial_year_id' => $row['quarter'],
                            'financial_year' => $actualYear,
                        ]
                    );
                }
                $quarter = $quarterCache[$quarterKey];
                $affectedQuarterIds[$quarter->id] = $quarter->id;

                //  MONTH CACHE
                $monthKey = $quarter->id . '_' . $monthNumber;



                if (!isset($monthCache[$monthKey])) {
                    $monthCache[$monthKey] = MonthTargetModel::firstOrCreate(
                        [
                            'quarter_id' => $quarter->id,
                            'month' => $monthNumber
                        ]
                    );
                }
                $month = $monthCache[$monthKey];
                $affectedMonthIds[$month->id] = $month->id;

                //  WEEK
                // [$startDate, $endDate] = $this->getWeekDates($monthNumber, $row['year'], $row['week']);
                [$startDate, $endDate] = $this->getWeekDates($monthNumber, $actualYear, $row['week']);

                WeekTargetModel::updateOrCreate(
                    [
                        'month_id' => $month->id,
                        'week' => $row['week']
                    ],
                    [
                        'percentage' => $row['percentage'],
                        'target_amount' => $row['target'],
                        'pre_sale' => $row['pre_sale'],
                        'post_sale' => $row['post_sale'],
                        'week_start_date' => $startDate,
                        'week_end_date' => $endDate
                    ]
                );


                $monthKeyForPayload = $row['company'] . '_' . $row['year'] . '_' . $monthNumber;

                if (!isset($payloads[$monthKeyForPayload])) {
                    $payloads[$monthKeyForPayload] = [
                        'entity_id' => $entity_id,
                        'branch_id' => $erp_branch_id,
                        'year' => $row['year'],
                        'month' => $monthNumber,
                        'quarter' => $financial_year_id,
                        // 'date' => Carbon::create($row['year'], $monthNumber, 1)->toDateString(),
                        'date' => Carbon::create($actualYear, $monthNumber, 1)->toDateString(),

                        'monthly_target' => 0,
                        'pre_sale' => 0,
                        'post_sale' => 0,

                        'weeks' => []
                    ];
                }


                $payloads[$monthKeyForPayload]['weeks'][] = [
                    'week' => $row['week'],
                    'percentage' => $row['percentage'],
                    'target_amount' => $row['target'],
                    'pre_sale' => $row['pre_sale'],
                    'post_sale' => $row['post_sale'],
                    'start_day' => $startDate,
                    'end_day' => $endDate,
                ];


                // ACCUMULATE TOTALS
                $payloads[$monthKeyForPayload]['monthly_target'] += $row['target'];
                $payloads[$monthKeyForPayload]['pre_sale'] += $row['pre_sale'];
                $payloads[$monthKeyForPayload]['post_sale'] += $row['post_sale'];
            }

            //  ONLY UPDATE AFFECTED DATA
            $this->updateTotalsOptimized($affectedMonthIds, $affectedQuarterIds, $affectedYearIds);

            if (!empty($payloads)) {
                $firstPayload = reset($payloads);
                $entityId = $firstPayload['entity_id'];
            }




            DB::commit();

            $this->dispatchWebhooks([
                'entity_id' => $entity_id,
                'targets' => array_values($payloads)
            ], 1, 'UPDATE_TARGET_HOOK');

            return response()->json(['status' => true]);
        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'msg' => $e->getMessage()
            ]);
        }
    }



    private function updateTotalsOptimized($monthIds, $quarterIds, $yearIds)
    {
        //  MONTH TOTALS (single query)
        $monthTotals = WeekTargetModel::whereIn('month_id', $monthIds)
            ->groupBy('month_id')
            ->selectRaw('month_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($monthTotals as $m) {
            MonthTargetModel::where('id', $m->month_id)->update([
                'target_amount' => $m->t ?? 0,
                'pre_sale' => $m->pre ?? 0,
                'post_sale' => $m->post ?? 0,
            ]);
        }

        //  QUARTER TOTALS
        $quarterTotals = MonthTargetModel::whereIn('quarter_id', $quarterIds)
            ->groupBy('quarter_id')
            ->selectRaw('quarter_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($quarterTotals as $q) {
            QuarterTargetModel::where('id', $q->quarter_id)->update([
                'target_amount' => $q->t ?? 0,
                'pre_sale' => $q->pre ?? 0,
                'post_sale' => $q->post ?? 0,
            ]);
        }

        //  YEAR TOTALS
        $yearTotals = QuarterTargetModel::whereIn('yearly_id', $yearIds)
            ->groupBy('yearly_id')
            ->selectRaw('yearly_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($yearTotals as $y) {
            YearlyTargetModel::where('id', $y->yearly_id)->update([
                'total_target' => $y->t ?? 0,
                'total_pre_sale' => $y->pre ?? 0,
                'total_post_sale' => $y->post ?? 0,
            ]);
        }
    }

    private function getWeekDates($monthNumber, $year, $week)
    {
        $startDay = match ($week) {
            1 => 1,
            2 => 8,
            3 => 15,
            4 => 22,
            default => 1
        };

        $endDay = match ($week) {
            1 => 7,
            2 => 14,
            3 => 21,
            4 => \Carbon\Carbon::create($year, $monthNumber)->endOfMonth()->day,
            default => 7
        };

        $start = \Carbon\Carbon::create($year, $monthNumber, $startDay)->toDateString();
        $end   = \Carbon\Carbon::create($year, $monthNumber, $endDay)->toDateString();

        return [$start, $end];
    }


    


    public function IncentiveRoles(Request $request)
    {
        $entity_id = $request->entity_id;
        $setErpRoleIds = [];
        if ($entity_id == 1) {
        } elseif ($entity_id == 2) {
            $setErpRoleIds = ['11', '14', '15', '16', '22', '17', '19',];
        } elseif ($entity_id == 3) {
        } elseif ($entity_id == 4) {
        } elseif ($entity_id == 5) {
        }
        $user = UserRoleModel::where('status', 0)
            ->where('entity_id', $entity_id)
            ->whereIn('erp_role_id', $setErpRoleIds)
            ->orderBy('sno', 'asc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $user
        ], 200);
    }


    public function getCollectionData(Request $request)
    {
        try {

            $branchId = $request->branch_id;
            $entity_id = $request->entity_id;
            $monthFilter = $request->get('month_year', date('M-Y'));
            try {
                $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);
            } catch (\Exception $e) {
                $parsedDate = now();
            }

            $month = (int) $parsedDate->month;
            $year  = (int) $parsedDate->year;

           

            $collectionData = TargetAchievementModel::where('status','!=',2)
                                                    ->whereMonth('achieved_date',$month)
                                                    ->whereYear('achieved_date',$year)
                                                    ->where('branch_id',$branchId)
                                                    ->sum('achieved_amount');
                      
            return response()->json([
                'status' => true,
                'collection_amount' => round($collectionData,2)
            ]);
        } catch (\Exception $e) {

            \Log::error('Achieve API Error: ' . $e->getMessage());

            return response()->json([
                'status' => false,
                'message' => 'Server Error'
            ]);
        }
    }

    // public function getCollectionTable(Request $request)
    // {
    //     try {

    //         $entityId = $request->entity_id;
    //         $branchId = $request->branch_id;

    //         $data = TargetAchievementModel::select(
    //                 'egc_entity.entity_name',
    //                 'egc_branch.branch_name',
    //                 DB::raw('YEAR(achieved_date) as year'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=4 THEN achieved_amount ELSE 0 END) as apr'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=5 THEN achieved_amount ELSE 0 END) as may'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=6 THEN achieved_amount ELSE 0 END) as jun'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=7 THEN achieved_amount ELSE 0 END) as jul'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=8 THEN achieved_amount ELSE 0 END) as aug'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=9 THEN achieved_amount ELSE 0 END) as sep'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=10 THEN achieved_amount ELSE 0 END) as oct'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=11 THEN achieved_amount ELSE 0 END) as nov'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=12 THEN achieved_amount ELSE 0 END) as dece'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=1 THEN achieved_amount ELSE 0 END) as jan'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=2 THEN achieved_amount ELSE 0 END) as feb'),
    //                 DB::raw('SUM(CASE WHEN MONTH(achieved_date)=3 THEN achieved_amount ELSE 0 END) as mar'),
    //                 DB::raw('SUM(achieved_amount) as total')
    //             )
    //             ->where('egc_target_achievements.status', '!=', 2)
    //             ->leftJoin('egc_entity','egc_target_achievements.entity_id','=','egc_entity.sno')
    //             ->leftJoin('egc_branch','egc_target_achievements.branch_id','=','egc_branch.sno')
    //             ->when($entityId, function ($q) use ($entityId) {
    //                 $q->where('egc_target_achievements.entity_id', $entityId);
    //             })
    //             ->when($branchId, function ($q) use ($branchId) {
    //                 $q->where('egc_target_achievements.branch_id', $branchId);
    //             })
    //             ->groupBy('egc_entity.entity_name','egc_branch.branch_name',DB::raw('YEAR(egc_target_achievements.achieved_date)'))
    //             ->orderBy('egc_entity.sno', 'asc')
    //             ->get();

    //         return response()->json([
    //             'status' => true,
    //             'data' => $data
    //         ]);

    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => $e->getMessage()
    //         ]);
    //     }
    // }


    public function getCollectionTable(Request $request)
    {
        try {

            $entityId = $request->entity_id;
            $branchId = $request->branch_id;

            $branches = DB::table('egc_branch')
                ->select(
                    'egc_branch.sno',
                    'egc_branch.branch_name',
                    'egc_entity.entity_name'
                )
                ->leftJoin('egc_entity', 'egc_branch.entity_id', '=', 'egc_entity.sno')
                ->when($entityId, function ($q) use ($entityId) {
                    $q->where('egc_branch.entity_id', $entityId);
                })
                ->when($branchId, function ($q) use ($branchId) {
                    $q->where('egc_branch.sno', $branchId);
                })
                ->where('egc_branch.status', 0)
                ->orderBy('egc_entity.sno', 'asc')
                ->orderBy('egc_branch.sno', 'asc')
                ->get();


            $records = TargetAchievementModel::select(
                    'branch_id',
                    'achieved_amount',
                    'achieved_date'
                )
                ->where('status', '!=', 2)
                ->when($entityId, function ($q) use ($entityId) {
                    $q->where('entity_id', $entityId);
                })
                ->when($branchId, function ($q) use ($branchId) {
                    $q->where('branch_id', $branchId);
                })
                ->orderBy('achieved_date', 'asc')
                ->get();


            $grouped = [];

            foreach ($records as $row) {

                $date = Carbon::parse($row->achieved_date);

                $monthYear = $date->format('M-Y');

                if (!isset($grouped[$monthYear])) {

                    $grouped[$monthYear] = [
                        'month_year' => $monthYear,
                        'sort_date'  => $date->format('Y-m'),
                        'branches'   => [],
                        'total'      => 0
                    ];
                }

                if (!isset($grouped[$monthYear]['branches'][$row->branch_id])) {

                    $grouped[$monthYear]['branches'][$row->branch_id] = 0;
                }

                $grouped[$monthYear]['branches'][$row->branch_id] += $row->achieved_amount;

                $grouped[$monthYear]['total'] += $row->achieved_amount;
            }


            usort($grouped, function ($a, $b) {

                return strtotime($a['sort_date']) <=> strtotime($b['sort_date']);
            });

            return response()->json([

                'status'  => true,
                'branches'=> $branches,
                'data'    => array_values($grouped)
            ]);

        } catch (\Exception $e) {

            return response()->json([

                'status' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function updateCollection(Request $request)
    {
        DB::beginTransaction();

        try {

            $user_id = $request->user()->user_id ?? 0;

            $request->validate([
                'entity_id' => 'required',
                'branch_id' => 'required',
                'month_year' => 'required',
                'amount' => 'required|numeric|min:0'
            ]);

            $parsedDate = Carbon::createFromFormat(
                'M-Y',
                $request->month_year
            );
            $month = $parsedDate->month;
            $year  = $parsedDate->year;

            if (in_array($month, [4,5,6])) {
                $quarter = 1;
            } elseif (in_array($month, [7,8,9])) {
                $quarter = 2;
            } elseif (in_array($month, [10,11,12])) {
                $quarter = 3;
            } else {
                $quarter = 4;
            }

            $achievedDate = Carbon::create(
                $year,
                $month,
                1
            )->endOfMonth();

            $financialYear = $month >= 4
                ? $year
                : $year - 1;

            $record = TargetAchievementModel::where(
                    'entity_id',
                    $request->entity_id
                )
                ->where(
                    'branch_id',
                    $request->branch_id
                )
                ->whereMonth('achieved_date', $month)
                ->whereYear('achieved_date', $year)
                ->first();

            if ($record) {

                $record->update([
                    'achieved_amount' => $request->amount,
                    'updated_by' => $user_id,
                    'updated_at' => now()
                ]);

            } else {
                TargetAchievementModel::create([

                    'entity_id' => $request->entity_id,
                    'branch_id' => $request->branch_id,

                    'year' => $year,
                    'quarter' => $quarter,
                    'month' => $month,
                    'week' => 4,

                    'achieved_amount' => $request->amount,

                    'pre_sale' => 0,
                    'post_sale' => 0,

                    'source' => 'manual',
                    'reference_id' => null,

                    'achieved_date' => $achievedDate,

                    'created_by' => $user_id,
                    'updated_by' => $user_id,

                    'status' => 0
                ]);
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Collection updated successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function SaveIncentive(Request $request)
    {
        DB::beginTransaction();

        try {

            $monthYear = $request->month_year;
            $entity_id = $request->entity_id;
            $erp_branch_id = $request->erp_branch_id;

            $date = Carbon::createFromFormat(
                'M-Y',
                $monthYear
            );

            $month = $date->format('m');
            $year  = $date->format('Y');

            $userId = $request->user()->user_id ?? 0;

            foreach ($request->incentives as $item) {

                $breakdown = $item['breakdown'] ?? [];
                $metrics = $item['metrics'] ?? [];

                $tenxAchieved =
                    isset($breakdown['10X Award']) &&
                    $breakdown['10X Award'] > 0
                    ? 1
                    : 0;
                $staff_id = $item['external_uuid'];

                $staff =DB::table('egc_staff')->where('sno',$staff_id)->first();

                DB::table('egc_staff_incentives')
                    ->updateOrInsert(
                        [
                            'staff_id' => $item['external_uuid'],
                            'month'    => $month,
                            'year'     => $year,
                        ],
                        [
                            'breakdown'      => json_encode(
                                $breakdown,
                                JSON_UNESCAPED_UNICODE
                            ),
                            'metrics'      => json_encode(
                                $metrics,
                                JSON_UNESCAPED_UNICODE
                            ),
                            'entity_id'   => $entity_id ?? 0,
                            'erp_branch_id'   => $erp_branch_id ?? 0,
                            'role_id'      => $staff->role_id ?? NULL,
                            'erp_role_id'   => $item['role_id'] ?? 0,
                            'total_amount'   => $item['total_award'] ?? 0,
                            'tenx_achieved'  => $tenxAchieved,
                            'updated_by'     => $userId,
                            'updated_at'     => now(),
                            'created_by'     => $userId,
                            'created_at'     => now(),
                            'status'         => 0,
                        ]
                    );
                    if( $tenxAchieved == 1){
                         DB::table('egc_staff_tenx_log')
                            ->updateOrInsert(
                            [
                                'staff_id' => $item['external_uuid'],
                                'month'    => $month,
                                'year'     => $year,
                            ],
                            [
                            
                                'entity_id'   => $entity_id ?? 0,
                                'job_role_id'   => $staff->job_role_id ?? 0,
                                'role_id'      => $staff->role_id ?? NULL,
                                'total_amount'   =>  $breakdown['10X Award'] ?? 0,
                                'tenx_achieved'  => $tenxAchieved,
                                'updated_by'     => $userId,
                                'updated_at'     => now(),
                                'created_by'     => $userId,
                                'created_at'     => now(),
                                'status'         => 0,
                            ]
                        );
                    }
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Incentive data saved successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
