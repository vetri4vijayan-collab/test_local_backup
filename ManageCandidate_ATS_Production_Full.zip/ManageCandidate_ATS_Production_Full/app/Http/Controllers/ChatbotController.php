<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ChatbotController extends Controller
{
    public function handle(Request $request)
    {
        $apiToken = env('HF_API_TOKEN'); // Hugging Face API token
        $modelId = 'YOUR_ANY_TO_ANY_MODEL_ID'; // Replace with the model you subscribed to

        $payload = [];
        $inputType = $request->input('type', 'text'); // default text
        $message = $request->input('message', '');

        // Handling uploaded file
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $fileContent = base64_encode(file_get_contents($file->getRealPath()));
            $payload['inputs'] = $fileContent;
        } else if ($inputType === 'text') {
            $payload['inputs'] = $message;
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$apiToken}",
                'Content-Type' => 'application/json'
            ])->post("https://api-inference.huggingface.co/models/{$modelId}", $payload);

            $result = $response->json();

            // The output may vary by model; typically `generated_text` or similar
            $reply = $result[0]['generated_text'] ?? 'No response from AI';

            return response()->json(['reply' => $reply]);

        } catch (\Exception $e) {
            return response()->json(['reply' => 'Error: ' . $e->getMessage()]);
        }
    }
}