<?php

namespace App\Http\Controllers\settings\interview;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRoleModel;
use App\Models\InterviewCategoryModel;
use App\Models\FeedbackSectionModel;
use App\Models\FeedbackQuestionModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class FeedbackQuestion extends Controller
{
   

    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = FeedbackQuestionModel::
          select(
            'egc_feedback_question.*',
            'egc_interview_category.interview_category_name',
            'egc_feedback_section.section_name',
            'egc_languages.name as language_name',
            )
        ->leftJoin('egc_interview_category', 'egc_feedback_question.interview_category_id', '=', 'egc_interview_category.sno')
        ->join('egc_feedback_section', 'egc_feedback_question.feedback_section_id', '=', 'egc_feedback_section.sno')
        ->join('egc_languages', 'egc_feedback_question.language_id', '=', 'egc_languages.sno')
        ->where( 'egc_feedback_question.status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_interview_category.interview_category_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_feedback_question.field_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_feedback_question.field_option', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_feedback_section.section_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'egc_feedback_question.sno', 'desc' )->paginate($perpage);
       
        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                // $question_list = FeedbackQuestionModel::select('egc_feedback_question.*')->where('job_role_id',$item->job_role_id)->where('interview_category_id',$item->interview_category_id)->where( 'status', '!=', 2 )->get();
                // $question_count=count($question_list);
                // $question_encrypt = $item->job_role_id .'~'.$item->interview_category_id;
                return [
                    'sno' => $item->sno,
                    'interview_category_id' => $item->interview_category_id,
                    'question_name' => $item->question_name,
                    'question_type' => $item->question_type,
                    'question_option' => $item->question_option,
                    'language_name' => $item->language_name,
                    'section_name' => $item->section_name,
                    'interview_category_name' => $item->interview_category_name,
                    'job_role_name' => $item->job_role_name,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.interview.feedback_question.feedback_question_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    function AddForm(Request $request){
        $interviewCategoryList = InterviewCategoryModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'ASC' )->get();
        $sectionList = FeedbackSectionModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'ASC' )->get();
        return view('content.settings.interview.feedback_question.feedback_question_add',[
            'interviewCategoryList'=>$interviewCategoryList,
            'sectionList'=>$sectionList,
        ]);
    }



    public function Edit($id,Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $exp = explode('~', $decryptedValue);
        $job_role_id = str_replace(' ', '', $exp[0] ?? '');
        $interview_category_id = str_replace(' ', '', $exp[1] ?? '');
        $entity_id =0;
        if($job_role_id){
            $jobRoleData= DB::table('egc_job_role')->where('sno',$job_role_id)->first();
            $entity_id =$jobRoleData ? $jobRoleData->entity_id : 0;
        }

        $question_list = FeedbackQuestionModel::where([
            'job_role_id' => $job_role_id,
            'interview_category_id' => $interview_category_id
        ])->where('status', '!=', 2)->get()->map(function ($q) {
            return [
                'edit_id'     => $q->sno,
                'label_name'  => $q->field_name,
                'label_value' => $q->field_value,
                'options'     => $q->field_option ? json_decode($q->field_option, true) : [],
            ];
        });
     
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list = ManageEntityModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $interviewCategoryList = FeedbackSectionModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        return view(
            'content.settings.interview.feedback_question.feedback_question_edit',[
                'interviewCategoryList'=>$interviewCategoryList,
                'question_list'=>$question_list,
                'company_list'=>$company_list,
                'entity_list'=>$entity_list,
                'job_role_id'=>$job_role_id,
                'entity_id'=>$entity_id,
                'interview_category_id'=>$interview_category_id,
            ]);
    }

    public function ListDisplay($id, Request $request)
    {   

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }


        $customer_type_id = $decryptedValue;

        $options = FeedbackQuestionModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type_option.sno as customer_type_option_id',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.customer_type_id', $customer_type_id)
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'asc') // Order by sno ascending to maintain order
            ->get();

        $result = $options->map(function ($item) {
            // Process dependencies
            $dependsOnArray = $item->depends_on ? json_decode($item->depends_on, true) : [];

            return [
                'customer_type_id' => $item->customer_type_id,
                'cus_type_opt_id' => $item->cus_type_opt_id,
                'customer_type_name' => $item->customer_type_name,
                'customer_type_option_id' => $item->customer_type_option_id,
                'field_name' => $item->field_name,
                'field_value' => $item->field_value,
                'field_option' => $item->field_option ? json_decode($item->field_option, true) : [],
                'is_depends' => $item->is_depends,
                'depends_on' => $dependsOnArray,
                'is_mandatory' => $item->is_mandatory,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    public function List()
    {
        $option = FeedbackQuestionModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type_option.sno as customer_type_option_id',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            return [
                'customer_type_id' => $firstItem->customer_type_id,
                'cus_type_opt_id' => $firstItem->cus_type_opt_id,
                'customer_type_name' => $firstItem->customer_type_name,
                'customer_type_option_id' => $items->pluck('customer_type_option_id')->implode(','),
                'field_name' => $items->pluck('field_name')->implode(','),
                'field_value' => $items->pluck('field_value')->implode(','),
                'field_option' => $items->pluck('field_option')->map(function ($option) {
                    return json_decode($option);
                })->toArray(),
                'is_depends' => $items->pluck('is_depends')->implode(','),
                'depends_on' => $items->pluck('depends_on')->implode(','),
                'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }


    public function View($id)
    {
        $cus_ids = explode(',', $id);

        // Get the first value from the array
        $cus_type_opt_id = $cus_ids[0];

        $editcategory = FeedbackQuestionModel::where('sno', $cus_type_opt_id)->first();
        $option = FeedbackQuestionModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.cus_type_opt_id', $editcategory->cus_type_opt_id)
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'asc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            $fieldOptions = $items->pluck('field_option')->map(function ($option) {
                return json_decode($option);
            })->toArray();

            return [
                'customer_type_name' => $firstItem->customer_type_name,
                'fields' => $items->map(function ($item) {
                    return [
                        'field_name' => $item->field_name,
                        'field_value' => $item->field_value,
                        'field_option' => json_decode($item->field_option, true),
                        'is_depends' => $item->is_depends,
                        'depends_on' => $item->depends_on,
                        'is_mandatory' => $item->is_mandatory,
                    ];
                })->toArray()
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    private function generateCustomerTypeOptionId()
    {
        $year = date('y');

        $latestRecord = FeedbackQuestionModel::orderBy('sno', 'desc')->first();

        if (!$latestRecord) {
            return "FDBKQ-0001/$year";
        }

        $latestId = $latestRecord->feedback_question_id;

        // Extract number from FDBKQ-0001/25
        preg_match('/FDBKQ-(\d{4})\/\d{2}/', $latestId, $matches);

        $nextNumber = isset($matches[1]) ? intval($matches[1]) + 1 : 1;

        return sprintf("FDBKQ-%04d/%s", $nextNumber, $year);
    }


    public function Add(Request $request)
{
    // Debugging only: remove or comment this line in production
    // return $request;

    // ✅ Validation
    $validator = Validator::make($request->all(), [
        'label_names' => 'required|array',
        'label_values' => 'required|array',
        // 'options' => 'required|array',
        // 'options.*.*.label' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Incorrect format input fields!',
        ]);
        return redirect()->back()->withErrors($validator)->withInput();
    }

    // ✅ Setup
    $user_id = $request->user()->user_id;
    $section_id = $request->section_id;
    $language_id = $request->language;
    $interview_category_id = $request->interview_category_id;
    
    $feedback_question_id = $this->generateCustomerTypeOptionId();
    // return $interview_question_id;
    // ✅ Loop through each main question
    foreach ($request->label_names as $index => $label_name) {
        
        
        $field_name = ucfirst(trim($label_name));
        $field_value = $request->label_values[$index] ?? '';
        $field_options = [];

        // Build options array
        foreach ($request->options[$index] ?? [] as $optionIndex => $option) {
            if (!empty($option['label'])) {
                $field_options[] = [
                    'value' => $optionIndex,
                    'label' => $option['label'],
                ];
            }
        }


        // ✅ Save main question
        $main = new FeedbackQuestionModel();
        $main->feedback_question_id = $feedback_question_id;
        $main->interview_category_id = $interview_category_id;
        $main->language_id = $language_id;
        $main->feedback_section_id = $section_id;
        $main->question_name = $field_name;
        $main->question_type = $field_value;
        $main->question_option = !empty($field_options) ? json_encode($field_options) : null;
        $main->created_by = $user_id;
        $main->updated_by = $user_id;
        $main->save();

       
    }

    // ✅ Success toast
    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Question added successfully!',
    ]);

    return redirect('settings/feedback_question');
}

    public function AddNew(Request $request)
    {
        
        // ✅ Validation
        $validator = Validator::make($request->all(), [
            'label_names' => 'required|array',
            'label_values' => 'required|array',
            // 'options' => 'required|array',
            // 'options.*.*.label' => 'nullable|string',
        ]);
        if ($validator->fails()) {
    
            return response([
                'status'    => 500,
                'message'   => 'Incorrect format input fields!',
                'error_msg' => 'Incorrect format input fields!',
                'data'      => $request->all(),
                ], 500);
        }

        // ✅ Setup
        $user_id = $request->user()->user_id;
        $job_role_id = $request->job_role_id;
        $interview_category_id = $request->interview_category_id;
        
        $interview_question_id = $this->generateCustomerTypeOptionId();
        // return $interview_question_id;
        // ✅ Loop through each main question
        foreach ($request->label_names as $index => $label_name) {
            
            
            $field_name = ucfirst(trim($label_name));
            $field_value = $request->label_values[$index] ?? '';
            $field_options = [];

            // Build options array
            foreach ($request->options[$index] ?? [] as $optionIndex => $option) {
                if (!empty($option['label'])) {
                    $field_options[] = [
                        'value' => $optionIndex,
                        'label' => $option['label'],
                    ];
                }
            }


            // ✅ Save main question
            $main = new FeedbackQuestionModel();
            $main->interview_question_id = $interview_question_id;
            $main->interview_category_id = $interview_category_id;
            $main->job_role_id = $job_role_id;
            $main->field_name = $field_name;
            $main->field_value = $field_value;
            $main->field_option = !empty($field_options) ? json_encode($field_options) : null;
            $main->created_by = $user_id;
            $main->updated_by = $user_id;
            $main->save();

        
        }
        
        return response([
            'status'    => 200,
            'message'   => 'Question added successfully',
            'error_msg' => null,
            'data'      => null,
            ], 200);
        
    }

    public function EditPage($id)
    {
        $customer_type = FeedbackQuestionModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $customer_type
        ], 200);
    }

    public function Update(Request $request)
    {

       
        $request->validate([
            'job_role_id' => 'required',
            'interview_category_id' => 'required',
            'questions' => 'required|string'
        ]);

        $questions = json_decode($request->questions, true);
        $user_id = $request->user()->user_id;
        //  return $user_id;
        foreach ($questions as $q) {

            $field_options = null;

            if (!empty($q['options'])) {
                $field_options = json_encode(array_values($q['options']));
            }

            // 🔁 UPDATE
            if (!empty($q['edit_id']) && $q['edit_id'] > 0) {
                
                FeedbackQuestionModel::where('sno', $q['edit_id'])->update([
                    'field_name'   => ucfirst(trim($q['label_name'])),
                    'field_value'  => $q['label_value'],
                    'field_option' => $field_options,
                    'updated_by'   => $user_id ?? 0,
                ]);

            } 
            // ➕ INSERT
            else {
                FeedbackQuestionModel::create([
                    'interview_question_id' => $this->generateCustomerTypeOptionId(),
                    'job_role_id'           => $request->job_role_id,
                    'interview_category_id' => $request->interview_category_id,
                    'field_name'            => ucfirst(trim($q['label_name'])),
                    'field_value'           => $q['label_value'],
                    'field_option'          => $field_options,
                    'created_by'            => $user_id ?? 0,
                    'updated_by'            => $user_id ?? 0,
                ]);
            }
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Interview Questions updated successfully!',
        ]);

        return redirect('settings/interview_question');
    }


    public function Delete($id)
    {
        $upd_CourseCategoryModel =  FeedbackQuestionModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  FeedbackQuestionModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

}
