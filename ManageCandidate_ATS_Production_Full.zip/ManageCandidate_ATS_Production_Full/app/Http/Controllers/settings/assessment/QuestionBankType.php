<?php

namespace App\Http\Controllers\settings\assessment;

use App\Http\Controllers\Controller;
use App\Models\ExamSectionModel;
use App\Models\QuestionBankTypeModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class QuestionBankType extends Controller
{
    public function index()
    {
        $lists = QuestionBankTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.exam_settings.question_bank_type', compact('lists'));
    }

    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'qtn_bnk_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->qtn_bnk_name;

        $check = QuestionBankTypeModel::where('status', '!=', 2)->where('question_bank_type', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = new QuestionBankTypeModel();
        $create->question_bank_type = $name;
        $create->desc = $request->desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Type Created Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type Creation Failed!'
            ]);
        }
    }

    public function Status($id, Request $request)
    {
        $status = QuestionBankTypeModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = QuestionBankTypeModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Exam Section Deleted Succesfully',
            'error_msg' => 'Exam Section Deletion Failed !',
            'data' => null,
        ]);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_qtn_bnk_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 402,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 402);
        }

        $user_id = $request->user()->user_id;
        $name = $request->edit_qtn_bnk_name;
        $sno = $request->edit_id;

        $check = QuestionBankTypeModel::where('status', '!=', 2)->where('sno', '!=', $sno)->where('question_bank_type', $name)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type Already Exists.'
            ]);

            return redirect()->back();
        }

        $create = QuestionBankTypeModel::where('status', '!=', 2)->where('sno', $sno)->first();
        $create->question_bank_type = $name;
        $create->desc = $request->edit_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->update();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Type Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type Updation Failed!'
            ]);
        }
    }
}
