<?php

namespace App\Http\Controllers\settings\assessment;

use App\Http\Controllers\Controller;
use App\Models\ExamGuidelinesModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExamGuideLines extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $guidelines = ExamGuidelinesModel::where('status', '!=', 2)->latest()->first();
        return view('content.settings.assessment.exam_guidelines.exam_guidelines', compact('guidelines','perpage','search_filter'));
    }

    public function store(Request $request) {
        // return $request;
        $create = ExamGuidelinesModel::latest()->first() ?? new ExamGuidelinesModel();
        $create->exam_guidelines = $request->add_text;
        $create->created_by = $request->user()->user_id;
        $create->updated_by = $request->user()->user_id;
        $create->save();

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Guidelines Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Guidelines Creation Failed!'
            ]);

            return redirect()->back();
        }
    }
}
