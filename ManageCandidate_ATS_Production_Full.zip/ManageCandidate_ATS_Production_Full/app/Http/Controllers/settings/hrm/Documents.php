<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DocumentModel;
use Illuminate\Support\Facades\Validator;

class Documents extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = DocumentModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('document_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('document_desc', 'LIKE', "%{$search_filter}%")
                    ->orWhere('document_id', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'document_name' => $item->document_name,
                    'document_desc' => $item->document_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.hrm.document.documents',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = DocumentModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'document_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $document_name       = $request->document_name;
            $document_desc          = $request->document_desc;
            $user_id                    = 1;
            $chk = DocumentModel::where( 'document_name', $document_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Document is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = DocumentModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $document_id = 'DOC-0001/' . $year;
                } else {

                    $data = $category_check->document_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int )$result + 1;
                    $request = sprintf( 'DOC-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $document_id = $request . '/' . $year;
                }

                $add_branchtype = new DocumentModel();
                $add_branchtype->document_id         = $document_id;
                $add_branchtype->document_name       = $document_name;
                $add_branchtype->document_desc       = $document_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Document added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Document!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'document_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $document_name       = $request->document_name;
            $document_desc       = $request->document_desc;
            $document_id       = $request->edit_id;

            $upd_DocumentModel =  DocumentModel::where( 'sno', $document_id )->first();

            $chk = DocumentModel::where( 'document_name', $document_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Document is exist!'
                ] );
                return redirect()->back();
            }

            $upd_DocumentModel->document_name  = $document_name;
            $upd_DocumentModel->document_desc  = $document_desc;
            $upd_DocumentModel->update();

            if ( $upd_DocumentModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Document Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Document!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_DocumentModel = DocumentModel::where( 'sno', $id )->first();
        $upd_DocumentModel->status  = 2;
        $upd_DocumentModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Document Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_DocumentModel =  DocumentModel::where( 'sno', $id )->first();
        $upd_DocumentModel->status = $request->input( 'status', 0 );
        $upd_DocumentModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
