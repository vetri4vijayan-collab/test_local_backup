<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PermissionReasonModel;
use Illuminate\Support\Facades\Validator;
use App\Models\SubErpWebhookModel;
use App\Models\ManageEntityModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;

class PermissionReason extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PermissionReasonModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('reason_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('description', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'reason_name' => $item->reason_name,
                    'description' => $item->description,
                    'comments_check' => $item->comments_check,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.hrm.permission_reason.permission_reason',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = PermissionReasonModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'reason_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $reason_name       = $request->reason_name;
             $comments_check    = $request->comments_check ? 1 : 0;
            $description          = $request->description;
            $user_id                    = 1;
            $chk = PermissionReasonModel::where( 'reason_name', $reason_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Permission Reason is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = PermissionReasonModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                $add_branchtype = new PermissionReasonModel();
                $add_branchtype->reason_name       = $reason_name;
                $add_branchtype->comments_check    = $comments_check;
                $add_branchtype->description       = $description;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
                    foreach($entity_list as $entity_id){
                        $this->dispatchWebhooks($add_branchtype, 1,'ADD_PERMISSION_REASON',$entity_id);
                    }
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Permission Reason added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Permission Reason!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'reason_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $reason_name       = $request->reason_name;
             $comments_check    = $request->comments_check ? 1 : 0;
            $description       = $request->description;
            $document_id       = $request->edit_id;

            $upd_PermissionReasonModel =  PermissionReasonModel::where( 'sno', $document_id )->first();

            $chk = PermissionReasonModel::where( 'reason_name', $reason_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Permission Reason is exist!'
                ] );
                return redirect()->back();
            }

            $upd_PermissionReasonModel->reason_name  = $reason_name;
            $upd_PermissionReasonModel->comments_check  = $comments_check;
            $upd_PermissionReasonModel->description  = $description;
            $upd_PermissionReasonModel->update();

            if ( $upd_PermissionReasonModel ) {
                $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
                    foreach($entity_list as $entity_id){
                        $this->dispatchWebhooks($upd_PermissionReasonModel, 1,'ADD_PERMISSION_REASON',$entity_id);
                    }
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Permission Reason Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Permission Reason!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_PermissionReasonModel = PermissionReasonModel::where( 'sno', $id )->first();
        $upd_PermissionReasonModel->status  = 2;
        $upd_PermissionReasonModel->Update();

        if($upd_PermissionReasonModel){
             $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
            foreach($entity_list as $entity_id){
                $this->dispatchWebhooks($upd_PermissionReasonModel, 1,'UPDATE_PERMISSION_REASON',$entity_id);
            }
        }

        return response( [
            'status'    => 200,
            'message'   => 'Permission Reason Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_PermissionReasonModel =  PermissionReasonModel::where( 'sno', $id )->first();
        $upd_PermissionReasonModel->status = $request->input( 'status', 0 );
        $upd_PermissionReasonModel->update();

        if($upd_PermissionReasonModel){
             $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
            foreach($entity_list as $entity_id){
                $this->dispatchWebhooks($upd_PermissionReasonModel, 1,'UPDATE_PERMISSION_REASON',$entity_id);
            }
        }

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
