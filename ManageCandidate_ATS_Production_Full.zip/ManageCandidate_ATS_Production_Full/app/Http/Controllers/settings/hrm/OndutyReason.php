<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OnDutyReasonModel;
use Illuminate\Support\Facades\Validator;
use App\Models\SubErpWebhookModel;
use App\Models\ManageEntityModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;

class OndutyReason extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = OnDutyReasonModel::where('status', '!=', 2);
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('reason_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('description', 'LIKE', "%{$search_filter}%");
            });
        }
        $Document = $Document->orderBy('sno', 'desc')->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'reason_name' => $item->reason_name,
                    'comments_check' => $item->comments_check,
                    'description' => $item->description,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.hrm.onduty_reason.onduty_reason', [
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List()
    {
        $Branchtype = OnDutyReasonModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'reason_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $reason_name       = $request->reason_name;
            $comments_check       = $request->comments_check ? 1 : 0;
            $description          = $request->description;
            $user_id                    = 1;
            $chk = OnDutyReasonModel::where('reason_name', $reason_name)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Onduty Reason is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = OnDutyReasonModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                $add_branchtype = new OnDutyReasonModel();
                $add_branchtype->reason_name       = $reason_name;
                $add_branchtype->comments_check    = $comments_check;
                $add_branchtype->description       = $description;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ($add_branchtype) {

                    $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
                    foreach ($entity_list as $entity_id) {
                        $this->dispatchWebhooks($add_branchtype, 1, 'ADD_ONDUTY_REASON', $entity_id);
                    }
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Onduty Reason added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Onduty Reason!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }


    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'reason_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $reason_name       = $request->reason_name;
            $comments_check    = $request->comments_check ? 1 : 0;
            $description       = $request->description;
            $document_id       = $request->edit_id;

            $upd_OnDutyReasonModel =  OnDutyReasonModel::where('sno', $document_id)->first();

            $chk = OnDutyReasonModel::where('reason_name', $reason_name)->where('sno', '!=', $document_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Onduty Reason is exist!'
                ]);
                return redirect()->back();
            }

            $upd_OnDutyReasonModel->reason_name  = $reason_name;
            $upd_OnDutyReasonModel->comments_check  = $comments_check;
            $upd_OnDutyReasonModel->description  = $description;
            $upd_OnDutyReasonModel->update();

            if ($upd_OnDutyReasonModel) {

                $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
                foreach ($entity_list as $entity_id) {
                    $this->dispatchWebhooks($upd_OnDutyReasonModel, 1, 'ADD_ONDUTY_REASON', $entity_id);
                }
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Onduty Reason Update Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Onduty Reason!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_OnDutyReasonModel = OnDutyReasonModel::where('sno', $id)->first();
        $upd_OnDutyReasonModel->status  = 2;
        $upd_OnDutyReasonModel->Update();


        if ($upd_OnDutyReasonModel) {
            $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
            foreach ($entity_list as $entity_id) {
                $this->dispatchWebhooks($upd_OnDutyReasonModel, 1, 'UPDATE_ONDUTY_REASON', $entity_id);
            }
        }

        return response([
            'status'    => 200,
            'message'   => 'Onduty Reason Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_OnDutyReasonModel =  OnDutyReasonModel::where('sno', $id)->first();
        $upd_OnDutyReasonModel->status = $request->input('status', 0);
        $upd_OnDutyReasonModel->update();

        if ($upd_OnDutyReasonModel) {
            $entity_list = ManageEntityModel::where('status', 0)->pluck('sno')->toArray();
            foreach ($entity_list as $entity_id) {
                $this->dispatchWebhooks($upd_OnDutyReasonModel, 1, 'UPDATE_ONDUTY_REASON', $entity_id);
            }
        }

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    protected function dispatchWebhooks(OnDutyReasonModel $broadcast, $userId = 1, $dispatchHook, $entity_id = null)
    {
        $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module', $dispatchHook)->where('entity_id', $entity_id)->first();
        if ($webhook) {
            $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => get_class($broadcast),
                'dispatchable_id' => $broadcast->sno,
                'message_uuid' => $broadcast->sno,
                'payload' => $broadcast->toArray(),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // broadcast creation once
            broadcast(new WebhookDispatchedEvent($dispatch));

            // enqueue the job
            try {
                $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                // if (!$result['success']) {
                //     // If fails, dispatch to queue
                //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                // }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                // SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
    }

    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }
}
