<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PayrollComponentNewModel;
use Illuminate\Support\Facades\Validator;

class PayrollComponentNew extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PayrollComponentNewModel::where('status', '!=', 2);
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('component_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('component_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('category', 'LIKE', "%{$search_filter}%")
                    ->orWhere('component_type', 'LIKE', "%{$search_filter}%");
            });
        }
        $Document = $Document->orderBy('display_order', 'asc')
            ->orderBy('id', 'desc')->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'id'                => $item->id,
                    'encrypted_id'      => $helper->encrypt_decrypt($item->id, 'encrypt'),
                    'component_name'    => $item->component_name,
                    'component_code'    => $item->component_code,
                    'category'          => $item->category,
                    'component_type'    => $item->component_type,
                    'affects_pf'        => (int) $item->affects_pf,
                    'affects_esi'       => (int) $item->affects_esi,
                    'affects_pt'        => (int) $item->affects_pt,
                    'affects_tds'       => (int) $item->affects_tds,
                    'prorate_on_lop'    => (int) $item->prorate_on_lop,
                    'taxable'           => (int) $item->taxable,
                    'display_order'     => $item->display_order,
                    'effective_from'    => $item->effective_from
                        ? date('d M Y', strtotime($item->effective_from))
                        : '-',
                    'effective_to'      => $item->effective_to
                        ? date('d M Y', strtotime($item->effective_to))
                        : '-',
                    'status'            => (int) $item->status,
                    'created_at'        => $item->created_at
                        ? $item->created_at->format('d M Y h:i A')
                        : '-',
                ];
            });



            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }


        return view('content.settings.payroll.payroll_component.payroll_component_new', [
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List()
    {
        $Branchtype = PayrollComponentNewModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200);
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'component_name' => 'required|string|max:255',
            'component_code' => 'required|string|max:100',
            'category'       => 'required|string|max:100',
            'component_type' => 'required|in:EARNING,DEDUCTION',
            'display_order'  => 'nullable|integer',
            'effective_from' => 'nullable|date',
        ]);

        if ($validator->fails()) {

            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }

        try {

            $user_id = auth()->user()->user_id ?? 1;

            $exists = PayrollComponentNewModel::where(function ($q) use ($request) {

                $q->where('component_name', $request->component_name)
                    ->orWhere('component_code', $request->component_code);
            })
                ->where('status', '!=', 2)
                ->first();

            if ($exists) {

                return response()->json([
                    'status'  => false,
                    'message' => 'Payroll Component already exists!'
                ], 409);
            }

            $component = new PayrollComponentNewModel();

            $component->component_name  = strtoupper(trim($request->component_name));
            $component->component_code  = strtoupper(trim($request->component_code));
            $component->category        = $request->category;
            $component->component_type  = $request->component_type;

            $component->affects_pf      = $request->affects_pf ? 1 : 0;
            $component->affects_esi     = $request->affects_esi ? 1 : 0;
            $component->affects_pt      = $request->affects_pt ? 1 : 0;
            $component->affects_tds     = $request->affects_tds ? 1 : 0;

            $component->prorate_on_lop  = $request->prorate_on_lop ? 1 : 0;
            $component->taxable         = $request->taxable ? 1 : 0;

            $component->display_order   = $request->display_order ?? 0;

            $component->effective_from  = $request->effective_from;
            $component->effective_to    = $request->effective_to;

            $component->created_by      = $user_id;
            $component->updated_by      = $user_id;

            $component->status          = 0;

            $component->save();

            return response()->json([
                'status'  => true,
                'message' => 'Payroll Component Created Successfully!',
                'data'    => $component
            ], 200);
        } catch (\Exception $e) {

            return response()->json([
                'status'  => false,
                'message' => 'Something went wrong!',
                'error'   => $e->getMessage()
            ], 500);
        }
    }


    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'edit_id'           => 'required|exists:egc_payroll_components,id',

            'component_name'    => 'required|string|max:100',

            'component_code'    => 'required|string|max:50',

            'category'          => 'required|in:earning,deduction,employer_contribution,reimbursement,statutory',

            'component_type'    => 'required|in:fixed,percentage,formula,dynamic',

            'display_order'     => 'nullable|integer|min:0',

            'effective_from'    => 'nullable|date',

            'effective_to'      => 'nullable|date',

        ]);

        if ($validator->fails()) {

            return response()->json([

                'status'    => false,
                'message'   => 'Validation failed',
                'errors'    => $validator->errors(),

            ], 422);
        }

        try {

            $user_id = auth()->user()->user_id ?? 1;

            $component = PayrollComponentNewModel::where('id', $request->edit_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$component) {

                return response()->json([

                    'status'  => false,
                    'message' => 'Payroll Component not found'

                ], 404);
            }

            // Duplicate check
            $duplicate = PayrollComponentNewModel::where('id', '!=', $request->edit_id)
                ->where(function ($query) use ($request) {

                    $query->where('component_name', $request->component_name)
                        ->orWhere('component_code', $request->component_code);
                })
                ->where('status', '!=', 2)
                ->first();

            if ($duplicate) {

                return response()->json([

                    'status'  => false,
                    'message' => 'Component Name or Code already exists'

                ], 409);
            }

            $component->component_name   = trim($request->component_name);

            $component->component_code   = strtoupper(trim($request->component_code));

            $component->category         = $request->category;

            $component->component_type   = $request->component_type;

            $component->affects_pf       = $request->has('affects_pf') ? 1 : 0;

            $component->affects_esi      = $request->has('affects_esi') ? 1 : 0;

            $component->affects_pt       = $request->has('affects_pt') ? 1 : 0;

            $component->affects_tds      = $request->has('affects_tds') ? 1 : 0;

            $component->prorate_on_lop  = $request->has('prorate_on_lop') ? 1 : 0;

            $component->taxable          = $request->has('taxable') ? 1 : 0;

            $component->display_order    = $request->display_order ?? 0;

            $component->effective_from   = $request->effective_from
                ? date('Y-m-d', strtotime($request->effective_from))
                : null;

            $component->effective_to     = $request->effective_to
                ? date('Y-m-d', strtotime($request->effective_to))
                : null;

            $component->updated_by       = $user_id;

            $component->save();

            return response()->json([

                'status'  => true,
                'message' => 'Payroll Component Updated Successfully'

            ], 200);
        } catch (\Exception $e) {

            return response()->json([

                'status'  => false,
                'message' => 'Something went wrong',
                'error'   => $e->getMessage()

            ], 500);
        }
    }

    public function Delete($id)
    {
        $upd_PayrollComponentNewModel = PayrollComponentNewModel::where('sno', $id)->first();
        $upd_PayrollComponentNewModel->status  = 2;
        $upd_PayrollComponentNewModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Payroll Setting Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_PayrollComponentNewModel =  PayrollComponentNewModel::where('sno', $id)->first();
        $upd_PayrollComponentNewModel->status = $request->input('status', 0);
        $upd_PayrollComponentNewModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
