<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RuleCategoryModel;
use Illuminate\Support\Facades\Validator;

class RuleCategory extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = RuleCategoryModel::where('status', '!=', 2);
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('rule_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('rule_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('rule_category', 'LIKE', "%{$search_filter}%")
                    ->orWhere('rule_expression', 'LIKE', "%{$search_filter}%");
            });
        }
        $Document = $Document->orderBy('id', 'desc')->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->id,
                    'rule_name' => $item->rule_name,
                    'rule_code' => $item->rule_code,
                    'rule_category' => strtoupper($item->rule_category),
                    'rule_expression' => $item->rule_expression,
                    'priority_order' => $item->priority_order,
                    'effective_from' => $item->effective_from ? date('d-M-Y', strtotime($item->effective_from)) : '-',
                    'effective_to' => $item->effective_to ? date('d-M-Y', strtotime($item->effective_to)) : 'No Expiry',
                    'is_active' => $item->is_active,
                    'status' => $item->status,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->id, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.payroll.rule_category.rule_category_list', [
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List()
    {
        $Branchtype = RuleCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200);
    }

    // public function Edit(Request $request)
    // {

    //     $Branchtype = RuleCategoryModel::where('status', '!=', 2)->where('sno', $request->rule_id)->first();
    //     return  response([
    //         'status'    => 200,
    //         'message'   => null,
    //         'error_msg' => null,
    //         'data'      => $Branchtype
    //     ], 200);
    // }

    public function Edit(Request $request)
    {
        $rule = RuleCategoryModel::where('status', '!=', 2)->where('id', $request->rule_id)->first();
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $rule
        ], 200);
    }
    // public function Add(Request $request)
    // {

    //     $validator = Validator::make($request->all(), [
    //         'rule_name' => 'required|max:255'
    //     ]);
    //     if ($validator->fails()) {
    //         return  response([
    //             'status'    => 401,
    //             'message'   => 'Incorrect format input feilds',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data'      => null,
    //         ], 200);
    //     } else {

    //         $rule_name       = $request->rule_name;
    //         $rule_code       = $request->rule_code;
    //         $rule_type       = $request->rule_type;
    //         $condition_json       = $request->condition_json ?? NULL;
    //         $action_json       = $request->action_json ?? NULL;
    //         $description          = $request->category_desc;
    //         $user_id                    = 1;
    //         $chk = RuleCategoryModel::where('rule_category', $rule_category)->where('status', '!=', 2)->first();

    //         if ($chk) {

    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Already  Interview Mode is exist!'
    //             ]);
    //             return redirect()->back();
    //         } else {
    //             $category_check = RuleCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();



    //             $add_branchtype = new RuleCategoryModel();
    //             $add_branchtype->rule_name       = $rule_name;
    //             $add_branchtype->rule_code       = $rule_code;
    //             $add_branchtype->rule_type       = $rule_type;
    //             $add_branchtype->condition_json       = $condition_json;
    //             $add_branchtype->action_json       = $action_json;
    //             $add_branchtype->description       = $description;
    //             $add_branchtype->created_by                 = $user_id;
    //             $add_branchtype->updated_by                 = $user_id;

    //             $add_branchtype->save();

    //             if ($add_branchtype) {
    //                 // If category added successfully, return success response and display Toastr message
    //                 session()->flash('toastr', [
    //                     'type' => 'success',
    //                     'message' => 'Interview Mode added Successfully!'
    //                 ]);
    //             } else {
    //                 session()->flash('toastr', [
    //                     'type' => 'error',
    //                     'message' => 'Could not add the Interview Mode!'
    //                 ]);
    //             }
    //         }
    //         return redirect()->back();
    //     }
    // }
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'rule_name'        => 'required|max:200',
            'rule_code'        => 'required|max:100|unique:egc_payroll_rules,rule_code',
            'rule_category'    => 'required',
            'rule_expression'  => 'required',
            'priority_order'   => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Validation Error',
                'error_msg' => $validator->messages(),
                'data'      => null,
            ], 200);
        }
        $user_id = $request->user()->user_id ?? 0;
        try {
            $rule = new RuleCategoryModel();
            $rule->rule_name       = $request->rule_name;
            $rule->rule_code       = strtoupper($request->rule_code);
            $rule->rule_category   = $request->rule_category;
            $rule->rule_expression = $request->rule_expression;
            $rule->effective_from  = $request->effective_from ? date('Y-m-d', strtotime($request->effective_from)) : null;
            $rule->effective_to    = $request->effective_to ? date('Y-m-d', strtotime($request->effective_to)) : null;
            $rule->priority_order  = $request->priority_order;
            $rule->is_active       =  1;
            $rule->status          = 0;
            $rule->created_by      = $user_id;
            $rule->updated_by      = $user_id;
            $rule->save();

            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Payroll Rule Added Successfully!'
            ]);
        } catch (\Exception $e) {

            session()->flash('toastr', [
                'type' => 'error',
                'message' => $e->getMessage()
            ]);
        }

        return redirect()->back();
    }
    // public function Update(Request $request)
    // {

    //     $validator = Validator::make($request->all(), [
    //         'rule_name' => 'required|max:255',

    //     ]);

    //     if ($validator->fails()) {
    //         return   response([
    //             'status'    => 401,
    //             'message'   => 'Incorrect format input feilds',
    //             'error_msg'     => $validator->messages()->get('*'),
    //             'data'      => null,
    //         ], 200);
    //     } else {


    //         $rule_name       = $request->rule_name;
    //         $rule_code       = $request->rule_code;
    //         $rule_type       = $request->rule_type;
    //         $condition_json       = $request->condition_json ?? NULL;
    //         $action_json       = $request->action_json ?? NULL;
    //         $description       = $request->category_desc;
    //         $document_id       = $request->edit_id;

    //         $upd_RuleCategoryModel =  RuleCategoryModel::where('sno', $document_id)->first();

    //         $chk = RuleCategoryModel::where('rule_name', $rule_name)->where('sno', '!=', $document_id)->where('status', '!=', 2)->first();

    //         if ($chk) {
    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Already  Rule is exist!'
    //             ]);
    //             return redirect()->back();
    //         }

    //         $upd_RuleCategoryModel->rule_name  = $rule_name;
    //         $upd_RuleCategoryModel->rule_code  = $rule_code;
    //         $upd_RuleCategoryModel->rule_type  = $rule_type;
    //         $upd_RuleCategoryModel->condition_json  = $condition_json;
    //         $upd_RuleCategoryModel->action_json  = $action_json;
    //         $upd_RuleCategoryModel->description  = $description;
    //         $upd_RuleCategoryModel->update();

    //         if ($upd_RuleCategoryModel) {
    //             // If category added successfully, return success response and display Toastr message
    //             session()->flash('toastr', [
    //                 'type' => 'success',
    //                 'message' => 'Rule Category Update Successfully!'
    //             ]);
    //         } else {
    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Could not Update the Rule Category!'
    //             ]);
    //         }
    //     }
    //     return redirect()->back();
    // }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'rule_name'       => 'required|max:200',
            'rule_code'       => 'required|max:100',
            'rule_category'   => 'required',
            'rule_expression' => 'required',
        ]);

        if ($validator->fails()) {

            return response([
                'status'    => 401,
                'message'   => 'Validation Error',
                'error_msg' => $validator->messages(),
                'data'      => null,
            ], 200);
        }

        try {

            $rule = RuleCategoryModel::find(
                $request->edit_id
            );

            if (!$rule) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Rule not found'

                ]);

                return redirect()->back();
            }

            // Duplicate Check
            $chk = RuleCategoryModel::where(
                'rule_code',
                $request->rule_code
            )
                ->where('id', '!=', $request->edit_id)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Rule Code already exists!'

                ]);

                return redirect()->back();
            }

            $rule->rule_name = $request->rule_name;
            $rule->rule_code = strtoupper($request->rule_code);
            $rule->rule_category = $request->rule_category;
            $rule->rule_expression = $request->rule_expression;
            $rule->priority_order = $request->priority_order;
            $rule->effective_from = $request->effective_from;
            $rule->effective_to = $request->effective_to;
            $rule->is_active = $request->is_active;
            $rule->update();

            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Payroll Rule Updated Successfully!'
            ]);
        } catch (\Exception $e) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => $e->getMessage()

            ]);
        }

        return redirect()->back();
    }

    public function Delete($id, Request $request)
    {

        $user_id = $request->user()->user_id ?? 0;

        $upd_RuleCategoryModel = RuleCategoryModel::where('sno', $id)->first();
        $upd_RuleCategoryModel->status  = 2;
        $upd_RuleCategoryModel->updated_by  = $user_id;
        $upd_RuleCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Rule Category Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $user_id = $request->user()->user_id ?? 0;

        $upd_RuleCategoryModel =  RuleCategoryModel::where('id', $id)->first();
        $upd_RuleCategoryModel->status = $request->input('status', 0);
        $upd_RuleCategoryModel->is_active  = $request->input('status', 0) == 0 ? 1 : 0;
        $upd_RuleCategoryModel->updated_by  = $user_id;
        $upd_RuleCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
