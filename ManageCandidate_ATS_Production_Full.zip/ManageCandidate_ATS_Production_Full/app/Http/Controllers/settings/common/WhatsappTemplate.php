<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use App\Models\WhatsappTemplateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use App\Models\WhatsappApiConfigureModel;

class WhatsappTemplate extends Controller
{
   
     public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        
        $whatsappTemplateList = WhatsappTemplateModel::where('status', '!=', 2);
            if ($search_filter != '') {
                $whatsappTemplateList->where(function ($subquery) use ($search_filter) {
                    $subquery->where('whatsapp_title_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('waba_template_id', 'LIKE', "%{$search_filter}%");
                });
            }

            $whatsappTemplateList=$whatsappTemplateList->orderBy('sno', 'desc')->paginate($perpage);
            $helper = new \App\Helpers\Helpers();
            
            if ($request->ajax()) {
                $data = $whatsappTemplateList->map(function ($item) use ($helper) {

                    if ($item && $item->template_content) {
                        $tpl = json_decode($item->template_content, true);

                        if (is_string($tpl)) {
                            $tpl = json_decode($tpl, true);
                        }
                    }
                    return [
                        'sno' => $item->sno,
                        'status' => $item->status,
                        'whatsapp_title_name' => $item->whatsapp_title_name,
                        'whatsapp_template_name' => $item->whatsapp_template_name,
                        'template_use_modals' => $item->template_use_modals ? json_decode($item->template_use_modals, true) : [],
                        'waba_template_id' => $item->waba_template_id,
                        'template_content' => $tpl,
                        'item' => $item,
                        'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    ];
                });

                return response()->json([
                    'data' => $data,
                    'current_page' => $whatsappTemplateList->currentPage(),
                    'last_page' => $whatsappTemplateList->lastPage(),
                    'total' => $whatsappTemplateList->total(),
                ]);
            }
            $whatsappTemplateNames = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'asc')->pluck('whatsapp_title_name');
        return view('content.settings.common.whatsapp_template.whatsapp_template_list',[
            'perpage'=>$perpage,
            'search_filter'=>$search_filter,
            'whatsappTemplateNames' => $whatsappTemplateNames,
            'whatsappTemplate' => $whatsappTemplateList,
        ]);
    }
    // public function index()
    // {
        
    //     $whatsappTemplate = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    //     $pageConfigs = ['myLayout' => 'default'];

    //     $whatsappTemplateNames = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'asc')->pluck('whatsapp_title_name');

    //     return view('content.settings.common.whatsapp_template.whatsapp_template_list', [
    //         'whatsappTemplate' => $whatsappTemplate,
    //         'pageConfigs' => $pageConfigs,
    //         'whatsappTemplateNames' => $whatsappTemplateNames,
    //     ]);
    // }


    public function list()
    {
        $whatsappTemplate = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $whatsappTemplate,
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'whatsapp_title_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $whatsapp_title_name = $request->whatsapp_title_name;
            $whatsapp_template_name = $request->whatsapp_template_name;
            $template_use_modals = json_encode($request->template_module);
            $waba_template_id = $request->waba_template_id;
            $whatsapp_content = json_encode($request->whatsapp_content);
            $user_id = $request->user()->user_id;

            $chk = WhatsappTemplateModel::where('whatsapp_template_name', $whatsapp_template_name)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Whatsapp Template is exist!',
                ]);
                return redirect('settings/whatsapp_template');
            } else {
                $category_check = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $whatsapp_template_id = 'WA-0001/' . $year;
                } else {

                    $data = $category_check->whatsapp_template_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('WA-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $whatsapp_template_id = $request . '/' . $year;
                }

                $add_wTemplate = new WhatsappTemplateModel();
                $add_wTemplate->whatsapp_template_id = $whatsapp_template_id;
                $add_wTemplate->whatsapp_template_name = $whatsapp_template_name;
                $add_wTemplate->template_use_modals = $template_use_modals;
                $add_wTemplate->whatsapp_title_name = $whatsapp_title_name;
                $add_wTemplate->waba_template_id = $waba_template_id;
                $add_wTemplate->template_content = $whatsapp_content;
                $add_wTemplate->branch_id = 0;
                $add_wTemplate->created_by = $user_id;
                $add_wTemplate->updated_by = $user_id;

                $add_wTemplate->save();

                if ($add_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Template added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Whatsapp Template!',
                    ]);
                }
            }
            return redirect('settings/whatsapp_template');
        }
    }

    public function Update(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            'whatsapp_template_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $whatsapp_template_name = $request->whatsapp_template_name;
            $template_use_modals = json_encode($request->template_module);
            $edit_id = $request->edit_id;

            $upd_wTemplate = WhatsappTemplateModel::where('sno', $edit_id)->first();

            $chk = WhatsappTemplateModel::where('whatsapp_template_name', $whatsapp_template_name)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already whatsapp Template is exist!',
                ]);
                return redirect()->back();
            } else {

                $upd_wTemplate->whatsapp_template_name = $whatsapp_template_name;
                $upd_wTemplate->template_use_modals = $template_use_modals;
                $upd_wTemplate->update();

                if ($upd_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Template Update Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the Whatsapp Template!',
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_wTemplate = WhatsappTemplateModel::where('sno', $id)->first();
        $upd_wTemplate->status = 2;
        $upd_wTemplate->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_wTemplate = WhatsappTemplateModel::where('sno', $id)->first();
        $upd_wTemplate->status = $request->input('status', 0);
        $upd_wTemplate->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
 public function handleWebhook(Request $request)
{
    // Handle verification (GET request)
    if ($request->isMethod('get')) {
        if (
            $request->query('hub_mode') === 'subscribe' &&
            $request->query('hub_verify_token') === '2026d0dfea8175ec07b42b2245da10f7'
        ) {
            // Send challenge back as plain text, not as a JSON response
            return response($request->query('hub_challenge'), 200)->header('Content-Type', 'text/plain');
        }
        return response()->json(['error' => 'Invalid token'], 403);
    }

    // Handle incoming message (POST request)
    return response()->json(['success' => true]);
}


public function showTemplates()
  {
    $businessId = $this->whatsappAccess()['waba_id'];
    $accessToken = $this->whatsappAccess()['accessToken'];
    $templates = $this->getWhatsAppTemplates($businessId, $accessToken);

    $formattedData = isset($templates['data']) ? $templates['data'] : [];

    // Filter only the templates with "status": "APPROVED"
    $approvedTemplates = array_filter($formattedData, function ($template) {
      return isset($template['status']) && $template['status'] === 'APPROVED';
    });

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => array_values($approvedTemplates),
    ], 200);
  }

  public function getWhatsAppTemplates($business_id,$access_token)
    {
        $baseUrl = 'https://graph.facebook.com/v17.0';
        $client =new Client();
        try {
            $response = $client->request('GET', "{$baseUrl}/{$business_id}/message_templates", [
                'headers' => [
                    'Authorization' => "Bearer {$access_token}",
                    'Accept' => 'application/json',
                ],
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            // Log the error or handle it as needed
            return ['error' => $e->getMessage()];
        }
    }

    public function getWhatsAppTemplateById($businessId, $templateId)
    {
        $templates = $this->getWhatsAppTemplates($businessId);

        if (isset($templates['data']) && is_array($templates['data'])) {
            $filteredTemplate = array_filter($templates['data'], function ($template) use ($templateId) {
                return $template['id'] == $templateId;
            });

            return !empty($filteredTemplate) ? reset($filteredTemplate) : null;
        }

        return null;
    }

    public function getMessageStatusFromAPI($messageId,$access_token)
    {
         $baseUrl = 'https://graph.facebook.com/v17.0';
        $url = "{$baseUrl}/{$messageId}?fields=status&access_token={$access_token}";
        $client =new Client();

        try {
            $response = $client->get($url);

            return $url;

            if ($response->getStatusCode() === 200) {
                return json_decode($response->getBody(), true);
            }
        } catch (\GuzzleHttp\Exception\ClientException $e) {
        // return $e;
            // Log::warning("Client error for message ID $messageId: " . $e->getMessage());
        } catch (\Exception $e) {
            // Log::error("Error fetching status for message ID $messageId: " . $e->getMessage());
        }

        return null;
    }

    private function whatsappAccess(){
        $whatsappApi = DB::table('egc_api_integration')->where('api_key','egc_whatsapp_meta_api_1')->where('status',0)->orderBy('sno', 'desc')->first();
          if($whatsappApi){
            $apiFields = json_decode($whatsappApi->api_fields, true);
            $WhatsAppBusinessAccountId = '';
            $accessToken = '';
            $fromPhoneNumberId = '';
            foreach ($apiFields as $field) {
                if ($field['key'] === 'waba_id') {
                    $WhatsAppBusinessAccountId = $field['value'];
                } elseif ($field['key'] === 'access_token') {
                    $accessToken = $field['value'];
                } elseif ($field['key'] === 'phone_number_id') {
                    $fromPhoneNumberId = $field['value'];
                }
            }
             
          }else{
            $WhatsAppBusinessAccountId = '';
            $accessToken = '';
            $fromPhoneNumberId = '';
          }

          $whastapp = [
            "waba_id"=>$WhatsAppBusinessAccountId,
            "accessToken"=>$accessToken,
            "fromPhoneNumberId"=>$fromPhoneNumberId,
          ];

          return $whastapp;
    }


}
