<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\exam_management\ManageAssessment;
use App\Mail\EAPLMail;
use App\Mail\ETPLMail;
use Illuminate\Support\Facades\File;
use App\Models\BranchModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use App\Models\CallTrackerModel;
use App\Models\CugManagementModel;
use App\Models\DepartmentModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\GeneralSettingsModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use App\Models\ExamProcessModel;
use App\Services\DoubletickService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\AIQuestionModel;



class Cronjobs extends Controller
{

  protected $doubletickService;

  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;

  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }


  public function Cronjob_staff_lead_bank_update(Request $request)
  {
    $monitor = CronjobMonitorModel::where('sno', 3)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor && $monitor->status != 0) {
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $today = now('Asia/Kolkata');
    $lastDayOfMonth = now('Asia/Kolkata')->endOfMonth();

    $helper = new \App\Helpers\Helpers();
    $increase_count = $helper->general_setting_data()->lead_bank_count ?? 50;
    $inserted_records = 0;
    $message = '';

    if ($today->isSameDay($lastDayOfMonth)) {
      StaffModel::where('status', 0)->update([
        'lead_bank_count' => $increase_count,
        'month_lead_count' => 0
      ]);
      $message = "Updated successfully";
      $success = true;
    } else {
      $message = "Today is not the last day of the month.";
      $success = false;
    }

    // Step 1: Get the matching staff IDs
    $getaNoticePeriodInStaff = DB::table('egc_staff')
      ->whereIn('status', [0, 1])
      ->where('notice_check', 1)
      ->whereDate('notice_end_date', '<=', $today)
      ->pluck('sno');

    // Step 2: Update the status to 2
    DB::table('egc_staff')
      ->whereIn('sno', $getaNoticePeriodInStaff)
      ->update(['status' => 4]);

    // End time & duration
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update monitor and create log
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
        'message'           => $message
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    return response()->json([
      "success" => $success,
      "message" => $message,
      "processed_records" => $inserted_records,
      "execution_time" => $duration
    ]);
  }

  public function Cronjob_otherdb()
  {
    return 'return';
    // Connect to the secondary database
    $other_db = DB::connection('mysql_secondary');

    //   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('user as u')
      ->select(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id',
        $other_db->raw('SUM(CASE WHEN cl.call_log_id IS NOT NULL THEN 1 ELSE 0 END) as call_log_count') // Sum the call logs
      )
      ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')  // Join company table
      ->leftJoin('call_log as cl', 'u.user_id', '=', 'cl.user_id')      // Join call_log table
      ->where('u.company_id', 1)  // Filter by company_id
      ->where('cl.count_status', 0)  // Filter by company_id
      ->groupBy(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id'  // Group by user attributes and company details
      )
      ->get();
    $total = 0;
    foreach ($users_with_call_log_count as $list) {
      $total += $list->call_log_count;
    }


    return $total;
  }

  public function Cronjob_call_log()
  {
    $monitor = CronjobMonitorModel::where('sno', 1)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    //   return 'stop';
    $other_db = DB::connection('mysql_secondary');
    $branches = BranchModel::select('sno AS branch_id', 'call_tracker_branch_id')
      ->where('status', 0)
      ->where('call_tracker_branch_id', '>', 0)
      ->get();

    $all_users = []; // Array to store all users with branch_id
    $inserted_records = []; // Array to store inserted records

    foreach ($branches as $branch) {
      $getmobiles = CugManagementModel::select('staff_mobile', 'staff_id')
        ->where('branch_id', $branch->branch_id)
        ->where('status', 0)
        ->get();

      foreach ($getmobiles as $mobile) {
        $select_users = $other_db
          ->table('user as u')
          ->select('u.user_id', 'u.name', 'u.nick_name', 'u.phone_no', 'u.user_code', 'u.status', 'u.company_id', 'c.company_name', 'u.department_id')
          ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')
          ->where('u.phone_no', $mobile->staff_mobile)
          ->where('u.status', 0)
          ->where('u.company_id', $branch->call_tracker_branch_id)
          ->get();

        if (!$select_users->isEmpty()) {
          foreach ($select_users as $user) {
            $user->branch_id = $branch->branch_id; // Add branch_id to user data
            $user_logs = $other_db
              ->table('call_log as cl')
              ->select('cl.call_log_id', 'cl.count_status', 'cl.contact_book_id', 'cl.call_date', 'cl.call_end_date', 'cl.call_time', 'cl.call_end_time', 'cl.duration', 'cl.latitude', 'cl.longitude', 'cl.status AS log_status', 'cb.phone_no as customer_phone_no', 'cb.contact_name as customer_name', 'cb.reason as customer_reason', 'cb.status as customer_status')
              ->leftJoin('contact_book as cb', 'cl.contact_book_id', '=', 'cb.contact_book_id')
              ->where('cl.user_id', $user->user_id) // Assuming you have user_id in call_log
              ->whereYear('cl.call_date', '>', '2021')
              ->where('cl.count_status', 0)
              ->orderBy('cl.call_date', 'ASC')
              ->limit(10)
              ->get();

            // Add logs to user data
            $user->logs = $user_logs; // Add logs to user data
            // $all_users[] = (array) $user; // Convert object to array and store

            //   return $user_logs;

            // Check if there are logs to insert
            if (!$user_logs->isEmpty()) {
              foreach ($user_logs as $log) {
                $status = $log->log_status;
                $call_duration = $log->duration;

                if ($status === 0 && $call_duration != '00:00:00') {
                  $staus_up = $log->log_status;
                } elseif ($status === 0 && $call_duration == '00:00:00') {
                  $staus_up = 4;
                } else {
                  $staus_up = $log->log_status;
                }
                $record = CallTrackerModel::create([
                  'branch_id' => $branch->branch_id,
                  'branch_staff_id' => $mobile->staff_id ?? 51,
                  'call_tracker_staff_id' => $user->user_id,
                  'staff_phone_no' => $user->phone_no,
                  'customer_phone_no' => $log->customer_phone_no,
                  'customer_name' => $log->customer_name ?: 'Unknown',
                  'customer_status' => $log->customer_status,
                  'customer_reason' => $log->customer_reason,
                  'call_start_date' => $log->call_date,
                  'call_end_date' => $log->call_end_date ?: null,
                  'call_start_time' => $log->call_time,
                  'call_end_time' => $log->call_end_time,
                  'call_duration' => $log->duration,
                  'latitude' => $log->latitude,
                  'longitude' => $log->longitude,
                  'call_status' => $staus_up
                ]);
                $user_logs_upadte = $other_db
                  ->table('call_log')
                  ->where('call_log_id', $log->call_log_id)
                  ->update(['count_status' => 1]);
                // Store inserted record for return
                $inserted_records[] = 1; // Add a count for each inserted record
              }
            }
          }
        }
      }
    }
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }
  public function Cronjob_lead_calls_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 2)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $call_last_fetch_id = $genset ? $genset->call_last_fetch_id : 0;
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records
    $getmobiles = DB::table('egc_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->where('ct.sno', '>=', $call_last_fetch_id)
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();
    //   return $getmobiles;
    $last_fetch_id = $call_last_fetch_id;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
      $last_fetch_id = $ct->sno;
      GeneralSettingsModel::where('sno', 1)->update(['call_last_fetch_id' => $ct->sno]);
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_lead_calls_update_before_days()
  {
    return 'Waiting for Lead enrty';
    $start_time = microtime(true);
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records

    $getmobiles = DB::table('egc_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->whereBetween('ct.call_start_date', [Carbon::now()->subDays(500)->toDateString(), Carbon::now()->toDateString()])
      ->limit(500)
      ->orderBy('ct.sno', 'ASC')
      ->get();

    //   return count($getmobiles);

    // return $getmobiles;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      // 

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds',
    ];
  }

  public function Cronjob_lead_phone_verify()
  {
    $monitor = CronjobMonitorModel::where('sno', 6)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $Leads = DB::table('egc_lead')
      ->select('sno', 'lead_name', 'lead_mobile', 'phone_verify_status', 'inter_calls')
      ->where('phone_verify_status', 0)
      ->limit(1000)
      ->get();

    // Check if leads exist
    if ($Leads->isEmpty()) {
      return response()->json(['message' => 'Lead not found'], 404);
    }
    $inserted_records = 0;

    foreach ($Leads as $lead) {
      $lead_id = $lead->sno;
      $lead_mobile = $lead->lead_mobile;
      if ($lead->inter_calls == 0 || $lead->inter_calls == null || $lead->inter_calls == 91) {
        $countryCode = 'IN';
      } else {
        $countries = DB::table('egc_countries')->where('phonecode', $lead->inter_calls)->first();
        if ($countries) {
          $countryCode = $countries->sortname;
        } else {
          $countryCode = 'IN';
        }
      }

      // Fetch lead details
      $lead_update = LeadModel::where('sno', $lead_id)->first();
      if (!$lead_update) {
        continue; // Skip if lead not found
      }

      // API URL
      $url = 'http://apilayer.net/api/validate';
      $accessKey = '60af509a52f854bf5efbf11595874b5c';
      // Determine country code
      // $countryCode = ($lead->inter_calls == 0 || $lead->inter_calls == null) ? '+ 91' : $lead->inter_calls;


      // Set up cURL
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "{$url}?access_key={$accessKey}&number={$lead_mobile}&country_code={$countryCode}&format=1");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_TIMEOUT, 30);

      $response = curl_exec($ch);

      // Check for cURL errors
      if (curl_errno($ch)) {
        curl_close($ch);
        return response()->json(['error' => 'cURL error: ' . curl_error($ch)], 500);
      }

      curl_close($ch);
      $data = json_decode($response, true);
      // return $data;
      // Handle API response errors
      if (!$data || !isset($data['valid'])) {
        continue;
      }
      // Update phone verification status
      $lead_update->phone_verify_status  = $data['valid'] ? 1 : 2;
      $lead_update->phone_verify_content = json_encode($data); // Store JSON properly
      $lead_update->save();
      $inserted_records++;
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds ¢ª H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

 

  public function Cronjob_CloseInCompleteExam()
  {
    $monitor = CronjobMonitorModel::where('sno', 16)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $processlist = DB::table('egc_exam_process')->where('status', '!=', 2)->get();
    $inserted_records = 0;

    foreach ($processlist as $list) {
      $exam_data = DB::table('egc_manage_exam')->where('sno', $list->exam_id)->first();
      $exam_duration_in_min = (int)($exam_data->duration ?? 0);

      if ($exam_duration_in_min > 0) {
        // ✅ DB stores IST timestamps → parse as Asia/Kolkata
        $created_time = Carbon::parse($list->created_at, 'Asia/Kolkata');
        $exam_end_time = $created_time->copy()->addMinutes($exam_duration_in_min);
        $current_time = now('Asia/Kolkata');

        // 🪵 Debug log
        // \Log::info('Exam Time Check', [
        //     'exam_id'       => $list->exam_id,
        //     'created_time'  => $created_time->toDateTimeString(),
        //     'exam_end_time' => $exam_end_time->toDateTimeString(),
        //     'current_time'  => $current_time->toDateTimeString(),
        //     'is_expired'    => $current_time->greaterThan($exam_end_time) ? 'YES' : 'NO'
        // ]);

        // ✅ Close expired exams
        if ($current_time->greaterThan($exam_end_time)) {
          $update = ExamProcessModel::find($list->sno);
          if ($update && $update->status != 2) {

            // ⏱ Calculate total attended duration
            $diffInSeconds = $created_time->diffInSeconds($current_time);
            $hours = floor($diffInSeconds / 3600);
            $minutes = floor(($diffInSeconds % 3600) / 60);
            $seconds = $diffInSeconds % 60;
            $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

            $update->completed_date = $current_time;
            $update->status = 2;
            $update->total_attended_duration = $duration;
            $update->save();

            $inserted_records++;
          }
        }
      }
    }

    // 🕒 Calculate total cron execution time
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds → H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // 🪵 Update monitor and create log
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }


  private function updateCronMonitor($monitor, $startDateTime, $start_time, $return)
  {
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update the monitor if it exists
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response = json_encode($return);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    // Return the response
    return response()->json($return);
  }
  
     // Document Un upload files Remove
    public function Cronjob_Documents_unupload_files()
    {
        $monitor = CronjobMonitorModel::where('sno', 22)->first();
        $start_time = microtime(true);

        $startDateTime = Carbon::createFromTimestamp((int) $start_time, 'Asia/Kolkata');

        if ($monitor) {
            if ($monitor->status != 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cronjob status Off',
                ]);
            }
            $monitor->running_status = 1;
            $monitor->save();
        }

        $inserted_records = 0;

        // ✅ DELETE storage/app/temp folder
        $folderPath = storage_path('app/temp');

        if (File::exists($folderPath)) {
            File::deleteDirectory($folderPath);
        }

        // (Optional) recreate empty folder
        File::makeDirectory($folderPath, 0755, true, true);

        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);

        $endDateTime = Carbon::createFromTimestamp((int) $end_time, 'Asia/Kolkata');

        $hours = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

        if ($monitor) {
            $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor->sync_duration = $duration;
            $monitor->running_status = 0;
            $monitor->save();

            $monitor_log = new CronjobLogModel();
            $monitor_log->cronjob_id = $monitor->sno;
            $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
            $monitor_log->sync_duration = $duration;
            $monitor_log->response = json_encode([
                'execution_time' => $duration,
                'message' => 'Cron job completed successfully'
            ]);
            $monitor_log->created_by = 0;
            $monitor_log->updated_by = 0;
            $monitor_log->save();
        }

        return [
            'execution_time' => "{$execution_time} seconds",
            'message' => 'Cron job completed successfully'
        ];
    }

  
}
