<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Events\WebhookDispatchedEvent;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WebhookAdminController extends Controller
{
    public function index(Request $request)
    {
         $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = trim($request->search_filter ?? '');

        $webhook_name = $request->webhook_name;
        $entity_fill = $request->entity_fill;
        $date_filter = $request->dt_fill_issue_rpt;

        $from_date = $request->from_dt_iss_rpt;
        $to_date = $request->to_dt_iss_rpt;

        $query = WebhookDispatchModel::with([
            'attemptLogs',
            'webhook'
        ]);
        if (!empty($search_filter)) {
            $query->where(function ($q) use ($search_filter) {
                $q->where('last_response', 'LIKE', "%{$search_filter}%")
                    ->orWhere('message_uuid', 'LIKE', "%{$search_filter}%")
                    ->orWhereHas('attemptLogs', function ($attempt) use ($search_filter) {
                        $attempt->where('request_body', 'LIKE', "%{$search_filter}%")
                            ->orWhere('response_body', 'LIKE', "%{$search_filter}%");
                    });
            });
        }

        if (!empty($webhook_name)) {
            $query->where('sub_erp_webhook_sno', $webhook_name);
        }

        if (!empty($entity_fill)) {
            $query->whereHas('webhook', function ($q) use ($entity_fill) {
                $q->where('entity_id', $entity_fill);
            });
        }

        switch ($date_filter) {

            case 'today':
                $query->whereDate('created_at', today());
                break;
            case 'week':
                $query->whereBetween('created_at', [
                    now()->startOfWeek(),
                    now()->endOfWeek()
                ]);
                break;
            case 'monthly':
                $query->whereMonth('created_at', now()->month)
                    ->whereYear('created_at', now()->year);
                break;
            case 'custom_date':
                if (!empty($from_date) && !empty($to_date)) {
                    $query->whereBetween('created_at', [
                        date('Y-m-d 00:00:00', strtotime($from_date)),
                        date('Y-m-d 23:59:59', strtotime($to_date))
                    ]);
                }
                break;
        }

        $webhooks = $query
            ->orderByDesc('created_at')
            ->paginate($perpage);


        // $webhooks = WebhookDispatchModel::with('attemptLogs')
        //     ->orderBy('created_at', 'desc')
        //     ->paginate($perpage);
       
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $webhooks->map(function ($item) use ($helper) {
                
                if($item->webhook->entity_id){
                    $entity_data = DB::table('egc_entity')->where('sno',$item->webhook->entity_id)->first();
                }else{
                    $entity_data = NULL;
                }
                
               
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'url' => $item->webhook->url ?? 'N/A',
                    'attempts' => $item->attempts,
                    'entity_name' => $entity_data ? $entity_data->entity_name : '' ,
                    'entity_base_color' => $entity_data ? $entity_data->entity_base_color : '' ,
                    'last_response' => $item->last_response,
                    'attempt_logs' => $item->attempt_logs,
                    'last_attempt_at' => $item->last_attempt_at,
                    'next_attempt_at' => $item->next_attempt_at,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $webhooks->currentPage(),
                'last_page' => $webhooks->lastPage(),
                'total' => $webhooks->total(),
            ]);
        }

        $webhook_list = DB::table('egc_sub_erp_webhooks')
                        ->join('egc_entity','egc_entity.sno','=','egc_sub_erp_webhooks.entity_id')
                        ->where('egc_sub_erp_webhooks.status', 0)
                        ->select('egc_sub_erp_webhooks.*','egc_entity.entity_name')
                        ->get();
        $entity_list = DB::table('egc_entity')->where('status', 0)->get();

        return view('content.admin.webhooks.webhooks_list', [
            'webhooks' => $webhooks,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'webhook_list' => $webhook_list,
            'entity_list' => $entity_list,
        ]);
    }

    public function retry($id)
    {
        $dispatch = WebhookDispatchModel::findOrFail($id);

        if ($dispatch->status !== 2) {
            SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            $dispatch->update(['status' => 1]); 
            broadcast(new WebhookDispatchedEvent($dispatch));
        }

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->with('success', 'Webhook retried successfully.');
    }

    function webhooksLog(Request $request){

        $id =$request->dispatch_sno;
        // $id =2;
        $dispatch =WebhookDispatchModel::where('egc_webhook_dispatches.sno',$id)
        ->select(
            'egc_webhook_dispatches.http_status',
            'egc_webhook_dispatches.status',
            'egc_sub_erp_webhooks.webhook_module',
            'egc_sub_erp_webhooks.url',
            'egc_sub_erp_webhooks.url',
            'egc_entity.entity_name',
            'egc_entity.entity_base_color',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            )
        ->join('egc_sub_erp_webhooks', 'egc_webhook_dispatches.sub_erp_webhook_sno', 'egc_sub_erp_webhooks.sno')
        ->join('egc_company', 'egc_sub_erp_webhooks.company_id', 'egc_company.sno')
        ->join('egc_entity', 'egc_sub_erp_webhooks.entity_id', 'egc_entity.sno')
        ->first();

        $attempts = WebhookDispatchAttemptModel::where('webhook_dispatch_sno',$id)->get();
        $dispatch->attempt_logs=$attempts;

         return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $dispatch
        ], 200);
        

    }
}
