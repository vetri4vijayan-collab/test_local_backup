<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FinanaceController extends Controller
{
  public function index(Request $request)
  {
    return view('content.accounts_finance.finance_target.finance_target');
  }
  
}
