<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\ShiftTimeModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use Carbon\Carbon;
use App\Models\WhatsappTemplateLogModel;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\StaffBankDetailsModel;
use App\Models\StaffPayrollProfileModel;
use App\Models\StaffStatutoryDetailsModel;
use App\Models\StaffSalaryComponentModel;
use App\Models\StaffExistReasonModel;
use App\Models\StaffTransferLogModel;
use App\Models\StaffSalaryAccountModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Client\Response;

use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollStaffStructureDetailModel;
use App\Models\StaffSalaryAppraisalHistoryModel;

class Expenditure extends Controller
{
  public function index(Request $request)
  {
    

    return view('content.accounts_finance.expenditure.expense_log', [
      
    ]);
  }
  
}
