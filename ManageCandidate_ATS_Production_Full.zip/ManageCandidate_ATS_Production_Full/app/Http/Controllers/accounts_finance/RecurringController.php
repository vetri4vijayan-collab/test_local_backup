<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Validation\Rule;

use App\Exports\ExpenseExport;

class RecurringController extends Controller
{
    

    public function index()
    {
        
        $expenseCategories = DB::table('egc_acc_expense_categories')
        ->where('status', 0)
        ->get();

        return view('content.accounts_finance.expenditure.recurring_log',
            [
                'expenseCategories' => $expenseCategories
            ]
        );
    }

    public function recurringList(Request $request)
    {
        $today = Carbon::today('Asia/Kolkata');

        $tab = $request->input('tab', '7_days');

        $categoryId = $request->input('category');
        $statusFilter = $request->input('status');
        $search = trim((string) $request->input('search', ''));

        /* Date range */

        $fromDate = null;
        $toDate = null;

        switch ($tab) {

            case 'current_month':
                $fromDate = $today->copy()->startOfMonth();
                $toDate   = $today->copy()->endOfMonth();
                break;
            case 'next_month':
                $fromDate = $today->copy()
                    ->addMonthNoOverflow()
                    ->startOfMonth();
                $toDate = $fromDate->copy()->endOfMonth();
                break;
            case '6_months':
                $fromDate = $today->copy();
                $toDate = $today->copy()
                    ->addMonthsNoOverflow(6)
                    ->endOfDay();
                break;
            case 'next_year':
                $fromDate = $today->copy()
                    ->addYearNoOverflow()
                    ->startOfYear();
                $toDate = $fromDate->copy()
                    ->endOfYear();
                break;
            case '7_days':
            default:
                $fromDate = null;
                $toDate = $today->copy()
                    ->addDays(7);
                break;
        }

        /*Latest paid log */

        $latestPaidLog = DB::table('egc_acc_recurring_log as l')
            ->select([
                'l.recurring_id',
                'l.sno',
                'l.date',
                'l.paid_date',
                'l.amount',
                'l.currency_type',
                'l.currency_amount',
            ])
            ->where('l.status', 1)
            ->whereRaw(
                'l.sno = (
                    SELECT MAX(l2.sno)
                    FROM egc_acc_recurring_log l2
                    WHERE l2.recurring_id = l.recurring_id
                    AND l2.status = 1)'
            );

        /* Current / next occurrence  */

        $currentLog = DB::table('egc_acc_recurring_log as l')
            ->select([
                'l.recurring_id',
                'l.sno',
                'l.date',
                'l.paid_date',
                'l.status',
                'l.amount',
                'l.currency_type',
                'l.currency_amount',
                'l.is_gst',
                'l.gst_amount',
                'l.total_amount',
            ])
            ->whereRaw(
                'l.sno = (
                    SELECT MAX(l2.sno)
                    FROM egc_acc_recurring_log l2
                    WHERE l2.recurring_id = l.recurring_id
                    AND l2.status IN (0, 1, 3)
                )'
            );

        /* Master query  */

        $query = DB::table('egc_acc_recurring as r')

            ->join('egc_acc_expense_products as p','p.sno','=','r.product_id' )
            ->leftJoin('egc_acc_expense_categories as c','c.sno','=','r.category_id' )
            ->leftJoinSub(
                $latestPaidLog,
                'lp',
                function ($join) {
                    $join->on('lp.recurring_id', '=','r.sno');
                } )
            ->leftJoinSub(
                $currentLog,
                'cl',
                function ($join) {
                    $join->on(
                        'cl.recurring_id',
                        '=',
                        'r.sno'
                    );
                }
            )

            ->select([
                'r.sno',
                'r.product_id',
                'r.category_id',
                'r.frequency_type',
                'r.date',
                'r.next_pay_date',
                'r.last_paid_date',
                'r.amount',
                'r.currency_type',
                'r.currency_amount',
                'r.is_gst',
                'r.gst_amount',
                'r.total_amount',
                'r.status as recurring_status',

                'p.product_name',
                'p.product_code',
                'p.is_recurring',
                'p.billing_date',
                'p.email_id',
                'p.mobile_no',
                'p.website',
                'p.remarks',

                'c.category_name',
                'c.icon',

                'lp.sno as last_paid_log_id',
                'lp.date as last_paid_due_date',
                'lp.paid_date as latest_paid_date',

                'cl.sno as current_log_id',
                'cl.status as current_log_status',
                'cl.date as current_log_date',
                'cl.paid_date as current_log_paid_date',
                'cl.is_gst as current_log_is_gst',
                'cl.gst_amount as current_log_gst_amount',
                'cl.total_amount as current_log_total_amount',
            ]);

        /* Category */

        if ($categoryId !== null && $categoryId !== '') {
            $query->where('r.category_id', (int) $categoryId );
        }

        /* Search */

        if ($search !== '') {

            $query->where(function ($q) use ($search) {
                $q->where('p.product_name', 'like',"%{$search}%")
                ->orWhere('p.product_code','like', "%{$search}%" )
                ->orWhere('c.category_name','like',"%{$search}%");
            });
        }

        /*Tab date filtering */
        if ($fromDate) {
            $query->whereDate('r.next_pay_date','>=', $fromDate->toDateString());
        }

        /* For 7-days we intentionally include overdue. */
        if ($toDate) {
            $query->whereDate( 'r.next_pay_date', '<=',  $toDate->toDateString() );
        }

        /* Status filtering  */

        if ($statusFilter === 'dropped') {
            $query->where('r.status', 2);
        } elseif ($statusFilter === 'active') {
            $query->where('r.status', 0);
        } elseif ($statusFilter === 'overdue') {
            $query->where('r.status', 0)
                ->whereDate('r.next_pay_date', '<', $today->toDateString() );
        } elseif ($statusFilter === 'today') {
            $query->where('r.status', 0)
                ->whereDate('r.next_pay_date',$today->toDateString());
        } elseif ($statusFilter === 'tomorrow') {
            $query
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    $today->copy()->addDay()->toDateString()
                );
        } elseif ($statusFilter === 'paid') {
            $query->whereNotNull('r.last_paid_date');
        } elseif ($statusFilter === 'upcoming') {
            $query
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    '>',
                    $today->copy()->addDay()->toDateString()
                );
        }

        /* Ordering */

        $rows = $query
            ->orderByRaw(
                "CASE
                    WHEN r.status = 2 THEN 5
                    WHEN r.next_pay_date < ? THEN 1
                    WHEN r.next_pay_date = ? THEN 2
                    WHEN r.next_pay_date = ? THEN 3
                    ELSE 4
                END",
                [
                    $today->toDateString(),
                    $today->toDateString(),
                    $today->copy()->addDay()->toDateString(),
                ]
            )
            ->orderBy('r.next_pay_date')
            ->orderBy('p.product_name')
            ->get();

        /* Transform  */

        $data = $rows->map(function ($row) use ($today) {

            $nextDate = $row->next_pay_date
                ? Carbon::parse($row->next_pay_date)
                : null;

            /* Master status */

            if ((int) $row->recurring_status === 2) {

                $displayStatus = 'dropped';
                $statusLabel = 'Stopped';
                $statusIcon = 'mdi-stop-circle-outline';

            } elseif (!$nextDate) {

                $displayStatus = 'dropped';
                $statusLabel = 'No Schedule';
                $statusIcon = 'mdi-calendar-remove-outline';

            } elseif ($nextDate->lt($today)) {

                $displayStatus = 'overdue';
                $statusLabel = 'Overdue';
                $statusIcon = 'mdi-alert-circle-outline';

            } elseif ($nextDate->isSameDay($today)) {

                $displayStatus = 'today';
                $statusLabel = 'Due Today';
                $statusIcon = 'mdi-alarm-alert';

            } elseif (
                $nextDate->isSameDay(
                    $today->copy()->addDay()
                )
            ) {

                $displayStatus = 'tomorrow';
                $statusLabel = 'Due Tomorrow';
                $statusIcon = 'mdi-clock-alert-outline';

            } else {

                $displayStatus = 'upcoming';
                $statusLabel = 'Upcoming';
                $statusIcon = 'mdi-calendar-clock-outline';
            }

            /* Last payment  */

            $lastPaymentStatus =
                $row->last_paid_date
                    ? 'paid'
                    : 'not_paid';

            /* Days */

            $daysDifference = $nextDate
                ? $today->diffInDays($nextDate, false)
                : null;

            if ($daysDifference === null) {

                $reminderText = 'No payment schedule';

            } elseif ($daysDifference < 0) {

                $daysOverdue = abs($daysDifference);

                $reminderText =
                    $daysOverdue === 1
                        ? '1 day overdue'
                        : $daysOverdue . ' days overdue';

            } elseif ($daysDifference === 0) {

                $reminderText = 'Due today';

            } elseif ($daysDifference === 1) {

                $reminderText = 'Due tomorrow';

            } else {

                $reminderText =
                    'Due in ' . $daysDifference . ' days';
            }

            return [

                'id' => (int) $row->sno,
                'product_id' => (int) $row->product_id,
                'product_name' => $row->product_name,
                'product_code' => $row->product_code,
                'category_id' => (int) $row->category_id,
                'category_name' => $row->category_name,
                'category_icon' => $row->icon,
                'frequency_type' => $this->formatExpenseFrequency($row->frequency_type),
                'frequency_key' => $row->frequency_type,
                'next_pay_date' => $row->next_pay_date,
                'last_paid_date' => $row->last_paid_date,
                'amount' => (float) ($row->amount ?? 0),
                'currency_type' => $row->currency_type,
                'currency_amount' => (float) ($row->currency_amount ?? 0),
                'gst_amount' => (float) ($row->gst_amount ?? 0),
                'total_amount' =>  (float) ($row->total_amount ?? 0),
                'is_gst' =>  (int) $row->is_gst,
                'recurring_status' => (int) $row->recurring_status,
                'display_status' => $displayStatus,
                'status_label' => $statusLabel,
                'status_icon' => $statusIcon,
                'last_payment_status' => $lastPaymentStatus,
                'latest_paid_date' => $row->latest_paid_date,
                'last_paid_due_date' => $row->last_paid_due_date,
                'current_log_id' =>
                    $row->current_log_id
                        ? (int) $row->current_log_id
                        : null,
                'current_log_status' =>
                    $row->current_log_status !== null
                        ? (int) $row->current_log_status
                        : null,
                'reminder_text' =>$reminderText,
                'days_difference' => $daysDifference,
                'email_id' => $row->email_id,
                'mobile_no' => $row->mobile_no,
                'website' => $row->website,
                'remarks' =>  $row->remarks,
            ];
        })->values();

        /* Summary  */

        $summary = [
            'total' =>$data->count(),
            'active' => $data->where('recurring_status', 0 )->count(),
            'paid' =>$data->where('last_payment_status','paid')->count(),
            'today' => $data->where( 'display_status', 'today' )->count(),
            'tomorrow' =>$data->where('display_status','tomorrow')->count(),
            'overdue' => $data->where('display_status','overdue')->count(),
            'dropped' => $data->where( 'recurring_status',2 )->count(),
        ];

        return response()->json([
            'success' => true,
            'data' => $data,
            'summary' => $summary,
            'tab' => $tab,
            'today' => $today->toDateString(),
        ]);
    }

    public function recurringShow(
        Request $request,
        int $id
    ){

        $master = DB::table('egc_acc_recurring as r')

            ->join(
                'egc_acc_expense_products as p',
                'p.sno',
                '=',
                'r.product_id'
            )

            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'r.category_id'
            )

            ->where('r.sno', $id)

            ->select([
                'r.sno',
                'r.product_id',
                'r.category_id',
                'r.frequency_type',
                'r.date',
                'r.next_pay_date',
                'r.last_paid_date',
                'r.amount',
                'r.currency_type',
                'r.currency_amount',
                'r.is_gst',
                'r.gst_amount',
                'r.total_amount',
                'r.status as recurring_status',

                'p.product_name',
                'p.product_code',
                'p.email_id',
                'p.mobile_no',
                'p.website',
                'p.remarks',
                'p.billing_date',
                'p.is_recurring',

                'c.category_name',
                'c.icon',
            ])
            ->first();

        if (!$master) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring master not found.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Complete payment history
        |--------------------------------------------------------------------------
        */

        $logs = DB::table('egc_acc_recurring_log as rl')

            ->leftJoin(
                'egc_acc_expense_logs as el',
                'el.sno',
                '=',
                'rl.expense_log_id'
            )

            ->leftJoin(
                'egc_staff as st',
                'st.user_id',
                '=',
                'rl.updated_by'
            )

            ->where(
                'rl.recurring_id',
                $id
            )

            ->select([
                'rl.sno',
                'rl.date',
                'rl.paid_date',
                'rl.amount',
                'rl.currency_type',
                'rl.currency_amount',
                'rl.is_gst',
                'rl.gst_amount',
                'rl.total_amount',
                'rl.status',
                'rl.expense_log_id',
                'rl.created_at',
                'rl.updated_at',
                'st.staff_name',
                'el.reference_no',
            ])

            ->orderByDesc('rl.date')
            ->orderByDesc('rl.sno')
            ->get()
            ->map(function ($log) {

                if ((int) $log->status === 1) {

                    $status = 'paid';
                    $label = 'Paid';
                    $icon = 'mdi-check-circle-outline';

                } elseif ((int) $log->status === 3) {

                    $status = 'dropped';
                    $label = 'Dropped';
                    $icon = 'mdi-close-circle-outline';

                } elseif (
                    Carbon::parse($log->date)
                        ->lt(Carbon::today('Asia/Kolkata'))
                ) {

                    $status = 'overdue';
                    $label = 'Overdue';
                    $icon = 'mdi-alert-circle-outline';

                } elseif (
                    Carbon::parse($log->date)
                        ->isToday()
                ) {

                    $status = 'today';
                    $label = 'Due Today';
                    $icon = 'mdi-alarm-alert';

                } elseif (
                    Carbon::parse($log->date)
                        ->isTomorrow()
                ) {

                    $status = 'tomorrow';
                    $label = 'Due Tomorrow';
                    $icon = 'mdi-clock-alert-outline';

                } else {

                    $status = 'upcoming';
                    $label = 'Upcoming';
                    $icon = 'mdi-calendar-clock-outline';
                }

                return [
                    'id' => (int) $log->sno,

                    'date' => $log->date,

                    'paid_date' => $log->paid_date,

                    'amount' => (float) ($log->amount ?? 0),

                    'currency_type' => $log->currency_type,

                    'currency_amount' =>
                        (float) ($log->currency_amount ?? 0),

                    'gst_amount' =>
                        (float) ($log->gst_amount ?? 0),

                    'total_amount' =>
                        (float) ($log->total_amount ?? 0),

                    'status' => (int) $log->status,

                    'display_status' => $status,

                    'status_label' => $label,

                    'status_icon' => $icon,

                    'expense_log_id' =>
                        $log->expense_log_id
                            ? (int) $log->expense_log_id
                            : null,

                    'reference_no' =>
                        $log->reference_no,

                    'updated_by' =>
                        $log->staff_name,

                    'created_at' =>
                        $log->created_at,

                    'updated_at' =>
                        $log->updated_at,
                ];
            });

        /*Summary */

        $logSummary = [

            'total' => $logs->count(),
            'paid' => $logs->where('status', 1)->count(),
            'unpaid' => $logs->where('status', 0)->count(),
            'dropped' => $logs->where('status', 3)->count(),
            'overdue' => $logs->where('display_status','overdue' )->count(),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'master' => $master,
                'logs' => $logs->values(),
                'summary' => $logSummary,
            ],
        ]);
    }

    public function productRecurringLogs(
        Request $request,
        int $id
    ) {

        $product = DB::table(
            'egc_acc_expense_products as p'
        )
            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )
            ->where('p.sno', $id)
            ->select([
                'p.sno',
                'p.product_name',
                'p.product_code',
                'p.category_id',
                'p.frequency_type',
                'p.is_recurring',
                'p.billing_date',
                'p.default_amount',
                'p.currency_type',
                'p.is_gst_applicable',
                'p.remarks',
                'c.category_name',
                'c.icon',
            ])
            ->first();

        if (!$product) {

            return response()->json([
                'success' => false,
                'message' => 'Expense product not found.',
            ], 404);
        }

        $recurring = DB::table(
            'egc_acc_recurring'
        )
            ->where(
                'product_id',
                $id
            )
            ->first();

        if (!$recurring) {

            return response()->json([
                'success' => true,
                'data' => [
                    'product' => $product,
                    'master' => null,
                    'logs' => [],
                ],
            ]);
        }

        $logs = DB::table(
            'egc_acc_recurring_log as rl'
        )
            ->where(
                'rl.recurring_id',
                $recurring->sno
            )
            ->orderByDesc('rl.date')
            ->orderByDesc('rl.sno')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'product' => $product,
                'master' => $recurring,
                'logs' => $logs,
            ],
        ]);
    }

    public function stopRecurring(
        int $id,
        Request $request
    ) {

        $userId = $request->user()->user_id ?? 0;

        try {

            DB::transaction(function () use ($id, $userId) {

                $recurring = DB::table(
                    'egc_acc_recurring'
                )
                    ->where('product_id', $id)
                    ->where('status', 0)
                    ->lockForUpdate()
                    ->first();

                if (!$recurring) {

                    throw new \RuntimeException(
                        'Active recurring subscription not found.'
                    );
                }

                $now = Carbon::now('Asia/Kolkata');

                DB::table('egc_acc_recurring')
                    ->where('sno', $recurring->sno)
                    ->update([
                        'status' => 2,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);

                DB::table('egc_acc_recurring_log')
                    ->where(
                        'recurring_id',
                        $recurring->sno
                    )
                    ->where('status', 0)
                    ->whereDate(
                        'date',
                        '>=',
                        Carbon::today('Asia/Kolkata')
                            ->toDateString()
                    )
                    ->update([
                        'status' => 3,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);

                DB::table(
                    'egc_acc_expense_products'
                )
                    ->where('sno', $id)
                    ->update([
                        'is_recurring' => 0,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);
            });

            return response()->json([
                'success' => true,
                'message' =>
                    'Recurring subscription stopped successfully.',
            ]);

        } catch (\Throwable $e) {

            report($e);

            return response()->json([
                'success' => false,
                'message' =>
                    'Unable to stop the recurring subscription.',
            ], 500);
        }
    }


    public function dropRecurring(
        Request $request,
        int $id
    ){

        $userId = $request->user()->user_id ?? 0;

        $recurring = DB::table( 'egc_acc_recurring_log' )
            ->where('sno', $id)
            ->first();


        if (!$recurring) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring record not found.',
            ], 404);
        }


        if ((int) $recurring->status === 1) {

            return response()->json([
                'success' => false,
                'message' => 'A paid recurring record cannot be dropped.',
            ], 422);
        }


        if ((int) $recurring->status === 3) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring record is already dropped.',
            ], 422);
        }


        DB::table('egc_acc_recurring_log' )
            ->where('sno', $id)
            ->update([
                'status' => 3,
                'updated_by' => $userId,
                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

            ]);


        return response()->json([
            'success' => true,
            'message' => 'Recurring payment dropped successfully.',
        ]);
    }


}