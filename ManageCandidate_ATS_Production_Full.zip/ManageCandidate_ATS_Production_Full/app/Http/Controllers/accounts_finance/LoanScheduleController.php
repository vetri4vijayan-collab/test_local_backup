<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use App\Models\Loans\Loan;
use App\Models\Loans\LoanAuditLog;
use App\Models\Loans\LoanCcFacility;
use App\Models\Loans\LoanChangeRequest;
use App\Models\Loans\LoanJewelPledge;
use App\Models\Loans\LoanLender;
use App\Models\Loans\LoanObligation;
use App\Models\Loans\LoanPayment;
use App\Models\Loans\LoanPaymentAllocation;
use App\Models\Loans\LoanSchedule;
use App\Models\Loans\LoanScheduleLine;
use App\Models\Loans\LoanTranche;
use App\Models\Loans\LoanType;
use App\Models\Loans\LoanVehicle;
use App\Services\Loans\LoanScheduleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class LoanScheduleController extends Controller
{
    public function __construct(
        private readonly LoanScheduleService $scheduleService
    ) {
    }

    public function index()
    {
        return view('content.accounts_finance.loan_schedule.index');
    }

    public function calendarPage()
    {
        return view('content.accounts_finance.loan_schedule.calendar');
    }

    public function detail(Loan $loan)
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.view');

        return view(
            'content.accounts_finance.loan_schedule.show',
            compact('loan')
        );
    }

    public function data(Request $request): JsonResponse
    {
        $this->assertPermission('loan.view');

        $page = max(1, (int) $request->input('page', 1));
        $perPage = min(100, max(10, (int) $request->input('per_page', 25)));

        $query = Loan::query()
            ->with([
                'lender:id,lender_name,branch_name',
                'type:id,type_code,type_name,icon',
            ])
            ->with([
                'obligations' => fn ($q) => $q
                    ->whereIn('status', ['pending', 'today', 'overdue', 'partial', 'snoozed'])
                    ->orderBy('due_date')
                    ->limit(1),
            ])
            ->whereNull('deleted_at');

        $this->applyEntityScope($query, $request);

        $this->applyLoanFilters($query, $request);

        $loans = $query
            ->orderByDesc('id')
            ->paginate($perPage, ['*'], 'page', $page);

        $today = now()->startOfDay();
        $weekEnd = $today->copy()->endOfWeek();

        $summaryQuery = Loan::query()->whereNull('deleted_at');
        $this->applyEntityScope($summaryQuery, $request);
        $this->applyLoanFilters($summaryQuery, $request);

        $loanIds = (clone $summaryQuery)->pluck('id');

        $summary = [
            'total_loans' => (clone $summaryQuery)->count(),
            'active_loans' => (clone $summaryQuery)->where('status', 'active')->count(),
            'total_outstanding' => (float) (clone $summaryQuery)
                ->whereIn('status', ['active', 'restructured'])
                ->sum('outstanding_amount'),
            'pending_approval' => (clone $summaryQuery)->where('status', 'pending_approval')->count(),
            'due_this_week_count' => 0,
            'due_this_week_amount' => 0,
            'overdue_count' => 0,
            'overdue_amount' => 0,
            'renewals_60_days' => 0,
            'redemptions_30_days' => 0,
        ];

        if ($loanIds->isNotEmpty()) {
            $summary['due_this_week_count'] = LoanObligation::query()
                ->whereIn('loan_id', $loanIds)
                ->whereIn('status', ['pending', 'today', 'partial'])
                ->whereBetween('due_date', [$today->toDateString(), $weekEnd->toDateString()])
                ->count();

            $summary['due_this_week_amount'] = (float) LoanObligation::query()
                ->whereIn('loan_id', $loanIds)
                ->whereIn('status', ['pending', 'today', 'partial'])
                ->whereBetween('due_date', [$today->toDateString(), $weekEnd->toDateString()])
                ->sum('balance_amount');

            $summary['overdue_count'] = LoanObligation::query()
                ->whereIn('loan_id', $loanIds)
                ->whereIn('status', ['overdue', 'partial'])
                ->whereDate('due_date', '<', $today->toDateString())
                ->count();

            $summary['overdue_amount'] = (float) LoanObligation::query()
                ->whereIn('loan_id', $loanIds)
                ->whereIn('status', ['overdue', 'partial'])
                ->whereDate('due_date', '<', $today->toDateString())
                ->sum('balance_amount');
        }

        $summary['renewals_60_days'] = (clone $summaryQuery)
            ->whereHas('ccFacility', function ($q) use ($today) {
                $q->whereBetween('renewal_date', [
                    $today->toDateString(),
                    $today->copy()->addDays(60)->toDateString(),
                ]);
            })
            ->count();

        $summary['redemptions_30_days'] = (clone $summaryQuery)
            ->whereHas('jewelPledge', function ($q) use ($today) {
                $q->whereBetween('redemption_due_date', [
                    $today->toDateString(),
                    $today->copy()->addDays(30)->toDateString(),
                ]);
            })
            ->count();

        $loanRows = $loans->getCollection()
            ->map(fn (Loan $loan) => $this->serializeLoan($loan))
            ->values();

        return response()->json([
            'status' => 200,
            'message' => 'Loans loaded successfully.',
            'data' => $loanRows,
            'pagination' => [
                'current_page' => $loans->currentPage(),
                'last_page' => $loans->lastPage(),
                'per_page' => $loans->perPage(),
                'total' => $loans->total(),
            ],
            'summary' => $summary,
        ]);
    }

    public function calendar(Request $request): JsonResponse
    {
        $this->assertPermission('loan.view');

        $year = max(2000, min(2100, (int) $request->input('year', now()->year)));
        $month = max(1, min(12, (int) $request->input('month', now()->month)));

        $start = Carbon::create($year, $month, 1)->startOfMonth();
        $end = $start->copy()->endOfMonth();

        if ($request->input('view') === 'week') {
            $anchor = $request->filled('date')
                ? Carbon::parse($request->input('date'))
                : now();

            $start = $anchor->copy()->startOfWeek();
            $end = $anchor->copy()->endOfWeek();
        }

        $query = LoanObligation::query()
            ->with([
                'loan:id,entity_id,lender_id,loan_type_id,loan_type,account_no,title,outstanding_amount,status',
                'loan.lender:id,lender_name',
                'loan.type:id,type_code,type_name,icon',
                'scheduleLine:id,schedule_id,installment_no,principal_amount,interest_amount,closing_balance',
            ])
            ->whereBetween('due_date', [$start->toDateString(), $end->toDateString()])
            ->whereNotIn('status', ['superseded', 'waived']);

        $this->applyEntityScopeToObligations($query, $request);
        $this->applyCalendarFilters($query, $request);

        if ($request->filled('search')) {
            $term = trim($request->input('search'));
            $query->where(function ($q) use ($term) {
                $q->where('title', 'like', "%{$term}%")
                    ->orWhereHas('loan', function ($loan) use ($term) {
                        $loan->where('account_no', 'like', "%{$term}%")
                            ->orWhere('title', 'like', "%{$term}%");
                    })
                    ->orWhereHas('loan.lender', function ($lender) use ($term) {
                        $lender->where('lender_name', 'like', "%{$term}%");
                    });
            });
        }

        $items = $query
            ->orderBy('due_date')
            ->orderBy('id')
            ->get();

        $items = $items->map(function (LoanObligation $item) {
            return $this->serializeObligation($item);
        })->values();

        $today = now()->toDateString();

        $summary = [
            'items' => $items->count(),
            'amount' => (float) $items->sum(fn ($item) => (float) $item['balance_amount']),
            'today' => $items->where('status_key', 'today')->count(),
            'overdue' => $items->where('status_key', 'overdue')->count(),
            'paid' => $items->where('status_key', 'paid')->count(),
        ];

        return response()->json([
            'status' => 200,
            'range' => [
                'start' => $start->toDateString(),
                'end' => $end->toDateString(),
                'today' => $today,
            ],
            'data' => $items,
            'summary' => $summary,
        ]);
    }

    public function lookups(): JsonResponse
    {
        $this->assertPermission('loan.view');

        $entities = DB::table('egc_entity')
            ->where('status', 0)
            ->orderBy('entity_name')
            ->get(['sno as id', 'entity_name as name']);

        $types = LoanType::query()
            ->where('status', 1)
            ->orderBy('display_order')
            ->get(['id', 'type_code', 'type_name', 'icon', 'description']);

        $lenders = LoanLender::query()
            ->where('status', 1)
            ->orderBy('lender_name')
            ->get(['id', 'lender_name', 'branch_name']);

        return response()->json([
            'status' => 200,
            'data' => [
                'entities' => $entities,
                'types' => $types,
                'lenders' => $lenders,
                'statuses' => [
                    ['code' => 'draft', 'name' => 'Draft'],
                    ['code' => 'pending_approval', 'name' => 'Pending Approval'],
                    ['code' => 'active', 'name' => 'Active'],
                    ['code' => 'returned', 'name' => 'Returned'],
                    ['code' => 'restructured', 'name' => 'Restructured'],
                    ['code' => 'closed', 'name' => 'Closed'],
                    ['code' => 'foreclosed', 'name' => 'Foreclosed'],
                ],
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->assertPermission('loan.create');

        $data = $this->validateLoan($request, false);

        $actor = $this->currentUserId();

        $loan = DB::transaction(function () use ($data, $actor) {
            $loan = Loan::create([
                ...$this->loanCoreData($data),
                'status' => 'pending_approval',
                'created_by' => $actor,
                'updated_by' => $actor,
            ]);

            $this->saveTypeSpecificData($loan, $data, true);

            $this->audit(
                $loan,
                'loan_created',
                'Loan created and submitted for Finance approval.',
                null,
                $loan->fresh()->toArray()
            );

            return $loan->fresh();
        });

        return response()->json([
            'status' => 200,
            'message' => 'Loan created and submitted for Finance approval.',
            'data' => $this->serializeLoan($loan->load(['lender', 'type', 'obligations'])),
        ]);
    }

    public function update(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        $data = $this->validateLoan($request, true);

        if (in_array($loan->status, ['active', 'restructured'], true)) {
            $financialFields = [
                'sanctioned_amount','disbursed_amount','outstanding_amount',
                'interest_rate','interest_type','start_date','first_due_date',
                'tenure_months','emi_amount','maturity_date','moratorium_months',
            ];

            foreach ($financialFields as $field) {
                if ($request->has($field) && (string) $request->input($field) !== (string) $loan->{$field}) {
                    abort(422, 'Financial fields of an active loan cannot be edited directly. Use Part-Prepay or Restructure.');
                }
            }
        }

        $before = $loan->toArray();
        $actor = $this->currentUserId();

        DB::transaction(function () use ($loan, $data, $actor, $before) {
            $loan->update([
                ...$this->loanCoreData($data),
                'updated_by' => $actor,
            ]);

            $this->saveTypeSpecificData($loan, $data, false);

            $this->audit(
                $loan,
                'loan_updated',
                'Loan details updated.',
                $before,
                $loan->fresh()->toArray()
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Loan updated successfully.',
            'data' => $this->serializeLoan($loan->fresh()->load(['lender', 'type', 'obligations'])),
        ]);
    }

    public function show(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.view');

        $loan->load([
            'lender',
            'type',
            'vehicle',
            'tranches',
            'jewelPledge.items',
            'ccFacility.utilisations',
            'schedules.lines',
            'obligations.scheduleLine',
            'payments',
            'documents',
            'changeRequests',
            'renewalChecklists.items',
            'auditLogs',
        ]);

        return response()->json([
            'status' => 200,
            'data' => [
                'loan' => $this->serializeLoan($loan),
                'loan_raw' => $loan,
                'schedule_versions' => $loan->schedules->map(fn ($s) => [
                    'id' => $s->id,
                    'version_no' => $s->version_no,
                    'label' => $s->schedule_label,
                    'method' => $s->method,
                    'effective_from' => optional($s->effective_from)->format('Y-m-d'),
                    'is_active' => (bool) $s->is_active,
                ])->values(),
            ],
        ]);
    }

    public function approve(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.approve');

        abort_unless(
            $loan->status === 'pending_approval',
            422,
            'Only pending loans can be approved.'
        );

        // abort_if(
        //     (int) $loan->created_by === (int) $this->currentUserId(),
        //     403,
        //     'The maker cannot approve their own loan.'
        // );

        DB::transaction(function () use ($loan) {
            $loan->update([
                'status' => 'active',
                'approved_by' => $this->currentUserId(),
                'approved_at' => now(),
                'updated_by' => $this->currentUserId(),
            ]);

            if (in_array($loan->loan_type, ['vehicle', 'term'], true)) {
                $loan->load('type');

                if (!$loan->schedules()->where('is_active', true)->exists()) {
                    $this->scheduleService->generateForLoan($loan->fresh());
                }
            }

            $loan->load([
                'jewelPledge',
                'ccFacility',
            ]);

            $this->scheduleService->syncSpecialObligations($loan->fresh());

            $this->audit(
                $loan,
                'loan_approved',
                'Loan approved and activated. Schedule/calendar obligations synchronized.'
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Loan approved successfully.',
        ]);
    }

    public function reject(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.approve');

        $data = $request->validate([
            'remarks' => ['required', 'string', 'max:1000'],
        ]);

        abort_unless(
            $loan->status === 'pending_approval',
            422,
            'Only pending loans can be returned.'
        );

        $before = $loan->toArray();

        $loan->update([
            'status' => 'returned',
            'returned_by' => $this->currentUserId(),
            'returned_at' => now(),
            'updated_by' => $this->currentUserId(),
        ]);

        $this->audit(
            $loan,
            'loan_returned',
            'Loan returned to maker: '.$data['remarks'],
            $before,
            ['status' => 'returned', 'remarks' => $data['remarks']]
        );

        return response()->json([
            'status' => 200,
            'message' => 'Loan returned to maker.',
        ]);
    }

    public function payment(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.payment');

        $data = $request->validate([
            'obligation_id' => ['nullable', 'integer', 'exists:egc_loan_obligations,id'],
            'payment_type' => ['required', 'in:regular,interest,principal'],
            'payment_date' => ['required', 'date'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'principal_amount' => ['nullable', 'numeric', 'gte:0'],
            'interest_amount' => ['nullable', 'numeric', 'gte:0'],
            'penal_interest' => ['nullable', 'numeric', 'gte:0'],
            'bounce_charge' => ['nullable', 'numeric', 'gte:0'],
            'mode' => ['required', 'in:NACH,NEFT,RTGS,Cash,Cheque,UPI,Other'],
            'reference_no' => ['nullable', 'string', 'max:150'],
            'pay_from_account' => ['nullable', 'string', 'max:180'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);

        $obligation = null;

        if (!empty($data['obligation_id'])) {
            $obligation = LoanObligation::query()
                ->where('loan_id', $loan->id)
                ->findOrFail($data['obligation_id']);
        }

        $payment = DB::transaction(function () use ($loan, $obligation, $data) {
            $amount = round((float) $data['amount'], 2);

            $principalAmount = round(
                (float) ($data['principal_amount'] ?? 0),
                2
            );

            $interestAmount = round(
                (float) ($data['interest_amount'] ?? 0),
                2
            );

            if (!$obligation && $data['payment_type'] === 'interest') {
                $interestAmount = $amount;
            }

            if (!$obligation && $data['payment_type'] === 'principal') {
                $principalAmount = $amount;
            }

            $payment = LoanPayment::create([
                'loan_id' => $loan->id,
                'obligation_id' => $obligation?->id,
                'payment_type' => $data['payment_type'],
                'payment_date' => $data['payment_date'],
                'amount' => $amount,
                'principal_amount' => $principalAmount,
                'interest_amount' => $interestAmount,
                'penal_interest' => (float) ($data['penal_interest'] ?? 0),
                'bounce_charge' => (float) ($data['bounce_charge'] ?? 0),
                'mode' => $data['mode'],
                'reference_no' => $data['reference_no'] ?? null,
                'pay_from_account' => $data['pay_from_account'] ?? null,
                'notes' => $data['notes'] ?? null,
                'created_by' => $this->currentUserId(),
            ]);

            if ($obligation) {
                $currentBalance = max(
                    0,
                    (float) $obligation->balance_amount
                );

                $allocated = min($amount, $currentBalance);

                LoanPaymentAllocation::create([
                    'payment_id' => $payment->id,
                    'obligation_id' => $obligation->id,
                    'amount' => $allocated,
                ]);

                $newPaid = min(
                    (float) $obligation->amount,
                    (float) $obligation->paid_amount + $allocated
                );

                $newBalance = max(
                    0,
                    (float) $obligation->amount - $newPaid
                );

                if ($newBalance <= 0) {
                    $obligation->update([
                        'paid_amount' => $newPaid,
                        'balance_amount' => 0,
                        'status' => 'paid',
                        'completed_at' => now(),
                    ]);
                } elseif ($newPaid > 0) {
                    $status = Carbon::parse($obligation->due_date)->isPast()
                        ? 'overdue'
                        : 'partial';

                    $obligation->update([
                        'paid_amount' => $newPaid,
                        'balance_amount' => $newBalance,
                        'status' => $status,
                    ]);
                }

                if ($obligation->schedule_line_id) {
                    $line = LoanScheduleLine::find($obligation->schedule_line_id);

                    if ($line) {
                        $line->update([
                            'status' => $newBalance <= 0 ? 'paid' : 'partial',
                            'paid_at' => $newBalance <= 0 ? now() : null,
                        ]);
                    }
                }
            }

            $outstanding = (float) $loan->outstanding_amount;
            $loan->update([
                'outstanding_amount' => max(
                    0,
                    $outstanding - $principalAmount
                ),
                'updated_by' => $this->currentUserId(),
            ]);

            $this->audit(
                $loan,
                'payment_recorded',
                'Payment recorded: ₹'.number_format($amount, 2).' via '.$data['mode'].'.'
            );

            return $payment;
        });

        return response()->json([
            'status' => 200,
            'message' => 'Payment recorded successfully.',
            'data' => ['payment_id' => $payment->id],
        ]);
    }

    public function prepayPreview(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        $data = $request->validate([
            'amount' => ['required', 'numeric', 'gt:0'],
            'effective_date' => ['required', 'date'],
            'mode' => ['required', 'in:reduce_emi,reduce_tenure'],
        ]);

        $schedule = $loan->schedules()
            ->where('is_active', true)
            ->with('lines')
            ->first();

        abort_if(!$schedule, 422, 'This loan does not have an active schedule.');

        $paid = $schedule->lines->where('status', 'paid');
        $unpaid = $schedule->lines->where('status', '!=', 'paid');

        $currentBalance = (float) (
            $paid->last()?->closing_balance
            ?? $schedule->principal_amount
        );

        $newBalance = max(
            0,
            $currentBalance - (float) $data['amount']
        );

        $newLines = $this->scheduleService->buildReducingSchedule(
            max(0.01, $newBalance),
            (float) $loan->interest_rate,
            max(
                1,
                $data['mode'] === 'reduce_emi'
                    ? (int) $unpaid->count()
                    : (int) $unpaid->count()
            ),
            Carbon::parse($data['effective_date'])->addMonthNoOverflow()
        );

        $newEmi = (float) ($newLines[0]['emi_amount'] ?? 0);
        $currentEmi = (float) ($unpaid->first()?->emi_amount ?? $loan->emi_amount);

        return response()->json([
            'status' => 200,
            'data' => [
                'current_balance' => $currentBalance,
                'new_balance' => $newBalance,
                'prepay_amount' => (float) $data['amount'],
                'current_emi' => $currentEmi,
                'new_emi' => $newEmi,
                'current_installments' => $unpaid->count(),
                'new_installments' => count($newLines),
                'mode' => $data['mode'],
                'interest_saved_preview' => max(
                    0,
                    (float) $unpaid->sum('interest_amount') -
                    (float) collect($newLines)->sum('interest_amount')
                ),
                'new_end_date' => $newLines
                    ? end($newLines)['due_date']
                    : null,
            ],
        ]);
    }

    public function prepay(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        $data = $request->validate([
            'amount' => ['required', 'numeric', 'gt:0'],
            'effective_date' => ['required', 'date'],
            'mode' => ['required', 'in:reduce_emi,reduce_tenure'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $preview = $this->prepayPreview($request, $loan)->getData(true)['data'];

        LoanChangeRequest::create([
            'loan_id' => $loan->id,
            'change_type' => 'prepay',
            'status' => 'pending',
            'requested_by' => $this->currentUserId(),
            'effective_date' => $data['effective_date'],
            'payload_json' => [
                ...$data,
                'preview' => $preview,
            ],
            'remarks' => $data['reason'],
        ]);

        $loan->update([
            'status' => 'pending_approval',
            'updated_by' => $this->currentUserId(),
        ]);

        $this->audit(
            $loan,
            'prepay_submitted',
            'Part-prepayment submitted for Finance approval.'
        );

        return response()->json([
            'status' => 200,
            'message' => 'Part-prepayment submitted for Finance approval.',
        ]);
    }

    public function approvePrepay(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.approve');

        $change = LoanChangeRequest::query()
            ->where('loan_id', $loan->id)
            ->where('change_type', 'prepay')
            ->where('status', 'pending')
            ->latest('id')
            ->firstOrFail();

        abort_if(
            (int) $change->requested_by === (int) $this->currentUserId(),
            403,
            'The maker cannot approve their own change.'
        );

        $payload = $change->payload_json ?? [];

        $schedule = $loan->schedules()
            ->where('is_active', true)
            ->with('lines')
            ->firstOrFail();

        $paid = $schedule->lines->where('status', 'paid');
        $unpaid = $schedule->lines->where('status', '!=', 'paid');

        $balance = (float) ($paid->last()?->closing_balance ?? $schedule->principal_amount);
        $newBalance = max(0, $balance - (float) $payload['amount']);

        $months = max(1, (int) $unpaid->count());

        if (($payload['mode'] ?? '') === 'reduce_tenure') {
            $newLines = $this->scheduleService->buildReducingSchedule(
                max(0.01, $newBalance),
                (float) $loan->interest_rate,
                $months,
                Carbon::parse($payload['effective_date'])->addMonthNoOverflow()
            );

            $targetEmi = (float) ($loan->emi_amount ?? $newLines[0]['emi_amount'] ?? 0);

            if ($targetEmi > 0) {
                $rate = (float) $loan->interest_rate / 1200;
                $n = 1;
                $running = $newBalance;

                while ($running > 0.01 && $n <= 360) {
                    $interest = $running * $rate;
                    $principalPart = min(
                        max(0, $targetEmi - $interest),
                        $running
                    );
                    $running = max(
                        0,
                        round($running - $principalPart, 2)
                    );
                    $n++;
                }

                $newLines = $this->scheduleService->buildReducingSchedule(
                    max(0.01, $newBalance),
                    (float) $loan->interest_rate,
                    max(1, $n - 1),
                    Carbon::parse($payload['effective_date'])->addMonthNoOverflow()
                );
            }
        } else {
            $newLines = $this->scheduleService->buildReducingSchedule(
                max(0.01, $newBalance),
                (float) $loan->interest_rate,
                $months,
                Carbon::parse($payload['effective_date'])->addMonthNoOverflow()
            );
        }

        DB::transaction(function () use ($loan, $change, $payload, $newLines, $newBalance) {
            $this->scheduleService->activateSchedule(
                $loan,
                $newLines,
                [
                    'label' => 'Prepayment — '.now()->format('d-m-Y'),
                    'method' => 'prepay_version',
                    'principal_amount' => $newBalance,
                    'interest_rate' => $loan->interest_rate,
                    'effective_from' => $payload['effective_date'],
                ]
            );

            $loan->update([
                'status' => 'active',
                'outstanding_amount' => $newBalance,
                'emi_amount' => $newLines[0]['emi_amount'] ?? 0,
                'maturity_date' => $newLines
                    ? end($newLines)['due_date']
                    : $loan->maturity_date,
                'updated_by' => $this->currentUserId(),
            ]);

            $change->update([
                'status' => 'approved',
                'approved_by' => $this->currentUserId(),
                'approved_at' => now(),
            ]);

            $this->audit(
                $loan,
                'prepay_approved',
                'Part-prepayment approved and new schedule version activated.'
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Part-prepayment approved and schedule updated.',
        ]);
    }

    public function restructurePreview(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        $data = $request->validate([
            'new_rate' => ['required', 'numeric', 'gte:0', 'max:100'],
            'new_months' => ['required', 'integer', 'min:1', 'max:360'],
            'effective_date' => ['required', 'date'],
        ]);

        $schedule = $loan->schedules()
            ->where('is_active', true)
            ->with('lines')
            ->first();

        abort_if(!$schedule, 422, 'The loan has no active schedule.');

        $paid = $schedule->lines->where('status', 'paid');
        $unpaid = $schedule->lines->where('status', '!=', 'paid');

        $balance = (float) ($paid->last()?->closing_balance ?? $schedule->principal_amount);

        $rows = $this->scheduleService->buildReducingSchedule(
            max(0.01, $balance),
            (float) $data['new_rate'],
            (int) $data['new_months'],
            Carbon::parse($data['effective_date'])->addMonthNoOverflow()
        );

        return response()->json([
            'status' => 200,
            'data' => [
                'current' => [
                    'balance' => $balance,
                    'emi' => (float) ($unpaid->first()?->emi_amount ?? $loan->emi_amount),
                    'interest' => (float) $unpaid->sum('interest_amount'),
                    'installments' => $unpaid->count(),
                    'end_date' => optional($unpaid->last()?->due_date)->format('Y-m-d'),
                ],
                'new' => [
                    'balance' => $balance,
                    'emi' => (float) ($rows[0]['emi_amount'] ?? 0),
                    'interest' => (float) collect($rows)->sum('interest_amount'),
                    'installments' => count($rows),
                    'end_date' => $rows ? end($rows)['due_date'] : null,
                ],
            ],
        ]);
    }

    public function restructure(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        $data = $request->validate([
            'new_rate' => ['required', 'numeric', 'gte:0', 'max:100'],
            'new_months' => ['required', 'integer', 'min:1', 'max:360'],
            'effective_date' => ['required', 'date'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $preview = $this->restructurePreview($request, $loan)->getData(true)['data'];

        LoanChangeRequest::create([
            'loan_id' => $loan->id,
            'change_type' => 'restructure',
            'status' => 'pending',
            'requested_by' => $this->currentUserId(),
            'effective_date' => $data['effective_date'],
            'payload_json' => [
                ...$data,
                'preview' => $preview,
            ],
            'remarks' => $data['reason'],
        ]);

        $loan->update([
            'status' => 'pending_approval',
            'updated_by' => $this->currentUserId(),
        ]);

        $this->audit(
            $loan,
            'restructure_submitted',
            'Restructure submitted for Finance approval.'
        );

        return response()->json([
            'status' => 200,
            'message' => 'Restructure submitted for Finance approval.',
        ]);
    }

    public function approveRestructure(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.approve');

        $change = LoanChangeRequest::query()
            ->where('loan_id', $loan->id)
            ->where('change_type', 'restructure')
            ->where('status', 'pending')
            ->latest('id')
            ->firstOrFail();

        abort_if(
            (int) $change->requested_by === (int) $this->currentUserId(),
            403,
            'The maker cannot approve their own change.'
        );

        $payload = $change->payload_json ?? [];

        $loan->load('schedules.lines');

        $previewRequest = new Request([
            'new_rate' => $payload['new_rate'],
            'new_months' => $payload['new_months'],
            'effective_date' => $change->effective_date?->toDateString(),
        ]);

        $preview = $this->restructurePreview($previewRequest, $loan)->getData(true)['data'];

        $schedule = $loan->schedules()
            ->where('is_active', true)
            ->with('lines')
            ->firstOrFail();

        $paid = $schedule->lines->where('status', 'paid');
        $balance = (float) ($paid->last()?->closing_balance ?? $schedule->principal_amount);

        $rows = $this->scheduleService->buildReducingSchedule(
            max(0.01, $balance),
            (float) $payload['new_rate'],
            (int) $payload['new_months'],
            Carbon::parse($change->effective_date)->addMonthNoOverflow()
        );

        DB::transaction(function () use ($loan, $change, $payload, $rows, $preview) {
            $newSchedule = $this->scheduleService->activateSchedule(
                $loan,
                $rows,
                [
                    'label' => 'Restructured — '.now()->format('d-m-Y'),
                    'method' => 'restructure_version',
                    'principal_amount' => $loan->outstanding_amount,
                    'interest_rate' => $payload['new_rate'],
                    'effective_from' => $change->effective_date->toDateString(),
                ]
            );

            $loan->update([
                'status' => 'restructured',
                'interest_rate' => $payload['new_rate'],
                'tenure_months' => $payload['new_months'],
                'emi_amount' => $preview['new']['emi'],
                'maturity_date' => $preview['new']['end_date'],
                'updated_by' => $this->currentUserId(),
            ]);

            $change->update([
                'status' => 'approved',
                'approved_by' => $this->currentUserId(),
                'approved_at' => now(),
            ]);

            $this->audit(
                $loan,
                'restructure_approved',
                'Restructure approved; schedule v'.$newSchedule->version_no.' activated.'
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Restructure approved and new schedule activated.',
        ]);
    }

    public function close(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.close');

        $data = $request->validate([
            'closure_type' => ['required', 'in:closed,foreclosed'],
            'noc_received' => ['required', 'boolean'],
            'security_released' => ['required', 'boolean'],
            'remarks' => ['nullable', 'string', 'max:1000'],
        ]);

        if (!$data['noc_received'] || !$data['security_released']) {
            throw ValidationException::withMessages([
                'checklist' => 'NOC and security release must both be completed before closing the loan.',
            ]);
        }

        $before = $loan->toArray();

        $loan->update([
            'status' => $data['closure_type'],
            'closed_at' => now(),
            'updated_by' => $this->currentUserId(),
        ]);

        LoanObligation::where('loan_id', $loan->id)
            ->whereIn('status', ['pending', 'today', 'overdue', 'partial', 'snoozed'])
            ->update([
                'status' => 'superseded',
                'updated_at' => now(),
            ]);

        $this->audit(
            $loan,
            'loan_closed',
            'Loan closed: '.$data['closure_type'].'. '.($data['remarks'] ?? ''),
            $before,
            $loan->fresh()->toArray()
        );

        return response()->json([
            'status' => 200,
            'message' => 'Loan closed successfully.',
        ]);
    }

    public function renewal(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        abort_unless($loan->loan_type === 'cc', 422, 'Renewal is available only for CC facilities.');

        $data = $request->validate([
            'renewal_date' => ['required', 'date'],
            'limit' => ['nullable', 'numeric', 'gte:0'],
            'rate' => ['nullable', 'numeric', 'gte:0', 'max:100'],
        ]);

        $facility = $loan->ccFacility()->firstOrFail();

        $before = $facility->toArray();

        $facility->update([
            'renewal_date' => $data['renewal_date'],
            'sanctioned_limit' => $data['limit'] ?? $facility->sanctioned_limit,
            'interest_rate' => $data['rate'] ?? $facility->interest_rate,
        ]);

        LoanObligation::where('loan_id', $loan->id)
            ->where('obligation_type', 'renewal')
            ->whereNotIn('status', ['paid', 'superseded'])
            ->update([
                'due_date' => $data['renewal_date'],
                'status' => 'pending',
                'updated_at' => now(),
            ]);

        $this->audit(
            $loan,
            'cc_renewed',
            'CC renewal date updated to '.$data['renewal_date'].'.',
            $before,
            $facility->fresh()->toArray()
        );

        return response()->json([
            'status' => 200,
            'message' => 'CC renewal details updated successfully.',
        ]);
    }

    public function utilisation(Request $request, Loan $loan): JsonResponse
    {
        $this->assertLoanAccess($loan);
        $this->assertPermission('loan.edit');

        abort_unless($loan->loan_type === 'cc', 422, 'Utilisation is available only for CC facilities.');

        $data = $request->validate([
            'as_of_date' => ['required', 'date'],
            'utilised_amount' => ['required', 'numeric', 'gte:0'],
            'interest_debit' => ['nullable', 'numeric', 'gte:0'],
            'drawing_power' => ['nullable', 'numeric', 'gte:0'],
            'remarks' => ['nullable', 'string', 'max:500'],
        ]);

        $facility = $loan->ccFacility()->firstOrFail();

        $facility->utilisations()->updateOrCreate(
            ['as_of_date' => $data['as_of_date']],
            [
                'utilised_amount' => $data['utilised_amount'],
                'interest_debit' => $data['interest_debit'] ?? 0,
                'drawing_power' => $data['drawing_power'] ?? null,
                'remarks' => $data['remarks'] ?? null,
                'created_by' => $this->currentUserId(),
            ]
        );

        $this->audit(
            $loan,
            'cc_utilisation_updated',
            'CC utilisation recorded for '.$data['as_of_date'].'.'
        );

        return response()->json([
            'status' => 200,
            'message' => 'CC utilisation saved successfully.',
        ]);
    }

    public function snooze(Request $request, LoanObligation $obligation): JsonResponse
    {
        $this->assertObligationAccess($obligation);
        $this->assertPermission('loan.reminder');

        $data = $request->validate([
            'snoozed_until' => ['required', 'date', 'after:now'],
        ]);

        $obligation->update([
            'status' => 'snoozed',
            'snoozed_until' => $data['snoozed_until'],
            'updated_at' => now(),
        ]);

        $this->audit(
            $obligation->loan,
            'obligation_snoozed',
            'Reminder snoozed until '.$data['snoozed_until'].'.'
        );

        return response()->json([
            'status' => 200,
            'message' => 'Reminder snoozed successfully.',
        ]);
    }

    private function validateLoan(Request $request, bool $isUpdate): array
    {
        $rules = [
            'entity_id' => ['nullable', 'integer'],
            'lender_id' => ['required', 'integer', 'exists:egc_loan_lenders,id'],
            'loan_type_id' => ['required', 'integer', 'exists:egc_loan_types,id'],
            'account_no' => ['required', 'string', 'max:120'],
            'title' => ['nullable', 'string', 'max:220'],
            'sanctioned_amount' => ['required', 'numeric', 'gte:0'],
            'disbursed_amount' => ['required', 'numeric', 'gte:0'],
            'outstanding_amount' => ['required', 'numeric', 'gte:0'],
            'interest_rate' => ['required', 'numeric', 'gte:0', 'max:100'],
            'interest_type' => ['required', 'in:reducing,flat,simple'],
            'start_date' => ['required', 'date'],
            'first_due_date' => ['nullable', 'date'],
            'tenure_months' => ['nullable', 'integer', 'min:1', 'max:360'],
            'emi_amount' => ['nullable', 'numeric', 'gte:0'],
            'maturity_date' => ['nullable', 'date'],
            'moratorium_months' => ['nullable', 'integer', 'min:0', 'max:120'],
            'security_details' => ['nullable', 'string', 'max:5000'],
            'remarks' => ['nullable', 'string', 'max:5000'],

            'registration_no' => ['nullable', 'string', 'max:60'],
            'make_model' => ['nullable', 'string', 'max:160'],
            'chassis_no' => ['nullable', 'string', 'max:120'],
            'engine_no' => ['nullable', 'string', 'max:120'],
            'hypothecated_flag' => ['nullable', 'boolean'],
            'insurance_renewal_date' => ['nullable', 'date'],

            'pledge_receipt_no' => ['nullable', 'string', 'max:120'],
            'interest_pattern' => ['nullable', 'in:monthly,at_redemption'],
            'redemption_due_date' => ['nullable', 'date'],
            'jewel_items' => ['nullable', 'array'],
            // 'jewel_items.*.description' => ['required_with:jewel_items', 'string', 'max:255'],
            // 'jewel_items.*.gross_weight' => ['nullable', 'numeric', 'gte:0'],
            // 'jewel_items.*.net_weight' => ['nullable', 'numeric', 'gte:0'],
            // 'jewel_items.*.purity' => ['nullable', 'string', 'max:30'],

            'tranches' => ['nullable', 'array'],
            // 'tranches.*.disbursed_date' => ['required_with:tranches', 'date'],
            // 'tranches.*.amount' => ['required_with:tranches', 'numeric', 'gte:0'],
            // 'tranches.*.remarks' => ['nullable', 'string', 'max:500'],

            'sanctioned_limit' => ['nullable', 'numeric', 'gte:0'],
            'margin_percent' => ['nullable', 'numeric', 'gte:0', 'max:100'],
            'drawing_power' => ['nullable', 'numeric', 'gte:0'],
            'cc_interest_rate' => ['nullable', 'numeric', 'gte:0', 'max:100'],
            'renewal_date' => ['nullable', 'date'],
            'stock_statement_day' => ['nullable', 'integer', 'min:1', 'max:31'],
        ];

        $data = $request->validate($rules);

        $duplicate = Loan::query()
            ->where('lender_id', $data['lender_id'])
            ->where('account_no', trim($data['account_no']))
            ->when(
                $isUpdate,
                fn ($q) => $q->whereKey('<>', (int) $request->route('loan'))
            )
            ->exists();

        if ($duplicate) {
            throw ValidationException::withMessages([
                'account_no' => 'A loan with the same lender and account number already exists.',
            ]);
        }

        $type = LoanType::findOrFail($data['loan_type_id']);
        $data['loan_type'] = $type->type_code;

        if (($data['loan_type'] ?? null) === 'vehicle') {
            if (empty($data['registration_no'])) {
                throw ValidationException::withMessages([
                    'registration_no' => 'Vehicle registration number is required.',
                ]);
            }
        }

        if (($data['loan_type'] ?? null) === 'jewel') {
            if (empty($data['redemption_due_date'])) {
                throw ValidationException::withMessages([
                    'redemption_due_date' => 'Redemption due date is required.',
                ]);
            }
        }

        if (($data['loan_type'] ?? null) === 'cc') {
            if (empty($data['renewal_date'])) {
                throw ValidationException::withMessages([
                    'renewal_date' => 'Renewal date is required for CC facilities.',
                ]);
            }
        }

        return $data;
    }

    private function loanCoreData(array $data): array
    {
        return [
            'entity_id' => $data['entity_id'] ?? null,
            'lender_id' => $data['lender_id'],
            'loan_type_id' => $data['loan_type_id'],
            'loan_type' => $data['loan_type'],
            'account_no' => trim($data['account_no']),
            'title' => $data['title'] ?? null,
            'sanctioned_amount' => $data['sanctioned_amount'],
            'disbursed_amount' => $data['disbursed_amount'],
            'outstanding_amount' => $data['outstanding_amount'],
            'interest_rate' => $data['interest_rate'],
            'interest_type' => $data['interest_type'],
            'start_date' => $data['start_date'],
            'first_due_date' => $data['first_due_date'] ?? null,
            'tenure_months' => $data['tenure_months'] ?? null,
            'emi_amount' => $data['emi_amount'] ?? null,
            'maturity_date' => $data['maturity_date'] ?? null,
            'moratorium_months' => $data['moratorium_months'] ?? 0,
            'security_details' => $data['security_details'] ?? null,
            'remarks' => $data['remarks'] ?? null,
        ];
    }

    private function saveTypeSpecificData(Loan $loan, array $data, bool $creating): void
    {
        $type = $data['loan_type'];

        if ($type === 'vehicle') {
            LoanVehicle::updateOrCreate(
                ['loan_id' => $loan->id],
                [
                    'registration_no' => $data['registration_no'] ?? null,
                    'make_model' => $data['make_model'] ?? null,
                    'chassis_no' => $data['chassis_no'] ?? null,
                    'engine_no' => $data['engine_no'] ?? null,
                    'hypothecated_flag' => (bool) ($data['hypothecated_flag'] ?? true),
                    'insurance_renewal_date' => $data['insurance_renewal_date'] ?? null,
                ]
            );
        }

        if ($type === 'term' && !empty($data['tranches'])) {
            if (!$creating) {
                LoanTranche::where('loan_id', $loan->id)->delete();
            }

            foreach (array_values($data['tranches']) as $index => $tranche) {
                LoanTranche::create([
                    'loan_id' => $loan->id,
                    'tranche_no' => $index + 1,
                    'disbursed_date' => $tranche['disbursed_date'],
                    'amount' => $tranche['amount'],
                    'remarks' => $tranche['remarks'] ?? null,
                    'created_by' => $this->currentUserId(),
                    'updated_by' => $this->currentUserId(),
                ]);
            }
        }

        if ($type === 'jewel') {
            $pledge = LoanJewelPledge::updateOrCreate(
                ['loan_id' => $loan->id],
                [
                    'pledge_receipt_no' => $data['pledge_receipt_no'] ?? null,
                    'interest_pattern' => $data['interest_pattern'] ?? 'monthly',
                    'redemption_due_date' => $data['redemption_due_date'] ?? null,
                    'status' => 'pledged',
                ]
            );

            if (!$creating) {
                $pledge->items()->delete();
            }

            foreach (array_values($data['jewel_items'] ?? []) as $index => $item) {
                $pledge->items()->create([
                    'item_no' => $index + 1,
                    'description' => $item['description'],
                    'gross_weight' => $item['gross_weight'] ?? null,
                    'net_weight' => $item['net_weight'] ?? null,
                    'purity' => $item['purity'] ?? null,
                    'release_status' => 'held',
                ]);
            }
        }

        if ($type === 'cc') {
            LoanCcFacility::updateOrCreate(
                ['loan_id' => $loan->id],
                [
                    'sanctioned_limit' => $data['sanctioned_limit'] ?? $data['sanctioned_amount'],
                    'margin_percent' => $data['margin_percent'] ?? null,
                    'drawing_power' => $data['drawing_power'] ?? null,
                    'interest_rate' => $data['cc_interest_rate'] ?? $data['interest_rate'],
                    'renewal_date' => $data['renewal_date'] ?? null,
                    'stock_statement_day' => $data['stock_statement_day'] ?? null,
                    'status' => 'active',
                ]
            );
        }
    }

    private function serializeLoan(Loan $loan): array
    {
        $next = $loan->relationLoaded('obligations')
            ? $loan->obligations->sortBy('due_date')->first()
            : null;

        $days = $next
            ? now()->startOfDay()->diffInDays(
                Carbon::parse($next->due_date),
                false
            )
            : null;

        $status = $next
            ? $this->effectiveObligationStatus($next)
            : null;

        $tenurePaid = 0;
        $tenureTotal = (int) ($loan->tenure_months ?? 0);

        if ($loan->relationLoaded('schedules')) {
            $active = $loan->schedules->firstWhere('is_active', true);
            if ($active && $active->relationLoaded('lines')) {
                $tenurePaid = $active->lines
                    ->where('status', 'paid')
                    ->count();
            }
        }

        return [
            'id' => $loan->id,
            'entity_id' => $loan->entity_id,
            'lender_id' => $loan->lender_id,
            'loan_type_id' => $loan->loan_type_id,
            'account_no' => $loan->account_no,
            'title' => $loan->title ?: $loan->account_no,
            'loan_type' => $loan->loan_type ?: $loan->type?->type_code,
            'loan_type_name' => $loan->type?->type_name,
            'loan_type_icon' => $loan->type?->icon ?: 'mdi-bank-outline',
            'lender_name' => $loan->lender?->lender_name,
            'branch_name' => $loan->lender?->branch_name,
            'outstanding_amount' => (float) $loan->outstanding_amount,
            'emi_amount' => (float) ($loan->emi_amount ?? 0),
            'status' => $loan->status,
            'next_due' => $next ? $next->due_date?->format('Y-m-d') : null,
            'next_due_title' => $next?->title,
            'next_due_amount' => $next ? (float) $next->balance_amount : 0,
            'next_due_status' => $status,
            'days_to_due' => $days,
            'tenure_paid' => $tenurePaid,
            'tenure_total' => $tenureTotal,
            'tenure_percent' => $tenureTotal > 0
                ? min(100, round(($tenurePaid / $tenureTotal) * 100, 1))
                : 0,
            'maturity_date' => $loan->maturity_date?->format('Y-m-d'),
            'start_date' => $loan->start_date?->format('Y-m-d'),
            'interest_rate' => (float) $loan->interest_rate,
        ];
    }

    private function serializeObligation(LoanObligation $item): array
    {
        $statusKey = $this->effectiveObligationStatus($item);

        return [
            'id' => $item->id,
            'loan_id' => $item->loan_id,
            'schedule_line_id' => $item->schedule_line_id,
            'title' => $item->title,
            'obligation_type' => $item->obligation_type,
            'due_date' => $item->due_date?->format('Y-m-d'),
            'amount' => (float) $item->amount,
            'paid_amount' => (float) $item->paid_amount,
            'balance_amount' => (float) $item->balance_amount,
            'status' => $item->status,
            'status_key' => $statusKey,
            'snoozed_until' => $item->snoozed_until?->format('Y-m-d H:i:s'),
            'action_label' => $item->action_label,
            'installment_no' => $item->scheduleLine?->installment_no,
            'principal_amount' => (float) ($item->scheduleLine?->principal_amount ?? 0),
            'interest_amount' => (float) ($item->scheduleLine?->interest_amount ?? 0),
            'closing_balance' => (float) ($item->scheduleLine?->closing_balance ?? 0),
            'loan' => [
                'id' => $item->loan?->id,
                'account_no' => $item->loan?->account_no,
                'title' => $item->loan?->title ?: $item->loan?->account_no,
                'entity_id' => $item->loan?->entity_id,
                'loan_type' => $item->loan?->loan_type ?: $item->loan?->type?->type_code,
                'loan_type_name' => $item->loan?->type?->type_name,
                'loan_type_icon' => $item->loan?->type?->icon ?: 'mdi-bank-outline',
                'lender_name' => $item->loan?->lender?->lender_name,
                'outstanding_amount' => (float) ($item->loan?->outstanding_amount ?? 0),
            ],
        ];
    }

    private function effectiveObligationStatus(LoanObligation $item): string
    {
        if ($item->status === 'paid') {
            return 'paid';
        }

        if ($item->status === 'snoozed' && $item->snoozed_until && $item->snoozed_until->isFuture()) {
            return 'snoozed';
        }

        $date = $item->due_date?->toDateString();

        if (!$date) {
            return $item->status;
        }

        if ($date < now()->toDateString()) {
            return 'overdue';
        }

        if ($date === now()->toDateString()) {
            return 'today';
        }

        return 'upcoming';
    }

    private function applyLoanFilters($query, Request $request): void
    {
        if ($request->filled('entity_id')) {
            $query->where('entity_id', (int) $request->entity_id);
        }

        if ($request->filled('type')) {
            $query->where(function ($q) use ($request) {
                $q->where('loan_type', $request->type)
                    ->orWhereHas('type', fn ($type) => $type->where('type_code', $request->type));
            });
        }

        if ($request->filled('type_id')) {
            $query->where('loan_type_id', (int) $request->type_id);
        }

        if ($request->filled('lender_id')) {
            $query->where('lender_id', (int) $request->lender_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $term = trim($request->search);

            $query->where(function ($q) use ($term) {
                $q->where('account_no', 'like', "%{$term}%")
                    ->orWhere('title', 'like', "%{$term}%")
                    ->orWhereHas('lender', fn ($lender) =>
                        $lender->where('lender_name', 'like', "%{$term}%")
                    );
            });
        }
    }

    private function applyCalendarFilters($query, Request $request): void
    {
        if ($request->filled('entity_id')) {
            $query->whereHas(
                'loan',
                fn ($loan) => $loan->where('entity_id', (int) $request->entity_id)
            );
        }

        if ($request->filled('type_id')) {
            $query->whereHas(
                'loan',
                fn ($loan) => $loan->where('loan_type_id', (int) $request->type_id)
            );
        }

        if ($request->filled('type')) {
            $query->whereHas('loan', function ($loan) use ($request) {
                $loan->where('loan_type', $request->type)
                    ->orWhereHas('type', fn ($type) => $type->where('type_code', $request->type));
            });
        }

        if ($request->filled('lender_id')) {
            $query->whereHas(
                'loan',
                fn ($loan) => $loan->where('lender_id', (int) $request->lender_id)
            );
        }

        if ($request->filled('status')) {
            $status = $request->status;

            if ($status === 'upcoming') {
                $query->whereIn('status', ['pending', 'partial'])
                    ->whereDate('due_date', '>', now()->toDateString());
            } elseif ($status === 'today') {
                $query->whereDate('due_date', now()->toDateString());
            } elseif ($status === 'overdue') {
                $query->whereIn('status', ['pending', 'partial', 'overdue'])
                    ->whereDate('due_date', '<', now()->toDateString());
            } elseif ($status === 'paid') {
                $query->where('status', 'paid');
            } else {
                $query->where('status', $status);
            }
        }
    }

    private function applyEntityScope($query, Request $request): void
    {
        if ($request->filled('entity_id')) {
            $query->where('entity_id', (int) $request->entity_id);
        }

        $user = auth()->user();

        if ($user && method_exists($user, 'loanEntityIds')) {
            $ids = array_map('intval', $user->loanEntityIds());

            if ($ids) {
                $query->whereIn('entity_id', $ids);
            } else {
                $query->whereRaw('1 = 0');
            }
        }
    }

    private function applyEntityScopeToObligations($query, Request $request): void
    {
        $user = auth()->user();

        if ($request->filled('entity_id')) {
            $query->whereHas(
                'loan',
                fn ($loan) => $loan->where('entity_id', (int) $request->entity_id)
            );
        }

        if ($user && method_exists($user, 'loanEntityIds')) {
            $ids = array_map('intval', $user->loanEntityIds());

            if ($ids) {
                $query->whereHas(
                    'loan',
                    fn ($loan) => $loan->whereIn('entity_id', $ids)
                );
            } else {
                $query->whereRaw('1 = 0');
            }
        }
    }

    private function assertLoanAccess(Loan $loan): void
    {
        $this->applyEntityAccessOrAbort($loan->entity_id);
    }

    private function assertObligationAccess(LoanObligation $obligation): void
    {
        $obligation->loadMissing('loan');

        abort_if(!$obligation->loan, 404);

        $this->assertLoanAccess($obligation->loan);
    }

    private function applyEntityAccessOrAbort(?int $entityId): void
    {
        $user = auth()->user();

        if (!$user) {
            abort(401);
        }

        if (method_exists($user, 'loanEntityIds')) {
            $allowed = array_map('intval', $user->loanEntityIds());

            abort_unless(
                in_array((int) $entityId, $allowed, true),
                403,
                'You are not authorized for this entity.'
            );
        }
    }

    private function assertPermission(string $permission): void
    {
        $user = auth()->user();

        if (!$user) {
            abort(401);
        }

        /*
         * Integrate with the ERP's real permission service if available.
         * Supports both Laravel Gate/Spatie-style can() and a custom hasPermission() hook.
         */
        // if (method_exists($user, 'hasPermission')) {
        //     abort_unless(
        //         (bool) $user->hasPermission($permission),
        //         403,
        //         'You do not have permission to perform this action.'
        //     );

        //     return;
        // }

        if (method_exists($user, 'can') && app()->bound('gate')) {
            /*
             * Only enforce an explicit denial when the application's Gate
             * actually has a definition for this ability. This avoids making
             * the module unusable in an ERP that uses another RBAC layer.
             */
            try {
                $abilities = app('gate')->abilities();

                if (isset($abilities[$permission])) {
                    abort_unless(
                        $user->can($permission),
                        403,
                        'You do not have permission to perform this action.'
                    );
                }
            } catch (\Throwable $e) {
                Log::debug('Loan permission hook skipped.', [
                    'permission' => $permission,
                    'message' => $e->getMessage(),
                ]);
            }
        }
    }

    private function currentUserId(): int
    {
        return (int) (
            auth()->user()->user_id
            ?? auth()->id()
            ?? 0
        );
    }

    private function audit(
        Loan $loan,
        string $action,
        string $summary,
        ?array $before = null,
        ?array $after = null
    ): void {
        LoanAuditLog::create([
            'loan_id' => $loan->id,
            'entity_type' => 'loan',
            'entity_id' => $loan->id,
            'action' => $action,
            'summary' => $summary,
            'before_json' => $before,
            'after_json' => $after,
            'actor_user_id' => $this->currentUserId(),
            'actor_name' => auth()->user()?->name,
            'actor_role' => auth()->user()?->role_name,
            'ip_address' => request()->ip(),
            'user_agent' => mb_substr(
                (string) request()->userAgent(),
                0,
                500
            ),
        ]);
    }
}
