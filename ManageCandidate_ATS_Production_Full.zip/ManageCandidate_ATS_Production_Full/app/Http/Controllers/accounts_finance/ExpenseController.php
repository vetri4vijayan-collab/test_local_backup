<?php

namespace App\Http\Controllers\accounts_finance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;

use App\Exports\ExpenseExport;

class ExpenseController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Expenditure Management
    |--------------------------------------------------------------------------
    */

    public function index(): View
    {
        $expenseCategories =  DB::table('egc_acc_expense_categories')->where('status', 0)->get();
        return view('content.accounts_finance.expenditure.expense_log',['expenseCategories'=>$expenseCategories]);
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    public function dashboard(Request $request): JsonResponse
    {
        //
    }

    public function dashboardCards(Request $request): JsonResponse
{
    $query = DB::table('egc_acc_expense_logs as el')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 'el.entity_id')
            ->leftJoin('egc_acc_expense_categories as ec','ec.sno','=','el.category_id')
            ->leftJoin('egc_acc_expense_products as ep','ep.sno','=','el.product_id')
            ->leftJoin('egc_acc_tiderc_drac as cc','cc.sno','=','el.tiderc_id')
            ->leftJoin('egc_staff as st','st.sno','=','el.created_by')
            ->where('el.status', 0);

    /*
    |--------------------------------------------------------------------------
    | Filters
    |--------------------------------------------------------------------------
    */

    

    if ($request->filled('search')) {
        $search = trim($request->input('search'));
        $query->where(function ($q) use ($search) {
            $q->where('ep.product_name','like',"%{$search}%")
            ->orWhere( 'ec.category_name','like',"%{$search}%")
            ->orWhere('c.company_name','like', "%{$search}%")
            ->orWhere('e.entity_name','like',"%{$search}%")
            ->orWhere('cc.b_name','like',"%{$search}%")
            ->orWhere('el.reference_no', 'like',"%{$search}%")
            ->orWhere('st.staff_name','like',"%{$search}%");
        });
    }

    if ($request->filled('company')) {
        $query->where('el.company_id',$request->input('company'));
    }
    if ($request->filled('entity')) {
        $query->where( 'el.entity_id',$request->input('entity'));
    }
    if ($request->filled('category')) {
        $query->where('el.category_id',$request->input('category'));
    }
    if ($request->filled('product')) {
        $query->where('el.product_id',$request->input('product'));
    }
    if ($request->filled('credit_card')) {
        $query->where('el.tiderc_id',$request->input('credit_card'));
    }
    if ($request->filled('date')) {
        $query->whereDate('el.date',$request->input('date'));
    }
    // return $request->filled('financial_year');
    // if ($request->filled('financial_year')) {
    //     $financialYear = $request->input('financial_year');
    //     if (preg_match( '/^(\d{4})-(\d{4})$/', $financialYear,$matches)) {
    //         $startYear = (int) $matches[1];
    //         $endYear   = (int) $matches[2];
    //         $query>whereBetween('el.date',[ $startYear . '-04-01',$endYear . '-03-31']);
    //     }
    // }

    if ($request->filled('month')) {
        $query->whereMonth('el.date', $request->input('month') );
    }
    if ($request->filled('amount')) {
        $amount = $request->input('amount');
        if (is_numeric($amount)) {
            $query->where('el.amount',$amount);
        }
    }

    if ($request->filled('reference')) {
        $reference =trim($request->input('reference'));
        $query->where('el.reference_no','like',"%{$reference}%");
    }

    
    
    if ($request->filled('status')) {
        $query->where('el.status',$request->input('status'));
    }



    /*
    |--------------------------------------------------------------------------
    | Cards
    |--------------------------------------------------------------------------
    */

    $totalExpense=(clone $query)
        ->sum('el.total_amount');

    $monthlyExpense=(clone $query)
        ->whereYear('el.date',now()->year)
        ->whereMonth('el.date',now()->month)
        ->sum('el.total_amount');

    $todayExpense=(clone $query)
        ->whereDate('el.date',today())
        ->sum('el.total_amount');

    $dailyAverage=(clone $query)
        ->avg('el.total_amount');

    return response()->json([

        'status'=>true,

        'data'=>[

            'total_expense'=>

                round($totalExpense,2),

            'monthly_expense'=>

                round($monthlyExpense,2),

            'today_expense'=>

                round($todayExpense,2),

            'daily_average'=>

                round($dailyAverage,2)

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Charts
    |--------------------------------------------------------------------------
    */

    public function monthlyChart(Request $request): JsonResponse
{

    $year=$request->year ?? now()->year;

    $rows=DB::table('egc_acc_expense_logs')

        ->selectRaw(

            'MONTH(date) month,

            SUM(total_amount) total'

        )

        ->where('status',0)

        ->whereYear('date',$year)

        ->groupByRaw('MONTH(date)')

        ->orderByRaw('MONTH(date)')

        ->get();

    $months=[

        'Jan','Feb','Mar',

        'Apr','May','Jun',

        'Jul','Aug','Sep',

        'Oct','Nov','Dec'

    ];

    $values=array_fill(0,12,0);

    foreach($rows as $row){

        $values[$row->month-1]=(double)

            $row->total;

    }

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$months,

            'values'=>$values

        ]

    ]);

}

    public function categoryChart(Request $request): JsonResponse
{

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_categories as ec',

            'ec.sno',

            '=',

            'el.category_id'

        )

        ->selectRaw(

            'ec.category_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ec.sno',

            'ec.category_name'

        )

        ->orderByDesc('total')

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('category_name'),

            'values'=>$rows->pluck('total'),

            'total'=>$rows->sum('total')

        ]

    ]);

}

    public function productChart(Request $request): JsonResponse
{

    $limit=$request->limit ?? 10;

    $rows=DB::table('egc_acc_expense_logs as el')

        ->join(

            'egc_acc_expense_products as ep',

            'ep.sno',

            '=',

            'el.product_id'

        )

        ->selectRaw(

            'ep.product_name,

            SUM(el.amount) total'

        )

        ->where('el.status',0)

        ->groupBy(

            'ep.sno',

            'ep.product_name'

        )

        ->orderByDesc('total')

        ->limit($limit)

        ->get();

    return response()->json([

        'status'=>true,

        'data'=>[

            'labels'=>$rows->pluck('product_name'),

            'values'=>$rows->pluck('total')

        ]

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Timeline
    |--------------------------------------------------------------------------
    */

    public function timeline(Request $request): JsonResponse
{
    $limit = $request->input('limit', 10);

    $query = DB::table('egc_acc_expense_logs as el')

        ->leftJoin('egc_acc_expense_categories as ec', 'ec.sno', '=', 'el.category_id')

        ->leftJoin('egc_acc_expense_products as ep', 'ep.sno', '=', 'el.product_id')

        ->leftJoin('egc_acc_tiderc_drac as cc', 'cc.sno', '=', 'el.tiderc_id')

        ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')

        ->leftJoin('egc_staff as st', 'st.sno', '=', 'el.created_by')

        ->where('el.status',0);

        $query->select([

    'el.sno',

    'el.date',

    'el.amount',
    'el.total_amount',

    'ep.product_name',

    'ec.category_name',

    'ec.icon',

    'c.company_name',

    'cc.b_name',

    'st.staff_name',

    'el.created_at'

]);
$rows = $query

    ->orderByDesc('el.created_at')

    ->limit($limit)

    ->get();
    $data = $rows->map(function($row){

    return [

        'id' => $row->sno,

        'product' => $row->product_name,

        'category' => $row->category_name,

        'amount' => (double)($row->total_amount ?? $row->amount),

        'company' => $row->company_name ?? 'Elysium Groups',

        'credit_card' => $row->b_name,

        'time' => Carbon::parse($row->created_at)

            ->diffForHumans(),

        'icon' => $this->timelineIcon($row->icon),

        'color' => $this->timelineColor($row->category_name)

    ];

});
return response()->json([

    'status'=>true,

    'data'=>$data

]);
}
private function timelineIcon(?string $icon): string
{
    if(!empty($icon)){

        return $icon;

    }

    return 'ti ti-wallet';

}
private function timelineColor(?string $category): string
{
    return match(strtolower($category ?? '')){

        'software' => '#B12A1F',

        'marketing' => '#F59E0B',

        'travel' => '#10B981',

        'office' => '#3B82F6',

        default => '#6B7280'

    };
}

    /*
    |--------------------------------------------------------------------------
    | DataTable
    |--------------------------------------------------------------------------
    */

    public function datatable(Request $request)
    {
        $query = DB::table('egc_acc_expense_logs as el')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'el.company_id')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 'el.entity_id')
            ->leftJoin('egc_acc_expense_categories as ec','ec.sno','=','el.category_id')
            ->leftJoin('egc_acc_expense_products as ep','ep.sno','=','el.product_id')
            ->leftJoin('egc_acc_tiderc_drac as cc','cc.sno','=','el.tiderc_id')
            ->leftJoin('egc_staff as st','st.sno','=','el.created_by')
            ->where('el.status', 0);

            if ($request->filled('search')) {
                $search = trim($request->input('search'));
                $query->where(function ($q) use ($search) {
                    $q->where('ep.product_name','like',"%{$search}%")
                    ->orWhere( 'ec.category_name','like',"%{$search}%")
                    ->orWhere('c.company_name','like', "%{$search}%")
                    ->orWhere('e.entity_name','like',"%{$search}%")
                    ->orWhere('cc.b_name','like',"%{$search}%")
                    ->orWhere('el.reference_no', 'like',"%{$search}%")
                    ->orWhere('st.staff_name','like',"%{$search}%");
                });
            }

            if ($request->filled('company')) {
                $query->where('el.company_id',$request->input('company'));
            }
            if ($request->filled('entity')) {
                $query->where( 'el.entity_id',$request->input('entity'));
            }
            if ($request->filled('category')) {
                $query->where('el.category_id',$request->input('category'));
            }
            if ($request->filled('product')) {
                $query->where('el.product_id',$request->input('product'));
            }
            if ($request->filled('credit_card')) {
                $query->where('el.tiderc_id',$request->input('credit_card'));
            }
            if ($request->filled('date')) {
                $query->whereDate('el.date',$request->input('date'));
            }
            // return $request->filled('financial_year');
            // if ($request->filled('financial_year')) {
            //     $financialYear = $request->input('financial_year');
            //     if (preg_match( '/^(\d{4})-(\d{4})$/', $financialYear,$matches)) {
            //         $startYear = (int) $matches[1];
            //         $endYear   = (int) $matches[2];
            //         $query>whereBetween('el.date',[ $startYear . '-04-01',$endYear . '-03-31']);
            //     }
            // }
      
            if ($request->filled('month')) {
                $query->whereMonth('el.date', $request->input('month') );
            }
            if ($request->filled('amount')) {
                $amount = $request->input('amount');
                if (is_numeric($amount)) {
                    $query->where('el.amount',$amount);
                }
            }

            if ($request->filled('reference')) {
                $reference =trim($request->input('reference'));
                $query->where('el.reference_no','like',"%{$reference}%");
            }

          
           
            if ($request->filled('status')) {
                $query->where('el.status',$request->input('status'));
            }

            $total = (clone $query)->count();

            $page = max(1, (int) $request->input('page', 1));

            $perPage = (int) $request->input( 'per_page',25);

        if (!in_array($perPage,[10, 25, 50, 100,500], true)) {
            $perPage = 25;
        }

        $offset =($page - 1) * $perPage;

        $expenses = $query
            ->select([
                'el.sno as id',
                'el.date as expense_date',
                'el.reference_no',
                'el.amount',
                'el.amount',
                'el.gst_amount',

                'el.other_transaction_fee',
                'el.fcy_conversion_fee',
                'el.sgst',
                'el.cgst',

                'el.is_gst',
                'el.total_amount',

                'el.expense_frequency',
                'el.next_payment_date',
                'el.custom_start_date',

                'el.custom_end_date',

                'c.company_name',
                'c.company_short_name',
                'c.company_base_color',

                'e.entity_name',
                'e.entity_short_name',
                'e.entity_base_color',

                'ec.category_name',
                'ec.icon',

                'ep.product_name',
                'ep.product_code',

                'cc.b_name as credit_card',
                'cc.rd_prt1',
                'cc.rd_prt2',
                'cc.rd_prt3',
                'cc.rd_prt4',
                'cc.rd_prt5',

                'st.staff_name'
            ])
            ->orderBy('el.date','desc')
            ->orderBy('el.sno','desc')
            ->skip($offset)
            ->take($perPage)
            ->get();

        
   

        $data = $expenses->map(
            function ($row) {

                $companyName =
                    $row->company_name ?? 'Elysium Groups';

                $companyShort =
                    $row->entity_short_name
                    ?: 'EGC';
                $companyBaseColor =
                    $row->company_base_color
                    ?: '#B12A1F';
                $entityBaseColor =
                    $row->entity_base_color
                    ?: '#B12A1F';


                $staffName =
                    $row->staff_name ?? '';


                return [

                    'id' => (int) $row->id,

                    'expense_date' =>
                        $row->expense_date,

                    'company' =>
                        $companyName,

                    'company_short' =>
                        strtoupper($companyShort,),

                    'company_code' => '',
                    'company_base_color' => $companyBaseColor,
                    'entity_base_color' => $entityBaseColor,

                    'entity' =>
                        $row->entity_name ?? '',

                    'category' =>
                        $row->category_name ?? '',

                    'category_icon' =>
                        $row->icon ?? '',

                    'category_color' =>
                        '#B12A1F',

                    'product' =>
                        $row->product_name ?? '',

                    'product_code' =>
                        $row->product_code ?? '',

                    'credit_card' =>
                        $row->credit_card ?? '',

                    'card_last_four' =>
                        $this->getCreditCardLastFour($row),

                    'reference' =>
                        $row->reference_no ?? '',

                    'amount' => (float) ($row->amount ?? 0),
                    'is_gst' =>  $row->is_gst ,
                    'gst_amount' => (float) ($row->gst_amount ?? 0),
                    'total_amount' => (float) ($row->total_amount ?? 0),

                    'other_transaction_fee' => (float) ($row->other_transaction_fee ?? 0),
                    'fcy_conversion_fee' => (float) ($row->fcy_conversion_fee ?? 0),
                    'sgst' => (float) ($row->sgst ?? 0),
                    'cgst' => (float) ($row->cgst ?? 0),

                    'frequency' =>
                        $this->formatExpenseFrequency(
                            $row->expense_frequency ?? 'one_time'
                        ),

                    'frequency_key' =>
                        $row->expense_frequency ?? 'one_time',

                    'next_payment_date' =>
                        $row->next_payment_date,

                    'custom_start_date' =>
                        $row->custom_start_date,

                    'custom_end_date' =>
                        $row->custom_end_date,

                    'created_by' =>
                        $staffName,

                    'created_initial' =>
                        $staffName
                            ? strtoupper(
                                substr(
                                    $staffName,
                                    0,
                                    1
                                )
                            )
                            : ''
                ];

            }
        )->values();


        /*
        |--------------------------------------------------------------------------
        | Custom table response
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'data' =>
                $data,

            'total' =>
                $total,

            'page' =>
                $page,

            'per_page' =>
                $perPage,

            'total_pages' =>
                $perPage > 0
                    ? (int) ceil(
                        $total / $perPage
                    )
                    : 1

        ]);
    }

    private function formatExpenseFrequency(?string $frequency): string
    {
        return match ($frequency) {

            'Daily','daily' => 'Daily',
            'Weekly' =>'Weekly',
            'Monthly','monthly' =>'Monthly',
            'Quarterly','quarterly' =>'Quarterly',
            'Half Yearly','half yearly' => 'Half Yearly',
            'Life Time','life time' => 'Life Time',
            'Yearly','yearly' => 'Yearly',
            'Custom' =>'Custom Schedule',

            default => 'One Time',
        };
    }

    private function getCreditCardLastFour($row)
    {
        if (
            isset($row->rd_prt4) &&
            $row->rd_prt4 !== null &&
            $row->rd_prt4 !== ''
        ) {

            return str_pad(
                (string) $row->rd_prt4,
                4,
                '0',
                STR_PAD_LEFT
            );

        }

        return '';
    }

    /*
    |--------------------------------------------------------------------------
    | CRUD
    |--------------------------------------------------------------------------
    */

//     public function store(Request $request): JsonResponse
// {
//     $validator = Validator::make(
//         $request->all(),
//         [
//             'company_id' => [
//                 'required',
//                 'integer',
//             ],

//             'entity_id' => [
//                 'nullable',
//                 'integer',
//             ],

//             'tiderc_id' => [
//                 'required',
//                 'integer',
//             ],

//             'date' => [
//                 'required',
//                 'date',
//             ],

//             'category_id' => [
//                 'required',
//                 'integer',
//             ],

//             'product_id' => [
//                 'required',
//                 'integer',
//             ],

//             'reference_no' => [
//                 'required',
//                 'string',
//                 'max:250',
//             ],

//         ],
//         [
//             'company_id.required' =>
//                 'Please select a company.',

//             'entity_id.required' =>
//                 'Please select an entity.',

//             'tiderc_id.required' =>
//                 'Please select a credit card.',

//             'date.required' =>
//                 'Please select the expense date.',

//             'category_id.required' =>
//                 'Please select an expense category.',

//             'product_id.required' =>
//                 'Please select an expense product.',

//             'reference_no.required' =>
//                 'Transaction name is required.',

//             'amount.required' =>
//                 'Expense amount is required.',

//             'amount.numeric' =>
//                 'Expense amount must be a valid number.',

//             'amount.min' =>
//                 'Expense amount must be greater than zero.',

//             'expense_frequency.required' =>
//                 'Please select an expense frequency.',

//             'custom_start_date.required_if' =>
//                 'Custom start date is required.',

//             'custom_end_date.required_if' =>
//                 'Custom end date is required.',

//             'custom_end_date.after_or_equal' =>
//                 'Custom end date must be on or after the start date.',
//         ]
//     );

//      $validator->sometimes(
//         'entity_id',
//         ['required'],
//         function ($input) {
//             return (int) $input->company_id !== 0;
//         }
//     );

//     /*
//     |--------------------------------------------------------------------------
//     | Validate entity when supplied
//     |--------------------------------------------------------------------------
//     */

//     $validator->sometimes(
//         'entity_id',
//         ['exists:egc_entity,sno'],
//         function ($input) {
//             return !empty($input->entity_id);
//         }
//     );

//     if ($validator->fails()) {
//         return response()->json([
//             'success' => false,
//             'message' => 'Please correct the highlighted fields.',
//             'errors' => $validator->errors(),
//         ], 422);
//     }

//     DB::beginTransaction();

//     try{
//         $user_id = $request->user()->user_id;

//         $expenseDate = Carbon::parse($request->date);

//         $frequency = $request->expense_frequency ?? 'one_time';

//         $nextPaymentDate = null;

//         $customStartDate = null;
//         $customEndDate = null;

//         switch ($frequency) {

//             case 'daily':

//                 $nextPaymentDate = $expenseDate->copy()->addDay();

//                 break;


//             case 'weekly':

//                 $nextPaymentDate = $expenseDate->copy()->addWeek();

//                 break;


//             case 'monthly':

//                 $nextPaymentDate = $expenseDate->copy()->addMonth();

//                 break;


//             case 'quarterly':

//                 $nextPaymentDate = $expenseDate->copy()->addMonths(3);

//                 break;


//             case 'yearly':

//                 $nextPaymentDate = $expenseDate->copy()->addYear();

//                 break;


//             case 'custom':

//                 /*
//                 |--------------------------------------------------------------------------
//                 | Custom Payment Range
//                 |--------------------------------------------------------------------------
//                 |
//                 | Custom does NOT use interval/unit.
//                 |
//                 | Start date = first possible payment date
//                 | End date   = last allowed payment date
//                 |
//                 */

//                 if (
//                     !$request->filled('custom_start_date') ||
//                     !$request->filled('custom_end_date')
//                 ) {
//                     $nextPaymentDate = null;
//                     break;
//                 }


//                 $customStartDate = Carbon::parse(
//                     $request->custom_start_date
//                 );

//                 $customEndDate = Carbon::parse(
//                     $request->custom_end_date
//                 );


//                 /*
//                 |--------------------------------------------------------------------------
//                 | Validate date range
//                 |--------------------------------------------------------------------------
//                 */

//                 if ($customEndDate->lt($customStartDate)) {

//                     return response()->json([
//                         'success' => false,
//                         'message' => 'Custom end date cannot be before the start date.',
//                         'errors' => [
//                             'custom_end_date' => [
//                                 'Custom end date cannot be before the start date.'
//                             ],
//                         ],
//                     ], 422);
//                 }


//                 /*
//                 |--------------------------------------------------------------------------
//                 | Determine Next Payment
//                 |--------------------------------------------------------------------------
//                 |
//                 | Start date must be AFTER the expense date.
//                 |
//                 */

//                 if ($customStartDate->gt($expenseDate)) {

//                     $nextPaymentDate = $customStartDate->copy();

//                 } else {

//                     /*
//                     * Start date is already reached/passed.
//                     *
//                     * Since custom has no interval/unit,
//                     * another occurrence cannot be calculated.
//                     */

//                     $nextPaymentDate = null;
//                 }


//                 /*
//                 |--------------------------------------------------------------------------
//                 | Never allow payment after custom end date
//                 |--------------------------------------------------------------------------
//                 */

//                 if (
//                     $nextPaymentDate &&
//                     $nextPaymentDate->gt($customEndDate)
//                 ) {
//                     $nextPaymentDate = null;
//                 }

//                 break;


//             case 'one_time':
//             default:

//                 $nextPaymentDate = null;

//                 break;
//         }

//         $id = DB::table('egc_acc_expense_logs')

//             ->insertGetId([

//                 'company_id'   => $request->company_id,

//                 'entity_id'    => $request->entity_id,

//                 'branch_id'    => $request->branch_id,

//                 'category_id'  => $request->category_id,

//                 'product_id'   => $request->product_id,

//                 'tiderc_id'    => $request->tiderc_id,

//                 'reference_no' =>

//                     $request->reference_no,

//                 'amount'       =>

//                     $request->amount,

//                 'remarks'      =>

//                     $request->remarks,

//                 'date'         =>

//                     $request->date,
                
//                 'next_payment_date' => $nextPaymentDate
//                     ? $nextPaymentDate->toDateString()
//                     : null,

//                 'recurring_status' => $nextPaymentDate ? 1 : 0,

//                 'expense_frequency' => $frequency,

//                 'custom_start_date' => $customStartDate
//                     ? $customStartDate->toDateString()
//                     : null,

//                 'custom_end_date' => $customEndDate
//                     ? $customEndDate->toDateString()
//                     : null,

//                 'created_by'   =>

//                     $user_id,

//                 'updated_by'   =>

//                     $user_id,

//                 'created_at'   => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

//                 'updated_at'   => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

//                 'status'       => 0

//             ]);

//         DB::commit();

//         return response()->json([

//             'status'=>true,

//             'id'=>$id,

//             'message'=>'Expense Added Successfully.'

//         ]);

//     }

//     catch(\Throwable $e){

//         DB::rollBack();

//         return response()->json([

//             'status'=>false,

//             'message'=>$e->getMessage()

//         ],500);

//     }

// }

public function store(Request $request): JsonResponse
{
    $validator = Validator::make(
        $request->all(),
        [

            /*
            |--------------------------------------------------------------------------
            | COMPANY
            |--------------------------------------------------------------------------
            */

            'company_id' => [
                'required',
                'integer',
            ],

            /*
            |--------------------------------------------------------------------------
            | ENTITY
            |--------------------------------------------------------------------------
            */

            // 'entity_id' => [
            //     'nullable',
            //     'integer',
            // ],

            /*
            |--------------------------------------------------------------------------
            | CREDIT CARD
            |--------------------------------------------------------------------------
            */

            'tiderc_id' => [
                'required',
                'integer',
            ],

            /*
            |--------------------------------------------------------------------------
            | EXPENSE DATE
            |--------------------------------------------------------------------------
            */

            'date' => [
                'required',
                'date',
            ],

            /*
            |--------------------------------------------------------------------------
            | PRODUCT
            |--------------------------------------------------------------------------
            */

            'product_id' => [
                'required',
                'integer',
                'exists:egc_acc_expense_products,sno',
            ],

            'amount' => [
                'required',
                'numeric',
                'min:0.01',
            ],

            'gst_amount' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'attachments' => [
                'nullable',
                'array',
                'max:10',
            ],

            'attachments.*' => [
                'file',
                'max:10240', // 10 MB in KB
                'mimes:jpg,jpeg,png,pdf,xls,xlsx',
            ],
            /*
            |--------------------------------------------------------------------------
            | TRANSACTION NAME
            |--------------------------------------------------------------------------
            */

            'reference_no' => [
                'required',
                'string',
                'max:250',
            ],

        ],
        [

            'company_id.required' =>
                'Please select a company.',

            

            'tiderc_id.required' =>
                'Please select a credit card.',

            'date.required' =>
                'Please select the expense date.',

            'product_id.required' =>
                'Please select an expense product.',

            'product_id.exists' =>
                'The selected expense product is no longer available.',

            'reference_no.required' =>
                'Transaction name is required.',
                'attachments.max' =>
            'Maximum 10 attachments are allowed.',

            'attachments.*.max' =>
                'Each attachment must not exceed 10 MB.',

            'attachments.*.mimes' =>
                'Allowed files: JPG, JPEG, PNG, PDF, XLS and XLSX.',
        ]
    );


    /*
    |--------------------------------------------------------------------------
    | ENTITY REQUIRED WHEN COMPANY IS NOT 0
    |--------------------------------------------------------------------------
    */

    // $validator->sometimes(
    //     'entity_id',
    //     ['required'],
    //     function ($input) {

    //         return (int) $input->company_id !== 0;

    //     }
    // );


    /*
    |--------------------------------------------------------------------------
    | ENTITY EXISTS
    |--------------------------------------------------------------------------
    */

    // $validator->sometimes(
    //     'entity_id',
    //     ['exists:egc_entity,sno'],
    //     function ($input) {

    //         return !empty($input->entity_id);

    //     }
    // );


    /*
    |--------------------------------------------------------------------------
    | VALIDATION RESPONSE
    |--------------------------------------------------------------------------
    */

    if ($validator->fails()) {

        return response()->json([

            'success' => false,

            'message' =>
                'Please correct the highlighted fields.',

            'errors' =>
                $validator->errors(),

        ], 422);

    }


    DB::beginTransaction();
    $uploadedPaths = [];


    try {

        /*
        |--------------------------------------------------------------------------
        | USER
        |--------------------------------------------------------------------------
        */

        $userId = $request->user()->user_id;


    

        $product = DB::table(
            'egc_acc_expense_products'
        )
        ->where('sno', $request->product_id)
        ->where('status', 0)
        ->first();


        /*
        |--------------------------------------------------------------------------
        | PRODUCT NOT AVAILABLE
        |--------------------------------------------------------------------------
        */

        if (!$product) {

            DB::rollBack();

            return response()->json([

                'success' => false,

                'message' =>
                    'The selected expense product is inactive or no longer available.',

                'errors' => [

                    'product_id' => [

                        'Please select an active expense product.'

                    ],

                ],

            ], 422);

        }


        /*
        |--------------------------------------------------------------------------
        | PRODUCT CATEGORY
        |--------------------------------------------------------------------------
        |
        | Do NOT trust category_id from request.
        | Product is the source of truth.
        |
        |--------------------------------------------------------------------------
        */

        $categoryId = $product->category_id;


        /*
        |--------------------------------------------------------------------------
        | PRODUCT CURRENCY
        |--------------------------------------------------------------------------
        */

        $currencyType =
            strtoupper(
                trim(
                    $product->currency_type ?? 'INR'
                )
            );


        $isGstApplicable =  (int) ($product->is_gst_applicable ?? 0) === 1;

            $gstAmount = 0;
            $sgstAmount = 0;
            $cgstAmount = 0;
            $igstAmount = 0;

            if ($isGstApplicable) {
                $sgstAmount = (float) $request->input('gst_amount',0);
                $cgstAmount = (float) $request->input('cgst_amount',0);
                $igstAmount = (float) $request->input('igst_amount',0);

                $gstAmount = $sgstAmount + $cgstAmount +$igstAmount;

                if ($gstAmount < 0) {
                    DB::rollBack();

                    return response()->json([
                        'success' => false,
                        'message' => 'Invalid GST amount.',
                        'errors' => [
                            'gst_amount' => [
                                'GST amount cannot be negative.'
                            ]
                        ],
                    ], 422);
                }
            }
        $fcy_conversion_fee = $currencyType === 'USD' ? (float) $request->input('fcy_conversion_fee',0) : 0;
        $other_transaction_fee = (float) $request->input('other_transaction_fee',0);
        $currencyAmount = (float) ($product->default_amount ?? 0);
        $expenseAmount = (float) $request->input('amount', 0);

        if ($expenseAmount <= 0) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Expense amount must be greater than zero.',
                'errors' => [
                    'amount' => [
                        'Please enter the expense amount in INR.'
                    ]
                ],
            ], 422);
        }

        

        /* EXPENSE DATE*/

        $expenseDate = Carbon::parse( $request->date );

        /*PRODUCT FREQUENCY */

        $frequency =
            strtolower(
                trim($product->frequency_type ?? 'one_time')
            );

            

        /*RECURRING */

        $isRecurring =  (int) ($product->is_recurring ?? 0) === 1;
        /* NEXT PAYMENT */

        $nextPaymentDate = null;


        $customStartDate = null;

        $customEndDate = null;

        $total_amount_inr =$expenseAmount + $gstAmount + $fcy_conversion_fee + $other_transaction_fee;


        

        $id = DB::table(
            'egc_acc_expense_logs'
        )->insertGetId([

            /*
            |--------------------------------------------------------------------------
            | EXPENSE INFORMATION
            |--------------------------------------------------------------------------
            */

            'company_id' =>
                $request->company_id,

            'entity_id' =>
                $request->entity_id,

            'branch_id' =>
                $request->branch_id,

            'category_id' =>
                $categoryId,

            'product_id' =>
                $product->sno,

            'tiderc_id' =>
                $request->tiderc_id,

            'date' =>
                $expenseDate->toDateString(),


            /*
            |--------------------------------------------------------------------------
            | AMOUNT
            |--------------------------------------------------------------------------
            */

            'amount' =>
                $expenseAmount,


            /*
            |--------------------------------------------------------------------------
            | TRANSACTION
            |--------------------------------------------------------------------------
            */

            'reference_no' =>
                trim(
                    $request->reference_no
                ),


            /*
            |--------------------------------------------------------------------------
            | PRODUCT DETAILS
            |--------------------------------------------------------------------------
            */

            'remarks' =>
                $request->remarks,

            'email' =>
                $product->email_id,

            'mobile_no' =>
                $product->mobile_no,

            'reference_link' =>
                $product->website,


            /*
            |--------------------------------------------------------------------------
            | CURRENCY
            |--------------------------------------------------------------------------
            */

            'currency_type' =>
                $currencyType,

            'currency_amount' =>
                $currencyAmount,

            
            'is_gst' => $isGstApplicable ? 1 : 0,
            'recurring_status' => $product->is_recurring ? 1 : 0,
            'fcy_conversion_fee' => $fcy_conversion_fee,
            'sgst' => $sgstAmount,
            'cgst' => $cgstAmount,
            'igst' => $igstAmount,
            'other_transaction_fee' => $other_transaction_fee,
            'gst_amount' => $gstAmount,
            'total_amount' => $total_amount_inr,


            /*
            |--------------------------------------------------------------------------
            | RECURRING
            |--------------------------------------------------------------------------
            */
            'expense_frequency' =>  $frequency,
            'created_by' =>$userId,
            'updated_by' => $userId,
            'created_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            'updated_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            'status' =>  0,

             

        ]);

        $expense_log_id =  $id ;

        $uploadedAttachments = [];

        if ($request->hasFile('attachments')) {

            $files = $request->file('attachments');

            if (!is_array($files)) {
                $files = [$files];
            }

            $directory =  public_path('expenses/' . Carbon::now('Asia/Kolkata')->format('Y/m') );

            /* Create directory */
            if (!is_dir($directory)) {
                if (!mkdir($directory, 0755, true) &&
                    !is_dir($directory)) {
                    throw new \RuntimeException('Unable to create expense attachment directory.');
                }
            }

            foreach ($files as $file) {

                /* Validate uploaded temporary file  */
                if (!$file instanceof \Illuminate\Http\UploadedFile) {
                    throw new \RuntimeException(
                        'Invalid attachment upload.'
                    );
                }

                if (!$file->isValid()) {
                    throw new \RuntimeException('Attachment upload failed: ' .$file->getErrorMessage());
                }

                /*Extension */

                $extension = strtolower($file->getClientOriginalExtension() );
                $allowedExtensions = [
                    'jpg',
                    'jpeg',
                    'png',
                    'pdf',
                    'xls',
                    'xlsx',
                ];

                if (!in_array( $extension, $allowedExtensions, true)) {
                    throw new \RuntimeException('Unsupported attachment format.');
                }

                /*Unique production filename */
                $uniqueName ='expense_' . $id .'_' . Str::lower(Str::random(24)) .'.' . $extension;

                /*Final absolute path */
                $destination = $directory . DIRECTORY_SEPARATOR . $uniqueName;

                /* Move PHP temporary upload */
                $originalName = $file->getClientOriginalName();
                $mime = $file->getMimeType();
                $size = $file->getSize();
                $relativePath =  'expenses/' . Carbon::now('Asia/Kolkata')->format('Y/m') .'/' . $uniqueName;
                $tmpPath = $file->getRealPath();

                if (!$tmpPath || !is_file($tmpPath) || !is_readable($tmpPath)) {
                    throw new \RuntimeException('Uploaded temporary file is not readable: ' . ($tmpPath ?: 'unknown') );
                }


                if (!$file->move($directory,$uniqueName )) {
                    throw new \RuntimeException( 'Unable to save attachment.');
                }

                /* Keep path for rollback */
                $uploadedPaths[] = $destination;

                /* Save metadata */
                $uploadedAttachments[] = [
                    'name' => $uniqueName,
                    'path' => $relativePath,
                    'original_name' => $originalName,
                    'mime' => $mime,
                    'size' => $size,
                ];
            }
        }


        DB::table('egc_acc_expense_logs')
            ->where('sno', $expense_log_id)
            ->update([
                'attachments' =>
                    !empty($uploadedAttachments)
                        ? json_encode(
                            $uploadedAttachments,
                            JSON_UNESCAPED_SLASHES
                        )
                        : null,
            ]);

        if ((int) $product->is_recurring === 1) {

            $recurring = DB::table('egc_acc_recurring')
                ->where('product_id', $product->sno)
                ->where('status', 0)
                ->lockForUpdate()
                ->first();

            if ($recurring) {

                $currentLog = DB::table('egc_acc_recurring_log')
                    ->where('recurring_id', $recurring->sno)
                    ->where('status', 0)
                    ->orderBy('date')
                    ->lockForUpdate()
                    ->first();

                if ($currentLog) {

                    /*
                    * 1. Mark current occurrence paid
                    */
                    DB::table('egc_acc_recurring_log')
                        ->where('sno', $currentLog->sno)
                        ->update([
                            'paid_date' => $expenseDate->toDateString(),
                            'expense_log_id' => $expense_log_id,

                            'amount' => $expenseAmount,
                            'currency_type' => $currencyType,
                            'currency_amount' => $currencyAmount,

                            'is_gst' => $isGstApplicable ? 1 : 0,
                            'fcy_conversion_fee' => $fcy_conversion_fee,
                            'sgst' => $sgstAmount,
                            'cgst' => $cgstAmount,
                            'igst' => $igstAmount,
                            'other_transaction_fee' => $other_transaction_fee,
                            'gst_amount' => $gstAmount,
                            'total_amount' => $total_amount_inr,

                            'updated_by' => $userId,
                            'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

                            'status' => 1,
                        ]);

                    /*
                    * 2. Calculate next payment date
                    */
                    $nextDate = $this->nextRecurringDate(
                        $product->frequency_type,
                        Carbon::parse($currentLog->date)
                    );

                    if ($nextDate) {

                        /*
                        * 3. Update recurring master
                        */
                        DB::table('egc_acc_recurring')
                            ->where('sno', $recurring->sno)
                            ->update([
                                'last_paid_date' => $expenseDate->toDateString(),
                                'next_pay_date' => $nextDate->toDateString(),

                                'amount' => $expenseAmount,
                                'currency_type' => $currencyType,
                                'currency_amount' => $currencyAmount,

                                'is_gst' => $isGstApplicable ? 1 : 0,
                                'fcy_conversion_fee' => $fcy_conversion_fee,
                                'sgst' => $sgstAmount,
                                'cgst' => $cgstAmount,
                                'igst' => $igstAmount,
                                'other_transaction_fee' => $other_transaction_fee,
                                'gst_amount' => $gstAmount,
                                'total_amount' => $total_amount_inr,

                                'updated_by' => $userId,
                                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                            ]);

                        /*
                        * 4. Create next occurrence
                        */
                        DB::table('egc_acc_recurring_log')->insert([
                            'recurring_id' => $recurring->sno,

                            'category_id' => $product->category_id,
                            'product_id' => $product->sno,

                            'date' => $nextDate->toDateString(),
                            'paid_date' => null,

                            'amount' => $expenseAmount,
                            'currency_type' => $currencyType,
                            'currency_amount' => $currencyAmount,

                            'is_gst' => $isGstApplicable ? 1 : 0,

                            'fcy_conversion_fee' => 0,
                            'sgst' => 0,
                            'cgst' => 0,
                            'other_transaction_fee' => 0,

                            'credit_amount' => 0,
                            'gst_amount' => 0,
                            'total_amount' => $total_amount_inr,

                            'created_by' => $userId,
                            'updated_by' => $userId,

                            'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                            'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

                            'status' => 0,
                        ]);

                         DB::table('egc_acc_expense_logs')
                            ->where('sno', $expense_log_id)
                            ->update([
                                'next_payment_date' =>$nextDate->toDateString() ?? NULL ,
                            ]);
                    }else{
                         DB::table('egc_acc_recurring')
                            ->where('sno', $recurring->sno)
                            ->update([
                                'last_paid_date' => $expenseDate->toDateString(),
                                'amount' => $expenseAmount,
                                'currency_type' => $currencyType,
                                'currency_amount' => $currencyAmount,
                                'is_gst' => $isGstApplicable ? 1 : 0,
                                'fcy_conversion_fee' => $fcy_conversion_fee,
                                'sgst' => $sgstAmount,
                                'cgst' => $cgstAmount,
                                'igst' => $igstAmount,
                                'other_transaction_fee' => $other_transaction_fee,
                                'gst_amount' => $gstAmount,
                                'total_amount' => $total_amount_inr,
                                'updated_by' => $userId,
                                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                            ]);
                    }
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | COMMIT
        |--------------------------------------------------------------------------
        */

        DB::commit();


        /*
        |--------------------------------------------------------------------------
        | SUCCESS
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'success' => true,

            'status' => true,

            'id' => $id,

            'message' =>
                'Expense Added Successfully.',

        ]);


    } catch (\Throwable $e) {

        DB::rollBack();

        foreach ($uploadedPaths as $path) {
            try {
                if (is_file($path)) {
                    @unlink($path);
                }
            } catch (\Throwable $cleanupException) {
                // Do not hide original exception.
            }
        }




        return response()->json([

            'success' => false,

            'status' => false,

            'message' =>
                'Unable to save the expense. Please try again.',
            
            "err" => $e->getMessage(),

        ], 500);

    }
}

    public function show(int $expense): JsonRespons
    {
        return $this->edit($expense);
    }

   public function edit(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->first();

    if(!$expense){

        return response()->json([

            'status'=>false,

            'message'=>'Expense Not Found.'

        ],404);

    }

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    public function update(
    Request $request,
    int $expense
): JsonResponse
{

    $validator = Validator::make($request->all(),[

        'company_id'=>'required',

        'entity_id'=>'required',

        'category_id'=>'required',

        'product_id'=>'required',

        'tiderc_id'=>'required',

        'amount'=>'required|numeric',

        'date'=>'required'

    ]);

    if($validator->fails()){

        return response()->json([

            'status'=>false,

            'errors'=>$validator->errors()

        ],422);

    }

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'company_id'=>$request->company_id,

            'entity_id'=>$request->entity_id,

            'branch_id'=>$request->branch_id,

            'category_id'=>$request->category_id,

            'product_id'=>$request->product_id,

            'tiderc_id'=>$request->tiderc_id,

            'reference_no'=>$request->reference_no,

            'amount'=>$request->amount,

            'remarks'=>$request->remarks,

            'date'=>$request->date,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Updated Successfully.'

    ]);

}

    public function destroy(int $expense): JsonResponse
{

    DB::table('egc_acc_expense_logs')

        ->where('sno',$expense)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Expense Deleted Successfully.'

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Duplicate
    |--------------------------------------------------------------------------
    */

    public function duplicate(int $expense): JsonResponse
{
    $expenseData = DB::table('egc_acc_expense_logs')
        ->where('sno', $expense)
        ->where('status', 0)
        ->first();

    if (!$expenseData) {

        return response()->json([
            'status' => false,
            'message' => 'Expense not found.'
        ], 404);

    }

    $newExpense = (array) $expenseData;

    unset($newExpense['sno']);

    $newExpense['reference_no'] = null;

    $newExpense['created_by'] = session('staff_id');

    $newExpense['updated_by'] = session('staff_id');

    $newExpense['created_at'] = now();

    $newExpense['updated_at'] = now();

    $id = DB::table('egc_acc_expense_logs')->insertGetId($newExpense);

    return response()->json([

        'status' => true,

        'id' => $id,

        'message' => 'Expense duplicated successfully.'

    ]);
}

    /*
    |--------------------------------------------------------------------------
    | History
    |--------------------------------------------------------------------------
    */

   public function history(int $expense): JsonResponse
{
    $expense = DB::table('egc_acc_expense_logs')

        ->leftJoin('egc_staff','egc_staff.sno','=','egc_acc_expense_logs.created_by')

        ->where('egc_acc_expense_logs.sno',$expense)

        ->select(

            'egc_acc_expense_logs.created_at',

            'egc_acc_expense_logs.updated_at',

            'egc_staff.staff_name'

        )

        ->first();

    return response()->json([

        'status'=>true,

        'data'=>$expense

    ]);

}

    /*
    |--------------------------------------------------------------------------
    | Bulk
    |--------------------------------------------------------------------------
    */

    public function bulkDelete(Request $request): JsonResponse
{

    $ids = $request->ids;

    if(empty($ids)){

        return response()->json([

            'status'=>false,

            'message'=>'No expense selected.'

        ]);

    }

    DB::table('egc_acc_expense_logs')

        ->whereIn('sno',$ids)

        ->update([

            'status'=>2,

            'updated_by'=>session('staff_id'),

            'updated_at'=>now()

        ]);

    return response()->json([

        'status'=>true,

        'message'=>'Selected expenses deleted successfully.'

    ]);

}

    public function bulkExport(Request $request)
{

    $ids = explode(',',$request->ids);

    return Excel::download(

        new ExpenseExport($ids),

        'Expense.xlsx'

    );

}

    /*
    |--------------------------------------------------------------------------
    | Dropdown APIs
    |--------------------------------------------------------------------------
    */

    public function companies(): JsonResponse
{

    return response()->json([
        'status'=>true,
        'data'=>DB::table('egc_company')
            ->where('status',0)
            ->orderBy('sno')
            ->select(
                'sno',
                'company_name'
            )
            ->get()
    ]);

}

    public function entities(Request $request): JsonResponse
{

    $query=DB::table('egc_entity')

        ->where('status',0);

    if($request->company_id){

        $query->where(

            'company_id',

            $request->company_id

        );

    }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('sno')

            ->select(

                'sno',

                'entity_name'

            )

            ->get()

    ]);

}

    public function categories(): JsonResponse
{

    return response()->json([

        'status'=>true,
        'success' => true,

        'data'=>DB::table(

            'egc_acc_expense_categories'

        )

        ->where('status',0)

        ->orderBy('category_name')

        ->get()

    ]);

}

    public function products(Request $request): JsonResponse
{

    $query=DB::table('egc_acc_expense_products')
    ->join('egc_acc_expense_categories','egc_acc_expense_categories.sno','=','egc_acc_expense_products.category_id')
    ->where('egc_acc_expense_products.status',0)
    ->select('egc_acc_expense_products.*','egc_acc_expense_categories.category_name');

    if($request->category_id){
        $query->where('egc_acc_expense_products.category_id', $request->category_id);
    }

    return response()->json([

        'status'=>true,

        'data'=>$query
            ->orderBy('egc_acc_expense_products.product_name')
            ->get()

    ]);

}

    public function creditCards(Request $request): JsonResponse
{

    $query=DB::table(

        'egc_acc_tiderc_drac'

    )

    ->where('status',0);

    // if($request->company_id){

    //     $query->where(

    //         'company_id',

    //         $request->company_id

    //     );

    // }

    // if($request->entity_id){

    //     $query->where(

    //         'entity_id',

    //         $request->entity_id

    //     );

    // }

    return response()->json([

        'status'=>true,

        'data'=>$query

            ->orderBy('b_name')

            ->get()

    ]);

}


// Category 
public function categoryStore(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
            // 'category_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            // ],

            'category_name' => [
                'required',
                'string',
                'max:250',
            ],

            'icon' => [
                'required',
                'string',
                'max:200',
            ],
        ],
        [
            // 'category_code.required' => 'Category code is required.',
            'category_name.required' => 'Category name is required.',
            'icon.required' => 'Please select a category icon.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);

    }

     $categoryName = trim($request->category_name);


     $categoryCode = strtoupper($categoryName);

    // Replace anything other than letters/numbers with -
    $categoryCode = preg_replace('/[^A-Z0-9]+/', '-', $categoryCode);

    // Remove - from beginning/end
    $categoryCode = trim($categoryCode, '-');

    // Fallback in case the name contains no usable characters
    if ($categoryCode === '') {
        $categoryCode = 'CATEGORY';
    }

    /*
    |--------------------------------------------------------------------------
    | Make Code Unique
    |--------------------------------------------------------------------------
    */

    $baseCode = $categoryCode;
    $counter = 1;

    while (
        DB::table('egc_acc_expense_categories')
            ->where('category_code', $categoryCode)
            ->where('status', 0)
            ->exists()
    ) {
        $counter++;

        $categoryCode = $baseCode . '-' . $counter;
    }


    $exists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'category_code',
            $categoryCode
        )
        ->where(
            'status',
            0
        )
        ->exists();


    if ($exists) {

        return response()->json([
            'success' => false,
            'message' => 'Category code already exists.',
            'errors' => [
                'category_code' => [
                    'Category code already exists.'
                ]
            ],
        ], 422);

    }


    $id = DB::table(
        'egc_acc_expense_categories'
    )->insertGetId([

        'category_code' => $categoryCode,

        'category_name' => $categoryName,

        'icon' => $request->icon,

        'created_by' => $request->user()->user_id ?? 0,

        'updated_by' => $request->user()->user_id ?? 0,

        'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

        'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

        'status' => 0,

    ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category created successfully.',

        'data' => [
            'sno' => $id,
        ],

    ]);
}

public function categoryShow($id)
{
    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    return response()->json([

        'success' => true,

        'data' => $category,

    ]);
}

public function categoryUpdate(
    Request $request,
    $id
) {

    $validator = Validator::make(
        $request->all(),
        [
            // 'category_code' => [
            //     'required',
            //     'string',
            //     'max:200',
            // ],

            'category_name' => [
                'required',
                'string',
                'max:250',
            ],

            'icon' => [
                'required',
                'string',
                'max:200',
            ],
        ],
        [
            // 'category_code.required' => 'Category code is required.',
            'category_name.required' => 'Category name is required.',
            'icon.required' => 'Please select a category icon.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors' => $validator->errors(),
        ], 422);

    }


    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    $categoryCode = strtoupper(
        trim($request->category_code)
    );


    $categoryName = trim(
        $request->category_name
    );


    $exists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'category_code',
            $categoryCode
        )
        ->where(
            'sno',
            '!=',
            $id
        )
        ->where(
            'status',
            0
        )
        ->exists();


    if ($exists) {

        return response()->json([
            'success' => false,
            'message' => 'Category code already exists.',
            'errors' => [
                'category_code' => [
                    'Category code already exists.'
                ]
            ],
        ], 422);

    }


    DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->update([

            // 'category_code' => $categoryCode,

            'category_name' => $categoryName,

            'icon' => $request->icon,

            'updated_by' => $request->user()->user_id ?? 0,

            'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category updated successfully.',

        'data' => [
            'sno' => $id,
        ],

    ]);
}

public function categoryDestroy($id,Request $request)
{
    $category = DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->where(
            'status',
            0
        )
        ->first();


    if (!$category) {

        return response()->json([
            'success' => false,
            'message' => 'Expense category not found.',
        ], 404);

    }


    DB::table(
        'egc_acc_expense_categories'
    )
        ->where(
            'sno',
            $id
        )
        ->update([

            'status' => 2,

            'updated_by' => $request->user()->user_id ?? 0,

            'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

        ]);


    return response()->json([

        'success' => true,

        'message' => 'Expense category deleted successfully.',

    ]);
}

// expense Product

/**
 * Store Expense Product
 */
public function storeProduct(Request $request)
{
    $validator = Validator::make(
        $request->all(),
        [
        
            'product_name' => [
                'required',
                'string',
                'max:250',
            ],

            'category_id' => [
                'required',
                'integer',
                'exists:egc_acc_expense_categories,sno',
            ],

            'email_id' => [
                'nullable',
                'email',
                'max:255',
            ],

            'mobile_no' => [
                'nullable',
                'string',
                'max:30',
            ],

            'website' => [
                'nullable',
                'string',
                'max:500',
            ],

            'frequency_type' => [
                'required',
                'string',
                'max:200',
            ],

            'currency_type' => [
                'required',
                'in:INR,USD',
            ],

            'default_amount' => [
                'required',
                'numeric',
                'min:0',
            ],
            'is_gst_applicable' => [
                'nullable',
                'boolean',
            ],

            // 'amount_inr' => [
            //     'nullable',
            //     'numeric',
            //     'min:0',
            // ],

            'is_recurring' => [
                'nullable',
                'boolean',
            ],

            'billing_date' => [
                'nullable',
                'date',
            ],

            'remarks' => [
                'nullable',
                'string',
                'max:2000',
            ],

        ],
        [
          

            'product_name.required' =>
                'Product name is required.',

            'category_id.required' =>
                'Please select an expense category.',

        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors'  => $validator->errors(),
        ], 422);
    }

    // if ( $request->currency_type === 'USD' && !$request->filled('amount_inr')) {
    //     return response()->json([
    //         'success' => false,
    //         'message' => 'INR equivalent amount is required for USD products.',
    //         'errors' => [
    //             'amount_inr' => [
    //                 'INR equivalent amount is required for USD products.'
    //             ]
    //         ],
    //     ], 422);
    // }
    if ($request->boolean('is_recurring') && !$request->filled('billing_date') ) {
        return response()->json([
            'success' => false,
            'message' => 'Billing date is required for recurring products.',
            'errors' => [
                'billing_date' => [
                    'Billing date is required for recurring products.'
                ]
            ],
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Active Category
    |--------------------------------------------------------------------------
    */

    // $categoryExists = DB::table(
    //     'egc_acc_expense_categories'
    // )
    //     ->where('sno', $request->category_id)
    //     ->where('status', 0)
    //     ->exists();


    // if (!$categoryExists) {

    //     return response()->json([
    //         'success' => false,
    //         'message' => 'Selected expense category is not active.',
    //         'errors' => [
    //             'category_id' => [
    //                 'Selected expense category is not active.'
    //             ],
    //         ],
    //     ], 422);
    // }

    $categoryExists = DB::table(
        'egc_acc_expense_products'
    )
        ->where('product_name', trim($request->product_name))
        ->where('category_id',$request->category_id)
        ->where('status','!=', 2)
        ->first();


    if ($categoryExists) {

        return response()->json([
            'success' => false,
            'message' => 'Expense Product is Already Exists.',
            'errors' => 'Expense Product is Already Exists',
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Current User
    |--------------------------------------------------------------------------
    */

    $userId = $request->user()->user_id ?? 0;
    $productName =trim($request->product_name);


     $productCode = strtoupper($productName);

        $productCode = preg_replace(
            '/[^A-Z0-9]+/',
            '-',
            $productCode
        );

     
        $productCode = trim(
            $productCode,
            '-'
        );


        /*
        | Fallback if product name contains
        | no usable characters.
        */

        if ($productCode === '') {
            $productCode = 'PRODUCT';
        }

        $baseProductCode = $productCode;

        $counter = 1;


        while (
            DB::table('egc_acc_expense_products')
                ->where('product_code', $productCode)
                ->where('status', '!=', 2)
                ->exists()
        ) {

            $counter++;

            $productCode = $baseProductCode . '-' . $counter;
        }


    /*
    |--------------------------------------------------------------------------
    | Insert
    |--------------------------------------------------------------------------
    */

    $productId = DB::table('egc_acc_expense_products')->insertGetId([
        'product_code' =>$productCode,
        'product_name' => trim($request->product_name),
        'category_id' => (int) $request->category_id,
        'email_id' => $request->filled('email_id') ? trim($request->email_id) : null,
        'mobile_no' => $request->filled('mobile_no') ? trim($request->mobile_no) : null,
        'website' => $request->filled('website') ? trim($request->website) : null,
        'frequency_type' => $request->filled('frequency_type') ? trim($request->frequency_type) : null,
        'is_recurring' => $request->boolean('is_recurring') ? 1 : 0,
       'billing_date' => $request->boolean('is_recurring') && $request->filled('billing_date')
                        ? date('Y-m-d', strtotime($request->billing_date))
                        : null,
        'currency_type' => $request->currency_type,
        'default_amount' => $request->default_amount,
        'amount_inr' =>  $request->default_amount,
        'is_gst_applicable' => $request->boolean('is_gst_applicable') ? 1 : 0,
        'remarks' => $request->filled('remarks') ? trim($request->remarks) : null,
        'created_by' => $userId,
        'updated_by' =>  $userId,
        'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
        'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
        'status' => 0,
    ]);


    if ($request->boolean('is_recurring')) {

        $product = DB::table('egc_acc_expense_products')
            ->where('sno', $productId)
            ->first();

        $this->createRecurringMaster( $productId, $product, $userId );

        $recurring = DB::table('egc_acc_recurring')
            ->where('product_id', $productId)
            ->first();

        $this->createRecurringLog( $recurring, Carbon::parse($product->billing_date), $userId );

    }


    /*
    |--------------------------------------------------------------------------
    | Return Created Product
    |--------------------------------------------------------------------------
    */

    $product = DB::table('egc_acc_expense_products as p' )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.email_id',
            'p.mobile_no',
            'p.website',
            'p.frequency_type',
            'p.is_recurring',
            'p.billing_date',
            'p.is_gst_applicable',
            'p.currency_type',
            'p.remarks',
            'p.amount_inr',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $productId)
        ->first();


    return response()->json([
        'success' => true,
        'message' => 'Expense product created successfully.',
        'data' => $product,
    ]);
}
/**
 * Get Expense Product
 */
public function showProduct($id)
{
    $product = DB::table(
        'egc_acc_expense_products as p'
    )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.email_id',
            'p.mobile_no',
            'p.website',
            'p.frequency_type',
            'p.is_recurring',
            'p.billing_date',
            'p.is_gst_applicable',
            'p.currency_type',
            'p.remarks',
            'p.amount_inr',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $id)
        ->where('p.status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    return response()->json([
        'success' => true,
        'data' => $product,
    ]);
}

/**
 * Update Expense Product
 */
public function updateProduct(
    Request $request,
    $id
) {

    $product = DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->where('status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    $validator = Validator::make(
        $request->all(),
        [
        
            'product_name' => [
                'required',
                'string',
                'max:250',
            ],

            'category_id' => [
                'required',
                'integer',
                'exists:egc_acc_expense_categories,sno',
            ],
            'email_id' => [
                'nullable',
                'email',
                'max:255',
            ],

            'mobile_no' => [
                'nullable',
                'string',
                'max:30',
            ],

            'website' => [
                'nullable',
                'string',
                'max:500',
            ],

            'frequency_type' => [
                'required',
                'string',
                'max:200',
            ],

            'currency_type' => [
                'required',
                'in:INR,USD',
            ],

            'default_amount' => [
                'required',
                'numeric',
                'min:0',
            ],

            // 'amount_inr' => [
            //     'nullable',
            //     'numeric',
            //     'min:0',
            // ],

            'is_gst_applicable' => [
                'nullable',
                'boolean',
            ],
            'is_recurring' => [
                'nullable',
                'boolean',
            ],

            'billing_date' => [
                'nullable',
                'date',
            ],

            'remarks' => [
                'nullable',
                'string',
                'max:2000',
            ],

       
        ],
        [
        

            'product_name.required' =>
                'Product name is required.',

            'category_id.required' =>
                'Please select an expense category.',

            'category_id.exists' =>
                'Selected expense category is invalid.',
        ]
    );


    if ($validator->fails()) {

        return response()->json([
            'success' => false,
            'message' => 'Please correct the highlighted fields.',
            'errors'  => $validator->errors(),
        ], 422);
    }

    // if ( $request->currency_type === 'USD' && !$request->filled('amount_inr')) {
    //     return response()->json([
    //         'success' => false,
    //         'message' => 'INR equivalent amount is required for USD products.',
    //         'errors' => [
    //             'amount_inr' => [
    //                 'INR equivalent amount is required for USD products.'
    //             ]
    //         ],
    //     ], 422);
    // }
    if ($request->boolean('is_recurring') && !$request->filled('billing_date') ) {
        return response()->json([
            'success' => false,
            'message' => 'Billing date is required for recurring products.',
            'errors' => [
                'billing_date' => [
                    'Billing date is required for recurring products.'
                ]
            ],
        ], 422);
    }


    /*
    |--------------------------------------------------------------------------
    | Verify Active Category
    |--------------------------------------------------------------------------
    */

    $categoryExists = DB::table(
        'egc_acc_expense_categories'
    )
        ->where('sno', $request->category_id)
        ->where('status', 0)
        ->exists();


    if (!$categoryExists) {

        return response()->json([
            'success' => false,
            'message' => 'Selected expense category is not active.',
            'errors' => [
                'category_id' => [
                    'Selected expense category is not active.'
                ],
            ],
        ], 422);
    }


    $userId = $request->user()->user_id ?? 0;

    DB::transaction(function () use ($request, $id, $userId) {

        $product = DB::table('egc_acc_expense_products')
            ->where('sno', $id)
            ->where('status', 0)
            ->first();

        if (!$product) {
            throw new \Exception('Product not found.');
        }

        $isRecurring = $request->boolean('is_recurring') ? 1 : 0;

        DB::table('egc_acc_expense_products')
            ->where('sno', $id)
            ->update([
                'product_name' =>trim($request->product_name),
                'email_id' => $request->filled('email_id') ? trim($request->email_id) : null,
                'mobile_no' => $request->filled('mobile_no') ? trim($request->mobile_no) : null,
                'website' => $request->filled('website') ? trim($request->website) : null,

                'frequency_type' => $request->filled('frequency_type') ? trim($request->frequency_type) : null,
                'is_recurring' => $isRecurring ? 1 : 0,
                'billing_date' => $request->boolean('is_recurring') && $request->filled('billing_date')
                        ? date('Y-m-d', strtotime($request->billing_date))
                        : null,

                'currency_type' => $request->currency_type,

                'default_amount' => (float) $request->default_amount,

                'amount_inr' => (float) $request->default_amount,

                'is_gst_applicable' => $request->boolean('is_gst_applicable') ? 1 : 0,

                'remarks' =>  $request->filled('remarks') ? trim($request->remarks) : null,

                'updated_by' => $userId,
                'updated_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

                'category_id' => (int) $request->category_id,
            ]);


    

        $recurring = DB::table('egc_acc_recurring')
            ->where('product_id', $id)
            ->first();

        if (!$isRecurring) {

            if ($recurring) {
                DB::table('egc_acc_recurring')
                    ->where('sno', $recurring->sno)
                    ->update([
                        'status' => 2,
                        'updated_by' => $userId,
                        'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                    ]);

                DB::table('egc_acc_recurring_log')
                    ->where('recurring_id', $recurring->sno)
                    ->where('status', 0)
                    ->update([
                        'status' => 3,
                        'updated_by' => $userId,
                        'updated_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                    ]);
            }

            return;
        }

        // Product is recurring.
        if (!$recurring) {

            $updatedProduct = DB::table('egc_acc_expense_products')
                ->where('sno', $id)
                ->first();

            $this->createRecurringMaster(
                $id,
                $updatedProduct,
                $userId
            );

            $recurring = DB::table('egc_acc_recurring')
                ->where('product_id', $id)
                ->first();

            $this->createRecurringLog(
                $recurring,
                Carbon::parse($updatedProduct->billing_date),
                $userId
            );

            return;
        }

        // Existing recurring master.
        DB::table('egc_acc_recurring')
            ->where('sno', $recurring->sno)
            ->update([
                'category_id' => (int) $request->category_id,
                'frequency_type' => $request->frequency_type,

                'amount' => (float) $request->default_amount,
                'currency_type' => $request->currency_type,
                'currency_amount' => (float) $request->default_amount,

                'is_gst' => $request->boolean('is_gst_applicable') ? 1 : 0,

                'updated_by' => $userId,
                'updated_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                'status' => 0,
            ]);

        /*
        * IMPORTANT:
        * Do not blindly reset date/next_pay_date here.
        *
        * Existing unpaid occurrence should remain.
        */

        DB::table('egc_acc_recurring_log')
            ->where('recurring_id', $recurring->sno)
            ->where('status', 0)
            ->update([
                'category_id' => (int) $request->category_id,
                'amount' => (float) $request->default_amount,
                'currency_type' => $request->currency_type,
                'currency_amount' => (float) $request->default_amount,
                'is_gst' =>
                    $request->boolean('is_gst_applicable') ? 1 : 0,
                'updated_by' => $userId,
                'updated_at' =>Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            ]);
    });


    
    /*
    |--------------------------------------------------------------------------
    | Return Updated Product
    |--------------------------------------------------------------------------
    */

    $updatedProduct = DB::table(
        'egc_acc_expense_products as p'
    )
        ->leftJoin(
            'egc_acc_expense_categories as c',
            'c.sno',
            '=',
            'p.category_id'
        )
        ->select(
            'p.sno',
            'p.product_code',
            'p.product_name',
            'p.default_amount',
            'p.category_id',
            'c.category_name',
            'c.icon'
        )
        ->where('p.sno', $id)
        ->first();


    return response()->json([
        'success' => true,
        'message' => 'Expense product updated successfully.',
        'data' => $updatedProduct,
    ]);
}

/**
 * Deactivate Expense Product
 */
public function destroyProduct($id,Request $request)
{
    $product = DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->where('status', 0)
        ->first();


    if (!$product) {

        return response()->json([
            'success' => false,
            'message' => 'Expense product not found.',
        ], 404);
    }


    $userId = $request->user()->user_id ?? 0;


    DB::table(
        'egc_acc_expense_products'
    )
        ->where('sno', $id)
        ->update([

            'status' => 2,

            'updated_by' =>
                $userId,

            'updated_at' =>
               Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
        ]);


    return response()->json([
        'success' => true,
        'message' => 'Expense product deactivated successfully.',
    ]);
}

    public function productList(Request $request)
    {
        $products = DB::table(
            'egc_acc_expense_products as p'
        )
            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )
            ->where(
                'p.status',
                0
            )
            ->select([
                'p.sno',
                'p.product_code',
                'p.product_name',
                'p.default_amount',
                'p.category_id',

                'c.category_name',
                'c.icon',
            ])
            ->orderBy(
                'p.sno',
                'desc'
            )
            ->get();


        return response()->json([

            'success' => true,

            'data' => $products,

        ]);
    }


    private function nextRecurringDate(
        ?string $frequency,
        Carbon $date
    ): ?Carbon {
        if (!$frequency) {
            return null;
        }

        return match (strtolower(trim($frequency))) {
            'daily' => $date->copy()->addDay(),

            'weekly' => $date->copy()->addWeek(),

            'monthly' => $date->copy()->addMonthNoOverflow(),

            'quarterly' => $date->copy()->addMonthsNoOverflow(3),

            'half yearly',
            'half-yearly',
            'half_yearly' => $date->copy()->addMonthsNoOverflow(6),

            'yearly',
            'annually',
            'annual' => $date->copy()->addYearNoOverflow(),

            default => null,
        };
    }


    private function createRecurringMaster(int $productId, object $product,int $userId ): void {

        if ((int) $product->is_recurring !== 1) {
            return;
        }

        $billingDate = $product->billing_date
            ? Carbon::parse($product->billing_date)
            : Carbon::today();

        $now = Carbon::now('Asia/Kolkata');

        DB::table('egc_acc_recurring')->insert([
            'product_id' => $productId,
            'category_id' => $product->category_id,
            'frequency_type' => $product->frequency_type,

            'date' => $billingDate->toDateString(),
            'next_pay_date' => $billingDate->toDateString(),
            'last_paid_date' => null,

            'amount' => (float) $product->default_amount,
            'currency_type' => $product->currency_type,
            'currency_amount' => (float) $product->default_amount,

            'is_gst' => (int) ($product->is_gst_applicable ?? 0),
            'gst_amount' => 0,
            'total_amount' => (float) $product->default_amount,

            'status' => 0,

            'created_by' => $userId,
            'updated_by' => $userId,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    private function createRecurringLog( object $recurring, Carbon $date, int $userId): void {

        $now = Carbon::now('Asia/Kolkata');

        DB::table('egc_acc_recurring_log')->insert([
            'recurring_id' => $recurring->sno,
            'category_id' => $recurring->category_id,
            'product_id' => $recurring->product_id,

            'date' => $date->toDateString(),
            'paid_date' => null,

            'amount' => $recurring->amount,
            'currency_type' => $recurring->currency_type,
            'currency_amount' => $recurring->currency_amount,

            'is_gst' => $recurring->is_gst,
            'credit_amount' => 0,
            'gst_amount' => 0,
            'total_amount' => $recurring->total_amount,

            'created_by' => $userId,
            'updated_by' => $userId,

            'created_at' => $now,
            'updated_at' => $now,

            'status' => 0,
        ]);
    }



    public function recurringIndex(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $expenseCategories = DB::table('egc_acc_expense_categories')
        ->where('status', 0)
        ->get();

        return view('content.accounts_finance.expenditure.recurring_log',
            [
                'expenseCategories' => $expenseCategories,
                'perpage' => $perpage,
            ]
        );
    }

    // public function recurringTabCounts(Request $request)
    // {
    //     $today = Carbon::today('Asia/Kolkata');

    //     $categoryId = $request->input('category');
    //     $statusFilter = $request->input('status');
    //     $search = trim((string) $request->input('search', ''));

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Latest paid log
    //     |--------------------------------------------------------------------------
    //     */

    //     $latestPaidLog = DB::table('egc_acc_recurring_log as l')
    //         ->select([
    //             'l.recurring_id',
    //             'l.sno',
    //             'l.date',
    //             'l.paid_date',
    //         ])
    //         ->where('l.status', 1)
    //         ->whereRaw(
    //             'l.sno = (
    //                 SELECT MAX(l2.sno)
    //                 FROM egc_acc_recurring_log l2
    //                 WHERE l2.recurring_id = l.recurring_id
    //                 AND l2.status = 1
    //             )'
    //         );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Base query
    //     |--------------------------------------------------------------------------
    //     */

    //     $baseQuery = DB::table('egc_acc_recurring as r')
    //         ->join(
    //             'egc_acc_expense_products as p',
    //             'p.sno',
    //             '=',
    //             'r.product_id'
    //         )
    //         ->leftJoin(
    //             'egc_acc_expense_categories as c',
    //             'c.sno',
    //             '=',
    //             'r.category_id'
    //         )
    //         ->leftJoinSub(
    //             $latestPaidLog,
    //             'lp',
    //             function ($join) {
    //                 $join->on(
    //                     'lp.recurring_id',
    //                     '=',
    //                     'r.sno'
    //                 );
    //             }
    //         )
    //         ->where('r.status', '!=', 2);

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Category
    //     |--------------------------------------------------------------------------
    //     */

    //     if ($categoryId !== null && $categoryId !== '') {
    //         $baseQuery->where(
    //             'r.category_id',
    //             (int) $categoryId
    //         );
    //     }

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Search
    //     |--------------------------------------------------------------------------
    //     */

    //     if ($search !== '') {

    //         $baseQuery->where(function ($q) use ($search) {

    //             $q->where(
    //                 'p.product_name',
    //                 'like',
    //                 "%{$search}%"
    //             )
    //             ->orWhere(
    //                 'p.product_code',
    //                 'like',
    //                 "%{$search}%"
    //             )
    //             ->orWhere(
    //                 'c.category_name',
    //                 'like',
    //                 "%{$search}%"
    //             );
    //         });
    //     }

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Status filter
    //     |--------------------------------------------------------------------------
    //     |
    //     | Apply only global filters here.
    //     | Tab itself is NOT applied yet because we need all 5 counts.
    //     |
    //     */

    //     if ($statusFilter === 'dropped') {

    //         $baseQuery->where('r.status', 2);

    //     } elseif ($statusFilter === 'active') {

    //         $baseQuery->where('r.status', 0);

    //     } elseif ($statusFilter === 'paid') {

    //         $baseQuery->whereNotNull('r.last_paid_date');

    //     }

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Clone query for each tab
    //     |--------------------------------------------------------------------------
    //     */

    //     $countForTab = function ($fromDate, $toDate) use ($baseQuery) {

    //         $query = clone $baseQuery;

    //         $query->where(function ($q) use ($fromDate, $toDate) {

    //             /*
    //             * Future/current recurring occurrence
    //             */
    //             $q->where(function ($sub) use ($fromDate, $toDate) {

    //                 if ($fromDate) {
    //                     $sub->whereDate(
    //                         'r.next_pay_date',
    //                         '>=',
    //                         $fromDate->toDateString()
    //                     );
    //                 }

    //                 if ($toDate) {
    //                     $sub->whereDate(
    //                         'r.next_pay_date',
    //                         '<=',
    //                         $toDate->toDateString()
    //                     );
    //                 }
    //             })

    //             /*
    //             * OR paid occurrence
    //             */
    //             ->orWhere(function ($sub) use ($fromDate, $toDate) {

    //                 $sub->whereNotNull('lp.date');

    //                 if ($fromDate) {
    //                     $sub->whereDate(
    //                         'lp.date',
    //                         '>=',
    //                         $fromDate->toDateString()
    //                     );
    //                 }

    //                 if ($toDate) {
    //                     $sub->whereDate(
    //                         'lp.date',
    //                         '<=',
    //                         $toDate->toDateString()
    //                     );
    //                 }
    //             });
    //         });

    //         return $query->count('r.sno');
    //     };

    //     /*
    //     |--------------------------------------------------------------------------
    //     | 7 Days
    //     |--------------------------------------------------------------------------
    //     */

    //     $count7Days = $countForTab(
    //         null,
    //         $today->copy()->addDays(7)
    //     );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Current Month
    //     |--------------------------------------------------------------------------
    //     */

    //     $countCurrentMonth = $countForTab(
    //         $today->copy()->startOfMonth(),
    //         $today->copy()->endOfMonth()
    //     );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Next Month
    //     |--------------------------------------------------------------------------
    //     */

    //     $nextMonthStart = $today->copy()
    //         ->addMonthNoOverflow()
    //         ->startOfMonth();

    //     $countNextMonth = $countForTab(
    //         $nextMonthStart,
    //         $nextMonthStart->copy()->endOfMonth()
    //     );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Next 6 Months
    //     |--------------------------------------------------------------------------
    //     */

    //     $count6Months = $countForTab(
    //         $today->copy(),
    //         $today->copy()
    //             ->addMonthsNoOverflow(6)
    //             ->endOfDay()
    //     );

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Next Year
    //     |--------------------------------------------------------------------------
    //     */

    //     $nextYearStart = $today->copy()
    //         ->addYearNoOverflow()
    //         ->startOfYear();

    //     $countNextYear = $countForTab(
    //         $nextYearStart,
    //         $nextYearStart->copy()->endOfYear()
    //     );

    //     return response()->json([
    //         'success' => true,

    //         'counts' => [
    //             '7_days' => $count7Days,
    //             'current_month' => $countCurrentMonth,
    //             'next_month' => $countNextMonth,
    //             '6_months' => $count6Months,
    //             'next_year' => $countNextYear,
    //         ],
    //     ]);
    // }

    public function recurringTabCounts(Request $request)
    {
        $today = Carbon::today('Asia/Kolkata');

        $categoryId = $request->input('category');
        $statusFilter = trim((string) $request->input('status', ''));
        $search = trim((string) $request->input('search', ''));

        /*
        |--------------------------------------------------------------------------
        | LATEST PAID LOG
        |--------------------------------------------------------------------------
        |
        | Used only for recurring products.
        |
        */
        $latestPaidLog = DB::table('egc_acc_recurring_log as l')
            ->select([
                'l.recurring_id',
                'l.sno',
                'l.date',
                'l.paid_date',
            ])
            ->where('l.status', 1)
            ->whereRaw(
                'l.sno = (
                    SELECT MAX(l2.sno)
                    FROM egc_acc_recurring_log l2
                    WHERE l2.recurring_id = l.recurring_id
                    AND l2.status = 1
                )'
            );

       
        $latestRecurringMaster = DB::table('egc_acc_recurring')
            ->selectRaw('MAX(sno) as sno, product_id')
            ->groupBy('product_id');

   
        $baseQuery = DB::table('egc_acc_expense_products as p')

            ->leftJoinSub(
                $latestRecurringMaster,
                'latest_r',
                function ($join) {
                    $join->on(
                        'latest_r.product_id',
                        '=',
                        'p.sno'
                    );
                }
            )

            ->leftJoin(
                'egc_acc_recurring as r',
                'r.sno',
                '=',
                'latest_r.sno'
            )

            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )

            ->leftJoinSub(
                $latestPaidLog,
                'lp',
                function ($join) {
                    $join->on(
                        'lp.recurring_id',
                        '=',
                        'r.sno'
                    );
                }
            )

            /*
            |--------------------------------------------------------------------------
            | ACTIVE PRODUCTS ONLY
            |--------------------------------------------------------------------------
            */
            ->where('p.status', 0)
         
            

            ->where(function ($q) {

        /*
                |--------------------------------------------------------------------------
                | LIFETIME
                |--------------------------------------------------------------------------
                |
                | Lifetime is identified ONLY from product.
                | No recurring record is required.
                |
                */

                $q->whereRaw(
                    "LOWER(TRIM(p.frequency_type)) = 'life time'"
                )

                /*
                |--------------------------------------------------------------------------
                | RECURRING / STOPPED RECURRING
                |--------------------------------------------------------------------------
                |
                | Active recurring:
                |     p.is_recurring = 1
                |
                | Stopped recurring:
                |     r.status = 2
                |
                | Important:
                |     Do NOT require p.is_recurring = 1 for stopped records.
                |
                */

                ->orWhere(function ($recurring) {

                    $recurring->where(function ($status) {

                        $status->where('p.is_recurring', 1)
                            ->orWhere('r.status', 2);

                    });

                    /*
                    |--------------------------------------------------------------------------
                    | Never allow One Time
                    |--------------------------------------------------------------------------
                    */

                    $recurring->whereRaw(
                        "LOWER(TRIM(p.frequency_type)) <> 'one time'"
                    );
                });

            });

        /*
        |--------------------------------------------------------------------------
        | CATEGORY FILTER
        |--------------------------------------------------------------------------
        */

        if ($categoryId !== null && $categoryId !== '') {

            $baseQuery->where(
                'p.category_id',
                (int) $categoryId
            );
        }

        /*
        |--------------------------------------------------------------------------
        | SEARCH
        |--------------------------------------------------------------------------
        */

        if ($search !== '') {

            $baseQuery->where(function ($q) use ($search) {

                $q->where(
                    'p.product_name',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'p.product_code',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'c.category_name',
                    'like',
                    "%{$search}%"
                );
            });
        }

        /*
        |--------------------------------------------------------------------------
        | STATUS FILTER
        |--------------------------------------------------------------------------
        |
        | Lifetime has NO recurring status.
        |
        | Therefore:
        |
        | active   => recurring active + lifetime
        | dropped  => recurring dropped only
        | paid     => recurring paid only
        | overdue  => recurring only
        | today    => recurring only
        | tomorrow => recurring only
        | upcoming => recurring only
        |
        |--------------------------------------------------------------------------
        */

        if ($statusFilter === 'dropped') {

            $baseQuery->where('p.is_recurring', 1)
                ->where('r.status', 2);

        } elseif ($statusFilter === 'active') {
            

            $baseQuery->where(function ($q) {

                $q->whereRaw(
                    "LOWER(TRIM(p.frequency_type)) = 'life time'"
                )

                ->orWhere(function ($sub) {

                    $sub->where('p.is_recurring', 1)
                        ->where('r.status', 0);
                });
            });

        } elseif ($statusFilter === 'paid') {

            $baseQuery->where('p.is_recurring', 1)
                ->whereNotNull('r.last_paid_date');

        } elseif ($statusFilter === 'overdue') {

            $baseQuery->where('p.is_recurring', 1)
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    '<',
                    $today->toDateString()
                );

        } elseif ($statusFilter === 'today') {

            $baseQuery->where('p.is_recurring', 1)
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    $today->toDateString()
                );

        } elseif ($statusFilter === 'tomorrow') {

            $baseQuery->where('p.is_recurring', 1)
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    $today->copy()
                        ->addDay()
                        ->toDateString()
                );

        } elseif ($statusFilter === 'upcoming') {

            $baseQuery->where('p.is_recurring', 1)
                ->where('r.status', 0)
                ->whereDate(
                    'r.next_pay_date',
                    '>',
                    $today->copy()
                        ->addDay()
                        ->toDateString()
                );
        }

        /*
        |--------------------------------------------------------------------------
        | RECURRING TAB COUNT
        |--------------------------------------------------------------------------
        |
        | Lifetime products are deliberately excluded from date tabs.
        |
        |--------------------------------------------------------------------------
        */

        $countForTab = function (
            ?Carbon $fromDate,
            ?Carbon $toDate
        ) use ($baseQuery) {

            $query = clone $baseQuery;

            /*
            |--------------------------------------------------------------------------
            | ONLY RECURRING PRODUCTS
            |--------------------------------------------------------------------------
            */

            $query->where('p.is_recurring', 1);

            /*
            |--------------------------------------------------------------------------
            | Date condition
            |--------------------------------------------------------------------------
            */

            $query->where(function ($q) use (
                $fromDate,
                $toDate
            ) {

                /*
                |--------------------------------------------------------------------------
                | Next recurring occurrence
                |--------------------------------------------------------------------------
                */

                $q->where(function ($sub) use (
                    $fromDate,
                    $toDate
                ) {

                    if ($fromDate) {

                        $sub->whereDate(
                            'r.next_pay_date',
                            '>=',
                            $fromDate->toDateString()
                        );
                    }

                    if ($toDate) {

                        $sub->whereDate(
                            'r.next_pay_date',
                            '<=',
                            $toDate->toDateString()
                        );
                    }
                })

                /*
                |--------------------------------------------------------------------------
                | OR latest paid occurrence
                |--------------------------------------------------------------------------
                */

                ->orWhere(function ($sub) use (
                    $fromDate,
                    $toDate
                ) {

                    $sub->whereNotNull('lp.date');

                    if ($fromDate) {

                        $sub->whereDate(
                            'lp.date',
                            '>=',
                            $fromDate->toDateString()
                        );
                    }

                    if ($toDate) {

                        $sub->whereDate(
                            'lp.date',
                            '<=',
                            $toDate->toDateString()
                        );
                    }
                });
            });

            return $query->count('p.sno');
        };

        /*
        |--------------------------------------------------------------------------
        | 7 DAYS
        |--------------------------------------------------------------------------
        */

        $count7Days = $countForTab(
            null,
            $today->copy()->addDays(7)
        );

        /*
        |--------------------------------------------------------------------------
        | CURRENT MONTH
        |--------------------------------------------------------------------------
        */

        $countCurrentMonth = $countForTab(
            $today->copy()->startOfMonth(),
            $today->copy()->endOfMonth()
        );

        /*
        |--------------------------------------------------------------------------
        | NEXT MONTH
        |--------------------------------------------------------------------------
        */

        $nextMonthStart = $today->copy()
            ->addMonthNoOverflow()
            ->startOfMonth();

        $countNextMonth = $countForTab(
            $nextMonthStart,
            $nextMonthStart->copy()->endOfMonth()
        );

        /*
        |--------------------------------------------------------------------------
        | NEXT 6 MONTHS
        |--------------------------------------------------------------------------
        */

        $count6Months = $countForTab(
            $today->copy(),
            $today->copy()
                ->addMonthsNoOverflow(6)
                ->endOfDay()
        );

        /*
        |--------------------------------------------------------------------------
        | NEXT YEAR
        |--------------------------------------------------------------------------
        */

        $nextYearStart = $today->copy()
            ->addYearNoOverflow()
            ->startOfYear();

        $countNextYear = $countForTab(
            $nextYearStart,
            $nextYearStart->copy()->endOfYear()
        );

        /*
        |--------------------------------------------------------------------------
        | LIFETIME COUNT
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        | No recurring master/log is checked here.
        |
        |--------------------------------------------------------------------------
        */

        $lifetimeQuery = DB::table(
            'egc_acc_expense_products as p'
        )
            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )
            ->where('p.status', 0)
            ->whereRaw(
                "LOWER(TRIM(p.frequency_type)) = 'life time'"
            );

        if ($categoryId !== null && $categoryId !== '') {

            $lifetimeQuery->where(
                'p.category_id',
                (int) $categoryId
            );
        }

        if ($search !== '') {

            $lifetimeQuery->where(function ($q) use ($search) {

                $q->where(
                    'p.product_name',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'p.product_code',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'c.category_name',
                    'like',
                    "%{$search}%"
                );
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Lifetime status filter
        |--------------------------------------------------------------------------
        |
        | Lifetime is a valid active product.
        | It is NOT paid/due/overdue/etc.
        |
        |--------------------------------------------------------------------------
        */

        if (
            $statusFilter !== '' &&
            !in_array(
                $statusFilter,
                ['active'],
                true
            )
        ) {
            $lifetimeQuery->whereRaw('1 = 0');
        }

        $countLifetime = $lifetimeQuery
            ->count('p.sno');

        /*
        |--------------------------------------------------------------------------
        | ALL
        |--------------------------------------------------------------------------
        |
        | All = recurring products + lifetime products.
        |
        | We count products, not recurring masters.
        |
        |--------------------------------------------------------------------------
        */

        $allQuery = clone $baseQuery;

        $countAll = $allQuery->count('p.sno');

        /*
        |--------------------------------------------------------------------------
        | RESPONSE
        |--------------------------------------------------------------------------
        */

        return response()->json([
            'success' => true,

            'counts' => [
                '7_days'       => $count7Days,
                'current_month' => $countCurrentMonth,
                'next_month'   => $countNextMonth,
                '6_months'     => $count6Months,
                'next_year'    => $countNextYear,

                'lifetime'     => $countLifetime,
                'all'          => $countAll,
            ],
        ]);
    }

    // public function recurringList(Request $request)
    // {
    //     $today = Carbon::today('Asia/Kolkata');

    //     $tab = $request->input('tab', '7_days');

    //     $categoryId = $request->input('category');
    //     $statusFilter = $request->input('status');
    //     $search = trim((string) $request->input('search', ''));

    //     $startTime = microtime(true);
    //     $page = $request->input('page', 1);
    //     $perpage = (int) $request->input('sorting_filter', 25);
    //     $offset = ($page - 1) * $perpage;

    //     $helper = new \App\Helpers\Helpers();
    //     $general_setting = $helper->general_setting_data();
        
    //     /* Date range */

    //     $fromDate = null;
    //     $toDate = null;

    //     switch ($tab) {
    
    //         case 'current_month':
    //             $fromDate = $today->copy()->startOfMonth();
    //             $toDate   = $today->copy()->endOfMonth();
    //             break;
    //         case 'next_month':
    //             $fromDate = $today->copy()
    //                 ->addMonthNoOverflow()
    //                 ->startOfMonth();
    //             $toDate = $fromDate->copy()->endOfMonth();
    //             break;
    //         case '6_months':
    //             $fromDate = $today->copy();
    //             $toDate = $today->copy()
    //                 ->addMonthsNoOverflow(6)
    //                 ->endOfDay();
    //             break;
    //         case 'next_year':
    //             $fromDate = $today->copy()
    //                 ->addYearNoOverflow()
    //                 ->startOfYear();
    //             $toDate = $fromDate->copy()
    //                 ->endOfYear();
    //             break;
    //         case '7_days':
    //         default:
    //             $fromDate = null;
    //             $toDate = $today->copy()
    //                 ->addDays(7);
    //             break;
    //     }

    //     /*Latest paid log */

    //     $latestPaidLog = DB::table('egc_acc_recurring_log as l')
    //         ->select([
    //             'l.recurring_id',
    //             'l.sno',
    //             'l.date',
    //             'l.paid_date',
    //             'l.amount',
    //             'l.currency_type',
    //             'l.currency_amount',
    //         ])
    //         ->where('l.status', 1)
    //         ->whereRaw(
    //             'l.sno = (
    //                 SELECT MAX(l2.sno)
    //                 FROM egc_acc_recurring_log l2
    //                 WHERE l2.recurring_id = l.recurring_id
    //                 AND l2.status = 1)'
    //         );

    //     /* Current / next occurrence  */

    //     $currentLog = DB::table('egc_acc_recurring_log as l')
    //         ->select([
    //             'l.recurring_id',
    //             'l.sno',
    //             'l.date',
    //             'l.paid_date',
    //             'l.status',
    //             'l.amount',
    //             'l.currency_type',
    //             'l.currency_amount',
    //             'l.is_gst',
    //             'l.gst_amount',
    //             'l.total_amount',
    //         ])
    //         ->whereRaw(
    //             'l.sno = (
    //                 SELECT MAX(l2.sno)
    //                 FROM egc_acc_recurring_log l2
    //                 WHERE l2.recurring_id = l.recurring_id
    //                 AND l2.status IN (0, 1, 3)
    //             )'
    //         );

    //     /* Master query  */

    //     $query = DB::table('egc_acc_recurring as r')

    //         ->join('egc_acc_expense_products as p','p.sno','=','r.product_id' )
    //         ->leftJoin('egc_acc_expense_categories as c','c.sno','=','r.category_id' )
    //         ->leftJoinSub(
    //             $latestPaidLog,
    //             'lp',
    //             function ($join) {
    //                 $join->on('lp.recurring_id', '=','r.sno');
    //             } )
    //         ->leftJoinSub(
    //             $currentLog,
    //             'cl',
    //             function ($join) {
    //                 $join->on(
    //                     'cl.recurring_id',
    //                     '=',
    //                     'r.sno'
    //                 );
    //             }
    //         )

    //         ->select([
    //             'r.sno',
    //             'r.product_id',
    //             'r.category_id',
    //             'r.frequency_type',
    //             'r.date',
    //             'r.next_pay_date',
    //             'r.last_paid_date',
    //             'r.amount',
    //             'r.currency_type',
    //             'r.currency_amount',
    //             'r.is_gst',
    //             'r.gst_amount',
    //             'r.total_amount',
    //             'r.status as recurring_status',

    //             'p.product_name',
    //             'p.product_code',
    //             'p.is_recurring',
    //             'p.billing_date',
    //             'p.email_id',
    //             'p.mobile_no',
    //             'p.website',
    //             'p.remarks',

    //             'c.category_name',
    //             'c.icon',

    //             'lp.sno as last_paid_log_id',
    //             'lp.date as last_paid_due_date',
    //             'lp.paid_date as latest_paid_date',

    //             'cl.sno as current_log_id',
    //             'cl.status as current_log_status',
    //             'cl.date as current_log_date',
    //             'cl.paid_date as current_log_paid_date',
    //             'cl.is_gst as current_log_is_gst',
    //             'cl.gst_amount as current_log_gst_amount',
    //             'cl.total_amount as current_log_total_amount',
    //         ]);

            

    //     /* Category */

    //     if ($categoryId !== null && $categoryId !== '') {
    //         $query->where('r.category_id', (int) $categoryId );
    //     }

    //     /* Search */

    //     if ($search !== '') {

    //         $query->where(function ($q) use ($search) {
    //             $q->where('p.product_name', 'like',"%{$search}%")
    //             ->orWhere('p.product_code','like', "%{$search}%" )
    //             ->orWhere('c.category_name','like',"%{$search}%");
    //         });
    //     }

       

    //     if ($fromDate || $toDate) {

    //         $query->where(function ($q) use ($fromDate, $toDate) {

    //             /* Upcoming / next recurring occurrence */
    //             $q->where(function ($sub) use ($fromDate, $toDate) {

    //                 if ($fromDate) {
    //                     $sub->whereDate(
    //                         'r.next_pay_date',
    //                         '>=',
    //                         $fromDate->toDateString()
    //                     );
    //                 }

    //                 if ($toDate) {
    //                     $sub->whereDate(
    //                         'r.next_pay_date',
    //                         '<=',
    //                         $toDate->toDateString()
    //                     );
    //                 }
    //             })

    //             /* OR latest paid occurrence */
    //             ->orWhere(function ($sub) use ($fromDate, $toDate) {

    //                 $sub->whereNotNull('lp.date');

    //                 if ($fromDate) {
    //                     $sub->whereDate(
    //                         'lp.date',
    //                         '>=',
    //                         $fromDate->toDateString()
    //                     );
    //                 }

    //                 if ($toDate) {
    //                     $sub->whereDate(
    //                         'lp.date',
    //                         '<=',
    //                         $toDate->toDateString()
    //                     );
    //                 }
    //             });
    //         });
    //     }
        
    //     /* Status filtering  */
    //     if ($statusFilter === 'dropped') {
    //         $query->where('r.status', 2);
    //     } elseif ($statusFilter === 'active') {
    //         $query->where('r.status', 0);
    //     } elseif ($statusFilter === 'overdue') {
    //         $query->where('r.status', 0)
    //             ->whereDate('r.next_pay_date', '<', $today->toDateString() );
    //     } elseif ($statusFilter === 'today') {
    //         $query->where('r.status', 0)
    //             ->whereDate('r.next_pay_date',$today->toDateString());
    //     } elseif ($statusFilter === 'tomorrow') {
    //         $query
    //             ->where('r.status', 0)
    //             ->whereDate(
    //                 'r.next_pay_date',
    //                 $today->copy()->addDay()->toDateString()
    //             );
    //     } elseif ($statusFilter === 'paid') {
    //         $query->whereNotNull('r.last_paid_date');
    //     } elseif ($statusFilter === 'upcoming') {
    //         $query
    //             ->where('r.status', 0)
    //             ->whereDate(
    //                 'r.next_pay_date',
    //                 '>',
    //                 $today->copy()->addDay()->toDateString()
    //             );
    //     }

    //     /* Ordering */

    //     $rows = $query
    //         ->orderByRaw(
    //             "CASE
    //                 WHEN r.status = 2 THEN 5
    //                 WHEN r.next_pay_date < ? THEN 1
    //                 WHEN r.next_pay_date = ? THEN 2
    //                 WHEN r.next_pay_date = ? THEN 3
    //                 ELSE 4
    //             END",
    //             [
    //                 $today->toDateString(),
    //                 $today->toDateString(),
    //                 $today->copy()->addDay()->toDateString(),
    //             ]
    //         )
    //         ->orderBy('r.next_pay_date')
    //         ->orderBy('p.product_name')
    //         ->paginate($perpage);

    //     /* Transform  */
    //     $data = $rows->map(function ($row) use ($today ,$fromDate,$toDate,$tab) {

    //       $paidDueDate = $row->last_paid_due_date
    //         ? Carbon::parse($row->last_paid_due_date)
    //         : null;

    //     $nextDate = $row->next_pay_date
    //         ? Carbon::parse($row->next_pay_date)
    //         : null;

    //     /*
    //     |--------------------------------------------------------------------------
    //     | Paid occurrence
    //     |--------------------------------------------------------------------------
    //     |
    //     | The latest paid log represents the PREVIOUS occurrence.
    //     |
    //     | If next_pay_date is after the paid due date, then the next
    //     | occurrence has not been paid yet.
    //     |
    //     */

    //     $isPaidOccurrence = false;

    //     if ($paidDueDate && $row->latest_paid_date && $nextDate) {

    //         /*
    //         * The paid occurrence is the occurrence whose due date
    //         * was paid. Once next_pay_date moves beyond that date,
    //         * next_pay_date represents a NEW unpaid occurrence.
    //         */
    //         $isPaidOccurrence =
    //             $paidDueDate->isSameDay($nextDate);
    //     }

    //         /* Master status */
    //         if ((int) $row->recurring_status === 2) {

    //             $displayStatus = 'dropped';
    //             $statusLabel = 'Stopped';
    //             $statusIcon = 'mdi-stop-circle-outline';

    //         } elseif (!$nextDate) {

    //             $displayStatus = 'dropped';
    //             $statusLabel = 'No Schedule';
    //             $statusIcon = 'mdi-calendar-remove-outline';

    //         } elseif ($isPaidOccurrence && $paidDueDate) {

               
    //             $displayStatus = 'paid';
    //             $statusLabel = 'Paid';
    //             $statusIcon = 'mdi-check-circle-outline';

    //         } elseif ($nextDate->lt($today)) {

    //             $displayStatus = 'overdue';
    //             $statusLabel = 'Overdue';
    //             $statusIcon = 'mdi-alert-circle-outline';

    //         } elseif ($nextDate->isSameDay($today)) {

    //             $displayStatus = 'today';
    //             $statusLabel = 'Due Today';
    //             $statusIcon = 'mdi-bell-alert';

    //         } elseif (
    //             $nextDate->isSameDay(
    //                 $today->copy()->addDay()
    //             )
    //         ) {

    //             $displayStatus = 'tomorrow';
    //             $statusLabel = 'Due Tomorrow';
    //             $statusIcon = 'mdi-clock-alert-outline';

    //         } else {

    //             $displayStatus = 'upcoming';
    //             $statusLabel = 'Upcoming';
    //             $statusIcon = 'mdi-calendar-clock-outline';
    //         }

    //         /* Last payment  */

    //         $lastPaymentStatus =
    //             $row->last_paid_date
    //                 ? 'paid'
    //                 : 'not_paid';

    //         /* Days */

    //         $daysDifference = $nextDate
    //             ? $today->diffInDays($nextDate, false)
    //             : null;

    //         if ($daysDifference === null) {

    //             $reminderText = 'No payment schedule';

    //         } elseif ($daysDifference < 0) {

    //             $daysOverdue = abs($daysDifference);

    //             $reminderText =
    //                 $daysOverdue === 1
    //                     ? '1 day overdue'
    //                     : $daysOverdue . ' days overdue';

    //         } elseif ($daysDifference === 0) {

    //             $reminderText = 'Due today';

    //         } elseif ($daysDifference === 1) {

    //             $reminderText = 'Due tomorrow';

    //         } else {

    //             $reminderText =
    //                 'Due in ' . $daysDifference . ' days';
    //         }

    //         return [

    //             'id' => (int) $row->sno,
    //             'product_id' => (int) $row->product_id,
    //             'product_name' => $row->product_name,
    //             'product_code' => $row->product_code,
    //             'category_id' => (int) $row->category_id,
    //             'category_name' => $row->category_name,
    //             'category_icon' => $row->icon,
    //             'frequency_type' => $this->formatExpenseFrequency($row->frequency_type),
    //             'frequency_key' => $row->frequency_type,
    //             'next_pay_date' => $row->next_pay_date,
    //             'last_paid_date' => $row->last_paid_date,
    //             'amount' => (float) ($row->amount ?? 0),
    //             'currency_type' => $row->currency_type,
    //             'currency_amount' => (float) ($row->currency_amount ?? 0),
    //             'gst_amount' => (float) ($row->gst_amount ?? 0),
    //             'total_amount' =>  (float) ($row->total_amount ?? 0),
    //             'is_gst' =>  (int) $row->is_gst,
    //             'recurring_status' => (int) $row->recurring_status,
    //             'display_status' => $displayStatus,
    //             'status_label' => $statusLabel,
    //             'status_icon' => $statusIcon,
    //             'last_payment_status' => $lastPaymentStatus,
    //             'latest_paid_date' => $row->latest_paid_date,
    //             'last_paid_due_date' => $row->last_paid_due_date,
    //             'current_log_id' =>
    //                 $row->current_log_id
    //                     ? (int) $row->current_log_id
    //                     : null,
    //             'current_log_status' =>
    //                 $row->current_log_status !== null
    //                     ? (int) $row->current_log_status
    //                     : null,
    //             'reminder_text' =>$reminderText,
    //             'days_difference' => $daysDifference,
    //             'email_id' => $row->email_id,
    //             'mobile_no' => $row->mobile_no,
    //             'website' => $row->website,
    //             'remarks' =>  $row->remarks,
    //         ];
    //     })->values();

    //     /* Summary  */
    //     $summary = [
    //         'total' =>$data->count(),
    //         'active' => $data->where('recurring_status', 0 )->count(),
    //         'paid' =>$data->where('last_payment_status','paid')->count(),
    //         'today' => $data->where( 'display_status', 'today' )->count(),
    //         'tomorrow' =>$data->where('display_status','tomorrow')->count(),
    //         'overdue' => $data->where('display_status','overdue')->count(),
    //         'dropped' => $data->where( 'recurring_status',2 )->count(),
    //     ];

    //     return response()->json([
    //         'success' => true,
    //         'data' => $data,
    //         'current_page' => $rows->currentPage(),
    //         'last_page' => $rows->lastPage(),
    //         'total' => $rows->total(),
    //         'summary' => $summary,
    //         'tab' => $tab,
    //         'today' => $today->toDateString(),
    //     ]);
    // }

    public function recurringList(Request $request)
    {
        $today = Carbon::today('Asia/Kolkata');

        $allowedTabs = [
            '7_days',
            'current_month',
            'next_month',
            '6_months',
            'next_year',
            'lifetime',
            'all',
        ];

        $tab = $request->input('tab', '7_days');

        if (!in_array($tab, $allowedTabs, true)) {
            $tab = '7_days';
        }

        $categoryId = $request->input('category');
        $statusFilter = trim((string) $request->input('status', ''));
        $search = trim((string) $request->input('search', ''));

        $perpage = (int) $request->input('sorting_filter', 25);

        /*
        |--------------------------------------------------------------------------
        | Production pagination protection
        |--------------------------------------------------------------------------
        */

        $perpage = max(1, min($perpage, 100));

        /*
        |--------------------------------------------------------------------------
        | DATE RANGE
        |--------------------------------------------------------------------------
        |
        | Lifetime and All do NOT use this date range directly.
        |
        |--------------------------------------------------------------------------
        */

        $fromDate = null;
        $toDate = null;

        switch ($tab) {

            case 'current_month':

                $fromDate = $today->copy()
                    ->startOfMonth();

                $toDate = $today->copy()
                    ->endOfMonth();

                break;

            case 'next_month':

                $fromDate = $today->copy()
                    ->addMonthNoOverflow()
                    ->startOfMonth();

                $toDate = $fromDate->copy()
                    ->endOfMonth();

                break;

            case '6_months':

                $fromDate = $today->copy();

                $toDate = $today->copy()
                    ->addMonthsNoOverflow(6)
                    ->endOfDay();

                break;

            case 'next_year':

                $fromDate = $today->copy()
                    ->addYearNoOverflow()
                    ->startOfYear();

                $toDate = $fromDate->copy()
                    ->endOfYear();

                break;

            case '7_days':

                $fromDate = null;

                $toDate = $today->copy()
                    ->addDays(7);

                break;

            case 'lifetime':
            case 'all':

                /*
                |--------------------------------------------------------------------------
                | No date restriction.
                |--------------------------------------------------------------------------
                */

                $fromDate = null;
                $toDate = null;

                break;
        }

        /*
        |--------------------------------------------------------------------------
        | LATEST RECURRING MASTER PER PRODUCT
        |--------------------------------------------------------------------------
        |
        | Prevents duplicate rows if historical recurring masters exist.
        |
        |--------------------------------------------------------------------------
        */

        $latestRecurringMaster = DB::table(
            'egc_acc_recurring'
        )
            ->selectRaw(
                'MAX(sno) as sno, product_id'
            )
            ->groupBy('product_id');

        /*
        |--------------------------------------------------------------------------
        | LATEST PAID LOG
        |--------------------------------------------------------------------------
        */

        $latestPaidLog = DB::table(
            'egc_acc_recurring_log as l'
        )
            ->select([
                'l.recurring_id',
                'l.sno',
                'l.date',
                'l.paid_date',
                'l.amount',
                'l.currency_type',
                'l.currency_amount',
            ])
            ->where('l.status', 1)
            ->whereRaw(
                'l.sno = (
                    SELECT MAX(l2.sno)
                    FROM egc_acc_recurring_log l2
                    WHERE l2.recurring_id = l.recurring_id
                    AND l2.status = 1
                )'
            );

        /*
        |--------------------------------------------------------------------------
        | CURRENT / LATEST RECURRING LOG
        |--------------------------------------------------------------------------
        */

        $currentLog = DB::table(
            'egc_acc_recurring_log as l'
        )
            ->select([
                'l.recurring_id',
                'l.sno',
                'l.date',
                'l.paid_date',
                'l.status',
                'l.amount',
                'l.currency_type',
                'l.currency_amount',
                'l.is_gst',
                'l.gst_amount',
                'l.total_amount',
            ])
            ->whereRaw(
                'l.sno = (
                    SELECT MAX(l2.sno)
                    FROM egc_acc_recurring_log l2
                    WHERE l2.recurring_id = l.recurring_id
                    AND l2.status IN (0, 1, 3)
                )'
            );

        /*
        |--------------------------------------------------------------------------
        | MAIN QUERY
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        |
        | Products are the root table.
        |
        | Lifetime:
        |   p exists
        |   r may NOT exist
        |
        | Recurring:
        |   p exists
        |   r exists
        |
        |--------------------------------------------------------------------------
        */

        $query = DB::table(
            'egc_acc_expense_products as p'
        )

            ->leftJoinSub(
                $latestRecurringMaster,
                'latest_r',
                function ($join) {

                    $join->on(
                        'latest_r.product_id',
                        '=',
                        'p.sno'
                    );
                }
            )

            ->leftJoin(
                'egc_acc_recurring as r',
                'r.sno',
                '=',
                'latest_r.sno'
            )

            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )

            ->leftJoinSub(
                $latestPaidLog,
                'lp',
                function ($join) {

                    $join->on(
                        'lp.recurring_id',
                        '=',
                        'r.sno'
                    );
                }
            )

            ->leftJoinSub(
                $currentLog,
                'cl',
                function ($join) {

                    $join->on(
                        'cl.recurring_id',
                        '=',
                        'r.sno'
                    );
                }
            )

            ->where('p.status', 0)

            /*
            |--------------------------------------------------------------------------
            | ONLY RECURRING OR LIFETIME
            |--------------------------------------------------------------------------
            */

            ->where(function ($q) {

                /*
                |--------------------------------------------------------------------------
                | Lifetime
                |--------------------------------------------------------------------------
                */

                $q->whereRaw(
                    "LOWER(TRIM(p.frequency_type)) = 'life time'"
                )

                /*
                |--------------------------------------------------------------------------
                | Recurring + stopped recurring
                |--------------------------------------------------------------------------
                */

                ->orWhere(function ($recurring) {

                    $recurring->whereRaw(
                        "LOWER(TRIM(p.frequency_type)) <> 'one time'"
                    );

                    $recurring->where(function ($status) {

                        $status->where('p.is_recurring', 1)
                            ->orWhere('r.status', 2);

                    });
                });

            })

            ->select([
                /*
                |--------------------------------------------------------------------------
                | PRODUCT
                |--------------------------------------------------------------------------
                */

                'p.sno as product_id',
                'p.product_name',
                'p.product_code',
                'p.category_id as product_category_id',
                'p.frequency_type as product_frequency_type',
                'p.is_recurring as product_is_recurring',
                'p.billing_date',
                'p.email_id',
                'p.mobile_no',
                'p.website',
                'p.remarks',
                'p.currency_type as product_currency_type',
                'p.default_amount as product_default_amount',
                'p.amount_inr as product_amount_inr',
                'p.is_gst_applicable',

                /*
                |--------------------------------------------------------------------------
                | RECURRING MASTER
                |--------------------------------------------------------------------------
                */

                'r.sno as recurring_id',
                'r.product_id as recurring_product_id',
                'r.category_id as recurring_category_id',
                'r.frequency_type as recurring_frequency_type',
                'r.date as recurring_date',
                'r.next_pay_date',
                'r.last_paid_date',
                'r.amount as recurring_amount',
                'r.currency_type as recurring_currency_type',
                'r.currency_amount as recurring_currency_amount',
                'r.is_gst as recurring_is_gst',
                'r.gst_amount as recurring_gst_amount',
                'r.total_amount as recurring_total_amount',
                'r.status as recurring_status',

                /*
                |--------------------------------------------------------------------------
                | CATEGORY
                |--------------------------------------------------------------------------
                */

                'c.category_name',
                'c.icon',

                /*
                |--------------------------------------------------------------------------
                | PAID LOG
                |--------------------------------------------------------------------------
                */

                'lp.sno as last_paid_log_id',
                'lp.date as last_paid_due_date',
                'lp.paid_date as latest_paid_date',

                /*
                |--------------------------------------------------------------------------
                | CURRENT LOG
                |--------------------------------------------------------------------------
                */

                'cl.sno as current_log_id',
                'cl.status as current_log_status',
                'cl.date as current_log_date',
                'cl.paid_date as current_log_paid_date',
                'cl.is_gst as current_log_is_gst',
                'cl.gst_amount as current_log_gst_amount',
                'cl.total_amount as current_log_total_amount',
            ]);

            // return $query->get();
        /*
        |--------------------------------------------------------------------------
        | CATEGORY
        |--------------------------------------------------------------------------
        */

        if ($categoryId !== null && $categoryId !== '') {

            $query->where(
                'p.category_id',
                (int) $categoryId
            );
        }

        /*
        |--------------------------------------------------------------------------
        | SEARCH
        |--------------------------------------------------------------------------
        */

        if ($search !== '') {

            $query->where(function ($q) use ($search) {

                $q->where(
                    'p.product_name',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'p.product_code',
                    'like',
                    "%{$search}%"
                )

                ->orWhere(
                    'c.category_name',
                    'like',
                    "%{$search}%"
                );
            });
        }

        /*
        |--------------------------------------------------------------------------
        | TAB FILTER
        |--------------------------------------------------------------------------
        */

        if ($tab === 'lifetime') {

            /*
            |--------------------------------------------------------------------------
            | LIFETIME
            |--------------------------------------------------------------------------
            |
            | CRITICAL:
            |
            | Do NOT check r.
            |
            | Lifetime products are identified only from products table.
            |
            |--------------------------------------------------------------------------
            */

            $query->whereRaw(
                "LOWER(TRIM(p.frequency_type)) = 'life time'"
            );

        } elseif ($tab === 'all') {
        
            /*
            |--------------------------------------------------------------------------
            | ALL
            |--------------------------------------------------------------------------
            |
            | Product query already contains:
            |
            | recurring OR lifetime
            |
            | Therefore no date condition here.
            |
            |--------------------------------------------------------------------------
            */

        } else {

            $query->where(function ($q) {

                /*
                |--------------------------------------------------------------------------
                | Active OR stopped recurring
                |--------------------------------------------------------------------------
                */

                $q->where('p.is_recurring', 1)
                ->orWhere('r.status', 2);

            });

            $query->where(function ($q) use (
                $fromDate,
                $toDate
            ) {

                /*
                |--------------------------------------------------------------------------
                | STOPPED RECURRING
                |--------------------------------------------------------------------------
                |
                | status = 2 must always be available.
                | Do NOT apply next_pay_date filtering to stopped records.
                |
                */

                $q->where(
                    'r.status',
                    2
                );

                /*
                |--------------------------------------------------------------------------
                | ACTIVE RECURRING
                |--------------------------------------------------------------------------
                |
                | Only active records are filtered by date.
                |
                */

                $q->orWhere(function ($active) use (
                    $fromDate,
                    $toDate
                ) {

                    $active->where(
                        'r.status',
                        0
                    );

                    $active->where(function ($dateQuery) use (
                        $fromDate,
                        $toDate
                    ) {

                        /*
                        |--------------------------------------------------------------------------
                        | Next payment date
                        |--------------------------------------------------------------------------
                        */

                        $dateQuery->where(function ($sub) use (
                            $fromDate,
                            $toDate
                        ) {

                            if ($fromDate) {
                                $sub->whereDate(
                                    'r.next_pay_date',
                                    '>=',
                                    $fromDate->toDateString()
                                );
                            }

                            if ($toDate) {
                                $sub->whereDate(
                                    'r.next_pay_date',
                                    '<=',
                                    $toDate->toDateString()
                                );
                            }
                        });

                        /*
                        |--------------------------------------------------------------------------
                        | OR latest paid occurrence
                        |--------------------------------------------------------------------------
                        */

                        $dateQuery->orWhere(function ($sub) use (
                            $fromDate,
                            $toDate
                        ) {

                            $sub->whereNotNull(
                                'lp.date'
                            );

                            if ($fromDate) {
                                $sub->whereDate(
                                    'lp.date',
                                    '>=',
                                    $fromDate->toDateString()
                                );
                            }

                            if ($toDate) {
                                $sub->whereDate(
                                    'lp.date',
                                    '<=',
                                    $toDate->toDateString()
                                );
                            }
                        });
                    });
                });
            });
        }

        /*
        |--------------------------------------------------------------------------
        | STATUS FILTER
        |--------------------------------------------------------------------------
        */

        if ($statusFilter === 'dropped') {

            /*
            |--------------------------------------------------------------------------
            | Only recurring products can be dropped.
            |--------------------------------------------------------------------------
            */

            // $query->where('p.is_recurring',1);
            $query->where('r.status', 2);

        } elseif ($statusFilter === 'active') {

            /*
            |--------------------------------------------------------------------------
            | Lifetime is always active from recurring-status perspective.
            |--------------------------------------------------------------------------
            */

            $query->where(
                function ($q) {

                    $q->whereRaw(
                        "LOWER(TRIM(p.frequency_type)) = 'life time'"
                    )

                    ->orWhere(
                        function ($sub) {

                            $sub->where(
                                'p.is_recurring',
                                1
                            )

                            ->where(
                                'r.status',
                                0
                            );
                        }
                    );
                }
            );

        } elseif ($statusFilter === 'paid') {

            /*
            |--------------------------------------------------------------------------
            | Lifetime has no recurring payment status.
            |--------------------------------------------------------------------------
            */

            $query->where(
                'p.is_recurring',
                1
            );

            $query->whereNotNull(
                'r.last_paid_date'
            );

        } elseif ($statusFilter === 'overdue') {

            $query->where(
                'p.is_recurring',
                1
            );

            $query->where(
                'r.status',
                0
            );

            $query->whereDate(
                'r.next_pay_date',
                '<',
                $today->toDateString()
            );

        } elseif ($statusFilter === 'today') {

            $query->where(
                'p.is_recurring',
                1
            );

            $query->where(
                'r.status',
                0
            );

            $query->whereDate(
                'r.next_pay_date',
                $today->toDateString()
            );

        } elseif ($statusFilter === 'tomorrow') {

            $query->where(
                'p.is_recurring',
                1
            );

            $query->where(
                'r.status',
                0
            );

            $query->whereDate(
                'r.next_pay_date',
                $today->copy()
                    ->addDay()
                    ->toDateString()
            );

        } elseif ($statusFilter === 'upcoming') {

            $query->where(
                'p.is_recurring',
                1
            );

            $query->where(
                'r.status',
                0
            );

            $query->whereDate(
                'r.next_pay_date',
                '>',
                $today->copy()
                    ->addDay()
                    ->toDateString()
            );
        }

        /*
        |--------------------------------------------------------------------------
        | ORDERING
        |--------------------------------------------------------------------------
        */

        if ($tab === 'lifetime') {

            $query->orderBy('p.product_name');

        } elseif ($tab === 'all') {

            /*
            |--------------------------------------------------------------------------
            | Lifetime first, then recurring by next payment.
            |--------------------------------------------------------------------------
            */

            $query
                ->orderByRaw(
                    "CASE
                        WHEN LOWER(TRIM(p.frequency_type)) = 'life time'
                            THEN 5
                        WHEN r.status = 2
                            THEN 4
                        WHEN r.next_pay_date < ?
                            THEN 1
                        WHEN r.next_pay_date = ?
                            THEN 2
                        WHEN r.next_pay_date = ?
                            THEN 3
                        ELSE 4
                    END",
                    [
                        $today->toDateString(),
                        $today->toDateString(),
                        $today->copy()
                            ->addDay()
                            ->toDateString(),
                    ]
                )
                ->orderBy('r.next_pay_date')
                ->orderBy('p.product_name');

        } else {

            $query
                ->orderByRaw(
                    "CASE
                        WHEN r.status = 2
                            THEN 5
                        WHEN r.next_pay_date < ?
                            THEN 1
                        WHEN r.next_pay_date = ?
                            THEN 2
                        WHEN r.next_pay_date = ?
                            THEN 3
                        ELSE 4
                    END",
                    [
                        $today->toDateString(),
                        $today->toDateString(),
                        $today->copy()
                            ->addDay()
                            ->toDateString(),
                    ]
                )
                ->orderBy('r.next_pay_date')
                ->orderBy('p.product_name');
        }

        /*
        |--------------------------------------------------------------------------
        | PAGINATION
        |--------------------------------------------------------------------------
        */

        $rows = $query->paginate(
            $perpage
        );

        /*
        |--------------------------------------------------------------------------
        | TRANSFORM
        |--------------------------------------------------------------------------
        */

        $data = $rows->getCollection()
            ->map(function ($row) use ($today) {

                /*
                |--------------------------------------------------------------------------
                | Determine record type
                |--------------------------------------------------------------------------
                */

                $isLifetime =
                    strtolower(
                        trim(
                            (string) $row->product_frequency_type
                        )
                    ) === 'life time';

                $recordType =
                    $isLifetime
                        ? 'lifetime'
                        : 'recurring';

                /*
                |--------------------------------------------------------------------------
                | LIFETIME
                |--------------------------------------------------------------------------
                */

                if ($isLifetime) {

                    return [
                        'id' => (int) $row->product_id,

                        'product_id' => (int) $row->product_id,

                        'product_name' =>
                            $row->product_name,

                        'product_code' =>
                            $row->product_code,

                        'category_id' =>
                            (int) $row->product_category_id,

                        'category_name' =>
                            $row->category_name,

                        'category_icon' =>
                            $row->icon,

                        'frequency_type' =>
                            $this->formatExpenseFrequency(
                                $row->product_frequency_type
                            ),

                        'frequency_key' =>
                            $row->product_frequency_type,

                        /*
                        |--------------------------------------------------------------------------
                        | Lifetime has NO recurring schedule.
                        |--------------------------------------------------------------------------
                        */

                        'next_pay_date' => null,

                        'last_paid_date' => null,

                        'amount' =>
                            (float) (
                                $row->product_default_amount ?? 0
                            ),

                        'currency_type' =>
                            $row->product_currency_type,

                        'currency_amount' =>
                            (float) (
                                $row->product_default_amount ?? 0
                            ),

                        'gst_amount' => 0,

                        'total_amount' =>
                            (float) (
                                $row->product_default_amount ?? 0
                            ),

                        'is_gst' =>
                            (int) (
                                $row->is_gst_applicable ?? 0
                            ),

                        /*
                        |--------------------------------------------------------------------------
                        | Lifetime status
                        |--------------------------------------------------------------------------
                        */

                        'recurring_status' => 0,

                        'display_status' => 'lifetime',

                        'status_label' => 'Lifetime',

                        'status_icon' => 'mdi-infinity',

                        'last_payment_status' => 'not_applicable',

                        'latest_paid_date' => null,

                        'last_paid_due_date' => null,

                        'current_log_id' => null,

                        'current_log_status' => null,

                        'reminder_text' =>
                            'Lifetime product',

                        'days_difference' => null,

                        'record_type' => 'lifetime',

                        'is_lifetime' => true,

                        'email_id' =>
                            $row->email_id,

                        'mobile_no' =>
                            $row->mobile_no,

                        'website' =>
                            $row->website,

                        'remarks' =>
                            $row->remarks,
                    ];
                }

                /*
                |--------------------------------------------------------------------------
                | RECURRING
                |--------------------------------------------------------------------------
                */

                $paidDueDate =
                    $row->last_paid_due_date
                        ? Carbon::parse(
                            $row->last_paid_due_date
                        )
                        : null;

                $nextDate =
                    $row->next_pay_date
                        ? Carbon::parse(
                            $row->next_pay_date
                        )
                        : null;

                /*
                |--------------------------------------------------------------------------
                | Paid occurrence
                |--------------------------------------------------------------------------
                */

                $isPaidOccurrence = false;

                if (
                    $paidDueDate &&
                    $row->latest_paid_date &&
                    $nextDate
                ) {

                    $isPaidOccurrence =
                        $paidDueDate->isSameDay(
                            $nextDate
                        );
                }

                /*
                |--------------------------------------------------------------------------
                | STATUS
                |--------------------------------------------------------------------------
                */

                if (
                    (int) $row->recurring_status === 2
                ) {

                    $displayStatus = 'dropped';
                    $statusLabel = 'Stopped';
                    $statusIcon =
                        'mdi-stop-circle-outline';

                } elseif (!$nextDate) {

                    $displayStatus = 'dropped';
                    $statusLabel = 'No Schedule';
                    $statusIcon =
                        'mdi-calendar-remove-outline';

                } elseif (
                    $isPaidOccurrence &&
                    $paidDueDate
                ) {

                    $displayStatus = 'paid';
                    $statusLabel = 'Paid';
                    $statusIcon =
                        'mdi-check-circle-outline';

                } elseif (
                    $nextDate->lt($today)
                ) {

                    $displayStatus = 'overdue';
                    $statusLabel = 'Overdue';
                    $statusIcon =
                        'mdi-alert-circle-outline';

                } elseif (
                    $nextDate->isSameDay($today)
                ) {

                    $displayStatus = 'today';
                    $statusLabel = 'Due Today';
                    $statusIcon =
                        'mdi-bell-alert';

                } elseif (
                    $nextDate->isSameDay(
                        $today->copy()->addDay()
                    )
                ) {

                    $displayStatus = 'tomorrow';
                    $statusLabel = 'Due Tomorrow';
                    $statusIcon =
                        'mdi-clock-alert-outline';

                } else {

                    $displayStatus = 'upcoming';
                    $statusLabel = 'Upcoming';
                    $statusIcon =
                        'mdi-calendar-clock-outline';
                }

                /*
                |--------------------------------------------------------------------------
                | Last payment status
                |--------------------------------------------------------------------------
                */

                $lastPaymentStatus =
                    $row->last_paid_date
                        ? 'paid'
                        : 'not_paid';

                /*
                |--------------------------------------------------------------------------
                | Days difference
                |--------------------------------------------------------------------------
                */

                $daysDifference =
                    $nextDate
                        ? $today->diffInDays(
                            $nextDate,
                            false
                        )
                        : null;

                /*
                |--------------------------------------------------------------------------
                | Reminder
                |--------------------------------------------------------------------------
                */

                if ($daysDifference === null) {

                    $reminderText =
                        'No payment schedule';

                } elseif ($daysDifference < 0) {

                    $daysOverdue =
                        abs($daysDifference);

                    $reminderText =
                        $daysOverdue === 1
                            ? '1 day overdue'
                            : $daysOverdue .
                                ' days overdue';

                } elseif ($daysDifference === 0) {

                    $reminderText =
                        'Due today';

                } elseif ($daysDifference === 1) {

                    $reminderText =
                        'Due tomorrow';

                } else {

                    $reminderText =
                        'Due in ' .
                        $daysDifference .
                        ' days';
                }

                /*
                |--------------------------------------------------------------------------
                | RECURRING RESPONSE
                |--------------------------------------------------------------------------
                */

                return [
                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT:
                    | id = recurring master ID
                    | product_id = product ID
                    |--------------------------------------------------------------------------
                    */

                    'id' =>
                        (int) $row->recurring_id,

                    'product_id' =>
                        (int) $row->product_id,

                    'product_name' =>
                        $row->product_name,

                    'product_code' =>
                        $row->product_code,

                    'category_id' =>
                        (int) $row->product_category_id,

                    'category_name' =>
                        $row->category_name,

                    'category_icon' =>
                        $row->icon,

                    'frequency_type' =>
                        $this->formatExpenseFrequency(
                            $row->recurring_frequency_type
                        ),

                    'frequency_key' =>
                        $row->recurring_frequency_type,

                    'next_pay_date' =>
                        $row->next_pay_date,

                    'last_paid_date' =>
                        $row->last_paid_date,

                    'amount' =>
                        (float) (
                            $row->recurring_amount ?? 0
                        ),

                    'currency_type' =>
                        $row->recurring_currency_type,

                    'currency_amount' =>
                        (float) (
                            $row->recurring_currency_amount ?? 0
                        ),

                    'gst_amount' =>
                        (float) (
                            $row->recurring_gst_amount ?? 0
                        ),

                    'total_amount' =>
                        (float) (
                            $row->recurring_total_amount ?? 0
                        ),

                    'is_gst' =>
                        (int) (
                            $row->recurring_is_gst ?? 0
                        ),

                    'recurring_status' =>
                        (int) (
                            $row->recurring_status ?? 0
                        ),

                    'display_status' =>
                        $displayStatus,

                    'status_label' =>
                        $statusLabel,

                    'status_icon' =>
                        $statusIcon,

                    'last_payment_status' =>
                        $lastPaymentStatus,

                    'latest_paid_date' =>
                        $row->latest_paid_date,

                    'last_paid_due_date' =>
                        $row->last_paid_due_date,

                    'current_log_id' =>
                        $row->current_log_id
                            ? (int) $row->current_log_id
                            : null,

                    'current_log_status' =>
                        $row->current_log_status !== null
                            ? (int) $row->current_log_status
                            : null,

                    'reminder_text' =>
                        $reminderText,

                    'days_difference' =>
                        $daysDifference,

                    'record_type' =>
                        'recurring',

                    'is_lifetime' =>
                        false,

                    'email_id' =>
                        $row->email_id,

                    'mobile_no' =>
                        $row->mobile_no,

                    'website' =>
                        $row->website,

                    'remarks' =>
                        $row->remarks,
                ];
            })
            ->values();

        /*
        |--------------------------------------------------------------------------
        | SUMMARY
        |--------------------------------------------------------------------------
        */

        $summary = [
            'total' =>
                $rows->total(),

            'active' =>
                $data->where(
                    'recurring_status',
                    0
                )->count(),

            'paid' =>
                $data->where(
                    'last_payment_status',
                    'paid'
                )->count(),

            'today' =>
                $data->where(
                    'display_status',
                    'today'
                )->count(),

            'tomorrow' =>
                $data->where(
                    'display_status',
                    'tomorrow'
                )->count(),

            'overdue' =>
                $data->where(
                    'display_status',
                    'overdue'
                )->count(),

            'dropped' =>
                $data->where(
                    'recurring_status',
                    2
                )->count(),

            'lifetime' =>
                $data->where(
                    'record_type',
                    'lifetime'
                )->count(),
        ];

        /*
        |--------------------------------------------------------------------------
        | RESPONSE
        |--------------------------------------------------------------------------
        */

        return response()->json([
            'success' => true,

            'data' => $data,

            'current_page' =>
                $rows->currentPage(),

            'last_page' =>
                $rows->lastPage(),

            'total' =>
                $rows->total(),

            'summary' =>
                $summary,

            'tab' =>
                $tab,

            'today' =>
                $today->toDateString(),
        ]);
    }

   public function recurringShow(
        Request $request,
        int $id
    ): JsonResponse {

        $master = DB::table('egc_acc_recurring as r')

            ->join(
                'egc_acc_expense_products as p',
                'p.sno',
                '=',
                'r.product_id'
            )

            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'r.category_id'
            )

            ->where('r.sno', $id)

            ->select([
                'r.sno',
                'r.product_id',
                'r.category_id',
                'r.frequency_type',
                'r.date',
                'r.next_pay_date',
                'r.last_paid_date',
                'r.amount',
                'r.currency_type',
                'r.currency_amount',
                'r.is_gst',
                'r.gst_amount',
                'r.total_amount',
                'r.status as recurring_status',

                'p.product_name',
                'p.product_code',
                'p.email_id',
                'p.mobile_no',
                'p.website',
                'p.remarks',
                'p.billing_date',
                'p.is_recurring',

                'c.category_name',
                'c.icon',
            ])
            ->first();

        if (!$master) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring master not found.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Complete payment history
        |--------------------------------------------------------------------------
        */

        $logs = DB::table('egc_acc_recurring_log as rl')

            ->leftJoin(
                'egc_acc_expense_logs as el',
                'el.sno',
                '=',
                'rl.expense_log_id'
            )

            ->leftJoin('egc_staff as st','st.sno', '=','rl.updated_by')
            ->where('rl.recurring_id',$id )

            ->select([
                'rl.sno',
                'rl.date',
                'rl.paid_date',
                'rl.amount',
                'rl.currency_type',
                'rl.currency_amount',
                'rl.is_gst',
                'rl.gst_amount',
                'rl.total_amount',
                'rl.status',
                'rl.expense_log_id',
                'rl.created_at',
                'rl.updated_at',
                'st.staff_name',
                'el.reference_no',
            ])

            ->orderByDesc('rl.date')
            ->orderByDesc('rl.sno')
            ->get()
            ->map(function ($log) {

                if ((int) $log->status === 1) {

                    $status = 'paid';
                    $label = 'Paid';
                    $icon = 'mdi-check-circle-outline';

                } elseif ((int) $log->status === 3) {

                    $status = 'dropped';
                    $label = 'Dropped';
                    $icon = 'mdi-close-circle-outline';

                } elseif (
                    Carbon::parse($log->date)
                        ->lt(Carbon::today('Asia/Kolkata'))
                ) {

                    $status = 'overdue';
                    $label = 'Overdue';
                    $icon = 'mdi-alert-circle-outline';

                } elseif (
                    Carbon::parse($log->date)
                        ->isToday()
                ) {

                    $status = 'today';
                    $label = 'Due Today';
                    $icon = 'mdi-bell-alert';

                } elseif (
                    Carbon::parse($log->date)
                        ->isTomorrow()
                ) {

                    $status = 'tomorrow';
                    $label = 'Due Tomorrow';
                    $icon = 'mdi-clock-alert-outline';

                } else {

                    $status = 'upcoming';
                    $label = 'Upcoming';
                    $icon = 'mdi-calendar-clock-outline';
                }

                return [
                    'id' => (int) $log->sno,

                    'date' => $log->date,

                    'paid_date' => $log->paid_date,

                    'amount' => (float) ($log->amount ?? 0),

                    'currency_type' => $log->currency_type,

                    'currency_amount' =>
                        (float) ($log->currency_amount ?? 0),

                    'gst_amount' =>
                        (float) ($log->gst_amount ?? 0),

                    'total_amount' =>
                        (float) ($log->total_amount ?? 0),

                    'status' => (int) $log->status,

                    'display_status' => $status,

                    'status_label' => $label,

                    'status_icon' => $icon,

                    'expense_log_id' =>
                        $log->expense_log_id
                            ? (int) $log->expense_log_id
                            : null,

                    'reference_no' =>
                        $log->reference_no,

                    'updated_by' =>
                        $log->staff_name,

                    'created_at' =>
                        $log->created_at,

                    'updated_at' =>
                        $log->updated_at,
                ];
            });

        /*Summary */

        $logSummary = [

            'total' => $logs->count(),
            'paid' => $logs->where('status', 1)->count(),
            'unpaid' => $logs->where('status', 0)->count(),
            'dropped' => $logs->where('status', 3)->count(),
            'overdue' => $logs->where('display_status','overdue' )->count(),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'master' => $master,
                'logs' => $logs->values(),
                'summary' => $logSummary,
            ],
        ]);
    }

    public function productRecurringLogs(
        Request $request,
        int $id
    ): JsonResponse {

        $product = DB::table(
            'egc_acc_expense_products as p'
        )
            ->leftJoin(
                'egc_acc_expense_categories as c',
                'c.sno',
                '=',
                'p.category_id'
            )
            ->where('p.sno', $id)
            ->select([
                'p.sno',
                'p.product_name',
                'p.product_code',
                'p.category_id',
                'p.frequency_type',
                'p.is_recurring',
                'p.billing_date',
                'p.default_amount',
                'p.currency_type',
                'p.is_gst_applicable',
                'p.remarks',
                'c.category_name',
                'c.icon',
            ])
            ->first();

        if (!$product) {

            return response()->json([
                'success' => false,
                'message' => 'Expense product not found.',
            ], 404);
        }

        $recurring = DB::table(
            'egc_acc_recurring'
        )
            ->where(
                'product_id',
                $id
            )
            ->first();

        if (!$recurring) {

            return response()->json([
                'success' => true,
                'data' => [
                    'product' => $product,
                    'master' => null,
                    'logs' => [],
                ],
            ]);
        }

        $logs = DB::table(
            'egc_acc_recurring_log as rl'
        )
            ->where(
                'rl.recurring_id',
                $recurring->sno
            )
            ->orderByDesc('rl.date')
            ->orderByDesc('rl.sno')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'product' => $product,
                'master' => $recurring,
                'logs' => $logs,
            ],
        ]);
    }

    public function stopRecurring(
        int $id,
        Request $request
    ): JsonResponse {

        $userId = $request->user()->user_id ?? 0;

        try {

            DB::transaction(function () use ($id, $userId) {

                $recurring = DB::table(
                    'egc_acc_recurring'
                )
                    ->where('product_id', $id)
                    ->where('status', 0)
                    ->lockForUpdate()
                    ->first();

                if (!$recurring) {

                    throw new \RuntimeException(
                        'Active recurring subscription not found.'
                    );
                }

                $now = Carbon::now('Asia/Kolkata');

                DB::table('egc_acc_recurring')
                    ->where('sno', $recurring->sno)
                    ->update([
                        'status' => 2,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);

                DB::table('egc_acc_recurring_log')
                    ->where(
                        'recurring_id',
                        $recurring->sno
                    )
                    ->where('status', 0)
                    ->whereDate(
                        'date',
                        '>=',
                        Carbon::today('Asia/Kolkata')
                            ->toDateString()
                    )
                    ->update([
                        'status' => 3,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);

                DB::table(
                    'egc_acc_expense_products'
                )
                    ->where('sno', $id)
                    ->update([
                        'is_recurring' => 0,
                        'updated_by' => $userId,
                        'updated_at' => $now,
                    ]);
            });

            return response()->json([
                'success' => true,
                'message' =>
                    'Recurring subscription stopped successfully.',
            ]);

        } catch (\Throwable $e) {

            report($e);

            return response()->json([
                'success' => false,
                'message' =>
                    'Unable to stop the recurring subscription.',
            ], 500);
        }
    }


      public function dropRecurring(
        Request $request,
        int $id
    ): JsonResponse {

        $userId = $request->user()->user_id ?? 0;

        $recurring = DB::table( 'egc_acc_recurring_log' )
            ->where('sno', $id)
            ->first();


        if (!$recurring) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring record not found.',
            ], 404);
        }


        if ((int) $recurring->status === 1) {

            return response()->json([
                'success' => false,
                'message' => 'A paid recurring record cannot be dropped.',
            ], 422);
        }


        if ((int) $recurring->status === 3) {

            return response()->json([
                'success' => false,
                'message' => 'Recurring record is already dropped.',
            ], 422);
        }


        DB::table('egc_acc_recurring_log' )
            ->where('sno', $id)
            ->update([
                'status' => 3,
                'updated_by' => $userId,
                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

            ]);


        return response()->json([
            'success' => true,
            'message' => 'Recurring payment dropped successfully.',
        ]);
    }
    
    // Pay through Functions
    public function payThrough()
    {
        return response()->json([
            'status'=>true,
            'success' => true,
            'data'=>DB::table(
                'egc_acc_pay_through'
            )
            ->where('status',0)
            ->orderBy('pay_through_name')
            ->get()
        ]);

    }
    public function payThroughStore(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'pay_through_name' => [
                    'required',
                    'string',
                    'max:250',
                ]
            ],
            [
                'pay_through_name.required' => 'Category name is required.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $payThroughName = trim($request->pay_through_name);
        $payThroughCode = strtoupper($payThroughName);

        // Replace anything other than letters/numbers with -
        $payThroughCode = preg_replace('/[^A-Z0-9]+/', '-', $payThroughCode);

        // Remove - from beginning/end
        $payThroughCode = trim($payThroughCode, '-');

        // Fallback in case the name contains no usable characters
        if ($payThroughCode === '') {
            $payThroughCode = 'PAYTHROUGH';
        }

        /* Make Code Unique  */
        $baseCode = $payThroughCode;
        $counter = 1;

        while (
            DB::table('egc_acc_pay_through')
                ->where('pay_through_code', $payThroughCode)
                ->where('status', 0)
                ->exists()
        ) {
            $counter++;
            $payThroughCode = $baseCode . '-' . $counter;
        }


        $exists = DB::table('egc_acc_pay_through')
            ->where('pay_through_name',$payThroughName)
            ->where('status',0)
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'Category code already exists.',
                'errors' => [
                    'pay_through_name' => [
                        'Pay Through Name already exists.'
                    ]
                ],
            ], 422);
        }

        $id = DB::table('egc_acc_expense_categories')->insertGetId([
            'pay_through_code' => $payThroughCode,
            'pay_through_name' => $payThroughName,
            'icon' => $request->icon,
            'created_by' => $request->user()->user_id ?? 0,
            'updated_by' => $request->user()->user_id ?? 0,
            'created_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            'status' => 0,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Expense Pay Through created successfully.',
            'data' => [
                'sno' => $id,
            ],
        ]);
    }
    public function payThroughShow($id)
    {
        $payThrough = DB::table('egc_acc_pay_through')
            ->where('sno',$id)
            ->where('status',0 )
            ->first();

        if (!$payThrough) {
            return response()->json([
                'success' => false,
                'message' => 'Expense Pay Through not found.',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $payThrough,
        ]);
    }
    public function payThroughUpdate(Request $request, $id)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'pay_through_name' => [
                    'required',
                    'string',
                    'max:250',
                ],
            ],
            [
                'pay_through_name.required' => 'Category name is required.',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Please correct the highlighted fields.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $category = DB::table('egc_acc_pay_through')
            ->where('sno',$id)
            ->where('status', 0)
            ->first();

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Expense category not found.',
            ], 404);
        }


        $categoryCode = strtoupper( trim($request->category_code));
        $payThroughName = trim($request->pay_through_name);

        $exists = DB::table( 'egc_acc_pay_through' )
            ->where('pay_through_name', $payThroughName)
            ->where( 'sno', '!=', $id)
            ->where('status', 0)
            ->exists();

        if ($exists) {
            return response()->json([
                'success' => false,
                'message' => 'Pay Through Name already exists.',
                'errors' => [
                    'pay_through_name' => [
                        'Pay Through Name already exists.'
                    ]
                ],
            ], 422);
        }

        DB::table('egc_acc_pay_through')
            ->where('sno', $id)
            ->update([
                'pay_through_name' => $payThroughName,
                'icon' => $request->icon,
                'updated_by' => $request->user()->user_id ?? 0,
                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            ]);

        return response()->json([
            'success' => true,
            'message' => 'Expense Pay Through successfully.',
            'data' => [
                'sno' => $id,
            ],
        ]);
    }

    public function payThroughDestroy($id,Request $request)
    {
        $category = DB::table( 'egc_acc_pay_through')
            ->where( 'sno', $id)
            ->where( 'status', 0)
            ->first();

        if (!$category) {
            return response()->json([
                'success' => false,
                'message' => 'Expense category not found.',
            ], 404);
        }

        DB::table('egc_acc_pay_through' )
            ->where('sno',$id)
            ->update([
                'status' => 2,
                'updated_by' => $request->user()->user_id ?? 0,
                'updated_at' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
            ]);

        return response()->json([
            'success' => true,
            'message' => 'Expense Pay Through deleted successfully.',
        ]);
    }


}