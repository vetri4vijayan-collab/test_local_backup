@extends('layouts/layoutMaster')

@section('title', 'Manage Candidate')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<style>
    .candidate-history-timeline{
        position:relative;
        padding-left:40px;
    }

    .history-item{
        position:relative;
        margin-bottom:20px;
    }

    .history-line{
        position:absolute;
        left:-23px;
        top:35px;
        width:2px;
        height:100%;
        background:#e5e7eb;
    }

    .history-item:last-child .history-line{
        display:none;
    }

    .history-dot{
        position:absolute;
        left:-38px;
        top:15px;
        width:30px;
        height:30px;
        border-radius:50%;
        color:#fff;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:12px;
        font-weight:700;
        box-shadow:0 4px 10px rgba(0,0,0,.15);
    }

    .history-card{
        background:#fff;
        border-radius:12px;
        padding:16px;
        border:1px solid #eef2f7;
        box-shadow:0 3px 10px rgba(0,0,0,.05);
        transition:.2s;
    }

    .history-card:hover{
        transform:translateY(-2px);
        box-shadow:0 8px 18px rgba(0,0,0,.08);
    }

    .history-remarks{
        background:#f8fafc;
        border-left:4px solid #f59e0b;
        padding:12px;
        border-radius:8px;
        margin-top:12px;
    }
</style>
<style>
    .modal-title-ai {
        font-weight: 700;
        letter-spacing: 0.5px;
    }

    .ai-subtitle {
        font-size: 13px;
        color: #6c757d;
    }

    .ai-loading {
        height: 150px;
        background: linear-gradient(90deg, #eee, #f5f5f5, #eee);
        animation: shimmer 1.5s infinite;
    }

    @keyframes shimmer {
        0% {
            background-position: -200px 0;
        }

        100% {
            background-position: 200px 0;
        }
    }

    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    /*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */

    .bg-label-ug {
        background-color: #E8F1FF;
        color: #0D6EFD;
    }

    .bg-label-pg {
        background-color: #E6F7EE;
        color: #198754;
    }

    .bg-label-doctorate {
        background-color: #F3E8FF;
        color: #6F42C1;
    }

    .bg-label-hsc {
        background-color: #E7F9FF;
        color: #0DCaf0;
    }

    .bg-label-sslc {
        background-color: #FFF4E5;
        color: #FF8C00;
    }

    .bg-label-below-sslc {
        background-color: #FFECEC;
        color: #DC3545;
    }

    .bg-label-others {
        background-color: #F1F3F5;
        color: #6C757D;
    }
</style>
<style>
      #download_qr_code_name {
            overflow-x: auto;       /* enable horizontal scroll */
            overflow-y: hidden;     /* optional: hide vertical scroll */
            white-space: nowrap;    /* keep content in one line if needed */

            /* Hide scrollbar - Firefox */
            scrollbar-width: none;

            /* Hide scrollbar - IE & Edge */
            -ms-overflow-style: none;
        }

        /* Hide scrollbar - Chrome, Safari */
        #download_qr_code_name::-webkit-scrollbar {
            display: none;
        }
</style>
<style>
    /* QR Card */
        .qr-card {
            width:350px;
        background: #ffffff;
        border-radius: 14px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        transition: transform 0.3s ease;
        }

        .qr-card:hover {
        transform: translateY(-4px);
        }

        /* QR Image */
        /*.qr-image {*/
        /*  width: 220px;*/
        /*  height: 220px;*/
        /*  border-radius: 12px;*/
        /*  padding: 10px;*/
        /*  background: #f8f9fa;*/
        /*  border: 1px solid #e9ecef;*/
        /*}*/

        .qr-image {
            width: 140px;
            height: 140px;
            /* border-radius: 12px; */
            position: absolute;
            top: 24.5%;
            left: 28%;
            padding: 0px;
            /* background: #f8f9fa; */
            /* border: 1px solid #e9ecef; */
        }

        /* Modal animation */
        .modal.fade .modal-dialog {
        transform: scale(0.95);
        transition: transform 0.3s ease;
        }

        .modal.show .modal-dialog {
        transform: scale(1);
        }

</style>
<style>
    .mini-card {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        border-radius: 12px;
        background: #ffffff;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        transition: 0.3s;
        cursor: pointer;
    }

    .mini-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
    }

    .mini-icon {
        width: 45px;
        height: 45px;
        object-fit: contain;
    }

    .mini-content h5 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
    }

    .mini-content span {
        font-size: 13px;
        color: #666;
    }

    /* Color Variants */
    .mini-card.primaryegc {
        border-left: 4px solid #ab2b22;
    }

    .mini-card.success {
        border-left: 4px solid #28c76f;
    }

    .mini-card.danger {
        border-left: 4px solid #ea5455;
    }

    .mini-card.walkincolor {
        border-left: 4px solid #182B46;
    }
    .mini-card.vipcandidatecolor {
        border-left: 4px solid #FFB80F;
    }

    .active-dashboard-filter{
        transform: translateY(-3px);
        border: 2px solid #f59e0b !important;
        box-shadow: 0 10px 25px rgba(245,158,11,.35);
        position: relative;
    }

    .active-dashboard-filter::after{
        content:'';
        position:absolute;
        top:8px;
        right:8px;
        width:10px;
        height:10px;
        background:#22c55e;
        border-radius:50%;
    }

    .mini-card.warning {
        border-left: 4px solid #ff9f43;
    }

    .mini-card.info {
        border-left: 4px solid #00cfe8;
    }

    .mini-card.primary {
        border-left: 4px solid #7367f0;
    }
</style>

<style>
    .vip-profile-card{
    background:#fff;
    border-radius:16px;
    padding:25px;
    box-shadow:0 3px 20px rgba(0,0,0,.08);
}

.vip-avatar{
    width:90px;
    height:90px;
    border-radius:50%;
    background:linear-gradient(
        135deg,
        #f59e0b,
        #f97316
    );
    color:#fff;
    font-size:36px;
    font-weight:700;
    display:flex;
    align-items:center;
    justify-content:center;
}

.vip-section{
    background:#fff;
    border-radius:12px;
    padding:20px;
    border:1px solid #eee;
}

.vip-remark-box{
    border-radius:12px;
    min-height:120px;
}
</style>
<style>
    .history-profile-card{
    background:#fff;
    border-radius:16px;
    padding:25px;
    box-shadow:0 3px 20px rgba(0,0,0,.08);
}

.history-avatar{
    width:90px;
    height:90px;
    border-radius:50%;
    background:linear-gradient(
        135deg,
        #f59e0b,
        #f97316
    );
    color:#fff;
    font-size:36px;
    font-weight:700;
    display:flex;
    align-items:center;
    justify-content:center;
}

.history-section{
    background:#fff;
    border-radius:12px;
    padding:20px;
    border:1px solid #eee;
}

.history-remark-box{
    border-radius:12px;
    min-height:120px;
}
</style>
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$role_id = auth()->user()->role_id ;
$auth_id = auth()->user()->id ;
@endphp
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Manage Candidate</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Recruitment
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <span class="cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom"
                title="Daily Check In QR Code">
                <a href="javascript:;" class="btn btn-sm fw-semibold btn-primary text-white generate-qr-btn" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_generate" onclick="generateQr()">
                    <span>
                        <i class="mdi mdi-qrcode-scan fs-3 "></i>
                    </span>
                </a>

            </span>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a>
            <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_create_candidate">-->
            <!--    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Candidate-->
            <!--</a>-->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_paticipants">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Candidate
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="branch_filter mb-4" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Job Role</label>
                    <input type="text" class="form-control" id="job_role_fill" name="job_role_fill" placeholder="Enter Job Role" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Type</label>
                    <select id="source_type_filt" name="source_type_filt" class="select3 form-select">
                        <option value="">All</option>
                        <option value="job_fair">Job Fair</option>
                        <option value="old_data">Recruiter Database</option>
                        <option value="resource">Resource Request</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Qualification</label>
                    <select id="qualification_filt" name="qualification_filt" class="select3 form-select" onchange="qualification_change()">
                        <option value="">All</option>
                        <option value="4">HSC</option>
                        <option value="5">SSLC</option>
                        <option value="6">Below SSLC</option>
                        <option value="1">UG</option>
                        <option value="2">PG</option>
                        <option value="3">Doctorate</option>
                        <option value="Others">Others</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Major</label>
                    <select id="major_filt" name="major_filt" class="select3 form-select">
                        <option value="">All</option>

                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Experience</label>
                    <select id="exp_type_filt" name="exp_type_filt" class="select3 form-select">
                        <option value="">All</option>
                        <option value="1">Fresher</option>
                        <option value="2">Experience</option>
                    </select>
                </div>

                @if($user_id==0)
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Old Resume</label>
                    <select class="select3 form-select" name="old_resume_fill" id="old_resume_fill">
                        <option value="">All</option>
                        <option value="1">Import</option>
                        <option value="0">Not Import</option>
                    </select>
                </div>
                @endif

          

                <div class="col-lg-3 mb-2" id="">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Source</label>
                    <select id="source_name_filt" name="source_name_filt" class="select3 form-select">
                        <option value="">All Source</option>
                        @if(isset($source_list))
                        @foreach($source_list as $source)
                        <option value="{{ $source->sno }}">{{ $source->source_name }}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Applied Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="closing_date_filt" name="closing_date_filt" placeholder="Select Date" class="form-control common_datepicker" value="" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="form-select select3 " name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-sm btn-primary fw-semibold fs-6 me-2" class="filterSubmit" id="filterSubmit">Go</button>
                <a href="{{ url('/hr_recruitment/manage_candidate') }}" class="btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card primaryegc" onclick="clearDashboardFilter()">
                    <img src="{{asset('assets/egc_images/magic_menu/candidate.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="total_candidates">00</h5>
                        <span class="text-nowrap">Total Candidates</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card info dashboard-filter" onclick="applyDashboardFilter('today', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/new_badge.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="today_candidates">00</h5>
                        <span class="text-nowrap">Today Applied</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card success dashboard-filter" onclick="applyDashboardFilter('month', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/star_employee.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="month_candidates">00</h5>
                        <span class="text-nowrap">This Month</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card primary dashboard-filter" onclick="applyDashboardFilter('fresher', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/newbie.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="fresher_count">00</h5>
                        <span class="text-nowrap">Freshers</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card warning dashboard-filter" onclick="applyDashboardFilter('experienced', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/experience.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="experienced_count">00</h5>
                        <span class="text-nowrap">Experienced</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3" >
                <div class="mini-card danger dashboard-filter" onclick="applyDashboardFilter('jobfair', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/job_fair.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="job_fair_count">00</h5>
                        <span class="text-nowrap">Job Fair</span>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card walkincolor dashboard-filter" onclick="applyDashboardFilter('walkin', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/walkinacandidate.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="walkin_candidates">00</h5>
                        <span class="text-nowrap">Walk-In</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="mini-card vipcandidatecolor dashboard-filter" onclick="applyDashboardFilter('vip', this)">
                    <img src="{{asset('assets/egc_images/magic_menu/vip_candidate.png')}}" class="mini-icon">
                    <div class="mini-content">
                        <h5 id="vip_candidates">00</h5>
                        <span class="text-nowrap">VIP</span>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                        class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Job Role Name..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold text-primary"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold text-primary"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Candidate/Mobile no</th>
                                <th class="min-w-100px">Job Role/Source</th>
                                <th class="min-w-100px">Qualification</th>
                                <th class="min-w-100px">Experience</th>
                                <th class="min-w-100px">Applied Date</th>
                                <th class="min-w-100px">Applicant Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="kt_modal_qr_generate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">

        <!-- Title -->
        <div class="text-center mb-6">
            <h3 class="fw-bold text-dark mb-1">Resume QR Code</h3>
            <p class="text-muted fs-7">
            Download this QR to apply for the job
            </p>
        </div>  
        
        <!-- QR Card -->
        <div class="d-flex justify-content-center mb-6">
            <div class="qr-card text-center p-4 ">
            <div id="qr_template" class="position-relative">
                <img  src="{{ asset('assets/egc_images/job/job_common_template.jpg') }}" id="poster_preview_img" class="w-100 object-fit-cover" />
                <img id="qrImage"
                src="{{ asset('assets/egc_images/qr_code.png') }}"
                class="qr-image mb-3">
            </div>
            <!-- Actions -->
            <div class="d-flex justify-content-center gap-3">
                
                 <button class="btn btn-sm btn-light-primary"
                        data-target="download_qr_code_name"
                        onclick="copyText(this)">
                    <i class="mdi mdi-content-copy me-1"></i>
                    Copy Link
                </button>
            </div>
            </div>
        </div>

        <div class="mb-2 d-flex text-center">
            <!-- Hidden Link -->
            <span id="download_qr_code_name" class="d-none bg-light p-1 w-100 rounded scroll-x"></span>
        </div>

        </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>

<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_candidate" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Jayashree Ganesh </b> Candidate ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center py-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->

<!--begin::Modal - Approve Job Posting-->
<div class=" modal fade" id="kt_modal_select_candidate" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-check text-success" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to select <br><b class="text-success">Jayashree Ganesh </b> Candidate ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center py-8 mb-4">
                <button type="submit" class="btn btn-success me-3" data-bs-dismiss="modal">Yes,Select!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Approve Job Posting-->

<!--begin::Modal - Reject Job Posting-->
<div class=" modal fade" id="kt_modal_reject_candidate" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-xmark text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to Reject <br><b class="text-danger">Jayashree Ganesh </b> Candidate ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center py-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,Reject!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Reject Job Posting-->

<div class="modal fade" id="kt_modal_add_paticipants" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Add Candidate </h3>
                </div>

                <form id="jobApplyForm" action="{{ route('add_new_candidate') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
                    @csrf
                    <input type="hidden" name="apply_job_request_id" id="apply_job_request_id">
                    <input type="hidden" name="apply_candidate_id" id="apply_candidate_id">
                    <input type="hidden" name="apply_applicant_id" id="apply_applicant_id">
                    <input type="hidden" name="resume_check" id="resume_check">
                    <div class="row mt-2">
                        <div class="col-12 border rounded p-2 px-3">
                            <div class="row mb-3">
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Name" id="candidate_name" name="candidate_name" oninput="this.value=this.value.replace(/^\w/, txt=>txt.toUpperCase());" />
                                    <div class="text-danger" id="candidate_name_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Mobile Number<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Mobile Number" id="candidate_mobile" name="candidate_mobile" maxLength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                    <div class="text-danger" id="candidate_mobile_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Email Id<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Email Id" id="candidate_email" name="candidate_email" oninput="this.value=this.value.toLowerCase();" />
                                    <div class="text-danger" id="candidate_email_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Gender<span class="text-danger">*</span></label>
                                    <select id="candidate_gender" name="candidate_gender" class="select3 form-select">
                                        <option value="">Select Gender</option>
                                        <option value="1" selected>Male</option>
                                        <option value="2">Female</option>
                                        <option value="3">Others</option>
                                    </select>
                                    <div class="text-danger" id="candidate_gender_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Marital Status<span class="text-danger">*</span></label>
                                    <select id="candidate_marital_status" name="candidate_marital_status" class="select3 form-select">
                                        <option value="">Select Marital Status</option>
                                        <option value="1">Married</option>
                                        <option value="2">Single</option>
                                    </select>
                                    <div class="text-danger" id="candidate_marital_status_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Source<span class="text-danger">*</span></label>
                                    <select id="source_name" name="source_name" class="select3 form-select">
                                        <option value="">Select Source</option>
                                        @if(isset($source_list))
                                        @foreach($source_list as $source)
                                        <option value="{{ $source->sno }}" data-detail="{{$source->detail_check ?? 0}}">{{ $source->source_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <div class="text-danger" id="source_name_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Qualification<span class="text-danger">*</span></label>
                                    <select id="candidate_qualification" name="candidate_qualification" class="select3 form-select" onchange="qualification_change()">
                                        <option value="">Select Qualification</option>
                                        <option value="1">UG</option>
                                        <option value="2">PG</option>
                                        <option value="3">Doctorate</option>
                                        <option value="Others">Others</option>
                                    </select>
                                    <div class="text-danger" id="candidate_qualification_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="major_div">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Major<span class="text-danger">*</span></label>
                                    <select id="candidate_major" name="candidate_major" class="select3 form-select" onchange="major_change_func()">
                                        <option value="">Select Major</option>

                                    </select>
                                    <div class="text-danger" id="candidate_major_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="candidate_other_qualify_div">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Others<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Other Qualification" id="candidate_other_qualify" name="candidate_other_qualify" oninput="this.value=this.value.replace(/^\w/, txt=>txt.toUpperCase());" />
                                    <div class="text-danger" id="candidate_other_qualify_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Experience Type<span class="text-danger">*</span></label>
                                    <select id="candidate_exper_type" name="candidate_exper_type" class="select3 form-select" onchange="toggleExperience()">
                                        <option value="">Select Type</option>
                                        <option value="1" selected>Fresher</option>
                                        <option value="2">Experience</option>
                                    </select>
                                    <div class="text-danger" id="candidate_exper_type_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="experience_div" style="display:none;">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Experience<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="candidate_exper_count" name="candidate_exper_count" placeholder="Enter Experience" maxlength="2" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                    <div class="text-danger" id="candidate_exper_count_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="resume_div">
                                    <div class="row">
                                        <label class="col-lg-12 text-black mb-1 fs-6 fw-semibold">Upload Resume<span class="text-danger">*</span></label>
                                        <div class="align-items-sm-center gap-4">
                                            <img src="{{asset('assets/egc_images/docx_icon.png')}}" alt="user-avatar" class="d-block p-1 w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />


                                            <div class="button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="upload_resume" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Resume">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" id="upload_resume" name="upload_resume" class="file-in" hidden accept=".pdf,.doc,.docx" />
                                                    </label>
                                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Resume">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small">Allowed PDF, DOC, DOCX Max size of 5MB</div>
                                                <div id="resume_preview" class="mt-2 d-none">
                                                    <div class="d-flex align-items-center gap-2 text-success">
                                                        <i class="mdi mdi-file-document-outline fs-4"></i>
                                                        <span id="resume_file_name" class="fw-semibold"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-danger" id="resume_err"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                        <button id="addApplicantBtn" type="button" class="btn btn-primary" onclick="validation_func()">
                            <span id="yesBtnText">Apply</span>
                            <span id="yesBtnLoader" style="display: none;" role="status" aria-hidden="true">
                                <span class="spinner-border spinner-border-sm"></span>
                                <span class="ms-2">Applying...</span>
                            </span>

                        </button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="kt_modal_edit_applicant" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Candidate </h3>
                </div>

                <form id="jobApplyFormEdit" action="{{ route('update_candidate') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
                    @csrf
                    <input type="hidden" name="edit_candidate_id" id="edit_candidate_id">

                    <div class="row mt-2">
                        <div class="col-12 border rounded p-2 px-3">
                            <div class="row mb-3">
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Name" id="candidate_name_edit" name="candidate_name" oninput="this.value=this.value.replace(/^\w/, txt=>txt.toUpperCase());" />
                                    <div class="text-danger" id="candidate_name_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Mobile Number<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Mobile Number" id="candidate_mobile_edit" name="candidate_mobile" maxLength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                    <div class="text-danger" id="candidate_mobile_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Candidate Email Id<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Candidate Email Id" id="candidate_email_edit" name="candidate_email" oninput="this.value=this.value.toLowerCase();" />
                                    <div class="text-danger" id="candidate_email_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Gender<span class="text-danger">*</span></label>
                                    <select id="candidate_gender_edit" name="candidate_gender" class="select3 form-select">
                                        <option value="">Select Gender</option>
                                        <option value="1" selected>Male</option>
                                        <option value="2">Female</option>
                                        <option value="3">Others</option>
                                    </select>
                                    <div class="text-danger" id="candidate_gender_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Marital Status<span class="text-danger">*</span></label>
                                    <select id="candidate_marital_status_edit" name="candidate_marital_status" class="select3 form-select">
                                        <option value="">Select Marital Status</option>
                                        <option value="1">Married</option>
                                        <option value="2">Single</option>
                                    </select>
                                    <div class="text-danger" id="candidate_marital_status_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Source<span class="text-danger">*</span></label>
                                    <select id="source_name_edit" name="source_name" class="select3 form-select">
                                        <option value="">Select Source</option>
                                        @if(isset($source_list))
                                        @foreach($source_list as $source)
                                        <option value="{{ $source->sno }}" data-detail="{{$source->detail_check ?? 0}}">{{ $source->source_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <div class="text-danger" id="source_name_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Qualification<span class="text-danger">*</span></label>
                                    <select id="qualification_id_edit" name="candidate_qualification" class="select3 form-select" onchange="qualification_change_edit()">
                                        <option value="">Select Qualification</option>
                                        <option value="1">UG</option>
                                        <option value="2">PG</option>
                                        <option value="3">Doctorate</option>
                                        <option value="4">HSC</option>
                                        <option value="5">SSLC</option>
                                        <option value="6">Below SSLC</option>
                                        <option value="Others">Others</option>
                                    </select>
                                    <div class="text-danger" id="candidate_qualification_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="major_div_edit">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Major<span class="text-danger">*</span></label>
                                    <select id="major_edit" name="candidate_major" class="select3 form-select">
                                        <option value="">Select Major</option>

                                    </select>
                                    <div class="text-danger" id="candidate_major_edit_err"></div>
                                </div>

                                <div class="col-lg-4 mb-2">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Experience Type<span class="text-danger">*</span></label>
                                    <select id="candidate_exper_type_edit" name="candidate_exper_type" class="select3 form-select" onchange="toggleExperienceEdit()">
                                        <option value="">Select Type</option>
                                        <option value="1" selected>Fresher</option>
                                        <option value="2">Experience</option>
                                    </select>
                                    <div class="text-danger" id="candidate_exper_type_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-2" id="experience_div_edit" style="display:none;">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Experience<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="candidate_exper_count_edit" name="candidate_exper_count" placeholder="Enter Experience" maxlength="2" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                    <div class="text-danger" id="candidate_exper_count_edit_err"></div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-6">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                        <button id="updateApplicantBtn" type="button" class="btn btn-primary" onclick="validation_edit_func()">
                            <span id="yesBtnTextEdit">Update</span>
                            <span id="yesBtnLoaderEdit" style="display: none;" role="status" aria-hidden="true">
                                <span class="spinner-border spinner-border-sm"></span>
                                <span class="ms-2">Updating...</span>
                            </span>

                        </button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!--begin::Modal Create Candidate--->

<!--end::Modal - Create Candidate-->






<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_id" name="sts_change_id" />
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#contact_info" aria-controls="contact_info" aria-selected="false">
                                    Contact Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#work_info" aria-controls="work_info" aria-selected="false">
                                    Work Type
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_info" aria-controls="edu_info" aria-selected="false">
                                    Education Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Application" aria-controls="Application" aria-selected="false">
                                    Application Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#StaffCheckList" aria-controls="StaffCheckList" aria-selected="false">
                                    Staff Checklist
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Orientation" aria-controls="Orientation" aria-selected="false">
                                    Orientation
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Birth</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">09-Jan-2001</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Gender</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Male</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Saravanen</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Bank Manager</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Nila</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Tongue</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Languages Known</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil , English</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Children</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Studying 5th Grade</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Siblings</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">No</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Hobby</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Drawing , Shooting ,Story Writing </label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-px-150 h-auto rounded-circle"
                                                id="uploadedlogo" style="border: 2px solid #ab2b22;" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="row">

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Company Details</div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Company Details</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Management</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                            </div>
                                        </div>


                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">HR Operation</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Designation Details</div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Nick</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">07-Oct-2025</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-danger">₹ 100</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Leadership , Management , Postive</label>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Login Credentials</div>
                                        </div>


                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Other Credentials</div>
                                        </div>

                                        <h5 class="title fw-bold mt-2 text-warning">Teams Credentials</h5>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>

                                        </div>

                                        <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>

                                        </div>

                                        <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>

                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Contact Person</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Sibi Kumar</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">7485196785</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Residential Address</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">18I Gandhi Nagar Happy Street Madurai</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Permanent Address</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">122K K K Nagar D-block Madurai</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">7584967821</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 1</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">7721869435</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 2</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">9978428965</label>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Type</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Experience</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Shifted Company Count</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">2</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Total Years Of Experience</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6">
                                                    <span class="badge bg-primary text-white px-3 fs-7">3</span>
                                                </label>
                                            </div>
                                        </div>

                                        <h5 class="title fw-bold mt-2 text-warning">1st Company</h5>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <span class="badge bg-primary text-white px-3 fs-7">1</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">TCS</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000 /-</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">01-Oct-2021</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">18-Jul-2022</label>
                                            </div>
                                        </div>



                                        <h5 class="title fw-bold mt-2 text-warning">2nd Company</h5>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <span class="badge bg-primary text-white px-3 fs-7">2</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">CTS</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-danger">₹ 15,000 /-</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">27-Nov-2023</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">12-Feb-2024</label>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Attachment Details</div>
                                        </div>

                                        <div class="col-lg-12 d-flex align-items-center justify-content-start gap-3 flex-wrap py-3 px-1">

                                            <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                                <label class=" fw-semibold fs-7 text-dark">Resume</label>
                                                <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                                    style="width:100px; height:100px;" />
                                            </div>

                                            <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                                <label class=" fw-semibold fs-7 text-dark">Aadhar card</label>
                                                <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                                    style="width:100px; height:100px;" />
                                            </div>

                                            <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                                <label class=" fw-semibold fs-7 text-dark">Pan Card</label>
                                                <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                                    style="width:100px; height:100px;" />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_info" role="tabpanel">
                            <div class="row mb-2">

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-3 fw-semibold fs-7 text-dark">Course Completed</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Java , Python , C++ , C# , HTML , JS , CSS , REACT , SQL and Ruby</label>
                                    </div>
                                </div>


                                <div class="divider text-start-center">
                                    <div class="divider-text fs-5 text-primary fw-semibold my-2">Educational Details</div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning text-warning">UG</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Under Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                            <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">BBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">MKU</label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">PG</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Post Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 ">
                                            <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">MBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance And Application</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">SRM</label>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="Application" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Technical Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Java , C# , .Net ,FullStack</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Non Technical Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Sales Management , SEO Analyst</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Interview Attended Company</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <span class="badge bg-label-primary text-primary fw-semibold fs-6 rounded">EIBS</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Already Attended Interview In Elysium Groups</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Attended Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">07-10-2024 , 04-11-2024 , 12-01-2025</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Submit Original Certificate</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Travel For Official Purpose</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Joining Status</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Immediate Joining</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Joining Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">07-10-2025</label>
                                            </div>
                                        </div>


                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="StaffCheckList" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check1">
                                        <label class="fw-semibold fs-6 text-black" for="check1">Educational certificates verified (Degree, Diploma, Transcripts), experience/resume checked (previous employment verification)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check2" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check2">Identity proof verified (Aadhaar, Passport, Driving License), address proof verified (Ration Card, Utility Bill),</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check3" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check3">Official documents submitted (Joining Letter, Form 16)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check4" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check4">and alternate contact/emergency details provided (alternate mobile number, emergency contact).</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check5">
                                        <label class="fw-semibold fs-6 text-black" for="check5">Verify identity proof, address proof, and educational certificates.</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check6">
                                        <label class="fw-semibold fs-6 text-black" for="check6">Check previous experience/resume, submission of official documents, and provide alternate/emergency contact details.</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Orientation" role="tabpanel">
                            <div class="row mb-2">
                                <h5 class="title fw-bold mt-2 text-warning">Staff Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                                style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Company Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Department Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                                style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->


<!-- ai analyses -->
<div class="modal fade" id="kt_modal_ai_analyses_applicant" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class="mb-4 text-dark text-center fw-bold modal-title-ai">
                        AI Candidate Intelligence
                    </h3>
                    <p class="text-center text-muted small ai-subtitle">
                        Smart resume evaluation powered by AI-driven hiring insights
                    </p>
                </div>
                <input type="hidden" name="" id="applicant_id_hidden">
                <div class="card mb-4 shadow-sm border-1 border-primary">
                    <div class="card-body d-flex align-items-center gap-4">

                        <div class="avatar bg-label-primary rounded-circle text-center m-0 p-0">
                            <i class="mdi mdi-account fs-2 mb-0 p-0 text-primary"></i>
                        </div>

                        <div class="flex-grow-1">
                            <h5 id="cand_name" class="mb-1 fw-bold"></h5>
                            <div class="text-muted small">
                                <span id="cand_email"></span> •
                                <span id="cand_mobile"></span>
                            </div>
                            <div class="mt-1">
                                <span class="badge bg-light-info text-dark" id="cand_exp"></span>
                                <span class="badge bg-light-success text-dark" id="cand_qualification"></span>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_fill" name="company_fill" class="select3 form-select" onchange="company_change_func()">
                            <option value="">Select Company Name</option>
                            <option value="egc">Elysium Groups</option>
                            @if(isset($company_list))
                            @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="business_div">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_fill" name="entity_fill" class="select3 form-select" onchange="entity_change_func()">
                            <option value="">Select Entity Name</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>

                        </select>
                        <div class="text-danger" id="job_role_name_err"></div>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <label class="text-dark mb-1 fs-6 fw-semibold">AI Analyse Preview<span class="text-danger">*</span></label>
                            <button type="button" id="aiBtn"
                                class="btn btn-sm btn-light-primary border rounded-pill px-3 fw-bold shadow-sm mb-1"
                                onclick="generateAiAnalyse()">
                                <span class="d-flex justify-content-center align-items-center gap-1">
                                    <i class="mdi mdi-robot-outline"></i>
                                    <span>AI</span>
                                </span>

                            </button>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div id="ai_analyses_div" class="mt-3"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<div class="modal fade" id="kt_modal_vip_candidate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                    data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <h3 class="text-black">⭐ Assign VIP Candidate</h3>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white ">
                <div id="vip_loader" class="text-center py-5">
                    <div class="spinner-border text-warning"></div>
                    <div class="mt-3">
                        Loading Candidate Details...
                    </div>
                </div>
                <div class="row mb-2 mt-2">
                    
                    <div id="vip_content" class="d-none">
                        <div class="vip-profile-card">
                            <div class="d-flex align-items-center">

                                <div class="vip-avatar" id="vip_avatar">
                                    V
                                </div>

                                <div class="flex-grow-1 ms-4">

                                    <div class="d-flex align-items-center flex-wrap gap-2">

                                        <h3 class="mb-0 fw-bold" id="vip_name"></h3>
                                        <span id="vip_qualification_badge"></span>

                                    </div>

                                    <div class="mt-2">

                                        <span class="badge bg-label-primary me-2">
                                            ID : <span id="vip_applicant_id"></span>
                                        </span>

                                        <span class="badge bg-label-success me-2">
                                            <i class="mdi mdi-phone"></i>
                                            <span id="vip_mobile"></span>
                                        </span>

                                        <span class="badge bg-label-info me-2">
                                            <i class="mdi mdi-email"></i>
                                            <span id="vip_email"></span>
                                        </span>

                                    </div>

                                    <div class="row mt-3">

                                        <div class="col-lg-3">
                                            <small class="text-muted">Gender</small>
                                            <div class="fw-bold" id="vip_gender"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Experience</small>
                                            <div class="fw-bold" id="vip_experience"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Major</small>
                                            <div class="fw-bold" id="vip_major"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Source</small>
                                            <div class="fw-bold" id="vip_source"></div>
                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                        <hr>
                        <div class="mb-3">
                            <label class="form-label fw-bold">VIP Remarks</label>
                            <textarea class="form-control" id="vip_remarks" rows="4" placeholder="Why is this candidate considered VIP?" ></textarea>
                        </div>

                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <button class="btn btn-primary" id="saveVipBtn">
                            <i class="mdi mdi-star"></i>Mark As VIP
                        </button>
                    </div>
                    
                </div>

            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<div class="modal fade" id="candidateHistoryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                    data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <h3 class="text-black">Candidate Recruitment Update</h3>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white ">
                <input type="hidden" id="history_applicant_id">
                <div id="history_loader" class="text-center py-5">
                    <div class="spinner-border text-warning"></div>
                    <div class="mt-3">
                        Loading Candidate Details...
                    </div>
                </div>
                <div class="row mb-2 mt-2">
                    
                    <div id="history_content" class="d-none">
                        <div class="history-profile-card">
                            <div class="d-flex align-items-center">
                                <div class="history-avatar" id="history_avatar">
                                    V
                                </div>

                                <div class="flex-grow-1 ms-4">
                                    <div class="d-flex align-items-center flex-wrap gap-2">
                                        <h3 class="mb-0 fw-bold" id="history_name"></h3>
                                        <span id="history_qualification_badge"></span>

                                    </div>

                                    <div class="mt-2">
                                        <span class="badge bg-label-primary me-2">
                                            ID : <span id="history_applicant_id"></span>
                                        </span>

                                        <span class="badge bg-label-success me-2">
                                            <i class="mdi mdi-phone"></i>
                                            <span id="history_mobile"></span>
                                        </span>

                                        <span class="badge bg-label-info me-2">
                                            <i class="mdi mdi-email"></i>
                                            <span id="history_email"></span>
                                        </span>

                                    </div>

                                    <div class="row mt-3">
                                        <div class="col-lg-3">
                                            <small class="text-muted">Gender</small>
                                            <div class="fw-bold" id="history_gender"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Experience</small>
                                            <div class="fw-bold" id="history_experience"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Major</small>
                                            <div class="fw-bold" id="history_major"></div>
                                        </div>

                                        <div class="col-lg-3">
                                            <small class="text-muted">Source</small>
                                            <div class="fw-bold" id="history_source"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label"> Interview Date <span class="text-danger">*</span></label>
                            <input type="text" id="interview_date" class="form-control common_datepicker" placeholder="Select Interview Date" readonly>
                            <div id="interview_date_err" class="text-danger"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label"> Status<span class="text-danger">*</span></label>

                            <select id="applicant_status"  class="form-select select3" onchange="applicant_status_change()">
                                <option value="">Select Status</option>
                                <!-- <option value="Interview Attended">Interview Attended</option> -->
                                <option value="Selected">Selected</option>
                                <option value="Rejected">Rejected</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Critical">Critical</option>
                                <option value="Not Joined">Not Joined</option>
                                <!-- <option value="Offer Released">Offer Released</option>
                                <option value="Offer Accepted">Offer Accepted</option>
                                <option value="Offer Rejected">Offer Rejected</option>
                                <option value="Joined">Joined</option> -->
                            </select>
                            <div id="applicant_status_err" class="text-danger"></div>
                        </div>

                        <!-- <div class="col-md-4">
                            <label class="form-label">Followup Date</label>
                            <input type="text" id="followup_date" class="form-control common_datepicker">
                        </div> -->
                    </div>

                     <div id="selectedSection" class="row mt-3 d-none">
                        <div class="col-md-4">
                            <label>Selected Date</label>
                            <input type="text" id="selected_date" class="form-control common_datepicker" placeholder="Selected Date" readonly >
                        </div>

                        <div class="col-md-4">
                            <label>Entity</label>
                            <select id="selected_company"  class="form-select select3" onchange="histry_entity_change()">
                                <option value="" >Select Entity</option>
                                <option value="egc" >Elysium Groups</option>
                                @if(isset($entity_list))
                                    @foreach($entity_list as $elist)
                                        <option value="{{$elist->sno}}" >{{$elist->entity_name}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>

                        <div class="col-md-4">
                            <label>Job Role</label>
                            <select id="selected_job_role" class="form-select select3">
                            </select>
                        </div>

                        <!-- <div class="col-md-4 mt-3">
                            <label>Expected Salary</label>
                            <input type="text" id="expected_salary" class="form-control">
                        </div>

                        <div class="col-md-4 mt-3">
                            <label>Offered Salary</label>
                            <input type="text" id="offered_salary" class="form-control">
                        </div>
                        <div class="col-md-4 mt-3">
                            <label>Joining Date</label>
                            <input type="text" id="joining_date" class="form-control common_datepicker">
                        </div> -->
                    </div>

                    <div class="mt-3 mb-2">
                        <label>Remarks</label>
                        <textarea id="history_remarks" rows="4" class="form-control" placeholder="Enter remarks">
                        </textarea>
                    </div>

                    <hr>

                    <h5>
                        Recruitment Timeline
                    </h5>

                    <div id="historyTimeline"></div>
                    
                    <div class="d-flex justify-content-end">
                        <button class="btn btn-primary" id="saveHistoryBtn">
                            Update Candidate
                        </button>
                    </div>
                    
                </div>

            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>






<div class="modal fade" id="applicantDetailedAiModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-fullscreen-xl-down modal-xl">
        <div class="modal-content applicant-modal">
            <!-- Header -->
            <div class="modal-header border-0 shadow-sm">
                <div>
                    <h3 class="mb-0 fw-bold">
                        Applicant Analysis
                    </h3>
                    <small class="text-muted">
                        AI Recruitment Dashboard
                    </small>
                </div>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <!-- Body -->
            <div class="modal-body p-0">
                
                <div class="row g-0">
                    <!-- LEFT -->
                    <div class="col-lg-4 applicant-sidebar">
                        <div id="candidateProfile"></div>
                        
                    </div>
                    <!-- RIGHT -->
                    <div class="col-lg-8">
                        <!-- Tabs -->
                        <ul class="nav nav-pills applicant-tabs">

                            <li class="nav-item">
                                <button
                                    class="nav-link active"
                                    data-bs-toggle="pill"
                                    data-bs-target="#overviewTab">
                                    <i class="mdi mdi-view-dashboard-outline me-1"></i>
                                    Overview
                                </button>
                            </li>

                            <li class="nav-item">
                                <button
                                    class="nav-link"
                                    data-bs-toggle="pill"
                                    data-bs-target="#aiTab">
                                    <i class="mdi mdi-brain me-1"></i>
                                    AI Analysis
                                </button>
                            </li>

                            <li class="nav-item">
                                <button
                                    class="nav-link"
                                    data-bs-toggle="pill"
                                    data-bs-target="#resumeTab">
                                    <i class="mdi mdi-file-document-outline me-1"></i>
                                    Resume
                                </button>
                            </li>

                            <!-- NEW -->

                            <li class="nav-item">

                                <button
                                    class="nav-link"
                                    data-bs-toggle="pill"
                                    data-bs-target="#customResumeTab">

                                    <i class="mdi mdi-file-eye-outline me-1"></i>

                                    Custom View

                                </button>

                            </li>

                        </ul>
                        <!-- Tab Contents -->
                        <div class="tab-content p-4">
                            <div class="tab-pane fade show active" id="overviewTab"></div>
                            <div class="tab-pane fade" id="aiTab"></div>
                            <div class="tab-pane fade" id="resumeTab"></div>
                            <!-- <div class="tab-pane fade" id="timelineTab"></div> -->
                            <!-- <div class="tab-pane fade" id="documentsTab"></div> -->
                        </div>
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<style>

    .resume-text{

white-space:pre-wrap;

font-size:14px;

line-height:1.8;

max-height:700px;

overflow:auto;

background:#fafafa;

padding:20px;

border-radius:10px;

}

.timeline-item{

border-left:3px solid #0d6efd;

padding-left:20px;

margin-bottom:25px;

}

.timeline-item::before{

content:"";

width:14px;

height:14px;

background:#0d6efd;

border-radius:50%;

display:block;

margin-left:-28px;

margin-bottom:10px;

}

.timeline-card{

display:flex;

margin-bottom:30px;

position:relative;

}

.timeline-card::before{

content:"";

position:absolute;

left:25px;

top:55px;

bottom:-30px;

width:2px;

background:#dee2e6;

}

.timeline-card:last-child::before{

display:none;

}

.timeline-icon{

width:50px;

height:50px;

border-radius:50%;

background:#0d6efd;

color:#fff;

display:flex;

align-items:center;

justify-content:center;

font-size:22px;

margin-right:20px;

flex-shrink:0;

}

.timeline-content{

background:#fff;

padding:20px;

border-radius:12px;

width:100%;

box-shadow:0 3px 10px rgba(0,0,0,.08);

}
    .decision-panel{
    background:#fff;
    border-radius:16px;
    padding:30px;
    margin-bottom:25px;
    box-shadow:0 4px 16px rgba(0,0,0,.08);
}

.decision-score{
    width:120px;
    height:120px;
    border-radius:50%;
    background:#0d6efd;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:32px;
    font-weight:bold;
    margin-left:auto;
}

.metric-box{
    background:#f8f9fa;
    border-radius:12px;
    padding:18px;
    margin-top:15px;
}

.metric-title{
    color:#6c757d;
    font-size:13px;
}

.metric-value{
    font-size:18px;
    font-weight:600;
}
    .progress{
    height:8px;
    border-radius:30px;
}

.progress-bar{
    transition:width 1.5s ease;
}

.card{
    border-radius:14px;
}

.badge{
    font-size:13px;
    padding:8px 12px;
}

.alert{
    border-radius:14px;
}

.list-group-item{
    border:none;
}
    .candidate-card{

padding:25px;

}

.candidate-header{

text-align:center;

padding-bottom:25px;

border-bottom:1px solid #eee;

margin-bottom:20px;

}

.candidate-avatar{

width:90px;

height:90px;

margin:auto;

border-radius:50%;

background:#0d6efd;

color:#fff;

font-size:34px;

font-weight:700;

display:flex;

align-items:center;

justify-content:center;

margin-bottom:15px;

}

.info-card{

background:#fff;

border-radius:12px;

padding:18px;

margin-bottom:20px;

box-shadow:0 2px 8px rgba(0,0,0,.05);

}

.info-card h6{

font-weight:700;

margin-bottom:15px;

}

.score-circle{

width:90px;

height:90px;

border-radius:50%;

background:#e9f5ff;

color:#0d6efd;

font-size:24px;

font-weight:bold;

display:flex;

align-items:center;

justify-content:center;

margin:auto;

border:5px solid #0d6efd;

}
    .applicant-modal{

    border-radius:18px;

    overflow:hidden;

}

.applicant-sidebar{

    background:#f8fafc;

    border-right:1px solid #e9ecef;

    min-height:82vh;

}

.applicant-tabs{

    background:#fff;

    padding:15px;

    border-bottom:1px solid #ececec;

}

.applicant-tabs .nav-link{

    border-radius:10px;

    font-weight:600;

    color:#6c757d;

    margin-right:10px;

}

.applicant-tabs .nav-link.active{

    background:#0d6efd;

    color:#fff;

}

.modal-header{

    background:#fff;

    position:sticky;

    top:0;

    z-index:99;

}

.modal-footer{

    position:sticky;

    bottom:0;

    z-index:99;

    border-top:1px solid #eee;

}

.tab-content{

    height:74vh;

    overflow:auto;

    background:#fcfcfc;

}

/* =========================================================
   Applicant Overview
========================================================= */

.overview-hero-card {
    background: #fff;
    border: 1px solid #edf0f5;
    border-radius: 16px;
    padding: 22px;
    box-shadow: 0 4px 16px rgba(0,0,0,.04);
}

.overview-avatar {
    width: 72px;
    height: 72px;
    min-width: 72px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg,#0d6efd,#6f42c1);
    color: #fff;
    font-size: 26px;
    font-weight: 700;
}

.overview-score-wrapper {
    margin-left: auto;
}

.overview-score-circle {
    width: 112px;
    height: 112px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;

    background:
        conic-gradient(
            #0d6efd calc(var(--score) * 1%),
            #e9eef5 0
        );

    position: relative;
}

.overview-score-circle::before {
    content: "";
    position: absolute;
    width: 88px;
    height: 88px;
    border-radius: 50%;
    background: #fff;
}

.overview-score-circle > div {
    position: relative;
    z-index: 2;
    text-align: center;
}

.overview-score-circle strong {
    display: block;
    font-size: 24px;
    line-height: 1;
}

.overview-score-circle small {
    display: block;
    margin-top: 5px;
    color: #6c757d;
    font-size: 10px;
    font-weight: 600;
}

.overview-contact-chip {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: #f5f7fa;
    padding: 6px 10px;
    border-radius: 8px;
    font-size: 12px;
    color: #495057;
}

.overview-metric-card {
    background: #fff;
    border: 1px solid #edf0f5;
    border-radius: 14px;
    padding: 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    height: 100%;
}

.overview-metric-icon {
    width: 44px;
    height: 44px;
    min-width: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
}

.overview-section-card {
    border: 1px solid #edf0f5;
    box-shadow: 0 3px 12px rgba(0,0,0,.035);
}

.overview-section-icon {
    width: 42px;
    height: 42px;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.overview-role-card {
    border: 1px solid #edf0f5;
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 12px;
    background: #fff;
    transition: .2s ease;
}

.overview-role-card:hover {
    transform: translateY(-1px);
    box-shadow: 0 5px 15px rgba(0,0,0,.06);
}

.overview-role-number {
    width: 38px;
    height: 38px;
    min-width: 38px;
    border-radius: 10px;
    background: #eef4ff;
    color: #0d6efd;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
}

.overview-empty-state {
    display: flex;
    align-items: center;
    gap: 15px;
    background: #f8f9fa;
    border: 1px dashed #dce1e7;
    border-radius: 12px;
    padding: 20px;
}

.overview-empty-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #eef0f3;
    color: #6c757d;
    font-size: 21px;
}

.overview-bullet-item {
    display: flex;
    gap: 9px;
    margin-bottom: 11px;
    font-size: 13px;
    line-height: 1.55;
}

.overview-info-item {
    background: #f8fafc;
    border-radius: 10px;
    padding: 12px;
    min-height: 68px;
}


/* =========================================================
   Resume Workspace
========================================================= */

.resume-workspace {
    min-height: 100%;
}

.resume-toolbar {
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 14px;
    padding: 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    flex-wrap: wrap;
}

.resume-file-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 25px;
}

.resume-file-pdf {
    background: #fff0f0;
    color: #dc3545;
}

.resume-file-word {
    background: #eef4ff;
    color: #0d6efd;
}

.resume-file-image {
    background: #f0fff7;
    color: #198754;
}

.resume-file-text {
    background: #fff8e8;
    color: #b58105;
}

.resume-file-default {
    background: #f1f3f5;
    color: #6c757d;
}

.resume-viewer-card {
    margin-top: 15px;
    background: #e9edf2;
    border: 1px solid #dfe4ea;
    border-radius: 14px;
    overflow: hidden;
}

.resume-viewer-body {
    min-height: 680px;
    position: relative;
}

.resume-pdf-container {
    width: 100%;
    height: 680px;
    position: relative;
    background: #525659;
}

.resume-pdf-frame {
    width: 100%;
    height: 100%;
    border: 0;
    display: block;
}

.resume-pdf-loading {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #f8f9fa;
    z-index: 3;
}

.resume-image-container {
    width: 100%;
    height: 680px;
    display: flex;
    flex-direction: column;
    background: #343a40;
}

.resume-image-toolbar {
    height: 48px;
    background: #212529;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-shrink: 0;
}

.resume-image-stage {
    flex: 1;
    overflow: auto;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 30px;
}

.resume-image-preview {
    max-width: 100%;
    height: auto;
    transform-origin: top center;
    transition: transform .2s ease;
    box-shadow: 0 8px 25px rgba(0,0,0,.35);
    background: #fff;
}

.resume-document-fallback,
.resume-viewer-empty {
    min-height: 680px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 40px;
    background: #f8f9fa;
}

.resume-document-icon,
.resume-empty-icon {
    width: 80px;
    height: 80px;
    border-radius: 20px;
    background: #eef4ff;
    color: #0d6efd;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
}

.resume-native-text-viewer {
    height: 680px;
    overflow: auto;
    white-space: pre-wrap;
    padding: 30px;
    background: #fff;
    font-size: 14px;
    line-height: 1.8;
}

.resume-extracted-card {
    border: 1px solid #e8edf3;
    box-shadow: 0 3px 12px rgba(0,0,0,.035);
}

.resume-section-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: #eef4ff;
    color: #0d6efd;
    display: flex;
    align-items: center;
    justify-content: center;
}

.resume-extracted-text {
    background: #f8fafc;
    border: 1px solid #edf0f5;
    border-radius: 10px;
    padding: 18px;
    white-space: pre-wrap;
    max-height: 500px;
    overflow: auto;
    font-size: 13px;
    line-height: 1.7;
}

.resume-empty-text {
    min-height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: #6c757d;
    text-align: center;
}


/* =========================================================
   Mobile
========================================================= */

@media (max-width: 767.98px) {

    .overview-score-wrapper {
        width: 100%;
        margin-top: 15px;
        display: flex;
        justify-content: center;
    }

    .overview-hero-card {
        padding: 15px;
    }

    .resume-viewer-body,
    .resume-pdf-container,
    .resume-image-container,
    .resume-document-fallback,
    .resume-viewer-empty {
        min-height: 550px;
        height: 550px;
    }

    .resume-toolbar {
        align-items: flex-start;
    }

}

* =========================================================
   CUSTOM RESUME VIEWER
========================================================= */

.custom-resume-wrapper {
    width: 100%;
    background: #f4f6f9;
    border: 1px solid #e4e7ec;
    border-radius: 14px;
    overflow: hidden;
}


/* Toolbar */

.custom-resume-toolbar {

    min-height: 64px;

    padding: 12px 16px;

    background: #ffffff;

    border-bottom: 1px solid #e5e7eb;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    position: sticky;

    top: 0;

    z-index: 10;

}


/* File icon */

.custom-file-icon {

    width: 42px;

    height: 42px;

    border-radius: 10px;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    font-size: 23px;

    flex-shrink: 0;

}

.custom-file-icon.pdf {

    background: #fff0f0;

    color: #dc3545;

}

.custom-file-icon.word {

    background: #edf4ff;

    color: #0d6efd;

}

.custom-file-icon.image {

    background: #eefbf3;

    color: #198754;

}

.custom-file-icon.text {

    background: #f3f4f6;

    color: #6c757d;

}


/* Document information */

.custom-doc-info {

    padding: 10px 16px;

    background: #fafbfc;

    border-bottom: 1px solid #e5e7eb;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 10px;

    font-size: 13px;

    color: #6b7280;

}

.custom-doc-info > div {

    display: flex;

    align-items: center;

    gap: 7px;

}


/* PDF */

.custom-pdf-viewer {

    height: 75vh;

    min-height: 600px;

    background: #525659;

}

.custom-pdf-viewer iframe {

    width: 100%;

    height: 100%;

    border: 0;

    display: block;

}


/* Document stage */

.custom-document-stage {

    min-height: 75vh;

    max-height: 78vh;

    overflow: auto;

    padding: 35px;

    background:

        linear-gradient(
            45deg,
            #eef1f5 25%,
            transparent 25%
        ),

        linear-gradient(
            -45deg,
            #eef1f5 25%,
            transparent 25%
        ),

        linear-gradient(
            45deg,
            transparent 75%,
            #eef1f5 75%
        ),

        linear-gradient(
            -45deg,
            transparent 75%,
            #eef1f5 75%
        );

    background-size: 24px 24px;

    background-position:
        0 0,
        0 12px,
        12px -12px,
        -12px 0;
}


/* Fake Word/PDF page */

.custom-document-page {

    width: min(900px, 100%);

    margin: 0 auto;

    background: #ffffff;

    min-height: 1000px;

    box-shadow:
        0 5px 25px rgba(0,0,0,.12);

    border-radius: 2px;

    padding: 55px 65px;

}


/* Document header */

.custom-document-header {

    padding-bottom: 20px;

    margin-bottom: 25px;

    border-bottom: 1px solid #e5e7eb;

}

.custom-document-title {

    font-size: 24px;

    font-weight: 700;

    color: #111827;

}

.custom-document-meta {

    margin-top: 5px;

    color: #6b7280;

    font-size: 13px;

}


/* Document content */

.custom-document-content {

    color: #252b36;

    font-size: 14px;

    line-height: 1.8;

}


/* Resume headings */

.resume-doc-heading {

    margin-top: 28px;

    margin-bottom: 12px;

    padding-bottom: 7px;

    border-bottom: 1px solid #e5e7eb;

    color: #111827;

    font-weight: 700;

    font-size: 16px;

    display: flex;

    align-items: center;

    gap: 5px;

}

.resume-doc-heading:first-child {

    margin-top: 0;

}

.resume-doc-heading i {

    color: #0d6efd;

}


/* Paragraph */

.resume-doc-paragraph {

    margin-bottom: 8px;

    white-space: normal;

    word-break: break-word;

}


/* Bullet */

.resume-doc-bullet {

    display: flex;

    align-items: flex-start;

    gap: 4px;

    margin-bottom: 6px;

    padding-left: 8px;

}

.resume-doc-bullet-icon {

    color: #0d6efd;

    line-height: 1.7;

}

.resume-doc-spacer {

    height: 8px;

}


/* Image viewer */

.custom-image-stage {

    min-height: 650px;

    max-height: 78vh;

    overflow: auto;

    display: flex;

    align-items: flex-start;

    justify-content: center;

    padding: 30px;

    background: #f3f4f6;

}

.custom-image-preview {

    max-width: 100%;

    height: auto;

    transform-origin: top center;

    transition: transform .2s ease;

    box-shadow:
        0 8px 30px rgba(0,0,0,.15);

    background: #fff;

}


/* Empty */

.custom-resume-empty {

    min-height: 450px;

    display: flex;

    flex-direction: column;

    justify-content: center;

    align-items: center;

    text-align: center;

    background: #f8fafc;

    border-radius: 14px;

    padding: 40px;

}

.custom-resume-empty-icon {

    width: 75px;

    height: 75px;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #eef2f7;

    color: #94a3b8;

    font-size: 35px;

}


/* Mobile */

@media(max-width: 767px) {

    .custom-resume-toolbar {

        align-items: flex-start;

        flex-direction: column;

    }

    .custom-document-stage {

        padding: 10px;

        max-height: 75vh;

    }

    .custom-document-page {

        padding: 30px 22px;

        min-height: auto;

    }

    .custom-pdf-viewer {

        height: 70vh;

        min-height: 450px;

    }

}
</style>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength": 25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>



<script>
    // document.addEventListener("DOMContentLoaded", function () {
    //     // Show filter div on "Add Filter"
    //     document.getElementById('filter_btn').addEventListener('click', function () {
    //         document.getElementById('filter_div').style.display = 'block';
    //     });
    // });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);
    let auth_role_id = @json($role_id);
    let vipCheckFilter = 0;
    let walkinCheckFilter = 0;
    let dashboardFilter = '';

    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function safeJsonParse(str) {
        try {
            return JSON.parse(str);
        } catch (e) {
            return str;
        }
    }

    function buildRow(item, index) {

        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        var old_data = typeof item.old_data === 'string' ? JSON.parse(item.old_data) : item.old_data;
        var old_status = old_data ? 1 : 0;
        let statuBadge = '';
        let genderIcon = '';
        let status = item.status;

        var drive_data = typeof item.drive_data === 'string' ? JSON.parse(item.drive_data) : item.drive_data;

        var resumeURL = drive_data && drive_data.webViewLink ? drive_data.webViewLink : null;

        if (data.gender == '2') {
            genderIcon = '<i class="mdi mdi-face-woman text-info"></i>';
        } else {
            genderIcon = '<i class="mdi mdi-face-man text-danger"></i>';
        }
        
        if (!data.interview_status) {
            statuBadge = `
                    <span class="badge rounded bg-label-warning text-black fw-semibold fs-7">New Applicant</span>
                `;
        } else {
                const color = getStatusColor(
                    data.interview_status
                );
            statuBadge = `
                    <span class="badge rounded bg-label-${color} text-black fw-semibold fs-7">${data.interview_status}</span>
                `;
        }
        


        let badgeClass = '';
        let qualification = '-';
        if (data.qualification_id == '1') {
            qualification = 'UG';
            badgeClass = 'bg-label-ug';
        } else if (data.qualification_id == '2') {
            qualification = 'PG';
            badgeClass = 'bg-label-pg';
        } else if (data.qualification_id == '3') {
            qualification = 'Doctorate';
            badgeClass = 'bg-label-doctorate';
        } else if (data.qualification_id == '4') {
            qualification = 'HSC';
            badgeClass = 'bg-label-hsc';
        } else if (data.qualification_id == '5') {
            qualification = 'SSLC';
            badgeClass = 'bg-label-sslc';
        } else if (data.qualification_id == '6') {
            qualification = 'Below SSLC';
            badgeClass = 'bg-label-below-sslc';
        } else {
            qualification = 'Others';
            badgeClass = 'bg-label-others';
        }
        let qualificationId = '';
        if (parseInt(data.recruitment_id) > 0 && data.old_data) {
            try {
                const oldData = JSON.parse(data.old_data);
                qualificationId = oldData.qualification_id ?? qualificationId;

                if (qualificationId == '5') {
                    qualification = 'UG';
                    badgeClass = 'bg-label-ug';
                } else if (qualificationId == '4') {
                    qualification = 'PG';
                    badgeClass = 'bg-label-pg';
                } else if (qualificationId == '3') {
                    qualification = 'Professional Degree';
                    badgeClass = 'bg-label-pg';
                } else if (qualificationId == '2') {
                    qualification = 'Doctorate';
                    badgeClass = 'bg-label-doctorate';
                } else {
                    qualification = 'Others';
                    badgeClass = 'bg-label-others';
                }

                // console.log(qualificationId)
            } catch (e) {
                badgeClass = 'bg-label-others';
                qualification = 'Others';
            }
        }
        let resume_local_url = `{{ asset('job_applications/resume_files/${data.attachment}') }}`;

        return `
            <tr id="webhook-${item.sno}">
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${data.company_base_color || ''};"></div>
                    <div class="d-flex start gap-1">
                        <div class="align-self-center">
                            <span class="">
                                ${item.vip_check == 1
                                    ? `<img src="{{asset('assets/egc_images/magic_menu/vip_badge.png')}}" style="width:40px;height:40px;object-fit: contain;">
                                    `
                                    : ''
                                }
                            </span>
                        </div>
                      
                        <div class="d-flex align-items-start justify-content-center flex-column">
                            <div class="d-flex align-items-start justify-content-center gap-1 cursor-pointer" onclick="viewApplicantAI(${item.sno })">
                                <label class="fs-7">${data.applicant_name}</label>
                                <label class="fs-7">
                                        ${genderIcon}
                                </label>
                                
                            </div>
                            <label class="fs-7 text-dark">${data.mobile}</label>
                        </div>
                    </div>


                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                            <span class="d-block text-truncate max-w-150px fw-semibold text-black fs-7" title="${old_status == 1 ? (old_data.job_role_names || (data.display_job_role_name ?? '-')) : (data.job_fair_id > 0 ? (data.display_job_role_name ?? '-') :(data.job_role_name ? data.job_role_name : (data.display_job_role_name ?? '-')))}">
                            ${old_status == 1 ? (old_data.job_role_names || (data.display_job_role_name ?? 'Not Defined')) : (data.job_fair_id > 0 ? (data.display_job_role_name ?? 'Not Defined') :(data.job_role_name ? data.job_role_name : (data.display_job_role_name ?? 'Not Defined')))}
                            </span>
                       
                        <label class="fw-semibold fs-7 text-truncate badge bg-label-slack">
                         ${old_status == 1 ? (old_data.source_name || '-') :(data.job_fair_id > 0 ? 'Job Fair' : data.applicant_source_name)}
                        </label>
                    </div>
                </td>
                <td class="text-center">
                        <span class="fs-7 badge ${badgeClass}">${qualification || '-'}</span>
                        ${old_status == 1 ? 
                        `<span class="d-block text-truncate max-w-150px fs-8" title="${old_data.major_name || '-'}">
                            ${old_data.major_name || '-'}
                            </span>`
                        :
                        (
                            data.major !='0' && data.major ?
                            `<span class="d-block text-truncate max-w-150px fs-8" title="${data.major_name || '-'}">
                                ${data.major_name || '-'}
                            </span>`
                            :
                            ''
                            
                        )
                        
                        } 
                    
                </td>
                <td>
                    ${data.experience_id == '2' ?
                        `<label class="fs-7 fw-semibold">${old_status == 1 ? (old_data.experience_name || '-') : data.experience_count +' Years'}</label>`:
                        '<label class="fs-7 fw-semibold">Fresher</label>'
                    }
                    
                </td>

                <td>
                   <label class="fs-7 text-black fw-semibold d-flex align-items-center justify-content-start gap-1 text-nowrap">
                        <span><i class="mdi mdi-calendar-outline"></i></span>
                        ${data.created_at ? formatDate(data.created_at) : '-'}
                    </label>
                </td>
               
                <td class ="position-relative">
                    <div class="d-flex  align-items-center gap-2" >
                        ${statuBadge}
                        <span class="badge bg-primary rounded cursor-pointer fs-7" data-bs-toggle="tooltip" title="Candidate History Update" onclick="openCandidateHistory(${item.sno})">
                                <i class="mdi mdi-clipboard-text-clock fs-7"></i>
                        </span>
                    </div>
                    
                </td>
                <td>
                    <div class="d-flex gap-1">
                        ${item.vip_check == 1
                            ? `
                                <i class="mdi mdi-star text-success fs-3"></i>
                            `
                            : `<span data-bs-toggle="tooltip" title="Assign VIP Candidate">
                                <button type="button" class="btn btn-icon btn-sm btn-light-warning" onclick="openVipModal(${item.sno})">
                                    <i class="mdi mdi-star text-warning fs-3"></i>
                                </button>
                            </span>`
                        }
                    

                        ${resumeURL ? 
                        `<a href="${resumeURL}" target="_blank" class="btn btn-icon btn-sm" download data-bs-toggle="tooltip" data-bs-placement="bottom" title="Resume Download" download>
                            <span><i class="mdi mdi-tray-arrow-down fs-3 text-black"></i></span>
                        </a>`
                        :`<a href="${resume_local_url}" target="_blank" class="" >
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Resume">
                                        <i class="ms-1 mdi mdi-eye cursor-pointer text-black"></i>
                                </span>
                            </a>`
                        }

                        ${auth_user_id == 0 ?
                        `<button type="button" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_applicant" onclick="openEditModal('${item.sno}')">
                            <span><i class="mdi mdi-pencil-outline fs-3"></i></span>
                        </button>`:
                        ''
                        }
                        <button type="button" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_ai_analyses_applicant" onclick="openAiAnalysesModal('${item.sno}')">
                            <span><i class="mdi mdi-robot fs-3"></i></span>
                        </button>
                    </div>
                    
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const closing_date_filt = document.getElementById('closing_date_filt').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const exp_type_filt = document.getElementById('exp_type_filt').value;
        const source_name_filt = document.getElementById('source_name_filt').value;
        const source_type_filt = document.getElementById('source_type_filt').value;
        const qualification_filt = document.getElementById('qualification_filt').value;
        const major_filt = document.getElementById('major_filt').value;
        let old_resume_fill = "";
        if (auth_user_id == 0) {
            old_resume_fill = document.getElementById('old_resume_fill').value;
        }
        $('#total_candidates').text('00');
        $('#today_candidates').text('00');
        $('#month_candidates').text('00');
        $('#fresher_count').text('00');
        $('#experienced_count').text('00');
        $('#job_fair_count').text('00');
        $('#walkin_candidates').text('00');
        $('#vip_candidates').text('00');
        const url = `/hr_recruitment/manage_candidate?page=${page}&sorting_filter=${perpage}&search_filter=${search}&closing_date_filt=${closing_date_filt}&exp_type_filt=${exp_type_filt}&source_type_filt=${source_type_filt}&source_name_filt=${source_name_filt}&qualification_filt=${qualification_filt}&major_filt=${major_filt}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}&old_resume_fill=${old_resume_fill}&dashboard_filter=${dashboardFilter}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                $('[data-bs-toggle="tooltip"]').tooltip();

                $('#total_candidates').text(res.total);
                $('#today_candidates').text(res.today_candidates);
                $('#month_candidates').text(res.month_candidates);
                $('#fresher_count').text(res.fresher_candidates);
                $('#experienced_count').text(res.experience_candidates);
                $('#job_fair_count').text(res.job_fair_candidates);
                $('#walkin_candidates').text(res.walkin_candidates);
                $('#vip_candidates').text(res.vip_candidates || 0);
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
             <tr class="no-data-found">
                <td colspan="7" class="text-center">No Data Found</td>
            </tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);
</script>
<script>
    $('#branch_filter').click(function() {
        $('.branch_filter').slideToggle('slow');
    });
</script>
<script>
    function qualification_change() {
        var qualification_id = $('#qualification_filt').val();
        let hideMajorFor = ['4', '5', '6', 'Others'];

        // if (hideMajorFor.includes(qualification_id)) {
        //     $('#major_div').hide();
        //     $('#major_filt').val("").trigger("change");
        //     return; // stop ajax call
        // } else {
        //     $('#major_div').show();
        // }

        var majorDropdown = $('#major_filt');
        majorDropdown.empty().append('<option value="">All</option>');

        if (qualification_id) {
            $.ajax({
                url: "{{ route('major_list_by_qualification') }}",
                type: "GET",
                data: {
                    qualification_id: qualification_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            majorDropdown.append($('<option></option>').attr(
                                'value', state.sno).text(state
                                .major_name));
                        });
                        majorDropdown.append('<option value="Others">Others</option>');

                    }
                },
                error: function(error) {
                    console.error('Error fetching major:', error);
                }
            });

        }
    }
</script>
<script>
    $(document).ready(function() {
        $('.common_datepicker').datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-M-yyyy'
        });
    });
</script>

<script>
    function validation_func() {
        let err = false;

        // Full Name
        if (!$('#candidate_name').val().trim()) {
            $('#candidate_name_err').text('Full Name is required.');
            err = true;
        } else {
            $('#candidate_name_err').text('');
        }

        // Gender
        if (!$('#candidate_gender').val()) {
            $('#candidate_gender_err').text('Gender is required.');
            err = true;
        } else {
            $('#candidate_gender_err').text('');
        }

        // Mobile Number (must be exactly 10 digits)
        const mobile = $('#candidate_mobile').val().trim();
        const mobilePattern = /^[0-9]{10}$/;

        if (!mobile) {
            $('#candidate_mobile_err').text('Mobile Number is required.');
            err = true;
        } else if (!mobilePattern.test(mobile)) {
            $('#candidate_mobile_err').text('Mobile Number must be exactly 10 digits.');
            err = true;
        } else {
            $('#candidate_mobile_err').text('');
        }

        // Email
        const email = $('#candidate_email').val().trim();
        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!email) {
            $('#candidate_email_err').text('Email ID is required.');
            err = true;
        } else if (!emailPattern.test(email)) {
            $('#candidate_email_err').text('Enter a valid Email ID.');
            err = true;
        } else {
            $('#candidate_email_err').text('');
        }

        // Marital Status
        if (!$('#candidate_marital_status').val()) {
            $('#candidate_marital_status_err').text('Marital Status is required.');
            err = true;
        } else {
            $('#candidate_marital_status_err').text('');
        }

        // Qualification
        if (!$('#candidate_qualification').val()) {
            $('#candidate_qualification_err').text('Qualification is required.');
            err = true;
        } else {
            $('#candidate_qualification_err').text('');
        }
        if (!$('#candidate_major').val()) {
            $('#candidate_major_err').text('Major is required.');
            err = true;
        } else {
            if ($('#candidate_major').val() == 'Others') {
                if (!$('#candidate_other_qualify').val()) {
                    $('#candidate_other_qualify_err').text('Qualification is required.');
                    err = true;
                } else {
                    $('#candidate_other_qualify_err').text('');
                }
            } else {
                $('#candidate_major_err').text('');
            }

        }

        // Experience Type
        const experType = $('#candidate_exper_type').val();
        if (!experType) {
            $('#candidate_exper_type_err').text('Please select Fresher or Experience.');
            err = true;
        } else {
            $('#candidate_exper_type_err').text('');
        }

        // Experience Count (only if Experience selected)
        if (experType === '2') {
            const experCount = $('#candidate_exper_count').val().trim();
            if (!experCount) {
                $('#candidate_exper_count_err').text('Experience is required.');
                err = true;
            } else {
                $('#candidate_exper_count_err').text('');
            }
        } else {
            $('#candidate_exper_count_err').text('');
        }

        // Resume
        if ($('#resume_check').val() == '1') {
            $('#resume_err').text('');
        } else {
            if (!$('#upload_resume').val()) {
                $('#resume_err').text('Resume is required.');
                err = true;
            } else {
                $('#resume_err').text('');
            }
        }


        // Source
        if (!$('#source_name').val()) {
            $('#source_name_err').text('Source is required.');
            err = true;
        } else {
            $('#source_name_err').text('');
        }

        // Submit if no errors
        if (!err) {
            submit_form();
        }
    }
</script>
<script>
    let resumeParsedmajor = null;

    function submit_form() {
        const form = document.getElementById("jobApplyForm");
        const submitBtn = document.getElementById("addApplicantBtn");
        const submitBtnText = document.getElementById("yesBtnText");
        const submitBtnLoader = document.getElementById("yesBtnLoader");

        if (form) {
            submitBtn.disabled = true;
            submitBtnText.style.display = "none"; // Hide "Yes"
            submitBtnLoader.style.display = "inline-block"; // Show loader

            // Create FormData manually
            const formData = new FormData(form);

            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    // console.log("Success:", response);
                    if (response.status == '200') {
                        window.location.href = '/hr_recruitment/manage_candidate/';
                        submitBtn.disabled = false;
                        submitBtnText.style.display = "inline-block"; // Show "Yes" again
                        submitBtnLoader.style.display = "none"; // Hide loader
                    } else {
                        toastr.error(response.message);
                        // Re-enable the button and reset the text
                        submitBtn.disabled = false;
                        submitBtnText.style.display = "inline-block"; // Show "Yes" again
                        submitBtnLoader.style.display = "none"; // Hide loader
                    }
                },
                error: function(err) {
                    console.error("Error:", err);
                    toastr.error(err.responseJSON.message || 'An error occurred while submitting the form.');
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                    submitBtnText.style.display = "inline-block"; // Show "Yes" again
                    submitBtnLoader.style.display = "none"; // Hide loader
                }
            });
        }
    }

    function qualification_change() {
        var qualification_id = $('#candidate_qualification').val();

        var majorDropdown = $('#candidate_major');
        majorDropdown.empty().append('<option value="">Select Major</option>');

        if (qualification_id) {
            $.ajax({
                url: "{{ route('major_list_by_qualification') }}",
                type: "GET",
                data: {
                    qualification_id: qualification_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            majorDropdown.append($('<option></option>').attr(
                                'value', state.sno).text(state
                                .major_name));
                        });
                        majorDropdown.append('<option value="Others">Others</option>');

                        if (resumeParsedmajor) {
                            $('#candidate_major').val(resumeParsedmajor).trigger('change');
                        }

                    }
                },
                error: function(error) {
                    console.error('Error fetching major:', error);
                }
            });

        }
    }
    major_change_func()

    function major_change_func() {
        var candidate_major = $('#candidate_major').val();
        if (candidate_major == 'Others') {
            $('#candidate_other_qualify_div').show();
        } else {
            $('#candidate_other_qualify_div').hide();
        }

    }

    $('#upload_resume').on('change', function() {

        const file = this.files[0];

        if (!file) return;

        const fileName = file.name;

        // show file name
        $('#resume_file_name').text(fileName);
        $('#resume_preview').removeClass('d-none');

        // change icon preview
        const ext = fileName.split('.').pop().toLowerCase();

        let icon = "{{asset('assets/egc_images/docx_icon.png')}}";

        if (ext === 'pdf') {
            icon = "{{asset('assets/egc_images/pdf_icon.png')}}";
        }

        $('#uploadedlogo').attr('src', icon);

    });

    // $('#upload_resume').on('change', function () {
    //     const file = this.files[0];
    //     if (!file) return;

    //     const formData = new FormData();
    //     formData.append('upload_resume', file);
    //     formData.append('_token', '{{ csrf_token() }}');

    //     $.ajax({
    //         url: "{{ route('extract_resume') }}",
    //         type: "POST",
    //         data: formData,
    //         processData: false,
    //         contentType: false,
    //         success: function(response) {
    //             if(response.status === 200) {
    //                 const data = response.data;

    //                 $('#candidate_name').val(data.candidate_name);
    //                 $('#candidate_email').val(data.candidate_email);
    //                 $('#candidate_mobile').val(data.candidate_mobile);

    //                 if(data.candidate_gender) {
    //                     $('#candidate_gender').val(data.candidate_gender).trigger('change');
    //                 }

    //                 if(data.candidate_qualification) {
    //                     let qualMap = {'UG':1,'PG':2,'Doctorate':3,'Others':'Others'};
    //                     $('#candidate_qualification').val(qualMap[data.candidate_qualification] || '').trigger('change');
    //                 }

    //                 if(data.candidate_exper_count) {
    //                     $('#candidate_exper_type').val(2).trigger('change'); // set Experience
    //                     $('#experience_div').show();
    //                     $('#candidate_exper_count').val(data.candidate_exper_count);
    //                 }

    //                 toastr.success('Resume parsed successfully!');
    //             }
    //         },
    //         error: function(err) {
    //             console.error(err);
    //             toastr.error('Failed to parse resume.');
    //         }
    //     });
    // });

    $('.file-reset').on('click', function() {

        $('#upload_resume').val('');
        $('#resume_preview').addClass('d-none');

        $('#uploadedlogo').attr(
            'src',
            "{{asset('assets/egc_images/docx_icon.png')}}"
        );

    });

    $('#upload_resume').on('change', function() {

        const submitBtn = document.getElementById("addApplicantBtn");
        const submitBtnText = document.getElementById("yesBtnText");
        const submitBtnLoader = document.getElementById("yesBtnLoader");

        const file = this.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('upload_resume', file);
        formData.append('_token', '{{ csrf_token() }}');

        submitBtn.disabled = true;
        submitBtnText.style.display = "none";
        submitBtnLoader.style.display = "inline-block";

        $.ajax({
            url: "{{ route('extract_resume') }}",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.status === 200) {
                    submitBtn.disabled = false;
                    submitBtnText.style.display = "inline-block";
                    submitBtnLoader.style.display = "none";
                    const data = response.data;

                    // Set the parsed data in the respective form fields
                    $('#candidate_name').val(data.candidate_name);
                    $('#candidate_email').val(data.candidate_email);
                    $('#candidate_mobile').val(data.candidate_mobile);

                    if (data.candidate_gender) {
                        $('#candidate_gender').val(data.candidate_gender).trigger('change');
                    }

                    $('#candidate_qualification').val(data.candidate_qualification).trigger('change');
                    resumeParsedmajor = data.candidate_major;


                    if (data.candidate_other_major) {
                        $('#candidate_other_qualify').val(
                            data.candidate_other_major
                        );
                    }



                    // Store the parsed major for later use


                    if (data.candidate_exper_count) {
                        $('#candidate_exper_type').val(2).trigger('change'); // Set experience type as experienced
                        $('#experience_div').show();
                        $('#candidate_exper_count').val(data.candidate_exper_count);
                    }

                    // Handle marital status
                    if (data.candidate_marital_status) {
                        $('#candidate_marital_status').val(data.candidate_marital_status).trigger('change');
                    }

                    toastr.success('Resume parsed successfully!');
                }
            },
            error: function(err) {
                console.error(err);
                toastr.error('Failed to parse resume.');
                submitBtn.disabled = false;
                submitBtnText.style.display = "inline-block";
                submitBtnLoader.style.display = "none";
            },
            beforeSend: function() {
                submitBtn.disabled = true;
                submitBtnText.style.display = "none";
                submitBtnLoader.style.display = "inline-block";
            },
            complete: function() {
                submitBtn.disabled = false;
                submitBtnText.style.display = "inline-block";
                submitBtnLoader.style.display = "none";
            }
        });
    });

    function toggleExperience() {
        var experType = document.getElementById('candidate_exper_type').value;
        var experienceDiv = document.getElementById('experience_div');

        if (experType === '2') { // Experience selected
            experienceDiv.style.display = 'block';
        } else {
            experienceDiv.style.display = 'none';
            document.getElementById('candidate_exper_count').value = ''; // Clear experience input
        }
    }

    function toggleExperienceEdit() {
        var experType = document.getElementById('candidate_exper_type_edit').value;
        var experienceDiv = document.getElementById('experience_div_edit');

        if (experType === '2') { // Experience selected
            experienceDiv.style.display = 'block';
        } else {
            experienceDiv.style.display = 'none';
            document.getElementById('candidate_exper_count_edit').value = ''; // Clear experience input
        }
    }
</script>
<script>
    let edit_major = null;

    function openEditModal(id) {
        $('#edit_candidate_id').val(id);
        if (id) {
            $.ajax({
                url: '/candidate_details_by_id',
                type: "GET",
                data: {
                    applicant_id: id
                },
                success: function(res) {
                    if (res.status == 200) {
                        let applicant = res.data;
                        console.log(applicant)
                        $('#candidate_name_edit').val(applicant.applicant_name);
                        $('#candidate_mobile_edit').val(applicant.mobile);
                        $('#candidate_email_edit').val(applicant.email);
                        $('#candidate_gender_edit').val(applicant.gender).change();
                        $('#candidate_marital_status_edit').val(applicant.marital_status_id || '').change();
                        $('#source_name_edit').val(applicant.source_id).change();
                        $('#qualification_id_edit').val(applicant.qualification_id).change();
                        edit_major = applicant.major;
                        $('#candidate_exper_type_edit').val(applicant.experience_id).change();
                        $('#candidate_exper_count_edit').val(applicant.experience_count);
                    }
                },
                error: function(err) {

                }
            })
        }
    }

    function qualification_change_edit() {
        var qualification_id = $('#qualification_id_edit').val();

        let majorWrapper = $('#major_edit_div');
        var majorDropdown = $('#major_edit');
        majorDropdown.empty().append('<option value="">Select Major</option>');

        let hideMajorFor = ['4', '5', '6', 'Others'];

        if (hideMajorFor.includes(qualification_id)) {
            majorWrapper.hide();
            majorDropdown.val("").trigger("change");

            return; // stop ajax call
        } else {
            majorWrapper.show();
        }



        if (qualification_id) {
            $.ajax({
                url: "{{ route('major_list_by_qualification') }}",
                type: "GET",
                data: {
                    qualification_id: qualification_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            majorDropdown.append($('<option></option>').attr(
                                'value', state.sno).text(state
                                .major_name));
                        });
                        majorDropdown.append('<option value="Others">Others</option>');

                        if (edit_major) {
                            $('#major_edit').val(edit_major).trigger('change');
                        }

                    }
                },
                error: function(error) {
                    console.error('Error fetching major:', error);
                }
            });

        }
    }

    function validation_edit_func() {
        let err = false;

        // Full Name
        if (!$('#candidate_name_edit').val().trim()) {
            $('#candidate_name_edit_err').text('Full Name is required.');
            err = true;
        } else {
            $('#candidate_name_edit_err').text('');
        }

        // Gender
        if (!$('#candidate_gender_edit').val()) {
            $('#candidate_gender_edit_err').text('Gender is required.');
            err = true;
        } else {
            $('#candidate_gender_edit_err').text('');
        }

        // Mobile Number (must be exactly 10 digits)
        const mobile = $('#candidate_mobile_edit').val().trim();
        const mobilePattern = /^[0-9]{10}$/;

        if (!mobile) {
            $('#candidate_mobile_edit_err').text('Mobile Number is required.');
            err = true;
        } else if (!mobilePattern.test(mobile)) {
            $('#candidate_mobile_edit_err').text('Mobile Number must be exactly 10 digits.');
            err = true;
        } else {
            $('#candidate_mobile_edit_err').text('');
        }

        // Email
        const email = $('#candidate_email_edit').val().trim();
        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!email) {
            $('#candidate_email_edit_err').text('Email ID is required.');
            err = true;
        } else if (!emailPattern.test(email)) {
            $('#candidate_email_edit_err').text('Enter a valid Email ID.');
            err = true;
        } else {
            $('#candidate_email_edit_err').text('');
        }

        // Marital Status
        if (!$('#candidate_marital_status_edit').val()) {
            $('#candidate_marital_status_edit_err').text('Marital Status is required.');
            err = true;
        } else {
            $('#candidate_marital_status_edit_err').text('');
        }

        // Qualification
        if (!$('#qualification_id_edit').val()) {
            $('#candidate_qualification_edit_err').text('Qualification is required.');
            err = true;
        } else {
            $('#candidate_qualification_edit_err').text('');
        }
        if (!$('#major_edit').val()) {
            $('#candidate_major_edit_err').text('Major is required.');
            err = true;
        }

        // Experience Type
        const experType = $('#candidate_exper_type_edit').val();
        if (!experType) {
            $('#candidate_exper_type_edit_err').text('Please select Fresher or Experience.');
            err = true;
        } else {
            $('#candidate_exper_type_edit_err').text('');
        }

        // Experience Count (only if Experience selected)
        if (experType === '2') {
            const experCount = $('#candidate_exper_count_edit').val().trim();
            if (!experCount) {
                $('#candidate_exper_count_edit_err').text('Experience is required.');
                err = true;
            } else {
                $('#candidate_exper_count_edit_err').text('');
            }
        } else {
            $('#candidate_exper_count_edit_err').text('');
        }

        // Source
        if (!$('#source_name_edit').val()) {
            $('#source_name_edit_err').text('Source is required.');
            err = true;
        } else {
            $('#source_name_edit_err').text('');
        }

        // Submit if no errors
        if (!err) {
            edit_submit_form();
        }
    }

    function edit_submit_form() {
        const form = document.getElementById("jobApplyFormEdit");
        const submitBtn = document.getElementById("updateApplicantBtn");
        const submitBtnText = document.getElementById("yesBtnTextEdit");
        const submitBtnLoader = document.getElementById("yesBtnLoaderEdit");

        console.log('working');

        if (form) {
            submitBtn.disabled = true;
            submitBtnText.style.display = "none"; // Hide "Yes"
            submitBtnLoader.style.display = "inline-block"; // Show loader

            // Create FormData manually
            const formData = new FormData(form);

            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    // console.log("Success:", response);
                    if (response.status == '200') {
                        window.location.href = '/hr_recruitment/manage_candidate/';
                        submitBtn.disabled = false;
                        submitBtnText.style.display = "inline-block"; // Show "Yes" again
                        submitBtnLoader.style.display = "none"; // Hide loader
                         toastr.success(response.message);
                    } else {
                        toastr.error(response.message);
                        // Re-enable the button and reset the text
                        submitBtn.disabled = false;
                        submitBtnText.style.display = "inline-block"; // Show "Yes" again
                        submitBtnLoader.style.display = "none"; // Hide loader
                    }
                },
                error: function(err) {
                    console.error("Error:", err);
                    toastr.error(err.message || 'An error occurred while submitting the form.');
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                    submitBtnText.style.display = "inline-block"; // Show "Yes" again
                    submitBtnLoader.style.display = "none"; // Hide loader
                }
            });
        }
    }
</script>
<script>
    function openAiAnalysesModal(id) {

        $('#applicant_id_hidden').val(id);

        if (id) {
            $.ajax({
                url: '/candidate_details_by_id',
                type: "GET",
                data: {
                    applicant_id: id
                },
                success: function(res) {
                    if (res.status == 200) {
                        let a = res.data;
                        $('#cand_name').text(a.applicant_name);
                        $('#cand_email').text(a.email);
                        $('#cand_mobile').text(a.mobile);

                        let expText = a.experience_id == '1' ?
                            'Fresher' :
                            a.experience_count + ' Years Experience';

                        $('#cand_exp').text(expText);
                        // $('#cand_qualification').text(a.qualification ?? '-');
                    }
                },
                error: function(err) {

                }
            })
        }

    }
    var aiInProgress = false;

    function generateAiAnalyse() {

        if (aiInProgress) return;
        // 1. Get Form Data
        let jobRoleName = $('#job_role_name option:selected').text(); // Get the text (e.g. "Software Engineer")
        let applicant_id = $('#applicant_id_hidden').val(); // Get the ID

        if (!jobRoleName) {
            $('#job_role_name_err').text("Select Job Role before generating AI.");
            return;
        } else {
            $('#job_role_name_err').text("");
        }

        aiInProgress = true;
        $('#ai_analyses_div').html('<div class="ai-loading rounded"></div>');

        $("#aiBtn")
            .prop("disabled", true)
            .html(`<span class="spinner-border spinner-border-sm me-1"></span>Generating...`);



        $.ajax({
            url: "{{ route('generate_ai_anlyse_by_resume') }}",
            type: 'POST',
            data: {
                job_role_name: jobRoleName.trim(),
                applicant_id: applicant_id,
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },

            success: function(response) {

                if (response.status === 200 && response.data) {
                    let aiData = response.data;

                    if (typeof aiData === "string") {
                        try {
                            aiData = JSON.parse(aiData);
                        } catch (e) {
                            console.error("Invalid JSON fallback", e);
                            return;
                        }
                    }

                    renderAIResult(aiData);
                }
            },

            error: function(error) {
                console.error('AI Error:', error);
            },

            complete: function() {
                aiInProgress = false;

                $("#aiBtn")
                    .prop("disabled", false)
                    .html(`<span class="d-flex justify-content-center align-items-center gap-1">
                                <i class="mdi mdi-robot-outline"></i><span>AI</span>
                            </span>`);
            }
        });
    }
</script>
<script>
    function company_change_func() {
        var countryId = $('#company_fill').val();
        var stateDropdown = $('#entity_fill');
        var jobRoleDropdown = $('#job_role_name');
        stateDropdown.empty().append('<option value="">Select Entity</option>');
        jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

        if (countryId == 'egc') {
            let entity_id = 0;
            $('#business_div').addClass('d-none');

            $.ajax({
                url: "{{ route('get_job_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            jobRoleDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .text(state.job_position_name));
                        });

                    }
                },
                error: function(error) {
                    console.error('Error fetching Job Role:', error);
                }
            });

        } else {
            $('#business_div').removeClass('d-none');
            if (countryId != '') {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: {
                        company_id: countryId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                    'value', state.sno).text(state
                                    .entity_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        }


    }

    function entity_change_func() {
        var entity_id = $('#entity_fill').val();

        var jobRoleDropdown = $('#job_role_name');

        jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');
        if (entity_id) {
            // Fetch and populate states based on selected country
            // Job role dropdown
            $.ajax({
                url: "{{ route('get_job_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            jobRoleDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .text(state.job_position_name));
                        });

                    }
                },
                error: function(error) {
                    console.error('Error fetching Job Role:', error);
                }
            });
        }
    }
</script>

<script>
    function renderAIResult(data) {

        let html = `
    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="row text-center mb-4">

                ${scoreBox('Overall Match', data.overall_match_score, 'primary')}
                ${scoreBox('ATS Score', data.ats_keyword_match_score, 'info')}
                ${scoreBox('Skills', data.skills_alignment_score, 'success')}
                ${scoreBox('Experience', data.experience_relevance_score, 'warning')}
                ${scoreBox('Impact', data.impact_metrics_score, 'danger')}

            </div>

            <div class="row">

                <div class="col-md-6">
                    ${listCard('Strengths', data.strengths, 'success')}
                    ${listCard('Missing Skills', data.missing_keywords, 'warning')}
                </div>

                <div class="col-md-6">
                    ${listCard('Weaknesses', data.weaknesses, 'danger')}
                    ${listCard('Improvements', data.resume_improvements, 'primary')}
                </div>

            </div>

            <div class="mt-4">
                <h6 class="fw-bold">Optimized Summary</h6>
                <div class="p-3 bg-light rounded">${data.optimized_summary}</div>
            </div>

        </div>
    </div>`;

        $('#ai_analyses_div').html(html);
    }

    function scoreBox(title, value, color) {
        return `
    <div class="col">
        <div class="p-3 border rounded bg-light">
            <h6>${title}</h6>
            <h4 class="text-${color}">${value}%</h4>
        </div>
    </div>`;
    }

    function listCard(title, items, color) {
        let list = items.map(i => `<li>${i}</li>`).join('');
        return `
    <div class="mb-3">
        <h6 class="text-${color} fw-bold">${title}</h6>
        <ul class="small">${list}</ul>
    </div>`;
    }
</script>
<script>
        function generateQr() {
            // Reset UI
            $('#download_qr_code_name').addClass('d-none').text('');
            $('#qrImage').attr('src', '{{ asset("assets/egc_images/qr_code.png") }}');

            fetch(`/gen_job_common_qr/generate-qr`)
                .then(res => res.json())
                .then(data => {

                    if (data.status !== 200 || !data.qr_base64) {
                        toastr.error('QR generation failed');
                        return;
                    }

                    // Show QR
                    $('#qrImage')
                        .attr('src', data.qr_base64)
                        .fadeIn(200);

                    // Store link for copy
                    $('#download_qr_code_name')
                        .removeClass('d-none')
                        .text(data.link);
                      downloadFullPoster(data.qr_base64, 'Resume_OR_Code');
                    // Auto download (optional UX)
                    // setTimeout(() => {
                    //     const link = document.createElement('a');
                    //     link.href = data.qr_base64;
                    //     link.download = `${event_name}-qr-code.png`;
                    //     document.body.appendChild(link);
                    //     link.click();
                    //     document.body.removeChild(link);
                    // }, 400);
                })
                .catch(err => {
                    console.error(err);
                    toastr.error('Something went wrong');
                });
        }

        function downloadFullPoster(qrBase64, event_name) {

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            canvas.width = 3508;
            canvas.height = 4961;

            const template = new Image();
            const qr = new Image();

            template.crossOrigin = "anonymous";
            qr.crossOrigin = "anonymous";

            template.src = "{{ asset('assets/egc_images/job/job_common_template.jpg') }}";
            qr.src = qrBase64;

            // Wait until BOTH images are loaded
            Promise.all([
                new Promise(resolve => template.onload = resolve),
                new Promise(resolve => qr.onload = resolve)
            ]).then(() => {

                // Draw template
                ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

                // 🔥 Adjust these values if needed
                const qrWidth = 1468;
                const qrHeight = 1468;

                const qrX = 1014;    // adjust if needed
                const qrY = 1254;    // adjust if needed

                ctx.drawImage(qr, qrX, qrY, qrWidth, qrHeight);

                // Convert to blob (better than toDataURL for large images)
                canvas.toBlob(function(blob) {

                    const url = URL.createObjectURL(blob);

                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `${event_name}-job-fair-poster.png`;
                    document.body.appendChild(a);
                    a.click();

                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);

                }, "image/png");

            }).catch(err => {
                console.error(err);
                toastr.error("Poster generation failed");
            });
        }



        function copyText(element) {

            const targetId = element.getAttribute('data-target');
            const targetEl = document.getElementById(targetId);

            if (!targetEl || !targetEl.textContent.trim()) {
                toastr.warning('Nothing to copy');
                return;
            }

            const text = targetEl.textContent.trim();

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text)
                    .then(() => successCopy(element))
                    .catch(() => fallbackCopy(text, element));
            } else {
                fallbackCopy(text, element);
            }
        }

        function fallbackCopy(text, element) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';

            document.body.appendChild(textarea);
            textarea.select();

            try {
                document.execCommand('copy');
                successCopy(element);
            } catch {
                toastr.error('Copy failed');
            }

            document.body.removeChild(textarea);
        }

        function successCopy(element) {
            toastr.success('Link copied');

            // Small UX feedback
            const icon = element.querySelector('i');
            icon.classList.replace('mdi-content-copy', 'mdi-check');
            icon.classList.add('text-success');

            setTimeout(() => {
                icon.classList.replace('mdi-check', 'mdi-content-copy');
                icon.classList.remove('text-success');
            }, 1200);
        }
</script>
<script>
    let vipApplicantId = null;

    function openVipModal(id)
    {
        vipApplicantId = id;

        $('#kt_modal_vip_candidate').modal('show');

        $('#vip_loader').removeClass('d-none');
        $('#vip_content').addClass('d-none');

        $.ajax({
            url: "{{ route('candidate.vip.details') }}",
            method: "GET",
            data: {
                sno: id
            },

            beforeSend:function(){

                $('#vip_loader').removeClass('d-none');
                $('#vip_content').addClass('d-none');

            },

            success:function(res){

                if(!res.status){
                    toastr.error('Candidate not found');
                    return;
                }

                renderVipCandidate(res.data);

                $('#vip_loader').addClass('d-none');
                $('#vip_content').removeClass('d-none');
            },

            error:function(){

                toastr.error(
                    'Unable to load candidate details'
                );

                $('#vip_loader').addClass('d-none');
            }
        });
    }

    function renderVipCandidate(d)
    {
        // Avatar
        $('#vip_avatar').html(
            d.applicant_name
            ? d.applicant_name.charAt(0).toUpperCase()
            : 'C'
        );

        // Basic Details
        $('#vip_name').text(d.applicant_name || '-');
        $('#vip_applicant_id').text(d.applicant_id || '-');
        $('#vip_mobile').text(d.mobile || '-');
        $('#vip_email').text(d.email || '-');
        $('#vip_source').text(d.source_name || '-');

        // Gender
        let gender = 'Unknown';

        if (d.gender == 1 || d.gender == '1') {
            gender = 'Male';
        } else if (d.gender == 2 || d.gender == '2') {
            gender = 'Female';
        }

        $('#vip_gender').html(`
            <span class="badge bg-light-primary text-primary">
                ${gender}
            </span>
        `);

        // Qualification Badge
        let qualification = 'Others';
        let badgeClass = 'bg-secondary';

        if (d.qualification_id == '1') {
            qualification = 'UG';
            badgeClass = 'bg-success';
        } else if (d.qualification_id == '2') {
            qualification = 'PG';
            badgeClass = 'bg-primary';
        } else if (d.qualification_id == '3') {
            qualification = 'Doctorate';
            badgeClass = 'bg-dark';
        } else if (d.qualification_id == '4') {
            qualification = 'HSC';
            badgeClass = 'bg-info';
        } else if (d.qualification_id == '5') {
            qualification = 'SSLC';
            badgeClass = 'bg-warning text-dark';
        } else if (d.qualification_id == '6') {
            qualification = 'Below SSLC';
            badgeClass = 'bg-danger';
        }

        // Old Recruitment Data Override
        if (parseInt(d.recruitment_id) > 0 && d.old_data) {

            try {

                const oldData = JSON.parse(d.old_data);

                switch(oldData.qualification_id){

                    case '5':
                        qualification = 'UG';
                        badgeClass = 'bg-success';
                        break;

                    case '4':
                        qualification = 'PG';
                        badgeClass = 'bg-primary';
                        break;

                    case '3':
                        qualification = 'Professional Degree';
                        badgeClass = 'bg-info';
                        break;

                    case '2':
                        qualification = 'Doctorate';
                        badgeClass = 'bg-dark';
                        break;

                    default:
                        qualification = 'Others';
                        badgeClass = 'bg-secondary';
                }

            } catch (e) {
                console.log(e);
            }
        }

        $('#vip_qualification_badge').html(`
            <span class="badge ${badgeClass}">
                ${qualification}
            </span>
        `);

        // Major
        let majorName = '-';

        if (
            d.major &&
            d.major != '0' &&
            d.major_name
        ) {
            majorName = d.major_name;
        }

        $('#vip_major').text(majorName);

        // Experience
        let experienceText = 'Fresher';

        if (
            d.experience_id == '2' ||
            d.experience_id == 2
        ) {
            experienceText =
                (d.experience_count || 0) + ' Years';
        }

        $('#vip_experience').html(`
            <span class="badge bg-light-success text-success">
                ${experienceText}
            </span>
        `);

        // VIP Remarks
        $('#vip_remarks').val(
            d.vip_remarks || ''
        );

    }


    $('#saveVipBtn').click(function () {

        $.ajax({

            url: "{{ route('candidate.mark.vip') }}",

            type: "POST",

            data: {

                _token: "{{ csrf_token() }}",

                applicant_id: vipApplicantId,

                remarks: $('#vip_remarks').val()

            },

            beforeSend: function () {

                $('#saveVipBtn')
                    .prop('disabled', true);

            },

            success: function (res) {

                toastr.success(res.message);

                $('#kt_modal_vip_candidate')
                    .modal('hide');

                loadThemes();

            },

            complete: function () {

                $('#saveVipBtn')
                    .prop('disabled', false);

            }
        });

    });
</script>
<script>
    function applyDashboardFilter(type, element)
    {
        if (dashboardFilter === type)
        {
            dashboardFilter = '';

            $('.dashboard-filter').removeClass(
                'active-dashboard-filter'
            );
        }
        else
        {
            dashboardFilter = type;

            $('.dashboard-filter').removeClass(
                'active-dashboard-filter'
            );

            $(element).addClass(
                'active-dashboard-filter'
            );
        }

        loadThemes(1);
    }

    function clearDashboardFilter()
    {
        dashboardFilter = '';

        $('.dashboard-filter').removeClass(
            'active-dashboard-filter'
        );

        loadThemes(1);
    }
</script>
<script>
    function openCandidateHistory(id)
    {
        $('#candidateHistoryModal').modal('show');

        $('#history_applicant_id').val(id);

        $('#history_loader').removeClass('d-none');
        $('#history_content').addClass('d-none');

        

        $('#historyTimeline').html('');

        $.ajax({
            url: "{{ route('candidate.history.details') }}",
            type: "GET",
            data: {
                applicant_id: id
            },
            beforeSend:function(){
                $('#history_loader').removeClass('d-none');
                $('#history_content').addClass('d-none');

            },
            success: function(res)
            {
                if(!res.status){
                    toastr.error('Candidate not found');
                    return;
                }

                renderHistoryCandidate(res.candidate);
                renderHistoryTimeline(res.history);
              

                $('#history_loader').addClass('d-none');
                $('#history_content').removeClass('d-none');
            },
            error:function(){
                toastr.error('Unable to load candidate details');
                $('#history_loader').addClass('d-none');
            }
        });
    }

    function applicant_status_change(){

        let status = $('#applicant_status').val();

        if( status === 'Selected' || status === 'Offer Released' || status === 'Offer Accepted' || status === 'Joined'){
            $('#selectedSection')
                .removeClass('d-none');
        }else{
            $('#selectedSection')
                .addClass('d-none');
        }
    }


    $('#saveHistoryBtn').click(function(){

        let btn = $(this);

        btn.prop('disabled',true);
        let interview_date = $('#interview_date').val();
        let applicant_status = $('#applicant_status').val();

        if (!interview_date) {
            $('#interview_date_err').text("Interview Date is Required.");
            btn.prop('disabled',false);
            return;
        } else {
            $('#interview_date_err').text("");
        }

        if (!applicant_status) {
            $('#applicant_status_err').text("Interview Status is Required.");
            btn.prop('disabled',false);
            return;
        } else {
            $('#applicant_status_err').text("");
        }

        $.ajax({
            url:"{{ route('candidate.history.store') }}",
            type:"POST",
            data:{
                _token:"{{ csrf_token() }}",
                applicant_id:$('#history_applicant_id').val(),
                interview_date:$('#interview_date').val(),
                applicant_status:$('#applicant_status').val(),
                selected_date:$('#selected_date').val(),
                entity_id:$('#selected_company').val(),
                job_role_id:$('#selected_job_role').val(),
                expected_salary: $('#expected_salary').val(),
                offered_salary:$('#offered_salary').val(),
                joining_date:$('#joining_date').val(),
                followup_date: $('#followup_date').val(),
                remarks:$('#history_remarks').val()
            },
            success:function(res){
                toastr.success(res.message);
                openCandidateHistory($('#history_applicant_id').val());
                loadThemes(currentPage);
            },
            complete:function(){
                btn.prop('disabled',false);
            }
        });

    });

    function getStatusColor(status)
    {
        switch(status)
        {
            case 'Selected':
            case 'Joined':
                return 'success';

            case 'Rejected':
            case 'Offer Rejected':
            case 'Not Joined':
                return 'danger';

            case 'On Hold':
                return 'warning';

            case 'Critical':
                return 'dark';

            default:
                return 'primary';
        }
    }

    function renderHistoryTimeline(history)
    {
        if(!history || history.length === 0)
        {
            $('#historyTimeline').html(`
                <div class="text-center py-5">
                    <span class="mdi mdi-clipboard-text-off fs-2"></span>
                    <div class="mt-3 text-muted">
                        No recruitment updates available
                    </div>
                </div>
            `);
            return;
        }

        let html = `<div class="candidate-history-timeline">`;

        history.forEach((item,index)=>{

            const color = getStatusColor(
                item.applicant_status
            );

            html += `
            <div class="history-item">

                <div class="history-line"></div>

                <div class="history-dot bg-${color}">
                    ${index + 1}
                </div>

                <div class="history-card">

                    <div class="d-flex justify-content-between align-items-start mb-2">

                        <div>

                            <span class="badge bg-${color}">
                                ${item.applicant_status}
                            </span>

                            ${
                                item.interview_date
                                ?
                                `
                                <div class="small text-muted mt-2">
                                    <i class="mdi mdi-calendar"></i>
                                    Interview :
                                    ${item.interview_date}
                                </div>
                                `
                                :
                                ''
                            }

                        </div>

                        <div class="text-end">
                            <small class="text-muted">
                                ${item.created_at}
                            </small>
                        </div>

                    </div>

                    ${
                        item.remarks
                        ?
                        `
                        <div class="history-remarks">
                            <i class="mdi mdi-note-text-outline me-1"></i>
                            ${item.remarks}
                        </div>
                        `
                        :
                        ''
                    }

                    <div class="row mt-3">

                        ${
                            item.company_name
                            ?
                            `
                            <div class="col-md-4 mb-2">
                                <small class="text-muted d-block">
                                    Company
                                </small>
                                <strong>
                                    ${item.company_name}
                                </strong>
                            </div>
                            `
                            :
                            ''
                        }

                        ${
                            item.job_position_name
                            ?
                            `
                            <div class="col-md-4 mb-2">
                                <small class="text-muted d-block">
                                    Job Role
                                </small>
                                <strong>
                                    ${item.job_position_name}
                                </strong>
                            </div>
                            `
                            :
                            ''
                        }

                        ${
                            item.offered_salary
                            ?
                            `
                            <div class="col-md-4 mb-2">
                                <small class="text-muted d-block">
                                    Offered Salary
                                </small>
                                <strong class="text-success">
                                    ₹ ${parseFloat(item.offered_salary).toLocaleString()}
                                </strong>
                            </div>
                            `
                            :
                            ''
                        }

                    </div>

                    ${
                        item.followup_date
                        ?
                        `
                        <div class="mt-3">
                            <span class="badge bg-light-warning text-warning">
                                Follow-up :
                                ${item.followup_date}
                            </span>
                        </div>
                        `
                        :
                        ''
                    }

                </div>

            </div>
            `;
        });

        html += `</div>`;

        $('#historyTimeline').html(html);
    }

    function profileSkeleton()
    {
        return `
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">

                <div class="d-flex align-items-center">

                    <div
                        class="placeholder-glow me-4">
                        <span
                            class="placeholder rounded-circle"
                            style="width:80px;height:80px;display:block;">
                        </span>
                    </div>

                    <div class="flex-grow-1">

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-4"></span>
                        </div>

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-3"></span>
                        </div>

                        <div class="placeholder-glow">
                            <span class="placeholder col-6"></span>
                        </div>

                    </div>

                </div>

            </div>
        </div>

        <div class="row">

            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <div class="placeholder-glow mb-3">
                            <span class="placeholder col-5"></span>
                        </div>

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-8"></span>
                        </div>

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-7"></span>
                        </div>

                        <div class="placeholder-glow">
                            <span class="placeholder col-6"></span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">

                        <div class="placeholder-glow mb-3">
                            <span class="placeholder col-5"></span>
                        </div>

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-9"></span>
                        </div>

                        <div class="placeholder-glow mb-2">
                            <span class="placeholder col-7"></span>
                        </div>

                        <div class="placeholder-glow">
                            <span class="placeholder col-5"></span>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        `;
    }

    function renderHistoryCandidate(d)
    {
        // Avatar
        $('#history_avatar').html(
            d.applicant_name
            ? d.applicant_name.charAt(0).toUpperCase()
            : 'C'
        );

        // Basic Details
        $('#history_name').text(d.applicant_name || '-');
        $('#history_applicant_id').text(d.applicant_id || '-');
        $('#history_mobile').text(d.mobile || '-');
        $('#history_email').text(d.email || '-');
        $('#history_source').text(d.source_name || '-');

        // Gender
        let gender = 'Unknown';

        if (d.gender == 1 || d.gender == '1') {
            gender = 'Male';
        } else if (d.gender == 2 || d.gender == '2') {
            gender = 'Female';
        }

        $('#history_gender').html(`
            <span class="badge bg-light-primary text-primary">
                ${gender}
            </span>
        `);

        // Qualification Badge
        let qualification = 'Others';
        let badgeClass = 'bg-secondary';

        if (d.qualification_id == '1') {
            qualification = 'UG';
            badgeClass = 'bg-success';
        } else if (d.qualification_id == '2') {
            qualification = 'PG';
            badgeClass = 'bg-primary';
        } else if (d.qualification_id == '3') {
            qualification = 'Doctorate';
            badgeClass = 'bg-dark';
        } else if (d.qualification_id == '4') {
            qualification = 'HSC';
            badgeClass = 'bg-info';
        } else if (d.qualification_id == '5') {
            qualification = 'SSLC';
            badgeClass = 'bg-warning text-dark';
        } else if (d.qualification_id == '6') {
            qualification = 'Below SSLC';
            badgeClass = 'bg-danger';
        }

        // Old Recruitment Data Override
        if (parseInt(d.recruitment_id) > 0 && d.old_data) {
            try {
                const oldData = JSON.parse(d.old_data);
                switch(oldData.qualification_id){
                    case '5':
                        qualification = 'UG';
                        badgeClass = 'bg-success';
                        break;
                    case '4':
                        qualification = 'PG';
                        badgeClass = 'bg-primary';
                        break;
                    case '3':
                        qualification = 'Professional Degree';
                        badgeClass = 'bg-info';
                        break;
                    case '2':
                        qualification = 'Doctorate';
                        badgeClass = 'bg-dark';
                        break;
                    default:
                        qualification = 'Others';
                        badgeClass = 'bg-secondary';
                }
            } catch (e) {
                console.log(e);
            }
        }

        $('#history_qualification_badge').html(`
            <span class="badge ${badgeClass}">
                ${qualification}
            </span>
        `);

        // Major
        let majorName = '-';

        if (
            d.major &&
            d.major != '0' &&
            d.major_name
        ) {
            majorName = d.major_name;
        }

        $('#history_major').text(majorName);

        // Experience
        let experienceText = 'Fresher';

        if (
            d.experience_id == '2' ||
            d.experience_id == 2
        ) {
            experienceText =
                (d.experience_count || 0) + ' Years';
        }

        $('#history_experience').html(`
            <span class="badge bg-light-success text-success">
                ${experienceText}
            </span>
        `);

        // history Remarks
        $('#history_remarks').val('');

    }


</script>
<script>
    function histry_entity_change() {
        var entity_id = $('#selected_company').val();
        let entityID =0;

        var jobRoleDropdown = $('#selected_job_role');

        jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');
        if (entity_id) {
            // Fetch and populate states based on selected country
            // Job role dropdown
            if(entity_id =='egc'){
                entityID =0;
            }else{
                entityID =entity_id;
            }
            $.ajax({
                url: "{{ route('get_job_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entityID
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            jobRoleDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .text(state.job_position_name));
                        });

                    }
                },
                error: function(error) {
                    console.error('Error fetching Job Role:', error);
                }
            });
        }
    }
</script>
<script>
     
    function viewApplicantAI(id){
        $('#applicantDetailedAiModal').modal('show');
        
         loadApplicant(id);

        // $.get('/candidate/ai-view/'+id,function(res){

        //     renderApplicantAI(res);

        //     $('#applicantAiModal').modal('show');

        // });

      

    }
</script>

<script>
   

function loadApplicant(id)
{

    $("#candidateProfile").html(loader());

    $("#overviewTab").html(loader());

    $("#aiTab").html(loader());

    $("#resumeTab").html(loader());

    $.ajax({

        url:
        "/hr-recruitment/applicant/"+id+"/ai-analysis",

        type:"GET",

        success:function(res){

            renderCandidate(res.data);

            renderOverview(res.data);

            renderAI(res.data);

            renderResume(res.data);

        },

        error:function(){

            toastr.error(
                "Unable to load applicant."
            );

        }

    });

}

function loader()
{

    return `

    <div class="placeholder-glow p-4">

        <span class="placeholder col-8 mb-3"></span>

        <span class="placeholder col-12 mb-2"></span>

        <span class="placeholder col-10 mb-2"></span>

        <span class="placeholder col-7 mb-2"></span>

        <span class="placeholder col-12"></span>

    </div>

    `;

}

function renderCandidate(data)
{

    let c = data.candidate;

    let ai = data.ai;

    let match = ai.matches.length
        ? ai.matches[0]
        : null;

    let score = 0;

    if(ai.ai_response){

        score = ai.ai_response.overall_match_score;

    }

    let badge = `
        <span class="badge bg-secondary">
            Not Matched
        </span>
    `;

    if(match){

        badge = `
        <span class="badge bg-success">
            AI Matched
        </span>
        `;
    }

    $("#candidateProfile").html(`

        ${candidateCard(c,badge,score)}

    `);

}

function candidateCard(c,badge,score)
{

return `

<div class="candidate-card">

    <div class="candidate-header">

        <div class="candidate-avatar">

            ${avatar(c.name)}

        </div>

        <h4>

            ${c.name ?? '-'}

        </h4>

        <div class="text-muted">

            ${c.current_designation ?? '-'}

        </div>

        <div class="mt-3">

            ${badge}

        </div>

        <div class="score-circle mt-4">

            ${score}%

        </div>

    </div>

    ${contactCard(c)}

    ${professionalCard(c)}

    ${companyCard(c)}

    ${resumeCard(c)}

</div>

`;

}

function contactCard(c)
{

return `

<div class="info-card">

<h6>

<i class="mdi mdi-account-circle"></i>

Contact

</h6>

<div>

<i class="mdi mdi-email-outline"></i>

${c.email ?? '-'}

</div>

<div>

<i class="mdi mdi-phone-outline"></i>

${c.mobile ?? '-'}

</div>

<div>

<i class="mdi mdi-map-marker"></i>

${c.location ?? '-'}

</div>

</div>

`;

}

function professionalCard(c)
{

return `

<div class="info-card">

<h6>

<i class="mdi mdi-briefcase"></i>

Professional

</h6>

<table class="table table-sm">

<tr>

<td>Experience</td>

<td>${c.experience ?? '-'}</td>

</tr>

<tr>

<td>Qualification</td>

<td>${c.qualification ?? '-'}</td>

</tr>

<tr>

<td>Current CTC</td>

<td>${c.current_ctc ?? '-'}</td>

</tr>

<tr>

<td>Expected CTC</td>

<td>${c.expected_ctc ?? '-'}</td>

</tr>

<tr>

<td>Notice</td>

<td>${c.notice_period ?? '-'}</td>

</tr>

</table>

</div>

`;

}

function companyCard(c)
{

return `

<div class="info-card">

<h6>

<i class="mdi mdi-office-building"></i>

Current Company

</h6>

<div class="fw-bold">

${c.current_company ?? '-'}

</div>

<div class="text-muted">

${c.current_designation ?? '-'}

</div>

</div>

`;

}

function resumeCard(c)
{

return `

<div class="info-card">

<h6>

Resume

</h6>

<a

href="/job_applications/resume_files/${c.resume}"

target="_blank"

class="btn btn-primary btn-sm w-100">

<i class="mdi mdi-download"></i>

Download Resume

</a>

</div>

`;

}

function avatar(name)
{

if(!name)
    return "?";

let arr = name.trim().split(" ");

if(arr.length==1)
    return arr[0][0].toUpperCase();

return arr[0][0].toUpperCase()+arr[1][0].toUpperCase();

}

function renderAI(data)
{
    let ai = data.ai;

    if (!ai || !ai.ai_response) {

        $("#aiTab").html(noAnalysis());

        return;

    }

    let analysis = ai.ai_response;

    let matches = ai.matches ?? [];

    $("#aiTab").html(`

        ${recommendationBanner(matches,analysis)}

        ${scoreCards(analysis)}

        ${matchedRole(matches)}

        <div class="row">

            <div class="col-lg-6">

                ${strengthCard(analysis)}

            </div>

            <div class="col-lg-6">

                ${weaknessCard(analysis)}

            </div>

        </div>

        <div class="row mt-4">

            <div class="col-lg-12">

                ${keywordCard(analysis)}

            </div>

        </div>

        <div class="row mt-4">

            <div class="col-lg-6">

                ${summaryCard(analysis)}

            </div>

            <div class="col-lg-6">

                ${improvementCard(analysis)}

            </div>

        </div>

        <div class="mt-4">

            ${rewriteCard(analysis)}

        </div>

    `);

}

function recommendationBanner(matches,ai)
{

let score = ai.overall_match_score;

let color="danger";

let text="Not Recommended";

let icon="mdi-close-circle";

if(score>=90){

    color="success";

    text="Highly Recommended";

    icon="mdi-check-decagram";

}
else if(score>=75){

    color="primary";

    text="Recommended";

    icon="mdi-thumb-up";

}
else if(score>=60){

    color="warning";

    text="Needs Review";

    icon="mdi-alert";

}

return `

<div class="alert alert-${color} shadow-sm">

<div class="d-flex justify-content-between align-items-center">

<div>

<h4>

<i class="mdi ${icon}"></i>

${text}

</h4>

<div>

Overall AI Evaluation

</div>

</div>

<h1>

${score}%

</h1>

</div>

</div>

`;

}

function scoreCards(ai)
{

return `

<div class="row g-3">

${scoreCard("Overall",ai.overall_match_score,"primary")}

${scoreCard("ATS",ai.ats_keyword_match_score,"success")}

${scoreCard("Skills",ai.skills_alignment_score,"info")}

${scoreCard("Experience",ai.experience_relevance_score,"warning")}

${scoreCard("Impact",ai.impact_metrics_score,"danger")}

${scoreCard("Role",ai.role_responsibility_match_score,"secondary")}

</div>

`;

}

function scoreCard(title,value,color)
{

return `

<div class="col-lg-4">

<div class="card border-0 shadow-sm">

<div class="card-body">

<div class="text-muted">

${title}

</div>

<h2 class="fw-bold">

${value}%

</h2>

<div class="progress">

<div

class="progress-bar bg-${color}"

style="width:${value}%">

</div>

</div>

</div>

</div>

</div>

`;

}

function matchedRole(matches)
{

if(matches.length==0){

return `

<div class="card mt-4 border-danger">

<div class="card-body">

<h5>

No Matching Company Role

</h5>

<div>

Candidate does not closely match any existing company role.

</div>

</div>

</div>

`;

}

let role=matches[0];

return `

<div class="card mt-4 shadow-sm">

<div class="card-body">

<h5>

Matched Role

</h5>

<div class="fs-4 fw-bold">

Role ID

${role.role_id}

</div>

<div>

Confidence

${role.confidence}%

</div>

<div class="mt-2 text-muted">

${role.reason}

</div>

</div>

</div>

`;

}


function strengthCard(ai){

return listCard(

"Strengths",

"success",

ai.strengths

);

}

function weaknessCard(ai){

return listCard(

"Weaknesses",

"danger",

ai.weaknesses

);

}

function listCard(title,color,list)
{

let html="";

(list||[]).forEach(item=>{

html+=`

<li class="list-group-item">

${item}

</li>

`;

});

return `

<div class="card border-${color}">

<div class="card-header bg-${color} text-white">

${title}

</div>

<ul class="list-group list-group-flush">

${html}

</ul>

</div>

`;

}

function keywordCard(ai)
{

let html="";

(ai.missing_keywords||[]).forEach(x=>{

html+=`

<span class="badge bg-danger me-2 mb-2">

${x}

</span>

`;

});

return `

<div class="card shadow-sm">

<div class="card-body">

<h5>

Missing Keywords

</h5>

${html}

</div>

</div>

`;

}

function summaryCard(ai)
{

return `

<div class="card shadow-sm h-100">

<div class="card-body">

<h5>

Optimized Summary

</h5>

<p>

${ai.optimized_summary}

</p>

</div>

</div>

`;

}

function improvementCard(ai)
{

let html="";

(ai.resume_improvements||[]).forEach(x=>{

html+=`

<li>

${x}

</li>

`;

});

return `

<div class="card h-100">

<div class="card-body">

<h5>

Resume Improvements

</h5>

<ol>

${html}

</ol>

</div>

</div>

`;

}

function rewriteCard(ai)
{

let html="";

(ai.rewritten_bullets||[]).forEach(x=>{

html+=`

<div class="alert alert-light border">

${x}

</div>

`;

});

return `

<div class="card shadow-sm">

<div class="card-body">

<h5>

AI Rewritten Resume Bullets

</h5>

${html}

</div>

</div>

`;

}


function noAnalysis(){

return `

<div class="text-center py-5">

<i class="mdi mdi-robot-outline display-1 text-muted"></i>

<h3 class="mt-3">

AI Analysis Not Available

</h3>

<p>

Run AI Resume Analysis to generate recruiter insights.

</p>

</div>

`;

}

function decisionPanel(ai,matches)
{

let role="-";
let confidence="-";

if(matches.length){

role=matches[0].role_name;

confidence=matches[0].confidence+"%";

}

return `

<div class="decision-panel">

<div class="row align-items-center">

<div class="col-lg-8">

${recommendationBadge(ai)}

<h3>

${ai.overall_hiring_recommendation}

</h3>

<div class="text-muted">

Candidate is recommended by AI.

</div>

</div>

<div class="col-lg-4 text-end">

<div class="decision-score">

${ai.overall_match_score}%

</div>

</div>

</div>

<hr>

<div class="row">

<div class="col-md-4">

${metric("Matched Role",role)}

</div>

<div class="col-md-4">

${metric("Confidence",confidence)}

</div>

<div class="col-md-4">

${metric("Career Level",ai.career_level)}

</div>

<div class="col-md-4">

${metric("Priority",ai.hiring_priority)}

</div>

<div class="col-md-4">

${metric("Experience",ai.estimated_experience_years+" Years")}

</div>

<div class="col-md-4">

${metric("Interview Readiness",ai.interview_readiness+"%")}

</div>

</div>

</div>

`;

}

function metric(title,value)
{

return `

<div class="metric-box">

<div class="metric-title">

${title}

</div>

<div class="metric-value">

${value}

</div>

</div>

`;

}

function recommendationBadge(ai)
{

let cls="secondary";

switch(ai.overall_hiring_recommendation){

case "Highly Recommended":

cls="success";

break;

case "Recommended":

cls="primary";

break;

case "Needs Review":

cls="warning";

break;

default:

cls="danger";

}

return `

<span class="badge bg-${cls} px-3 py-2">

${ai.overall_hiring_recommendation}

</span>

`;

}

function recruiterActions(id)
{

return `

<div class="card shadow-sm mt-4">

<div class="card-body">

<div class="d-flex flex-wrap gap-2">

<button class="btn btn-success">

<i class="mdi mdi-account-check"></i>

Shortlist

</button>

<button class="btn btn-warning">

<i class="mdi mdi-calendar"></i>

Interview

</button>

<button class="btn btn-primary">

<i class="mdi mdi-account-plus"></i>

Assign Recruiter

</button>

<button class="btn btn-info">

<i class="mdi mdi-download"></i>

Download AI Report

</button>

</div>

</div>

</div>

`;

}

function aiDecision(ai)
{

return `

<div class="card shadow-sm mt-4">

<div class="card-body">

<h5>

AI Decision

</h5>

<p>

${ai.ai_decision}

</p>

</div>

</div>

`;

}

function riskCard(ai)
{

let color="success";

if(ai.risk_level=="Medium")
color="warning";

if(ai.risk_level=="High")
color="danger";

return `

<div class="card border-${color} mt-4">

<div class="card-body">

<h5>

Risk Assessment

</h5>

<div class="display-6 text-${color}">

${ai.risk_level}

</div>

<div class="mt-2">

Technical Strength

<strong>

${ai.technical_strength}

</strong>

</div>

<div>

Communication

<strong>

${ai.communication_assessment}

</strong>

</div>

</div>

</div>

`;

}

// function renderResume(data)
// {

//     let resume=data.resume;

//     $("#resumeTab").html(`

//         ${resumeHeader(resume)}

//         ${resumeSummary(resume)}

//         ${skillsSection(resume)}

//         ${experienceSection(resume)}

//         ${educationSection(resume)}

        

//         ${keywordSection(data.ai)}

//         ${resumeTextViewer(resume)}

//     `);

// }

function renderResume(data)
{
    const candidate = data?.candidate || {};
    const resume = data?.resume || {};

    const attachment =
        resume.attachment ||
        candidate.resume ||
        '';

    const fileUrl = buildResumeUrl(
        attachment
    );

    const fileInfo = getResumeFileInfo(
        attachment
    );

    $("#resumeTab").html(`

        <div class="resume-workspace">

            <!-- Resume Header -->
            <div class="resume-toolbar">

                <div class="d-flex align-items-center">

                    <div class="resume-file-icon ${fileInfo.colorClass}">
                        <i class="mdi ${fileInfo.icon}"></i>
                    </div>

                    <div class="ms-3">

                        <h5 class="mb-1 fw-bold text-dark text-break">
                            ${escapeHtml(
                                attachment || 'Resume'
                            )}
                        </h5>

                        <div class="small text-muted">

                            ${fileInfo.extension.toUpperCase()}
                            &nbsp;•&nbsp;
                            Candidate Resume

                        </div>

                    </div>

                </div>

                <div class="d-flex flex-wrap gap-2">

                    ${
                        fileUrl
                            ? `
                                <a
                                    href="${escapeAttribute(fileUrl)}"
                                    target="_blank"
                                    rel="noopener"
                                    class="btn btn-sm btn-light-primary">

                                    <i class="mdi mdi-open-in-new me-1"></i>
                                    Open

                                </a>

                                <a
                                    href="${escapeAttribute(fileUrl)}"
                                    download
                                    class="btn btn-sm btn-primary">

                                    <i class="mdi mdi-download-outline me-1"></i>
                                    Download

                                </a>
                              `
                            : ''
                    }

                </div>

            </div>


            <!-- Viewer -->
            <div class="resume-viewer-card">

                <div class="resume-viewer-body">

                    ${renderResumeViewer(
                        fileUrl,
                        fileInfo,
                        resume
                    )}

                </div>

            </div>


            <!-- Extracted Text -->
            <div class="card resume-extracted-card mt-4">

                <div class="card-header bg-white">

                    <div class="d-flex align-items-center">

                        <div class="resume-section-icon">
                            <i class="mdi mdi-text-box-search-outline"></i>
                        </div>

                        <div class="ms-3">

                            <h6 class="mb-1 fw-bold">
                                Extracted Resume Text
                            </h6>

                            <small class="text-muted">
                                Text extracted from the uploaded resume
                            </small>

                        </div>

                    </div>

                </div>

                <div class="card-body">

                    ${
                        resume.text
                            ? `
                                <div class="resume-extracted-text">
                                    ${escapeHtml(
                                        resume.text
                                    )}
                                </div>
                              `
                            : `
                                <div class="resume-empty-text">
                                    <i class="mdi mdi-text-box-remove-outline fs-1"></i>

                                    <div class="mt-2">
                                        Extracted resume text is not available.
                                    </div>
                                </div>
                              `
                    }

                </div>

            </div>

        </div>

    `);

    initializeResumeViewer();
}

function getResumeFileInfo(filename)
{
    const extension = String(filename || '')
        .split('.')
        .pop()
        .toLowerCase();

    switch (extension) {

        case 'pdf':

            return {
                extension: 'pdf',
                type: 'pdf',
                icon: 'mdi-file-pdf-box',
                colorClass: 'resume-file-pdf'
            };

        case 'doc':

            return {
                extension: 'doc',
                type: 'document',
                icon: 'mdi-file-word-box',
                colorClass: 'resume-file-word'
            };

        case 'docx':

            return {
                extension: 'docx',
                type: 'document',
                icon: 'mdi-file-word-box',
                colorClass: 'resume-file-word'
            };

        case 'jpg':
        case 'jpeg':

            return {
                extension: extension,
                type: 'image',
                icon: 'mdi-file-image-box',
                colorClass: 'resume-file-image'
            };

        case 'png':

            return {
                extension: 'png',
                type: 'image',
                icon: 'mdi-file-image-box',
                colorClass: 'resume-file-image'
            };

        case 'webp':

            return {
                extension: 'webp',
                type: 'image',
                icon: 'mdi-file-image-box',
                colorClass: 'resume-file-image'
            };

        case 'txt':

            return {
                extension: 'txt',
                type: 'text',
                icon: 'mdi-file-document-outline',
                colorClass: 'resume-file-text'
            };

        default:

            return {
                extension: extension || 'file',
                type: 'unknown',
                icon: 'mdi-file-outline',
                colorClass: 'resume-file-default'
            };
    }
}

function buildResumeUrl(attachment)
{
    if (!attachment) {
        return '';
    }

    const cleanName = String(
        attachment
    )
    .replace(/^\/+/, '');

    return `/job_applications/resume_files/${encodeURIComponent(cleanName)}`;
}

function buildResumeUrl(attachment)
{
    if (!attachment) {
        return '';
    }

    const cleanName = String(
        attachment
    )
    .replace(/^\/+/, '');

    return `/job_applications/resume_files/${encodeURIComponent(cleanName)}`;
}

function renderResumeViewer(
    fileUrl,
    fileInfo,
    resume
)
{
    if (!fileUrl) {

        return `
            <div class="resume-viewer-empty">

                <div class="resume-empty-icon">
                    <i class="mdi mdi-file-alert-outline"></i>
                </div>

                <h5 class="fw-bold mt-3">
                    Resume File Not Available
                </h5>

                <p class="text-muted mb-0">
                    The candidate record does not contain a valid resume attachment.
                </p>

            </div>
        `;
    }


    /*
    |--------------------------------------------------------------------------
    | PDF
    |--------------------------------------------------------------------------
    */

    if (fileInfo.type === 'pdf') {

        return `

            <div class="resume-pdf-container">

                <div class="resume-pdf-loading"
                     id="resumePdfLoading">

                    <div class="spinner-border text-primary"></div>

                    <div class="mt-2 text-muted">
                        Loading resume...
                    </div>

                </div>

                <iframe
                    id="resumePdfFrame"
                    src="${escapeAttribute(fileUrl)}#toolbar=1&navpanes=0&view=FitH"
                    class="resume-pdf-frame"
                    title="Candidate Resume">
                </iframe>

            </div>

        `;
    }


    /*
    |--------------------------------------------------------------------------
    | Image
    |--------------------------------------------------------------------------
    */

    if (fileInfo.type === 'image') {

        return `

            <div class="resume-image-container">

                <div class="resume-image-toolbar">

                    <button
                        type="button"
                        class="btn btn-sm btn-light"
                        onclick="resumeImageZoom(-0.1)">

                        <i class="mdi mdi-minus"></i>

                    </button>

                    <span id="resumeImageZoomValue">
                        100%
                    </span>

                    <button
                        type="button"
                        class="btn btn-sm btn-light"
                        onclick="resumeImageZoom(0.1)">

                        <i class="mdi mdi-plus"></i>

                    </button>

                    <button
                        type="button"
                        class="btn btn-sm btn-light"
                        onclick="resumeImageReset()">

                        <i class="mdi mdi-refresh"></i>

                    </button>

                </div>

                <div
                    class="resume-image-stage"
                    id="resumeImageStage">

                    <img
                        id="resumeImagePreview"
                        src="${escapeAttribute(fileUrl)}"
                        alt="Candidate Resume"
                        class="resume-image-preview"
                    />

                </div>

            </div>

        `;
    }


    /*
    |--------------------------------------------------------------------------
    | TXT
    |--------------------------------------------------------------------------
    */

    if (fileInfo.type === 'text') {

        return `

            <div class="resume-native-text-viewer">

                ${escapeHtml(
                    resume.text || 'No text available.'
                )}

            </div>

        `;
    }


    /*
    |--------------------------------------------------------------------------
    | DOC / DOCX
    |--------------------------------------------------------------------------
    |
    | Browsers do not consistently render DOC/DOCX natively.
    | Show an intelligent production fallback.
    |--------------------------------------------------------------------------
    */

    if (fileInfo.type === 'document') {

        return `

            <div class="resume-document-fallback">

                <div class="resume-document-icon">

                    <i class="mdi mdi-file-word-outline"></i>

                </div>

                <h5 class="fw-bold mt-3">
                    ${fileInfo.extension.toUpperCase()} Resume
                </h5>

                <p class="text-muted text-center">

                    This document format cannot be reliably rendered
                    directly by every browser.

                </p>

                <div class="d-flex justify-content-center gap-2 mt-3">

                    <a
                        href="${escapeAttribute(fileUrl)}"
                        target="_blank"
                        rel="noopener"
                        class="btn btn-primary">

                        <i class="mdi mdi-open-in-new me-1"></i>

                        Open Document

                    </a>

                    <a
                        href="${escapeAttribute(fileUrl)}"
                        download
                        class="btn btn-light-primary">

                        <i class="mdi mdi-download-outline me-1"></i>

                        Download

                    </a>

                </div>

                ${
                    resume.text
                        ? `
                            <div class="mt-4 w-100">

                                <div class="alert alert-light-primary">

                                    <i class="mdi mdi-information-outline me-1"></i>

                                    Extracted resume text is available below
                                    for recruiter review.

                                </div>

                            </div>
                          `
                        : ''
                }

            </div>

        `;
    }


    /*
    |--------------------------------------------------------------------------
    | Unknown
    |--------------------------------------------------------------------------
    */

    return `

        <div class="resume-document-fallback">

            <div class="resume-document-icon">

                <i class="mdi mdi-file-question-outline"></i>

            </div>

            <h5 class="fw-bold mt-3">
                Unsupported Resume Format
            </h5>

            <p class="text-muted">
                Please open or download the original file.
            </p>

            <a
                href="${escapeAttribute(fileUrl)}"
                target="_blank"
                rel="noopener"
                class="btn btn-primary">

                <i class="mdi mdi-open-in-new me-1"></i>

                Open Resume

            </a>

        </div>

    `;
}

function escapeAttribute(value)
{
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
let resumeImageScale = 1;


function initializeResumeViewer()
{
    resumeImageScale = 1;

    const pdfFrame =
        document.getElementById(
            'resumePdfFrame'
        );

    if (pdfFrame) {

        pdfFrame.addEventListener(
            'load',
            function() {

                $('#resumePdfLoading')
                    .fadeOut(200);

            }
        );
    }
}


// function resumeImageZoom(change)
// {
//     const image =
//         document.getElementById(
//             'resumeImagePreview'
//         );

//     if (!image) {
//         return;
//     }

//     resumeImageScale += change;

//     resumeImageScale =
//         Math.max(
//             0.5,
//             Math.min(
//                 3,
//                 resumeImageScale
//             )
//         );

//     image.style.transform =
//         `scale(${resumeImageScale})`;

//     $('#resumeImageZoomValue')
//         .text(
//             Math.round(
//                 resumeImageScale * 100
//             ) + '%'
//         );
// }


// function resumeImageReset()
// {
//     const image =
//         document.getElementById(
//             'resumeImagePreview'
//         );

//     if (!image) {
//         return;
//     }

//     resumeImageScale = 1;

//     image.style.transform =
//         'scale(1)';

//     $('#resumeImageZoomValue')
//         .text('100%');
// }

function resumeImageZoom(change)
{
    const image =
        document.getElementById(
            'resumeImagePreview'
        );

    if (!image) {
        return;
    }

    resumeImageScale += change;

    resumeImageScale =
        Math.max(
            0.5,
            Math.min(
                3,
                resumeImageScale
            )
        );

    image.style.transform =
        `scale(${resumeImageScale})`;

    $('#resumeImageZoomValue').text(
        Math.round(
            resumeImageScale * 100
        ) + '%'
    );
}


function resumeImageReset()
{
    const image =
        document.getElementById(
            'resumeImagePreview'
        );

    if (!image) {
        return;
    }

    resumeImageScale = 1;

    image.style.transform =
        'scale(1)';

    $('#resumeImageZoomValue')
        .text('100%');
}

function resumeHeader(resume)
{

return `

<div class="card shadow-sm">

<div class="card-body d-flex justify-content-between">

<div>

<h4>

Resume Intelligence

</h4>

<div class="text-muted">

AI Extracted Resume

</div>

</div>

<a

href="/job_applications/resume_files/${resume.attachment}"

target="_blank"

class="btn btn-primary">

<i class="mdi mdi-download"></i>

Download Resume

</a>

</div>

</div>

`;

}

function resumeSummary(resume)
{

return `

<div class="card mt-4">

<div class="card-body">

<h5>

Professional Summary

</h5>

<p>

${resume.summary}

</p>

</div>

</div>

`;

}

function skillsSection(resume)
{

let html="";

(resume.skills||[]).forEach(skill=>{

html+=`

<span class="badge bg-success m-1">

${skill}

</span>

`;

});

return `

<div class="card mt-4">

<div class="card-body">

<h5>

Detected Skills

</h5>

${html}

</div>

</div>

`;

}

function experienceSection(resume)
{

let html="";

(resume.experience||[]).forEach(job=>{

html+=`

<div class="timeline-item">

<h5>

${job.company}

</h5>

<div>

${job.designation}

</div>

<div class="text-muted">

${job.duration}

</div>

<ul>

${job.responsibilities.map(x=>`<li>${x}</li>`).join("")}

</ul>

</div>

`;

});

return `

<div class="card mt-4">

<div class="card-body">

<h5>

Experience

</h5>

${html}

</div>

</div>

`;

}

function educationSection(resume)
{

let html="";

(resume.education||[]).forEach(x=>{

html+=`

<div class="mb-3">

<strong>

${x.degree}

</strong>

<div>

${x.college}

</div>

<div>

${x.year}

</div>

</div>

`;

});

return `

<div class="card mt-4">

<div class="card-body">

<h5>

Education

</h5>

${html}

</div>

</div>

`;

}

function keywordSection(ai)
{

let positive="";

(ai.ai_response.detected_keywords||[]).forEach(x=>{

positive+=`

<span class="badge bg-primary me-2 mb-2">

${x}

</span>

`;

});

let missing="";

(ai.ai_response.missing_keywords||[]).forEach(x=>{

missing+=`

<span class="badge bg-danger me-2 mb-2">

${x}

</span>

`;

});

return `

<div class="row mt-4">

<div class="col-lg-6">

<div class="card">

<div class="card-body">

<h5>

Detected Keywords

</h5>

${positive}

</div>

</div>

</div>

<div class="col-lg-6">

<div class="card">

<div class="card-body">

<h5>

Missing Keywords

</h5>

${missing}

</div>

</div>

</div>

</div>

`;

}

function resumeTextViewer(resume)
{
    return `
        <div class="card mt-4">
            <div class="card-header">
                <h5>Extracted Resume</h5>
            </div>
            <div class="card-body">
                <pre class="resume-text">
${resume.text}
                </pre>
            </div>
        </div>
    `;
}

function renderTimeline(data)
{
    let html="";
    (data.timeline || []).forEach(item=>{
        html+=timelineCard(item);
    });
    $("#timelineTab").html(html);

}

function timelineCard(item)
{
    return `
        <div class="timeline-card">
            <div class="timeline-icon">
                ${timelineIcon(item.type)}
            </div>
            <div class="timeline-content">
                <div class="d-flex justify-content-between">
                    <h5>
                        ${item.title}
                    </h5>
                    <small>
                        ${item.date}
                    </small>
                </div>
                <div>
                    ${item.description}
                </div>
                <small class="text-muted">
                    ${item.user}
                </small>
            </div>
        </div>
    `;
}

function timelineIcon(type)
{
    switch(type){
        case "application":
            return `<i class="mdi mdi-file-document-outline"></i>`;
        case "ai":
            return `<i class="mdi mdi-robot"></i>`;
        case "shortlist":
            return `<i class="mdi mdi-account-check"></i>`;
        case "interview":
            return `<i class="mdi mdi-calendar"></i>`;
        case "offer":
            return `<i class="mdi mdi-briefcase-check"></i>`;
        case "reject":
            return `<i class="mdi mdi-close-circle"></i>`;
        default:
            return `<i class="mdi mdi-circle"></i>`;
    }

}

function timelineColor(status)
{
    switch(status){
        case "completed":
            return "success";
        case "pending":
            return "warning";
        case "rejected":
            return "danger";
        case "scheduled":
            return "primary";
        default:
            return "secondary";
    }
}

function renderOverviewOld(data)
{
    const candidate = data?.candidate || {};
    const ai = data?.ai || {};
    const aiResponse = ai?.ai_response || {};

    const matches = Array.isArray(ai.matches)
        ? ai.matches
        : [];

    const score = clampScore(
        aiResponse.overall_match_score
    );

    const atsScore = clampScore(
        aiResponse.ats_keyword_match_score
    );

    const skillsScore = clampScore(
        aiResponse.skills_alignment_score
    );

    const experienceScore = clampScore(
        aiResponse.experience_relevance_score
    );

    const impactScore = clampScore(
        aiResponse.impact_metrics_score
    );

    const responsibilityScore = clampScore(
        aiResponse.role_responsibility_match_score
    );

    const candidateName =
        candidate.name ||
        candidate.email ||
        'Unnamed Candidate';

    const initials = getCandidateInitials(candidateName);

    /*
    |--------------------------------------------------------------------------
    | Hiring Signal
    |--------------------------------------------------------------------------
    */

    let signal = 'Review Required';
    let signalClass = 'warning';
    let signalIcon = 'mdi-eye-outline';

    if (matches.length === 0) {

        signal = 'No Company Role Match';
        signalClass = 'secondary';
        signalIcon = 'mdi-briefcase-remove-outline';

    } else if (score >= 85) {

        signal = 'Strong Candidate';
        signalClass = 'success';
        signalIcon = 'mdi-check-decagram-outline';

    } else if (score >= 70) {

        signal = 'Good Potential';
        signalClass = 'info';
        signalIcon = 'mdi-account-check-outline';

    } else if (score >= 50) {

        signal = 'Needs Recruiter Review';
        signalClass = 'warning';
        signalIcon = 'mdi-account-search-outline';

    } else {

        signal = 'Low Match';
        signalClass = 'danger';
        signalIcon = 'mdi-alert-circle-outline';
    }

    /*
    |--------------------------------------------------------------------------
    | Role Match Cards
    |--------------------------------------------------------------------------
    */

    let roleHtml = '';

    if (matches.length) {

        matches.forEach((role, index) => {

            const confidence = clampScore(
                role.confidence
            );

            const confidenceClass =
                confidence >= 80
                    ? 'success'
                    : confidence >= 60
                        ? 'info'
                        : 'warning';

            roleHtml += `
                <div class="overview-role-card">

                    <div class="d-flex align-items-center">

                        <div class="overview-role-number">
                            ${index + 1}
                        </div>

                        <div class="flex-grow-1 ms-3">

                            <div class="fw-bold text-dark">
                                Role ID ${escapeHtml(
                                    role.role_id ?? '-'
                                )}
                            </div>

                            <div class="small text-muted mt-1">
                                ${escapeHtml(
                                    role.reason ||
                                    'AI identified this role as a potential match.'
                                )}
                            </div>

                        </div>

                        <div class="text-end">

                            <div class="fw-bold text-${confidenceClass}">
                                ${confidence}%
                            </div>

                            <small class="text-muted">
                                Confidence
                            </small>

                        </div>

                    </div>

                    <div class="progress mt-3"
                         style="height:6px;">

                        <div
                            class="progress-bar bg-${confidenceClass}"
                            style="width:${confidence}%">
                        </div>

                    </div>

                </div>
            `;
        });

    } else {

        roleHtml = `
            <div class="overview-empty-state">

                <div class="overview-empty-icon">
                    <i class="mdi mdi-briefcase-remove-outline"></i>
                </div>

                <div>
                    <h6 class="fw-bold mb-1">
                        No Suitable Company Role Found
                    </h6>

                    <p class="text-muted mb-0 small">
                        AI did not find a sufficiently strong match
                        against the currently available company roles.
                    </p>
                </div>

            </div>
        `;
    }

    /*
    |--------------------------------------------------------------------------
    | Overview HTML
    |--------------------------------------------------------------------------
    */

    $('#overviewTab').html(`

        <!-- Candidate Summary -->
        <div class="overview-hero-card">

            <div class="d-flex flex-wrap align-items-center">

                <div class="overview-avatar">
                    ${escapeHtml(initials)}
                </div>

                <div class="ms-3 flex-grow-1">

                    <div class="d-flex flex-wrap align-items-center gap-2">

                        <h4 class="mb-0 fw-bold text-dark">
                            ${escapeHtml(candidateName)}
                        </h4>

                        <span class="badge bg-${signalClass}">
                            <i class="mdi ${signalIcon} me-1"></i>
                            ${signal}
                        </span>

                    </div>

                    <div class="text-muted mt-2">

                        ${
                            candidate.current_designation
                                ? escapeHtml(
                                    candidate.current_designation
                                )
                                : 'Designation not provided'
                        }

                    </div>

                    <div class="d-flex flex-wrap gap-2 mt-3">

                        ${
                            candidate.email
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-email-outline"></i>
                                        ${escapeHtml(candidate.email)}
                                    </span>
                                  `
                                : ''
                        }

                        ${
                            candidate.mobile
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-phone-outline"></i>
                                        ${escapeHtml(candidate.mobile)}
                                    </span>
                                  `
                                : ''
                        }

                        ${
                            candidate.location
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-map-marker-outline"></i>
                                        ${escapeHtml(candidate.location)}
                                    </span>
                                  `
                                : ''
                        }

                    </div>

                </div>

                <!-- Overall Score -->
                <div class="overview-score-wrapper">

                    <div
                        class="overview-score-circle"
                        style="--score:${score}"
                    >

                        <div>
                            <strong>
                                ${score}%
                            </strong>

                            <small>
                                ATS Match
                            </small>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Key Metrics -->
        <div class="row g-3 mt-1">

            ${overviewMetricCard(
                'Matched Roles',
                matches.length,
                'mdi-briefcase-check-outline',
                'primary'
            )}

            ${overviewMetricCard(
                'ATS Keywords',
                atsScore + '%',
                'mdi-key-outline',
                'info'
            )}

            ${overviewMetricCard(
                'Skills Alignment',
                skillsScore + '%',
                'mdi-code-tags-check',
                'success'
            )}

            ${overviewMetricCard(
                'Experience',
                experienceScore + '%',
                'mdi-briefcase-clock-outline',
                'warning'
            )}

        </div>


        <!-- Role Matching -->
        <div class="card overview-section-card mt-4">

            <div class="card-header bg-white border-0 pt-4 px-4">

                <div class="d-flex align-items-center">

                    <div class="overview-section-icon bg-primary-subtle text-primary">
                        <i class="mdi mdi-briefcase-search-outline"></i>
                    </div>

                    <div class="ms-3">

                        <h5 class="mb-1 fw-bold">
                            Company Role Matching
                        </h5>

                        <small class="text-muted">
                            AI matched this candidate against your available roles
                        </small>

                    </div>

                </div>

            </div>

            <div class="card-body px-4 pt-2">

                ${roleHtml}

            </div>

        </div>


        <!-- ATS Score Breakdown -->
        <div class="card overview-section-card mt-4">

            <div class="card-header bg-white border-0 pt-4 px-4">

                <div class="d-flex align-items-center">

                    <div class="overview-section-icon bg-success-subtle text-success">
                        <i class="mdi mdi-chart-box-outline"></i>
                    </div>

                    <div class="ms-3">

                        <h5 class="mb-1 fw-bold">
                            ATS Evaluation
                        </h5>

                        <small class="text-muted">
                            Overall resume quality and role suitability indicators
                        </small>

                    </div>

                </div>

            </div>

            <div class="card-body px-4">

                ${overviewScoreRow(
                    'ATS Keyword Match',
                    atsScore,
                    'mdi-key-outline'
                )}

                ${overviewScoreRow(
                    'Skills Alignment',
                    skillsScore,
                    'mdi-code-tags'
                )}

                ${overviewScoreRow(
                    'Experience Relevance',
                    experienceScore,
                    'mdi-briefcase-outline'
                )}

                ${overviewScoreRow(
                    'Impact & Achievements',
                    impactScore,
                    'mdi-chart-line'
                )}

                ${overviewScoreRow(
                    'Responsibility Match',
                    responsibilityScore,
                    'mdi-account-check-outline'
                )}

            </div>

        </div>


        <!-- Recruiter Snapshot -->
        <div class="row g-3 mt-1">

            <div class="col-lg-6">

                <div class="card overview-section-card h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center mb-3">

                            <div class="overview-section-icon bg-success-subtle text-success">
                                <i class="mdi mdi-star-check-outline"></i>
                            </div>

                            <h6 class="fw-bold mb-0 ms-3">
                                Candidate Strengths
                            </h6>

                        </div>

                        ${overviewBulletList(
                            aiResponse.strengths,
                            'success',
                            'mdi-check-circle-outline'
                        )}

                    </div>

                </div>

            </div>


            <div class="col-lg-6">

                <div class="card overview-section-card h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center mb-3">

                            <div class="overview-section-icon bg-danger-subtle text-danger">
                                <i class="mdi mdi-alert-circle-outline"></i>
                            </div>

                            <h6 class="fw-bold mb-0 ms-3">
                                Recruiter Attention Points
                            </h6>

                        </div>

                        ${overviewBulletList(
                            aiResponse.weaknesses,
                            'danger',
                            'mdi-alert-outline'
                        )}

                    </div>

                </div>

            </div>

        </div>


        <!-- Candidate Information -->
        <div class="card overview-section-card mt-4">

            <div class="card-body">

                <h6 class="fw-bold mb-4">
                    <i class="mdi mdi-account-details-outline me-2 text-primary"></i>
                    Candidate Information
                </h6>

                <div class="row g-4">

                    ${overviewInfo(
                        'Experience',
                        candidate.experience
                    )}

                    ${overviewInfo(
                        'Qualification',
                        candidate.qualification
                    )}

                    ${overviewInfo(
                        'Current Company',
                        candidate.current_company
                    )}

                    ${overviewInfo(
                        'Current Designation',
                        candidate.current_designation
                    )}

                    ${overviewInfo(
                        'Current CTC',
                        candidate.current_ctc
                    )}

                    ${overviewInfo(
                        'Expected CTC',
                        candidate.expected_ctc
                    )}

                    ${overviewInfo(
                        'Notice Period',
                        candidate.notice_period
                    )}

                    ${overviewInfo(
                        'Location',
                        candidate.location
                    )}

                </div>

            </div>

        </div>

    `);
}

function renderOverview(data)
{
    const candidate = data?.candidate || {};
    const ai = data?.ai || {};
    const aiResponse = ai?.ai_response || {};
    const matches = Array.isArray(ai?.matches) ? ai.matches : [];

    const score = clampScore(aiResponse.overall_match_score);
    const atsScore = clampScore(aiResponse.ats_keyword_match_score);
    const skillsScore = clampScore(aiResponse.skills_alignment_score);
    const experienceScore = clampScore(aiResponse.experience_relevance_score);
    const impactScore = clampScore(aiResponse.impact_metrics_score);
    const responsibilityScore =
        clampScore(aiResponse.role_responsibility_match_score);

    const candidateName =
        candidate.name ||
        candidate.email ||
        'Unnamed Candidate';

    const initials = getCandidateInitials(candidateName);

    /*
    |--------------------------------------------------------------------------
    | Hiring Signal
    |--------------------------------------------------------------------------
    */

    let signal = 'Recruiter Review Required';
    let signalClass = 'warning';
    let signalIcon = 'mdi-account-search-outline';

    if (!matches.length) {

        signal = 'No Suitable Company Role';
        signalClass = 'secondary';
        signalIcon = 'mdi-briefcase-remove-outline';

    } else if (score >= 85) {

        signal = 'Strong Candidate';
        signalClass = 'success';
        signalIcon = 'mdi-check-decagram-outline';

    } else if (score >= 70) {

        signal = 'Good Potential';
        signalClass = 'info';
        signalIcon = 'mdi-account-check-outline';

    } else if (score >= 50) {

        signal = 'Needs Review';
        signalClass = 'warning';
        signalIcon = 'mdi-account-search-outline';

    } else {

        signal = 'Low ATS Match';
        signalClass = 'danger';
        signalIcon = 'mdi-alert-circle-outline';

    }

    /*
    |--------------------------------------------------------------------------
    | Score helper
    |--------------------------------------------------------------------------
    */

    function scoreColor(value)
    {
        if (value >= 80) return 'success';
        if (value >= 60) return 'info';
        if (value >= 40) return 'warning';

        return 'danger';
    }

    function scoreLabel(value)
    {
        if (value >= 85) return 'Excellent';
        if (value >= 70) return 'Strong';
        if (value >= 50) return 'Moderate';

        return 'Needs Improvement';
    }

    function scoreCard(
        label,
        value,
        icon
    ) {

        const color = scoreColor(value);

        return `
            <div class="col-xl-4 col-md-6 mb-3">

                <div class="ai-score-card">

                    <div class="d-flex align-items-center justify-content-between">

                        <div class="d-flex align-items-center gap-2">

                            <div class="ai-score-icon text-${color}">
                                <i class="mdi ${icon}"></i>
                            </div>

                            <div>

                                <div class="small text-muted">
                                    ${escapeHtml(label)}
                                </div>

                                <div class="fw-bold text-dark">
                                    ${scoreLabel(value)}
                                </div>

                            </div>

                        </div>

                        <div class="ai-score-number text-${color}">
                            ${value}%
                        </div>

                    </div>

                    <div
                        class="progress mt-3"
                        style="height:6px;"
                    >
                        <div
                            class="progress-bar bg-${color}"
                            style="width:${value}%"
                        ></div>
                    </div>

                </div>

            </div>
        `;
    }

    /*
    |--------------------------------------------------------------------------
    | Role Matches
    |--------------------------------------------------------------------------
    */

    let roleHtml = '';

    if (matches.length > 0) {

        matches.forEach(function(role, index) {

            const confidence =
                clampScore(role?.confidence);

            const color =
                scoreColor(confidence);

            roleHtml += `
                <div class="overview-role-card">

                    <div class="d-flex align-items-start">

                        <div class="overview-role-number">
                            ${index + 1}
                        </div>

                        <div class="flex-grow-1 ms-3">

                            <div class="d-flex align-items-center gap-2">

                                <span class="fw-bold text-dark">
                                    Company Role
                                </span>

                                <span class="badge bg-light-primary text-primary">
                                    Role ID:
                                    ${escapeHtml(
                                        role?.role_id ?? '-'
                                    )}
                                </span>

                            </div>

                            <div class="small text-muted mt-2">
                                ${escapeHtml(
                                    role?.reason ||
                                    'AI identified a relevant match based on the candidate profile.'
                                )}
                            </div>

                        </div>

                        <div class="text-end ms-3">

                            <div class="fw-bold text-${color} fs-5">
                                ${confidence}%
                            </div>

                            <small class="text-muted">
                                Confidence
                            </small>

                        </div>

                    </div>

                    <div
                        class="progress mt-3"
                        style="height:6px;"
                    >
                        <div
                            class="progress-bar bg-${color}"
                            style="width:${confidence}%"
                        ></div>
                    </div>

                </div>
            `;

        });

    } else {

        roleHtml = `
            <div class="overview-empty-state">

                <div class="overview-empty-icon">
                    <i class="mdi mdi-briefcase-remove-outline"></i>
                </div>

                <div>

                    <h6 class="fw-bold mb-1">
                        No Suitable Company Role Found
                    </h6>

                    <p class="text-muted mb-0 small">
                        The AI did not identify a sufficiently strong
                        match against the company's available roles.
                    </p>

                    <div class="mt-2 small text-muted">
                        Recruiter can still review the candidate's
                        complete resume and AI evaluation.
                    </div>

                </div>

            </div>
        `;

    }

    /*
    |--------------------------------------------------------------------------
    | Strengths
    |--------------------------------------------------------------------------
    */

    const strengths =
        Array.isArray(aiResponse.strengths)
            ? aiResponse.strengths
            : [];

    const weaknesses =
        Array.isArray(aiResponse.weaknesses)
            ? aiResponse.weaknesses
            : [];

    const missingKeywords =
        Array.isArray(aiResponse.missing_keywords)
            ? aiResponse.missing_keywords
            : [];

    const improvements =
        Array.isArray(aiResponse.resume_improvements)
            ? aiResponse.resume_improvements
            : [];

    function renderList(
        items,
        emptyText,
        icon,
        color
    ) {

        if (!items.length) {

            return `
                <div class="text-muted small">
                    ${escapeHtml(emptyText)}
                </div>
            `;

        }

        return items.map(function(item) {

            return `
                <div class="ai-insight-item">

                    <i class="mdi ${icon} text-${color}"></i>

                    <span>
                        ${escapeHtml(item)}
                    </span>

                </div>
            `;

        }).join('');

    }

    /*
    |--------------------------------------------------------------------------
    | Candidate Information
    |--------------------------------------------------------------------------
    */

    const information = [

        {
            label: 'Email',
            value: candidate.email,
            icon: 'mdi-email-outline'
        },

        {
            label: 'Mobile',
            value: candidate.mobile,
            icon: 'mdi-phone-outline'
        },

        {
            label: 'Experience',
            value: candidate.experience,
            icon: 'mdi-briefcase-outline'
        },

        {
            label: 'Qualification',
            value: candidate.qualification,
            icon: 'mdi-school-outline'
        },

        {
            label: 'Current Company',
            value: candidate.current_company,
            icon: 'mdi-domain'
        },

        {
            label: 'Current Designation',
            value: candidate.current_designation,
            icon: 'mdi-account-tie-outline'
        },

        {
            label: 'Location',
            value: candidate.location,
            icon: 'mdi-map-marker-outline'
        },

        {
            label: 'Notice Period',
            value: candidate.notice_period,
            icon: 'mdi-calendar-clock-outline'
        }

    ];

    const informationHtml =
        information
            .filter(item => item.value)
            .map(item => `
                <div class="col-xl-3 col-md-6 mb-3">

                    <div class="candidate-info-item">

                        <div class="candidate-info-icon">
                            <i class="mdi ${item.icon}"></i>
                        </div>

                        <div>

                            <div class="small text-muted">
                                ${escapeHtml(item.label)}
                            </div>

                            <div class="fw-semibold text-dark text-break">
                                ${escapeHtml(item.value)}
                            </div>

                        </div>

                    </div>

                </div>
            `)
            .join('');

    /*
    |--------------------------------------------------------------------------
    | Main Overview
    |--------------------------------------------------------------------------
    */

    $('#overviewTab').html(`

        <!-- Candidate Header -->

        <div class="overview-hero-card mb-4">

            <div class="d-flex flex-wrap align-items-center">

                <div class="overview-avatar">
                    ${escapeHtml(initials)}
                </div>

                <div class="ms-3 flex-grow-1">

                    <div class="d-flex flex-wrap align-items-center gap-2">

                        <h4 class="mb-0 fw-bold text-dark">
                            ${escapeHtml(candidateName)}
                        </h4>

                        <span class="badge bg-${signalClass}">
                            <i class="mdi ${signalIcon} me-1"></i>
                            ${escapeHtml(signal)}
                        </span>

                    </div>

                    <div class="text-muted mt-2">

                        ${
                            candidate.current_designation
                                ? escapeHtml(
                                    candidate.current_designation
                                )
                                : 'Designation not provided'
                        }

                    </div>

                    <div class="d-flex flex-wrap gap-2 mt-3">

                        ${
                            candidate.email
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-email-outline"></i>
                                        ${escapeHtml(candidate.email)}
                                    </span>
                                `
                                : ''
                        }

                        ${
                            candidate.mobile
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-phone-outline"></i>
                                        ${escapeHtml(candidate.mobile)}
                                    </span>
                                `
                                : ''
                        }

                        ${
                            candidate.location
                                ? `
                                    <span class="overview-contact-chip">
                                        <i class="mdi mdi-map-marker-outline"></i>
                                        ${escapeHtml(candidate.location)}
                                    </span>
                                `
                                : ''
                        }

                    </div>

                </div>

                <div class="text-center mt-3 mt-lg-0">

                    <div class="overview-main-score">

                        <div class="overview-main-score-value">
                            ${score}%
                        </div>

                        <div class="small text-muted">
                            Overall ATS
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Candidate Information -->

        <div class="card border-0 shadow-sm mb-4">

            <div class="card-header bg-transparent">

                <h5 class="mb-0 fw-bold">
                    <i class="mdi mdi-account-details-outline me-2 text-primary"></i>
                    Candidate Information
                </h5>

            </div>

            <div class="card-body">

                <div class="row">
                    ${informationHtml || `
                        <div class="col-12">
                            <div class="text-muted">
                                Candidate information is not available.
                            </div>
                        </div>
                    `}
                </div>

            </div>

        </div>


        <!-- AI Score Dashboard -->

        <div class="card border-0 shadow-sm mb-4">

            <div class="card-header bg-transparent">

                <div class="d-flex align-items-center justify-content-between">

                    <div>

                        <h5 class="mb-1 fw-bold">
                            <i class="mdi mdi-chart-box-outline me-2 text-primary"></i>
                            Recruiter AI Scorecard
                        </h5>

                        <small class="text-muted">
                            Resume-level evaluation generated by the AI screening engine
                        </small>

                    </div>

                    <span class="badge bg-light-primary text-primary">
                        AI Evaluation
                    </span>

                </div>

            </div>

            <div class="card-body">

                <div class="row">

                    ${scoreCard(
                        'ATS Keyword Match',
                        atsScore,
                        'mdi-text-search'
                    )}

                    ${scoreCard(
                        'Skills Alignment',
                        skillsScore,
                        'mdi-tools'
                    )}

                    ${scoreCard(
                        'Experience Relevance',
                        experienceScore,
                        'mdi-briefcase-check-outline'
                    )}

                    ${scoreCard(
                        'Impact & Achievements',
                        impactScore,
                        'mdi-trending-up'
                    )}

                    ${scoreCard(
                        'Role Responsibility Match',
                        responsibilityScore,
                        'mdi-clipboard-check-outline'
                    )}

                    ${scoreCard(
                        'Overall Match',
                        score,
                        'mdi-star-check-outline'
                    )}

                </div>

            </div>

        </div>


        <!-- Company Role Matches -->

        <div class="card border-0 shadow-sm mb-4">

            <div class="card-header bg-transparent">

                <h5 class="mb-1 fw-bold">

                    <i class="mdi mdi-briefcase-search-outline me-2 text-primary"></i>

                    Company Role Matching

                </h5>

                <small class="text-muted">
                    Only roles supplied by the company's recruitment database are displayed.
                </small>

            </div>

            <div class="card-body">

                ${roleHtml}

            </div>

        </div>


        <!-- Recruiter Insights -->

        <div class="row">

            <div class="col-lg-6 mb-4">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-header bg-transparent">

                        <h5 class="mb-0 fw-bold">
                            <i class="mdi mdi-thumb-up-outline text-success me-2"></i>
                            Candidate Strengths
                        </h5>

                    </div>

                    <div class="card-body">

                        ${renderList(
                            strengths,
                            'No major strengths were identified.',
                            'mdi-check-circle-outline',
                            'success'
                        )}

                    </div>

                </div>

            </div>


            <div class="col-lg-6 mb-4">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-header bg-transparent">

                        <h5 class="mb-0 fw-bold">
                            <i class="mdi mdi-alert-circle-outline text-danger me-2"></i>
                            Candidate Weaknesses
                        </h5>

                    </div>

                    <div class="card-body">

                        ${renderList(
                            weaknesses,
                            'No significant weaknesses were identified.',
                            'mdi-alert-outline',
                            'danger'
                        )}

                    </div>

                </div>

            </div>


            <div class="col-lg-6 mb-4">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-header bg-transparent">

                        <h5 class="mb-0 fw-bold">
                            <i class="mdi mdi-key-remove-outline text-warning me-2"></i>
                            Missing Keywords
                        </h5>

                    </div>

                    <div class="card-body">

                        ${
                            missingKeywords.length
                                ? missingKeywords.map(keyword => `
                                    <span class="badge bg-label-warning me-1 mb-2">
                                        ${escapeHtml(keyword)}
                                    </span>
                                `).join('')
                                : `
                                    <div class="text-muted small">
                                        No important missing keywords identified.
                                    </div>
                                `
                        }

                    </div>

                </div>

            </div>


            <div class="col-lg-6 mb-4">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-header bg-transparent">

                        <h5 class="mb-0 fw-bold">
                            <i class="mdi mdi-file-edit-outline text-info me-2"></i>
                            Resume Improvement Recommendations
                        </h5>

                    </div>

                    <div class="card-body">

                        ${renderList(
                            improvements,
                            'No specific resume improvements were identified.',
                            'mdi-lightbulb-outline',
                            'info'
                        )}

                    </div>

                </div>

            </div>

        </div>

    `);
}

function clampScore(value)
{
    value = Number(value || 0);

    return Math.max(
        0,
        Math.min(100, Math.round(value))
    );
}


function getCandidateInitials(name)
{
    const parts = String(name || 'A')
        .trim()
        .split(/\s+/)
        .filter(Boolean);

    if (!parts.length) {
        return 'A';
    }

    if (parts.length === 1) {
        return parts[0].charAt(0).toUpperCase();
    }

    return (
        parts[0].charAt(0) +
        parts[parts.length - 1].charAt(0)
    ).toUpperCase();
}


function overviewMetricCard(
    label,
    value,
    icon,
    color
)
{
    return `
        <div class="col-xl-3 col-md-6">

            <div class="overview-metric-card">

                <div class="overview-metric-icon bg-${color}-subtle text-${color}">
                    <i class="mdi ${icon}"></i>
                </div>

                <div class="flex-grow-1">

                    <div class="small text-muted">
                        ${label}
                    </div>

                    <div class="fs-4 fw-bold text-dark mt-1">
                        ${escapeHtml(String(value))}
                    </div>

                </div>

            </div>

        </div>
    `;
}


function overviewScoreRow(
    label,
    score,
    icon
)
{
    score = clampScore(score);

    const color =
        score >= 80
            ? 'success'
            : score >= 60
                ? 'info'
                : score >= 40
                    ? 'warning'
                    : 'danger';

    return `
        <div class="mb-4">

            <div class="d-flex justify-content-between align-items-center mb-2">

                <div class="d-flex align-items-center">

                    <i class="mdi ${icon} text-muted me-2"></i>

                    <span class="fw-semibold">
                        ${label}
                    </span>

                </div>

                <strong class="text-${color}">
                    ${score}%
                </strong>

            </div>

            <div class="progress"
                 style="height:8px;">

                <div
                    class="progress-bar bg-${color}"
                    style="width:${score}%">
                </div>

            </div>

        </div>
    `;
}


function overviewBulletList(
    items,
    color,
    icon
)
{
    if (!Array.isArray(items) || !items.length) {

        return `
            <div class="text-muted small py-3">
                No information available.
            </div>
        `;
    }

    return `
        <div class="overview-bullet-list">

            ${items.map(item => `
                <div class="overview-bullet-item">

                    <i class="mdi ${icon} text-${color}"></i>

                    <span>
                        ${escapeHtml(String(item))}
                    </span>

                </div>
            `).join('')}

        </div>
    `;
}


function overviewInfo(label, value)
{
    return `
        <div class="col-md-6 col-xl-3">

            <div class="overview-info-item">

                <div class="small text-muted mb-1">
                    ${escapeHtml(label)}
                </div>

                <div class="fw-semibold text-dark text-break">
                    ${escapeHtml(
                        value !== null &&
                        value !== undefined &&
                        String(value).trim() !== ''
                            ? String(value)
                            : 'Not provided'
                    )}
                </div>

            </div>

        </div>
    `;
}

function escapeHtml(value)
{
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function renderCustomResumeViewer(
    fileUrl,
    fileInfo,
    resume,
    candidate
) {

    const resumeText =
        String(resume?.text || '').trim();

    const attachment =
        String(resume?.attachment || '').trim();

    /*
    |--------------------------------------------------------------------------
    | No Resume
    |--------------------------------------------------------------------------
    */

    if (!attachment && !resumeText) {

        return `
            <div class="custom-resume-empty">

                <div class="custom-resume-empty-icon">
                    <i class="mdi mdi-file-alert-outline"></i>
                </div>

                <h5 class="fw-bold mt-3">
                    Resume Not Available
                </h5>

                <p class="text-muted mb-0">
                    No resume file or extracted resume content is available.
                </p>

            </div>
        `;

    }

    /*
    |--------------------------------------------------------------------------
    | PDF
    |--------------------------------------------------------------------------
    */

    if (fileInfo?.type === 'pdf') {

        return `
            <div class="custom-resume-wrapper">

                <div class="custom-resume-toolbar">

                    <div class="d-flex align-items-center gap-2">

                        <span class="custom-file-icon pdf">
                            <i class="mdi mdi-file-pdf-box"></i>
                        </span>

                        <div>

                            <div class="fw-bold">
                                Resume Preview
                            </div>

                            <small class="text-muted">
                                PDF document
                            </small>

                        </div>

                    </div>

                    <div class="d-flex gap-2">

                        <a
                            href="${escapeAttribute(fileUrl)}"
                            target="_blank"
                            rel="noopener"
                            class="btn btn-sm btn-light-primary">

                            <i class="mdi mdi-open-in-new me-1"></i>

                            Open

                        </a>

                        <a
                            href="${escapeAttribute(fileUrl)}"
                            download
                            class="btn btn-sm btn-primary">

                            <i class="mdi mdi-download-outline me-1"></i>

                            Download

                        </a>

                    </div>

                </div>

                <div class="custom-pdf-viewer">

                    <iframe
                        src="${escapeAttribute(fileUrl)}#toolbar=1&navpanes=0&view=FitH"
                        title="Candidate Resume"
                        loading="lazy">
                    </iframe>

                </div>

            </div>
        `;

    }

    /*
    |--------------------------------------------------------------------------
    | DOC / DOCX
    |--------------------------------------------------------------------------
    */

    if (
        fileInfo?.type === 'document' ||
        fileInfo?.extension === 'doc' ||
        fileInfo?.extension === 'docx'
    ) {

        return `
            <div class="custom-resume-wrapper">

                <!-- Toolbar -->

                <div class="custom-resume-toolbar">

                    <div class="d-flex align-items-center gap-2">

                        <span class="custom-file-icon word">
                            <i class="mdi mdi-file-word-box"></i>
                        </span>

                        <div>

                            <div class="fw-bold">
                                Resume Document
                            </div>

                            <small class="text-muted">
                                ${escapeHtml(
                                    fileInfo?.extension?.toUpperCase() || 'DOCUMENT'
                                )}
                                • Recruiter View
                            </small>

                        </div>

                    </div>

                    <div class="d-flex gap-2">

                        <a
                            href="${escapeAttribute(fileUrl)}"
                            target="_blank"
                            rel="noopener"
                            class="btn btn-sm btn-light-primary">

                            <i class="mdi mdi-open-in-new me-1"></i>

                            Original

                        </a>

                        <a
                            href="${escapeAttribute(fileUrl)}"
                            download
                            class="btn btn-sm btn-primary">

                            <i class="mdi mdi-download-outline me-1"></i>

                            Download

                        </a>

                    </div>

                </div>


                <!-- Document information -->

                <div class="custom-doc-info">

                    <div>

                        <i class="mdi mdi-file-document-outline"></i>

                        <span>
                            ${escapeHtml(
                                attachment || 'Resume document'
                            )}
                        </span>

                    </div>

                    <span class="badge bg-label-primary">
                        Recruiter Document View
                    </span>

                </div>


                <!-- Document -->

                <div class="custom-document-stage">

                    <div class="custom-document-page">

                        <div class="custom-document-header">

                            <div class="custom-document-title">
                                Candidate Resume
                            </div>

                            <div class="custom-document-meta">
                                ${escapeHtml(
                                    candidateSafeName()
                                )}
                            </div>

                        </div>

                        <div class="custom-document-content">

                            ${
                                resumeText
                                    ? formatResumeText(
                                        resumeText
                                      )
                                    : `
                                        <div class="text-center py-5">

                                            <i class="mdi mdi-file-alert-outline fs-1 text-muted"></i>

                                            <h6 class="mt-3 fw-bold">
                                                Resume text unavailable
                                            </h6>

                                            <p class="text-muted">
                                                Please use the Original button
                                                to open the DOC/DOCX file.
                                            </p>

                                        </div>
                                      `
                            }

                        </div>

                    </div>

                </div>

            </div>
        `;

    }

    /*
    |--------------------------------------------------------------------------
    | IMAGE
    |--------------------------------------------------------------------------
    */

    if (fileInfo?.type === 'image') {

        return `
            <div class="custom-resume-wrapper">

                <div class="custom-resume-toolbar">

                    <div class="d-flex align-items-center gap-2">

                        <span class="custom-file-icon image">
                            <i class="mdi mdi-file-image-box"></i>
                        </span>

                        <div>

                            <div class="fw-bold">
                                Resume Image
                            </div>

                            <small class="text-muted">
                                Image preview
                            </small>

                        </div>

                    </div>

                    <div class="d-flex gap-2">

                        <button
                            type="button"
                            class="btn btn-sm btn-light"
                            onclick="resumeImageZoom(-0.1)">

                            <i class="mdi mdi-minus"></i>

                        </button>

                        <span
                            id="resumeImageZoomValue"
                            class="px-2 align-self-center">

                            100%

                        </span>

                        <button
                            type="button"
                            class="btn btn-sm btn-light"
                            onclick="resumeImageZoom(0.1)">

                            <i class="mdi mdi-plus"></i>

                        </button>

                        <button
                            type="button"
                            class="btn btn-sm btn-light"
                            onclick="resumeImageReset()">

                            <i class="mdi mdi-refresh"></i>

                        </button>

                        <a
                            href="${escapeAttribute(fileUrl)}"
                            download
                            class="btn btn-sm btn-primary">

                            <i class="mdi mdi-download-outline"></i>

                        </a>

                    </div>

                </div>

                <div
                    class="custom-image-stage"
                    id="resumeImageStage">

                    <img
                        id="resumeImagePreview"
                        src="${escapeAttribute(fileUrl)}"
                        alt="Candidate Resume"
                        class="custom-image-preview">

                </div>

            </div>
        `;

    }

    /*
    |--------------------------------------------------------------------------
    | TXT / Extracted Text
    |--------------------------------------------------------------------------
    */

    return `
        <div class="custom-resume-wrapper">

            <div class="custom-resume-toolbar">

                <div class="d-flex align-items-center gap-2">

                    <span class="custom-file-icon text">
                        <i class="mdi mdi-file-document-outline"></i>
                    </span>

                    <div>

                        <div class="fw-bold">
                            Resume Text
                        </div>

                        <small class="text-muted">
                            Recruiter reading view
                        </small>

                    </div>

                </div>

                ${
                    fileUrl
                        ? `
                            <a
                                href="${escapeAttribute(fileUrl)}"
                                download
                                class="btn btn-sm btn-primary">

                                <i class="mdi mdi-download-outline me-1"></i>

                                Download

                            </a>
                          `
                        : ''
                }

            </div>

            <div class="custom-document-stage">

                <div class="custom-document-page">

                    <div class="custom-document-content">

                        ${
                            resumeText
                                ? formatResumeText(
                                    resumeText
                                  )
                                : `
                                    <div class="text-muted text-center py-5">
                                        Resume content unavailable.
                                    </div>
                                  `
                        }

                    </div>

                </div>

            </div>

        </div>
    `;
}

function formatResumeText(text)
{
    if (!text) {
        return '';
    }

    let clean = String(text)
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n');

    /*
    |--------------------------------------------------------------------------
    | Remove excessive duplicate whitespace
    |--------------------------------------------------------------------------
    */

    clean = clean
        .replace(/[ \t]+/g, ' ')
        .replace(/\n{3,}/g, '\n\n')
        .trim();

    const lines = clean.split('\n');

    let html = '';

    lines.forEach(function(line) {

        line = line.trim();

        if (!line) {

            html += `
                <div class="resume-doc-spacer"></div>
            `;

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Detect common resume headings
        |--------------------------------------------------------------------------
        */

        const headingPatterns = [

            /^professional summary$/i,
            /^summary$/i,
            /^profile$/i,
            /^objective$/i,
            /^education$/i,
            /^experience$/i,
            /^work experience$/i,
            /^professional experience$/i,
            /^employment history$/i,
            /^technical skills$/i,
            /^skills$/i,
            /^certifications$/i,
            /^projects$/i,
            /^languages$/i,
            /^achievements$/i,
            /^awards$/i,
            /^responsibilities$/i,
            /^personal information$/i

        ];

        const isHeading =
            headingPatterns.some(
                pattern => pattern.test(line)
            );

        if (isHeading) {

            html += `
                <div class="resume-doc-heading">
                    <i class="mdi mdi-chevron-right"></i>
                    ${escapeHtml(line)}
                </div>
            `;

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Bullet points
        |--------------------------------------------------------------------------
        */

        if (
            /^[•●▪◦\-*]\s*/.test(line)
        ) {

            const bullet =
                line.replace(
                    /^[•●▪◦\-*]\s*/,
                    ''
                );

            html += `
                <div class="resume-doc-bullet">

                    <span class="resume-doc-bullet-icon">
                        <i class="mdi mdi-circle-small"></i>
                    </span>

                    <span>
                        ${escapeHtml(bullet)}
                    </span>

                </div>
            `;

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Normal paragraph
        |--------------------------------------------------------------------------
        */

        html += `
            <p class="resume-doc-paragraph">
                ${escapeHtml(line)}
            </p>
        `;

    });

    return html;
}


function candidateSafeName()
{
    /*
     * renderCustomResumeViewer does not receive candidate directly.
     * Keep this intentionally generic.
     */

    return 'Candidate';
}
</script>
@endsection

<!-- ALTER TABLE egc_applicant
MODIFY resume_text LONGTEXT
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;


ALTER TABLE egc_applicant
MODIFY ai_response LONGTEXT
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;


ALTER TABLE egc_applicant
MODIFY ai_summary TEXT
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci; -->
