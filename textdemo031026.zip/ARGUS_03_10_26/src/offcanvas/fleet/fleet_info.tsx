import { CalendarIcon, PencilSimpleIcon, ShieldCheckIcon, TruckIcon, WrenchIcon } from "@phosphor-icons/react";
import { FleetFormValues } from "../../types/fleet";
import OffCanvas from "../../components/OffCanvas";


/* =========================================================
   PROPS
========================================================= */
interface FleetInfoProps {
    isOpen: boolean;
    onClose: () => void;
    fleet: FleetFormValues | null;
    onEdit?: (fleet: FleetFormValues) => void;
}

/* =========================================================
   HELPERS
========================================================= */
const formatDate = (value?: string) => {
    if (!value) return "—";
    const d = new Date(value);
    if (isNaN(d.getTime())) return value;
    return d.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    });
};

const formatCurrency = (value?: string | number) => {
    if (value === undefined || value === null || value === "") return "—";
    const num = typeof value === "string" ? Number(value) : value;
    if (isNaN(num)) return String(value);
    return `₹ ${num.toLocaleString("en-IN")}`;
};

const display = (value?: string | number | null) => {
    if (value === undefined || value === null || value === "") return "—";
    return String(value);
};

/* Small status pill */
const StatusPill = ({ label, tone }: { label: string; tone: "green" | "amber" | "red" | "slate" }) => {
    const tones: Record<string, string> = {
        green: "bg-emerald-50 text-emerald-700 border-emerald-200",
        amber: "bg-amber-50 text-amber-700 border-amber-200",
        red: "bg-red-50 text-red-700 border-red-200",
        slate: "bg-slate-100 text-slate-600 border-slate-200",
    };
    return (
        <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold ${tones[tone]}`}>
            {label}
        </span>
    );
};

const insuranceTone = (status?: string): "green" | "amber" | "red" | "slate" => {
    if (!status) return "slate";
    const s = status.toLowerCase();
    if (s === "active") return "green";
    if (s === "expiring") return "amber";
    if (s === "expired") return "red";
    return "slate";
};

/* =========================================================
   SECTION WRAPPER
========================================================= */
const Section = ({
    icon,
    title,
    children,
}: {
    icon: React.ReactNode;
    title: string;
    children: React.ReactNode;
}) => (
    <section className="flex h-full flex-col">
        <div className="mb-4 flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-red-50 text-red-600">
                {icon}
            </div>
            <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                {title}
            </h3>
        </div>
        <div className="flex-1 rounded-xl border border-slate-200 bg-slate-50/50 p-4">
            {children}
        </div>
    </section>
);

/* =========================================================
   ROW — label / value pair
========================================================= */
const Row = ({
    label,
    value,
    full,
}: {
    label: string;
    value: React.ReactNode;
    full?: boolean;
}) => (
    <div className={full ? "sm:col-span-2" : ""}>
        <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
            {label}
        </p>
        <p className="mt-1 text-sm font-medium text-slate-800 break-words">
            {value}
        </p>
    </div>
);

/* =========================================================
   MAIN COMPONENT
========================================================= */
const FleetInfo = ({ isOpen, onClose, fleet, onEdit }: FleetInfoProps) => {
    if (!fleet) return null;

    const f = fleet as any;

    // const footer = (
    //     <div className="flex items-center justify-end gap-3">
    //         <button
    //             type="button"
    //             onClick={onClose}
    //             className="
    //                 rounded-lg border border-slate-200 bg-white px-4 py-2.5
    //                 text-sm font-semibold text-slate-600 transition hover:bg-slate-50
    //             "
    //         >
    //             Close
    //         </button>

    //         {/* {onEdit && (
    //             <button
    //                 type="button"
    //                 onClick={() => onEdit(fleet)}
    //                 className="
    //                     flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5
    //                     text-sm font-semibold text-white shadow-sm transition hover:bg-red-700
    //                 "
    //             >
    //                 <PencilSimpleIcon size={16} weight="bold" />
    //                 Edit Fleet
    //             </button>
    //         )} */}
    //     </div>
    // );

    return (
        <OffCanvas
    isOpen={isOpen}
    onClose={onClose}
    title={fleet.vehicleName || "Fleet Details"}   // still used as aria fallback / non-slot render
    subtitle={
        fleet.fleetCode
            ? `Fleet Code · ${fleet.fleetCode}`
            : "Fleet / Vehicle information"
    }
    widthClass="max-w-[1000px]"
    headerSlot={
        <div className="flex items-start justify-between gap-3 pr-2">
            <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-red-50 text-red-600">
                    <TruckIcon size={22} weight="duotone" />
                </div>
                <div>
                    <p className="text-sm font-bold text-slate-900">
                        {display(fleet.vehicleName)}
                    </p>
                    <p className="text-xs text-slate-500">
                        {display(fleet.fleetCode)} · {display(fleet.registrationNo)}
                    </p>
                </div>
            </div>

            {fleet.insuranceStatus && (
                <StatusPill
                    label={
                        fleet.insuranceStatus === "active"
                            ? "Active"
                            : fleet.insuranceStatus === "expiring"
                            ? "Expiring"
                            : "Expired"
                    }
                    tone={insuranceTone(fleet.insuranceStatus)}
                />
            )}
        </div>
    }
>
            <div className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-2">

                {/* ============ 1. BASE DETAILS ============ */}
                <Section icon={<TruckIcon size={14} weight="bold" />} title="Base Details">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Fleet / Vehicle Code" value={display(fleet.fleetCode)} />
                        <Row label="Vehicle Name" value={display(fleet.vehicleName)} />
                        <Row label="Vehicle Category" value={display(fleet.category)} />
                        <Row label="Registration No" value={display(fleet.registrationNo)} />
                        <Row label="Chassis VIN No" value={display(f.chassisVinNo)} />
                        <Row label="Engine No" value={display(f.engineNo)} />
                        <Row label="Make / Brand" value={display(f.makeBrand)} />
                        <Row label="Model Variant" value={display(f.modelVariant)} />
                        <Row label="Mfg Year" value={display(f.mfgYear)} />
                    </div>
                </Section>

                {/* ============ 2. INSURANCE ============ */}
                <Section icon={<ShieldCheckIcon size={14} weight="bold" />} title="Insurance">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Insurance Name" value={display(fleet.insurance_name)} full />
                        <Row label="Insurance Provider" value={display(f.insuranceProvider)} full />
                        <Row label="Policy Number" value={display(f.policyNumber)} />
                        <Row label="Annual Premium" value={formatCurrency(f.annualPremium)} />
                        <Row
                            label="Insurance Status"
                            value={
                                fleet.insuranceStatus ? (
                                    <StatusPill
                                        label={
                                            fleet.insuranceStatus === "active"
                                                ? "Active & Valid"
                                                : fleet.insuranceStatus === "expiring"
                                                ? "Expiring Soon"
                                                : "Expired"
                                        }
                                        tone={insuranceTone(fleet.insuranceStatus)}
                                    />
                                ) : (
                                    "—"
                                )
                            }
                        />
                        <Row
                            label="Insurance Expiry Date"
                            value={formatDate(fleet.insuranceExpiryDate)}
                        />
                    </div>
                </Section>

                {/* ============ 3. OWNERSHIP ============ */}
                <Section icon={<CalendarIcon size={14} weight="bold" />} title="Owned Details">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Ownership Type" value={display(f.ownershipType)} />
                        <Row label="Purchase Date" value={formatDate(f.purchaseDate)} />
                        <Row label="Purchase Cost" value={formatCurrency(f.purchaseCost)} />
                        <Row label="Vendor / Dealer Name" value={display(f.vendorDealerName)} full />
                    </div>
                </Section>

                {/* ============ 4. SERVICE DETAILS ============ */}
                <Section icon={<WrenchIcon size={14} weight="bold" />} title="Service Details">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Service Interval" value={display(fleet.serviceInterval)} />
                        <Row label="Warranty Status" value={display(fleet.warrantyStatus)} />
                        <Row label="Last Service Date" value={formatDate(fleet.lastServiceDate)} />
                        <Row
                            label="Next Service Due Date"
                            value={formatDate(fleet.nextServiceDueDate)}
                        />
                        <Row
                            label="Preferred Workshop"
                            value={display(fleet.preferredWorkshop)}
                            full
                        />
                    </div>
                </Section>

            </div>
        </OffCanvas>
    );
};

export default FleetInfo;