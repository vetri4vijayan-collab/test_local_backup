import { useState, useEffect } from "react";
import { CheckIcon, XIcon } from "@phosphor-icons/react";
import Select, { SingleValue, StylesConfig } from "react-select";
import { emptyFleetForm, FleetFormValues } from "../../types/fleet";
import { todayIso } from "../../data/fleet_datas";

/* =========================================================
   PROPS
========================================================= */
interface AddNewFleetProps {
    isOpen: boolean;
    onClose: () => void;
    onSave?: (fleet: FleetFormValues) => void;
    editingFleet?: FleetFormValues | null;
}

/* =========================================================
   SELECT OPTIONS
========================================================= */
interface SelectOption {
    value: string;
    label: string;
}

const assignedVendorOptions: SelectOption[] = [
    { value: "Flow Jamaica", label: "Flow Jamaica" },
    { value: "Seiretsu", label: "Seiretsu" },
    { value: "Jon doe", label: "Jon doe" },
];
const insuranceStatusOptions: SelectOption[] = [
    { value: "active", label: "Active & Valid" },
    { value: "expiring", label: "Expiring Soon" },
    { value: "expired", label: "Expired" },
];

const emiStatusOptions: SelectOption[] = [
    { label: "Active", value: "active" },
    { label: "Expired", value: "expired" },
];

const vehicleCategoryOptions: SelectOption[] = [
    { value: "Bucket Truck", label: "Bucket Truck" },
    { value: "Splicer Van", label: "Splicer Van" },
    { value: "Field Service Pickup", label: "Field Service Pickup" },
];

const ownershipTypeOptions: SelectOption[] = [
    { value: "Company Owned", label: "Company Owned" },
    { value: "Leased", label: "Leased" },
    { value: "Rented", label: "Rented" },
    { value: "Financed", label: "Financed" },
];

const warrantyStatusOptions: SelectOption[] = [
    { value: "Under Warranty", label: "Under Warranty" },
    { value: "Extended Warranty", label: "Extended Warranty" },
    { value: "Out of Warranty", label: "Out of Warranty" },
];

/* =========================================================
   SELECT STYLES
========================================================= */
const selectStyles: StylesConfig<SelectOption, false> = {
    control: (base, state) => ({
        ...base,
        minHeight: "42px",
        borderRadius: "8px",
        borderColor: state.isFocused ? "#fca5a5" : "#e2e8f0",
        backgroundColor: state.isFocused ? "#ffffff" : "#f8fafc",
        boxShadow: state.isFocused ? "0 0 0 1px #fca5a5" : "none",
        cursor: "pointer",
        "&:hover": { borderColor: "#fca5a5" },
    }),
    valueContainer: (base) => ({ ...base, padding: "0 12px" }),
    singleValue: (base) => ({ ...base, color: "#475569", fontSize: "13px" }),
    placeholder: (base) => ({ ...base, color: "#94a3b8", fontSize: "13px" }),
    indicatorSeparator: () => ({ display: "none" }),
    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#94a3b8",
        "&:hover": { color: "#ef4444" },
    }),
    menu: (base) => ({
        ...base,
        marginTop: "4px",
        borderRadius: "8px",
        overflow: "hidden",
        border: "1px solid #e2e8f0",
        boxShadow: "0 10px 25px rgba(15, 23, 42, 0.10)",
        zIndex: 100,
    }),
    menuList: (base) => ({ ...base, padding: "4px" }),
    option: (base, state) => ({
        ...base,
        borderRadius: "6px",
        padding: "9px 10px",
        fontSize: "13px",
        cursor: "pointer",
        color: state.isSelected ? "#b91c1c" : "#475569",
        backgroundColor: state.isSelected
            ? "#fef2f2"
            : state.isFocused
            ? "#f8fafc"
            : "#ffffff",
        "&:active": { backgroundColor: "#fef2f2" },
    }),
};

/* =========================================================
   MAIN COMPONENT
========================================================= */
const AddNewFleet = ({
    isOpen,
    onClose,
    onSave,
    editingFleet,
}: AddNewFleetProps) => {
    const [form, setForm] = useState<FleetFormValues>(
        editingFleet ?? emptyFleetForm(todayIso())
    );

    /* Reset form when the drawer opens (or editing target changes) */
    useEffect(() => {
        if (isOpen) {
            setForm(editingFleet ?? emptyFleetForm(todayIso()));
        }
    }, [isOpen, editingFleet]);

    /* ---------- Guards ---------- */
    if (!isOpen) return null;

    /* ---------- Handlers ---------- */
    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSelectChange = (
        field: keyof FleetFormValues,
        option: SingleValue<SelectOption>
    ) => {
        setForm({ ...form, [field]: option?.value ?? "" }); 
    };

    const handleSave = () => {
        if (
            !form.fleetCode ||
            !form.vehicleName ||
            !form.category ||
            !form.registrationNo 
            
        ) {
            alert("Please fill all required fields.");
            return;
        }
        onSave?.(form);
    };

    return (
        <>
            {/* =====================================================
                BACKDROP
            ====================================================== */}
            <div
                className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-[1px]"
                onClick={onClose}
            />

            {/* =====================================================
                DRAWER
            ====================================================== */}
            <div
                className="
                    fixed
                    right-0
                    top-0
                    z-50
                    flex
                    h-screen
                    w-full
                    max-w-[560px]
                    flex-col
                    bg-white
                    shadow-2xl
                    animate-slide-in-right
                "
            >
                {/* ================= HEADER ================= */}
                <div className="shrink-0 border-b border-slate-200 bg-white px-6 py-5">
                    <div className="flex items-start justify-between gap-4">
                        <div>
                            <h2 className="text-lg font-bold text-slate-900">
                                {editingFleet
                                    ? "Edit Fleet / vehicle"
                                    : "Add New Fleet / vehicle"}
                            </h2>
                            <p className="mt-1 text-xs leading-5 text-slate-500">
                                {editingFleet
                                    ? "Update fleet details, ownership, and service records"
                                    : "Enter fleet details, ownership, and service records"}
                            </p>
                        </div>

                        <button
                            type="button"
                            onClick={onClose}
                            className="
                                flex
                                h-9
                                w-9
                                shrink-0
                                items-center
                                justify-center
                                rounded-lg
                                border
                                border-slate-200
                                bg-white
                                text-slate-400
                                transition
                                hover:border-slate-300
                                hover:bg-slate-50
                                hover:text-slate-700
                            "
                        >
                            <XIcon size={18} weight="bold" />
                        </button>
                    </div>
                </div>

                {/* ================= SCROLLABLE BODY ================= */}
                <div className="min-h-0 flex-1 overflow-y-auto">
                    <div className="space-y-6 p-6">

                        {/* ============ 4. ASSIGN VENDOR ============ */}
                        {/* <section>
                            <div className="mb-4">
                                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                    Assign Vendor
                                </h3>
                                <div className="mt-2 h-px bg-slate-100" />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div className="sm:col-span-2">
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Assigned Vendor
                                    </label>
                                    <Select<SelectOption>
                                        options={assignedVendorOptions}
                                        value={
                                            assignedVendorOptions.find(
                                                (o) => o.value === form.assignedVendor
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelectChange("assignedVendor", opt)
                                        }
                                        styles={selectStyles}
                                        isSearchable={true}
                                        isClearable={true}
                                        placeholder="Select vendor (optional)"
                                    />
                                </div>
                            </div>
                        </section> */}

                        {/* ============ 1. BASE DETAILS ============ */}
                        <section>
                            <div className="mb-4">
                                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                    Base Details
                                </h3>
                                <div className="mt-2 h-px bg-slate-100" />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Fleet / Vehicle Code
                                        <span className="ml-1 text-red-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="fleetCode"
                                        value={form.fleetCode}
                                        onChange={handleChange}
                                        placeholder="e.g. EQ-401"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Vehicle Name
                                        <span className="ml-1 text-red-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="vehicleName"
                                        value={form.vehicleName}
                                        onChange={handleChange}
                                        placeholder="e.g. Caterpillar 320D Excavator"
                                        className="form-input"
                                    />
                                </div>

                               <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Vehicle Category
                                    </label>
                                    <Select<SelectOption>
                                        options={vehicleCategoryOptions}
                                        value={
                                            vehicleCategoryOptions.find(
                                                (o) => o.value === form.category
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelectChange("category", opt)
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                        isClearable={false}
                                        placeholder="Select category"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Registration No
                                    </label>
                                    <input
                                        type="text"
                                        name="registrationNo"
                                        value={form.registrationNo}
                                        onChange={handleChange}
                                        placeholder="e.g. TN-09-CB-4821"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Chassis VIN No
                                    </label>
                                    <input
                                        type="text"
                                        name="chassisVinNo"
                                        value={(form as any).chassisVinNo || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. CHS-CAT-9920184"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Engine No
                                    </label>
                                    <input
                                        type="text"
                                        name="engineNo"
                                        value={(form as any).engineNo || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. ENG-CAT-4820193"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Make / Brand
                                    </label>
                                    <input
                                        type="text"
                                        name="makeBrand"
                                        value={(form as any).makeBrand || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. Caterpillar Inc."
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Model Variant
                                    </label>
                                    <input
                                        type="text"
                                        name="modelVariant"
                                        value={(form as any).modelVariant || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. 320D Series II"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Mfg Year
                                    </label>
                                    <input
                                        type="number"
                                        name="mfgYear"
                                        value={(form as any).mfgYear || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. 2023"
                                        className="form-input"
                                    />
                                </div>
                            </div>
                        </section>

                        {/* ============ 2. SITE & INSURANCE ============ */}
                        <section>
                            <div className="mb-4">
                                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                    Insurance
                                </h3>
                                <div className="mt-2 h-px bg-slate-100" />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div className="sm:col-span-2">
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                      Insurance Name 
                                        <span className="ml-1 text-red-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="insurance_name"
                                        value={form.insurance_name}
                                        onChange={handleChange}
                                        placeholder="e.g. NH-45 Bridge Expansion"
                                        className="form-input"
                                    />
                                </div>

                                <div className="sm:col-span-2">
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Insurance Provider
                                    </label>
                                    <input
                                        type="text"
                                        name="insuranceProvider"
                                        value={(form as any).insuranceProvider || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. ICICI Lombard General Insurance"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Policy Number
                                    </label>
                                    <input
                                        type="text"
                                        name="policyNumber"
                                        value={(form as any).policyNumber || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. POL-2026-9920148"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Annual Premium (₹)
                                    </label>
                                    <input
                                        type="number"
                                        name="annualPremium"
                                        value={(form as any).annualPremium || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. 85000"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Insurance Status
                                    </label>
                                    <Select<SelectOption>
                                        options={insuranceStatusOptions}
                                        value={
                                            insuranceStatusOptions.find(
                                                (o) =>
                                                    o.value === form.insuranceStatus
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelectChange(
                                                "insuranceStatus",
                                                opt
                                            )
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                        isClearable={false}
                                        placeholder="Select status"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Insurance Expiry Date
                                    </label>
                                    <input
                                        type="date"
                                        name="insuranceExpiryDate"
                                        value={form.insuranceExpiryDate}
                                        onChange={handleChange}
                                        className="form-input"
                                    />
                                </div>
                            </div>
                        </section>

                        {/* ============ 3. OWNERSHIP DETAILS ============ */}
                        <section>
                            <div className="mb-4">
                                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                    Owned Details
                                </h3>
                                <div className="mt-2 h-px bg-slate-100" />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Ownership Type
                                    </label>
                                    <Select<SelectOption>
                                        options={ownershipTypeOptions}
                                        value={
                                            ownershipTypeOptions.find(
                                                (o) =>
                                                    o.value ===
                                                    (form as any).ownershipType
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelectChange(
                                                "ownershipType" as keyof FleetFormValues,
                                                opt
                                            )
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                        isClearable={false}
                                        placeholder="Select ownership type"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Purchase Date
                                    </label>
                                    <input
                                        type="date"
                                        name="purchaseDate"
                                        value={(form as any).purchaseDate || ""}
                                        onChange={handleChange}
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Purchase Cost (₹)
                                    </label>
                                    <input
                                        type="number"
                                        name="purchaseCost"
                                        value={(form as any).purchaseCost || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. 7800000"
                                        className="form-input"
                                    />
                                </div>

                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Vendor / Dealer Name
                                    </label>
                                    <input
                                        type="text"
                                        name="vendorDealerName"
                                        value={(form as any).vendorDealerName || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. GMMCO Caterpillar South India"
                                        className="form-input"
                                    />
                                </div>

                                {/* <div className="sm:col-span-2">
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Assigned Operator
                                    </label>
                                    <input
                                        type="text"
                                        name="assignedOperator"
                                        value={(form as any).assignedOperator || ""}
                                        onChange={handleChange}
                                        placeholder="e.g. K. Velu (Senior Operator)"
                                        className="form-input"
                                    />
                                </div> */}
                            </div>
                        </section>

                        {/* ============ 4. EMI DETAILS ============ */}
                        

                        {/* ============ 5. SERVICE DETAILS ============ */}
                       <section>
                            <div className="mb-4">
                                <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                                    Service Details
                                </h3>
                                <div className="mt-2 h-px bg-slate-100" />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                {/* Service Interval */}
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Service Interval
                                    </label>
                                    <input
                                        type="text"
                                        name="serviceInterval"
                                        value={form.serviceInterval}
                                        onChange={handleChange}
                                        placeholder="e.g. Every 250 Operating Hours / 3 Months"
                                        className="form-input"
                                    />
                                </div>

                                {/* Warranty Status */}
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Warranty Status
                                    </label>
                                    <Select<SelectOption>
                                        options={warrantyStatusOptions}
                                        value={
                                            warrantyStatusOptions.find(
                                                (o) => o.value === form.warrantyStatus
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelectChange("warrantyStatus", opt)
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                        isClearable={false}
                                        placeholder="Select warranty status"
                                    />
                                </div>

                                {/* Last Service Date */}
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Last Service Date
                                    </label>
                                    <input
                                        type="date"
                                        name="lastServiceDate"
                                        value={form.lastServiceDate}
                                        onChange={handleChange}
                                        className="form-input"
                                    />
                                </div>

                                {/* Next Service Due Date */}
                                <div>
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Next Service Due Date
                                    </label>
                                    <input
                                        type="date"
                                        name="nextServiceDueDate"
                                        value={form.nextServiceDueDate}
                                        onChange={handleChange}
                                        className="form-input"
                                    />
                                </div>

                                {/* Preferred Workshop */}
                                <div className="sm:col-span-2">
                                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                        Preferred Workshop
                                    </label>
                                    <input
                                        type="text"
                                        name="preferredWorkshop"
                                        value={form.preferredWorkshop}
                                        onChange={handleChange}
                                        placeholder="e.g. Central Equipment Maintenance Yard, Villupuram"
                                        className="form-input"
                                    />
                                </div>
                            </div>
                        </section>

                    </div>
                </div>

                {/* ================= FOOTER ================= */}
                <div className="shrink-0 border-t border-slate-200 bg-white px-6 py-4">
                    <div className="flex items-center justify-end gap-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="
                                rounded-lg
                                border
                                border-slate-200
                                bg-white
                                px-4
                                py-2.5
                                text-sm
                                font-semibold
                                text-slate-600
                                transition
                                hover:bg-slate-50
                            "
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="
                                flex
                                items-center
                                gap-2
                                rounded-lg
                                bg-red-600
                                px-5
                                py-2.5
                                text-sm
                                font-semibold
                                text-white
                                shadow-sm
                                transition
                                hover:bg-red-700
                            "
                        >
                            <CheckIcon size={16} weight="bold" />
                            {editingFleet
                                ? "Update Fleet"
                                : "Save Fleet Master Record"}
                        </button>
                    </div>
                </div>
            </div>

            {/* ================= SHARED INPUT STYLES ================= */}
            <style>
                {`
                    .form-input {
                        width: 100%;
                        border-radius: 8px;
                        border: 1px solid #e2e8f0;
                        background: #f8fafc;
                        padding: 10px 12px;
                        font-size: 13px;
                        color: #334155;
                        outline: none;
                        transition: all 150ms ease;
                    }

                    .form-input::placeholder {
                        color: #94a3b8;
                    }

                    .form-input:focus {
                        border-color: #fca5a5;
                        background: #ffffff;
                        box-shadow: 0 0 0 1px #fca5a5;
                    }

                    @keyframes slide-in-right {
                        from { transform: translateX(100%); }
                        to   { transform: translateX(0);    }
                    }

                    .animate-slide-in-right {
                        animation: slide-in-right 0.25s ease-out;
                    }
                `}
            </style>
        </>
    );
};

export default AddNewFleet;