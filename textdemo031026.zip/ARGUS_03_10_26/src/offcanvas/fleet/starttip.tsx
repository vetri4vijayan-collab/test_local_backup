import { useState } from "react";
import { KeyIcon } from "@phosphor-icons/react";

import { VendorVehicle, Trip } from "../../types/trip";
import Button from "../../components/Button";
import OffCanvas from "../../components/OffCanvas";   // 👈 adjust path if needed

interface PickVehicleModalProps {
    isOpen: boolean;
    vehicle: VendorVehicle | null;
    onClose: () => void;
    onPick: (trip: Trip) => void;
}

function nowLocalIso() {
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
        d.getHours()
    )}:${pad(d.getMinutes())}`;
}

export default function PickVehicleModal({
    isOpen,
    vehicle,
    onClose,
    onPick,
}: PickVehicleModalProps) {
    const [pickupTime, setPickupTime] = useState(nowLocalIso());
    const [startKm, setStartKm] = useState("");
    const [pickupLocation, setPickupLocation] = useState("");
    const [driverName, setDriverName] = useState("");
    const [remarks, setRemarks] = useState("");
    const [error, setError] = useState("");

    /* Reset form when drawer opens for a new vehicle */
    function resetForm() {
        setPickupTime(nowLocalIso());
        setStartKm("");
        setPickupLocation("");
        setDriverName("");
        setRemarks("");
        setError("");
    }

    function handleSubmit() {
        if (!vehicle) return;

        if (!startKm || Number(startKm) < 0) {
            setError("Starting odometer reading is required.");
            return;
        }
        if (!pickupLocation.trim()) {
            setError("Pickup location is required.");
            return;
        }

        const trip: Trip = {
            id: `TRIP-${Date.now()}`,
            vehicleId: vehicle.id,
            vehicleCode: vehicle.fleetCode,
            vendorId: "V-001",
            vendorName: "Flow Jamaica",
            pickupTime: new Date(pickupTime).toISOString(),
            startKm: Number(startKm),
            pickupLocation: pickupLocation.trim(),
            driverName: driverName.trim() || undefined,
            status: "Picked",
        };

        onPick(trip);
        resetForm();
    }

    return (
        <OffCanvas
            isOpen={isOpen && !!vehicle}
            onClose={onClose}
            title="Pick Vehicle"
            subtitle={vehicle?.vehicleName ?? ""}
            widthClass="max-w-lg"
            footer={
                <div className="flex items-center justify-end gap-3">
                    <Button variant="outline" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit}>
                        <KeyIcon size={14} weight="fill" />
                        Confirm Pickup & Start Trip
                    </Button>
                </div>
            }
        >
            <div className="space-y-4">
                {/* Read-only info */}
                <div className="grid grid-cols-2 gap-4 rounded-lg bg-slate-50 p-3">
                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                            Vehicle Code
                        </p>
                        <p className="text-sm font-semibold text-slate-800">
                            {vehicle?.fleetCode}
                        </p>
                    </div>
                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                            Registration No
                        </p>
                        <p className="text-sm font-semibold text-slate-800">
                            {vehicle?.registrationNo}
                        </p>
                    </div>
                </div>

                {/* Pickup Time */}
                <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Pickup Time
                    </label>
                    <input
                        type="datetime-local"
                        value={pickupTime}
                        onChange={(e) => setPickupTime(e.target.value)}
                        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>

                {/* Starting KM */}
                <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Starting Odometer (KM){" "}
                        <span className="text-red-500">*</span>
                    </label>
                    <input
                        type="number"
                        min={0}
                        value={startKm}
                        onChange={(e) => {
                            setStartKm(e.target.value);
                            setError("");
                        }}
                        placeholder="e.g. 12450"
                        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>

                {/* Pickup Location */}
                <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Pickup Location{" "}
                        <span className="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        value={pickupLocation}
                        onChange={(e) => {
                            setPickupLocation(e.target.value);
                            setError("");
                        }}
                        placeholder="e.g. Head Office, Chennai"
                        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>

                {/* Driver Name */}
                <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Driver Name{" "}
                        <span className="text-slate-400">(Optional)</span>
                    </label>
                    <input
                        type="text"
                        value={driverName}
                        onChange={(e) => setDriverName(e.target.value)}
                        placeholder="e.g. Ramesh Kumar"
                        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>

                {/* Remarks */}
                <div>
                    <label className="mb-1 block text-xs font-semibold text-slate-700">
                        Remarks{" "}
                        <span className="text-slate-400">(Optional)</span>
                    </label>
                    <textarea
                        rows={2}
                        value={remarks}
                        onChange={(e) => setRemarks(e.target.value)}
                        placeholder="Any notes about this trip..."
                        className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    /> 
                </div>

                {error && (
                    <p className="rounded-md bg-red-50 px-3 py-2 text-xs font-medium text-red-600">
                        {error}
                    </p>
                )}
            </div>
        </OffCanvas>
    );
}