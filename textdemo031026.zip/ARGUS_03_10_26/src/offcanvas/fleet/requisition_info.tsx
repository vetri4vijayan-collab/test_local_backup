import {
    CheckIcon,
    ClockIcon,
    InfoIcon,
    ShieldCheckIcon,
    TruckIcon,
    UserIcon,
    XIcon,
} from "@phosphor-icons/react";

import OffCanvas from "../../components/OffCanvas";
import { RequisitionRow } from "../../components/fleet_info/fleet_requistion";


/* =========================================================
   PROPS
========================================================= */
interface RequisitionInfoProps {
    isOpen: boolean;
    onClose: () => void;
    row: RequisitionRow | null;
}

/* =========================================================
   HELPERS
========================================================= */
const display = (v?: string | number | null) => {
    if (v === undefined || v === null || v === "") return "—";
    return String(v);
};

const formatDateTime = (v?: string) => {
    if (!v) return "—";
    const d = new Date(v);
    if (isNaN(d.getTime())) return v;
    return d.toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
};

/* =========================================================
   STATUS PILL
========================================================= */
const StatusPill = ({ status }: { status: string }) => {
    const map: Record<
        string,
        { cls: string; dot: string; label: string; icon: React.ReactNode }
    > = {
        Requested: {
            cls: "bg-amber-100 text-amber-800 border-amber-200",
            dot: "bg-amber-500",
            label: "Pending Approval",
            icon: <ClockIcon size={12} weight="bold" />,
        },
        Approved: {
            cls: "bg-blue-100 text-blue-800 border-blue-200",
            dot: "bg-blue-500",
            label: "Approved",
            icon: <CheckIcon size={12} weight="bold" />,
        },
        Rejected: {
            cls: "bg-red-100 text-red-800 border-red-200",
            dot: "bg-red-500",
            label: "Rejected",
            icon: <XIcon size={12} weight="bold" />,
        },
        Returned: {
            cls: "bg-purple-100 text-purple-800 border-purple-200",
            dot: "bg-purple-500",
            label: "Returned",
            icon: <CheckIcon size={12} weight="bold" />,
        },
        Picked: {
            cls: "bg-indigo-100 text-indigo-800 border-indigo-200",
            dot: "bg-indigo-500",
            label: "Picked",
            icon: <ClockIcon size={12} weight="bold" />,
        },
        Completed: {
            cls: "bg-green-100 text-green-800 border-green-200",
            dot: "bg-green-500",
            label: "Completed",
            icon: <CheckIcon size={12} weight="bold" />,
        },
        Available: {
            cls: "bg-slate-100 text-slate-700 border-slate-200",
            dot: "bg-slate-400",
            label: "Available",
            icon: <InfoIcon size={12} weight="bold" />,
        },
    };

    const s = map[status] ?? {
        cls: "bg-slate-100 text-slate-700 border-slate-200",
        dot: "bg-slate-400",
        label: status,
        icon: null,
    };

    return (
        <span
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${s.cls}`}
        >
            <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
            {s.label}
        </span>
    );
};

/* =========================================================
   SECTION WRAPPER
========================================================= */
const Section = ({
    icon,
    title,
    children,
}: {
    icon: React.ReactNode;
    title: string;
    children: React.ReactNode;
}) => (
    <section className="flex h-full flex-col">
        <div className="mb-4 flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-red-50 text-red-600">
                {icon}
            </div>
            <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">
                {title}
            </h3>
        </div>
        <div className="flex-1 rounded-xl border border-slate-200 bg-slate-50/50 p-4">
            {children}
        </div>
    </section>
);

/* =========================================================
   ROW
========================================================= */
const Row = ({
    label,
    value,
    full,
}: {
    label: string;
    value: React.ReactNode;
    full?: boolean;
}) => (
    <div className={full ? "sm:col-span-2" : ""}>
        <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
            {label}
        </p>
        <p className="mt-1 break-words text-sm font-medium text-slate-800">
            {value}
        </p>
    </div>
);

/* =========================================================
   MAIN COMPONENT
========================================================= */
const RequisitionInfo = ({ isOpen, onClose, row }: RequisitionInfoProps) => {
    if (!row) return null;

    return (
        <OffCanvas
            isOpen={isOpen}
            onClose={onClose}
            title={row.vehicleName || "Requisition Details"}
            subtitle={
                row.vehicleCode
                    ? `Fleet Code · ${row.vehicleCode}`
                    : "Fleet requisition request"
            }
            widthClass="max-w-[500px]"
            headerSlot={
                <div className="flex items-start justify-between gap-3 pr-2">
                    <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-red-50 text-red-600">
                            <TruckIcon size={22} weight="duotone" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-900">
                                {display(row.vehicleName)}
                            </p>
                            <p className="text-xs text-slate-500">
                                {display(row.vehicleCode)} ·{" "}
                                {display(row.registrationNo)}
                            </p>
                        </div>
                    </div>

                    <StatusPill status={row.status} />
                </div>
            }
        >
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-1">
                {/* ---------- 1. VEHICLE ---------- */}
                <Section
                    icon={<TruckIcon size={14} weight="bold" />}
                    title="Vehicle"
                >
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Fleet Code" value={display(row.vehicleCode)} />
                        <Row label="Vehicle Name" value={display(row.vehicleName)} />
                        <Row label="Category" value={display(row.category)} />
                        <Row
                            label="Registration No"
                            value={display(row.registrationNo)}
                        />
                    </div>
                </Section>

                {/* ---------- 2. REQUESTER ---------- */}
                <Section
                    icon={<UserIcon size={14} weight="bold" />}
                    title="Requested By"
                >
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Vendor" value={display(row.vendorName)} />
                        <Row
                            label="Requested At"
                            value={formatDateTime(row.requestedAt)}
                        />
                        <Row
                            label="Reason / Remarks"
                            value={display(row.requestRemarks)}
                            full
                        />
                    </div>
                </Section>

                {/* ---------- 3. STATUS ---------- */}
                <Section
                    icon={<ShieldCheckIcon size={14} weight="bold" />}
                    title="Status & Notes"
                >
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row
                            label="Current Status"
                            value={<StatusPill status={row.status} />}
                        />
                        {row.approvalNote && (
                            <Row
                                label="Approval Note"
                                value={row.approvalNote}
                                full
                            />
                        )}
                        {row.rejectionReason && (
                            <Row
                                label="Rejection Reason"
                                value={row.rejectionReason}
                                full
                            />
                        )}
                    </div>
                </Section>

                {/* ---------- 4. TRIP ---------- */}
                <Section
                    icon={<ClockIcon size={14} weight="bold" />}
                    title="Trip Reference"
                >
                    <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2">
                        <Row label="Trip ID" value={display(row.tripId)} />
                        <Row label="Request ID" value={display(row.id)} />
                    </div>
                </Section>
            </div>
        </OffCanvas>
    );
};

export default RequisitionInfo;