import { useState } from "react";
import {
    CheckCircleIcon,
    PaperclipIcon,
    UploadSimpleIcon,
    XIcon,
} from "@phosphor-icons/react";

import { VendorVehicle, Trip } from "../../types/trip";
import Button from "../../components/Button";
import OffCanvas from "../../components/OffCanvas";

interface EndTripModalProps {
    isOpen: boolean;
    vehicle: VendorVehicle | null;
    onClose: () => void;
    onComplete: (updatedTrip: Trip) => void;
}

function nowLocalIso() {
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
        d.getHours()
    )}:${pad(d.getMinutes())}`;
}

const MAX_FILE_MB = 5;

export default function EndTripModal({
    isOpen,
    vehicle,
    onClose,
    onComplete,
}: EndTripModalProps) {
    const [returnTime, setReturnTime] = useState(nowLocalIso());
    const [endKm, setEndKm] = useState("");
    const [files, setFiles] = useState<File[]>([]);
    const [error, setError] = useState("");

    /* Only render when there's an active trip */
    const trip = vehicle?.activeTrip;
    const startKm: number | null =
    trip && typeof trip.startKm === 'number' ? trip.startKm : null;

   const totalKm =
    startKm !== null && endKm && Number(endKm) >= startKm
        ? Number(endKm) - startKm
        : null;

    /* Reset form */
    function resetForm() {
        setEndKm("");
        setFiles([]);
        setReturnTime(nowLocalIso());
        setError("");
    }

function handleSubmit() {
    if (!trip || startKm === null) return;

    if (!endKm) {
        setError("Ending odometer reading is required.");
        return;
    }
    if (Number(endKm) < startKm) {
        setError(`Ending KM must be greater than starting KM (${startKm}).`);
        return;
    }
    if (files.length === 0) {
        setError("Please upload at least one document.");
        return;
    }

    const updated: Trip = {
        ...trip,
        returnTime: new Date(returnTime).toISOString(),
        endKm: Number(endKm),
        totalKm: Number(endKm) - startKm,
        documents: files.map((f, i) => ({
            id: `${Date.now()}-${i}`,
            name: f.name,
            url: URL.createObjectURL(f),
        })),
        status: "Returned",
    };

    onComplete(updated);
    resetForm();
}

    /* ---------- file handling ---------- */
    function addFiles(incoming: FileList | File[]) {
        const arr = Array.from(incoming);
        if (arr.length === 0) return;

        // Reject files over the size limit
        const tooLarge = arr.find(f => f.size > MAX_FILE_MB * 1024 * 1024);
        if (tooLarge) {
            setError(`${tooLarge.name} exceeds the ${MAX_FILE_MB} MB limit.`);
            return;
        }

        // Reject unsupported types (optional — the input already filters)
        const allowed = ['application/pdf', 'image/jpeg', 'image/png'];
        const badType = arr.find(f => !allowed.includes(f.type));
        if (badType) {
            setError(`${badType.name} is not a supported file type.`);
            return;
        }

        setFiles(prev => [...prev, ...arr]);
        setError("");
    }

    function removeFile(index: number) {
        setFiles(prev => prev.filter((_, i) => i !== index));
    }

    return (
        <OffCanvas
            isOpen={isOpen && !!vehicle && !!trip}
            onClose={onClose}
            title="End Trip"
            subtitle={vehicle?.vehicleName ?? ""}
            widthClass="max-w-lg"
            footer={
                <div className="flex items-center justify-end gap-3">
                    <Button variant="outline" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit}>
                        <CheckCircleIcon size={14} weight="fill" />
                        Submit Trip Completion
                    </Button>
                </div>
            }
        >
            {trip && (
                <div className="space-y-4">

                    {/* ---------- Read-only start info ---------- */}
                    <div className="grid grid-cols-2 gap-4 rounded-lg bg-slate-50 p-3">
                        <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                                Start Time
                            </p>
                            <p className="text-sm font-semibold text-slate-800">
                                {new Date(trip.pickupTime!).toLocaleString()}
                            </p>
                        </div>
                        <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                                Start KM
                            </p>
                            <p className="text-sm font-semibold text-slate-800">
                                {trip.startKm}
                            </p>
                        </div>
                    </div>

                    {/* ---------- Return Time ---------- */}
                    <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-700">
                            Return Time
                        </label>
                        <input
                            type="datetime-local"
                            value={returnTime}
                            onChange={(e) => setReturnTime(e.target.value)}
                            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                    </div>

                    {/* ---------- Ending KM ---------- */}
                    <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-700">
                            Ending Odometer (KM){" "}
                            <span className="text-red-500">*</span>
                        </label>
                        <input
                            type="number"
                            min={trip.startKm}
                            value={endKm}
                            onChange={(e) => {
                                setEndKm(e.target.value);
                                setError("");
                            }}
                            placeholder={`Must be ≥ ${trip.startKm}`}
                            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                    </div>

                    {/* ---------- Total KM ---------- */}
                    <div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-blue-600">
                            Total KM Covered
                        </p>
                        <p className="text-2xl font-bold text-blue-700">
                            {totalKm !== null ? `${totalKm} km` : "—"}
                        </p>
                    </div>

                    {/* ---------- Document Upload ---------- */}
                    <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-700">
                            Upload Trip Sheet / Receipts / Delivery Proof{" "}
                            <span className="text-red-500">*</span>
                        </label>

                        {/* Dropzone */}
                        <label
                            htmlFor="trip-docs"
                            className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center transition-colors hover:border-blue-400 hover:bg-blue-50"
                        >
                            <UploadSimpleIcon size={24} className="mb-2 text-slate-400" />
                            <p className="text-xs font-semibold text-slate-600">
                                Click to upload or drag &amp; drop
                            </p>
                            <p className="mt-1 text-[10px] text-slate-400">
                                PDF, JPG, PNG (max {MAX_FILE_MB} MB each) · You can select multiple files
                            </p>
                            <input
                                id="trip-docs"
                                type="file"
                                accept=".pdf,.jpg,.jpeg,.png"
                                multiple
                                className="hidden"
                                onChange={(e) => {
                                    if (e.target.files) addFiles(e.target.files);
                                    e.target.value = "";
                                }}
                            />
                        </label>

                        {/* Uploaded file list */}
                        {files.length > 0 && (
                            <div className="mt-3 space-y-2">
                                {files.map((f, index) => (
                                    <div
                                        key={`${f.name}-${index}`}
                                        className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2"
                                    >
                                        <div className="flex min-w-0 items-center gap-2">
                                            <PaperclipIcon
                                                size={14}
                                                className="shrink-0 text-slate-400"
                                            />
                                            <div className="min-w-0">
                                                <p className="truncate text-xs font-medium text-slate-700">
                                                    {f.name}
                                                </p>
                                                <p className="text-[10px] text-slate-400">
                                                    {(f.size / 1024).toFixed(1)} KB
                                                </p>
                                            </div>
                                        </div>

                                        <button
                                            type="button"
                                            onClick={() => removeFile(index)}
                                            className="shrink-0 rounded-md p-1 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                                            title="Remove"
                                        >
                                            <XIcon size={14} weight="bold" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* ---------- Error ---------- */}
                    {error && (
                        <p className="rounded-md bg-red-50 px-3 py-2 text-xs font-medium text-red-600">
                            {error}
                        </p>
                    )}
                </div>
            )}
        </OffCanvas>
    );
}