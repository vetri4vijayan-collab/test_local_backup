import { useState } from "react";
import { XIcon, PaperPlaneTiltIcon } from "@phosphor-icons/react";
import Button from "../../components/Button";
import { VendorVehicle, Trip } from "../../types/trip";

interface RequestVehicleModalProps {
    isOpen: boolean;
    vehicle: VendorVehicle;
    onClose: () => void;
    onRequest: (trip: Trip) => void;
}

export default function RequestVehicleModal({
    isOpen,
    vehicle,
    onClose,
    onRequest,
}: RequestVehicleModalProps) {
    const [reason, setReason] = useState("");
    const [pickupDate, setPickupDate] = useState("");
    const [error, setError] = useState("");

    if (!isOpen) {
        return null;
    }

    function handleClose() {
        setReason("");
        setPickupDate("");
        setError("");
        onClose();
    }

    function handleSubmit() {
        if (!reason.trim()) {
            setError("Please provide a reason.");
            return;
        }

        if (!pickupDate) {
            setError("Please select a preferred pickup date.");
            return;
        }

        const trip: Trip = {
            id: `TRIP-${Date.now()}`,
            vehicleId: vehicle.id,
            vehicleCode: vehicle.fleetCode,
            vendorId: "V-001",
            vendorName: "Flow Jamaica",
            requestedAt: new Date().toISOString(),
            requestedBy: "Flow Jamaica",
            requestRemarks: reason.trim(),
            pickupTime: new Date(pickupDate).toISOString(),
            status: "Requested",
        };

        onRequest(trip);

        setReason("");
        setPickupDate("");
        setError("");
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 px-4 backdrop-blur-sm">
            <div className="w-full max-w-lg overflow-hidden rounded-xl bg-white shadow-2xl">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
                    <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-100 text-red-600">
                            <PaperPlaneTiltIcon size={20} weight="fill" />
                        </div>

                        <div>
                            <h2 className="text-base font-bold text-slate-900">
                                Request Vehicle
                            </h2>
                            <p className="text-xs text-slate-500">
                                {vehicle.vehicleName}
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={handleClose}
                        className="cursor-pointer rounded-md p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
                        aria-label="Close"
                    >
                        <XIcon size={18} />
                    </button>
                </div>

                {/* Body */}
                <div className="space-y-4 px-6 py-5">
                    {/* Vehicle Summary */}
                    <div className="grid grid-cols-2 gap-4 rounded-lg bg-slate-50 p-3">
                        <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                                Fleet Code
                            </p>
                            <p className="text-sm font-semibold text-slate-800">
                                {vehicle.fleetCode}
                            </p>
                        </div>

                        <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                                Reg No
                            </p>
                            <p className="text-sm font-semibold text-slate-800">
                                {vehicle.registrationNo}
                            </p>
                        </div>
                    </div>

                    {/* Preferred Pickup Date */}
                    <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-700">
                            Preferred Pickup Date{" "}
                            <span className="text-red-500">*</span>
                        </label>

                        <input
                            type="date"
                            value={pickupDate}
                            min={new Date().toISOString().split("T")[0]}
                            onChange={(e) => {
                                setPickupDate(e.target.value);
                                setError("");
                            }}
                            className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-800 outline-none transition-colors focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Reason for Request */}
                    <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-700">
                            Reason for Request{" "}
                            <span className="text-red-500">*</span>
                        </label>

                        <textarea
                            rows={3}
                            value={reason}
                            onChange={(e) => {
                                setReason(e.target.value);
                                setError("");
                            }}
                            placeholder="e.g. Urgent site visit to Villupuram"
                            className="w-full resize-none rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-800 outline-none transition-colors placeholder:text-slate-400 focus:border-red-500 focus:ring-1 focus:ring-red-500"
                        />
                    </div>

                    {/* Error */}
                    {error && (
                        <p className="rounded-md bg-red-50 px-3 py-2 text-xs font-medium text-red-600">
                            {error}
                        </p>
                    )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-end gap-3 border-t border-slate-200 px-6 py-4">
                    <Button variant="outline" onClick={handleClose}>
                        Cancel
                    </Button>

                    <Button onClick={handleSubmit}>
                        <PaperPlaneTiltIcon size={14} weight="fill" />
                        Send Request
                    </Button>
                </div>
            </div>
        </div>
    );
}