import { useState } from "react";
import {
    ArrowsOutIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
} from "@phosphor-icons/react";


import DataTable, { DataTableColumn } from "../components/DataTable";
import ToggleSwitch from "../components/ToggleSwitch";


export interface VehicleCategory {
    id: string;
    name: string;
    description: string;
    status: boolean;
}

const INITIAL_CATEGORIES: VehicleCategory[] = [
    {
        id: "CAT-001",
        name: "Bucket Truck",
        description:
            "Aerial work platform truck with an articulated boom and bucket for tower climbing, antenna installation, and elevated line work.",
        status: true,
    },
    {
        id: "CAT-002",
        name: "Splicer Van",
        description:
            "Enclosed van equipped with fiber splicing equipment, OTDR testers, and fusion splicers for underground and aerial cable work.",
        status: true,
    },
    {
        id: "CAT-003",
        name: "Cable Reel Truck",
        description:
            "Flatbed or reel-handling truck designed to transport and pay out large fiber or copper cable reels to field sites.",
        status: true,
    },
    {
        id: "CAT-004",
        name: "Field Service Pickup",
        description:
            "Light-duty pickup used by telecom technicians for routine site visits, CPE installs, and small repair jobs.",
        status: true,
    },
];

interface VehicleCategoryFormData {
    name: string;
    description: string;
}

const emptyForm: VehicleCategoryFormData = {
    name: "",
    description: "",
};

export default function FleetManagement() {
    const [categories, setCategories] =
        useState<VehicleCategory[]>(INITIAL_CATEGORIES);

    const [showForm, setShowForm] = useState(false);

    const [editingCategory, setEditingCategory] =
        useState<VehicleCategory | null>(null);

    const [formData, setFormData] =
        useState<VehicleCategoryFormData>(emptyForm);

    const [deleteCategory, setDeleteCategory] =
        useState<VehicleCategory | null>(null);

    const [errors, setErrors] = useState<{
        name?: string;
        description?: string;
    }>({});

    const openAddForm = () => {
        setEditingCategory(null);
        setFormData(emptyForm);
        setErrors({});
        setShowForm(true);
    };

    const openEditForm = (category: VehicleCategory) => {
        setEditingCategory(category);

        setFormData({
            name: category.name,
            description: category.description,
        });

        setErrors({});
        setShowForm(true);
    };

    const closeForm = () => {
        setShowForm(false);
        setEditingCategory(null);
        setFormData(emptyForm);
        setErrors({});
    };

    const validateForm = () => {
        const nextErrors: {
            name?: string;
            description?: string;
        } = {};

        if (!formData.name.trim()) {
            nextErrors.name = "Category name is required.";
        }

        if (!formData.description.trim()) {
            nextErrors.description = "Description is required.";
        }

        const duplicateCategory = categories.some(
            (category) =>
                category.name.trim().toLowerCase() ===
                    formData.name.trim().toLowerCase() &&
                category.id !== editingCategory?.id
        );

        if (duplicateCategory) {
            nextErrors.name =
                "A category with this name already exists.";
        }

        setErrors(nextErrors);

        return Object.keys(nextErrors).length === 0;
    };

    const generateCategoryId = () => {
        const highestNumber = categories.reduce(
            (highest, category) => {
                const match = category.id.match(/CAT-(\d+)/);

                if (!match) {
                    return highest;
                }

                return Math.max(highest, Number(match[1]));
            },
            0
        );

        return `CAT-${String(highestNumber + 1).padStart(3, "0")}`;
    };

    const handleSave = () => {
        if (!validateForm()) {
            return;
        }

        if (editingCategory) {
            setCategories((previous) =>
                previous.map((category) =>
                    category.id === editingCategory.id
                        ? {
                              ...category,
                              name: formData.name.trim(),
                              description:
                                  formData.description.trim(),
                          }
                        : category
                )
            );
        } else {
            const newCategory: VehicleCategory = {
                id: generateCategoryId(),
                name: formData.name.trim(),
                description: formData.description.trim(),
                status: true,
            };

            setCategories((previous) => [...previous, newCategory]);
        }

        closeForm();
    };

    const handleToggle = (
        category: VehicleCategory,
        checked: boolean
    ) => {
        setCategories((previous) =>
            previous.map((item) =>
                item.id === category.id
                    ? {
                          ...item,
                          status: checked,
                      }
                    : item
            )
        );
    };

    const handleDelete = () => {
        if (!deleteCategory) {
            return;
        }

        setCategories((previous) =>
            previous.filter(
                (category) => category.id !== deleteCategory.id
            )
        );

        setDeleteCategory(null);
    };

    const columns: DataTableColumn<VehicleCategory>[] = [
        {
            key: "name",
            label: "Category",
            sortable: true,
            width: "30%",
            render: (row) => (
                <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                        <ArrowsOutIcon size={17} weight="duotone" />
                    </div>

                    <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-slate-800">
                            {row.name}
                        </p>

                        <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                            {row.id}
                        </p>
                    </div>
                </div>
            ),
        },
        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "45%",
            render: (row) => (
                <span className="text-xs leading-5 text-slate-500">
                    {row.description}
                </span>
            ),
        },
        {
            key: "status",
            label: "Status",
            sortable: true,
            align: "center",
            width: "15%",
            render: (row) => (
                <div className="flex items-center justify-center">
                    <ToggleSwitch
                        checked={row.status}
                        onChange={(checked) =>
                            handleToggle(row, checked)
                        }
                        srLabel={`Toggle ${row.name} status`}
                    />
                </div>
            ),
        },
        {
            key: "actions",
            label: "Actions",
            align: "center",
            width: "10%",
            render: (row) => (
                <div className="flex items-center justify-center gap-1">
                    <button
                        type="button"
                        onClick={() => openEditForm(row)}
                        title={`Edit ${row.name}`}
                        aria-label={`Edit ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                    >
                        <PencilSimpleIcon size={16} weight="duotone" />
                    </button>

                    <button
                        type="button"
                        onClick={() => setDeleteCategory(row)}
                        title={`Delete ${row.name}`}
                        aria-label={`Delete ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                    >
                        <TrashIcon size={16} weight="duotone" />
                    </button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Vehicle Categories
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage the vehicle categories used
                        across your fleet management system.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={openAddForm}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                >
                    <PlusIcon size={16} weight="bold" />

                    Add Category
                </button>
            </div>

            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingCategory
                                ? "Edit Vehicle Category"
                                : "Add Vehicle Category"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingCategory
                                ? "Update the category information."
                                : "Create a new vehicle category."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {editingCategory && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Category ID
                                </label>

                                <input
                                    type="text"
                                    value={editingCategory.id}
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Category Name
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={formData.name}
                                onChange={(event) => {
                                    setFormData((previous) => ({
                                        ...previous,
                                        name: event.target.value,
                                    }));

                                    if (errors.name) {
                                        setErrors((previous) => ({
                                            ...previous,
                                            name: undefined,
                                        }));
                                    }
                                }}
                                placeholder="e.g. Sedan"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.name
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.name && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={formData.description}
                                onChange={(event) => {
                                    setFormData((previous) => ({
                                        ...previous,
                                        description:
                                            event.target.value,
                                    }));

                                    if (errors.description) {
                                        setErrors((previous) => ({
                                            ...previous,
                                            description: undefined,
                                        }));
                                    }
                                }}
                                placeholder="Enter a description for this vehicle category..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.description}
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={closeForm}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                        >
                            {editingCategory
                                ? "Save Changes"
                                : "Add Category"}
                        </button>
                    </div>
                </div>
            )}

            <DataTable<VehicleCategory>
                columns={columns}
                data={categories}
                rowKey={(row) => row.id}
                minWidth="760px"
                emptyMessage="No vehicle categories found. Click Add Category to create one."
            />

            {deleteCategory && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={19}
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete Vehicle Category
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are you sure you want to delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {deleteCategory.name}
                                        </span>
                                        ? This action cannot be undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={() => setDeleteCategory(null)}
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleDelete}
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                            >
                                Delete Category
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}