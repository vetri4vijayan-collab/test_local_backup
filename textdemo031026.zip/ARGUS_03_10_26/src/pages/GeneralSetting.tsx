import { useState } from "react";
import {
    BuildingsIcon,
    FloppyDiskIcon,
    IdentificationCardIcon,
    BankIcon,
    CurrencyCircleDollarIcon,
    MapPinIcon,
    PencilSimpleIcon,
    UserCircleIcon,
    TrashIcon,
    UploadSimpleIcon,
    XIcon,
    UserIcon,
    Plus,
    FileText,
    Trash,
    Download, // 👈 added
} from "@phosphor-icons/react";
import Select, { SingleValue, StylesConfig } from "react-select";
import React from "react";

/* =========================================================
   TYPES
========================================================= */
interface SelectOption {
    value: string;
    label: string;
}

interface VendorFormState {
    // ---------- Primary Contact ----------
    primaryContactName: string;
    primaryDesignation: string;
    primaryEmail: string;
    primaryPhone: string;
    primaryWhatsapp: string;
     bankDocuments: UploadedDocument[];
     primaryContactDocuments: UploadedDocument[];  

    
    // ---------- Secondary Contact ----------
    secondaryContactName: string;
    secondaryDesignation: string;
    secondaryEmail: string;
    secondaryPhone: string;
    secondaryWhatsapp: string;

    // ---------- Bank ----------
    bankName: string;
    bankBranch: string;
    accountHolderName: string;
    accountNumber: string;
    ifscCode: string;
    swiftCode: string;

    // ---------- Financial Terms ----------
    currency: string;
    paymentTerms: string;

    // ---------- Addresses ----------
    billingAddress: string;
    siteAddress: string;
    projectLocations: string;
}

interface UploadedDocument {
    id: string;              // server-generated id
    name: string;
    category: string;
    size: number;
    uploadedAt: string;
    url?: string;            // permanent server URL
    file?: File;             // ← only present until the server responds
}

/* =========================================================
   OPTIONS
========================================================= */
const currencyOptions: SelectOption[] = [
    { value: "USD", label: "USD ($ United States Dollar)" },
    { value: "JMD", label: "JMD ($ Jamaican Dollar)" },
    { value: "EUR", label: "EUR (€ Euro)" },
    { value: "GBP", label: "GBP (£ British Pound)" },
];

const paymentTermsOptions: SelectOption[] = [
    { value: "net-15", label: "Net 15 Days" },
    { value: "net-30", label: "Net 30 Days" },
    { value: "net-45", label: "Net 45 Days" },
    { value: "net-60", label: "Net 60 Days" },
    { value: "net-90", label: "Net 90 Days" },
    { value: "due-on-receipt", label: "Due on Receipt" },
];

/* =========================================================
   SELECT STYLES
========================================================= */
const selectStyles: StylesConfig<SelectOption, false> = {
    control: (base, state) => ({
        ...base,
        minHeight: "48px",
        borderRadius: "6px",
        borderColor: state.isFocused ? "#ef4444" : "#d4d4d8",
        backgroundColor: "#ffffff",
        boxShadow: state.isFocused ? "0 0 0 1px #ef4444" : "none",
        cursor: "pointer",
        "&:hover": { borderColor: "#ef4444" },
    }),
    valueContainer: (base) => ({ ...base, padding: "0 14px" }),
    singleValue: (base) => ({
        ...base,
        color: "#0f172a",
        fontSize: "14px",
        fontWeight: 500,
    }),
    placeholder: (base) => ({
        ...base,
        color: "#a1a1aa",
        fontSize: "14px",
    }),
    indicatorSeparator: () => ({ display: "none" }),
    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#71717a",
        "&:hover": { color: "#ef4444" },
    }),
    menu: (base) => ({
        ...base,
        marginTop: "4px",
        borderRadius: "6px",
        overflow: "hidden",
        border: "1px solid #e4e4e7",
        boxShadow: "0 10px 25px rgba(15, 23, 42, 0.10)",
        zIndex: 100,
    }),
    menuList: (base) => ({ ...base, padding: "4px" }),
    option: (base, state) => ({
        ...base,
        borderRadius: "4px",
        padding: "10px 12px",
        fontSize: "14px",
        cursor: "pointer",
        color: state.isSelected ? "#b91c1c" : "#334155",
        backgroundColor: state.isSelected
            ? "#fef2f2"
            : state.isFocused
            ? "#f8fafc"
            : "#ffffff",
    }),
};

function ProfilePhotoUpload({
    isEditing,
    value,
    onChange,
    onRemove,
}: {
    isEditing: boolean;
    value: string | null;
    onChange: (file: File, previewUrl: string) => void;
    onRemove: () => void;
}) {
    const inputRef = React.useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        // Optional: basic validation
        if (!file.type.startsWith('image/')) {
            alert('Please select an image file (PNG, JPG, WEBP).');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            alert('Image must be under 5 MB.');
            return;
        }
        const url = URL.createObjectURL(file);
        onChange(file, url);
        // Reset the input so selecting the same file again still fires onChange
        e.target.value = '';
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        if (!isEditing) return;
        const file = e.dataTransfer.files?.[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) return;
        const url = URL.createObjectURL(file);
        onChange(file, url);
    };

    return (
        <div className="flex items-center gap-5">
            {/* Preview / Drop zone */}
          {/* Preview / Drop zone — clickable when editing */}
            <div
                onClick={() => isEditing && inputRef.current?.click()}
                onKeyDown={(e) => {
                    if (!isEditing) return;
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        inputRef.current?.click();
                    }
                }}
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                role={isEditing ? 'button' : undefined}
                tabIndex={isEditing ? 0 : -1}
                title={isEditing ? (value ? 'Replace photo' : 'Upload photo') : undefined}
                className={`group relative flex h-28 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl border-2 transition-colors ${
                    value
                        ? 'border-slate-200 bg-white'
                        : 'border-dashed border-slate-300 bg-slate-50'
                } ${
                    isEditing
                        ? 'cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/40 focus:outline-none focus:ring-2 focus:ring-indigo-500/40'
                        : ''
                }`}
            >
                {value ? (
                    <img
                        src={value}
                        alt="Profile preview"
                        className="h-full w-full object-cover"
                    />
                ) : (
                    <div className="flex flex-col items-center gap-1 text-slate-400">
                        <UserCircleIcon size={32} weight="duotone" />
                        <span className="text-[10px] font-semibold uppercase tracking-wide">
                            No photo
                        </span>
                    </div>
                )}

                {/* Hover overlay (edit mode only) */}
                {isEditing && (
                    <div className="absolute inset-0 hidden items-center justify-center bg-slate-900/50 text-white group-hover:flex">
                        <UploadSimpleIcon size={22} weight="bold" />
                    </div>
                )}

                {/* Remove badge */}
                {isEditing && value && (
                    <button
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();   // don't trigger the picker
                            onRemove();
                        }}
                        className="absolute right-1 top-1 z-10 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow hover:bg-red-600"
                        title="Remove photo"
                    >
                        <XIcon size={12} weight="bold" />
                    </button>
                )}
            </div>

            {/* Meta + actions */}
            <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-800">
                    Vendor / Company Logo
                </p>
                <p className="mt-0.5 text-xs text-slate-500">
                    Upload a square image · PNG, JPG, or WEBP · max 5 MB
                </p>

                {isEditing && (
                    <>
                        <input
                            ref={inputRef}
                            type="file"
                            accept="image/png, image/jpeg, image/webp"
                            className="hidden"
                            onChange={handleFileChange}
                        />
                        <div className="mt-3 flex items-center gap-2">
                            {/* <button
                                type="button"
                                onClick={() => inputRef.current?.click()}
                                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                            >
                                <UploadSimpleIcon size={14} weight="bold" />
                                {value ? 'Replace' : 'Upload'}
                            </button> */}

                            {value && (
                                <button
                                    type="button"
                                    onClick={onRemove}
                                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                                >
                                    <TrashIcon size={14} weight="bold" />
                                    Remove
                                </button>
                            )}
                        </div>
                    </>
                )}

                {!isEditing && !value && (
                    <p className="mt-2 text-xs italic text-slate-400">
                        Click <b>Edit Profile</b> to upload a photo.
                    </p>
                )}
            </div>
        </div>
    );
}

/* =========================================================
   MAIN
========================================================= */
export default function GeneralSetting() {
    const [isEditing, setIsEditing] = useState(false); // 👈 NEW
   const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
   const [profilePhotoFile, setProfilePhotoFile] = useState<File | null>(null);


const [form, setForm] = useState<VendorFormState>({
    // ---------- Primary Contact ----------
    primaryContactName: "Marcus Sterling",
    primaryDesignation: "Procurement Manager",
    primaryEmail: "m.sterling@company.com",
    primaryPhone: "+1 (876) 920-4100",
    primaryWhatsapp: "",

    // ---------- Secondary Contact ----------
    secondaryContactName: "Sarah Thompson",
    secondaryDesignation: "Operations Manager",
    secondaryEmail: "s.thompson@company.com",
    secondaryPhone: "+1 (876) 920-4100",
    secondaryWhatsapp: "+1 (876) 550-1234",

    // ---------- Bank Details ----------
    bankName: "State Bank of India",
    bankBranch: "Anna Nagar Branch",
    accountHolderName: "SRK Infra Developers Pvt Ltd",
    accountNumber: "1234567890123",
    ifscCode: "SBIN0001234",
    swiftCode: "SBININBBXXX",
    bankDocuments: [],
     primaryContactDocuments: [], 

    // ---------- Payment ----------
    currency: "JMD",
    paymentTerms: "net-30",

    // ---------- Addresses ----------
    billingAddress: "Level 42, Innovation Tower, Dubai, UAE",
    siteAddress: "Primary Site, Villupuram Highway",
    projectLocations:
        "Spalding Node 1, Mandeville Trunk, Christiana Loop",
});

    /* ---------- Handlers ---------- */
    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSelect = (
        field: keyof VendorFormState,
        opt: SingleValue<SelectOption>
    ) => {
        setForm({ ...form, [field]: opt?.value ?? "" });
    };

    const handleSave = () => {
        console.log("Saving vendor profile:", form);
        // TODO: call your API here
        setIsEditing(false); // 👈 exit edit mode
    };

    const handleCancel = () => {
        setIsEditing(false); // optionally reset form back to last saved here
    };

    

    return (
        <div className="mx-auto max-w-6xl p-1">
            {/* =====================================================
                HEADER
            ===================================================== */}
            <div className="mb-6 flex items-center justify-between">
                    {/* ---------- LEFT: icon + title ---------- */}
                    <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-50 text-red-600">
                            <IdentificationCardIcon size={22} weight="bold" />
                        </div>
                        <h1 className="text-2xl font-bold text-slate-900">
                            Vendor Profile
                        </h1>
                    </div>

                    {/* ---------- RIGHT: Edit / Cancel / Save ---------- */}
                    <div className="flex items-center gap-3">
                        {isEditing ? (
                            <>
                                <button
                                    type="button"
                                    onClick={handleCancel}
                                    className="rounded-lg border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                                >
                                    Cancel
                                </button>

                                <button
                                    type="button"
                                    onClick={handleSave}
                                    className="flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                                >
                                    <FloppyDiskIcon size={16} weight="bold" />
                                    Save Profile
                                </button>
                            </>
                        ) : (
                            <button
                                type="button"
                                onClick={() => setIsEditing(true)}
                                className="flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                            >
                                <PencilSimpleIcon size={16} weight="bold" />
                                Edit Profile
                            </button>
                        )}
                    </div>
                </div>



            <div className="space-y-10 bg-white p-1">

                {/* =================================================
                    PROFILE PHOTO
                ================================================== */}
                <Section
                    icon={<UserCircleIcon size={18} weight="bold" />}
                    title="Profile Photo">
                    <ProfilePhotoUpload
                        isEditing={isEditing}
                        value={profilePhoto}
                        onChange={(file, previewUrl) => {
                            setProfilePhotoFile(file);
                            setProfilePhoto(previewUrl);
                        }}
                        onRemove={() => {
                            setProfilePhotoFile(null);
                            setProfilePhoto(null);
                        }}
                    />
                </Section>

                <Section
                    icon={<UserIcon size={18} weight="bold" />}
                    title="Primary Contact Person" >
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                        <SmartField
                            isEditing={isEditing}
                            label="Contact Name"
                            name="primaryContactName"
                            value={form.primaryContactName}
                            onChange={handleChange}
                            placeholder="e.g. Marcus Sterling"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Designation / Role"
                            name="primaryDesignation"
                            value={form.primaryDesignation}
                            onChange={handleChange}
                            placeholder="e.g. Procurement Manager"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Email Address"
                            name="primaryEmail"
                            value={form.primaryEmail}
                            onChange={handleChange}
                            placeholder="e.g. m.sterling@company.com"
                            type="email"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Phone Number"
                            name="primaryPhone"
                            value={form.primaryPhone}
                            onChange={handleChange}
                            placeholder="e.g. +1 (876) 920-4100"
                            type="tel"
                            required
                        />
                        <div className="md:col-span-2">
                            <SmartField
                                isEditing={isEditing}
                                label="WhatsApp Number"
                                name="primaryWhatsapp"
                                value={form.primaryWhatsapp}
                                onChange={handleChange}
                                placeholder="e.g. +1 (876) 550-1234"
                                hint="Optional"
                            />
                        </div>
                    </div>

                    {/* ⬇️ VENDOR ID PROOF UPLOAD */}
                    <div className="mt-6 border-t border-slate-100 pt-6">
                        <MultiDocumentUpload
                            documents={form.primaryContactDocuments}
                            onChange={(docs) =>
                                setForm((prev) => ({ ...prev, primaryContactDocuments: docs }))
                            }
                            isEditing={isEditing}
                            title="Vendor ID Proof"
                            subtitle="Passport, National ID Card, Social Security Number (SSN), Driver's License, or any government-issued photo ID"
                            categories={[
                                'Passport',
                                'National ID Card',
                                'Social Security Number (SSN)',
                                "Driver's License",
                                'Voter ID',
                                'Other Government ID',
                            ]}
                        />
                    </div>
                </Section>
                {/* =================================================
                    SECONDARY CONTACT
                ================================================== */}
                <Section
                    icon={<BuildingsIcon size={18} weight="bold" />}
                    title="Secondary Contact Person">
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                        <SmartField
                            isEditing={isEditing}
                            label="Contact Name"
                            name="secondaryContactName"
                            value={form.secondaryContactName}
                            onChange={handleChange}
                            placeholder="e.g. Sarah Thompson"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Designation / Role"
                            name="secondaryDesignation"
                            value={form.secondaryDesignation}
                            onChange={handleChange}
                            placeholder="e.g. Operations Manager"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Email Address"
                            name="secondaryEmail"
                            value={form.secondaryEmail}
                            onChange={handleChange}
                            placeholder="e.g. s.thompson@company.com"
                            type="email"
                            required
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Phone Number"
                            name="secondaryPhone"
                            value={form.secondaryPhone}
                            onChange={handleChange}
                            placeholder="e.g. +1 (876) 920-4100"
                            type="tel"
                            required
                        />
                        <div className="md:col-span-2">
                            <SmartField
                                isEditing={isEditing}
                                label="WhatsApp Number"
                                name="secondaryWhatsapp"
                                value={form.secondaryWhatsapp}
                                onChange={handleChange}
                                placeholder="e.g. +1 (876) 550-1234"
                                hint="Optional"
                            />
                        </div>
                    </div>
                </Section>

                {/* =================================================
                    BANK INFORMATION
                ================================================== */}
              <Section
                    icon={<BankIcon size={18} weight="bold" />}
                    title="Bank Information">
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                        <SmartField
                            isEditing={isEditing}
                            label="Name of the Bank"
                            name="bankName"
                            value={form.bankName}
                            onChange={handleChange}
                            placeholder="e.g. State Bank of India"
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Branch"
                            name="bankBranch"
                            value={form.bankBranch}
                            onChange={handleChange}
                            placeholder="e.g. Anna Nagar Branch"
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Account Holder Name"
                            name="accountHolderName"
                            value={form.accountHolderName}
                            onChange={handleChange}
                            placeholder="e.g. SRK Infra Developers Pvt Ltd"
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="Account Number"
                            name="accountNumber"
                            value={form.accountNumber}
                            onChange={handleChange}
                            placeholder="Enter account number"
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="IFSC Code"
                            name="ifscCode"
                            value={form.ifscCode}
                            onChange={handleChange}
                            placeholder="e.g. SBIN0001234"
                            uppercase
                        />
                        <SmartField
                            isEditing={isEditing}
                            label="SWIFT Code"
                            name="swiftCode"
                            value={form.swiftCode}
                            onChange={handleChange}
                            placeholder="e.g. SBININBBXXX"
                            uppercase
                        />
                    </div>

                    {/* ⬇️ MULTI DOCUMENT UPLOAD */}
                    <div className="mt-6 border-t border-slate-100 pt-6">
                        <MultiDocumentUpload
                            documents={form.bankDocuments}
                            onChange={(docs) => setForm(prev => ({ ...prev, bankDocuments: docs }))}
                            isEditing={isEditing}
                            title="Bank Documents"
                            subtitle="Cancelled cheque, bank statement, passbook, or a bank verification letter"
                            categories={[
                                'Cancelled Cheque',
                                'Bank Statement',
                                'Passbook Copy',
                                'Bank Verification Letter',
                                'Other',
                            ]}
                        />
                    </div>
                </Section>

                {/* =================================================
                    FINANCIAL TERMS
                ================================================== */}
                <Section
                    icon={<CurrencyCircleDollarIcon size={18} weight="bold" />}
                    title="Financial Terms & Billing Currency"
                >
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                        {/* Currency */}
                        <div>
                            {isEditing ? (
                                <>
                                    <Label>Preferred Currency</Label>
                                    <Select<SelectOption>
                                        options={currencyOptions}
                                        value={
                                            currencyOptions.find(
                                                (o) => o.value === form.currency
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelect("currency", opt)
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                    />
                                </>
                            ) : (
                                <ViewField
                                    label="Preferred Currency"
                                    value={
                                        currencyOptions.find(
                                            (o) => o.value === form.currency
                                        )?.label ?? ""
                                    }
                                />
                            )}
                        </div>

                        {/* Payment Terms */}
                        <div>
                            {isEditing ? (
                                <>
                                    <Label>Payment Terms</Label>
                                    <Select<SelectOption>
                                        options={paymentTermsOptions}
                                        value={
                                            paymentTermsOptions.find(
                                                (o) =>
                                                    o.value ===
                                                    form.paymentTerms
                                            ) || null
                                        }
                                        onChange={(opt) =>
                                            handleSelect("paymentTerms", opt)
                                        }
                                        styles={selectStyles}
                                        isSearchable={false}
                                    />
                                </>
                            ) : (
                                <ViewField
                                    label="Payment Terms"
                                    value={
                                        paymentTermsOptions.find(
                                            (o) =>
                                                o.value === form.paymentTerms
                                        )?.label ?? ""
                                    }
                                />
                            )}
                        </div>
                    </div>
                </Section>

                {/* =================================================
                    ADDRESSES
                ================================================== */}
                <Section
                    icon={<MapPinIcon size={18} weight="bold" />}
                    title="Addresses & Project Locations"
                >
                    <div className="space-y-6">
                        {/* Billing Address */}
                        <div>
                            <Label>Billing Address</Label>
                            {isEditing ? (
                                <textarea
                                    name="billingAddress"
                                    value={form.billingAddress}
                                    onChange={handleChange}
                                    rows={3}
                                    placeholder="Corporate billing address..."
                                    className="form-input"
                                />
                            ) : (
                                <StaticTextarea value={form.billingAddress} />
                            )}
                        </div>

                        {/* Site Address */}
                        <div>
                            <Label>Site Address / Exchange Headend</Label>
                            {isEditing ? (
                                <textarea
                                    name="siteAddress"
                                    value={form.siteAddress}
                                    onChange={handleChange}
                                    rows={3}
                                    placeholder="Primary physical site location..."
                                    className="form-input"
                                />
                            ) : (
                                <StaticTextarea value={form.siteAddress} />
                            )}
                        </div>

                        {/* Project Locations */}
                        <div>
                            <Label hint="comma separated">
                                Project Locations
                            </Label>
                            {isEditing ? (
                                <textarea
                                    name="projectLocations"
                                    value={form.projectLocations}
                                    onChange={handleChange}
                                    rows={3}
                                    placeholder="e.g. Spalding Node 1, Mandeville Trunk, Christiana Loop"
                                    className="form-input"
                                />
                            ) : (
                                <StaticTextarea
                                    value={form.projectLocations}
                                />
                            )}
                        </div>
                    </div>
                </Section>
            </div>

            {/* =====================================================
                FOOTER
            ===================================================== */}
            {/* <div className="mt-8 flex justify-end gap-3">
                {isEditing ? (
                    <>
                        <button
                            type="button"
                            onClick={handleCancel}
                            className="rounded-lg border border-slate-200 bg-white px-6 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="flex items-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                        >
                            <FloppyDiskIcon size={18} weight="bold" />
                            Save Profile
                        </button>
                    </>
                ) : (
                    <button
                        type="button"
                        onClick={() => setIsEditing(true)}
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                    >
                        <PencilSimpleIcon size={18} weight="bold" />
                        Edit Profile
                    </button>
                )}
            </div> */}


            <style>{`
                .form-input {
                    width: 100%;
                    border-radius: 6px;
                    border: 1px solid #d4d4d8;
                    background: #f8f7f7;
                    padding: 12px 14px;
                    font-size: 14px;
                    font-weight: 500;
                    color: #0f172a;
                    outline: none;
                    transition: all 150ms ease;
                    resize: vertical;
                }
                .form-input::placeholder {
                    color: #a1a1aa;
                    font-weight: 400;
                }
                .form-input:focus {
                    border-color: #ef4444;
                    box-shadow: 0 0 0 1px #ef4444;
                }
            `}</style>
        </div>
    );
}


function MultiDocumentUpload({
    documents,
    onChange,
    isEditing,
    title,
    subtitle,
    categories,
}: {
    documents: UploadedDocument[];
    onChange: (docs: UploadedDocument[]) => void;
    isEditing: boolean;
    title: string;
    subtitle?: string;
    categories: string[];
}) {
    const [uploadCategory, setUploadCategory] = React.useState<string>(categories[0] ?? 'Other');
    const [pendingFiles, setPendingFiles] = React.useState<File[]>([]);
    const [isDragging, setIsDragging] = React.useState(false);
    const [error, setError] = React.useState<string | null>(null);
    const fileInputRef = React.useRef<HTMLInputElement | null>(null);

    /* ---------- helpers ---------- */
    const formatSize = (bytes: number) => {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
        return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    };

    const formatNow = () => {
        const d = new Date();
        const date = d.toLocaleDateString('en-US', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
        });
        const time = d.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });
        return `${date} · ${time}`;
    };

    const addFiles = (files: FileList | File[]) => {
        const arr = Array.from(files);
        if (arr.length === 0) return;

        const tooLarge = arr.find(f => f.size > 10 * 1024 * 1024);
        if (tooLarge) {
            setError(`${tooLarge.name} exceeds the 10 MB limit.`);
            return;
        }

        setPendingFiles(prev => [...prev, ...arr]);
        setError(null);
    };

    const handlePick = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) addFiles(e.target.files);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
    };

    /* ---------- commit pending → local list only ---------- */
    const commitPending = () => {
        if (pendingFiles.length === 0) return;

        const now = formatNow();
        const newDocs: UploadedDocument[] = pendingFiles.map(f => ({
            id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            name: f.name,
            category: uploadCategory,
            size: f.size,
            uploadedAt: now,
            url: URL.createObjectURL(f),   // local blob URL for preview / download
        }));

        onChange([...documents, ...newDocs]);
        setPendingFiles([]);
        setError(null);
    };

    const removePending = (index: number) => {
        setPendingFiles(prev => prev.filter((_, i) => i !== index));
    };

    const removeDoc = (id: string) => {
        const target = documents.find(d => d.id === id);
        if (target?.url) URL.revokeObjectURL(target.url);
        onChange(documents.filter(d => d.id !== id));
    };

    const downloadDoc = (doc: UploadedDocument) => {
        if (!doc.url) return;
        const a = document.createElement('a');
        a.href = doc.url;
        a.download = doc.name;
        a.click();
    };

    /* ---------- render ---------- */
    return (
        <div>

            {/* Header */}
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
                <div>
                    <h3 className="text-sm font-bold text-slate-900">{title}</h3>
                    {subtitle && (
                        <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>
                    )}
                </div>
                <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-slate-600">
                    {documents.length} file{documents.length !== 1 ? 's' : ''}
                </span>
            </div>

            {/* ---------- Upload zone (edit mode only) ---------- */}
            {isEditing && (
                <div className="space-y-4">

                    {/* Category + Choose files + Add */}
                    <div className="grid grid-cols-1 md:grid-cols-[260px_1fr_auto] gap-3 items-end">

                        <div>
                            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-slate-500">
                                Document Type
                            </label>
                            <select
                                value={uploadCategory}
                                onChange={e => setUploadCategory(e.target.value)}
                                className="h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm font-medium text-slate-800 outline-none transition-colors focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                            >
                                {categories.map(c => (
                                    <option key={c} value={c}>{c}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-slate-500">
                                Files
                            </label>
                            <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-dashed border-slate-300 bg-white px-3 text-sm font-medium text-slate-600 transition-colors hover:border-red-400 hover:bg-red-50/40 hover:text-red-700"
                            >
                                <Plus size={14} />
                                Choose files…
                            </button>
                            <input
                                ref={fileInputRef}
                                type="file"
                                multiple
                                className="sr-only"
                                onChange={handlePick}
                            />
                        </div>

                        <button
                            type="button"
                            onClick={commitPending}
                            disabled={pendingFiles.length === 0}
                            className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-red-600 px-5 text-xs font-bold uppercase tracking-wide text-white shadow-sm transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            <FileText size={14} />
                            Add {pendingFiles.length > 0 ? `(${pendingFiles.length})` : ''}
                        </button>
                    </div>

                    {/* Drop zone */}
                    <div
                        onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={handleDrop}
                        className={`rounded-xl border-2 border-dashed p-6 text-center transition-colors ${
                            isDragging
                                ? 'border-red-400 bg-red-50/60'
                                : 'border-slate-300 bg-slate-50'
                        }`}
                    >
                        <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-white ring-1 ring-slate-200">
                            <UploadSimpleIcon size={18} weight="bold" className="text-slate-400" />
                        </div>
                        <p className="mt-3 text-sm font-semibold text-slate-700">
                            Drag &amp; drop files here
                        </p>
                        <p className="mt-1 text-xs text-slate-500">
                            Or click "Choose files…" above · PDF, JPG, PNG · max 10 MB each
                        </p>
                    </div>

                    {error && (
                        <p className="text-[11px] font-medium text-red-500">{error}</p>
                    )}

                    {/* Pending queue */}
                    {pendingFiles.length > 0 && (
                        <div className="rounded-xl border border-red-200 bg-red-50/40 p-4">
                            <p className="mb-2 text-[10px] font-bold uppercase tracking-wide text-red-700">
                                Ready to add · {pendingFiles.length} file{pendingFiles.length !== 1 ? 's' : ''}
                            </p>
                            <ul className="space-y-2">
                                {pendingFiles.map((f, idx) => (
                                    <li
                                        key={`${f.name}-${idx}`}
                                        className="flex items-center justify-between gap-3 rounded-lg border border-red-100 bg-white px-3 py-2"
                                    >
                                        <div className="flex min-w-0 items-center gap-3">
                                            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-red-50 text-red-600">
                                                <FileText size={14} />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="truncate text-sm font-semibold text-slate-800">
                                                    {f.name}
                                                </p>
                                                <p className="text-[10px] text-slate-400">
                                                    {formatSize(f.size)} · {uploadCategory}
                                                </p>
                                            </div>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => removePending(idx)}
                                            className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                                            title="Remove from queue"
                                        >
                                            <Trash size={14} />
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </div>
            )}

            {/* ---------- Uploaded documents list ---------- */}
            {documents.length === 0 ? (
                <div className="mt-4 rounded-xl border border-dashed border-slate-200 bg-slate-50 py-8 text-center">
                    <FileText size={22} className="mx-auto text-slate-300" />
                    <p className="mt-2 text-sm font-semibold text-slate-600">
                        No documents attached yet
                    </p>
                    <p className="mt-1 text-xs text-slate-400">
                        Upload your bank documents to keep everything in one place
                    </p>
                </div>
            ) : (
                <ul className="mt-4 space-y-2">
                    {documents.map(doc => (
                        <li
                            key={doc.id}
                            className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm transition-colors hover:bg-slate-50/60"
                        >
                            <div className="flex min-w-0 items-center gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <FileText size={17} />
                                </div>
                                <div className="min-w-0">
                                    <p className="truncate text-sm font-semibold text-slate-800">
                                        {doc.name}
                                    </p>
                                    <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-slate-400">
                                        <span className="font-bold uppercase tracking-wide text-slate-500">
                                            {doc.category}
                                        </span>
                                        <span className="text-slate-300">·</span>
                                        <span>{formatSize(doc.size)}</span>
                                        <span className="text-slate-300">·</span>
                                        <span>{doc.uploadedAt}</span>
                                    </p>
                                </div>
                            </div>

                            <div className="flex shrink-0 items-center gap-1">
                                <button
                                    type="button"
                                    onClick={() => downloadDoc(doc)}
                                    disabled={!doc.url}
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                                    title="Download"
                                >
                                    <Download size={15} />
                                </button>
                                {isEditing && (
                                    <button
                                        type="button"
                                        onClick={() => removeDoc(doc.id)}
                                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                                        title="Remove"
                                    >
                                        <Trash size={15} />
                                    </button>
                                )}
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
/* =========================================================
   SUB-COMPONENTS
========================================================= */

function Section({
    icon,
    title,
    children,
}: {
    icon: React.ReactNode;
    title: string;
    children: React.ReactNode;
}) {
    return (
        <section>
            <div className="mb-6 flex items-center gap-2">
                <span className="text-slate-500">{icon}</span>
                <h2 className="text-lg font-bold text-slate-900">{title}</h2>
            </div>
            {children}
        </section>
    );
}

function Label({
    children,
    hint,
}: {
    children: React.ReactNode;
    hint?: string;
}) {
    return (
        <label className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-slate-500">
            {children}
            {hint && (
                <span className="text-[10px] font-normal normal-case text-slate-400">
                    ({hint})
                </span>
            )}
        </label>
    );
}

/* -------- Editable input -------- */
function Field({
    label,
    name,
    value,
    onChange,
    placeholder,
    type = "text",
    required,
    hint,
    uppercase,
}: {
    label: string;
    name: string;
    value: string;
    onChange: (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => void;
    placeholder?: string;
    type?: string;
    required?: boolean;
    hint?: string;
    uppercase?: boolean;
}) {
    return (
        <div>
            <Label hint={hint}>
                {label}
                {required && <span className="text-red-500">*</span>}
            </Label>
            <input
                type={type}
                name={name}
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                className={`form-input ${uppercase ? "uppercase" : ""}`}
            />
        </div>
    );
}

/* -------- Static value -------- */
function ViewField({
    label,
    value,
    hint,
}: {
    label: string;
    value: string;
    hint?: string;
}) {
    return (
        <div>
            <Label hint={hint}>{label}</Label>
            <div className="rounded-md bg-slate-100 px-3.5 py-3 text-sm font-medium text-slate-800">
                {value || (
                    <span className="text-slate-400 italic">Not provided</span>
                )}
            </div>
        </div>
    );
}

/* -------- Static multi-line value -------- */
function StaticTextarea({ value }: { value: string }) {
    return (
        <div className="min-h-[80px] rounded-md bg-slate-100 px-3.5 py-3 text-sm font-medium text-slate-800 whitespace-pre-wrap">
            {value || (
                <span className="text-slate-400 italic">Not provided</span>
            )}
        </div>
    );
}

/* -------- Auto-switch between Field and ViewField -------- */
function SmartField({
    isEditing,
    label,
    name,
    value,
    onChange,
    placeholder,
    type = "text",
    required,
    hint,
    uppercase,
}: {
    isEditing: boolean;
    label: string;
    name: string;
    value: string;
    onChange: (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => void;
    placeholder?: string;
    type?: string;
    required?: boolean;
    hint?: string;
    uppercase?: boolean;
}) {
    if (!isEditing) {
        return <ViewField label={label} value={value} hint={hint} />;
    }
    return (
        <Field
            label={label}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            type={type}
            required={required}
            hint={hint}
            uppercase={uppercase}
        />
    );
}