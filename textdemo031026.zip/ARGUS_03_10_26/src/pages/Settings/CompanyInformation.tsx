import { useState } from "react";
import Field from "../../components/Field";
import { BuildingsIcon, FloppyDiskBackIcon } from "@phosphor-icons/react";
import ImageUpload from "../../components/ImageUpload";
import { logo, favIcon } from "../../assets/image";
import Button from "../../components/Button";

export default function CompanyInformation() {
  const [form, setForm] = useState({
    legalName: "Telecom Infrastructure Solutions Ltd.",
    taxId: "VAT-992-1200-X",
    address: "Level 42, Innovation Tower, Dubai, UAE",
    email: "operations@telecom-infra.com",
    phone: "+971 4 555 1234",
  });

  // Uploaded files
  const [companyLogo, setCompanyLogo] = useState<File | null>(null);
  const [companyFavicon, setCompanyFavicon] = useState<File | null>(null);

  const update =
    (key: keyof typeof form) =>
      (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setForm((prev) => ({
          ...prev,
          [key]: e.target.value,
        }));
      };

  const handleSave = () => {
    console.log("Company Logo:", companyLogo);
    console.log("Company Favicon:", companyFavicon);
    console.log("Form:", form);

    // API / FormData can be added here
  };

  return (
    <div>
      {/* Header */}
      <div className="border-b border-slate-100 pb-6">
        <div className="flex items-start gap-4">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
            <BuildingsIcon size={20} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Company Information</h2>
          </div>
        </div>
        {/* Logo Uploads */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8">

          {/* Company Logo */}
          <div className="flex items-center gap-4">
            <ImageUpload
              value={logo}
              accept="image/png,image/jpeg,image/webp"
              onChange={(file) => {
                setCompanyLogo(file);
              }}
            />

            <div>
              <h3 className="text-sm font-semibold text-slate-800">
                Company Logo
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                Upload your company logo
              </p>

              <p className="mt-1 text-xs text-slate-400">
                PNG, JPG or WEBP
              </p>
            </div>
          </div>

          {/* Favicon */}
          <div className="flex items-center gap-4">
            <ImageUpload
              value={favIcon}
              accept="image/png,image/x-icon,image/svg+xml"
              onChange={(file) => {
                setCompanyFavicon(file);
              }}
            />

            <div>
              <h3 className="text-sm font-semibold text-slate-800">
                Favicon
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                Upload your application favicon
              </p>

              <p className="mt-1 text-xs text-slate-400">
                PNG, ICO or SVG
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Form */}
      <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2">

        <Field
          label="Company Legal Name"
          value={form.legalName}
          onChange={update("legalName")}
        />

        <Field
          label="Tax ID / VAT Number"
          value={form.taxId}
          onChange={update("taxId")}
        />

        <Field
          label="Primary Contact Email"
          type="email"
          value={form.email}
          onChange={update("email")}
        />

        <Field
          label="Support Phone"
          type="tel"
          value={form.phone}
          onChange={update("phone")}
        />

        <div className="sm:col-span-2">
          <Field
            label="Headquarters Address"
            type="textarea"
            rows={4}
            value={form.address}
            onChange={update("address")}
          />
        </div>

      </div>

      {/* Footer */}
      <div className="mt-8 flex justify-end border-t border-slate-100 pt-6">
        <Button onClick={handleSave}>
          <FloppyDiskBackIcon size={16} />
          Save Profile
        </Button>
      </div>
    </div>
  );
}