export type VehicleStatus =
    | "Available"
    | "Requested"
    | "Approved"
    | "Picked"
    | "Returned"
    | "Completed"
    | "Rejected";

export type TripStatus =
    | "Requested"
    | "Approved"
    | "Picked"
    | "Returned"
    | "Completed"
    | "Rejected";

export interface Trip {
    id: string;
    vehicleId: string;
    vehicleCode: string;
    vendorId: string;
    vendorName: string;

    /* Request stage */
    requestedAt?: string;
    requestedBy?: string;
    requestRemarks?: string;

    /* Approval stage */
    approvedAt?: string;
    approvedBy?: string;

    /* Pickup stage */
    pickupTime?: string;
    startKm?: number;
    pickupLocation?: string;
    driverName?: string;

    /* Return stage */
    returnTime?: string;
    endKm?: number;
    totalKm?: number;
    documents?: { id: string; name: string; url: string }[];
    expenses?: { id: string; type: string; amount: number; remarks?: string }[];

    status: TripStatus;
}

export interface VendorVehicle {
    id: string;
    fleetCode: string;
    vehicleName: string;
    vehicleId: string;
    registrationNo: string;
    category: string;
    vehicleType: "Two Wheeler" | "Four Wheeler";
    status: VehicleStatus;
    activeTrip?: Trip;
}