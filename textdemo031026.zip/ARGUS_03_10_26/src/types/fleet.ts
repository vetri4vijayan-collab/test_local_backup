/* =========================================================
   UNION TYPES
========================================================= */
export type InsuranceStatus = "active" | "expiring" | "expired";
export type ServiceStatus = "ok" | "due_soon" | "overdue";
export type FleetStatus = "active" | "inactive";

/* =========================================================
   FLEET ITEM — a row in the table
========================================================= */
export interface FleetItem {
    id: string;

      assignedVendor?: string;
    // Base details
    fleetCode: string;
    vehicleName: string;
    category: string;
    registrationNo: string;
    chassisVinNo: string;
    engineNo: string;
    makeBrand: string;
    modelVariant: string;
    mfgYear: string;

    // Site
    siteLocation: string;
    currentSiteLocation: string;

    // Ownership
    ownershipType: string;
    purchaseDate: string;
    purchaseCost: string;
    vendorDealerName: string;
    assignedOperator: string;

    // Insurance
    insurance_name: string;
    insuranceProvider: string;
    policyNumber: string;
    annualPremium: string;
    insuranceStatus: InsuranceStatus;
    insuranceExpiryDate: string;

    // EMI
    financingBank: string;
    monthlyEmi: string;
    emiDueCycleDay: string;

    // Service
    serviceStatus: ServiceStatus;
    lastServiceDate: string;         // ISO YYYY-MM-DD
    nextServiceDueDate: string;      // ISO YYYY-MM-DD
    serviceIntervalHours: number;    // e.g. 250
    serviceInterval: string;         // e.g. "Every 250 Hours"
    preferredWorkshop: string;
    warrantyStatus: string;

    // Status
    status: FleetStatus;
}

/* =========================================================
   FLEET FORM VALUES — what the drawer edits
========================================================= */
export interface FleetFormValues {
    // Base
    fleetCode: string;
    vehicleName: string;
    category: string;
    registrationNo: string;
    chassisVinNo: string;
    engineNo: string;
    makeBrand: string;
    modelVariant: string;
    mfgYear: string;

    // Site
    siteLocation: string;
    currentSiteLocation: string;

   assignedVendor?: string;
    // Ownership
    ownershipType: string;
    purchaseDate: string;
    purchaseCost: string;
    vendorDealerName: string;
    assignedOperator: string;

    // Insurance
    insurance_name: string;
    insuranceProvider: string;
    policyNumber: string;
    annualPremium: string;
    insuranceStatus: InsuranceStatus;
    insuranceExpiryDate: string;

    // EMI
    financingBank: string;
    monthlyEmi: string;
    emiDueCycleDay: string;

    // Service
    serviceInterval: string;
    warrantyStatus: string;
    lastServiceDate: string;
    nextServiceDueDate: string;
    preferredWorkshop: string;

    // Status
    status: FleetStatus;
}

/* =========================================================
   EMPTY FORM — truly blank defaults for "Add New Fleet"
========================================================= */
export const emptyFleetForm = (todayIso: string): FleetFormValues => ({
    // Base
    fleetCode: "",
    vehicleName: "",
    category: "",
    registrationNo: "",
    chassisVinNo: "",
    engineNo: "",
    makeBrand: "",
    modelVariant: "",
    mfgYear: "",

    // Site
    siteLocation: "",
    currentSiteLocation: "",

    // Ownership
    ownershipType: "Company Owned",
    purchaseDate: todayIso,
    purchaseCost: "",
    vendorDealerName: "",
    assignedOperator: "",

    // Insurance
    insurance_name: "",
    insuranceProvider: "",
    policyNumber: "",
    annualPremium: "",
    insuranceStatus: "active",
    insuranceExpiryDate: todayIso,

    // EMI
    financingBank: "",
    monthlyEmi: "",
    emiDueCycleDay: "",

    // Service
    serviceInterval: "",
    warrantyStatus: "",
    lastServiceDate: "",
    nextServiceDueDate: "",
    preferredWorkshop: "",

    // Status
    status: "active",
});