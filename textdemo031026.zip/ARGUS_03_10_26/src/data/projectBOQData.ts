import { BOQSection, SelectOption } from "../types/projectBOQ";

export const CATEGORY_TYPES: SelectOption[] = [
    {
        value: "Project Milestone",
        label: "Project Milestone",
    },
    {
        value: "Material Specifications",
        label: "Material Specifications",
    },
    {
        value: "Technical Services",
        label: "Technical Services",
    },
];

export const VENDOR_OPTIONS: SelectOption[] = [
    {
        value: "Seiretsu JA Ltd",
        label: "Seiretsu JA Ltd",
    },
    {
        value: "Caribbean Fiber Solutions",
        label: "Caribbean Fiber Solutions",
    },
    {
        value: "Kingston Telecom Services",
        label: "Kingston Telecom Services",
    },
    {
        value: "Island Network Infrastructure",
        label: "Island Network Infrastructure",
    },
];

export const UNIT_OPTIONS: SelectOption[] = [
    {
        value: "Unit",
        label: "Unit",
    },
    {
        value: "Meter",
        label: "Meter",
    },
    {
        value: "SqM",
        label: "SqM",
    },
    {
        value: "Each",
        label: "Each",
    },
    {
        value: "Hour",
        label: "Hour",
    },
    {
        value: "Day",
        label: "Day",
    },
    {
        value: "Km",
        label: "Km",
    },
    {
        value: "Lot",
        label: "Lot",
    },
    {
        value: "Site",
        label: "Site",
    },
];

export const BOQ_SECTIONS = [
    { id: 1, category: "Civil Works",  title: "Project Milestones & Civil Infrastructure", color: "bg-red-600" },
    { id: 2, category: "Fiber Optics", title: "Material Specifications & Fiber Equipment",  color: "bg-emerald-600" },
    // 👇 category must match the dropdown value, not the title
    { id: 3, category: "Services",     title: "Technical Services & Human Resources",      color: "bg-blue-600" },
];


