import { FleetItem } from "../types/fleet";

export const todayIso = () => new Date().toISOString().split("T")[0];

/* =========================================================
   TYPES
========================================================= */
interface FleetSeed {
    id: string;
    fleetCode: string;
    vehicleName: string;
    category: string;
    registrationNo: string;
    siteLocation: string;
    insuranceStatus: FleetItem["insuranceStatus"];
    insuranceExpiryDate: string;
    status: FleetItem["status"];
    serviceStatus: FleetItem["serviceStatus"];
    lastServiceDate: string;
    nextServiceDueDate: string;
    serviceIntervalHours: number;
    /* Extra fields for the info drawer */
    chassisVinNo: string;
    engineNo: string;
    makeBrand: string;
    modelVariant: string;
    mfgYear: string;
    ownershipType: string;
    purchaseDate: string;
    purchaseCost: string;
    vendorDealerName: string;
    assignedOperator: string;
    insurance_name: string;
    insuranceProvider: string;
    policyNumber: string;
    annualPremium: string;
    serviceInterval: string;
    warrantyStatus: string;
    preferredWorkshop: string;
    financingBank: string;
    monthlyEmi: string;
    emiDueCycleDay: string;
    currentSiteLocation: string;
    assignedVendor?: string;
}

/* =========================================================
   SEED DATA — every field populated
========================================================= */
const seeds: FleetSeed[] = [
    {
        id: "1",
        fleetCode: "EQ-401",
        vehicleName: "Caterpillar 320D Excavator",
        category: "Bucket Truck",
        registrationNo: "TN-09-CB-4821",
        siteLocation: "NH-45 Bridge Expansion (Pier P4 Foundation Site)",
        insuranceStatus: "active",
        insuranceExpiryDate: "2027-01-09",
        status: "active",
        serviceStatus: "ok",
        lastServiceDate: "2026-06-15",
        nextServiceDueDate: "2026-10-15",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-CAT-9920184",
        engineNo: "ENG-CAT-4820193",
        makeBrand: "Caterpillar Inc.",
        modelVariant: "320D Series II",
        mfgYear: "2021",
        ownershipType: "Company Owned",
        purchaseDate: "2021-04-12",
        purchaseCost: "7800000",
        vendorDealerName: "GMMCO Caterpillar South India",
        assignedOperator: "K. Velu (Senior Operator)",
        insurance_name: "Commercial Vehicle Comprehensive",
        insuranceProvider: "ICICI Lombard General Insurance",
        policyNumber: "POL-2027-9920148",
        annualPremium: "85000",
        serviceInterval: "Every 250 Operating Hours / 3 Months",
        warrantyStatus: "Extended Warranty",
        preferredWorkshop: "Central Equipment Maintenance Yard, Villupuram",
        financingBank: "HDFC Bank",
        monthlyEmi: "145000",
        emiDueCycleDay: "5",
        currentSiteLocation: "NH-45 Bridge Expansion — Pier P4",
        assignedVendor: "Flow Jamaica",
    },
    {
        id: "2",
        fleetCode: "EQ-402",
        vehicleName: "JCB 3DX Backhoe Loader",
        category: "Splicer Van",
        registrationNo: "TN-09-CB-4822",
        siteLocation: "Villupuram Bypass Road Work",
        insuranceStatus: "expiring",
        insuranceExpiryDate: "2026-10-15",
        status: "active",
        serviceStatus: "ok",
        lastServiceDate: "2026-06-15",
        nextServiceDueDate: "2026-10-15",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-JCB-7721045",
        engineNo: "ENG-JCB-5510922",
        makeBrand: "JCB India",
        modelVariant: "3DX Super",
        mfgYear: "2022",
        ownershipType: "Financed",
        purchaseDate: "2022-08-05",
        purchaseCost: "3250000",
        vendorDealerName: "JCB India Ltd — Chennai",
        assignedOperator: "R. Suresh",
        insurance_name: "Construction Equipment Policy",
        insuranceProvider: "Bajaj Allianz",
        policyNumber: "POL-2026-5510234",
        annualPremium: "42000",
        serviceInterval: "Every 250 Hours",
        warrantyStatus: "Under Warranty",
        preferredWorkshop: "JCB Authorised Service — Kanchipuram",
        financingBank: "Bajaj Finance",
        monthlyEmi: "62000",
        emiDueCycleDay: "10",
        currentSiteLocation: "Villupuram Bypass",
        assignedVendor: "Seiretsu",
    },
    {
        id: "3",
        fleetCode: "EQ-403",
        vehicleName: "Tata Hitachi ZX 220",
        category: "Bucket Truck",
        registrationNo: "TN-09-CB-4823",
        siteLocation: "Chennai Metro Phase 2 — Station 4",
        insuranceStatus: "expired",
        insuranceExpiryDate: "2026-08-01",
        status: "active",
        serviceStatus: "overdue",
        lastServiceDate: "2026-05-01",
        nextServiceDueDate: "2026-08-01",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-TH-8892013",
        engineNo: "ENG-TH-4410277",
        makeBrand: "Tata Hitachi",
        modelVariant: "ZX 220 LC",
        mfgYear: "2020",
        ownershipType: "Leased",
        purchaseDate: "2020-11-20",
        purchaseCost: "5400000",
        vendorDealerName: "Tata Hitachi Construction Machinery",
        assignedOperator: "M. Anand",
        insurance_name: "Heavy Equipment Cover",
        insuranceProvider: "New India Assurance",
        policyNumber: "POL-2026-8810099",
        annualPremium: "68000",
        serviceInterval: "Every 500 Hours",
        warrantyStatus: "Out of Warranty",
        preferredWorkshop: "Tata Hitachi Workshop — Guindy",
        financingBank: "Tata Capital",
        monthlyEmi: "98000",
        emiDueCycleDay: "7",
        currentSiteLocation: "Chennai Metro — Station 4",
        assignedVendor: "Jon doe",
    },
    {
        id: "4",
        fleetCode: "EQ-404",
        vehicleName: "Ashok Leyland 2518 Tipper",
        category: "Field Service Pickup",
        registrationNo: "TN-09-CB-4824",
        siteLocation: "Tambaram Quarry Haulage",
        insuranceStatus: "active",
        insuranceExpiryDate: "2027-03-22",
        status: "active",
        serviceStatus: "ok",
        lastServiceDate: "2026-06-15",
        nextServiceDueDate: "2026-10-15",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-AL-1190233",
        engineNo: "ENG-AL-6630121",
        makeBrand: "Ashok Leyland",
        modelVariant: "2518 Tipper",
        mfgYear: "2019",
        ownershipType: "Company Owned",
        purchaseDate: "2019-09-18",
        purchaseCost: "4100000",
        vendorDealerName: "Ashok Leyland — Chennai",
        assignedOperator: "P. Kumar",
        insurance_name: "Commercial Vehicle Comprehensive",
        insuranceProvider: "Reliance General Insurance",
        policyNumber: "POL-2027-3310776",
        annualPremium: "55000",
        serviceInterval: "Every 250 Operating Hours / 3 Months",
        warrantyStatus: "Out of Warranty",
        preferredWorkshop: "Leyland Authorised Service — Tambaram",
        financingBank: "ICICI Bank",
        monthlyEmi: "72000",
        emiDueCycleDay: "12",
        currentSiteLocation: "Tambaram Quarry",
        assignedVendor: "Flow Jamaica",
    },
    {
        id: "5",
        fleetCode: "EQ-405",
        vehicleName: "ACE 20-Ton Mobile Crane",
        category: "Field Service Pickup",
        registrationNo: "TN-09-CB-4825",
        siteLocation: "NH-45 Pier P4 Lift Operations",
        insuranceStatus: "active",
        insuranceExpiryDate: "2027-05-11",
        status: "active",
        serviceStatus: "ok",
        lastServiceDate: "2026-06-15",
        nextServiceDueDate: "2026-10-15",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-ACE-3302199",
        engineNo: "ENG-ACE-1120884",
        makeBrand: "Action Construction Equipment",
        modelVariant: "ACE FX 200",
        mfgYear: "2022",
        ownershipType: "Financed",
        purchaseDate: "2022-02-14",
        purchaseCost: "6300000",
        vendorDealerName: "ACE Ltd — South Zone",
        assignedOperator: "S. Ramesh",
        insurance_name: "Special Equipment Cover",
        insuranceProvider: "TATA AIG",
        policyNumber: "POL-2027-2201145",
        annualPremium: "78000",
        serviceInterval: "Every 300 Hours",
        warrantyStatus: "Under Warranty",
        preferredWorkshop: "ACE Authorised Service — Sriperumbudur",
        financingBank: "Kotak Mahindra Bank",
        monthlyEmi: "112000",
        emiDueCycleDay: "8",
        currentSiteLocation: "NH-45 — Pier P4",
        assignedVendor: "Seiretsu",
    },
    {
        id: "6",
        fleetCode: "EQ-406",
        vehicleName: "Bomag BW 212 Soil Compactor",
        category: "Splicer Van",
        registrationNo: "TN-09-CB-4826",
        siteLocation: "Villupuram Highway Widening",
        insuranceStatus: "expiring",
        insuranceExpiryDate: "2026-10-02",
        status: "inactive",
        serviceStatus: "due_soon",
        lastServiceDate: "2026-06-15",
        nextServiceDueDate: "2026-10-05",
        serviceIntervalHours: 250,
        chassisVinNo: "CHS-BOM-7701345",
        engineNo: "ENG-BOM-5510664",
        makeBrand: "Bomag GmbH",
        modelVariant: "BW 212 D-40",
        mfgYear: "2018",
        ownershipType: "Rented",
        purchaseDate: "2018-07-01",
        purchaseCost: "0",
        vendorDealerName: "Bomag Rental Partners",
        assignedOperator: "V. Ganesh",
        insurance_name: "Rental Equipment Policy",
        insuranceProvider: "Oriental Insurance",
        policyNumber: "POL-2026-6601458",
        annualPremium: "32000",
        serviceInterval: "Every 250 Operating Hours / 3 Months",
        warrantyStatus: "Out of Warranty",
        preferredWorkshop: "Bomag Service — Chennai",
        financingBank: "",
        monthlyEmi: "",
        emiDueCycleDay: "",
        currentSiteLocation: "Villupuram Highway",
        // Intentionally left unassigned to show the "Unassigned" badge state
    },
];

/* =========================================================
   EXPORTED DATA
========================================================= */
export const initialFleetData: FleetItem[] = seeds.map((s) => ({
    ...s,
    assignedVendor: s.assignedVendor ?? "",
})) as FleetItem[];

/* =========================================================
   HELPERS
========================================================= */
export const computeNextServiceDue = (baseDate: string): string => {
    const d = new Date(baseDate || new Date().toISOString());
    d.setMonth(d.getMonth() + 3);
    return d.toISOString().split("T")[0];
};