import { VendorVehicle, Trip } from "../types/trip";

/* Trip 1 — Requested (awaiting admin) */
const tripRequested: Trip = {
    id: "TRIP-1001",
    vehicleId: "2",
    vehicleCode: "CAR-002",
    vendorId: "V-001",
    vendorName: "Flow Jamaica",
    requestedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    requestedBy: "Flow Jamaica",
    requestRemarks: "Urgent site visit",
    status: "Requested",
};

/* Trip 2 — Approved (ready to pick) */
const tripApproved: Trip = {
    id: "TRIP-1002",
    vehicleId: "3",
    vehicleCode: "CAR-003",
    vendorId: "V-001",
    vendorName: "Flow Jamaica",
    requestedAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    requestedBy: "Flow Jamaica",
    requestRemarks: "Client meeting",
    approvedAt: new Date(Date.now() - 1000 * 60 * 20).toISOString(),
    approvedBy: "Admin",
    status: "Approved",
};

/* Trip 3 — Picked (on the road) */
const tripPicked: Trip = {
    id: "TRIP-1003",
    vehicleId: "4",
    vehicleCode: "CAR-004",
    vendorId: "V-001",
    vendorName: "Flow Jamaica",
    requestedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    approvedAt: new Date(Date.now() - 1000 * 60 * 100).toISOString(),
    pickupTime: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    startKm: 12450,
    pickupLocation: "Head Office, Chennai",
    status: "Picked",
};

/* Trip 4 — Returned (awaiting admin review) */
const tripReturned: Trip = {
    id: "TRIP-1004",
    vehicleId: "5",
    vehicleCode: "CAR-005",
    vendorId: "V-001",
    vendorName: "Flow Jamaica",
    requestedAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
    approvedAt: new Date(Date.now() - 1000 * 60 * 280).toISOString(),
    pickupTime: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    startKm: 8200,
    pickupLocation: "Warehouse, Ambattur",
    returnTime: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    endKm: 8420,
    totalKm: 220,
    status: "Returned",
};

export const initialVendorFleet: VendorVehicle[] = [
    /* Available — no trip yet */
    {
        id: "1",
        fleetCode: "CAR-001",
        vehicleName: "Maruti Swift Dzire",
        registrationNo: "TN-09-CA-1001",
        category: "Sedan",
        vehicleType: "Four Wheeler",
        status: "Available",
        vehicleId: ""
    },

    /* Requested */
    {
        id: "2",
        fleetCode: "CAR-002",
        vehicleName: "Hyundai Creta",
        registrationNo: "TN-09-CA-1002",
        category: "SUV",
        vehicleType: "Four Wheeler",
        status: "Requested",
        activeTrip: tripRequested,
        vehicleId: ""
    },

    /* Approved */
    {
        id: "3",
        fleetCode: "CAR-003",
        vehicleName: "Toyota Innova Crysta",
        registrationNo: "TN-09-CA-1003",
        category: "MUV",
        vehicleType: "Four Wheeler",
        status: "Approved",
        activeTrip: tripApproved,
        vehicleId: ""
    },

    /* Picked */
    {
        id: "4",
        fleetCode: "CAR-004",
        vehicleName: "Honda City",
        registrationNo: "TN-09-CA-1004",
        category: "Sedan",
        vehicleType: "Four Wheeler",
        status: "Picked",
        activeTrip: tripPicked,
        vehicleId: ""
    },

    /* Returned */
    {
        id: "5",
        fleetCode: "CAR-005",
        vehicleName: "Tata Nexon EV",
        registrationNo: "TN-09-CA-1005",
        category: " ",
        vehicleType: "Four Wheeler",
        status: "Returned",
        activeTrip: tripReturned,
        vehicleId: ""
    },

    /* More Available */
    {
        id: "6",
        fleetCode: "CAR-006",
        vehicleName: "Mahindra Scorpio-N",
        registrationNo: "TN-09-CA-1006",
        category: "SUV",
        vehicleType: "Four Wheeler",
        status: "Available",
        vehicleId: ""
    },
    {
        id: "7",
        fleetCode: "BIKE-001",
        vehicleName: "Honda Activa 6G",
        registrationNo: "TN-09-BA-2001",
        category: "Scooter",
        vehicleType: "Two Wheeler",
        status: "Available",
        vehicleId: ""
    },
    {
        id: "8",
        fleetCode: "BIKE-002",
        vehicleName: "Hero Splendor Plus",
        registrationNo: "TN-09-BA-2002",
        category: "Motorcycle",
        vehicleType: "Two Wheeler",
        status: "Available",
        vehicleId: ""
    },
];