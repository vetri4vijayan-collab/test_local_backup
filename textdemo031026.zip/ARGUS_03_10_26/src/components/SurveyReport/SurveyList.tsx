import { JSXElementConstructor, Key, ReactElement, ReactNode, ReactPortal, useEffect, useRef, useState } from "react";
import {
    Plus,
    PencilSimple,
    Trash,
    Eye,
    CaretDown,
} from "@phosphor-icons/react";

import DataTable, {
    DataTableColumn,
} from "../DataTable";
import { useNavigate } from "react-router-dom";

export type SurveyTemplate = {
    id: number;
    name: string;
    description: string;
    status: "Active" | "Draft" | "Inactive";
    modules: string[];
    vendorCategory: string[];
};

export const INITIAL_TEMPLATES: SurveyTemplate[] = [
    {
        id: 1,
        name: "Full FTTH Field Survey",
        description: "Complete FTTH field survey covering CO, OSP poles, NAP, drop, defects, and PPE verification.",
        status: "Active",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
            "MOD-04",
            "MOD-05",
            "MOD-06",
        ],
        vendorCategory: ["Telecommunication"]
    },
    {
        id: 2,
        name: "FTTH OSP Network Survey",
        description: "Survey template for central office, pole/structure, and NAP network inspection.",
        status: "Draft",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
        ],
        vendorCategory: ["Construction","Telecommunication","Technology"]
    },
    {
        id: 3,
        name: "FTTH Network & Drop Survey",
        description: "Covers CO, OSP structures, NAP stations, and customer drop route verification.",
        status: "Active",
        modules: [
            "MOD-01",
            "MOD-02",
            "MOD-03",
            "MOD-04",
        ],
        vendorCategory: ["Technology"]
    },
    {
        id: 4,
        name: "Pole Structure Survey",
        description: "Dedicated OSP pole and structure inspection including location, condition, measurements, and observations.",
        status: "Active",
        modules: [
            "MOD-02",
        ],
        vendorCategory: ["Utilities"]
    },
];

function VendorPopover({ vendors }: { vendors: string[] }) {
    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    // close on outside click
    useEffect(() => {
        if (!open) return;

        const handler = (e: MouseEvent) => {
            if (ref.current && !ref.current.contains(e.target as Node)) {
                setOpen(false);
            }
        };

        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, [open]);

    return (
        <div ref={ref} className="relative inline-block">
            <button
                type="button"
                onClick={(e) => {
                    e.stopPropagation();
                    setOpen((v) => !v);
                }}
                className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600 transition hover:bg-slate-200"
            >
                +{vendors.length}
            </button>

            {open && (
                <div
                    className="absolute left-0 top-full z-50 mt-1 w-max min-w-[160px] rounded-lg border border-slate-200 bg-white p-2 shadow-lg"
                    onClick={(e) => e.stopPropagation()}
                >
                    <ul className="space-y-1">
                        {vendors.map((vendor) => (
                            <li
                                key={vendor}
                                className="whitespace-nowrap rounded px-2 py-1 text-xs text-slate-700"
                            >
                                {vendor}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
}

export default function SurveyList() {
    const [templates, setTemplates] =
        useState<SurveyTemplate[]>(INITIAL_TEMPLATES);
    

    const navigate = useNavigate();

    const handleDelete = (template: SurveyTemplate) => {
        const confirmed = window.confirm(
            `Are you sure you want to delete "${template.name}"?`
        );

        if (!confirmed) {
            return;
        }

        setTemplates((current) =>
            current.filter(
                (item) => item.id !== template.id
            )
        );
    };

    const handleEditTemplate = (
        template: SurveyTemplate
    ) => {
        navigate(
            `/survey_report/create_template?editId=${template.id}`
        );
    };

    const handleAddTemplate = () => {
        navigate("/survey_report/create_template");
    };

    const VENDOR_LABELS: Record<string, string> = {
    telecom: "Telecommunication",
    construction: "Construction",
    technology: "Technology",
    utilities: "Utilities",
};

const STATUS_STYLES: Record<string, string> = {
    Active:   "bg-emerald-50 text-emerald-700 border-emerald-200",
    Inactive: "bg-rose-50 text-rose-700 border-rose-200",
    Draft:    "bg-amber-50 text-amber-700 border-amber-200",
};

// Status dropdown options
const STATUS_OPTIONS = [
    { value: "Active",   label: "Active"   },
    { value: "Inactive", label: "Inactive" },
    { value: "Draft",    label: "Draft"    },
] as const;


type SurveyStatus = (typeof STATUS_OPTIONS)[number]["value"];


const handleUpdateStatus = (row: SurveyTemplate, nextStatus: string) => {
    setTemplates((current) =>
        current.map((t) =>
            t.id === row.id ? { ...t, status: nextStatus as SurveyTemplate["status"] } : t
        )
    );
};
const formatVendorLabel = (value: string): string =>
    VENDOR_LABELS[value] ?? value;

    const columns: DataTableColumn<SurveyTemplate>[] = [
        {
            key: "name",
            label: "Template Name",
            sortable: true,
            width: "20%",
            render: (row) => (
                <div>
                    <div className="font-medium text-slate-900">
                        {row.name}
                    </div>

                    <div className="mt-0.5 font-mono text-[10px] text-slate-400">
                        TMP-{String(row.id).padStart(3, "0")}
                    </div>
                </div>
            ),
        },

        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "42%",
            render: (row) => (
                <div className="max-w-xl truncate text-xs text-slate-500">
                    {row.description}
                </div>
            ),
        },

{
    key: "vendorCategory",
    label: "Vendor Category",
    sortable: true,
    width: "20%",
    render: (row) => {
        const vendors = row.vendorCategory ?? [];

        if (vendors.length === 0) {
            return (
                <span className="text-xs italic text-slate-400">
                    Not assigned
                </span>
            );
        }

        const first = formatVendorLabel(vendors[0]);

        // single vendor — just show the name
        if (vendors.length === 1) {
            return <span className="text-xs text-slate-700">{first}</span>;
        }

        // multiple vendors — show first + clickable +N
        return (
            <div className="flex items-center gap-1.5">
                <span className="truncate text-xs text-slate-700">
                    {first}
                </span>

                <VendorPopover
                    vendors={vendors.slice(1).map(formatVendorLabel)}
                />
            </div>
        );
    },
},
{
    key: "status",
    label: "Status",
    sortable: true,
    width: "18%",
    render: (row) => {
        const handleStatusChange = (nextStatus: string) => {
            if (nextStatus === row.status) return;

            handleUpdateStatus(row, nextStatus);
        };

        const statusStyle =
            STATUS_STYLES[row.status] ?? STATUS_STYLES.Draft;

        return (
            <div className="relative inline-block">
                <select
                    value={row.status}
                    onChange={(e) => handleStatusChange(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    className={`inline-flex cursor-pointer items-center rounded-full border px-2.5 py-1 pr-7 text-[10px] font-semibold outline-none appearance-none transition ${statusStyle}`}
                >
                    {STATUS_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>

                {/* Custom caret */}
                <CaretDown
                    size={10}
                    weight="bold"
                    className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 opacity-70"
                />
            </div>
        );
    },
},

        {
            key: "actions",
            label: "Actions",
            width: "12%",
            render: (row) => (
                <div className="flex items-center justify-content-center gap-2  transition-opacity duration-200 ">
                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();

                            navigate(
                                `/survey_report/view_form/${row.id}?from=survey_report`
                            );
                        }}
                        title="View Survey"
                        aria-label="View Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-sky-600 transition hover:bg-sky-50 hover:text-sky-700"
                    >
                        <Eye size={13} />
                    </button>

                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();
                            handleEditTemplate(row);
                        }}
                        title="Edit Survey"
                        aria-label="Edit Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
                    >
                        <PencilSimple size={13} />
                    </button>

                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();
                            handleDelete(row);
                        }}
                        title="Delete Survey"
                        aria-label="Delete Survey"
                        className="inline-flex items-center gap-1.5 rounded-lg bg-white px-2.5 py-1.5 text-xs font-medium text-red-600 transition hover:bg-red-50"
                    >
                        <Trash size={13} />
                    </button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-base font-semibold text-slate-900">
                        Survey Templates
                    </h1>

                    <p className="mt-1 text-xs leading-relaxed text-slate-500">
                        Create and manage survey
                        templates for field
                        inspections.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={handleAddTemplate}
                    className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
                >
                    <Plus
                        size={15}
                        weight="bold"
                    />

                    Add Template
                </button>
            </div>

            <DataTable<SurveyTemplate>
                columns={columns}
                data={templates}
                rowKey={(row) => row.id}
                emptyMessage="No survey templates found."
                minWidth="850px"
            />
        </div>
    );
}