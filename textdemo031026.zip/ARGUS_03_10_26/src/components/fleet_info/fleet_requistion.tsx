import { useMemo, useRef, useState } from "react";
import {
    CheckIcon,
    XIcon,
    EyeIcon,
    ClockIcon,
    TruckIcon,
    MagnifyingGlassIcon,
    CaretDownIcon,
    InfoIcon,
} from "@phosphor-icons/react";

import Button from "../../components/Button";
import DataTable, { DataTableColumn } from "../../components/DataTable";
import { VehicleStatus } from "../../types/trip";
import { createPortal } from "react-dom";
import RequisitionInfo from "../../offcanvas/fleet/requisition_info";

/* =========================================================
   TAB TYPE — must match the parent's FleetTab
========================================================= */
type FleetTab = "fleet-manage" | "fleet-requisition";

/* =========================================================
   TYPES
========================================================= */
export interface RequisitionRow {
    id: string;
    tripId: string;
    vehicleId: string;
    vehicleCode: string;
    vehicleName: string;
    registrationNo: string;
    category: string;
    vendorId: string;
    vendorName: string;
    requestedAt: string;
    requestRemarks?: string;
    status: VehicleStatus;
    approvalNote?: string;
    rejectionReason?: string;
}

/* =========================================================
   MOCK DATA
========================================================= */
export const requisitionRows: RequisitionRow[] = [
    /* =========================================================
       PENDING APPROVAL (Requested)
    ========================================================= */
    {
        id: "REQ-001",
        tripId: "TRIP-1001",
        vehicleId: "1",
        vehicleCode: "CAR-001",
        vehicleName: "Maruti Swift Dzire",
        registrationNo: "TN-09-CA-1001",
        category: "Sedan",
        vendorId: "V-001",
        vendorName: "Flow Jamaica",
        requestedAt: new Date().toISOString(),
        requestRemarks: "Urgent site visit to Villupuram",
        status: "Requested",
    },
    {
        id: "REQ-002",
        tripId: "TRIP-1002",
        vehicleId: "2",
        vehicleCode: "CAR-002",
        vehicleName: "Hyundai Creta",
        registrationNo: "TN-09-CA-1002",
        category: "SUV",
        vendorId: "V-002",
        vendorName: "Seiretsu",
        requestedAt: new Date(Date.now() - 3600_000).toISOString(),
        requestRemarks: "Client pickup at Chennai airport",
        status: "Requested",
    },
    {
        id: "REQ-003",
        tripId: "TRIP-1003",
        vehicleId: "3",
        vehicleCode: "CAR-003",
        vehicleName: "Toyota Innova Crysta",
        registrationNo: "TN-09-CA-1003",
        category: "MUV",
        vendorId: "V-001",
        vendorName: "Flow Jamaica",
        requestedAt: new Date(Date.now() - 7200_000).toISOString(),
        requestRemarks: "Team transport to Pondicherry site survey",
        status: "Requested",
    },

    /* =========================================================
       APPROVED
    ========================================================= */
    {
        id: "REQ-004",
        tripId: "TRIP-1004",
        vehicleId: "4",
        vehicleCode: "CAR-004",
        vehicleName: "Mahindra Scorpio N",
        registrationNo: "TN-09-CA-1004",
        category: "SUV",
        vendorId: "V-002",
        vendorName: "Seiretsu",
        requestedAt: new Date(Date.now() - 86_400_000).toISOString(),
        requestRemarks: "Executive client visit to OMR office",
        status: "Approved",
        approvalNote: "Approved — vehicle confirmed for 10:00 AM pickup.",
    },
    {
        id: "REQ-005",
        tripId: "TRIP-1005",
        vehicleId: "5",
        vehicleCode: "CAR-005",
        vehicleName: "Honda City",
        registrationNo: "TN-09-CA-1005",
        category: "Sedan",
        vendorId: "V-003",
        vendorName: "Jon doe",
        requestedAt: new Date(Date.now() - 172_800_000).toISOString(),
        requestRemarks: "Airport drop for senior engineer",
        status: "Approved",
        approvalNote: "Driver assigned — contact Ravi at 98xxxxxx12.",
    },

    /* =========================================================
       REJECTED
    ========================================================= */
    {
        id: "REQ-006",
        tripId: "TRIP-1006",
        vehicleId: "6",
        vehicleCode: "CAR-006",
        vehicleName: "Kia Seltos",
        registrationNo: "TN-09-CA-1006",
        category: "SUV",
        vendorId: "V-001",
        vendorName: "Flow Jamaica",
        requestedAt: new Date(Date.now() - 259_200_000).toISOString(),
        requestRemarks: "Weekend trip to Yercaud",
        status: "Rejected",
        rejectionReason:
            "Vehicle already committed to another route on the requested date.",
    },
    {
        id: "REQ-007",
        tripId: "TRIP-1007",
        vehicleId: "7",
        vehicleCode: "CAR-007",
        vehicleName: "Tata Nexon EV",
        registrationNo: "TN-09-CA-1007",
        category: "EV",
        vendorId: "V-002",
        vendorName: "Seiretsu",
        requestedAt: new Date(Date.now() - 345_600_000).toISOString(),
        requestRemarks: "Client demo run in city",
        status: "Rejected",
        rejectionReason:
            "Charging infrastructure not available at destination site.",
    },

    /* =========================================================
       RETURNED
    ========================================================= */
    {
        id: "REQ-008",
        tripId: "TRIP-1008",
        vehicleId: "8",
        vehicleCode: "CAR-008",
        vehicleName: "Toyota Fortuner",
        registrationNo: "TN-09-CA-1008",
        category: "SUV",
        vendorId: "V-001",
        vendorName: "Flow Jamaica",
        requestedAt: new Date(Date.now() - 432_000_000).toISOString(),
        requestRemarks: "Site inspection at Kanchipuram",
        status: "Returned",
        approvalNote: "Returned on time — odometer 12,458 km.",
    },

    /* =========================================================
       BONUS — PICKED / COMPLETED / AVAILABLE
       (in case you add those statuses to the filter later)
    ========================================================= */
    {
        id: "REQ-009",
        tripId: "TRIP-1009",
        vehicleId: "9",
        vehicleCode: "CAR-009",
        vehicleName: "Maruti Ertiga",
        registrationNo: "TN-09-CA-1009",
        category: "MUV",
        vendorId: "V-003",
        vendorName: "Jon doe",
        requestedAt: new Date(Date.now() - 518_400_000).toISOString(),
        requestRemarks: "Staff pickup from Chennai Central",
        status: "Picked",
        approvalNote: "Picked at 09:12 AM.",
    },
    {
        id: "REQ-010",
        tripId: "TRIP-1010",
        vehicleId: "10",
        vehicleCode: "CAR-010",
        vehicleName: "Hyundai Verna",
        registrationNo: "TN-09-CA-1010",
        category: "Sedan",
        vendorId: "V-001",
        vendorName: "Flow Jamaica",
        requestedAt: new Date(Date.now() - 604_800_000).toISOString(),
        requestRemarks: "Client pickup completed",
        status: "Completed",
        approvalNote: "Trip completed — invoice pending.",
    },
    {
        id: "REQ-011",
        tripId: "TRIP-1011",
        vehicleId: "11",
        vehicleCode: "CAR-011",
        vehicleName: "Renault Kwid",
        registrationNo: "TN-09-CA-1011",
        category: "Hatchback",
        vendorId: "V-002",
        vendorName: "Seiretsu",
        requestedAt: new Date(Date.now() - 691_200_000).toISOString(),
        requestRemarks: "Available for ad-hoc runs",
        status: "Available",
    },
];

/* =========================================================
   PROPS
========================================================= */
interface FleetRequisitionProps {
    rows?: RequisitionRow[];
    onApprove?: (tripId: string) => void;
    onReject?: (tripId: string) => void;
    onView?: (tripId: string) => void;

    activeTab?: FleetTab;
    onChange?: (tab: FleetTab) => void;
}

/* =========================================================
   STATUS BADGE
========================================================= */
function RequestStatusBadge({ status }: { status: VehicleStatus }) {
    const styles: Record<string, { cls: string; dot: string; label: string }> = {
        Requested: {
            cls: "bg-amber-100 text-amber-800 ring-amber-600/20",
            dot: "bg-amber-500",
            label: "Pending Approval",
        },
        Approved: {
            cls: "bg-blue-100 text-blue-800 ring-blue-600/20",
            dot: "bg-blue-500",
            label: "Approved",
        },
        Rejected: {
            cls: "bg-red-100 text-red-800 ring-red-600/20",
            dot: "bg-red-500",
            label: "Rejected",
        },
        Picked: {
            cls: "bg-indigo-100 text-indigo-800 ring-indigo-600/20",
            dot: "bg-indigo-500",
            label: "Picked",
        },
        Returned: {
            cls: "bg-purple-100 text-purple-800 ring-purple-600/20",
            dot: "bg-purple-500",
            label: "Returned",
        },
        Completed: {
            cls: "bg-green-100 text-green-800 ring-green-600/20",
            dot: "bg-green-500",
            label: "Completed",
        },
        Available: {
            cls: "bg-slate-100 text-slate-700 ring-slate-400/20",
            dot: "bg-slate-400",
            label: "Available",
        },
    };

    const s = styles[status] ?? styles.Available;

    return (
        <span
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${s.cls}`}
        >
            <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
            {s.label}
        </span>
    );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */
export default function FleetRequisition({
    rows = requisitionRows,
    onApprove,
    onReject,
    onView,
    activeTab = "fleet-requisition",
    onChange,
}: FleetRequisitionProps) {
    const [filter, setFilter] = useState<
        "all" | "Requested" | "Approved" | "Rejected"
    >("Requested");
    const [search, setSearch] = useState("");
    const [showPopup, setShowPopup] = useState(false);
    const [popupMessage, setPopupMessage] = useState("");
    const [popupType, setPopupType] = useState<"success" | "error">("success");

    const [reasonOverrides, setReasonOverrides] = useState<Record<string, string>>({});
    const [noteOverrides, setNoteOverrides] = useState<Record<string, string>>({});
    const [expandedRowId, setExpandedRowId] = useState<string | null>(null);
    const [viewRow, setViewRow] = useState<RequisitionRow | null>(null);

    /* ---------- Modal state ---------- */
    type ModalMode = "approve" | "reject" | null;
    const [modalMode, setModalMode] = useState<ModalMode>(null);
    const [activeRow, setActiveRow] = useState<RequisitionRow | null>(null);
    const [note, setNote] = useState("");
    const [reason, setReason] = useState("");
    const [reasonError, setReasonError] = useState(false);
    const [statusOverrides, setStatusOverrides] = useState<
        Record<string, VehicleStatus>
    >({});

    const btnRefs = useRef<Record<string, HTMLButtonElement | null>>({});

    /* ---- Filtered rows ---- */
    const filtered = useMemo(() => {
        const q = search.trim().toLowerCase();
        return rows
            .map((r) => ({
                ...r,
                status: statusOverrides[r.id] ?? r.status,
            }))
            .filter((r) => {
                const matchesStatus = filter === "all" || r.status === filter;
                const matchesSearch =
                    q === "" ||
                    r.vehicleName.toLowerCase().includes(q) ||
                    r.vehicleCode.toLowerCase().includes(q) ||
                    r.registrationNo.toLowerCase().includes(q) ||
                    r.vendorName.toLowerCase().includes(q);
                return matchesStatus && matchesSearch;
            });
    }, [rows, filter, search, statusOverrides]);

    /* ---- Counts ---- */
    const pendingCount = rows.filter((r) => r.status === "Requested").length;
    const approvedCount = rows.filter((r) => r.status === "Approved").length;
    const rejectedCount = rows.filter((r) => r.status === "Rejected").length;

    /* ---------- Handlers ---------- */
    function handleStatusChange(row: RequisitionRow, newStatus: string) {
        setStatusOverrides((prev) => ({
            ...prev,
            [row.id]: newStatus as VehicleStatus,
        }));

        if (newStatus === "Approved") {
            onApprove?.(row.tripId);
            setPopupMessage(
                `${row.vendorName} approved successfully for ${row.vehicleName}.`
            );
            setPopupType("success");
            setShowPopup(true);
            setTimeout(() => setShowPopup(false), 3000);
            return;
        }

        if (newStatus === "Rejected") {
            onReject?.(row.tripId);
            setPopupMessage(
                `${row.vendorName}'s request for ${row.vehicleName} has been rejected.`
            );
            setPopupType("error");
            setShowPopup(true);
            setTimeout(() => setShowPopup(false), 3000);
            return;
        }
    }

    function closeModal() {
        setModalMode(null);
        setActiveRow(null);
        setNote("");
        setReason("");
        setReasonError(false);
    }

    function confirmApprove() {
        if (!activeRow) return;

        setStatusOverrides((prev) => ({
            ...prev,
            [activeRow.id]: "Approved" as VehicleStatus,
        }));

        if (note.trim()) {
            setNoteOverrides((prev) => ({ ...prev, [activeRow.id]: note.trim() }));
        }

        onApprove?.(activeRow.tripId);

        setPopupMessage(
            `${activeRow.vendorName} approved successfully for ${activeRow.vehicleName}.`
        );
        setPopupType("success");
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 3000);

        closeModal();
    }

    function confirmReject() {
        if (!activeRow) return;

        if (!reason.trim()) {
            setReasonError(true);
            return;
        }

        setStatusOverrides((prev) => ({
            ...prev,
            [activeRow.id]: "Rejected" as VehicleStatus,
        }));

        setReasonOverrides((prev) => ({
            ...prev,
            [activeRow.id]: reason.trim(),
        }));

        /* 👇 auto-open the reason panel for the row you just rejected */
        setExpandedRowId(activeRow.id);

        onReject?.(activeRow.tripId);

        setPopupMessage(
            `${activeRow.vendorName}'s request for ${activeRow.vehicleName} has been rejected.`
        );
        setPopupType("error");
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 3000);

        closeModal();
    }

    /* =========================================================
       TABLE COLUMNS
    ========================================================= */
    const columns: DataTableColumn<RequisitionRow>[] = [
        {
            key: "vehicleCode",
            label: "Fleet Code",
            sortable: true,
            render: (r) => (
                <span className="text-xs font-bold text-slate-700">
                    {r.vehicleCode}
                </span>
            ),
        },
        {
            key: "vehicleName",
            label: "Vehicle Name",
            sortable: true,
            render: (r) => (
                <div>
                    <p className="text-xs font-semibold text-slate-900">
                        {r.vehicleName}
                    </p>
                    <p className="text-[10px] text-slate-400">{r.category}</p>
                </div>
            ),
        },
        {
            key: "registrationNo",
            label: "Reg No",
            sortable: true,
            render: (r) => (
                <span className="font-mono text-xs text-slate-700">
                    {r.registrationNo}
                </span>
            ),
        },
        {
            key: "vendorName",
            label: "Requested By (Vendor)",
            sortable: true,
            render: (r) => (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-700 ring-1 ring-inset ring-blue-600/20">
                    <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                    {r.vendorName}
                </span>
            ),
        },
        {
            key: "requestedAt",
            label: "Requested At",
            sortable: true,
            render: (r) => (
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <ClockIcon size={12} className="text-slate-400" />
                    {new Date(r.requestedAt).toLocaleString([], {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                    })}
                </div>
            ),
        },
        {
            key: "requestRemarks",
            label: "Reason / Remarks",
            render: (r) => (
                <span
                    className="block max-w-[220px] truncate text-xs text-slate-600"
                    title={r.requestRemarks || "—"}
                >
                    {r.requestRemarks || "—"}
                </span>
            ),
        },
{
    key: "status",
    label: "Status",
    sortable: true,
    align: "center",
    render: (row) => {
        const currentStatus = statusOverrides[row.id] ?? row.status;
        const rejection = reasonOverrides[row.id] ?? row.rejectionReason;
        const approvalNote = noteOverrides[row.id] ?? row.approvalNote;

        const styles: Record<
    string,
    { cls: string; dot: string; label: string }
> = {
    Requested: {
        cls: "bg-amber-100 text-amber-800 ring-amber-600/20",
        dot: "bg-amber-500",
        label: "Pending Approval",
    },
    Approved: {
        cls: "bg-blue-100 text-blue-800 ring-blue-600/20",
        dot: "bg-blue-500",
        label: "Approved",
    },
    Rejected: {
        cls: "bg-red-100 text-red-800 ring-red-600/20",
        dot: "bg-red-500",
        label: "Rejected",
    },
    Returned: {
        cls: "bg-purple-100 text-purple-800 ring-purple-600/20",
        dot: "bg-purple-500",
        label: "Returned",
    },
    Picked: {
        cls: "bg-indigo-100 text-indigo-800 ring-indigo-600/20",
        dot: "bg-indigo-500",
        label: "Picked",
    },
    Completed: {
        cls: "bg-green-100 text-green-800 ring-green-600/20",
        dot: "bg-green-500",
        label: "Completed",
    },
    Available: {
        cls: "bg-slate-100 text-slate-700 ring-slate-400/20",
        dot: "bg-slate-400",
        label: "Available",
    },
};

        const s = styles[currentStatus] ?? {
            cls: "bg-slate-100 text-slate-700 ring-slate-400/20",
            dot: "bg-slate-400",
            label: currentStatus,
        };

        return (
            <div className="flex items-center justify-center gap-1.5">
                <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${s.cls}`}
                >
                    <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
                    {s.label}
                </span>

                {/* ℹ️ Rejected + info popover anchored to the icon */}
             {currentStatus === "Rejected" && rejection && (
                <span className="relative inline-flex">
                    <button
                        ref={(el) => { btnRefs.current[row.id] = el; }}
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();
                            setExpandedRowId((prev) =>
                                prev === row.id ? null : row.id
                            );
                        }}
                        className={`flex h-5 w-5 items-center justify-center rounded-full transition ${
                            expandedRowId === row.id
                                ? "bg-red-600 text-white"
                                : "bg-red-100 text-red-600 hover:bg-red-200"
                        }`}
                        title="Rejection reason"
                    >
                        <InfoIcon size={12} weight="bold" />
                    </button>
                </span>
            )}

                {/* ℹ️ Approved + note popover */}
                {currentStatus === "Approved" && approvalNote && (
                    <span className="group relative inline-flex">
                        <button
                            type="button"
                            onClick={(e) => e.stopPropagation()}
                            className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 transition hover:bg-blue-200"
                            title="Approval note"
                        >
                            <InfoIcon size={12} weight="bold" />
                        </button>

                        <span
                            className="
                                pointer-events-none absolute left-1/2 top-full z-[100] mt-2 w-64
                                -translate-x-1/2 rounded-lg border border-slate-200
                                bg-white p-2.5 text-left text-[11px] leading-relaxed
                                text-slate-700 opacity-0 shadow-lg transition-opacity
                                duration-150 group-hover:opacity-100
                            "
                        >
                            <span className="block font-semibold text-blue-600">
                                Approval Note
                            </span>
                            <span className="mt-1 block text-slate-600">
                                {approvalNote}
                            </span>
                        </span>
                    </span>
                )}
            </div>
        );
    },
},
{
    key: "action",
    label: "Actions",
    align: "center",
    render: (row) => {
        const currentStatus = statusOverrides[row.id] ?? row.status;

        /* 👁️ Shared view button — rendered in every state */
        const ViewButton = (
         <Button
            type="button"
            variant="outline"
            onClick={() => {
                setExpandedRowId(null);   // close any open reason popover
                setViewRow(row);
            }}
            className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-700"
            title="View request"
        >
            <EyeIcon size={16} />
        </Button>
        );

        /* ---------- REQUESTED → View / Approve / Reject ---------- */
        if (currentStatus === "Requested") {
            return (
                <div className="flex items-center justify-center gap-2">
                    {ViewButton}

                    {/* ✅ Approve */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                            setActiveRow(row);
                            setNote("");
                            setModalMode("approve");
                        }}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-green-600"
                        title="Approve"
                    >
                        <CheckIcon size={16} weight="bold" />
                    </Button>

                    {/* ❌ Reject */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                            setActiveRow(row);
                            setReason("");
                            setReasonError(false);
                            setModalMode("reject");
                        }}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-red-600"
                        title="Reject"
                    >
                        <XIcon size={16} weight="bold" />
                    </Button>
                </div>
            );
        }

        /* ---------- APPROVED → View + Awaiting pickup ---------- */
        if (currentStatus === "Approved") {
            return (
                <div className="flex items-center justify-center gap-2">
                    {ViewButton}

                    <span
                        className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-50 text-blue-600"
                        title="Awaiting pickup"
                    >
                        <ClockIcon size={16} weight="bold" />
                    </span>
                </div>
            );
        }

        /* ---------- REJECTED → View + ✕ ---------- */
        if (currentStatus === "Rejected") {
            return (
                <div className="flex items-center justify-center gap-2">
                    {ViewButton}

                    <span
                        className="flex h-8 w-8 items-center justify-center rounded-md bg-red-50 text-red-600"
                        title="Rejected"
                    >
                        <XIcon size={16} weight="bold" />
                    </span>
                </div>
            );
        }

        /* ---------- Fallback ---------- */
        return (
            <div className="flex items-center justify-center gap-2">
                {ViewButton}
            </div>
        );
    },
},
    ];

    /* =========================================================
       RENDER
    ========================================================= */
    return (
        <>
            {/* ==============================================
                TAB BAR
            ============================================== */}
            {/* <div className="mb-6 flex items-center justify-between">
                <div className="inline-flex items-center rounded-xl bg-slate-100 p-1">
                    <button
                        type="button"
                        onClick={() => onChange?.("fleet-manage")}
                        className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                            activeTab === "fleet-manage"
                                ? "bg-white text-red-600 shadow-sm"
                                : "text-slate-500 hover:text-slate-700"
                        }`}
                    >
                        <span>FLEET MANAGE</span>
                    </button>

                    <button
                        type="button"
                        onClick={() => onChange?.("fleet-requisition")}
                        className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                            activeTab === "fleet-requisition"
                                ? "bg-white text-red-600 shadow-sm"
                                : "text-slate-500 hover:text-slate-700"
                        }`}
                    >
                        <span>FLEET REQUISITION</span>
                    </button>
                </div>
            </div> */}

            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div>
                        <h1 className="text-2xl font-bold text-slate-900">
                            Fleet Requisition
                        </h1>
                        <p className="text-xs text-slate-500">
                            Review and approve vendor vehicle requests
                        </p>
                    </div>
                </div>
            </div>

            {/* Search + Filters */}
            <div className="mb-6 flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3">
                <div className="relative flex-1">
                    <MagnifyingGlassIcon
                        size={16}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                    <input
                        type="text"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Search by vehicle, vendor, or fleet code..."
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-9 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-red-400"
                    />
                    {search && (
                        <button
                            type="button"
                            onClick={() => setSearch("")}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                        >
                            <XIcon size={14} />
                        </button>
                    )}
                </div>

                <div className="relative">
                    <select
                        value={filter}
                        onChange={(e) =>
                            setFilter(e.target.value as typeof filter)
                        }
                        className="appearance-none rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-4 pr-9 text-sm font-medium text-slate-700 focus:border-red-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-red-400"
                    >
                        <option value="all">All Statuses</option>
                        <option value="Requested">Pending ({pendingCount})</option>
                        <option value="Approved">Approved ({approvedCount})</option>
                        <option value="Rejected">Rejected ({rejectedCount})</option>
                    </select>
                    <CaretDownIcon
                        size={14}
                        className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                </div>
            </div>

            {/* ==============================================
                REJECTION REASON PANEL — outside the table
            ============================================== */}


            {/* Table */}
            <DataTable
                columns={columns}
                data={filtered}
                rowKey={(r) => r.id}
                emptyMessage="No requisition requests found."
            />

            {/* ---------- TOAST POPUP ---------- */}
            {showPopup &&
                createPortal(
                    <div className="fixed right-6 top-6 z-[2000] animate-slide-in-right">
                        <div
                            className={`flex items-start gap-3 rounded-xl border px-4 py-3 shadow-lg ${
                                popupType === "success"
                                    ? "border-green-200 bg-green-50"
                                    : "border-red-200 bg-red-50"
                            }`}
                        >
                            <div
                                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                                    popupType === "success"
                                        ? "bg-green-100 text-green-600"
                                        : "bg-red-100 text-red-600"
                                }`}
                            >
                                {popupType === "success" ? (
                                    <CheckIcon size={18} weight="bold" />
                                ) : (
                                    <XIcon size={18} weight="bold" />
                                )}
                            </div>

                            <div className="flex-1">
                                <p
                                    className={`text-sm font-semibold ${
                                        popupType === "success"
                                            ? "text-green-800"
                                            : "text-red-800"
                                    }`}
                                >
                                    {popupType === "success"
                                        ? "Approved Successfully"
                                        : "Request Rejected"}
                                </p>
                                <p
                                    className={`mt-0.5 text-xs ${
                                        popupType === "success"
                                            ? "text-green-700"
                                            : "text-red-700"
                                    }`}
                                >
                                    {popupMessage}
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() => setShowPopup(false)}
                                className={`shrink-0 rounded-md p-1 transition-colors ${
                                    popupType === "success"
                                        ? "text-green-500 hover:bg-green-100"
                                        : "text-red-500 hover:bg-red-100"
                                }`}
                            >
                                <XIcon size={14} weight="bold" />
                            </button>
                        </div>
                    </div>,
                    document.body
                )}

            {/* ---------- REJECTION REASON POPOVER (portal) ---------- */}
            {expandedRowId && (() => {
                const row = rows.find((r) => r.id === expandedRowId);
                const rejection = row
                    ? reasonOverrides[row.id] ?? row.rejectionReason
                    : null;
                const btn = btnRefs.current[expandedRowId];
                if (!row || !rejection || !btn) return null;

                const rect = btn.getBoundingClientRect();

                return createPortal(
                    <>
                        {/* Click-away backdrop */}
                        <div
                            className="fixed inset-0 z-[2500]"
                            onClick={() => setExpandedRowId(null)}
                        />

                        {/* Popover */}
                        <div
                            className="fixed z-[2600] w-64 rounded-lg border border-red-200 bg-white p-3 text-left shadow-xl"
                            style={{
                                top: rect.bottom + 8,
                                left: rect.left + rect.width / 2,
                                transform: "translateX(-50%)",
                            }}
                            onClick={(e) => e.stopPropagation()}
                        >
                            {/* Upward arrow */}
                            <span
                                className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 border-l border-t border-red-200 bg-white"
                            />

                            <p className="text-[11px] font-bold uppercase tracking-wide text-red-700">
                                Rejection Reason
                            </p>
                            <p className="mt-1 text-xs leading-relaxed text-slate-700">
                                {rejection}
                            </p>
                        </div>
                    </>,
                    document.body
                );
            })()}
            {/* ---------- APPROVE / REJECT MODAL ---------- */}
            {modalMode && activeRow &&
                createPortal(
                    <>
                        {/* Backdrop */}
                        <div
                            className="fixed inset-0 z-[2100] bg-slate-900/40 backdrop-blur-[2px] animate-fade-in"
                            onClick={closeModal}
                        />

                        {/* Modal */}
                        <div className="fixed inset-0 z-[2200] flex items-center justify-center p-4">
                            <div
                                className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl animate-scale-in"
                                onClick={(e) => e.stopPropagation()}
                            >
                                {/* HEADER */}
                                <div className="flex items-start gap-3 border-b border-slate-100 px-5 py-4">
                                    <div
                                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                                            modalMode === "approve"
                                                ? "bg-green-100 text-green-600"
                                                : "bg-red-100 text-red-600"
                                        }`}
                                    >
                                        {modalMode === "approve" ? (
                                            <CheckIcon size={20} weight="bold" />
                                        ) : (
                                            <XIcon size={20} weight="bold" />
                                        )}
                                    </div>
                                    <div className="flex-1">
                                        <h3 className="text-sm font-bold text-slate-900">
                                            {modalMode === "approve"
                                                ? "Approve Request"
                                                : "Reject Request"}
                                        </h3>
                                        <p className="mt-0.5 text-xs text-slate-500">
                                            {modalMode === "approve"
                                                ? "Confirm approval for this vehicle request."
                                                : "Provide a reason for rejecting this request."}
                                        </p>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={closeModal}
                                        className="shrink-0 rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                                    >
                                        <XIcon size={16} weight="bold" />
                                    </button>
                                </div>

                                {/* BODY */}
                                <div className="space-y-4 px-5 py-4">
                                    {/* Request summary */}
                                    <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3">
                                        <div className="flex items-center gap-2">
                                            <TruckIcon
                                                size={16}
                                                className="text-slate-500"
                                                weight="duotone"
                                            />
                                            <p className="text-sm font-semibold text-slate-900">
                                                {activeRow.vehicleName}
                                            </p>
                                        </div>
                                        <p className="mt-1 text-[11px] text-slate-500">
                                            {activeRow.vehicleCode} · {activeRow.registrationNo}
                                        </p>

                                        <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-[11px]">
                                            <div>
                                                <p className="text-slate-400">Requested By</p>
                                                <p className="font-semibold text-slate-700">
                                                    {activeRow.vendorName}
                                                </p>
                                            </div>
                                            <div>
                                                <p className="text-slate-400">Category</p>
                                                <p className="font-semibold text-slate-700">
                                                    {activeRow.category}
                                                </p>
                                            </div>
                                            {activeRow.requestRemarks && (
                                                <div className="col-span-2">
                                                    <p className="text-slate-400">
                                                        Reason / Remarks
                                                    </p>
                                                    <p className="font-medium text-slate-700">
                                                        {activeRow.requestRemarks}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {/* Approval note (optional) */}
                                    {modalMode === "approve" && (
                                        <div>
                                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                Note{" "}
                                                <span className="font-normal text-slate-400">
                                                    (optional)
                                                </span>
                                            </label>
                                            <textarea
                                                value={note}
                                                onChange={(e) => setNote(e.target.value)}
                                                rows={3}
                                                placeholder="Add a note for the vendor (e.g. pickup time, contact person)..."
                                                className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 focus:border-green-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-green-400"
                                            />
                                        </div>
                                    )}

                                    {/* Rejection reason (required) */}
                                    {modalMode === "reject" && (
                                        <div>
                                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                Reason for rejection{" "}
                                                <span className="text-red-500">*</span>
                                            </label>
                                            <textarea
                                                value={reason}
                                                onChange={(e) => {
                                                    setReason(e.target.value);
                                                    if (reasonError)
                                                        setReasonError(false);
                                                }}
                                                rows={4}
                                                placeholder="Enter the reason for rejecting this request..."
                                                className={`w-full resize-none rounded-xl border px-3 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-1 ${
                                                    reasonError
                                                        ? "border-red-300 bg-red-50 focus:border-red-400 focus:ring-red-400"
                                                        : "border-slate-200 bg-slate-50 focus:border-red-400 focus:bg-white focus:ring-red-400"
                                                }`}
                                            />
                                            {reasonError && (
                                                <p className="mt-1 flex items-center gap-1 text-[11px] font-medium text-red-600">
                                                    <XIcon size={11} weight="bold" />
                                                    Reason is required to reject this request.
                                                </p>
                                            )}
                                        </div>
                                    )}
                                </div>

                                {/* FOOTER */}
                                <div className="flex items-center justify-end gap-3 border-t border-slate-100 bg-slate-50/60 px-5 py-3">
                                    <button
                                        type="button"
                                        onClick={closeModal}
                                        className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                                    >
                                        Cancel
                                    </button>

                                    {modalMode === "approve" ? (
                                        <button
                                            type="button"
                                            onClick={confirmApprove}
                                            className="flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-green-700"
                                        >
                                            <CheckIcon size={14} weight="bold" />
                                            Confirm Approval
                                        </button>
                                    ) : (
                                        <button
                                            type="button"
                                            onClick={confirmReject}
                                            className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                                        >
                                            <XIcon size={14} weight="bold" />
                                            Confirm Rejection
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </>,
                    document.body
                )}
                {/* ---------- REQUEST INFO DRAWER ---------- */}
            {viewRow && (
                <RequisitionInfo
                    isOpen={!!viewRow}
                    onClose={() => setViewRow(null)}
                    row={viewRow}
                />
            )}
        </>
    );
}