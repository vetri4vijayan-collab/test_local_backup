import { useMemo, useState } from "react";
import { createPortal } from "react-dom";
import {
    EyeIcon,
    PenNibIcon,
    TrashIcon,
    UserIcon,
} from "@phosphor-icons/react";

import Button from "../Button";
import DataTable, { DataTableColumn } from "../DataTable";
import {
    FleetItem,
    InsuranceStatus,
} from "../../types/fleet";
import FleetInfo from "../../offcanvas/fleet/fleet_info";

/* =========================================================
   INSURANCE BADGE
========================================================= */
const insuranceBadge: Record<
    InsuranceStatus,
    { label: string; cls: string; dot: string }
> = {
    active: {
        label: "Active & Valid",
        cls: "bg-green-100 text-green-800 ring-green-600/20",
        dot: "bg-green-500",
    },
    expiring: {
        label: "Expiring Soon",
        cls: "bg-amber-100 text-amber-800 ring-amber-600/20",
        dot: "bg-amber-500",
    },
    expired: {
        label: "Expired",
        cls: "bg-red-100 text-red-800 ring-red-600/20",
        dot: "bg-red-500",
    },
};

function InsuranceBadge({ status }: { status: InsuranceStatus }) {
    const s = insuranceBadge[status];
    return (
        <span
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${s.cls}`}
        >
            <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
            {s.label}
        </span>
    );
}

/* =========================================================
   VENDOR OPTIONS
========================================================= */
interface SelectOption {
    value: string;
    label: string;
}

const assignedVendorOptions: SelectOption[] = [
    { value: "Flow Jamaica", label: "Flow Jamaica" },
    { value: "Seiretsu", label: "Seiretsu" },
    { value: "Jon doe", label: "Jon doe" },
];

/* =========================================================
   PROPS
========================================================= */
export interface FleetProps {
    rows: FleetItem[];
    onEdit?: (row: FleetItem) => void;
    onDelete?: (row: FleetItem) => void;
    onAssignVendor?: (vehicleId: string, vendorName: string) => void;
}

/* =========================================================
   MAIN COMPONENT
========================================================= */
export default function FleetList({
    rows,
    onEdit,
    onDelete,
    onAssignVendor,
}: FleetProps) {
    const [search, setSearch] = useState("");
    const [categoryFilter, setCategoryFilter] = useState("all");

    const [openVendorMenuId, setOpenVendorMenuId] = useState<string | null>(null);
    const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(
        null
    );
    const [viewFleet, setViewFleet] = useState<FleetItem | null>(null);

    /* ---- Filtered data ---- */
    const filtered = useMemo(() => {
        const q = search.trim().toLowerCase();
        return rows.filter((row) => {
            const matchesCategory =
                categoryFilter === "all" || row.category === categoryFilter;
            const matchesSearch =
                q === "" ||
                row.fleetCode.toLowerCase().includes(q) ||
                row.vehicleName.toLowerCase().includes(q);
            return matchesCategory && matchesSearch;
        });
    }, [rows, search, categoryFilter]);

    /* ---- View handlers ---- */
    function openView(row: FleetItem) {
        setOpenVendorMenuId(null);
        setViewFleet(row);
    }
    function closeView() {
        setViewFleet(null);
    }

    /* =========================================================
       COLUMNS
    ========================================================= */
    const columns: DataTableColumn<FleetItem>[] = [
        {
            key: "fleetCode",
            label: "Fleet Code",
            sortable: true,
            render: (r) => (
                <a
                    href={`/fleet/${r.fleetCode}`}
                    className="text-xs font-bold text-slate-600 hover:underline"
                >
                    {r.fleetCode}
                </a>
            ),
        },
        {
            key: "vehicleName",
            label: "Vehicle Name",
            sortable: true,
            render: (r) => (
                <span className="text-xs font-semibold text-slate-900">
                    {r.vehicleName}
                </span>
            ),
        },
        {
            key: "category",
            label: "Category",
            sortable: true,
            render: (r) => (
                <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-600">
                    {r.category}
                </span>
            ),
        },
        {
            key: "registrationNo",
            label: "Reg No",
            sortable: true,
            render: (r) => (
                <span className="font-mono text-xs text-slate-700">
                    {r.registrationNo}
                </span>
            ),
        },
        {
            key: "assignedVendor",
            label: "Assigned Vendor",
            sortable: true,
            render: (r) => {
                const vendor = r.assignedVendor;
                if (!vendor) {
                    return (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-semibold text-slate-500 ring-1 ring-inset ring-slate-400/20">
                            <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                            Unassigned
                        </span>
                    );
                }
                return (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-2.5 py-0.5 text-[11px] font-semibold text-blue-700 ring-1 ring-inset ring-blue-600/20">
                        <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                        {vendor}
                    </span>
                );
            },
        },
        {
            key: "insuranceStatus",
            label: "Insurance Status",
            sortable: true,
            align: "center",
            render: (r) => (
                <div className="flex justify-center">
                    <InsuranceBadge status={r.insuranceStatus} />
                </div>
            ),
        },
        {
            key: "serviceStatus",
            label: "Service",
            sortable: true,
            align: "center",
            render: (r) => {
                const hasDate = !!r.nextServiceDueDate;
                return (
                    <span
                        className={`text-[11px] ${
                            hasDate ? "text-slate-500" : "text-slate-300 italic"
                        }`}
                        title={
                            hasDate
                                ? `Next service due: ${r.nextServiceDueDate}`
                                : "No service scheduled"
                        }
                    >
                        {hasDate
                            ? `Due ${r.nextServiceDueDate}`
                            : "Not scheduled"}
                    </span>
                );
            },
        },
        {
            key: "action",
            label: "Actions",
            align: "center",
            render: (row) => (
                <div className="flex items-center justify-center gap-2">
                    {/* 👁️ VIEW */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => openView(row)}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-700"
                        title="View fleet details"
                    >
                        <EyeIcon size={16} />
                    </Button>

                    {/* 👤 ASSIGN VENDOR */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={(e) => {
                            const rect = (
                                e.currentTarget as HTMLElement
                            ).getBoundingClientRect();
                            setMenuPos({
                                top: rect.bottom + 6,
                                left: rect.right - 176,
                            });
                            setOpenVendorMenuId(
                                openVendorMenuId === row.id ? null : row.id
                            );
                        }}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-blue-600"
                        title="Assign vendor"
                    >
                        <UserIcon size={16} />
                    </Button>

                    {/* ✏️ EDIT */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => onEdit?.(row)}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-amber-600"
                        title="Edit fleet"
                    >
                        <PenNibIcon size={16} />
                    </Button>

                    {/* 🗑️ DELETE */}
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => onDelete?.(row)}
                        className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-red-600"
                        title="Delete fleet"
                    >
                        <TrashIcon size={16} />
                    </Button>
                </div>
            ),
        },
    ];

    /* =========================================================
       RENDER
    ========================================================= */
    return (
        <>
            <DataTable
                columns={columns}
                data={filtered}
                rowKey={(r) => r.id}
                emptyMessage="No fleet records match your filters."
            />

            <FleetInfo
                isOpen={!!viewFleet}
                fleet={viewFleet}
                onClose={closeView}
            />

            {/* ===============================================
                VENDOR DROPDOWN PORTAL
            =============================================== */}
            {openVendorMenuId &&
                menuPos &&
                createPortal(
                    <>
                        <div
                            className="fixed inset-0 z-[999]"
                            onClick={() => setOpenVendorMenuId(null)}
                        />

                        <div
                            className="fixed z-[1000] w-44 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xl"
                            style={{ top: menuPos.top, left: menuPos.left }}
                        >
                            <div className="border-b border-slate-100 px-3 py-2">
                                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                    Assign to
                                </p>
                            </div>

                            {assignedVendorOptions.map((v) => {
                                const current = rows.find(
                                    (d) => d.id === openVendorMenuId
                                );
                                const isActive =
                                    current?.assignedVendor === v.value;

                                return (
                                    <button
                                        key={v.value}
                                        type="button"
                                        onClick={() => {
                                            onAssignVendor?.(
                                                openVendorMenuId,
                                                v.value
                                            );
                                            setOpenVendorMenuId(null);
                                        }}
                                        className={`flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-medium transition-colors hover:bg-slate-50 ${
                                            isActive
                                                ? "bg-blue-50 text-blue-700"
                                                : "text-slate-700"
                                        }`}
                                    >
                                        <span
                                            className={`h-1.5 w-1.5 rounded-full ${
                                                isActive
                                                    ? "bg-blue-500"
                                                    : "bg-slate-300"
                                            }`}
                                        />
                                        {v.label}
                                    </button>
                                );
                            })}

                            {rows.find((d) => d.id === openVendorMenuId)
                                ?.assignedVendor && (
                                <>
                                    <div className="h-px bg-slate-100" />
                                    <button
                                        type="button"
                                        onClick={() => {
                                            onAssignVendor?.(
                                                openVendorMenuId,
                                                ""
                                            );
                                            setOpenVendorMenuId(null);
                                        }}
                                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-medium text-red-600 transition-colors hover:bg-red-50"
                                    >
                                        <span className="h-1.5 w-1.5 rounded-full bg-red-500" />
                                        Unassign
                                    </button>
                                </>
                            )}
                        </div>
                    </>,
                    document.body
                )}
        </>
    );
}