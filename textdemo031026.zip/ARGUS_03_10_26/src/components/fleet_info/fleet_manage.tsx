import { useState } from "react";
import { PlusIcon } from "@phosphor-icons/react";

import Button from "../Button";
import FleetList from "./fleet_list";
import VendorFleet from "./fleet_vendor";
import FleetRequisition from "./fleet_requistion";
import AddNewFleet from "../../offcanvas/fleet/newfleet";

import {
    FleetItem,
    FleetFormValues,
} from "../../types/fleet";
import {
    initialFleetData,
    computeNextServiceDue,
    todayIso,
} from "../../data/fleet_datas";

/* ---------- Types ---------- */
type Section = "admin" | "vendor";
type AdminTab = "fleet-manage" | "fleet-requisition";

export default function Fleet_manage() {
    const [section, setSection] = useState<Section>("admin");
    const [adminTab, setAdminTab] = useState<AdminTab>("fleet-manage");

    /* ---------- Fleet data (owned here now) ---------- */
    const [fleetData, setFleetData] = useState<FleetItem[]>(initialFleetData);

    /* ---------- Add / Edit drawer state ---------- */
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [editingFleet, setEditingFleet] = useState<FleetFormValues | null>(null);

    function openAdd() {
        setEditingFleet(null);
        setIsDrawerOpen(true);
    }

    function openEdit(row: FleetItem) {
        setEditingFleet({
            fleetCode: row.fleetCode,
            vehicleName: row.vehicleName,
            category: row.category,
            registrationNo: row.registrationNo,
            siteLocation: row.siteLocation,
            chassisVinNo: row.chassisVinNo ?? "",
            engineNo: row.engineNo ?? "",
            makeBrand: row.makeBrand ?? "",
            modelVariant: row.modelVariant ?? "",
            mfgYear: row.mfgYear ?? "",
            ownershipType: row.ownershipType ?? "",
            purchaseDate: row.purchaseDate ?? "",
            purchaseCost: row.purchaseCost ?? "",
            vendorDealerName: row.vendorDealerName ?? "",
            currentSiteLocation: row.currentSiteLocation ?? "",
            assignedOperator: row.assignedOperator ?? "",
            insurance_name: row.insurance_name ?? "",
            insuranceProvider: row.insuranceProvider ?? "",
            policyNumber: row.policyNumber ?? "",
            annualPremium: row.annualPremium ?? "",
            insuranceStatus: row.insuranceStatus,
            insuranceExpiryDate: row.insuranceExpiryDate,
            financingBank: row.financingBank ?? "",
            monthlyEmi: row.monthlyEmi ?? "",
            emiDueCycleDay: row.emiDueCycleDay ?? "",
            serviceInterval: row.serviceInterval ?? "",
            warrantyStatus: row.warrantyStatus ?? "",
            lastServiceDate: row.lastServiceDate ?? "",
            nextServiceDueDate: row.nextServiceDueDate ?? "",
            preferredWorkshop: row.preferredWorkshop ?? "",
            status: row.status,
        });
        setIsDrawerOpen(true);
    }

    function closeDrawer() {
        setIsDrawerOpen(false);
        setEditingFleet(null);
    }

    /* ---------- Save ---------- */
    function handleSave(form: FleetFormValues) {
        if (editingFleet) {
            setFleetData((prev) =>
                prev.map((row) => {
                    if (row.fleetCode !== form.fleetCode) return row;
                    const nextDue =
                        form.nextServiceDueDate ||
                        computeNextServiceDue(form.purchaseDate || todayIso());
                    return { ...row, ...form, nextServiceDueDate: nextDue };
                })
            );
        } else {
            const nextDue =
                form.nextServiceDueDate ||
                computeNextServiceDue(form.purchaseDate || todayIso());

            const newRow: FleetItem = {
                id: `${form.fleetCode}-${Date.now()}`,
                ...form,
                lastServiceDate: form.lastServiceDate || todayIso(),
                nextServiceDueDate: nextDue,
                currentSiteLocation: "",
                ownershipType: form.ownershipType || "Company Owned",
                purchaseDate: form.purchaseDate || todayIso(),
                purchaseCost: form.purchaseCost || "",
                vendorDealerName: form.vendorDealerName || "",
                assignedOperator: "",
                insuranceProvider: form.insuranceProvider || "",
                policyNumber: form.policyNumber || "",
                annualPremium: form.annualPremium || "",
                financingBank: "",
                monthlyEmi: "",
                emiDueCycleDay: "",
                serviceStatus: "ok",
                serviceIntervalHours: 250,
                insurance_name: form.insurance_name || "",
            };
            setFleetData((prev) => [newRow, ...prev]);
        }
        closeDrawer();
    }

    /* ---------- Delete ---------- */
    function handleDelete(row: FleetItem) {
        const confirmed = window.confirm(
            `Delete "${row.vehicleName}" (${row.fleetCode})?\nThis action cannot be undone.`
        );
        if (!confirmed) return;
        setFleetData((prev) => prev.filter((r) => r.id !== row.id));
    }

    /* ---------- Assign vendor ---------- */
    function handleAssignVendor(vehicleId: string, vendorName: string) {
        setFleetData((prev) =>
            prev.map((row) =>
                row.id === vehicleId ? { ...row, assignedVendor: vendorName } : row
            )
        );
    }

    return (
        <>
            {/* Top-level tabs */}
            <div className="mb-6 flex items-center gap-8 border-b border-slate-200">
                <button
                    type="button"
                    onClick={() => setSection("admin")}
                    className={`relative -mb-px whitespace-nowrap pb-3 text-sm font-semibold transition-colors ${
                        section === "admin"
                            ? "text-red-600"
                            : "text-slate-500 hover:text-slate-700"
                    }`}
                >
                    ADMIN
                    {section === "admin" && (
                        <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-red-600" />
                    )}
                </button>

                <button
                    type="button"
                    onClick={() => setSection("vendor")}
                    className={`relative -mb-px whitespace-nowrap pb-3 text-sm font-semibold transition-colors ${
                        section === "vendor"
                            ? "text-red-600"
                            : "text-slate-500 hover:text-slate-700"
                    }`}
                >
                    VENDOR
                    {section === "vendor" && (
                        <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-red-600" />
                    )}
                </button>
            </div>

            {/* Admin section */}
            {section === "admin" && (
                <>
                    {/* Sub-tabs + action button */}
                    <div className="mb-6 flex items-center justify-between gap-3">
                        <div className="inline-flex items-center rounded-xl bg-slate-100 p-1">
                            <button
                                type="button"
                                onClick={() => setAdminTab("fleet-manage")}
                                className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                                    adminTab === "fleet-manage"
                                        ? "bg-white text-red-600 shadow-sm"
                                        : "text-slate-500 hover:text-slate-700"
                                }`}
                            >
                                FLEET MANAGE
                            </button>

                            <button
                                type="button"
                                onClick={() => setAdminTab("fleet-requisition")}
                                className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                                    adminTab === "fleet-requisition"
                                        ? "bg-white text-red-600 shadow-sm"
                                        : "text-slate-500 hover:text-slate-700"
                                }`}
                            >
                                FLEET REQUISITION
                            </button>
                        </div>

                        {/* Add button — only on fleet-manage */}
                        {adminTab === "fleet-manage" && (
                            <Button onClick={openAdd}>
                                <PlusIcon size={16} /> Add New Fleet
                            </Button>
                        )}
                    </div>

                    {adminTab === "fleet-manage" && (
                        <FleetList
                            rows={fleetData}
                            onDelete={handleDelete}
                            onEdit={openEdit}
                            onAssignVendor={handleAssignVendor}
                        />
                    )}
                    {adminTab === "fleet-requisition" && <FleetRequisition />}
                </>
            )}

            {section === "vendor" && <VendorFleet />}

            {/* Add / Edit drawer */}
            <AddNewFleet
                isOpen={isDrawerOpen}
                onClose={closeDrawer}
                onSave={handleSave}
                editingFleet={editingFleet}
            />
        </>
    );
}