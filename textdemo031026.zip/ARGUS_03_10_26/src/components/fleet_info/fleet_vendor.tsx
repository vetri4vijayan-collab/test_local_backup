import { useState } from "react";
import {
    KeyIcon,
    CheckCircleIcon,
    PaperPlaneTiltIcon,
    ClockIcon,
} from "@phosphor-icons/react";

import Button from "../../components/Button";
import DataTable, { DataTableColumn } from "../../components/DataTable";

import { VendorVehicle, Trip, VehicleStatus } from "../../types/trip";
import { initialVendorFleet } from "../../data/fleet_vendor_data";
import PickVehicleModal from "../../offcanvas/fleet/starttip";
import EndTripModal from "../../offcanvas/fleet/endtrip";
import RequestVehicleModal from "../../offcanvas/fleet/requestfleet";


/* =========================================================
   STATUS BADGE
========================================================= */
function StatusBadge({ status }: { status: VehicleStatus }) {
    const styles: Record<
        VehicleStatus,
        { cls: string; dot: string; label: string }
    > = {
        Available: {
            cls: "bg-green-100 text-green-800 ring-green-600/20",
            dot: "bg-green-500",
            label: "Available",
        },
        Requested: {
            cls: "bg-amber-100 text-amber-800 ring-amber-600/20",
            dot: "bg-amber-500",
            label: "Requested",
        },
        Approved: {
            cls: "bg-blue-100 text-blue-800 ring-blue-600/20",
            dot: "bg-blue-500",
            label: "Approved",
        },
        Picked: {
            cls: "bg-indigo-100 text-indigo-800 ring-indigo-600/20",
            dot: "bg-indigo-500",
            label: "Picked",
        },
        Returned: {
            cls: "bg-purple-100 text-purple-800 ring-purple-600/20",
            dot: "bg-purple-500",
            label: "Returned",
        },
        Completed: {
            cls: "bg-green-100 text-green-800 ring-green-600/20",
            dot: "bg-green-500",
            label: "Completed",
        },
        Rejected: {
            cls: "bg-red-100 text-red-800 ring-red-600/20",
            dot: "bg-red-500",
            label: "Rejected",
        },
    };

    const s = styles[status] ?? styles.Available;

    return (
        <span
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${s.cls}`}
        >
            <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
            {s.label}
        </span>
    );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */
export default function VendorFleet() {
    const [fleet, setFleet] = useState<VendorVehicle[]>(initialVendorFleet);

    const [requestVehicle, setRequestVehicle] = useState<VendorVehicle | null>(
        null
    );
    const [pickVehicle, setPickVehicle] = useState<VendorVehicle | null>(null);
    const [endVehicle, setEndVehicle] = useState<VendorVehicle | null>(null);

    /* =========================================================
       HANDLERS — one per status transition
    ========================================================= */

    /* Available → Requested */
    function handleRequest(trip: Trip) {
        setFleet((prev) =>
            prev.map((v) =>
                v.id === trip.vehicleId
                    ? { ...v, status: "Requested", activeTrip: trip }
                    : v
            )
        );
        setRequestVehicle(null);
    }

    /* Approved → Picked */
    function handlePick(trip: Trip) {
        setFleet((prev) =>
            prev.map((v) =>
                v.id === trip.vehicleId
                    ? { ...v, status: "Picked", activeTrip: trip }
                    : v
            )
        );
        setPickVehicle(null);
    }

    /* Picked → Returned */
    function handleEndTrip(updatedTrip: Trip) {
        setFleet((prev) =>
            prev.map((v) =>
                v.id === updatedTrip.vehicleId
                    ? { ...v, status: "Returned", activeTrip: updatedTrip }
                    : v
            )
        );
        setEndVehicle(null);
    }

    /* =========================================================
       TABLE COLUMNS
    ========================================================= */
    const columns: DataTableColumn<VendorVehicle>[] = [
        {
            key: "fleetCode",
            label: "Fleet Code",
            sortable: true,
            render: (r) => (
                <span className="text-xs font-bold text-slate-600">
                    {r.fleetCode}
                </span>
            ),
        },
        {
            key: "vehicleName",
            label: "Vehicle Name",
            sortable: true,
            render: (r) => (
                <div>
                    <p className="text-xs font-semibold text-slate-900">
                        {r.vehicleName}
                    </p>
                    <p className="text-[10px] text-slate-400">{r.category}</p>
                </div>
            ),
        },
        {
            key: "registrationNo",
            label: "Reg No",
            sortable: true,
            render: (r) => (
                <span className="font-mono text-xs text-slate-700">
                    {r.registrationNo}
                </span>
            ),
        },
        {
            key: "status",
            label: "Status",
            sortable: true,
            align: "center",
            render: (r) => (
                <div className="flex justify-center">
                    <StatusBadge status={r.status} />
                </div>
            ),
        },
        {
            key: "action",
            label: "Action",
            align: "center",
            render: (row) => {
                /* ---------- Available → Request Vehicle ---------- */
                if (row.status === "Available") {
                    return (
                        <Button
                            onClick={() => setRequestVehicle(row)}
                            className="!h-8 !bg-amber-600 !py-0 text-xs hover:!bg-amber-700"
                        >
                            <PaperPlaneTiltIcon size={14} weight="fill" />
                            Request Vehicle
                        </Button>
                    );
                }

                /* ---------- Requested → waiting for admin ---------- */
                if (row.status === "Requested") {
                    return (
                        <div className="flex justify-center">
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-[10px] font-semibold text-amber-700">
                                <ClockIcon size={12} weight="bold" />
                                Awaiting admin approval
                            </span>
                        </div>
                    );
                }

                /* ---------- Approved → Pick Vehicle ---------- */
                if (row.status === "Approved") {
                    return (
                        <Button
                            onClick={() => setPickVehicle(row)}
                            className="!h-8 !py-0 text-xs"
                        >
                            <KeyIcon size={14} weight="fill" />
                            Pick Vehicle
                        </Button>
                    );
                }

                /* ---------- Picked → End Trip ---------- */
                if (row.status === "Picked") {
                    return (
                        <div className="flex flex-col items-center gap-1">
                            <div className="rounded-md bg-indigo-50 px-2 py-1 text-[10px] font-medium text-indigo-700">
                                Picked:{" "}
                                {row.activeTrip?.pickupTime &&
                                    new Date(
                                        row.activeTrip.pickupTime
                                    ).toLocaleTimeString([], {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                    })}{" "}
                                | {row.activeTrip?.startKm} km
                            </div>
                            <Button
                                variant="outline"
                                onClick={() => setEndVehicle(row)}
                                className="!h-8 !py-0 text-xs !text-green-700 hover:!bg-green-50"
                            >
                                <CheckCircleIcon size={14} weight="fill" />
                                End Trip
                            </Button>
                        </div>
                    );
                }

                /* ---------- Returned → waiting for admin ---------- */
                if (row.status === "Returned") {
                    return (
                        <div className="flex justify-center">
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-purple-50 px-3 py-1 text-[10px] font-semibold text-purple-700">
                                <ClockIcon size={12} weight="bold" />
                                Awaiting admin review
                            </span>
                        </div>
                    );
                }

                /* ---------- Completed / Rejected ---------- */
                return <span className="text-[11px] text-slate-400">—</span>;
            },
        },
    ];

    /* =========================================================
       RENDER
    ========================================================= */
    return (
        <>
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        My Assigned Fleet
                    </h1>
                    <p className="text-xs text-slate-500">
                        Manage your assigned vehicles and duty logs
                    </p>
                </div>
            </div>

            {/* Table */}
            <DataTable
                columns={columns}
                data={fleet}
                rowKey={(r) => r.id}
                emptyMessage="No vehicles assigned to you yet."
            />

            {/* Modals — guarded so `vehicle` is never null when passed in */}
            {requestVehicle && (
                <RequestVehicleModal
                    isOpen={true}
                    vehicle={requestVehicle}
                    onClose={() => setRequestVehicle(null)}
                    onRequest={handleRequest}
                />
            )}

            {pickVehicle && (
                <PickVehicleModal
                    isOpen={true}
                    vehicle={pickVehicle}
                    onClose={() => setPickVehicle(null)}
                    onPick={handlePick}
                />
            )}

            {endVehicle && (
                <EndTripModal
                    isOpen={true}
                    vehicle={endVehicle}
                    onClose={() => setEndVehicle(null)}
                    onComplete={handleEndTrip}
                />
            )}
        </>
    );
}