import {
  InputHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";

interface FieldProps {
  label: string;
  type?: "text" | "email" | "number" | "password" | "tel" | "textarea" | "date";
  rows?: number;

  value?: string;
  placeholder?: string;
  onChange?: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
}

export default function Field({
  label,
  type = "text",
  rows = 4,
  value,
  placeholder,
  onChange,
}: FieldProps) {
  const className =
    "w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20";

  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">
        {label}
      </span>

      {type === "textarea" ? (
        <textarea
          value={value}
          placeholder={placeholder}
          rows={rows}
          onChange={onChange}
          className={className}
        />
      ) : (
        <input
          type={type}
          value={value}
          placeholder={placeholder}
          onChange={onChange}
          className={className}
        />
      )}
    </label>
  );
}
