-- WhatsApp Management v2 add-on for the supplied ERP MVC application.
-- Default prefix is za_. For a sister ERP, set WHATSAPP_TABLE_PREFIX and change za_ here before applying.
-- This file only creates new tables; it does not alter or drop existing ERP tables.
-- MySQL 5.7+/MariaDB compatible schema. Test against the exact production engine first.

CREATE TABLE IF NOT EXISTS `za_whatsapp_automation_settings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `provider` VARCHAR(40) NOT NULL DEFAULT 'meta_cloud_api',
  `waba_id` VARCHAR(100) NOT NULL DEFAULT '',
  `phone_number_id` VARCHAR(100) NULL DEFAULT NULL,
  `graph_api_version` VARCHAR(20) NOT NULL DEFAULT 'v26.0',
  `access_token_encrypted` LONGTEXT NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `kill_switch` TINYINT(1) NOT NULL DEFAULT 0,
  `min_send_interval_seconds` SMALLINT UNSIGNED NOT NULL DEFAULT 10,
  `next_send_at` DATETIME NULL,
  `last_tested_at` DATETIME NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_settings_branch` (`branch_id`),
  UNIQUE KEY `uq_wa_phone_number_id` (`phone_number_id`),
  KEY `idx_wa_settings_enabled` (`is_enabled`,`kill_switch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_template_registry` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `waba_id` VARCHAR(100) NOT NULL,
  `meta_template_id` VARCHAR(100) NULL,
  `template_key` CHAR(40) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `language` VARCHAR(20) NOT NULL,
  `category` VARCHAR(40) NOT NULL DEFAULT 'UNKNOWN',
  `approval_status` VARCHAR(40) NOT NULL DEFAULT 'UNKNOWN',
  `components_json` LONGTEXT NULL,
  `raw_json` LONGTEXT NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `last_synced_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_template` (`branch_id`,`waba_id`,`template_key`),
  KEY `idx_wa_template_status` (`branch_id`,`approval_status`,`is_enabled`),
  KEY `idx_wa_template_name_language` (`branch_id`,`name`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_workflow_rules` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `event_key` VARCHAR(100) NOT NULL,
  `template_name` VARCHAR(200) NOT NULL,
  `language` VARCHAR(20) NOT NULL,
  `parameter_map_json` LONGTEXT NULL,
  `notes` VARCHAR(1000) NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_workflow_event` (`branch_id`,`event_key`),
  KEY `idx_wa_workflow_enabled` (`branch_id`,`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_consents` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `phone_e164` VARCHAR(20) NOT NULL,
  `category` VARCHAR(30) NOT NULL DEFAULT 'all',
  `consent_status` VARCHAR(20) NOT NULL DEFAULT 'opted_out',
  `source` VARCHAR(100) NOT NULL,
  `evidence_ref` VARCHAR(1000) NOT NULL,
  `opted_in_at` DATETIME NULL,
  `opted_out_at` DATETIME NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_consent` (`branch_id`,`phone_e164`,`category`),
  KEY `idx_wa_consent_check` (`branch_id`,`phone_e164`,`consent_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `phone_e164` VARCHAR(20) NOT NULL,
  `last_inbound_at` DATETIME NULL,
  `last_inbound_meta_message_id` VARCHAR(160) NULL,
  `last_inbound_text` VARCHAR(500) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_session_phone` (`branch_id`,`phone_e164`),
  KEY `idx_wa_session_last_inbound` (`last_inbound_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_campaigns` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `campaign_uuid` CHAR(36) NOT NULL,
  `branch_id` BIGINT NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `template_name` VARCHAR(200) NOT NULL,
  `language` VARCHAR(20) NOT NULL,
  `state` VARCHAR(30) NOT NULL DEFAULT 'draft',
  `total_recipients` INT UNSIGNED NOT NULL DEFAULT 0,
  `queued_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `blocked_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_campaign_uuid` (`campaign_uuid`),
  KEY `idx_wa_campaign_branch_date` (`branch_id`,`created_at`),
  KEY `idx_wa_campaign_state` (`branch_id`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_outbox` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `phone_e164` VARCHAR(20) NOT NULL,
  `message_type` VARCHAR(20) NOT NULL DEFAULT 'template',
  `template_name` VARCHAR(200) NULL,
  `language` VARCHAR(20) NULL,
  `template_category` VARCHAR(40) NULL,
  `components_json` LONGTEXT NULL,
  `text_body` TEXT NULL,
  `payload_json` LONGTEXT NULL,
  `media_path` VARCHAR(500) NULL,
  `media_filename` VARCHAR(255) NULL,
  `media_mime_type` VARCHAR(100) NULL,
  `media_caption` VARCHAR(1024) NULL,
  `uploaded_media_id` VARCHAR(200) NULL,
  `source_type` VARCHAR(80) NOT NULL DEFAULT 'admin_manual',
  `workflow_event_key` VARCHAR(100) NULL,
  `campaign_id` BIGINT UNSIGNED NULL,
  `source_id` BIGINT NULL,
  `created_by` BIGINT NULL,
  `idempotency_key` VARCHAR(191) NOT NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'queued',
  `scheduled_at` DATETIME NULL,
  `meta_message_id` VARCHAR(160) NULL,
  `attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `request_json` LONGTEXT NULL,
  `response_json` LONGTEXT NULL,
  `error_code` VARCHAR(100) NULL,
  `error_message` VARCHAR(2000) NULL,
  `sent_at` DATETIME NULL,
  `delivered_at` DATETIME NULL,
  `read_at` DATETIME NULL,
  `failed_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_outbox_idempotency` (`idempotency_key`),
  UNIQUE KEY `uq_wa_outbox_meta_id` (`meta_message_id`),
  KEY `idx_wa_outbox_dispatch` (`status`,`scheduled_at`),
  KEY `idx_wa_outbox_branch_period` (`branch_id`,`created_at`),
  KEY `idx_wa_outbox_branch_status` (`branch_id`,`status`,`created_at`),
  KEY `idx_wa_outbox_phone` (`branch_id`,`phone_e164`,`created_at`),
  KEY `idx_wa_outbox_campaign` (`campaign_id`),
  KEY `idx_wa_outbox_workflow` (`branch_id`,`workflow_event_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_contacts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `phone_e164` VARCHAR(20) NOT NULL,
  `display_name` VARCHAR(191) NULL,
  `contact_kind` VARCHAR(20) NOT NULL DEFAULT 'unknown',
  `source_id` BIGINT NULL,
  `last_message_at` DATETIME NULL,
  `last_message_preview` VARCHAR(255) NULL,
  `is_archived` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_contact_phone` (`branch_id`,`phone_e164`),
  KEY `idx_wa_contact_list` (`branch_id`,`is_archived`,`last_message_at`),
  KEY `idx_wa_contact_name` (`branch_id`,`display_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_messages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `contact_id` BIGINT UNSIGNED NOT NULL,
  `direction` VARCHAR(10) NOT NULL,
  `message_type` VARCHAR(30) NOT NULL DEFAULT 'text',
  `body` LONGTEXT NULL,
  `media_id` VARCHAR(200) NULL,
  `media_mime_type` VARCHAR(100) NULL,
  `media_filename` VARCHAR(255) NULL,
  `meta_message_id` VARCHAR(160) NULL,
  `outbox_id` BIGINT UNSIGNED NULL,
  `template_name` VARCHAR(200) NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'received',
  `context_json` LONGTEXT NULL,
  `created_by` BIGINT NULL,
  `sent_at` DATETIME NULL,
  `delivered_at` DATETIME NULL,
  `read_at` DATETIME NULL,
  `failed_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `legacy_source_table` VARCHAR(64) NULL,
  `legacy_source_id` BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_message_meta_id` (`meta_message_id`),
  UNIQUE KEY `uq_wa_legacy_source` (`legacy_source_table`,`legacy_source_id`),
  KEY `idx_wa_message_conversation` (`branch_id`,`contact_id`,`id`),
  KEY `idx_wa_message_outbox` (`outbox_id`),
  KEY `idx_wa_message_status` (`branch_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_audiences` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_audience_name` (`branch_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_audience_members` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `audience_id` BIGINT UNSIGNED NOT NULL,
  `phone_e164` VARCHAR(20) NOT NULL,
  `consent_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_audience_member` (`branch_id`,`audience_id`,`phone_e164`),
  KEY `idx_wa_audience_members` (`branch_id`,`audience_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `za_whatsapp_menu_settings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `branch_id` BIGINT NOT NULL,
  `feature_key` VARCHAR(60) NOT NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wa_menu_feature` (`branch_id`,`feature_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Global kill-switch row. Branch 0 is reserved and is not a usable send profile.
INSERT INTO `za_whatsapp_automation_settings`
(`branch_id`,`provider`,`waba_id`,`phone_number_id`,`graph_api_version`,`access_token_encrypted`,`is_enabled`,`kill_switch`,`min_send_interval_seconds`,`created_at`,`updated_at`)
SELECT 0,'meta_cloud_api','',NULL,'v26.0',NULL,0,1,10,NOW(),NOW()
WHERE NOT EXISTS (SELECT 1 FROM `za_whatsapp_automation_settings` WHERE `branch_id`=0);
