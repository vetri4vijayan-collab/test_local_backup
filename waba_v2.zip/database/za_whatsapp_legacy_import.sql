-- LEGACY HISTORY IMPORT: run only after whatsapp_management_upgrade.sql creates za_whatsapp_contacts/messages.
-- Take a full DB backup first. This is additive and preserves original za_wb_* tables.
-- Imported legacy conversations are assigned branch_id=0 (unassigned/global) because the old tables have no branch_id.
-- Review `from` semantics in your old sender before treating direction as authoritative.

-- Idempotently add legacy tracking columns/index if they do not already exist.
SET @db_name = DATABASE();

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `za_whatsapp_messages` ADD COLUMN `legacy_source_table` VARCHAR(64) NULL',
    'SELECT 1')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'za_whatsapp_messages'
    AND COLUMN_NAME = 'legacy_source_table'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `za_whatsapp_messages` ADD COLUMN `legacy_source_id` BIGINT UNSIGNED NULL',
    'SELECT 1')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'za_whatsapp_messages'
    AND COLUMN_NAME = 'legacy_source_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `za_whatsapp_messages` ADD UNIQUE KEY `uq_wa_legacy_source` (`legacy_source_table`,`legacy_source_id`)',
    'SELECT 1')
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'za_whatsapp_messages'
    AND INDEX_NAME = 'uq_wa_legacy_source'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;


-- Preserve old contacts; phone is normalized to E.164-like +digits. No names exist in the old contacts table.
INSERT INTO `za_whatsapp_contacts`
 (`branch_id`,`phone_e164`,`display_name`,`contact_kind`,`source_id`,`last_message_at`,`last_message_preview`,`is_archived`,`created_at`,`updated_at`)
SELECT 0,
       CONCAT('+', REGEXP_REPLACE(TRIM(c.phone), '[^0-9]', '')),
       NULL, 'unknown', c.sno,
       NULL, NULL, IF(c.status <> 0, 1, 0), c.created_at, c.updated_at
FROM `za_wb_contacts` c
WHERE TRIM(COALESCE(c.phone,'')) <> ''
  AND LENGTH(REGEXP_REPLACE(TRIM(c.phone), '[^0-9]', '')) BETWEEN 8 AND 15
ON DUPLICATE KEY UPDATE
 `source_id`=COALESCE(`za_whatsapp_contacts`.`source_id`, VALUES(`source_id`)),
 `updated_at`=GREATEST(COALESCE(`za_whatsapp_contacts`.`updated_at`,'1970-01-01'),COALESCE(VALUES(`updated_at`),'1970-01-01'));

-- Import history by matching old contact_id -> old phone -> new contact. Meta IDs are preserved where present.
-- `from=1` is assumed outbound and `from=0` inbound; validate against the old app's semantics first.
INSERT INTO `za_whatsapp_messages`
 (`branch_id`,`contact_id`,`direction`,`message_type`,`body`,`media_id`,`media_mime_type`,`media_filename`,
  `meta_message_id`,`outbox_id`,`template_name`,`status`,`context_json`,`created_by`,`sent_at`,`delivered_at`,`read_at`,`failed_at`,
  `created_at`,`updated_at`,`legacy_source_table`,`legacy_source_id`)
SELECT 0, nc.id,
       CASE WHEN COALESCE(om.`from`,0)=1 THEN 'outbound' ELSE 'inbound' END,
       CASE
         WHEN LOWER(COALESCE(om.media_type,'')) LIKE '%image%' THEN 'image'
         WHEN LOWER(COALESCE(om.media_type,'')) LIKE '%video%' THEN 'video'
         WHEN LOWER(COALESCE(om.media_type,'')) LIKE '%audio%' THEN 'audio'
         WHEN LOWER(COALESCE(om.media_type,'')) LIKE '%document%' OR LOWER(COALESCE(om.mime_type,'')) LIKE '%pdf%' THEN 'document'
         WHEN LOWER(COALESCE(om.type,'')) LIKE '%reaction%' OR COALESCE(om.reaction_emoji,'') <> '' THEN 'reaction'
         WHEN COALESCE(om.location,'') <> '' THEN 'location'
         ELSE COALESCE(NULLIF(LOWER(om.type),''),'text')
       END,
       COALESCE(NULLIF(om.media_caption,''), om.message, om.location),
       NULL, NULLIF(om.mime_type,''), NULL,
       CASE
         WHEN NULLIF(TRIM(om.wama_id),'') IS NOT NULL
          AND NOT EXISTS (
            SELECT 1
            FROM `za_whatsapp_messages` existing_meta
            WHERE existing_meta.meta_message_id COLLATE utf8mb4_unicode_ci =
                  (om.wama_id COLLATE utf8mb4_unicode_ci)
          )
          AND NOT EXISTS (
            SELECT 1
            FROM `za_wb_messages` earlier
            WHERE earlier.sno < om.sno
              AND NULLIF(TRIM(earlier.wama_id),'') IS NOT NULL
              AND earlier.wama_id COLLATE utf8mb4_unicode_ci =
                  (om.wama_id COLLATE utf8mb4_unicode_ci)
          )
         THEN om.wama_id
         ELSE NULL
       END, NULL, NULL,
       CASE
         WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%read%' THEN 'read'
         WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%deliver%' THEN 'delivered'
         WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%fail%' THEN 'failed'
         WHEN COALESCE(om.`from`,0)=1 THEN 'sent'
         ELSE 'received'
       END,
       JSON_OBJECT('legacy_table','za_wb_messages','legacy_id',om.sno,'legacy_reaction_emoji',om.reaction_emoji,
                   'legacy_reaction_status',om.reaction_status,'legacy_location',om.location,'legacy_media_url',om.media_url,
                   'legacy_message_status',om.message_status,'legacy_contact_id',om.contact_id),
       NULLIF(om.created_by,0),
       CASE WHEN COALESCE(om.`from`,0)=1 THEN om.message_date_time ELSE NULL END,
       CASE WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%deliver%' OR LOWER(COALESCE(om.message_status,'')) LIKE '%read%' THEN om.message_date_time ELSE NULL END,
       CASE WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%read%' THEN om.message_date_time ELSE NULL END,
       CASE WHEN LOWER(COALESCE(om.message_status,'')) LIKE '%fail%' THEN om.message_date_time ELSE NULL END,
       om.created_at, om.updated_at, 'za_wb_messages', om.sno
FROM `za_wb_messages` om
JOIN `za_wb_contacts` oc ON oc.sno=om.contact_id
JOIN `za_whatsapp_contacts` nc ON nc.branch_id=0
  AND nc.phone_e164 COLLATE utf8mb4_unicode_ci =
      (CONCAT('+', REGEXP_REPLACE(TRIM(oc.phone), '[^0-9]', '')) COLLATE utf8mb4_unicode_ci)
LEFT JOIN `za_whatsapp_messages` already
  ON already.legacy_source_table COLLATE utf8mb4_unicode_ci = ('za_wb_messages' COLLATE utf8mb4_unicode_ci)
 AND already.legacy_source_id=om.sno
WHERE already.id IS NULL;

-- Refresh last-message previews from the imported history.
UPDATE `za_whatsapp_contacts` c
JOIN (
 SELECT m.contact_id, MAX(m.created_at) AS last_at,
        SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(m.body,'') ORDER BY m.created_at DESC SEPARATOR '\n'), '\n', 1) AS preview
 FROM `za_whatsapp_messages` m WHERE m.legacy_source_table COLLATE utf8mb4_unicode_ci = ('za_wb_messages' COLLATE utf8mb4_unicode_ci)
 GROUP BY m.contact_id
) x ON x.contact_id=c.id
SET c.last_message_at=x.last_at, c.last_message_preview=LEFT(x.preview,255)
WHERE c.branch_id=0;

-- Verification queries; review counts and sample rows before enabling agents.
SELECT 'legacy_contacts' AS metric, COUNT(*) AS total FROM `za_wb_contacts`
UNION ALL SELECT 'new_imported_contacts', COUNT(*) FROM `za_whatsapp_contacts` WHERE branch_id=0 AND source_id IS NOT NULL;
SELECT 'legacy_messages' AS metric, COUNT(*) AS total FROM `za_wb_messages`
UNION ALL SELECT 'new_imported_messages', COUNT(*) FROM `za_whatsapp_messages` WHERE legacy_source_table='za_wb_messages';
