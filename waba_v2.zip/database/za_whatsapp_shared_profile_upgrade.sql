-- EAPL shared-WhatsApp profile + global history migration for MariaDB 10.4 / MySQL 8.
-- BACK UP THE DATABASE AND RUN IN STAGING FIRST. This script is intentionally non-destructive to source za_wb_* tables.
-- It standardizes shared WhatsApp management tables at branch_id=0. Lead/Customer UI lists still query za_lead/za_customer with branch_id filters.
-- Run after whatsapp_management_upgrade.sql. It can run before or after za_whatsapp_legacy_import.sql; the import itself should only run after the schema exists.

SET @db_name = DATABASE();

-- 1) Add Cloud API media payload columns used by the chat attachment worker (idempotent on repeated runs).
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `payload_json` LONGTEXT NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='payload_json'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `media_path` VARCHAR(500) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='media_path'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `media_filename` VARCHAR(255) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='media_filename'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `media_mime_type` VARCHAR(100) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='media_mime_type'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `media_caption` VARCHAR(1024) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='media_caption'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_outbox` ADD COLUMN `uploaded_media_id` VARCHAR(200) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_outbox' AND COLUMN_NAME='uploaded_media_id'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_messages` ADD COLUMN `legacy_source_table` VARCHAR(64) NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_messages' AND COLUMN_NAME='legacy_source_table'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_messages` ADD COLUMN `legacy_source_id` BIGINT UNSIGNED NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_messages' AND COLUMN_NAME='legacy_source_id'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)=0,'ALTER TABLE `za_whatsapp_messages` ADD UNIQUE KEY `uq_wa_legacy_source` (`legacy_source_table`,`legacy_source_id`)','SELECT 1') FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_messages' AND INDEX_NAME='uq_wa_legacy_source'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) phone_number_id must allow NULL for retired branch profiles; unique indexes allow multiple NULL values.
SET @sql = (SELECT IF(IS_NULLABLE='NO','ALTER TABLE `za_whatsapp_automation_settings` MODIFY `phone_number_id` VARCHAR(100) NULL DEFAULT NULL','SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db_name AND TABLE_NAME='za_whatsapp_automation_settings' AND COLUMN_NAME='phone_number_id'); PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Snapshot the most suitable existing configured profile before retiring branch rows.
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_global_profile`;
CREATE TEMPORARY TABLE `tmp_za_wa_global_profile` AS
SELECT `provider`,`waba_id`,`phone_number_id`,`graph_api_version`,`access_token_encrypted`,`is_enabled`,`kill_switch`,`min_send_interval_seconds`,`next_send_at`,`last_tested_at`,`created_by`,`updated_by`,`created_at`,`updated_at`
FROM `za_whatsapp_automation_settings`
WHERE COALESCE(`phone_number_id`,'')<>'' AND COALESCE(`waba_id`,'')<>'' AND COALESCE(`access_token_encrypted`,'')<>''
ORDER BY (`branch_id`=0) DESC, `is_enabled` DESC, `updated_at` DESC, `id` DESC
LIMIT 1;

-- Disable and retire all non-global API profiles (the selected encrypted profile is preserved in the temporary snapshot).
UPDATE `za_whatsapp_automation_settings`
SET `phone_number_id`=NULL, `access_token_encrypted`=NULL, `is_enabled`=0, `kill_switch`=0, `next_send_at`=NULL, `updated_at`=NOW()
WHERE `branch_id`<>0;

-- Branch 0 is the single common profile. If no previous configured profile existed, keep sending disabled until admin setup.
INSERT INTO `za_whatsapp_automation_settings`
 (`branch_id`,`provider`,`waba_id`,`phone_number_id`,`graph_api_version`,`access_token_encrypted`,`is_enabled`,`kill_switch`,`min_send_interval_seconds`,`next_send_at`,`last_tested_at`,`created_by`,`updated_by`,`created_at`,`updated_at`)
SELECT 0,`provider`,`waba_id`,`phone_number_id`,`graph_api_version`,`access_token_encrypted`,`is_enabled`,1,`min_send_interval_seconds`,`next_send_at`,`last_tested_at`,`created_by`,`updated_by`,COALESCE(`created_at`,NOW()),NOW()
FROM `tmp_za_wa_global_profile`
ON DUPLICATE KEY UPDATE
 `provider`=VALUES(`provider`), `waba_id`=VALUES(`waba_id`), `phone_number_id`=VALUES(`phone_number_id`),
 `graph_api_version`=VALUES(`graph_api_version`), `access_token_encrypted`=VALUES(`access_token_encrypted`),
 `is_enabled`=0, `kill_switch`=1, `min_send_interval_seconds`=VALUES(`min_send_interval_seconds`),
 `next_send_at`=VALUES(`next_send_at`), `last_tested_at`=VALUES(`last_tested_at`), `updated_at`=NOW();

-- 3) Merge the newest branch template variants into the global registry. Newly migrated templates remain disabled for admin review.
INSERT IGNORE INTO `za_whatsapp_template_registry`
 (`branch_id`,`waba_id`,`meta_template_id`,`template_key`,`name`,`language`,`category`,`approval_status`,`components_json`,`raw_json`,`is_enabled`,`last_synced_at`,`created_at`,`updated_at`)
SELECT 0,t.`waba_id`,t.`meta_template_id`,t.`template_key`,t.`name`,t.`language`,t.`category`,t.`approval_status`,t.`components_json`,t.`raw_json`,0,t.`last_synced_at`,t.`created_at`,NOW()
FROM `za_whatsapp_template_registry` t
WHERE t.`branch_id`<>0
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_template_registry` g WHERE g.`branch_id`=0 AND g.`waba_id`=t.`waba_id` AND g.`template_key`=t.`template_key`)
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_template_registry` newer WHERE newer.`branch_id`<>0 AND newer.`waba_id`=t.`waba_id` AND newer.`template_key`=t.`template_key` AND (COALESCE(newer.`last_synced_at`,'1970-01-01')>COALESCE(t.`last_synced_at`,'1970-01-01') OR (newer.`last_synced_at`=t.`last_synced_at` AND newer.`id`>t.`id`)));
UPDATE `za_whatsapp_template_registry` SET `is_enabled`=0, `updated_at`=NOW();

-- 4) Merge newest workflow mapping per event. Do not auto-enable migrated rules; review before production.
INSERT IGNORE INTO `za_whatsapp_workflow_rules`
 (`branch_id`,`event_key`,`template_name`,`language`,`parameter_map_json`,`notes`,`is_enabled`,`created_by`,`updated_by`,`created_at`,`updated_at`)
SELECT 0,t.`event_key`,t.`template_name`,t.`language`,t.`parameter_map_json`,t.`notes`,0,t.`created_by`,t.`updated_by`,t.`created_at`,NOW()
FROM `za_whatsapp_workflow_rules` t
WHERE t.`branch_id`<>0
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_workflow_rules` g WHERE g.`branch_id`=0 AND g.`event_key`=t.`event_key`)
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_workflow_rules` newer WHERE newer.`branch_id`<>0 AND newer.`event_key`=t.`event_key` AND (COALESCE(newer.`updated_at`,'1970-01-01')>COALESCE(t.`updated_at`,'1970-01-01') OR (newer.`updated_at`=t.`updated_at` AND newer.`id`>t.`id`)));
UPDATE `za_whatsapp_workflow_rules` SET `is_enabled`=0, `updated_at`=NOW();

-- 5) Merge newest consent rows per phone/category globally. Existing global consent takes precedence; opt-out state is retained.
INSERT IGNORE INTO `za_whatsapp_consents`
 (`branch_id`,`phone_e164`,`category`,`consent_status`,`source`,`evidence_ref`,`opted_in_at`,`opted_out_at`,`created_by`,`updated_by`,`created_at`,`updated_at`)
SELECT 0,t.`phone_e164`,t.`category`,t.`consent_status`,t.`source`,t.`evidence_ref`,t.`opted_in_at`,t.`opted_out_at`,t.`created_by`,t.`updated_by`,t.`created_at`,NOW()
FROM `za_whatsapp_consents` t
WHERE t.`branch_id`<>0
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_consents` g WHERE g.`branch_id`=0 AND g.`phone_e164`=t.`phone_e164` AND g.`category`=t.`category`)
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_consents` newer WHERE newer.`branch_id`<>0 AND newer.`phone_e164`=t.`phone_e164` AND newer.`category`=t.`category` AND (COALESCE(newer.`updated_at`,'1970-01-01')>COALESCE(t.`updated_at`,'1970-01-01') OR (newer.`updated_at`=t.`updated_at` AND newer.`consent_status`='opted_out' AND t.`consent_status`<>'opted_out')));
-- Keep source-branch consent rows for audit; shared send checks use only branch_id=0.

-- 6) Build a canonical global contact row per phone and move old conversation foreign keys before deleting duplicates.
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_contact_canon`;
CREATE TEMPORARY TABLE `tmp_za_wa_contact_canon` AS
SELECT `phone_e164`, COALESCE(MIN(CASE WHEN `branch_id`=0 THEN `id` END),MIN(`id`)) AS `canonical_id`
FROM `za_whatsapp_contacts` GROUP BY `phone_e164`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_contact_map`;
CREATE TEMPORARY TABLE `tmp_za_wa_contact_map` AS
SELECT c.`id` AS `old_id`, x.`canonical_id` FROM `za_whatsapp_contacts` c JOIN `tmp_za_wa_contact_canon` x ON x.`phone_e164`=c.`phone_e164`;
UPDATE `za_whatsapp_messages` m JOIN `tmp_za_wa_contact_map` x ON x.`old_id`=m.`contact_id` SET m.`contact_id`=x.`canonical_id`,m.`branch_id`=0;
DELETE c FROM `za_whatsapp_contacts` c JOIN `tmp_za_wa_contact_map` x ON x.`old_id`=c.`id` WHERE x.`old_id`<>x.`canonical_id`;
UPDATE `za_whatsapp_contacts` SET `branch_id`=0 WHERE `branch_id`<>0;
UPDATE `za_whatsapp_outbox` SET `branch_id`=0 WHERE `branch_id`<>0;
UPDATE `za_whatsapp_campaigns` SET `branch_id`=0 WHERE `branch_id`<>0;

-- 7) Consolidate 24-hour sessions by phone using the newest customer inbound time. The global profile owns all windows.
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_sessions`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_canon`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_map`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_member_canon`;
CREATE TEMPORARY TABLE `tmp_za_wa_sessions` AS
SELECT `phone_e164`, MAX(`last_inbound_at`) AS `last_inbound_at`,
       SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(`last_inbound_meta_message_id`,'') ORDER BY `last_inbound_at` DESC SEPARATOR '\n'),'\n',1) AS `last_inbound_meta_message_id`
FROM `za_whatsapp_sessions` GROUP BY `phone_e164`;
-- Update an existing global session only when the consolidated inbound timestamp is newer.
-- Split UPDATE and INSERT to avoid ambiguous last_inbound_at references in ON DUPLICATE KEY UPDATE.
UPDATE `za_whatsapp_sessions` AS dst
JOIN `tmp_za_wa_sessions` AS src
  ON src.`phone_e164` = dst.`phone_e164`
SET
  dst.`last_inbound_meta_message_id` = CASE
    WHEN src.`last_inbound_at` IS NOT NULL
     AND (dst.`last_inbound_at` IS NULL OR src.`last_inbound_at` > dst.`last_inbound_at`)
      THEN NULLIF(src.`last_inbound_meta_message_id`, '')
    ELSE dst.`last_inbound_meta_message_id`
  END,
  dst.`last_inbound_at` = CASE
    WHEN dst.`last_inbound_at` IS NULL THEN src.`last_inbound_at`
    WHEN src.`last_inbound_at` IS NULL THEN dst.`last_inbound_at`
    ELSE GREATEST(dst.`last_inbound_at`, src.`last_inbound_at`)
  END,
  dst.`updated_at` = NOW()
WHERE dst.`branch_id` = 0;

-- Insert a global session only for a phone that does not already have one.
INSERT INTO `za_whatsapp_sessions`
  (`branch_id`,`phone_e164`,`last_inbound_at`,`last_inbound_meta_message_id`,`created_at`,`updated_at`)
SELECT
  0, src.`phone_e164`, src.`last_inbound_at`,
  NULLIF(src.`last_inbound_meta_message_id`, ''), NOW(), NOW()
FROM `tmp_za_wa_sessions` AS src
LEFT JOIN `za_whatsapp_sessions` AS dst
  ON dst.`branch_id` = 0 AND dst.`phone_e164` = src.`phone_e164`
WHERE dst.`id` IS NULL;

DELETE FROM `za_whatsapp_sessions` WHERE `branch_id` <> 0; -- after the latest inbound window has been copied to branch 0

-- 8) Any history not explicitly tagged legacy still moves global. CRM contact list filtering is performed from za_lead/za_customer.
UPDATE `za_whatsapp_messages` SET `branch_id`=0 WHERE `branch_id`<>0;

-- 9) Consolidate ERP-managed audiences and menu feature switches globally as well.
-- Audience names are unique inside a branch, but different branches can reuse a name. Pick the existing global row if present; otherwise retain the lowest ID.
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_canon`;
CREATE TEMPORARY TABLE `tmp_za_wa_audience_canon` AS
SELECT `name`, COALESCE(MIN(CASE WHEN `branch_id`=0 THEN `id` END), MIN(`id`)) AS `canonical_id`
FROM `za_whatsapp_audiences` GROUP BY `name`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_map`;
CREATE TEMPORARY TABLE `tmp_za_wa_audience_map` AS
SELECT a.`id` AS `old_id`, c.`canonical_id` FROM `za_whatsapp_audiences` a JOIN `tmp_za_wa_audience_canon` c ON c.`name`=a.`name`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_member_canon`;
CREATE TEMPORARY TABLE `tmp_za_wa_audience_member_canon` AS
SELECT MIN(am.`id`) AS `keep_id`
FROM `za_whatsapp_audience_members` am
JOIN `tmp_za_wa_audience_map` m ON m.`old_id`=am.`audience_id`
GROUP BY m.`canonical_id`, am.`phone_e164`;
-- Delete duplicate recipient rows that would violate the global audience/phone unique key after remapping.
DELETE am FROM `za_whatsapp_audience_members` am
JOIN `tmp_za_wa_audience_map` m ON m.`old_id`=am.`audience_id`
LEFT JOIN `tmp_za_wa_audience_member_canon` keep_row ON keep_row.`keep_id`=am.`id`
WHERE keep_row.`keep_id` IS NULL;
UPDATE `za_whatsapp_audience_members` am
JOIN `tmp_za_wa_audience_map` m ON m.`old_id`=am.`audience_id`
SET am.`audience_id`=m.`canonical_id`, am.`branch_id`=0;
-- Move selected rows global, then remove only duplicate audience definitions (membership rows are already remapped).
UPDATE `za_whatsapp_audiences` a JOIN `tmp_za_wa_audience_map` m ON m.`old_id`=a.`id`
SET a.`branch_id`=0, a.`updated_at`=NOW() WHERE a.`id`=m.`canonical_id`;
DELETE a FROM `za_whatsapp_audiences` a JOIN `tmp_za_wa_audience_map` m ON m.`old_id`=a.`id` WHERE m.`old_id`<>m.`canonical_id`;
-- Per-feature menu switches become ERP-global. Preserve an existing global value; otherwise use the most recently updated branch value.
INSERT IGNORE INTO `za_whatsapp_menu_settings` (`branch_id`,`feature_key`,`is_enabled`,`updated_by`,`created_at`,`updated_at`)
SELECT 0,s.`feature_key`,s.`is_enabled`,s.`updated_by`,s.`created_at`,s.`updated_at`
FROM `za_whatsapp_menu_settings` s
WHERE s.`branch_id`<>0
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_menu_settings` g WHERE g.`branch_id`=0 AND g.`feature_key`=s.`feature_key`)
  AND NOT EXISTS (SELECT 1 FROM `za_whatsapp_menu_settings` newer WHERE newer.`branch_id`<>0 AND newer.`feature_key`=s.`feature_key` AND (COALESCE(newer.`updated_at`,'1970-01-01')>COALESCE(s.`updated_at`,'1970-01-01') OR (newer.`updated_at`=s.`updated_at` AND newer.`id`>s.`id`)));
-- Keep source branch switch rows for audit; all reads/writes use branch_id=0.

-- 10) Reports for review; compare global counts to legacy source counts before deleting nothing (nothing is deleted from za_wb_*).
SELECT 'shared_profile' AS metric,COUNT(*) AS total FROM `za_whatsapp_automation_settings` WHERE `branch_id`=0 AND COALESCE(`phone_number_id`,'')<>''
UNION ALL SELECT 'non_global_profiles_remaining',COUNT(*) FROM `za_whatsapp_automation_settings` WHERE `branch_id`<>0 AND COALESCE(`phone_number_id`,'')<>''
UNION ALL SELECT 'non_global_contacts_remaining',COUNT(*) FROM `za_whatsapp_contacts` WHERE `branch_id`<>0
UNION ALL SELECT 'non_global_messages_remaining',COUNT(*) FROM `za_whatsapp_messages` WHERE `branch_id`<>0
UNION ALL SELECT 'global_templates',COUNT(*) FROM `za_whatsapp_template_registry` WHERE `branch_id`=0
UNION ALL SELECT 'global_workflow_rules',COUNT(*) FROM `za_whatsapp_workflow_rules` WHERE `branch_id`=0;

DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_global_profile`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_contact_canon`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_contact_map`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_sessions`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_canon`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_map`;
DROP TEMPORARY TABLE IF EXISTS `tmp_za_wa_audience_member_canon`;
