<div class="wa-page-head"><div><h2>Bulk campaign queue</h2><p>Admin-controlled, paced sends. Every recipient is independently checked for an approved template and recorded opt-in; sending is capped to reduce accidental blasts.</p></div></div>
<div class="wa-grid-2">
  <div class="wa-card">
    <div class="wa-card-title">Create campaign</div>
    <div class="wa-field"><label>Campaign name</label><input id="waCampaignName" placeholder="October academy update"></div>
    <div class="wa-grid-2">
      <div class="wa-field"><label>Approved template</label><select id="waCampaignTemplate" class="wa-search"><option value="">Select template</option></select></div>
      <div class="wa-field"><label>Language</label><select id="waCampaignLanguage" class="wa-search"><option value="en">en</option></select></div>
    </div>
    <div class="wa-field"><label>Saved audience (optional)</label><select id="waCampaignAudience" class="wa-search"><option value="">Manual numbers only</option></select><small>A saved ERP audience is a reusable recipient list, not a native WhatsApp group. Consent is checked separately for every recipient.</small></div>
    <div class="wa-field"><label>Additional recipients (optional; E.164, one per line)</label><textarea id="waCampaignRecipients" placeholder="+919876543210&#10;+919876543211"></textarea><small>Choose a saved audience, enter manual numbers, or use both. Numbers must include their country code. Recipients without documented opt-in will be blocked.</small></div>
    <div class="wa-field"><label>Template components JSON</label><textarea id="waCampaignComponents" spellcheck="false">[]</textarea><small>Use the exact component structure and parameter order for the approved Meta template. The preview here does not replace validation by Meta.</small></div>
    <button id="waCampaignSend" class="wa-btn wa-btn-primary">Validate and queue campaign</button><div id="waCampaignResult" style="margin-top:12px"></div>
  </div>
  <div class="wa-card">
    <div class="wa-card-title">Recent campaigns</div>
    <div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Name</th><th>Template</th><th>State</th><th>Queued</th><th>Blocked</th><th>Created</th></tr></thead><tbody id="waCampaignRows"><tr><td colspan="6" class="wa-empty">Loading campaigns…</td></tr></tbody></table></div>
    <div class="wa-inline-note" style="margin-top:12px">Campaign status describes queue admission, not final delivery. Use Message Logs for sent, delivered, read and failed provider statuses. A blocked recipient should not be re-added until the reason is resolved.</div>
  </div>
</div>
<script>
(function($){
  function loadTemplates(){WA.api('/templates','GET',{}).done(function(r){var ts=((r.data||{}).templates||[]).filter(function(t){return t.approval_status==='APPROVED'&&t.is_enabled;});$('#waCampaignTemplate').html('<option value="">Select template</option>'+ts.map(function(t){return '<option value="'+WA.esc(t.name)+'" data-lang="'+WA.esc(t.language)+'">'+WA.esc(t.name)+' · '+WA.esc(t.language)+'</option>';}).join(''));});}
  function loadAudiences(){WA.api('/audiences','GET',{}).done(function(r){var a=((r.data||{}).audiences||[]);$('#waCampaignAudience').html('<option value="">Manual numbers only</option>'+a.map(function(x){return '<option value="'+Number(x.id)+'">'+WA.esc(x.name)+' · #'+Number(x.id)+'</option>';}).join(''));});}
  function loadCampaigns(){WA.api('/campaigns','GET',{}).done(function(r){var rows=(r.data||{}).campaigns||[];$('#waCampaignRows').html(rows.length?rows.map(function(c){return '<tr><td><strong>'+WA.esc(c.name)+'</strong></td><td>'+WA.esc(c.template_name)+'</td><td><span class="wa-badge '+(c.state==='queued'?'ok':(c.state==='blocked'?'bad':'warn'))+'">'+WA.esc(c.state)+'</span></td><td>'+Number(c.queued_count||0)+'</td><td>'+Number(c.blocked_count||0)+'</td><td>'+WA.esc(c.created_at||'')+'</td></tr>';}).join(''):'<tr><td colspan="6" class="wa-empty">No campaigns have been created.</td></tr>');});}
  $('#waCampaignTemplate').on('change',function(){var lang=$(this).find(':selected').data('lang')||'en';$('#waCampaignLanguage').html('<option value="'+WA.esc(lang)+'">'+WA.esc(lang)+'</option>').val(lang);});
  $('#waCampaignSend').on('click',function(){
    var comp=$.trim($('#waCampaignComponents').val()||'[]'), audience=$('#waCampaignAudience').val(), recipients=$.trim($('#waCampaignRecipients').val());
    try{if(!Array.isArray(JSON.parse(comp)))throw new Error();}catch(e){WA.toast('Components must be a JSON array.',true);return;}
    if(!$('#waCampaignName').val()||!$('#waCampaignTemplate').val()||(!audience&&!recipients)){WA.toast('Campaign name, approved template, and either a saved audience or manual recipients are required.',true);return;}
    if(!window.confirm('Queue this campaign? Each recipient will be checked for an enabled template, opt-in and global pause status.'))return;
    var b=$(this);b.prop('disabled',true).text('Validating & queuing…');
    WA.api('/send/bulk','POST',{name:$('#waCampaignName').val(),template_name:$('#waCampaignTemplate').val(),language:$('#waCampaignLanguage').val(),components:comp,recipients:recipients,audience_id:audience||''})
      .done(function(r){var d=r.data||{};$('#waCampaignResult').html('<div class="wa-inline-note"><strong>Campaign #'+WA.esc(d.campaign_id)+'</strong><br>Total: '+Number(d.total||0)+' · Queued: '+Number(d.queued||0)+' · Blocked: '+Number(d.blocked||0)+'<br>See Message Logs for delivery statuses and block reasons.</div>');WA.toast(r.message||'Campaign processed.');loadCampaigns();})
      .fail(function(x){WA.toast(x.responseJSON&&x.responseJSON.message||'Campaign could not be queued.',true);})
      .always(function(){b.prop('disabled',false).text('Validate and queue campaign');});
  });
  loadTemplates();loadAudiences();loadCampaigns();
})(jQuery);
</script>
