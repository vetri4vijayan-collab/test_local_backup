<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dashboard\Analytics;
use App\Http\Controllers\dashboard\Crm;
use App\Http\Controllers\dashboard\Login;
use App\Http\Controllers\dashboard\Cronjobs;
use App\Http\Controllers\dashboard\CloudCall;
use App\Http\Controllers\dashboard\OtherSourceLead;
use App\Http\Controllers\dashboard\DicountQR;
use App\Http\Controllers\dashboard\CatalogueQR;
use App\Http\Controllers\apps\Email;
use App\Http\Controllers\apps\Chat;
use App\Http\Controllers\apps\Calendar;
use App\Http\Controllers\TableManagerController;
// Customer Analysis
use App\Http\Controllers\report_management\LeadReports;
use App\Http\Controllers\report_management\CustomerReport;
use App\Http\Controllers\report_management\AccountsReport;
use App\Http\Controllers\report_management\PaymentReport;
use App\Http\Controllers\report_management\StudentReport;
use App\Http\Controllers\report_management\BatchReport;
use App\Http\Controllers\report_management\FacultyReport;
use App\Http\Controllers\report_management\OtherReport;
use App\Http\Controllers\report_management\PlacementReport;
use App\Http\Controllers\report_management\PerformanceReport;
use App\Http\Controllers\report_management\FeedbackReport;

//Customer Management

use App\Http\Controllers\customer\PlacedStudent;
use App\Http\Controllers\customer\ManageLongAbsent;

use App\Http\Controllers\WhatsAppManagementController;
use App\Http\Controllers\MetaWhatsAppWebhookController;


use App\Http\Controllers\MenuCountController;         

// Epro

use App\Http\Controllers\project_management\ProjectLead;
use App\Http\Controllers\project_management\ProjectCustomer;
use App\Http\Controllers\project_management\ProjectPayment;
use App\Http\Controllers\project_management\ProjectAppointment;

use App\Http\Controllers\apps\Kanban;
use App\Http\Controllers\apps\EcommerceDashboard;
use App\Http\Controllers\apps\EcommerceProductList;
use App\Http\Controllers\apps\EcommerceProductAdd;
use App\Http\Controllers\apps\EcommerceProductCategory;
use App\Http\Controllers\apps\EcommerceOrderList;
use App\Http\Controllers\apps\EcommerceOrderDetails;
use App\Http\Controllers\apps\EcommerceCustomerAll;
use App\Http\Controllers\apps\EcommerceCustomerDetailsOverview;
use App\Http\Controllers\apps\EcommerceCustomerDetailsSecurity;
use App\Http\Controllers\apps\EcommerceCustomerDetailsBilling;
use App\Http\Controllers\apps\EcommerceCustomerDetailsNotifications;
use App\Http\Controllers\sales\lead_appointment\ManageLeadAppointment;
use App\Http\Controllers\sales\manage_calls\ManageCalls;
use App\Http\Controllers\sales\manage_team\ManageTeam;
use App\Http\Controllers\team_management\team_ftot\TeamFollowingTot;
use App\Http\Controllers\team_management\team_lead\TeamLead;
use App\Http\Controllers\team_management\team_goalset\TeamGoalset;
use App\Http\Controllers\team_management\team_followup\TeamFollowup;
use App\Http\Controllers\team_management\team_appointment\TeamAppointment;
use App\Http\Controllers\team_management\team_call\TeamCall;
use App\Http\Controllers\team_management\team_cloud_call\TeamCloudCall;
use App\Http\Controllers\apps\EcommerceManageReviews;
use App\Http\Controllers\apps\EcommerceReferrals;
use App\Http\Controllers\apps\EcommerceSettingsDetails;
use App\Http\Controllers\apps\EcommerceSettingsPayments;
use App\Http\Controllers\apps\EcommerceSettingsCheckout;
use App\Http\Controllers\apps\EcommerceSettingsShipping;
use App\Http\Controllers\apps\EcommerceSettingsLocations;
use App\Http\Controllers\apps\EcommerceSettingsNotifications;
use App\Http\Controllers\apps\AcademyDashboard;
use App\Http\Controllers\apps\AcademyCourse;
use App\Http\Controllers\apps\AcademyCourseDetails;
use App\Http\Controllers\apps\LogisticsDashboard;
use App\Http\Controllers\apps\LogisticsFleet;
use App\Http\Controllers\apps\InvoiceList;
use App\Http\Controllers\apps\InvoicePreview;
use App\Http\Controllers\apps\InvoicePrint;
use App\Http\Controllers\apps\InvoiceEdit;
use App\Http\Controllers\apps\InvoiceAdd;
use App\Http\Controllers\apps\UserList;
use App\Http\Controllers\apps\UserViewAccount;
use App\Http\Controllers\apps\UserViewSecurity;
use App\Http\Controllers\apps\UserViewBilling;
use App\Http\Controllers\apps\UserViewNotifications;
use App\Http\Controllers\apps\UserViewConnections;
use App\Http\Controllers\apps\AccessRoles;
use App\Http\Controllers\apps\AccessPermission;
use App\Http\Controllers\authentications\LoginBasic;
use App\Http\Controllers\authentications\LoginCover;
use App\Http\Controllers\authentications\RegisterBasic;
use App\Http\Controllers\authentications\RegisterCover;
use App\Http\Controllers\authentications\RegisterMultiSteps;
use App\Http\Controllers\authentications\VerifyEmailBasic;
use App\Http\Controllers\authentications\VerifyEmailCover;
use App\Http\Controllers\authentications\ResetPasswordBasic;
use App\Http\Controllers\authentications\ResetPasswordCover;
use App\Http\Controllers\authentications\ForgotPasswordBasic;
use App\Http\Controllers\authentications\ForgotPasswordCover;
use App\Http\Controllers\authentications\TwoStepsBasic;
use App\Http\Controllers\authentications\TwoStepsCover;
use App\Http\Controllers\icons\MdiIcons;
use App\Http\Controllers\tables\Basic as TablesBasic;
use App\Http\Controllers\tables\DatatableBasic;
use App\Http\Controllers\tables\DatatableAdvanced;
use App\Http\Controllers\tables\DatatableExtensions;
use App\Http\Controllers\settings\placements\PlacementReasons;

use App\Http\Controllers\task_management\TaskManagement;

use App\Http\Controllers\task_management\MyTask;
use App\Http\Controllers\task_management\TeamTask;

use App\Http\Controllers\support_management\ManageTrainingDocument;
use App\Http\Controllers\support_management\TrainingDocument;
use App\Http\Controllers\support_management\InteractiveAudio;

use App\Http\Controllers\settings\common\ModulesList;
use App\Http\Controllers\settings\bug_fixes\BugReasons;
use App\Http\Controllers\bugs_list\BugsList;


use App\Http\Controllers\branch_management\BranchAudit;
use App\Http\Controllers\branch_management\WhatsappTemplateLog;
use App\Http\Controllers\branch_management\BranchMetrics;
use App\Http\Controllers\branch_management\BranchCampaign;
use App\Http\Controllers\branch_management\BranchHoliday;
use App\Http\Controllers\qr_promotion\QrPromotion;
use App\Http\Controllers\qr_catalogue\QrCatalogue;
use App\Http\Controllers\branch_management\QrCoupon;
use App\Http\Controllers\branch_management\ManageTraining;
use App\Http\Controllers\branch_management\CronjobMonitor;
use App\Http\Controllers\branch_management\MaintenanceMode;
use App\Http\Controllers\branch_management\UserLog;
use App\Http\Controllers\branch_management\MaintenancePage;
use App\Http\Controllers\branch_management\CallLog;
use App\Http\Controllers\accounts_management\ManageDailyAccounts;
use App\Http\Controllers\accounts_management\ManageProfitLoss;
use App\Http\Controllers\accounts_management\ManageTrialBalance;


use App\Http\Controllers\courses\ManageCourses;
use App\Http\Controllers\courses\ManageCoursesMaterial;
use App\Http\Controllers\courses\ManageBatch;
use App\Http\Controllers\courses\ManageExtensionBatch;
// Exam management
use App\Http\Controllers\exam\ManageExam;
use App\Http\Controllers\exam\ManageExamResult;
use App\Http\Controllers\exam\ManageQuestionBank;

use App\Http\Controllers\production\ManageCosting;
use App\Http\Controllers\production\TeamCosting;
use App\Http\Controllers\production\StaffBoard;
use App\Http\Controllers\production\BatchValidator;
use App\Http\Controllers\sales\lead\Lead;
use App\Http\Controllers\sales\lead\ManagePotentialLead;
use App\Http\Controllers\sales\lead\DailyCallLead;
use App\Http\Controllers\sales\lead\HotLead;
use App\Http\Controllers\settings\sales\PotentialReason;
use App\Http\Controllers\sales\lead_calendar\LeadCalendar;
use App\Http\Controllers\sales\manage_walkin\ManageWalkin;
use App\Http\Controllers\customer\ManageCustomer;
use App\Http\Controllers\customer\ManageReview;
use App\Http\Controllers\customer\ManageStudent;
use App\Http\Controllers\customer\ManageCustomerDrop;
use App\Http\Controllers\customer\ManageCustomerRefund;
use App\Http\Controllers\hr_management\Staff;
use App\Http\Controllers\user_management\ManageUsers;
use App\Http\Controllers\user_management\UserManage;
use App\Http\Controllers\user_management\UserRole;
use App\Http\Controllers\user_management\UserRoleTask;
use App\Http\Controllers\report_management\ManageReports;
use App\Http\Controllers\hr_management\JobRequest;
use App\Http\Controllers\settings\hrm\SpecialRequirement;


use App\Http\Controllers\errors\ErrosController;
use App\Http\Controllers\settings\marketing\Variable;
use App\Http\Controllers\settings\marketing\MarketingKitCategory;
use App\Http\Controllers\settings\marketing\MarketingKitDelivery;
use App\Http\Controllers\settings\marketing\MarketingKitSubCategory;

use App\Http\Controllers\settings\GeneralSettings;
use App\Http\Controllers\settings\course\Brand;
use App\Http\Controllers\settings\course\Group;
use App\Http\Controllers\settings\course\JobRoll;
use App\Http\Controllers\settings\course\PreSkillSet;
use App\Http\Controllers\settings\course\CourseCategory;
use App\Http\Controllers\settings\course\CourseSubCategory;
use App\Http\Controllers\settings\common\BatchChecklist;
use App\Http\Controllers\settings\common\CloudCallApiSetup;
use App\Http\Controllers\settings\common\HoldReason;
use App\Http\Controllers\settings\course\CourseType;
use App\Http\Controllers\settings\course\SummaryReason;
use App\Http\Controllers\settings\sales\LeadSource;
use App\Http\Controllers\settings\sales\LeadType;
use App\Http\Controllers\settings\sales\LeadPotentialType;
use App\Http\Controllers\settings\sales\LeadStatus;
use App\Http\Controllers\settings\sales\CustomerType;
use App\Http\Controllers\settings\sales\CustomerTypeOption;
use App\Http\Controllers\settings\sales\PaymentMode;
use App\Http\Controllers\settings\sales\PaymentModeOption;
use App\Http\Controllers\settings\sales\CurrencyFormat;
use App\Http\Controllers\settings\sales\ProgressLevel;
use App\Http\Controllers\settings\course\CourseAction;
use App\Http\Controllers\settings\course\CourseActionType;
use App\Http\Controllers\settings\course\StudentFeedback;
use App\Http\Controllers\settings\batch\SlotTypes;
use App\Http\Controllers\settings\batch\ExtensionCancelReason;
use App\Http\Controllers\settings\batch\Slot;
use App\Http\Controllers\settings\batch\SlotOld;
use App\Http\Controllers\settings\batch\Facility;
use App\Http\Controllers\settings\batch\ClassRoom;
use App\Http\Controllers\settings\batch\FeedbackStudentQuestion;
use App\Http\Controllers\settings\hrm\JobTime;
use App\Http\Controllers\settings\hrm\Credential;
use App\Http\Controllers\settings\hrm\JobPosition;
use App\Http\Controllers\settings\hrm\KnowledgeTag;
use App\Http\Controllers\settings\hrm\KnowledgeLevel;
use App\Http\Controllers\settings\hrm\ShiftTime;
use App\Http\Controllers\settings\hrm\Attachment;
use App\Http\Controllers\settings\sales\LeadQuestion;
use App\Http\Controllers\settings\branch\Branch;
use App\Http\Controllers\settings\branch\FranchiseCheckList;
use App\Http\Controllers\settings\branch\FranchiseReason;
use App\Http\Controllers\marketing_management\TrainingPlanner;
use App\Http\Controllers\settings\branch\BranchType;
use App\Http\Controllers\settings\branch\Department;
use App\Http\Controllers\settings\branch\DocumentType;
use App\Http\Controllers\settings\branch\CourseAssigne;
use App\Http\Controllers\settings\branch\IpConfig;
use App\Http\Controllers\settings\placements\InterviewCheckList;
use App\Http\Controllers\settings\placements\InterviewType;
use App\Http\Controllers\settings\placements\EventCategory;
use App\Http\Controllers\settings\placements\EventType;
use App\Http\Controllers\settings\accounts\Ledger;
use App\Http\Controllers\settings\accounts\Subledger;
use App\Http\Controllers\settings\hrm\Grade;
use App\Http\Controllers\settings\hrm\Level;
use App\Http\Controllers\settings\branch\AuditCategory;
use App\Http\Controllers\settings\branch\AuditQuestion;
use App\Http\Controllers\settings\branch\AuditStaff;
use App\Http\Controllers\settings\branch\AuditScore;

use App\Http\Controllers\settings\intern\Education;
use App\Http\Controllers\settings\intern\LetterPad;
use App\Http\Controllers\settings\intern\Topic;
use App\Http\Controllers\settings\intern\College;

use App\Http\Controllers\settings\location\Country;
use App\Http\Controllers\settings\location\State;
use App\Http\Controllers\settings\location\City;
use App\Http\Controllers\settings\location\TimeZone;

use App\Http\Controllers\settings\counsellor\CategoryQuestion;
use App\Http\Controllers\settings\counsellor\SelfAssessment;
use App\Http\Controllers\settings\counsellor\CourseQuestion;

use App\Http\Controllers\settings\exam\QuestionBankCategory;
use App\Http\Controllers\settings\exam\QuestionBankType;
use App\Http\Controllers\settings\exam\QuestionBank;
use App\Http\Controllers\settings\exam\TypeofExam;
use App\Http\Controllers\settings\exam\GradeTemplate;
use App\Http\Controllers\settings\exam\CertificateTemplate;
use App\Http\Controllers\settings\exam\AIPrompt;
use App\Http\Controllers\settings\exam\Exam_guidelines;

use App\Http\Controllers\settings\branch\SubDepartment;
use App\Http\Controllers\settings\placements\IndustryType;
use App\Http\Controllers\settings\placements\IndustryJobName;

use App\Http\Controllers\settings\placements\JobCategory;
use App\Http\Controllers\settings\placements\JobSubcategory;
use App\Http\Controllers\settings\placements\JobRoleTag;
use App\Http\Controllers\settings\placements\JobSkillTag;
use App\Http\Controllers\placements_events\ManageCompany;
use App\Http\Controllers\placements_events\ManagePlacement;
use App\Http\Controllers\placements_events\PlacedStudents;
use App\Http\Controllers\placements_events\ManageCandidate;
use App\Http\Controllers\placements_events\ManageInterview;
use App\Http\Controllers\placements_events\ManageJobs;


use App\Http\Controllers\settings\training_settings\AudioCategory;
use App\Http\Controllers\settings\training_settings\TrainingCategory;
use App\Http\Controllers\settings\training_settings\TrainingSubCategory;


//  Common Settings
use App\Http\Controllers\marketing_management\ManageMarketing;
use App\Http\Controllers\marketing_management\MarketingKit;
use App\Http\Controllers\marketing_management\ManageMarketingKit;
use App\Http\Controllers\ai_suggestion\AISuggestion;
use App\Http\Controllers\settings\common\SmsTemplate;
use App\Http\Controllers\settings\common\ReviewLinks;
use App\Http\Controllers\settings\common\WhatsappApiConfigure;  
use App\Http\Controllers\settings\common\EmailTemplate;
use App\Http\Controllers\settings\common\Communication_config;
use App\Http\Controllers\settings\common\RefundChecklist;
use App\Http\Controllers\settings\common\DropReason;
use App\Http\Controllers\settings\common\SpamCallReason;
use App\Http\Controllers\settings\common\InternalCallReason;
use App\Http\Controllers\settings\common\FollowupReason;
use App\Http\Controllers\settings\common\LeadMetrics;
use App\Http\Controllers\settings\common\Holiday;
use App\Http\Controllers\settings\common\Internal_cugs;
use App\Http\Controllers\settings\common\Gift;

use App\Http\Controllers\sales\manage_followup\ManageLeadFollowup;

// Rosini mam
use App\Http\Controllers\sales\manage_coupon\ManageCoupon;
use App\Http\Controllers\courses\ManageCertificate;
use App\Http\Controllers\courses\CertificateAuthority;
use App\Http\Controllers\customer_care\CustomerCare;
use App\Http\Controllers\customer_care\CustomerCareAttendanceView;
use App\Http\Controllers\customer_care\CustomerCareCourseView;
use App\Http\Controllers\customer_care\manage_ticket\ManageTicket;
use App\Http\Controllers\settings\course\CertificateChecklist;
use App\Http\Controllers\settings\course\CertificateStatus;
use App\Http\Controllers\settings\course\CertificateAuthorityStatus;
use App\Http\Controllers\settings\course\Courier;
use App\Http\Controllers\source_summary\SourceSummary;

use App\Http\Controllers\ManageGmail;

use App\Http\Controllers\settings\marketing\MarketingCategory;
use App\Http\Controllers\settings\marketing\MarketingType;
use App\Http\Controllers\settings\marketing\Area;
use App\Http\Controllers\settings\marketing\Zone;
use App\Http\Controllers\settings\marketing\Vendor;
use App\Http\Controllers\settings\marketing\CampaignChecklist;
use App\Http\Controllers\settings\marketing\CampaignStatus;



use App\Http\Controllers\hr_management\Attendance;
use App\Http\Controllers\MenuController;
use Illuminate\Support\Facades\Auth;


use App\Http\Controllers\support_management\NewsBroadcast;

use App\Http\Controllers\settings\broadcast_theme\BroadcastTheme;

// raj kumar
use App\Http\Controllers\placements_events\HRDirectory;
use App\Http\Controllers\placements_events\JobDirectory;
use App\Http\Controllers\settings\counsellor\FeedbackQuestion;
use App\Http\Controllers\settings\common\FinancialYear;
use App\Http\Controllers\settings\sales\Referral;
use App\Http\Controllers\settings\common\HighLightTemplate;
use App\Http\Controllers\settings\common\Rules_guidelines;

// Header
use App\Http\Controllers\toolbar_calculator\ToolbarCalculator;
use App\Http\Controllers\staff_attendance\StaffAttendanceToday;

use App\Http\Controllers\goal_set\GoalSetStaff;
use App\Http\Controllers\goal_set\SetGoal;
use App\Http\Controllers\goal_set\ManageTarget;
use App\Http\Controllers\goal_set\ManageFranchise;
use App\Http\Controllers\settings\default_goal\DefaultGoal;
use App\Http\Controllers\settings\business_goal\BusinessGoal;
use App\Http\Controllers\settings\incentive\Incentive;
use App\Http\Controllers\settings\golden_rules\GoldenRules;

// Alagu Akilan
use App\Http\Controllers\metrics\ManageGoalset;
use App\Http\Controllers\metrics\ManageMetrics;
use App\Http\Controllers\metrics\ManageBhIncentive;
use App\Http\Controllers\metrics\ManageTPO;
use App\Http\Controllers\metrics\ManageGoldenRules;
use App\Http\Controllers\metrics\ForecastMetrics;
use App\Http\Controllers\metrics\OverallOutstanding;
use App\Http\Controllers\settings\counsellor\Offerzone;
use App\Http\Controllers\placements_events\PlacementsTraining;
use App\Http\Controllers\placements_events\Events;
use App\Http\Controllers\settings\common\WhatsappTemplate;
use App\Http\Controllers\settings\course\MaterialType;
use App\Http\Controllers\customer\ManagePos;
use App\Http\Controllers\Payment\ManagePayment;
use App\Http\Controllers\Payment\ManageHarvesting;
use App\Http\Controllers\Admin\WebhookAdminController;


use App\Http\Controllers\customer\ManageIntern;

use App\Http\Controllers\WhatsAppWebhookController;
use App\Http\Controllers\WhatsAppConfig;
use App\Http\Controllers\dashboard\Notification;
use App\Http\Controllers\dashboard\SalesPromise;
use App\Http\Controllers\team_management\team_promise\TeamPromise;

use App\Http\Controllers\corporate_management\ManageCorporate;
use App\Http\Controllers\hr_management\TrainingDatabase;
use App\Http\Controllers\settings\corporate_settings\CorporateSettings;
use App\Http\Controllers\settings\corporate_settings\CorporateVenue;



use App\Http\Controllers\app_management\MobileApps;
use App\Http\Controllers\settings\marketing\Variant;
use App\Http\Controllers\settings\marketing\Variables;

use App\Http\Controllers\settings\common\MobileApp;




//Exam Settings
use App\Http\Controllers\settings\exam_settings\ExamBadge;
use App\Http\Controllers\settings\exam_settings\ExamCategory;
use App\Http\Controllers\settings\exam_settings\ExamSection;
use App\Http\Controllers\settings\exam_settings\GuideLines;
use App\Http\Controllers\settings\exam_settings\JobRoleSchedule;
use App\Http\Controllers\settings\exam_settings\QuestionBankCategorySetting;
use App\Http\Controllers\settings\exam_settings\QuestionBankTypeSetting;

//Exam Management
use App\Http\Controllers\exam_management\ManageExams;
use App\Http\Controllers\exam_management\ManageQuestionBanks;
use App\Http\Controllers\exam_management\ManageAssessment;
use App\Http\Controllers\hr_management\BadgeBoard;
use App\Http\Controllers\exam_management\ManageResult;
use App\Http\Controllers\exam_management\StaffReport;

//Corporate Settings

use App\Http\Controllers\settings\corporate_settings\CorporatePositions;
use App\Http\Controllers\settings\intern\CollegePositions;
use App\Http\Controllers\settings\corporate_settings\CorporateFeedbackQuestions;
use App\Http\Controllers\settings\corporate_settings\CorporateIndustries;

use App\Http\Controllers\customer\ManageMobileFeedback;

// Route::get('/webhook', function (Request $request) {
//     $verifyToken = '2026d0dfea8175ec07b42b2245da10f7';

//     if ($request->input('hub_verify_token') === $verifyToken) {
//         return response($request->input('hub_challenge'), 200);
//     }

//     return response('Invalid verify token', 403);
// });
// Route::post('/webhook', [Lead::class, 'handleWebhookcatch']);
 Route::match(['get', 'post'], '/meta_whatsapp_callback', [MetaWhatsAppWebhookController::class, 'handle'])->withoutMiddleware(['auth:web', 'timezone', 'check.maintenance'])->name('whatsapp.webhook.alias');
 Route::get('/interactive_audio_qr/{id}', [InteractiveAudio::class, 'audio_qr'])->name('support-manage-interactive-audio');
 
  
  Route::get('/Cronjob_HotleadToLeadBasket', [Cronjobs::class, 'Cronjob_HotleadToLeadBasket'])->name('Cronjob_HotleadToLeadBasket');
Route::get('/Cronjob_UnfollowToLeadBasket', [Cronjobs::class, 'Cronjob_UnfollowToLeadBasket'])->name('Cronjob_UnfollowToLeadBasket');
Route::get('/Cronjob_DailyCallList', [Cronjobs::class, 'Cronjob_DailyCallList'])->name('Cronjob_DailyCallList');
       
     Route::post('/checkEventMobileExists', [Events::class, 'checkEventMobileExists'])->name('checkEventMobileExists');
     Route::post('/add_qr_event_participant', [Events::class, 'AddQrParticipant'])->name('add_qr_event_participant');
     Route::post('/add_scanners_count_event', [Events::class, 'add_scanners_count_event'])->name('add_scanners_count_event');
     Route::get('/event_applied_successfully/{id}', [Events::class, 'EventAppliedSuccess'])->name('event_applied_successfully');
     Route::get('/print/invoice/pdf/{id}', [ManageFranchise::class, 'printInvoicedownload'])->name('/print/invoice/pdf');
     Route::post('/participant_location_qr', [Events::class, 'participant_location_qr'])->name('participant_location_qr'); 
   
    Route::get('/event_qr/{id}', [Events::class, 'EventQrForm'])->name('event_qr');
    Route::get('/event/event_certificate_download/{id}',[Events::class, 'EventCertificateDownload']);
    
    Route::get('/get_branch_scheduled_event',[Events::class,'GetScheduledEvent'])->name('get_branch_scheduled_event');
    Route::post('/tranfer_event_participant',[Events::class,'TranferEventParticipant'])->name('tranfer_event_participant');
  
    
    Route::match(['get', 'post'],'/corp_training_qr/participate/{id}', [ManageCorporate::class, 'TrainingAddPartQrForm']);
    Route::match(['get', 'post'],'/corp_training_qr/checkCorpTrainingMobileExists', [ManageCorporate::class, 'checkCorpTrainingMobileExists']);
    Route::match(['get', 'post'],'/corp_training_qr/add_qr_training_participant', [ManageCorporate::class, 'AddQrParticipant']);
    Route::get('/training_applied_successfully/{id}', [ManageCorporate::class, 'TrainingAppliedSuccess']);
    Route::match(['get', 'post'],'/training_certification/{id}', [ManageCorporate::class, 'TrainingCertificateDownload']);
    
Route::middleware(['auth:web', 'timezone','check.maintenance'])->group(function () {

   Route::get('/download-login-report', [Login::class, 'downloadLoginReport']);
          Route::get('/phpinfo', function() {
            phpinfo();
        });
    Route::get('/classmate_app', [MobileApps::class, 'index'])->name('app-management-classmate');
    Route::get('/guidy_app', [MobileApps::class, 'guidy_app'])->name('app-management-guidy');
    Route::get('/exam_portal', [MobileApps::class, 'exam_portal'])->name('app-management-exam-portal');
    Route::get('/score_pilot', [MobileApps::class, 'score_pilot'])->name('app-management-scorepilot');
    Route::get('/clari_app', [MobileApps::class, 'clari_app'])->name('app-management-clari');
    Route::get('/e_learning_portal', [MobileApps::class, 'e_learning_portal'])->name('app-management-learning-portal');
    Route::get('/head_hub', [MobileApps::class, 'HeadHub'])->name('app-management-head-hub');
    Route::get('/inspecto', [MobileApps::class, 'Audit'])->name('app-management-inspecto');
  
  
   // franhcise setting checklist
  Route::get('/setting/branch/fr_checklist', [FranchiseCheckList::class, 'index'])->name('settings-branch');
  Route::post('/save_franchise_check_list_order', [FranchiseCheckList::class, 'saveDocumentOrder'])->name('save_franchise_check_list_order');
  Route::post('/create_fr_checklist', [FranchiseCheckList::class, 'create'])->name('create_fr_checklist');
  Route::post('/update_fr_checklist', [FranchiseCheckList::class, 'Update'])->name('update_fr_checklist');
  Route::post('/status_fr_checklist/{id}', [FranchiseCheckList::class, 'Status'])->name('status_task_checklist');
  Route::delete('/delete_fr_checklist/{id}', [FranchiseCheckList::class, 'Delete'])->name('delete_task_checklist');
  Route::get('/edit_fr_checklist/{id}', [FranchiseCheckList::class, 'Edit']);
  Route::get('/delete_data_fr_checklist/{id}', [FranchiseCheckList::class, 'deleteData']);
  Route::get('/list_fr_checklist', [FranchiseCheckList::class, 'list']);


  Route::get('/list_fr_reason', [FranchiseReason::class, 'list']);
  Route::get('/franchise_stats/{id}', [Branch::class, 'getFranchiseStats']);
    
  Route::post('/franchise_terminate', [Branch::class, 'Franchiseterminate']);
  
  //Manage Corporate

Route::match(['get', 'post'], '/manage_corporate/corporate_training', [ManageCorporate::class, 'index'])->name('manage-corporate-training');
  Route::get('/manage_corporate/certificate', [ManageCorporate::class, 'certificate'])->name('manage-corporate-training');
  Route::post('/add_corporate_training', [ManageCorporate::class, 'Add'])->name('corporate_training_add');
  Route::get('/edit_corporate_training/{id}', [ManageCorporate::class, 'Edit'])->name('corporate_training_edit');
  Route::post('/update_corporate_training', [ManageCorporate::class, 'Update'])->name('corporate_training_update');
  Route::match(['get', 'post'],'/view_corporate_training/{id}', [ManageCorporate::class, 'View_details'])->name('corporate_training_view');
  Route::get('/college_list', [ManageCorporate::class, 'College_list'])->name('corporate_college_list');
  Route::match(['get', 'post'],'/inter_staff_list', [ManageCorporate::class, 'Internal_staff_list'])->name('corporate_inter_staff_list');
  Route::match(['get', 'post'],'/exter_staff_list', [ManageCorporate::class, 'External_staff_list'])->name('corporate_exter_staff_list');
  Route::get('/get_corporate_list', [ManageCorporate::class, 'Corporate_list'])->name('get_corporate_list');
  Route::post('/corporate_training_status/{id}', [ManageCorporate::class, 'Status'])->name('corporate_training_status');
  Route::delete('/corporate_training_delete/{id}', [ManageCorporate::class, 'Delete'])->name('corporate_training_delete');
  Route::post('/corp_payment_update/{id}', [ManageCorporate::class, 'Payment']);
  Route::match(['get', 'post'],'/manage_corporate/add_college_settings', [ManageCorporate::class, 'add_college_settings']);
  Route::match(['get', 'post'],'/manage_corporate/add_corporate_settings', [ManageCorporate::class, 'add_corporate_settings']);
  Route::match(['get', 'post'],'/manage_corporate/assign_participate_details', [ManageCorporate::class, 'Assign_participate_details']);
  Route::match(['get', 'post'],'/manage_corporate/corp_participate_details', [ManageCorporate::class, 'CorpParticipateDetails']);
  Route::match(['get', 'post'],'/manage_corporate/add_attendance_participate', [ManageCorporate::class, 'AttCorpParticipateUpdate']);
  Route::match(['get', 'post'],'/manage_corporate/swap_staffs_training', [ManageCorporate::class, 'SwapStaffTrainers']);
  Route::match(['get', 'post'],'/autocomplete_collage_corp_name', [ManageCorporate::class, 'autocomplete_collage_corp'])->name('autocomplete_collage_corp_name');
  Route::match(['get', 'post'],'/get_spoc_details', [ManageCorporate::class, 'get_spoc_details']);
  Route::match(['get', 'post'],'/manage_corporate/view_corp_campus/{id}', [ManageCorporate::class, 'view_corp_campus'])->name('manage-corporate-training');
  Route::match(['get', 'post'],'/corporate_training_ishold/{id}', [ManageCorporate::class, 'training_ishold']);
  Route::match(['get', 'post'],'/corporate_training_isunhold/{id}', [ManageCorporate::class, 'training_isunhold']);
  Route::match(['get', 'post'],'/corporate_training_cancel/{id}', [ManageCorporate::class, 'training_iscancel']);
  Route::match(['get', 'post'],'/corporate_reasons_list', [ManageCorporate::class, 'corporate_reasons_list'])->name('corporate_reasons_list');
  Route::match(['get', 'post'],'/corporate_exam_list', [ManageCorporate::class, 'get_corporate_exam_list'])->name('corporate_exam_list');
  Route::match(['get', 'post'],'/get_corporate_exam_type_list', [ManageCorporate::class, 'get_corporate_exam_type_list'])->name('corporate_exam_type_list');
  Route::match(['get', 'post'],'/manage_corporate/add_assessment_students', [ManageCorporate::class, 'add_assessment_students']);
  Route::match(['get', 'post'],'/manage_corporate/view_corp_campus_staff_info/{id}', [ManageCorporate::class, 'view_corp_campus_staff_info'])->name('manage-corporate-training');
  
  Route::match(['get', 'post'],'/manage_corporate/view_corp_campus_part_info/{id}', [ManageCorporate::class, 'view_corp_campus_part_info'])->name('manage-corporate-training');
  Route::match(['get', 'post'],'/manage_corporate/view_corp_campus_payment_info/{id}', [ManageCorporate::class, 'view_corp_campus_payment_info'])->name('manage-corporate-training');
  Route::match(['get', 'post'],'/manage_corporate/add_feedback_students', [ManageCorporate::class, 'add_feedback_students']);
  Route::match(['get', 'post'],'/manage_corporate/confirm_bulk_certification', [ManageCorporate::class, 'confirm_bulk_certification']);

  Route::match(['get', 'post'],'/manage_corporate/train_grouping_participate/{id}', [ManageCorporate::class, 'GroupingParticipate'])->name('manage-corporate-training');
  Route::match(['get', 'post'],'/manage_corporate/train_grouping_participate_save', [ManageCorporate::class, 'GroupingParticipateSave']);
  Route::match(['get', 'post'],'/manage_corporate/update_part_participate_details', [ManageCorporate::class, 'UpdateParticipateDetails']);
  Route::match(['get', 'post'],'/manage_corporate/get_company_list', [ManageCorporate::class, 'Company_list']);
  Route::match(['get', 'post'],'/manage_corporate/train_qr_generate/{id}', [ManageCorporate::class, 'generateQrEvent']);
  Route::match(['get', 'post'],'/manage_corporate/get_corp_college_positions_list', [ManageCorporate::class, 'get_corp_college_positions_list']);
    //Training Database
  Route::match(['get', 'post'], '/hr_management/trainer_database', [TrainingDatabase::class, 'index'])->name('hr-management-training');
  Route::post('/training/store', [TrainingDatabase::class, 'store']);
  Route::get('/training/edit/{id}', [TrainingDatabase::class, 'Edit']);
  Route::post('/training_database/update', [TrainingDatabase::class, 'Update']);
  Route::get('/training/view_training_details/{id}', [TrainingDatabase::class, 'View_details']);
  Route::post('/hr_management/training_database_status/{id}', [TrainingDatabase::class, 'Status']);
  Route::delete('/hr_management/training_database_delete/{id}', [TrainingDatabase::class, 'Delete']);
 
  Route::match(['get', 'post'],'/hr_management/training_database/state', [TrainingDatabase::class, 'getStates'])->name('training_database_state');
  Route::match(['get', 'post'],'/hr_management/training_database/grouped_city', [TrainingDatabase::class, 'getCitiesGroupedByState'])->name('training_database_grouped_city');
  Route::match(['get', 'post'],'/training_database/get_resume_view_details/{id}', [TrainingDatabase::class, 'get_resume_view_details']);
  Route::match(['get', 'post'],'/training_database/get_corporate_industries_list', [TrainingDatabase::class, 'get_corporate_industries_list']);
  
  // Corporate Positions
  Route::get('/settings/corporate_positions', [CorporatePositions::class, 'index'])->name('settings-coporate-settings');
  Route::post('/corporate_positions_add', [CorporatePositions::class, 'Add'])->name('add_corporate_positions');
  Route::get('/corporate_positions_list', [CorporatePositions::class, 'List'])->name('corporate_positions_list');
  Route::get('/corporate_positions_edit/{id}', [CorporatePositions::class, 'Edit'])->name('corporate_positions_edit');
  Route::post('/corporate_positions_update', [CorporatePositions::class, 'Update'])->name('update_corporate_positions');
  Route::delete('/corporate_positions_delete/{id}', [CorporatePositions::class, 'Delete']);
  Route::post('/corporate_positions_status/{id}', [CorporatePositions::class, 'Status']);

  // College Positions
  Route::get('/settings/intern/college_positions', [CollegePositions::class, 'index'])->name('settings-intern');
  Route::post('/college_positions_add', [CollegePositions::class, 'Add'])->name('add_college_positions');
  Route::get('/college_positions_list', [CollegePositions::class, 'List'])->name('college_positions_list');
  Route::get('/college_positions_edit/{id}', [CollegePositions::class, 'Edit'])->name('college_positions_edit');
  Route::post('/college_positions_update', [CollegePositions::class, 'Update'])->name('update_college_positions');
  Route::delete('/college_positions_delete/{id}', [CollegePositions::class, 'Delete']);
  Route::post('/college_positions_status/{id}', [CollegePositions::class, 'Status']);
  
  // Corporate Industries
  Route::get('/settings/corporate/corporate_industries', [CorporateIndustries::class, 'index'])->name('settings-coporate-settings');
  Route::post('/settings/corporate/corporate_industries_add', [CorporateIndustries::class, 'Add'])->name('add_corporate_industries');
  Route::get('/settings/corporate/corporate_industries_list', [CorporateIndustries::class, 'List'])->name('corporate_industries_list');
  Route::match(['get', 'post'],'/settings/corporate/corporate_industries_edit/{id}', [CorporateIndustries::class, 'Edit'])->name('corporate_industries_edit');
  Route::post('/settings/corporate/corporate_industries_update', [CorporateIndustries::class, 'Update'])->name('update_corporate_industries');
  Route::delete('/settings/corporate/corporate_industries_delete/{id}', [CorporateIndustries::class, 'Delete']);
  Route::post('/settings/corporate/corporate_industries_status/{id}', [CorporateIndustries::class, 'Status']);

  // Corporate Feedback Questions
  Route::match(['get', 'post'],'/settings/corporate/feedback_questions_list', [CorporateFeedbackQuestions::class, 'index'])->name('settings-coporate-settings');
  Route::get('/settings/corporate/feedback_questions_add', [CorporateFeedbackQuestions::class, 'FeedbackAdd'])->name('settings-coporate-settings');
  Route::match(['get', 'post'],'/settings/corporate/add_feedback_questions', [CorporateFeedbackQuestions::class, 'Add'])->name('add_corporate_feedback_questions');
  Route::get('/settings/corporate/feedback_question_list', [CorporateFeedbackQuestions::class, 'List'])->name('corp_feedback_question_list');
  Route::get('/settings/corporate/feedback_question_edit/{id}', [CorporateFeedbackQuestions::class, 'Edit'])->name('settings-coporate-settings');
  Route::match(['get', 'post'],'/settings/corporate/update_feedback_questions/{id}', [CorporateFeedbackQuestions::class, 'Update'])->name('update_corporate_feedback_questions');
  Route::delete('/settings/corporate/feedback_question_delete/{id}', [CorporateFeedbackQuestions::class, 'Delete']);
  Route::post('/settings/corporate/feedback_question_status/{id}', [CorporateFeedbackQuestions::class, 'Status']);
  Route::post('/settings/corporate/get_feedback_question_details/{id}', [CorporateFeedbackQuestions::class, 'get_feedback_question_details']);
  
  
   // Manage Exam
        Route::match(['get', 'post'], '/manage_exam_test', [ManageExams::class, 'index'])->name('exam-management-manage-exam');
        Route::get('/manage_exam/add', [ManageExams::class, 'showCreateExam'])->name('exam-management-manage-exam');
        Route::get('/fetch_job_roles', [ManageExams::class, 'fetchJobRoles']);
        Route::post('/manage_exam/create', [ManageExams::class, 'Create'])->name('manage_exam_create');
        Route::get('/edit_manage_exam/{id}', [ManageExams::class, 'Edit']);
        Route::get('/view_manage_exam/{id}', [ManageExams::class, 'View'])->name('exam-management-manage-exam');
        Route::post('/manage_exam/update', [ManageExams::class, 'Update'])->name('manage_exam_update');
        Route::post('/status_manage_exam/{id}', [ManageExams::class, 'Status']);
        Route::get('/level_based_exam_questions', [ManageExams::class, 'levelBasedQuestion']);
        Route::get('/fetch_question_bank_name/{id}', [ManageExams::class, 'fetchQuestionBankName']);
        Route::get('/edit_level_based_exam_questions/{sno}', [ManageExams::class, 'editLevelQuestions']);
         Route::get('/check-exam-process/{id}', [ManageExams::class, 'checkExamProcess']);
        Route::delete('/delete-exam/{id}', [ManageExams::class, 'Delete']);

    // Exam Question Bank
        Route::match(['get', 'post'], '/question-bank', [ManageQuestionBanks::class, 'index'])->name('exam-management-manage-question-bank');
        Route::post('/question_bank_status/{id}', [ManageQuestionBanks::class, 'Status']);
        Route::get('/question-bank/view/{id}', [ManageQuestionBanks::class, 'View'])->name('exam-management-manage-question-bank');
        Route::get('/question-bank/edit/{id}', [ManageQuestionBanks::class, 'Edit']);
        Route::post('/add_quesion_bank', [ManageQuestionBanks::class, 'Add'])->name('add_quesion_bank');
        Route::post('/edit_quesion_bank', [ManageQuestionBanks::class, 'Update'])->name('edit_quesion_bank');
        Route::post('/add_quesions', [ManageQuestionBanks::class, 'AddQuestion'])->name('add_quesions');
        Route::post('/update_quesions', [ManageQuestionBanks::class, 'UpdateQuestion'])->name('update_quesions');
    
        Route::get('/question-bank/section_add/{id}', [ManageQuestionBanks::class, 'question_add'])->name('exam-management-manage-question-bank');
        Route::get('/question-bank/section_edit/{id}', [ManageQuestionBanks::class, 'question_edit'])->name('exam-management-manage-question-bank');
        Route::post('/questions_import', [ManageQuestionBanks::class, 'ImportQuestion'])->name('questions_import');
    // Manage ManageAssessment   
        Route::match(['get', 'post'], '/manage-assessments', [ManageAssessment::class, 'index'])->name('exam-management-manage-assessments');
        Route::get('/manage-assessments/write_exam/{id}', [ManageAssessment::class, 'write_exam'])->name('exam-management-manage-assessments');
        Route::post('/save-exam-answer', [ManageAssessment::class, 'saveAnswer'])->name('saveExamAnswer');
        Route::post('/save-exam-answer-complete', [ManageAssessment::class, 'saveAnswerComplete'])->name('saveAnswerComplete');
        Route::post('/time-out', [ManageAssessment::class, 'TimeOut'])->name('timeout');
        Route::post('ids/encrypt', [ManageAssessment::class, 'encrypt_ids'])->name('ids/encrypt');
        
        Route::post('/exam-time-save', [ManageAssessment::class, 'ExamTimeSave'])->name('exam-time-save');
        Route::post('/exam/get-question-statuses', [ManageAssessment::class, 'getQuestionStatuses'])->name('examgetQuestionStatuses');
        Route::get('/exam-result/{id}', [ManageAssessment::class, 'view_result'])->name('exam-management-manage-assessments');
    // Manage Result
        Route::match(['get', 'post'], '/manage-result', [ManageResult::class, 'index'])->name('exam-management-manage-result');
        Route::match(['get', 'post'], '/staff-exam-report/{id}', [ManageResult::class, 'view_report'])->name('exam-management-manage-result');
        
        Route::post('/exam-limit-increase', [ManageResult::class, 'store_limit'])->name('exam.limit.increase');
        Route::post('/exam-process-delete', [ManageResult::class, 'exam_process_delete'])->name('exam-process-delete');
        
        // Manage Report
  Route::get('/staff_report', [StaffReport::class, 'index'])->name('exam-management-staff-report');
  Route::get('/exam-management/staff-report', [StaffReport::class, 'staffReport']);
  Route::get('/exam-management/exam-report-modal', [StaffReport::class, 'getExamReport']);
  
        Route::post('/next-attempt-schedule', [ManageAssessment::class, 'NextSchudule'])->name('next-attempt-schedule');
        Route::post('/exam-badge-claim', [ManageAssessment::class, 'BadgeClaim'])->name('exam-badge-claim');
        Route::get('/exam_log/{id}', [ManageAssessment::class, 'exam_log']);
        Route::get('/staff-assessment-certificate/{id}', [ManageAssessment::class, 'assesment_certificate'])->name('staff-assessment-certificate');
          Route::get('/assesment_certificate_preview/{id}', [ManageAssessment::class, 'assesment_certificate_preview'])->name('assesment_certificate_preview');
          Route::get('/staff_certificate_send/{id}', [ManageAssessment::class, 'staff_certificate_send'])->name('staff_certificate_send');
        
    // Badge Board
      Route::get('/badge_board', [BadgeBoard::class, 'index'])->name('leaderboard');
      Route::post('toggle_pin', [BadgeBoard::class, 'toggle_pin'])->name('toggle_pin');
      Route::get('/exam_badge_data_fetch', [BadgeBoard::class, 'badge_board_data']);
      Route::get('/update_nav_badges', [BadgeBoard::class, 'update_nav_badges']);
      Route::get('/get_nav_points', [BadgeBoard::class, 'get_nav_points']);
        
    
                  
      // Corporate Settings
      Route::get('/settings/corporate_settings', [CorporateSettings::class, 'index'])->name('settings-coporate-settings'); 
      Route::post('/corporate_settings_add', [CorporateSettings::class, 'Add'])->name('add_corporate_settings'); 
      Route::get('/corporate_settings_edit/{id}', [CorporateSettings::class, 'Edit'])->name('corporate_settings_edit'); 
      Route::post('/corporate_settings_update', [CorporateSettings::class, 'Update'])->name('update_corporate_settings');
      Route::delete('/corporate_settings_delete/{id}', [CorporateSettings::class, 'Delete']);
      Route::post('/corporate_settings_status/{id}', [CorporateSettings::class, 'Status']);
    
      // Corporate Venue
      Route::get('/settings/corporate_venue', [CorporateVenue::class, 'index'])->name('settings-coporate-settings'); 
      Route::post('/corporate_venue_add', [CorporateVenue::class, 'Add'])->name('add_corporate_venue');
      Route::get('/corporate_venue_list', [CorporateVenue::class, 'List'])->name('corporate_venue_list');
      Route::get('/corporate_venue_edit/{id}', [CorporateVenue::class, 'Edit'])->name('corporate_venue_edit'); 
      Route::post('/corporate_venue_update', [CorporateVenue::class, 'Update'])->name('update_corporate_venue');
      Route::delete('/corporate_venue_delete/{id}', [CorporateVenue::class, 'Delete']);
      Route::post('/corporate_venue_status/{id}', [CorporateVenue::class, 'Status']);

    
    

    // Variant
      Route::get('/settings/marketing/variant', [Variant::class, 'index'])->name('settings-marketing');
      Route::get('variant', [Variant::class, 'List'])->name('variant');
      Route::post('/add-variant', [Variant::class, 'Add'])->name('add_variant');
      Route::get('/variant-edit/{id}', [Variant::class, 'Edit']);
      Route::post('/variant-update/{id}', [Variant::class, 'Update']);
      Route::delete('/variant-delete/{id}', [Variant::class, 'Delete']);
      Route::post('/variant-status/{id}', [Variant::class, 'Status']);
    
      //  Variables
      Route::get('/settings/marketing/variables', [Variables::class, 'index'])->name('settings-marketing');
      Route::get('variables', [Variables::class, 'List'])->name('variables');
      Route::post('/add-variables', [Variables::class, 'Add'])->name('add_variables');
      Route::get('/variables-edit/{id}', [Variables::class, 'Edit']);
      Route::post('/variables-update', [Variables::class, 'Update'])->name('variables_update');
      Route::delete('/variables-delete/{id}', [Variables::class, 'Delete']);
      Route::post('/variables-status/{id}', [Variables::class, 'Status']);
  
  
  

    Route::match(['get', 'post'], '/team/team_promise/{day?}/{month?}/{year?}', [TeamPromise::class, 'index'])->name('team-team_promise');
    Route::match(['get', 'post'], '/team/team_promise_month/{month?}/{year?}', [TeamPromise::class, 'teamMonth'])->name('team-team_promise');
    Route::get('/comparison_lead', [TeamPromise::class, 'staffpromiseList']);
    //promise
     Route::get('/daily-task', [SalesPromise::class, 'showTaskPopup']);
      Route::get('/daily-task-failure', [SalesPromise::class, 'showFailerPopup']);
      Route::post('/daily-task/submit', [SalesPromise::class, 'submitTask']);
      Route::post('/daily-task-failure/submit', [SalesPromise::class, 'submitFailureReason']);
      Route::get('/check-promise-success', [SalesPromise::class, 'showSuccessPopup']);
      Route::post('/submit-success-cheers', [SalesPromise::class, 'submitSuccessCheers']);
      Route::post('/submit-success-cheers-call', [SalesPromise::class, 'submitSuccessCheerscall']);
     Route::post('/daily-task-failure-call/submit', [SalesPromise::class, 'submitFailureReasonCall']);
    
    Route::get('/whatsapp_chat', [WhatsAppWebhookController::class, 'index'])->name('whatsapp-chat-lead');
    Route::post('/send-message', [WhatsAppWebhookController::class, 'sendMessage']);
    Route::get('/messages/{phone}', [WhatsAppWebhookController::class, 'loadMessages']);
    Route::post('/read_message/{id}', [WhatsAppWebhookController::class, 'CountChange']);
    Route::get('/contact_info/{phone}', [WhatsAppWebhookController::class, 'LeadContactInfo']);
    Route::get('/contact_customer_info/{phone}', [WhatsAppWebhookController::class, 'CustomerContactInfo']);
    Route::post('/delete_for_message/{id}', [WhatsAppWebhookController::class, 'DeleteForMe']);
    Route::post('/send_syllabus_message', [WhatsAppWebhookController::class, 'sendSyllabusMessage'])->name('send_syllabus_message');
    Route::post('/chat_pay_remainder_message', [WhatsAppWebhookController::class, 'sendPayRemainderMessage'])->name('chat_pay_remainder_message');
    Route::get('get_customer_course_pay', [WhatsAppWebhookController::class, 'getCoursesByCustomer'])->name('get_customer_course_pay');
    


    Route::get('/whatsapp_chat_customer', [WhatsAppWebhookController::class, 'CustomerChat'])->name('whatsapp-chat-customer');
    Route::get('/whatsapp_chat_unknown', [WhatsAppWebhookController::class, 'UnknownChat'])->name('whatsapp-chat-unknown');
    
    Route::get('/contacts', [WhatsAppWebhookController::class, 'getContactsWithLastMessage']);
    Route::get('/contacts_customer', [WhatsAppWebhookController::class, 'getContactsWithLastMessage_customer']);
    Route::get('/contacts_unknown', [WhatsAppWebhookController::class, 'getContactsWithLastMessage_unknown']);

    // alagu
    Route::get('/gen_event_qr/{id}/generate-qr', [Events::class, 'generateQrEvent']);

    // process goal
    
      Route::get('team/team_goalset', [GoalSetStaff::class, 'index'])->name('team-goalset');
      Route::get('/departments_goal', [GoalSetStaff::class, 'getDepartmentsGoal'])->name('departments_goal');
      Route::get('/team_goals', [GoalSetStaff::class, 'getTeamGoal'])->name('team_goals');
      Route::post('/save_team_goals', [GoalSetStaff::class, 'saveTeamGoal'])->name('save_team_goals');
      Route::get('/staff_goal', [GoalSetStaff::class, 'getStaffGoal'])->name('staff_goal');
      Route::post('/staff_goal_update', [GoalSetStaff::class, 'addOrUpdateStaffGoal'])->name('staff_goal_update');
    
    // set goal set
      Route::get('branch_setgoal', [SetGoal::class, 'index'])->name('kpi_manage_team_setgoal');
      Route::get('/departments_setgoal', [SetGoal::class, 'getDepartmentsGoal'])->name('departments_setgoal');
      Route::get('/team_setgoals', [SetGoal::class, 'getTeamGoal'])->name('team_setgoals');
      Route::post('/save_team_setgoals', [SetGoal::class, 'saveTeamGoalset'])->name('save_team_setgoals');
      Route::get('/staff_setgoal', [SetGoal::class, 'getStaffGoal'])->name('staff_setgoal');
      Route::post('/staff_setgoal_update', [SetGoal::class, 'addOrUpdateStaffGoal'])->name('staff_setgoal_update');
      
  
      // ManageTarget goal
      Route::get('branch_target', [ManageTarget::class, 'index'])->name('kpi_manage_target');
      Route::get('get_target_goals', [ManageTarget::class, 'getTargets'])->name('get_target_goals');
      Route::get('get_target_goals_teams', [ManageTarget::class, 'getTargetsTeam'])->name('get_target_goals_teams');
      Route::post('update_target_goals', [ManageTarget::class, 'updateTargets'])->name('update_target_goals');
      
       // franchise_shar
      Route::get('franchise_share', [ManageFranchise::class, 'index'])->name('branch_manage_franchise');
      Route::get('get_franchise_share', [ManageFranchise::class, 'getShare'])->name('get_franchise_share');
      Route::get('get_payment_summary', [ManageFranchise::class, 'getPaymentSummary'])->name('get_payment_summary');
      Route::post('share_payment_update', [ManageFranchise::class, 'updateShare'])->name('share_payment_update');
      Route::get('/franchise/payment-history', [ManageFranchise::class, 'getPaymentHistory'])->name('get_payment_history');
      Route::get('/get-yearly-payment-history', [ManageFranchise::class, 'getYearlyPaymentHistory'])->name('get_yearly_payment_history');
      Route::get('/print/invoice/{id}', [ManageFranchise::class, 'printInvoice'])->name('print_invoice');
     

      
        // branch metrics goal
      Route::get('branch_metrics', [BranchMetrics::class, 'index'])->name('branch_manage_metrics');
      Route::get('get_target_goals', [BranchMetrics::class, 'getTargets'])->name('get_target_goals');
      Route::get('get_target_goals_metrics', [BranchMetrics::class, 'getTargetsMetrics'])->name('get_target_goals_metrics');
      
    Route::match(['get', 'post'], '/support/training_document', [TrainingDocument::class, 'index'])->name('support-manage-training');
    Route::match(['get', 'post'], '/support/training_document_table', [TrainingDocument::class, 'ajax_table'])->name('support.training_document_table');
    Route::get('/training-document_view/{id}', [TrainingDocument::class, 'fetchTrainingDocumentById']);
    Route::get('/training_document/categoryList', [TrainingDocument::class, 'TrainingCategoryList']);
    Route::post('/training/list', [TrainingDocument::class, 'TrainingList']);
    
    
    Route::match(['get', 'post'], '/support/manage_training_document', [ManageTrainingDocument::class, 'index'])->name('support-manage-training-document');
    Route::post('/manage_training_document_status/{id}', [ManageTrainingDocument::class, 'Status']);
    Route::post('/document_frans_status/{id}', [ManageTrainingDocument::class, 'FransStatus']);
    Route::post('/create_manage_training_document', [ManageTrainingDocument::class, 'Create'])->name('create_manage_training_document');
    Route::post('/update_manage_training_document', [ManageTrainingDocument::class, 'Update'])->name('update_manage_training_document');
    Route::delete('/training_document_delete/{id}', [ManageTrainingDocument::class, 'Delete']);
    Route::get('/training_document_edit/{id}', [ManageTrainingDocument::class, 'Edit']);
    Route::get('/traning_subcat_list', [ManageTrainingDocument::class, 'getSubcategories'])->name('traning_subcat_list');
    
    Route::get('/traning_subcat_document_list', [ManageTrainingDocument::class, 'getSubcategories_Document_list'])->name('traning_subcat_document_list');
    Route::post('/save-document-order', [ManageTrainingDocument::class, 'saveDocumentOrder'])->name('save_document_order');
        // web.ph
    Route::post('/roles/remove', [ManageTrainingDocument::class, 'removeRole'])->name('roles.remove');
    Route::post('/update_document_roles', [ManageTrainingDocument::class, 'Update_role'])->name('update_document_roles');
    
    Route::get('/role_list_fetch/{id}', [ManageTrainingDocument::class, 'role_list_fetch']);
  
  
    Route::get('/support/interactive-audio', [InteractiveAudio::class, 'index'])->name('support-manage-interactive-audio');
    
    Route::get('/api/languages', [InteractiveAudio::class, 'languages'])->name('get_languages');
    Route::post('/save_interactive_audio', [InteractiveAudio::class, 'Add'])->name('save_interactive_audio');
    Route::post('/update_interactive_audio', [InteractiveAudio::class, 'update'])->name('update_interactive_audio');
    Route::get('/interactive-audio/{id}', [InteractiveAudio::class, 'view'])->name('interactive_audio.view');
    Route::get('/interactive-audio-edit/{id}', [InteractiveAudio::class, 'edit'])->name('interactive-audio-edit');
    Route::get('/interactive-audio/{id}/generate-qr', [InteractiveAudio::class, 'generateQr']);
    Route::post('/audio_status/{id}', [InteractiveAudio::class, 'Status']);
    Route::get('/check-course-exists', [InteractiveAudio::class, 'checkCourseExists'])->name('check_course_exists');
    Route::post('/interactive-audio/upload', [InteractiveAudio::class, 'upload'])->name('interactive_audio.upload');
    Route::delete('/interactive_audio_delete/{id}', [InteractiveAudio::class, 'Delete']);
  
      //Settings -> Common -> Modules
      Route::get('/settings/modulename', [ModulesList::class, 'index'])->name('settings-bug_fixes');
      Route::get('/modulename', [ModulesList::class, 'List'])->name('modulename');
      Route::post('/add_modulename', [ModulesList::class, 'Add'])->name('add_modulename');
      Route::get('/modulename_edit/{id}', [ModulesList::class, 'Edit']);
      Route::post('/modulename_update', [ModulesList::class, 'Update'])->name('update_modulename');
      Route::delete('/modulename_delete/{id}', [ModulesList::class, 'Delete']);
      Route::post('/modulename_status/{id}', [ModulesList::class, 'Status'])->name('modulename_status');
      
      Route::get('/bugs_fixes', [BugsList::class, 'index']);
  Route::match(['get', 'post'],'/bugs_fixes/ajax_bugs_ist', [BugsList::class, 'get_bugs_list']);
  Route::match(['get', 'post'],'/get_modules_list', [BugsList::class, 'get_modules_list'])->name('get_modules_list');
  Route::match(['get', 'post'],'/add_module_list', [BugsList::class, 'add_module_list']);
  Route::match(['get', 'post'],'/bugs_fixes/add_bug', [BugsList::class, 'Add']);
  Route::match(['get', 'post'],'/bugs_fixes/edit_bug/{id}', [BugsList::class, 'Edit']);
  Route::match(['get', 'post'],'/bugs_fixes/update_bug', [BugsList::class, 'Update']);
  Route::match(['get', 'post'],'/bugs_fixes/completed_bug', [BugsList::class, 'CompletedBug']);
  Route::match(['get', 'post'],'/bugs_fixes/bugs_reasons_list', [BugsList::class, 'bugs_reasons_list']);
  Route::match(['get', 'post'],'/bugs_fixes/dropped_bug', [BugsList::class, 'DroppedBug']);
  Route::match(['get', 'post'],'/bugs_fixes/holded_bug', [BugsList::class, 'HoldedBug']);
  Route::match(['get', 'post'],'/bugs_fixes/unhold_bug', [BugsList::class, 'UnHoldedBug']);
  Route::match(['get', 'post'],'/bugs_fixes/assign_staff', [BugsList::class, 'AssignStaff']);
  Route::match(['get', 'post'],'/bugs_fixes/completed_verification_bug', [BugsList::class, 'CompletedVerifiedBug']);
  Route::match(['get', 'post'],'/bugs_fixes/testing_verification_bug', [BugsList::class, 'TestingVerifiedBug']);
  
  //Settings -> Bug & Fixes -> Drop Reasons
  Route::get('/settings/bug_fixes/drop_reasons', [BugReasons::class, 'index'])->name('settings-bug_fixes');
  Route::get('/settings/bug_fixes/drop_reasons_list', [BugReasons::class, 'List'])->name('bug_drop_reasons');
  Route::post('/settings/bug_fixes/drop_reasons_add', [BugReasons::class, 'Add'])->name('add_bug_drop_reasons');
  Route::get('/settings/bug_fixes/drop_reasons_edit/{id}', [BugReasons::class, 'Edit']);
  Route::post('/settings/bug_fixes/drop_reasons_update', [BugReasons::class, 'Update'])->name('update_bug_drop_reasons');
  Route::delete('/settings/bug_fixes/drop_reasons_delete/{id}', [BugReasons::class, 'Delete']);
  Route::post('/settings/bug_fixes/drop_reasons_status/{id}', [BugReasons::class, 'Status'])->name('bug_drop_reasons_status');

  Route::get('/settings/bug_fixes/hold_reasons', [BugReasons::class, 'hold_index'])->name('settings-bug_fixes');
  Route::get('/settings/bug_fixes/hold_reasons_list', [BugReasons::class, 'holdList'])->name('bug_hold_reasons');
  Route::post('/settings/bug_fixes/hold_reasons_add', [BugReasons::class, 'holdAdd'])->name('add_bug_hold_reasons');
  Route::get('/settings/bug_fixes/hold_reasons_edit/{id}', [BugReasons::class, 'holdEdit']);
  Route::post('/settings/bug_fixes/hold_reasons_update', [BugReasons::class, 'holdUpdate'])->name('update_bug_hold_reasons');
  Route::delete('/settings/bug_fixes/hold_reasons_delete/{id}', [BugReasons::class, 'holdDelete']);
  Route::post('/settings/bug_fixes/hold_reasons_status/{id}', [BugReasons::class, 'holdStatus'])->name('bug_hold_reasons_status');



  
   // task management
     Route::match(['get', 'post'], '/task_management_list', [TaskManagement::class, 'index'])->name('branch_manage_task');
     Route::get('task_staff_list', [TaskManagement::class, 'taskStaff']);
     Route::post('create_task', [TaskManagement::class, 'createTask']);
     Route::get('my-task-list', [TaskManagement::class, 'taskList']);
     Route::post('/task/mark-completed', [TaskManagement::class, 'markCompleted']);
     Route::post('/task/approve', [TaskManagement::class, 'approveTask']);
     Route::get('/task/edit/{id}', [TaskManagement::class, 'editTask']);
     Route::post('/task/update/{id}', [TaskManagement::class, 'updateTask']);
     Route::post('/task-complete/{id}', [TaskManagement::class, 'markComplete']);
     Route::post('/task-reopen/{id}', [TaskManagement::class, 'markReopen']);
     Route::post('/task/delete/{id}', [TaskManagement::class, 'delete']);
     
     Route::get('/task_management/my_task', [MyTask::class, 'index'])->name('task-management-my-task');
     Route::get('/task_management/team_task', [TeamTask::class, 'index'])->name('task-management-team-task');
     Route::post('/task_management/team_task_view', [TeamTask::class, 'ViewTask']);
     Route::post('/team_tasks/add', [TeamTask::class, 'addTask']);
     // setting goal
     Route::get('settings/default_goal_set', [DefaultGoal::class, 'index'])->name('settings-default_goal_set');
      Route::get('get_default_goals', [DefaultGoal::class, 'getDefaultGoals'])->name('get_default_goals');
      Route::post('update_default_goals', [DefaultGoal::class, 'updateDefaultGoals'])->name('update_default_goals');
  
        // setting goal
     Route::get('settings/business_goal_set', [BusinessGoal::class, 'index'])->name('settings-business_goal_set');
     Route::get('get_business_goals', [BusinessGoal::class, 'getBusinessGoals'])->name('get_business_goals');
     Route::post('update_business_goals', [BusinessGoal::class, 'updateBusinessGoals'])->name('update_business_goals');
 
 
     //setting incentive
      Route::get('branch_incentive', [Incentive::class, 'index'])->name('kpi_manage_manage_incentive');
      Route::get('/incentive_role', [Incentive::class, 'getroleIncentive'])->name('incentive_role');
      Route::get('/get-role-incentive-data', [Incentive::class, 'getroleIncentivedata'])->name('get-role-incentive-data');
      Route::post('/incentive-create-update', [Incentive::class, 'Incentivecreateupdate']);
      Route::get('/get-incentive-criteria', [Incentive::class, 'getCriteria']);
      Route::post('/save-incentive-criteria', [Incentive::class, 'saveCriteria']);
      Route::get('/check-incentive', [Incentive::class, 'checkIncentive'])->name('checkIncentive');

    // Branch Audit
    Route::match(['get', 'post'],'/branch_audit', [BranchAudit::class, 'index'])->name('branch_manage-audit');
    Route::get('/audit_staff_branch', [BranchAudit::class, 'auditStaffList'])->name('audit_staff');
    Route::get('/audit_branch', [BranchAudit::class, 'auditBranchList'])->name('audit_branch');
    Route::get('/audit_depart', [BranchAudit::class, 'auditDepartmentList'])->name('audit_depart');
    Route::post('/branch_audit_add', [BranchAudit::class, 'Add'])->name('branch_audit_add');
    Route::post('/branch_audit_update', [BranchAudit::class, 'Update'])->name('branch_audit_update');
    Route::get('review_audit/{id}', [BranchAudit::class, 'ReviewAudit']);
    Route::post('/audit_cancel', [BranchAudit::class, 'AuditCancel'])->name('audit_cancel');
    Route::delete('/branch_audit_delete/{id}', [BranchAudit::class, 'Delete'])->name('branch_audit_delete');
    
        // Audit staff
     Route::get('/settings/branch/audit_staff_list', [AuditStaff::class, 'index'])->name('settings-branch');
     Route::get('/audit_staff', [AuditStaff::class, 'List'])->name('audit_staff');
     Route::post('/add_audit_staff', [AuditStaff::class, 'Add'])->name('add_audit_staff');
     Route::get('/audit_staff_edit/{id}', [AuditStaff::class, 'Edit'])->name('audit_staff_edit');
     Route::post('/audit_staff_update', [AuditStaff::class, 'Update'])->name('audit_staff_update');
     Route::delete('/audit_staff_delete/{id}', [AuditStaff::class, 'Delete']);
     Route::post('/audit_staff_status/{id}', [AuditStaff::class, 'Status']);
    
     // Audit Category
    Route::get('/settings/branch/audit_category_list', [AuditCategory::class, 'index'])->name('settings-branch');
    Route::get('/audit_category', [AuditCategory::class, 'List'])->name('audit_category');
    Route::post('/add_audit_category', [AuditCategory::class, 'Add'])->name('add_audit_category');
    Route::get('/audit_category_edit/{id}', [AuditCategory::class, 'Edit'])->name('audit_category_edit');
    Route::post('/audit_category_update', [AuditCategory::class, 'Update'])->name('audit_category_update');
    Route::delete('/audit_category_delete/{id}', [AuditCategory::class, 'Delete']);
    Route::post('/audit_category_status/{id}', [AuditCategory::class, 'Status']);
      Route::get('audit_category_questions/{id}', [AuditCategory::class, 'AuditCategoryQuestions']);
    
            // AuditScore
      Route::get('/settings/branch/audit_score', [AuditScore::class, 'index'])->name('settings-branch');
      Route::post('/add_audit_score', [AuditScore::class, 'Add'])->name('add_audit_score');
      Route::post('/audit_score_update', [AuditScore::class, 'Update'])->name('audit_score_update');
      Route::delete('/audit_score_delete/{id}', [AuditScore::class, 'Delete']);
      Route::post('/audit_score_status/{id}', [AuditScore::class, 'Status']);
      Route::post('/audit_score_color_uni/{id}', [AuditScore::class, 'Color']);


    //audit question
    Route::get('/settings/branch/audit_question_list', [AuditQuestion::class, 'index'])->name('settings-branch');
    Route::get('/audit_question_list', [AuditQuestion::class, 'List'])->name('/audit_question_list');
    Route::get('/sub_category_list', [AuditQuestion::class, 'SubCategoryList'])->name('sub_category_list');
    Route::get('/sub_/audit_list/{id}', [AuditQuestion::class, 'SubCat/auditList'])->name('sub_/audit_list');
    Route::get('/sub_/audit_list_all', [AuditQuestion::class, 'SubCat/auditListAll'])->name('sub_/audit_list_all');
    Route::get('/settings/branch/audit_questions_add', [AuditQuestion::class, 'AuditQuestionAdd'])->name('/audit_questions_add');
    Route::get('/settings/branch/audit_questions_edit', [AuditQuestion::class, 'AuditQuestionEdit'])->name('settings-branch-audit-questions-edit');
    Route::get('preview_audit', [AuditQuestion::class, 'PreviewQuestions']);

    // auditQuestion
    Route::post('/audit_questions_add', [AuditQuestion::class, 'Add'])->name('audit_questions_add');
    Route::get('/audit_question_edit/{id}', [AuditQuestion::class, 'Edit'])->name('audit_question_edit');
    Route::get('/audit_analysis_ques_edit/{id}', [AuditQuestion::class, 'audit_edit'])->name('audit_edit');
    Route::post('/update_audit_question', [AuditQuestion::class, 'Update'])->name('update_audit_question');
    Route::delete('/audit_question_delete/{id}', [AuditQuestion::class, 'Delete']);
    Route::post('/audit_question_status/{id}', [AuditQuestion::class, 'Status']);
    

   Route::post('addOldCustomerSchedule', [ManageCustomer::class, 'addOldCustomerSchedule'])->name('addOldCustomerSchedule');
   Route::get('fetchOldCustomerSchedule', [ManageCustomer::class, 'fetchOldCustomerSchedule'])->name('fetchOldCustomerSchedule');
   Route::post('/customer/un_attended_class', [ManageCustomer::class, 'customerUnAttendedClass'])->name('un_attended_class');


      //setting golden_rules
      Route::get('settings/golden_rules', [GoldenRules::class, 'index'])->name('settings-golden_rules');
      Route::get('fetch-golden-rules', [GoldenRules::class, 'FetchGoldenRules']);
      Route::post('/golden_rules-create-update/{id}', [GoldenRules::class, 'goldenrulescreateupdate ']);
      
      
      Route::post('finalpayresult', [ManagePos::class, 'finalpayresult'])->name('finalpayresult');
      Route::get('/customer_pos_payment', [ManagePos::class, 'index'])->name('customer_pos_payment');
      Route::get('/autocompletepos', [ManagePos::class, 'autocomplete'])->name('autocompletepos');
      Route::get('/customerfind', [ManagePos::class, 'customerfind'])->name('customerfind');
      Route::get('/payment_particular', [ManagePos::class, 'payment_particular'])->name('payment_particular');
      Route::get('/paymentAmount', [ManagePos::class, 'paymentAmount'])->name('paymentAmount');
      Route::post('/processPayment', [ManagePos::class, 'processPayment'])->name('processPayment');
      Route::get('/customer_pos_payment_final', [ManagePos::class, 'customer_pos_payment_final'])->name('customer_pos_payment_final');
      
  
      //updateProfile 
        Route::post('/update-profile', [Login::class, 'updateProfile'])->name('update_profile');
        
        // ManageHarvesting
      Route::match(['get', 'post'], '/payment_harvesting/{month?}/{year?}/{day?}', [ManageHarvesting::class, 'Index'])->name('payment-transaction-manage_harvesting');
      Route::match(['get', 'post'], '/payment_harvesting_old', [ManageHarvesting::class, 'oldHarvesting'])->name('payment-transaction-manage_harvesting_old');
      Route::match(['get', 'post'], '/payment_remainder', [ManageHarvesting::class, 'PaymentRemainder'])->name('payment_remainder');





   // manageintern
    Route::match(['get', 'post'], '/manage_intern', [ManageIntern::class, 'Index'])->name('intern_manage');
    Route::get('add_intern', [ManageIntern::class, 'Add'])->name('intern_intern');
    Route::get('intern_certificate/{id}', [ManageIntern::class, 'viewCertificate'])->name('intern_certificate');
    Route::get('intern_certificate_employee/{id}', [ManageIntern::class, 'viewCertificateEmployee'])->name('intern_certificate_employee');
    Route::post('/generate-certificate', [ManageIntern::class, 'generate']);
    Route::post('/update-intern', [ManageIntern::class, 'update'])->name('update_intern');
    Route::post('/intern/view', [ManageIntern::class, 'View'])->name('intern_view');
    Route::post('/intern/view/invoice', [ManageIntern::class, 'ViewInvoice'])->name('intern_view_invoice');
     Route::post('/payment_update/{id}', [ManageIntern::class, 'Payment'])->name('Payment');
     Route::get('/customer/manage_intern/intern_print/{id}/{print_id}/{sno}', [ManageIntern::class, 'intern_invoice'])->name('intern-invoice');
    Route::get('staff_list', [ManageIntern::class, 'StaffListIntern'])->name('staff_list');
    
    Route::post('create_intern', [ManageIntern::class, 'CreateIntern'])->name('create_intern');
    Route::post('/convert_intern', [ManageIntern::class, 'CustomerIntern'])->name('convert_intern');
    Route::get('/lead_add_intern/{id}', [ManageIntern::class, 'lead_add'])->name('lead_add_intern');
     Route::get('/intern-date', [ManageIntern::class, 'intern_summary']);
   Route::get('/intern/preview/{id}', [ManageIntern::class, 'previewCertificate']);
   Route::get('/intern/preview/staff/{id}', [ManageIntern::class, 'previewCertificateEmployee']);
   Route::post('/certificate/update-status', [ManageIntern::class, 'updateStatus'])->name('update_certificate_status');
   
   Route::post('/intern_change', [ManageIntern::class, 'Change'])->name('intern_change');
   
    Route::match(['get', 'post'], '/intern/intern_feedback', [ManageIntern::class, 'internWise'])->name('intern_manage_feedback');
    Route::get('/intern_feedback_modal/{id}', [ManageIntern::class, 'FeedbackIntern']);
    Route::get('/collegeinternList', [ManageIntern::class, 'collegeList']);
    Route::get('/companyList', [ManageIntern::class, 'companyList']);
    
        // Routes for dropdown data
      Route::get('/get-customer-details/{id}', [ManageIntern::class, 'getCustomerDetails']);
      Route::get('/get-colleges', [ManageIntern::class, 'getColleges']);
      Route::get('/get-topics', [ManageIntern::class, 'getTopics']);
      Route::get('/get-staff', [ManageIntern::class, 'getStaff']);
     
      // Route for creating internship
      Route::post('/create-internship', [ManageIntern::class, 'createInternship'])->name('create.internship');

    // Route::get('/today_payment', [ManagePayment::class, 'TodayPayment'])->name('payment-manage_payment');
    // Route::match(['get', 'post'], '/outstanding_filter', [ManagePayment::class, 'OutstandingPayment_filter'])->name('outstanding_filter');
    // Route::get('/outstanding_payment', [ManagePayment::class, 'OutstandingPayment'])->name('payment-outstanding-manage_payment');
    // Route::get('/payment_history', [ManagePayment::class, 'PaymentHistory'])->name('payment-manage_payment');
    // Route::get('/payment_under', [ManagePayment::class, 'PaidUnder'])->name('payment-manage_payment');
    // Route::get('/get_customer_details/{id}', [ManagePayment::class, 'getCustomerDetails']);
    // Route::get('/drop_payment', [ManagePayment::class, 'DropPayment'])->name('payment-manage_payment');
    // Route::get('/reschedule_payment', [ManagePayment::class, 'ReschedulePayment'])->name('payment-manage_payment');
    // Route::post('/payment_reschdule', [ManagePayment::class, 'Payment_reschedule'])->name('payment_reschdule');
    // Route::post('/payment_reschdule_again', [ManagePayment::class, 'Payment_reschedule_again'])->name('payment_reschdule_again');

    Route::match(['get', 'post'], '/payment_transaction', [ManagePayment::class, 'PaymentTransaction'])->name('payment-manage_payment_history');
    Route::match(['get', 'post'], '/get_edit_transaction_details/{id}', [ManagePayment::class, 'GetTransactionDetails']);
    Route::match(['get', 'post'], '/update_transaction_details', [ManagePayment::class, 'UpdateTransactionDetails']);
    
        Route::match(['get', 'post'], '/today_payment', [ManagePayment::class, 'TodayPayment'])->name('payment-manage_payment');
      Route::match(['get', 'post'], '/outstanding_filter', [ManagePayment::class, 'OutstandingPayment_filter'])->name('outstanding_filter');
      Route::get('/outstanding_payment', [ManagePayment::class, 'OutstandingPayment'])->name('payment-outstanding-manage_payment');
      Route::get('/old_outstanding_payment', [ManagePayment::class, 'OldOutstandingPayment'])->name('payment-oldoutstanding-manage_payment');
      //menu old_outstanding
      Route::get('/old_outstanding', [ManagePayment::class, 'OldOutstanding'])->name('payment-old_outstanding-manage_payment');
      Route::match(['get', 'post'], '/payment_history', [ManagePayment::class, 'PaymentHistory'])->name('payment-manage_payment');
      Route::match(['get', 'post'], '/payment_under', [ManagePayment::class, 'PaidUnder'])->name('payment-manage_payment');
      Route::get('/get_customer_details/{id}', [ManagePayment::class, 'getCustomerDetails']);
       Route::get('/get_old_customer_details/{id}', [ManagePayment::class, 'getoldCustomerDetails']);
      Route::match(['get', 'post'],'/drop_payment', [ManagePayment::class, 'DropPayment'])->name('payment-manage_payment');
      Route::match(['get', 'post'], '/reschedule_payment', [ManagePayment::class, 'ReschedulePayment'])->name('payment-manage_payment');
      Route::post('/payment_reschdule', [ManagePayment::class, 'Payment_reschedule'])->name('payment_reschdule');
      Route::post('/payment_reschdule_again', [ManagePayment::class, 'Payment_reschedule_again'])->name('payment_reschdule_again');
      
      Route::match(['get', 'post'], '/low_mpc_payment', [ManagePayment::class, 'LowMPC'])->name('payment-manage_low_mpc');
      
       Route::post('/payment_history_status_change/', [ManagePayment::class, 'payment_history_status_change'])->name('payment_history_status_change');
       Route::post('/attendance_details/', [ManagePayment::class, 'attendanceDetails'])->name('attendance_details');
       Route::get('/notifications/{whom}', [Notification::class, 'getNotificationsForUser']);
       Route::post('/notifications/{whom}/mark-all-read', [Notification::class, 'markAllAsRead']);
       Route::post('/notifications/{whom}/clear-all', [Notification::class, 'clearAllNotifications']);
       Route::post('/notifications/{whom}/clear/{id}', [Notification::class, 'clearNotifications']);
   
      Route::get('/user-role-management', [MenuController::class, 'users_add'])->name('users-manage-users');
    
      Route::get('/dashboards', [Login::class, 'dashboards'])->name('dashboards');
        Route::get('/dashboard', [Login::class, 'dashboards_team'])->name('dashboard');
        Route::get('/ceo_alertdashboard', [Login::class, 'ceo_alertdashboard'])->name('ceo_alertdashboard');
      Route::get('/team_goals_dashboard', [Login::class, 'team_goals_dashboard'])->name('team_goals_dashboard');
      Route::get('/staff_goal_dashboard', [Login::class, 'staff_goal_dashboard'])->name('staff_goal_dashboard');
    
      Route::post('/logout', [Login::class, 'destroy'])->name('logout');
    
      Route::get('/db_table', [TableManagerController::class, 'index']);
      Route::get('/tables', [TableManagerController::class, 'getTables'])->name('table.manager.tables');
      Route::post('/data', [TableManagerController::class, 'getTableData'])->name('table.manager.data');
      Route::post('/update-cell', [TableManagerController::class, 'updateCell'])->name('table.manager.update.cell');
      Route::post('/update-row', [TableManagerController::class, 'updateRow'])->name('table.manager.update.row');
      Route::delete('/delete', [TableManagerController::class, 'deleteRecord'])->name('table.manager.delete');
      Route::post('/add', [TableManagerController::class, 'addRecord'])->name('table.manager.add');
      Route::post('/search', [TableManagerController::class, 'searchTable'])->name('table.manager.search');
     
     
      Route::post('/table-manager/export', [TableManagerController::class, 'exportTable'])->name('table.manager.export');
      Route::post('/table-manager/structure', [TableManagerController::class, 'getTableStructure'])->name('table.manager.structure');
      Route::post('/table-manager/modify', [TableManagerController::class, 'modifyTable'])->name('table.manager.modify');
     
      Route::post('/table-manager/column-info', [TableManagerController::class, 'getColumnInfo'])->name('table.manager.column.info');
      Route::post('/table-manager/update-query', [TableManagerController::class, 'executeUpdateQuery'])->name('table.manager.update.query');
     
      Route::post('/table-manager/execute-create-table', [TableManagerController::class, 'executeCreateTable'])->name('table.manager.execute.create.table');
    
    
    
      Route::get('/users_manage', [UserManage::class, 'index'])->name('users-manage-users_manage');
      Route::get('/user_role_manage', [UserManage::class, 'List'])->name('user_role_manage');
      Route::get('/staff/view/{id}', [UserManage::class, 'View'])->name('staff.view');
      Route::get('/users/manage_users_list', [ManageUsers::class, 'index'])->name('users-manage-users-list');
      Route::get('/users/create_manage_users', [ManageUsers::class, 'users_add'])->name('users-manage-users_add');
      Route::get('/users/update_manage_users/{id}', [ManageUsers::class, 'users_edit'])->name('users-manage-users');
      Route::get('/users/view_manage_users/{id}', [ManageUsers::class, 'users_view'])->name('users-manage-users');
    
      Route::post('/add_user_role_permission', [ManageUsers::class, 'Add'])->name('add_user_role_permission');
      Route::post('/edit_user_role_permission/{id}', [ManageUsers::class, 'Edit']);
      Route::post('/update_user_role_permission/{id}', [ManageUsers::class, 'Update'])->name('update_user_role_permission');
      Route::delete('/user_role_permission_delete/{id}', [ManageUsers::class, 'Delete']);
      Route::post('/user_role_permission_status/{id}', [ManageUsers::class, 'Status']);
      Route::match(['get', 'post'],'/users/role_based_staff_details/{id}', [ManageUsers::class, 'role_based_staff_details']);

    
      Route::get('/users/user_role', [UserRole::class, 'index'])->name('users-role');
      Route::get('/user_role', [UserRole::class, 'List'])->name('user_role');
      Route::post('/add_user_role', [UserRole::class, 'Add'])->name('add_user_role');
      Route::get('/user_role_edit/{id}', [UserRole::class, 'Edit']);
      Route::post('/user_role_update/{id}', [UserRole::class, 'Update']);
      Route::delete('/user_role_delete/{id}', [UserRole::class, 'Delete']);
      Route::post('/user_role_status/{id}', [UserRole::class, 'Status']);
      Route::get('/role/export-excel', [UserRole::class, 'ExportExcel']);
    //   Route::get('/user_role/task_edit', [UserRole::class, 'edit_task'])->name('users-management-role');
    //   Route::post('/task/import/json', [UserRole::class, 'importJson'])->name('task.import.json');
    //   Route::post('/tasks/add', [UserRole::class, 'addTask']);
      
      Route::get('/users/user_role_task', [UserRoleTask::class, 'index'])->name('users-role-task');
      Route::get('/user_role_task', [UserRoleTask::class, 'List'])->name('user_role');
      Route::post('/add_user_role_atsk', [UserRoleTask::class, 'Add'])->name('add_user_role');
      Route::get('/user_role_edit_task/{id}', [UserRoleTask::class, 'Edit']);
      Route::post('/user_role_update_task/{id}', [UserRoleTask::class, 'Update']);
      Route::delete('/user_role_delete_task/{id}', [UserRoleTask::class, 'Delete']);
      Route::post('/user_role_status_task/{id}', [UserRoleTask::class, 'Status']);
      Route::get('/role/export-excel_task', [UserRoleTask::class, 'ExportExcel']);
      Route::get('/user_role/task_edit', [UserRoleTask::class, 'edit_task'])->name('users-role-task');
      Route::post('/tasks/update_all', [UserRoleTask::class, 'updateTasks']);
      Route::post('/task/import/json', [UserRoleTask::class, 'importJson'])->name('task.import.json');
      Route::post('/tasks/add', [UserRoleTask::class, 'addTask']);
      Route::get('/tasks/counts/{role_id}', [UserRoleTask::class, 'getTaskCounts']);
      Route::get('role_task_view/{encryptedId}', [UserRoleTask::class, 'ViewTask'])->name('users-role-task');
      Route::post('/task/favorite-toggle', [UserRoleTask::class, 'toggleFavorite'])->name('task.favorite.toggle');
      Route::post('/task/favorite-all', [UserRoleTask::class, 'toggleAllFavorites'])->name('task.favorite.all');
      Route::post('/fetch-assessment', [UserRoleTask::class, 'fetchAssessment'])->name('fetch.assessment');

      // Settings Menu Starts
      // Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general_settings');
      // Route::get('/settings-general_settings', function () {
      //     // Your controller logic for the settings page goes her
      //     return 'content.settings.general_settings'; // Assuming you have a view named 'settings.general'
      // });
    
      // Staff
      Route::get('/hr_management/staff', [Staff::class, 'index'])->name('hr-management-staff');
      Route::match(['get', 'post'], '/staff_list_filter', [Staff::class, 'list_filter'])->name('staff_list_filter');
      Route::post('/staff/Add_staff_branch', [Staff::class, 'Add_staff_branch_id'])->name('staff/Add_staff_branch');
      Route::get('/hr_management/staff/staff_add', [Staff::class, 'staff_add'])->name('hr_management-staff-add');
      Route::get('/staff_role/{id}', [Staff::class, 'staff_add_ajx'])->name('staff_role');
      Route::get('/staff_list', [Staff::class, 'List'])->name('staff_list');
      Route::get('/staff_list_by_branch_id/{id}', [Staff::class, 'List_by_branch'])->name('staff_list_by_branch_id');
      Route::post('/checkunique_mobile_edit', [Staff::class, 'checkStaffMobileExists_edit'])->name('checkunique_mobile_edit');
      Route::post('/add_staff', [Staff::class, 'Add'])->name('add_staff');
      Route::post('/update_staff', [Staff::class, 'Update'])->name('update_staff');
      Route::get('/staff', [Staff::class, 'List'])->name('staff');
      Route::post('/staff_status/{id}', [Staff::class, 'Status']);
      Route::delete('/staff_delete/{id}', [Staff::class, 'Delete']);
      Route::get('/staff_data_get/{id}', [Staff::class, 'staff_data_get']);
      Route::post('/hr_management/staff/staff_view', [Staff::class, 'staff_view'])->middleware('auth')->name('staff_view');
      Route::get('/hr_management/staff/staff_edit/{id}', [Staff::class, 'staff_edit']);
      Route::get('/credential_edit_staff/{id}', [Staff::class, 'credential_edit'])->name('credential_edit_staff');
      Route::post('/checkunique_user_name', [Staff::class, 'checkunique_user_name'])->name('checkunique_user_name');
      Route::post('/checkunique_user_name_edit', [Staff::class, 'checkunique_user_name_edit'])->name('checkunique_user_name_edit');
      Route::get('/get_branch_access_role', [Staff::class, 'get_branch_access_role'])->name('get_branch_access_role');
      Route::post('/sunday_staff_add', [Staff::class, 'sunday_staff_add'])->name('sunday_staff_add');
      Route::get('/hr_management/staff/sunday_staff_list', [Staff::class, 'sunday_staff_list']);
      Route::post('/staff_sunday_status/{id}', [Staff::class, 'SundayStatus']);
      Route::get('/hr_management/staff/Exit_staff_list', [Staff::class, 'Exit_staff_list']);
      Route::post('/departure_staff', [Staff::class, 'Departure_staff'])->name('departure_staff');
      Route::post('/check-staff-mobile-exists', [Staff::class, 'checkStaffMobileExists'])->name('checkStaffMobileExists');
      Route::get('/staff_list_lead_balance', [Staff::class, 'StaffFetchLeadBalance']);
      Route::match(['get','post'], '/convert_bulk_transfer_staff_list', [Staff::class, 'BulkTransferExitStaff'])->name('convert_bulk_transfer_staff_list');
      Route::post('/staff/role/transfer', [Staff::class, 'roleTransfer'])->name('staff.role.transfer');
      
        Route::get('/hr_management/job_request', [JobRequest::class, 'index'])->name('hr-management-job-request');
        Route::post('/add_job_request', [JobRequest::class, 'Add'])->name('add_job_request');
          Route::get('/job_request_edit/{id}', [JobRequest::class, 'Edit'])->name('job_request_edit');
          Route::post('/update_job_request', [JobRequest::class, 'Update'])->name('update_job_request');
          Route::get('/job_request_list', [JobRequest::class, 'List'])->name('job_request_list');
          Route::post('/job_request_status/{id}', [JobRequest::class, 'Status']);
          Route::delete('/job_request_delete/{id}', [JobRequest::class, 'Delete']);
          Route::post('generate-job-description', [JobRequest::class, 'generateJobDescription'])->name('generate-job-description');  
          
      // Special Requirement
  Route::get('/settings/special_requirement', [SpecialRequirement::class, 'index'])->name('settings-hrm');
  Route::get('/special_requirement', [SpecialRequirement::class, 'List'])->name('special_requirement');
  Route::post('/add_special_requirement_new', [SpecialRequirement::class, 'AddNew'])->name('add_special_requirement_new');
  Route::post('/add_special_requirement', [SpecialRequirement::class, 'Add'])->name('add_special_requirement');
  Route::get('/special_requirement_edit/{id}', [SpecialRequirement::class, 'Edit'])->name('special_requirement_edit');
  Route::post('/special_requirement_update', [SpecialRequirement::class, 'Update'])->name('special_requirement_update');
  Route::delete('/special_requirement_delete/{id}', [SpecialRequirement::class, 'Delete']);
  Route::post('/special_requirement_status/{id}', [SpecialRequirement::class, 'Status']);
  Route::get('job_special_requirement_list', [JobRequest::class, 'JobRequirementList'])->name('job_special_requirement_list');
      
      Route::get('/manage_forecast_metrics', [ForecastMetrics::class, 'index'])->name('metrics-manage_forecast_metrics');
      Route::get('/get_forecast_metrics', [ForecastMetrics::class, 'getForecastMetrics']);
      
      
      
      Route::get('/manage_golden_rules', [ManageGoldenRules::class, 'index'])->name('metrics-manage-golden_rules');
      Route::get('/golden_rules', [ManageGoldenRules::class, 'GoldenRules']);
      
      Route::get('/overall_outstanding', [OverallOutstanding::class, 'index'])->name('metrics-manage-Outstanding');
      Route::get('/metrics/overall-outstanding', [OverallOutstanding::class, 'overallOutstanding'])->name('overall.outstanding');
      // Main Menu Starts metrics
      Route::get('/metrics', [ManageMetrics::class, 'index'])->name('metrics-manage-metrics');
       Route::get('/incentive', [ManageMetrics::class, 'incentive'])->name('metrics-manage-incentive');
      Route::get('/get-metrics', [ManageMetrics::class, 'getMetrics'])->name('get-metrics');
      Route::get('/get-incentive', [ManageMetrics::class, 'getIncentiveMetrics'])->name('get-incentive');
      Route::get('/my_incentive', [ManageMetrics::class, 'MyIncentive'])->name('my_incentive');
      Route::get('/my-incentive', [ManageMetrics::class, 'getMyIncentiveMetrics'])->name('my-incentive');
      Route::get('/get-Convertion-list', [ManageMetrics::class, 'getConvertedCustomers']);
      Route::get('/incentives/pi-calculation', [ManageMetrics::class, 'getcalculationCustomers']);
      Route::get('/incentives/eci-list', [ManageMetrics::class, 'geteciCustomers']);
      Route::get('/get-Collection-list', [ManageMetrics::class, 'getCollectionCustomers']);
      Route::get('/get-course-list', [ManageMetrics::class, 'getCourseCustomers']);
      Route::get('/incentives/call-list', [ManageMetrics::class, 'getCallCustomers']);
      Route::post('/fetch-incentive', [ManageMetrics::class, 'fetchIncentive']);
      
      Route::post('/get-convertion', [ManageMetrics::class, 'getConvertion'])->name('get-convertion');
      
 // Main Menu Starts bh incentive metrics
    Route::get('/bh_incentive', [ManageBhIncentive::class, 'index'])->name('metrics-manage-bh-incentive');
    Route::post('/fetch-bh-incentive', [ManageMetrics::class, 'fetchIncentive']);
    Route::get('/get-bh-incentive', [ManageBhIncentive::class, 'getIncentiveMetrics']);
    Route::get('/incentive/floating-bar', [ManageMetrics::class, 'selfIncentiveFloatingBar']);
      Route::post('/incentive/refresh-cache', [ManageMetrics::class, 'refreshIncentiveCache']);
      Route::post('/incentive/details', [ManageMetrics::class, 'getIncentiveDetails']);
    
  Route::get('/get-team-detail', [ManageMetrics::class, 'getTeamDetail'])->name('get-team-detail');
  
  
  
     Route::get('/manage_tpo', [ManageTPO::class, 'index'])->name('metrics-manage-tpo');
     Route::get('/tpo_list', [ManageTPO::class, 'tpoList']);
    
      // bh incentive
      Route::get('/bh_incentive', [ManageBhIncentive::class, 'index'])->name('metrics-manage-bh-incentive');
      Route::get('/get-bh-incentive', [ManageBhIncentive::class, 'getIncentiveMetrics'])->name('get-bh-incentive');
       // ai suggestion
       Route::get('/ai_suggestion', [AISuggestion::class, 'index'])->name('ai_suggestion');
      Route::post('/ai-suggestion/get', [AISuggestion::class, 'Suggestion'])->name('ai.suggestion.get');
      Route::get('/get-executives', [AISuggestion::class, 'getExecutives']);
      Route::get('/get-actions', [AISuggestion::class, 'getActions']);
      Route::post('/save-ai-suggestion', [AISuggestion::class, 'Suggestionsave']);
      Route::get('/get-history', [AISuggestion::class, 'history']);
    
    
       // marketing kit
       Route::get('/marketing_kit', [MarketingKit::class, 'index'])->name('marketing-manage-marketing-kit');
       Route::get('/categories', [MarketingKit::class, 'getcategories']);
       Route::get('/subcategories/{categoryId}', [MarketingKit::class, 'getSubcategories']);
       Route::get('/variables/{subcategoryId}', [MarketingKit::class, 'getVariables']);
       Route::post('/marketing-kit/add', [MarketingKit::class, 'MarketingKitAdd']);
       Route::post('/marketing-kit/update', [MarketingKit::class, 'MarketingKitUpdate']);
       Route::post('/marketing-kit/add_to_cart', [MarketingKit::class, 'MarketingKitAddToCart']);
       Route::get('/get_Cart_Count', [MarketingKit::class, 'GetCartCount']);
       Route::get('/get_Cart_view', [MarketingKit::class, 'GetCartview']);
       Route::post('/marketing-kit/list', [MarketingKit::class, 'MarketingKitList']);
       Route::post('/marketing-kit/delete', [MarketingKit::class, 'softDelete']);
       Route::get('/marketing-kit/view/{id}', [MarketingKit::class, 'MarketingKitView']);
       Route::get('/marketing-kit/edit/{id}', [MarketingKit::class, 'MarketingKitEdit']);
       Route::get('/marketing-kit/cart-view/{id}', [MarketingKit::class, 'MarketingKitCartView']);
       Route::get('/marketing-kit/payment-get', [MarketingKit::class, 'GetMarketingPayment']);
       Route::post('/razorpay-store-payment-data', [MarketingKit::class, 'storePaymentData']);
       Route::get('/razorpay-payment', [MarketingKit::class, 'showPaymentPage']);
       Route::post('/razorpay-verify', [MarketingKit::class, 'MarketingOrderPayment'])->name('razorpay.verify');
       Route::get('/marketing-kit/filter-list', [MarketingKit::class, 'MarketingKitFilterList']);
       Route::post('/cart/remove/{cartId}', [MarketingKit::class, 'removeFromCart']);
       Route::get('/download-kit/{id}', [MarketingKit::class, 'downloadKit']);
       
      Route::get('/marketing_order', [MarketingKit::class, 'orders'])->name('marketing-manage-marketing-order');
      Route::post('/deliver_order', [MarketingKit::class, 'deliverOrder'])->name('deliver_order');
      Route::post('/update_order', [MarketingKit::class, 'UpdateOrder'])->name('update_order');
      Route::get('/order_edit/{id}', [MarketingKit::class, 'EditOrder']);
      Route::post('/order_feedback', [MarketingKit::class, 'Feedback'])->name('order_feedback');
      Route::get('/order_view/{id}', [MarketingKit::class, 'viewOrder']);
      
      //manage Manage MarketingKit
       Route::get('/manage_marketing_kit', [ManageMarketingKit::class, 'index'])->name('marketing-manage-marketing-kit-list');
       Route::get('/categories', [ManageMarketingKit::class, 'getcategories']);
       Route::get('/subcategories/{categoryId}', [ManageMarketingKit::class, 'getSubcategories']);
       Route::get('/variables/{subcategoryId}', [ManageMarketingKit::class, 'getVariables']);
       Route::post('/marketing-kit/add', [ManageMarketingKit::class, 'MarketingKitAdd']);
      
      //manage Gaolset
      Route::get('/goalset', [ManageGoalset::class, 'Index'])->name('metrics-manage-goalset');
      Route::post('/add_goalset', [ManageGoalset::class, 'Add'])->name('add_goalset');
      Route::post('/update_goalset', [ManageGoalset::class, 'Update'])->name('update_goalset');
      Route::post('/goalset_delete/{id}', [ManageGoalset::class, 'Delete'])->name('goalset_delete');
      Route::post('/goalset_status_change/{id}', [ManageGoalset::class, 'Status'])->name('goalset_status_change');
      Route::post('/goalset_filter', [ManageGoalset::class, 'goalset_filter'])->name('goalset_filter');
     // Industry Type
      Route::get('/settings/placements/industry_type', [IndustryType::class, 'index'])->name('settings-placements');
      // Route::get('/interview_type', [InterviewType::class, 'List'])->name('interview_type');
      Route::post('/add_industry_type', [IndustryType::class, 'Add'])->name('add_industry_type');
      Route::post('/industry_type_update', [IndustryType::class, 'Update'])->name('industry_type_update');
      Route::delete('/industry_type_delete/{id}', [IndustryType::class, 'Delete']);
      Route::post('/industry_type_status/{id}', [IndustryType::class, 'Status']);
    
      // Industry job positon name 
      Route::get('/settings/placements/industry_job_position_name', [IndustryJobName::class, 'index'])->name('settings-placements');
      Route::get('/industry_type', [IndustryJobName::class, 'List'])->name('industry_type');
      Route::post('/add_industry_job_name', [IndustryJobName::class, 'Add'])->name('add_industry_job_name');
      Route::get('/industry_job_name_edit/{id}', [IndustryJobName::class, 'Edit'])->name('industry_job_name_edit');
      Route::post('/industry_job_name_update', [IndustryJobName::class, 'Update'])->name('industry_job_name_update');
      Route::delete('/industry_job_delete/{id}', [IndustryJobName::class, 'Delete']);
      Route::post('/industry_job_name_status/{id}', [IndustryJobName::class, 'Status']);
    
      // Job_Position
      Route::get('/settings/hrm/job_position', [JobPosition::class, 'index'])->name('settings-hrm');
      Route::get('/job_position', [JobPosition::class, 'List'])->name('job_position');
      Route::post('/add_job_position', [JobPosition::class, 'Add'])->name('add_job_position');
      Route::get('/job_position_edit/{id}', [JobPosition::class, 'Edit']);
      Route::post('/job_position_update/{id}', [JobPosition::class, 'Update']);
      Route::delete('/job_position_delete/{id}', [JobPosition::class, 'Delete']);
      Route::post('/job_position_status/{id}', [JobPosition::class, 'Status']);
    
      //Credential
    
      Route::get('/settings/hrm/credential', [Credential::class, 'index'])->name('settings-hrm');
      Route::get('/credential', [Credential::class, 'List'])->name('credential');
      Route::post('/add_credential', [Credential::class, 'Add'])->name('add_credential');
      Route::get('/credential_edit/{id}', [Credential::class, 'Edit']);
      Route::post('/credential_update/{id}', [Credential::class, 'Update']);
      Route::delete('/credential_delete/{id}', [Credential::class, 'Delete']);
      Route::post('/credential_status/{id}', [Credential::class, 'Status']);
      // Settings Menu Starts
      Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general_settings');
      Route::post('/general_settings-update', [GeneralSettings::class, 'Update'])->name('general_settings_update');
      // Main Menu Starts
    
      // Main Menu courses
      // Main Menu courses
      Route::get('/courses/manage_courses', [ManageCourses::class, 'index'])->name('courses-manage-courses');
      Route::get('/audio/{courseId}/{fileName}', [ManageCourses::class, 'streamAudio'])->name('streamAudio');
      Route::get('/pdf/stream/{encrypted}', [ManageCourses::class, 'streamPdf'])->name('streamPdf');
      Route::get('/courses/combined_course', [ManageCourses::class, 'Combined_course_list'])->name('courses-manage-courses');
      Route::match(['get', 'post'], '/course_list_filter', [ManageCourses::class, 'list_filter'])->name('course_list_filter');
      Route::get('course', [ManageCourses::class, 'List'])->name('course');
      Route::get('course_custoemr', [ManageCourses::class, 'ListCustomer'])->name('course_custoemr');
      Route::get('course_tesbo', [ManageCourses::class, 'Tesbo_List'])->name('course_tesbo');
      Route::post('/add_course', [ManageCourses::class, 'Add'])->name('add_course');
      Route::get('/course_edit/{id}', [ManageCourses::class, 'Edit']);
      Route::post('/course_update', [ManageCourses::class, 'Update'])->name('course_update');
      Route::get('/courses/manage_courses/course_view/{id}', [ManageCourses::class, 'course_view']);
      Route::get('/courses/combained_courses/course_view/{id}', [ManageCourses::class, 'Combined_course_view']);
      Route::get('/view-file/{encrypted}', [ManageCourses::class, 'viewFile'])->name('viewFile');
      Route::get('/view-lab/{encrypted}', [ManageCourses::class, 'viewLab'])->name('viewLab');
      Route::post('/update-lab-code', [ManageCourses::class, 'updateLabCode'])->name('updateLabCode');
      Route::post('/courses_status/{id}', [ManageCourses::class, 'Status']);
      Route::delete('/courses_delete/{id}', [ManageCourses::class, 'Delete']);
      Route::delete('/courses_chapter_delete/{id}', [ManageCourses::class, 'Chapter_Delete']);
      Route::delete('/courses_section_delete/{id}', [ManageCourses::class, 'Section_Delete']);
      Route::delete('/courses_topic_delete/{id}', [ManageCourses::class, 'Topic_Delete']);
      Route::get('/getCourse_keytag/{id}', [ManageCourses::class, 'getCourse_keytag']);
      Route::post('/upload_material', [ManageCourses::class, 'uploadMaterial'])->name('upload_material');
      Route::get('/course-chapters/{id}', [ManageCourses::class, 'courseChapter'])->name('course_chapter_list');

      // Main Menu courses Syllabus
      Route::get('/courses/manage_courses/syllabus_add/{id}', [ManageCourses::class, 'syllabus_add'])->name('syllabus-add');
      Route::get('/course_action_type_data/{id}', [ManageCourses::class, 'course_action_type_data']);
      Route::post('/add_syllabus', [ManageCourses::class, 'Add_syllabus'])->name('add_syllabus');
      Route::post('/Update_syllabus', [ManageCourses::class, 'Update_syllabus'])->name('Update_syllabus');
      Route::get('/courses/manage_courses/syllabus_edit/{id}', [ManageCourses::class, 'syllabus_edit'])->name('syllabus-edit');
      Route::get('/courses/manage_courses/syllabus_view', [ManageCourses::class, 'syllabus_view'])->name('syllabus-view');
      Route::get('/courses/manage_courses/course_upload_view/{id}', [ManageCourses::class, 'course_view_material']);
      Route::post('/update-document', [ManageCourses::class, 'updateDocument'])->name('update-document');
      Route::post('/update-ppt', [ManageCourses::class, 'updatePPT'])->name('update-ppt');
      Route::post('/update-pdf', [ManageCourses::class, 'updatePDF'])->name('update-pdf');
      Route::post('/update-video', [ManageCourses::class, 'updateVideo'])->name('update-video');
      Route::post('/update-auido', [ManageCourses::class, 'updateAudioMaterial'])->name('update.audio.materials');
      Route::post('/update-lab-codes', [ManageCourses::class, 'updateLabCodeMaterial'])->name('update.audio.materials');
      //  courses material
      Route::match(['get', 'post'], '/courses/course_material', [ManageCoursesMaterial::class, 'index'])->name('courses-manage-material');
      Route::post('/saveCourseMaterial', [ManageCourses::class, 'saveCourseMaterial'])->name('saveCourseMaterial');
      Route::get('/getCourseMaterial/{id}', [ManageCourses::class, 'getCourseMaterial']);
       Route::get('/syllbus-prompt', [ManageCourses::class, 'syllbusPrompt'])->name('syllbus.prompt');
    
     Route::get('/download-file', [ManageCourses::class, 'downloadFile'])->name('downloadFile');
    
      // Main Menu Batch
      Route::get('/production/manage_batch', [ManageBatch::class, 'index'])->name('production-manage-batch');
      Route::match(['get', 'post'], '/batch_list_filter', [ManageBatch::class, 'list_filter'])->name('batch_list_filter');
      Route::get('batch', [ManageBatch::class, 'LisgetCoursest'])->name('batch');
      Route::get('get_course', [ManageBatch::class, 'getCourses'])->name('get_course');
      Route::get('get_course_details', [ManageBatch::class, 'getCourselist'])->name('get_course_details');
      Route::get('slot_detail', [ManageBatch::class, 'getSlotlist'])->name('slot_detail');
      Route::post('/add_batch', [ManageBatch::class, 'Add'])->name('add_batch');
      Route::get('/batch_edit/{id}', [ManageBatch::class, 'Edit']);
      Route::post('/batch_update', [ManageBatch::class, 'Update'])->name('batch_update');
      Route::get('/batch_staff_swap/{id}', [ManageBatch::class, 'Batch_staff_swap']);
      Route::post('/batch_staff_swap_update', [ManageBatch::class, 'Batch_staff_swap_update'])->name('batch_staff_swap_update');
      Route::post('/batchs_status/{id}', [ManageBatch::class, 'Status']);
      Route::delete('/batchs_delete/{id}', [ManageBatch::class, 'Delete']);
      Route::get('/batch_view/{id}', [ManageBatch::class, 'View'])->name('batch_view');
      Route::get('/batch_staff_att/{id}', [ManageBatch::class, 'batch_staff_att'])->name('batch_staff_att');
      
      Route::delete('/batch_delete_permanently/{id}', [ManageBatch::class, 'DeleteBatchPermanently'])->name('batch_delete_permanently');
      
      Route::get('/batch_slot_change/{id}', [ManageBatch::class, 'BatchSlotChange']);
      Route::post('/batch_slot_change_update', [ManageBatch::class, 'BatchSlotChangeUpdate'])->name('batch_slot_change_update');
    
      Route::get('/batch_attendance/{id}', [ManageBatch::class, 'viewBatchAttendance'])->name('batch_attendance');
      Route::get('/batch_staff_attendance/{id}', [ManageBatch::class, 'view_batch_staff_attendance'])->name('batch_staff_attendance');
      Route::get('/batch_summary/{id}', [ManageBatch::class, 'viewBatchSummary'])->name('batch_summary');
      Route::post('/attendance_batch', [ManageBatch::class, 'batchAttendance'])->name('attendance_batch');
      Route::get('/batch_staff_history/{id}', [ManageBatch::class, 'batch_staff_history'])->name('batch_staff_history');
      
      Route::get('/unpaid_list/{id}', [ManageBatch::class, 'unpaidList'])->name('unpaid_list');
        Route::post('/batch_drop', [ManageBatch::class, 'DropBatch'])->name('batch_drop');
      
      Route::get('/batch_bulk_attendence/{id}', [ManageBatch::class, 'batch_bulk_attendence']);
      Route::post('/batch_bulk_syllabus_update', [ManageBatch::class, 'batch_bulk_syllabus'])->name('batch_bulk_syllabus_update');
      Route::post('/bulk_student_attendence_update', [ManageBatch::class, 'Bulk_atten_update'])->name('bulk_student_attendence_update');
      Route::get('/filter-staff', [ManageBatch::class, 'filterStaff'])->name('filterStaff');
      Route::get('/filter-staff-edit', [ManageBatch::class, 'filterStaffEdit'])->name('filterStaffEdit');
      Route::delete('/batchs_complete/{id}', [ManageBatch::class, 'Complete']);
      Route::get('/batch_staff_list', [ManageBatch::class, 'staffList'])->name('batch_staff_list');
      
      
      // Proccess Management -> Manage Batch Attendance
  Route::match(['get', 'post'], '/manage_batch_attendance', [ManageReview::class, 'manage_batch_attendance'])->name('production-batch-attendance');
  Route::match(['get', 'post'],'/attendance/staff-list', [ManageReview::class, 'GetStaffList'])->name('attendance.staff.list');
  Route::match(['get', 'post'],'/attendance/staff-batches', [ManageReview::class, 'GetStaffBatches'])->name('attendance.staff.batches');
  Route::match(['get', 'post'],'/attendance/matrix', [ManageReview::class, 'GetAttendanceMatrix'])->name('attendance.matrix');
  Route::match(['get', 'post'],'/attendance/change', [ManageReview::class, 'UpdateAttendanceMatrix'])->name('attendance.change');
  
  
      Route::get('/production/manage_extension_batch', [ManageExtensionBatch::class, 'index'])->name('production-manage-extension-batch');
      Route::get('/extend_batch_edit/{id}', [ManageExtensionBatch::class, 'ExtendBatchEdit']);
      Route::post('/batch_extend_approve', [ManageExtensionBatch::class, 'ExtendBatchApprove'])->name('batch_extend_approve');
        Route::post('/batch_extend_cancel', [ManageExtensionBatch::class, 'ExtendBatchCancel'])->name('batch_extend_cancel');
    
    
     // Exam result
      Route::get('/manage_exam_result', [ManageExamResult::class, 'index'])->name('exam_slug-manage_exam_result');
      Route::get('/get-exam-details/{id}', [ManageExamResult::class, 'result_view']);
      Route::get('/get-exam-certificate/{id}', [ManageExamResult::class, 'certificate_view']);
      Route::match(['get', 'post'], '/exam_certificate/{id}', [ManageExamResult::class, 'PrintCertiifcate'])->name('exam_certificate');
    
      // Exam
      
      Route::match(['get', 'post'],'/manage_exam', [ManageExam::class, 'index'])->name('exam_slug-manage-exams');
      Route::match(['get', 'post'], '/exam_filter', [ManageExam::class, 'exam_filter'])->name('exam_filter');
      Route::get('/create_exam', [ManageExam::class, 'create_exam'])->name('exam_slug-manage-exams');
      Route::get('/create_multi_exam', [ManageExam::class, 'create_multi_exam'])->name('exam_slug-manage-exams');
      Route::get('/update_exam', [ManageExam::class, 'update_exam'])->name('exam_slug-manage-exams');
      Route::get('/exam/forgot_password', [ManageExam::class, 'student_forgot_password'])->name('student-forgot-password');
      Route::get('/exam/change_password', [ManageExam::class, 'student_new_password'])->name('student-new-password');
      Route::match(['get', 'post'],'/staff_add_examiner', [ManageExam::class, 'add_staff'])->name('staff_add_examiner');
      Route::get('/question_answer', [ManageExam::class, 'question_answer'])->name('question-answer');
      Route::post('/add_exam', [ManageExam::class, 'Add'])->name('add_exam');
      Route::post('/add_multi_exam', [ManageExam::class, 'Add_multi_exam'])->name('add_multi_exam');
      Route::get('/edit_exam/{id}', [ManageExam::class, 'Edit']);
      Route::get('/edit_multi_exam/{id}', [ManageExam::class, 'Multi_Edit']);
      Route::get('/view_exam/{id}', [ManageExam::class, 'View']);
      Route::post('/update_exam', [ManageExam::class, 'Update'])->name('update_exam');
      Route::post('/update_multi_exam', [ManageExam::class, 'Update_multi_exam'])->name('update_multi_exam');
      Route::post('/exam_question_generate', [ManageExam::class, 'exam_question_generate'])->name('exam_question_generate');
      Route::get('get_chapter', [ManageExam::class, 'getChapter'])->name('get_chapter');
      Route::get('get_section', [ManageExam::class, 'getSection'])->name('get_section');
      Route::get('get_question_bank', [ManageExam::class, 'getQuestionBank'])->name('get_question_bank');
      Route::get('get_type_of_exam', [ManageExam::class, 'getTypeOfExam'])->name('get_type_of_exam');
      Route::post('/exam_delete/{id}', [ManageExam::class, 'Delete'])->name('exam_delete');
      Route::post('/exam_status_change/{id}', [ManageExam::class, 'Status'])->name('exam_status_change');
      Route::post('/examers_import', [ManageExam::class, 'ExamersImport'])->name('examers_import');
      Route::get('/examers/export-excel', [ManageExam::class, 'exportExcel']);
      Route::get('/examers/sample-excel', [ManageExam::class, 'ExamersExportExcel']);
    
      // Exam Question
      Route::match(['get', 'post'], '/manage_question_bank', [ManageQuestionBank::class, 'index'])->name('exam_slug-manage-question-bank');
      Route::get('/manage_question_bank_add/{id}', [ManageQuestionBank::class, 'question_bank_add'])->name('exam_slug-manage-question-bank');
      Route::get('/manage_question_bank_view/{id}', [ManageQuestionBank::class, 'question_bank_view'])->name('exam_slug-manage-question-bank');
      Route::get('/manage_question_bank_edit/{id}', [ManageQuestionBank::class, 'question_bank_edit'])->name('exam_slug-manage-question-bank');
      Route::get('/fetch_question_bank_data/{id}', [ManageQuestionBank::class, 'fetchQuestionBankData'])->name('fetch-question-bank-data');
      Route::post('/question/import/json', [ManageQuestionBank::class, 'importJson'])->name('question.import.json');
      Route::post('/question_create_ai', [ManageQuestionBank::class, 'askChatGPT'])->name('question_create_ai');
      
      Route::post('/exam_question_bank_add', [ManageQuestionBank::class, 'Add'])->name('exam_question_bank_add');
      Route::post('/question_bank_status/{id}', [ManageQuestionBank::class, 'Status']);
      Route::delete('/question_bank_delete/{id}', [ManageQuestionBank::class, 'Delete']);
      Route::post('/chapter_list', [ManageQuestionBank::class, 'chapter_list']);
      Route::post('/section_list', [ManageQuestionBank::class, 'section_list']);
      Route::post('/topic_list', [ManageQuestionBank::class, 'topic_list']);
    
    
    //Epro
    // ProjectLead
  Route::match(['get', 'post'], '/project/manage_lead', [ProjectLead::class, 'index'])->name('project-manage-lead');
  Route::get('/list_college', [ProjectLead::class, 'CollegeList']);
  Route::get('/college_department_list', [ProjectLead::class, 'DepartmentList']);
  Route::post('/add_fyp_lead', [ProjectLead::class, 'Add'])->name('add_fyp_lead');
  Route::get('/fyp_lead_view/{id}', [ProjectLead::class, 'View']);
  Route::get('/fyp_lead_edit/{id}', [ProjectLead::class, 'Edit']);
  Route::post('/fyp_lead_update', [ProjectLead::class, 'Update'])->name('fyp_lead_update');
  Route::post('/fyp_convert_customer', [ProjectLead::class, 'ConvertCustomer'])->name('fyp_convert_customer');
  Route::post('/get_not_closed_followups', [Lead::class, 'getNotClosedFollowups'])->name('get_not_closed_followups');
 
  // ProjectCustomer
  Route::match(['get', 'post'], '/project/manage_customer', [ProjectCustomer::class, 'index'])->name('project-manage-customer');
  Route::get('/edit_customer/{id}', [ProjectCustomer::class, 'edit']);
  Route::post('/update_customer/{id}', [ProjectCustomer::class, 'update']);
  Route::get('/language_list', [ProjectCustomer::class, 'EproLanguage']);
  Route::get('/database_lists', [ProjectCustomer::class, 'EproDatabase']);
  Route::get('/domain_lists', [ProjectCustomer::class, 'EproDomain']);
  Route::get('/list_manage_project', [ProjectCustomer::class, 'EproProject']);
  Route::get('/add_fyp_customer', [ProjectCustomer::class, 'AddCustomer'])->name('project-add-customer');
  Route::post('/check_customer_details', [ProjectCustomer::class, 'check_customer_details']);
  Route::get('/get_payment_min_and_max/{id}', [ProjectCustomer::class, 'get_payment_min_and_max']);
  Route::get('/lead_to_cus_data/{id}', [ProjectCustomer::class, 'lead_to_cus_data']);
  Route::get('/get_payment_mode_option', [ProjectCustomer::class, 'get_payment_mode_option']);
  Route::get('/get_payment_option/{id}', [ProjectCustomer::class, 'get_payment_option']);
  Route::get('/get_project_name/{id}', [ProjectCustomer::class, 'get_project_name']);
  Route::post('/create_customer', [ProjectCustomer::class, 'create_customer']);
  Route::get('/project/customer/customer_view/{id}', [ProjectCustomer::class, 'customerView']);
  Route::get('/project/customer/customer_payment/{id}', [ProjectCustomer::class, 'customer_add_payment'])->name('project-manage-payment');
  Route::post('/project/customer/customer_view/{id}', [ProjectCustomer::class, 'add_payment']);
 
  Route::get('/project/manage_payment', [ProjectPayment::class, 'index'])->name('project-manage-payment');
 
 
 
  // * APPOINTMENTS
  Route::match(['GET', 'POST'], '/project/manage_appointment', [ProjectAppointment::class, 'index'])->name('project-manage-appointment');
  Route::get('/fetch_appointment_lead', [ProjectAppointment::class, 'fetch_appointment_lead']);
  Route::get('/appointment_reason_list', [ProjectAppointment::class, 'list']);
  Route::match(['GET', 'POST'], '/upload_files', [ProjectAppointment::class, 'upload_files'])->name('upload_files');
  Route::get('/fetch_appointment_customer', [ProjectAppointment::class, 'fetch_appointment_customer']);
  Route::get('/fetch_appointment_staff', [ProjectAppointment::class, 'fetch_appointment_staff']);
  Route::post('/add_pro_appointment', [ProjectAppointment::class, 'add_appointment']);
  Route::get('/edit_appointment/{id}', [ProjectAppointment::class, 'edit']);
  Route::post('/update_appointment', [ProjectAppointment::class, 'update']);
  Route::get('/view_appointment/{id}', [ProjectAppointment::class, 'view']);
  Route::post('/status_change_appointment', [ProjectAppointment::class, 'appointmentStatusChange']);
  
    
    

      // Main Menu Costing
    
      Route::match(['get', 'post'], '/production/manage_costing_batch', [ManageCosting::class, 'index'])->name('production-manage-costing');
      Route::get('/production/manage_costing_staff', [ManageCosting::class, 'staffList'])->name('manage_costing_staff');
      Route::get('/production/manage_costing_course', [ManageCosting::class, 'courseList'])->name('production-manage-costing');
      Route::get('/production/manage_costing_slot', [ManageCosting::class, 'slotList'])->name('production-manage-costing');
      Route::get('/production/manage_costing/batch_costing_view/{id}', [ManageCosting::class, 'batchcost_view'])->name('production-manage-costing');
      Route::get('/production/manage_costing/staff_costing_view/{id}', [ManageCosting::class, 'staffcost_view'])->name('production-manage-costing');
      Route::get('/production/manage_costing/course_costing_view/{id}', [ManageCosting::class, 'coursecost_view'])->name('production-manage-costing');
      Route::get('/production/manage_costing/slot_costing_view/{id}', [ManageCosting::class, 'slotcost_view'])->name('production-manage-costing');
      //costing filters
      Route::match(['get', 'post'], '/batch_costing_filter', [ManageCosting::class, 'batch_Filter'])->name('batch_costing_filter');
      Route::post('/staff_costing_filter', [ManageCosting::class, 'StaffFilter'])->name('staff_costing_filter');
      Route::match(['get', 'post'], '/course_costing_filter', [ManageCosting::class, 'courseFilter'])->name('course_costing_filter');
      Route::match(['get', 'post'], '/slot_costing_filter', [ManageCosting::class, 'slotFilter'])->name('slot_costing_filter');
      Route::get('/student_batc_cos', [ManageCosting::class, 'studentDetailsBatch'])->name('student_batc_cos');
      
      
           // Team Costing
      Route::get('/team/team_costing', [TeamCosting::class, 'index'])->name('team-manage-costing');
      Route::match(['get', 'post'],'/team_costing_filter', [TeamCosting::class, 'StaffFilter'])->name('team_costing_filter');
      Route::get('/production/team_costing_view/{id}', [TeamCosting::class, 'staffcost_view'])->name('team_costing_view');
    
      Route::get('/production/staff_board', [StaffBoard::class, 'index'])->name('production-staff-board');
      Route::post('/day_completion', [StaffBoard::class, 'DayCompletion'])->name('day_completion');
    
      Route::get('/production/staff_board/staff_manage_batch/{id}', [StaffBoard::class, 'staff_manage_batch'])->name('production-staff-board');
      Route::get('/student_details/{id}', [StaffBoard::class, 'studentDetails'])->name('student_details');
      Route::get('/topic_details', [StaffBoard::class, 'get_topics_data']);
      Route::post('/batch_complete', [StaffBoard::class, 'Complete'])->name('batch_complete');
    //   Route::post('/batch_extend_approve', [StaffBoard::class, 'ExtendBatchApprove'])->name('batch_extend_approve');
      Route::post('/batch_extension', [StaffBoard::class, 'BatchExtension'])->name('batch_extension');
    //   Route::get('/extend_batch_edit/{id}', [StaffBoard::class, 'ExtendBatchEdit']);
    Route::match(['get', 'post'], '/batch/batch_feedback', [StaffBoard::class, 'batchFeedback'])->name('production-batch-feedback');
  Route::match(['get', 'post'], '/batch/student_feedback', [StaffBoard::class, 'StudentWise'])->name('production-student-feedback');
  Route::get('/batch_feedback_student/{id}', [StaffBoard::class, 'batchFeedbackStudent']);
  Route::get('/CourseTypeBatchList', [StaffBoard::class, 'CourseTypeList']);
  Route::get('/BatchList', [StaffBoard::class, 'BatchList']);
  Route::post('/send_feedback_student', [StaffBoard::class, 'sendFeedbackBatch']);
  Route::get('view_course_updated/{id}', [StaffBoard::class, 'ViewUpdated']);
    
     
      // batch validator
  Route::match(['get', 'post'], '/batch_validator', [BatchValidator::class, 'index'])->name('production-batch-validator');
 
  Route::get('/batch-task-list', [BatchValidator::class, 'batchTaskList']);
  Route::get('/batch-common-fetch', [BatchValidator::class, 'batchCommonFetch']);
  Route::post('/batch-common-save', [BatchValidator::class, 'batchCommonSave']);
  Route::post('/acknowledge-task-issue', [BatchValidator::class, 'acknowledgeTaskIssue']);
  Route::post('/daily-call-switch-update', [BatchValidator::class, 'updateSwitch'])->name('daily_call_switch_update');
 
     
      // attendance for student
      Route::post('/attendance_add', [StaffBoard::class, 'Attendance']);
      Route::get('/syllabus_edit', [StaffBoard::class, 'SyllabusEdit'])->name('syllabus_edit');
      Route::post('/syllabus_update', [StaffBoard::class, 'SyllabusUpdate']);
      Route::get('/production/staff_board/staff_manage_batch/feedback/{id}', [StaffBoard::class, 'staff_manage_batch_feedback'])->name('production-staff-board');
      // Route::get('/production/staff_board/staff_board_view', [StaffBoard::class, 'staff_board_view'])->name('production-staff-board');
      Route::get('/production/staff_board/staff_board_view/{id}', [StaffBoard::class, 'staff_board_view'])->name('production-staff-board');
    
    
      Route::get('/staff_attendance', [StaffAttendanceToday::class, 'index'])->name('staff_attendance');
      Route::post('/attendance_filter', [StaffAttendanceToday::class, 'att_filter'])->name('attendance_filter');
      // attendance for staff
      Route::get('/hr_management/attendance', [Attendance::class, 'index'])->name('hr-management-attendance');
      Route::post('/attendance_list_filter', [Attendance::class, 'list_filter'])->name('attendance_list_filter');
      Route::get('/branch_att', [Attendance::class, 'getBranches'])->name('branch_att');
      Route::get('/departments_att', [Attendance::class, 'getDepartments'])->name('departments_att');
      Route::get('/staff_att', [Attendance::class, 'getStaff'])->name('staff_att');
      Route::post('/staff_attendance', [Attendance::class, 'Add'])->name('staff_attendance');
      Route::post('/staff_attendance_update', [Attendance::class, 'Update'])->name('staff_attendance_update');
      Route::get('/attendance_view/{id}', [Attendance::class, 'viewAttendance'])->name('attendance_view');
      Route::post('/fetchStaffMonthlyAttendance', [Attendance::class, 'fetchStaffMonthlyAttendance'])->name('fetchStaffMonthlyAttendance');
      Route::post('/fetchIndividualStaffAttendance', [Attendance::class, 'fetchIndividualStaffAttendance'])->name('fetchIndividualStaffAttendance');
      Route::post('/ViewAttendanceDate', [Attendance::class, 'ViewAttendanceDate'])->name('ViewAttendanceDate');
      Route::get('/hr_management/attendance/staff_reschedule/{staff_attendance_id}', [Attendance::class, 'staff_reschedule'])->name('hr-management-staff-reschedule');
      Route::post('/update-batch-staff', [Attendance::class, 'StaffBatchReshedule'])->name('update-batch-staff');
      Route::get('/attendance/yearly', [Attendance::class, 'getYearlyAttendance'])->name('attendance.yearly');
      
      Route::match(['get', 'post'], '/staff_bulk_attendence', [Attendance::class, 'staff_bulk_attendence'])->name('staff_bulk_attendence');
      Route::match(['get', 'post'], '/staff_bulk_attendence_update', [Attendance::class, 'bulkAttendanceUpdate'])->name('staff_bulk_attendence_update');
      
       // Lead Calendar
      Route::match(['get', 'post'], '/sales/lead_calendar', [LeadCalendar::class, 'lead_calendar'])->name('sales-lead-calendar');
      // Manage Walk-In
      Route::match(['get', 'post'], '/sales/manage_walkin', [ManageWalkin::class, 'index'])->name('sales-manage-walkin');
    
      // Main Menu lead
      Route::match(['get', 'post'],'/sales/manage_lead', [Lead::class, 'index'])->name('sales-manage-lead');
      Route::get('/sales/raw_lead', [Lead::class, 'raw_lead'])->name('sales-manage-lead');
      Route::match(['get', 'post'], '/lead_bank_list', [Lead::class, 'Lead_bank_list'])->name('sales-manage-lead');
      Route::post('/raw-lead/approve-reject', [Lead::class, 'approveRejectLead'])->name('raw-lead. Approve-reject');
      Route::post('/bulk_bank_lead', [Lead::class, 'bulk_bank_lead_conversion'])->name('bulk_bank_lead');
      Route::post('/bank_lead', [Lead::class, 'bank_lead_conversion'])->name('bank_lead');
      Route::get('/lead_edit_bank_convert/{id}', [Lead::class, 'EditConvertBank']);
      Route::post('/convert_bank_to_lead', [Lead::class, 'ConvertBanktoLead'])->name('convert_bank_to_lead');
      
       //new
  Route::match(['get', 'post'], '/lead_management/potential_lead', [ManagePotentialLead::class, 'index'])->name('sales-manage-pot_lead');
  Route::post('/trans_potential_to_lead', [ManagePotentialLead::class, 'trans_potential_to_lead'])->name('trans_potential_to_lead');
  Route::post('/add_appointment_pb', [ManagePotentialLead::class, 'AppointmentPB'])->name('add_appointment_pb');
  Route::post('/appointment_update_pb/{id}', [ManagePotentialLead::class, 'appointment_update_pb']);
  Route::post('/lead/change-interested', [ManagePotentialLead::class, 'changeInterested']);
  
  //
  
 //Daily Calls
  Route::match(['get', 'post'], '/sales/daily_call_lead', [DailyCallLead::class, 'index'])->name('sales-manage-daily-call');
  Route::post('/add_appointment_daily', [DailyCallLead::class, 'Appointment'])->name('add_appointment_daily');
  Route::post('/appointment_update_daily/{id}', [DailyCallLead::class, 'AppointmentUpdate']);
  Route::get('/sales_staff_list', [DailyCallLead::class, 'SalesList'])->name('sales_staff_list');
  Route::post('/sales-staff-update', [DailyCallLead::class, 'SalesListUpdate'])->name('sales_staff_update');
  Route::post('/daily-call-switch-update', [DailyCallLead::class, 'updateSwitch'])->name('daily_call_switch_update');
  Route::get('/daily_call_history', [DailyCallLead::class, 'daily_call_history'])->name('daily_call_history');
  Route::post('/daily-performance', [DailyCallLead::class, 'getDailyPerformance']);
 Route::post('/reset_daily_call/{id}', [DailyCallLead::class, 'ResetDailyCall']);
 Route::get('/daily_call_log', [DailyCallLead::class, 'daily_call_log'])->name('daily_call_log');
 
 //Lead
 
 Route::get('/lead/getNotClosedDead', [Lead::class, 'getNotClosedDead']);
  Route::get('/lead/getNotClosedSpam', [Lead::class, 'getNotClosedSpam']);
  
 
  Route::match(['get', 'post'], '/settings/lead/potential_reason', [PotentialReason::class, 'index'])->name('settings-lead-settings');
  Route::post('/potential_reason_add', [PotentialReason::class, 'Add'])->name('potential_reason_add');
  Route::get('potential_reason_list', [PotentialReason::class, 'List'])->name('potential_reason_list');
  Route::post('/potential_reason_status/{id}', [PotentialReason::class, 'Status']);
  Route::delete('/potential_reason_delete/{id}', [PotentialReason::class, 'Delete']);
  Route::post('/potential_reason_update', [PotentialReason::class, 'Update'])->name('potential_reason_update');
      
      Route::get('/phn_no_valid', [Lead::class, 'validatePhoneNumber'])->name('phn_no_valid');
      Route::get('/get_call_history_cus', [ManageCustomer::class, 'getCallHistoryCustomer'])->name('get_call_history_cus');
      Route::get('/get_staff_call_history', [ManageCalls::class, 'staffCallHistory'])->name('get_staff_call_history');
      Route::post('/spam_lead_convert_calls', [ManageCalls::class, 'spamLeadConvertCalls'])->name('spam_lead_convert_calls');
      
      Route::post('/add_on_course', [ManageCustomer::class, 'Add_on_course'])->name('add_on_course');
      Route::post('/validate-coupon', [ManageCustomer::class, 'validateCoupon'])->name('validate.coupon');
      Route::get('/payment/edit', [ManageCustomer::class, 'editPay'])->name('payment.edit');
      Route::post('/payment/update', [ManageCustomer::class, 'updatePay'])->name('payment.update');
      Route::get('/training/{customerId}', [ManageCustomer::class, 'getTraining']);
      Route::post('/training/update', [ManageCustomer::class, 'updateTraining']);
    
      Route::post('/customer-placements/{id}', [ManageCustomer::class, 'confirmplacement'])->name('customer_placements');
      
      Route::post('/lead_transfer/{id}', [Lead::class, 'LeadTransfer']);
      Route::match(['get', 'post'], '/raw_lead_filter', [Lead::class, 'raw_filter'])->name('sales-manage-lead');
      Route::match(['get', 'post'], '/lead_filter', [Lead::class, 'filter_lead'])->name('sales-manage-lead');
      Route::post('/check-mobile-exists', [Lead::class, 'checkMobileExists'])->name('checkMobileExists');
      Route::post('/convert_raw_to_lead/{id}', [Lead::class, 'ConvertRawtoLead']);
      Route::post('/bulk_raw_lead', [Lead::class, 'bulk_raw_lead_conversion'])->name('bulk_raw_lead');
      Route::get('lead', [Lead::class, 'List'])->name('lead');
      Route::get('/lead/export-excel', [Lead::class, 'exportExcel']);
      Route::get('/lead/sample-excel', [Lead::class, 'LeadExportExcel']);
    
      Route::get('/appointment_history/{id}', [Lead::class, 'AppointmentHistory'])->name('appointment_history');
      Route::post('/hot_lead_status_update/{id}', [Lead::class, 'HotLeadStatus']);
      Route::match(['get', 'post'], '/sales/hot_lead', [HotLead::class, 'index'])->name('sales-manage-hot-lead');
      Route::post('/unmark_hot_lead/{id}', [HotLead::class, 'unMarkHotLead']);
    
      Route::post('/quick_add_lead', [Lead::class, 'QuickAdd'])->name('quick_add_lead');
      Route::post('/add_lead', [Lead::class, 'Add'])->name('add_lead');
      Route::get('/lead_edit/{id}', [Lead::class, 'Edit']);
      Route::get('/lead_view/{id}', [Lead::class, 'View']);
      Route::post('/lead_update', [Lead::class, 'Update'])->name('lead_update');
      Route::post('/raw_lead_update', [Lead::class, 'Update_raw'])->name('raw_lead_update');
      Route::post('/lead_checklist', [Lead::class, 'Leadchecklist'])->name('lead_checklist');
      Route::delete('/lead_delete/{id}', [Lead::class, 'Delete']);
      Route::post('/status_update/{id}', [Lead::class, 'Status']);
    
      Route::post('/add_appointment', [Lead::class, 'Appointment'])->name('add_appointment');
      Route::get('/edit_appointment/{id}', [Lead::class, 'AppointmentEdit'])->name('edit_appointment');
      Route::post('/appointment_update/{id}', [Lead::class, 'AppointmentUpdate']);
      Route::post('/lead_import', [Lead::class, 'LeadImport'])->name('lead_import');
      Route::post('/lead_import_old', [Lead::class, 'LeadImportOld'])->name('lead_import_old');
      Route::post('/convert_customer', [Lead::class, 'CustomerConvert'])->name('convert_customer');
    
      Route::post('/lead_message', [Lead::class, 'LeadMessage'])->name('lead_message');
      Route::post('/lead_status_change/{id}', [Lead::class, 'LeadStatus']);
      Route::get('/whatsapp_templates', [Lead::class, 'showTemplates'])->name('whatsapp_templates');
      
      Route::post('/syllabus_message', [Lead::class, 'syllabusMessage'])->name('syllabus_message');
      
    Route::match(['get', 'post'], '/CloudCall', [CloudCall::class, 'Index'])->name('sales-manage-cloud-call');
    Route::post('/spam_lead_convert', [CloudCall::class, 'spamLeadConvert'])->name('spam_lead_convert');
    
    Route::match(['get', 'post'], '/sales/lead_source', [Lead::class, 'Lead_source_list'])->name('sales-lead_source_list');
  
   // manage calls and Manage team
    Route::match(['get', 'post'], '/sales/manage_calls', [ManageCalls::class, 'manage_calls'])->name('sales-manage-calls');
      Route::match(['get', 'post'], '/sales/manage_calls', [ManageCalls::class, 'index'])->name('sales-manage-calls');

    Route::post('/team_add', [ManageCalls::class, 'Add'])->name('team_add');
    Route::get('/team_staff', [ManageCalls::class, 'StaffList'])->name('team_staff');
     Route::match(['get', 'post'], '/sales/individual_call_details/{id}', [ManageCalls::class, 'call_history'])->name('sales.individual_call_details');
    Route::match(['get', 'post'], '/sales/individual_lead_call_details/{id}/{status}', [ManageCalls::class, 'lead_call_history'])->name('sales.individual_lead_call_details');
    Route::get('/get-call-history', [ManageCalls::class, 'getCallHistory'])->name('get_call_history');
    
    Route::get('/cug_monitor', [ManageCalls::class,'cugIndex'])->name('team-cug-monitor');
      Route::get('/ajax/cug-monitor/list',[ManageCalls::class,'cugStaffList'])->name('ajax.cug.monitor.list');
      Route::get('/ajax/cug-monitor/departments',[ManageCalls::class,'cugDepartments'])->name('ajax.cug.monitor.departments');
      Route::get('/get-call-locations/{id}', [ManageCalls::class, 'getMonthStaffLocations']);
     
      Route::get('/call_location_tracker', [ManageCalls::class,'locationTrackerIndex'])->name('team-cug-loaction-monitor');
      Route::get('/call_location_tracker/data', [ManageCalls::class,'locationTrackerData'])->name('call.location.tracker.data');
      Route::get('/call_location_tracker/staff', [ManageCalls::class,'locationTrackerStaff'])->name('call.location.tracker.staff');
  
    Route::get('/ajax/menu-counts', [MenuCountController::class, 'index'])->name('ajax.menu.counts');    
    
    
     //Team Management
    //Team lead
    Route::match(['get', 'post'], '/team/manage_team_lead/today', [TeamLead::class, 'TeamLeadToday'])->name('team-manage-lead');
    Route::match(['get', 'post'], '/team/manage_team_lead/all', [TeamLead::class, 'TeamLeadTotal'])->name('team-manage-lead');
    Route::post('/lead_limit_set/{id}', [TeamLead::class, 'leadLimitSet']);
    Route::match(['get', 'post'], '/team/manage_team_lead/{id}', [TeamLead::class, 'staffLeadFilter']);
    Route::match(['get', 'post'], '/team/manage_team_lead', [TeamLead::class, 'index'])->name('team-manage-lead');
    
    //Team Goalset
    // Route::match(['get', 'post'], '/team/team_goalset', [TeamGoalset::class, 'Index'])->name('team-goalset');
    // Route::get('/departments_goal', [TeamGoalset::class, 'getDepartmentsGoal'])->name('departments_goal');
    // Route::get('/staff_goal_team', [TeamGoalset::class, 'getStaffGoal'])->name('staff_goal_team');
    // Route::post('/staff_goal_update', [TeamGoalset::class, 'addOrUpdateStaffGoal'])->name('staff_goal_update');
    //Team FtotList
    Route::match(['get', 'post'], '/team/manage_team_ftot_list', [TeamFollowingTot::class, 'teamFtotList'])->name('teamFtotList');
    Route::match(['get', 'post'], '/team/manage_team_ftot', [TeamFollowingTot::class, 'index'])->name('team-manage-ftot');
    Route::match(['get', 'post'], '/team/manage_team_lead/today', [TeamFollowingTot::class, 'TeamLeadToday'])->name('team-manage-lead');

    //Team Followup
    Route::match(['get', 'post'], '/team/manage_team_followup/today', [TeamFollowup::class, 'teamFollowupToday'])->name('team-manage-followup');
    Route::match(['get', 'post'], '/team/manage_team_followup/all', [TeamFollowup::class, 'teamFollowupTotal'])->name('team-manage-followup');
    Route::match(['get', 'post'], '/team/manage_team_followup', [TeamFollowup::class, 'index'])->name('team-manage-followup');

    //Team Appointment
    Route::match(['get', 'post'], '/team/manage_team_appointment/today', [TeamAppointment::class, 'teamAppointmentToday'])->name('team-manage-appointment');
    Route::match(['get', 'post'], '/team/manage_team_appointment/all', [TeamAppointment::class, 'teamAppointmentTotal'])->name('team-manage-appointment');
    Route::match(['get', 'post'], '/team/manage_team_appointment', [TeamAppointment::class, 'index'])->name('team-manage-appointment');

    //Team Call
    Route::match(['get', 'post'], '/team/manage_team_call/today', [TeamCall::class, 'teamCallToday'])->name('team-manage-call');
    Route::match(['get', 'post'], '/team/manage_team_call/all', [TeamCall::class, 'teamCallTotal'])->name('team-manage-call');
    Route::match(['get', 'post'], '/team/manage_team_call', [TeamCall::class, 'index'])->name('team-manage-call');
    
    //Team Cloud Call
    Route::match(['get', 'post'], '/team/manage_team_cloud_call', [TeamCloudCall::class, 'index'])->name('team-manage-cloud-call');
    
  
      Route::post('/submit_drop_reason', [Lead::class, 'drop_reason'])->name('submit_drop_reason');
      Route::post('/submit_spam_reason', [Lead::class, 'spam_reason'])->name('submit_spam_reason');
      Route::match(['get', 'post'], '/sales/internal_calls', [Lead::class, 'internal_calls'])->name('sales-manage-lead');
      Route::post('/lead_convert_branch/{id}', [Lead::class, 'ConvertLeadBranch']);
      
    Route::get('/branch_staff', [Lead::class, 'BranchStaffList'])->name('branch_staff');
    Route::match(['get', 'post'], '/sales/manage_lead/spam_lead', [Lead::class, 'spamLeadList'])->name('sales-manage-lead');
    Route::match(['get', 'post'], '/sales/manage_lead/drop_lead', [Lead::class, 'dropLeadList'])->name('sales-manage-lead');
    Route::delete('/lead_internal_calls/{id}', [Lead::class, 'InternalCalls']);
    Route::match(['get', 'post'],'/confirm_spam_bulk', [Lead::class, 'ConfirmSpamLeadBulk']);
  Route::match(['get', 'post'],'/confirm_drop_lead_bulk', [Lead::class, 'ConfirmDropLeadBulk']);
     
    Route::match(['get', 'post'],'/sales/today_followup', [Lead::class, 'TodayFollowup'])->name('sales-manage-lead');
    Route::post('/submit_internal_reason', [Lead::class, 'internal_reason'])->name('submit_internal_reason');
    Route::post('/add_spam', [Lead::class, 'AddSpam'])->name('add_spam');
    // spam
    Route::post('/convert_spam_to_lead/{id}', [Lead::class, 'ConvertSpamToLead']);
    Route::post('/confirm_spam', [Lead::class, 'ConfirmSpamLead'])->name('confirm_spam');
    // drop
    Route::post('/convert_drop_to_lead/{id}', [Lead::class, 'ConvertDropToLead']);
    Route::post('/confirm_drop', [Lead::class, 'ConfirmDropLead'])->name('confirm_drop');
    Route::post('/confirm_drop_lead', [Lead::class, 'ConvertDropLead'])->name('confirm_drop_lead');
    
    Route::post('/confirm_internal_calls', [Lead::class, 'ConfirmInternalCalls'])->name('confirm_internal_calls');
    Route::post('/convert_internal_to_lead/{id}', [Lead::class, 'ConvertInternalToLead']);
    
    Route::post('/bulk_sales_staff_convert', [Lead::class, 'bulkSalesStaffConversion'])->name('bulk_sales_staff_convert');
    
    Route::post('/submit_raw_spam_reason', [Lead::class, 'Rawspam'])->name('submit_raw_spam_reason');
  Route::post('/raw_drop', [Lead::class, 'Rawdrop'])->name('raw_drop');
  Route::post('/future_lead_status/{id}', [Lead::class, 'FutureLead']);
  
  Route::match(['get', 'post'], '/sales/lead_wallet', [Lead::class, 'LeadWallet'])->name('sales-manage-lead');
  Route::post('/convert_wallet_to_lead', [Lead::class, 'ConvertWallettoLead']);
  Route::post('/lead_wallet_status', [Lead::class, 'wallet_status'])->name('lead_wallet_status');


 //followup list
    Route::match(['get', 'post'], '/sales/manage_lead_follow_up', [ManageLeadFollowup::class, 'index'])->name('sales-manage-lead-followup');
    Route::match(['get', 'post'], '/sales/manage_lead_follow_up/closed_follow', [ManageLeadFollowup::class, 'closedFollowup'])->name('sales-manage-lead-followup');
    Route::match(['get', 'post'], '/sales/manage_lead_follow_up/reschedule_follow', [ManageLeadFollowup::class, 'rescheduleFollowup'])->name('sales-manage-lead-followup');
    Route::match(['get', 'post'], '/sales/manage_lead_follow_up/un_follow', [ManageLeadFollowup::class, 'unfollowup'])->name('sales-manage-lead-followup');



  //manage_coupon
    Route::get('/sales/manage_coupon', [ManageCoupon::class, 'index'])->name('marketing-manage-coupon');
  Route::get('/sales/usage_history', [ManageCoupon::class, 'usage_history'])->name('sales-manage-coupon'); 
  Route::post('/usage_history_filter', [ManageCoupon::class, 'UsageHistoryFilter'])->name('usage_history_filter'); 
  Route::post('/coupon_status/{id}', [ManageCoupon::class, 'Status']);
  Route::post('/add_coupon', [ManageCoupon::class, 'Add'])->name('add_coupon');
  Route::delete('/coupon_delete/{id}', [ManageCoupon::class, 'Delete']);
  Route::match(['get', 'post'], '/manage_coupon_filter', [ManageCoupon::class, 'list_filter'])->name('manage_coupon_filter');
  Route::get('/autocomplete_coupon', [ManageCoupon::class, 'autocomplete_coupon'])->name('autocomplete_coupon');

// Material Type
  Route::get('/settings/course/material_type', [MaterialType::class, 'index'])->name('settings-course-material_type');
  Route::get('/material_type', [MaterialType::class, 'List'])->name('material_type');
  Route::post('/add_material_type', [MaterialType::class, 'Add'])->name('add_material_type');
  Route::get('/material_type_edit/{id}', [MaterialType::class, 'Edit'])->name('material_type_edit');
  Route::post('/material_type_update', [MaterialType::class, 'Update'])->name('material_type_update');
  Route::delete('/material_type_delete/{id}', [MaterialType::class, 'Delete']);
  Route::post('/material_type_status/{id}', [MaterialType::class, 'Status']);
  Route::get('/manage_student', [ManageStudent::class, 'index'])->name('customer-manage_student');
  Route::get('/student_list_att', [ManageStudent::class, 'studentList'])->name('student_list_att');
  
  // Manage Review
//   Route::match(['get', 'post'], '/manage_review', [ManageReview::class, 'index'])->name('customer-manage_review');
//   Route::post('/add_ManageReview', [ManageReview::class, 'Add'])->name('add_ManageReview');
//   Route::get('/ManageReview-edit/{id}', [ManageReview::class, 'Edit']);
//   Route::post('/ManageReview_update', [ManageReview::class, 'Update'])->name('ManageReview_update');
  
  // Manage Review
  Route::match(['get', 'post'], '/manage_review', [ManageReview::class, 'index'])->name('customer-management-manage-review');
  Route::match(['get', 'post'], '/manage_review_ajax', [ManageReview::class, 'manage_review_ajax'])->name('manage_review_ajax');
  Route::match(['get', 'post'], '/review_customer_list', [ManageReview::class, 'review_customer_list'])->name('review_customer_list');
  Route::post('/add_ManageReview', [ManageReview::class, 'Add'])->name('add_ManageReview');
  Route::match(['get', 'post'],'/edit_ManageReview/{id}', [ManageReview::class, 'Edit']);
  // Main Menu customer
    
  Route::match(['get', 'post'],'/customer_completed', [ManageCustomer::class, 'complete_customer'])->name('customer-manage_customer');
  
   Route::get('/manage_not_started_customer', [ManageCustomer::class, 'NotStartedCustomer'])->name('customer-NotStarted');
   Route::match(['get', 'post'], '/manage_not_started_customer_filter', [ManageCustomer::class, 'NotStartedListFilter'])->name('customer-NotStarted');
    Route::get('/scheduled_customer', [ManageCustomer::class, 'ScheduledCustomer'])->name('customer-manage_customer');
    Route::match(['get', 'post'], '/scheduled_customer_filter', [ManageCustomer::class, 'ScheduledCustomerFilter'])->name('customer-manage_customer');

    Route::post('/customer/customer_score', [ManageCustomer::class, 'customerScore'])->name('customer_score');
    Route::get('/manage_hold_customer', [ManageCustomer::class, 'HoldCustomer'])->name('customer-Hold');
  Route::match(['get', 'post'], '/hold_customer_filter', [ManageCustomer::class, 'HoldListFilter'])->name('customer-Hold');
  Route::post('/confirm_reactive', [ManageCustomer::class, 'reactiveCustomer'])->name('confirm_reactive');
  
  // Route::get('/manage_customer', [ManageCustomer::class, 'Index'])->name('customer-manage_customer');
  
  Route::match(['get', 'post'],'/manage_customer', [ManageCustomer::class, 'Index'])->name('customer-manage_customer');
  
  Route::get('/customer/customer_add/{id}', [ManageCustomer::class, 'customer_add'])->name('customer_add');
  Route::get('/customer/customer_add_course/{id}/{step?}', [ManageCustomer::class, 'customer_add_course'])->name('customer-add-course');
  Route::get('get_referralList', [ManageCustomer::class, 'ReferralList'])->name('get_referralList');
  Route::get('get_referralcustomerList', [ManageCustomer::class, 'ReferralCustomerList'])->name('get_referralcustomerList');
  Route::get('get_referralstaffList', [ManageCustomer::class, 'ReferralStaffList'])->name('get_referralstaffList');
  Route::get('get_referralstaffPostList', [ManageCustomer::class, 'ReferralStaffPostList'])->name('get_referralstaffPostList');
  Route::get('/customer/customer_invoice_print/{id}/{print_id}', [ManageCustomer::class, 'customer_invoice'])->name('customer-invoice');
  Route::get('/customer/old_customer_invoice_print/{id}/{print_id}', [ManageCustomer::class, 'old_customer_invoice'])->name('old-customer-invoice');
  Route::post('/customer/customer_view', [ManageCustomer::class, 'customer_view'])->middleware('auth')->name('customer-view');
  Route::post('/customer/customer_save', [ManageCustomer::class, 'customerSave'])->name('customer_save');
  Route::post('/customer/customer_course_save', [ManageCustomer::class, 'customerCourseSave'])->name('customer_course_save');
//   Route::get('/customer/customer_view/{id}', [ManageCustomer::class, 'customer_view'])->name('customer-view');
  Route::get('/customer/customer_edit/{id}', [ManageCustomer::class, 'customer_edit'])->name('customer_edit');
  Route::post('/customer/customer_update', [ManageCustomer::class, 'customer_update'])->name('customer_update');
  Route::get('/customer/batch_add_course/{id}', [ManageCustomer::class, 'customer_batch_add'])->name('customer-manage_customer');

  Route::post('/customer/customer_batch_update', [ManageCustomer::class, 'customer_batch_update'])->name('customer_batch_update');
  
  Route::post('get_combined_course', [ManageCustomer::class, 'CombinedCourse'])->name('get_combined_course');
  Route::get('/getCourse_list', [ManageCustomer::class, 'getCourse_list']);
  
  Route::post('/customer/change_course_offline/', [ManageCustomer::class, 'change_course_offline'])->name('change_course_offline');
  Route::post('/customer/change_course_online/', [ManageCustomer::class, 'change_course_Online'])->name('change_course_online');
  Route::post('/change_course_online/{id}', [ManageCustomer::class, 'change_course_Online']);
  Route::post('/change_course_mode', [ManageCustomer::class, 'change_course_mode'])->name('change_course_mode');
  Route::match(['get', 'post'],'/pay_edit_online/{id}', [ManageCustomer::class, 'PayEditOnline'])->name('pay_edit_online');
  Route::get('/customer/course_online/{id}', [ManageCustomer::class, 'online_course'])->name('customer-manage_payment');
  Route::post('/customer_hold', [ManageCustomer::class, 'customerHold'])->name('customer_hold');
  // vasanth
  Route::get('/customer/change_batch', [ManageCustomer::class, 'customer_batch_change'])->name('customer-manage_customer');
  Route::get('/customer/customer_change_course/{id}', [ManageCustomer::class, 'customer_change_course'])->name('customer-manage_customer');
  Route::post('customer/encrypt', [ManageCustomer::class, 'encrypt_ids'])->name('customer/encrypt');
  Route::post('customer_course_change', [ManageCustomer::class, 'customer_course_change'])->name('customer_course_change');
  Route::get('getBatch_change_course', [ManageCustomer::class, 'getBatch_change_course'])->name('getBatch_change_course');
  Route::get('/customer/drop_course/{id}', [ManageCustomer::class, 'customer_drop_course'])->name('customer-manage_customer');
  Route::post('customer/student_attendance_amount', [ManageCustomer::class, 'student_attendance_amount'])->name('customer/student_attendance_amount');
  Route::post('customer_drop', [ManageCustomer::class, 'customer_drop'])->name('customer_drop');
  Route::get('/refund_eligibility', [ManageCustomer::class, 'refund_eligibility']);
  Route::get('/autocomplete_customer', [ManageCustomer::class, 'autocomplete_customer'])->name('autocomplete_customer');
  
   // Post Sale Customer
   Route::match(['get', 'post'],'/manage_customer_post_sale', [ManageCustomer::class, 'Post_sale_list'])->name('customer-manage_customer_post_sale');


  Route::match(['get', 'post'], '/customer/old_customer', [ManageCustomer::class, 'old_customer'])->name('customer-manage_customer');
  Route::get('/customer/old_customer_add/{id}', [ManageCustomer::class, 'old_customer_add'])->name('old_customer_add');
  Route::post('/customer/add_customer', [ManageCustomer::class, 'customerAdd'])->name('add_customer');
  Route::get('get_course_cus', [ManageCustomer::class, 'getCourses'])->name('get_course_cus');
  Route::post('old_customer_status_change', [ManageCustomer::class, 'old_customer_status_change'])->name('old_customer_status_change');

  // Drop List
  Route::get('/manage_customer_drop', [ManageCustomerDrop::class, 'Index'])->name('customer_drop_list');
  Route::match(['get', 'post'], '/manage_customer_drop_filter', [ManageCustomerDrop::class, 'list_filter'])->name('manage_customer_drop_filter');
  Route::post('customer_drop_status_change', [ManageCustomerDrop::class, 'customer_drop_status_change'])->name('customer_drop_status_change');
  // Refund List
  Route::get('/manage_customer_refund', [ManageCustomerRefund::class, 'Index'])->name('customer_refund_list');
  Route::match(['get', 'post'], '/manage_customer_refund_filter', [ManageCustomerRefund::class, 'list_filter'])->name('manage_customer_refund_filter');
  Route::post('customer_refund_status_change', [ManageCustomerRefund::class, 'customer_refund_bh_status_change'])->name('customer_refund_status_change');
  Route::post('customer_refund_ac_status_change', [ManageCustomerRefund::class, 'customer_refund_ac_status_change'])->name('customer_refund_ac_status_change');
  Route::post('customer_refunded_status_change', [ManageCustomerRefund::class, 'customer_refunded_status_change'])->name('customer_refunded_status_change');
  
  // akilan batch change
  Route::post('/assign-batch-selection', [ManageCustomer::class, 'selectedAssignBatch'])->name('assign-batch-selection');
  Route::get('/customer/customer_batch_change/{id}', [ManageCustomer::class, 'customer_batch_change'])->name('customer_batch_change');
  Route::get('/customer_batch_details', [ManageCustomer::class, 'customer_batch_details'])->name('customer_batch_details');
  Route::post('/customer/batch_change_update', [ManageCustomer::class, 'batch_change_update'])->name('batch_change_update');
  Route::get('get_batch_course', [ManageCustomer::class, 'getBatchCourse'])->name('get_batch_course');
  Route::delete('/customer_delete/{id}', [ManageCustomer::class, 'Delete']);
  Route::post('/customer_status/{id}', [ManageCustomer::class, 'Status']);
  Route::get('get_course_sub_category', [ManageCustomer::class, 'getSubcatgory'])->name('get_course_sub_category');
  Route::get('get_batch', [ManageCustomer::class, 'getBatch'])->name('get_batch');
  Route::get('get_course_pay', [ManageCustomer::class, 'getCoursePay'])->name('get_course_pay');
  Route::get('get_course_type_pay', [ManageCustomer::class, 'getCourseTypePay'])->name('get_course_type_pay');
  Route::get('get_batch_pay', [ManageCustomer::class, 'getBatchpay'])->name('get_batch_pay');
  Route::get('get_batch_pay_course', [ManageCustomer::class, 'getBatchpayCourse'])->name('get_batch_pay_course');
  Route::post('get_payment_calculation', [ManageCustomer::class, 'getPaymentCalculation'])->name('get_payment_calculation');
  Route::get('get_userstaff', [ManageCustomer::class, 'getuserStaff'])->name('get_userstaff');
  Route::get('get_customer', [ManageCustomer::class, 'getCustomer'])->name('get_customer');
  Route::post('/store-batch-selection', [ManageCustomer::class, 'saveSelectedBatch'])->name('store-batch-selection');
  Route::post('/store-batch-selection-course', [ManageCustomer::class, 'saveSelectedBatchCourse'])->name('store-batch-selection-course');
  //   Change branch
  Route::post('/change-branch', [ManageCustomer::class, 'changeBranch'])->name('change-branch');
  Route::post('/change-role', [ManageCustomer::class, 'changeRole'])->name('change-role');
  Route::post('/get-users-by-role', [ManageCustomer::class, 'getUsersByRole'])->name('get-users-by-role');
  Route::post('/change-user', [ManageCustomer::class, 'changeUser'])->name('change-user');
  Route::get('get_couponcode', [ManageCustomer::class, 'get_couponcode'])->name('get_couponcode');



  Route::get('get_customer_course', [ManageCustomer::class, 'getCustomerCourse'])->name('get_customer_course');
  Route::post('add_payment', [ManageCustomer::class, 'add_payment']);
   Route::post('/customer/update_customer', [ManageCustomer::class, 'update_old_customer'])->name('update_customer');
  Route::get('/customer/old_customer_edit/{id}', [ManageCustomer::class, 'old_customer_edit'])->name('old_customer_edit');
  
  // free slot toolbar by akilan
 Route::match(['get', 'post'],'/toolbar_calculator', [ToolbarCalculator::class, 'index'])->name('toolbar_calculator');
  Route::post('/toolbar_filter', [ToolbarCalculator::class, 'toolbar_filter'])->name('toolbar_filter');
  Route::get('/cus_lead_details', [ManageCustomer::class, 'LeadDetails'])->name('cus_lead_details');

  // Header atte
  Route::get('/staff_attendance', [StaffAttendanceToday::class, 'index'])->name('staff_attendance');

  // If you also want to support GET requests for the same route
  Route::get('/customer/payment/{id}', [ManageCustomer::class, 'customer_add_payment'])->name('customer-manage_payment');

  Route::get('/customer/customer_view', [ManageCustomer::class, 'customer_view'])->name('customer-view');

  Route::get('/cuatomer_add/{id}', [ManageCustomer::class, 'CustomerAdd']);

  Route::match(['get', 'post'], '/pay_edit/{id}', [ManageCustomer::class, 'PayEdit']);
  Route::post('/pay_update/{id}', [ManageCustomer::class, 'PayUpdate']);
  
  Route::post('/pay_remainder_message', [ManageCustomer::class, 'payRemainderMessage'])->name('pay_remainder_message');


  Route::post('/free_shd_update/{id}', [ManageCustomer::class, 'FreeScheduleUpdate']);

  Route::post('/fs_request/{id}', [ManageCustomer::class, 'RequestUpdate']);
  Route::match(['get', 'post'], '/customer_list_filter', [ManageCustomer::class, 'list_filter'])->name('customer_list_filter');

  // Main Menu Starts
  Route::match(['get', 'post'],'/marketing', [ManageMarketing::class, 'index'])->name('marketing-manage-marketing');
  Route::get('/manage_marketing/verify_activity_edit/{id}', [ManageMarketing::class, 'verify_activity_edit'])->name('marketing-manage-marketing');
  Route::get('/manage_marketing/verify_activity/{id}', [ManageMarketing::class, 'verify_activity'])->name('marketing-manage-marketing');
  Route::get('/manage_marketing/view_activity/{id}', [ManageMarketing::class, 'view_activity'])->name('marketing-manage-marketing_view');


  //dropdwon code
  Route::get('type_dropdown/{id}', [MarketingType::class, 'Listdropdown'])->name('type_dropdown');
  Route::get('/zone_dropdown', [Zone::class, 'Listdropdown'])->name('zone_dropdown');
  Route::get('/zone_dropdown_area', [ManageMarketing::class, 'zoneget'])->name('zone_dropdown_area');
  Route::get('/vendor_dropdown', [Vendor::class, 'Listdropdown'])->name('vendor_dropdown');
  Route::post('/add_marketing', [ManageMarketing::class, 'Add'])->name('add_marketing');
  Route::get('/marketing_campaign_edit/{id}', [ManageMarketing::class, 'Edit'])->name('edit_marketing_campaign');
  Route::post('/marketing_update', [ManageMarketing::class, 'Update'])->name('marketing_update');
  Route::post('/marketing_verifiy_activity', [ManageMarketing::class, 'marketing_verifiy_activity_Update'])->name('marketing_verifiy_activity');
  Route::delete('/marketing_campaign_delete/{id}', [ManageMarketing::class, 'Delete']);
  Route::post('/marketing_campaign_status/{id}', [ManageMarketing::class, 'Status']);

  
  
  // Marketting Zone
  Route::get('/branch_drop_down', [Branch::class, 'List'])->name('branch_drop_down');
  Route::get('/settings/marketing/area', [Area::class, 'index'])->name('settings-marketing');
  Route::post('/add_marketing_area', [Area::class, 'Add'])->name('add_marketing_area');
  Route::post('/marketing_area_update', [Area::class, 'Update'])->name('marketing_area_update');
  Route::post('/marketing_area_status/{id}', [Area::class, 'Status']);
  Route::delete('/marketing_area_delete/{id}', [Area::class, 'Delete']);

  Route::get('/settings/marketing/zone', [Zone::class, 'index'])->name('settings-marketing');
  Route::post('/add_marketing_zone', [Zone::class, 'Add'])->name('add_marketing_zone');
  Route::post('/marketing_zone_update', [Zone::class, 'Update'])->name('marketing_zone_update');
  Route::post('/marketing_zone_status/{id}', [Zone::class, 'Status']);
  Route::delete('/marketing_zone_delete/{id}', [Zone::class, 'Delete']);


  //Marketting Vendor
  Route::get('/settings/marketing/vendor', [Vendor::class, 'index'])->name('settings-marketing');
  Route::post('/settings/marketing/vendor', [Vendor::class, 'Add'])->name('add_marketing_vendor');
  Route::post('/marketing_vendor_update', [Vendor::class, 'Update'])->name('marketing_vendor_update');
  Route::delete('/marketing_vendor_delete/{id}', [Vendor::class, 'Delete']);
  Route::post('/marketing_vendor_status/{id}', [Vendor::class, 'Status']);
  
  
  // job category - placement updates change by akmax
  Route::get('/settings/placements/Job_category', [JobCategory::class, 'index'])->name('settings-placements');
  Route::get('/Job_category', [JobCategory::class, 'List'])->name('Job_category');
  Route::post('/add_job_category', [JobCategory::class, 'Add'])->name('add_job_category');
  Route::get('/job-category-edit/{id}', [JobCategory::class, 'Edit']);
  Route::post('/job-category-update/{id}', [JobCategory::class, 'Update']);
  Route::delete('/job-category-delete/{id}', [JobCategory::class, 'Delete']);
  Route::post('/job-category-status/{id}', [JobCategory::class, 'Status']);


 // jobsubcategory
  Route::get('/settings/placements/Job_subcategory', [JobSubCategory::class, 'index'])->name('settings-placements');
  Route::get('Job_subcategory', [JobSubCategory::class, 'List'])->name('Job_subcategory');
  Route::post('/add_Job_subcategory', [JobSubCategory::class, 'Add'])->name('add_Job_subcategory');
  Route::get('/Job-subcategory-edit/{id}', [JobSubCategory::class, 'Edit']);
  Route::post('/Job-subcategory-update', [JobSubCategory::class, 'Update'])->name('Job_subcategory_update');
  Route::delete('/Job-subcategory-delete/{id}', [JobSubCategory::class, 'Delete']);
  Route::post('/Job-subcategory-status/{id}', [JobSubCategory::class, 'Status']);
  
  
      // job_skill_tag
      Route::get('/settings/placements/job_skill_tag', [JobSkillTag::class, 'index'])->name('settings-placements');
      Route::get('/job_skill_tag', [JobSkillTag::class, 'List'])->name('job_skill_tag');
      Route::post('/add_job_skill_tag', [JobSkillTag::class, 'Add'])->name('add_job_skill_tag');
      Route::get('/job_skill_tag_edit/{id}', [JobSkillTag::class, 'Edit']);
      Route::post('/job_skill_tag_update/{id}', [JobSkillTag::class, 'Update']);
      Route::delete('/job_skill_tag_delete/{id}', [JobSkillTag::class, 'Delete']);
      Route::post('/job_skill_tag_status/{id}', [JobSkillTag::class, 'Status']);

      // job_role_tag
      Route::get('/settings/placements/job_role_tag', [JobRoleTag::class, 'index'])->name('settings-placements');
      Route::get('/job_role_tag', [JobRoleTag::class, 'List'])->name('job_role_tag');
      Route::post('/add_job_role_tag', [JobRoleTag::class, 'Add'])->name('add_job_role_tag');
      Route::get('/job_role_tag_edit/{id}', [JobRoleTag::class, 'Edit']);
      Route::post('/job_role_tag_update/{id}', [JobRoleTag::class, 'Update']);
      Route::delete('/job_role_tag_delete/{id}', [JobRoleTag::class, 'Delete']);
      Route::post('/job_role_tag_status/{id}', [JobRoleTag::class, 'Status']);
      
    // Exam Settings
    // Question Bank Category
    Route::get('/settings/exam/question_bank_category_setting', [QuestionBankCategorySetting::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_question_bank_category', [QuestionBankCategorySetting::class, 'Create'])->name('create_question_bank_category');
    Route::post('/status_question_bank/{id}', [QuestionBankCategorySetting::class, 'Status']);
    Route::delete('/delete_question_bank/{id}', [QuestionBankCategorySetting::class, 'Delete']);
    Route::post('/update_question_bank', [QuestionBankCategorySetting::class, 'Update'])->name('update_question_bank');

    // Exam Guidelines
    Route::get('/settings/exam/guidelines', [GuideLines::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_guidelines', [GuideLines::class, 'store'])->name('create_guidelines');

    // Exam Category
    Route::get('/settings/exam/exam_category', [ExamCategory::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_exam_category', [ExamCategory::class, 'Create'])->name('create_exam_category');
    Route::post('/status_exam_category/{id}', [ExamCategory::class, 'Status']);
    Route::delete('/delete_exam_category/{id}', [ExamCategory::class, 'Delete']);
    Route::post('/update_exam_category', [ExamCategory::class, 'Update'])->name('update_exam_category');
    Route::get('/list_exam_category', [ExamCategory::class, 'List']);

    // Exam Section
    Route::get('/settings/exam/exam_section', [ExamSection::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_exam_section', [ExamSection::class, 'Create'])->name('create_exam_section');
    Route::post('/status_exam_section/{id}', [ExamSection::class, 'Status']);
    Route::delete('/delete_exam_section/{id}', [ExamSection::class, 'Delete']);
    Route::post('/update_exam_section', [ExamSection::class, 'Update'])->name('update_exam_section');

    // Question Bank Type
    Route::get('/settings/exam/question_bank_type_setting', [QuestionBankTypeSetting::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_question_bank_type', [QuestionBankTypeSetting::class, 'Create'])->name('create_question_bank_type');
    Route::post('/status_question_bank_type/{id}', [QuestionBankTypeSetting::class, 'Status']);
    Route::delete('/delete_question_bank_type/{id}', [QuestionBankTypeSetting::class, 'Delete']);
    Route::post('/update_question_bank_type', [QuestionBankTypeSetting::class, 'Update'])->name('update_question_bank_type');

    // Job Role Schedule
    Route::get('/settings/exam/job_role_schedule', [JobRoleSchedule::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_exam_schedule', [JobRoleSchedule::class, 'Create'])->name('create_exam_schedule');
    Route::post('/status_exam_schedule/{id}', [JobRoleSchedule::class, 'Status']);
    Route::delete('/delete_job_role_schedule/{id}', [JobRoleSchedule::class, 'Delete']);
    Route::get('/edit_job_role_schedule/{id}', [JobRoleSchedule::class, 'Edit']);
    Route::get('/list_job_role_schedule/{id}', [JobRoleSchedule::class, 'list']);
    Route::get('/list_job_role_schedule_all', [JobRoleSchedule::class, 'list_all']);
    Route::post('/update_job_role_schedule', [JobRoleSchedule::class, 'Update'])->name('update_job_role_schedule');

    // Exam Badge 
    Route::get('/settings/exam/exam_badge', [ExamBadge::class, 'index'])->name('settings-exam-settings');
    Route::post('/create_exam_badge', [ExamBadge::class, 'Create'])->name('create_exam_badge');
    Route::post('/status_exam_badge/{id}', [ExamBadge::class, 'Status']);
    Route::delete('/delete_exam_badge/{id}', [ExamBadge::class, 'Delete']);
    Route::post('/update_exam_badge', [ExamBadge::class, 'Update'])->name('update_exam_badge');
    Route::get('/edit_exam_badge/{id}', [ExamBadge::class, 'Edit']);
    Route::get('/list_exam_badge', [ExamBadge::class, 'list']);
   

    //Manage Company
     Route::match(['get', 'post'], '/placements/manage_company', [ManageCompany::class, 'index'])->name('placements-manage-company');
     Route::post('update_placement_company', [ManageCompany::class, 'UpdateCompany'])->name('update_placement_company');
     Route::get('/authority_staff_list', [ManageCompany::class, 'Authority_staff_list'])->name('authority_staff_list');
    Route::post('add_placement_company', [ManageCompany::class, 'AddCompany'])->name('add_placement_company');
    Route::get('/company_view/{id}', [ManageCompany::class, 'View']);
      Route::get('/edit_placement_company/{id}', [ManageCompany::class, 'Edit']);
      Route::get('/company_list', [ManageCompany::class, 'List'])->name('placement_company_list');
    Route::post('/company_status/{id}', [ManageCompany::class, 'Status']);
    Route::delete('/company-delete/{id}', [ManageCompany::class, 'Delete']);
    Route::post('add_placement_jobs', [ManageCompany::class, 'AddJob'])->name('add_placement_jobs');
    Route::get('job_catogory_list', [ManageCompany::class, 'jobCategoryList'])->name('job_catogory_list');
    Route::get('job_role_list', [ManageCompany::class, 'getJobRolelist'])->name('job_role_list');
    Route::post('generate-ai-tags', [ManageCompany::class, 'generateAITags'])->name('generate-ai-tags');
    Route::post('/upload_company_mou', [ManageCompany::class, 'uploadMOU'])->name('upload_company_mou');
    Route::match(['get','post'],'/add_category_ajax', [ManageCompany::class, 'Add_category_list'])->name('add_category_ajax');
    
    // NewsBroadcast
  Route::get('/support/news_broadcast', [NewsBroadcast::class, 'index'])->name('support-news-broadcast');
  Route::get('/settings/add_news_broadcast', [NewsBroadcast::class, 'Add'])->name('support-news-broadcast');
  Route::post('/broadcast_template_create', [NewsBroadcast::class, 'saveTemplate'])->name('broadcast_template_create');
  Route::get('/edit_news_broadcast/{id}', [NewsBroadcast::class, 'Edit'])->name('support-news-broadcast');
  Route::post('/news_broadcast_update', [NewsBroadcast::class, 'Update'])->name('news_broadcast_update');
  Route::delete('/news_broadcast_update_delete/{id}', [NewsBroadcast::class, 'Delete'])->name('news_broadcast_update_delete');
  Route::post('/check_news_broadcast_dates', [NewsBroadcast::class, 'checkDates']);
  Route::post('/check_news_broadcast_datesEdit', [NewsBroadcast::class, 'checkDatesEdit']);
   Route::post('/news_broadcast_status_change/{id}', [NewsBroadcast::class, 'Status'])->name('news_broadcast_status_change');
   Route::get('/broadcast_theme_by_id', [NewsBroadcast::class, 'broadcastThemeById'])->name('broadcast_theme_by_id');
   Route::get('/news_broadcast_by_id', [NewsBroadcast::class, 'newsBroadcastById'])->name('news_broadcast_by_id');
   
    Route::get('/role_list_broadcast/{id}', [NewsBroadcast::class, 'role_list_broadcast']);
    Route::post('/update_broadcast_roles', [NewsBroadcast::class, 'Update_role'])->name('update_broadcast_roles');
    Route::post('/broadcast_roles_remove', [NewsBroadcast::class, 'removeRole'])->name('broadcast_roles_remove');
    
    Route::get('/branch_list_broadcast/{id}', [NewsBroadcast::class, 'branch_list_broadcast']);
    Route::post('/update_broadcast_branch', [NewsBroadcast::class, 'Update_branch'])->name('update_broadcast_branch');
    Route::post('/broadcast_branch_remove', [NewsBroadcast::class, 'removeBranch'])->name('broadcast_branch_remove');
    Route::get('/branch_list', [NewsBroadcast::class, 'branch_list'])->name('branch_list');
   
  //Broadcast Theme Setting
    Route::get('/settings/broadcast_theme', [BroadcastTheme::class, 'index'])->name('settings-broadcast-theme');
  Route::get('/settings/add_broadcast_theme', [BroadcastTheme::class, 'Add'])->name('settings-broadcast-theme');
  Route::post('/broadcast_theme_create', [BroadcastTheme::class, 'saveTemplate'])->name('broadcast_theme_create');
  Route::get('/edit_broadcast_theme/{id}', [BroadcastTheme::class, 'Edit'])->name('settings-broadcast-theme');
  Route::post('/broadcast_theme_update', [BroadcastTheme::class, 'Update'])->name('broadcast_theme_update');
  Route::delete('/broadcast_theme_update_delete/{id}', [BroadcastTheme::class, 'Delete'])->name('broadcast_theme_update_delete');
   Route::post('/broadcast_theme_status_change/{id}', [BroadcastTheme::class, 'Status'])->name('broadcast_theme_status_change');
    

    
    // manage Job
    Route::match(['get','post'],'/placements/manage_jobs', [ManageJobs::class, 'index'])->name('placements-manage-jobs');
    Route::get('/job_view/{id}', [ManageJobs::class, 'View']);
    Route::get('/job_details/{id}', [ManageJobs::class, 'JobDetails']);
    Route::get('/student_list', [ManageJobs::class, 'AllStudentList'])->name('student_list');
    Route::post('/job_status/{id}', [ManageJobs::class, 'Status']);
    Route::delete('/job-delete/{id}', [ManageJobs::class, 'Delete']);
    Route::post('add_interested_student', [ManageJobs::class, 'AddInterestStudent'])->name('add_interested_student');
    Route::post('/update_last_pay_date/{id}', [ManageJobs::class, 'UpdateLastPayDate']);




    // manage Placement
    Route::match(['get','post'],'/placements/manage_placement', [ManagePlacement::class, 'index'])->name('placements-manage-placement');
    Route::post('/placement_status/{id}', [ManagePlacement::class, 'Status']);
    Route::match(['get', 'post'],'/get_place_reassign_details/{id}', [ManagePlacement::class, 'GetReassignDetails']);
    Route::post('/re_assign_placements', [ManagePlacement::class, 'Reassign_placements'])->name('re_assign_placements');
    
    Route::get('/placed_students', [PlacedStudents::class, 'index'])->name('placements-manage-placed-students');
  Route::get('/placedReport', [PlacedStudents::class, 'placedReport']);
  Route::get('/CourseTypeList', [PlacedStudents::class, 'CourseTypeList']);
  Route::get('/JobRoleList', [PlacedStudents::class, 'JobRoleList']);
  Route::post('/student/update-profile-pic', [PlacedStudents::class, 'updateProfilePic']);
  

       // manage Candidate
       Route::match(['get', 'post'], '/placements/manage_candidate', [ManageCandidate::class, 'index'])->name('placements-manage-candidate');
       Route::match(['get', 'post'], '/placements/manage_applicants', [ManageCandidate::class, 'Applicants'])->name('placements-manage-candidate');
       Route::get('/apply_job_list', [ManageCandidate::class, 'applyJobList'])->name('apply_job_list');
       Route::get('/get_educate_details/{id}', [ManageCandidate::class, 'GetEducateDetails']);
      Route::post('/update_educate_details', [ManageCandidate::class, 'UpdateEducateDetails'])->name('update_educate_details');
      Route::match(['get', 'post'],'/get_coursetype_list', [ManageCandidate::class, 'CourseTypeList'])->name('get_coursetype_list');
      Route::match(['get', 'post'],'/get_course_list', [ManageCandidate::class, 'CourseList'])->name('get_course_list');
      Route::match(['get', 'post'],'/placements/manage_candidate/upcoming', [ManageCandidate::class, 'Upcoming_candidate'])->name('manage_candidate_upcoming');



    //Manage Interview
     Route::match(['get','post'],'/placements/manage_interview', [ManageInterview::class, 'index'])->name('placements-manage-interview');
    Route::get('/interview_job_view/{id}', [ManageInterview::class, 'View']);
    Route::get('/interview_job_details/{id}', [ManageInterview::class, 'JobDetails']);
    Route::post('/job_status_update/{id}', [ManageInterview::class, 'JobStatusChange']);
    Route::post('update_interested_status', [ManageInterview::class, 'updateInterviewStatus'])->name('update_interested_status');




     // Placements Reasons
    Route::get('/settings/placements_events/placement_reasons', [PlacementReasons::class, 'index'])->name('settings-placements');
    Route::get('/placement_reasons', [PlacementReasons::class, 'List'])->name('placement_reasons');
    Route::post('/placement_reason_add', [PlacementReasons::class, 'Add'])->name('add_placement_reason');
    Route::get('/placement_reason_edit/{id}', [PlacementReasons::class, 'Edit'])->name('placement_reason_edit');
    Route::post('/placement_reason_update', [PlacementReasons::class, 'Update'])->name('placement_reason_update');
    Route::delete('/placement_reason_delete/{id}', [PlacementReasons::class, 'Delete']);
    Route::post('/placement_reason_status/{id}', [PlacementReasons::class, 'Status']);


  // CampaignStatus
  Route::get('/settings/marketing/campaign_status', [CampaignStatus::class, 'index'])->name('settings-marketing');
  Route::post('/settings/marketing/campaign_status', [CampaignStatus::class, 'Add'])->name('add_camp_status');
  Route::post('/camp_status_update', [CampaignStatus::class, 'Update'])->name('camp_status_update');
  Route::post('/campaign_status/{id}', [CampaignStatus::class, 'Status']);
  Route::delete('/campaign_status/{id}', [CampaignStatus::class, 'Delete']);


  // CampaignChecklist
  Route::get('/settings/marketing/campaign_checklist', [CampaignChecklist::class, 'index'])->name('settings-marketing');
  Route::post('/add_camp_checklist', [CampaignChecklist::class, 'Add'])->name('add_camp_checklist');
  Route::post('/campaign_checklist_update', [CampaignChecklist::class, 'Update'])->name('campaign_checklist_update');
  Route::post('/campaign_status/{id}', [CampaignChecklist::class, 'Status']);
  Route::delete('/campaign_status/{id}', [CampaignChecklist::class, 'Delete']);

  //JOB DIRECTORY
  Route::get('/placements/job_directory', [JobDirectory::class, 'index']);
  //Route::get('/placements/job_directory/create_job_directory', [JobDirectory::class, 'create_job_directory'])->name('placements-job-directory');
  Route::get('/placements/job_directory/update_job_directory', [JobDirectory::class, 'update_job_directory'])->name('placements-job-directory');
  Route::get('interivew_rounds', [JobDirectory::class, 'InterviewChecklist_list'])->name('interivew_rounds');

  //JOB DIRECTORY METHOD CALL
  Route::get('/placements/job_directory/create_job_directory/{id}', [JobDirectory::class, 'hr_directory_details'])->name('placements-hr-directory');

  Route::post('/add_job_directory', [JobDirectory::class, 'Add'])->name('add_job_directory');
  Route::post('/get_company_branch_drop/{id}', [JobDirectory::class, 'get_company_branch_drop'])->name('get_company_branch_drop');
  Route::get('/get_job_directory/{id}', [JobDirectory::class, 'get_job_directory']);
  // Route::post('/edit_job_directory', [JobDirectory::class, 'Edit'])->name('edit_job_directory');
  Route::get('/placements/job_directory/edit/{id}', [JobDirectory::class, 'job_edit']);
  Route::post('/update_job_directory', [JobDirectory::class, 'Update'])->name('update_job_directory');
  Route::post('/job_directory_status/{id}', [JobDirectory::class, 'Status']);
  Route::delete('/job_directory/{id}', [JobDirectory::class, 'Delete']);
  Route::get('/view_job_directory', [JobDirectory::class, 'View'])->name('view_job_directory');

  // Route::get('job_directory', [JobDirectory::class, 'List'])->name('job_directory');
  //new routes
  Route::get('/placements/job_directory/create_job_directory/{id}', [JobDirectory::class, 'hr_directory_details'])->name('placements-hr-directory');
  // Route::get('/job_based_on_course_type', [JobDirectory::class, 'Job_based_on_course_type']);
  // Route::get('/job_name_based_on_industry_type/{id}', [JobDirectory::class, 'Job_List'])->name('job_name');
  Route::get('/job_name_based_on_industry_type/{id}', [JobDirectory::class, 'Job_List'])->name('job_name');


  //hr directory
  Route::get('/placements/hr_directory', [HRDirectory::class, 'index'])->name('placements-hr-directory');
  Route::get('/placements/hr_directory/create_directory', [HRDirectory::class, 'create_directory'])->name('create_directory');
  Route::get('/placements/hr_directory/update_directory/{id}', [HRDirectory::class, 'update_directory'])->name('placements-hr-directory');

  Route::post('/update_hr_directory', [HRDirectory::class, 'Update'])->name('update_hr_directory');

  // HR DIRECTORY METHOD CALL
  Route::post('/add_hr_directory', [HRDirectory::class, 'Add'])->name('add_hr_directory');
  Route::get('/get_hr_directory/{id}', [HRDirectory::class, 'get_hr_directory']);
  Route::get('/view_hr_directory', [HRDirectory::class, 'View'])->name('view_hr_directory');
  Route::post('/hr_directory_status/{id}', [HRDirectory::class, 'Status']);
  Route::delete('/hr_directory_delete/{id}', [HRDirectory::class, 'Delete']);
  Route::delete('/hr_directory_branch_delete_all/{id}', [HRDirectory::class, 'Delete_all_branch']);
  Route::delete('/hr_branch_delete/{id}', [HRDirectory::class, 'hr_branch_delete']);
  //job directory dropdown
  // Route::get('/industry_type', [IndustryJobName::class, 'List'])->name('industry_type');
  Route::get('hr_directory', [HRDirectory::class, 'List'])->name('hr_directory');
  Route::get('hr_directory_branch', [HRDirectory::class, 'List_branch'])->name('hr_directory_branch');



  // main menu Placements & Training
  Route::get('/placements/placements_training', [PlacementsTraining::class, 'index'])->name('placements-placements-training');
  Route::get('/placements/placements_training/student_view/{id}', [PlacementsTraining::class, 'placements_student_view'])->name('placements-placements-training');
  Route::get('/placements/placements_training_followup', [PlacementsTraining::class, 'placements_training_followup'])->name('placements-placements-training');
  Route::get('/placement/placement-student-excel', [PlacementsTraining::class, 'StudentExportExcel']);
  
  Route::get('placement_checklist/{id}', [PlacementsTraining::class, 'Placement_checklist'])->name('placement_checklist');
  Route::post('update_interview_checklist', [PlacementsTraining::class, 'Placement_update'])->name('update_interview_checklist');
  // main menu Placements & Training
  Route::get('/placements/placements_training', [PlacementsTraining::class, 'index'])->name('placements-placements-training');
  Route::get('/placement_training_view', [PlacementsTraining::class, 'placements_view'])->name('placement_training_view');
Route::get('/jobtableGet/{id}', [PlacementsTraining::class, 'JobtableGet'])->name('tableGet');

  // Main Menu placement Events
    Route::match(['get', 'post'],'/events', [Events::class, 'index'])->name('marketing-events');
    Route::get('/events/event_add', [Events::class, 'event_add'])->name('marketing-events');
    Route::get('/events/event_edit/{id}', [Events::class, 'event_edit'])->name('marketing-events');
    Route::get('/events/event_view', [Events::class, 'View_event'])->name('marketing-events');
    Route::post('/Placement_event_add', [Events::class, 'Add'])->name('Placement_event_add');
    Route::post('/Placement_event_update', [Events::class, 'Update'])->name('Placement_event_update');
    Route::post('/event_status/{id}', [Events::class, 'Status']);
    Route::post('/active_event/{id}', [Events::class, 'ActiveEvent']);
    Route::delete('/event-delete/{id}', [Events::class, 'Delete']);
    Route::get('/events/event-excel', [Events::class, 'EventExportExcel']);
    Route::post('/event_list_filter', [Events::class, 'list_filter'])->name('event_list_filter');
    Route::post('/event_drop', [Events::class, 'DropEvent'])->name('event_drop');
    
    Route::post('/send_event_certificate', [Events::class, 'sendEventCertificate'])->name('send_event_certificate');
    
    Route::post('/update_attendance', [Events::class, 'updateAttendance']);
    
      Route::match(['get', 'post'], '/events/event_feedback', [Events::class, 'eventWise'])->name('marketing-event-feedback');
  Route::match(['get', 'post'], '/events/participant_feedback', [Events::class, 'participantWise'])->name('marketing-participant-feedback');
  Route::get('/events_feedback_participant/{id}', [Events::class, 'eventFeedbackParticipant']);
  Route::get('/events_feedback_all/{id}', [Events::class, 'eventFeedbackAll']);
  Route::get('/categoryEventList', [Events::class, 'catgeoryList']);
  Route::get('/eventList', [Events::class, 'EventList']);
   


    // event updates
    Route::post('add_event_Participant', [Events::class, 'AddEventParticipant'])->name('add_event_Participant');
    Route::get('view_event/{id}', [Events::class, 'View']);
    Route::get('view_event_updated/{id}', [Events::class, 'ViewUpdated']);
    Route::post('/event_status_update/{id}', [Events::class, 'eventStatusChange']);
    Route::get('/branch_all_staff', [Events::class, 'AllBranchStaffList'])->name('branch_all_staff');
    Route::get('/event/event_certificate_print/{id}',[Events::class, 'EventCertificate']);
    Route::match(['get', 'post'], '/qr_event_scanners', [Events::class, 'Scanner_view'])->name('qr.scanner.event');
    Route::match(['get', 'post'], '/qr.scanner.event.map', [Events::class, 'MultiMap'])->name('qr.scanner.event.map');
    
      Route::post('add_poster_template', [Events::class, 'AddPosterTemplate'])->name('add_poster_template');
      Route::get('/poster_list_by_type', [Events::class, 'PosterListByType'])->name('poster_list_by_type');
      Route::get('/get_poster_preview', [Events::class, 'get_poster_data'])->name('get_poster_preview');
  // brand
  Route::get('/settings/course/brand', [Brand::class, 'index'])->name('settings-course');
  Route::get('brand', [Brand::class, 'List'])->name('brand');
  Route::post('/add_brand', [Brand::class, 'Add'])->name('add_brand');
  Route::get('/brand_edit/{id}', [Brand::class, 'Edit']);
  Route::post('/brand_update/{id}', [Brand::class, 'Update']);
  Route::delete('/brand_delete/{id}', [Brand::class, 'Delete']);
  Route::post('/brand_status/{id}', [Brand::class, 'Status']);



  // Group
  Route::get('/settings/course/group', [Group::class, 'index'])->name('settings-course');
  Route::get('group', [Group::class, 'List'])->name('group');
  Route::post('/add_group', [Group::class, 'Add'])->name('add_group');
  Route::get('/group_edit/{id}', [Group::class, 'Edit']);
  Route::post('/group_update/{id}', [Group::class, 'Update']);
  Route::delete('/group_delete/{id}', [Group::class, 'Delete']);
  Route::post('/group_status/{id}', [Group::class, 'Status']);


  // Jobroll
  Route::get('/settings/course/job_role', [JobRoll::class, 'index'])->name('settings-course');
  Route::get('job_roll', [JobRoll::class, 'List'])->name('job_roll');
  Route::post('/add_job_roll', [JobRoll::class, 'Add'])->name('add_job_roll');
  Route::get('/job_roll_edit/{id}', [JobRoll::class, 'Edit']);
  Route::post('/job_roll_update/{id}', [JobRoll::class, 'Update']);
  Route::delete('/job_roll_delete/{id}', [JobRoll::class, 'Delete']);
  Route::post('/job_roll_status/{id}', [JobRoll::class, 'Status']);


  // PreSkillSet
  Route::get('/settings/course/pre_skill_set', [PreSkillSet::class, 'index'])->name('settings-course');
  Route::get('pre_skill_set', [PreSkillSet::class, 'List'])->name('pre_skill_set');
  Route::post('/add_pre_skill_set', [PreSkillSet::class, 'Add'])->name('add_pre_skill_set');
  Route::get('/pre_skill_set_edit/{id}', [PreSkillSet::class, 'Edit']);
  Route::post('/pre_skill_set_update/{id}', [PreSkillSet::class, 'Update']);
  Route::delete('/pre_skill_set_delete/{id}', [PreSkillSet::class, 'Delete']);
  Route::post('/pre_skill_set_status/{id}', [PreSkillSet::class, 'Status']);

  // CourseCategory
  Route::get('/settings/course/course_category', [CourseCategory::class, 'index'])->name('settings-course');
  Route::get('course_category', [CourseCategory::class, 'List'])->name('course_category');
  Route::post('/add-course-category', [CourseCategory::class, 'Add'])->name('add_course_category');
  Route::get('/course-category-edit/{id}', [CourseCategory::class, 'Edit']);
  Route::post('/course-category-update/{id}', [CourseCategory::class, 'Update']);
  Route::delete('/course-category-delete/{id}', [CourseCategory::class, 'Delete']);
  Route::post('/course-category-status/{id}', [CourseCategory::class, 'Status']);

  // CourseSubCategory
  Route::get('/settings/course/course_subcategory', [CourseSubCategory::class, 'index'])->name('settings-course');
  Route::get('sub_course_category', [CourseSubCategory::class, 'List'])->name('sub_course_category');
  Route::get('sub_course_category_customer', [CourseSubCategory::class, 'ListCustomer'])->name('sub_course_category_customer');
  Route::post('/add-course-subcategory', [CourseSubCategory::class, 'Add'])->name('add_course_subcategory');
  Route::get('/course-subcategory-edit/{id}', [CourseSubCategory::class, 'Edit']);
  Route::post('/course-subcategory-update', [CourseSubCategory::class, 'Update'])->name('course_subcategory_update');
  Route::delete('/course-subcategory-delete/{id}', [CourseSubCategory::class, 'Delete']);
  Route::post('/course-subcategory-status/{id}', [CourseSubCategory::class, 'Status']);
  
   // Batch Checklist
  Route::get('/settings/common/batch_checklist/batch_checklist_list', [BatchChecklist::class, 'index'])->name('settings-common');
  Route::post('/add_batch_checklist', [BatchChecklist::class, 'Add'])->name('add_batch_checklist');
  Route::post('/batch_checklist_update', [BatchChecklist::class, 'Update'])->name('batch_checklist_update');
  Route::post('/batch_checklist_status/{id}', [BatchChecklist::class, 'Status'])->name('batch_checklist_status');
  Route::delete('/batch_checklist_delete/{id}', [BatchChecklist::class, 'Delete'])->name('batch_checklist_delete');


    Route::get('/base_settings/cloudcall_api_setup', [CloudCallApiSetup::class, 'index'])->name('settings-base-settings');
    Route::post('/create_cloudcall_api_setup', [CloudCallApiSetup::class, 'create'])->name('create_cloudcall_api_setup');
    Route::post('/update_cloudcall_api_setup', [CloudCallApiSetup::class, 'Update'])->name('update_cloudcall_api_setup');
    Route::post('/status_cloudcall_api_setup/{id}', [CloudCallApiSetup::class, 'Status']);
    Route::delete('/delete_cloudcall_api_setup/{id}', [CloudCallApiSetup::class, 'Delete']);
    Route::get('/edit_cloudcall_api_setup/{id}', [CloudCallApiSetup::class, 'Edit']);
    Route::get('/delete_data_cloudcall_api_setup/{id}', [CloudCallApiSetup::class, 'deleteData']);
    Route::get('/list_cloudcall_api_setup', [CloudCallApiSetup::class, 'list']);

  // CourseType
  Route::get('/settings/course/course_type', [CourseType::class, 'index'])->name('settings-course');
  Route::get('course_type', [CourseType::class, 'List'])->name('course_type');
  Route::get('get_course_type_data/{id}', [CourseType::class, 'get_course_type_data'])->name('get_course_type_data');
  Route::post('/add-course-type', [CourseType::class, 'Add'])->name('add_course_type');
  Route::get('/course-type-edit/{id}', [CourseType::class, 'Edit'])->name('course_type_edit');
  Route::post('/course-type-update', [CourseType::class, 'Update'])->name('course_type_update');
  Route::delete('/course-type-delete/{id}', [CourseType::class, 'Delete']);
  Route::post('/course-type-status/{id}', [CourseType::class, 'Status']);
  
  // CourseSummary
  Route::get('/settings/course/summary_reason', [SummaryReason::class, 'index'])->name('settings-course');
  Route::post('/summary_reason_add', [SummaryReason::class, 'Add'])->name('summary_reason_add');
  Route::get('summary_reason_list', [SummaryReason::class, 'List'])->name('summary_reason_list');
  Route::get('/summary_reason_edit/{id}', [SummaryReason::class, 'Edit']);
  Route::post('/summary_reason_status/{id}', [SummaryReason::class, 'Status']);
  Route::delete('/summary_reason_delete/{id}', [SummaryReason::class, 'Delete']);
  Route::post('/summary_reason_update', [SummaryReason::class, 'Update'])->name('summary_reason_update');
  


  // LeadSource
  Route::get('/settings/sales/lead_source', [LeadSource::class, 'index'])->name('settings-sales');
  Route::get('lead_source', [LeadSource::class, 'List'])->name('lead_source');
  Route::post('/add-lead-source', [LeadSource::class, 'Add'])->name('add_lead_source');
  Route::get('/lead-source-edit/{id}', [LeadSource::class, 'Edit'])->name('lead_source_edit');
  Route::post('/lead-source-update', [LeadSource::class, 'Update'])->name('lead_source_update');
  Route::delete('/lead-source-delete/{id}', [LeadSource::class, 'Delete']);
  Route::post('/lead-source-status/{id}', [LeadSource::class, 'Status']);

  // LeadType
  Route::get('/settings/sales/lead_type', [LeadType::class, 'index'])->name('settings-sales');
  Route::get('lead_type', [LeadType::class, 'List'])->name('lead_type');
  Route::post('/add-lead-type', [LeadType::class, 'Add'])->name('add_lead_type');
  Route::get('/lead-type-edit/{id}', [LeadType::class, 'Edit'])->name('lead_type_edit');
  Route::post('/lead-type-update', [LeadType::class, 'Update'])->name('lead_type_update');
  Route::delete('/lead-type-delete/{id}', [LeadType::class, 'Delete']);
  Route::post('/lead-type-status/{id}', [LeadType::class, 'Status']);


  // LeadPotential
  Route::get('/settings/sales/lead_potential_type', [LeadPotentialType::class, 'index'])->name('settings-sales');
  Route::post('/add-potential_type', [LeadPotentialType::class, 'Add'])->name('add_lead_potential_type');
  Route::get('/lead-potential_type-edit/{id}', [LeadPotentialType::class, 'Edit'])->name('lead_potential_type_edit');
  Route::post('/lead-potential_type-update', [LeadPotentialType::class, 'Update'])->name('lead_potential_type_update');
  Route::delete('/lead-potential_type-delete/{id}', [LeadPotentialType::class, 'Delete']);
  Route::post('/lead-potential_type-status/{id}', [LeadPotentialType::class, 'Status']);


  // Lead status
  Route::get('/settings/sales/lead_status', [LeadStatus::class, 'index'])->name('settings-sales');
  Route::get('/lead_status', [LeadStatus::class, 'List'])->name('lead_status');
  Route::post('/add_lead_status', [LeadStatus::class, 'Add'])->name('add_lead_status');
  Route::get('/lead_status_edit/{id}', [LeadStatus::class, 'Edit']);
  Route::post('/lead_status_update', [LeadStatus::class, 'Update'])->name('lead_status_update');
  Route::delete('/lead_status_delete/{id}', [LeadStatus::class, 'Delete']);
  Route::post('/lead_status_status/{id}', [LeadStatus::class, 'Status']);
  Route::post('/lead_status_lg_status/{id}', [LeadStatus::class, 'Legend_Status']);



  // customer type
  Route::get('/settings/sales/customer_type', [CustomerType::class, 'index'])->name('settings-sales');
  Route::get('/customer_type', [CustomerType::class, 'List'])->name('customer_type');

  Route::post('/add_customer_type', [CustomerType::class, 'Add'])->name('add_customer_type');
  Route::get('/customer_type_edit/{id}', [CustomerType::class, 'Edit']);
  Route::post('/customer_type_update/{id}', [CustomerType::class, 'Update']);
  Route::delete('/customer_type_delete/{id}', [CustomerType::class, 'Delete']);
  Route::post('/customer_type_status/{id}', [CustomerType::class, 'Status']);


  // customer type option
  Route::get('/settings/sales/customer_option', [CustomerTypeOption::class, 'index'])->name('settings-sales-customerlist');
  Route::get('/settings/customer_option/customer_option_add', [CustomerTypeOption::class, 'AddIndex'])->name('settings-sales');
  Route::get('/settings/customer_option/customer_option_edit', [CustomerTypeOption::class, 'EditIndex'])->name('settings-sales');
  Route::get('/customer_type_option', [CustomerTypeOption::class, 'List'])->name('customer_type_option');
  Route::get('/customer_type_option_list/{id}', [CustomerTypeOption::class, 'ListDisplay'])->name('customer_type_option_list');
  Route::post('/add_customer_type_option', [CustomerTypeOption::class, 'Add'])->name('add_customer_type_option');
  Route::get('/customer_type_option_edit/{id}', [CustomerTypeOption::class, 'Edit']);
  Route::get('/customer_type_option_view/{id}', [CustomerTypeOption::class, 'View']);
  Route::post('/customer_type_option_update/{id}', [CustomerTypeOption::class, 'Update']);
  Route::delete('/customer_type_option_delete/{id}', [CustomerTypeOption::class, 'Delete']);
  Route::post('/customer_type_option/{id}', [CustomerTypeOption::class, 'Status']);


  // manage lead Appointment
  Route::get('/sales/manage_lead_appointment', [ManageLeadAppointment::class, 'index'])->name('sales-manage-lead-appointment');
  Route::get('/sales_staff', [ManageLeadAppointment::class, 'SalesStaffList'])->name('sales_staff');
  Route::get('/dept_staff', [ManageLeadAppointment::class, 'DeptStaffList'])->name('dept_staff');
  Route::post('/lead_appointment_add', [ManageLeadAppointment::class, 'Add'])->name('lead_appointment_add');
  Route::post('/lead_appointment_update', [ManageLeadAppointment::class, 'Update'])->name('lead_appointment_update');
  Route::post('/complete_appointment_update', [ManageLeadAppointment::class, 'updateCompleteAppointment'])->name('complete_appointment_update');
  Route::post('/cancel_appointment_update', [ManageLeadAppointment::class, 'updateCancelAppointment'])->name('cancel_appointment_update');
  Route::post('/re_appointment_update', [ManageLeadAppointment::class, 'updateReAppointment'])->name('re_appointment_update');
  Route::get('/autocomplete_lead_name', [ManageLeadAppointment::class, 'autocomplete_lead'])->name('autocomplete_lead_name');
   Route::match(['get', 'post'], '/appointment_filter', [ManageLeadAppointment::class, 'filter_appointment'])->name('appointment_filter');

  // Payment option
  Route::get('/settings/sales/payment_mode_option', [PaymentModeOption::class, 'index'])->name('settings-sales-payment-mode-option');
  Route::get('/settings/payment_mode_option/payment_mode_option_add', [PaymentModeOption::class, 'AddIndex'])->name('settings-sales');
  Route::match(['get', 'post'], '/settings/payment_mode_option/payment_mode_option_edit/{id}', [PaymentModeOption::class, 'EditIndex'])->name('settings-sales');
  Route::get('/payment_option_list/{id}', [PaymentModeOption::class, 'ListDisplay'])->name('payment_option_list');
  Route::post('/add_payment_option', [PaymentModeOption::class, 'Add'])->name('add_payment_option');
  Route::post('/edit_payment_mode_options', [PaymentModeOption::class, 'Update'])->name('edit_payment_mode_options');
  Route::delete('/payment_mode_option_delete/{id}', [PaymentModeOption::class, 'Delete']);
  Route::post('/payment_mode_option_status/{id}', [PaymentModeOption::class, 'Status']);

  Route::get('/settings/course/course_action', [CourseAction::class, 'index'])->name('settings-course');
  Route::post('/add-course-action', [CourseAction::class, 'Add'])->name('add_course_action');
  Route::get('/course-action-edit/{id}', [CourseAction::class, 'Edit'])->name('course_action_edit');
  Route::post('/course-action-update/{id}', [CourseAction::class, 'Update']);
  Route::delete('/course-action-delete/{id}', [CourseAction::class, 'Delete']);
  Route::post('/course-action-status/{id}', [CourseAction::class, 'Status']);

  // CourseActionType
  Route::get('/settings/course/course_action_type', [CourseActionType::class, 'index'])->name('settings-course');
  Route::get('/course_action_type_list', [CourseActionType::class, 'List'])->name('course_action_type_list');
  Route::post('/add-course-action-type', [CourseActionType::class, 'Add'])->name('add_course_action_type');
  Route::get('/course-action-type-edit/{id}', [CourseActionType::class, 'Edit'])->name('course_action_type_edit');
  Route::post('/course-action-type-update/{id}', [CourseActionType::class, 'Update']);
  Route::delete('/course-action-type-delete/{id}', [CourseActionType::class, 'Delete']);
  Route::post('/course-action-type-status/{id}', [CourseActionType::class, 'Status']);


  // slot_types
  Route::get('/settings/batch/slot_types', [SlotTypes::class, 'index'])->name('settings-batch');
  Route::get('/slot_types_list', [SlotTypes::class, 'List'])->name('slot_types_list');
  Route::post('/add_slot_types', [SlotTypes::class, 'Add'])->name('add_slot_types');
  Route::get('/slot_types_edit/{id}', [SlotTypes::class, 'Edit']);
  Route::post('/slot_types-update/{id}', [SlotTypes::class, 'Update']);
  Route::delete('/slot_types-delete/{id}', [SlotTypes::class, 'Delete']);
  Route::post('/slot_types-status/{id}', [SlotTypes::class, 'Status']);


  // Batch Cancel Reason
  Route::get('/settings/batch/cancel_reason/cancel_reason_list', [ExtensionCancelReason::class, 'index'])->name('settings-batch');
  Route::post('/cancel_reason_add', [ExtensionCancelReason::class, 'Add'])->name('cancel_reason_add');
  Route::get('cancel_reason_list', [ExtensionCancelReason::class, 'List'])->name('cancel_reason_list');
  Route::post('/cancel_reason_status/{id}', [ExtensionCancelReason::class, 'Status']);
  Route::delete('/cancel_reason_delete/{id}', [ExtensionCancelReason::class, 'Delete']);
  Route::post('/cancel_reason_update', [ExtensionCancelReason::class, 'Update'])->name('cancel_reason_update');

  // slot
  Route::get('/settings/batch/slot', [Slot::class, 'index'])->name('settings-batch');
  Route::get('/slot_list', [Slot::class, 'List'])->name('slot_list');
  Route::post('/add_slot', [Slot::class, 'Add'])->name('add_slot');
  Route::get('/slot_edit/{id}', [Slot::class, 'Edit']);
  Route::post('/slot_update/{id}', [Slot::class, 'Update']);
  Route::delete('/slot_delete/{id}', [Slot::class, 'Delete']);
  Route::post('/slot_status/{id}', [Slot::class, 'Status']);
  
  // slotOld
  Route::get('/settings/batch/slot_old', [SlotOld::class, 'index'])->name('settings-batch');
  Route::get('/slot_list_old', [SlotOld::class, 'List'])->name('slot_old_list');
  Route::post('/add_slot_old', [SlotOld::class, 'Add'])->name('add_slot_old');
  Route::get('/slot_edit_old/{id}', [SlotOld::class, 'Edit']);
  Route::post('/slot_update_old/{id}', [SlotOld::class, 'Update']);
  Route::delete('/slot_delete_old/{id}', [SlotOld::class, 'Delete']);
  Route::post('/slot_status_old/{id}', [SlotOld::class, 'Status']);


  // facility
  Route::get('/settings/batch/facility', [Facility::class, 'index'])->name('settings-batch');
  Route::get('/facility', [Facility::class, 'List'])->name('facility');
  Route::post('/add_facility', [Facility::class, 'Add'])->name('add_facility');
  Route::get('/facility_edit/{id}', [Facility::class, 'Edit']);
  Route::post('/facility_update/{id}', [Facility::class, 'Update']);
  Route::delete('/facility_delete/{id}', [Facility::class, 'Delete']);
  Route::post('/facility_status/{id}', [Facility::class, 'Status']);

  // classroom
  Route::get('/settings/batch/classroom', [ClassRoom::class, 'index'])->name('settings-batch');
  Route::get('/classroom', [ClassRoom::class, 'List'])->name('classroom');
  Route::post('/add_classroom', [ClassRoom::class, 'Add'])->name('add_classroom');
  Route::get('/classroom_edit/{id}', [ClassRoom::class, 'Edit']);
  Route::post('/classroom_update/{id}', [ClassRoom::class, 'Update']);
  Route::delete('/classroom_delete/{id}', [ClassRoom::class, 'Delete']);
  Route::post('/classroom_status/{id}', [ClassRoom::class, 'Status']);
  
  // Settings category Question

  Route::get('/settings/batch/feedback/feedback_list', [FeedbackStudentQuestion::class, 'Index'])->name('settings-batch-feedback_question_list');

  Route::get('/settings/batch/feedback/feedback_questions_add', [FeedbackStudentQuestion::class, 'feedbackQuestionsAdd'])->name('feedback_questions_add');

  Route::get('/settings/batch/feedback/feedback_questions_edit', [FeedbackStudentQuestion::class, 'feedbackQuestionsEdit'])->name('settings-batch-feedback-questions-edit');
    Route::post('/feedback_question_add', [FeedbackStudentQuestion::class, 'Add'])->name('feedback_student_question_add');

 

  Route::get('/feedback_questions_edit/{id}', [FeedbackStudentQuestion::class, 'Category_edit'])->name('feedback_edit');

  Route::post('/update_feedback_question', [FeedbackStudentQuestion::class, 'Update'])->name('update_feedback_question');

  Route::post('/category_question_status/{id}', [FeedbackStudentQuestion::class, 'Status']);

  Route::delete('/category_question_delete/{id}', [FeedbackStudentQuestion::class, 'Delete']);



  // job_time
  Route::get('/settings/hrm/job_time', [JobTime::class, 'index'])->name('settings-hrm');
  Route::post('/add_job_time', [JobTime::class, 'Add'])->name('add_job_time');
  Route::get('/job_time_edit/{id}', [JobTime::class, 'Edit']);
  Route::post('/job_time_update/{id}', [JobTime::class, 'Update']);
  Route::delete('/job_time_delete/{id}', [JobTime::class, 'Delete']);
  Route::post('/job_time_status/{id}', [JobTime::class, 'Status']);

  // knowledge_tag
  Route::get('/settings/hrm/knowledge_tag', [KnowledgeTag::class, 'index'])->name('settings-hrm');
  Route::get('/knowledge_tag', [KnowledgeTag::class, 'List'])->name('knowledge_tag');
  Route::post('/add_knowledge_tag', [KnowledgeTag::class, 'Add'])->name('add_knowledge_tag');
  Route::get('/knowledge_tag_edit/{id}', [KnowledgeTag::class, 'Edit']);
  Route::post('/knowledge_tag_update/{id}', [KnowledgeTag::class, 'Update']);
  Route::delete('/knowledge_tag_delete/{id}', [KnowledgeTag::class, 'Delete']);
  Route::post('/knowledge_tag_status/{id}', [KnowledgeTag::class, 'Status']);


  // knowledge_level
  Route::get('/settings/course/knowledge_level', [KnowledgeLevel::class, 'index'])->name('settings-course');
  Route::get('/knowledge_level', [KnowledgeLevel::class, 'List'])->name('knowledge_level');
  Route::post('/add_knowledge_level', [KnowledgeLevel::class, 'Add'])->name('add_knowledge_level');
  Route::get('/knowledge_level_edit/{id}', [KnowledgeLevel::class, 'Edit']);
  Route::post('/knowledge_level_update/{id}', [KnowledgeLevel::class, 'Update']);
  Route::delete('/knowledge_level_delete/{id}', [KnowledgeLevel::class, 'Delete']);
  Route::post('/knowledge_level_status/{id}', [KnowledgeLevel::class, 'Status']);


  Route::get('/settings/placements/interview_checklist', [InterviewCheckList::class, 'index'])->name('settings-placements');
  Route::get('/interview_checklist', [InterviewCheckList::class, 'List'])->name('interview_checklist');
  Route::post('/add_interview_checklist', [InterviewCheckList::class, 'Add'])->name('add_interview_checklist');
  Route::get('/interview_checklist_edit/{id}', [InterviewCheckList::class, 'Edit'])->name('interview_checklist_edit');
  Route::post('/interview_checklist_update', [InterviewCheckList::class, 'Update'])->name('interview_checklist_update');
  Route::delete('/interview_checklist_delete/{id}', [InterviewCheckList::class, 'Delete']);
  Route::post('/interview_checklist_status/{id}', [InterviewCheckList::class, 'Status']);

  // Interview Type
  Route::get('/settings/placements/interview_type', [InterviewType::class, 'index'])->name('settings-placements');
  Route::get('/interview_type', [InterviewType::class, 'List'])->name('interview_type');
  Route::post('/add_interview_type', [InterviewType::class, 'Add'])->name('add_interview_type');
  Route::get('/interview_type_edit/{id}', [InterviewType::class, 'Edit'])->name('interview_type_edit');
  Route::post('/interview_type_update', [InterviewType::class, 'Update'])->name('interview_type_update');
  Route::delete('/interview_type_delete/{id}', [InterviewType::class, 'Delete']);
  Route::post('/interview_type_status/{id}', [InterviewType::class, 'Status']);

  // Event Category
  Route::get('/settings/placements/event_category', [EventCategory::class, 'index'])->name('settings-placements');
  Route::get('/event_category', [EventCategory::class, 'List'])->name('event_category');
  Route::post('/add_event_category', [EventCategory::class, 'Add'])->name('add_event_category');
  Route::get('/event_category_edit/{id}', [EventCategory::class, 'Edit'])->name('event_category_edit');
  Route::post('/event_category_update', [EventCategory::class, 'Update'])->name('event_category_update');
  Route::delete('/event_category_delete/{id}', [EventCategory::class, 'Delete']);
  Route::post('/event_category_status/{id}', [EventCategory::class, 'Status']);

  // Event Type
  Route::get('/settings/placements/event_type', [EventType::class, 'index'])->name('settings-placements');
  Route::get('/event_type', [EventType::class, 'List'])->name('event_type');
  Route::post('/add_event_type', [EventType::class, 'Add'])->name('add_event_type');
  Route::get('/event_type_edit/{id}', [EventType::class, 'Edit'])->name('event_type_edit');
  Route::post('/event_type_update', [EventType::class, 'Update'])->name('event_type_update');
  Route::delete('/event_type_delete/{id}', [EventType::class, 'Delete']);
  Route::post('/event_type_status/{id}', [EventType::class, 'Status']);

  // Attachment
  Route::get('/settings/hrm/attachment', [Attachment::class, 'index'])->name('settings-hrm');
  Route::get('/attachment', [Attachment::class, 'List'])->name('attachment');
  Route::post('/add_attachment', [Attachment::class, 'Add'])->name('add_attachment');
  Route::get('/attachment_edit/{id}', [Attachment::class, 'Edit']);
  Route::post('/attachment_update/{id}', [Attachment::class, 'Update']);
  Route::delete('/attachment_delete/{id}', [Attachment::class, 'Delete']);
  Route::post('/attachment_status/{id}', [Attachment::class, 'Status']);


  // Settings Lead Question Inner Page
  Route::get('/settings/sales/lead_question_list', [LeadQuestion::class, 'Index'])->name('settings-sales-lead_question_list');
  Route::get('/settings/sales/lead_question/lead_question_add', [LeadQuestion::class, 'LeadQuestionAdd'])->name('settings-sales');
  Route::get('/settings/sales/lead_question/lead_question_edit', [LeadQuestion::class, 'LeadQuestionEdit'])->name('lead_question_edit');
  Route::get('/lead_question_edit/{id}', [LeadQuestion::class, 'LeadQuestion_edit'])->name('LeadQuestion_edit');
  Route::post('/update_lead_question', [LeadQuestion::class, 'Update'])->name('update_lead_question');
  Route::post('/lead_question_status/{id}', [LeadQuestion::class, 'Status']);
  Route::delete('/lead_question_delete/{id}', [LeadQuestion::class, 'Delete']);

  Route::post('/lead_question_add', [LeadQuestion::class, 'Add'])->name('lead_question_add');
  Route::get('/lead_question', [LeadQuestion::class, 'List'])->name('lead_question');


  // Settings category Question
  Route::get('/settings/counsellor/category_question_list', [CategoryQuestion::class, 'Index'])->name('settings-counsellor-category_question_list');
  Route::get('/settings/counsellor/category_question/cat_questions_add', [CategoryQuestion::class, 'cat_questions_add'])->name('cat_questions_add');
  Route::get('/settings/counsellor/cat_questions_edit', [CategoryQuestion::class, 'cat_questions_edit'])->name('settings-counsellor-cat-questions-edit');

  Route::post('/category_question_add', [CategoryQuestion::class, 'Add'])->name('category_question_add');
  Route::get('/category_question', [CategoryQuestion::class, 'List'])->name('category_question');
  Route::get('/cat_questions_edit/{id}', [CategoryQuestion::class, 'Category_edit'])->name('Category_edit');
  Route::post('/update_category_question', [CategoryQuestion::class, 'Update'])->name('update_category_question');
  Route::post('/category_question_status/{id}', [CategoryQuestion::class, 'Status']);
  Route::delete('/category_question_delete/{id}', [CategoryQuestion::class, 'Delete']);


  // Settings Assessment Question
  Route::get('/settings/counsellor/assessment', [SelfAssessment::class, 'Index'])->name('settings-counsellor-assessment_ques_list');
  Route::get('/settings/counsellor/category_assessment/ass_questions_add', [SelfAssessment::class, 'ass_questions_add'])->name('ass_questions_add');
  Route::get('/assessment_ques_edit/{id}', [SelfAssessment::class, 'assessment_edit'])->name('assessment_edit');

  Route::post('/ass_question_add', [SelfAssessment::class, 'Add'])->name('ass_question_add');
  Route::post('/update_self_assessment', [SelfAssessment::class, 'Update'])->name('update_self_assessment');
  Route::post('/self_assessment_status/{id}', [SelfAssessment::class, 'Status']);
  Route::delete('/self_assessment_delete/{id}', [SelfAssessment::class, 'Delete']);


  //course question
  Route::get('/settings/counsellor/course_question_list', [CourseQuestion::class, 'index'])->name('settings-counsellor-course_question_list');
  Route::get('/course_question_list', [CourseQuestion::class, 'List'])->name('course_question_list');
  Route::get('/sub_category_list', [CourseQuestion::class, 'SubCategoryList'])->name('sub_category_list');
  Route::get('/sub_course_list/{id}', [CourseQuestion::class, 'SubCatCourseList'])->name('sub_course_list');
  Route::get('/sub_course_list_all', [CourseQuestion::class, 'SubCatCourseListAll'])->name('sub_course_list_all');
  Route::get('/settings/counsellor/course_questions_add', [CourseQuestion::class, 'CourseQuestionAdd'])->name('course_questions_add');
  Route::get('/settings/counsellor/course_questions_edit', [CourseQuestion::class, 'CourseQuestionEdit'])->name('settings-counsellor-cat-questions-edit');

  // CourseQuestion
  Route::post('/course_questions_add', [CourseQuestion::class, 'Add'])->name('course_questions_add');
  Route::get('/course_question_edit/{id}', [CourseQuestion::class, 'Edit'])->name('course_question_edit');
  Route::get('/course_analysis_ques_edit/{id}', [CourseQuestion::class, 'Course_edit'])->name('Course_edit');
  Route::post('/update_course_question', [CourseQuestion::class, 'Update'])->name('update_course_question');
  Route::delete('/course_question_delete/{id}', [CourseQuestion::class, 'Delete']);
  Route::post('/course_question_status/{id}', [CourseQuestion::class, 'Status']);

  // Settings Counsellor Feedback Question
  Route::get('/settings/counsellor/feedback_quest_list', [FeedbackQuestion::class, 'Index'])->name('settings-counsellor-feedback_question_list');
  Route::get('/settings/counsellor/feedback_question/feedback_quest_add', [FeedbackQuestion::class, 'feedback_question_add'])->name('feedback_question_add');
  // Route::get('/settings/counsellor/ass_questions_edit', [SelfAssessment::class, 'cat_questions_edit'])->name('settings-counsellor-cat-questions-edit');
  Route::post('/feed_quest_add', [FeedbackQuestion::class, 'Add'])->name('feed_quest_add');
  Route::get('/feedback_ques_edit/{id}', [FeedbackQuestion::class, 'FeedBack_edit'])->name('FeedBack_edit');
  Route::post('/update_feedback_question', [FeedbackQuestion::class, 'Update'])->name('update_feedback_question');
  Route::post('/feedback_quest_list/{id}', [FeedbackQuestion::class, 'Status']);
  Route::delete('/feedback_quest_list/{id}', [FeedbackQuestion::class, 'Delete']);

  //offerZone
  Route::get('/settings/counsellor/OfferZone', [Offerzone::class, 'index'])->name('settings-counsellor');
  Route::get('/OfferZone', [Offerzone::class, 'List'])->name('OfferZone');
  Route::post('/add-offerzone', [Offerzone::class, 'Add'])->name('add_offerzone');
  Route::get('/offerzone-edit/{id}', [Offerzone::class, 'Edit'])->name('offerzone_edit');
  Route::post('/offerzone-update', [Offerzone::class, 'Update'])->name('offerzone_update');
  Route::delete('/offerzone-delete/{id}', [Offerzone::class, 'Delete']);
  Route::post('/offerzone-status/{id}', [Offerzone::class, 'Status']);



  // Settings Counsellor Feedback Question
  Route::get('/settings/counsellor/feedback_quest_list', [FeedbackQuestion::class, 'Index'])->name('settings-counsellor-feedback_question_list');
  Route::get('/settings/counsellor/feedback_question/feedback_quest_add', [FeedbackQuestion::class, 'feedback_question_add'])->name('feedback_question_add');
  // Route::get('/settings/counsellor/ass_questions_edit', [SelfAssessment::class, 'cat_questions_edit'])->name('settings-counsellor-cat-questions-edit');

  Route::post('/feed_quest_add', [FeedbackQuestion::class, 'Add'])->name('feed_quest_add');
  Route::post('/feedback_quest_list/{id}', [FeedbackQuestion::class, 'Status']);
  Route::delete('/feedback_quest_list/{id}', [FeedbackQuestion::class, 'Delete']);
  // ProgressLevel
  Route::get('/settings/sales/progress_level', [ProgressLevel::class, 'index'])->name('settings-sales');
  Route::post('/add-progress_level', [ProgressLevel::class, 'Add'])->name('add_progress_level');
  Route::get('/progress_level-edit/{id}', [ProgressLevel::class, 'Edit'])->name('progress_level_edit');
  Route::post('/progress_level-update', [ProgressLevel::class, 'Update'])->name('progress_level_update');
  Route::delete('/progress_level-delete/{id}', [ProgressLevel::class, 'Delete']);
  Route::post('/progress_level-status/{id}', [ProgressLevel::class, 'Status']);

  // Country
  Route::get('/country', [Country::class, 'List'])->name('country');

  // state

  Route::get('/state', [State::class, 'List'])->name('state');

  // city

  Route::get('/city', [City::class, 'List'])->name('city');

  // timezone

  Route::get('/time_zone', [TimeZone::class, 'List'])->name('time_zone');

  // CurrenctFormat
  Route::get('/settings/sales/currency_format', [CurrencyFormat::class, 'index'])->name('settings-sales-currency_format');
  Route::get('/currency_format', [CurrencyFormat::class, 'List'])->name('currency_format');
  Route::post('/add_currency_format', [CurrencyFormat::class, 'Add'])->name('add_currency_format');
  Route::get('/currency_format_edit/{id}', [CurrencyFormat::class, 'Edit'])->name('currency_format_edit');
  Route::post('/currency_format_update', [CurrencyFormat::class, 'Update'])->name('currency_format_update');
  Route::delete('/currency_format_delete/{id}', [CurrencyFormat::class, 'Delete']);
  Route::post('/currency_format_status/{id}', [CurrencyFormat::class, 'Status']);

  // // Settings Course Question
  // Route::get('/settings/counsellor/category_question_list', [CategoryQuestion::class, 'Index'])->name('settings-counsellor-category_question_list');
  // Route::get('/settings/counsellor/cat_questions_add', [CategoryQuestion::class, 'cat_questions_add'])->name('settings-counsellor-cat-questions-add');
  // Route::get('/settings/counsellor/cat_questions_edit', [CategoryQuestion::class, 'cat_questions_edit'])->name('settings-counsellor-cat-questions-edit');




  // // Settings customer Question
  // Route::get('/settings/counsellor/category_question_list', [CategoryQuestion::class, 'Index'])->name('settings-counsellor-category_question_list');
  // Route::get('/settings/counsellor/cat_questions_add', [CategoryQuestion::class, 'cat_questions_add'])->name('cat-questions-add');
  // Route::get('/settings/counsellor/cat_questions_edit', [CategoryQuestion::class, 'cat_questions_edit'])->name('settings-counsellor-cat-questions-edit');

  // type_of_exam
  Route::get('/settings/exam/type_of_exam', [TypeofExam::class, 'index'])->name('settings-exam');
  Route::post('/add_type_of_exam', [TypeofExam::class, 'Add'])->name('add_type_of_exam');
  Route::post('/type_of_exam_update', [TypeofExam::class, 'Update'])->name('type_of_exam_update');
  Route::delete('/type_of_exam_delete/{id}', [TypeofExam::class, 'Delete']);
  Route::post('/type_of_exam_status/{id}', [TypeofExam::class, 'Status']);


  // Question bank category
  Route::get('/settings/exam/question_bank_category', [QuestionBankCategory::class, 'index'])->name('settings-exam');
  Route::post('/add_question_bank_category', [QuestionBankCategory::class, 'Add'])->name('add_question_bank_category');
  Route::post('/question_bank_category_update', [QuestionBankCategory::class, 'Update'])->name('question_bank_category_update');
  Route::delete('/question_bank_category_delete/{id}', [QuestionBankCategory::class, 'Delete']);
  Route::post('/question_bank_category_status/{id}', [QuestionBankCategory::class, 'Status']);



  // QuestionBankType
  Route::get('/settings/exam/question_bank_type', [QuestionBankType::class, 'index'])->name('settings-exam');
  Route::post('/add_question_bank_type', [QuestionBankType::class, 'Add'])->name('add_question_bank_type');
  Route::post('/question_bank_type_update', [QuestionBankType::class, 'Update'])->name('question_bank_type_update');
  Route::delete('/question_bank_type_delete/{id}', [QuestionBankType::class, 'Delete']);
  Route::post('/question_bank_type_status/{id}', [QuestionBankType::class, 'Status']);



  // Branch
    // Branch
  Route::match(['get', 'post'],'/branch', [Branch::class, 'index'])->name('branch_manage-branch');
  Route::match(['get', 'post'], '/branch_terminal_list', [Branch::class, 'terminalList'])->name('branch_manage-branch');
  Route::get('/branch_students/{branch_id}',             [Branch::class, 'terminalBranchCustomer'])->name('branch_manage-branch_students');
  Route::match(['get', 'post'],'/branch_list_filter', [Branch::class, 'list_filter'])->name('branch_manage-branch');
  Route::post('/branch_status/{id}', [Branch::class, 'Status']);
  Route::delete('/branch_delete/{id}', [Branch::class, 'Delete']);
  Route::get('/branch_view/{id}', [Branch::class, 'View']);
  Route::get('/create_branch_franchise', [Branch::class, 'create_branch_franchise'])->name('branch');
  Route::get('/update_branch_franchise/{id}', [Branch::class, 'Edit']);
  Route::post('/add_branch_franchise', [Branch::class, 'Add'])->name('add_branch_franchise');
  Route::post('/update_branch_franchise', [Branch::class, 'Update'])->name('update_branch_franchise');
  Route::post('/add_staff_assignee', [Branch::class, 'Add_staff_assignee'])->name('add_staff_assignee');
  Route::post('/branch/Add_staff_branch', [Branch::class, 'Add_staff_branch'])->name('Add_staff_branch');
  Route::get('/bran_drop_down', [Branch::class, 'List'])->name('bran_drop_down');
  Route::get('/get_course_branch', [Branch::class, 'get_course_by_type'])->name('get_course_branch');
  Route::get('/job_position_branch', [Branch::class, 'Job_postion_to_Cug'])->name('job_position_branch');
  Route::get('/get_staff_data_based_on_role/{id}', [Branch::class, 'Staff_based_on_role'])->name('get_staff_data_based_on_role');
  Route::post('/add_cug_to_staff', [Branch::class, 'Add_staff_Cug_modal'])->name('add_cug_to_staff');
  Route::post('/edit_cug_to_staff', [Branch::class, 'Update_staff_Cug_modal'])->name('edit_cug_to_staff');
  Route::get('/cre_dropdown_for_branch', [Branch::class, 'Cre_Dropdown'])->name('cre_dropdown_for_branch');
  Route::get('/cug_edit_fetch', [Branch::class, 'Cug_Edit_Fetch'])->name('cug_edit_fetch');
  Route::delete('/cug_delete', [Branch::class, 'Cug_delete'])->name('cug_delete');
  Route::get('/check_unique_mobile_number', [Branch::class, 'checkUniqueMobileNumber'])->name('check_unique_mobile_number');
  
    Route::get('/staff_access_app/{id}', [Branch::class, 'StaffAccessApp']);
    Route::post('update_staff_access', [Branch::class, 'updateStaffAccess'])->name('update_staff_access');
    
  Route::get('/check_unique_mail_id', [Branch::class, 'checkUniqueMailId'])->name('check_unique_mail_id');
  Route::get('/mail_cug_edit_fetch', [Branch::class, 'Cug_Mail_Edit_Fetch'])->name('mail_cug_edit_fetch');
  Route::post('/add_mail_cug_to_staff', [Branch::class, 'Add_staff_Cug_mail'])->name('add_mail_cug_to_staff');
  Route::post('/edit_mail_cug_to_staff', [Branch::class, 'Update_staff_Cug_mail'])->name('edit_mail_cug_to_staff');
  Route::delete('/cug_delete_mail', [Branch::class, 'Cug_delete_mail'])->name('cug_delete_mail');
  
  
  
  
  Route::get('/get_branch_target/{id}', [Branch::class, 'getBranchTargets']);
    Route::get('/get_branch_alert/{id}', [Branch::class, 'getBranchAlert']);
    Route::get('/get_alert_list', [Branch::class, 'getBranchAlertList'])->name('get_alert_list');
   Route::get('/get_branch_manpower/{id}', [Branch::class, 'getBranchManPower']);
   Route::get('/get_manpower_list', [Branch::class, 'getmanpowerlist'])->name('get_manpower_list');
    Route::get('/get_branch_metrics/{id}', [Branch::class, 'getBranchMetrics']);
  Route::get('/get_branch_check_list/{id}', [Branch::class, 'getBranchChecklist'])->name('branch_manage-branch');
  Route::get('get_branch_target_metrics', [Branch::class, 'getBranchTargetsMetrics'])->name('get_branch_target_metrics');
 
   
    Route::get('/get_branch_checklist', [Branch::class, 'getCheckList'])->name('get_branch_checklist');
    Route::get('/get_branch_dashboard_metrics', [Branch::class, 'get_branch_dashboard_metrics'])->name('get_branch_dashboard_metrics');
    // Main Training Planner
  Route::match(['get', 'post'],'/training_planner', [TrainingPlanner::class, 'index'])->name('marketing-training-planner');
  Route::post('/training_filter_manage', [TrainingPlanner::class, 'list_filter'])->name('training_filter_manage');
  // Route::post('/training_status/{id}', [TrainingPlanner::class, 'Status']);
  // Route::delete('/training_delete/{id}', [TrainingPlanner::class, 'Delete']);
  // Route::post('/add_training', [TrainingPlanner::class, 'Add'])->name('add_training');
  // Route::get('/training_edit/{id}', [TrainingPlanner::class, 'Edit']);
  // Route::post('/update_training', [TrainingPlanner::class, 'Update'])->name('update_training');
  // Route::get('/get-all-staff', [TrainingPlanner::class, 'getAllStaff']);
  // Route::get('/get_branch_staff', [TrainingPlanner::class, 'get_branch_staff'])->name('get_branch_staff');
  // Route::get('/jobPosition', [TrainingPlanner::class, 'jobPosition'])->name('jobPosition');
  // Route::get('/branchList', [TrainingPlanner::class, 'branchList'])->name('branchList');
  // Route::get('/get-staff-excluding/{trainerId}', [TrainingPlanner::class, 'getStaffExcluding']);
  Route::get('/training_view_manage/{id}', [TrainingPlanner::class, 'View']);
  // Route::get('/training_attendance/{id}', [TrainingPlanner::class, 'Attendance']);
  // Route::get('/tableGet', [TrainingPlanner::class, 'tableGet'])->name('tableGet');
  // Route::post('/complete_training', [TrainingPlanner::class, 'completeTraining'])->name('complete_training');
  
      // Main Training Planner
    Route::match(['get', 'post'],'/branch_training', [ManageTraining::class, 'index'])->name('branch_manage-training-planner');
    Route::post('/training_filter', [ManageTraining::class, 'list_filter'])->name('training_filter');
    Route::post('/training_status/{id}', [ManageTraining::class, 'Status']);
    Route::delete('/training_delete/{id}', [ManageTraining::class, 'Delete']);
    Route::post('/add_training', [ManageTraining::class, 'Add'])->name('add_training');
    Route::get('/training_edit/{id}', [ManageTraining::class, 'Edit']);
    Route::post('/update_training', [ManageTraining::class, 'Update'])->name('update_training');
    Route::get('/get-all-staff', [ManageTraining::class, 'getAllStaff']);
    Route::get('/get_branch_staff', [ManageTraining::class, 'get_branch_staff'])->name('get_branch_staff');
    Route::get('/jobPosition', [ManageTraining::class, 'jobPosition'])->name('jobPosition');
    Route::get('/branchList', [ManageTraining::class, 'branchList'])->name('branchList');
    Route::get('/get-staff-excluding/{trainerId}', [ManageTraining::class, 'getStaffExcluding']);
    Route::get('/training_view/{id}', [ManageTraining::class, 'View']);
    Route::get('/training_attendance/{id}', [ManageTraining::class, 'Attendance']);
    Route::get('/tableGet', [ManageTraining::class, 'tableGet'])->name('tableGet');
    Route::post('/complete_training', [ManageTraining::class, 'completeTraining'])->name('complete_training');
    
    
    Route::match(['get', 'post'],'/Cronjob_Monitor', [CronjobMonitor::class, 'index'])->name('tools_manage-cronjob');
    Route::post('/CronjobStatusChange/{id}', [CronjobMonitor::class, 'Status']);
    Route::get('/cronjob_contact_details_transfer', [Cronjobs::class, 'CronjobContactDetailsTransfer'])->name('CronjobContactDetailsTransfer');
    Route::get('/branch-manage/cronjob-history/{id}', [CronjobMonitor::class, 'cronjobHistory'])->name('branch_manage-cronjob-history');
    Route::post('/add_cronjobs', [CronjobMonitor::class, 'Add'])->name('add_cronjobs');
    Route::post('/update_cronjobs', [CronjobMonitor::class, 'Update'])->name('update_cronjobs');
    Route::get('/cronjob_edit/{id}', [CronjobMonitor::class, 'Edit']);
  
    Route::get('/maintenance_mode', [MaintenanceMode::class, 'index'])->name('tools_manage-maintenance_mode');
    Route::post('/maintenance/toggle', [MaintenanceMode::class, 'toggle'])->name('maintenance.toggle');

    
    Route::get('/user_log', [UserLog::class, 'index'])->name('tools_manage-user_log');
    Route::get('/user_login_logs/list', [UserLog::class, 'List']);
    Route::post('/logs/clear', [UserLog::class, 'clearOldLogs']);

    Route::get('/call_log', [CallLog::class, 'index'])->name('tools_manage-call_log');
    Route::get('/team-call-report-ajax', [CallLog::class, 'List']);
    
    Route::get('/maintenance', [MaintenancePage::class, 'show'])->name('maintenance_page');
  
  
    // QR Coupo
  Route::match(['get', 'post'],'/branch_management/qr_coupon', [QrCoupon::class, 'index'])->name('marketing_manage-qr_coupon');
  Route::post('/redeem_coupon/{id}', [QrCoupon::class, 'redeemCoupon']);
  
 // Main Menu Starts
  Route::match(['get', 'post'],'/branch_campaign', [BranchCampaign::class, 'index'])->name('branch_manage_campaign');
  Route::get('/manage_marketing/verify_activity_edit/{id}', [BranchCampaign::class, 'verify_activity_edit'])->name('marketing-manage-marketing');
  Route::get('/manage_marketing/verify_activity/{id}', [BranchCampaign::class, 'verify_activity'])->name('marketing-manage-marketing');
  Route::get('/manage_marketing/view_activity/{id}', [BranchCampaign::class, 'view_activity'])->name('marketing-manage-marketing_view');
 
  
  //dropdwon code
  Route::get('type_dropdown/{id}', [MarketingType::class, 'Listdropdown'])->name('type_dropdown');
  Route::get('/zone_dropdown', [Zone::class, 'Listdropdown'])->name('zone_dropdown');
  Route::get('/zone_dropdown_area', [BranchCampaign::class, 'zoneget'])->name('zone_dropdown_area');
  Route::get('/vendor_dropdown', [Vendor::class, 'Listdropdown'])->name('vendor_dropdown');
  Route::post('/add_marketing', [BranchCampaign::class, 'Add'])->name('add_marketing');
  Route::get('/marketing_campaign_edit/{id}', [BranchCampaign::class, 'Edit'])->name('edit_marketing_campaign');
  Route::post('/marketing_update', [BranchCampaign::class, 'Update'])->name('marketing_update');
  Route::post('/marketing_verifiy_activity', [BranchCampaign::class, 'marketing_verifiy_activity_Update'])->name('marketing_verifiy_activity');
  Route::delete('/marketing_campaign_delete/{id}', [BranchCampaign::class, 'Delete']);
  Route::post('/marketing_campaign_status/{id}', [BranchCampaign::class, 'Status']);

  // Branchtype
  Route::get('/settings/branch_type/branch_type_list', [Branchtype::class, 'index'])->name('settings-branch');
  Route::get('/branch_type', [Branchtype::class, 'List'])->name('branch_type');
  Route::post('/add_branch_type', [Branchtype::class, 'Add'])->name('add_branch_type');
  Route::get('/branch_type_edit/{id}', [Branchtype::class, 'Edit'])->name('branch_type_edit');
  Route::post('/branch_type_update', [Branchtype::class, 'Update'])->name('branch_type_update');
  Route::delete('/branch_type_delete/{id}', [Branchtype::class, 'Delete']);
  Route::post('/branch_type_status/{id}', [Branchtype::class, 'Status']);

  // Documenttype
  Route::get('/settings/document_type/document_type_list', [Documenttype::class, 'index'])->name('settings-branch');
  Route::get('/document_type', [Documenttype::class, 'List'])->name('document_type');
  Route::post('/add_document_type', [Documenttype::class, 'Add'])->name('add_document_type');
  Route::get('/document_type_edit/{id}', [Documenttype::class, 'Edit'])->name('document_type_edit');
  Route::post('/document_type_update', [Documenttype::class, 'Update'])->name('document_type_update');
  Route::delete('/document_type_delete/{id}', [Documenttype::class, 'Delete']);
  Route::post('/document_type_status/{id}', [Documenttype::class, 'Status']);

  // Department
  Route::get('/settings/department/department_list', [Department::class, 'index'])->name('settings-branch');
  Route::get('/department', [Department::class, 'List'])->name('department');
  Route::post('/add_department', [Department::class, 'Add'])->name('add_department');
  Route::get('/department_edit/{id}', [Department::class, 'Edit'])->name('department_edit');
  Route::post('/department_update', [Department::class, 'Update'])->name('department_update');
  Route::delete('/department_delete/{id}', [Department::class, 'Delete']);
  Route::post('/department_status/{id}', [Department::class, 'Status']);



  //Sub  Department
  Route::get('/settings/sub_department/sub_department_list', [SubDepartment::class, 'index'])->name('sub_department_list');
  Route::get('/sub_department_list', [SubDepartment::class, 'List'])->name('sub_department_list');
  Route::get('/get_sub_department', [SubDepartment::class, 'Get_list'])->name('get_sub_department');
  Route::post('/add_sub_department', [SubDepartment::class, 'Add'])->name('add_sub_department');
  Route::get('/sub_department_edit/{id}', [SubDepartment::class, 'Edit'])->name('sub_department_edit');
  Route::post('/sub_department_update', [SubDepartment::class, 'Update'])->name('sub_department_update');
  Route::delete('/sub_department_delete/{id}', [SubDepartment::class, 'Delete']);
  Route::post('/sub_department_status/{id}', [SubDepartment::class, 'Status']);

  // IpConfig
  Route::get('/settings/ipconfig/ipconfig', [IpConfig::class, 'index'])->name('settings-branch');
  Route::get('/ip_config', [IpConfig::class, 'List'])->name('ip_config');
  Route::get('/ip_config_branch', [IpConfig::class, 'branch_List'])->name('ip_config_branch');
  Route::get('/ip_config_franchise', [IpConfig::class, 'franchise_List'])->name('ip_config_franchise');
  Route::post('/add_ip_config', [IpConfig::class, 'Add'])->name('add_ip_config');
  Route::post('/ip_config_update', [IpConfig::class, 'Update'])->name('ip_config_update');
  Route::delete('/ip_config_delete/{id}', [IpConfig::class, 'Delete']);
  Route::post('/ip_config_status/{id}', [IpConfig::class, 'Status']);

  // corse assigne
  Route::get('/settings/course_assigne/course_assigne_list', [CourseAssigne::class, 'index'])->name('settings-branch');
  Route::post('/add_course_assigne', [CourseAssigne::class, 'Add'])->name('add_course_assigne');
  Route::get('/course_assignee_edit/{id}', [CourseAssigne::class, 'Edit'])->name('course_assignee_edit');
  Route::post('/course_assigne_update', [CourseAssigne::class, 'Update'])->name('course_assigne_update');
  Route::delete('/branch_course_delete/{id}', [CourseAssigne::class, 'Delete']);
  Route::post('/branch_course_status/{id}', [CourseAssigne::class, 'Status']);


  // Ledger
  Route::get('/settings/accounts/ledger', [Ledger::class, 'index'])->name('settings-accounts-ledger');
  Route::get('ledger', [Ledger::class, 'List'])->name('ledger');
  Route::post('/add-ledger', [Ledger::class, 'Add'])->name('add_ledger');
  Route::get('/ledger-edit/{id}', [Ledger::class, 'Edit'])->name('ledger_edit');
  Route::post('/ledger-update', [Ledger::class, 'Update'])->name('ledger_update');
  Route::delete('/ledger-delete/{id}', [Ledger::class, 'Delete']);
  Route::post('/ledger-status/{id}', [Ledger::class, 'Status']);

  // SubLedger
  Route::get('/settings/accounts/subledger', [Subledger::class, 'index'])->name('settings-accounts-subledger');
  // Route::get('subledger', [SubLedger::class, 'List'])->name('subledger');
  Route::post('/add-subledger', [SubLedger::class, 'Add'])->name('add_subledger');
  Route::get('/subledger-edit/{id}', [SubLedger::class, 'Edit'])->name('subledger_edit');
  Route::post('/subledger-update', [SubLedger::class, 'Update'])->name('subledger_update');
  Route::delete('/subledger-delete/{id}', [SubLedger::class, 'Delete']);
  Route::post('/subledger-status/{id}', [SubLedger::class, 'Status']);

  // Accounts
  // Daily  Accounts
  Route::get('/accounts/daily_accounts', [ManageDailyAccounts::class, 'index'])->name('accounts-daily-accounts');
  Route::post('/account_filter', [ManageDailyAccounts::class, 'filter_account'])->name('account_filter');
  Route::get('/autocomplete_daily_acounts', [ManageDailyAccounts::class, 'autocomplete'])->name('autocomplete_daily_acounts');
  Route::get('subledger_list', [ManageDailyAccounts::class, 'sub_ledger_List'])->name('subledger_list');
  Route::post('/add_daily_accounts', [ManageDailyAccounts::class, 'Add'])->name('add_daily_accounts');
  Route::get('/edit_daily_accounts/{id}', [ManageDailyAccounts::class, 'Edit'])->name('edit_daily_accounts');
  Route::post('/update_daily_accounts', [ManageDailyAccounts::class, 'Update'])->name('update_daily_accounts');
  Route::delete('/delete_daily_accounts/{id}', [ManageDailyAccounts::class, 'Delete']);
  
   // Profit loss
    Route::get('/accounts/profit_loss', [ManageProfitLoss::class, 'index'])->name('accounts-profit-loss');

    // Trial Balance
    Route::get('/accounts/trial_balance', [ManageTrialBalance::class, 'index'])->name('accounts-trial-balance');
    Route::get('view_trial_balance', [ManageTrialBalance::class, 'view_trial_balance'])->name('view_trial_balance');

  // StudentFeedback
  Route::get('/settings/course/student_feedback', [StudentFeedback::class, 'index'])->name('settings-course');
  Route::get('/student_feedback', [StudentFeedback::class, 'List'])->name('student_feedback');
  Route::post('/add_student_feedback', [StudentFeedback::class, 'Add'])->name('add_student_feedback');
  Route::get('/student_feedback_edit/{id}', [CourseType::class, 'Edit'])->name('student_feedback_edit');
  Route::post('/student_feedback_update', [StudentFeedback::class, 'Update'])->name('student_feedback_update');
  Route::delete('/student_feedback_delete/{id}', [StudentFeedback::class, 'Delete']);
  Route::post('/student_feedback_status/{id}', [StudentFeedback::class, 'Status']);

  // Paymentmode
  Route::get('/settings/sales/payment_mode', [PaymentMode::class, 'index'])->name('settings-sales-payment_mode');
  Route::get('/payment_mode', [PaymentMode::class, 'List'])->name('payment_mode');
  Route::post('/add_payment_mode', [PaymentMode::class, 'Add'])->name('add_payment_mode');
  Route::get('/payment_mode_edit/{id}', [PaymentMode::class, 'Edit'])->name('payment_mode_edit');
  Route::post('/payment_mode_update', [PaymentMode::class, 'Update'])->name('payment_mode_update');
  Route::delete('/payment_mode_delete/{id}', [PaymentMode::class, 'Delete']);
  Route::post('/payment_mode_status/{id}', [PaymentMode::class, 'Status']);

  // CertificateTemplate
  Route::get('/settings/exam/certificate_template', [CertificateTemplate::class, 'index'])->name('settings-exam');
  Route::post('/add_certificate_template', [CertificateTemplate::class, 'Add'])->name('add_certificate_template');
  Route::post('/certificate_template_update', [CertificateTemplate::class, 'Update'])->name('certificate_template_update');
  Route::delete('/certificate_template_delete/{id}', [CertificateTemplate::class, 'Delete']);
  Route::post('/certificate_template_status/{id}', [CertificateTemplate::class, 'Status']);

  // GradeTemplate
  Route::get('/settings/exam/grade_template', [GradeTemplate::class, 'index'])->name('settings-exam');
  Route::post('/add_grade_template', [GradeTemplate::class, 'Add'])->name('add_grade_template');
  Route::post('/grade_template_update', [GradeTemplate::class, 'Update'])->name('grade_template_update');
  Route::delete('/grade_template_delete/{id}', [GradeTemplate::class, 'Delete']);
  Route::post('/grade_template_status/{id}', [GradeTemplate::class, 'Status']);
  Route::post('/grade_template_color_uni/{id}', [GradeTemplate::class, 'Color']);

  Route::get('/settings/exam/question_bank', [QuestionBank::class, 'index'])->name('settings-exam-question-bank');
  Route::get('/settings/exam/question_bank_add', [QuestionBank::class, 'question_bank_add'])->name('settings-exam-question-bank-add');
  Route::get('/settings/exam/question_bank_edit', [QuestionBank::class, 'question_bank_edit'])->name('settings-exam-question-bank-edit');


  // Grade
  Route::get('/settings/hrm/grade', [Grade::class, 'index'])->name('settings-hrm');
  Route::get('/grade', [Grade::class, 'List'])->name('grade');
  Route::post('/add-grade', [Grade::class, 'Add'])->name('add_grade');
  Route::get('/grade-edit/{id}', [Grade::class, 'Edit'])->name('grade_edit');
  Route::post('/grade-update', [Grade::class, 'Update'])->name('grade_update');
  Route::delete('/grade-delete/{id}', [Grade::class, 'Delete']);
  Route::post('/grade-status/{id}', [Grade::class, 'Status']);

  // Level
  Route::get('/settings/hrm/level', [Level::class, 'index'])->name('settings-hrm');
  Route::get('/level', [Level::class, 'List'])->name('level');
  Route::post('/add-level', [Level::class, 'Add'])->name('add_level');
  Route::get('/level-edit/{id}', [Level::class, 'Edit'])->name('level_edit');
  Route::post('/level-update', [Level::class, 'Update'])->name('level_update');
  Route::delete('/level-delete/{id}', [Level::class, 'Delete']);
  Route::post('/level-status/{id}', [Level::class, 'Status']);
  Route::get('/settings/exam/ai_prompt', [AIPrompt::class, 'index'])->name('settings-exam-ai-prompt');


  // Exam_guidelines
  Route::get('/settings/exam/exam_guidelines', [Exam_guidelines::class, 'index'])->name('settings-exam');
  Route::post('/exam_guidelines_update', [Exam_guidelines::class, 'Update'])->name('exam_guidelines_update');


  // Roshini mam
  
  Route::match(['get', 'post'],'/courses/manage_certificate', [ManageCertificate::class, 'index'])->name('production-manage-certificate');
  Route::get('/certificate_list', [ManageCertificate::class, 'List'])->name('list');
  Route::get('/tableGet_cert', [ManageCertificate::class, 'tableGet'])->name('tableGet_cert');
  Route::post('/request_cert_checklist', [ManageCertificate::class, 'AddRequest'])->name('request_cert_checklist');
  Route::post('/cert_request_status/{id}', [ManageCertificate::class, 'RequestStatus'])->name('cert_request_status');
  Route::get('/certificate_view/{id}', [ManageCertificate::class, 'View']);
  Route::get('/certificate_request/{id}', [ManageCertificate::class, 'CertificateRequest'])->name('certificate_request_status');
  Route::get('/distribution_checklist/{id}', [ManageCertificate::class, 'DistributionChecklist'])->name('distribution_checklist');
  Route::post('/cert_distribution_checklist', [ManageCertificate::class, 'Distribute'])->name('cert_distribution_checklist');
 

  //   Certificate Authority
  // Main Menu Certificate Authority
  
  Route::match(['get', 'post'],'/courses/certificate_authority', [CertificateAuthority::class, 'index'])->name('production-certificate-authority');
  Route::post('/course_cert_receive/{id}', [CertificateAuthority::class, 'ReceivedStatus'])->name('course_cert_receive');
  Route::post('/add_schedule', [CertificateAuthority::class, 'AddSchedule'])->name('add_schedule');
  Route::get('/authority_view/{id}', [CertificateAuthority::class, 'View'])->name('authority_view');
  Route::get('/approve_cert/{id}', [CertificateAuthority::class, 'approveCert'])->name('approve_cert');
  Route::post('/cus_score_data/{id}', [CertificateAuthority::class, 'cusScoreDetails']);
  Route::post('/request_cert_score', [CertificateAuthority::class, 'AddScore'])->name('request_cert_score');
  Route::match(['get', 'post'], '/course_completed_certificate/view/{id}', [CertificateAuthority::class, 'PrintCertiifcate'])->name('course_completed_certificate');
   Route::match(['get', 'post'], '/course_completed_certificate/download/{id}', [CertificateAuthority::class, 'generateCertificatePdf'])->name('course_completed_certificate');
  Route::get('/generate-pdf', [CertificateAuthority::class, 'generateCertificatePdf']);
  
  
   Route::get('/certificate_authority/certificate_print/{id}', [CertificateAuthority::class, 'CertificatePrint'])->name('authority_view');
  // Customer Care
  // Main menu Customer Care


 Route::get('/customer_care/course_type_json', [CustomerCare::class, 'getCourseTypes'])->name('support-management-courseList-json');
  // Main menu Customer Care
  Route::get('/customer_care/customer_care_list', [CustomerCare::class, 'index'])->name('customer-care-list');
    //  Route::match(['get', 'post'], '/customer_list_filter', [CustomerCare::class, 'list_filter'])->name('customer_list_filter');
  Route::get('/customer_care/customer_indiv_course_attend_print/{id}', [CustomerCare::class, 'CourseSummaryPrint'])->name('customer_course_summary_print');
  Route::get('/customer_care/customer_care_view/{id}', [CustomerCare::class, 'customer_view'])->name('customer_care-view');
  Route::get('/customer_care_course_view/{id}', [CustomerCareCourseView::class, 'customer_course_view'])->name('customer_care-course_view');
  Route::get('/customer_attendance_view/{id}', [CustomerCareAttendanceView::class, 'customer_attendance_view'])->name('customer_care-attendance_view');
  // Route::get('/customer_care/customer_attendance_view/{id}', [CustomerCare::class, 'customer_Attendance_view'])->name('customer_attendance_view');
  Route::get('/customer_care/course_list', [CustomerCare::class, 'Course_List'])->name('customer-care-courseList');
  Route::post('/customer_care_course_list_filter', [CustomerCare::class, 'Course_list_filter'])->name('customer-care-courseList');
  // Batch Customer Care
  Route::get('/customer_care/batch_list', [CustomerCare::class, 'Batch_List'])->name('customer-care-batch_list');
  Route::post('/customer_care_batch_list_filter', [CustomerCare::class, 'Batch_list_filter'])->name('customer-care-batch_list');
  
  Route::get('/customer_care/course_list_json', [CustomerCare::class, 'Course_List_JSON'])->name('support-management-courseList-json');
  
  // Manage certificate
  Route::get('/customer_care/manage_certificate', [CustomerCare::class, 'ManageCertificate'])->name('customer-care-manage-certificate');
  Route::get('/customer_care/manage_certificate_view/{id}', [CustomerCare::class, 'View']);

    //Manage Ticket
    Route::match(['get', 'post'],'/customer_care/manage_ticket',[ManageTicket::class,'index'])->name('customer_care_manage_ticket');
    Route::get('ManageTicket', [ManageTicket::class, 'List'])->name('ManageTicket');
    Route::get('admin/chat/fetch', [ManageTicket::class, 'fetchChatMessages']);
    Route::post('admin/chat/send', [ManageTicket::class, 'sendChatMessage']);
    Route::post('admin/chat/mark-seen', [ManageTicket::class, 'markSeen']);
    // Route::get('/ManageTicket-view/{id}', [ManageTicket::class, 'View']);
    Route::post('add_assignee', [ManageTicket::class, 'Add_Assignee'])->name('add_assignee');
    Route::post('close_ticket', [ManageTicket::class, 'Close_ticket'])->name('close_ticket');
    Route::post('confirm_ticket', [ManageTicket::class, 'Confirm_ticket'])->name('confirm_ticket');
    
    Route::get('/getTicketDetails', [ManageTicket::class, 'getTicketDetails']);
    Route::get('issue_list/{id}', [ManageTicket::class, 'issue_list']);
    Route::post('issue_reply', [ManageTicket::class, 'issue_reply']);
 
    //Manage Mobile Feedback
  Route::match(['get', 'post'], '/manage_customer/manage_mob_feedback', [ManageMobileFeedback::class, 'index'])->name('customer-manage_mob_feedback');
  Route::match(['get', 'post'], '/manage_customer/manage_mob_feedback_ajax', [ManageMobileFeedback::class, 'getFeedbackAccordionAjax']);
  Route::match(['get', 'post'], '/manage_customer/manage_mob_feedback_staff_ajax', [ManageMobileFeedback::class, 'getFeedbackAjaxStaff']);
  Route::match(['get', 'post'], '/manage_customer/manage_mob_feedback_batch_ajax', [ManageMobileFeedback::class, 'getFeedbackAjaxBatch']);
  
  // ShiftTime
  Route::get('/settings/hrm/shift_time', [ShiftTime::class, 'index'])->name('settings-hrm');
  Route::post('/add_shift_time', [ShiftTime::class, 'Add'])->name('add_shift_time');
  Route::get('/shift_time_edit/{id}', [ShiftTime::class, 'Edit'])->name('shift_time_edit');
  Route::post('/shift_time_update', [ShiftTime::class, 'Update'])->name('shift_time_update');
  Route::delete('/shift_time_delete/{id}', [ShiftTime::class, 'Delete']);
  Route::post('/shift_time_status/{id}', [ShiftTime::class, 'Status']);
  Route::get('/branch_list', [ShiftTime::class, 'branch_list'])->name('branch_list');


  // Certificate Checklist
  Route::get('/settings/course/certificate_checklist', [CertificateChecklist::class, 'index'])->name('settings-course-certificate_checklist');
  Route::get('/certificate_checklist', [CertificateChecklist::class, 'List'])->name('certificate_checklist');
  Route::post('/add_certificate_checklist', [CertificateChecklist::class, 'Add'])->name('add_certificate_checklist');
  Route::get('/certificate_checklist_edit/{id}', [CertificateChecklist::class, 'Edit'])->name('certificate_checklist_edit');
  Route::post('/certificate_checklist_update', [CertificateChecklist::class, 'Update'])->name('certificate_checklist_update');
  Route::delete('/certificate_checklist_delete/{id}', [CertificateChecklist::class, 'Delete']);
  Route::post('/certificate_checklist_status/{id}', [CertificateChecklist::class, 'Status']);


  // Certificate Status
  Route::get('/settings/course/certificate_status', [CertificateStatus::class, 'index'])->name('settings-course-certificate_status');
  Route::get('/certificate_status', [CertificateStatus::class, 'List'])->name('certificate_status');
  Route::post('/add_certificate_status', [CertificateStatus::class, 'Add'])->name('add_certificate_status');
  Route::get('/certificate_status_edit/{id}', [CertificateStatus::class, 'Edit'])->name('certificate_status_edit');
  Route::post('/certificate_status_update', [CertificateStatus::class, 'Update'])->name('certificate_status_update');
  Route::delete('/certificate_status_delete/{id}', [CertificateStatus::class, 'Delete']);
  Route::post('/certificate_status/{id}', [CertificateStatus::class, 'Status']);

  // Certificate Authority Status
  Route::get('/settings/course/certificate_authority_status', [CertificateAuthorityStatus::class, 'index'])->name('settings-course-certificate_authority_status');
  Route::get('/certificate_authority_status', [CertificateAuthorityStatus::class, 'List'])->name('certificate_authority_status');
  Route::post('/add_certificate_authority_status', [CertificateAuthorityStatus::class, 'Add'])->name('add_certificate_authority_status');
  Route::get('/certificate_authority_status_edit/{id}', [CertificateAuthorityStatus::class, 'Edit'])->name('certificate_authority_status_edit');
  Route::post('/certificate_authority_status_update', [CertificateAuthorityStatus::class, 'Update'])->name('certificate_authority_status_update');
  Route::delete('/certificate_authority_status_delete/{id}', [CertificateAuthorityStatus::class, 'Delete']);
  Route::post('/certificate_authority_status/{id}', [CertificateAuthorityStatus::class, 'Status']);
  
  // courier
  Route::get('/settings/course/courier_list', [Courier::class, 'index'])->name('settings-course-course');
  Route::get('/courier', [Courier::class, 'List'])->name('courier');
  Route::post('/add_courier', [Courier::class, 'Add'])->name('add_courier');
  Route::get('/courier_edit/{id}', [Courier::class, 'Edit'])->name('courier_edit');
  Route::post('/courier_update', [Courier::class, 'Update'])->name('courier_update');
  Route::delete('/courier_delete/{id}', [Courier::class, 'Delete']);
  Route::post('/courier_status/{id}', [Courier::class, 'Status']);


  // MarketingCategory
  Route::get('/settings/marketing/category', [MarketingCategory::class, 'index'])->name('settings-marketing');
  Route::get('marketing_category', [MarketingCategory::class, 'List'])->name('marketing_category');
  Route::post('/add_marketing_category', [MarketingCategory::class, 'Add'])->name('add_marketing_category');
  Route::post('/marketing_category_update', [MarketingCategory::class, 'Update'])->name('marketing_category_update');
  Route::delete('/marketing_category_delete/{id}', [MarketingCategory::class, 'Delete']);
  Route::post('/marketing_category_status/{id}', [MarketingCategory::class, 'Status']);

  // MarketingType
  Route::get('/settings/marketing/type', [MarketingType::class, 'index'])->name('settings-marketing');
  Route::get('marketing_type', [MarketingType::class, 'List'])->name('marketing_type');
  Route::post('/add_marketing_type', [MarketingType::class, 'Add'])->name('add_marketing_type');
  Route::get('/marketing_type_edit/{id}', [MarketingType::class, 'Edit'])->name('marketing_type_edit');
  Route::post('/marketing_type_update', [MarketingType::class, 'Update'])->name('marketing_type_update');
  Route::delete('/marketing_type_delete/{id}', [MarketingType::class, 'Delete']);
  Route::post('/marketing_type_status/{id}', [MarketingType::class, 'Status']);


  // common setting start
  // Whatsapp configure setting
  Route::get('/settings/common/whatsapp_api_configure', [WhatsappApiConfigure::class, 'index'])->name('settings-common');
  Route::get('/whatsapp_api_list', [WhatsappApiConfigure::class, 'List'])->name('whatsapp_api_list');
  Route::post('/whatsapp_api_configure_add', [WhatsappApiConfigure::class, 'Add'])->name('whatsapp_api_configure_add');
  Route::post('/whatsapp_api_configure_update', [WhatsappApiConfigure::class, 'Update'])->name('whatsapp_api_configure_update');
  Route::delete('/whatsapp_api_configure_delete/{id}', [WhatsappApiConfigure::class, 'Delete'])->name('whatsapp_api_configure_delete');
  Route::post('/whatsapp_api_configure_status_change/{id}', [WhatsappApiConfigure::class, 'Status'])->name('whatsapp_api_configure_status_change');
  // sms Template
  Route::get('/settings/common/sms_template', [SmsTemplate::class, 'index'])->name('settings-common');
  Route::post('/add_sms_template', [SmsTemplate::class, 'Add'])->name('add_sms_template');
  Route::get('/sms_template_edit', [SmsTemplate::class, 'Edit'])->name('sms_template_edit');
  Route::post('/sms_template_update', [SmsTemplate::class, 'Update'])->name('sms_template_update');
  Route::delete('/sms_template_delete/{id}', [SmsTemplate::class, 'Delete'])->name('sms_template_delete');
  Route::post('/sms_template_status_change/{id}', [SmsTemplate::class, 'Status'])->name('sms_template_status_change');
  //ReviewLink
  Route::get('/settings/common/ReviewLinks', [ReviewLinks::class, 'index'])->name('settings-common_setting');
  Route::get('/ReviewLinks', [ReviewLinks::class, 'List'])->name('ReviewLinks');
  Route::post('/add_review', [ReviewLinks::class, 'Add'])->name('add_review');
  Route::get('/review-edit/{id}', [ReviewLinks::class, 'Edit']);
  Route::post('/review_update', [ReviewLinks::class, 'Update'])->name('review_update');
  Route::delete('/review-delete/{id}', [ReviewLinks::class, 'Delete']);
  Route::post('/review-status/{id}', [ReviewLinks::class, 'Status']);
  

  // email Template
  Route::get('/settings/common/email_template', [EmailTemplate::class, 'index'])->name('settings-common');
  Route::get('/email_template_list', [EmailTemplate::class, 'List'])->name('email_template_list');
  Route::get('/settings/email_template/email_template_add', [EmailTemplate::class, 'EmailAdd'])->name('settings-common');
  Route::post('/email_template_add', [EmailTemplate::class, 'Add'])->name('email_template_add');
  Route::get('/email_template_edit/{id}', [EmailTemplate::class, 'Edit'])->name('email_template_edit');
  Route::post('/email_template_update', [EmailTemplate::class, 'Update'])->name('email_template_update');
  Route::delete('/email_template_delete/{id}', [EmailTemplate::class, 'Delete'])->name('email_template_delete');
  Route::post('/email_template_status/{id}', [EmailTemplate::class, 'Status'])->name('email_template_status');


  //whatsapp template
  Route::get('/settings/common/whatsapp_template', [WhatsappTemplate::class, 'index'])->name('settings-common');
  Route::get('/whatsapp_template_list', [WhatsappTemplate::class, 'List'])->name('whatsapp_template_list');
  Route::post('/whatsapp_template_add', [WhatsappTemplate::class, 'Add'])->name('whatsapp_template_add');
  Route::post('/whatsapp_template_update', [WhatsappTemplate::class, 'Update'])->name('whatsapp_template_update');
  Route::delete('/whatsapp_template_delete/{id}', [WhatsappTemplate::class, 'Delete'])->name('whatsapp_template_delete');
  Route::post('/whatsapp_template_status_change/{id}', [WhatsappTemplate::class, 'Status'])->name('whatsapp_template_status_change');
  Route::get('/whatsapp_templates', [Lead::class, 'showTemplates'])->name('whatsapp_templates');

  // Communication
  Route::get('/settings/common/communication_config', [Communication_config::class, 'index'])->name('settings-common');
  Route::get('/communication_config_list', [Communication_config::class, 'List'])->name('communication_config_list');
  Route::post('/communication_config_status_change/{id}', [Communication_config::class, 'Status'])->name('communication_config_status_change');
  Route::post('/communication_config_add', [Communication_config::class, 'Add'])->name('communication_config_add');
  Route::get('/communication_config_edit', [Communication_config::class, 'Edit'])->name('communication_config_edit');
  Route::post('/communication_config_update', [Communication_config::class, 'Update'])->name('communication_config_update');
  Route::delete('/communication_config_delete/{id}', [Communication_config::class, 'Delete'])->name('communication_config_delete');
  
  //Refund Checklist
  Route::get('/settings/common/refund_checklist/refund_checklist_list', [RefundChecklist::class, 'index'])->name('settings-common');
  Route::post('/add_refund_checklist', [RefundChecklist::class, 'Add'])->name('add_refund_checklist');
  Route::post('/refund_checklist_update', [RefundChecklist::class, 'Update'])->name('refund_checklist_update');
  Route::post('/refund_checklist_status/{id}', [RefundChecklist::class, 'Status'])->name('refund_checklist_status');
  Route::delete('/refund_checklist_delete/{id}', [RefundChecklist::class, 'Delete'])->name('refund_checklist_delete');
  
  // Spam Call Reason
  Route::get('/settings/common/spam_call_reason/spam_call_reason_list', [SpamCallReason::class, 'index'])->name('settings-common');
  Route::post('/spam_call_reason_add', [SpamCallReason::class, 'Add'])->name('spam_call_reason_add');
  Route::get('spam_call_reason_list', [SpamCallReason::class, 'List'])->name('spam_call_reason_list');
  Route::post('/spam_call_reason_status/{id}', [SpamCallReason::class, 'Status']);
  Route::delete('/spam_call_reason_delete/{id}', [SpamCallReason::class, 'Delete']);
  Route::post('/spam_call_reason_update', [SpamCallReason::class, 'Update'])->name('spam_call_reason_update');
  
    // Hold Reason
  Route::get('/settings/common/hold_reason', [HoldReason::class, 'index'])->name('settings-common');
  Route::post('/hold_reason_add', [HoldReason::class, 'Add'])->name('hold_reason_add');
  Route::get('hold_reason_list', [HoldReason::class, 'List'])->name('hold_reason_list');
  Route::get('/hold_reason_edit/{id}', [HoldReason::class, 'Edit']);
  Route::post('/hold_reason_status/{id}', [HoldReason::class, 'Status']);
  Route::delete('/hold_reason_delete/{id}', [HoldReason::class, 'Delete']);
  Route::post('/hold_reason_update', [HoldReason::class, 'Update'])->name('hold_reason_update');
  
 // Training Settings
 
     //Audio category
      Route::get('/settings/training_settings/audio_category', [AudioCategory::class, 'index'])->name('settings-training-settings');
      Route::get('/audio_category', [AudioCategory::class, 'List'])->name('audio_category');
      Route::post('/add_audio_category', [AudioCategory::class, 'Add'])->name('add_audio_category');
      Route::get('/audio-category-edit/{id}', [AudioCategory::class, 'Edit']);
      Route::post('/audio_category_update', [AudioCategory::class, 'Update'])->name('audio_category_update');
      Route::delete('/audio-category-delete/{id}', [AudioCategory::class, 'Delete']);
      Route::post('/audio-category-status/{id}', [AudioCategory::class, 'Status']);

    // Training Document Category
    Route::get('/settings/training/category', [TrainingCategory::class, 'index'])->name('settings-training-settings');
    Route::post('/create_training_category', [TrainingCategory::class, 'store'])->name('create_training_category');
    Route::post('/status_training_category/{id}', [TrainingCategory::class, 'Status']);
    Route::delete('/delete_training_category/{id}', [TrainingCategory::class, 'Delete']);
    Route::post('/update_training_category', [TrainingCategory::class, 'Update'])->name('update_training_category');

    // Training Document Sub Category
    Route::get('/settings/training/sub_category', [TrainingSubCategory::class, 'index'])->name('settings-training-settings');
    Route::post('/create_training_sub_category', [TrainingSubCategory::class, 'store'])->name('create_training_sub_category');
    Route::post('/status_training_sub_category/{id}', [TrainingSubCategory::class, 'Status']);
    Route::delete('/delete_training_sub_category/{id}', [TrainingSubCategory::class, 'Delete']);
    Route::post('/update_training_sub_category', [TrainingSubCategory::class, 'Update'])->name('update_training_sub_category');
    Route::get('/edit_sub_category_data/{id}', [TrainingSubCategory::class, 'Edit']);
  
  //Internal Call Reason
  Route::get('/settings/common/internal_call_reason/internal_call_reason_list', [InternalCallReason::class, 'index'])->name('settings-common');
  Route::post('/internal_call_reason_add', [InternalCallReason::class, 'Add'])->name('internal_call_reason_add');
  Route::get('internal_call_reason_list', [InternalCallReason::class, 'List'])->name('internal_call_reason_list');
  Route::post('/internal_call_reason_status/{id}', [InternalCallReason::class, 'Status']);
  Route::delete('/internal_call_reason_delete/{id}', [InternalCallReason::class, 'Delete']);
  Route::post('/internal_call_reason_update', [InternalCallReason::class, 'Update'])->name('internal_call_reason_update');
    // followup Reason
    Route::get('/settings/common/followup_reason/followup_reason_list', [FollowupReason::class, 'index'])->name('settings-common');
    Route::post('/followup_reason_add', [FollowupReason::class, 'Add'])->name('followup_reason_add');
    Route::get('followup_reason_list', [FollowupReason::class, 'List'])->name('followup_reason_list');
    Route::post('/followup_reason_status/{id}', [FollowupReason::class, 'Status']);
    Route::delete('/followup_reason_delete/{id}', [FollowupReason::class, 'Delete']);
    Route::post('/followup_reason_update', [FollowupReason::class, 'Update'])->name('followup_reason_update');  
    
    // Lead metrics
    Route::get('/settings/common/lead_metrics', [LeadMetrics::class, 'index'])->name('settings-common');
    Route::post('/lead_metrics_update', [LeadMetrics::class, 'Update'])->name('lead_metrics_update');
    
     // Holiday
  Route::get('/settings/common/holiday/holiday_list', [Holiday::class, 'index'])->name('settings-common');
  Route::post('/holiday_add', [Holiday::class, 'Add'])->name('holiday_add');
  Route::post('/holiday_update', [Holiday::class, 'Update'])->name('holiday_update');
  Route::delete('/holiday_delete/{id}', [Holiday::class, 'Delete']);
  
  
  //Branch Holiday
  Route::get('/branch_management/holiday/holiday_list', [BranchHoliday::class, 'index'])->name('branch_manage-holiday');
  Route::post('/holiday_add', [BranchHoliday::class, 'Add'])->name('holiday_add');
  Route::post('/holiday_update', [BranchHoliday::class, 'Update'])->name('holiday_update');
  Route::delete('/holiday_delete/{id}', [BranchHoliday::class, 'Delete']);
  
  //Qr Promotion
  Route::match(['get', 'post'], '/branch_management/qr_promotion', [QrPromotion::class, 'index'])->name('marketing_manage-qr_promotion');
  Route::post('/add_qr_promotion', [QrPromotion::class, 'Add'])->name('add_qr_promotion');
  Route::get('/edit_qr_promotion/{id}', [QrPromotion::class, 'Edit'])->name('edit_qr_promotion');
  Route::get('/scan_qr_promotion/{id}', [QrPromotion::class, 'Scanner_view'])->name('scan_qr_promotion');
  Route::match(['get', 'post'], '/branch_management/qr_promotion_scanners', [QrPromotion::class, 'ajax_table'])->name('qr.scanner.table');
  Route::match(['get', 'post'], '/qr.scanner.multi.map', [QrPromotion::class, 'MultiMap'])->name('qr.scanner.multi.map');
  Route::get('/branch_sales_staff_list/{id}', [QrPromotion::class, 'branch_sales_staff_list'])->name('branch_sales_staff_list');
  Route::post('/update_qr_promotion', [QrPromotion::class, 'Update'])->name('update_qr_promotion');
  
  
   Route::match(['get', 'post'], '/branch_management/qr_catalogue', [QrCatalogue::class, 'index'])->name('branch_manage-qr_catalogue');

  
//   Internal_cugs
  
  Route::get('/settings/common/Internal_cugs', [Internal_cugs::class, 'index'])->name('settings-common');
  Route::post('/Internal_cugs_add', [Internal_cugs::class, 'Add'])->name('Internal_cugs_add');
  Route::post('/Internal_cugs_update', [Internal_cugs::class, 'Update'])->name('Internal_cugs_update');
  Route::delete('/Internal_cugs_delete/{id}', [Internal_cugs::class, 'Delete']);
  
    //Gift
  Route::get('/settings/common/Gift', [Gift::class, 'index'])->name('settings-common_setting');
  Route::get('/Gift', [Gift::class, 'List'])->name('Gift');
  Route::post('/add_gift', [Gift::class, 'Add'])->name('add_gift');
  Route::get('/gift-edit/{id}', [Gift::class, 'Edit']);
  Route::post('/gift_update', [Gift::class, 'Update'])->name('gift_update');
  Route::delete('/gift-delete/{id}', [Gift::class, 'Delete']);
  Route::post('/gift-status/{id}', [Gift::class, 'Status']);
  
  
  // Education
  Route::get('/settings/intern/education/education_list', [Education::class, 'index'])->name('settings-intern');
  Route::get('education', [Education::class, 'List'])->name('education');
  Route::post('/add-education', [Education::class, 'Add'])->name('add_education');
  Route::get('/education-edit/{id}', [Education::class, 'Edit'])->name('education_edit');
  Route::post('/education-update', [Education::class, 'Update'])->name('education_update');
  Route::delete('/education-delete/{id}', [Education::class, 'Delete']);
  Route::post('/education-status/{id}', [Education::class, 'Status']);

 // Topic
  Route::get('/settings/intern/topic/topic_list', [Topic::class, 'index'])->name('settings-intern');
  Route::get('topic', [Topic::class, 'List'])->name('topic');
  Route::post('/add-topic', [Topic::class, 'Add'])->name('add_topic');
  Route::get('/topic-edit/{id}', [Topic::class, 'Edit'])->name('topic_edit');
  Route::post('/topic-update', [Topic::class, 'Update'])->name('topic_update');
  Route::delete('/topic-delete/{id}', [Topic::class, 'Delete']);
  Route::post('/topic-status/{id}', [Topic::class, 'Status']);

   //LetterPad
  Route::get('/settings/intern/letter_pad/letter_pad_list', [LetterPad::class, 'index'])->name('settings-intern');
  Route::get('letter_pad', [LetterPad::class, 'List'])->name('letter_pad');
  Route::post('/add-letter_pad', [LetterPad::class, 'Add'])->name('add_letter_pad');
  Route::get('/letter_pad-edit/{id}', [LetterPad::class, 'Edit'])->name('letter_pad_edit');
  Route::post('/letter_pad-update', [LetterPad::class, 'Update'])->name('letter_pad_update');
  Route::delete('/letter_pad-delete/{id}', [LetterPad::class, 'Delete']);
  Route::post('/letter_pad-status/{id}', [LetterPad::class, 'Status']);


  
   //College
   Route::get('/settings/intern/College', [College::class, 'index'])->name('settings-intern');
   Route::get('/College', [College::class, 'List'])->name('College');
   Route::post('/add_college', [College::class, 'Add'])->name('add_college');
   Route::get('/college-edit/{id}', [College::class, 'Edit']);
   Route::post('/college_update', [College::class, 'Update'])->name('college_update');
   Route::delete('/college-delete/{id}', [College::class, 'Delete']);
   Route::post('/college-status/{id}', [College::class, 'Status']);
    
  // Drop Reason
  Route::get('/settings/common/drop_reason/drop_reason_list', [DropReason::class, 'index'])->name('settings-course');
  Route::post('/drop_reason_add', [DropReason::class, 'Add'])->name('drop_reason_add');
  Route::get('drop_reason_list', [DropReason::class, 'List'])->name('drop_reason_list');
  Route::post('/drop_reason_status/{id}', [DropReason::class, 'Status']);
  Route::delete('/drop_reason_delete/{id}', [DropReason::class, 'Delete']);
  Route::post('/drop_reason_update', [DropReason::class, 'Update'])->name('drop_reason_update');
  
  
  // rajkumar
  // Referral
  Route::get('/settings/sales/referral_list', [Referral::class, 'index'])->name('settings-sales');
  Route::post('/add_referral', [Referral::class, 'Add'])->name('add_referral');
  Route::post('/referral_update', [Referral::class, 'Update'])->name('referral_update');
  Route::delete('/referral_delete/{id}', [Referral::class, 'Delete']);
  Route::post('/referral_status/{id}', [Referral::class, 'Status']);

  // Financial Year
  Route::get('/settings/common/financial_year/financial_year_list', [FinancialYear::class, 'index'])->name('settings-common');
  Route::post('/add_financial_year', [FinancialYear::class, 'Add'])->name('add_financial_year');
  Route::post('/financial_year_update', [FinancialYear::class, 'Update'])->name('financial_year_update');
  Route::delete('/financial_year_delete/{id}', [FinancialYear::class, 'Delete']);
  Route::post('/financial_year_status/{id}', [FinancialYear::class, 'Status']);
  
 //highlight Template 
  Route::get('/settings/common/highlight/highlight_template_list', [HighLightTemplate::class, 'index'])->name('settings-common');
  Route::get('/settings/highlight/highlight_template_add', [HighLightTemplate::class, 'HighLightAdd'])->name('settings-common');
  Route::post('/highlight_template_add', [HighLightTemplate::class, 'Add'])->name('highlight_template_add');
  Route::get('/highlight_template_edit/{id}', [HighLightTemplate::class, 'Edit'])->name('highlight_template_edit');
  Route::post('/highlight_template_update', [HighLightTemplate::class, 'Update'])->name('highlight_template_update');
  Route::delete('/highlight_template_delete/{id}', [HighLightTemplate::class, 'Delete'])->name('highlight_template_delete');
  Route::post('/highlight_template_status/{id}', [HighLightTemplate::class, 'Status'])->name('highlight_template_status');


  //Rules 
    Route::get('/settings/common/rules/rules_list', [Rules_guidelines::class, 'index'])->name('settings-common');
  Route::post('/rules_guidelines_update', [Rules_guidelines::class, 'Update'])->name('rules_guidelines_update');
  Route::post('/add_rules', [Rules_guidelines::class, 'create_rules'])->name('add_rules');
  Route::post('/update_rules', [Rules_guidelines::class, 'update_rules'])->name('update_rules');
  Route::get('/edit_rules/{id}', [Rules_guidelines::class, 'editRules'])->name('edit_rules');
  Route::get('/view_rules/{id}', [Rules_guidelines::class, 'view'])->name('view_rules');
  
    // Score Summary
    Route::get('/score_summary', [SourceSummary::class, 'index'])->name('score_summary');
    Route::post('/update_score', [SourceSummary::class, 'update'])->name('update_score');
    
    

    // MobileApp
  Route::get('/settings/common/MobileApp/MobileApp_list', [MobileApp::class, 'index'])->name('settings-common');
  Route::post('/add_MobileApp', [MobileApp::class, 'Add'])->name('add_MobileApp');
  Route::post('/MobileApp_update/{id}', [MobileApp::class, 'Update'])->name('MobileApp_update');
  Route::get('/MobileApp-edit/{id}', [MobileApp::class, 'Edit'])->name('MobileApp-edit');
  Route::delete('/MobileApp_delete/{id}', [MobileApp::class, 'Delete']);
  Route::post('/MobileApp_status/{id}', [MobileApp::class, 'Status']);
  
  // Variable
  Route::get('/settings/marketing/Variable', [Variable::class, 'index'])->name('settings-marketing');
  Route::get('/Variable', [Variable::class, 'List'])->name('Variable');
  Route::post('/add_Variable', [Variable::class, 'Add'])->name('add_Variable');
  Route::get('/Variable-edit/{id}', [Variable::class, 'Edit']);
  Route::post('/Variable-update/{id}', [Variable::class, 'Update'])->name('Variable-update');
  Route::delete('/Variable-delete/{id}', [Variable::class, 'Delete']);
  Route::post('/Variable-status/{id}', [Variable::class, 'Status']);
  
  
  // marketing category
  Route::get('/settings/marketing/MarketingKitCategory', [MarketingKitcategory::class, 'index'])->name('settings-marketing');
  Route::get('/MarketingKitCategory', [MarketingKitcategory::class, 'List'])->name('MarketingKitCategory');
  Route::post('/add_MarketingKitCategory', [MarketingKitcategory::class, 'Add'])->name('add_MarketingKitCategory');
  Route::get('/MarketingKitCategory-edit/{id}', [MarketingKitcategory::class, 'Edit']);
  Route::post('/MarketingKitCategory-update/{id}', [MarketingKitcategory::class, 'Update'])->name('MarketingKitCategory-update');
  Route::delete('/MarketingKitCategory-delete/{id}', [MarketingKitcategory::class, 'Delete']);
  Route::post('/MarketingKitCategory-status/{id}', [MarketingKitcategory::class, 'Status']);
  
   // MarketingKitDelivery
  Route::get('/settings/marketing/MarketingkitDelivery', [MarketingKitDelivery::class, 'index'])->name('settings-marketing');
  Route::get('/MarketingkitDelivery', [MarketingKitDelivery::class, 'List'])->name('MarketingkitDelivery');
  Route::post('/add_MarketingkitDelivery', [MarketingKitDelivery::class, 'Add'])->name('add_MarketingkitDelivery');
  Route::get('/MarketingkitDelivery-edit/{id}', [MarketingKitDelivery::class, 'Edit']);
  Route::post('/MarketingkitDelivery-update/{id}', [MarketingKitDelivery::class, 'Update'])->name('MarketingkitDelivery-update');
  Route::delete('/MarketingkitDelivery-delete/{id}', [MarketingKitDelivery::class, 'Delete']);
  Route::post('/MarketingkitDelivery-status/{id}', [MarketingKitDelivery::class, 'Status']);

  // marketingsubcategory
  Route::get('/settings/marketing/MarketingKitSubCategory', [MarketingKitSubcategory::class, 'index'])->name('settings-marketing');
  Route::get('MarketingKitSubCategory', [MarketingKitSubcategory::class, 'List'])->name('MarketingKitSubCategory');
  Route::post('/add_MarketingKitSubCategory', [MarketingKitSubcategory::class, 'Add'])->name('add_MarketingKitSubCategory');
  Route::get('/MarketingKitSubCategory-edit/{id}', [MarketingKitSubcategory::class, 'Edit']);
  Route::post('/MarketingKitSubCategory-update', [MarketingKitSubcategory::class, 'Update'])->name('MarketingKitSubCategory-update');
  Route::delete('/MarketingKitSubCategory-delete/{id}', [MarketingKitSubcategory::class, 'Delete']);
  Route::post('/MarketingKitSubCategory-status/{id}', [MarketingKitSubcategory::class, 'Status']);
  
  //Reports management

 

  // Lead Analysis
  Route::get('/manage_reports/lead_report', [LeadReports::class, 'index'])->name('reports-lead_reports'); //Lead - Monthly view
  Route::match(['get', 'post'], '/manage_reports/leads_data', [LeadReports::class, 'getLeadsData'])->name('leads_data'); //Lead - Monthly Ajax
  Route::get('/manage_reports/lead_report_yearly', [LeadReports::class, 'yearly_lead'])->name('reports-lead_reports'); //Lead - Yearly view
  Route::match(['get', 'post'], '/manage_reports/yearly_leads_data', [LeadReports::class, 'getLeadsYearlyData'])->name('yearly_leads_data'); //Lead - Yearly Ajax
  Route::get('/manage_reports/lead_src_report', [LeadReports::class, 'lead_src_month'])->name('reports-lead_reports'); //Lead Source - Monthly view
  Route::match(['get', 'post'], '/manage_reports/leads_src_data', [LeadReports::class, 'getLeadsSourceData'])->name('leads_src_data'); //Lead Source - Monthly Ajax
  Route::get('/manage_reports/lead_src_report_yearly', [LeadReports::class, 'yearly_lead_src'])->name('reports-lead_reports'); //Lead Source - Yearly view
  Route::match(['get', 'post'], '/manage_reports/leads_src_data_yearly', [LeadReports::class, 'getLeadsSourceYearData'])->name('leads_src_data_yearly'); //Lead Source - Yearly Ajax
  Route::match(['get', 'post'], '/manage_reports/get_lead_source_list', [LeadReports::class, 'get_lead_source_list'])->name('get_lead_source_list'); //Lead Type List Ajax
  Route::get('/manage_reports/sales_lead_report', [LeadReports::class, 'sales_lead_month'])->name('reports-lead_reports'); //Sales Executive - Monthly view
  Route::match(['get', 'post'], '/manage_reports/sales_lead_data', [LeadReports::class, 'getSalesMonthlyData'])->name('sales_lead_data'); //Sales Executive - Monthly Ajax
  Route::get('/manage_reports/sales_yearly_report', [LeadReports::class, 'yearly_lead_sales'])->name('reports-lead_reports'); //Sales Executive - Yearly view
  Route::match(['get', 'post'], '/manage_reports/sales_lead_yearly_data', [LeadReports::class, 'getSalesYearlyData'])->name('sales_lead_yearly_data'); //Sales Executive - Yearly Ajax
  Route::match(['get', 'post'], '/manage_reports/get_sales_executive_list', [LeadReports::class, 'SalesExcutiveStaffList'])->name('get_sales_executive_list'); //Sales Executive - List Ajax
  Route::get('/manage_reports/week_lead_report', [LeadReports::class, 'week_lead_month'])->name('reports-lead_reports'); //Weekly - Monthly view
  Route::match(['get', 'post'], '/manage_reports/week_lead_report_data', [LeadReports::class, 'getWeeklyMonthData'])->name('week_lead_report_data'); //Weekly - Monthly view
  Route::get('/manage_reports/week_yearly_report', [LeadReports::class, 'yearly_lead_weekly'])->name('reports-lead_reports'); //Weekly - Yearly view
  Route::match(['get', 'post'], '/manage_reports/week_yearly_report_data', [LeadReports::class, 'getWeeklyYearlyData'])->name('week_yearly_report_data'); //Weekly - Yearly view
  // Route::get('/manage_reports/manage_reports', [LeadReports::class, 'index'])->name('lead-report');

  // Customer Analysis
  Route::get('/manage_reports/customer_report_yearly', [CustomerReport::class, 'index'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_report_yearly_data', [CustomerReport::class, 'CusYearlyData'])->name('customer_report_yearly_data'); //Drop Cutsomer - Monthly Ajax
  Route::match(['get', 'post'], '/manage_reports/lead_type_list', [CustomerReport::class, 'get_lead_type_list'])->name('get_lead_type_list'); //Lead Type List Ajax
  Route::get('/manage_reports/customer_report', [CustomerReport::class, 'month_customer'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_report_data', [CustomerReport::class, 'CusMonthlyData'])->name('customer_report_data'); //Drop Cutsomer - Monthly Ajax
  Route::get('/manage_reports/customer_drop_report_yearly', [CustomerReport::class, 'customer_drop'])->name('reports-customer_report'); //Drop Cutsomer - yearly View
  Route::match(['get', 'post'], '/manage_reports/customer_drop_report_yearly_data', [CustomerReport::class, 'CusDropYearlyData'])->name('customer_drop_report_yearly_data'); //Drop Cutsomer - yearly Ajax
  Route::get('/manage_reports/customer_drop_report', [CustomerReport::class, 'cus_drop_monthly'])->name('reports-customer_report'); //Drop Cutsomer - Monthly View
  Route::match(['get', 'post'], '/manage_reports/customer_drop_report_data', [CustomerReport::class, 'CusDropMonthlyData'])->name('customer_drop_report_data'); //Drop Cutsomer - Monthly Ajax
  Route::get('/manage_reports/customer_source_report_yearly', [CustomerReport::class, 'cus_src_yearly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_source_report_yearly_data', [CustomerReport::class, 'CusSrcYearlyData'])->name('customer_source_report_yearly_data');
  Route::get('/manage_reports/customer_source_report', [CustomerReport::class, 'cus_src_monthly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_source_report_data', [CustomerReport::class, 'CusSrcMonthlyData'])->name('customer_source_report_data');
  Route::get('/manage_reports/customer_age_report', [CustomerReport::class, 'cus_age_monthly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_age_report_data', [CustomerReport::class, 'CusAgeMonthlyData'])->name('customer_age_report_data');
  Route::get('/manage_reports/customer_age_report_yearly', [CustomerReport::class, 'cus_age_yearly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_age_report_yearly_data', [CustomerReport::class, 'CusAgeYearlyData'])->name('customer_age_report_yearly_data');
  Route::get('/manage_reports/customer_employee_type_report', [CustomerReport::class, 'cus_employee_type_monthly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/cus_employee_type_report_data', [CustomerReport::class, 'CusTypeMonthlyData'])->name('cus_employee_type_report_data');
  Route::get('/manage_reports/customer_employee_type_yearly', [CustomerReport::class, 'cus_employee_type_yearly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/cus_employee_type_yearly_data', [CustomerReport::class, 'CusTypeYearlyData'])->name('cus_employee_type_yearly_data');
  Route::get('/manage_reports/customer_batch_report', [CustomerReport::class, 'cus_batch_monthly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_batch_report_data', [CustomerReport::class, 'CusBatchMonthlyData'])->name('cus_batch_report_data');
  Route::get('/manage_reports/customer_batch_yearly', [CustomerReport::class, 'cus_batch_yearly'])->name('reports-customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_batch_yearly_data', [CustomerReport::class, 'CusBatchYearlyData'])->name('customer_batch_yearly_data');
  Route::match(['get', 'post'], '/manage_reports/get_slot_type_list', [CustomerReport::class, 'get_slot_type_list'])->name('get_slot_type_list');

 // Payment Analysis
  Route::get('/manage_reports/intern_payment_yearly', [PaymentReport::class, 'intern_payment_yearly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/intern_payment_yearly_data', [PaymentReport::class, 'InternPaymentYearlyData'])->name('intern_payment_yearly_data');
  Route::get('/manage_reports/intern_payment_monthly', [PaymentReport::class, 'intern_payment_monthly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/intern_payment_monthly_data', [PaymentReport::class, 'InternPaymentMonthlyData'])->name('intern_payment_monthly_data');
  Route::get('/manage_reports/intern_payment_quarterly', [PaymentReport::class, 'intern_payment_quarterly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/intern_payment_quarterly_data', [PaymentReport::class, 'InternPaymentQuarterlyData'])->name('intern_payment_quarterly_data');

  Route::get('/manage_reports/outstanding_yearly', [PaymentReport::class, 'outstanding_yearly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/outstanding_yearly_data', [PaymentReport::class, 'OutstandingYearlyData'])->name('outstanding_yearly_data');
  Route::get('/manage_reports/outstanding_monthly', [PaymentReport::class, 'outstanding_monthly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/outstanding_monthly_data', [PaymentReport::class, 'OutstandingMonthlyData'])->name('outstanding_monthly_data');
  Route::get('/manage_reports/outstanding_quarterly', [PaymentReport::class, 'outstanding_quarterly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/outstanding_quarterly_data', [PaymentReport::class, 'OutstandingQuarterlyData'])->name('outstanding_quarterly_data');

  Route::get('/manage_reports/drop_payment_yearly', [PaymentReport::class, 'drop_payment_yearly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/drop_payment_yearly_data', [PaymentReport::class, 'DropPaymentYearlyData'])->name('drop_payment_yearly_data');
  Route::get('/manage_reports/drop_payment_monthly', [PaymentReport::class, 'drop_payment_monthly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/drop_payment_monthly_data', [PaymentReport::class, 'DropPaymentMonthlyData'])->name('drop_payment_monthly_data');
  Route::get('/manage_reports/drop_payment_quarterly', [PaymentReport::class, 'drop_payment_quarterly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/drop_payment_quarterly_data', [PaymentReport::class, 'DropPaymentQuarterlyData'])->name('drop_payment_quarterly_data');

  Route::get('/manage_reports/pre_post_collection_yearly', [PaymentReport::class, 'pre_post_yearly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/pre_post_yearly_data', [PaymentReport::class, 'PrePostYearlyData'])->name('pre_post_yearly_data');
  Route::get('/manage_reports/pre_post_collection_monthly', [PaymentReport::class, 'pre_post_monthly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/pre_post_monthly_data', [PaymentReport::class, 'PrePostMonthlyData'])->name('pre_post_monthly_data');
  Route::get('/manage_reports/pre_post_collection_quarterly', [PaymentReport::class, 'pre_post_quarterly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/pre_post_quarterly_data', [PaymentReport::class, 'PrePostQuarterlyData'])->name('pre_post_quarterly_data');

  Route::get('/manage_reports/payment_collection_yearly', [PaymentReport::class, 'index'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/payment_collection_yearly_data', [PaymentReport::class, 'PaymentCollectionYearData'])->name('payment_collection_yearly_data');
  Route::get('/manage_reports/payment_collection_monthly', [PaymentReport::class, 'payment_collection_monthly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/payment_collection_monthly_data', [PaymentReport::class, 'PaymentCollectionMonthData'])->name('payment_collection_monthly_data');
  Route::get('/manage_reports/payment_collection_quarterly', [PaymentReport::class, 'payment_collection_quarterly'])->name('reports-payment-report');
  Route::match(['get', 'post'], '/manage_reports/payment_collection_quarterly_data', [PaymentReport::class, 'PaymentCollectionQuarterlyData'])->name('payment_collection_quarterly_data');

  // Student Analysis
  Route::get('/manage_reports/student_attendance_yearly', [StudentReport::class, 'index'])->name('reports-student-report');
  Route::match(['get', 'post'], '/manage_reports/student_attendance_yearly_data', [StudentReport::class, 'StudentAttYearlyData'])->name('student_att_yearly_data');
  Route::get('/manage_reports/student_attendance_monthly', [StudentReport::class, 'stud_att_monthly'])->name('reports-student-report');
  Route::match(['get', 'post'], '/manage_reports/student_attendance_monthly_data', [StudentReport::class, 'StudentAttMonthlyData'])->name('student_att_monthly_data');
  Route::get('/manage_reports/student_details_yearly', [StudentReport::class, 'stud_details_yearly'])->name('reports-student-report');
  Route::match(['get', 'post'], '/manage_reports/student_details_yearly_data', [StudentReport::class, 'StudentDetailsYearlyData'])->name('student_details_yearly_data');
  Route::get('/manage_reports/student_details_monthly', [StudentReport::class, 'stud_details_monthly'])->name('reports-student-report');
  Route::match(['get', 'post'], '/manage_reports/student_details_monthly_data', [StudentReport::class, 'StudentDetailsMonthlyData'])->name('student_details_monthly_data');

  // Batch Analysis
  Route::get('/manage_reports/active_upcoming_yearly', [BatchReport::class, 'index'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/active_upcoming_yearly_data', [BatchReport::class, 'ActiveUpcomingYearData'])->name('active_upcoming_yearly_data');
  Route::get('/manage_reports/active_upcoming_monthly', [BatchReport::class, 'active_upcoming_monthly'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/active_upcoming_monthly_data', [BatchReport::class, 'ActiveUpcomingMonthData'])->name('active_upcoming_monthly_data');
  Route::get('/manage_reports/batch_student_yearly', [BatchReport::class, 'batch_student_yearly'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/batch_student_yearly_data', [BatchReport::class, 'ActiveBatchStudentYearData'])->name('batch_student_yearly_data');
  Route::get('/manage_reports/batch_student_monthly', [BatchReport::class, 'batch_student_monthly'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/batch_student_monthly_data', [BatchReport::class, 'ActiveBatchStudentMonthData'])->name('batch_student_monthly_data');
  Route::get('/manage_reports/extend_batch_yearly', [BatchReport::class, 'extend_batch_yearly'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/extend_batch_yearly_data', [BatchReport::class, 'ExtentBatchYearData'])->name('extend_batch_yearly_data');
  Route::get('/manage_reports/extend_batch_monthly', [BatchReport::class, 'extend_batch_monthly'])->name('reports-batch-report');
  Route::match(['get', 'post'], '/manage_reports/extend_batch_monthly_data', [BatchReport::class, 'ExtentBatchMonthData'])->name('extend_batch_monthly_data');

  // Faculty Analysis
  Route::get('/manage_reports/faculty_yearly', [FacultyReport::class, 'index'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_yearly_data', [FacultyReport::class, 'FacultyYearData'])->name('faculty_yearly_data');
  Route::get('/manage_reports/faculty_monthly', [FacultyReport::class, 'faculty_monthly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_monthly_data', [FacultyReport::class, 'FacultyMonthData'])->name('faculty_monthly_data');
  Route::get('/manage_reports/faculty_student_yearly', [FacultyReport::class, 'faculty_student_yearly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_student_yearly_data', [FacultyReport::class, 'FacultyStudentYearData'])->name('faculty_student_yearly_data');
  Route::get('/manage_reports/faculty_student_quarterly', [FacultyReport::class, 'faculty_student_quarterly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_student_quarterly_data', [FacultyReport::class, 'FacultyStudentQuarterlyData'])->name('faculty_student_quarterly_data');
  // Route::get('/manage_reports/faculty_student_monthly', [FacultyReport::class, 'faculty_student_monthly'])->name('reports-faculty-report');
  // Route::match(['get', 'post'],'/manage_reports/faculty_student_monthly_data', [FacultyReport::class, 'FacultyStudentMonthData'])->name('faculty_student_monthly_data');
  Route::get('/manage_reports/faculty_batch_yearly', [FacultyReport::class, 'faculty_batch_yearly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_batch_yearly_data', [FacultyReport::class, 'FacultyBatchYearData'])->name('faculty_batch_yearly_data');
  Route::get('/manage_reports/faculty_batch_quarterly', [FacultyReport::class, 'faculty_batch_quarterly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_batch_quarterly_data', [FacultyReport::class, 'FacultyBatchQuarterlyData'])->name('faculty_batch_quarterly_data');
  // Route::get('/manage_reports/faculty_batch_monthly', [FacultyReport::class, 'faculty_batch_monthly'])->name('reports-faculty-report');
  // Route::match(['get', 'post'],'/manage_reports/faculty_batch_monthly_data', [FacultyReport::class, 'FacultyBatchMonthData'])->name('faculty_batch_monthly_data');
  Route::get('/manage_reports/faculty_revenue_yearly', [FacultyReport::class, 'faculty_revenue_yearly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_revenue_yearly_data', [FacultyReport::class, 'FacultyRevenueYearData'])->name('faculty_revenue_yearly_data');
  Route::get('/manage_reports/faculty_revenue_monthly', [FacultyReport::class, 'faculty_revenue_monthly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_revenue_monthly_data', [FacultyReport::class, 'FacultyRevenueMonthData'])->name('faculty_revenue_monthly_data');
  Route::get('/manage_reports/faculty_revenue_quarterly', [FacultyReport::class, 'faculty_revenue_quarterly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_revenue_quarterly_data', [FacultyReport::class, 'FacultyRevenueQuarterlyData'])->name('faculty_revenue_quarterly_data');
  Route::get('/manage_reports/faculty_attendance_yearly', [FacultyReport::class, 'faculty_attendance_yearly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_attendance_yearly_data', [FacultyReport::class, 'FacultyAttYearData'])->name('faculty_attendance_yearly_data');
  Route::get('/manage_reports/faculty_attendance_monthly', [FacultyReport::class, 'faculty_attendance_monthly'])->name('reports-faculty-report');
  Route::match(['get', 'post'], '/manage_reports/faculty_attendance_monthly_data', [FacultyReport::class, 'FacultyAttMonthData'])->name('faculty_attendance_monthly_data');
  Route::match(['get', 'post'], '/manage_reports/faculty_positions_list', [FacultyReport::class, 'get_faculty_positions_list'])->name('faculty_positions_list');
  //Accounts Analysis
  Route::get('/manage_reports/branch_income_yearly', [AccountsReport::class, 'index'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/branch_income_yearly_data', [AccountsReport::class, 'BranchIncomeYearData'])->name('branch_income_yearly_data');
  Route::get('/manage_reports/branch_income_monthly', [AccountsReport::class, 'branch_income_monthly'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/branch_income_monthly_data', [AccountsReport::class, 'BranchIncomeMonthData'])->name('branch_income_monthly_data');
  Route::get('/manage_reports/branch_income_quarterly', [AccountsReport::class, 'branch_income_quarterly'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/branch_income_quarterly_data', [AccountsReport::class, 'BranchIncomeQuarterlyData'])->name('branch_income_quarterly_data');
  Route::get('/manage_reports/franchise_income_yearly', [AccountsReport::class, 'franchise_income_yearly'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/franchise_income_yearly_data', [AccountsReport::class, 'FranchiseIncomeYearData'])->name('franchise_income_yearly_data');
  Route::get('/manage_reports/franchise_income_monthly', [AccountsReport::class, 'franchise_income_monthly'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/franchise_income_monthly_data', [AccountsReport::class, 'FranchiseIncomeMonthData'])->name('franchise_income_monthly_data');
  Route::get('/manage_reports/franchise_income_quarterly', [AccountsReport::class, 'franchise_income_quarterly'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/franchise_income_quarterly_data', [AccountsReport::class, 'FranchiseIncomeQuarterlyData'])->name('franchise_income_quarterly_data');
  Route::get('/manage_reports/incomevsexp_month_list', [AccountsReport::class, 'incomevsexp_month_list'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/incomevsexp_month_data', [AccountsReport::class, 'IncomevsExpMonthlyData'])->name('incomevsexp_month_data');
  Route::get('/manage_reports/incomevsexp_yr_list', [AccountsReport::class, 'incomevsexp_yr_list'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/incomevsexp_yr_data', [AccountsReport::class, 'IncomevsExpYearlyData'])->name('incomevsexp_yr_data');
  Route::get('/manage_reports/incomevsexp_quarterly_list', [AccountsReport::class, 'incomevsexp_quarterly_list'])->name('reports-accounts-report');
  Route::match(['get', 'post'], '/manage_reports/incomevsexp_quarterly_data', [AccountsReport::class, 'IncomevsExpQuarterlyData'])->name('incomevsexp_quarterly_data');
  Route::match(['get', 'post'], '/manage_reports/get_branch_list_data', [AccountsReport::class, 'get_type_wise_branch_list'])->name('get_branch_list_data');

  //Placement Analysis
  Route::get('/manage_reports/job_posting_yearly', [PlacementReport::class, 'index'])->name('reports-placement-report');
  Route::match(['get', 'post'], '/manage_reports/job_posting_yearly_data', [PlacementReport::class, 'JobPostingPlaceYearData'])->name('job_posting_yearly_data');
  Route::get('/manage_reports/job_posting_monthly', [PlacementReport::class, 'job_posting_monthly'])->name('reports-placement-report');
  Route::match(['get', 'post'], '/manage_reports/job_posting_monthly_data', [PlacementReport::class, 'JobPostingPlaceMonthData'])->name('job_posting_monthly_data');
  Route::get('/manage_reports/placed_unplaced_stud_yearly', [PlacementReport::class, 'placed_unplaced_stud_yearly'])->name('reports-placement-report');
  Route::match(['get', 'post'], '/manage_reports/placed_unplaced_stud_yearly_data', [PlacementReport::class, 'PlacedUnplacedYearData'])->name('placed_unplaced_stud_yearly_data');
  Route::get('/manage_reports/placed_unplaced_stud_monthly', [PlacementReport::class, 'placed_unplaced_stud_monthly'])->name('reports-placement-report');
  Route::match(['get', 'post'], '/manage_reports/placed_unplaced_stud_monthly_data', [PlacementReport::class, 'PlacedUnplacedMonthData'])->name('placed_unplaced_stud_monthly_data');
  Route::match(['get', 'post'], '/report_job_catogory_list', [PlacementReport::class, 'ReportjobCategoryList'])->name('report_job_catogory_list');


  //Other Analysis
  Route::get('/manage_reports/events_yearly', [OtherReport::class, 'index'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/events_yearly_data', [OtherReport::class, 'EventYearlyData'])->name('events_yearly_data');
  Route::get('/manage_reports/events_monthly', [OtherReport::class, 'events_monthly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/events_monthly_data', [OtherReport::class, 'EventMonthlyData'])->name('events_monthly_data');
  Route::get('/manage_reports/marketing_activity_yearly', [OtherReport::class, 'marketing_activity_yearly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/marketing_activity_yearly_data', [OtherReport::class, 'MarketingActivityYearlyData'])->name('marketing_activity_yearly_data');
  Route::get('/manage_reports/marketing_activity_monthly', [OtherReport::class, 'marketing_activity_monthly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/marketing_activity_monthly_data', [OtherReport::class, 'MarketingActivityMonthlyData'])->name('marketing_activity_monthly_data');
  Route::get('/manage_reports/exam_completed_yearly', [OtherReport::class, 'exam_completed_yearly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/exam_completed_yearly_data', [OtherReport::class, 'ExamCompletedYearData'])->name('exam_completed_yearly_data');
  Route::get('/manage_reports/exam_completed_monthly', [OtherReport::class, 'exam_completed_monthly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/exam_completed_monthly_data', [OtherReport::class, 'ExamCompletedMonthData'])->name('exam_completed_monthly_data');
  Route::get('/manage_reports/intern_stud_yearly', [OtherReport::class, 'intern_stud_yearly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/intern_stud_yearly_data', [OtherReport::class, 'InternStuYearlyData'])->name('intern_stud_yearly_data');
  Route::get('/manage_reports/intern_stud_monthly', [OtherReport::class, 'intern_stud_monthly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/intern_stud_monthly_data', [OtherReport::class, 'InternStuMonthlyData'])->name('intern_stud_monthly_data');
  Route::get('/manage_reports/staff_yearly', [OtherReport::class, 'staff_yearly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/staff_yearly_data', [OtherReport::class, 'StaffYearData'])->name('staff_yearly_data');
  Route::get('/manage_reports/staff_monthly', [OtherReport::class, 'staff_monthly'])->name('reports-other-report');
  Route::match(['get', 'post'], '/manage_reports/staff_monthly_data', [OtherReport::class, 'StaffMonthData'])->name('staff_monthly_data');
  Route::match(['get', 'post'], '/manage_reports/get_all_exam_list', [OtherReport::class, 'get_all_exam_list'])->name('get_all_exam_list');
  Route::match(['get', 'post'], '/manage_reports/get_other_report_department_list', [OtherReport::class, 'get_other_report_department_list'])->name('get_other_report_department_list');

  //Performance Analysis
  Route::get('/manage_reports/production_yearly', [PerformanceReport::class, 'index'])->name('reports-performance-report');
  Route::match(['get', 'post'], '/manage_reports/production_yearly_data', [PerformanceReport::class, 'ProductionYearlyData'])->name('production_yearly_data');
  // Route::get('/manage_reports/goalset_yearly', [PerformanceReport::class, 'goalset_yearly'])->name('reports-performance-report');
  // Route::match(['get', 'post'],'/manage_reports/goalset_yearly_data', [PerformanceReport::class, 'GoalsetYearlyData'])->name('goalset_yearly_data');
  Route::get('/manage_reports/leave_yearly', [PerformanceReport::class, 'leave_percent_yearly'])->name('reports-performance-report');
  Route::match(['get', 'post'], '/manage_reports/leave_yearly_data', [PerformanceReport::class, 'LeavePerYearlyData'])->name('leave_yearly_data');
  Route::get('/manage_reports/stud_count_yearly', [PerformanceReport::class, 'stud_count_yearly'])->name('reports-performance-report');
  Route::match(['get', 'post'], '/manage_reports/stud_count_yearly_data', [PerformanceReport::class, 'ProductionStudentsYearlyData'])->name('stud_count_yearly_data');
  Route::match(['get', 'post'], '/manage_reports/production_staff_list', [PerformanceReport::class, 'getStaffPerformList'])->name('production_staff_list');
  Route::match(['get', 'post'], '/manage_reports/get_all_department_wise_staff', [PerformanceReport::class, 'get_all_department_wise_staff'])->name('get_all_department_wise_staff');
  
  //FeedBack Report
Route::get('/manage_reports/feedback_event_yearly', [FeedbackReport::class, 'feedback_event_yearly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_event_yearly_data', [FeedbackReport::class, 'feedbackEventYearlyData'])->name('feedback_event_yearly_data');
  Route::get('/manage_reports/feedback_event_monthly', [FeedbackReport::class, 'feedback_event_monthly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_event_monthly_data', [FeedbackReport::class, 'feedbackEventMonthlyData'])->name('feedback_event_monthly_data');
  Route::get('/manage_reports/feedback_intern_yearly', [FeedbackReport::class, 'feedback_intern_yearly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_intern_yearly_data', [FeedbackReport::class, 'feedbackInternYearlyData'])->name('feedback_intern_yearly_data');
  Route::get('/manage_reports/feedback_intern_monthly', [FeedbackReport::class, 'feedback_intern_monthly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_intern_monthly_data', [FeedbackReport::class, 'feedbackInternMonthlyData'])->name('feedback_intern_monthly_data');
  Route::get('/manage_reports/feedback_avg_yearly', [FeedbackReport::class, 'feedback_avg_yearly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_avg_yearly_data', [FeedbackReport::class, 'feedbackAvgYearlyData'])->name('feedback_avg_yearly_data');
  Route::get('/manage_reports/feedback_corporate_yearly', [FeedbackReport::class, 'feedback_corporate_yearly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_corporate_yearly_data', [FeedbackReport::class, 'feedbackcorporateYearlyData'])->name('feedback_corporate_yearly_data');
  Route::get('/manage_reports/feedback_corporate_monthly', [FeedbackReport::class, 'feedback_corporate_monthly'])->name('reports-feedback-report');
  Route::match(['get', 'post'], '/manage_reports/feedback_corporate_monthly_data', [FeedbackReport::class, 'feedbackcorporateMonthlyData'])->name('feedback_corporate_monthly_data');
  
  //Customer Management
  Route::match(['get', 'post'], '/customer_management/manage_placed_student', [PlacedStudent::class, 'index'])->name('customer-management-manage-placed-student');
  Route::match(['get', 'post'],'/customer_management/print_cerificate', [ManageCustomer::class, 'certificate_index'])->name('production-cerificate-print');
  Route::match(['get','post'],'/customer_management/print_cerificate_ajax', [ManageCustomer::class, 'print_cerificate_ajax']);
  
    Route::get('/manage_long_absent', [ManageLongAbsent::class, 'Index'])->name('customer-long_absent');
    
  // common setting end
  
  // Reports
//   Route::match(['get', 'post'], '/manage_reports', [ManageReports::class, 'index'])->name('manage_reports');
//   Route::match(['get', 'post'], '/manage_reports/customer_report', [ManageReports::class, 'customer_report'])->name('manage_reports/customer_report');
  Route::match(['get', 'post'], '/manage_reports/customer_course_report', [ManageReports::class, 'customer_course_report'])->name('customer_course_report');
  Route::match(['get', 'post'], '/manage_reports/customer_consolidate_report', [ManageReports::class, 'customer_consolidate_report'])->name('manage_reports/customer_consolidate_report');
  Route::match(['get', 'post'], '/manage_reports/accounts_report', [ManageReports::class, 'accounts_report'])->name('manage_reports/accounts_report');
  Route::match(['get', 'post'], '/manage_reports/batch_report', [ManageReports::class, 'batch_report'])->name('manage_reports/batch_report');
  Route::match(['get', 'post'], '/manage_reports', [ManageReports::class, 'index'])->name('manage_reports');
  Route::match(['get', 'post'], '/source_graph', [ManageReports::class, 'source_graph'])->name('source_graph');
  Route::match(['get', 'post'], '/status_graph', [ManageReports::class, 'status_graph'])->name('status_graph');
  Route::match(['get', 'post'], '/sales_graph', [ManageReports::class, 'sales_graph'])->name('sales_graph');







 Route::get('/role_permission_error', [ErrosController::class, 'index'])->name('role_permission_error');
  // Main Page Route
  Route::get('/', [Analytics::class, 'index'])->name('dashboard-analytics');
  Route::get('/dashboard/analytics', [Analytics::class, 'index'])->name('dashboard-analytics');
  Route::get('/dashboard/crm', [Crm::class, 'index'])->name('dashboard-crm');

  // locale


  // apps
  Route::get('/app/email', [Email::class, 'index'])->name('app-email');
  Route::get('/app/chat', [Chat::class, 'index'])->name('app-chat');
  Route::get('/app/calendar', [Calendar::class, 'index'])->name('app-calendar');
  Route::get('/app/kanban', [Kanban::class, 'index'])->name('app-kanban');
  Route::get('/app/ecommerce/dashboard', [EcommerceDashboard::class, 'index'])->name('app-ecommerce-dashboard');
  Route::get('/app/ecommerce/product/list', [EcommerceProductList::class, 'index'])->name('app-ecommerce-product-list');
  Route::get('/app/ecommerce/product/add', [EcommerceProductAdd::class, 'index'])->name('app-ecommerce-product-add');
  Route::get('/app/ecommerce/product/category', [EcommerceProductCategory::class, 'index'])->name('app-ecommerce-product-category');
  Route::get('/app/ecommerce/order/list', [EcommerceOrderList::class, 'index'])->name('app-ecommerce-order-list');
  Route::get('app/ecommerce/order/details', [EcommerceOrderDetails::class, 'index'])->name('app-ecommerce-order-details');
  Route::get('/app/ecommerce/customer/all', [EcommerceCustomerAll::class, 'index'])->name('app-ecommerce-customer-all');
  Route::get('app/ecommerce/customer/details/overview', [EcommerceCustomerDetailsOverview::class, 'index'])->name('app-ecommerce-customer-details-overview');
  Route::get('app/ecommerce/customer/details/security', [EcommerceCustomerDetailsSecurity::class, 'index'])->name('app-ecommerce-customer-details-security');
  Route::get('app/ecommerce/customer/details/billing', [EcommerceCustomerDetailsBilling::class, 'index'])->name('app-ecommerce-customer-details-billing');
  Route::get('app/ecommerce/customer/details/notifications', [EcommerceCustomerDetailsNotifications::class, 'index'])->name('app-ecommerce-customer-details-notifications');
  Route::get('/app/ecommerce/manage/reviews', [EcommerceManageReviews::class, 'index'])->name('app-ecommerce-manage-reviews');
  Route::get('/app/ecommerce/referrals', [EcommerceReferrals::class, 'index'])->name('app-ecommerce-referrals');
  Route::get('/app/ecommerce/settings/details', [EcommerceSettingsDetails::class, 'index'])->name('app-ecommerce-settings-details');
  Route::get('/app/ecommerce/settings/payments', [EcommerceSettingsPayments::class, 'index'])->name('app-ecommerce-settings-payments');
  Route::get('/app/ecommerce/settings/checkout', [EcommerceSettingsCheckout::class, 'index'])->name('app-ecommerce-settings-checkout');
  Route::get('/app/ecommerce/settings/shipping', [EcommerceSettingsShipping::class, 'index'])->name('app-ecommerce-settings-shipping');
  Route::get('/app/ecommerce/settings/locations', [EcommerceSettingsLocations::class, 'index'])->name('app-ecommerce-settings-locations');
  Route::get('/app/ecommerce/settings/notifications', [EcommerceSettingsNotifications::class, 'index'])->name('app-ecommerce-settings-notifications');
  Route::get('/app/academy/dashboard', [AcademyDashboard::class, 'index'])->name('app-academy-dashboard');
  Route::get('/app/academy/course', [AcademyCourse::class, 'index'])->name('app-academy-course');
  Route::get('/app/academy/course-details', [AcademyCourseDetails::class, 'index'])->name('app-academy-course-details');
  Route::get('/app/logistics/dashboard', [LogisticsDashboard::class, 'index'])->name('app-logistics-dashboard');
  Route::get('/app/logistics/fleet', [LogisticsFleet::class, 'index'])->name('app-logistics-fleet');
  Route::get('/app/invoice/list', [InvoiceList::class, 'index'])->name('app-invoice-list');
  Route::get('/app/invoice/preview', [InvoicePreview::class, 'index'])->name('app-invoice-preview');
  Route::get('/app/invoice/print', [InvoicePrint::class, 'index'])->name('app-invoice-print');
  Route::get('/app/invoice/edit', [InvoiceEdit::class, 'index'])->name('app-invoice-edit');
  Route::get('/app/invoice/add', [InvoiceAdd::class, 'index'])->name('app-invoice-add');
  Route::get('/app/user/list', [UserList::class, 'index'])->name('app-user-list');
  Route::get('/app/user/view/account', [UserViewAccount::class, 'index'])->name('app-user-view-account');
  Route::get('/app/user/view/security', [UserViewSecurity::class, 'index'])->name('app-user-view-security');
  Route::get('/app/user/view/billing', [UserViewBilling::class, 'index'])->name('app-user-view-billing');
  Route::get('/app/user/view/notifications', [UserViewNotifications::class, 'index'])->name('app-user-view-notifications');
  Route::get('/app/user/view/connections', [UserViewConnections::class, 'index'])->name('app-user-view-connections');
  Route::get('/app/access-roles', [AccessRoles::class, 'index'])->name('app-access-roles');
  Route::get('/app/access-permission', [AccessPermission::class, 'index'])->name('app-access-permission');


  // authentication
  // Route::get('/auth/login-basic', [LoginBasic::class, 'index'])->name('auth-login-basic');

  Route::get('/auth/register-basic', [RegisterBasic::class, 'index'])->name('auth-register-basic');
  Route::get('/auth/register-cover', [RegisterCover::class, 'index'])->name('auth-register-cover');
  Route::get('/auth/register-multisteps', [RegisterMultiSteps::class, 'index'])->name('auth-register-multisteps');
  Route::get('/auth/verify-email-basic', [VerifyEmailBasic::class, 'index'])->name('auth-verify-email-basic');
  Route::get('/auth/verify-email-cover', [VerifyEmailCover::class, 'index'])->name('auth-verify-email-cover');
  Route::get('/auth/reset-password-basic', [ResetPasswordBasic::class, 'index'])->name('auth-reset-password-basic');
  Route::get('/auth/reset-password-cover', [ResetPasswordCover::class, 'index'])->name('auth-reset-password-cover');
  Route::get('/auth/forgot-password-basic', [ForgotPasswordBasic::class, 'index'])->name('auth-reset-password-basic');
  Route::get('/auth/forgot-password-cover', [ForgotPasswordCover::class, 'index'])->name('auth-forgot-password-cover');
  Route::get('/auth/two-steps-basic', [TwoStepsBasic::class, 'index'])->name('auth-two-steps-basic');
  Route::get('/auth/two-steps-cover', [TwoStepsCover::class, 'index'])->name('auth-two-steps-cover');


  // icons
  Route::get('/icons/icons-mdi', [MdiIcons::class, 'index'])->name('icons-mdi');

  // tables
  Route::get('/tables/basic', [TablesBasic::class, 'index'])->name('tables-basic');
  Route::get('/tables/datatables-basic', [DatatableBasic::class, 'index'])->name('tables-datatables-basic');
  Route::get('/tables/datatables-advanced', [DatatableAdvanced::class, 'index'])->name('tables-datatables-advanced');
  Route::get('/tables/datatables-extensions', [DatatableExtensions::class, 'index'])->name('tables-datatables-extensions');
});

    // Route::get('/settings/main_settings', 'SettingsController@index')->middleware('auth');
    Route::get('/auth/login-basic', [LoginBasic::class, 'index'])->name('auth-login-basic');
    Route::post('/auth/login-basic', [LoginBasic::class, 'login'])->name('auth-login-basic-post');
    Route::post('/auth/verify', [LoginBasic::class, 'Verify'])->name('auth-verify');
    Route::get('/auth/login-cover', [LoginCover::class, 'index'])->name('auth-login-cover');
    
    
    Route::get('/exam/student_login', [ManageExam::class, 'student_login'])->name('student-login');
    Route::post('/exam/student_login', [ManageExam::class, 'authenticateStudent'])->name('student-login-post');
    Route::get('/', [Login::class, 'index'])->name('login');
    Route::post('/login', [Login::class, 'Login'])->name('login_auth');
    Route::get('/get_staff', [Login::class, 'get_staff'])->name('get-staff');
    Route::get('/forgot_password', [Login::class, 'forgot_password'])->name('forgot-password');
    Route::get('/change_password', [Login::class, 'new_password'])->name('new-password');
    Route::get('/Cronjob_staff_schedule', [Login::class, 'Cronjob_staff_schedule'])->name('Cronjob_staff_schedule');
    Route::get('/Cronjob_scheduled_message', [Login::class, 'Cronjob_scheduled_message'])->name('Cronjob_scheduled_message');
    Route::get('/Cronjob_staff_lead_bank_update', [Cronjobs::class, 'Cronjob_staff_lead_bank_update'])->name('Cronjob_staff_lead_bank_update');
    Route::get('/Cronjob_payment_remainder', [Cronjobs::class, 'Cronjob_payment_remainder'])->name('Cronjob_payment_remainder');
    Route::get('/daily_summary_report', [Cronjobs::class, 'dailySummaryReport'])->name('daily_summary_report');
    
    
    
    
    Route::get('/Cronjob_urbanpro_mdu_led', [Cronjobs::class, 'Cronjob_urbanpro_mdu_led'])->name('Cronjob_urbanpro_mdu_led');

    // Route::get('/Cronjob_list', [Cronjobs::class, 'Index'])->name('Cronjob_list');
    Route::get('/cronjob_list', [Cronjobs::class, 'CronjobList'])->name('cronjoblist');
        Route::get('/cronjob-list', function () {
            return view('content.branch_management.Cronjob');
        });
    Route::get('/Cronjob_otherdb', [Cronjobs::class, 'Cronjob_otherdb'])->name('Cronjob_otherdb');
    Route::get('/Cronjob_call_log', [Cronjobs::class, 'Cronjob_call_log'])->name('Cronjob_call_log');
    Route::get('/Cronjob_lead_calls_update', [Cronjobs::class, 'Cronjob_lead_calls_update'])->name('Cronjob_lead_calls_update');
    Route::get('/Cronjob_lead_calls_update_before_days', [Cronjobs::class, 'Cronjob_lead_calls_update_before_days'])->name('Cronjob_lead_calls_update_before_days');
    Route::get('/Cronjob_lead_phone_verify', [Cronjobs::class, 'Cronjob_lead_phone_verify'])->name('Cronjob_lead_phone_verify');
    Route::get('/Cronjob_staff_goal_set_update', [Cronjobs::class, 'Cronjob_staff_goal_set_update'])->name('Cronjob_staff_goal_set_update');
    Route::get('/Cronjob_team_goal_set_update', [Cronjobs::class, 'Cronjob_team_goal_set_update'])->name('Cronjob_team_goal_set_update');
    Route::match(['get', 'post'], '/Cronjob_ai_questuons', [Cronjobs::class, 'Cronjob_ai_questuons'])->name('Cronjob_ai_questuons');
    Route::match(['get', 'post'], '/getOpenAIBalance', [Cronjobs::class, 'getCreditBalance'])->name('getOpenAIBalance');
    
    Route::get('/CloudCall/call_logs', [CloudCall::class, 'getCallLogs']);
    Route::get('/play-audio', [CloudCall::class, 'streamAudio']);
    Route::get('/googleads', function () {
        return response()->json([
            'status' => 405,
            'message' => 'Method Not Allowed. Please use POST request.'
        ], 405);
    });
    Route::post('/googleads', [OtherSourceLead::class, 'googleads'])->name('googleads');
    
    Route::post('/facebook-leads', [OtherSourceLead::class, 'facebookleads']);
    Route::match(['get', 'post'], '/facebook/webhook', [OtherSourceLead::class, 'facebookhandle']);
    Route::get('/justdial', [OtherSourceLead::class, 'justdial'])->name('justdial');
    Route::get('/website_lead',  [OtherSourceLead::class, 'website_lead'])->name('website_lead');
    Route::get('/urbanpro', [OtherSourceLead::class, 'urbanpro'])->name('urbanpro');
    Route::get('/sulekha', [OtherSourceLead::class, 'sulekha'])->name('sulekha');
    Route::get('/Cronjob_just_dial_lead', [Cronjobs::class, 'Cronjob_just_dial_lead'])->name('Cronjob_just_dial_lead');
    Route::get('/Cronjob_sulekha_lead', [Cronjobs::class, 'Cronjob_sulekha_lead'])->name('Cronjob_sulekha_lead');
    Route::get('/Cronjob_website_lead', [Cronjobs::class, 'Cronjob_website_lead'])->name('Cronjob_website_lead');
     Route::get('/Cronjob_google_lead', [Cronjobs::class, 'Cronjob_google_lead'])->name('Cronjob_google_lead');

    
    Route::get('/Cronjob_session_cleanup', [Cronjobs::class, 'Cronjob_session_cleanup'])->name('Cronjob_session_cleanup');
    
    // Old test callback removed from the authenticated ERP group; use the public signed callback alias below.
    // Gmail Management
    Route::get('/manage_gmail', [ManageGmail::class, 'index'])->name('gmail-manage');
    Route::get('/compose', [ManageGmail::class, 'showComposeForm']);
    Route::post('/send-email', [ManageGmail::class, 'sendEmail'])->name('send-email');
    Route::post('/inbox_view_detail', [ManageGmail::class, 'inboxView'])->name('inbox_view_detail');
    // Verified Qr Certificate
    Route::get('/verified/{id}', [CertificateAuthority::class, 'QrCertiifcate'])->name('verified');
    Route::get('/payment_verified/{id}', [ManageCustomer::class, 'QrInvoice'])->name('payment_verified');
    
    // Discount QR
    Route::get('/Discount-Qr/{id}', [DicountQR::class, 'Index'])->name('Discount-Qr');
    Route::get('/Discount-Qr-View/{id}', [DicountQR::class, 'Discount_View'])->name('Discount-Qr-View');
    Route::get('/Event-Qr-Verify/{id}', [DicountQR::class, 'Event_View'])->name('Event-Qr-Verify');
    Route::post('/checkdDiscountMobileExists', [DicountQR::class, 'checkdDiscountMobileExists'])->name('checkdDiscountMobileExists');
    Route::post('/add_discount_lead', [DicountQR::class, 'Add'])->name('add_discount_lead');
    Route::post('/add_scanners_count_qr', [DicountQR::class, 'Add_scanner_count'])->name('add_scanners_count_qr');
    Route::post('/lead_location_qr', [DicountQR::class, 'lead_location_qr'])->name('lead_location_qr'); 
    Route::post('/lead_call_try_qr', [DicountQR::class, 'lead_call_try_qr'])->name('lead_call_try_qr'); 
    Route::post('/add_call_try_counts', [DicountQR::class, 'Add_call_try_count'])->name('add_call_try_counts');
    
    
    // Catalogue QR
    Route::get('/Catalogue-Qr/{id}', [CatalogueQR::class, 'Index'])->name('Catalogue-Qr');
    Route::get('/Catalogue-Qr-View/{id}', [CatalogueQR::class, 'Catalogue_View'])->name('Catalogue-Qr-View');
    Route::get('/Event-Qr-Verify/{id}', [CatalogueQR::class, 'Event_View'])->name('Event-Qr-Verify');
    Route::post('/checkdCatalogueMobileExists', [CatalogueQR::class, 'checkdCatalogueMobileExists'])->name('checkdCatalogueMobileExists');
    Route::post('/add_catalogue_lead', [CatalogueQR::class, 'Add'])->name('add_catalogue_lead');
    Route::post('/add_scanners_count', [CatalogueQR::class, 'Add_scanner_count'])->name('add_scanners_count');
    Route::post('/add_call_try_count', [CatalogueQR::class, 'Add_call_try_count'])->name('add_call_try_count');
    Route::get('/bran_drop_down_cat', [CatalogueQR::class, 'List'])->name('bran_drop_down_cat');
    Route::get('/Catalogue-Qr-Accept', [CatalogueQR::class, 'Catalogue_Accept'])->name('Catalogue-Qr-Accept');
    Route::get('/Cronjob_hot_lead_update', [Cronjobs::class, 'Cronjob_hot_lead_update'])->name('Cronjob_hot_lead_update');
    Route::get('/Cronjob_CloseInCompleteExam', [Cronjobs::class, 'Cronjob_CloseInCompleteExam'])->name('Cronjob_CloseInCompleteExam');
    Route::get('/Cronjob_DailyPCTaskAssign', [Cronjobs::class, 'Cronjob_DailyPCTaskAssign'])->name('Cronjob_DailyPCTaskAssign');
    
    Route::get('/assesment_certificate_download/{id}', [ManageAssessment::class, 'assesment_certificate_download'])->name('assesment_certificate_download');
    Route::get('/auto-login', [Login::class, 'HandleEGCLogin']);
    //new routes
     Route::get('/student_feedback/{id}/{batch_id}', [StaffBoard::class, 'studentFeedback']);
    Route::get('/student_feedback_list/{id}', [StaffBoard::class, 'List']);
    Route::post('/submit_student_feedback/{id}', [StaffBoard::class, 'studentFeedbackSubmit'])->name('submit_student_feedback');
    Route::get('/event_feedback/{id}/{event_id}', [Events::class, 'eventFeedback']);
    Route::get('/event_feedback_list/{id}', [Events::class, 'ListFeedback']);
    Route::post('/submit_event_feedback/{id}', [Events::class, 'eventFeedbackSubmit'])->name('submit_event_feedback');
     
    Route::get('/intern_feedback/{id}', [ManageIntern::class, 'internFeedback']);
    Route::get('/intern_feedback_list/{id}', [ManageIntern::class, 'ListFeedback']);
    Route::post('/submit_intern_feedback/{id}', [ManageIntern::class, 'internFeedbackSubmit'])->name('submit_intern_feedback');
    Route::match(['get', 'post'],'/manage_intern/confirmation_certificate', [ManageIntern::class, 'PreviewConfirmationCertificate']);
    Route::match(['get', 'post'],'/manage_intern/print_certificate/{id}', [ManageIntern::class, 'PrintConfirmationCertificate']);



    Route::get('/certificate_qr', [CertificateAuthority::class, 'QrCertiifcateVerify']);
    Route::get('/get_sections_by_language/{language_id}', [FeedbackStudentQuestion::class, 'getSections'])->name('get_sections_by_language');

 // whatsapp template Log
    Route::get('/whatsapp_template_log', [WhatsappTemplateLog::class, 'index'])->name('tools_manage-whatsapp_template_log');
    Route::get('/whatsapp_template_history_log', [WhatsappTemplateLog::class, 'historyLog'])->name('tools_manage-whatsapp_template_log');
    Route::get('/whatsapp_template_log/list', [WhatsappTemplateLog::class, 'List']);
    Route::get('/whatsapp_template_log_by_id', [WhatsappTemplateLog::class, 'MessageListByTemplate'])->name('whatsapp_template_log_by_id');
    Route::get('/whatsapp_template_log/template_list', [WhatsappTemplateLog::class, 'TemplateList']);
    
     // WebhookAdminController
  Route::get('/admin/webhooks', [WebhookAdminController::class, 'index'])->name('admin.webhooks');
  Route::post('/admin/webhooks/retry/{id}', [WebhookAdminController::class, 'retry'])->name('admin.webhooks.retry');
  Route::get('/webhooks_log', [WebhookAdminController::class, 'webhooksLog'])->name('webhooks_log');

//   Route::prefix('wa-management')->name('wa-management.')->group(function () {
//     Route::get('/', [WhatsAppManagementController::class, 'index'])->name('index');
//     Route::get('/overview', [WhatsAppManagementController::class, 'overview'])->name('overview');
//     Route::get('/configs', [WhatsAppManagementController::class, 'configs'])->name('configs');
//     Route::post('/config', [WhatsAppManagementController::class, 'saveConfig'])->name('config.save');
//     Route::post('/config/test', [WhatsAppManagementController::class, 'testConfig'])->name('config.test');
//     Route::post('/config/{branchId}/toggle', [WhatsAppManagementController::class, 'toggleConfig'])->name('config.toggle');
//     Route::post('/kill-switch', [WhatsAppManagementController::class, 'killSwitch'])->name('kill-switch');
//     Route::get('/templates', [WhatsAppManagementController::class, 'templates'])->name('templates');
//     Route::post('/templates/sync', [WhatsAppManagementController::class, 'syncTemplates'])->name('templates.sync');
//     Route::post('/templates/{id}/toggle', [WhatsAppManagementController::class, 'toggleTemplate'])->name('templates.toggle');
//     Route::get('/workflows', [WhatsAppManagementController::class, 'workflowRules'])->name('workflows');
//     Route::post('/workflows', [WhatsAppManagementController::class, 'saveWorkflowRule'])->name('workflows.save');
//     Route::post('/workflows/{id}/toggle', [WhatsAppManagementController::class, 'toggleWorkflowRule'])->name('workflows.toggle');
//     Route::get('/outbox', [WhatsAppManagementController::class, 'outbox'])->name('outbox');
//     Route::post('/send/template', [WhatsAppManagementController::class, 'sendTemplate'])->name('send.template');
//     Route::post('/send/text', [WhatsAppManagementController::class, 'sendText'])->name('send.text');
//     Route::post('/send/bulk', [WhatsAppManagementController::class, 'bulkSend'])->name('send.bulk');
//     Route::get('/conversations', [WhatsAppManagementController::class, 'conversations'])->name('conversations');
//     Route::get('/conversations/{phone}/messages', [WhatsAppManagementController::class, 'conversationMessages'])->name('conversation.messages');
//     Route::post('/consent', [WhatsAppManagementController::class, 'recordConsent'])->name('consent');
//     Route::get('/audiences', [WhatsAppManagementController::class, 'audiences'])->name('audiences');
//     Route::post('/audiences', [WhatsAppManagementController::class, 'createAudience'])->name('audiences.create');
//     Route::post('/audiences/{id}/members', [WhatsAppManagementController::class, 'addAudienceMembers'])->name('audiences.members');
//     Route::get('/audiences/{id}/recipients', [WhatsAppManagementController::class, 'bulkFromAudience'])->name('audiences.recipients');
// });

// Compatibility callback alias for installations that still have /test_webhook configured in Meta.
Route::match(['get', 'post'], '/test_webhook', [MetaWhatsAppWebhookController::class, 'handle'])
    ->withoutMiddleware(['auth:web', 'timezone', 'check.maintenance'])->name('whatsapp.webhook.test_alias');

Route::prefix('wa-management')->name('wa-management.')->middleware(['auth:web', 'timezone'])->group(function () {
    Route::get('/', [WhatsAppManagementController::class, 'dashboard'])->name('dashboard');
    Route::get('/chats/{kind}', [WhatsAppManagementController::class, 'chat'])->where('kind', 'lead|customer|common')->name('chat');
    Route::get('/groups', [WhatsAppManagementController::class, 'groups'])->name('groups');
    Route::get('/broadcast', [WhatsAppManagementController::class, 'broadcast'])->name('broadcast');
    Route::get('/calling', [WhatsAppManagementController::class, 'calling'])->name('calling');
    Route::get('/templates', [WhatsAppManagementController::class, 'templatesPage'])->name('templates');
    Route::get('/automation', [WhatsAppManagementController::class, 'automation'])->name('automation');
    Route::get('/campaigns', [WhatsAppManagementController::class, 'campaignsPage'])->name('campaigns');
    Route::get('/logs', [WhatsAppManagementController::class, 'logsPage'])->name('logs');
    Route::get('/setup', [WhatsAppManagementController::class, 'setup'])->name('setup');
    Route::get('/consent', [WhatsAppManagementController::class, 'consentPage'])->name('consent');

    Route::prefix('api')->name('api.')->group(function () {
        Route::get('/overview', [WhatsAppManagementController::class, 'overview']);
        Route::get('/analytics', [WhatsAppManagementController::class, 'analytics']);
        Route::get('/config', [WhatsAppManagementController::class, 'configs']);
        Route::post('/config', [WhatsAppManagementController::class, 'saveConfig']);
        Route::post('/config/test', [WhatsAppManagementController::class, 'testConfig']);
        Route::post('/config/toggle', [WhatsAppManagementController::class, 'toggleConfig']);
        Route::post('/kill-switch', [WhatsAppManagementController::class, 'killSwitch']);
        Route::get('/features', [WhatsAppManagementController::class, 'features']);
        Route::post('/features', [WhatsAppManagementController::class, 'saveFeatures']);
        Route::get('/templates', [WhatsAppManagementController::class, 'templates']);
        Route::post('/templates/sync', [WhatsAppManagementController::class, 'syncTemplates']);
        Route::post('/templates/toggle', [WhatsAppManagementController::class, 'toggleTemplate']);
        Route::get('/workflow-rules', [WhatsAppManagementController::class, 'workflowRules']);
        Route::post('/workflow-rules', [WhatsAppManagementController::class, 'saveWorkflowRule']);
        Route::post('/workflow-rules/toggle', [WhatsAppManagementController::class, 'toggleWorkflowRule']);
        Route::get('/outbox', [WhatsAppManagementController::class, 'outbox']);
        Route::post('/send/template', [WhatsAppManagementController::class, 'sendTemplate']);
        Route::post('/send/text', [WhatsAppManagementController::class, 'sendText']);
        Route::post('/send/bulk', [WhatsAppManagementController::class, 'bulkSend']);
        Route::get('/conversations', [WhatsAppManagementController::class, 'conversations']);
        Route::get('/conversations/{phone}/messages', [WhatsAppManagementController::class, 'conversationMessages']);
        Route::post('/conversations/{phone}/read', [WhatsAppManagementController::class, 'markConversationRead']);
        Route::post('/consent', [WhatsAppManagementController::class, 'recordConsent']);
        Route::get('/audiences', [WhatsAppManagementController::class, 'audiences']);
        Route::post('/audiences', [WhatsAppManagementController::class, 'createAudience']);
        Route::post('/audiences/members', [WhatsAppManagementController::class, 'addAudienceMembers']);
        Route::post('/contacts/create', [WhatsAppManagementController::class, 'createContact']);
        Route::post('/send/media', [WhatsAppManagementController::class, 'sendMedia']);
        Route::post('/send/reaction', [WhatsAppManagementController::class, 'sendReaction']);
        Route::post('/send/location', [WhatsAppManagementController::class, 'sendLocation']);
        Route::post('/send/contact', [WhatsAppManagementController::class, 'sendContactCard']);
        Route::post('/send/interactive', [WhatsAppManagementController::class, 'sendInteractive']);
        Route::post('/send/flow', [WhatsAppManagementController::class, 'sendFlow']);
        Route::get('/media/{messageId}', [WhatsAppManagementController::class, 'mediaContent'])->whereNumber('messageId');
        Route::get('/campaigns', [WhatsAppManagementController::class, 'campaigns']);
    });
});

// SECURITY: Do not put this endpoint inside auth:web. It verifies Meta's GET challenge and POST HMAC.
// Remove the existing /webhook_whatsapp route from inside the authenticated group and add this after it closes.
Route::match(['get', 'post'], '/webhook_whatsapp', [MetaWhatsAppWebhookController::class, 'handle'])
    ->withoutMiddleware(['auth:web', 'timezone'])->name('whatsapp.webhook');