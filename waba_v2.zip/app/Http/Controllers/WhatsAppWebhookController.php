<?php

namespace App\Http\Controllers;

use App\Services\WhatsAppConversationService;
use App\Services\WhatsAppManagerService;
use App\Support\WhatsAppTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/** Compatibility bridge for legacy WhatsApp URLs. New functionality lives under /wa-management. */
class WhatsAppWebhookController extends Controller
{
    public function __construct()
    {
        // Legacy compatibility routes must not bypass the WhatsApp admin allowlist.
        $this->middleware(function ($request, $next) {
            $user = $request->user();
            $allowed = (array) config('whatsapp.admin_user_ids', []);
            $userId = (string) ($user->user_id ?? $user->id ?? '');
            if (!$user || !$allowed || !in_array($userId, array_map('strval', $allowed), true)) abort(403, 'WhatsApp Management administrator access is not configured for this account.');
            return $next($request);
        });
    }

    private function table(string $suffix): string { return WhatsAppTables::name($suffix); }
    private function adminRedirect(string $kind) { return redirect('/wa-management/chats/' . $kind); }

    public function index() { return $this->adminRedirect('lead'); }
    public function CustomerChat() { return $this->adminRedirect('customer'); }
    public function UnknownChat() { return $this->adminRedirect('common'); }

    public function sendMessage(Request $request)
    {
        $phone = (string) $request->input('to', $request->input('phone', $request->input('phone_number', '')));
        $body = (string) $request->input('text', $request->input('message', $request->input('body', '')));
        if (trim($phone) === '' || trim($body) === '') return response()->json(['ok'=>false,'message'=>'Recipient and text are required.'], 422);
        $result = app(WhatsAppManagerService::class)->queueText([
            'branch_id'=>0, 'to'=>$phone, 'text'=>$body, 'source_type'=>'legacy_chat_redirect',
            'created_by'=>(int)($request->user()->user_id ?? $request->user()->id ?? 0),
            'idempotency_key'=>'legacy-chat:'.Str::uuid(),
        ]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function loadMessages(string $phone, Request $request, WhatsAppConversationService $service)
    {
        try { $data = $service->conversationFor(0, urldecode($phone), 'common'); }
        catch (Throwable $e) { return response()->json(['ok'=>false,'message'=>'Invalid contact number.'], 422); }
        return response()->json(['ok'=>true,'data'=>$data]);
    }

    public function CountChange($id, Request $request)
    {
        $message = DB::table($this->table('whatsapp_messages'))->where('id',(int)$id)->first(['meta_message_id','direction']);
        if (!$message || $message->direction !== 'inbound' || !$message->meta_message_id) return response()->json(['ok'=>false,'message'=>'Inbound message not found.'],404);
        $result = app(WhatsAppManagerService::class)->markAsRead((string)$message->meta_message_id);
        return response()->json($result, !empty($result['ok']) ? 200 : 422);
    }

    public function LeadContactInfo(string $phone, Request $request, WhatsAppConversationService $service)
    {
        $branch = (int)($request->user()->branch_id ?? 0);
        return response()->json(['data'=>$service->searchCrmContacts($branch,'lead',urldecode($phone),5)]);
    }
    public function CustomerContactInfo(string $phone, Request $request, WhatsAppConversationService $service)
    {
        $branch = (int)($request->user()->branch_id ?? 0);
        return response()->json(['data'=>$service->searchCrmContacts($branch,'customer',urldecode($phone),5)]);
    }

    public function DeleteForMe($id)
    {
        // We do not destroy shared conversation history from a legacy route; archival/deletion needs an audited UI flow.
        return response()->json(['ok'=>false,'message'=>'Message deletion is not available on the legacy endpoint. Use WhatsApp Management.'],410);
    }
    public function sendSyllabusMessage(Request $request)
    {
        return response()->json(['ok'=>false,'message'=>'Legacy endpoint retired. Configure the event in WhatsApp Management → Automation rules and invoke it from the syllabus controller.'],410);
    }
    public function sendPayRemainderMessage(Request $request)
    {
        return response()->json(['ok'=>false,'message'=>'Legacy endpoint retired. Configure a payment-reminder automation rule and invoke it from the payment workflow.'],410);
    }
    public function getCoursesByCustomer(Request $request)
    {
        return response()->json(['ok'=>false,'message'=>'This legacy route has no implementation in the WhatsApp module. Use the existing Customer/Course API.'],410);
    }

    public function getContactsWithLastMessage(Request $request, WhatsAppConversationService $service)
    {
        return response()->json($service->listConversations((int)($request->user()->branch_id ?? 0),'lead',(string)$request->query('q','')));
    }
    public function getContactsWithLastMessage_customer(Request $request, WhatsAppConversationService $service)
    {
        return response()->json($service->listConversations((int)($request->user()->branch_id ?? 0),'customer',(string)$request->query('q','')));
    }
    public function getContactsWithLastMessage_unknown(Request $request, WhatsAppConversationService $service)
    {
        return response()->json($service->listConversations(0,'common',(string)$request->query('q','')));
    }
}
