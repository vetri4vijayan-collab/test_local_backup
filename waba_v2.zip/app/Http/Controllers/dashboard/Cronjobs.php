<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\File;
use App\Models\AppointmentModel;
use App\Models\AttendanceModel;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\Batch_staff_swap_Model;
use App\Models\BranchModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\GoalSetTeamModel;
use App\Models\EmailTemplateModel;
use App\Models\GoalSetStaffModel;
use App\Models\CronjobMonitorModel;
use App\Models\CronjobLogModel;
use App\Models\LeadModel;
use App\Models\SulekhaModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\WhatsappTemplateLogModel;
use App\Models\PaymentModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\StaffAttendanceModel;
use App\Models\ManageCoursesModel;
use App\Models\StaffModel;
use App\Models\CallTrackerModel;
use App\Models\CugManagementModel;
use App\Models\StaffRescheduleModel;
use App\Models\LeadTransferLogModel;
use App\Models\JustDialModel;
use App\Models\DepartmentModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\HotLeadModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\UserRolePermissionModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\GeneralSettingsModel;
use App\Services\DoubletickService;
use App\Models\GoogleAdsModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\RawLeadModel;
// use App\Events\CronJobUpdated;
use App\Models\ManageQuestionBankModel;
use App\Models\ManageQuestionModel;
use App\Models\AIQuestionModel;
use App\Services\ChatGPTService;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use App\Models\UrbanProModel;
use App\Models\ExamProcessModel;

class Cronjobs extends Controller
{

  protected $doubletickService;

  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;
  protected $chatGPTService;

  public function __construct(DoubletickService $doubletickService, ChatGPTService $chatGPTService)
  {
    $this->doubletickService = $doubletickService;
    $whatsappConfig = app(\App\Services\WhatsAppManagerService::class)->legacyCompatibilityProfile();
    $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
    $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
    $this->baseUrl = 'https://graph.facebook.com/' . config('whatsapp.api_version', 'v26.0');
    $this->businessId = $whatsappConfig->waba_id;
    $this->chatGPTService = $chatGPTService;
  }

  public function CronjobList()
  {
    $cronRoutes = [
      [
        'name' => 'Cronjob otherdb',
        'path' => route('Cronjob_otherdb', [], false),
        'lock' => 'cron_otherdb.lock',
      ],
      [
        'name' => 'Cronjob call log',
        'path' => route('Cronjob_call_log', [], false),
        'lock' => 'cron_call_log.lock',
      ],
      [
        'name' => 'Cronjob lead calls update',
        'path' => route('Cronjob_lead_calls_update', [], false),
        'lock' => 'cron_lead_calls_update.lock',
      ],
      [
        'name' => 'Cronjob lead calls update',
        'path' => route('Cronjob_lead_phone_verify', [], false),
        'lock' => 'Cronjob_lead_phone_verify.lock',
      ],
      [
        'name' => 'Cronjob staff goal set update',
        'path' => route('Cronjob_staff_goal_set_update', [], false),
        'lock' => 'Cronjob_staff_goal_set_update.lock',
      ],
      [
        'name' => 'Cronjob ai questuons',
        'path' => route('Cronjob_ai_questuons', [], false),
        'lock' => 'Cronjob_ai_questuons.lock',
      ],
      [
        'name' => 'Cronjob urbanpro mdu lead',
        'path' => route('Cronjob_urbanpro_mdu_led', [], false),
        'lock' => 'Cronjob_urbanpro_mdu_led.lock',
      ],
      [
        'name' => 'Cronjob_staff_lead_bank_update',
        'path' => route('Cronjob_staff_lead_bank_update', [], false),
        'lock' => 'Cronjob_staff_lead_bank_update.lock',
      ],
      [
        'name' => 'Cronjob scheduled message',
        'path' => route('Cronjob_scheduled_message', [], false),
        'lock' => 'Cronjob_scheduled_message.lock',
      ],
      [
        'name' => 'Cronjob staff schedule',
        'path' => route('Cronjob_staff_schedule', [], false),
        'lock' => 'Cronjob_staff_schedule.lock',
      ],
      [
        'name' => 'Cronjob Sulekha Lead',
        'path' => route('Cronjob_sulekha_lead', [], false),
        'lock' => 'Cronjob_sulekha_lead.lock',
      ],
      // Add others similarly...
    ];
    $cronList = [];
    $logPath = storage_path('logs/laravel-' . date('Y-m-d') . '.log');

    foreach ($cronRoutes as $cron) {
      $lockPath = storage_path('cron_locks/' . $cron['lock']);
      $isRunning = file_exists($lockPath);
      $lastRun = 'Never';

      $logPath = storage_path('logs/laravel-' . date('Y-m-d') . '.log');

      if (file_exists($logPath)) {
        $search = $cron['name'] . ' START';
        $line = '';

        try {
          // Use Process instead of shell_exec
          $process = new Process(['bash', '-c', "grep \"$search\" \"$logPath\" | tail -1"]);
          $process->run();

          if ($process->isSuccessful()) {
            $line = $process->getOutput();
          }
        } catch (\Throwable $e) {
          $line = '';
        }

        if ($line && preg_match('/\[(.*?)\]/', $line, $matches)) {
          $lastRun = $matches[1];
        } elseif ($line) {
          $lastRun = now();
        }
      }

      $cronList[] = [
        'name' => $cron['name'],
        'url' => url($cron['path']),
        'is_running' => $isRunning,
        'last_run' => $lastRun,
      ];
    }
    // event(new \App\Events\CronJobUpdated($cronJobsArray));
    return response()->json([
      'status' => true,
      'data' => $cronList
    ]);
  }

  public function Cronjob_ai_questuons()
  {
    $monitor = CronjobMonitorModel::where('sno', 13)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $AI_list = AIQuestionModel::where('status', '!=', 2)->where('pending_count', '>', 0)->orderBy('sno', 'desc')->limit(5)->get();
    // return $AI_list;
    $chatGPTResponse = '';
    $inserted_records = 0;
    foreach ($AI_list as $list) {
      $previous_count = $list->previous_count;
      $ask_count = $list->ask_count ?? 0;
      $completed_count = $list->completed_count ?? 0;

      $hint_check = $list->hint_check;
      $explanations_check = $list->explanations_check;
      $snippet_check = $list->snippet_check;
      $bank_id = $list->question_bank_id;

      $user_id  = $list->created_by;
      $id  = $list->sno;
      $prompt  = $list->prompt;
      $pending_count = $list->pending_count ?? 0;
      // Retrieve previously stored questions
      $previous_questions = ManageQuestionModel::select('question_name')
        ->where('question_bank_id', $bank_id)
        ->limit(20)
        ->orderBy('sno', 'desc')
        ->pluck('question_name')
        ->toArray();
      // Exclude previously asked questions
      if (!empty($previous_questions)) {
        $prompt .= ". Avoid these questions and give another questions: " . implode(", ", $previous_questions);
      }

      $prompt = str_replace("Please provide _count_", "Please provide 5", $prompt);
      if ($pending_count < 5) {
        $prompt = str_replace("Please provide 5", "Please provide {$pending_count}", $prompt);
        // return $pending_count;
      }
      //   return $prompt;
      $chatGPTResponse = $this->chatGPTService->getChatGPTResponse($prompt, 'gpt-3.5-turbo');

      //   return $chatGPTResponse;
      // Initialize counters
      $skippedCount = 0;
      $insertedCount = 0;

      foreach ($chatGPTResponse as $questionData) {
        if (!isset($questionData['question'], $questionData['options'], $questionData['answer'])) {
          continue; // Skip if required fields are missing
        }

        $chk = ManageQuestionModel::where('question_name', $questionData['question'])->where('question_bank_id', $bank_id)->first();

        if ($chk) {
          $skippedCount++; // Increment skipped count if duplicate found
          continue;
        }

        // Generate a new question_id
        $question_GET = ManageQuestionModel::orderBy('sno', 'desc')->first();
        if (!$question_GET) {
          $year = substr(date('y'), -2);
          $question_id = 'EAQ-0001/' . $year;
        } else {
          $data = $question_GET->question_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);
          $next_number = (int)$result + 1;
          $question_id = sprintf('EAQ-%04d', $next_number) . '/' . substr(date('y'), -2);
        }

        // Create and save the new question
        $question = new ManageQuestionModel();
        $question->question_id = $question_id;
        $question->branch_id = 6;
        $question->question_bank_id = $bank_id;
        $question->question_name = $questionData['question'];
        $question->question_type = 'radio_button';
        $question->question_option = json_encode($questionData['options']);
        $question->answer = $questionData['answer'];

        if ($hint_check && isset($questionData['hint'])) {
          $question->question_hint = 1;
          $question->hint_text = $questionData['hint'];
        } else {
          $question->question_hint = 0;
        }

        if ($explanations_check && isset($questionData['explanation'])) {
          $question->question_explanation = 1;
          $question->explanation_text = $questionData['explanation'];
        } else {
          $question->question_explanation = 0;
        }

        if ($snippet_check && isset($questionData['snippet'])) {
          $question->question_snippet = 1;
          $question->snippet_content = $questionData['snippet'];
        } else {
          $question->question_snippet = 0;
        }

        $question->updated_by = $user_id;
        $question->created_by = $user_id;

        if ($question->save()) {
          $insertedCount++;
          $inserted_records++;
        }
      }

      $update =  AIQuestionModel::where('sno', $id)->first();
      $update->completed_count = $completed_count + $insertedCount;
      $update->pending_count   = $pending_count   - $insertedCount;
      if ($update->pending_count < 1) {
        $update->status = 2;
      }
      $update->update();
    }
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_CloseInCompleteExam()
  {
    $monitor = CronjobMonitorModel::where('sno', 16)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      // Stop execution if cron is OFF
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off',
        ]);
      }

      // Mark cron as running
      $monitor->running_status = 1;
      $monitor->save();
    }

    $processlist = DB::table('za_process_exam')->where('status', '!=', 2)->get();

    $inserted_records = 0;

    foreach ($processlist as $list) {
      $exam_data = DB::table('za_manage_exam')->where('sno', $list->exam_id)->first();
      $exam_duration_in_min = (int) ($exam_data->duration ?? 0);

      if ($exam_duration_in_min > 0) {
        $created_time = Carbon::parse($list->created_at, 'Asia/Kolkata');
        $exam_end_time = $created_time->copy()->addMinutes($exam_duration_in_min);
        $current_time = now('Asia/Kolkata');

        if ($current_time->greaterThan($exam_end_time)) {
          $update = ExamProcessModel::find($list->sno);
          if ($update && $update->status != 2) {

            // 🧮 Calculate total attended duration in seconds
            $total_seconds = $created_time->diffInSeconds($current_time);

            // ⏱ Convert seconds → HH:MM:SS
            $hours = floor($total_seconds / 3600);
            $minutes = floor(($total_seconds % 3600) / 60);
            $seconds = $total_seconds % 60;
            $duration_formatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

            $update->completed_date = $current_time;
            $update->status = 2;
            $update->total_attended_duration = $duration_formatted;
            $update->save();

            $inserted_records++;
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {
      // Update monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      // Insert log
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration = $duration;
      $monitor_log->response = json_encode([
        'processed_records' => $inserted_records,
        'execution_time' => $duration,
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }


  public function getCreditBalance()
  {
    try {
      $balance = $this->chatGPTService->getOpenAICreditBalance();
      return response()->json($balance);
    } catch (\Exception $e) {
      return response()->json(['error' => $e->getMessage()], 500);
    }
  }

  public function Cronjob_staff_lead_bank_update(Request $request)
  {
    $monitor = CronjobMonitorModel::where('sno', 3)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor && $monitor->status != 0) {
      return response()->json([
        'success' => false,
        'message' => 'Cronjob status Off'
      ]);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $today = now('Asia/Kolkata');
    $lastDayOfMonth = now('Asia/Kolkata')->endOfMonth();

    $helper = new \App\Helpers\Helpers();
    $increase_count = $helper->general_setting_data()->lead_bank_count ?? 50;
    $inserted_records = 0;
    $message = '';

    if ($today->isSameDay($lastDayOfMonth)) {
      StaffModel::where('status', 0)->update([
        'lead_bank_count' => $increase_count,
        'month_lead_count' => 0
      ]);
      $message = "Updated successfully";
      $success = true;
    } else {
      $message = "Today is not the last day of the month.";
      $success = false;
    }

    // End time & duration
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update monitor and create log
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
        'message'           => $message
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    return response()->json([
      "success" => $success,
      "message" => $message,
      "processed_records" => $inserted_records,
      "execution_time" => $duration
    ]);
  }

  public function Cronjob_payment_remainder(Request $request)
  {

    // --- Session Cleanup ---
    $sessionPath = storage_path('framework/sessions');
    $files = File::allFiles($sessionPath);

    foreach ($files as $file) {
      try {
        if (File::lastModified($file) < now()->subMinutes(config('session.lifetime'))->getTimestamp()) {
          File::delete($file);
          $this->info("Deleted expired session file: {$file->getFilename()}");
        }
      } catch (\Exception $e) {
        // Log or ignore if the file was not found
        // \Log::warning("Failed to check/delete session file: {$file->getPathname()} - " . $e->getMessage());
      }
    }

    $monitor = CronjobMonitorModel::where('sno', 8)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    // Get the current date
    $today = now(); // Current date
    $lastDayOfMonth = now()->endOfMonth(); // Last day of the current month
    $helper = new \App\Helpers\Helpers();
    // return $today;
    // Get the number of days to send the reminder
    $send_message_before = $helper->general_setting_data()->payment_remainder ?? 1;
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // Calculate the date to compare with nextPayDate
    $reminderDate = date('Y-m-d', strtotime($today->copy()->addDays($send_message_before)));

    // return $reminderDate;

    // Fetch payments where the nextPayDate is equal to the calculated reminder date and status is 0
    $payments = PaymentModel::where('status', 0)
      ->whereDate('nextPayDate', $reminderDate)
      ->orderBy('nextPayDate', 'asc')
      ->get();

    // return $payments;
    //   Send Communication
    $inserted_records = 0;
    foreach ($payments as $i => $pay) {

      $customer         = CustomerModel::where('sno', $pay->customer_id)->first();
      $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
      $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
      $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
      $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
      $gst_amount = isset($pay->amount) ? round(($pay->amount * 18) / 100) : 0;
      $totalAmount      = $pay->amount + $gst_amount;

      $paymentAmt       = number_format($totalAmount, 2, '.', ',');
      $totalAmount      = $paymentAmt . ". Rs";
      $duedate          = date($common_date_format, strtotime($pay->nextPayDate));
      $pay_course_id    = $pay->course_id ?? 1;

      $branch_data = BranchModel::where('sno', $pay->branch_id)->first();
      $branch_name = " ";
      if ($branch_data->branch_type == 1) {
        $branch_name = $branch_data->branch_name;
      } elseif ($branch_data->branch_type == 2) {
        $branch_name = $branch_data->franchise_name;
      }

      // Test Static values
      //   $customer_mails   = 'vetri4vijayan@gmail.com';
      //   $customer_mobiles = '';

      //sms
      if ($customer && $customer_mobiles) {
        $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '006_PaymentRemainder')->first();
        $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
        $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
        $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
        $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
        $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
        $mobile_number   = $country_code . $customer_mobiles;
        $cre_no          = $branch_data->cre_mobile ?? '9677781155';

        // Replace placeholders with actual values
        $replacement_values = [$customer_names, $duedate, $cre_no];
        $message_content    = preg_replace_callback(
          '/\{#var#\}/',
          function () use (&$replacement_values) {
            return array_shift($replacement_values);
          },
          $message_content
        );

        $route    = "default";
        $postData = [
          'authkey' => $authkey,
          'mobiles' => $mobile_number,
          'message' => $message_content,
          'sender'  => $sender_id,
          'route'   => $route,
        ];

        // API URL
        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

        // Initialize the resource
        $ch = curl_init();
        curl_setopt_array($ch, [
          CURLOPT_URL            => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_POST           => true,
          CURLOPT_POSTFIELDS     => $postData,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
        ]);
        // Get response
        $response = curl_exec($ch);
        // return $response;
        $err = curl_error($ch);
        curl_close($ch);
      }
      // Email
      if ($customer && $customer_mails) {
        // return 'each working';
        $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
        $email_template_id = 9; // thank you template
        $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
        $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
        $dynamicSubject    = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
        $content     = $emailTemplate->email_subject;
        $content     = str_replace('#name', $customer_names, $content);
        $content     = str_replace('#course', $coursename->course_name ?? 'Course', $content);
        $content     = str_replace('#amount', $totalAmount, $content);
        $content     = str_replace('#dueDate', $duedate, $content);
        $content     = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

        $branchNo           = $branch_data->mobile ?? '9677781155';
        $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
        $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
        $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
        $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
        $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

        $mailData = [
          'url'         => 'Eapl.com',
          'subject'     => $dynamicSubject,
          'content'     => $content,
          'branchNo'    => $branchNo,
          'branchemail' => $branchemail, // Use the message content from the request
          'fbLink'      => $fbLink,      // Use the message content from the request
          'instaLink'   => $instaLink,   // Use the message content from the request
          'salesMobile' => $branch_data->sales_mobile,
        ];

        $to_address   = $customer_mails;
        $from_address = 'elysiumacademy@elysium.community';
        $from_name    = 'Elysium AcademyÂ®';
        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
      }
      //   $customer_mobiles = '7639093063';
      // Whatapp
      if ($customer && $customer_mobiles) {

        $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
        $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
        $hasHeader  = false; // Example flag: set based on template
        $hasBody    = false; // Example flag: set based on template
        $components = [];
        $couponCode = " ";

        // Example flag: set based on template
        $components_trans = [];
        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
        // $currentHour = date('H'); // Get current hour in 24-hour format
        if ($currentHour >= 5 && $currentHour < 12) {
          $greeting = 'Good Morning';
        } elseif ($currentHour >= 12 && $currentHour < 18) {
          $greeting = 'Good Afternoon';
        } else {
          $greeting = 'Good Evening';
        }
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $paymentDate        = date($common_date_format);


        $templateName = 'elysium_academy_pay_reminder2';
        $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
        $bodyText     = [
          [
            'type'           => 'text',
            'text'           => $greeting,
            'parameter_name' => 'greet_msg',
          ],
          [
            'type'           => 'text',
            'text'           => $customer_names,
            'parameter_name' => 'customer_name',
          ],
          [
            'type'           => 'text',
            'text'           => $coursename->course_name ?? 'Course',
            'parameter_name' => 'course_name',
          ],
          [
            'type'           => 'text',
            'text'           => $totalAmount,
            'parameter_name' => 'amount',
          ],
          [
            'type'           => 'text',
            'text'           => $duedate,
            'parameter_name' => 'due_date',
          ],
          [
            'type'           => 'text',
            'text'           => $cre->nick_name ?? 'Elsa',
            'parameter_name' => 'cre_name',
          ],
          [
            'type'           => 'text',
            'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
            'parameter_name' => 'contact_email',
          ],
          [
            'type'           => 'text',
            'text'           => $branch_name ?? 'Elysium Academy',
            'parameter_name' => 'branch_name',
          ],
          [
            'type'           => 'text',
            'text'           => $branch_data->sales_mobile ?? '9677781155',
            'parameter_name' => 'contact_no',
          ],

        ];
        $components_trans[] = [
          'type'       => 'header',
          'parameters' => [
            [
              'type'  => 'image',
              'image' => [
                'link' => $headerImage, // Dynamically set header image
              ],
            ],
          ],
        ];

        $components_trans[] = [
          'type'       => 'body',
          'parameters' => $bodyText,
        ];
        $dynamicParameters         = $templateParameters[$templateName] ?? [];
        $WhatsAppBusinessAccountId = $this->businessId;
        $accessToken               = $this->accessToken;
        $fromPhoneNumberId         = $this->phoneNumberId;

        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

        $to           = $customer_mobiles;
        $languageCode = 'en';

        if (strpos($to, '+91') !== 0) {
          $to = '+91' . $to;
        }

        $message = 'test~message';

        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $to,
          'type'              => 'template',
          'template'          => [
            'name'       => $templateName,
            'language'   => [
              'code' => $languageCode,
            ],
            'components' => $components_trans,
          ],
        ];

        $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
      }

      $inserted_records++;
    }



    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function dailySummaryReport(Request $request)
  {

    try {
      $currentHour = Carbon::now('Asia/Kolkata')->hour; // 0-23

      if ($currentHour == 20) { // 20 = 8 PM
        $monitor = CronjobMonitorModel::where('sno', 15)->first();
        $start_time = microtime(true);
        $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

        if ($monitor) {
          if ($monitor->status != 0) {
            Log::info("Cronjob dailySummaryReport stopped: Cron OFF");
            return response()->json([
              'success' => false,
              'message' => 'Cronjob status Off'
            ]);
          }
          $monitor->running_status = 1;
          $monitor->save();
        }

        $today = now(); // Current date
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

        $branchAll = BranchModel::where('status', 0)->whereNotIn('sno', [3])->get();
        $inserted_records = 0;

        foreach ($branchAll as $i => $brach) {
          try {
            $currentDayCustomerCountNav = CustomerModel::whereIn('za_customer.status', [0, 6])
              ->where('za_customer.branch_id', $brach->sno)
              ->whereDate('za_customer.created_at', $today->format('Y-m-d'))
              ->count();

            $currentDaytransaction = DB::table('za_transaction')
              ->where('za_transaction.branch_id', $brach->sno)
              ->whereDate('za_transaction.transaction_date', $today->format('Y-m-d'))
              ->sum('za_transaction.credit');

            $currentMonthCustomerCountNav = CustomerModel::whereIn('za_customer.status', [0, 6])
              ->where('za_customer.branch_id', $brach->sno)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->count();

            $currentMonthtransaction = DB::table('za_transaction')
              ->where('za_transaction.branch_id', $brach->sno)
              ->whereYear('za_transaction.transaction_date', date('Y'))
              ->whereMonth('za_transaction.transaction_date', date('m'))
              ->sum('za_transaction.credit');


            $branch_data = BranchModel::where('sno', $brach->sno)->first();
            $branch_name = "";
            if ($branch_data->branch_type == 1) {
              $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
              $branch_name = $branch_data->franchise_name;
            }

            $branch_names = $branch_name ?? 'Elysium Academy';
            $currentdate = date($common_date_format, strtotime($today));

            $overall_collection   = number_format($currentMonthtransaction, 2, '.', ',');
            $overall_registration = $currentMonthCustomerCountNav;
            $today_collection     = number_format($currentDaytransaction, 2, '.', ',');
            $today_registration   = $currentDayCustomerCountNav;

            // WhatsApp recipients
            $staticnumber = '7708053111';
            $branch_mobile = $brach->mobile;
            $recipients = [];
            if (!empty($branch_mobile)) $recipients[] = $branch_mobile;
            if ($brach->sno == 6) $recipients[] = $staticnumber;

            if (!empty($recipients)) {
              $templateName = "daily_summary";
              $components = [];
              $bodyText = [
                ['type' => 'text', 'text' => $branch_names, 'parameter_name' => 'branch_name'],
                ['type' => 'text', 'text' => $currentdate, 'parameter_name' => 'date'],
                ['type' => 'text', 'text' => $today_registration, 'parameter_name' => 'today_registration'],
                ['type' => 'text', 'text' => $today_collection, 'parameter_name' => 'today_collection'],
                ['type' => 'text', 'text' => $overall_registration, 'parameter_name' => 'overall_registration'],
                ['type' => 'text', 'text' => $overall_collection, 'parameter_name' => 'overall_collection'],
              ];
              $components[] = ['type' => 'body', 'parameters' => $bodyText];

              $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
              $accessToken               = $this->accessData($request)->access_tokken;
              $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
              $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

              foreach ($recipients as $lead_mobile) {
                $mobile = preg_replace('/\D/', '', $lead_mobile);
                // $mobile = '9677482114';
                $to = (strpos($lead_mobile, '+') === 0) ? $lead_mobile : '+91' . $mobile;

                $payload = [
                  'messaging_product' => 'whatsapp',
                  'to' => $to,
                  'type' => 'template',
                  'template' => [
                    'name' => $templateName,
                    'language' => ['code' => 'en'],
                    'components' => $components
                  ],
                ];

                $response = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

                if ($response['status'] == 200) {
                  $log_branch_id = $brach->sno ?? 1;
                  $unique_id = $brach->sno ?? 0;
                  $send_user_id = 0;
                  $source = 'Branch';
                  $module_name = 'Cronjob - Daily Summary Report';
                  $log_phone_no = $to;
                  $log_template_name = $templateName;

                  $save_log = $this->WhatsappSendLog(
                    $response,
                    $payload,
                    $log_phone_no,
                    $log_template_name,
                    $send_user_id,
                    $log_branch_id,
                    $unique_id,
                    $source,
                    $module_name
                  );
                }

                // Log WhatsApp response
                Log::info("WhatsApp dailySummaryReport sent to {$to}: " . json_encode($response));
                Log::info("WhatsApp dailySummaryReport sent to {$to}: - PayLoad" . json_encode($payload));
              }
            }

            $inserted_records++;
          } catch (\Exception $e) {
            // Log branch-level errors and continue
            Log::error("Error processing branch {$brach->sno} - {$brach->branch_name}: " . $e->getMessage());
          }
        }

        // Execution time logging
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 4);
        $hours   = floor($execution_time / 3600);
        $minutes = floor(($execution_time % 3600) / 60);
        $seconds = $execution_time % 60;
        $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
        $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

        if ($monitor) {
          $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
          $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
          $monitor->sync_duration        = $duration;
          $monitor->running_status       = 0;
          $monitor->save();

          $monitor_log = new CronjobLogModel();
          $monitor_log->cronjob_id           = $monitor->sno;
          $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
          $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
          $monitor_log->sync_duration        = $duration;
          $monitor_log->response             = json_encode([
            'processed_records' => $inserted_records,
            'execution_time'    => $duration,
          ]);
          $monitor_log->created_by  = 0;
          $monitor_log->updated_by  = 0;
          $monitor_log->save();
        }
      }
    } catch (\Exception $e) {
      Log::error("dailySummaryReport Cronjob failed: " . $e->getMessage());
      Log::error($e->getTraceAsString());
    }
  }

  //   public function dailySummaryReport(Request $request)
  //   {

  //      $currentHour = Carbon::now('Asia/Kolkata')->hour; // 0-23
  //     if ($currentHour >= 20 && $currentHour < 21) { // 20 = 8 PM
  //         $monitor = CronjobMonitorModel::where('sno', 15)->first();
  //         $start_time = microtime(true);
  //         // Get start time in India time
  //         $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
  //         if ($monitor) {
  //           if ($monitor->status != 0) {
  //             // Stop execution if cron is OFF
  //             return response()->json([
  //               'success' => false,
  //               'message' => 'Cronjob status Off'
  //             ]);
  //           }
  //           $monitor->running_status = 1;
  //           $monitor->save();
  //         }
  //         //   return $monitor;
  //         // Get the current date
  //         $today = now(); // Current date
  //         $helper = new \App\Helpers\Helpers();
  //         $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  //         // return $today;
  //         // i need to run this cronjob every day 8 clock

  //         // Fetch payments where the nextPayDate is equal to the calculated reminder date and status is 0
  //         $branchAll = BranchModel::where('status', 0)
  //         ->whereNotIn('sno', [3])
  //         ->get();

  //         // return $payments;
  //         //   Send Communication
  //         $inserted_records = 0;
  //         foreach ($branchAll as $i => $brach) {
  //             $currentDayCustomerCountNav = CustomerModel::whereIn('za_customer.status',[0,6])
  //                   ->where('za_customer.branch_id', $brach->sno)
  //                   ->whereYear('za_customer.created_at', date('Y'))
  //                   ->whereMonth('za_customer.created_at', date('m'))
  //                   ->whereDay('za_customer.created_at', date('d'))
  //                   ->count();
  //             $currentDaytransaction = DB::table('za_transaction')
  //                           ->where('za_transaction.branch_id', $brach->sno)
  //                           ->whereYear('za_transaction.transaction_date', date('Y'))
  //                           ->whereMonth('za_transaction.transaction_date', date('m'))
  //                           ->whereDay('za_transaction.transaction_date', date('d'))
  //                          ->sum('za_transaction.credit');
  //           $currentMonthCustomerCountNav = CustomerModel::whereIn('za_customer.status',[0,6])
  //                   ->where('za_customer.branch_id', $brach->sno)
  //                   ->whereYear('za_customer.created_at', date('Y'))
  //                   ->whereMonth('za_customer.created_at', date('m'))
  //                   ->count();
  //             $currentMonthtransaction = DB::table('za_transaction')
  //                          ->where('za_transaction.branch_id', $brach->sno)
  //                           ->whereYear('za_transaction.transaction_date', date('Y'))
  //                         ->whereMonth('za_transaction.transaction_date', date('m'))
  //                          ->sum('za_transaction.credit');

  //             $branch_names         = isset($brach->branch_name) ? $brach->branch_name : $brach->franchise_name;
  //             $currentdate          = date($common_date_format, strtotime($today));

  //             $overall_collection   = isset($currentMonthtransaction) ? number_format($currentMonthtransaction, 2, '.', ',') : 0;
  //             $overall_registration = isset($currentMonthCustomerCountNav) ? $currentMonthCustomerCountNav : 0;
  //             $today_collection     = isset($currentDaytransaction) ? number_format($currentDaytransaction, 2, '.', ',') : 0;
  //             $today_registration   = isset($currentDayCustomerCountNav) ? $currentDayCustomerCountNav : 0;


  //           $branch_data = BranchModel::where('sno', $brach->sno)->first();
  //           $branch_name = " ";
  //           if ($branch_data->branch_type == 1) {
  //             $branch_name = $branch_data->branch_name;
  //           } elseif ($branch_data->branch_type == 2) {
  //             $branch_name = $branch_data->franchise_name;
  //           }
  //                 $staticnumber = '7708053111';
  //                 $branch_mobile = $brach->mobile; // regular branch mobile

  //                 $recipients = [];

  //                 // Always send to branch mobile if available
  //                 if (!empty($branch_mobile)) {
  //                     $recipients[] = $branch_mobile;
  //                 }

  //                 // If this is branch 6, also add the admin number
  //                 if ($brach->sno == 6) {
  //                     $recipients[] = $staticnumber;
  //                 } // testing number after we can dynamic get from loop
  //           // Whatapp
  //             if (!empty($recipients)) {
  //                 $templateName  = "daily_summary";

  //                 $hasHeader  = false; // Example flag: set based on template
  //                 $hasBody    = false; // Example flag: set based on template
  //                 $hasFooter  = false; // Example flag: set based on template
  //                 $hasButton  = false;
  //                 $components = [];
  //                 $couponCode = " ";
  //                 date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
  //                 $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
  //                                                           // $currentHour = date('H'); // Get current hour in 24-hour format
  //                 if ($currentHour >= 5 && $currentHour < 12) {
  //                     $greeting = 'Good Morning';
  //                 } elseif ($currentHour >= 12 && $currentHour < 18) {
  //                     $greeting = 'Good Afternoon';
  //                 } else {
  //                     $greeting = 'Good Evening';
  //                 }

  //                 if ($templateName == 'daily_summary') {
  //                     // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
  //                     $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
  //                     $couponCode  = 'NOOFFER';
  //                     $buttonIndex = 1;
  //                     $bodyText    = [
  //                     [
  //                         'type'           => 'text',
  //                         'text'           =>  $branch_names ?? 'Elysium Academy',
  //                         'parameter_name' => 'branch_name',
  //                     ],
  //                     [
  //                         'type'           => 'text',
  //                         'text'           =>  $currentdate,
  //                         'parameter_name' => 'date',
  //                     ],
  //                     [
  //                         'type'           => 'text',
  //                         'text'           => $today_registration,
  //                         'parameter_name' => 'today_registration',
  //                     ],
  //                     [
  //                         'type'           => 'text',
  //                         'text'           => $today_collection,
  //                         'parameter_name' => 'today_collection',
  //                     ],
  //                     [
  //                         'type'           => 'text',
  //                         'text'           => $overall_registration,
  //                         'parameter_name' => 'overall_registration',
  //                     ],
  //                     [
  //                         'type'           => 'text',
  //                         'text'           => $overall_collection,
  //                         'parameter_name' => 'overall_collection',
  //                     ],

  //                     ];
  //                     $hasHeader = false;
  //                     $hasBody   = true;
  //                     $hasButton = false;
  //                 }

  //                 // Add Header if required
  //                 if ($hasHeader) {
  //                     $components[] = [
  //                         'type'       => 'header',
  //                         'parameters' => [
  //                             [
  //                                 'type'  => 'image',
  //                                 'image' => [
  //                                     'link' => $headerImage, // Dynamically set header image
  //                                 ],
  //                             ],
  //                         ],
  //                     ];
  //                 }

  //                 // Add Body if required
  //                 if ($hasBody) {
  //                     $components[] = [
  //                         'type'       => 'body',
  //                         'parameters' => $bodyText,
  //                     ];
  //                 }

  //                 // Add Footer if required
  //                 if ($hasButton) {
  //                     $components[] = [
  //                         'type'       => 'button',
  //                         'sub_type'   => 'url',
  //                         'index'      => 0,
  //                         'parameters' => [
  //                             [
  //                                 'type' => 'text',
  //                                 'text' => $certificate_key,
  //                             ],
  //                         ],
  //                     ];
  //                 }


  //                 $dynamicParameters         = $templateParameters[$templateName] ?? [];
  //                 $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
  //                 $accessToken               = $this->accessData($request)->access_tokken;
  //                 $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

  //                 $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

  //                 foreach ($recipients as $lead_mobile) {
  //                      $mobile = preg_replace('/\D/', '', $lead_mobile); // remove any non-digits
  //                         if (strpos($lead_mobile, '+') === 0) {
  //                             $to = $lead_mobile;
  //                         } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
  //                             $to = '+' . $mobile;
  //                         } else {
  //                             $to = '+91' . $mobile;
  //                         }
  //                     $languageCode = 'en';

  //                     $message = 'test~message';
  //                     if (empty($components)) {
  //                         $payload = [
  //                             'messaging_product' => 'whatsapp',
  //                             'to'                => $to,
  //                             'type'              => 'template',
  //                             'template'          => [
  //                                 'name'     => $templateName,
  //                                 'language' => [
  //                                     'code' => $languageCode,
  //                                 ],
  //                             ],
  //                         ];
  //                     } else {
  //                         $payload = [
  //                             'messaging_product' => 'whatsapp',
  //                             'to'                => $to,
  //                             'type'              => 'template',
  //                             'template'          => [
  //                                 'name'       => $templateName,
  //                                 'language'   => [
  //                                     'code' => $languageCode,
  //                                 ],
  //                                 'components' => $components,
  //                             ],
  //                         ];
  //                     }

  //                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

  //                     Log::error('WhatsApp API Error Cronjob dailySummaryReport : ' . $response);
  //                     Log::info('WhatsApp API Error Cronjob dailySummaryReport : ' . $response);
  //                 }

  //               }

  //           $inserted_records++;
  //         }

  //         $end_time = microtime(true);
  //         $execution_time = round($end_time - $start_time, 4);

  //         $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
  //           // Convert seconds → H:i:s
  //         $hours   = floor($execution_time / 3600);
  //         $minutes = floor(($execution_time % 3600) / 60);
  //         $seconds = $execution_time % 60;
  //         $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

  //         if ($monitor) {

  //             // Update the monitor
  //             $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
  //             $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
  //             $monitor->sync_duration        = $duration;
  //             $monitor->running_status       = 0;
  //             $monitor->save();

  //             // Create a log record
  //             $monitor_log = new CronjobLogModel();
  //             $monitor_log->cronjob_id           = $monitor->sno;
  //             $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
  //             $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
  //             $monitor_log->sync_duration        = $duration;
  //             $monitor_log->response             = json_encode([
  //                                                     'processed_records' => $inserted_records,
  //                                                     'execution_time'    => $duration,
  //                                                 ]);
  //             $monitor_log->created_by  = 0;
  //             $monitor_log->updated_by  = 0;
  //             $monitor_log->save();
  //     }

  // Return the count of updated records
  //         return [
  //             'processed_records' => $inserted_records,
  //             'execution_time'    => "{$execution_time} seconds",
  //         ];
  //      }else{
  //          return [
  //             'processed_records' => 0,
  //             'time' => 'not 8 pm ',
  //             'execution_time'    => "{0} seconds",
  //         ];
  //      }
  //   }
  public function accessData(Request $request)
  {
    $whatsappConfig = app(\App\Services\WhatsAppManagerService::class)->legacyCompatibilityProfile();
    return $whatsappConfig;
  }

  private function sendRequestToWhatsApp($url, $token, $data)
  {
      // Compatibility shim only: the original URL/token are intentionally ignored.
      // Admin-managed global automation rule selects the actual Meta-approved template.
      $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
      $callerMethod = $trace[1]['function'] ?? 'unknown';
      return app(\App\Services\WhatsAppLegacyDispatchService::class)->dispatch(static::class, $callerMethod, (array) $data);
  }

  private function sendEmail($template_id, $entity, $type)
  {
    $emailTemplate = EmailTemplateModel::find($template_id);
    if (! $emailTemplate) {
      // Log::error("Email Template not found for ID: {$update->email_template_id}");
      return;
    }

    // Dynamically map the fields based on the type
    $name     = $type === 'lead' ? $entity->lead_name : $entity->cus_name;
    $email    = $type === 'lead' ? $entity->lead_email_id : $entity->cus_email_id;
    $gender   = $type === 'lead' ? $entity->lead_gender : $entity->cus_gender;
    $contact2 = $type === 'lead' ? $entity->phone_number : $entity->cus_phone_number;

    // $branchMobile = BranchModel::find($entity->branch_id)?->mobile; // Assuming branch_id exists in both tables
    $branch_data = BranchModel::where('sno', $entity->branch_id)->first();
    $branch_name = " ";
    if ($branch_data->branch_type == 1) {
      $branch_name = $branch_data->branch_name;
    } elseif ($branch_data->branch_type == 2) {
      $branch_name = $branch_data->franchise_name;
    }

    // $coursename = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();

    // $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
    $dynamicSubject = str_replace('#course', 'Java Full stack', $emailTemplate->email_name);

    // $helper             = new \App\Helpers\Helpers();
    // $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // $paymentDate        = date($common_date_format);
    // $paymentAmt         = number_format($totalAmount, 2, '.', ',');
    // $paymentAmount      = $paymentAmt . ". Rs";
    $content     = $emailTemplate->email_subject;
    $content     = str_replace('#name', "Raja", $content);
    $content     = str_replace('#course', 'Java Full Stack', $content);
    $content     = str_replace('#amount', "5000.Rs", $content);
    $content     = str_replace('#dueDate', "26-Jan-2025", $content);
    $content     = str_replace('#mail', 'info@elysiumacademy.org', $content);
    $branchNo    = $branch_data->mobile ?? "67865787545";
    $branchemail = $branch_data->mail ?? "hfghdgh";
    $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
    $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
    $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? 'Branch Mobile', $content);
    $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

    $mailData = [
      'url'         => 'Eapl.com',
      'subject'     => $dynamicSubject,
      'content'     => $content,
      'branchNo'    => $branchNo,
      'branchemail' => $branchemail, // Use the message content from the request
      'fbLink'      => $fbLink,      // Use the message content from the request
      'instaLink'   => $instaLink,   // Use the message content from the request
      'salesMobile' => $branch_data->sales_mobile,
    ];

    $to_address   = $email;
    $from_address = 'elysiumacademy@elysium.community';
    $from_name    = 'Elysium AcademyÂ®';
    Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
  }

  public function Cronjob_otherdb()
  {
    // Connect to the secondary database
    $other_db = DB::connection('mysql_secondary');
    return DB::connection('mysql_secondary')->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('user as u')
      ->select(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id',
        $other_db->raw('SUM(CASE WHEN cl.call_log_id IS NOT NULL THEN 1 ELSE 0 END) as call_log_count') // Sum the call logs
      )
      ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')  // Join company table
      ->leftJoin('call_log as cl', 'u.user_id', '=', 'cl.user_id')      // Join call_log table
      ->where('u.company_id', 3)  // Filter by company_id
      ->where('cl.count_status', 0)  // Filter by company_id
      ->groupBy(
        'u.user_id',
        'u.name',
        'u.nick_name',
        'u.phone_no',
        'u.user_code',
        'u.is_primary',
        'u.company_id',
        'c.company_name',
        'u.department_id'  // Group by user attributes and company details
      )
      ->get();
    $total = 0;
    foreach ($users_with_call_log_count as $list) {
      $total += $list->call_log_count;
    }

    //      $user_logs_update = $other_db
    // ->table('call_log')
    // ->where('count_status', '!=', 0) // Update only records where count_status is not already 0
    // ->update(['count_status' => 0]);


    //   $user_logs_update = $other_db
    // ->table('call_log')
    // ->where('count_status', '!=', 0)->count(); // Update only records where count_status is not already 0
    // // ->update(['count_status' => 0]);


    return $total;
  }

  public function Cronjob_call_log()
  {
    //  return "stop";
    $lockDir = storage_path('cron_locks');
    $lockPath = $lockDir . '/Cronjob_call_log.lock';

    // Create directory if not exists
    if (!file_exists($lockDir)) {
      mkdir($lockDir, 0775, true);
    }

    // Prevent duplicate runs
    // if (file_exists($lockPath)) {
    //     return response()->json([
    //         'success' => false,
    //         'message' => 'Cron is already running.'
    //     ]);
    // }

    // Create lock
    file_put_contents($lockPath, now());
    try {
      //   \Log::info('Cronjob_call_log START');
      //   return 'stop';
      $monitor = CronjobMonitorModel::where('sno', 1)->first();
      $start_time = microtime(true);
      // Get start time in India time
      $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
      if ($monitor) {
        if ($monitor->status != 0) {
          // Stop execution if cron is OFF
          return response()->json([
            'success' => false,
            'message' => 'Cronjob status Off'
          ]);
        }
        $monitor->running_status = 1;
        $monitor->save();
      }
      $other_db = DB::connection('mysql_secondary');
      $branches = BranchModel::select('sno AS branch_id', 'call_tracker_branch_id')
        ->where('status', 0)
        ->where('call_tracker_branch_id', '>', 0)
        ->where('sno', '!=', 6)
        ->get();

      $all_users = []; // Array to store all users with branch_id
      $inserted_records = []; // Array to store inserted records

      foreach ($branches as $branch) {
        $getmobiles = CugManagementModel::select('staff_mobile', 'staff_id')
          ->where('branch_id', $branch->branch_id)
          ->where('status', 0)
          ->get();
            // return $getmobiles;
            
        foreach ($getmobiles as $mobile) {
          $select_users = $other_db
            ->table('user as u')
            ->select('u.user_id', 'u.name', 'u.nick_name', 'u.phone_no', 'u.user_code', 'u.status', 'u.company_id', 'c.company_name', 'u.department_id')
            ->leftJoin('company as c', 'u.company_id', '=', 'c.company_id')
            ->where('u.phone_no', $mobile->staff_mobile)
            ->where('u.status', 0)
            ->where('u.company_id', $branch->call_tracker_branch_id)
            ->get();
            

          if (!$select_users->isEmpty()) {
            foreach ($select_users as $user) {
              $user->branch_id = $branch->branch_id; // Add branch_id to user data
              $user_logs = $other_db
                ->table('call_log as cl')
                ->select('cl.call_log_id', 'cl.count_status', 'cl.contact_book_id', 'cl.call_date', 'cl.call_end_date', 'cl.call_time', 'cl.call_end_time', 'cl.duration', 'cl.latitude', 'cl.longitude', 'cl.status AS log_status', 'cb.phone_no as customer_phone_no', 'cb.contact_name as customer_name', 'cb.reason as customer_reason', 'cb.status as customer_status')
                ->leftJoin('contact_book as cb', 'cl.contact_book_id', '=', 'cb.contact_book_id')
                ->where('cl.user_id', $user->user_id) // Assuming you have user_id in call_log
                ->whereYear('cl.call_date', '>', '2021')
                ->where('cl.count_status', 0)
                ->orderBy('cl.call_date', 'ASC')
                ->limit(100)
                ->get();

              // Add logs to user data
              $user->logs = $user_logs; // Add logs to user data
              // $all_users[] = (array) $user; // Convert object to array and store

              //   return $user_logs;

              // Check if there are logs to insert
              if (!$user_logs->isEmpty()) {
                foreach ($user_logs as $log) {
                  $status = $log->log_status;
                  $call_duration = $log->duration;

                  if ($status === 0 && $call_duration != '00:00:00') {
                    $staus_up = $log->log_status;
                  } elseif ($status === 0 && $call_duration == '00:00:00') {
                    $staus_up = 4;
                  } else {
                    $staus_up = $log->log_status;
                  }
                  $record = CallTrackerModel::create([
                    'branch_id' => $branch->branch_id,
                    'branch_staff_id' => $mobile->staff_id ?? 51,
                    'call_tracker_staff_id' => $user->user_id,
                    'staff_phone_no' => $user->phone_no,
                    'customer_phone_no' => $log->customer_phone_no,
                    'customer_name' => $log->customer_name ?: 'Unknown',
                    'customer_status' => $log->customer_status,
                    'customer_reason' => $log->customer_reason,
                    'call_start_date' => $log->call_date,
                    'call_end_date' => $log->call_end_date ?: null,
                    'call_start_time' => $log->call_time,
                    'call_end_time' => $log->call_end_time,
                    'call_duration' => $log->duration,
                    'latitude' => $log->latitude,
                    'longitude' => $log->longitude,
                    'call_status' => $staus_up
                  ]);
                  $user_logs_upadte = $other_db
                    ->table('call_log')
                    ->where('call_log_id', $log->call_log_id)
                    ->update(['count_status' => 1]);
                  // Store inserted record for return
                  $inserted_records[] = 1; // Add a count for each inserted record
                }
              }
            }
          }
        }
      }
      //   \Log::info('Cronjob_call_log END - Inserted: ' . count($inserted_records));
      // Return all users and their logs, along with the inserted records
      $end_time = microtime(true);
      $execution_time = round($end_time - $start_time, 4);

      $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
      // Convert seconds → H:i:s
      $hours   = floor($execution_time / 3600);
      $minutes = floor(($execution_time % 3600) / 60);
      $seconds = $execution_time % 60;
      $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

      if ($monitor) {

        // Update the monitor
        $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor->sync_duration        = $duration;
        $monitor->running_status       = 0;
        $monitor->save();

        // Create a log record
        $monitor_log = new CronjobLogModel();
        $monitor_log->cronjob_id           = $monitor->sno;
        $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
        $monitor_log->sync_duration        = $duration;
        $monitor_log->response             = json_encode([
          'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
          'execution_time'    => $duration,
        ]);
        $monitor_log->created_by  = 0;
        $monitor_log->updated_by  = 0;
        $monitor_log->save();
      }

      // Return the count of updated records
      return [
        'processed_records' => isset($inserted_records) ? count($inserted_records) : 0,
        'execution_time'    => "{$execution_time} seconds",
      ];
    } finally {

      if (file_exists($lockPath)) {
        unlink($lockPath);
      }
    }
  }

  public function Cronjob_lead_calls_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 2)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $call_last_fetch_id = $genset ? $genset->call_last_fetch_id : 359657;
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records
    $getmobiles = DB::table('za_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->where('ct.sno', '>=', $call_last_fetch_id)
      ->limit(1000)
      ->orderBy('ct.sno', 'ASC')
      ->get();
    //   return $getmobiles;
    $last_fetch_id = $call_last_fetch_id;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      //

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }


      $last_fetch_id = $ct->sno;
      GeneralSettingsModel::where('sno', 1)->update(['call_last_fetch_id' => $ct->sno]);
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_lead_calls_update_before_days()
  {
    $start_time = microtime(true);
    //   $call_last_fetch_id =  489497;

    // Fetch uncounted call records

    $getmobiles = DB::table('za_call_tracker as ct')
      ->select('ct.sno', 'ct.call_status', 'ct.call_duration', 'ct.customer_phone_no')
      ->where('ct.count_status', 0)
      ->whereBetween('ct.call_start_date', [Carbon::now()->subDays(500)->toDateString(), Carbon::now()->toDateString()])
      //   ->limit(50000)
      ->orderBy('ct.sno', 'ASC')
      ->get();

    //   return count($getmobiles);

    // return $getmobiles;
    $inserted_records = 0;
    foreach ($getmobiles as $ct) {
      $lead_mobile = $ct->customer_phone_no;
      $phoneWithCountryCode = '+91' . $lead_mobile;
      $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $lead_mobile);

      // Fetch lead details
      $lead_update = LeadModel::where(function ($query) use ($lead_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
        $query->where('lead_mobile', 'LIKE', "%{$lead_mobile}%")
          ->orWhere('lead_mobile', $phoneWithCountryCode)
          ->orWhere('lead_mobile', $phoneWithoutCountryCode);
      })->first();

      //

      if (isset($lead_update)) {
        //   return $lead_update;
        // continue; // Skip if no lead is found
        // Initialize previous counts
        $old_outgoing = $lead_update->outgoing_count ?? 0;
        $old_incoming = $lead_update->incoming_count ?? 0;
        $old_missed_reject = $lead_update->missed_reject_count ?? 0;
        $old_dialed = $lead_update->dialed_count ?? 0;

        $status = $ct->call_status;

        // Update counts based on call status
        if ($status === 0) {
          $old_outgoing += 1;
        } elseif ($status === 4) {
          $old_dialed += 1;
        } elseif ($status == 1) {
          $old_incoming += 1;
        } elseif ($status == 2 || $status == 3) {
          $old_missed_reject += 1;
        }

        // Update count_status in CallTrackerModel
        $updated = CallTrackerModel::where('sno', $ct->sno)->update(['count_status' => 1]);

        if ($updated > 0) {
          $lead_update->outgoing_count = $old_outgoing;
          $lead_update->dialed_count = $old_dialed;
          $lead_update->incoming_count = $old_incoming;
          $lead_update->missed_reject_count = $old_missed_reject;
          $lead_update->save();
          $inserted_records++;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    return [
      'processed_records' => $inserted_records,
      'execution_time' => $execution_time . ' seconds',
    ];
  }

  public function Cronjob_lead_phone_verify()
  {
    $monitor = CronjobMonitorModel::where('sno', 6)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $Leads = DB::table('za_lead')
      ->select('sno', 'lead_name', 'lead_mobile', 'phone_verify_status', 'inter_calls')
      ->where('phone_verify_status', 0)
      ->limit(100)
      ->get();

    // Check if leads exist
    if ($Leads->isEmpty()) {
      //   return response()->json(['message' => 'Lead not found'], 404);
    }
    $inserted_records = 0;

    foreach ($Leads as $lead) {
      $lead_id = $lead->sno;
      $lead_mobile = $lead->lead_mobile;
      if ($lead->inter_calls == 0 || $lead->inter_calls == null || $lead->inter_calls == 91) {
        $countryCode = 'IN';
      } else {
        $countries = DB::table('za_countries')->where('phonecode', $lead->inter_calls)->first();
        if ($countries) {
          $countryCode = $countries->sortname;
        } else {
          $countryCode = 'IN';
        }
      }

      // Fetch lead details
      $lead_update = LeadModel::where('sno', $lead_id)->first();
      if (!$lead_update) {
        continue; // Skip if lead not found
      }

      // API URL https://numverify.com/documentation
      $url = 'http://apilayer.net/api/validate';
      $accessKey = '60af509a52f854bf5efbf11595874b5c';
      // Determine country code
      // $countryCode = ($lead->inter_calls == 0 || $lead->inter_calls == null) ? '+ 91' : $lead->inter_calls;


      // Set up cURL
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "{$url}?access_key={$accessKey}&number={$lead_mobile}&country_code={$countryCode}&format=1");
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_TIMEOUT, 30);

      $response = curl_exec($ch);

      // Check for cURL errors
      if (curl_errno($ch)) {
        curl_close($ch);
        return response()->json(['error' => 'cURL error: ' . curl_error($ch)], 500);
      }

      curl_close($ch);
      $data = json_decode($response, true);
      // return $data;
      // Handle API response errors
      if (!$data || !isset($data['valid'])) {
        continue;
      }
      // Update phone verification status
      $lead_update->phone_verify_status  = $data['valid'] ? 1 : 2;
      $lead_update->phone_verify_content = json_encode($data); // Store JSON properly
      $lead_update->save();
      $inserted_records++;
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  // Justdail Lead to Lead
  public function Cronjob_just_dial_lead()
  {
    $monitor = CronjobMonitorModel::where('sno', 7)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $getLeads = DB::table('za_justdial_lead')
      ->select('*')
      ->where('status', 0)
      ->whereNotNull('lead_id')
      ->whereNotNull('parentid')
      ->where('parentid', '!=', 'PX452.X452.160511121626.Q2Y4')
      ->where('parentid', '!=', 'P4562.4562.240610102456.E7W3')
      ->where('parentid', '!=', 'PX452.X452.180308130054.N3D2')
      //   ->where('sno', 39)
      //   ->where('sno', 39)
      ->limit(1000)
      ->orderBy('sno', 'ASC')
      ->get();

    $inserted_records = 0;
    foreach ($getLeads as $jlead) {

      $parentid = $jlead->parentid;
      // Skip unwanted parent ID (optional)
      if ($parentid == 'PX452.X452.160511121626.Q2Y4') {
        continue;
      }

      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'just_dial_id')
        ->where('just_dial_id', $parentid)
        ->first();

      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $jlead->lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
        // Check if lead already exists
        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = JustDialModel::where('sno', $jlead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($jlead->lead_name);
        $add_category->lead_mobile = $lead_mobile;
        $add_category->lead_alternate_mobile = $jlead->lead_alternate_mobile;
        $add_category->lead_email_id = $jlead->lead_email_id;
        $add_category->lead_knowledge_tags = $jlead->lead_knowledge_tags;
        $add_category->registered_date = $jlead->registered_date;
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 6;
        $add_category->just_dial_id = $jlead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;

        if ($add_category->save()) {
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 12;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          $add_history->save();

          $lead_update = JustDialModel::where('sno', $jlead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($jlead->lead_name);
        $lead_email_id = $jlead->lead_email_id;

        if ($add_category) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 9; // from Cloud Call Spam
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          // return $add_history;
          $add_history->save();
        }
        // sms thank you lead
        if ($add_category && $lead_mobile) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $jlead->lead_email_id) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium AcademyÂ®';
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }
        // whatsapp message
        if ($add_category && $lead_mobile) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '7708053111',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  // Cronjob_google_lead Lead to Lead
  public function Cronjob_google_lead()
  {
    $monitor = CronjobMonitorModel::where('sno', 17)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $getLeads = GoogleAdsModel::where('status', 0)
      ->limit(1000)
      ->orderBy('sno', 'ASC')
      ->get();

    $inserted_records = 0;

    foreach ($getLeads as $jlead) {

      $data = json_decode($jlead->data, true);

      if (!$data) continue;

      $lead_name = null;
      $lead_email = null;
      $lead_mobile = null;

      if (!empty($data['user_column_data'])) {
        foreach ($data['user_column_data'] as $field) {
          if ($field['column_id'] === 'FULL_NAME') {
            $lead_name = $field['string_value'];
          }

          if ($field['column_id'] === 'EMAIL') {
            $lead_email = $field['string_value'];
          }

          if ($field['column_id'] === 'PHONE_NUMBER') {
            $lead_mobile = preg_replace('/[^0-9]/', '', $field['string_value']);
          }
        }
      }
      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'just_dial_id')
        ->where('sno', 6)
        ->first();

      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
        // Check if lead already exists
        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = GoogleAdsModel::where('sno', $jlead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($lead_name);
        $add_category->lead_mobile = $lead_mobile;
        $add_category->lead_email_id = $lead_email;
        $add_category->registered_date = date('Y-m-d', strtotime($jlead->created_at));
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 1;
        $add_category->google_lead_id = $jlead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;

        if ($add_category->save()) {
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 12;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          $add_history->save();

          $lead_update = GoogleAdsModel::where('sno', $jlead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($lead_name);
        $lead_email = $lead_email;

        if ($add_category) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 9; // from Cloud Call Spam
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;
          // return $add_history;
          $add_history->save();
        }
        // sms thank you lead
        if ($add_category && $lead_mobile) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $lead_email) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium AcademyÂ®';
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }
        // whatsapp message
        if ($add_category && $lead_mobile) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '7708053111',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_staff_goal_set_update()
  {
    $helper             = new \App\Helpers\Helpers();
    $month_id = date('m'); // "03"
    $month = (int)$month_id; // 3
    $year     = date('Y');

    $monitor = CronjobMonitorModel::where('sno', 11)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::whereMonth('za_goal_set_staff.goal_date', $month_id)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->where('za_goal_set_staff.goal_completed', 0)
      ->get();

    // Convert goalsetRecords to an associative array for easy lookup
    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    $helper = new \App\Helpers\Helpers();
    $staffDetails = [];
    $goalset_monthend_chk = 0;
    foreach ($goalsetRecords as $member) {
      $branch_sno  = $member->branch_id;
      $today_day = date('d');
      $get_branch =  DB::table('za_branch')->where('sno', $branch_sno)->first();

      $goalset_monthend_chk = isset($get_branch->goalset_monthend_chk) ? $get_branch->goalset_monthend_chk : 0;

      if ($goalset_monthend_chk == 1) {
        // Get the last day of the current month
        $registeration_close_day = date('t');
      } else {
        // Use the configured registration close day or default to 25
        $registeration_close_day = $get_branch->goalset_last_date ? $get_branch->goalset_last_date : 25;
      }
      // return $goalset_monthend_chk.'===='.$branch_sno.$registeration_close_day;

      $message = '';
      // $registeration_close_day = 9;
      if ($today_day == $registeration_close_day) {
        $current_date = date('Y-m-d'); // Define the current date
        $branch_id = $member->branch_id;
        $departmentId = $member->department_id;
        $std_count = TrainingModel::where('za_training.status', 0)
          ->where('za_batch.status', 0)
          ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
          ->where('za_training.staff_id', $member->staff_id)
          ->where('za_batch.start_date', '<=', $current_date)
          ->where('za_batch.end_date', '>=', $current_date)
          ->count();
        //Sales Team
        $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $member->staff_id)
          ->where('za_lead.branch_id', $branch_id)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();
        $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->where('za_lead.created_by', $member->staff_id)
          ->where('za_lead.branch_id', $branch_id)
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->whereNotIn('za_lead.status', [2, 6])
          ->where('za_lead.spam_verified', 0)
          ->where('za_lead.internal_status', 0)
          ->count();
        $customerConvertCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $member->staff_id)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 4)->count();
        $customerConvertCount = CustomerModel::select('za_customer.sno')
          ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
          ->where('za_customer.branch_id', $branch_id)
          ->whereIn('za_customer.status', [0, 6])
          ->where('za_lead.created_by', $member->staff_id)
          ->whereYear('za_customer.created_at', $year)
          ->whereMonth('za_customer.created_at', $month)
          ->count();
        $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $member->staff_id)
          ->where('za_lead.spam_verified', 1)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 7)->count();
        $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
          ->whereYear('za_lead.registered_date', $year)
          ->whereMonth('za_lead.registered_date', $month)
          ->where('za_lead.created_by', $member->staff_id)
          ->where('za_lead.branch_id', $branch_id)
          ->where('za_lead.status', 5)->count();
        $monthFollowupCount = DB::table('za_appointment')
          ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
          ->whereIn('za_lead.status', [0, 4])
          ->where('za_appointment.created_by', $member->staff_id)
          ->whereYear('za_appointment.appointment_date', $year)
          ->whereMonth('za_appointment.appointment_date', $month)
          ->count();
        $monthwalkincount = DB::table('za_lead_appointment')
          ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
          ->where('za_lead_appointment.appointment_category', 'walk-in') // Fixed the table reference
          ->where('za_lead_appointment.created_by', $member->staff_id)
          ->whereYear('za_lead_appointment.appointment_date', $year)
          ->whereMonth('za_lead_appointment.appointment_date', $month)
          ->count();
        $monthcall_out = DB::table('za_call_tracker')
          ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
          ->whereYear('call_start_date', $year)
          ->whereMonth('call_start_date', $month)
          ->where('za_call_tracker.branch_id', $branch_id)
          ->where('za_call_tracker.branch_staff_id', $member->staff_id)
          ->first();
        $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
        // Spam Ratio
        $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
        $spam_lead_ratio = number_format($spam_lead_ratio, 2);
        // Dead ratio
        $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
        $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
        // customer ratio
        $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
        $convertion_rate = number_format($convertion_rate, 2);
        //acr
        $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
        $averager_convertion_rate = number_format($averager_convertion_rate, 2);
        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;
        $averageBusinessValue      = 0;
        $averageCollectionValue    = 0;
        $totalAllPayment = 0;
        $totalAllPaidPayment = 0;
        if ($customerConvertCount > 0) {
          $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_lead.created_by', $member->staff_id)
            ->whereIn('za_customer.status', [0, 6])
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->get();
          if ($currentMonthCustomer->isNotEmpty()) {
            foreach ($currentMonthCustomer as $customer) {

              $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->where('za_training.tesbo_check', 0)
                ->sum('za_training.overall_fees');
              $total_payment += $payment;
              $latestTraining = DB::table('za_training')
                ->where('customer_id', $customer->sno)
                ->where('tesbo_check', 2)
                ->orderByDesc('sno')
                ->first();

              if ($latestTraining) {
                $total_payment += $latestTraining->overall_fees;
              }

              $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                ->where('za_training.customer_id', $customer->sno)
                ->sum('za_training.paid_amount');

              $total_paid_payment += $paid_payment;
            }
          }
          // average
          $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
          $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

          $totalAllPayment += $total_payment;
          $totalAllPaidPayment += $total_paid_payment;
        }
        // Production Goal***********************************************
        $staffproduction = StaffModel::select(
          'za_staff.sno',
          'za_staff.staff_id',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.dob',
          'za_staff.mobile_no',
          'za_staff.email_id',
          'za_staff.staff_image',
          'za_staff.nick_name',
          'za_staff.knowledge_tag',
          'za_staff.per_hour_cost',
          'za_job_position.job_position_name',
          'za_staff.avaiable_points',
          'za_staff.basic_salary',
          'za_staff.status AS staff_status'
        )
          ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
          ->where([
            ['za_staff.status', 0],
            ['za_staff.branch_id', $branch_id],
            ['za_staff.sno', $member->staff_id]
          ])
          ->orderByDesc('za_staff.sno')
          ->first();


        // Initialize variables
        $total_batch = $total_student = $total_free_batch = $total_staff = 0;
        $overall_earned = $overall_earned_per = $success_staff_count = 0;
        if ($staffproduction) {

          $slotType = $staffproduction;
          $slotType->earned_amount = 0;
          $slotType->batch_count = 0;
          $slotType->student_count = 0;
          $slotType->present_count = $slotType->course_count = 0;
          $slotType->slotDetails = [];
          $slotType->avg_amnt = $slotType->salary = 0;

          // Fetch batch IDs associated with staff
          $batchIds = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->distinct()
            ->pluck('batch_id')
            ->toArray();

          $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
          foreach ($slotType->batch_ids as $batchId) {
            // Fetch slot details for the staff's batches
            $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
              ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
              ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                  $query->whereMonth('start_date', '<=', $month)
                    ->whereYear('start_date', '<=', $year)
                    ->whereMonth('end_date', '>=', $month)
                    ->whereYear('end_date', '>=', $year);
                })
                ->pluck('batch_id'))
              ->where('za_batch.status', 0)
              ->get();

            $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

            // Fetch batch details
            $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
              ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
              ->find($batchId);

            if ($batch) {
              $startTime = Carbon::parse($batch->start_time);
              $endTime = Carbon::parse($batch->end_time);
              $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

              // Fetch attendance records
              $attendanceRecords = AttendanceModel::select('per_hr_cost')
                ->where([
                  ['batch_id', $batch->sno],
                  ['staff_id', $slotType->sno],
                  ['attendance', 'P']
                ])
                ->whereMonth('att_date', $month)
                ->whereYear('att_date', $year)
                ->get();

              foreach ($attendanceRecords as $attendance) {
                $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
              }
            }
          }
          // Student count
          $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where('za_training.status', 0)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            // ->distinct('customer_id')
            ->count('customer_id');

          // Course count
          $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->distinct('course_id')
            ->count('course_id');

          // Batch count
          $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->distinct('batch_id')
            ->count('batch_id');

          // Salary calculation
          $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
          // Average earned percentage calculation
          $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
          // Calculate free batch count
          $total_free_batch = max(0, 8 - $slotType->batch_count);
          $overall_earned += $slotType->earned_amount;
          $overall_earned_per += $slotType->avg_amnt;
          // Count success staff
          if ($slotType->salary < $slotType->earned_amount) {
            $success_staff_count++;
          }
          $staffproduction = $slotType;
          $costing_amount = $staffproduction->earned_amount ?? 0;
        }



        $refferal_count = DB::table('za_referral_persons')
          ->where('branch_id', $branch_id)
          ->where('referral_id', $member->staff_id)
          ->where('status', 0)
          ->where('referral_type', 2)
          ->whereYear('created_at', $year)
          ->whereMonth('created_at', $month)
          ->count();

        // Production Goal***********************************************
        // CRE Goal *****************************************************
        $review_count = DB::table('za_review')
          ->where('branch_id', $branch_id)
          ->where('created_by', $member->staff_id)
          ->where('status', 0)
          ->whereYear('created_at', $year)
          ->whereMonth('created_at', $month)
          ->count();

        // CRE Goal *****************************************************
        // PC Goal *****************************************************

        $staff_pc = StaffModel::where('za_staff.branch_id', $branch_id)
          ->where('za_staff.department_id', 2)
          ->where('za_staff.status', 0)
          ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
          ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
          ->orderBy('staff_name', 'ASC')
          ->get([
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_department.department_name',
            'za_user_role.role_name'
          ]);

        $totalcosting_amount = 0;
        $totalrefferal_count = 0;
        $total_basic_pay_pro = 0;
        foreach ($staff_pc as $staff_pc_list) {

          // Production Goal***********************************************


          $staffproduction = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_job_position.job_position_name',
            'za_staff.avaiable_points',
            'za_staff.basic_salary',
            'za_staff.status AS staff_status'
          )
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where([
              ['za_staff.status', 0],
              ['za_staff.branch_id', $branch_id],
              ['za_staff.sno', $staff_pc_list->sno]
            ])
            ->orderByDesc('za_staff.sno')
            ->first();

          // Initialize variables
          $total_batch = $total_student = $total_free_batch = $total_staff = 0;
          $overall_earned = $overall_earned_per = $success_staff_count = 0;
          $slotType = $staffproduction;

          $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
          $slotType->present_count = $slotType->course_count = 0;
          $slotType->slotDetails = [];
          $slotType->avg_amnt = $slotType->salary = 0;

          // Fetch batch IDs associated with staff
          $batchIds = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->distinct()
            ->pluck('batch_id')
            ->toArray();

          $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

          foreach ($slotType->batch_ids as $batchId) {
            // Fetch slot details for the staff's batches
            $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
              ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
              ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                  $query->whereMonth('start_date', '<=', $month)
                    ->whereYear('start_date', '<=', $year)
                    ->whereMonth('end_date', '>=', $month)
                    ->whereYear('end_date', '>=', $year);
                })
                ->pluck('batch_id'))
              ->where('za_batch.status', 0)
              ->get();

            $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

            // Fetch batch details
            $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
              ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
              ->find($batchId);

            if ($batch) {
              $startTime = Carbon::parse($batch->start_time);
              $endTime = Carbon::parse($batch->end_time);
              $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

              // Fetch attendance records
              $attendanceRecords = AttendanceModel::select('per_hr_cost')
                ->where([
                  ['batch_id', $batch->sno],
                  ['staff_id', $slotType->sno],
                  ['attendance', 'P']
                ])
                ->whereMonth('att_date', $month)
                ->whereYear('att_date', $year)
                ->get();

              foreach ($attendanceRecords as $attendance) {
                $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
              }
            }
          }

          // Student count
          $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where('za_training.status', 0)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            // ->distinct('customer_id')
            ->count('customer_id');

          // Course count
          $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->distinct('course_id')
            ->count('course_id');

          // Batch count
          $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->where(function ($query) use ($month, $year) {
              $query->whereMonth('start_date', '<=', $month)
                ->whereYear('start_date', '<=', $year)
                ->whereMonth('end_date', '>=', $month)
                ->whereYear('end_date', '>=', $year);
            })
            ->distinct('batch_id')
            ->count('batch_id');

          // Salary calculation
          $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
          // Average earned percentage calculation
          $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
          // Calculate free batch count
          $total_free_batch = max(0, 8 - $slotType->batch_count);
          $overall_earned += $slotType->earned_amount;
          $overall_earned_per += $slotType->avg_amnt;
          // Count success staff
          if ($slotType->salary < $slotType->earned_amount) {
            $success_staff_count++;
          }
          $staffproduction = $slotType;
          $totalcosting_amount += $staffproduction->earned_amount ?? 0;
          $total_basic_pay_pro += $slotType->basic_salary ?? 0;

          $refferal_count = DB::table('za_referral_persons')
            ->where('branch_id', $branch_id)
            ->where('referral_id', $staff_pc_list->sno)
            ->where('status', 0)
            ->where('referral_type', 2)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();

          $totalrefferal_count += $refferal_count ?? 0;
        }

        if ($departmentId == 5) {
          $review_count = $totalrefferal_count;
        }

        // PC Goal *****************************************************

        // Sales Exc *****************************************************
        $drop_ids = DB::table('za_drop_refund')
          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
          ->where('za_drop_refund.bh_status', 1)
          ->where('za_drop_refund.branch_id', $branch_id)
          ->pluck('za_training.payment_id');

        $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
          ->whereNotIn('za_payment.payment_id', $drop_ids)
          ->where('za_payment.status', 0)
          ->where('za_payment.amount', '>', 0)
          ->whereIn('za_customer.status', [0, 6])
          ->whereMonth('za_payment.nextPayDate', $month)
          ->whereYear('za_payment.nextPayDate', $year)
          ->orderBy('za_payment.sno', 'asc')
          ->count();

        $post_sale_count = DB::table('za_training')
          ->where('created_by', $member->staff_id)
          ->where('post_sale_check', 1)
          ->whereYear('post_sale_date', $year)
          ->whereMonth('post_sale_date', $month)
          ->distinct()
          ->count('customer_id');


        $hacAmount = DB::table('za_payment')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->where('za_payment.status', 1) // paid amount
          ->whereIn('za_customer.status', [0, 6])
          ->whereYear('za_payment.initialPayDate', $year)
          ->whereMonth('za_payment.initialPayDate', $month)
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.paidAmount');

        // Sales Exc *****************************************************

        $placement_count = DB::table('za_placement_interview')
          ->where('updated_by', $member->staff_id)
          ->where('status', 4)
          ->whereYear('selected_date', $year)
          ->whereMonth('selected_date', $month)
          ->distinct()
          ->count('customer_id');


        $mou_count = DB::table('za_placement_company')
          ->where('created_by', $member->staff_id)
          ->where('mou_status', 1)
          ->whereYear('mou_upload_date', $year)
          ->whereMonth('mou_upload_date', $month)
          ->count();



        $user_details_dashboard = StaffModel::where('sno', $member->staff_id)->first();
        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;
        $monthcall_out = $dayCount > 0  ? round($monthcall_out /  $dayCount) : 0;
        $monthwalkincount = $dayCount > 0  ? round($monthwalkincount /  $dayCount) : 0;
        $monthFollowupCount = $dayCount > 0  ? round($monthFollowupCount /  $dayCount) : 0;

        // $basic_pay = $user_details_dashboard->basic_salary ?? 0;
        // $costing_amount_asign = $member->production_costing ?? 0;
        // $costing_amount = $basic_pay > 0  ? round(($costing_amount /  $basic_pay) *  $costing_amount_asign) : 0;


        // $productions_asign   = $member->productions ?? 0;
        // $totalcosting_amount = $total_basic_pay_pro > 0  ? round(($costing_amount /  $total_basic_pay_pro) *  $productions_asign) : 0;

        $basic_pay = $user_details_dashboard->basic_salary > 0 ? ($user_details_dashboard->basic_salary * 10) : 0;
        $costing_amount_asign = $member->production_costing ?? 0;
        $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
        $costing_amount = $costing_amount2;


        $productions_asign   = $member->productions ?? 0;
        $total_basic_pay_pro = $total_basic_pay_pro * 10;
        $totalcosting_amount = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $productions_asign : 0;

        $up_goal_set =  GoalSetStaffModel::where('sno', $member->sno)->first();

        if ($up_goal_set) {
          $branch_sno  = $up_goal_set->branch_id;
          $today_day = date('d');
          $get_branch =  DB::table('za_branch')->where('sno', $branch_sno)->first();
          $goalset_monthend_chk = isset($get_branch->goalset_monthend_chk) ? $get_branch->goalset_monthend_chk : 0;

          if ($goalset_monthend_chk == 1) {
            // Get the last day of the current month
            $registeration_close_day = date('t');
          } else {
            // Use the configured registration close day or default to 25
            $registeration_close_day = $get_branch->goalset_last_date ? $get_branch->goalset_last_date : 25;
          }
          // $registeration_close_day = 9;
          if ($today_day == $registeration_close_day) {
            $up_goal_set->conversion_actual = $customerConvertCount ?? 0;
            $up_goal_set->CR_actual = $convertion_rate ?? 0;
            $up_goal_set->ABV_actual = $averageBusinessValue ?? 0;
            $up_goal_set->ACV_actual = $averageCollectionValue ?? 0;
            $up_goal_set->avg_call_out_actual = $monthcall_out ?? 0;
            $up_goal_set->no_of_walk_actual = $monthwalkincount ?? 0;
            $up_goal_set->no_of_followup_actual = $monthFollowupCount ?? 0;
            $up_goal_set->min_no_of_students_actual = $std_count ?? 0;
            $up_goal_set->production_costing_actual = $costing_amount ?? 0;
            $up_goal_set->no_of_reviews_actual = $review_count ?? 0;
            $up_goal_set->no_of_placements_actual = $placement_count ?? 0;
            $up_goal_set->mou_actual = $mou_count ?? 0;
            $up_goal_set->productions_actual = $totalcosting_amount ?? 0;
            $up_goal_set->hac_actual = $hacAmount ?? 0;
            $up_goal_set->no_of_post_sale_actual = $post_sale_count ?? 0;
            $up_goal_set->no_of_outstanding_actual = $OutstandingPayment_count ?? 0;
            $up_goal_set->reference_sales_actual = $refferal_count ?? 0;
            $up_goal_set->goal_completed = 1;
            $up_goal_set->save();
            $inserted_records++;
            $message =  'Goalset updated sucessfully';
          } else {
            return 'Today is Not Goalset Close Date';
            $message =  'Today is Not Goalset Close Date';
          }
        }
      } else {
        $message =  'Today is Not Goalset Close Date';
      }
    }
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'message'    => $message,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'message'    => $message,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_team_goal_set_update()
  {


    $month_id = date('m'); // "03"
    $month = (int)$month_id; // 3

    $year  = date('Y');
    $inserted_records = 0;
    $monitor = CronjobMonitorModel::where('sno', 12)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    // Get goal records for the selected department and month
    $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->where('za_goal_set_team.goal_completed', 0)
      ->orderBy('sno', 'DESC')
      ->get();
    $registeration_close_day = 0;
    foreach ($goalsetteam as $team) {

      $up_goal_set =  GoalSetTeamModel::where('sno', $team->sno)->first();

      if ($up_goal_set) {
        $branch_sno  = $up_goal_set->branch_id;
        $today_day = date('d');
        $get_branch =  DB::table('za_branch')->where('sno', $branch_sno)->first();
        $goalset_monthend_chk = isset($get_branch->goalset_monthend_chk) ? $get_branch->goalset_monthend_chk : 0;


        if ($goalset_monthend_chk == 1) {
          // Get the last day of the current month
          $registeration_close_day = date('t');
        } else {
          // Use the configured registration close day or default to 25
          $registeration_close_day = $get_branch->goalset_last_date ? $get_branch->goalset_last_date : 25;
        }
        // $registeration_close_day = 9;
        // return $goalset_monthend_chk.'===='.$branch_sno.$registeration_close_day;
        if ($today_day == $registeration_close_day) {

          $branch_id = $team->branch_id;
          $departmentId = $team->department_id;

          $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);


          $staff = StaffModel::where('za_staff.branch_id', $branch_id)
            ->where('za_staff.department_id', $departmentId)
            ->where('za_staff.status', 0)
            ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
            ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
            ->orderBy('staff_name', 'ASC')
            ->get([
              'za_staff.sno',
              'za_staff.staff_name',
              'za_staff.nick_name',
              'za_staff.gender',
              'za_staff.staff_image',
              'za_staff.basic_salary',
              'za_department.department_name',
              'za_user_role.role_name'
            ]);

          // Initialize Totals
          $totalDepartmentAllLead = $totalDepartmentMonthLead = $totalDepartmentHotLead = 0;
          $totalDepartmentSpamLead = $totalDepartmentDeadLead = $totalDepartmentConvertCustomer = 0;
          $totalDepartmentBusinessValue = $totalDepartmentCollectionValue = 0;
          $totalDepartmentPaidPayment = $totalDepartmentTotalPayment = 0;
          $totalmonthFollowupCount = $totalmonthwalkincount = $totalmonthcall_outcount = 0;

          $totalcosting_amount = 0;
          $totalrefferal_count = 0;
          $totalreview_count   = 0;
          $OutstandingPayment_count_total   = 0;
          $post_sale_count_total   = 0;
          $hacAmount_total   = 0;
          $placement_count_total   = 0;
          $std_count_total   = 0;
          $total_basic_salary = 0;
          $totalmou_count   = 0;

          foreach ($staff as $member) {

            // Leads Count
            $allLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereNotIn('status', [2, 6])
              ->where('spam_verified', 0)
              ->where('internal_status', 0)
              ->count();

            $monthLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->whereNotIn('status', [2, 6])
              ->where('spam_verified', 0)
              ->where('internal_status', 0)
              ->count();

            $hotLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->whereNotIn('status', [2, 6])
              ->where('lead_status_id', 3)
              ->where('internal_status', 0)
              ->where('spam_verified', 0)
              ->count();

            $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
              ->where('za_customer.branch_id', $branch_id)
              ->where('za_lead.created_by', $member->sno)
              ->whereIn('za_customer.status', [0, 6])
              ->whereYear('za_customer.created_at', $year)
              ->whereMonth('za_customer.created_at', $month)
              ->count();

            $spamLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->where('spam_verified', 1)
              ->where('status', 7)
              ->count();

            $deadLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->where('status', 5)
              ->count();

            // Follow-ups & Walk-ins
            $monthFollowupCount = DB::table('za_appointment')
              ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
              ->whereIn('za_lead.status', [0, 4])
              ->where('za_appointment.created_by', $member->sno)
              ->whereYear('za_appointment.appointment_date', $year)
              ->whereMonth('za_appointment.appointment_date', $month)
              ->count();

            $monthwalkincount = DB::table('za_lead_appointment')
              ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
              ->where('za_lead_appointment.appointment_category', 'walk-in')
              ->where('za_lead_appointment.created_by', $member->sno)
              ->whereYear('za_lead_appointment.appointment_date', $year)
              ->whereMonth('za_lead_appointment.appointment_date', $month)
              ->count();

            // Call Out Count
            $monthcall_out = DB::table('za_call_tracker')
              ->whereYear('call_start_date', $year)
              ->whereMonth('call_start_date', $month)
              ->where('za_call_tracker.branch_id', $branch_id)
              ->where('za_call_tracker.branch_staff_id', $member->sno)
              ->where('call_status', 0)
              ->count();

            // Update Department Totals
            $totalDepartmentAllLead += $allLeadCount;
            $totalDepartmentMonthLead += $monthLeadCount;
            $totalDepartmentHotLead += $hotLeadCount;
            $totalDepartmentSpamLead += $spamLeadCount;
            $totalDepartmentDeadLead += $deadLeadCount;
            $totalDepartmentConvertCustomer += $customerConvertCount;
            $totalmonthFollowupCount += $monthFollowupCount;
            $totalmonthwalkincount += $monthwalkincount;
            $totalmonthcall_outcount += $monthcall_out;

            // Payments Calculation
            $totalPayment = 0;
            $totalPaidPayment = 0;

            if ($customerConvertCount > 0) {
              $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branch_id)
                ->where('za_lead.created_by', $member->sno)
                ->whereIn('za_customer.status', [0, 6])
                ->whereYear('za_customer.created_at', $year)
                ->whereMonth('za_customer.created_at', $month)
                ->get();
              if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {

                  $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                    ->where('za_training.customer_id', $customer->sno)
                    ->where('za_training.tesbo_check', 0)
                    ->sum('za_training.overall_fees');
                  $totalPayment += $payment;
                  $latestTraining = DB::table('za_training')
                    ->where('customer_id', $customer->sno)
                    ->where('tesbo_check', 2)
                    ->orderByDesc('sno')
                    ->first();

                  if ($latestTraining) {
                    $totalPayment += $latestTraining->overall_fees;
                  }

                  $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
                    ->where('za_training.customer_id', $customer->sno)
                    ->sum('za_training.paid_amount');

                  $totalPaidPayment += $paid_payment;
                }
              }
            }

            // Update Total Department Payments
            $totalDepartmentTotalPayment += $totalPayment;
            $totalDepartmentPaidPayment += $totalPaidPayment;


            // Production Goal***********************************************

            $current_date = date('Y-m-d'); // Define the current date
            $std_count = TrainingModel::where('za_training.status', 0)
              ->where('za_batch.status', 0)
              ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
              ->where('za_training.staff_id', $member->sno)
              ->where('za_batch.start_date', '<=', $current_date)
              ->where('za_batch.end_date', '>=', $current_date)
              ->count();

            $std_count_total = $std_count;

            $staffproduction = StaffModel::select(
              'za_staff.sno',
              'za_staff.staff_id',
              'za_staff.staff_name',
              'za_staff.gender',
              'za_staff.dob',
              'za_staff.mobile_no',
              'za_staff.email_id',
              'za_staff.staff_image',
              'za_staff.nick_name',
              'za_staff.knowledge_tag',
              'za_staff.per_hour_cost',
              'za_job_position.job_position_name',
              'za_staff.avaiable_points',
              'za_staff.basic_salary',
              'za_staff.status AS staff_status'
            )
              ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
              ->where([
                ['za_staff.status', 0],
                ['za_staff.branch_id', $branch_id],
                ['za_staff.sno', $member->sno]
              ])
              ->orderByDesc('za_staff.sno')
              ->first();

            // Initialize variables
            $total_batch = $total_student = $total_free_batch = $total_staff = 0;
            $overall_earned = $overall_earned_per = $success_staff_count = 0;
            $slotType = $staffproduction;

            $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
            $slotType->present_count = $slotType->course_count = 0;
            $slotType->slotDetails = [];
            $slotType->avg_amnt = $slotType->salary = 0;

            // Fetch batch IDs associated with staff
            $batchIds = TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->distinct()
              ->pluck('batch_id')
              ->toArray();

            $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

            foreach ($slotType->batch_ids as $batchId) {
              // Fetch slot details for the staff's batches
              $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                  ->where('staff_id', $slotType->sno)
                  ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                      ->whereYear('start_date', '<=', $year)
                      ->whereMonth('end_date', '>=', $month)
                      ->whereYear('end_date', '>=', $year);
                  })
                  ->pluck('batch_id'))
                ->where('za_batch.status', 0)
                ->get();

              $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

              // Fetch batch details
              $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->find($batchId);

              if ($batch) {
                $startTime = Carbon::parse($batch->start_time);
                $endTime = Carbon::parse($batch->end_time);
                $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

                // Fetch attendance records
                $attendanceRecords = AttendanceModel::select('per_hr_cost')
                  ->where([
                    ['batch_id', $batch->sno],
                    ['staff_id', $slotType->sno],
                    ['attendance', 'P']
                  ])
                  ->whereMonth('att_date', $month)
                  ->whereYear('att_date', $year)
                  ->get();

                foreach ($attendanceRecords as $attendance) {
                  $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                }
              }
            }

            // Student count
            $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              //   ->distinct('customer_id')
              ->count('customer_id');

            // Course count
            $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->distinct('course_id')
              ->count('course_id');

            // Batch count
            $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->distinct('batch_id')
              ->count('batch_id');

            // Salary calculation
            $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
            // Average earned percentage calculation
            $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
            // Calculate free batch count
            $total_free_batch = max(0, 8 - $slotType->batch_count);
            $overall_earned += $slotType->earned_amount;
            $overall_earned_per += $slotType->avg_amnt;
            // Count success staff
            if ($slotType->salary < $slotType->earned_amount) {
              $success_staff_count++;
            }
            $staffproduction = $slotType;



            $totalcosting_amount += $staffproduction->earned_amount ?? 0;

            $refferal_count = DB::table('za_referral_persons')
              ->where('branch_id', $branch_id)
              ->where('referral_id', $member->sno)
              ->where('status', 0)
              ->where('referral_type', 2)
              ->whereYear('created_at', $year)
              ->whereMonth('created_at', $month)
              ->count();

            $totalrefferal_count += $refferal_count ?? 0;

            $review_count = DB::table('za_review')
              ->where('branch_id', $branch_id)
              ->where('created_by', $member->sno)
              ->where('status', 0)
              ->whereYear('created_at', $year)
              ->whereMonth('created_at', $month)
              ->count();

            $totalreview_count += $review_count ?? 0;

            $mou_count = DB::table('za_placement_company')
              ->where('branch_id', $branch_id)
              ->where('created_by', $member->sno)
              ->where('mou_status', 1)
              ->whereYear('mou_upload_date', $year)
              ->whereMonth('mou_upload_date', $month)
              ->count();
            $totalmou_count += $mou_count ?? 0;


            // Sales Exc *****************************************************
            $drop_ids = DB::table('za_drop_refund')
              ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
              ->where('za_drop_refund.bh_status', 1)
              ->where('za_drop_refund.branch_id', $branch_id)
              ->pluck('za_training.payment_id');

            $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
              ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
              ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
              ->whereNotIn('za_payment.payment_id', $drop_ids)
              ->where('za_payment.status', 0)
              ->where('za_payment.amount', '>', 0)
              ->whereIn('za_customer.status', [0, 6])
              ->where('za_payment.created_by', $member->sno)
              ->whereMonth('za_payment.nextPayDate', $month)
              ->whereYear('za_payment.nextPayDate', $year)
              ->orderBy('za_payment.sno', 'asc')
              ->count();

            $post_sale_count = DB::table('za_training')
              ->where('created_by', $member->sno)
              ->where('post_sale_check', 1)
              ->whereYear('post_sale_date', $year)
              ->whereMonth('post_sale_date', $month)
              ->distinct()
              ->count('customer_id');

            $placement_count = DB::table('za_placement_interview')
              ->where('updated_by', $member->sno)
              ->where('status', 4)
              ->whereYear('selected_date', $year)
              ->whereMonth('selected_date', $month)
              ->distinct()
              ->count('customer_id');


            $OutstandingPayment_count_total += $OutstandingPayment_count;
            $post_sale_count_total += $post_sale_count;
            $placement_count_total += $placement_count;

            $hacAmount = DB::table('za_payment')
              ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
              ->where('za_payment.status', 1) // paid amount
              ->whereIn('za_customer.status', [0, 6])
              ->whereYear('za_payment.initialPayDate', $year)
              ->whereMonth('za_payment.initialPayDate', $month)
              ->where('za_payment.branch_id', $branch_id)
              ->sum('za_payment.paidAmount');

            $hacAmount_total += $hacAmount;
            $total_basic_salary += $member->basic_salary ?? 0;

            // Sales Exc *****************************************************

          }

          // Business and Collection Value Calculation
          $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

          $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

          // Conversion Rate
          $convertion_rate = $totalDepartmentMonthLead > 0  ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

          $totalConvertRatio = number_format($convertion_rate, 2);





          // Prepare goal details response
          $goalteamDetails = [
            'department_name' => optional($department)->department_name ?? '',
            'department_id'   => optional($department)->sno ?? '',
            'team_id'         => optional($team)->sno ?? '',

            'conversion_over_all'           => optional($team)->conversion_over_all ?? 0,
            'conversion_check'              => optional($team)->conversion_check ?? 0,
            'conversion_type'               => optional($team)->conversion_type ?? 0,
            'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

            'cr_over_all'                   => optional($team)->cr_over_all ?? 0,
            'cr_check'                      => optional($team)->cr_check ?? 0,
            'cr_type'                       => optional($team)->cr_type ?? 0,
            'cr_actual'                     => $totalConvertRatio ?? 'N/A',


            'abv_over_all'                  => optional($team)->abv_over_all ?? 0,
            'abv_check'                     => optional($team)->abv_check ?? 0,
            'abv_type'                      => optional($team)->abv_type ?? 0,
            'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

            'acv_over_all'                  => optional($team)->acv_over_all ?? 0,
            'acv_check'                     => optional($team)->acv_check ?? 0,
            'acv_type'                      => optional($team)->acv_type ?? 0,
            'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

            'avg_call_out_over_all'         => optional($team)->avg_call_out_over_all ?? 0,
            'avg_call_out_check'            => optional($team)->avg_call_out_check ?? 0,
            'avg_call_out_type'             => optional($team)->avg_call_out_type ?? 0,
            'avg_call_out_actual'           => $totalmonthcall_outcount ?? 0,

            'no_of_walk_over_all'           => optional($team)->no_of_walk_over_all ?? 0,
            'no_of_walk_check'              => optional($team)->no_of_walk_check ?? 0,
            'no_of_walk_type'               => optional($team)->no_of_walk_type ?? 0,
            'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

            'no_of_followup_over_all'       => optional($team)->no_of_followup_over_all ?? 0,
            'no_of_followup_check'          => optional($team)->no_of_followup_check ?? 0,
            'no_of_followup_type'           => optional($team)->no_of_followup_type ?? 0,
            'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

            'hac_over_all'                  => optional($team)->hac_over_all ?? 0,
            'hac_check'                     => optional($team)->hac_check ?? 0,
            'hac_type'                      => optional($team)->hac_type ?? 0,
            'hac_actual'                    => $hacAmount_total ?? 0,

            'no_of_post_sale_over_all'      => optional($team)->no_of_post_sale_over_all ?? 0,
            'no_of_post_sale_check'         => optional($team)->no_of_post_sale_check ?? 0,
            'no_of_post_sale_type'          => optional($team)->no_of_post_sale_type ?? 0,
            'no_of_post_sale_actual'        => $post_sale_count_total ?? 0,

            'no_of_outstanding_over_all'    => optional($team)->no_of_outstanding_over_all ?? 0,
            'no_of_outstanding_check'       => optional($team)->no_of_outstanding_check ?? 0,
            'no_of_outstanding_type'        => optional($team)->no_of_outstanding_type ?? 0,
            'no_of_outstanding_actual'      => $OutstandingPayment_count ?? 0,

            'min_no_of_students_over_all'   => optional($team)->min_no_of_students_over_all ?? 0,
            'min_no_of_students_check'      => optional($team)->min_no_of_students_check ?? 0,
            'min_no_of_students_type'       => optional($team)->min_no_of_students_type ?? 0,
            'min_no_of_students_actual'     => $std_count_total ?? 0,

            'production_costing_over_all'   => optional($team)->production_costing_over_all ?? 0,
            'production_costing_check'      => optional($team)->production_costing_check ?? 0,
            'production_costing_type'       => optional($team)->production_costing_type ?? 0,
            'production_costing_actual'     => $totalcosting_amount ?? 0,

            'productions_over_all'          => optional($team)->productions_over_all ?? 0,
            'productions_check'             => optional($team)->productions_check ?? 0,
            'productions_type'              => optional($team)->productions_type ?? 0,
            'productions_actual'            => $totalcosting_amount ?? 0,

            'no_of_reviews_over_all'        => optional($team)->no_of_reviews_over_all ?? 0,
            'no_of_reviews_check'           => optional($team)->no_of_reviews_check ?? 0,
            'no_of_reviews_type'            => optional($team)->no_of_reviews_type ?? 0,
            'no_of_reviews_actual'          => $totalreview_count ?? 0,

            'no_of_placements_over_all'     => optional($team)->no_of_placements_over_all ?? 0,
            'no_of_placements_check'        => optional($team)->no_of_placements_check ?? 0,
            'no_of_placements_type'         => optional($team)->no_of_placements_type ?? 0,
            'no_of_placements_actual'       => $placement_count_total ?? 0,

            'mou_over_all'                  => optional($team)->mou_over_all ?? 0,
            'mou_check'                     => optional($team)->mou_check ?? 0,
            'mou_type'                      => optional($team)->mou_type ?? 0,
            'mou_actual'                    => $totalmou_count ?? 0,

            'reference_sales_over_all'      => optional($team)->reference_sales_over_all ?? 0,
            'reference_sales_check'         => optional($team)->reference_sales_check ?? 0,
            'reference_sales_type'          => optional($team)->reference_sales_type ?? 0,
            'reference_sales_actual'        => $totalrefferal_count ?? 0,

            'status' => optional($team)->status == 1 ? true : false,
            'month'  => $month_id
          ];


          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
          $dayCount = $startDate->diffInDays($endDate) + 1;
          $total_staff = count($staff) ?? 0;
          $totalmonthcall_outcount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
          $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
          $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;


          //   $basic_pay = $total_basic_salary ?? 0;
          //   $costing_amount_asign = optional($team)->production_costing_over_all ?? 0;
          //   $totalcosting_amount = $basic_pay > 0  ? round(($totalcosting_amount /  $basic_pay) *  $costing_amount_asign) : 0;

          $basic_pay = $total_basic_salary ?? 0;
          $total_basic_pay_pro  = $total_basic_salary * 10;
          $costing_amount_asign = optional($team)->production_costing_over_all ?? 0;
          $totalcosting_amount  = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $costing_amount_asign : 0;




          $up_goal_set =  GoalSetTeamModel::where('sno', $team->sno)->first();

          if ($up_goal_set) {
            $branch_sno  = $up_goal_set->branch_id;
            $today_day = date('d');
            $get_branch =  DB::table('za_branch')->where('sno', $branch_sno)->first();
            $goalset_monthend_chk = isset($get_branch->goalset_monthend_chk) ? $get_branch->goalset_monthend_chk : 0;

            if ($goalset_monthend_chk == 1) {
              // Get the last day of the current month
              $registeration_close_day = date('t');
            } else {
              // Use the configured registration close day or default to 25
              $registeration_close_day = $get_branch->goalset_last_date ? $get_branch->goalset_last_date : 25;
            }
            // $registeration_close_day = 9;
            if ($today_day == $registeration_close_day) {
              $up_goal_set->conversion_actual = $totalDepartmentConvertCustomer ?? 0;
              $up_goal_set->cr_actual = $totalConvertRatio ?? 0;
              $up_goal_set->abv_actual = $totalDepartmentBusinessValue ?? 0;
              $up_goal_set->acv_actual = $totalDepartmentCollectionValue ?? 0;
              $up_goal_set->avg_call_out_actual = $totalmonthcall_outcount ?? 0;
              $up_goal_set->no_of_walk_actual = $totalmonthwalkincount ?? 0;
              $up_goal_set->no_of_followup_actual = $totalmonthFollowupCount ?? 0;
              $up_goal_set->hac_actual = $hacAmount_total ?? 0;
              $up_goal_set->no_of_post_sale_actual = $post_sale_count_total ?? 0;
              $up_goal_set->no_of_outstanding_actual = $OutstandingPayment_count ?? 0;
              $up_goal_set->min_no_of_students_actual = $placement_count ?? 0;
              $up_goal_set->production_costing_actual = $totalcosting_amount ?? 0;
              $up_goal_set->no_of_reviews_actual = $totalreview_count ?? 0;
              $up_goal_set->no_of_placements_actual = $placement_count_total ?? 0;
              $up_goal_set->mou_actual = 0 ?? 0;
              $up_goal_set->productions_actual = $totalcosting_amount ?? 0;
              $up_goal_set->reference_sales_actual = $totalrefferal_count ?? 0;
              $up_goal_set->goal_completed = 1;
              $up_goal_set->save();
              $inserted_records++;
              $message =  'Team Goalset Updated Successfully';
            } else {
              $message =  'Today is Not Team Goalset Close Date';
            }
          }
          // return response()->json([
          //   'status' => 200,
          //   'data'   => $goalteamDetails
          // ]);
        } else {
          $message =  'Today is Not Team Goalset Close Date';
        }
      }
    }
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'message'    => $message,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'message'    => $message,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  // Sulekha Lead To Lead
  public function Cronjob_sulekha_lead()
  {
    $monitor = CronjobMonitorModel::where('sno', 5)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();


    $getLeads = DB::table('za_sulekha_lead')
      ->select('*')
      ->where('status', 0)
      ->whereNotNull('lead_mobile')
      //   ->where('sno', 39)
      ->limit(1000)
      ->orderBy('sno', 'ASC')
      ->get();

    // return $getLeads;

    $inserted_records = 0;
    foreach ($getLeads as $slead) {
      $branch_id = 6;
      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'sulekha_id')
        ->where('sulekha_id', $branch_id)
        ->first();
      //   return $branch_get;

      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $slead->lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
        // Check if lead already exists

        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = SulekhaModel::where('sno', $slead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }
        // return $lead_update;

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        // return $branch_check;
        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($slead->lead_name);
        $add_category->lead_mobile = $lead_mobile;
        // $add_category->lead_alternate_mobile = $slead->lead_alternate_mobile;
        $add_category->lead_email_id = $slead->lead_email;
        $add_category->lead_knowledge_tags = $slead->category;
        $add_category->registered_date = $slead->created_at;
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 5;
        $add_category->sulekha_id = $slead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;



        if ($add_category->save()) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 14;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;

          // return $add_history;
          $add_history->save();

          $lead_update = SulekhaModel::where('sno', $slead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();

        // return $branch_data;
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($slead->lead_name);
        $lead_email_id = $slead->lead_email;

        // return $lead_email_id;

        // sms thank you lead
        if ($add_category && $lead_mobile) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $slead->lead_email) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium AcademyÂ®';
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }
        // whatsapp message
        if ($add_category && $lead_mobile) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '7708053111',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_urbanpro_mdu_led()
  {
    $monitor = CronjobMonitorModel::where('sno', 10)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $genset = GeneralSettingsModel::where('sno', 1)->first();


    $getLeads = DB::table('za_urbanpro_lead')
      ->select('*')
      ->where('status', 0)
      //   ->where('sno', 39)
      ->limit(1000)
      ->orderBy('sno', 'ASC')
      ->get();

    // return $getLeads;

    $inserted_records = 0;
    foreach ($getLeads as $slead) {
      $branch_id = $slead->branch_id;
      $branch_get = BranchModel::select('sno', 'other_src_staff_id', 'urban_pro_id')
        ->where('urban_pro_id', $branch_id)
        ->first();
      // return $branch_get;

      if ($branch_get && $branch_get->other_src_staff_id) {

        $branch_sno = $branch_get->sno;
        $lead_mobile = $slead->lead_mobile;
        $lead_othr_src_staff = $branch_get ? $branch_get->other_src_staff_id : 123;
        // Check if lead already exists
        if (LeadModel::where('lead_mobile', $lead_mobile)->exists()) {

          $lead_update = UrbanProModel::where('sno', $slead->sno)->first();
          $lead_update->status = 3;
          $lead_update->save();
          continue;
        }
        // return $lead_update;

        $branch_check = BranchModel::where('sno', $branch_sno)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code ?? 'MDU';

        $year = date("Y");
        $category_check = LeadModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$category_check) {
          $lead_id = "{$year}/{$branch_code}/LED0001";
        } else {
          $last_lead_id = $category_check->lead_id;
          $slice = explode("/", $last_lead_id);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = sprintf("%s/%s/LED%04d", $year, $branch_code, $next_number);
        }

        // return $branch_check;
        $add_category = new LeadModel();
        $add_category->lead_id = $lead_id;
        $add_category->lead_name = ucfirst($slead->lead_name);
        $add_category->lead_mobile = $lead_mobile;
        $add_category->lead_alternate_mobile = $slead->lead_alternate_mobile;
        // $add_category->lead_email_id = $slead->lead_email;
        $add_category->lead_knowledge_tags = $slead->category;
        $add_category->registered_date = $slead->registered_date;
        $add_category->branch_id = $branch_sno;
        $add_category->lead_source_id = 8;
        $add_category->urban_pro_id = $slead->sno;
        $add_category->created_by = $lead_othr_src_staff;
        $add_category->updated_by = $lead_othr_src_staff;
        $add_category->lead_status_id = 1;
        $add_category->lead_condition = 2;



        if ($add_category->save()) {
          // return $add_category;
          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->end_date = null;
          $add_history->transferred_from = 15;
          $add_history->created_by = $lead_othr_src_staff;
          $add_history->updated_by = $lead_othr_src_staff;

          // return $add_history;
          $add_history->save();

          $lead_update = UrbanProModel::where('sno', $slead->sno)->first();

          $lead_update->status = 2;
          $lead_update->save();

          $inserted_records++;
        }

        $branch_data = BranchModel::where('sno', $branch_sno)->first();

        // return $branch_data;
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        $lead_name = ucfirst($slead->lead_name);
        $lead_email_id = $slead->lead_email;

        // return $lead_email_id;

        // sms thank you lead
        if ($add_category && $lead_mobile) {

          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
          $authkey = $result_sms ? $result_sms->authkey : '';
          $sender_id = $result_sms ? $result_sms->sender_id : '';
          $template_id = $result_sms ? $result_sms->template_id : '';
          $country_code = $result_sms ? $result_sms->country_code : '';
          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
          $mobile_number = $country_code . $lead_mobile;

          $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

          // Replace placeholders with actual values
          $replacement_values = [$lead_name, $cre_mobile];
          $message_content = preg_replace_callback(
            '/\{#var#\}/',
            function () use (&$replacement_values) {
              return array_shift($replacement_values);
            },
            $message_content
          );

          $route = "default";
          $postData = array(
            'authkey' => $authkey,
            'mobiles' => $mobile_number,
            'message' => $message_content,
            'sender' => $sender_id,
            'route' => $route,
          );

          // API URL
          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

          // Initialize the resource
          $ch = curl_init();
          curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
          ));

          // Get response
          $response = curl_exec($ch);
          // return $response;
          $err = curl_error($ch);
          curl_close($ch);
        }
        // Thank you email send
        if ($add_category && $slead->lead_email) {
          $email_template_id = 6; // thank you template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $lead_name, $content);
          $content = str_replace('#webLink', $branch_data->website ?? 'https://elysiumacademy.org/', $content);
          $branchNo = $branch_data->mobile;
          $branchemail = $branch_data->mail;
          $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
          $content = str_replace('#salesNo', $branch_data->sales_mobile ?? '9677781155', $content);
          $content = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink' => $fbLink, // Use the message content from the request
            'instaLink' => $instaLink, // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile,
          ];

          $to_address = $lead_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium AcademyÂ®';
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
        }
        // whatsapp message
        if ($add_category && $lead_mobile) {
          $templateName = "elysium_academy_welcome_message";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";
          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
          // $currentHour = date('H'); // Get current hour in 24-hour format
          if ($currentHour >= 5 && $currentHour < 12) {
            $greeting = 'Good Morning';
          } elseif ($currentHour >= 12 && $currentHour < 18) {
            $greeting = 'Good Afternoon';
          } else {
            $greeting = 'Good Evening';
          }

          if ($templateName == 'elysium_academy_welcome_message') {

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            $couponCode  = 'NOOFFER';
            $buttonIndex = 0;
            $bodyText    = [
              [
                'type'           => 'text',
                'text'           => $greeting,
                'parameter_name' => 'greet_msg',
              ],
              [
                'type'           => 'text',
                'text'           => $lead_name,
                'parameter_name' => 'customer_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
                'parameter_name' => 'web_link',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_name,
                'parameter_name' => 'branch_name',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->cre_mobile ?? '7708053111',
                'parameter_name' => 'contact_no',
              ],
              [
                'type'           => 'text',
                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                'parameter_name' => 'contact_email',
              ],
            ];
            $hasHeader = true;
            $hasBody   = true;
            $hasButton = true;
          }

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasFooter) {
            $components[] = [
              'type'       => 'footer',
              'parameters' => [
                [
                  'type'           => 'text',
                  'text'           => 'This is the footer text.',
                  'parameter_name' => 'footer_text',
                ],
              ],
            ];
          }

          // Add Button if required
          if ($hasButton) {
            $components[] = [
              'type'       => 'button',
              'sub_type'   => 'copy_code',
              'index'      => $buttonIndex,
              'parameters' => [
                [
                  'type'        => 'coupon_code',
                  'coupon_code' => $couponCode,
                ],
              ],
            ];
          }

          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->businessId;
          $accessToken               = $this->accessToken;
          $fromPhoneNumberId         = $this->phoneNumberId;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $to           = $lead_mobile;
          $languageCode = 'en_US';

          if (strpos($to, '+91') !== 0) {
            $to = '+91' . $to;
          }

          $message = 'test~message';
          if (empty($components)) {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'     => $templateName,
                'language' => [
                  'code' => $languageCode,
                ],
              ],
            ];
          } else {
            $payload = [
              'messaging_product' => 'whatsapp',
              'to'                => $to,
              'type'              => 'template',
              'template'          => [
                'name'       => $templateName,
                'language'   => [
                  'code' => $languageCode,
                ],
                'components' => $components,
              ],
            ];
          }

          $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  public function Cronjob_session_cleanup()
  {
    $sessionPath = storage_path('framework/sessions');
    $files = File::allFiles($sessionPath);

    $deleted = 0;

    foreach ($files as $file) {
      try {
        // Delete files older than 30 days
        // if (File::lastModified($file) < now()->subDays(30)->getTimestamp()) {
        if (File::lastModified($file) < now()->getTimestamp()) {
          File::delete($file);
          $deleted++;
        }
      } catch (\Exception $e) {
        Log::warning("Failed to delete session file: {$file->getPathname()} - " . $e->getMessage());
      }
    }

    return response()->json([
      'status' => 'success',
      'message' => "Session cleanup completed.",
      'deleted_files_count' => $deleted
    ]);
  }


  private function WhatsappSendLog(

    array $response,

    array $payload,

    string $phone_no,

    string $template_name,

    int $user_id,

    int $branch_id = 0,

    int $unique_id = 0,

    ?string $source = null,

    ?string $module_name = null,

  ) {

    $messageId = $response['data']['messages'][0]['id'] ?? null;



    return WhatsappTemplateLogModel::create([

      'phone_no' => $phone_no,

      'branch_id' => $branch_id,

      'unique_id' => $unique_id,

      'id_source' => $source,

      'module_name' => $module_name,

      'template_name' => $template_name,

      'message_date_time' =>  Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),

      'type' => 'template',

      'from' => 1,

      'wama_id' => $messageId,

      'payload' => json_encode($payload),

      'created_by' => $user_id,

      'updated_by' => $user_id,

      'message_status' => 'sent',

    ]);
  }

  /**
   * Optimized method to find working lead configuration
   */
  private function findWorkingLeadConfig($branch_id, $monthRanges, $leadSplits, $pb_days, $staffCount)
  {
    $neededLeadsPerStaff = $pb_days * max($leadSplits); // Maximum needed
    $returns = null;
    foreach ($monthRanges as $months) {
      $startDate = Carbon::now()->subMonths($months)->startOfMonth();
      $currentDate = Carbon::now();

      // Single query to get lead count (optimization)
      $totalLeads = DB::table('za_lead')
        ->whereBetween('registered_date', [$startDate, $currentDate])
        ->where('status', 0)
        ->where('lead_status_id', '!=', 2)
        ->where('potential_verify', 1)
        ->where('is_potential', 1)
        ->where('branch_id', $branch_id)
        ->count();

      // Try different lead splits
      foreach ($leadSplits as $split) {
        $neededTotal = ($split * $pb_days) * $staffCount;
        if ($neededTotal <= $totalLeads) {
          $returns =  [
            'months' => $months,
            'split' => $split,
            'start_date' => $startDate,
            'end_date' => $currentDate
          ];
        }
      }
    }

    return $returns;
  }

  /**
   * Batch assign leads (optimization 4)
   */
  private function batchAssignLeads($branch_id, $branch_name, $config, $pb_days, $staff, $genset)
  {
    $inserted = 0;

    // Get all eligible leads at once
    $eligibleLeads = DB::table('za_lead')
      ->select('sno', 'created_by')
      ->whereBetween('registered_date', [$config['start_date'], $config['end_date']])
      ->where('status', 0)
      ->where('lead_status_id', '!=', 2)
      ->where('potential_verify', 1)
      ->where('is_potential', 1)
      ->where('is_dc', 0)
      ->where('branch_id', $branch_id)
      ->orderBy('registered_date', 'asc')
      ->get()
      ->shuffle(); // Shuffle in PHP instead of DB

    $staffArray = $staff->toArray();
    $staffCount = count($staffArray);

    if ($eligibleLeads->isEmpty() || $staffCount == 0) {
      return 0;
    }

    DB::beginTransaction();

    try {
      $leadIndex = 0;
      $schedules = [];
      $leadUpdates = [];
      $totalLeadsNeeded = $config['split'] * $pb_days * $staffCount;

      // Generate assignments for all days at once
      for ($day = 0; $day < $pb_days; $day++) {
        $assignmentDate = Carbon::now('Asia/Kolkata')->addDays($day)->toDateString();

        for ($staffIdx = 0; $staffIdx < $staffCount; $staffIdx++) {
          if ($leadIndex >= $eligibleLeads->count()) {
            break 2;
          }

          for ($i = 0; $i < $config['split']; $i++) {
            if ($leadIndex >= $eligibleLeads->count()) {
              break 3;
            }

            $lead = $eligibleLeads[$leadIndex];

            // Prepare batch update
            $leadUpdates[] = [
              'sno' => $lead->sno,
              'is_dc' => 1,
              'internal_status' => 1,
              'potential_verify' => 1,
              'is_potential' => 1,
              'dc_date' => $assignmentDate,
              'dc_staff_id' => $staffArray[$staffIdx]->sno,
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];

            // Prepare batch insert
            $schedules[] = [
              'branch_id' => $branch_id,
              'lead_id' => $lead->sno,
              'previous_staff' => $lead->created_by,
              'current_staff' => $staffArray[$staffIdx]->sno,
              'sch_date' => $assignmentDate,
              'created_at' => Carbon::now('Asia/Kolkata'),
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];

            $leadIndex++;
            $inserted++;
          }
        }
      }

      // Batch update leads
      if (!empty($leadUpdates)) {
        foreach (array_chunk($leadUpdates, 100) as $chunk) {
          foreach ($chunk as $update) {
            DB::table('za_lead')
              ->where('sno', $update['sno'])
              ->update([
                'is_dc' => $update['is_dc'],
                'internal_status' => $update['internal_status'],
                'potential_verify' => $update['potential_verify'],
                'is_potential' => $update['is_potential'],
                'dc_date' => $update['dc_date'],
                'dc_staff_id' => $update['dc_staff_id'],
                'updated_at' => $update['updated_at']
              ]);
          }
        }
      }

      // Batch insert schedules
      if (!empty($schedules)) {
        foreach (array_chunk($schedules, 100) as $chunk) {
          DB::table('za_schedule_daily_call')->insert($chunk);
        }
      }

      DB::commit();

      // Update genset if config changed
      if ($config['months'] != $genset->cycling_month || $config['split'] != $genset->pb_lead_count) {
        $genset->cycling_month = $config['months'];
        $genset->pb_lead_count = $config['split'];
        $genset->is_posible = 0;
        $genset->save();
      }

      return $inserted;
    } catch (\Exception $e) {
      DB::rollBack();
      throw $e;
    }
  }

  public function Cronjob_hot_lead_update()
  {
    $monitor = CronjobMonitorModel::where('sno', 9)->first();
    $start_time = microtime(true);
    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }
    $inserted_records = 0;

    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->hot_lead_days) {
      $hot_lead_day = $genset->hot_lead_days;
      $before_date  = date('Y-m-d', strtotime("-$hot_lead_day days"));

      $gza_leads = DB::table('za_lead')
        ->select('sno', 'last_hot_lead_date', 'lead_status_id', 'status', 'lead_name', 'created_by', 'branch_id')
        ->where('last_hot_lead_date', '<', $before_date)  // 'last_hot_lead_date' less than $before_date
        ->where('lead_status_id', 3)
        ->get();


      foreach ($gza_leads as $lead) {
        $hot = new HotLeadModel();
        $hot->branch_id = $lead->branch_id;
        $hot->lead_id = $lead->sno;
        $hot->staff_id = $lead->created_by;
        $hot->startdate = $lead->last_hot_lead_date;
        $hot->enddate = date('Y-m-d');
        $hot->created_by = $lead->created_by;
        $hot->updated_by = $lead->created_by;
        $hot->save();

        if ($hot) {
          $lead_update = LeadModel::where('sno', $lead->sno)->first();
          if ($lead_update) {
            $lead_update->lead_status_id = 2;
            $lead_update->is_hot_lead = 2;
            // $lead_update->last_hot_lead_date = null;
            $lead_update->save();
            $inserted_records++;
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime   = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');
    // Convert seconds → H:i:s
    $hours   = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {

      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response             = json_encode([
        'processed_records' => $inserted_records,
        'execution_time'    => $duration,
      ]);
      $monitor_log->created_by  = 0;
      $monitor_log->updated_by  = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time'    => "{$execution_time} seconds",
    ];
  }

  // 7days Before
  public function Cronjob_HotleadToLeadBasket()
  {
    $monitor = CronjobMonitorModel::where('sno', 18)->first();
    $start_time = microtime(true);

    // Get start time in India time
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        // Stop execution if cron is OFF
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->hotleadtoleadbasket) {
      $hot_lead_day = $genset->hotleadtoleadbasket;
      $now = Carbon::now();
      $today = Carbon::today();

      // Calculate additional hours for weekends/holidays
      $additional_days = 0;

      // Check weekends
      if ($today->isSunday() || $today->isMonday()) {
        $additional_days += 1;
      }

      // Check holidays - single optimized query
      $beforeHours = $now->copy()->subDays($hot_lead_day + $additional_days);
      $holiday_count = DB::table('za_holiday')
        ->whereBetween('hol_date', [$beforeHours->toDateString(), $today->toDateString()])
        ->count();

      $additional_days += $holiday_count;

      // Calculate final cutoff date
      $before_date = $now->copy()->subDays($hot_lead_day + $additional_days)->format('Y-m-d');

      $gza_leads = DB::table('za_lead')
        ->select(
          'za_lead.sno',
          'za_lead.status',
          'za_lead.lead_name',
          'za_lead.created_by',
          'za_lead.branch_id'
        )
        ->leftJoin('za_branch', 'za_lead.branch_id', '=', 'za_branch.sno')
        ->where('za_branch.branch_type', 1)
        ->whereNotIN('za_lead.lead_status_id', [1, 3])
        ->where('za_lead.is_hot_lead', 0)
        ->where('za_lead.is_potential', 0)
        ->where('za_lead.potential_verify', 0)
        ->where('za_lead.spam_verified', 0)
        ->where('za_lead.drop_verified', 0)
        ->whereNotIn('za_lead.status', [10, 4])
        // ->limit(500)
        ->orderBy('za_lead.sno', 'desc')
        ->get();

      foreach ($gza_leads as $lead) {
        $get_followup = DB::table('za_appointment')
          ->where('lead_id', $lead->sno)
          ->whereBetween('appointment_date', [$before_date, $today->format('Y-m-d')])
          ->first();

        if (empty($get_followup)) {
          $lead_update = LeadModel::where('sno', $lead->sno)->first();
          if ($lead_update) {
            $lead_update->internal_status = 1;
            $lead_update->potential_verify = 1;
            $lead_update->is_potential = 1;
            $lead_update->potentail_reason = 'Auto Convert 7days Unfollow-up Lead';
            $lead_update->save();
            $inserted_records++;
          }
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    if ($monitor) {
      // Update the monitor
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration = $duration;
      $monitor_log->response = json_encode([
        'processed_records' => $inserted_records,
        'execution_time' => $duration,
      ]);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    // Return the count of updated records
    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }

  // 48hours
  public function Cronjob_UnfollowToLeadBasket()
  {
    $monitor = CronjobMonitorModel::where('sno', 19)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    if ($monitor) {
      if ($monitor->status != 0) {
        return response()->json([
          'success' => false,
          'message' => 'Cronjob status Off'
        ]);
      }
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if ($genset && $genset->unfollowtoleadbasket) {
      $lead_hours = $genset->unfollowtoleadbasket ?? 48;
      $now = Carbon::now();
      $today = Carbon::today();

      // Calculate additional hours for weekends/holidays
      $additional_hours = 0;

      // Check weekends
      if ($today->isSunday() || $today->isMonday()) {
        $additional_hours += 32;
      }

      // Check holidays - single optimized query
      $beforeHours = $now->copy()->subHours($lead_hours + $additional_hours);
      $holiday_count = DB::table('za_holiday')
        ->whereBetween('hol_date', [$beforeHours->toDateString(), $today->toDateString()])
        ->count();

      $additional_hours += ($holiday_count * 30);

      // Calculate final cutoff time
      $beforeday = $now->subHours($lead_hours + $additional_hours);

      // Single optimized query to get all leads with their call status
      $leads_with_call_status = DB::table('za_lead as l')
        ->select([
          'l.sno',
          'l.lead_mobile',
          DB::raw('MAX(ct.call_start_date) as last_call_date'),
          DB::raw('COUNT(ct.sno) as call_count')
        ])
        ->leftJoin('za_call_tracker as ct', function ($join) use ($beforeday) {
          $join->on(DB::raw('RIGHT(ct.customer_phone_no, 10)'), '=', 'l.lead_mobile');
          // ->where('ct.call_start_date', '>=', $beforeday);
        })
        ->leftJoin('za_branch', 'l.branch_id', '=', 'za_branch.sno')
        ->where('za_branch.branch_type', 1)
        ->where('l.status', 0)
        ->where('l.lead_status_id', 1)
        ->where('l.potential_verify', 0)
        ->where('l.is_potential', 0)
        ->where('l.spam_verified', 0)
        ->where('l.drop_verified', 0)
        ->whereDate('l.registered_date', '<', $beforeday->toDateString())
        ->groupBy('l.sno', 'l.lead_mobile')
        ->having('call_count', '=', 0) // Only leads with no calls
        ->get();

      if ($leads_with_call_status->isNotEmpty()) {
        $lead_ids = $leads_with_call_status->pluck('sno')->toArray();

        // Bulk update in chunks to avoid memory issues
        $chunks = array_chunk($lead_ids, 100);
        foreach ($chunks as $chunk) {
          $updated = DB::table('za_lead')
            ->whereIn('sno', $chunk)
            ->update([
              'internal_status' => 1,
              'potential_verify' => 1,
              'is_potential' => 1,
              'potentail_reason' => 'Auto Convert 48 hours Unfollow Lead',
              'updated_at' => $now
            ]);

          $inserted_records += $updated;
        }
      }
    }

    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);
    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Format duration
    $duration = gmdate("H:i:s", floor($execution_time));

    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration = $duration;
      $monitor->running_status = 0;
      $monitor->save();

      CronjobLogModel::create([
        'cronjob_id' => $monitor->sno,
        'sync_start_date_time' => $startDateTime->format('Y-m-d H:i:s'),
        'sync_end_date_time' => $endDateTime->format('Y-m-d H:i:s'),
        'sync_duration' => $duration,
        'response' => json_encode([
          'processed_records' => $inserted_records,
          'execution_time' => $duration,
        ]),
        'created_by' => 0,
        'updated_by' => 0
      ]);
    }

    return [
      'processed_records' => $inserted_records,
      'execution_time' => "{$execution_time} seconds",
    ];
  }

  /**
   * Schedule Daily Call
   */

  public function Cronjob_DailyCallList()
  {
    $monitor = CronjobMonitorModel::where('sno', 20)->where('status', 0)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');

    // Early return checks
    if ($monitor && $monitor->status != 0) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Cronjob status Off',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }

    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }

    $inserted_records = 0;
    $processed_branches = 0;
    $branch_messages = [];

    $genset = GeneralSettingsModel::where('sno', 1)->first();

    if (!$genset) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'General settings not found',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }

    // Only proceed if nextschdate matches today
    if ($genset->nextschdate != date('Y-m-d')) {
      $return = [
        'success' => true,
        'processed_records' => 0,
        'message' => 'Not scheduled for today',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }

    // Required settings check
    if (!isset($genset->cycling_month) || !isset($genset->pb_days)) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Required settings missing',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }

    $activeBranch = DB::table('za_branch')->where('status', 0)->where('branch_type', 1)->get();

    // Get all staff data in one query
    $allStaff = DB::table('za_staff')
      ->select(
        'sno',
        'staff_name',
        'branch_id',
        'call_check',
        'call_count'
      )
      ->where('status', 0)
      ->where('department_id', 1)
      ->where('call_check', 1)
      ->where('call_count', '>', 0)
      ->inRandomOrder()
      ->get()
      ->groupBy('branch_id');

    foreach ($activeBranch as $branch) {
      $branch_id = $branch->sno;
      $branch_name = $branch->branch_name ?? 'Branch ' . $branch_id;

      // Get staff for this branch
      $salesStaff = isset($allStaff[$branch_id]) ? $allStaff[$branch_id] : collect();
      $salesStaffCount = $salesStaff->count();

      if ($salesStaffCount == 0) {
        $branch_messages[] = "Branch {$branch_name}: No active sales staff found";
        continue;
      }

      $daysAgo = 3;
      $subDate = Carbon::now()->subDays($daysAgo);

      DB::table('za_schedule_daily_call')
        ->where('branch_id', $branch_id)
        ->where('sch_date', '<', $subDate)
        ->where('status', 0)
        ->update([
          'status' => 3,
          'updated_at' => now()
        ]);
      DB::table('za_lead')
        ->where('branch_id', $branch_id)
        ->where('dc_date', '<', $subDate)
        ->where('is_dc', 1)
        ->update([
          'is_dc' => 0,
          'dc_date' => null,
          'updated_at' => now()
        ]);

      $now = Carbon::now('Asia/Kolkata');
      $today = Carbon::today('Asia/Kolkata');
      $pb_days = $genset->pb_days;

      // Calculate additional days for weekends/holidays (these days will be skipped)
      $additional_days = 0;

      // Get holidays list for the upcoming period
      $endDate = $now->copy()->addDays($pb_days * 2); // Look ahead enough days
      $holidays = DB::table('za_holiday')
        ->whereBetween('hol_date', [$today->toDateString(), $endDate->toDateString()])
        ->pluck('hol_date')
        ->map(function ($date) {
          return Carbon::parse($date)->toDateString();
        })
        ->toArray();

      $branchProcessed = false;
      $staffMessages = [];

      // Track assigned lead IDs to prevent duplicates across staff
      $assignedLeadIds = [];

      // Process each staff member individually
      foreach ($salesStaff as $staff) {
        $neededLeads = $staff->call_count * $pb_days;

        // Find available leads for this specific staff
        $monthRanges = [6, 8];
        $workingConfig = null;
        $selectedMonths = null;
        $availableLeads = null;
        $maxAvailableInAnyRange = 0;
        $bestMonthRange = null;

        foreach ($monthRanges as $months) {
          $startDate = Carbon::now()->subMonths($months)->startOfMonth();
          $currentDate = Carbon::now();

          // Count available leads (not assigned to anyone yet)
          $totalAvailable = DB::table('za_lead')
            ->whereBetween('registered_date', [$startDate, $currentDate])
            ->where('potential_verify', 1)
            ->where('is_potential', 1)
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->whereNotIn('status', [10, 4])
            ->where('branch_id', $branch_id)
            ->whereNotIn('sno', $assignedLeadIds)
            ->where(function ($query) use ($subDate) {
              $query->whereDate('dc_date', '<', $subDate)
                ->orWhereNull('dc_date');
            })
            ->where(function ($query) {
              $query->whereNull('is_dc')
                ->orWhere('is_dc', 0);
            })
            ->count();

          // Track the maximum available for reporting
          if ($totalAvailable > $maxAvailableInAnyRange) {
            $maxAvailableInAnyRange = $totalAvailable;
            $bestMonthRange = $months;
          }

          if ($totalAvailable >= $neededLeads) {
            // Get the actual leads
            $availableLeads = DB::table('za_lead')
              ->select('sno', 'created_by', 'registered_date')
              ->whereBetween('registered_date', [$startDate, $currentDate])
              ->where('potential_verify', 1)
              ->where('is_potential', 1)
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->whereNotIn('status', [10, 4])
              ->where('branch_id', $branch_id)
              ->whereNotIn('sno', $assignedLeadIds)
              ->where(function ($query) {
                $query->whereNull('is_dc')
                  ->orWhere('is_dc', 0);
              })
              ->where(function ($query) use ($subDate) {
                $query->whereDate('dc_date', '<', $subDate)
                  ->orWhereNull('dc_date');
              })
              ->orderBy('registered_date', 'asc')
              ->inRandomOrder()  // <-- This will randomize the order
              ->limit($neededLeads)
              ->get();

            $workingConfig = [
              'months' => $months,
              'start_date' => $startDate,
              'end_date' => $currentDate,
              'split' => $staff->call_count
            ];
            $selectedMonths = $months;
            break;
          }
        }

        if (!$workingConfig || !$availableLeads || $availableLeads->isEmpty()) {
          $staffMessages[] = "Staff {$staff->staff_name}: Needs {$neededLeads} leads but only {$maxAvailableInAnyRange} available in best range ({$bestMonthRange} months)";
          continue;
        }

        // Assign leads to this staff (skipping Sundays and holidays)
        $insertCount = $this->assignLeadsToStaff(
          $branch_id,
          $staff,
          $workingConfig,
          $pb_days,
          $availableLeads,
          $holidays // Pass holidays array
        );

        if ($insertCount > 0) {
          // Add assigned lead IDs to the tracking array
          foreach ($availableLeads as $lead) {
            $assignedLeadIds[] = $lead->sno;
          }

          $inserted_records += $insertCount;
          $branchProcessed = true;
          $staffMessages[] = "Staff {$staff->staff_name}: Successfully assigned {$insertCount} leads (skipping Sundays and holidays)";

          // Update genset with the working configuration (use the first successful staff's config)
          if ($selectedMonths != $genset->cycling_month) {
            $genset->cycling_month = $selectedMonths;
            $genset->is_posible = 0;
            $genset->save();
          }
        } else {
          $staffMessages[] = "Staff {$staff->staff_name}: Failed to assign leads";
        }
      }

      if ($branchProcessed) {
        $processed_branches++;
      }

      $branch_messages = array_merge($branch_messages, $staffMessages);
    }

    // Update next schedule date
    if ($inserted_records > 0) {
      $Nxtsch = Carbon::now('Asia/Kolkata')->addDays($genset->pb_days)->toDateString();
      $genset->nextschdate = $Nxtsch;
      $genset->save();
    }

    $return = [
      'success' => true,
      'processed_records' => $inserted_records,
      'processed_branches' => $processed_branches,
      'total_branches' => count($activeBranch),
      'branch_details' => $branch_messages,
      'message' => $inserted_records > 0 ? 'Cron job completed successfully' : 'No records were inserted',
      'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
    ];

    return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
  }

  private function assignLeadsToStaff($branch_id, $staff, $config, $pb_days, $leads, $holidays = [])
  {
    $inserted = 0;
    $schedules = [];
    $leadUpdates = [];

    $leadIndex = 0;
    $leadCount = $leads->count();

    DB::beginTransaction();

    try {
      $day = 0;
      $assignedDays = 0;
      $today = Carbon::now('Asia/Kolkata')->startOfDay();

      // Convert holidays to proper format for comparison
      $holidaysFormatted = array_map(function ($date) {
        return Carbon::parse($date)->toDateString();
      }, $holidays);

      // Keep assigning until we've assigned leads for all required working days
      while ($assignedDays < $pb_days && $leadIndex < $leadCount) {
        // Start from start from today to avoid assigning for today if it's already passed
        $checkDate = $today->copy()->addDays($day);
        $assignmentDate = $checkDate->toDateString();
        $assignmentDayOfWeek = $checkDate->dayOfWeek; // 0 = Sunday, 1 = Monday, etc.

        // Debug: Log the date being checked
        // \Log::info("Checking date: {$assignmentDate}, Day of week: {$assignmentDayOfWeek}");

        // Check if it's Sunday (0) or a holiday
        $isSunday = ($assignmentDayOfWeek == 0);
        $isHoliday = in_array($assignmentDate, $holidaysFormatted);

        // Skip if it's Sunday or holiday
        if (!$isSunday && !$isHoliday) {
          // Additional check: Verify this staff doesn't already have leads on this date
          $existingAssignments = DB::table('za_schedule_daily_call')
            ->where('current_staff', $staff->sno)
            ->whereDate('sch_date', $assignmentDate)
            ->where('status', 0)
            ->count();

          if ($existingAssignments > 0) {
            //  \Log::info("Staff {$staff->staff_name} already has {$existingAssignments} assignments on {$assignmentDate}, skipping");
            $day++;
            continue;
          }

          // \Log::info("Assigning for working day: {$assignmentDate}");

          // This is a working day - assign leads
          for ($i = 0; $i < $config['split']; $i++) {
            if ($leadIndex >= $leadCount) {
              break 2;
            }

            $lead = $leads[$leadIndex];

            // Verify lead isn't already assigned to this date
            $alreadyAssigned = DB::table('za_schedule_daily_call')
              ->where('lead_id', $lead->sno)
              ->whereDate('sch_date', $assignmentDate)
              ->exists();

            if ($alreadyAssigned) {
              //   \Log::info("Lead {$lead->sno} already assigned on {$assignmentDate}, skipping");
              $leadIndex++;
              $i--; // Try next lead for same slot
              continue;
            }

            // Prepare lead update
            $leadUpdates[] = [
              'sno' => $lead->sno,
              'is_dc' => 1,
              'internal_status' => 1,
              'potential_verify' => 1,
              'is_potential' => 1,
              'dc_date' => $assignmentDate,
              'dc_staff_id' => $staff->sno,
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];

            // Prepare schedule insert
            $schedules[] = [
              'branch_id' => $branch_id,
              'lead_id' => $lead->sno,
              'previous_staff' => $lead->created_by,
              'current_staff' => $staff->sno,
              'sch_date' => $assignmentDate,
              'created_at' => Carbon::now('Asia/Kolkata'),
              'updated_at' => Carbon::now('Asia/Kolkata')
            ];

            $leadIndex++;
            $inserted++;
          }
          $assignedDays++;
        } else {
          // \Log::info("Skipping non-working day: {$assignmentDate} (Sunday: " . ($isSunday ? 'Yes' : 'No') . ", Holiday: " . ($isHoliday ? 'Yes' : 'No') . ")");
        }

        $day++;
      }

      // Batch update leads
      if (!empty($leadUpdates)) {
        foreach ($leadUpdates as $update) {
          DB::table('za_lead')
            ->where('sno', $update['sno'])
            ->update([
              'is_dc' => $update['is_dc'],
              'internal_status' => $update['internal_status'],
              'potential_verify' => $update['potential_verify'],
              'is_potential' => $update['is_potential'],
              'dc_date' => $update['dc_date'],
              'dc_staff_id' => $update['dc_staff_id'],
              'updated_at' => $update['updated_at']
            ]);
        }
      }

      // Batch insert schedules
      if (!empty($schedules)) {
        foreach (array_chunk($schedules, 100) as $chunk) {
          DB::table('za_schedule_daily_call')->insert($chunk);
        }
      }

      // Log summary
      // \Log::info("Assignment complete for staff {$staff->staff_name}: Assigned {$inserted} leads over {$assignedDays} working days");

      DB::commit();
      return $inserted;
    } catch (\Exception $e) {
      DB::rollBack();
      // \Log::error('Lead assignment failed for staff ' . $staff->sno . ': ' . $e->getMessage());
      return 0;
    }
  }

  private function updateCronMonitor($monitor, $startDateTime, $start_time, $return)
  {
    $end_time = microtime(true);
    $execution_time = round($end_time - $start_time, 4);

    $endDateTime = Carbon::createFromTimestamp((int)$end_time, 'Asia/Kolkata');

    // Convert seconds to H:i:s
    $hours = floor($execution_time / 3600);
    $minutes = floor(($execution_time % 3600) / 60);
    $seconds = $execution_time % 60;
    $duration = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);

    // Update the monitor if it exists
    if ($monitor) {
      $monitor->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor->sync_duration        = $duration;
      $monitor->running_status       = 0;
      $monitor->save();

      // Create a log record
      $monitor_log = new CronjobLogModel();
      $monitor_log->cronjob_id           = $monitor->sno;
      $monitor_log->sync_start_date_time = $startDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_end_date_time   = $endDateTime->format('Y-m-d H:i:s');
      $monitor_log->sync_duration        = $duration;
      $monitor_log->response = json_encode($return);
      $monitor_log->created_by = 0;
      $monitor_log->updated_by = 0;
      $monitor_log->save();
    }

    // Return the response
    return response()->json($return);
  }
  
   public function Cronjob_DailyPCTaskAssign()
  {
    $monitor = CronjobMonitorModel::where('sno', 21)->where('status', 0)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
 
    // Early return checks
    if ($monitor && $monitor->status != 0) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Cronjob status Off',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }
 
    $inserted_records = 0;
    $processed_branches = 0;
    $branch_messages = [];
 
    // Get current day (0=Sunday, 1=Monday, ..., 6=Saturday)
    $currentDay = Carbon::now('Asia/Kolkata')->dayOfWeek;
 
    // Get active branches
    $activeBranch = DB::table('za_branch')->where('status', 0)->where('branch_type', 1)->get();
 
    // Get all staff data grouped by branch_id
    $allStaff = DB::table('za_staff')
      ->select(
        'sno',
        'staff_name',
        'branch_id',
        'call_check',
        'call_count'
      )
      ->where('status', 0)
      ->where('sub_department_id', 11) //pc staffs
      ->inRandomOrder()
      ->get()
      ->groupBy('branch_id');
 
    // Get all batches with slot information, filtered by current day
    // FIX: Added za_batch.slot_id to the select query
    $allbatch = DB::table('za_batch')
      ->select(
        'za_batch.sno',
        'za_batch.branch_id',
        'za_batch.slot_id',  // ADD THIS LINE - FIXES THE NULL SLOT_ID ISSUE
        'za_slot.slot_type_days'
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->where('za_batch.status', 0)
      ->inRandomOrder()
      ->get()
      ->filter(function ($batch) use ($currentDay) {
        // Condition 1: Filter batch by current day
        $slotDays = json_decode($batch->slot_type_days, true);
        if (is_array($slotDays) && in_array($currentDay, $slotDays)) {
          return true;
        }
        return false;
      })
      ->groupBy('branch_id');
 
    // Process each branch
    foreach ($activeBranch as $branch) {
      $branchId = $branch->sno;
 
      // Get staff for this branch
      $branchStaff = isset($allStaff[$branchId]) ? $allStaff[$branchId] : collect();
 
      // Get batches for this branch that match current day
      $branchBatches = isset($allbatch[$branchId]) ? $allbatch[$branchId] : collect();
 
      if ($branchStaff->isEmpty() || $branchBatches->isEmpty()) {
        $branch_messages[] = "Branch {$branch->branch_name}: No staff or batches available";
        continue;
      }
 
      // Prepare array to track staff assignments (limit 5 per staff)
      $staffAssignmentCount = [];
 
      // Get recently assigned batches for this branch (last 4 days)
      $recentAssignments = DB::table('za_batch_daily_task')
        ->where('branch_id', $branchId)
        ->where('date', '>=', Carbon::now('Asia/Kolkata')->subDays(4))
        ->get()
        ->groupBy('batch_id');
 
      // Create a list of available batches (not assigned in last 4 days to same staff)
      $availableBatches = [];
      foreach ($branchBatches as $batch) {
        $batchId = $batch->sno;
 
        // Check if this batch was assigned to any staff in last 4 days
        $recentAssignedStaff = isset($recentAssignments[$batchId])
          ? $recentAssignments[$batchId]->pluck('staff_id')->toArray()
          : [];
 
        $availableBatches[$batchId] = [
          'batch' => $batch,
          'recent_staff' => $recentAssignedStaff
        ];
      }
 
      // Initialize staff assignment counts
      foreach ($branchStaff as $staff) {
        $staffAssignmentCount[$staff->sno] = 0;
      }
 
      // Assign batches to staff
      $assignments = [];
 
      foreach ($availableBatches as $batchId => $batchInfo) {
        $batch = $batchInfo['batch'];
        $recentStaffIds = $batchInfo['recent_staff'];
 
        // Find available staff who:
        // 1. Haven't reached limit of 5 assignments
        // 2. Haven't been assigned this batch in last 4 days
        $availableStaff = $branchStaff->filter(function ($staff) use ($staffAssignmentCount, $recentStaffIds) {
          return $staffAssignmentCount[$staff->sno] < 5 && !in_array($staff->sno, $recentStaffIds);
        });
 
        if ($availableStaff->isNotEmpty()) {
          // Assign to first available staff (since already randomized)
          $selectedStaff = $availableStaff->first();
 
          // FIX: Added validation to ensure slot_id exists
          $slotId = $batch->slot_id ?? null;
          if ($slotId === null) {
            $branch_messages[] = "Warning: Batch ID {$batchId} has no slot_id, skipping assignment";
            continue;
          }
 
          $assignments[] = [
            'branch_id' => $branchId,
            'staff_id' => $selectedStaff->sno,
            'batch_id' => $batchId,
            'slot_id' => $slotId,  // Now this will have a valid value
            'date' => Carbon::now('Asia/Kolkata'),
            'created_at' => Carbon::now('Asia/Kolkata')
          ];
 
          $staffAssignmentCount[$selectedStaff->sno]++;
          $inserted_records++;
        }
      }
 
      // Insert assignments for this branch
      if (!empty($assignments)) {
        DB::table('za_batch_daily_task')->insert($assignments);
        $processed_branches++;
        $branch_messages[] = "Branch {$branch->branch_name}: Assigned " . count($assignments) . " batches";
      } else {
        $branch_messages[] = "Branch {$branch->branch_name}: No batches could be assigned";
      }
    }
 
    $execution_time = round(microtime(true) - $start_time, 4);
 
    $return = [
      'success' => true,
      'processed_records' => $inserted_records,
      'processed_branches' => $processed_branches,
      'message' => 'Daily PC task assignment completed',
      'details' => $branch_messages,
      'execution_time' => $execution_time . " seconds",
    ];
 
    if ($monitor) {
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    return $return;
  }
  
    public function CronjobContactDetailsTransfer()
  {
    $monitor = CronjobMonitorModel::where('sno', 22)->where('status', 0)->first();
    $start_time = microtime(true);
    $startDateTime = Carbon::createFromTimestamp((int)$start_time, 'Asia/Kolkata');
 
    // Early return checks
    if ($monitor && $monitor->status != 0) {
      $return = [
        'success' => false,
        'processed_records' => 0,
        'message' => 'Cronjob status Off',
        'execution_time' => round(microtime(true) - $start_time, 4) . " seconds",
      ];
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    if ($monitor) {
      $monitor->running_status = 1;
      $monitor->save();
    }
 
    $inserted_records = 0;
    $processed_branches = 0;
    $branch_messages = [];
    $skipped_records = 0;
 
    // Get current day (0=Sunday, 1=Monday, ..., 6=Saturday)
    $currentDay = Carbon::now('Asia/Kolkata')->dayOfWeek;
 
    // Get active branches with key as branch_id for easy access
    $activeBranches = DB::table('za_branch')
      ->where('status', 0)
      ->get()
      ->keyBy('sno'); // Key by branch_id
 
    // Get contact details with status 0
    $contactDetails = DB::table('za_contact_details')
      ->where('status', 0)
      ->select('id', 'branch_id', 'name', 'mobile_no', 'referral_by', 'status')
      ->get();
 
    // Limit to 5 records for testing
    $contactDetails = $contactDetails->take(500);
 
    foreach ($contactDetails as $contact) {
      // Clean mobile number: remove +91, spaces, and any non-numeric characters except +
      $cleanedMobile = $this->cleanMobileNumber($contact->mobile_no);
 
      // Skip if mobile number is empty after cleaning
      if (empty($cleanedMobile)) {
        $skipped_records++;
        $branch_messages[] = "Skipped: Empty mobile number for contact ID: " . ($contact->id ?? 'unknown');
        continue;
      }
 
      // Check if mobile already exists in RawLeadModel
      $existingLead = RawLeadModel::where('lead_mobile', $cleanedMobile)->first();
 
      if ($existingLead) {
        // Skip if mobile already exists
        $skipped_records++;
        $branch_messages[] = "Skipped: Mobile number $cleanedMobile already exists in RawLeadModel (Contact ID: $contact->id)";
        continue;
      }
 
      // Create new lead
      try {
        DB::beginTransaction();
 
        // Get branch details for this contact
        $branch = $activeBranches->get($contact->branch_id);
 
        if (!$branch) {
          throw new \Exception("Branch not found for branch_id: " . $contact->branch_id);
        }
 
        $branch_code = $branch->city_short_code ?? 'DEF'; // Default if city_short_code is null
 
        // Generate lead_id
        $customer = CustomerModel::where('status', '!=', 2)->where('sno', $contact->referral_by)->orderBy('sno', 'desc')->first();
        $category_check = RawLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
 
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "RL0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $lead_id = $year . '/' . $branch_code . '/' . sprintf("RL%04d", $next_number);
        }
 
        $lead = new RawLeadModel();
        $lead->lead_id = $lead_id;
        $lead->branch_id = $contact->branch_id ?? 0;
        $lead->lead_name = $contact->name ?? '';
        $lead->lead_mobile = $cleanedMobile;
        $lead->status = 7; // Default status
        $lead->lead_source_id = 27; // Default status
        $lead->lead_group = $customer->cus_name; // Default status
        $lead->referral_by = $contact->referral_by ?? $cleanedMobile;
        $lead->approved_by = 0;
        $lead->created_at = Carbon::now('Asia/Kolkata');
        $lead->updated_at = Carbon::now('Asia/Kolkata');
        $lead->registered_date = date('Y-m-d');
        $lead->save();
 
        // Update za_contact_details status to 1 (processed)
        DB::table('za_contact_details')
          ->where('id', $contact->id)
          ->update([
            'status' => 1,
            'updated_at' => Carbon::now('Asia/Kolkata')
          ]);
 
        DB::commit();
 
        $inserted_records++;
        $branch_messages[] = "Inserted: Mobile $cleanedMobile from branch ID: " . ($contact->branch_id ?? 'N/A') . " (Contact ID: $contact->id)";
      } catch (\Exception $e) {
        DB::rollBack();
        $branch_messages[] = "Error inserting lead for Contact ID $contact->id: " . $e->getMessage();
        \Log::error('Contact transfer error: ' . $e->getMessage(), [
          'contact_id' => $contact->id ?? 'unknown',
          'branch_id' => $contact->branch_id ?? 'unknown',
          'contact' => $contact,
          'cleaned_mobile' => $cleanedMobile
        ]);
      }
    }
 
    $processed_branches = $activeBranches->count();
    $execution_time = round(microtime(true) - $start_time, 4);
 
    $return = [
      'success' => true,
      'processed_records' => $inserted_records,
      'skipped_records' => $skipped_records,
      'processed_branches' => $processed_branches,
      'message' => 'Contact transfer to lead bank completed',
      'details' => $branch_messages,
      'execution_time' => $execution_time . " seconds",
    ];
 
    if ($monitor) {
      return $this->updateCronMonitor($monitor, $startDateTime, $start_time, $return);
    }
 
    return $return;
  }
  
    /**
   * Clean mobile number by removing +91, spaces, and special characters
   * Returns cleaned mobile number or empty string if invalid
   */
//   private function cleanMobileNumber($mobile)
//   {
//     if (empty($mobile)) {
//       return '';
//     }
 
//     // Remove spaces
//     $cleaned = preg_replace('/\s+/', '', $mobile);
 
//     // Remove +91 prefix if present
//     if (strpos($cleaned, '+91') === 0) {
//       $cleaned = substr($cleaned, 3);
//     }
 
//     // Remove any other non-numeric characters
//     $cleaned = preg_replace('/[^0-9]/', '', $cleaned);
 
//     // Remove leading zeros if any
//     $cleaned = ltrim($cleaned, '0');
 
//     // Validate: should be 10 digits (Indian mobile number)
//     if (strlen($cleaned) < 10 || strlen($cleaned) > 13) {
//       \Log::warning('Invalid mobile number length', [
//         'original' => $mobile,
//         'cleaned' => $cleaned,
//         'length' => strlen($cleaned)
//       ]);
//       return '';
//     }
 
//     return $cleaned;
//   }

/**
* Clean mobile number by removing all prefixes, spaces, and special characters
* Handles formats: +97471185074, 3082 6747, +974 7161 5330, +97455065305, 5554 4027, 6615 3322, 3399 0765
* Returns cleaned 10-digit mobile number or empty string if invalid
*/
private function cleanMobileNumber($mobile)
{
    if (empty($mobile)) {
        return '';
    }
 
    // Step 1: Remove all spaces
    $cleaned = preg_replace('/\s+/', '', $mobile);
    // Step 2: Remove all special characters except digits
    $cleaned = preg_replace('/[^0-9]/', '', $cleaned);
    // Step 3: Remove common prefixes
    $prefixes = ['+974', '974', '+91', '91', '+', '0'];
    foreach ($prefixes as $prefix) {
        if (strpos($cleaned, $prefix) === 0) {
            $cleaned = substr($cleaned, strlen($prefix));
            break; // Only remove one prefix
        }
    }
    // Step 4: Remove any remaining leading zeros
    $cleaned = ltrim($cleaned, '0');
    // Log the cleaning process for debugging
    \Log::info('Mobile cleaning', [
        'original' => $mobile,
        'cleaned' => $cleaned,
        'length' => strlen($cleaned)
    ]);
    // Step 5: Validate length
    if (strlen($cleaned) < 10) {
        \Log::warning('Mobile number too short after cleaning', [
            'original' => $mobile,
            'cleaned' => $cleaned,
            'length' => strlen($cleaned)
        ]);
        return '';
    }
    // Step 6: If length > 10, try to extract the last 10 digits
    if (strlen($cleaned) > 10) {
        // Check if it's a 12-digit number starting with 91
        if (strlen($cleaned) == 12 && substr($cleaned, 0, 2) == '91') {
            $cleaned = substr($cleaned, 2);
        } 
        // Check if it's an 11-digit number starting with 0 or 91
        elseif (strlen($cleaned) == 11) {
            if (substr($cleaned, 0, 2) == '91') {
                $cleaned = substr($cleaned, 2);
            } elseif (substr($cleaned, 0, 1) == '0') {
                $cleaned = substr($cleaned, 1);
            } else {
                // Take last 10 digits
                $cleaned = substr($cleaned, -10);
            }
        } else {
            // For any other length > 10, take the last 10 digits
            $cleaned = substr($cleaned, -10);
        }
    }
    // Step 7: Final validation - should be exactly 10 digits
    if (strlen($cleaned) != 10) {
        \Log::warning('Invalid mobile number after final validation', [
            'original' => $mobile,
            'cleaned' => $cleaned,
            'length' => strlen($cleaned)
        ]);
        return '';
    }
    // Step 8: Check if it's a valid Indian mobile number (starts with 6,7,8,9)
    $firstDigit = substr($cleaned, 0, 1);
    if (!in_array($firstDigit, ['6', '7', '8', '9'])) {
        \Log::warning('Invalid Indian mobile number (should start with 6,7,8,9)', [
            'original' => $mobile,
            'cleaned' => $cleaned,
            'first_digit' => $firstDigit
        ]);
        return '';
    }
    return $cleaned;
}
  
}
