<?php

namespace App\Http\Controllers\customer;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\settings\course\CourseSubCategory;
use App\Http\Controllers\settings\course\CourseType;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CourseSubCategoryModel;
use App\Models\ContactDetailsModel;
use App\Models\CourseTypeModel;
use App\Models\DropRefundModel;
use App\Models\StudentpointsModel;
use App\Models\GeneralSettingsModel;
use App\Models\RefundChecklistModel;
use App\Models\BatchSummaryModel;
use App\Models\CustomerEducationModel;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\ReferralModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use App\Models\SubLedgerModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingChangeModel;
use App\Models\TrainingModel;
use App\Models\QrCouponModel;
use App\Models\TransactionModel;
use App\Models\WhatsappTemplateLogModel;
use App\Models\User;
use Carbon\Carbon;
use App\Models\OldCustomerModel;
use App\Models\PaymentOldModel;
use DateTime;
use App\Models\EmailTemplateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Mail\EAPLMail;
use App\Models\StaffpointsModel;
use App\Models\ManageCouponModel;
use App\Models\WhatsappApiConfigureModel;
use Illuminate\Support\Facades\Auth;
use App\Models\ManageCouponHistoryModel;
use App\Models\HoldReasonModel;
use App\Models\HoldHistoryModel;
use App\Models\ReferralPersonModel;
use App\Traits\NotifiableTrait;
use App\Models\RequestCertificateModel;
use Illuminate\Support\Facades\Log;


class ManageCustomer extends Controller
{
    protected $client;
    protected $accessToken;
    protected $businessId;
    protected $baseUrl;
    protected $phoneNumberId;
    use NotifiableTrait;
    public function __construct()
    {
        $whatsappConfig      = app(\App\Services\WhatsAppManagerService::class)->legacyCompatibilityProfile();
        $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
        $this->accessToken   = $whatsappConfig->access_tokken;  // Set your access token in the environment file
        $this->baseUrl       = 'https://graph.facebook.com/' . config('whatsapp.api_version', 'v26.0');
        $this->businessId    = $whatsappConfig->waba_id;
    }

    // whatsapp config
    private function sendRequestToWhatsApp($url, $token, $data)
    {
        // Compatibility shim only: the original URL/token are intentionally ignored.
        // Admin-managed global automation rule selects the actual Meta-approved template.
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
        $callerMethod = $trace[1]['function'] ?? 'unknown';
        return app(\App\Services\WhatsAppLegacyDispatchService::class)->dispatch(static::class, $callerMethod, (array) $data);
    }
      public function ReferralList()
      {
        $ReferralList = ReferralModel::where('status', 0)->orderBy('sno', 'desc')->get();
        return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $ReferralList
        ], 200);
      }

    public function ReferralCustomerList(Request $request)
    {
      $ReferralList = CustomerModel::where('status', 0)->where('branch_id', $request->user()->branch_id)->orderBy('sno', 'desc')->get();

      $helper = new \App\Helpers\Helpers();
      
      if($ReferralList->isNotEmpty()){
        foreach($ReferralList as $ReferralData){
          
          $completed_by_id = isset($ReferralData->sno) && ((int)$ReferralData->sno >= 0) ? (int)$ReferralData->sno : -1;

          $staff_backgrounds = isset($ReferralData->sno) ? $helper->generateAvatarColors((int)$ReferralData->sno) : null;
          $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
          $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;

          $staff_img_html = '';

          if($completed_by_id > 0){
            $staff_img_html .= '<div class="avatar">
                <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($ReferralData->cus_name) && !empty($ReferralData->cus_name) ? strtoupper(substr(($ReferralData->cus_name ?? 'U'), 0, 1)) : 'U') . '</span>
            </div>';
          }else{
            $staff_img_html .= '<div class="customer-avatar" id="ref_customer_profile">
              <i class="mdi mdi-account-circle"></i>
            </div>

            <div class="customer-details">

              <div class="customer-name" id="ref_customer_name">
                  None
              </div>

              <div class="info-row">
                  <i class="mdi mdi-phone"></i>
                  <span id="ref_customer_mobno">None</span>
              </div>

              <div class="info-row">
                  <i class="mdi mdi-email-outline"></i>
                  <span id="ref_customer_mailid">None</span>
              </div>

            </div>';
          }

          $ReferralData->cust_image_html = $staff_img_html;

        }
      }

      return  response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $ReferralList
      ], 200);
    }

  public function ReferralStaffList(Request $request)
  {
    $ReferralList = StaffModel::where('status', 0)->where('branch_id', $request->user()->branch_id)->orderBy('sno', 'desc')->get();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $ReferralList
    ], 200);
  }
  
   public function ReferralStaffPostList(Request $request)
  {
    $ReferralList = StaffModel::where('status', 0)->whereIn('department_id', [2, 3, 5, 6, 7])
      ->where('branch_id', $request->user()->branch_id)
      ->orderBy('sno', 'desc')
      ->get();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $ReferralList
    ], 200);
  }
  
  public function customer_add($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $id = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($id === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
    }


    // Split the decrypted value
    $exp = explode('~', $id);
    $id = str_replace(' ', '', $exp[0] ?? '');

    $step = str_replace(' ', '', $exp[1] ?? '');
    $course_type_hidden_id = session('course_type_hidden_id');
    $course_batch_hidden_id = session('course_batch_hidden_id');
    $allStepsData = [];

    // Retrieve data for all steps from the session
    for ($i = 1; $i <= 5; $i++) {
      $allStepsData['step_' . $i] = session('customer_form_step_' . $i, []);
    }
    $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();


    // Fetch customer details
    $customer = CustomerModel::select('za_customer.*', 'za_lead.sno as lead_id', 'za_course.course_name', 'za_lead.sno as lead_id','za_course_type.ratio', 'za_course_type.course_type_name', 'za_course_type.online_fee','za_lead.is_qr_discount','za_discount_lead.type','za_discount_lead.discount_code','za_discount_lead.discount_value','za_discount_lead.discount_id')
            ->leftjoin('za_course', 'za_customer.course_id', '=', 'za_course.sno')
            ->leftjoin('za_course_type', 'za_customer.course_type_id', '=', 'za_course_type.sno')
            ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
            ->leftjoin('za_discount_lead', 'za_lead.is_qr_discount', '=', 'za_discount_lead.sno')
            // ->where('za_customer.status', '!=', 2)
            ->where('za_customer.lead_id', $id)
            ->orderBy('sno', 'desc')
            ->first();

    // Decode the course_id if customer exists
    if ($customer) {
      $customer->course_id = json_decode($customer->course_id, true); // Ensure the second argument to decode as an array
    }

    // Decode the course_id if customer exists
    if ($customer) {
      // Ensure the course_id exists and is not empty
      if (!empty($customer->course_id)) {
        // Fetch the course names based on the customer's course_id
        $courses = ManageCoursesModel::whereIn('sno', $customer->course_id)
          ->pluck('course_name')
          ->toArray();

        // Assign the fetched course names to the customer
        $customer->course_names = $courses; // No need for null coalescing since $courses is always an array
      } else {
        // If course_id is empty, set course_names to an empty array
        $customer->course_names = [];
      }
    }
    // return $customer;
    $course_data = ManageCoursesModel::where('sno', $customer->course_id ?? '')->first();
    // return $course_data;
    $lead = LeadModel::select('za_lead.*')
      // ->join('za_course', 'za_lead.course_id', '=', 'za_course.sno')
      ->where('za_lead.sno', $id)
      ->first();

    // // Decode course_id if it's JSON
    if ($lead && !empty($lead->course_id)) {
      $courseIds = json_decode($lead->course_id);

      // Check if courseIds is a valid array after decoding
      if (is_array($courseIds)) {
        // Fetch course names based on IDs
        $courses = DB::table('za_course')
          ->whereIn('sno', $courseIds)
          ->pluck('course_name');

        // Assign course names to the lead object
        $lead->course_names = $courses;
      } else {
        $lead->course_names = []; // Empty array if course_id is not an array
      }
    }

    $batch_check_hidden_id = session('batch_check_hidden_id', '');
    $cus_name = session('cus_name');
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings->date_format ?? 'd-M-y';
    $lead->formatted_lead_dob = $lead->lead_dob ? Carbon::parse($lead->lead_dob)->format($dateFormat) : null;
    // dd($customer);
    return view('content.customer.customer_add', compact('branch_data', 'customer', 'step', 'allStepsData', 'course_type_hidden_id', 'course_batch_hidden_id', 'batch_check_hidden_id', 'course_data', 'lead'));
  }
  public function saveSelectedBatch(Request $request)
  {
    // Get the batch_id and lead_id from the request
    $batch_id_arr = $request->input('batch_id');
    $lead_id = $request->input('lead_id');

    // Ensure batch_id is in an array format
    if (!is_array($batch_id_arr)) {
      $batch_id_arr = [$batch_id_arr];
    }
    if (empty($batch_id_arr) || $batch_id_arr === [null]) {
      $batch_id_arr = ["0"];
    }
    // Convert the batch ID array to a JSON string
    $batchIdJson = json_encode($batch_id_arr);

    // Update or create the customer record with the batch_id
    $customer = CustomerModel::updateOrCreate(
      ['lead_id' => $lead_id],
      [
        'batch_id' => $batchIdJson ?? null,
      ]
    );

    // Return success response
    return response()->json([
      'status' => 'success',
      'message' => 'Batch selected successfully!',
      'data' => $request->batch_id
    ]);
  }
  public function saveSelectedBatchCourse(Request $request)
  {
    // Get the batch_id and lead_id from the request
    $batch_id_arr = $request->input('batch_id');
    $lead_id = $request->input('lead_id');

    // // Ensure batch_id is in an array format
    // if (!is_array($batch_id_arr)) {
    //     $batch_id_arr = [$batch_id_arr];
    // }

    // // Convert the batch ID array to a JSON string
    // $batchIdJson = json_encode($batch_id_arr);

    // Update or create the customer record with the batch_id
    $customer = CustomerModel::updateOrCreate(
      ['lead_id' => $lead_id],
      [
        'enroll_batch_id' => $batch_id_arr ?? null,
      ]
    );

    // Return success response
    return response()->json([
      'status' => 'success',
      'message' => 'Batch selected successfully!',
      'data' => $request->batch_id
    ]);
  }
  
  public function customerSave(Request $request)
  {
      $all_options = $request->input('all_options') ?? 0;
      $lead_tag_course_id = $request->input('course_batch_id_chk');
      $ref_customer_id = $request->ref_customer_id ?? 0;
      $step = $request->input('step');
      $tableData = json_decode($request->input('table_data'), true);

    
      //  dd($request->all());
      // dd($request->hasFile('cus_pic'));

      // Define validation rules based on the step
      $rules = [];
      switch ($step) {
          case 1:
              $rules = [
                  'cus_name' => 'required|string|max:255',
                //   'cus_email_id' => 'required|email',
                  'cus_mobile' => 'required|digits:10',
                //   'cus_dob' => 'required',
                  // 'cus_address' => 'required|string|max:500',
                  // 'contact_person' => 'required',
                  // Add other fields for step 1 as needed
              ];
              break;
          case 2:
              $rules = [
                  // 'customer_type_id' => 'required',
                  // Add other fields for step 2 as needed
              ];
              break;
          case 3:
                if ($all_options == 0) {
                  $rules = [
                      'course_batch_id_chk' => 'required',
                      // Add other fields for step 3 as needed
                  ];
              } else {
                  $rules = [
                      'course_category_id' => 'required',
                      'course_subcategory_id' => 'required',
                      'course_type_batch_id' => 'required',
                      'course_batch_id' => 'required',
                      // Add other fields for step 3 as needed
                  ];
              }
              break;
          case 4:
              // Add validation for step 4 if needed
              break;
          case 5:
              $rules = [
                  'initial_fees_pay' => 'required',
                  // Add other final step validations as needed
              ];
              break;
      }

      // Perform validation
      $request->validate($rules);
      $filePath = '';
      
     if ($request->hasFile('cus_pic')) {
        $fileName = idate('B') . rand(1, 50) . '.' . $request->file('cus_pic')->extension();
        $destinationPath = public_path('cus_pics');
        // Path to the logos directory
        $request->file('cus_pic')->move($destinationPath, $fileName);
        $filePath = $fileName;
      }

      
      if ($step == 1) {
          
         $allData = $request->except(['_token', 'step']);

        // Store the data in session for later steps
        session(['customer_form_step_' . $step => $allData]);


        // $cus_gender = ($allData['inlineRadioOptions'] == 'Male') ? 1 : 2;
        $cus_gender = ($allData['inlineRadioOptions'] ?? 'Female') == 'Male' ? 1 : 2;
        $batch_id_cus = $allData['batch_new_id'];
        // $cus_gender = isset($allData['inlineRadioOptions']) && $allData['inlineRadioOptions'] == 'Male' ? 1 : 2;

        $courseId = $all_options == 0 ? $lead_tag_course_id : $allData['course_new_id'];
        $batch_id_arr = $allData['batch_new_id'];
        // Check if course_id is a single value and convert it to an array
        if (!is_array($courseId)) {
            $courseId = [$courseId];
        }

        // Convert the array to a JSON string
        $courseIdJson = json_encode($courseId);
        // Check if course_id is a single value and convert it to an array
        if (!is_array($batch_id_arr)) {
            $batch_id_arr = [$batch_id_arr];
        }

        // If the array is null or empty, set it to ["0"]
        if (empty($batch_id_arr) || $batch_id_arr === [null]) {
            $batch_id_arr = ["0"];
        }

        // Convert the array to a JSON string
        $batchIdJson = json_encode($batch_id_arr);
        $branch_id = $request->user()->branch_id;

        $user_id = $request->user()->user_id;

        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;
        $user_id = $request->user()->user_id;


        $customer = CustomerModel::updateOrCreate(
            ['lead_id' => $allData['lead_id']],
            [

                'cus_name' => ucfirst($allData['cus_name'] ?? null),
                'branch_id' => $branch_id ?? null,
                'cus_gender' => $cus_gender ?? null,
                'cus_dob' => isset($allData['cus_dob']) ? DateTime::createFromFormat('d-M-Y', $allData['cus_dob'])->format('Y-m-d') : null,
                'doj' => isset($allData['doj']) ? DateTime::createFromFormat('d-M-Y', $allData['doj'])->format('Y-m-d') : date('Y-m-d'),
                'cus_mobile' => $allData['cus_mobile'] ?? null,
                'cus_alternate_mobile' => $allData['cus_alternate_mobile'] ?? null,
                'cus_email_id' => $allData['cus_email_id'] ?? null,
                'cus_marital_status' => $allData['cus_marital_status'] ?? null,
                'c_p_mobile' => $allData['c_p_mobile'] ?? null,
                'contact_person' => $allData['contact_person'] ?? null,
                'door_no' => $allData['door_no'] ?? null,
                'pincode' => $allData['pincode'] ?? null,
                'customer_type_id' => $allData['customer_type_id'] ?? null,
                'country' => $allData['country'] ?? null,
                'state' => $allData['state'] ?? null,
                'city' => $allData['city'] ?? null,
                'address' => $allData['address'] ?? null,
                'vip' => $allData['vip_customer'] ?? null,
                'course_id' => $courseIdJson ?? null,
                'course_subcategory_id' => $allData['course_subcategory_id'] ?? null,
                'course_type_id' => $all_options == 0 ? $request->input('course_type_batch_id_chk') ?? 0 : $allData['course_type_batch_id'] ?? null,
                'coupon_code_ref' => $allData['coupon_code'] ?? null,
                'customer_ref' => $allData['customer_id'] ?? null,
                'batch_id' => $batchIdJson ?? null,
                'course_mode_id' => $all_options == 0 ? $request->input('course_mode_id_chk') ?? 0 : $allData['course_mode_id'] ?? 0,
                'free_shd_count' => $allData['free_shd_count'] ?? null,
                'is_placement' => $allData['is_placement'] ?? 0,
                'cus_edcuation' => '', // this appears to be intentionally empty
                'cus_pic' => $filePath ?? null, // Corrected this line
                'created_by' => $user_id,
                'status' => 5,
                'updated_by' => $user_id,
            ]
        );
        
          if ($customer->customer_ref > 0) {

            ReferralPersonModel::updateOrCreate(
                [
                    'customer_id' => $customer->sno ?? null, // Unique identifier for update
                    'branch_id' => $branch_id ?? null,       // Ensure branch_id is part of uniqueness
                ],
                [
                  'referral_type' => $allData['referral_student_id'], // Ensures unique referral type per customer
                    'referral_id' => $allData['referral_student_id'] == 1 ? $allData['referral_customer_id'] :
                                    ($allData['referral_student_id'] == 2 ? $allData['referral_staff_id'] : null),
                    'referral_person' => $allData['referral_student_id'] == 3 ? $allData['referral_person_name'] : null,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]
            );
        }
          $helper = new \App\Helpers\Helpers();
          $encrypted_values = $helper->encrypt_decrypt($request->lead_id . '~' . $step + 1, 'encrypt');
          return redirect()->route('customer_add', ['id' => $encrypted_values]);
      }
      
      session(['customer_form_step_' . $step => $request->except(['_token', 'step', 'cus_pic'])]);
      if ($step < 5 && $step > 1) {
          $allData = [];
          for ($i = 1; $i <= 5; $i++) {
              $allData = array_merge($allData, session('customer_form_step_' . $i, []));
          }


          // $cus_gender = ($allData['inlineRadioOptions'] == 'Male') ? 1 : 2;
          $cus_gender = ($allData['inlineRadioOptions'] ?? 'Female') == 'Male' ? 1 : 2;
          $batch_id_cus = $allData['batch_new_id'];
          // $cus_gender = isset($allData['inlineRadioOptions']) && $allData['inlineRadioOptions'] == 'Male' ? 1 : 2;

          $courseId = $all_options == 0 ? $lead_tag_course_id : $allData['course_new_id'];
          $batch_id_arr = $allData['batch_new_id'];
          // Check if course_id is a single value and convert it to an array
          if (!is_array($courseId)) {
              $courseId = [$courseId];
          }

          // Convert the array to a JSON string
          if (empty($courseId) || $courseId === [null]) {
        $courseIdJson = ["55"];
      } else {
        // Convert the array to a JSON string
        $courseIdJson = json_encode($courseId);
      }
          
          // Check if course_id is a single value and convert it to an array
          if (!is_array($batch_id_arr)) {
              $batch_id_arr = [$batch_id_arr];
          }

          // If the array is null or empty, set it to ["0"]
          if (empty($batch_id_arr) || $batch_id_arr === [null]) {
              $batch_id_arr = ["0"];
          }

          // Convert the array to a JSON string
          $batchIdJson = json_encode($batch_id_arr);
          $branch_id = $request->user()->branch_id;

          $user_id = $request->user()->user_id;

          $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

          $branch_code = $branch_check->city_short_code;
          $user_id = $request->user()->user_id;


          $customer = CustomerModel::updateOrCreate(
              ['lead_id' => $allData['lead_id']],
              [

                 
                //   'customer_id' => $customer_id ?? null,
                  'course_id' => $courseIdJson ?? ["33"],
                  'course_subcategory_id' => $allData['course_subcategory_id'] ?? null,
                  'course_type_id' => $all_options == 0 ? $request->input('course_type_batch_id_chk') ?? 0 : $allData['course_type_batch_id'] ?? null,
                  'coupon_code_ref' => $allData['coupon_code'] ?? null,
                  'customer_ref' => $allData['customer_id'] ?? null,
                  'batch_id' => $batchIdJson ?? null,
                  'course_mode_id' => $all_options == 0 ? $request->input('course_mode_id_chk') ?? 0 : $allData['course_mode_id'] ?? 0,
                  'free_shd_count' => $allData['free_shd_count'] ?? null,
                  'cus_edcuation' => '', // this appears to be intentionally empty
                  'created_by' => $user_id,
                //   'status' => 5,
                  'updated_by' => $user_id,
              ]
          );
            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($request->lead_id . '~' . $step + 1, 'encrypt');
            return redirect()->route('customer_add', ['id' => $encrypted_values]);
      }
      try {
        DB::beginTransaction();
          $allData = [];
          if ($step == 5) {
              for ($i = 1; $i <= 5; $i++) {
                  $allData = array_merge($allData, session('customer_form_step_' . $i, []));
              }
          
              $cus_gender = ($allData['inlineRadioOptions'] ?? 'Female') == 'Male' ? 1 : 2;
              $batch_id_cus = $allData['batch_new_id'];
            
    
              $courseId = $allData['course_batch_hidden_id'];
              $batch_id_arr = $allData['batch_new_id'];
              // Check if course_id is a single value and convert it to an array
              if (!is_array($courseId)) {
                  $courseId = [$courseId];
              }
    
              // Convert the array to a JSON string
              $courseIdJson = json_encode($courseId);
              // Check if course_id is a single value and convert it to an array
              if (!is_array($batch_id_arr)) {
                  $batch_id_arr = [$batch_id_arr];
              }
              // If the array is null or empty, set it to ["0"]
              if (empty($batch_id_arr) || $batch_id_arr === [null]) {
                  $batch_id_arr = ["0"];
              }
              // Convert the array to a JSON string
              $batchIdJson = json_encode($batch_id_arr);
              $branch_id = $request->user()->branch_id;
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
    
              $branch_code = $branch_check->city_short_code;
              $user_id = $request->user()->user_id;
                 $cus_check = CustomerModel::whereNotNull('customer_id') // Skip null customer_id
                ->where('customer_id', 'LIKE', date("Y") . '/' . $branch_code . '/CUS%')
                ->orderByRaw("CAST(SUBSTRING_INDEX(customer_id, 'CUS', -1) AS UNSIGNED) DESC")
                ->first();
    
                if (!$cus_check || !isset($cus_check->customer_id)) {
                    $year = date("Y");
                    $customer_id = $year . '/' . $branch_code . '/' . "CUS2005";
                } else {
                    $data = $cus_check->customer_id;
                    $slice = explode("/", $data);
    
                    // Validate $slice[2] exists before using it
                    if (isset($slice[2]) && preg_match('/CUS(\d+)/', $slice[2], $matches)) {
                        $next_number_cos = (int)$matches[1] + 1;
                    } else {
                        $next_number_cos = 2005; // Default if extraction fails
                    }
    
                    $request_cus = sprintf("CUS%04d", $next_number_cos);
                    $year = date("Y");
                    $customer_id = $year . '/' . $branch_code . '/' . $request_cus;
                }

              $customer = CustomerModel::updateOrCreate(
                  ['lead_id' => $allData['lead_id']],
                  [
    
                      'customer_id' => $customer_id ?? null,
                      'coupon_code_ref' => $allData['coupon_code'] ?? null,
                      'customer_ref'    => $allData['referral_student_id'] ?? null,
                      'referral_person_name'    => $allData['referral_person_name'] ?? null,
                      'free_shd_count'  => $allData['free_shd_count'] ?? null,
                      'status'          => 0,
                      'created_by'      => $user_id,
                      'updated_by'      => $user_id,
                  ]
              );
    
              $ed_check = CustomerEducationModel::orderBy('sno', 'desc')->first();
              if (!$ed_check) {
                  $year = date("Y");
                  $education_id = $year . '/' . $branch_code . '/' . "EDU2005";
              } else {
                  $data = $ed_check->education_id;
                  $slice = explode("/", $data);
                  $result_cus = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int)$result_cus + 1;
                  $request_cos = sprintf("EDU%04d", $next_number_cos);
                  $year = date("Y");
                  $education_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
              // Get the dynamic fields from the request (example: field_5, field_6)
              $dynamicFields = collect($allData)->filter(function ($value, $key) {
                  return strpos($key, 'field_') !== false;
              });
    
              // Initialize formatted data array
              $formattedData = [];
    
             
              foreach ($dynamicFields as $key => $value) {
    
                  if (strpos($key, 'field_name_') !== false) {
    
                    $optionId = str_replace('field_name_', '', $key);
                    $fieldKey = 'field_' . $optionId;
    
                    if (isset($dynamicFields[$fieldKey])) {
                      $formattedData[] = [
                        'label_name' => $value,
                        'label_value' => $dynamicFields[$fieldKey]
                      ];
                    }
                  }
                }
    
              CustomerEducationModel::updateOrCreate(
                  [
    
                      'education_id' => $education_id,
                      'branch_id'    => $branch_id,
                      'customer_id'  => $customer->sno,
                      'customer_type_id' => $allData['customer_type_id'] ?? null,
                      'datas'        => json_encode($formattedData),
                      'created_by'   => $user_id,
                      'updated_by'   => $user_id,
                  ]
              );
            
           
             // Generate payment ID
                $pay_check = PaymentModel::where('payment_id', 'LIKE', $year . '/' . $branch_code . '/PAY%')
                    ->orderByRaw("CAST(SUBSTRING_INDEX(payment_id, 'PAY', -1) AS UNSIGNED) DESC")
                    ->first();
    
                $year = date("Y");
    
                if (!$pay_check) {
                  $payment_auto_id = $year . '/' . $branch_code . '/' . "PAY0001";
                } else {
                    $data = $pay_check->payment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[2]); // Extract only numbers from "PAYxxxx"
                    $next_number = (int)$result + 1;
                    $request_pay = sprintf("PAY%04d", $next_number); // Format as PAYxxxx
                    $payment_auto_id = $year . '/' . $branch_code . '/' . $request_pay;
                }
              $courseArrayJson = $customer->course_id;  // This is a JSON-encoded string like '["7"]'
              $courseArray = json_decode($courseArrayJson);  // Decode the JSON to get an array
    
              $courseArrayToNormal = (int) $courseArray[0];  // Access the first element and cast to integer
    
              $invoice_chk_cus = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
              $year = date("Y");
              if (!$invoice_chk_cus) {
                  $invoice_id_cus = 'EA/' . $year . '/INV2005';
              } else {
                  $data = $invoice_chk_cus->invoice_id;
                  $slice = explode("/", $data);
                  if (count($slice) >= 3) {
                      $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
                      $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
                  } else {
                      $next_inv_number = 2005;
                  }
                  $invoice_id_cus = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
              }
    
              // Loop through each row in tableData
              foreach ($allData['tableData'] as $row) {
                  // Ensure $row is valid and contains the necessary data
                  if (is_array($row)) {
                      // Handle "N/A" or null for initialPayDate
                      if ($row['column1'] === 'N/A' || $row['column1'] === null) {
                          $initialPayDateFormatted = now()->format('Y-m-d'); // Default to today's date
                      } else {
                          $initialPayDate = DateTime::createFromFormat('d-m-Y', $row['column1']);
                          if ($initialPayDate === false) {
                              \Log::error('Invalid initialPayDate format:', ['column1' => $row['column1']]);
                              continue; // Skip this row if the date format is invalid
                          }
                          $initialPayDateFormatted = $initialPayDate->format('Y-m-d');
                      }
    
                      // Handle nextPayDate (allowing null)
                      if ($row['column2'] !== null) {
                          $nextPayDate = DateTime::createFromFormat('d-m-Y', $row['column2']);
                          if ($nextPayDate === false) {
                              \Log::error('Invalid nextPayDate format:', ['column2' => $row['column2']]);
                              continue; // Skip this row if the date format is invalid
                          }
                          $nextPayDateFormatted = $nextPayDate->format('Y-m-d');
                      } else {
                          $nextPayDateFormatted = null; // Set to null if there's no next pay date
                      }
    
                      // Determine payment status
                      $status = ($row['column6'] === 'Paid') ? 1 : 0;
                      $invoices = ($row['column6'] === 'Paid') ? $invoice_id_cus: null;
    
                      // Update or create payment record
                      PaymentModel::updateOrCreate(
                          [
                              'payment_id'     => $payment_auto_id,
                              'branch_id'      => $branch_id,
                              'customer_id'    => $customer->sno,
                              'course_id'      => $courseArrayToNormal,
                              'initialPayDate' => $initialPayDateFormatted,
                              'nextPayDate'    => $nextPayDateFormatted,
                              'amount'         => $row['amount1'],
                              'paidAmount'     => $row['amount4'] ?? 0, // Default to 0 if null
                              'gst_amount'     => $row['amount5'] == 0 ? $row['amount1'] * 0.18 : $row['amount5'],
                              'balanceFee'     => $row['amount7'] ?? 0, // Default to 0 if null
                              'total_amount'   => $allData['final_course_fees'],
                              'payment_mode_label'   => $allData['payment_mode_display_hidden'],
                              'transaction'   => $allData['transaction_id_input'],
                              'status'         => $status,
                              'invoice_id'     => $invoices,
                              'created_by'     => $user_id,
                              'updated_by'     => $user_id,
                          ]
                      );
                  }
              }
    
    
              $batchArrayJson = $customer->batch_id;  // This is a JSON-encoded string like '["7"]'
              $batchArray = json_decode($batchArrayJson);  // Decode the JSON to get an array
    
              $batchArrayToNormal = (int) $batchArray[0];
              $batch_id = BatchModel::where('sno', $batchArrayToNormal)->first();
              $cos_check = TrainingModel::orderBy('sno', 'desc')->first();
    
              // Generate training_id based on existing records or start fresh
              if (!$cos_check) {
                  $year = date("Y");
                  $training_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $cos_check->training_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int)$result_cos + 1;
                  $request_cos = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $training_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
    
              // Calculate fees and amounts
              $finalCourseFees = $allData['final_course_fees'] ?? 0; // Default to 0 if not set
              $paidAmount = $allData['initial_fees_pay_input'] ?? 0; // Default to 0 if not set
              $discounted_check = isset($allData['discounted_amount_hidden']) && $allData['discounted_amount_hidden'] > 0 ? 1 : 0;
              $paidGst = $paidAmount * 0.18; // Calculate paid GST
    
              $totalAmount = $paidAmount + $paidGst; // Total amount
              $balanceAmount = $allData['balance_course_fee']; // Default to 0 if not set
              $balanceGst = $balanceAmount * 0.18; // Calculate balance GST
    
              $courseArrayToNormals = $customer->course_id;
              $courseArray = json_decode($courseArrayToNormals, true); // Decode as an array
    
              $course = ManageCoursesModel::where('sno', $courseArray)->first(); // Fetch course details
            //   $course = ManageCoursesModel::where('sno', $customer->enroll_course_id)->first();
              $training = null; // Initialize $training to ensure it's always defined
              $course_type = CourseTypeModel::where('sno', $course->course_type_id)->first();
              if ($course && $course->tesbo_cousre_id &&  $course_type->combined_course == 1) {
                  // Decode the tesbo_cousre_id array
                  $tesbo_course_ids = json_decode($course->tesbo_cousre_id, true);
                  if (!empty($tesbo_course_ids)) {
                  // Iterate over each tesbo_cousre_id
                  foreach ($tesbo_course_ids as $tesbo_course_id) {
                      // Update or create the TrainingModel record for each tesbo_cousre_id
                        $training =  TrainingModel::updateOrCreate(
                                  [
                                      'training_id'     => $training_id,
                                      'branch_id'       => $branch_check->sno,
                                      'customer_id'     => $customer->sno,
                                      'course_id'       => $tesbo_course_id, // Save each tesbo_course_id
                                      'batch_id'        => $batch_id->sno ?? 0,
                                      'slot_id'         => $batch_id->slot_id ?? null,
                                      'staff_id'        => $batch_id->staff_id ?? null,
                                      'start_date'      => $batch_id->start_date ?? null,
                                      'end_date'        => $batch_id->end_date ?? null,
                                      'overall_fees'    => $finalCourseFees,
                                      'gst_amount'      => $finalCourseFees * 0.18, // Calculate GST for overall fees
                                      'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
                                      'discount_check'  => $discounted_check,
                                      'paid_amount'     => $paidAmount,
                                      'paid_gst'        => $paidGst,
                                      'total_amount'    => $totalAmount,
                                      'balance_amount'  => $balanceAmount,
                                      'balance_gst'     => $balanceGst,
                                      'tesbo_check'     => $course->course_type_id ?? 0,
                                      'course_mode_id'  => $customer->course_mode_id ?? 0,
                                      'online_amount'   => $customer->online_fee ?? 0,
                                      'payment_id'      => $payment_auto_id ?? null,
                                      'created_by'      => $user_id,
                                      'updated_by'      => $user_id,
                                  ]
                              );
                          }
                }else{
                      $training =   TrainingModel::updateOrCreate(
                      [
                          'training_id'     => $training_id,
                          'branch_id'       => $branch_check->sno,
                          'customer_id'     => $customer->sno,
                          'course_id'       => $courseArrayToNormal, // Use the normal course_id
                          'batch_id'        => $batch_id->sno ?? 0,
                          'slot_id'         => $batch_id->slot_id ?? null,
                          'staff_id'        => $batch_id->staff_id ?? null,
                          'start_date'      => $batch_id->start_date ?? null,
                          'end_date'        => $batch_id->end_date ?? null,
                          'overall_fees'    => $finalCourseFees,
                          'gst_amount'      => $finalCourseFees * 0.18, // Calculate GST for overall fees
                          'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
                          'discount_check'  => $discounted_check,
                          'paid_amount'     => $paidAmount,
                          'paid_gst'        => $paidGst,
                          'total_amount'    => $totalAmount,
                          'balance_amount'  => $balanceAmount,
                          'balance_gst'     => $balanceGst,
                          'tesbo_check'     => 0,
                          'course_mode_id'  => $customer->course_mode_id ?? 0,
                          'online_amount'   => $customer->online_fee ?? 0,
                          'payment_id'      => $payment_auto_id ?? null,
                          'created_by'      => $user_id,
                          'updated_by'      => $user_id,
                      ]
                  );
                }
              } else {
                  // If no tesbo_cousre_id, update or create a single record for the normal course
                    $training =   TrainingModel::updateOrCreate(
                      [
                          'training_id'     => $training_id,
                          'branch_id'       => $branch_check->sno,
                          'customer_id'     => $customer->sno,
                          'course_id'       => $courseArrayToNormal, // Use the normal course_id
                          'batch_id'        => $batch_id->sno ?? 0,
                          'slot_id'         => $batch_id->slot_id ?? null,
                          'staff_id'        => $batch_id->staff_id ?? null,
                          'start_date'      => $batch_id->start_date ?? null,
                          'end_date'        => $batch_id->end_date ?? null,
                          'overall_fees'    => $finalCourseFees,
                          'gst_amount'      => $finalCourseFees * 0.18, // Calculate GST for overall fees
                          'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
                          'discount_check'  => $discounted_check,
                          'paid_amount'     => $paidAmount,
                          'paid_gst'        => $paidGst,
                          'total_amount'    => $totalAmount,
                          'balance_amount'  => $balanceAmount,
                          'balance_gst'     => $balanceGst,
                          'tesbo_check'     => 0,
                          'course_mode_id'  => $customer->course_mode_id ?? 0,
                          'online_amount'   => $customer->online_fee ?? 0,
                          'payment_id'      => $payment_auto_id ?? null,
                          'created_by'      => $user_id,
                          'updated_by'      => $user_id,
                      ]
                  );
    
              }
    
    
    
              //  return $training;
    
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();
    
    
              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_led = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int)$result_led + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
    
              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id      = 1;
              $add_subledger->subledger_id   = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id      = $branch_check->sno;
              $add_subledger->traning_sno    = $training->sno;
              $add_subledger->created_by     = $user_id;
              $add_subledger->updated_by     = $user_id;
    
              $add_subledger->save();
              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                  $transaction_attach_sno = "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_tra = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int)$result_tra + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                  $transaction_attach_sno = $request_tr;
              }

              $attachments = isset($request->payment_attachments_hidden) && !empty($request->payment_attachments_hidden) ? json_decode($request->payment_attachments_hidden, true) : [];

              if(!empty($attachments)){

                $upload_path = public_path('payment_attachments/' . $transaction_attach_sno);
  
                if (!file_exists($upload_path)) {
                  mkdir($upload_path, 0777, true);
                }
  
                $file_list = [];
  
                foreach ($attachments as $attachment) {
  
                    $original_name = $attachment['name'];
  
                    $extension = pathinfo($original_name, PATHINFO_EXTENSION);
  
                    $file_name = 'payment_' . time() . '_' . uniqid() . '.' . $extension;
  
                    $base64 = $attachment['content'];
  
                    $base64 = preg_replace('/^data:.*;base64,/', '', $base64);
  
                    $file_content = base64_decode($base64);
  
                    file_put_contents(
                        $upload_path . '/' . $file_name,
                        $file_content
                    );
  
                    $file_list[] = [
                      'file_name'      => $file_name,
                      'original_name'  => $original_name,
                      'file_extension' => $extension,
                      'file_path'      => 'payment_attachments/' . $transaction_attach_sno . '/' . $file_name
                    ];
                }
              }

              TransactionModel::updateOrCreate(
                  [
                      'branch_id'         => $branch_check->sno,
                      'transaction_id'    => $transaction_id,
                      'transaction_type'  => 'Credit',
                      'transaction_name'  => 'Customer',
                      'trans_source_id'   => $customer->customer_id,
                      'ledger_id'         => 1,
                      'subledger_id'      => $add_subledger->sno,
                      'credit'            => $allData['initial_fees_pay_input'],
                      'invoice_id'        =>    $invoice_id_cus,
                      'receipt_id'            => $allData['receipt_id'],
                      'training_id'            => $training->sno,
                      'attachments' => !empty($file_list) ? json_encode($file_list) : NULL,
                      'debit'             => null,
                      'tax'               => $allData['initial_fees_pay_input'] * 0.18, // 18% tax calculation
                      'total_amount'      => $totalAmount ?? 0,
                      'created_by'        => $user_id,
                      'updated_by'        => $user_id,
                  ]
              );

              if(!empty($ref_customer_id)){
 
                $r_customer = DB::table('za_customer')->where('sno', $ref_customer_id)->first();
 
                $existingRewards = isset($r_customer->rewards) && !empty($r_customer->rewards) ? json_decode($r_customer->rewards ?? '[]', true) : [];
 
                if (!is_array($existingRewards)) {
                  $existingRewards = [];
                }
 
                if (!empty($existingRewards)) {
 
                  $lastKey = array_key_last($existingRewards);
 
                  $existingRewards[$lastKey]['crown'] = ($existingRewards[$lastKey]['crown'] ?? 0) + 1;
 
                } else {
 
                  $existingRewards[] = [
                    'date' => now()->toDateString(),
                    'coin'    => 0,
                    'diamond' => 0,
                    'crown'   => 1
                  ];
                }
 
                DB::table('za_customer')->where('sno', $customer->sno)->update([
                  'ref_customer_id' => $ref_customer_id
                ]);
               
                DB::table('za_customer')->where('sno', $ref_customer_id)->update([
                  'rewards' => json_encode($existingRewards)
                ]);
              }
    
    
              \Log::info('Before forgetting session:', session()->all());
              for ($i = 1; $i <= 5; $i++) {
                  session()->forget('customer_form_step_' . $i);
              }
              // Clear other customer-related session data
              session()->forget([
                  'course_type_hidden_id',
                  'course_batch_hidden_id',
                  'batch_check_hidden_id'
              ]);
              $lead_id            = $request->lead_id;
              $upd_lead           =  LeadModel::where('sno', $lead_id)->first();
              $upd_lead->lead_status_id          = 5;
              $upd_lead->status   = 4;
              // dd($upd_lead);
              $upd_lead->update();
              
              
               //****************** */ create the usage history ManageCouponHistoryModel
               $couponid = ManageCouponModel::where('coupon_code', $allData['new_coupon_code'])->first();

              if ($couponid) {
                  ManageCouponHistoryModel::updateOrCreate(
                      [
                          'coupon_id' => $couponid->sno ?? null, // Unique identifier
                          'used_by' => $customer->sno ?? null, // The user who used the coupon
                      ],
                      [
                          'modal_id' => 2, // Reference to the customer or related model
                          'amount' => $allData['discounted_amount_hidden'] ?? 0, // Discount amount
                          'used_date' => now(), // Current timestamp
                          'created_by' => $user_id,
                          'updated_by' => $user_id,
                      ]
                  );
                  
                    ManageCouponModel::updateOrCreate(
                    ['sno' => $couponid->sno], // Assuming 'sno' is the unique identifier for the coupon
                    [
                        'used_count' => \DB::raw('COALESCE(used_count, 0) + 1') // Increment used_count by 1, starting from 0 if null
                    ]
                );
              }

              //****************** */ Update Staff Sales Person Points
            //   Send Communication 
              $branch_data = BranchModel::where('sno', $branch_id)->first();
            $branch_name = " ";
            if ($branch_data->branch_type == 1) {
                $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
                $branch_name = $branch_data->franchise_name;
            }
            //   SMS
           $customer_mobiles = !empty($customer->cus_mobile)
          ? $customer->cus_mobile
          : (isset($allData['cus_mobile']) ? $allData['cus_mobile'] : '');
 
        $customer_mails = !empty($customer->cus_email_id)
          ? $customer->cus_email_id
          : (isset($allData['cus_email_id']) ? $allData['cus_email_id'] : '');
          
            $customer_names = isset($allData['cus_name'])?$allData['cus_name']: 'Mr/Mrs';
            $cre_mobile = isset($branch_data->cre_mobile) ?$branch_data->cre_mobile:'9677781155';
            $tempdate      = $allData['doj'] ?? null;
            if ($training && $customer_mobiles) {
                    $branch_data     = BranchModel::where('sno', $branch_id)->first();
                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '004_WelcomeOnBoard')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $customer_mobiles;
    
                    // Replace placeholders with actual values
                    $replacement_values = [$customer_names, $cre_mobile];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );
    
                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];
    
                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);
    
                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
    
                    if ($batch_id) {
                        $result_sms_bat  = SmsTemplateModel::where('status', 0)->where('template_name', '007_BatchAssign')->first();
                        $authkey         = $result_sms_bat ? $result_sms_bat->authkey : '';
                        $sender_id       = $result_sms_bat ? $result_sms_bat->sender_id : '';
                        $template_id     = $result_sms_bat ? $result_sms_bat->template_id : '';
                        $country_code    = $result_sms_bat ? $result_sms_bat->country_code : '';
                        $message_content = $result_sms_bat ? $result_sms_bat->sms_template_messagecontent : '';
    
                        $formattedDate = Carbon::parse($batch_id->start_date)->format('d M Y'); // e.g., 11 Jan 2025
    
                        // Replace placeholders with actual values
                        $replacement_values = [$customer_names, $formattedDate, $cre_mobile];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
    
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
    
                    }
    
                    if ($transaction_id) {
                        $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '005_PaymentSuccess')->first();
                        $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
                        $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
                        $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
                        $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
                        $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
    
                        // Replace placeholders with actual values
                        $replacement_values = [$customer_names, $totalAmount, $transaction_id];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                    
                }
                // Email
            if ($training && $customer_mails) {
                    $email_template_id = 10; // thank you template
                    $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                    $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();
                    $cre               = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                    $content           = $emailTemplate->email_subject;
                    $content           = str_replace('#name', $customer_names, $content);
                    $content           = str_replace('#Course', $coursename->course_name, $content);
                    $content           = str_replace('#CREname', $cre->nick_name??'Elsa', $content);
                    $branchNo          = $branch_data->mobile??'9677781155';
                    $branchemail       = $branch_data->mail??'info@elysiumacademy.org';
                    $fbLink            = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                    $instaLink         = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                    $content           = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                    $content           = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
    
                    $mailData = [
                        'url'         => 'Eapl.com',
                        'subject'     => $emailTemplate->email_name,
                        'content'     => $content,
                        'branchNo'    => $branchNo,
                        'branchemail' => $branchemail, // Use the message content from the request
                        'fbLink'      => $fbLink,      // Use the message content from the request
                        'instaLink'   => $instaLink,   // Use the message content from the request
                        'salesMobile' => $branch_data->sales_mobile??'9677781155',
                        
                    ];
    
                    $to_address   = $customer_mails;
                    $from_address = 'elysiumacademy@elysium.community';
                    $from_name    = 'Elysium Academy®';
                    Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    
                    if ($batch_id) {
                        $email_template_id  = 12; // thank you template
                        $emailTemplate      = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                        $coursename         = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();
                        $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch_id->sno)->first();
                        $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
                        $dynamicSubject     = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
                        $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
                        $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
                        $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');
    
                        $class_time  = $start_time . ' to ' . $end_time;
                        $content     = $emailTemplate->email_subject;
                        $content     = str_replace('#name', $customer_names, $content);
                        $content     = str_replace('#Course', $coursename->course_name, $content);
                        $content     = str_replace('#start_date', $format_startDate, $content);
                        $content     = str_replace('#end_date', $format_endDate, $content);
                        $content     = str_replace('#class_time', $class_time, $content);
                        $content     = str_replace('#staff_nick_name', $staff->nick_name??'Elsa', $content);
                        $branchNo    = $branch_data->mobile??'9677781155';
                        $branchemail = $branch_data->mail??'info@elysiumacademy.org';
                        $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                        $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
    
                        $mailData = [
                            'url'         => 'Eapl.com',
                            'subject'     => $dynamicSubject,
                            'content'     => $content,
                            'branchNo'    => $branchNo,
                            'branchemail' => $branchemail, // Use the message content from the request
                            'fbLink'      => $fbLink,      // Use the message content from the request
                            'instaLink'   => $instaLink,   // Use the message content from the request
                            'salesMobile' => $branch_data->sales_mobile,
                        ];
    
                        $to_address   = $customer_mails;
                        $from_address = 'elysiumacademy@elysium.community';
                        $from_name    = 'Elysium Academy®';
                        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    
                    }
    
                    if ($transaction_id) {
                        $email_template_id = 18; // thank you template
                        $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                        $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();
    
                        $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
    
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $paymentDate        = $tempdate;
                        $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                        $paymentAmount      = $paymentAmt . ". Rs";
                        $content            = $emailTemplate->email_subject;
                        $content            = str_replace('#name', $customer_names, $content);
                        $content            = str_replace('#course', $coursename->course_name??'Course', $content);
                        $content            = str_replace('#transactionId', $transaction_id, $content);
                        $content            = str_replace('#amount', $paymentAmount, $content);
                        $content            = str_replace('#transactionDate', $paymentDate, $content);
                        $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
                        $branchNo           = $branch_data->mobile??'9677781155';
                        $branchemail        = $branch_data->mail??'info@elysiumacademy.org';
                        $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                        $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
    
                        $mailData = [
                            'url'         => 'Eapl.com',
                            'subject'     => $dynamicSubject,
                            'content'     => $content,
                            'branchNo'    => $branchNo,
                            'branchemail' => $branchemail, // Use the message content from the request
                            'fbLink'      => $fbLink,      // Use the message content from the request
                            'instaLink'   => $instaLink,   // Use the message content from the request
                            'salesMobile' => $branch_data->sales_mobile??'9677781155',
                        ];
    
                        $to_address   = $customer_mails;
                        $from_address = 'elysiumacademy@elysium.community';
                        $from_name    = 'Elysium Academy®';
                        
                        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    
                    }
    
                }
                // Whatsapp messages
            if ($training && $customer_mobiles) {
    
                    $templateName = "elysium_academy_cre_welcome2";
                    $templateHeaderMediaId = '2124149255068525'; 
                    $coursename   = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();
                    $cre          = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                    $hasHeader    = false; // Example flag: set based on template
                    $hasBody      = false; // Example flag: set based on template
                    $components   = [];
                    $couponCode   = " ";
                    date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                    $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                               // $currentHour = date('H'); // Get current hour in 24-hour format
                    if ($currentHour >= 5 && $currentHour < 12) {
                        $greeting = 'Good Morning';
                    } elseif ($currentHour >= 12 && $currentHour < 18) {
                        $greeting = 'Good Afternoon';
                    } else {
                        $greeting = 'Good Evening';
                    }
    
                    if ($templateName == 'elysium_academy_cre_welcome2') {
                        // $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/WelcomeMessageCre.jpg';
                        $headerImage = asset('assets/WelcomeMessageCre.jpg');
                        $bodyText    = [
                            [
                                'type'           => 'text',
                                'text'           => $greeting,
                                'parameter_name' => 'greet_msg',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $customer_names,
                                'parameter_name' => 'customer_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $coursename->course_name??'Course',
                                'parameter_name' => 'course_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $cre->nick_name??'Elsa',
                                'parameter_name' => 'cre_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_name??'Elysium Academy',
                                'parameter_name' => 'branch_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->cre_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no',
                            ],
    
                        ];
                        $hasHeader = true;
                        $hasBody   = true;
                    }
    
                    // Add Header if required
                    if ($hasHeader) {
                        $components[] = [
                            'type'       => 'header',
                            'parameters' => [
                                [
                                    'type'  => 'image',
                                    // 'image' => [
                                    //   'id' => $templateHeaderMediaId
                                    // ],
                                    'image' => [
                                        'link' => $headerImage, // Dynamically set header image
                                    ],
                                ],
                            ],
                        ];
                    }
                    // Add Body if required
                    if ($hasBody) {
                        $components[] = [
                            'type'       => 'body',
                            'parameters' => $bodyText,
                        ];
                    }
    
                    $dynamicParameters         = $templateParameters[$templateName] ?? [];
                    $WhatsAppBusinessAccountId = $this->businessId;
                    $accessToken               = $this->accessToken;
                    $fromPhoneNumberId         = $this->phoneNumberId;
    
                    $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                    $to           = $customer_mobiles;
                    $languageCode = 'en';
    
                    if (strpos($to, '+91') !== 0) {
                        $to = '+91' . $to;
                    }
    
                    $message = 'test~message';
                    $payload = [
                        'messaging_product' => 'whatsapp',
                        'to'                => $to,
                        'type'              => 'template',
                        'template'          => [
                            'name'       => $templateName,
                            'language'   => [
                                'code' => $languageCode,
                            ],
                            'components' => $components,
                        ],
                    ];
    
                    $responsewel = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                    
                    if ($responsewel['status'] == 200) {
                            // 1. Customer Welcome 
                            $log_branch_id = $branch_id;
                            $unique_id = $customer->sno;
                            $source ='Customer';
                            $log_phone_no =$to;
                            $log_template_name =$templateName;

                            $save_log = $this->WhatsappSendLog(
                                $responsewel,
                                $payload,
                                $log_phone_no,
                                $log_template_name,
                                $user_id,
                                $log_branch_id,
                                $unique_id,
                                $source
                            );
                    }
                    
    
                    if ($batch_id) {
    
                        $components_batch = [];
    
                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                   // $currentHour = date('H'); // Get current hour in 24-hour format
                        if ($currentHour >= 5 && $currentHour < 12) {
                            $greeting = 'Good Morning';
                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
                        
                        $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch_id->sno)->first();
                        $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
                        $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
                        $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
                        $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');
                        $class_time         = $start_time . ' to ' . $end_time;
                        $templateName       = 'elysium_academy_batch_allot2';
    
                        $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/BatchAllocation.jpg';
                        $bodyText    = [
                            [
                                'type'           => 'text',
                                'text'           => $greeting,
                                'parameter_name' => 'greet_msg',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $customer_names,
                                'parameter_name' => 'customer_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $coursename->course_name??'Course',
                                'parameter_name' => 'course_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $format_startDate,
                                'parameter_name' => 'start_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $format_endDate,
                                'parameter_name' => 'end_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $class_time,
                                'parameter_name' => 'class_time',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $staff->nick_name??'Elsa',
                                'parameter_name' => 'staff_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $cre->nick_name??'Elsa',
                                'parameter_name' => 'cre_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->cre_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_name??'Elysium Academy',
                                'parameter_name' => 'branch_name',
                            ],
                        ];
                        $components_batch[] = [
                            'type'       => 'header',
                            'parameters' => [
                                [
                                    'type'  => 'image',
                                    'image' => [
                                        'link' => $headerImage, // Dynamically set header image
                                    ],
                                ],
                            ],
                        ];
                        $components_batch[] = [
                            'type'       => 'body',
                            'parameters' => $bodyText,
                        ];
    
                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                        $WhatsAppBusinessAccountId = $this->businessId;
                        $accessToken               = $this->accessToken;
                        $fromPhoneNumberId         = $this->phoneNumberId;
    
                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                        $to           = $customer_mobiles;
                        $languageCode = 'en';
    
                        if (strpos($to, '+91') !== 0) {
                            $to = '+91' . $to;
                        }
    
                        $message = 'test~message';
    
                        $payload = [
                            'messaging_product' => 'whatsapp',
                            'to'                => $to,
                            'type'              => 'template',
                            'template'          => [
                                'name'       => $templateName,
                                'language'   => [
                                    'code' => $languageCode,
                                ],
                                'components' => $components_batch,
                            ],
                        ];
    
                        $responseBatch= $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                        
                        if ($responseBatch['status'] == 200) {
                                // 1. batch Allocate 
                                $log_branch_id = $branch_id;
                                $unique_id = $customer->sno;
                                $source ='Customer';
                                $log_phone_no =$to;
                                $log_template_name =$templateName;

                                $save_log = $this->WhatsappSendLog(
                                    $responseBatch,
                                    $payload,
                                    $log_phone_no,
                                    $log_template_name,
                                    $user_id,
                                    $log_branch_id,
                                    $unique_id,
                                    $source
                                );
                        }
                        
    
                    }
                    if ($transaction_id) {
                        // Example flag: set based on template
                        $components_trans = [];
                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                   // $currentHour = date('H'); // Get current hour in 24-hour format
                        if ($currentHour >= 5 && $currentHour < 12) {
                            $greeting = 'Good Morning';
                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
                        $helper = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        // $paymentDate        = date($common_date_format);
                        $paymentDate        = $tempdate;
                        $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                        $paymentAmount      = $paymentAmt . ". Rs";
    
                        $templateName = 'elysium_academy_pay_transaction2';
                         $templateHeaderMediaId = '2177298459677656';  
                        // $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
                        $headerImage = asset('assets/Payment_success.jpg');
                        $bodyText     = [
                            [
                                'type'           => 'text',
                                'text'           => $greeting,
                                'parameter_name' => 'greet_msg',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $customer_names,
                                'parameter_name' => 'customer_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $coursename->course_name??'Course',
                                'parameter_name' => 'course_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $transaction_id,
                                'parameter_name' => 'transaction_id',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $paymentAmount,
                                'parameter_name' => 'amount',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $paymentDate,
                                'parameter_name' => 'pay_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->cre_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->mail??'info@elysiumacademy.org',
                                'parameter_name' => 'contact_email',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_name??'Elysium Academy',
                                'parameter_name' => 'branch_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->sales_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no2',
                            ],
                            
                        ];
                        $components_trans[] = [
                            'type'       => 'header',
                            'parameters' => [
                                [
                                    'type'  => 'image',
                                    // 'image' => [
                                    //   'id' => $templateHeaderMediaId
                                    // ],
                                    'image' => [
                                        'link' => $headerImage, // Dynamically set header image
                                    ],
                                ],
                            ],
                        ];
    
                        $components_trans[] = [
                            'type'       => 'body',
                            'parameters' => $bodyText,
                        ];
                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                        $WhatsAppBusinessAccountId = $this->businessId;
                        $accessToken               = $this->accessToken;
                        $fromPhoneNumberId         = $this->phoneNumberId;
    
                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                        $to           = $customer_mobiles;
                        $languageCode = 'en';
    
                        if (strpos($to, '+91') !== 0) {
                            $to = '+91' . $to;
                        }
    
                        $message = 'test~message';
    
                        $payload = [
                            'messaging_product' => 'whatsapp',
                            'to'                => $to,
                            'type'              => 'template',
                            'template'          => [
                                'name'       => $templateName,
                                'language'   => [
                                    'code' => $languageCode,
                                ],
                                'components' => $components_trans,
                            ],
                        ];
    
                        $responseTransc = $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                        
                         if ($responseTransc['status'] == 200) {
                                // 3. Payment transcation 
                                $log_branch_id = $branch_id;
                                $unique_id = $customer->sno;
                                $source ='Customer';
                                $log_phone_no =$to;
                                $log_template_name =$templateName;

                                $save_log = $this->WhatsappSendLog(
                                    $responseTransc,
                                    $payload,
                                    $log_phone_no,
                                    $log_template_name,
                                    $user_id,
                                    $log_branch_id,
                                    $unique_id,
                                    $source
                                );
                        }


    
                    }
                }
                
                // Define point category:
                // 1 Lead Entry, 2 Check List, 3 Follow UP, 4 Replay Follow UP, 5 Customer Convert
                $helper = new \App\Helpers\Helpers();
                $pointsData = $helper->get_points_by_id(5);
                $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
                $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
                // Save new points for the staff
                $newPoints = new StaffpointsModel();
                $newPoints->branch_id = $branch_id;
                $newPoints->staff_id = $user_id;
                $newPoints->points_by = $lead_id;
                $newPoints->points_id = 5;
                $newPoints->points = $point;
                $newPoints->reason = $reason;
                $newPoints->save();
    
                // Update staff's available points
                $staff_points = StaffModel::where('sno', $user_id)->first();
                if ($staff_points) {
                  $staff_points->avaiable_points += $point; // Increment the available points
                  $staff_points->save();
                }
                //****************** */ Update Staff Sales Person Points
           
    
                // Define customer and course details
                // $coursename = ManageCoursesModel::where('status', 0)->where('sno', $courseArray)->first();
                // $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
                // if($training->batch_id > 0){
                //     $batch_details = BatchModel::where('sno', $training->batch_id)->orderBy('sno', 'desc')->first();
                //     $slot = SlotModel::where('sno', $batch_details->slot_id)->orderBy('sno', 'desc')->first();
                //         $staff = StaffModel::where('sno', $batch_details->staff_id)->orderBy('sno', 'desc')->first();
        
                //         // Format start and end date
                //         $formattedStartDate = \Carbon\Carbon::parse($batch_details->start_date)->format('d M Y');
                //         $formattedEndDate = \Carbon\Carbon::parse($batch_details->end_date)->format('d M Y');
                // }
    
    
    
                // // Gender condition
                // $genderPrefix = 'Mr/Ms'; // Default value
                // if ($customerdetails->cus_gender == 1) {
                //     $genderPrefix = 'Mr';
                // } elseif ($customerdetails->cus_gender == 2) {
                //     $genderPrefix = 'Ms';
                // }
                // $welcomeEmailTemplateId =10;
                // $welcomeEmailTemplateId =1;
            
          }

            DB::commit();
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Customer saved successfully!'
            ]);
    
            // Redirect after saving the customer
          return redirect('/manage_customer');
      } catch (\Exception $e) {
        DB::rollBack();
        return response()->json(['message' => 'Error processing payment', 'error' => $e->getMessage()], 500);
      }
      
  }
    
  public function customer_add_course($id,  Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $id = $helper->encrypt_decrypt($id, 'decrypt');

    // return $id;
    // return $request;


    // Check if decryption failed
    if ($id === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }


    // Split the decrypted value
    $exp = explode('~', $id);
    $id = str_replace(' ', '', $exp[0] ?? '');

    $step = str_replace(' ', '', $exp[1] ?? '');
    // return $id;
    // return $step;

    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();

    $course_type_hidden_id = session('course_type_hidden_id');
    $course_batch_hidden_id = session('course_batch_hidden_id');
    $allStepsData = [];

    // Retrieve data for all steps from the session
    for ($i = 3; $i <= 5; $i++) {
      $allStepsData['step_' . $i] = session('customer_form_step_' . $i, []);
    }
    $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();

    // Fetch customer details
    $customer = CustomerModel::select('za_customer.*', 'za_lead.sno as lead_id', 'za_course.course_name','za_course_type.ratio', 'za_lead.sno as lead_id', 'za_course_type.course_type_name')
      ->leftjoin('za_course', 'za_customer.enroll_course_id', '=', 'za_course.sno')
      ->leftjoin('za_course_type', 'za_customer.enroll_course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->where('za_customer.status', '!=', 2)
      ->where('za_customer.sno', $id)
      ->orderBy('sno', 'desc')
      ->first();
    // return $customer;

   
    // dd($customer);
    $course_data = ManageCoursesModel::where('sno', $customer->enroll_course_id ?? '')->first();
    // dd($course_data);
    $lead = LeadModel::select('za_lead.*')
      // ->join('za_course', 'za_lead.course_id', '=', 'za_course.sno')
      ->where('za_lead.sno', $id)
      ->first();
    $lead_tag = LeadModel::select('za_lead.*')
      // ->join('za_course', 'za_lead.course_id', '=', 'za_course.sno')
      ->where('za_lead.sno', $customer->lead_id)
      ->first();
    // dd($lead);
    // // Decode course_id if it's JSON
    if ($lead && !empty($lead->course_id)) {
      $courseIds = json_decode($lead->course_id);

      // Check if courseIds is a valid array after decoding
      if (is_array($courseIds)) {
        // Fetch course names based on IDs
        $courses = DB::table('za_course')
          ->whereIn('sno', $courseIds)
          ->pluck('course_name');

        // Assign course names to the lead object
        $lead->course_names = $courses;
      } else {
        $lead->course_names = []; // Empty array if course_id is not an array
      }
    }
    $batch_check_hidden_id = session('batch_check_hidden_id', '');
    $cus_name = session('cus_name');
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings->date_format ?? 'd-M-y';
    // return $customer;
    // $customer->formatted_lead_dob = $customer->lead_dob ? Carbon::parse($customer->lead_dob)->format($dateFormat) : null;
    return view('content.customer.customer_add_course', compact('customer', 'branch_data', 'step', 'allStepsData', 'course_type_hidden_id', 'course_batch_hidden_id', 'batch_check_hidden_id', 'course_data', 'cus_name', 'lead', 'course_list', 'lead_tag'));
  }
  
  public function customerCourseSave(Request $request)
  {
        $all_options = $request->input('all_options') ?? 0;
        $lead_tag_course_id = $request->input('course_batch_id_chk');
        $step = $request->input('step');
        $tableData = json_decode($request->input('table_data'), true);
        $course_batch_hidden_id = $request->input('course_batch_hidden_id');
        $customer_id_sno = $request->input('customer_hidden_id');


      session(['customer_form_step_' . $step => $request->except(['_token', 'step'])]);

       if ($step < 5) {
      $allData = [];
      for ($i = 1; $i <= 5; $i++) {
        $allData = array_merge($allData, session('customer_form_step_' . $i, []));
      }
      // return $allData;
      $customer = CustomerModel::updateOrCreate(
        ['lead_id' => $allData['lead_id']],
        [
            'enroll_course_id' => $all_options == 0 ? $lead_tag_course_id : $allData['course_new_id'] ?? null,
            'enroll_course_type_id' => $all_options == 0 ? $request->input('course_type_batch_id_chk') ?? 0 : $allData['course_type_batch_id'] ?? null,
            'enroll_course_mode_id' => $all_options == 0 ? $request->input('course_mode_id_chk') ?? 0 : $allData['course_mode_id'] ?? 0,
        ]
      );
      return redirect()->route('customer-add-course', ['id' => $request->customer_hidden_id, 'step' => $step + 1]);
    }

        $allData = [];
        for ($i = 3; $i <= 5; $i++) {
          $stepData = session('customer_form_step_' . $i, []);
          if (!is_array($stepData)) {
            $stepData = (array)$stepData;
          }
          $allData = array_merge($allData, $stepData);
        }
        // return $allData;
        $validator = Validator::make($allData, [
          'lead_id' => 'required|max:255'
        ]);

        if ($validator->fails()) {
          return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
          ], 200);
        } else {
            try {
              DB::beginTransaction();
              
               $staff_dropdown_id  = $request->referral_staff_id;

              // Fetch the existing customer record based on lead_id
              $customer = CustomerModel::where('lead_id', $allData['lead_id'])->first();
               $comunication_course_id = $customer->enroll_course_id;
              $branch_id = $request->user()->branch_id;
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        
              $branch_code = $branch_check->city_short_code;
              $user_id = $request->user()->user_id;
    
                  $year = date("Y");
                  
              // Generate payment ID
              $pay_check = PaymentModel::where('payment_id', 'LIKE', $year . '/' . $branch_code . '/PAY%')
                    ->orderByRaw("CAST(SUBSTRING_INDEX(payment_id, 'PAY', -1) AS UNSIGNED) DESC")
                    ->first();
    
              
    
                if (!$pay_check) {
                  $payment_auto_id = $year . '/' . $branch_code . '/' . "PAY0001";
                } else {
                    $data = $pay_check->payment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[2]); // Extract only numbers from "PAYxxxx"
                    $next_number = (int)$result + 1;
                    $request_pay = sprintf("PAY%04d", $next_number); // Format as PAYxxxx
                    $payment_auto_id = $year . '/' . $branch_code . '/' . $request_pay;
                }
              
              $invoice_chk_cus = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
                  $year = date("Y");
              if (!$invoice_chk_cus) {
                  $invoice_id_cus = 'EA/' . $year . '/INV2005';
              } else {
                  $data = $invoice_chk_cus->invoice_id;
                  $slice = explode("/", $data);
                  if (count($slice) >= 3) {
                      $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
                      $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
                  } else {
                      $next_inv_number = 2005;
                  }
                  $invoice_id_cus = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
              }
              // Loop through each row in tableData
              foreach ($allData['tableData'] as $row) {
            // Ensure $row is valid and contains the necessary data
            if (is_array($row)) {
              // Handle "N/A" or null for initialPayDate
              if ($row['column1'] === 'N/A' || $row['column1'] === null) {
                $initialPayDateFormatted = now()->format('Y-m-d'); // Default to today's date
              } else {
                $initialPayDate = DateTime::createFromFormat('d-m-Y', $row['column1']);
                if ($initialPayDate === false) {
                  \Log::error('Invalid initialPayDate format:', ['column1' => $row['column1']]);
                  continue; // Skip this row if the date format is invalid
                }
                $initialPayDateFormatted = $initialPayDate->format('Y-m-d');
              }
    
              // Handle nextPayDate (allowing null)
              if ($row['column2'] !== null) {
                $nextPayDate = DateTime::createFromFormat('d-m-Y', $row['column2']);
                if ($nextPayDate === false) {
                  \Log::error('Invalid nextPayDate format:', ['column2' => $row['column2']]);
                  continue; // Skip this row if the date format is invalid
                }
                $nextPayDateFormatted = $nextPayDate->format('Y-m-d');
              } else {
                $nextPayDateFormatted = null; // Set to null if there's no next pay date
              }
    
              // Determine payment status
              $status = ($row['column6'] === 'Paid') ? 1 : 0;
              $invoices = ($row['column6'] === 'Paid') ? $invoice_id_cus: null;
    
              // Update or create payment record
              PaymentModel::updateOrCreate(
                [
                  'payment_id'     => $payment_auto_id,
                  'branch_id'      => $branch_id,
                  'customer_id'    => $customer->sno,
                  'course_id'      => $customer->enroll_course_id,
                  'initialPayDate' => $initialPayDateFormatted,
                  'nextPayDate'    => $nextPayDateFormatted,
                  'amount'         => $row['amount1'],
                  'paidAmount'     => $row['amount4'] ?? 0, // Default to 0 if null
                  'gst_amount'     => $row['amount5'] == 0 ? $row['amount1'] * 0.18 : $row['amount5'],
                  'balanceFee'     => $row['amount7'] ?? 0, // Default to 0 if null
                  'total_amount'   => $allData['final_course_fees'],
                  'payment_mode_label'   => $allData['payment_mode_display_hidden'],
                   'transaction'   => $allData['transaction_id_input'],
                  'status'         => $status,
                  'invoice_id'     => $invoices,
                  'created_by'     => $user_id,
                  'updated_by'     => $user_id,
                ]
              );
            }
          }


              $batch_id = BatchModel::where('sno', $customer->enroll_batch_id)->first();
              $cos_check = TrainingModel::orderBy('sno', 'desc')->first();
    
              // Generate training_id based on existing records or start fresh
              if (!$cos_check) {
                $year = date("Y");
                $training_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                $data = $cos_check->training_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cos + 1;
                $request_cos = sprintf("TRA%04d", $next_number_cos);
                $year = date("Y");
                $training_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
    
             // Calculate fees and amounts
              $finalCourseFees = $allData['final_course_fees'] ?? 0; // Default to 0 if not set
              $paidAmount = $allData['initial_fees_pay_input'] ?? 0; // Default to 0 if not set
              $discounted_check = isset($allData['discounted_amount_hidden']) && $allData['discounted_amount_hidden'] > 0 ? 1 : 0;
              $paidGst = $paidAmount * 0.18; // Calculate paid GST
              $totalAmount = $paidAmount + $paidGst; // Total amount
              $balanceAmount = $allData['balance_course_fee']; // Default to 0 if not set
              $balanceGst = $balanceAmount * 0.18; // Calculate balance GST
    
                $courseArrayToNormals = $customer->course_id;
                $courseArray = json_decode($courseArrayToNormals, true); // Decode as an array
               
                // $course = ManageCoursesModel::where('sno', $courseArray)->first(); // Fetch course details
                $course = ManageCoursesModel::where('sno', $customer->enroll_course_id)->first();
                $course_type = CourseTypeModel::where('sno', $customer->enroll_course_type_id)->first();
                $training = null;
                
                if ($course && $course->tesbo_cousre_id &&  $course_type->combined_course == 1) {
                    
                    // Decode the tesbo_cousre_id array
                    $tesbo_course_ids = json_decode($course->tesbo_cousre_id, true);
    
                    // Iterate over each tesbo_cousre_id
                    foreach ($tesbo_course_ids as $tesbo_course_id) {
                        // Update or create the TrainingModel record for each tesbo_cousre_id
                     $training =   TrainingModel::updateOrCreate(
                            [
                                'training_id'     => $training_id,
                                'branch_id'       => $branch_check->sno,
                                'customer_id'     => $customer->sno,
                                'course_id'       => $tesbo_course_id, // Save each tesbo_course_id
                                'batch_id'        => $batch_id->sno ?? 0,
                                'slot_id'         => $batch_id->slot_id ?? null,
                                'staff_id'        => $batch_id->staff_id ?? null,
                                'start_date'      => $batch_id->start_date ?? null,
                                'end_date'        => $batch_id->end_date ?? null,
                                'overall_fees'    => $finalCourseFees,
                                'gst_amount'      => $finalCourseFees * 0.18, // Calculate GST for overall fees
                                'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
                                'discount_check'  => $discounted_check,
                                'paid_amount'     => $paidAmount,
                                'paid_gst'        => $paidGst,
                                'total_amount'    => $totalAmount,
                                'balance_amount'  => $balanceAmount,
                                'balance_gst'     => $balanceGst,
                                'tesbo_check'     => $customer->enroll_course_type_id ?? 0,
                                'course_mode_id'  => $customer->enroll_course_mode_id ?? 0,
                                'online_amount'   => $customer->online_fee ?? 0,
                                'payment_id'      => $payment_auto_id ?? null,
                                'post_sale_check'      => 1,
                                'created_by'      => $user_id,
                                'updated_by'      => $user_id,
                            ]
                        );
                    }
                } else {
                       
                    // If no tesbo_cousre_id, update or create a single record for the normal course
                    $training = TrainingModel::updateOrCreate(
                        [
                            'training_id'     => $training_id,
                            'branch_id'       => $branch_check->sno,
                            'customer_id'     => $customer->sno,
                            'course_id'       => $customer->enroll_course_id, // Use the normal course_id
                            'batch_id'        => $batch_id->sno ?? 0,
                            'slot_id'         => $batch_id->slot_id ?? null,
                            'staff_id'        => $batch_id->staff_id ?? null,
                            'start_date'      => $batch_id->start_date ?? null,
                            'end_date'        => $batch_id->end_date ?? null,
                            'overall_fees'    => $finalCourseFees,
                            'gst_amount'      => $finalCourseFees * 0.18, // Calculate GST for overall fees
                            'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
                             'discount_check'  => $discounted_check,
                            'paid_amount'     => $paidAmount,
                            'paid_gst'        => $paidGst,
                            'total_amount'    => $totalAmount,
                            'balance_amount'  => $balanceAmount,
                            'balance_gst'     => $balanceGst,
                            'tesbo_check'     => 0,
                            'course_mode_id'  => $customer->enroll_course_mode_id ?? 0,
                            'online_amount'   => $customer->online_fee ?? 0,
                            'payment_id'      => $payment_auto_id ?? null,
                            'post_sale_check'      => 1,
                            'created_by'      => $user_id,
                            'updated_by'      => $user_id,
                        ]
                    );
                }
    
    
    
             $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();
    
    
              if (!$ledger_check) {
                $year = date("Y");
                $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                $data = $ledger_check->subledger_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cos + 1;
                $request_cos = sprintf("SUB%04d", $next_number_cos);
                $year = date("Y");
                $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
    
              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id      = 1;
              $add_subledger->subledger_id   = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id      = $branch_check->sno;
               $add_subledger->traning_sno    = $training->sno;
              $add_subledger->created_by     = $user_id;
              $add_subledger->updated_by     = $user_id;
        
              $add_subledger->save();
              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                $year = date("Y");
                $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                $data = $tr_check->transaction_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cos + 1;
                $request_tr = sprintf("TRA%04d", $next_number_cos);
                $year = date("Y");
                $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
            
          
              TransactionModel::updateOrCreate(
                  [
                      'branch_id'         => $branch_check->sno,
                      'transaction_id'    => $transaction_id,
                      'transaction_type'  => 'Credit',
                      'transaction_name'  => 'Customer',
                      'trans_source_id'   => $customer->customer_id,
                      'ledger_id'         => 1,
                      'subledger_id'      => $add_subledger->sno,
                      'credit'            => $allData['initial_fees_pay_input'],
                      'invoice_id'        =>    $invoice_id_cus,
                      'receipt_id'            => $allData['receipt_id'],
                      'training_id'            => $training->sno,
                      'debit'             => null,
                      'tax'               => $allData['initial_fees_pay_input'] * 0.18, // 18% tax calculation
                      'total_amount'      => $totalAmount ?? 0,
                      'created_by'        => $user_id,
                      'updated_by'        => $user_id,
                  ]
              );
    
           
              if ($customer) {
            // Decode existing course_id and batch_id from JSON
            $existingCourseIds = json_decode($customer->course_id, true) ?? [];
            $existingBatchIds = json_decode($customer->batch_id, true) ?? [];
    
            // Ensure existing values are arrays
            $existingCourseIds = is_array($existingCourseIds) ? $existingCourseIds : (array) $existingCourseIds;
            $existingBatchIds = is_array($existingBatchIds) ? $existingBatchIds : (array) $existingBatchIds;
    
            // Ensure newCourseIds and newBatchIds are arrays
            $newCourseIds = is_array($customer->enroll_course_id) ? $customer->enroll_course_id : [$customer->enroll_course_id];
            $newBatchIds = is_array($customer->enroll_batch_id) ? $customer->enroll_batch_id : [$customer->enroll_batch_id];
    
            // Remove null values from newBatchIds
            $newBatchIds = array_filter($newBatchIds, function ($id) {
              return !is_null($id);
            });
    
            // Set to ["0"] if empty after filtering
            if (empty($newBatchIds)) {
              $newBatchIds = ["0"];
            }
    
            // Merge existing values with new values and remove duplicates
            $mergedCourseIds = array_unique(array_merge($existingCourseIds, $newCourseIds));
            $mergedBatchIds = array_unique(array_merge($existingBatchIds, $newBatchIds));
    
            // Convert arrays back to JSON strings, ensuring IDs are strings
            $courseIdJson = json_encode(array_map('strval', $mergedCourseIds));
            $batchIdJson  = json_encode(array_map('strval', $mergedBatchIds));
    
            // Update the customer record with the new course_id and batch_id
            $customer->update([
            //   'course_id'              => $courseIdJson,
              'batch_id'               => $batchIdJson,
               'post_sale_check'               => 1,
               'status'               => 0,
              'enroll_course_id'       => 0,
              'enroll_batch_id'        => 0,
            ]);
            
             //****************** */ create the usage history ManageCouponHistoryModel
               $couponid = ManageCouponModel::where('coupon_code', $allData['new_coupon_code'])->first();

              if ($couponid) {
                  ManageCouponHistoryModel::updateOrCreate(
                      [
                          'coupon_id' => $couponid->sno ?? null, // Unique identifier
                          'used_by' => $customer->sno ?? null, // The user who used the coupon
                      ],
                      [
                          'modal_id' => 2, // Reference to the customer or related model
                          'amount' => $allData['discounted_amount_hidden'] ?? 0, // Discount amount
                          'used_date' => now(), // Current timestamp
                          'created_by' => $user_id,
                          'updated_by' => $user_id,
                      ]
                  );
                  
                    ManageCouponModel::updateOrCreate(
                    ['sno' => $couponid->sno], // Assuming 'sno' is the unique identifier for the coupon
                    [
                        'used_count' => \DB::raw('COALESCE(used_count, 0) + 1') // Increment used_count by 1, starting from 0 if null
                    ]
                );
              }
          }
        
               //   Send Communication
                $branch_data = BranchModel::where('sno', $branch_id)->first();
                $branch_name = " ";
                if ($branch_data->branch_type == 1) {
                    $branch_name = $branch_data->branch_name;
                } elseif ($branch_data->branch_type == 2) {
                    $branch_name = $branch_data->franchise_name;
                }
                //   SMS
                $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
                $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
                $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
                $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
              
    
                if ($training && $customer_mobiles) {
                    
                    $branch_data   = BranchModel::where('sno', $branch_id)->first();
                   
    
                    if ($batch_id) {
                        $result_sms_bat  = SmsTemplateModel::where('status', 0)->where('template_name', '007_BatchAssign')->first();
                        $authkey         = $result_sms_bat ? $result_sms_bat->authkey : '';
                        $sender_id       = $result_sms_bat ? $result_sms_bat->sender_id : '';
                        $template_id     = $result_sms_bat ? $result_sms_bat->template_id : '';
                        $country_code    = $result_sms_bat ? $result_sms_bat->country_code : '';
                        $message_content = $result_sms_bat ? $result_sms_bat->sms_template_messagecontent : '';
                         $mobile_number = $country_code . $customer_mobiles;
    
                        $formattedDate = Carbon::parse($batch_id->start_date)->format('d M Y'); // e.g., 11 Jan 2025
    
                        // Replace placeholders with actual values
                        $replacement_values = [$customer_names, $formattedDate, $cre_mobile];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
    
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
    
                    }
    
                    if ($transaction_id) {
                        $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '005_PaymentSuccess')->first();
                        $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
                        $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
                        $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
                        $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
                        $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
                         $mobile_number = $country_code . $customer_mobiles;
    
                        // Replace placeholders with actual values
                        $replacement_values = [$customer_names, $totalAmount, $transaction_id];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );
    
                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];
    
                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
    
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);
                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
    
                }
                // Email
                if ($training && $customer_mails) {
                    $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
    
                    if ($batch_id) {
                        $email_template_id  = 12; // thank you template
                        $emailTemplate      = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                        $coursename         = ManageCoursesModel::where('status', 0)->where('sno', $comunication_course_id)->first();
                        $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch_id->sno)->first();
                        $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
                        $dynamicSubject     = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
                        $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
                        $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
                        $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');
    
                        $class_time  = $start_time . ' to ' . $end_time;
                        $content     = $emailTemplate->email_subject;
                        $content     = str_replace('#name', $customer_names, $content);
                        $content     = str_replace('#Course', $coursename->course_name, $content);
                        $content     = str_replace('#start_date', $format_startDate, $content);
                        $content     = str_replace('#end_date', $format_endDate, $content);
                        $content     = str_replace('#class_time', $class_time, $content);
                        $content     = str_replace('#staff_nick_name', $staff->nick_name ?? 'Elsa', $content);
                        $branchNo    = $branch_data->mobile ?? '9677781155';
                        $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
                        $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                        $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
    
                        $mailData = [
                            'url'         => 'Eapl.com',
                            'subject'     => $dynamicSubject,
                            'content'     => $content,
                            'branchNo'    => $branchNo,
                            'branchemail' => $branchemail, // Use the message content from the request
                            'fbLink'      => $fbLink,      // Use the message content from the request
                            'instaLink'   => $instaLink,   // Use the message content from the request
                            'salesMobile' => $branch_data->sales_mobile,
                        ];
    
                        $to_address   = $customer_mails;
                        $from_address = 'elysiumacademy@elysium.community';
                        $from_name    = 'Elysium Academy®';
                        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    
                    }
    
                    if ($transaction_id) {
                        $email_template_id = 18; // thank you template
                        $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                        $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $comunication_course_id)->first();
    
                        $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
    
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $paymentDate        = date($common_date_format);
                        $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                        $paymentAmount      = $paymentAmt . ". Rs";
                        $content            = $emailTemplate->email_subject;
                        $content            = str_replace('#name', $customer_names, $content);
                        $content            = str_replace('#course', $coursename->course_name ?? 'Course', $content);
                        $content            = str_replace('#transactionId', $transaction_id, $content);
                        $content            = str_replace('#amount', $paymentAmount, $content);
                        $content            = str_replace('#transactionDate', $paymentDate, $content);
                        $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
                        $branchNo           = $branch_data->mobile ?? '9677781155';
                        $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
                        $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                        $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                        $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                        $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
    
                        $mailData = [
                            'url'         => 'Eapl.com',
                            'subject'     => $dynamicSubject,
                            'content'     => $content,
                            'branchNo'    => $branchNo,
                            'branchemail' => $branchemail, // Use the message content from the request
                            'fbLink'      => $fbLink,      // Use the message content from the request
                            'instaLink'   => $instaLink,   // Use the message content from the request
                            'salesMobile' => $branch_data->sales_mobile ?? '9677781155',
                        ];
    
                        $to_address   = $customer_mails;
                        $from_address = 'elysiumacademy@elysium.community';
                        $from_name    = 'Elysium Academy®';
    
                        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
    
                    }
    
                }
                // Whatsapp messages
                if ($training && $customer_mobiles) {
                    $coursename = ManageCoursesModel::where('status', 0)->where('sno', $comunication_course_id)->first();
                    $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                    $hasHeader  = false; // Example flag: set based on template
                    $hasBody    = false; // Example flag: set based on template
                    $components = [];
                    $couponCode = " ";
    
                    if ($batch_id) {
    
                        $components_batch = [];
    
                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                   // $currentHour = date('H'); // Get current hour in 24-hour format
                        if ($currentHour >= 5 && $currentHour < 12) {
                            $greeting = 'Good Morning';
                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
    
                        $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch_id->sno)->first();
                        $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
                        $helper             = new \App\Helpers\Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
                        $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
                        $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
                        $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');
                        $class_time         = $start_time . ' to ' . $end_time;
                        $templateName       = 'elysium_academy_batch_allot2';
    
                        $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/BatchAllocation.jpg';
                        $bodyText    = [
                            [
                                'type'           => 'text',
                                'text'           => $greeting,
                                'parameter_name' => 'greet_msg',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $customer_names,
                                'parameter_name' => 'customer_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $coursename->course_name ?? 'Course',
                                'parameter_name' => 'course_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $format_startDate,
                                'parameter_name' => 'start_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $format_endDate,
                                'parameter_name' => 'end_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $class_time,
                                'parameter_name' => 'class_time',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $staff->nick_name ?? 'Elsa',
                                'parameter_name' => 'staff_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $cre->nick_name ?? 'Elsa',
                                'parameter_name' => 'cre_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->cre_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_name ?? 'Elysium Academy',
                                'parameter_name' => 'branch_name',
                            ],
                        ];
                        $components_batch[] = [
                            'type'       => 'header',
                            'parameters' => [
                                [
                                    'type'  => 'image',
                                    'image' => [
                                        'link' => $headerImage, // Dynamically set header image
                                    ],
                                ],
                            ],
                        ];
                        $components_batch[] = [
                            'type'       => 'body',
                            'parameters' => $bodyText,
                        ];
    
                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                        $WhatsAppBusinessAccountId = $this->businessId;
                        $accessToken               = $this->accessToken;
                        $fromPhoneNumberId         = $this->phoneNumberId;
    
                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                        $to           = $customer_mobiles;
                        $languageCode = 'en';
    
                        if (strpos($to, '+91') !== 0) {
                            $to = '+91' . $to;
                        }
    
                        $message = 'test~message';
    
                        $payload = [
                            'messaging_product' => 'whatsapp',
                            'to'                => $to,
                            'type'              => 'template',
                            'template'          => [
                                'name'       => $templateName,
                                'language'   => [
                                    'code' => $languageCode,
                                ],
                                'components' => $components_batch,
                            ],
                        ];
    
                        $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
    
                    }
                    if ($transaction_id) {
                        // Example flag: set based on template
                        $components_trans = [];
                        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                   // $currentHour = date('H'); // Get current hour in 24-hour format
                        if ($currentHour >= 5 && $currentHour < 12) {
                            $greeting = 'Good Morning';
                        } elseif ($currentHour >= 12 && $currentHour < 18) {
                            $greeting = 'Good Afternoon';
                        } else {
                            $greeting = 'Good Evening';
                        }
                        $helper = new Helpers();
                        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                        $paymentDate        = date($common_date_format);
                        $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                        $paymentAmount      = $paymentAmt . ". Rs";
    
                        $templateName = 'elysium_academy_pay_transaction2';
                        $templateHeaderMediaId = '2177298459677656'; 
                        // $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
                        $headerImage = asset('assets/Payment_success.jpg');
                        $bodyText     = [
                            [
                                'type'           => 'text',
                                'text'           => $greeting,
                                'parameter_name' => 'greet_msg',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $customer_names,
                                'parameter_name' => 'customer_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $coursename->course_name ?? 'Course',
                                'parameter_name' => 'course_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $transaction_id,
                                'parameter_name' => 'transaction_id',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $paymentAmount,
                                'parameter_name' => 'amount',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $paymentDate,
                                'parameter_name' => 'pay_date',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->cre_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                                'parameter_name' => 'contact_email',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_name ?? 'Elysium Academy',
                                'parameter_name' => 'branch_name',
                            ],
                            [
                                'type'           => 'text',
                                'text'           => $branch_data->sales_mobile ?? '9677781155',
                                'parameter_name' => 'contact_no2',
                            ],
    
                        ];
                        $components_trans[] = [
                            'type'       => 'header',
                            'parameters' => [
                                [
                                    'type'  => 'image',
                                    // 'image' => [
                                    //   'id' => $templateHeaderMediaId
                                    // ],
                                    'image' => [
                                        'link' => $headerImage, // Dynamically set header image
                                    ],
                                ],
                            ],
                        ];
    
                        $components_trans[] = [
                            'type'       => 'body',
                            'parameters' => $bodyText,
                        ];
                        $dynamicParameters         = $templateParameters[$templateName] ?? [];
                        $WhatsAppBusinessAccountId = $this->businessId;
                        $accessToken               = $this->accessToken;
                        $fromPhoneNumberId         = $this->phoneNumberId;
    
                        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
    
                        $to           = $customer_mobiles;
                        $languageCode = 'en';
    
                        if (strpos($to, '+91') !== 0) {
                            $to = '+91' . $to;
                        }
    
                        $message = 'test~message';
    
                        $payload = [
                            'messaging_product' => 'whatsapp',
                            'to'                => $to,
                            'type'              => 'template',
                            'template'          => [
                                'name'       => $templateName,
                                'language'   => [
                                    'code' => $languageCode,
                                ],
                                'components' => $components_trans,
                            ],
                        ];
    
                        $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
    
                    }
                }
                
                 if ($staff_dropdown_id > 0) {
                      ReferralPersonModel::updateOrCreate(
                        [
                          'customer_id'       => $customer->sno ?? null, // Unique identifier for update
                          'branch_id'         => $branch_check->sno ?? null,       // Ensure branch_id is part of uniqueness
                        ],
                        [
                          'referral_type'     => 2,
                          'referral_id'       => $staff_dropdown_id,  //staff_dropdown_id
                          'referral_person'   => "Staff",
                          'created_by'        => $user_id,
                          'updated_by'        => $user_id,
                        ]
                      );
                    }

                  for ($i = 1; $i <= 5; $i++) {
                    session()->forget('customer_form_step_' . $i);
                  }
                  // Clear other customer-related session data
                  session()->forget([
                    'course_type_hidden_id',
                    'course_batch_hidden_id',
                    'batch_check_hidden_id'
                  ]);
          DB::commit();
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Customer Course Added successfully!'
          ]);
           return redirect('/manage_customer');
            } catch (\Exception $e) {
                DB::rollBack();
                return response()->json(['message' => 'Error processing payment', 'error' => $e->getMessage()], 500);
            }
    }
  }
  
  

  public function getPaymentCalculation(Request $request)
  {
    $data = $request->all();

    $validator = Validator::make($request->all(), [
        'initial_fee' => 'required|numeric',
        'payment_mode_id' => 'required|integer',
        'payment_mode_name' => 'required|string',
        'balance_fee' => 'required|numeric',
        'split_amounts' => 'required|array',
        'split_amounts.*' => 'required|numeric',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 401,
            'message' => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data' => null,
        ], 200);
    }

    $branch_id = $request->user()->branch_id;
    $initialFee = intval($data['initial_fee']); // Corrected to use initial_fee
    $courseTypeSchedule = $data['course_type_schedule'] ?? 1;
    $ratiotype = json_decode($data['ratio'], true); // Decode ratio JSON string
    if (!is_array($ratiotype) || empty($ratiotype)) {
        $ratiotype = [1]; // Default ratio to prevent empty split
    }
    $balanceFee = $data['balance_fee'];
    $original = $data['original'];
    $paymentTotal = $data['paymentTotal'];
    $splitAmounts = $data['split_amounts'];

    // Check the branch conditions
    $branchbelow = BranchModel::where('sno', $branch_id)
        ->where('min_prd_cost', '<', $initialFee)
        ->first();
    $branchabove = BranchModel::where('sno', $branch_id)
        ->where('min_prd_cost', '>', $initialFee)
        ->first();
    $branchequal = BranchModel::where('sno', $branch_id)
        ->where('min_prd_cost', '=', $initialFee)
        ->first();

    // Determine notable status
    $notable = $paymentTotal == $initialFee ? 0 : 1;

    // Determine check balance based on branch conditions
    if ($branchbelow) {
        $chk_bal = $courseTypeSchedule == 1 ? $balanceFee : $balanceFee;
    
    } elseif ($branchequal) {
        // return 'checking2';
         // this working now chek this 
        $chk_bal = $balanceFee;
    } elseif ($branchabove) {
      
        $chk_bal = $original; // Ensure consistency
    } else {
   
        $chk_bal = $original; // Default to original
    }

    // Calculate split amounts and remaining balance
    $calculatedSplitAmounts = [];
    $splitBalance = [];
    $remainingBalance = $chk_bal;
 
    // if (!empty($ratiotype) && is_array($ratiotype)) {
    //     $totalRatio = array_sum($ratiotype);

    //     foreach ($ratiotype as $ratio) {
    //         $splitAmount = round(($chk_bal * $ratio) / $totalRatio, 2);
    //         $remainingBalance -= $splitAmount;

    //         $calculatedSplitAmounts[] = $splitAmount;
    //         $splitBalance[] = round($remainingBalance, 2);
    //     }

    //     // Ensure the last split balance is zero
    //     if (!empty($splitBalance)) {
    //         $splitBalance[count($splitBalance) - 1] = 0;
    //     }
    // }

    if (!empty($ratiotype) && is_array($ratiotype)) {
        $totalRatio = array_sum($ratiotype);
    
        if ($totalRatio > 0) {  // Ensure no division by zero
            foreach ($ratiotype as $ratio) {
                $splitAmount = round(($chk_bal * $ratio) / $totalRatio, 2);
                $remainingBalance -= $splitAmount;
    
                $calculatedSplitAmounts[] = $splitAmount;
                $splitBalance[] = round($remainingBalance, 2);
            }
    
            // Ensure the last split balance is zero
            if (!empty($splitBalance)) {
                $splitBalance[count($splitBalance) - 1] = 0;
            }
        }
    }

    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Customer calculation successfully!',
    ]);

    return response()->json([
        'status' => 200,
        'message' => 'Payment Table successfully Created!',
        'data' => [
            'initial_fee' => $initialFee,
            'initialFeeGst' => $initialFee * 0.18,
            'course_type_schedule' => $courseTypeSchedule,
            'payment_mode_id' => $data['payment_mode_id'],
            'payment_mode_name' => $data['payment_mode_name'],
            'balance_fee' => $balanceFee,
            'original' => $original,
            'split_amounts' => $calculatedSplitAmounts,
            'split_balance' => $splitBalance,
            'notable' => $notable,
        ],
    ]);
}


  public function getSubcatgory(Request $request)
  {
    $coursesubId = $request->input('course_subcategory_id');

    // Fetch courses based on course_type_id
    $courses = CourseSubCategoryModel::where('course_category_id', $coursesubId)->get();

    return response()->json([
      'status' => 200,
      'data' => $courses
    ]);
  }

  public function getBatch(Request $request)
  {
    // $courseId = $request->input('course_id');

    $courseId = $request->input('course_id');
    //
    // If batch_id is a JSON string (like ["9"]), decode it
    if (is_string($courseId)) {
      $courseId = json_decode($courseId, true);
    }

    // Check if batch_id is an array and has values
    if (is_array($courseId) && count($courseId) > 0) {
      $courseId = $courseId[0]; // Get the first batch_id
    } else {
      return response()->json([
        'status' => 'error',
        'message' => 'Invalid batch ID received'
      ], 400);
    }
    $branchId = $request->user()->branch_id;
    // return $courseId;
    // Subquery to calculate allocated students
    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno');

    $startDate = Carbon::now()->toDateString();

        // Calculate 15 days from today
        $endDate = Carbon::now()->addDays(15)->toDateString();
        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.course_id', $courseId)
            // ->whereBetween('za_batch.start_date', [$startDate, $endDate])
            ->where('za_batch.branch_id', $branchId)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_slot_type.status', '!=', 2)
      ->whereDate('za_batch.start_date', '<=', Carbon::now()->addDays(7))
      ->whereDate('za_batch.end_date', '>=', Carbon::now())
      ->where('za_slot.status', '!=', 2)
      ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        'za_slot.end_time'
      )
      ->orderBy('za_batch.sno', 'desc')
      ->get();

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i A');
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i A');

      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      // Calculate available students
      $item->available_students = $item->max_students - $item->allocated_students;

      return $item;
    });

    if (count($formattedBatches) === 0) {
      return response()->json([
        'status' => 200,
        'data' => [],
        'message' => 'No batches have this course allocated'
      ]);
    } else {
      return response()->json([
        'status' => 200,
        'data' => $formattedBatches
      ]);
    }
  }
  public function getBatchCourse(Request $request)
  {
    // $courseId = $request->input('course_id');

    $courseId = $request->input('course_id');
    //

    $branchId = $request->user()->branch_id;
    // return $courseId;
    // Subquery to calculate allocated students
    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno');

    // Fetch batch data with necessary joins
    $startDate = Carbon::now()->toDateString();

        // Calculate 15 days from today
        $endDate = Carbon::now()->addDays(15)->toDateString();
        // Fetch batch data with necessary joins
        $batches = BatchModel::where('za_batch.course_id', $courseId)
            ->whereBetween('za_batch.start_date', [$startDate, $endDate])
            ->where('za_batch.branch_id', $branchId)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        'za_slot.end_time'
      )
      ->orderBy('za_batch.sno', 'desc')
      ->get();

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i A');
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i A');

      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      // Calculate available students
      $item->available_students = $item->max_students - $item->allocated_students;

      return $item;
    });

    if (count($formattedBatches) === 0) {
      return response()->json([
        'status' => 200,
        'data' => [],
        'message' => 'No batches have this course allocated'
      ]);
    } else {
      return response()->json([
        'status' => 200,
        'data' => $formattedBatches
      ]);
    }
  }

  public function getCoursePay(Request $request)
  {
    $courseId = $request->input('course_id');
    
    $course = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name','za_course_type.course_days',
   'za_course_type.course_duration','za_course_type.fees_schedule as course_fees_schedule')
                 ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')->where('za_course.status', 0)->where('za_course.sno', $courseId)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $course
    ], 200);
  }
  public function getCourseTypePay(Request $request)
  {
    $courseId = $request->input('course_type_id');
    $course = CourseTypeModel::where('status', 0)->where('sno', $courseId)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $course
    ], 200);
  }
  public function getBatchpay(Request $request)
  {


    $batchId = $request->input('batch_id');

    // If batch_id is a JSON string (like ["9"]), decode it
    if (is_string($batchId)) {
      $batchId = json_decode($batchId, true);
    }

    // Check if batch_id is an array and has values
    if (is_array($batchId) && count($batchId) > 0) {
      $courseId = $batchId[0]; // Get the first batch_id
    } else {
      return response()->json([
        'status' => 'error',
        'message' => 'Invalid batch ID received'
      ], 400);
    }

    // return $courseId;
    // Fetch batch data with necessary joins
    $batches = BatchModel::where('za_batch.sno', $courseId)->where('za_batch.branch_id', $request->user()->branch_id)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time'
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->orderBy('za_batch.sno', 'desc')
      ->get();

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i A');
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i A');

      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      return $item;
    });

    return response()->json([
      'status' => 200,
      'data' => $formattedBatches
    ]);
  }

  public function getBatchpayCourse(Request $request)
  {


    $batchId = $request->input('batch_id');


    // return $courseId;
    // Fetch batch data with necessary joins
    $batches = BatchModel::where('za_batch.sno', $batchId)->where('za_batch.branch_id', $request->user()->branch_id)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time'
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->orderBy('za_batch.sno', 'desc')
      ->get();

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i A');
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i A');

      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      return $item;
    });

    return response()->json([
      'status' => 200,
      'data' => $formattedBatches
    ]);
  }

  public function getuserStaff(Request $request)
  {
    $staffId = $request->user()->user_id;
    $couponcode = $request->couponcode;

    // Fetch the staff user
    $staffuser = StaffModel::where('sno', $staffId)->first();

    // if (!$staffuser) {
    //     return response()->json([
    //         'status' => 404,
    //         'message' => 'Staff user not found'
    //     ]);
    // }

    // Check if a coupon code was provided and find the coupon details
    if ($couponcode != null || $couponcode != "") {
      $staff_coupon = StaffModel::where('coupon_code', $couponcode)->first();
    } else {
      $staff_coupon = "";
    }

    $staff_discount = StaffModel::where('sno', $request->user()->user_id)->first();

    if ($staff_coupon) {
      // Coupon is valid
      $discount = $staff_coupon->discount ?? 0;
      $nick_name = $staff_coupon->nick_name;

      return response()->json([
        'status' => 200,
        'discount' => $discount,
        'nick_name' => $nick_name,
        'message' => 'Coupon code applied successfully.',
      ]);
    } elseif ($staff_discount && empty($couponcode)) {

      $discount =  0;
      $nick_name = '';
      return response()->json([
        'status' => 404,
        'discount' => $discount,
        'nick_name' => $nick_name,
        'message' => '',
      ]);
    } else {
      $discount = $staffuser->discount;
      $nick_name = $staffuser->nick_name;
      return response()->json([
        'status' => 404,
        'discount' => $discount,
        'nick_name' => $nick_name,
        'message' => 'Invalid coupon code. Defaulting to user discount.',
      ]);
    }

    // $discount = $staffuser->discount;
    // $nick_name = $staffuser->nick_name;
    // return response()->json([
    //     'status' => 200,
    //     'discount' => $discount,
    //     'nick_name' => $nick_name,
    //     'message' => '.',
    // ]);

  }
  public function getCustomer(Request $request)
  {
    $staffId = $request->user()->user_id;
    $customer_id = $request->customer_id;

    // Fetch the staff user
    $staffuser = StaffModel::where('sno', $staffId)->first();

    if (!$staffuser) {
      return response()->json([
        'status' => 404,
        'message' => ''
      ]);
    }

    // Check if a coupon code was provided and find the coupon details
    $customer = CustomerModel::where('customer_id', $customer_id)->first();
    // $staff_discount = StaffModel::where('sno', $request->user()->user_id)->first();

    if ($customer) {
      // Coupon is valid
      $customer_id = $customer->customer_id;
      $cus_name = $customer->cus_name;
    } elseif (empty($customer_id)) {
      // $discount = $staffuser->discount;
      return response()->json([
        'status' => 404,
        'customer_id' => $customer_id,
        'cus_name' => '',
        'message' => ''
      ]);
    } else {
      // $discount = $staffuser->discount;
      return response()->json([
        'status' => 404,
        'customer_id' => $customer_id,
        'cus_name' => '',
        'message' => 'Invalid customer id.'
      ]);
    }

    return response()->json([
      'status' => 200,
      'customer_id' => $customer_id,
      'cus_name' => $cus_name,
      'message' => 'Customer Reference Added.'
    ]);
  }

  public function customer_add_payment($id, Request $request)
  {

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

      // Check if decryption failed
      if ($decryptedValue === false) {
          return redirect()->back()->with('error', 'Invalid Entry');
      }
      $id = $decryptedValue;
    //   return $id;
      $customers = CustomerModel::where('sno', $id) // Group by payment_id to get unique entries
          ->first();
      // dd($courseIds);
      $branch_id = $request->user()->branch_id;
      // Get branch details and calculate GST percentage
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
      $minimumamount = $branch ? $branch->min_amnt_receive : 1000;
      $pay = PaymentModel::where('za_payment.customer_id', $id)->where('za_payment.status','!=',2)
          ->select('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name')
          ->join('za_course', 'za_course.sno', '=', 'za_payment.course_id') // Select only the fields you need
          ->groupBy('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name') // Group by payment_id to get unique entries
          ->get();
    //   return $pay;

      // Get the course ID from the request
      $selectedPaymentId = $request->input('payment_id', $pay[0]->payment_id); // Use the first course if none selected

      // Retrieve payments where course_id matches any of the course IDs associated with the customer
    $payments = PaymentModel::where('payment_id', $selectedPaymentId)
        ->where('amount', '>=', 0)
        ->where('paidAmount', '>=', 0)
        // ->where('gst_amount', '>=', 0)
        // ->where('balanceFee', '>=', 0)
        ->where('za_payment.status','!=',2)
        ->orderBy('nextPayDate', 'asc')
        ->get();
      // return $payments;
      $total_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
      // ->where('customer_id', $id)
          ->select('total_amount')
          ->first()
          ->total_amount ?? 0;

      $paid_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
      // ->where('customer_id', $id)
          ->sum('paidAmount');

      $balance_amount = $total_amount - $paid_amount;

      $balance_amount = $total_amount - $paid_amount;

      // $total_amount = number_format($total_amount, 2);
      // $paid_amount = number_format($paid_amount, 2);
      // $balance_amount = number_format($balance_amount, 2);

      $total_amount = $total_amount;
      $paid_amount = $paid_amount;
      $balance_amount = $balance_amount;

    //   $invoice_chk = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
    //   $year = date("Y");
    //   if (!$invoice_chk) {
    //       $invoice_id = 'EA/' . $year . '/INV2005';
    //   } else {
    //       $data = $invoice_chk->invoice_id;
    //       $slice = explode("/", $data);
    //       if (count($slice) >= 3) {
    //           $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
    //           $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
    //       } else {
    //           $next_inv_number = 2005;
    //       }
    //       $invoice_id = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
    //   }
    $year = date("Y");
    
    $lastNumber = PaymentModel::where('status', 1)
        ->where('invoice_id', 'like', 'EA/' . $year . '/INV%')
        ->selectRaw("MAX(CAST(SUBSTRING(invoice_id, LENGTH('EA/$year/INV') + 1) AS UNSIGNED)) as max_inv")
        ->value('max_inv');
    
    $nextNumber = $lastNumber ? $lastNumber + 1 : 2005;
    
    $invoice_id = 'EA/' . $year . '/INV' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    //   return $payments;
      return view('content.customer.payment', compact(
          'payments',
          'pay',
          'selectedPaymentId',
          'customers',
          'invoice_id',
          'total_amount',
          'paid_amount',
          'balance_amount',
          'gstPercentage',
           'minimumamount'
      ));
  }
  public function add_payment(Request $request)
  {
    // Get the selected payment ID from the request
    $selectedPaymentId = $request->input('payment_id');

    // Get the branch ID from the logged-in user
    $branch_id = $request->user()->branch_id;

    // Get branch details and calculate GST percentage
    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();
    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    $minimumamount = $branch ? $branch->min_amnt_receive : 1000;

    // Retrieve payments based on the selected payment ID
    $payments = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=', 2)
      ->orderBy('nextPayDate', 'asc')
      ->get();
  

    // Calculate total, paid, and balance amounts
    $total_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
      ->select('total_amount')
      ->first()
      ->total_amount ?? 0;
    //  return $total_amount;
    $paid_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
      ->sum('paidAmount');

    $balance_amount = $total_amount - $paid_amount;

    // Format amounts for the response
    $total_amount = $total_amount;
    $paid_amount = $paid_amount;
    $balance_amount = $balance_amount;

    // Get date format from general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';


    $encryptedValue = $helper->encrypt_decrypt($request->invoice_id, 'encrypt');
    $printValue = $helper->encrypt_decrypt($request->index + 1, 'encrypt');
    // Format payment data according to the date format
    $formattedPayments = $payments->map(function ($payment,$index) use ($dateFormat, $gstPercentage,$helper) {
      return [
        'sno' => $payment->sno,
        'branch_id' => $payment->branch_id,
        'customer_id' => $payment->customer_id,
        'course_id' => $payment->course_id,
        'initialPayDate' => date($dateFormat, strtotime($payment->initialPayDate)),
        'nextPayDate' => date($dateFormat, strtotime($payment->nextPayDate)),
        // 'amount' => number_format($payment->amount, 2),
        'amount' => $payment->amount,
        // 'paidAmount' => number_format($payment->paidAmount, 2),
        'paidAmount' => $payment->paidAmount,
        // 'gst_amount' => number_format($payment->gst_amount, 2),
        'gst_amount' => $payment->gst_amount,
        // 'balanceFee' => number_format($payment->balanceFee, 2),
        'balanceFee' => $payment->balanceFee,
        'invoice_id' => $payment->invoice_id,
         'encryptedValue' => $helper->encrypt_decrypt($payment->invoice_id, 'encrypt'),
        'printValue' => $helper->encrypt_decrypt($index + 1, 'encrypt'), // $index is automatically passed by `map()`
        'status' => $payment->status,
        'gst_percentage' => $gstPercentage,
        // 'minimumamount' => $minimumamount ?? 1000,
      ];
    });

    // If the request is AJAX, return a JSON response
    if ($request->ajax()) {
      return response()->json([
        'total_amount' => $total_amount,
        'paid_amount' => $paid_amount,
        'balance_amount' => $balance_amount,
        'payments' => $formattedPayments,
        'gst_percentage' => $gstPercentage,
        'minimumamount' => $minimumamount
      ]);
    }

    // If not an AJAX request, you may return a different response here as needed
  }
  public function getCustomerCourse()
  {

    $lead = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }
  public function customer_update(Request $request)
  {
    // Validate that customer_id is required
    $validator = Validator::make($request->all(), [
      'customer_id' => 'required|integer',
    ]);
    $selected_batch = $request->input('batch_check_hidden_id');
    $staff_id = BatchModel::where('sno', $selected_batch)->value('staff_id');
    $slot_id = BatchModel::where('sno', $selected_batch)->value('slot_id');
    $costing_course_id = $request->input('course_batch_hidden_id');

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }

    $cus_gender = $request->input('inlineRadioOptions') == 'Female' ? 2 : ($request->input('inlineRadioOptions') == 'Male' ? 1 : 3);

    $courseId = $request->input('course_batch_hidden_id');

    // Ensure $courseId is an array
    if (!is_array($courseId)) {
      $courseId = [$courseId];
    }

    // Convert the array to a JSON string
    $courseIdJson = json_encode($courseId);

    // Fetch branch details
    $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
    $branch_code = $branch_check->city_short_code;
    $user_id = $request->user()->user_id;

    if ($request->hasFile('cus_pic')) {
      $imageName = idate('B') . rand(1, 50) . '.' . $request->file('cus_pic')->extension();
      $destinationPath = public_path('cus_pics');
      // Path to the logos directory
      $request->file('cus_pic')->move($destinationPath, $imageName);
      $logo = $imageName;
    } else if ($request->input('old_cus_pic')) {
      $logo = $request->input('old_cus_pic');
    } else {
      $logo = '';
    }

    $edit_sno = $request->input('customer_id');
    $customer_upd = CustomerModel::find($edit_sno);
    // return $costing_upd;
    if (!$customer_upd) {
      return response()->json([
        'status' => 404,
        'message' => 'Customer not found',
        'data' => null,
      ], 404);
    }

    // dd($request->input('c_p_mobile'));
    // Update or create customer record
    $customer_upd->cus_name = ucfirst($request->input('cus_name') ?? '');
    $customer_upd->lead_id = $request->input('lead_id') ?? '';
    $customer_upd->cus_name = ucfirst($request->input('cus_name') ?? '');
    $customer_upd->cus_gender = $cus_gender;
    $customer_upd->cus_dob = $request->input('cus_dob') ? DateTime::createFromFormat('d-M-Y', $request->input('cus_dob'))->format('Y-m-d') : null;
    $customer_upd->doj = $request->input('doj') ? DateTime::createFromFormat('d-M-Y', $request->input('doj'))->format('Y-m-d') : null;
    $customer_upd->cus_mobile = $request->input('cus_mobile') ?? '';
    $customer_upd->cus_alternate_mobile = $request->input('cus_alternate_mobile') ?? '';
    $customer_upd->cus_email_id = $request->input('cus_email_id') ?? '';
    $customer_upd->cus_marital_status = $request->input('cus_marital_status') ?? null;
    $customer_upd->c_p_mobile = $request->input('c_p_mobile') ?? '';
    $customer_upd->contact_person = $request->input('contact_person') ?? '';
    $customer_upd->door_no = $request->input('door_no') ?? '';
    $customer_upd->pincode = $request->input('pincode');
    $customer_upd->cus_pic = $logo;
    // $customer_upd->customer_type_id = $request->input('customer_type_id') ?? '';
    $customer_upd->country = $request->input('country') ?? null;
    $customer_upd->state = $request->input('state') ?? null;
    $customer_upd->city = $request->input('city') ?? null;
    $customer_upd->address = $request->input('address') ?? '';
    // $customer_upd->course_subcategory_id = $request->input('course_subcategory_id') ?? '';
    // $customer_upd->course_type_id = $request->input('course_type_batch_id') ?? '';
    $customer_upd->coupon_code_ref = $request->input('coupon_code') ?? '';
    $customer_upd->free_shd_count = $request->input('free_shd_count') ?? 0;
    $customer_upd->cus_education = ''; // Intentionally empty
    $customer_upd->created_by = $user_id;
    $customer_upd->updated_by = $user_id;

    $customer_upd->update();

    // $costing_upd->batch_id = $selected_batch ?? null;
    // $costing_upd->staff_id = $staff_id ?? null;
    // $costing_upd->slot_id = $slot_id ?? null;
    // $costing_upd->update();

    // $cust_edu_upd = CustomerEducationModel::where('customer_id', $edit_sno)->where('branch_id', $request->user()->branch_id)->first();
    // if ($cust_edu_upd) {
    //     $cust_edu_upd->customer_type_id = $request->input('customer_type_id');
    //     $cust_edu_upd->update();
    // }

    // Flash message based on save result
    if ($customer_upd) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Customer updated Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Customer!',
      ]);
    }
   return redirect('/manage_customer');
  }
  public function customer_edit($id)
  {
    // return $id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;

    // $course_type_hidden_id = session('course_type_hidden_id');
    // $course_batch_hidden_id = session('course_batch_hidden_id');
    // $allStepsData = [];

    // // Retrieve data for all steps from the session
    // for ($i = 1; $i <= 5; $i++) {
    //     $allStepsData['step_' . $i] = session('customer_form_step_' . $i, []);
    // }
    // $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
    // $course_data = ManageCoursesModel::where('sno', $course_batch_hidden_id)->first();

    // Fetch customer details
    $customer = CustomerModel::select('za_customer.*', 'za_course.course_name', 'za_training.course_id as cus_course_id', 'za_training.batch_id as cus_batch_id', 'za_training.course_id as cus_course_batch_id', 'za_customer_type.sno as customer_type_id', 'za_customer_type.customer_type_name')
      ->leftjoin('za_course', 'za_customer.course_id', '=', 'za_course.sno')
      ->leftjoin('za_customer_education', 'za_customer.sno', '=', 'za_customer_education.customer_id')
      ->leftjoin('za_customer_type', 'za_customer_education.customer_type_id', '=', 'za_customer_type.sno')
      ->leftjoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->leftjoin('za_payment', 'za_payment.customer_id', '=', 'za_training.customer_id')
      ->where('za_customer.status', '!=', 2)
      ->where('za_customer.sno', $id)
      ->orderBy('sno', 'desc')
      ->first();
    $ref_person = CustomerModel::where('status', '!=', 2)
      ->where('customer_id', $customer->customer_ref)
      ->value('cus_name');

    $course_ids = TrainingModel::where('status', '!=', 2)
      ->where('customer_id', $id)
      ->pluck('course_id');

    $course_amounts = ManageCoursesModel::whereIn('sno', $course_ids)
      ->pluck('course_max_price');
    $total_amount = $course_amounts->sum();

    $course_ids_payment = PaymentModel::where('status', '!=', 2)
      ->where('customer_id', $id)
      ->pluck('course_id');

    $paid_amounts = PaymentModel::where('customer_id', $id)
      ->pluck('paidAmount');

    $total_paid_amount = $paid_amounts->sum();

    // dd($total_paid_amount);
    // // Check if customer exists
    // if (!$customer) {
    //     abort(404, 'Customer not found');
    // }
    // $batch_check_hidden_id = session('batch_check_hidden_id', '');
    // $cus_name = session('cus_name');
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings->date_format ?? 'd-M-y';
    $customer->formatted_lead_dob = $customer->lead_dob ? Carbon::parse($customer->lead_dob)->format($dateFormat) : null;

    // return view('content.customer.customer_add', compact('customer', 'branch_data', 'step', 'allStepsData', 'course_type_hidden_id', 'course_batch_hidden_id', 'batch_check_hidden_id', 'course_data', 'cus_name'));
    return view('content.customer.customer_edit', [
      'customer' => $customer,
      'total_amount' => $total_amount,
      'ref_person' => $ref_person,
      'total_paid_amount' => $total_paid_amount,
    ]);
  }
  public function customer_batch_add($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        // Split the decrypted value
        $exp = explode('~', $decryptedValue);
        $cus_sno = str_replace(' ', '', $exp[0] ?? '');

        $course_index = str_replace(' ', '', $exp[1] ?? '');
        $course_sno = str_replace(' ', '', $exp[2] ?? '');
        $batch_sno = str_replace(' ', '', $exp[3] ?? '');
        $traning_sno = str_replace(' ', '', $exp[4] ?? '');

        // Fetch customer details
        $customer_details = CustomerModel::where('sno', $cus_sno)->first();
        // Fetch course details based on course_sno (not cus_sno)
        $course_details = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name', 'za_course_category.course_category_name', 'za_course_type.course_days', 'za_course_type.course_duration')
            ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
            ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_course.sno', $course_sno) // Corrected the field here
            ->first();
        // Fetch batch details
        $batch_details = BatchModel::select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',
            'za_staff.staff_name'
        )
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.sno', $batch_sno)->first();

        // Check if course details exist
        if (!$course_details) {
            return redirect()->back()->with('error', 'Course not found.');
        }

        // Fetch the list of courses with the same course type
        $course_list = ManageCoursesModel::where('course_type_id', $course_details->course_type_id)->get();

        // Return the view with the course and customer details
        return view('content.customer.batch_add_course', [
            'course_details' => $course_details,
            'customer_details' => $customer_details,
            'batch_sno' => $batch_sno,
            'course_sno' => $course_sno,
            'course_index' => $course_index,
            'cus_sno' => $cus_sno,
            'course_list' => $course_list,
            'batch_details' => $batch_details,
            'traning_sno' => $traning_sno,
        ]);
    }
    public function customer_batch_update(Request $request)
    {
        // return $request;
        // exit;
        $current_course_id = $request->current_course_id;
        $old_course_id = $request->old_course_id;
        $cus_sno = $request->cus_sno;
        $traning_sno = $request->traning_sno;
        $old_batch_id = $request->batch_id ?? 0;
        $current_batch_id = $request->batch_check_hidden_id ?? 0;
        $old_course_index = $request->old_course_index;

        // Fetch branch and user info
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $branch_check = BranchModel::where('sno', $branch_id)->first();
        $branch_code = optional($branch_check)->city_short_code; // Use optional to avoid null errors

        // Fetch batch details
        $batch_details = BatchModel::where('sno', $current_batch_id)->first();
        $batch = $batch_details ? [
            'batch_id' => $batch_details->sno,
            'slot_id' => $batch_details->slot_id ?? 0,
            'staff_id' => $batch_details->staff_id ?? 0,
            'start_date' => $batch_details->start_date ?? null,
            'end_date' => $batch_details->end_date ?? null,
        ] : null;

        // Fetch old training details
        $old_training_details = TrainingModel::where('customer_id', $cus_sno)
            ->where('sno', $traning_sno)
            ->first();
        if ($batch) {
            $old_training_details->batch_id = $batch['batch_id'];
            $old_training_details->slot_id = $batch['slot_id'];
            $old_training_details->staff_id = $batch['staff_id'];
            $old_training_details->start_date = $batch['start_date'];
            $old_training_details->end_date = $batch['end_date'];
        }

        $old_training_details->updated_by = $user_id;
        $old_training_details->update();

        $customer_details = CustomerModel::where('sno', $cus_sno)->first();
        if ($customer_details) {
            $get_old_courses = json_decode($customer_details->course_id, true) ?? [];
            $get_old_batch_id = json_decode($customer_details->batch_id, true) ?? [];

            // Update the old course and batch at the given index
            if (isset($get_old_courses[$old_course_index])) {
                $get_old_courses[$old_course_index] = $current_course_id;
            }

            if (isset($get_old_batch_id[$old_course_index]) && $current_batch_id) {
                $get_old_batch_id[$old_course_index] = $current_batch_id;
            }

            // Save updated course and batch details
            // $customer_details->course_id = json_encode($get_old_courses);
            $customer_details->batch_id = json_encode($get_old_batch_id);
            $customer_details->update();
        }
    
         $branch_data = BranchModel::where('sno', $branch_id)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
            $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
            $branch_name = $branch_data->franchise_name;
        }

        // whatsapp for batch allocate
        if ($customer_details) {

            $components_batch = [];

            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                       // $currentHour = date('H'); // Get current hour in 24-hour format
            if ($currentHour >= 5 && $currentHour < 12) {
                $greeting = 'Good Morning';
            } elseif ($currentHour >= 12 && $currentHour < 18) {
                $greeting = 'Good Afternoon';
            } else {
                $greeting = 'Good Evening';
            }
            $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch['batch_id'])->first();
            $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
            $coursename         = ManageCoursesModel::where('status', 0)->where('sno', $batchData->course_id)->first();
            $cre                = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
            $helper             = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
            $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
            $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
            $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');
            $class_time         = $start_time . ' to ' . $end_time;
            $templateName       = 'elysium_academy_batch_allot2';

            $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/BatchAllocation.jpg';
            $bodyText    = [
                [
                    'type'           => 'text',
                    'text'           => $greeting,
                    'parameter_name' => 'greet_msg',
                ],
                [
                    'type'           => 'text',
                    'text'           => $customer_details->cus_name,
                    'parameter_name' => 'customer_name',
                ],
                [
                    'type'           => 'text',
                    'text'           => $coursename->course_name,
                    'parameter_name' => 'course_name',
                ],
                [
                    'type'           => 'text',
                    'text'           => $format_startDate,
                    'parameter_name' => 'start_date',
                ],
                [
                    'type'           => 'text',
                    'text'           => $format_endDate,
                    'parameter_name' => 'end_date',
                ],
                [
                    'type'           => 'text',
                    'text'           => $class_time,
                    'parameter_name' => 'class_time',
                ],
                [
                    'type'           => 'text',
                    'text'           => $staff->nick_name,
                    'parameter_name' => 'staff_name',
                ],
                [
                    'type'           => 'text',
                    'text'           => $cre->nick_name??'Elsa',
                    'parameter_name' => 'cre_name',
                ],
                [
                    'type'           => 'text',
                    'text'           => $branch_data->cre_mobile ?? '9677781155',
                    'parameter_name' => 'contact_no',
                ],
                [
                    'type'           => 'text',
                    'text'           => $branch_name,
                    'parameter_name' => 'branch_name',
                ],
            ];
            $components_batch[] = [
                'type'       => 'header',
                'parameters' => [
                    [
                        'type'  => 'image',
                        'image' => [
                            'link' => $headerImage, // Dynamically set header image
                        ],
                    ],
                ],
            ];
            $components_batch[] = [
                'type'       => 'body',
                'parameters' => $bodyText,
            ];

            $dynamicParameters         = $templateParameters[$templateName] ?? [];
            $WhatsAppBusinessAccountId = $this->businessId;
            $accessToken               = $this->accessToken;
            $fromPhoneNumberId         = $this->phoneNumberId;

            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            $to           = $customer_details->cus_mobile;
            $languageCode = 'en';

            if (strpos($to, '+91') !== 0) {
                $to = '+91' . $to;
            }

            $message = 'test~message';

            $payload = [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => [
                    'name'       => $templateName,
                    'language'   => [
                        'code' => $languageCode,
                    ],
                    'components' => $components_batch,
                ],
            ];

            $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

        }
        // Email for batch allocate
        if ($customer_details && $customer_details->cus_email_id) {
            $email_template_id  = 12; // thank you template
            $emailTemplate      = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
            $batchData          = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch['batch_id'])->first();
            $coursename         = ManageCoursesModel::where('status', 0)->where('sno', $batchData->course_id)->first();
            $staff              = StaffModel::where('sno', $batchData->staff_id)->orderBy('sno', 'desc')->first();
            $dynamicSubject     = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
            $helper             = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            $format_startDate   = date($common_date_format, strtotime($batchData->start_date));
            $format_endDate     = date($common_date_format, strtotime($batchData->end_date));
            $start_time         = Carbon::parse($batchData->start_time)->format('h:i A');
            $end_time           = Carbon::parse($batchData->end_time)->format('h:i A');

            $class_time  = $start_time . ' to ' . $end_time;
            $content     = $emailTemplate->email_subject;
            $content     = str_replace('#name', $customer_details->cus_name, $content);
            $content     = str_replace('#Course', $coursename->course_name, $content);
            $content     = str_replace('#start_date', $format_startDate, $content);
            $content     = str_replace('#end_date', $format_endDate, $content);
            $content     = str_replace('#class_time', $class_time, $content);
            $content     = str_replace('#staff_nick_name', $staff->nick_name, $content);
            $branchNo    = $branch_data->mobile;
            $branchemail = $branch_data->mail;
            $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
            $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
            $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? 'Branch Mobile', $content);
            $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

            $mailData = [
                'url'         => 'Eapl.com',
                'subject'     => $dynamicSubject,
                'content'     => $content,
                'branchNo'    => $branchNo,
                'branchemail' => $branchemail, // Use the message content from the request
                'fbLink'      => $fbLink,      // Use the message content from the request
                'instaLink'   => $instaLink,   // Use the message content from the request
                'salesMobile' => $branch_data->sales_mobile,
            ];

            $to_address   = $customer_details->cus_email_id;
            $from_address = 'elysiumacademy@elysium.community';
           $from_name = 'Elysium Academy速';
            
            Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

        }
        // SMS for Batch Allocate
        if ($customer_details) {
          
            $cre_mobile      = $branch_data->cre_mobile ?? '7558184348';
            $batchData       = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')->where('za_batch.status', 0)->where('za_batch.sno', $batch['batch_id'])->first();
            $result_sms_bat  = SmsTemplateModel::where('status', 0)->where('template_name', '007_BatchAssign')->first();
            $authkey         = $result_sms_bat ? $result_sms_bat->authkey : '';
            $sender_id       = $result_sms_bat ? $result_sms_bat->sender_id : '';
            $template_id     = $result_sms_bat ? $result_sms_bat->template_id : '';
            $country_code    = $result_sms_bat ? $result_sms_bat->country_code : '';
            $message_content = $result_sms_bat ? $result_sms_bat->sms_template_messagecontent : '';
            $mobile_number   = $country_code . $customer_details->cus_mobile;

            $formattedDate = Carbon::parse($batchData->start_date)->format('d M Y'); // e.g., 11 Jan 2025

            // Replace placeholders with actual values
            $replacement_values = [$customer_details->cus_name, $formattedDate, $cre_mobile];
            $message_content    = preg_replace_callback(
                '/\{#var#\}/',
                function () use (&$replacement_values) {
                    return array_shift($replacement_values);
                },
                $message_content
            );

            $route    = "default";
            $postData = [
                'authkey' => $authkey,
                'mobiles' => $mobile_number,
                'message' => $message_content,
                'sender'  => $sender_id,
                'route'   => $route,
            ];

            // API URL
            $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            // Initialize the resource
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $postData,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
            ]);

            // Get response
            $response = curl_exec($ch);
            // return $response;
            $err = curl_error($ch);
            curl_close($ch);

        }

        
        

        // Flash message based on save result
        if ($customer_details) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Batch Assign updated Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Costing!',
            ]);
        }
        return redirect('/manage_customer');
    }

    // view popup
    public function customer_view(request $request)
   {

    if (!auth()->check()) {
        return redirect()->route('login');  // Redirect to login if the user is not authenticated
    }
  
    $id = $request->id;

    $customer = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      DB::raw("DATE_FORMAT(doj, '%d %b %Y') as doj"),
      'za_customer.cus_pic',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_countries.name as country_name',
      'za_states.name as state_name',
      'za_cities.name as city_name',
      'za_customer.address',
      'za_customer.door_no',
      'za_customer.pincode',
      'za_customer.customer_ref',
      'za_customer.final_fee',
      DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]")) as course_id'),
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_lead.qualification',
      'za_lead_type.lead_type_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_course.course_duration',
      'za_course.course_days',
      'za_slot.slot_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_slot_type.slot_type_name',
      'za_staff.staff_name',
      'za_class_room.class_room_name',
      'za_branch.min_prd_cost',
      'za_customer.status',

       DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount')
    )
      ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_batch', 'za_customer.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
      ->leftJoin('za_countries', 'za_customer.country', '=', 'za_countries.id')
      ->leftJoin('za_states', 'za_customer.state', '=', 'za_states.id')
      ->leftJoin('za_cities', 'za_customer.city', '=', 'za_cities.id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftjoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_class_room', 'za_batch.classroom_id', '=', 'za_class_room.sno')
      ->leftJoin('za_staff as staff_created_by', 'za_customer.created_by', '=', 'staff_created_by.sno')
      ->leftJoin('za_branch', 'staff_created_by.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id') // Join with payments
      ->where('za_customer.sno', $id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_countries.name',
        'za_states.name',
        'za_cities.name',
        'za_customer.address',
        'za_customer.door_no',
        'za_customer.pincode',
        'za_customer.final_fee',
        'za_customer.course_id',
        'za_customer.customer_ref',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_lead.qualification',
        'za_lead_type.lead_type_name',
        'za_course.course_name',
        'za_course.course_duration',
        'za_course.course_days',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_slot_type.slot_type_name',
        'za_staff.staff_name',
        'za_class_room.class_room_name',
        'za_branch.min_prd_cost',
        'za_customer.status'
      )
      ->orderBy('za_customer.sno', 'desc')
      ->first();
    //   return $customer;
    $ref_person = CustomerModel::where('status', '!=', 2)
      ->where('customer_id', $customer->customer_ref)
      ->value('cus_name');

    $course_ids = TrainingModel::where('status', '!=', 2)
      ->where('customer_id', $id)
      ->pluck('course_id');

    $course_amounts = ManageCoursesModel::whereIn('sno', $course_ids)
      ->pluck('course_max_price');
    $total_amount = $course_amounts->sum();

    $course_ids_payment = PaymentModel::where('status', '!=', 2)
      ->where('customer_id', $id)
      ->pluck('course_id');

    $paid_amounts = PaymentModel::where('customer_id', $id)->where('status','!=', 2)
      ->pluck('paidAmount');

    $total_paid_amount = $paid_amounts->sum();

    $educationDetails = CustomerEducationModel::where('customer_id', $id)->pluck('datas');
    $decodedEducation = [];
    
    foreach ($educationDetails as $data) {
        $decoded = json_decode($data, true); // decode JSON string
        if (is_array($decoded)) {
            $decodedEducation = array_merge($decodedEducation, $decoded);
        }
    }

    $course_details = TrainingModel::select(
        'za_training.course_id',
        'za_course.course_name',
        'za_course.course_duration',
        'za_course.course_days',
        'za_course.course_max_price',
        'za_course_type.course_type_name',
        'za_training.tesbo_check',
        // 'za_training.overall_fees',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount')
    )
    ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
    ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
    ->leftJoin('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
    ->where('za_training.customer_id', $id)
    ->where('za_training.status', '!=', 2)
    ->groupBy(
        'za_training.course_id',
        'za_course.course_name',
        'za_course.course_duration',
        'za_course.course_days',
        'za_course.course_max_price',
        'za_course_type.course_type_name',
        'za_training.tesbo_check',
        // 'za_training.overall_fees'
    )
    ->get();

     $student_redeem_table = DB::table('za_students_redeem')
      ->where('student_id', $id)
      ->where('status', '!=', 2) // optional: exclude deleted
      ->orderBy('created_at', 'desc')
      ->get();
    return view('content.customer.customer_view', [
      'customer' => $customer,
      'total_amount' => $total_amount,
      'ref_person' => $ref_person,
      'total_paid_amount' => $total_paid_amount,
      'educationDetails' => $decodedEducation,
      'student_redeem_table' => $student_redeem_table,
    ]);
  }
      // payment datas
      public function PayEdit($id, Request $request)
      {
    // Fetch the payment record along with course name
    $pay = PaymentModel::where('za_payment.sno', $id)->where('za_payment.status','!=', 2)
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->select('za_payment.*', 'za_course.course_name', 'za_batch.batch_name') // Select relevant fields
      ->first();

    // Check if the payment record exists
    if (!$pay) {
      return response([
        'status'    => 404,
        'message'   => 'Payment not found',
        'error_msg' => 'No payment record found with the given ID',
        'data'      => null
      ], 404);
    }

    // Retrieve the GST percentage from the branch
    $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

    // If the branch doesn't exist, you can handle it here as well
    if (!$branch) {
      return response([
        'status'    => 404,
        'message'   => 'Branch not found',
        'error_msg' => 'No branch record found for the user',
        'data'      => null
      ], 404);
    }

    // Format the amount if needed (you can customize this)
    $pay->amount = $pay->amount;

    // Include the GST percentage in the response
    return response([
      'status'    => 200,
      'message'   => 'Payment details retrieved successfully',
      'error_msg' => null,
      'data'      => [
        'payment'        => $pay,
        'gst_percentage' => $branch->gst_percentage // Include GST percentage here
      ]
    ], 200);
  }

  

    
    public function PayUpdate($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $validator = Validator::make($request->all(), [
            'pay_amount' => 'required|numeric', // Ensure it's a numeric value
            'total_amount_entered' => 'required|numeric', // Added validation for total_amount_entered
            'balanceFees' => 'required|numeric', // Added validation for balanceFees
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }
        // return $request->all();
        $year = date("Y");

        $lastNumber = PaymentModel::where('status', 1)
            ->where('invoice_id', 'like', 'EA/' . $year . '/INV%')
            ->selectRaw("MAX(CAST(SUBSTRING(invoice_id, LENGTH('EA/$year/INV') + 1) AS UNSIGNED)) as max_inv")
            ->value('max_inv');

        $nextNumber = $lastNumber ? $lastNumber + 1 : 2005;

        $invoice_id = 'EA/' . $year . '/INV' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        $original = $request->pay_amount;
        $nextdate = $request->nextdate;
        // $invoice_id = $request->invoice_id;
          $receipt_id = $request->reciptid;
          $next_pay_date = $request->nextdate;

        $paymentMode = $request->payment_mode;
        $coupon_id = $request->coupon_id;
        $transaction = json_encode($request->transaction_all);
        $paidAmount = $request->total_amount_entered;
        $balance_Fees = $request->balanceFees; // Make sure this is the correct value being used
        $initialPayDateFormatted = now()->format('Y-m-d');

        $get_ids = PaymentModel::where('sno', $id)->where('status','!=', 2)->first();

        $pay_course_id = $get_ids->course_id;
        $pay_customer_id = $get_ids->customer_id;
        $balanceFees = max(0,  $paidAmount - $get_ids->balanceFee);
        $total_course_amount = $get_ids->total_amount;
        $balanceFeestotal = $get_ids->total_amount;
        $paid_amt = PaymentModel::where('course_id', $pay_course_id)->where('status','!=', 2)
            ->where('customer_id', $pay_customer_id)
            ->pluck('paidAmount');

        $total_paid_amount = $paid_amt->sum();

        $redeemCoupon = DB::table('za_students_redeem')
            ->where('sno', $coupon_id)
            ->first();
        // return $balance_Fees;
        $total_bal = $total_course_amount - $total_paid_amount;
        
        if (!is_null($coupon_id)) {
            // If a coupon was applied, add its value to the paid amount
            $cumulativePay = $paidAmount + (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0);
            if($balance_Fees > 0){
             $cumulativeBal = $balance_Fees - (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0);
            }
            else{
             $cumulativeBal = $balance_Fees;
            }
        } else {
            // No coupon applied, cumulative pay is just the paid amount
            $cumulativePay = $paidAmount;
            $cumulativeBal = $balance_Fees;
        }

        // return $total_bal;
        $check_update = false;
        
        if ($cumulativeBal == 0) { // Corrected comparison
            // return '1';
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $payment_up = PaymentModel::where('sno', $id)->where('status','!=', 2)->first();
            $redeemValue = !is_null($coupon_id) ? (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0) : 0;
            if ($payment_up) {

                $payment_up->initialPayDate = $initialPayDateFormatted;
                $payment_up->paidAmount = $paidAmount;
                $payment_up->invoice_id = $invoice_id;
                $payment_up->payment_mode_label = $paymentMode;
                $payment_up->transaction = $transaction;
                $payment_up->status = 1;
                $payment_up->save(); // Save changes

                $check_update = true;

                $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
                $training = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
                // dd($training);
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                // Update or Create Training Model
                $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                $paidGst = $paidAmount * ($gstPercentage / 100);
                // return $paidAmount;
                TrainingModel::updateOrCreate(
                    ['payment_id' => $payment_up->payment_id],
                    [
                        'paid_amount' => $training->paid_amount + $paidAmount,
                        'paid_gst' => $training->paid_gst + $paidGst,
                        'balance_amount' => $training->balance_amount - $paidAmount - $redeemValue,
                        'balance_gst' => $training->balance_gst - $paidGst,
                        'overall_fees' => $training->overall_fees - $redeemValue,

                    ]
                );


                if ($redeemValue > 0) {
                    PaymentModel::where('payment_id', $payment_up->payment_id)
                        ->update([
                            'total_amount' => DB::raw("total_amount - {$redeemValue}")
                        ]);
                }
                if (!is_null($coupon_id)) {
                    DB::table('za_students_redeem')
                        ->where('sno', $coupon_id)
                        ->update([
                            'status' => 1
                        ]);
                }
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training->training_id;
                $add_subledger->subledger_desc = 'Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->traning_sno = $training->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();
                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                    $transaction_attach_sno = "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                    $transaction_attach_sno = $request_tr;
                }

                $attachments = [];

                if ($request->hasFile('attachements')) {

                  $upload_path = public_path('payment_attachments/' . $transaction_attach_sno);

                  if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                  }

                  foreach ($request->file('attachements') as $file) {

                    if (!$file) {
                        continue;
                    }

                    $original_name = $file->getClientOriginalName();

                    $extension = $file->getClientOriginalExtension();

                    $file_name = 'payment_' . time() . '_' . uniqid() . '.' . $extension;

                    $file->move($upload_path, $file_name);

                    $attachments[] = [

                        'file_name'      => $file_name,

                        'original_name'  => $original_name,

                        'file_extension' => $extension,

                        'file_path'      => 'payment_attachments/' . $transaction_attach_sno . '/' . $file_name

                    ];
                  }
                }

                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'ledger_id' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                        'invoice_id' => $invoice_id,
                        'receipt_id' => $receipt_id,
                        'training_id' => $training->sno,
                        'debit' => null,
                        'attachments' => !empty($attachments) ? json_encode($attachments) : NULL,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );


                if ($next_pay_date >= $initialPayDateFormatted) {
                  // return 'on time paymnet';
                  $pointsDataFullAttendance = $helper->get_points_by_id(19);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 19;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper == 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(20);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 20;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper > 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(21);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 21;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                 $this->sendNotification(
                    $branch_check->sno,
                    $customer->sno,
                    "Your Payment Successfully Paid",
                    "Web App",
                    $customer->sno
                );
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
        }else if ($total_bal  == $cumulativePay) {
            //  return '2';
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $payment_up = PaymentModel::where('sno', $id)->where('status','!=', 2)->first();
            $redeemValue = !is_null($coupon_id) ? (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0) : 0;
            if ($payment_up) {
              $payment_up->initialPayDate = $initialPayDateFormatted;
              $payment_up->paidAmount = $paidAmount;
              $payment_up->invoice_id = $invoice_id;
              $payment_up->payment_mode_label = $paymentMode;
              $payment_up->transaction = $transaction;
              $payment_up->status = 1;

              $payment_up->update();



              $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
              $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
              // return $training_id->paid_amount;
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

              // Update or Create Training Model
              $gstPercentage = $branch->gst_percentage ?? 0; // Default GST percentage to 0 if null
              $paidGst = $payment_up->paidAmount * ($gstPercentage / 100);

              TrainingModel::updateOrCreate(
                  ['payment_id' => $payment_up->payment_id],
                  [
                      'paid_amount' => $training_id->paid_amount + $payment_up->paidAmount,
                      'paid_gst' => $training_id->paid_gst + $paidGst,
                      'balance_amount' => $training_id->balance_amount - $payment_up->paidAmount - $redeemValue,
                      'balance_gst' => $training_id->balance_gst - $paidGst,
                      'total_amount' => $training_id->paid_amount + $payment_up->paidAmount + $paidGst,
                      'overall_fees' => $training_id->overall_fees - $redeemValue,

                    ]
                );


                if ($redeemValue > 0) {
                    PaymentModel::where('payment_id', $payment_up->payment_id)
                        ->update([
                            'total_amount' => DB::raw("total_amount - {$redeemValue}")
                        ]);
                }
                if (!is_null($coupon_id)) {
                    DB::table('za_students_redeem')
                        ->where('sno', $coupon_id)
                        ->update([
                            'status' => 1
                        ]);
                }

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->traning_sno = $training_id->sno;
              $add_subledger->created_by = $user_id;
              $add_subledger->updated_by = $user_id;

              $add_subledger->save();
              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                  $transaction_attach_sno = "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                  $transaction_attach_sno = $request_tr;
              }

              $attachments = [];

              if ($request->hasFile('attachements')) {

                $upload_path = public_path('payment_attachments/' . $transaction_attach_sno);

                if (!file_exists($upload_path)) {
                  mkdir($upload_path, 0777, true);
                }

                foreach ($request->file('attachements') as $file) {

                  if (!$file) {
                      continue;
                  }

                  $original_name = $file->getClientOriginalName();

                  $extension = $file->getClientOriginalExtension();

                  $file_name = 'payment_' . time() . '_' . uniqid() . '.' . $extension;

                  $file->move($upload_path, $file_name);

                  $attachments[] = [

                      'file_name'      => $file_name,

                      'original_name'  => $original_name,

                      'file_extension' => $extension,

                      'file_path'      => 'payment_attachments/' . $transaction_attach_sno . '/' . $file_name

                  ];
                }
              }

              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'attachments' => !empty($attachments) ? json_encode($attachments) : NULL,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $paidAmount,
                      'invoice_id' => $invoice_id,
                      'receipt_id' => $receipt_id,
                      'training_id' => $training_id->sno,
                      'debit' => null,
                      'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]
              );
              $check_update = true;
              $payment_all = PaymentModel::where('course_id', $pay_course_id)
              ->where('customer_id', $pay_customer_id)
              ->where(function ($query) {
                  $query->whereNull('paidAmount')->orWhere('paidAmount', 0);
              })
              ->get();

                if ($payment_all->isNotEmpty()) {
                    foreach ($payment_all as $payment) {
                        $payment->status = 2; // Close unused ones
                        $payment->save();
                    }
                }
          }

            if ($next_pay_date >= $initialPayDateFormatted) {
              $pointsDataFullAttendance = $helper->get_points_by_id(19);

              // Get points and reason for full attendance
              $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
              $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

              // Save new points for the student (full attendance)
              $newPointsFull = new StudentpointsModel();
              $newPointsFull->branch_id = $branch_id;
              $newPointsFull->student_id = $pay_customer_id;
              $newPointsFull->points_id = 19;
              $newPointsFull->points = $pointFull;
              $newPointsFull->reason = $reasonFull;

              // return $newPointsFull;
              $newPointsFull->save();

              // Update the student's available points in the CustomerModel
              $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

              if ($student_points) {
                  $student_points->points_score += $pointFull;
                  $student_points->save();
              }
            }
            if($customer->jumper_skiper == 1){
              $pointsDataFullAttendance = $helper->get_points_by_id(20);

              // Get points and reason for full attendance
              $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
              $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

              // Save new points for the student (full attendance)
              $newPointsFull = new StudentpointsModel();
              $newPointsFull->branch_id = $branch_id;
              $newPointsFull->student_id = $pay_customer_id;
              $newPointsFull->points_id = 20;
              $newPointsFull->points = $pointFull;
              $newPointsFull->reason = $reasonFull;

              // return $newPointsFull;
              $newPointsFull->save();

              // Update the student's available points in the CustomerModel
              $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

              if ($student_points) {
                  $student_points->points_score += $pointFull;
                  $student_points->save();
              }
            }
            if($customer->jumper_skiper > 1){
              $pointsDataFullAttendance = $helper->get_points_by_id(21);

              // Get points and reason for full attendance
              $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
              $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

              // Save new points for the student (full attendance)
              $newPointsFull = new StudentpointsModel();
              $newPointsFull->branch_id = $branch_id;
              $newPointsFull->student_id = $pay_customer_id;
              $newPointsFull->points_id = 21;
              $newPointsFull->points = $pointFull;
              $newPointsFull->reason = $reasonFull;

              // return $newPointsFull;
              $newPointsFull->save();

              // Update the student's available points in the CustomerModel
              $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

              if ($student_points) {
                  $student_points->points_score += $pointFull;
                  $student_points->save();
              }
            }

            $this->sendNotification(
                $branch_check->sno,
                $customer->sno,
                "Your Payment Successfully Paid",
                "Web App",
                $customer->sno
            );
        }else if ($cumulativeBal <= 0) {
          // return '3';
            $balanceNew = abs($request->balanceFees);
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $redeemValue = !is_null($coupon_id) ? (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0) : 0;
            $payment_id = PaymentModel::where('sno', $id)->where('status', 0)->first();
           $allPayments = PaymentModel::where('customer_id', $payment_id->customer_id)
              ->where('status', '!=', 2)
              ->orderBy('nextPayDate', 'ASC')
              ->get();
     
          $paymentsdetails = PaymentModel::where('customer_id', $payment_id->customer_id)->where('status', 0)->orderBy('nextPayDate', 'ASC')->get();
            if ($payment_id) {

                    $currentIndex = $paymentsdetails->search(fn($item) => $item->sno == $id);

                    // Get total already paid and total amount
                    $alreadyPaid = $paymentsdetails->sum('paidAmount');
                    $totalAmount = $payment_id->total_amount;

                    // Step 1: Apply ALL payment to current record's paidAmount (amount stays same)
                    $currentRecord = $paymentsdetails[$currentIndex];
                    $currentRecord->paidAmount = $paidAmount;
                    $currentRecord->status = 1;
                    $currentRecord->updated_by = $user_id;
                    $currentRecord->update();

                    // Step 2: Calculate excess and distribute to NEXT records by reducing their amount
                    $excessPayment = $currentRecord->paidAmount - $currentRecord->amount;

                    if ($excessPayment > 0) {
                        // Start from the record AFTER current
                        for ($i = $currentIndex + 1; $i < count($paymentsdetails) && $excessPayment > 0; $i++) {
                            $rec = $paymentsdetails[$i];

                            if ($rec->amount > 0) {
                                if ($excessPayment >= $rec->amount) {
                                    // This record is completely covered by excess
                                    $excessPayment -= $rec->amount;
                                    $rec->amount = 0;
                                    $rec->status = 2;
                                } else {
                                    // Partial coverage of this record
                                    $rec->amount -= $excessPayment;
                                    $excessPayment = 0;
                                    // $rec->status = 0;
                                }

                                $rec->updated_by = $user_id;
                                $rec->update();
                            }
                        }
                    }

                    // Step 3: Update balance fees sequentially
                    $this->updateBalanceFeesSequentially($allPayments, $totalAmount);

                    // Update current payment record with transaction details
                    $payment_id->initialPayDate = $initialPayDateFormatted;
                    $payment_id->invoice_id = $invoice_id;
                    $payment_id->payment_mode_label = $paymentMode;
                    $payment_id->transaction = $transaction;
                    $payment_id->paidAmount = $paidAmount;
                    $payment_id->updated_by = $user_id;
                    $payment_id->status = 1;
                    $payment_id->update();




                    $check_update = true;
                    $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                    $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                    // Update or Create Training Model
                    $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                    $paidGst = $paidAmount * ($gstPercentage / 100);

                    TrainingModel::updateOrCreate(
                        ['payment_id' => $payment_id->payment_id],
                        [
                            'paid_amount' => $training_id->paid_amount + $paidAmount,
                            'paid_gst' => $training_id->paid_gst + $paidGst,
                            'balance_amount' => $training_id->balance_amount - $paidAmount,
                            'balance_gst' => $training_id->balance_gst - $paidGst,
                            'total_amount' => $training_id->total_amount + $paidAmount + $paidGst,

                        ]
                    );

                if ($redeemValue > 0) {
                    PaymentModel::where('payment_id', $payment_id->payment_id)
                        ->update([
                            'total_amount' => DB::raw("total_amount - {$redeemValue}")
                        ]);
                }
                if (!is_null($coupon_id)) {
                    DB::table('za_students_redeem')
                        ->where('sno', $coupon_id)
                        ->update([
                            'status' => 1
                        ]);
                }
                $customer = CustomerModel::where('sno', $payment_id->customer_id)->first();
                $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB0001";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
                $add_subledger->subledger_desc = 'Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->traning_sno = $training_id->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();

                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA0001";
                    $transaction_attach_sno = "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                    $transaction_attach_sno = $request_tr;
                }
                
                $attachments = [];

                if ($request->hasFile('attachements')) {

                  $upload_path = public_path('payment_attachments/' . $transaction_attach_sno);

                  if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                  }

                  foreach ($request->file('attachements') as $file) {

                    if (!$file) {
                        continue;
                    }

                    $original_name = $file->getClientOriginalName();

                    $extension = $file->getClientOriginalExtension();

                    $file_name = 'payment_' . time() . '_' . uniqid() . '.' . $extension;

                    $file->move($upload_path, $file_name);

                    $attachments[] = [

                        'file_name'      => $file_name,

                        'original_name'  => $original_name,

                        'file_extension' => $extension,

                        'file_path'      => 'payment_attachments/' . $transaction_attach_sno . '/' . $file_name

                    ];
                  }
                }

                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'attachments' => !empty($attachments) ? json_encode($attachments) : NULL,
                        'ledger_id' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                        'invoice_id' => $invoice_id,
                        'receipt_id' => $receipt_id,
                        'training_id' => $training_id->sno,
                        'debit' => null,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );
                if ($next_pay_date >= $initialPayDateFormatted) {
                  $pointsDataFullAttendance = $helper->get_points_by_id(19);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 19;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper == 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(20);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 20;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper > 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(21);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 21;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                $this->sendNotification(
                    $branch_check->sno,
                    $customer->sno,
                    "Your Payment Successfully Paid",
                    "Web App",
                    $customer->sno
                );
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
        }else {
          //  return '4';
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $redeemValue = !is_null($coupon_id) ? (isset($redeemCoupon->redeem_value) && !empty($redeemCoupon->redeem_value) ? $redeemCoupon->redeem_value : 0) : 0;
            // return $redeemValue;
            $payment_id = PaymentModel::where('sno', $id)->where('status','!=', 2)->first();


            if ($payment_id) {
                $payment_up = new PaymentModel();
                $payment_up->payment_id = $payment_id->payment_id;
                $payment_up->customer_id = $payment_id->customer_id;
                $payment_up->course_id = $payment_id->course_id;
                $payment_up->initialPayDate = $payment_id->nextPayDate;
                $payment_up->nextPayDate = $payment_id->nextPayDate;
                $payment_up->amount = $balance_Fees - $redeemValue;
                $payment_up->paidAmount = 0;
                $payment_up->gst_amount = $balance_Fees * 0.18;
                $payment_up->payment_mode_label = null;
                $payment_up->transaction = $transaction;
                $payment_up->balanceFee = $payment_id->balanceFee - $payment_up->amount;
                $payment_up->total_amount = $payment_id->total_amount;
                $payment_up->created_by = $user_id;
                $payment_up->updated_by = $user_id;
                $payment_up->branch_id = $request->user()->branch_id;
                $payment_up->status = $balance_Fees < 0 ? 2:0;
                // return $payment_up;
                $payment_up->save(); // Save new record

                $check_update = true;

                if ($payment_up) {

                    $payment_id->initialPayDate = $initialPayDateFormatted;
                    $payment_id->paidAmount = $paidAmount;
                    $payment_id->invoice_id = $invoice_id;
                    $payment_id->gst_amount = $paidAmount * 0.18;
                    $payment_id->payment_mode_label = $paymentMode;
                    $payment_id->transaction = $transaction;
                    $payment_id->balanceFee = max(0, $payment_id->balanceFee - $paidAmount - $redeemValue);

                    $payment_id->status = 1;
                    // return $payment_id;
                    $payment_id->update(); // Save changes

                     $check_update = true;
                    $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                    $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                    // Update or Create Training Model
                    $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                    $paidGst = $paidAmount * ($gstPercentage / 100);

                    TrainingModel::updateOrCreate(
                        ['payment_id' => $payment_id->payment_id],
                        [
                            'paid_amount' => $training_id->paid_amount + $paidAmount,
                            'paid_gst' => $training_id->paid_gst + $paidGst,
                            'balance_amount' => $training_id->balance_amount - $paidAmount - $redeemValue,
                            'balance_gst' => $training_id->balance_gst - $paidGst,
                            'total_amount' => $training_id->total_amount + $paidAmount + $paidGst,
                            'overall_fees' => $training_id->overall_fees - $redeemValue,

                        ]
                    );


                    if ($redeemValue > 0) {
                        PaymentModel::where('payment_id', $payment_id->payment_id)
                            ->update([
                                'total_amount' => DB::raw("total_amount - {$redeemValue}")
                            ]);
                    }
                    if (!is_null($coupon_id)) {
                        DB::table('za_students_redeem')
                            ->where('sno', $coupon_id)
                            ->update([
                                'status' => 1
                            ]);
                    }

                }
                $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
                $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
                $add_subledger->subledger_desc = 'Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->traning_sno = $training_id->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();

                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                    $transaction_attach_sno = "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                    $transaction_attach_sno = $request_tr;
                }
                
                $attachments = [];

                if ($request->hasFile('attachements')) {

                  $upload_path = public_path('payment_attachments/' . $transaction_attach_sno);

                  if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                  }

                  foreach ($request->file('attachements') as $file) {

                    if (!$file) {
                        continue;
                    }

                    $original_name = $file->getClientOriginalName();

                    $extension = $file->getClientOriginalExtension();

                    $file_name = 'payment_' . time() . '_' . uniqid() . '.' . $extension;

                    $file->move($upload_path, $file_name);

                    $attachments[] = [

                        'file_name'      => $file_name,

                        'original_name'  => $original_name,

                        'file_extension' => $extension,

                        'file_path'      => 'payment_attachments/' . $transaction_attach_sno . '/' . $file_name

                    ];
                  }
                }

                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'attachments' => !empty($attachments) ? json_encode($attachments) : NULL,
                        'ledger_id' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                        'invoice_id' => $invoice_id,
                        'receipt_id' => $receipt_id,
                        'training_id' => $training_id->sno,
                        'debit' => null,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );
                if ($next_pay_date >= $initialPayDateFormatted) {
                  $pointsDataFullAttendance = $helper->get_points_by_id(19);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 19;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper == 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(20);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 20;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper > 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(21);

                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 21;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;

                  // return $newPointsFull;
                  $newPointsFull->save();

                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();

                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                 $this->sendNotification(
                    $branch_check->sno,
                    $customer->sno,
                    "Your Payment Successfully Paid",
                    "Web App",
                    $customer->sno
                );
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
        }

        if ($check_update) {
              $tempdate = PaymentModel::where('branch_id', $branch_id)->where('status','!=', 2)->where('customer_id', $customer->sno)->where('course_id', $pay_course_id)->orderBy('sno', 'desc')->first();
                //   Send Communication
                $branch_data = BranchModel::where('sno', $branch_id)->first();
                $branch_name = " ";
                if ($branch_data->branch_type == 1) {
                    $branch_name = $branch_data->branch_name;
                } elseif ($branch_data->branch_type == 2) {
                    $branch_name = $branch_data->franchise_name;
                }

                //   SMS
                $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
                $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
                $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
                $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
                $totalAmount      = $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0;

                if ($transaction_id && $customer_mobiles) {
                    $branch_data     = BranchModel::where('sno', $branch_id)->first();
                    $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '005_PaymentSuccess')->first();
                    $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
                    $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
                    $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
                    $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
                    $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $customer_mobiles;

                    // Replace placeholders with actual values
                    $replacement_values = [$customer_names, $totalAmount, $transaction_id];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);
                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);

                }
                // Email
                if ($transaction_id && $customer_mails) {
                    $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();

                    $email_template_id = 18; // thank you template
                    $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                    $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();

                    $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);

                    $helper             = new \App\Helpers\Helpers();
                    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                    $paymentDate        = date($common_date_format);
                    // $paymentDate        = $tempdate->initialPayDate;
                    $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                    $paymentAmount      = $paymentAmt . ". Rs";
                    $content            = $emailTemplate->email_subject;
                    $content            = str_replace('#name', $customer_names, $content);
                    $content            = str_replace('#course', $coursename->course_name ?? 'Course', $content);
                    $content            = str_replace('#transactionId', $transaction_id, $content);
                    $content            = str_replace('#amount', $paymentAmount, $content);
                    $content            = str_replace('#transactionDate', $paymentDate, $content);
                    $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
                    $branchNo           = $branch_data->mobile ?? '9677781155';
                    $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
                    $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                    $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                    $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                    $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

                    $mailData = [
                        'url'         => 'Eapl.com',
                        'subject'     => $dynamicSubject,
                        'content'     => $content,
                        'branchNo'    => $branchNo,
                        'branchemail' => $branchemail, // Use the message content from the request
                        'fbLink'      => $fbLink,      // Use the message content from the request
                        'instaLink'   => $instaLink,   // Use the message content from the request
                        'salesMobile' => $branch_data->sales_mobile ?? '9677781155',
                    ];

                    $to_address   = $customer_mails;
                    $from_address = 'elysiumacademy@elysium.community';
                    $from_name    = 'Elysium Academy®';

                    Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

                }
                // Whatsapp messages
                if ($transaction_id && $customer_mobiles) {
                    $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
                    $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                    $hasHeader  = false; // Example flag: set based on template
                    $hasBody    = false; // Example flag: set based on template
                    $components = [];
                    $couponCode = " ";

                    // Example flag: set based on template
                    $components_trans = [];
                    date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                    $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                               // $currentHour = date('H'); // Get current hour in 24-hour format
                    if ($currentHour >= 5 && $currentHour < 12) {
                        $greeting = 'Good Morning';
                    } elseif ($currentHour >= 12 && $currentHour < 18) {
                        $greeting = 'Good Afternoon';
                    } else {
                        $greeting = 'Good Evening';
                    }
                     $helper             = new \App\Helpers\Helpers();
                    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                    $paymentDate        = date($common_date_format);
                    // $paymentDate        = $tempdate->initialPayDate;
                    $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                    $paymentAmount      = $paymentAmt . ". Rs";

                    $templateName = 'elysium_academy_pay_transaction2';
                    $templateHeaderMediaId = '2177298459677656'; 
                    // $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
                    $headerImage = asset('assets/Payment_success.jpg');
                    $bodyText     = [
                        [
                            'type'           => 'text',
                            'text'           => $greeting,
                            'parameter_name' => 'greet_msg',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $customer_names,
                            'parameter_name' => 'customer_name',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $coursename->course_name ?? 'Course',
                            'parameter_name' => 'course_name',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $transaction_id,
                            'parameter_name' => 'transaction_id',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $paymentAmount,
                            'parameter_name' => 'amount',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $paymentDate,
                            'parameter_name' => 'pay_date',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $branch_data->cre_mobile ?? '9677781155',
                            'parameter_name' => 'contact_no',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                            'parameter_name' => 'contact_email',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $branch_name ?? 'Elysium Academy',
                            'parameter_name' => 'branch_name',
                        ],
                        [
                            'type'           => 'text',
                            'text'           => $branch_data->sales_mobile ?? '9677781155',
                            'parameter_name' => 'contact_no2',
                        ],

                    ];
                    $components_trans[] = [
                        'type'       => 'header',
                        'parameters' => [
                            [
                                'type'  => 'image',
                                // 'image' => [
                                //       'id' => $templateHeaderMediaId
                                //     ],
                                'image' => [
                                    'link' => $headerImage, // Dynamically set header image
                                ],
                            ],
                        ],
                    ];

                    $components_trans[] = [
                        'type'       => 'body',
                        'parameters' => $bodyText,
                    ];
                    $dynamicParameters         = $templateParameters[$templateName] ?? [];
                    $WhatsAppBusinessAccountId = $this->businessId;
                    $accessToken               = $this->accessToken;
                    $fromPhoneNumberId         = $this->phoneNumberId;

                    $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

                    $to           = $customer_mobiles;
                    $languageCode = 'en';

                    if (strpos($to, '+91') !== 0) {
                        $to = '+91' . $to;
                    }

                    $message = 'test~message';

                    $payload = [
                        'messaging_product' => 'whatsapp',
                        'to'                => $to,
                        'type'              => 'template',
                        'template'          => [
                            'name'       => $templateName,
                            'language'   => [
                                'code' => $languageCode,
                            ],
                            'components' => $components_trans,
                        ],
                    ];

                    $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

                }

        }

        return response([
            'status' => 200,
            'message' => 'Successfully Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    
      private function updateBalanceFeesSequentially($paymentsdetails, $totalAmount) {
      $runningBalance = $totalAmount;
 
      foreach ($paymentsdetails as $payment) {
          $payment->balanceFee = $runningBalance - $payment->paidAmount;
          $runningBalance = $payment->balanceFee;
          $payment->update();
      }
  }
      
  public function FreeScheduleUpdate($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'request_count' => 'required|numeric', // Ensure it's a numeric value
      'reason_request' => 'required|string',
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }

    $request_count  = $request->request_count;
    $reason_request = $request->reason_request;
    $course_id      = $request->course_id;
    $batch_id       = $request->batch_id;
    // return $batch_id;


    $upd_shd =  CustomerModel::where('sno', $id)->first();
    if ($upd_shd) {
      $upd_shd->request_count              = $request_count;
      $upd_shd->reason_request             = $reason_request;
      $upd_shd->free_status                = 1;
      $upd_shd->save(); // update

      return response([
        'status' => 200,
        'message' => 'Successfully Updated!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 404,
        'message' => 'Customer not found',
        'error_msg' => null,
        'data' => null,
      ], 200);
    }
  }
  public function RequestUpdate($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'status' => 'required|numeric', // Ensure it's a numeric value
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    }

    $free_status    = $request->status;
    $reason_reject  = $request->reason;
    $course_id      = $request->course_id;
    $batch_id       = $request->batch_id;
    // return $batch_id;
    // return $request;

    $upd_shd =  CustomerModel::where('sno', $id)->first();

    if ($free_status == 2) {
      $upd_shd->free_status               = $free_status;
      $upd_shd->reason_reject             = $reason_reject;
      $upd_shd->save(); // update

      // if ($upd_shd) {
      //     $upd_shd->free_status               = $free_status;
      //     $upd_shd->reason_reject             = $reason_reject;
      //     // $upd_shd->save(); // update
      // }

      return response([
        'status' => 200,
        'message' => 'Successfully Approved!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {

      $upd_shd->free_status               = $free_status;
      $upd_shd->reason_reject             = $reason_reject;
      $upd_shd->save(); // update


      return response([
        'status' => 200,
        'message' => 'Successfully Rejected',
        'error_msg' => null,
        'data' => null,
      ], 200);
    }
  }

//   public function Index(Request $request)
//   {
//     $branch_id = $request->user()->branch_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;

//     // return $branch_id;

//     $customers = CustomerModel::select(
//       'za_customer.sno',
//       'za_customer.add_course',
//       'za_customer.cus_name',
//       'za_customer.cus_pic',
//       'za_customer.customer_id',
//       'za_customer.cus_gender',
//       'za_customer.cus_dob',
//       'za_customer.doj',
//       'za_customer.cus_mobile',
//       'za_customer.cus_alternate_mobile',
//       'za_customer.cus_email_id',
//       'za_customer.cus_marital_status',
//       'za_customer.country',
//       'za_customer.state',
//       'za_customer.city',
//       'za_customer.address',
//       'za_customer.course_id',
//       'za_course.course_name',
//       'za_course.course_duration',
//       'za_course.course_code',
//       'za_course_subcategory.course_subcategory_name',
//       'za_course_type.course_type_name',
//       'za_customer.free_shd_count',
//       'za_customer.request_count',
//       'za_customer.reason_request',
//       'za_customer.free_status',
//       'za_customer.reason_reject',
//       'za_customer.created_by',
//       'za_customer.batch_id',
//       'za_customer.is_placement',
//       'za_lead.sno as lead_id',
//       'za_batch.batch_name',
//       'za_batch.start_date',
//       'za_batch.end_date',
//       'za_lead.created_by as lead_created_by',
//       'lead_staff.staff_name as lead_staff_name',
//       'za_slot.slot_name',
//       'za_staff.staff_name',
//       'za_staff.sno as staff_sno',
//       'za_branch.min_prd_cost',
//       //   'za_training.course_mode_id',
//       DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
//       DB::raw('MAX(za_payment.total_amount) as total_amount'),
//       DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
//       DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'), // Count of course_id
//       DB::raw('MAX(IFNULL(otp_data.app_installed, 0)) AS app_installed'),
//       DB::raw('MAX(IFNULL(points_sum.daily_points_sum, 0)) AS daily_points')
//     )
//       ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
//       ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
//       ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
//       ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
//       ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
//       ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
//       //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
//       ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
//       ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
//       /* --------- LATEST OTP = app_installed --------- */

//       ->leftJoin(DB::raw("

//         (

//               SELECT mx.user_id, 1 AS app_installed

//               FROM (
//                   SELECT user_id, MAX(sno) AS last_otp_id

//                   FROM za_otp

//                   GROUP BY user_id

//               ) mx

//           ) AS otp_data

//       "), 'otp_data.user_id', '=', 'za_customer.sno')

//       /* --------- POINTS SUM CLEAN --------- */

//       ->leftJoin(DB::raw("

//       (

//         SELECT student_id AS cust_ref, SUM(points) AS daily_points_sum

//               FROM za_students_points

//               GROUP BY student_id

//           ) AS points_sum

//       "), 'points_sum.cust_ref', '=', 'za_customer.sno')



//       ->where('za_customer.branch_id', $branch_id)
//       ->groupBy(
//         'za_customer.sno',
//         'za_customer.cus_name',
//         'za_customer.cus_pic',
//         'za_customer.customer_id',
//         'za_customer.cus_gender',
//         'za_customer.cus_dob',
//         'za_lead.created_by',
//         'lead_staff.staff_name',
//         'za_customer.doj',
//         'za_customer.cus_mobile',
//         'za_customer.cus_alternate_mobile',
//         'za_customer.cus_email_id',
//         'za_customer.cus_marital_status',
//         'za_customer.country',
//         'za_customer.state',
//         'za_customer.city',
//         'za_customer.address',
//         'za_customer.course_id',
//         // 'za_training.course_mode_id',
//         'za_customer.free_shd_count',
//         'za_customer.request_count',
//         'za_customer.free_status',
//         'za_customer.reason_request',
//         'za_customer.reason_reject',
//         'za_customer.created_by',
//         'za_customer.batch_id',
//         'za_customer.is_placement',
//         'za_lead.sno',
//         'za_customer.add_course',
//         'za_course.course_name',
//         'za_course.course_duration',
//         'za_course.course_code',
//         'za_course_subcategory.course_subcategory_name',
//         'za_course_type.course_type_name',
//         'za_batch.batch_name',
//         'za_batch.start_date',
//         'za_batch.end_date',
//         'za_slot.slot_name',
//         'za_staff.staff_name',
//         'za_staff.sno',
//         'za_branch.min_prd_cost'
//       )
//       ->where('za_customer.status', 0)
//       ->orderBy('za_customer.sno', 'desc')
//       ->paginate($perpage);

//     // $customers = $customers->unique('payment_id');

//     $allCourseIds = [];



//     foreach ($customers as $item) {
//       $courseIds = json_decode($item->add_course, true);
//       if (is_array($courseIds)) {
//         $allCourseIds = array_merge($allCourseIds, $courseIds);
//       }
//     }

//     // Remove duplicates
//     $allCourseIds = array_unique($allCourseIds);

//     // Fetch all course details at once
//     $courses = DB::table('za_course')
//       ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
//       ->whereIn('za_course.sno', $allCourseIds)
//       ->select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name')
//       ->get()
//       ->keyBy('sno');


//     // return $courses;

//     // Attach course details to each customer
//     foreach ($customers as $item) {
//       $courseIds = json_decode($item->add_course, true);
//       // return $courseIds;
//       $itemCourses = [];
//       // return $itemCourses;

//       if (is_array($courseIds)) {
//         foreach ($courseIds as $id) {
//           if (isset($courses[$id])) {
//             $itemCourses[] = $courses[$id];
//           }
//         }
//       }

//       $item->courses = $itemCourses;
//       // return $item->courses;
//       $item->course_count = count($itemCourses);
//     }

//     $customers_fill = CustomerModel::select(
//       'za_customer.sno',
//       'za_customer.cus_name',
//       'za_customer.cus_pic',
//       'za_customer.customer_id',
//       'za_customer.doj',
//       'za_customer.cus_gender',
//       'za_customer.cus_dob',
//       'za_customer.cus_mobile',
//       'za_customer.cus_alternate_mobile',
//       'za_customer.cus_email_id',
//       'za_customer.cus_marital_status',
//       'za_customer.country',
//       'za_customer.state',
//       'za_customer.city',
//       'za_customer.address',
//       'za_customer.course_id',
//       'za_customer.free_shd_count',
//       'za_customer.request_count',
//       'za_customer.reason_request',
//       'za_customer.free_status',
//       'za_customer.reason_reject',
//       'za_customer.created_by',
//       'za_customer.batch_id',
//       'za_customer.is_placement',
//       'za_lead.sno as lead_id',
//       'za_batch.batch_name',
//       'za_batch.start_date',
//       'za_batch.end_date',
//       'za_course_type.course_type_name',
//       'za_course.course_name',
//       'za_slot.slot_name',
//       'za_staff.staff_name',
//       'za_staff.sno as staff_sno',
//       'za_branch.min_prd_cost',
//       'za_training.course_mode_id',
//       DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
//       DB::raw('MAX(za_payment.total_amount) as total_amount'),
//       DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
//       DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
//     )
//       ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
//       ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
//       ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
//       ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
//       ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
//       ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
//       ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
//       ->where('za_customer.branch_id', $branch_id)
//       ->groupBy(
//         'za_customer.sno',
//         'za_customer.cus_name',
//         'za_customer.cus_pic',
//         'za_customer.customer_id',
//         'za_customer.doj',
//         'za_customer.cus_gender',
//         'za_customer.cus_dob',
//         'za_customer.cus_mobile',
//         'za_customer.cus_alternate_mobile',
//         'za_customer.cus_email_id',
//         'za_customer.cus_marital_status',
//         'za_customer.country',
//         'za_customer.state',
//         'za_customer.city',
//         'za_customer.address',
//         'za_customer.course_id',
//         'za_training.course_mode_id',
//         'za_customer.free_shd_count',
//         'za_customer.request_count',
//         'za_customer.free_status',
//         'za_customer.reason_request',
//         'za_customer.reason_reject',
//         'za_customer.created_by',
//         'za_customer.batch_id',
//         'za_customer.is_placement',
//         'za_lead.sno',
//         'za_course.course_name',
//         'za_batch.batch_name',
//         'za_batch.start_date',
//         'za_batch.end_date',
//         'za_course_type.course_type_name',
//         'za_slot.slot_name',
//         'za_staff.staff_name',
//         'za_staff.sno',
//         'za_branch.min_prd_cost'
//       )
//       ->where('za_customer.status', 0)
//       ->orderBy('za_customer.sno', 'desc')
//       ->get();


//     // Initialize counters for each category

//     $activeCount = 0;

//     $notYetStartedCount = 0;

//     $inactiveCount = 0;

//     $dropCount = 0;


//     $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
//       // Initialize flags for the conditions
//       $allActive = false;
//       $allCusDrop = false;
//       $allEndDate = false;

//       $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
//       $carouselDetails = [];

//       // Initialize internship eligibility flag
//       $intern_eligible = 0;
//       $totalPaid = 0;

//       // Get payment details and course info
//       $paymentDetailss = DB::table('za_payment')
//         ->select('za_payment.status', 'za_payment.nextPayDate')
//         ->where('za_payment.customer_id', $item->sno)
//         ->where('za_payment.status', 0)
//         ->get();

//       $paymentget = DB::table('za_training')
//         ->where('customer_id', $item->sno)
//         ->whereIn('status', [0, 2])
//         ->get();

//       $courseIds = $paymentget;
//       $batchIds = json_decode($item->batch_id);

//       // Flags for tracking customer status
//       $isActive = false;
//       $isDropped = false;
//       $isNotStarted = true; // Assume the customer is not started by default
//       $isInactive = false;
//       $isSchedule = false;

//       foreach ($courseIds as $index => $courseId) {
//         $batchId = $batchIds[$index] ?? [];

//         // Retrieve course details
//         $course = DB::table('za_course')
//           ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//           ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course.sno', 'za_course.course_type_id', 'za_course_type.online_fee')
//           ->where('za_course.sno', $courseId->course_id)
//           ->first();

//         // Check internship eligibility for this course
//          if ($course && $courseId->batch_id > 0) {
//           // Check if course qualifies for internship (tesbo_check == 2 OR course_type_id == 3)
//           $qualifiesForInternship = ($courseId->tesbo_check == 2) || ($course->course_type_id == 3);

//           if ($qualifiesForInternship) {
//             // Get payment records for this course
//             $payments = DB::table('za_payment')
//               ->where('customer_id', $item->sno)  // Fixed: use $item->sno instead of $courseId->sno
//               ->where('payment_id', $courseId->payment_id)
//               ->get();

//             if ($payments->isNotEmpty()) {
//               $totalAmount = $payments->first()->total_amount;
//               $totalPaid = $payments->sum('paidAmount');

//               // Check if customer has paid the full amount
//               if ($totalPaid >= $totalAmount) {
//                 $intern_eligible = 1;
//                 $totalPaid = $totalPaid; // Eligible for at least one course
//                 // No break here because we want to continue checking other courses
//                 // But we can add course-specific eligibility if needed
//               } else {
//                 $intern_eligible = 0;
//                 $totalPaid = $totalPaid;
//               }
//               // If not fully paid, we don't set intern_eligible to 0 here
//               // because other courses might make them eligible
//             }
//           }
//         }






//         // Retrieve batch details
//         $batch = DB::table('za_batch')
//           ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
//           ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
//           ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
//           ->where('za_batch.sno', $courseId->batch_id)
//           ->first();

//         // Retrieve payment details
//         $paymentDetails = DB::table('za_training')
//           ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
//           ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
//           ->where('za_training.customer_id', $item->sno)
//           ->where('za_training.course_id', $courseId->course_id)
//           ->where('za_training.status', '!=', 3)
//           ->where('za_payment.status', '!=', 3)
//           ->where('za_training.status', '!=', 1)
//           ->where('za_payment.status', '!=', 2)
//           ->groupBy('za_payment.total_amount')
//           ->first();

//         $paymentPercentage = 0;
//         if ($paymentDetails && $paymentDetails->total_amount > 0) {
//           $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
//           if ($paymentPercentage >= 100) {

//             $paymentPercentage = 100;
//           }
//         }

//         // Check if attendance exists for the specific batch and customer
//         $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
//           ->where('batch_id', $batchId)
//           ->where('attendance', 'P')
//           ->get();

//         // Initialize course progress percentage
//         $courseProgress = 0;
//         $topicCount = 0;
//         $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
//           ->count();

//         $helper = new \App\Helpers\Helpers();
//         $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);


//         //   if ($attendanceRecords->isNotEmpty()) {
//         //       foreach ($attendanceRecords as $attendance) {
//         //           $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchId)
//         //             //   ->whereDate('date', $attendance->att_date)
//         //               ->get();

//         //           if ($syllabusUpdates->isNotEmpty()) {
//         //               foreach ($syllabusUpdates as $syllabusUpdate) {
//         //                   if ($syllabusUpdate->percentage == 100) {
//         //                       $topicCount++;
//         //                   }
//         //               }
//         //           }
//         //       }

//         //       if ($course_topic_count > 0) {
//         //           $courseProgress = ($topicCount / $course_topic_count) * 100;
//         //       }
//         //       if ($courseProgress > 100) {
//         //           $courseProgress = 100;
//         //       }

//         //       $courseProgress = number_format($courseProgress, 2);
//         //   }

//         // batch count by course id
//         $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();


//         //*************************************************************************************

//         $currentDate = date('Y-m-d');
//         $allActive = false;
//         $allCusDrop = true;
//         $allEndDate = true;
//         $allSchedule = false;

//         $start_date = $batch->start_date ?? null;
//         $end_date  = $batch->end_date ?? null;

//         if ($start_date <= $currentDate && $start_date != null) {
//           $allActive = true;
//           //   break;
//         }
//         if ($courseId->status != 2) {
//           $allCusDrop = false;
//           //   break;
//         }
//         if (isset($end_date) && $end_date < $currentDate) {
//           $allEndDate = false;
//           //  break;
//         }
//         if (isset($start_date) && $start_date > $currentDate) {
//           $allSchedule = true; //  break;
//         }


//         if ($allActive && !$allCusDrop) {
//           $isActive = true;  // Customer is active
//         } elseif (!$allActive && !$allCusDrop && !$allSchedule) {
//           $isNotStarted = true;  // Customer is not yet started
//         } elseif ($allSchedule && !$allActive && !$allCusDrop) {
//           $isSchedule = true;  // Customer is inactive
//         } elseif ($allCusDrop) {
//           $isDropped = true;  // Customer is dropped
//         } elseif ($allEndDate) {
//           $isInactive = true;  // Customer is inactive
//         }

//         $certificate = null;
//         $cert_status_id = null;
//         $cert_status_name = null;
//         $cert_status_bg = null;
//         $cert_status_color = null;

//         if (DB::table('za_manage_certificate')->where('batch_id', $courseId->batch_id)->exists()) {
//           $certificate = DB::table('za_manage_certificate')
//             ->select('za_manage_certificate.cert_status_id', 'za_certificate_status.certificate_status_name', 'za_certificate_status.bg_color', 'za_certificate_status.text_color')
//             ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
//             ->where('za_manage_certificate.batch_id', $courseId->batch_id)
//             ->first();

//           $cert_status_id = $certificate->cert_status_id ?? null;
//           $cert_status_name = $certificate->certificate_status_name ?? null;
//           $cert_status_bg = $certificate->bg_color ?? null;
//           $cert_status_color = $certificate->text_color ?? null;
//         }

//         // Add course and batch details to the array
//         $carouselDetails[] = [
//           'course_sno' => $courseId->course_id ?? null,
//           'course_mode_id' => $courseId->course_mode_id ?? null,
//           'online_course_fee' => $course->online_fee ?? null,
//           'batch_sno' =>  $courseId->batch_id  ?? $batchId,
//           'batch_count' => $batch_count ?? 0,
//           'traning_sno' => $courseId->sno ?? null,
//           'traning_status' => $courseId->status ?? null,
//           'course_name' => $course->course_name ?? null,
//           'course_type_name' => $course->course_type_name ?? null,
//           'batch_name' => $batch->batch_name ?? null,
//           'start_date' => $batch->start_date ?? null,
//           'end_date' => $batch->end_date ?? null,
//           'slot_name' => $batch->slot_name ?? null,
//           'staff_name' => $batch->staff_name ?? null,
//           'payment_percentage' => $paymentPercentage,
//           'course_progress' => $courseProgress,
//           'cert_status_id' => $cert_status_id ?? null,
//           'certificate_status_name' => $cert_status_name ?? null,
//           'certificate_status_bg' => $cert_status_bg ?? null,
//           'certificate_status_color' => $cert_status_color ?? null,
//         ];
//       }

//       // Store internship eligibility in the customer object
//       $item->intern_eligible = $intern_eligible;
//       // Increment customer count based on status
//       if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
//         $activeCount++;
//       } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
//         $notYetStartedCount++;
//       } elseif ($isDropped) {
//         $dropCount++;
//       } elseif ($isSchedule) {
//         $inactiveCount++;
//       }

//       // Attach data to the customer item
//       $item->carousel_details = $carouselDetails;
//       $item->paymentDetailss = $paymentDetailss;
//       $item->all_active = $isActive;
//       $item->all_cus_drop = $isDropped;
//       $item->all_end_date = $isInactive;
//       $item->all_schedule = $isSchedule;

//       $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
//     //   $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
//      $item->payment_percentage = ($item->total_amount > 0)
//       ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
//       : 0;

//       return $item;
//     });

//     $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();

//     // alagu
//     // current month customer
//     $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
//       ->where('za_customer.branch_id', $branch_id)
//       ->whereYear('za_customer.created_at', date('Y'))
//       ->whereMonth('za_customer.created_at', date('m'))
//       ->get();

//     $currentMonthCustomerCount = 0;
//     $total_business_amount     = 0;
//     $total_payment             = 0;
//     $total_paid_payment        = 0;

//     if ($currentMonthCustomer->isNotEmpty()) {
//       $currentMonthCustomerCount = $currentMonthCustomer->count();
//       foreach ($currentMonthCustomer as $customer) {
//         $courseIds = json_decode($customer->course_id, true);
//         foreach ($courseIds as $courseId) {
//           // Fetch the course's maximum price
//           $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
//           $total_payment += $payment;
//           // Fetch the total paid amount for the course
//           $paid_payment = PaymentModel::where('customer_id', $customer->sno)
//             ->where('course_id', $courseId)
//             ->where('status', 1)
//             ->sum('paidAmount');
//           $total_paid_payment += $paid_payment;
//         }
//       }
//     }

//     // Calculate averages
//     $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
//     $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
//     $percentageover = 0;

//     $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
//     if ($branch_id != 0) {
//       $totalLeadCounts->where('za_lead.branch_id', $branch_id);
//     }
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', auth()->user()->user_id)->count();
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data (no additional filters needed)

//     }
//     $totalLeadCount = $totalLeadCounts->count();

//     $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
//     if ($branch_id != 0) {
//       $totalCustomerCount->where('za_customer.branch_id', $branch_id);
//     }
//     $totalCustomerCount = $totalCustomerCount->count();

//     if ($totalLeadCount > 0) {
//       $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
//     }

//     $percentageover = round($percentageover) . '%';

//     $leadOriginal = DB::table('za_customer')
//       ->where('za_customer.branch_id', $branch_id)
//       ->where('za_customer.created_by', '!=', 0)
//       ->where('za_customer.status', 0);

//     $leadOriginalCount = 0;
//     $leadOriginalCount = $leadOriginal->count();


//     // coversion rate current month
//     // Get the count of leads for the current month
//     $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
//     if ($branch_id != 0) {
//       $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
//     }
//     $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
//       ->whereMonth('created_at', date('m'))
//       ->count();
//     $percentagecurrentmonth = 0;
//     if ($currentMonthLeadCount > 0) {
//       $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
//     }

//     $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

//     $branch_id = $request->user()->branch_id;
//     $helper = new \App\Helpers\Helpers();
//     if ($branch_id > 0) {
//       $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
//     } else {
//       $get_course_change_days =  0;
//     }


//     $batch_Data = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       // ->whereNotNull('za_training.start_date')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     $dropCount = 0;
//     $activeCount = 0;
//     $notYetStartedCount = 0;
//     $scheduleCount = 0;

//     $processed_drop_customers = [];
//     $processed_active_customers = [];
//     $processed_schedule_customers = [];
//     $processed_not_started_customers = [];

//     foreach ($batch_Data as $singledata) {
//       if (in_array($singledata->customer_id, $processed_drop_customers)) {
//         continue;
//       }
//       if ($singledata->status == "2") {
//         $dropCount++;
//         $processed_drop_customers[] = $singledata->customer_id;
//       }
//     }

//     $batch_active_Data = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->whereNotNull('za_training.start_date')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     foreach ($batch_active_Data as $singledata) {
//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (in_array($singledata->customer_id, $processed_active_customers)) {
//           continue;
//         }
//         if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
//           $activeCount++;
//           $processed_active_customers[] = $singledata->customer_id;
//         }
//       }
//     }


//     $batch_Data_old = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     // return  $processed_active_customers;
//     foreach ($batch_Data_old as $singledata) {

//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (!in_array($singledata->customer_id, $processed_active_customers)) {
//           if (in_array($singledata->customer_id, $processed_schedule_customers)) {
//             continue;
//           }
//           if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
//             $scheduleCount++;
//             $processed_schedule_customers[] = $singledata->customer_id;
//           }
//         }
//       }
//     }
//     // return $processed_schedule_customers;


//     $batch_notyetStated = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();

//     foreach ($batch_notyetStated as $singledata) {

//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (!in_array($singledata->customer_id, $processed_active_customers)) {
//           if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
//             if (in_array($singledata->customer_id, $processed_not_started_customers)) {
//               continue;
//             }
//             if ($singledata->start_date === null) {
//               $notYetStartedCount++;
//               $processed_not_started_customers[] = $singledata->customer_id;
//             }
//           }
//         }
//       }
//     }

//     $reasonList_hold = HoldReasonModel::select('*')->where('status', '!=', 2)->get();

//     $app_result = CustomerModel::from('za_customer')
//     ->leftJoin(DB::raw("
//         (
//             SELECT user_id, 1 AS app_installed
//             FROM (
//                 SELECT user_id, MAX(sno) AS last_otp_id
//                 FROM za_otp
//                 GROUP BY user_id
//             ) mx
//         ) AS otp_data
//     "), 'otp_data.user_id', '=', 'za_customer.sno')

//     ->leftJoin(DB::raw("
//         (
//             SELECT student_id, SUM(points) AS daily_points
//             FROM za_students_points
//             GROUP BY student_id
//         ) AS points_sum
//     "), 'points_sum.student_id', '=', 'za_customer.sno')

//     ->where('za_customer.branch_id', $branch_id)
//     ->where('za_customer.status', 0)

//     ->selectRaw("
//         COUNT(*) AS total_customers,
//         SUM(IF(IFNULL(otp_data.app_installed,0)=1,1,0)) AS total_app_installed,
//         SUM(IF(IFNULL(otp_data.app_installed,0)=0,1,0)) AS total_app_not_installed,
//         SUM(IFNULL(points_sum.daily_points,0)) AS total_daily_points
//     ")
//     ->first();

//     $total_appinstalled_count = isset($app_result->total_app_installed) && !empty($app_result->total_app_installed) ? (int)$app_result->total_app_installed : 0;
//     $total_appnotinstalled_count = isset($app_result->total_app_not_installed) && !empty($app_result->total_app_not_installed) ? (int)$app_result->total_app_not_installed : 0;

//     // return $customers;
//     return view('content.customer.customer_list', [
//       'customers' => $customers,
//       'customers_list' => $customers_list,
//       'customer_name_fill' => '',
//       'cus_fill' => '',
//       'staff_fill' => '',
//       'status_fill' => '',
//       'course_type_list' => $course_type_list,
//       'course_type_fill' => '',
//       'leadOriginalCount' => $leadOriginalCount,
//       'course_list' => $course_list,
//       'batch_list' => $batch_list,
//       'staff_list' => $staff_list,
//       'activeCount' => $activeCount,
//       'scheduleCount' => $scheduleCount,
//       'notYetStartedCount' => $notYetStartedCount,
//       'inactiveCount' => $inactiveCount,
//       'dropCount' => $dropCount,
//       'percentageover' => $percentageover,
//       'batch_name_fill' => '',
//       'slot_list' => $slot_list,
//       'perpage' => $perpage,
//       'slot_name_fill' => '',
//       'slot_type_list' => $slot_type_list,
//       'slot_type_name_fill' => '',
//       'course_name_fill' => '',
//       'date_filter' => '',
//       'fin_yr_fill' => '',
//       'reasonList_hold' => $reasonList_hold,
//       'gender_fill' => '',
//       'currentMonthCustomerCount' => $currentMonthCustomerCount,
//       'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
//       'average_business_value' => $averageBusinessValue,
//       'average_collection_value' => $averageCollectionValue,
//       'total_appinstalled_count' => $total_appinstalled_count,
//       'total_appnotinstalled_count' => $total_appnotinstalled_count,
//       'course_change_count' => $get_course_change_days
//     ])->with('filter_on', false);
//   }

//   public function list_filter(Request $request)
//   {

//     $branch_id = $request->user()->branch_id;
//     $page = $request->input('page', 1);
//     $perpage = (int) $request->input('sorting_filter', 25);
//     $offset = ($page - 1) * $perpage;
//     $helper = new \App\Helpers\Helpers();

//     // return $request;
//     if ($branch_id) {
//       $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
//     } else {
//       $get_branch_type = 0;
//     }
//     $cus_fill = $request->cus_fill ?? '';
//     $customer_name_fill = $request->customer_name_fill_sno ?? '';
//     $staff_fill = $request->staff_name_fill_sno ?? '';
//     $status_fill = $request->input('status_fill', 'all');
//     $mobile_fill = $request->mobile_fill ?? '';
//     $gender_fill = $request->gender_fill ?? '';
//     $course_type_fill = $request->course_type_fill_sno ?? '';
//     $course_name_fill = $request->course_name_fill_sno ?? '';
//     $batch_name_fill = $request->batch_name_fill_sno ?? '';
//     $slot_name_fill = $request->slot_name_fill_sno ?? '';
//     $slot_type_name_fill = $request->slot_type_name_fill ?? '';
//     $date_filter = $request->dt_fill_issue_rpt;
//     $from_date_filter = $request->from_date_fillter_textbox;
//     $to_date_filter = $request->to_date_fillter_textbox;
//     $fin_yr_fill = $request->fin_yr_fill ?? '';

//     // return $request;
//     $query = CustomerModel::select(
//       'za_customer.sno',
//       'za_customer.cus_name',
//       'za_customer.cus_pic',
//       'za_customer.customer_id',
//       'za_customer.cus_gender',
//       'za_customer.cus_dob',
//       'za_customer.doj',
//       'za_customer.cus_mobile',
//       'za_customer.cus_alternate_mobile',
//       'za_customer.cus_email_id',
//       'za_customer.cus_marital_status',
//       'za_customer.country',
//       'za_customer.state',
//       'za_customer.city',
//       'za_customer.address',
//       'za_customer.course_id',
//       'za_customer.free_shd_count',
//       'za_customer.request_count',
//       'za_customer.reason_request',
//       'za_customer.free_status',
//       'za_customer.reason_reject',
//       'za_customer.created_by',
//       'za_customer.batch_id',
//       'za_customer.is_placement',
//       'za_lead.sno as lead_id',
//       'za_lead.created_by as lead_created_by',
//       'lead_staff.staff_name as lead_staff_name',
//       'za_batch.batch_name',
//       'za_batch.start_date',
//       'za_batch.end_date',
//       'za_course_type.course_type_name',
//       'za_course.course_name',
//       'za_slot.slot_name',
//       //   'za_training.course_mode_id',
//       'za_staff.staff_name',
//       'za_staff.sno as staff_sno',
//       'za_branch.min_prd_cost',
//       DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
//       DB::raw('MAX(za_payment.total_amount) as total_amount'),
//       DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
//       DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'),
//       DB::raw('MAX(IFNULL(otp_data.app_installed, 0)) AS app_installed'),
//       DB::raw('MAX(IFNULL(points_sum.daily_points_sum, 0)) AS daily_points')
//     )
//       ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
//       ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//       ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
//       ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
//       ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
//       ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
//       ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
//       ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
//       //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
//       ->leftJoin(DB::raw("

//         (

//               SELECT mx.user_id, 1 AS app_installed

//               FROM (
//                   SELECT user_id, MAX(sno) AS last_otp_id

//                   FROM za_otp

//                   GROUP BY user_id

//               ) mx

//           ) AS otp_data

//       "), 'otp_data.user_id', '=', 'za_customer.sno')

//       /* --------- POINTS SUM CLEAN --------- */

//       ->leftJoin(DB::raw("

//       (

//         SELECT student_id AS cust_ref, SUM(points) AS daily_points_sum

//               FROM za_students_points

//               GROUP BY student_id

//           ) AS points_sum

//       "), 'points_sum.cust_ref', '=', 'za_customer.sno')
//       ->where('za_customer.status', 0)
//       ->where('za_customer.branch_id', $branch_id)
//       ->groupBy(
//         'za_customer.sno',
//         'za_customer.cus_name',
//         'za_customer.cus_pic',
//         'za_customer.customer_id',
//         'za_customer.cus_gender',
//         'za_customer.cus_dob',
//         'za_customer.doj',
//         'za_customer.cus_mobile',
//         'za_customer.cus_alternate_mobile',
//         'za_customer.cus_email_id',
//         'za_customer.cus_marital_status',
//         'za_customer.country',
//         'za_customer.state',
//         'za_customer.city',
//         'za_customer.address',
//         'za_customer.course_id',
//         'za_customer.free_shd_count',
//         'za_customer.request_count',
//         // 'za_training.course_mode_id',
//         'za_customer.free_status',
//         'za_customer.reason_request',
//         'za_customer.reason_reject',
//         'za_customer.created_by',
//         'za_customer.batch_id',
//         'za_customer.is_placement',
//         'za_lead.sno',
//         'za_lead.created_by',
//         'lead_staff.staff_name',
//         'za_course.course_name',
//         'za_batch.batch_name',
//         'za_batch.start_date',
//         'za_batch.end_date',
//         'za_course_type.course_type_name',
//         'za_slot.slot_name',
//         'za_staff.staff_name',
//         'za_staff.sno',
//         'za_branch.min_prd_cost'

//       )
//       ->orderBy('za_customer.sno', 'desc');
//     // date filter query
//     // Date Filtering Logic
//     if ($date_filter == "today") {
//       $todayDate = date("Y-m-d");
//       $query->whereDate('za_customer.created_at', $todayDate);
//     } elseif ($date_filter == "week") {
//       $today = date('l');
//       if ($today == "Sunday") {
//         $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
//         $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
//       } else {
//         $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
//         $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
//       }
//       $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
//     } elseif ($date_filter == "monthly") {
//       $firstDayOfMonth = date('Y-m-01');
//       $lastDayOfMonth = date('Y-m-t');
//       $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
//     } elseif ($date_filter == "custom_date") {
//       if ($from_date_filter && $to_date_filter) {
//         $fromDate = date('Y-m-d', strtotime($from_date_filter));
//         $toDate = date('Y-m-d', strtotime($to_date_filter));
//         $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
//       } elseif ($from_date_filter) {
//         $fromDate = date('Y-m-d', strtotime($from_date_filter));
//         $query->where('za_customer.created_at', '>=', $fromDate);
//       } elseif ($to_date_filter) {
//         $toDate = date('Y-m-d', strtotime($to_date_filter));
//         $query->where('za_customer.created_at', '<=', $toDate);
//       }
//     }
//     // Financial year filter
//     if ($fin_yr_fill) {
//       $helper = new \App\Helpers\Helpers();
//       $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

//       if ($selected_fin_year) {
//         // Decode the financial month as an array
//         $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];

//         // Check if $monthsArray is valid
//         if (is_array($monthsArray) && count($monthsArray) > 0) {
//           $currentYear = now()->year; // Current year

//           // Filter leads that match any of the selected months
//           $leads->where(function ($q) use ($monthsArray, $currentYear) {
//             $q->whereYear('za_customer.created_at', $currentYear)
//               ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
//           });
//         }
//       }
//     }

//     if ($branch_id > 0) {
//       $query->where('za_customer.branch_id', $branch_id);
//     }

//     if ($cus_fill) {
//       $query->where(function ($customer) use ($cus_fill) {
//         $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
//           ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
//           ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
//       });
//     }
//     if ($customer_name_fill) {
//       $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
//     }
//     if ($mobile_fill) {
//       $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
//     }
//     if ($gender_fill) {
//       $query->where('za_customer.cus_gender', $gender_fill);
//     }
//     if ($course_type_fill) {
//       $query->where('za_course_type.sno', $course_type_fill);
//     }
//     if ($course_name_fill) {
//       $query->where('za_course.sno', $course_name_fill);
//     }
//     if ($staff_fill) {
//       $query->where('za_staff.sno', $staff_fill);
//     }
//     if ($batch_name_fill) {
//       $query->where('za_batch.sno', $batch_name_fill);
//     }
//     if ($slot_name_fill) {
//       $query->where('za_slot.sno', $slot_name_fill);
//     }
//     if ($slot_type_name_fill) {
//       $query->where('za_slot_type.sno', $slot_type_name_fill);
//     }

//     if ($request->has('app_installed')) {
//       if ($request->app_installed == 1) {
//         $query->whereRaw('IFNULL(otp_data.app_installed,0) = 1');
//       } elseif ($request->app_installed == 0) {
//         $query->whereRaw('IFNULL(otp_data.app_installed,0) = 0');
//       }
//     }
  

//     // Fetch Branch list ordered by sno in descending order
//     $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
//     // Initialize counters for each category
//     $activeCount = 0;
//     $notYetStartedCount = 0;
//     $inactiveCount = 0;
//     $dropCount = 0;
//     $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
//       // Initialize flags for the conditions
//       $allActive = false;
//       $allCusDrop = false;
//       $allEndDate = false;
//       $intern_eligible = 0;
//       $totalPaid = 0;
//       $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
//       $carouselDetails = [];

//       // Get payment details and course info
//       $paymentDetailss = DB::table('za_payment')
//         ->select('za_payment.status', 'za_payment.nextPayDate')
//         ->where('za_payment.customer_id', $item->sno)
//         ->where('za_payment.status', 0)
//         ->get();

//       $paymentget = DB::table('za_training')
//         ->where('customer_id', $item->sno)
//         ->whereIn('status', [0, 2])
//         ->get();

//       $courseIds = $paymentget;
//       $batchIds = json_decode($item->batch_id);

//       // Flags for tracking customer status
//       $isActive = false;
//       $isDropped = false;
//       $isNotStarted = true; // Assume the customer is not started by default
//       $isInactive = false;
//       $isSchedule = false;

//       foreach ($courseIds as $index => $courseId) {
//         $batchId = $batchIds[$index] ?? [];

//         // Retrieve course details
//         $course = DB::table('za_course')
//           ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
//           ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course.sno', 'za_course.course_type_id', 'za_course_type.online_fee')
//           ->where('za_course.sno', $courseId->course_id)
//           ->first();

//         // Check internship eligibility for this course
//          if ($course && $courseId->batch_id > 0) {
//           // Check if course qualifies for internship (tesbo_check == 2 OR course_type_id == 3)
//           $qualifiesForInternship = ($courseId->tesbo_check == 2) || ($course->course_type_id == 3);

//           if ($qualifiesForInternship) {
//             // Get payment records for this course
//             $payments = DB::table('za_payment')
//               ->where('customer_id', $item->sno)  // Fixed: use $item->sno instead of $courseId->sno
//               ->where('payment_id', $courseId->payment_id)
//               ->get();

//             if ($payments->isNotEmpty()) {
//               $totalAmount = $payments->first()->total_amount;
//               $totalPaid = $payments->sum('paidAmount');

//               // Check if customer has paid the full amount
//               if ($totalPaid >= $totalAmount) {
//                 $intern_eligible = 1;
//                 $totalPaid = $totalPaid; // Eligible for at least one course
//                 // No break here because we want to continue checking other courses
//                 // But we can add course-specific eligibility if needed
//               } else {
//                 $intern_eligible = 0;
//                 $totalPaid = $totalPaid;
//               }
//               // If not fully paid, we don't set intern_eligible to 0 here
//               // because other courses might make them eligible
//             }
//           }
//         }

//         // Retrieve batch details
//         $batch = DB::table('za_batch')
//           ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
//           ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
//           ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
//           ->where('za_batch.sno', $courseId->batch_id)
//           ->first();

//         // Retrieve payment details
//         $paymentDetails = DB::table('za_training')
//           ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
//           ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
//           ->where('za_training.customer_id', $item->sno)
//           ->where('za_training.course_id', $courseId->course_id)
//           ->where('za_training.status', '!=', 3)
//           ->whereNotIn('za_payment.status', [3, 2])
//           ->where('za_training.status', '!=', 1)
//           ->where('za_payment.status', '!=', 2)
//           ->where('za_payment.paidAmount', '>', 0)
//           ->groupBy('za_payment.total_amount')
//           ->first();

//         $paymentPercentage = 0;
//         if ($paymentDetails && $paymentDetails->total_amount > 0) {
//           $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
//           if ($paymentPercentage >= 100) {

//             $paymentPercentage = 100;
//           }
//         }

//         // Check if attendance exists for the specific batch and customer
//         $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
//           ->where('batch_id', $batchId)
//           ->where('attendance', 'P')
//           ->get();

//         // Initialize course progress percentage
//         $courseProgress = 0;
//         $topicCount = 0;
//         $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
//           ->count();
//         $helper = new \App\Helpers\Helpers();
//         $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
//         //   if ($attendanceRecords->isNotEmpty()) {
//         //       foreach ($attendanceRecords as $attendance) {
//         //           $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchId)
//         //               ->whereDate('date', $attendance->att_date)
//         //               ->get();

//         //           if ($syllabusUpdates->isNotEmpty()) {
//         //               foreach ($syllabusUpdates as $syllabusUpdate) {
//         //                   if ($syllabusUpdate->percentage == 100) {
//         //                       $topicCount++;
//         //                   }
//         //               }
//         //           }
//         //       }

//         //       if ($course_topic_count > 0) {
//         //           $courseProgress = ($topicCount / $course_topic_count) * 100;
//         //       }
//         //       if ($courseProgress > 100) {
//         //           $courseProgress = 100;
//         //       }

//         //       $courseProgress = number_format($courseProgress, 2);
//         //   }

//         // batch count by course id
//         $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();

//         // Set customer status based on conditions
//         //*************************************************************************************

//         $currentDate = date('Y-m-d');
//         $allActive = false;
//         $allCusDrop = true;
//         $allEndDate = true;
//         $allSchedule = false;

//         $start_date = $batch->start_date ?? null;
//         $end_date  = $batch->end_date ?? null;

//         if ($start_date <= $currentDate && $start_date != null) {
//           $allActive = true;
//           //   break;
//         }
//         if ($courseId->status != 2) {
//           $allCusDrop = false;
//           //   break;
//         }
//         if (isset($end_date) && $end_date < $currentDate) {
//           $allEndDate = false;
//           //  break;
//         }
//         if (isset($start_date) && $start_date > $currentDate) {
//           $allSchedule = true; //  break;
//         }


//         if ($allActive && !$allCusDrop) {
//           $isActive = true;  // Customer is active
//         } elseif (!$allActive && !$allCusDrop && !$allSchedule) {
//           $isNotStarted = true;  // Customer is not yet started
//         } elseif ($allSchedule && !$allActive && !$allCusDrop) {
//           $isSchedule = true;  // Customer is inactive
//         } elseif ($allCusDrop) {
//           $isDropped = true;  // Customer is dropped
//         } elseif ($allEndDate) {
//           $isInactive = true;  // Customer is inactive
//         }

//         $certificate = null;
//         $cert_status_id = null;
//         $cert_status_name = null;
//         $cert_status_bg = null;
//         $cert_status_color = null;

//         if (DB::table('za_manage_certificate')->where('batch_id', $courseId->batch_id)->exists()) {
//           $certificate = DB::table('za_manage_certificate')
//             ->select('za_manage_certificate.cert_status_id', 'za_certificate_status.certificate_status_name', 'za_certificate_status.bg_color', 'za_certificate_status.text_color')
//             ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
//             ->where('za_manage_certificate.batch_id', $courseId->batch_id)
//             ->first();

//           $cert_status_id = $certificate->cert_status_id ?? null;
//           $cert_status_name = $certificate->certificate_status_name ?? null;
//           $cert_status_bg = $certificate->bg_color ?? null;
//           $cert_status_color = $certificate->text_color ?? null;
//         }

//         // Add course and batch details to the array
//         $carouselDetails[] = [
//           'course_sno' => $courseId->course_id ?? null,
//           'course_mode_id' => $courseId->course_mode_id ?? null,
//           'online_course_fee' => $course->online_fee ?? null,
//           'batch_sno' =>  $courseId->batch_id  ?? $batchId,
//           'batch_count' => $batch_count ?? 0,
//           'traning_sno' => $courseId->sno ?? null,
//           'traning_status' => $courseId->status ?? null,
//           'course_name' => $course->course_name ?? null,
//           'course_type_name' => $course->course_type_name ?? null,
//           'batch_name' => $batch->batch_name ?? null,
//           'start_date' => $batch->start_date ?? null,
//           'end_date' => $batch->end_date ?? null,
//           'slot_name' => $batch->slot_name ?? null,
//           'staff_name' => $batch->staff_name ?? null,
//           'payment_percentage' => $paymentPercentage,
//           'course_progress' => $courseProgress,
//           'cert_status_id' => $cert_status_id ?? null,
//           'certificate_status_name' => $cert_status_name ?? null,
//           'certificate_status_bg' => $cert_status_bg ?? null,
//           'certificate_status_color' => $cert_status_color ?? null,
//         ];
//       }

//       $item->intern_eligible = $intern_eligible;
//       // Increment customer count based on status
//       if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
//         $activeCount++;
//       } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
//         $notYetStartedCount++;
//       } elseif ($isDropped) {
//         $dropCount++;
//       } elseif ($isSchedule) {
//         $inactiveCount++;
//       }

//       // Attach data to the customer item
//       $item->carousel_details = $carouselDetails;
//       $item->paymentDetailss = $paymentDetailss;
//       $item->all_active   = $isActive;
//       $item->all_cus_drop = $isDropped;
//       $item->all_end_date = $isInactive;
//       $item->all_schedule = $isSchedule;

//       $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
//     //   $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
//      $item->payment_percentage = ($item->total_amount > 0)
//       ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
//       : 0;

//       return $item;
//     });

//     if ($status_fill) {
//       if ($status_fill == 'active') {
//         $customers = $customers->filter(function ($item) {
//           return $item->all_active && !$item->all_cus_drop;
//         });
//       } elseif ($status_fill == 'not_started') {
//         $customers = $customers->filter(function ($item) {
//           return !$item->all_active && !$item->all_cus_drop;
//         });
//       } elseif ($status_fill == 'drop') {
//         $customers = $customers->filter(function ($item) {
//           return $item->all_cus_drop;
//         });
//       } elseif ($status_fill == 'inactive') {
//         $customers = $customers->filter(function ($item) {
//           return $item->all_end_date;
//         });
//       }
//     }

//     session()->forget('branch_id_ses');
//     session()->forget('branch_type_ses');
//     $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
//     $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();


//     // alagu
//     $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
//       ->where('za_customer.branch_id', $branch_id)
//       ->whereYear('za_customer.created_at', date('Y'))
//       ->whereMonth('za_customer.created_at', date('m'))
//       ->get();

//     $currentMonthCustomerCount = 0;
//     $total_business_amount     = 0;
//     $total_payment             = 0;
//     $total_paid_payment        = 0;

//     if ($currentMonthCustomer->isNotEmpty()) {
//       $currentMonthCustomerCount = $currentMonthCustomer->count();
//       foreach ($currentMonthCustomer as $customer) {
//         $courseIds = json_decode($customer->course_id, true);
//         foreach ($courseIds as $courseId) {
//           // Fetch the course's maximum price
//           $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
//           $total_payment += $payment;
//           // Fetch the total paid amount for the course
//           $paid_payment = PaymentModel::where('customer_id', $customer->sno)
//             ->where('course_id', $courseId)
//             ->where('status', 1)
//             ->sum('paidAmount');
//           $total_paid_payment += $paid_payment;
//         }
//       }
//     }

//     // Calculate averages
//     $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
//     $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
//     $branch_id = $request->user()->branch_id;
//     $helper = new \App\Helpers\Helpers();
//     if ($branch_id > 0) {
//       $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
//     } else {
//       $get_course_change_days =  0;
//     }

//     $percentageover = 0;

//     $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
//     if ($branch_id != 0) {
//       $totalLeadCounts->where('za_lead.branch_id', $branch_id);
//     }
//     if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
//       // User can only view their own data
//       $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
//     } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
//       // User can view all data (no additional filters needed)

//     }
//     $totalLeadCount = $totalLeadCounts->count();

//     $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
//     if ($branch_id != 0) {
//       $totalCustomerCount->where('za_customer.branch_id', $branch_id);
//     }
//     $totalCustomerCount = $totalCustomerCount->count();

//     if ($totalLeadCount > 0) {
//       $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
//     }

//     $percentageover = round($percentageover) . '%';

//     $leadOriginal = DB::table('za_customer')
//       ->where('za_customer.branch_id', $branch_id)
//       ->where('za_customer.created_by', '!=', 0)
//       ->where('za_customer.status', 0);

//     $leadOriginalCount = 0;
//     $leadOriginalCount = $leadOriginal->count();
//     $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
//     if ($branch_id != 0) {
//       $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
//     }
//     $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
//       ->whereMonth('created_at', date('m'))
//       ->count();
//     $percentagecurrentmonth = 0;
//     if ($currentMonthLeadCount > 0) {
//       $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
//     }

//     $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

//     $batch_Data = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       // ->whereNotNull('za_training.start_date')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     $dropCount = 0;
//     $activeCount = 0;
//     $notYetStartedCount = 0;
//     $scheduleCount = 0;

//     $processed_drop_customers = [];
//     $processed_active_customers = [];
//     $processed_schedule_customers = [];
//     $processed_not_started_customers = [];

//     foreach ($batch_Data as $singledata) {
//       if (in_array($singledata->customer_id, $processed_drop_customers)) {
//         continue;
//       }
//       if ($singledata->status == "2") {
//         $dropCount++;
//         $processed_drop_customers[] = $singledata->customer_id;
//       }
//     }

//     $batch_active_Data = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->whereNotNull('za_training.start_date')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     foreach ($batch_active_Data as $singledata) {
//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (in_array($singledata->customer_id, $processed_active_customers)) {
//           continue;
//         }
//         if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
//           $activeCount++;
//           $processed_active_customers[] = $singledata->customer_id;
//         }
//       }
//     }


//     $batch_Data_old = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();


//     // return  $processed_active_customers;
//     foreach ($batch_Data_old as $singledata) {

//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (!in_array($singledata->customer_id, $processed_active_customers)) {
//           if (in_array($singledata->customer_id, $processed_schedule_customers)) {
//             continue;
//           }
//           if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
//             $scheduleCount++;
//             $processed_schedule_customers[] = $singledata->customer_id;
//           }
//         }
//       }
//     }
//     // return $processed_schedule_customers;


//     $batch_notyetStated = DB::table('za_training')
//       ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->where('za_training.branch_id', $branch_id)
//       ->where('za_customer.status', 0)
//       ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
//       ->get();

//     foreach ($batch_notyetStated as $singledata) {

//       if (!in_array($singledata->customer_id, $processed_drop_customers)) {
//         if (!in_array($singledata->customer_id, $processed_active_customers)) {
//           if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
//             if (in_array($singledata->customer_id, $processed_not_started_customers)) {
//               continue;
//             }
//             if ($singledata->start_date === null) {
//               $notYetStartedCount++;
//               $processed_not_started_customers[] = $singledata->customer_id;
//             }
//           }
//         }
//       }
//     }

//     $reasonList_hold = HoldReasonModel::select('*')->where('status', '!=', 2)->get();

//     $app_result = CustomerModel::from('za_customer')
//     ->leftJoin(DB::raw("
//         (
//             SELECT user_id, 1 AS app_installed
//             FROM (
//                 SELECT user_id, MAX(sno) AS last_otp_id
//                 FROM za_otp
//                 GROUP BY user_id
//             ) mx
//         ) AS otp_data
//     "), 'otp_data.user_id', '=', 'za_customer.sno')

//     ->leftJoin(DB::raw("
//         (
//             SELECT student_id, SUM(points) AS daily_points
//             FROM za_students_points
//             GROUP BY student_id
//         ) AS points_sum
//     "), 'points_sum.student_id', '=', 'za_customer.sno')

//     ->where('za_customer.branch_id', $branch_id)
//     ->where('za_customer.status', 0)

//     ->selectRaw("
//         COUNT(*) AS total_customers,
//         SUM(IF(IFNULL(otp_data.app_installed,0)=1,1,0)) AS total_app_installed,
//         SUM(IF(IFNULL(otp_data.app_installed,0)=0,1,0)) AS total_app_not_installed,
//         SUM(IFNULL(points_sum.daily_points,0)) AS total_daily_points
//     ")
//     ->first();

//     $total_appinstalled_count = isset($app_result->total_app_installed) && !empty($app_result->total_app_installed) ? (int)$app_result->total_app_installed : 0;
//     $total_appnotinstalled_count = isset($app_result->total_app_not_installed) && !empty($app_result->total_app_not_installed) ? (int)$app_result->total_app_not_installed : 0;

//     // return $customers;
//     return view('content.customer.customer_list', [
//       'customers' => $customers,
//       'customers_list' => $customers_list,
//       'course_type_list' => $course_type_list,
//       'course_list' => $course_list,
//       'batch_list' => $batch_list,
//       'staff_list' => $staff_list,
//       'perpage' => $perpage,
//       'scheduleCount' => $scheduleCount,
//       'slot_list' => $slot_list,
//       'slot_type_list' => $slot_type_list,
//       'login_branch_id' => $branch_id,
//       'login_branch_type' => $get_branch_type,
//       'cus_fill' => $cus_fill,
//       'staff_fill' => $staff_fill,
//       'status_fill' => $status_fill,
//       'activeCount' => $activeCount,
//       'notYetStartedCount' => $notYetStartedCount,
//       'inactiveCount' => $inactiveCount,
//       'dropCount' => $dropCount,
//       'leadOriginalCount' => $leadOriginalCount,
//       'percentageover' => $percentageover,
//       'customer_name_fill' => $customer_name_fill,
//       'mobile_fill' => $mobile_fill,
//       'gender_fill' => $gender_fill,
//       'course_type_fill' => $course_type_fill,
//       'course_name_fill' => $course_name_fill,
//       'batch_name_fill' => $batch_name_fill,
//       'slot_name_fill' => $slot_name_fill,
//       'slot_type_name_fill' => $slot_type_name_fill,
//       'date_filter' => $date_filter,
//       'from_date_filter' => $from_date_filter,
//       'to_date_filter' => $to_date_filter,
//       'fin_yr_fill' => $fin_yr_fill,
//       'reasonList_hold' => $reasonList_hold,
//       'currentMonthCustomerCount' => $currentMonthCustomerCount,
//       'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
//       'average_business_value' => $averageBusinessValue,
//       'average_collection_value' => $averageCollectionValue,
//       'total_appinstalled_count' => $total_appinstalled_count,
//       'total_appnotinstalled_count' => $total_appnotinstalled_count,
//       'course_change_count' => $get_course_change_days

//     ])->with('filter_on', true);
//   }

      public function Index(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $helper = new \App\Helpers\Helpers();
 
      // Check if filters are applied
      $isFiltered = $request->hasAny([
          'cus_fill', 'customer_name_fill_sno', 'staff_name_fill_sno',
          'status_fill', 'mobile_fill', 'gender_fill', 'course_type_fill_sno',
          'course_name_fill_sno', 'batch_name_fill_sno', 'slot_name_fill_sno',
          'slot_type_name_fill', 'dt_fill_issue_rpt', 'fin_yr_fill', 'app_installed'
      ]);
 
      // Build the query
      $query = CustomerModel::select(
          'za_customer.sno',
          'za_customer.add_course',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_course.course_name',
          'za_course.course_duration',
          'za_course.course_code',
          'za_course_subcategory.course_subcategory_name',
          'za_course_type.course_type_name',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.reason_request',
          'za_customer.free_status',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_customer.is_placement',
          'za_lead.sno as lead_id',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_lead.created_by as lead_created_by',
          'lead_staff.staff_name as lead_staff_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno as staff_sno',
          'za_branch.min_prd_cost',
          DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
          DB::raw('MAX(za_payment.total_amount) as total_amount'),
          DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'),
          DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'),
          DB::raw('MAX(IFNULL(otp_data.app_installed, 0)) AS app_installed'),
          DB::raw('MAX(IFNULL(points_sum.daily_points_sum, 0)) AS daily_points')
      )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
      ->leftJoin(DB::raw("
          (
              SELECT mx.user_id, 1 AS app_installed
              FROM (
                  SELECT user_id, MAX(sno) AS last_otp_id
                  FROM za_otp
                  GROUP BY user_id
              ) mx
          ) AS otp_data
      "), 'otp_data.user_id', '=', 'za_customer.sno')
      ->leftJoin(DB::raw("
          (
              SELECT student_id AS cust_ref, SUM(points) AS daily_points_sum
              FROM za_students_points
              GROUP BY student_id
          ) AS points_sum
      "), 'points_sum.cust_ref', '=', 'za_customer.sno')
      ->where('za_customer.status', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
          'za_customer.sno',
          'za_customer.add_course',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_customer.is_placement',
          'za_lead.sno',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_course.course_name',
          'za_course.course_duration',
          'za_course.course_code',
          'za_course_subcategory.course_subcategory_name',
          'za_course_type.course_type_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
      )
      ->orderBy('za_customer.sno', 'desc');
 
      // ============== APPLY FILTERS ==============
      if ($isFiltered) {
          // Date filter
          $date_filter = $request->dt_fill_issue_rpt;
          $from_date_filter = $request->from_date_fillter_textbox;
          $to_date_filter = $request->to_date_fillter_textbox;
 
          if ($date_filter == "today") {
              $query->whereDate('za_customer.created_at', date("Y-m-d"));
          } elseif ($date_filter == "week") {
              $today = date('l');
              if ($today == "Sunday") {
                  $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                  $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
              } else {
                  $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                  $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
              }
              $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
              $query->whereBetween('za_customer.created_at', [date('Y-m-01'), date('Y-m-t')]);
          } elseif ($date_filter == "custom_date") {
              if ($from_date_filter && $to_date_filter) {
                  $query->whereBetween('za_customer.created_at', [
                      date('Y-m-d', strtotime($from_date_filter)),
                      date('Y-m-d', strtotime($to_date_filter))
                  ]);
              } elseif ($from_date_filter) {
                  $query->where('za_customer.created_at', '>=', date('Y-m-d', strtotime($from_date_filter)));
              } elseif ($to_date_filter) {
                  $query->where('za_customer.created_at', '<=', date('Y-m-d', strtotime($to_date_filter)));
              }
          }
 
          // Financial year filter
          if ($fin_yr_fill = $request->fin_yr_fill) {
              $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
              if ($selected_fin_year) {
                  $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
                  if (is_array($monthsArray) && count($monthsArray) > 0) {
                      $currentYear = now()->year;
                      $query->whereYear('za_customer.created_at', $currentYear)
                            ->whereIn(DB::raw('MONTH(za_customer.created_at)'), $monthsArray);
                  }
              }
          }
 
          // Search filters
          if ($cus_fill = $request->cus_fill) {
              $query->where(function ($q) use ($cus_fill) {
                  $q->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
                    ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
                    ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
              });
          }
 
          if ($request->customer_name_fill_sno) {
              $query->where('za_customer.sno', $request->customer_name_fill_sno);
          }
 
          if ($request->mobile_fill) {
              $query->where('za_customer.cus_mobile', 'LIKE', "%{$request->mobile_fill}%");
          }
 
          if ($request->gender_fill) {
              $query->where('za_customer.cus_gender', $request->gender_fill);
          }
 
          if ($request->course_type_fill_sno) {
              $query->where('za_course_type.sno', $request->course_type_fill_sno);
          }
 
          if ($request->course_name_fill_sno) {
              $query->where('za_course.sno', $request->course_name_fill_sno);
          }
 
          if ($request->staff_name_fill_sno) {
              $query->where('za_staff.sno', $request->staff_name_fill_sno);
          }
 
          if ($request->batch_name_fill_sno) {
              $query->where('za_batch.sno', $request->batch_name_fill_sno);
          }
 
          if ($request->slot_name_fill_sno) {
              $query->where('za_slot.sno', $request->slot_name_fill_sno);
          }
 
          if ($request->slot_type_name_fill) {
              $query->where('za_slot_type.sno', $request->slot_type_name_fill);
          }
 
          if ($request->has('app_installed')) {
              if ($request->app_installed == 1) {
                  $query->whereRaw('IFNULL(otp_data.app_installed,0) = 1');
              } elseif ($request->app_installed == 0) {
                  $query->whereRaw('IFNULL(otp_data.app_installed,0) = 0');
              }
          }
      }
 
      // Get paginated results - NO RETURN HERE!
      $customers = $query->paginate($perpage);
 
      // ============== PROCESS COURSES ==============
      $allCourseIds = [];
      foreach ($customers as $item) {
          $courseIds = json_decode($item->add_course, true);
          if (is_array($courseIds)) {
              $allCourseIds = array_merge($allCourseIds, $courseIds);
          }
      }
      $allCourseIds = array_unique($allCourseIds);
 
      $courses = DB::table('za_course')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
          ->whereIn('za_course.sno', $allCourseIds)
          ->select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name')
          ->get()
          ->keyBy('sno');
 
      foreach ($customers as $item) {
          $courseIds = json_decode($item->add_course, true);
          $itemCourses = [];
          if (is_array($courseIds)) {
              foreach ($courseIds as $id) {
                  if (isset($courses[$id])) {
                      $itemCourses[] = $courses[$id];
                  }
              }
          }
          $item->courses = $itemCourses;
          $item->course_count = count($itemCourses);
      }
 
      // ============== TRANSFORM CUSTOMERS ==============
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
 
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
          $allActive = false;
          $allCusDrop = false;
          $allEndDate = false;
          $intern_eligible = 0;
          $totalPaid = 0;
          $currentDate = date('d-M-Y');
          $carouselDetails = [];
 
          $paymentDetailss = DB::table('za_payment')
              ->select('za_payment.status', 'za_payment.nextPayDate')
              ->where('za_payment.customer_id', $item->sno)
              ->where('za_payment.status', 0)
              ->get();
 
          $paymentget = DB::table('za_training')
              ->where('customer_id', $item->sno)
              ->whereIn('status', [0, 2])
              ->get();
 
          $courseIds = $paymentget;
          $batchIds = json_decode($item->batch_id);
 
          $isActive = false;
          $isDropped = false;
          $isNotStarted = true;
          $isInactive = false;
          $isSchedule = false;
 
          foreach ($courseIds as $index => $courseId) {
              $batchId = $batchIds[$index] ?? [];
 
              $course = DB::table('za_course')
                  ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                  ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course.sno', 'za_course.course_type_id', 'za_course_type.online_fee')
                  ->where('za_course.sno', $courseId->course_id)
                  ->first();
 
              if ($course) {
                  $qualifiesForInternship = ($courseId->tesbo_check == 2) || ($course->course_type_id == 3);
                  if ($qualifiesForInternship) {
                      $payments = DB::table('za_payment')
                          ->where('customer_id', $item->sno)
                          ->where('course_id', $course->sno)
                          ->get();
 
                      if ($payments->isNotEmpty()) {
                          $totalAmount = $payments->first()->total_amount;
                          $totalPaid = $payments->sum('paidAmount');
                          if ($totalPaid >= $totalAmount) {
                              $intern_eligible = 1;
                          }
                      }
                  }
              }
 
              $batch = DB::table('za_batch')
                  ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                  ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                  ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                  ->where('za_batch.sno', $courseId->batch_id)
                  ->first();
 
              $paymentDetails = DB::table('za_training')
                  ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                  ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                  ->where('za_training.customer_id', $item->sno)
                  ->where('za_training.course_id', $courseId->course_id)
                  ->where('za_training.status', '!=', 3)
                  ->where('za_payment.status', '!=', 3)
                  ->where('za_training.status', '!=', 1)
                  ->where('za_payment.status', '!=', 2)
                  ->groupBy('za_payment.total_amount')
                  ->first();
 
              $paymentPercentage = 0;
              if ($paymentDetails && $paymentDetails->total_amount > 0) {
                  $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                  if ($paymentPercentage >= 100) {
                      $paymentPercentage = 100;
                  }
              }
 
              $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                  ->where('batch_id', $batchId)
                  ->where('attendance', 'P')
                  ->get();
 
              $courseProgress = 0;
              $topicCount = 0;
              $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)->count();
              $helper = new \App\Helpers\Helpers();
              $courseProgress = $helper->get_course_percentage($courseId->sno, $item->sno);
 
              $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
 
              $currentDate = date('Y-m-d');
              $allActive = false;
              $allCusDrop = true;
              $allEndDate = true;
              $allSchedule = false;
 
              $start_date = $batch->start_date ?? null;
              $end_date = $batch->end_date ?? null;
 
              if ($start_date <= $currentDate && $start_date != null) {
                  $allActive = true;
              }
              if ($courseId->status != 2) {
                  $allCusDrop = false;
              }
              if (isset($end_date) && $end_date < $currentDate) {
                  $allEndDate = false;
              }
              if (isset($start_date) && $start_date > $currentDate) {
                  $allSchedule = true;
              }
 
              if ($allActive && !$allCusDrop) {
                  $isActive = true;
              } elseif (!$allActive && !$allCusDrop && !$allSchedule) {
                  $isNotStarted = true;
              } elseif ($allSchedule && !$allActive && !$allCusDrop) {
                  $isSchedule = true;
              } elseif ($allCusDrop) {
                  $isDropped = true;
              } elseif ($allEndDate) {
                  $isInactive = true;
              }
 
              $certificate = null;
              $cert_status_id = null;
              $cert_status_name = null;
              $cert_status_bg = null;
              $cert_status_color = null;
 
              if (DB::table('za_manage_certificate')->where('batch_id', $courseId->batch_id)->exists()) {
                  $certificate = DB::table('za_manage_certificate')
                      ->select('za_manage_certificate.cert_status_id', 'za_certificate_status.certificate_status_name', 'za_certificate_status.bg_color', 'za_certificate_status.text_color')
                      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
                      ->where('za_manage_certificate.batch_id', $courseId->batch_id)
                      ->first();
 
                  $cert_status_id = $certificate->cert_status_id ?? null;
                  $cert_status_name = $certificate->certificate_status_name ?? null;
                  $cert_status_bg = $certificate->bg_color ?? null;
                  $cert_status_color = $certificate->text_color ?? null;
              }
 
              $carouselDetails[] = [
                  'course_sno' => $courseId->course_id ?? null,
                  'course_mode_id' => $courseId->course_mode_id ?? null,
                  'online_course_fee' => $course->online_fee ?? null,
                  'batch_sno' => $courseId->batch_id ?? $batchId,
                  'batch_count' => $batch_count ?? 0,
                  'traning_sno' => $courseId->sno ?? null,
                  'traning_status' => $courseId->status ?? null,
                  'course_name' => $course->course_name ?? null,
                  'course_type_name' => $course->course_type_name ?? null,
                  'batch_name' => $batch->batch_name ?? null,
                  'start_date' => $batch->start_date ?? null,
                  'end_date' => $batch->end_date ?? null,
                  'slot_name' => $batch->slot_name ?? null,
                  'staff_name' => $batch->staff_name ?? null,
                  'payment_percentage' => $paymentPercentage,
                  'course_progress' => $courseProgress,
                  'cert_status_id' => $cert_status_id ?? null,
                  'certificate_status_name' => $cert_status_name ?? null,
                  'certificate_status_bg' => $cert_status_bg ?? null,
                  'certificate_status_color' => $cert_status_color ?? null,
              ];
          }
 
          $item->intern_eligible = $intern_eligible;
 
          if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
              $activeCount++;
          } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
              $notYetStartedCount++;
          } elseif ($isDropped) {
              $dropCount++;
          } elseif ($isSchedule) {
              $inactiveCount++;
          }
 
          $item->carousel_details = $carouselDetails;
          $item->paymentDetailss = $paymentDetailss;
          $item->all_active = $isActive;
          $item->all_cus_drop = $isDropped;
          $item->all_end_date = $isInactive;
          $item->all_schedule = $isSchedule;
 
          $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
          $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
 
          return $item;
      });
 
      // ============== APPLY STATUS FILTER AFTER TRANSFORM ==============
      $status_fill = $request->input('status_fill', 'all');
      if ($status_fill !== 'all' && $status_fill !== '' && $isFiltered) {
          $filteredCustomers = $customers->filter(function ($item) use ($status_fill) {
              if ($status_fill == 'active') {
                  return $item->all_active && !$item->all_cus_drop;
              } elseif ($status_fill == 'not_started') {
                  return !$item->all_active && !$item->all_cus_drop && !$item->all_schedule;
              } elseif ($status_fill == 'drop') {
                  return $item->all_cus_drop;
              } elseif ($status_fill == 'inactive') {
                  return $item->all_end_date;
              }
              return true;
          });
 
          // Re-paginate the filtered results
          $customers = new \Illuminate\Pagination\LengthAwarePaginator(
              $filteredCustomers->forPage($page, $perpage),
              $filteredCustomers->count(),
              $perpage,
              $page,
              ['path' => \Illuminate\Pagination\Paginator::resolveCurrentPath()]
          );
      }
 
      // ============== GET LIST DATA ==============
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
 
      // ============== CURRENT MONTH CUSTOMER ==============
      $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
          ->where('za_customer.branch_id', $branch_id)
          ->whereYear('za_customer.created_at', date('Y'))
          ->whereMonth('za_customer.created_at', date('m'))
          ->get();
 
      $currentMonthCustomerCount = 0;
      $total_business_amount = 0;
      $total_payment = 0;
      $total_paid_payment = 0;
 
      if ($currentMonthCustomer->isNotEmpty()) {
          $currentMonthCustomerCount = $currentMonthCustomer->count();
          foreach ($currentMonthCustomer as $customer) {
              $courseIds = json_decode($customer->course_id, true);
              if (is_array($courseIds)) {
                  foreach ($courseIds as $courseId) {
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
      }
 
      $averageBusinessValue = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
      $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
 
      // ============== LEAD AND CONVERSION STATS ==============
      $percentageover = 0;
      $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
      if ($branch_id != 0) {
          $totalLeadCounts->where('za_lead.branch_id', $branch_id);
      }
     
      $user_id = auth()->user()->user_id ?? 0;
      if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
          $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
      } else {
          $totalLeadCount = $totalLeadCounts->count();
      }
 
      $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
      if ($branch_id != 0) {
          $totalCustomerCount->where('za_customer.branch_id', $branch_id);
      }
      $totalCustomerCount = $totalCustomerCount->count();
 
      if ($totalLeadCount > 0) {
          $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
      }
      $percentageover = round($percentageover) . '%';
 
      $leadOriginalCount = CustomerModel::where('za_customer.branch_id', $branch_id)
          ->where('za_customer.created_by', '!=', 0)
          ->where('za_customer.status', 0)
          ->count();
 
      // Conversion rate current month
      $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($branch_id != 0) {
          $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
          ->whereMonth('created_at', date('m'))
          ->count();
 
      $percentagecurrentmonth = 0;
      if ($currentMonthLeadCount > 0) {
          $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
      }
      $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
 
      // ============== COURSE CHANGE DAYS ==============
      if ($branch_id > 0) {
          $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
          $get_course_change_days = 0;
      }
 
      // ============== BATCH STATUS COUNTS ==============
      $batch_Data = DB::table('za_training')
          ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
          ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
          ->where('za_training.branch_id', $branch_id)
          ->where('za_customer.status', 0)
          ->get();
 
      $dropCount = 0;
      $activeCount = 0;
      $notYetStartedCount = 0;
      $scheduleCount = 0;
      $currentactiveCount = 0;
 
      $processed_drop_customers = [];
      $processed_active_customers = [];
      $processed_schedule_customers = [];
      $processed_not_started_customers = [];
      $processed_current_active_customers = [];
 
      foreach ($batch_Data as $singledata) {
          if (in_array($singledata->customer_id, $processed_drop_customers)) {
              continue;
          }
          if ($singledata->status == "2") {
              $dropCount++;
              $processed_drop_customers[] = $singledata->customer_id;
          }
      }
 
      $batch_active_Data = DB::table('za_training')
          ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date', 'za_training.end_date')
          ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
          ->whereNotNull('za_training.start_date')
          ->where('za_training.branch_id', $branch_id)
          ->where('za_customer.status', 0)
          ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date', 'za_training.end_date')
          ->get();
 
      foreach ($batch_active_Data as $singledata) {
          if (!in_array($singledata->customer_id, $processed_drop_customers)) {
              if (in_array($singledata->customer_id, $processed_active_customers)) {
                  continue;
              }
              if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                  $activeCount++;
                  $processed_active_customers[] = $singledata->customer_id;
              }

            $today = \Carbon\Carbon::today();

            if ($singledata->start_date <= $today && ( empty($singledata->end_date) || $singledata->end_date >= $today)) {
                $currentactiveCount++;
                $processed_current_active_customers[] = $singledata->customer_id;
            }
          }
      }
 
      $batch_Data_old = DB::table('za_training')
          ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
          ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
          ->where('za_training.branch_id', $branch_id)
          ->where('za_customer.status', 0)
          ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
          ->get();
 
      foreach ($batch_Data_old as $singledata) {
          if (!in_array($singledata->customer_id, $processed_drop_customers)) {
              if (!in_array($singledata->customer_id, $processed_active_customers)) {
                  if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                      continue;
                  }
                  if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
                      $scheduleCount++;
                      $processed_schedule_customers[] = $singledata->customer_id;
                  }
              }
          }
      }
 
      $batch_notyetStated = DB::table('za_training')
          ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
          ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
          ->where('za_training.branch_id', $branch_id)
          ->where('za_customer.status', 0)
          ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
          ->get();
 
      foreach ($batch_notyetStated as $singledata) {
          if (!in_array($singledata->customer_id, $processed_drop_customers)) {
              if (!in_array($singledata->customer_id, $processed_active_customers)) {
                  if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
                      if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                          continue;
                      }
                      if ($singledata->start_date === null) {
                          $notYetStartedCount++;
                          $processed_not_started_customers[] = $singledata->customer_id;
                      }
                  }
              }
          }
      }
 
      // ============== REASON LIST ==============
      $reasonList_hold = HoldReasonModel::select('*')->where('status', '!=', 2)->get();
 
      // ============== APP INSTALLATION STATS ==============
      $app_result = CustomerModel::from('za_customer')
          ->leftJoin(DB::raw("
              (
                  SELECT user_id, 1 AS app_installed
                  FROM (
                      SELECT user_id, MAX(sno) AS last_otp_id
                      FROM za_otp
                      GROUP BY user_id
                  ) mx
              ) AS otp_data
          "), 'otp_data.user_id', '=', 'za_customer.sno')
          ->leftJoin(DB::raw("
              (
                  SELECT student_id, SUM(points) AS daily_points
                  FROM za_students_points
                  GROUP BY student_id
              ) AS points_sum
          "), 'points_sum.student_id', '=', 'za_customer.sno')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_customer.status', 0)
          ->selectRaw("
              COUNT(*) AS total_customers,
              SUM(IF(IFNULL(otp_data.app_installed,0)=1,1,0)) AS total_app_installed,
              SUM(IF(IFNULL(otp_data.app_installed,0)=0,1,0)) AS total_app_not_installed,
              SUM(IFNULL(points_sum.daily_points,0)) AS total_daily_points
          ")
          ->first();
 
      $total_appinstalled_count = isset($app_result->total_app_installed) && !empty($app_result->total_app_installed) ? (int)$app_result->total_app_installed : 0;
      $total_appnotinstalled_count = isset($app_result->total_app_not_installed) && !empty($app_result->total_app_not_installed) ? (int)$app_result->total_app_not_installed : 0;
 
      // ============== RETURN VIEW ==============
      return view('content.customer.customer_list', [
          'customers' => $customers,
          'customers_list' => $customers_list,
          'customer_name_fill' => $request->customer_name_fill_sno ?? '',
          'cus_fill' => $request->cus_fill ?? '',
          'staff_fill' => $request->staff_name_fill_sno ?? '',
          'status_fill' => $status_fill,
          'course_type_list' => $course_type_list,
          'course_type_fill' => $request->course_type_fill_sno ?? '',
          'leadOriginalCount' => $leadOriginalCount,
          'course_list' => $course_list,
          'batch_list' => $batch_list,
          'staff_list' => $staff_list,
          'activeCount' => $activeCount,
          'scheduleCount' => $scheduleCount,
          'notYetStartedCount' => $notYetStartedCount,
          'inactiveCount' => $inactiveCount,
          'dropCount' => $dropCount,
          'percentageover' => $percentageover,
          'batch_name_fill' => $request->batch_name_fill_sno ?? '',
          'slot_list' => $slot_list,
          'perpage' => $perpage,
          'slot_name_fill' => $request->slot_name_fill_sno ?? '',
          'slot_type_list' => $slot_type_list,
          'slot_type_name_fill' => $request->slot_type_name_fill ?? '',
          'course_name_fill' => $request->course_name_fill_sno ?? '',
          'date_filter' => $request->dt_fill_issue_rpt ?? '',
          'fin_yr_fill' => $request->fin_yr_fill ?? '',
          'reasonList_hold' => $reasonList_hold,
          'gender_fill' => $request->gender_fill ?? '',
          'currentMonthCustomerCount' => $currentMonthCustomerCount,
          'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
          'average_business_value' => $averageBusinessValue,
          'average_collection_value' => $averageCollectionValue,
          'total_appinstalled_count' => $total_appinstalled_count,
          'total_appnotinstalled_count' => $total_appnotinstalled_count,
          'course_change_count' => $get_course_change_days,
          'mobile_fill' => $request->mobile_fill ?? '',
          'from_date_filter' => $request->from_date_fillter_textbox ?? '',
          'to_date_filter' => $request->to_date_fillter_textbox ?? '',
          'currentactiveCount' => $currentactiveCount,
      ])->with('filter_on', $isFiltered);
  }
  
  public function Post_sale_list2(Request $request)
  {
   $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $helper = new \App\Helpers\Helpers();
    
    // return $request;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $cus_fill = $request->cus_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $staff_fill = $request->staff_name_fill_sno ?? '';
    $status_fill = $request->input('status_fill', 'all'); 
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // return $request;
    $query = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.doj',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_lead.created_by as lead_created_by',
      'lead_staff.staff_name as lead_staff_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
    //   'za_training.course_mode_id',
      'za_staff.staff_name',
      'za_staff.sno as staff_sno',
      'za_branch.min_prd_cost',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'),
      DB::raw('(SUM(za_payment.paidAmount) / MAX(za_payment.total_amount)) * 100 as payment_percentage')

    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
    //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
      ->where('za_customer.status', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        // 'za_training.course_mode_id',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_lead.created_by',
        'lead_staff.staff_name',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno',
        'za_branch.min_prd_cost'

      )
      ->orderBy('za_customer.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_customer.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_customer.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_customer.created_at', '<=', $toDate);
      }
    }
    // Financial year filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
  
      if ($selected_fin_year) {
          // Decode the financial month as an array
          $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
  
          // Check if $monthsArray is valid
          if (is_array($monthsArray) && count($monthsArray) > 0) {
              $currentYear = now()->year; // Current year
              
              // Filter leads that match any of the selected months
              $leads->where(function ($q) use ($monthsArray, $currentYear) {
                  $q->whereYear('za_customer.created_at', $currentYear)
                    ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
              });
          }
      }
    }

    if ($branch_id > 0) {
      $query->where('za_customer.branch_id', $branch_id);
    }

    if ($cus_fill) {
      $query->where(function ($customer) use ($cus_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
      });
    }
    if ($customer_name_fill) {
      $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }
    if ($staff_fill) {
      $query->where('za_staff.sno', $staff_fill);
    }
    if ($batch_name_fill) {
      $query->where('za_batch.sno', $batch_name_fill);
    }
    if ($slot_name_fill) {
      $query->where('za_slot.sno', $slot_name_fill);
    }
    if ($slot_type_name_fill) {
      $query->where('za_slot_type.sno', $slot_type_name_fill);
    }
    

    // Fetch Branch list ordered by sno in descending order
    $customers = $query->havingRaw('payment_percentage = 100')->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
    // Initialize counters for each category
    $activeCount = 0;
    $notYetStartedCount = 0;
    $inactiveCount = 0;
    $dropCount = 0;

    $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
      // Initialize flags for the conditions
      $allActive = false;
      $allCusDrop = false;
      $allEndDate = false;
  
      $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
      $carouselDetails = [];
  
      // Get payment details and course info
      $paymentDetailss = DB::table('za_payment')
          ->select('za_payment.status', 'za_payment.nextPayDate')
          ->where('za_payment.customer_id', $item->sno)
          ->where('za_payment.status', 0)
          ->get();
  
      $paymentget = DB::table('za_training')
          ->where('customer_id', $item->sno)
          ->whereIn('status', [0, 2])
          ->get();
  
      $courseIds = $paymentget;
      $batchIds = json_decode($item->batch_id);
  
      // Flags for tracking customer status
      $isActive = false;
      $isDropped = false;
      $isNotStarted = true; // Assume the customer is not started by default
      $isInactive = false;
  
      foreach ($courseIds as $index => $courseId) {
          $batchId = $batchIds[$index] ?? [];
  
          // Retrieve course details
          $course = DB::table('za_course')
              ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
              ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
              ->where('za_course.sno', $courseId->course_id)
              ->first();
  
          // Retrieve batch details
          $batch = DB::table('za_batch')
              ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
              ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
              ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
             ->where('za_batch.sno', $courseId->batch_id)
              ->first();
  
          // Retrieve payment details
          $paymentDetails = DB::table('za_training')
              ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
              ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
              ->where('za_training.customer_id', $item->sno)
              ->where('za_training.course_id', $courseId->course_id)
              ->where('za_training.status', '!=', 3)
              ->whereNotIn('za_payment.status', [3,2])
              ->where('za_payment.paidAmount', '>',0)
              ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
              ->groupBy('za_payment.total_amount')
              ->first();
  
          $paymentPercentage = 0;
          if ($paymentDetails && $paymentDetails->total_amount > 0) {
              $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
              if($paymentPercentage>=100){
                  
                  $paymentPercentage = 100;
                  
              }
          }
  
          // Check if attendance exists for the specific batch and customer
          $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
              ->where('batch_id', $batchId)
              ->where('attendance', 'P')
              ->get();
  
          // Initialize course progress percentage
          $courseProgress = 0;
          $topicCount = 0;
          $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
              ->count();
           $helper = new \App\Helpers\Helpers();
            $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
    
  
          // batch count by course id
          $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
  
          // Set customer status based on conditions
           //*************************************************************************************
          
           $currentDate = date('Y-m-d');
           $allActive = false;
           $allCusDrop=true;
           $allEndDate=true;
           
           $start_date = $batch->start_date ?? null;
           $end_date  = $batch->end_date ?? null;
           
           if ($start_date <= $currentDate && $start_date != null) {
               $allActive = true;
            //   break;
           }
           if ( $courseId->status != 2) {
               $allCusDrop = false;
            //   break;
           }
             if (isset($end_date) && $end_date < $currentDate) {
                 $allEndDate = false;
                //  break;
             }
          
          
          if($allActive && !$allCusDrop){
                $isActive = true;  // Customer is active
           }
           elseif(!$allActive && !$allCusDrop){
                 $isNotStarted = true;  // Customer is not yet started
           }
            elseif($allCusDrop){
            $isDropped = true;  // Customer is dropped
           }
           elseif($allEndDate){
                $isInactive = true;  // Customer is inactive
           }
  
          // Add course and batch details to the array
          $carouselDetails[] = [
              'course_sno' => $courseId->course_id ?? null,
              'course_mode_id' => $courseId->course_mode_id ?? null,
              'online_course_fee' => $course->online_fee ?? null,
              'batch_sno' => $batchId ?? null,
              'batch_count' => $batch_count ?? 0,
              'traning_sno' => $courseId->sno ?? null,
              'traning_status' => $courseId->status ?? null,
              'course_name' => $course->course_name ?? null,
              'course_type_name' => $course->course_type_name ?? null,
              'batch_name' => $batch->batch_name ?? null,
              'start_date' => $batch->start_date ?? null,
              'end_date' => $batch->end_date ?? null,
              'slot_name' => $batch->slot_name ?? null,
              'staff_name' => $batch->staff_name ?? null,
              'payment_percentage' => $paymentPercentage,
              'course_progress' => $courseProgress,
          ];
      }
  
      // Increment customer count based on status
      if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
          $activeCount++;
      } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
          $notYetStartedCount++;
      } elseif ($isDropped) {
          $dropCount++;
      } elseif ($isInactive) {
          $inactiveCount++;
      }
  
      // Attach data to the customer item
      $item->carousel_details = $carouselDetails;
      $item->paymentDetailss = $paymentDetailss;
      $item->all_active = $isActive;
      $item->all_cus_drop = $isDropped;
      $item->all_end_date = $isInactive;
  
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
       $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
  
      return $item;
    });
  
    if ($status_fill) {
        if ($status_fill == 'active') {
            $customers = $customers->filter(function ($item) {
                return $item->all_active && !$item->all_cus_drop;
            });
        } elseif ($status_fill == 'not_started') {
            $customers = $customers->filter(function ($item) {
                return !$item->all_active && !$item->all_cus_drop;
            });
        } elseif ($status_fill == 'drop') {
            $customers = $customers->filter(function ($item) {
                return $item->all_cus_drop;
            });
        } elseif ($status_fill == 'inactive') {
            $customers = $customers->filter(function ($item) {
                return $item->all_end_date;
            });
        }
    }  

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();


    // alagu
    // current month customer
     $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', date('Y'))
            ->whereMonth('za_customer.created_at', date('m'))
            ->get();

        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
            $currentMonthCustomerCount = $currentMonthCustomer->count();
            foreach ($currentMonthCustomer as $customer) {
                $courseIds = json_decode($customer->course_id, true);
                foreach ($courseIds as $courseId) {
                    // Fetch the course's maximum price
                    $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                    $total_payment += $payment;
                    // Fetch the total paid amount for the course
                    $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                        ->where('course_id', $courseId)
                        ->where('status', 1)
                        ->sum('paidAmount');
                    $total_paid_payment += $paid_payment;
                }
            }
        }

        // Calculate averages
        $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
        $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
       
    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id > 0) {
      $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
    } else {
      $get_course_change_days =  0;
    }

    $percentageover = 0;
        
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
    if ($branch_id != 0) {
        $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
        // User can only view their own data
        $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
        // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_customer.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }

    $percentageover = round($percentageover) . '%';

    $leadOriginal = DB::table('za_customer')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_customer.created_by', '!=', 0)
    ->where('za_customer.status', 0);

    $leadOriginalCount = 0;
    $leadOriginalCount = $leadOriginal->count();
    $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
    if ($branch_id != 0) {
      $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->count();
    $percentagecurrentmonth = 0;
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

     $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }

        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                            continue;
                        }
                        if ($singledata->start_date === null || $singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
                            $notYetStartedCount++;
                            $processed_not_started_customers[] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        
    // return $notYetStartedCount;
    if($fill_chk==1){
      return view('content.customer.post_sale_customer_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'perpage' => $perpage,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'cus_fill' => $cus_fill,
        'staff_fill' => $staff_fill,
        'status_fill' => $status_fill,
        'activeCount' => $activeCount,
        'notYetStartedCount' => $notYetStartedCount,
        'inactiveCount' => $inactiveCount,
        'dropCount' => $dropCount,
        'leadOriginalCount' => $leadOriginalCount,
        'percentageover' => $percentageover,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $average_business_value,
        'average_collection_value' => $average_collection_value,
        'course_change_count' => $get_course_change_days
  
      ])->with('filter_on', true);
    }else{
      return view('content.customer.post_sale_customer_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'perpage' => $perpage,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'cus_fill' => $cus_fill,
        'staff_fill' => $staff_fill,
        'status_fill' => $status_fill,
        'activeCount' => $activeCount,
        'notYetStartedCount' => $notYetStartedCount,
        'inactiveCount' => $inactiveCount,
        'dropCount' => $dropCount,
        'leadOriginalCount' => $leadOriginalCount,
        'percentageover' => $percentageover,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
  
      ])->with('filter_on', false);
    }

    
  }
  
  public function Post_sale_list(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $helper = new \App\Helpers\Helpers();
    
    // return $request;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    
    $user_id = $request->user()->user_id;
    // if($user_id!=125){
    //     return 'Testing On progess';
    // }
    // $cus_fill = $request->cus_fill ?? '';
    
    //         $customers = CustomerModel::select(
    //                 'za_customer.sno', 
    //                 'za_customer.cus_name',
    //                 'za_customer.cus_pic',
    //                 'za_customer.customer_id',
    //                 'za_customer.cus_gender',
    //                 'za_customer.cus_dob',
    //                 'za_customer.doj',
    //                 'za_customer.cus_mobile',
    //                 'za_customer.cus_alternate_mobile',
    //                 'za_customer.cus_email_id',
    //                 'za_customer.course_id',
    //                 'za_customer.created_by',
    //                 'za_customer.batch_id',
    //                 'za_lead.sno as lead_id',
    //                 'za_lead.created_by as lead_created_by',
    //                 'lead_staff.staff_name as lead_staff_name',
    //                 'za_staff.staff_name',
    //                 'za_staff.sno as staff_sno',
    //                 DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
    //                 DB::raw('MAX(za_payment.total_amount) as total_amount')
    //             )
    //             ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno') 
    //             ->leftJoin('za_staff', 'za_customer.batch_id', '=', 'za_staff.sno') 
    //             ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno') 
    //             ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
    //             ->where('za_customer.status', 0)
    //             ->where('za_customer.branch_id', $branch_id)
    //             ->groupBy(
    //                 'za_customer.sno',
    //                 'za_customer.cus_name',
    //                 'za_customer.cus_pic',
    //                 'za_customer.customer_id',
    //                 'za_customer.cus_gender',
    //                 'za_customer.cus_dob',
    //                 'za_customer.doj',
    //                 'za_customer.cus_mobile',
    //                 'za_customer.cus_alternate_mobile',
    //                 'za_customer.cus_email_id',
    //                 'za_customer.course_id',
    //                 'za_customer.created_by',
    //                 'za_customer.batch_id',
    //                 'za_lead.sno',
    //                 'za_lead.created_by',
    //                 'lead_staff.staff_name',
    //                 'za_staff.staff_name',
    //                 'za_staff.sno'
    //             )
    //              ->where('za_customer.post_sale_check', 1)
    //             ->orderBy('za_customer.sno', 'desc')
    //             ->paginate($perpage);
                
               
            $cus_fill = trim($request->cus_fill ?? '');
 
            $customers = CustomerModel::select(
              'za_customer.sno',
              'za_customer.cus_name',
              'za_customer.cus_pic',
              'za_customer.customer_id',
              'za_customer.cus_gender',
              'za_customer.cus_dob',
              'za_customer.doj',
              'za_customer.cus_mobile',
              'za_customer.cus_alternate_mobile',
              'za_customer.cus_email_id',
              'za_customer.course_id',
              'za_customer.created_by',
              'za_customer.batch_id',
              'za_lead.sno as lead_id',
              'za_lead.created_by as lead_created_by',
              'lead_staff.staff_name as lead_staff_name',
              'za_staff.staff_name',
              'za_staff.sno as staff_sno',
              DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
              DB::raw('MAX(za_payment.total_amount) as total_amount')
            )
            ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
            ->leftJoin('za_staff', 'za_customer.batch_id', '=', 'za_staff.sno')
            ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
            ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
            ->where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.post_sale_check', 1);
         
            if (!empty($cus_fill)) {
         
              $customers->where(function ($query) use ($cus_fill) {
         
              $query->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_customer.customer_id', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_customer.cus_alternate_mobile', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%")
                ->orWhere('lead_staff.staff_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_staff.staff_name', 'LIKE', "%{$cus_fill}%");
         
              });
         
            }
         
            $customers = $customers
              ->groupBy(
                'za_customer.sno',
                'za_customer.cus_name',
                'za_customer.cus_pic',
                'za_customer.customer_id',
                'za_customer.cus_gender',
                'za_customer.cus_dob',
                'za_customer.doj',
                'za_customer.cus_mobile',
                'za_customer.cus_alternate_mobile',
                'za_customer.cus_email_id',
                'za_customer.course_id',
                'za_customer.created_by',
                'za_customer.batch_id',
                'za_lead.sno',
                'za_lead.created_by',
                'lead_staff.staff_name',
                'za_staff.staff_name',
                'za_staff.sno'
              )
              ->orderBy('za_customer.sno', 'desc')
              ->paginate($perpage);




    // Initialize counters for each category
    $activeCount = 0;
    $notYetStartedCount = 0;
    $inactiveCount = 0;
    $dropCount = 0;

    $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
      // Initialize flags for the conditions
      $allActive = false;
      $allCusDrop = false;
      $allEndDate = false;
  
      $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
      $carouselDetails = [];
  
      // Get payment details and course info
      $paymentDetailss = DB::table('za_payment')
          ->select('za_payment.status', 'za_payment.nextPayDate')
          ->where('za_payment.customer_id', $item->sno)
          ->where('za_payment.status', 0)
          ->get();
  
      $paymentget = DB::table('za_training')
          ->where('customer_id', $item->sno)
          ->whereIn('status', [0, 2])
          ->get();
  
      $courseIds = $paymentget;
      $batchIds = json_decode($item->batch_id);
  
      // Flags for tracking customer status
      $isActive = false;
      $isDropped = false;
      $isNotStarted = true; // Assume the customer is not started by default
      $isInactive = false;
  
      foreach ($courseIds as $index => $courseId) {
          $batchId = $batchIds[$index] ?? [];
  
          // Retrieve course details
          $course = DB::table('za_course')
              ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
              ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
              ->where('za_course.sno', $courseId->course_id)
              ->first();
  
          // Retrieve batch details
          $batch = DB::table('za_batch')
              ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
              ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
              ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
             ->where('za_batch.sno', $courseId->batch_id)
              ->first();
  
          // Retrieve payment details
          $paymentDetails = DB::table('za_training')
              ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
              ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
              ->where('za_training.customer_id', $item->sno)
              ->where('za_training.course_id', $courseId->course_id)
              ->where('za_training.status', '!=', 3)
              ->whereNotIn('za_payment.status', [3,2])
              ->where('za_payment.paidAmount', '>',0)
              ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
              ->groupBy('za_payment.total_amount')
              ->first();
  
          $paymentPercentage = 0;
          if ($paymentDetails && $paymentDetails->total_amount > 0) {
              $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
              if($paymentPercentage>=100){
                  
                  $paymentPercentage = 100;
                  
              }
          }
  
          // Check if attendance exists for the specific batch and customer
          $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
              ->where('batch_id', $batchId)
              ->where('attendance', 'P')
              ->get();
  
          // Initialize course progress percentage
          $courseProgress = 0;
          $topicCount = 0;
          $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
              ->count();
           $helper = new \App\Helpers\Helpers();
            $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
    
  
          // batch count by course id
          $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
  
          // Set customer status based on conditions
           //*************************************************************************************
          
           $currentDate = date('Y-m-d');
           $allActive = false;
           $allCusDrop=true;
           $allEndDate=true;
           
           $start_date = $batch->start_date ?? null;
           $end_date  = $batch->end_date ?? null;
           
           if ($start_date <= $currentDate && $start_date != null) {
               $allActive = true;
            //   break;
           }
           if ( $courseId->status != 2) {
               $allCusDrop = false;
            //   break;
           }
             if (isset($end_date) && $end_date < $currentDate) {
                 $allEndDate = false;
                //  break;
             }
          
          
          if($allActive && !$allCusDrop){
                $isActive = true;  // Customer is active
           }
           elseif(!$allActive && !$allCusDrop){
                 $isNotStarted = true;  // Customer is not yet started
           }
            elseif($allCusDrop){
            $isDropped = true;  // Customer is dropped
           }
           elseif($allEndDate){
                $isInactive = true;  // Customer is inactive
           }
  
          // Add course and batch details to the array
          $carouselDetails[] = [
              'course_sno' => $courseId->course_id ?? null,
              'course_mode_id' => $courseId->course_mode_id ?? null,
              'online_course_fee' => $course->online_fee ?? null,
              'batch_sno' => $batchId ?? null,
              'batch_count' => $batch_count ?? 0,
              'traning_sno' => $courseId->sno ?? null,
              'traning_status' => $courseId->status ?? null,
              'course_name' => $course->course_name ?? null,
              'course_type_name' => $course->course_type_name ?? null,
              'batch_name' => $batch->batch_name ?? null,
              'start_date' => $batch->start_date ?? null,
              'end_date' => $batch->end_date ?? null,
              'slot_name' => $batch->slot_name ?? null,
              'staff_name' => $batch->staff_name ?? null,
              'payment_percentage' => $paymentPercentage,
              'course_progress' => $courseProgress,
          ];
      }
  
      // Increment customer count based on status
      if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
          $activeCount++;
      } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
          $notYetStartedCount++;
      } elseif ($isDropped) {
          $dropCount++;
      } elseif ($isInactive) {
          $inactiveCount++;
      }
  
      // Attach data to the customer item
      $item->carousel_details = $carouselDetails;
      $item->paymentDetailss = $paymentDetailss;
      $item->all_active = $isActive;
      $item->all_cus_drop = $isDropped;
      $item->all_end_date = $isInactive;
  
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
      $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
  
     $refferal_persons_list = ReferralPersonModel::select(
        'za_referral_persons.referral_id',
        'za_referral_persons.customer_id',
        'referral_staff.staff_name as referral_staff_name'
      )
      ->join('za_staff as referral_staff', 'za_referral_persons.referral_id', '=', 'referral_staff.sno')
      ->where('za_referral_persons.customer_id', $item->sno)
      ->where('za_referral_persons.status', 0)
      ->distinct()
      ->get();
 
      $item->refferal_persons_list = $refferal_persons_list;
      
      return $item;
    });
  
   

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();


    // alagu
   // current month customer
     $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', date('Y'))
            ->whereMonth('za_customer.created_at', date('m'))
            ->get();

        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
            $currentMonthCustomerCount = $currentMonthCustomer->count();
            foreach ($currentMonthCustomer as $customer) {
                $courseIds = json_decode($customer->course_id, true);
                foreach ($courseIds as $courseId) {
                    // Fetch the course's maximum price
                    $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                    $total_payment += $payment;
                    // Fetch the total paid amount for the course
                    $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                        ->where('course_id', $courseId)
                        ->where('status', 1)
                        ->sum('paidAmount');
                    $total_paid_payment += $paid_payment;
                }
            }
        }

        // Calculate averages
        $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
        $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
       
    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id > 0) {
      $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
    } else {
      $get_course_change_days =  0;
    }

    $percentageover = 0;
        
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
    if ($branch_id != 0) {
        $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
        // User can only view their own data
        $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
        // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_customer.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }

    $percentageover = round($percentageover) . '%';

    $leadOriginal = DB::table('za_customer')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_customer.created_by', '!=', 0)
    ->where('za_customer.status', 0);

    $leadOriginalCount = 0;
    $leadOriginalCount = $leadOriginal->count();
    $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
    if ($branch_id != 0) {
      $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->count();
    $percentagecurrentmonth = 0;
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

    $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }

        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                            continue;
                        }
                        if ($singledata->start_date === null || $singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
                            $notYetStartedCount++;
                            $processed_not_started_customers[] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
    // return $notYetStartedCount;
    return view('content.customer.post_sale_customer_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'staff_list' => $staff_list,
      'perpage' => $perpage,
      'slot_list' => $slot_list,
      'slot_type_list' => $slot_type_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'cus_fill' => $cus_fill,
     
      'activeCount' => $activeCount,
      'notYetStartedCount' => $notYetStartedCount,
      'inactiveCount' => $inactiveCount,
      'dropCount' => $dropCount,
      'leadOriginalCount' => $leadOriginalCount,
      'percentageover' => $percentageover,
      
      'currentMonthCustomerCount' => $currentMonthCustomerCount,
      'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
      'average_business_value' => $averageBusinessValue,
      'average_collection_value' => $averageCollectionValue,
      'course_change_count' => $get_course_change_days

    ])->with('filter_on', true);
  }

  public function complete_customer(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $helper = new \App\Helpers\Helpers();
    
   $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
        }
      
      $notStartedCount=$notYetStartedCount;
    
    // return $request;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $cus_fill = $request->cus_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $staff_fill = $request->staff_name_fill_sno ?? '';
    $status_fill = $request->input('status_fill', 'all'); 
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // return $request;
    $query = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.doj',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_lead.created_by as lead_created_by',
      'lead_staff.staff_name as lead_staff_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
    //   'za_training.course_mode_id',
      'za_staff.staff_name',
      'za_staff.sno as staff_sno',
      'za_branch.min_prd_cost',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'),
      DB::raw('(SUM(za_payment.paidAmount) / MAX(za_payment.total_amount)) * 100 as payment_percentage')

    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
    //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
      ->where('za_customer.status', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        // 'za_training.course_mode_id',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_lead.created_by',
        'lead_staff.staff_name',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno',
        'za_branch.min_prd_cost'

      )
      ->orderBy('za_customer.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_customer.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_customer.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_customer.created_at', '<=', $toDate);
      }
    }
    // Financial year filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
  
      if ($selected_fin_year) {
          // Decode the financial month as an array
          $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
  
          // Check if $monthsArray is valid
          if (is_array($monthsArray) && count($monthsArray) > 0) {
              $currentYear = now()->year; // Current year
              
              // Filter leads that match any of the selected months
              $leads->where(function ($q) use ($monthsArray, $currentYear) {
                  $q->whereYear('za_customer.created_at', $currentYear)
                    ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
              });
          }
      }
    }

    if ($branch_id > 0) {
      $query->where('za_customer.branch_id', $branch_id);
    }

    if ($cus_fill) {
      $query->where(function ($customer) use ($cus_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
      });
    }
    if ($customer_name_fill) {
      $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }
    if ($staff_fill) {
      $query->where('za_staff.sno', $staff_fill);
    }
    if ($batch_name_fill) {
      $query->where('za_batch.sno', $batch_name_fill);
    }
    if ($slot_name_fill) {
      $query->where('za_slot.sno', $slot_name_fill);
    }
    if ($slot_type_name_fill) {
      $query->where('za_slot_type.sno', $slot_type_name_fill);
    }
    

    // Fetch Branch list ordered by sno in descending order
    $customers = $query->havingRaw('payment_percentage = 100')->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
    // Initialize counters for each category
    $activeCount = 0;
    $notYetStartedCount = 0;
    $inactiveCount = 0;
    $dropCount = 0;

    $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
      // Initialize flags for the conditions
      $allActive = false;
      $allCusDrop = false;
      $allEndDate = false;
  
      $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
      $carouselDetails = [];
  
      // Get payment details and course info
      $paymentDetailss = DB::table('za_payment')
          ->select('za_payment.status', 'za_payment.nextPayDate')
          ->where('za_payment.customer_id', $item->sno)
          ->where('za_payment.status', 0)
          ->get();
  
      $paymentget = DB::table('za_training')
          ->where('customer_id', $item->sno)
          ->whereIn('status', [0, 2])
          ->get();
  
      $courseIds = $paymentget;
      $batchIds = json_decode($item->batch_id);
  
      // Flags for tracking customer status
      $isActive = false;
      $isDropped = false;
      $isNotStarted = true; // Assume the customer is not started by default
      $isInactive = false;
  
      foreach ($courseIds as $index => $courseId) {
          $batchId = $batchIds[$index] ?? [];
  
          // Retrieve course details
          $course = DB::table('za_course')
              ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
              ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
              ->where('za_course.sno', $courseId->course_id)
              ->first();
  
          // Retrieve batch details
          $batch = DB::table('za_batch')
              ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
              ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
              ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
             ->where('za_batch.sno', $courseId->batch_id)
              ->first();
  
          // Retrieve payment details
          $paymentDetails = DB::table('za_training')
              ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
              ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
              ->where('za_training.customer_id', $item->sno)
              ->where('za_training.course_id', $courseId->course_id)
              ->where('za_training.status', '!=', 3)
              ->whereNotIn('za_payment.status', [3,2])
              ->where('za_payment.paidAmount', '>',0)
              ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
              ->groupBy('za_payment.total_amount')
              ->first();
  
          $paymentPercentage = 0;
          if ($paymentDetails && $paymentDetails->total_amount > 0) {
              $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
              if($paymentPercentage>=100){
                  
                  $paymentPercentage = 100;
                  
              }
          }
  
          // Check if attendance exists for the specific batch and customer
          $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
              ->where('batch_id', $batchId)
              ->where('attendance', 'P')
              ->get();
  
          // Initialize course progress percentage
          $courseProgress = 0;
          $topicCount = 0;
          $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
              ->count();
           $helper = new \App\Helpers\Helpers();
            $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
    
  
          // batch count by course id
          $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
  
          // Set customer status based on conditions
           //*************************************************************************************
          
           $currentDate = date('Y-m-d');
           $allActive = false;
           $allCusDrop=true;
           $allEndDate=true;
           
           $start_date = $batch->start_date ?? null;
           $end_date  = $batch->end_date ?? null;
           
           if ($start_date <= $currentDate && $start_date != null) {
               $allActive = true;
            //   break;
           }
           if ( $courseId->status != 2) {
               $allCusDrop = false;
            //   break;
           }
             if (isset($end_date) && $end_date < $currentDate) {
                 $allEndDate = false;
                //  break;
             }
          
          
          if($allActive && !$allCusDrop){
                $isActive = true;  // Customer is active
           }
           elseif(!$allActive && !$allCusDrop){
                 $isNotStarted = true;  // Customer is not yet started
           }
            elseif($allCusDrop){
            $isDropped = true;  // Customer is dropped
           }
           elseif($allEndDate){
                $isInactive = true;  // Customer is inactive
           }
  
          // Add course and batch details to the array
          $carouselDetails[] = [
              'course_sno' => $courseId->course_id ?? null,
              'course_mode_id' => $courseId->course_mode_id ?? null,
              'online_course_fee' => $course->online_fee ?? null,
              'batch_sno' => $batchId ?? null,
              'batch_count' => $batch_count ?? 0,
              'traning_sno' => $courseId->sno ?? null,
              'traning_status' => $courseId->status ?? null,
              'course_name' => $course->course_name ?? null,
              'course_type_name' => $course->course_type_name ?? null,
              'batch_name' => $batch->batch_name ?? null,
              'start_date' => $batch->start_date ?? null,
              'end_date' => $batch->end_date ?? null,
              'slot_name' => $batch->slot_name ?? null,
              'staff_name' => $batch->staff_name ?? null,
              'payment_percentage' => $paymentPercentage,
              'course_progress' => $courseProgress,
          ];
      }
  
      // Increment customer count based on status
      if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
          $activeCount++;
      } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
          $notYetStartedCount++;
      } elseif ($isDropped) {
          $dropCount++;
      } elseif ($isInactive) {
          $inactiveCount++;
      }
  
      // Attach data to the customer item
      $item->carousel_details = $carouselDetails;
      $item->paymentDetailss = $paymentDetailss;
      $item->all_active = $isActive;
      $item->all_cus_drop = $isDropped;
      $item->all_end_date = $isInactive;
  
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
       $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
  
      return $item;
    });
  
    if ($status_fill) {
        if ($status_fill == 'active') {
            $customers = $customers->filter(function ($item) {
                return $item->all_active && !$item->all_cus_drop;
            });
        } elseif ($status_fill == 'not_started') {
            $customers = $customers->filter(function ($item) {
                return !$item->all_active && !$item->all_cus_drop;
            });
        } elseif ($status_fill == 'drop') {
            $customers = $customers->filter(function ($item) {
                return $item->all_cus_drop;
            });
        } elseif ($status_fill == 'inactive') {
            $customers = $customers->filter(function ($item) {
                return $item->all_end_date;
            });
        }
    }  

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();


    // alagu
   // current month customer
     $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', date('Y'))
            ->whereMonth('za_customer.created_at', date('m'))
            ->get();

        $currentMonthCustomerCount = 0;
        $total_business_amount     = 0;
        $total_payment             = 0;
        $total_paid_payment        = 0;

        if ($currentMonthCustomer->isNotEmpty()) {
            $currentMonthCustomerCount = $currentMonthCustomer->count();
            foreach ($currentMonthCustomer as $customer) {
                $courseIds = json_decode($customer->course_id, true);
                foreach ($courseIds as $courseId) {
                    // Fetch the course's maximum price
                    $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                    $total_payment += $payment;
                    // Fetch the total paid amount for the course
                    $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                        ->where('course_id', $courseId)
                        ->where('status', 1)
                        ->sum('paidAmount');
                    $total_paid_payment += $paid_payment;
                }
            }
        }

        // Calculate averages
        $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
        $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
        
    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id > 0) {
      $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
    } else {
      $get_course_change_days =  0;
    }

    $percentageover = 0;
        
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
    if ($branch_id != 0) {
        $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
        // User can only view their own data
        $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
        // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_customer.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }

    $percentageover = round($percentageover) . '%';

    $leadOriginal = DB::table('za_customer')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_customer.created_by', '!=', 0)
    ->where('za_customer.status', 0);

    $leadOriginalCount = 0;
    $leadOriginalCount = $leadOriginal->count();
    $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
    if ($branch_id != 0) {
      $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->count();
    $percentagecurrentmonth = 0;
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

    $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
        }
    // return $notYetStartedCount;
    return view('content.customer.customer_complete_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'course_type_list' => $course_type_list,
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'staff_list' => $staff_list,
      'perpage' => $perpage,
      'slot_list' => $slot_list,
      'slot_type_list' => $slot_type_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'cus_fill' => $cus_fill,
      'staff_fill' => $staff_fill,
      'status_fill' => $status_fill,
      'activeCount' => $activeCount,
      'notYetStartedCount' => $notStartedCount,
      'inactiveCount' => $inactiveCount,
      'dropCount' => $dropCount,
      'leadOriginalCount' => $leadOriginalCount,
      'percentageover' => $percentageover,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'batch_name_fill' => $batch_name_fill,
      'slot_name_fill' => $slot_name_fill,
      'slot_type_name_fill' => $slot_type_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,
      'currentMonthCustomerCount' => $currentMonthCustomerCount,
      'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
      'average_business_value' => $averageBusinessValue,
      'average_collection_value' => $averageCollectionValue,
      'course_change_count' => $get_course_change_days

    ])->with('filter_on', true);
  }


  public function List()
  {
    $lead = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead
    ], 200);
  }

  public function LeadAdd(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'cus_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_mobile       = $request->lead_mobile;

      $user_id                    = 1;
      $chk = CustomerModel::where('lead_mobile', $lead_mobile)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile has been  already created!'
        ]);
      } else {



        $add_category = new CustomerModel();
        // $add_category->lead_id           = $lead_id;
        $add_category->lead_name         = Ucfirst($lead_name);
        $add_category->lead_mobile           = $lead_mobile;
        $add_category->lead_email_id           = $request->lead_email_id;
        $add_category->course_id              = json_encode($request->course_id);
        $add_category->lead_source_id           = $request->lead_source_id;
        $add_category->lead_type_id           = $request->lead_type_id;
        $add_category->lead_comments           = $request->lead_comments;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Lead Created successfully!');
    }
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name           = $request->lead_name;
      $lead_mobile         = $request->lead_mobile;
      $lead_alternate_mobile       = $request->lead_alternate_mobile;
      $lead_email_id       = $request->lead_email_id;
      $lead_gender         = $request->lead_gender;
      $lead_marital_status            = $request->lead_marital_status;
      $lead_dob             = $request->lead_dob;
      $country              = $request->country;
      $state                = $request->state;
      $city                 = $request->city;
      $address              = $request->address;
      $course_id            = json_encode($request->course_id);
      $lead_type_id            = $request->lead_type_id;
      $lead_source_id            = $request->lead_source_id;
      $lead_question_id            = $request->lead_question_id;
      $lead_comments            = $request->lead_comments;

      $lead_dob = DateTime::createFromFormat('d-M-Y', $request->lead_dob);

      $user_id                    = 1;
      $chk = CustomerModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = CustomerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $lead_id = "LD-2005/" . $year;
        } else {

          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("LD-%04d", $next_number);

          $year = substr(date("y"), -2);
          $lead_id = $request . '/' . $year;
        }


        $add_category = new CustomerModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->lead_alternate_mobile   = $lead_alternate_mobile;
        $add_category->lead_email_id           = $lead_email_id;
        $add_category->lead_gender             = $lead_gender;
        $add_category->lead_dob                = $lead_dob->format('Y-m-d');;
        $add_category->lead_marital_status     = $lead_marital_status;
        $add_category->country                 = $country;
        $add_category->state                   = $state;
        $add_category->city                    = $city;
        $add_category->address                 = $address;
        $add_category->course_id               = $course_id;
        $add_category->lead_source_id          = $lead_source_id;
        $add_category->lead_type_id            = $lead_type_id;
        $add_category->lead_question_id        = $lead_question_id;
        $add_category->lead_comments           = $lead_comments;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Lead Created successfully!');
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_id       = $request->lead_id;
      $course_id       = json_encode($request->course_id_edit);
      $lead_dob = DateTime::createFromFormat('d-M-Y', $request->lead_dob);
      $upd_lead =  CustomerModel::where('sno', $lead_id)->first();

      $chk = CustomerModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $lead_id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
        } else {
        }
      }

      $upd_lead->lead_name             = Ucfirst($lead_name);
      $upd_lead->lead_mobile           = $request->lead_mobile;
      $upd_lead->lead_alternate_mobile = $request->lead_alternate_mobile;
      $upd_lead->lead_email_id         = $request->lead_email_id;
      $upd_lead->lead_gender           = $request->lead_gender;
      $upd_lead->lead_dob              = $lead_dob;
      $upd_lead->lead_marital_status   = $request->lead_marital_status;
      $upd_lead->country               = $request->country;
      $upd_lead->state                 = $request->state;
      $upd_lead->city                  = $request->city;
      $upd_lead->address               = $request->address;
      $upd_lead->course_id             = $course_id;
      $upd_lead->lead_source_id        = $request->lead_source_id_edit;
      $upd_lead->lead_type_id          = $request->lead_type_id_edit;
      $upd_lead->lead_question_id      = $request->lead_question_id;
      $upd_lead->lead_comments         = $request->lead_comments;
      $upd_lead->update();


      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      // return $result;
    }

    return redirect()->back();
  }

  public function Delete($id)
  {
    $lead =  CustomerModel::where('sno', $id)->first();
    $lead->status  = 2;
    $lead->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $lead =  CustomerModel::where('sno', $id)->first();

    $lead->status = $request->status;
    // return  $lead;
    $lead->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  // vasanth
  public function get_couponcode(Request $request)
  {
    $couponcode = $request->couponcode;
    // Check if a coupon code was provided and find the coupon details
    if ($couponcode != null || $couponcode != "") {
      $coupon_details = ManageCouponModel::where('coupon_code', $couponcode)->first();
      
    } else {
      $coupon_details = "";
    }
    if ($coupon_details) {

      if ($coupon_details->coupon_type == 'percentage') {
        // Coupon is valid
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 0;
      } else {
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 1;
      }


      return response()->json([
        'status' => 200,
        'discount' => $discount,
        'discount_type' => $discount_type,
        'message' => 'Coupon code applied successfully.',
      ]);
    }elseif (empty($coupon_details)) {

       $branch_data = BranchModel::where('sno', $request->user()->branch_id)->first();
       
      $coupon = QrCouponModel::where('branch_id', $branch_data->sno)->where('discount_code', $couponcode)->first();
        if ($coupon->type == 0) {
         //   if ($coupon_details->coupon_type == 'percentag') {
        // Coupon is valid
        $discount = $branch_data->catalogue_offers ?? 0;
        $discount_type = 0;
        }elseif ($coupon->type == 1) {

            $QR_data = DB::table('za_qr_promotion')->where('sno', $coupon->discount_id)->first();
        
            if ($QR_data && ($QR_data->discount_type === 1 || $QR_data->discount_type === 0)) {
        
                $discount = $coupon->discount_value ?? 0;
                $discount_type = $QR_data->discount_type;
        
            }
        }

      return response()->json([
        'status' => 200,
        'discount' => $discount,
        'discount_type' => $discount_type,
        'message' => 'Coupon code applied successfully.',
      ]);
    }
    elseif (empty($couponcode)) {
      return response()->json([
        'status' => 404,
        'discount' => '0',
        'discount_type' => '-',
        'message' => 'Invalid coupon code.',
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'discount' => '0',
        'discount_type' => '-',
        'message' => 'Invalid coupon code.',
      ]);
    }
  }

  //customer_invoice
  public function customer_invoice($id = '', $print_id = '', Request $request)
  {
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      $print_decryptedValue = $helper->encrypt_decrypt($print_id, 'decrypt');

      $payment = PaymentModel::select(
          'za_payment.invoice_id',
          'za_payment.initialPayDate',
          'za_payment.paidAmount as amount',
          'za_payment.gst_amount',
          'za_payment.payment_mode_label',
          'za_payment.transaction',
        //   'za_transaction.transaction_id',
        'za_transaction.receipt_id',
          'za_customer.cus_name',
          'za_customer.customer_id',
          'za_customer.cus_mobile',
          'za_course.course_name',
          'za_branch.door_no',
          'za_branch.pincode',
          'za_branch.mobile',
          'za_branch.cre_mobile',
          'za_branch.branch_name',
          'za_branch.branch_type',
          'za_branch.business_name as franchise_name',
          'za_branch.mail',
          'za_branch.area_street',
          'za_branch.gst_no',
          'za_states.name as state_name',
          'za_cities.name as city_name'
      )
          ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_payment.customer_id')
          ->leftJoin('za_course', 'za_course.sno', '=', 'za_payment.course_id')
          ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_payment.branch_id')
          ->leftJoin('za_transaction', 'za_transaction.invoice_id', '=', 'za_payment.invoice_id')
          ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
          ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
          ->where('za_payment.invoice_id', $decryptedValue)
          ->orderBy('za_payment.sno', 'desc')
          ->first();
          
           if ($payment && !empty($payment->transaction)) {
                $transactionData = json_decode($payment->transaction, true);
                $payment->transaction_id = $transactionData['Transaction ID'] ?? null;
            }
        //   return $payment;  

          $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2','terms_3','terms_4', 'terms_5')->where('status' ,0)->get();
          // return $terms_conditions;
          
      $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
      // QR Code data
        $qrCodeData = [
            'Customer Name' => $payment->cus_name,
            'Customer ID' => $payment->customer_id,
            'Paid Amount' => $payment->amount
        ];

      return view('content.customer.customer_payment_print', [
          'payment' => $payment,
          'print_decryptedValue' => $print_decryptedValue,
          'gstPercentage' => $branch->gst_percentage,
          'terms' => $terms_conditions,
          'qrCodeData' => json_encode($qrCodeData)
      ]);
  }

//oldcustomer_invoice
  public function old_customer_invoice($id = '', $print_id = '', Request $request)
  {
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      $print_decryptedValue = $helper->encrypt_decrypt($print_id, 'decrypt');

      $payment = PaymentOldModel::select(
          'za_old_payments.invoice_id',
          'za_old_payments.paidAmount as amount',
          'za_old_payments.gst_amount',
            'za_old_payments.schedule_date',
          'za_old_customer.cus_name',
          'za_old_customer.customer_id',
          'za_old_customer.cus_mobile',
          'za_course.course_name',
          'za_branch.door_no',
          'za_branch.pincode',
          'za_branch.mobile',
          'za_branch.branch_name',
          'za_branch.branch_type',
          'za_branch.franchise_name',
          'za_branch.mail',
          'za_branch.area_street',
          'za_states.name as state_name',
          'za_cities.name as city_name'
      )
          ->join('za_old_customer', 'za_old_customer.sno', '=', 'za_old_payments.customer_id')
          ->join('za_course', 'za_course.sno', '=', 'za_old_payments.course_id')
          ->join('za_branch', 'za_branch.sno', '=', 'za_old_payments.branch_id')
          ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
          ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
          ->where('za_old_payments.invoice_id', $decryptedValue)
          ->orderBy('za_old_payments.sno', 'desc')
          ->first();
          // return $payment;  

          $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2','terms_3','terms_4', 'terms_5')->where('status' ,0)->get();
          // return $terms_conditions;
          
      $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
      // QR Code data
        $qrCodeData = [
            'Customer Name' => $payment->cus_name,
            'Customer ID' => $payment->customer_id,
            'Paid Amount' => $payment->amount
        ];
    //   return $payment;
      return view('content.customer.old_customer_payment_print', [
          'payment' => $payment,
          'print_decryptedValue' => $print_decryptedValue,
          'gstPercentage' => $branch->gst_percentage,
          'terms' => $terms_conditions,
          'qrCodeData' => json_encode($qrCodeData)
      ]);
  }
  function refund_eligibility(Request $request)
  {
    $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
    return view('content.customer.refund_eligibility_list', [
      'genaral_settings' => $genaral_settings
    ]);
  }
  public function autocomplete_customer(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $search = $request->get('term');

    // Fetch customer details matching the search term
    $customer = CustomerModel::select('sno', 'cus_email_id', 'customer_id', 'cus_mobile', 'cus_name', 'cus_pic')
      ->where(function ($query) use ($search) {
        $query->where('cus_email_id', 'LIKE', '%' . $search . '%')
          ->orWhere('customer_id', 'LIKE', '%' . $search . '%')
          ->orWhere('cus_mobile', 'LIKE', '%' . $search . '%');
      })
      ->where('branch_id', $branch_id)
      ->first();

    // Initialize response data
    $response = [
      'customer' => null,
      'attendance' => [
        'total_att_amount' => 0,
        'total_att_hours' => 0
      ],
      'course' => []
    ];

    if ($customer) {
      $response['customer'] = $customer;
      $helper = new \App\Helpers\Helpers();
      $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

      // Fetch training details for the customer
      $training = TrainingModel::where('customer_id', $customer->sno)
        ->where('status', 0)
        ->get();

      foreach ($training as $tr) {
        $batch_sno = $tr->batch_id;
        $course_sno = $tr->course_id;
        // Fetch course details
        $course_details = ManageCoursesModel::select(
          'za_course.course_name',
          'za_course.sno AS course_sno',
          'za_course_type.course_type_name',
          'za_course_subcategory.course_subcategory_name',
          'za_course_category.course_category_name',
          'za_course_type.course_days',
          'za_course_type.course_duration'
        )
          ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
          ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
          ->where('za_course.sno', $course_sno)
          ->first();

        if (!$course_details) {
          continue; // Skip if course details are not found
        }

        // Fetch batch details
        $batch_details = BatchModel::select(
          'za_batch.sno',
          'za_batch.batch_id',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_slot.slot_type_days',
          'za_batch.max_students',
          'za_batch.classroom_id',
          'za_class_room.class_room_name',
          'za_batch.course_id',
          'za_batch.course_type_id',
          'za_course_type.course_type_name',
          'za_batch.slot_id',
          'za_slot.slot_name',
          'za_slot_type.slot_type_name',
          'za_slot.start_time AS slot_start_time',
          'za_slot.end_time AS slot_end_time',
          'za_staff.staff_name'
        )
          ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
          ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
          ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
          ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
          ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
          ->where('za_batch.sno', $batch_sno)
          ->first();

        if (!$batch_details) {
          continue; // Skip if batch details are not found
        }

        // Calculate attendance details
        $attendance = AttendanceModel::selectRaw('SUM(total_cost) AS total_att_amount, SUM(total_duration) AS total_att_hours')
          ->where('status', 1)
          ->where('attendance', 'P')
          ->where('customer_id', $customer->sno)
          ->where('batch_id', $batch_details->sno)
          ->where('course_id', $course_details->course_sno)
          ->first();

        $response['attendance']['total_att_amount'] += $attendance->total_att_amount ?? 0;
        $response['attendance']['total_att_hours'] += $attendance->total_att_hours ?? 0;

        $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
        $courseProgress = $helper->get_course_percentage($tr->sno, $tr->customer_id);
        $refund_percentage = $genaral_settings->max_refund_percentage ?? 0;
        $batch_refund_days = $genaral_settings->batch_refund_days ?? 0;

        if ($courseProgress <= 20) {
          $color = '#ec0b03';
        } elseif ($courseProgress >= 90) {
          $color = '#16af08';
        } else {
          $color = '#ffa500';
        }

        $course_details->courseProgress      = $courseProgress;
        $course_details->courseProgresscolor = $color;

        $batch_details->message = '';
        $course_details->refund_percentage = $refund_percentage;
        if ($refund_percentage < $courseProgress) {
          $batch_details->message = "This course is $courseProgress% completed, refunds  the course is only allowed for courses below $refund_percentage% completion.";
        }
        if (isset($tr) && $tr->status == 2) {
          $batch_details->message = 'This course was dropped, so it could not be refund.';
        }
        $batch_details->message2 = '';
        if (isset($batch_details)) {
          $completed_days = $helper->batch_completed_days($batch_details->sno);
          $batch_details->completed_days = $completed_days;
          $batch_details->batch_refund_days = $batch_refund_days;
          if ($batch_refund_days < $completed_days) {
            $batch_details->message2 = "This batch is $completed_days days completed, refunds the course is only allowed for batches below $batch_refund_days days completed.";
          }
        }
        // Add course and batch details
        $response['course'][] = [
          'course' => $course_details,
          'batch' => $batch_details,
          'total_att_amount' => $attendance->total_att_amount ?? 0,
          'total_att_hours' => $attendance->total_att_hours ?? 0,
          'traning'  => $tr,
        ];
      }
    }

    return response()->json($response);
  }

  public function customer_change_course($id)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    // Split the decrypted value
    $exp        = explode('~', $decryptedValue);
    $cus_sno    = str_replace(' ', '', $exp[0] ?? '');

    $course_index = str_replace(' ', '', $exp[1] ?? '');
    $course_sno = str_replace(' ', '', $exp[2] ?? '');
    $batch_sno  = str_replace(' ', '', $exp[3] ?? '');
    $traning_sno  = str_replace(' ', '', $exp[4] ?? '');

    // Fetch customer details
    $customer_details = CustomerModel::where('sno', $cus_sno)->first();
    // Fetch course details based on course_sno (not cus_sno)
    $course_details = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name', 'za_course_category.course_category_name', 'za_course_type.course_days', 'za_course_type.course_duration')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
      ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->where('za_course.sno', $course_sno)  // Corrected the field here
      ->first();
    // Fetch batch details
    $batch_details = BatchModel::select(
      'za_batch.sno',
      'za_batch.batch_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_batch.max_students',
      'za_batch.classroom_id',
      'za_class_room.class_room_name',
      'za_batch.course_id',
      'za_batch.course_type_id',
      'za_course_type.course_type_name',
      'za_batch.slot_id',
      'za_slot.slot_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time as slot_start_time',
      'za_slot.end_time as slot_end_time',
      'za_staff.staff_name'
    )
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->where('za_batch.sno', $batch_sno)->first();

    // Check if course details exist
    if (!$course_details) {
      return redirect()->back()->with('error', 'Course not found.');
    }

    // Fetch the list of courses with the same course type
    $course_list = ManageCoursesModel::where('course_type_id', $course_details->course_type_id)->get();

    // Return the view with the course and customer details
    return view('content.customer.customer_change_course', [
      'course_details' => $course_details,
      'customer_details' => $customer_details,
      'batch_sno' => $batch_sno,
      'course_sno' => $course_sno,
      'traning_sno' => $traning_sno,
      'course_index' => $course_index,
      'cus_sno' => $cus_sno,
      'course_list' => $course_list,
      'batch_details' => $batch_details,
    ]);
  }
  public function customer_course_change(Request $request)
  {
    // return $request;
    // Extract request data
    $current_course_id = $request->current_course_id;
    $old_course_id = $request->old_course_id;
    $traning_sno = $request->traning_sno;
    $cus_sno = $request->cus_sno;
    $old_batch_id = $request->batch_id ?? 0;
    $current_batch_id = $request->batch_check_hidden_id ?? 0;
    $old_course_index = $request->old_course_index;

    // Fetch branch and user info
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $branch_check = BranchModel::where('sno', $branch_id)->first();
    $branch_code = optional($branch_check)->city_short_code; // Use optional to avoid null errors

    // Fetch batch details
    $batch_details = BatchModel::where('sno', $current_batch_id)->first();
    $batch = [
      'batch_id' => $batch_details->sno ?? 0,
      'slot_id' => $batch_details->slot_id ?? 0,
      'staff_id' => $batch_details->staff_id ?? 0,
      'start_date' => $batch_details->start_date ?? null,
      'end_date' => $batch_details->end_date ?? null,
    ];

    // Fetch old training details
    $old_training_details = TrainingModel::where('customer_id', $cus_sno)->where('sno', $traning_sno)
      ->first();

    // if (!$old_training_details) {
    //   return response()->json(['status' => 'error', 'message' => 'Old training details not found.'], 404);
    // }

    // Determine the new batch ID
    $batch_new = $batch['batch_id'] ?? $old_training_details->batch_id;
    // Create a record for the training change

    // return $old_training_details;
    // Generate training ID
    $year = date("Y");
    $cos_check = TrainingChangeModel::orderBy('sno', 'desc')->first();

    if (!$cos_check) {
      $training_id = "{$year}/{$branch_code}/TRC2005";
    } else {
      $data = $cos_check->traning_change_id;
      $slice = explode("/", $data);

      // Check if the slice has at least 3 elements
      if (count($slice) < 3) {
        // Handle the error: for example, log it or set a default value
        $training_id = "{$year}/{$branch_code}/TRC2005"; // Default value
      } else {
        // Extract the numeric part and increment
        $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number_cos = (int)$result_cos + 1;

        // Format the new training ID
        $training_id = "{$year}/{$branch_code}/" . sprintf("TRC%04d", $next_number_cos);
      }
    }


    $insert_training_change = TrainingChangeModel::create([
      'traning_change_id' => $training_id, // Assuming you want to use training_id here
      'branch_id' => $branch_id,
      'customer_id' => $cus_sno,
      'course_id' => $old_training_details->course_id,
      'batch_id' => $old_training_details->batch_id ?? 0,
      'batch_id_change' => $batch_new ?? 0,
      'course_id_change' => $current_course_id,
      'slot_id' => $old_training_details->slot_id ?? 0,
      'staff_id' => $old_training_details->staff_id ?? 0,
      'start_date' => $old_training_details->start_date ?? null,
      'end_date' => $old_training_details->end_date ?? null,
      'overall_fees' => $old_training_details->overall_fees,
      'gst_amount' => $old_training_details->gst_amount,
      'disc_amount' => $old_training_details->disc_amount,
      'paid_amount' => $old_training_details->paid_amount,
      'paid_gst' => $old_training_details->paid_gst,
      'total_amount' => $old_training_details->total_amount,
      'balance_amount' => $old_training_details->balance_amount,
      'balance_gst' => $old_training_details->balance_gst,
      'payment_id' => $old_training_details->payment_id,
      'created_by' => $user_id,
      'updated_by' => $user_id,
    ]);


    // if (!$insert_training_change) {
    //   return response()->json(['status' => 'error', 'message' => 'Failed to record training change.'], 500);
    // }

    // Update the old training details
    $old_training_details->course_id = $current_course_id;
    if ($batch) {
      $old_training_details->batch_id = $batch['batch_id'];
      $old_training_details->slot_id  = $batch['slot_id'];
      $old_training_details->staff_id = $batch['staff_id'];
      $old_training_details->start_date = $batch['start_date'];
      $old_training_details->end_date = $batch['end_date'];
    }

    $old_training_details->updated_by = $user_id;
    $old_training_details->save();

    // Fetch and update old payments
    $old_payments = PaymentModel::where('customer_id', $cus_sno)
      ->where('course_id', $old_course_id)
      ->where('branch_id', $branch_id)
      ->where('payment_id', $old_training_details->payment_id)
      ->get();

    foreach ($old_payments as $old_pay) {
      $old_pay->course_id = $current_course_id;
      $old_pay->updated_by = $user_id;
      $old_pay->save();
    }

    // Fetch customer details
    $customer_details = CustomerModel::where('sno', $cus_sno)->first();
    if ($customer_details) {
      $get_old_courses  = json_decode($customer_details->course_id, true) ?? [];
      $get_old_batch_id = json_decode($customer_details->batch_id, true) ?? [];

      // Update the old course and batch at the given index
      if (isset($get_old_courses[$old_course_index])) {
        $get_old_courses[$old_course_index] = $current_course_id;
      }

      if (isset($get_old_batch_id[$old_course_index])) {
        $get_old_batch_id[$old_course_index] = $current_batch_id ?: "0";
      } else {
        $get_old_batch_id[$old_course_index] = $current_batch_id ?: "0";
      }



      // Save updated course and batch details
      $customer_details->course_id = json_encode($get_old_courses);
      $customer_details->batch_id = json_encode($get_old_batch_id);
      $customer_details->save();
    }

    // Flash success message
    if ($customer_details) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Course Changed Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Change Course!'
      ]);
    }

    return redirect('/manage_customer');
    // return response()->json([
    //   'status' => 'success',
    //   'customer_details' => $customer_details,
    //   'batch_details' => $batch_details ?? null,
    // ]);
  }
  public function encrypt_ids(Request $request)
  {
    // Get the values sent from JavaScript
    $values = $request->input('values');
    // Encrypt the combined values
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }
    public function getBatch_change_course(Request $request)
  {
    $courseId = $request->input('course_id');
    $branchId = $request->user()->branch_id;

    // Subquery to calculate allocated students
    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno');

    // Fetch batch data with necessary joins
    $batches = BatchModel::where('za_batch.course_id', $courseId)
      ->where('za_batch.branch_id', $branchId)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_batch.status', '!=', 2)
      ->whereDate('za_batch.end_date', '>', Carbon::now())
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_batch.staff_id',
         'za_staff.staff_name',
        'za_staff.nick_name',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        'za_slot.end_time'
      )
      ->orderBy('za_batch.sno', 'desc')
      ->get();

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i A');
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i A');

      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      // Calculate available students
      $item->available_students = $item->max_students - $item->allocated_students;
      $course_progress=0;
      $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $item->course_id)
            ->count();
      $course_update_count = DB::table('za_syllabus_update')->where('za_syllabus_update.batch_id', $item->sno)
            ->where('za_syllabus_update.percentage','100')
            ->count();
      $course_progress = $course_topic_count > 0 ? number_format(($course_update_count/$course_topic_count)*100) : 0;
      $item->course_progress = $course_progress;
      return $item;
    });

    return response()->json([
      'status' => 200,
      'data' => $formattedBatches
    ]);
  }

  // vasanth customer drop
  public function customer_drop_course($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Fetch customer details
    $customer_details = CustomerModel::where('sno', $decryptedValue)->first();
    $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
    $check_list       = RefundChecklistModel::where('status', 0)->get();

    if (!$customer_details) {
      return redirect()->back()->with('error', 'Customer not found.');
    }

    // Fetch all training details related to the customer
    $training_details = TrainingModel::where('customer_id', $decryptedValue)->get();

    $courses_batches_payments = [];  // Array to store both course and batch details

    foreach ($training_details as $training) {
      // Fetch course details
      $course_details = ManageCoursesModel::select(
        'za_course.course_name',
        'za_course.sno AS course_sno',
        'za_course_type.course_type_name',
        'za_course_subcategory.course_subcategory_name',
        'za_course_category.course_category_name',
        'za_course_type.course_days',
        'za_course_type.course_duration'
      )
        ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
        ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
        ->where('za_course.sno', $training->course_id)
        ->first();

      // Fetch batch details
      $batch_details = BatchModel::select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        'za_staff.staff_name'
      )
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->where('za_batch.sno', $training->batch_id)
        ->first();

      // Add course and batch details as a pair
      $courses_batches_payments[] = [
        'course' => $course_details,
        'batch'  => $batch_details,
        'traning'  => $training,
      ];
    }
    // return $courses_batches_payments;
    return view('content.customer.customer_drop_course', [
      'customer_details' => $customer_details,
      'genaral_settings' => $genaral_settings,
      'check_list' => $check_list,
      'courses_batches'  => $courses_batches_payments
    ]);
  }
  // get student amount
  function student_attendance_amount()
  {
    $cus_sno    = $_POST['customer_id'];
    $batch_sno  = $_POST['batch_id'];
    $course_sno = $_POST['course_id'];
    $attendance = AttendanceModel::selectRaw('SUM(total_cost) AS total_att_amount, SUM(total_duration) AS total_att_hours')
      ->where('status', 1)
      ->where('attendance', 'P')
      ->where('customer_id', $cus_sno)
      ->where('batch_id', $batch_sno)
      ->where('course_id', $course_sno)
      ->first();

    // Handle null values by using the null coalescing operator
    $totalAttAmount = $attendance->total_att_amount ?? 0;
    $totalAttHours = $attendance->total_att_hours ?? 0;

    // Return both values as an array
    return [
      'total_att_amount' => $totalAttAmount,
      'total_att_hours' => $totalAttHours,
    ];
  }
  public function customer_drop(Request $request)
  {
    // return $request;
    // Fetch request data
    $cus_sno        = $request->customer_id;
    $checklist      = $request->checklist;
    $refund_chk_drp = $request->refund_chk_drp ?? 0;
    $drp_reason     = $request->drop_refund_reason;
    $course_sno     = $request->course_id_drop;
    $traning_sno    = $request->trans_id_drop;
    // Fetch user and branch details
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Handle refund-related logic
    $refund_chk      = $request->refund_chk ?? 0;
    $refund_amount   = $request->refund_amount ?? 0;
    $max_refund_date = $request->max_refund_date ? date('Y-m-d', strtotime($request->max_refund_date)) : null;
    $type = $refund_chk ? 1 : 0;  // 1 for refund, 0 for drop

    // Fetch old training details
    $training_details = TrainingModel::where('customer_id', $cus_sno)->where('sno', $traning_sno)->first();
    // return $training_details;

    if ($training_details) {
      // Insert new drop or refund entry
      $insert = DropRefundModel::create([
        'training_id'     => $traning_sno,
        'type'           => $type,
        'branch_id'      => $branch_id,
        'customer_id'    => $cus_sno,
        'course_id'      => $course_sno,
        'bh_status'      => 0,
        'ac_status'      => 0,
        'paid_amount' => $request->paid_amount,
        'min_deducted_amount' => $request->min_deducted_amount,
        'costing_amount' => $request->costing_amount,
        'costing_hours' => $request->costing_hours,
        'posible_eligible_amount' => $request->posible_eligible_amount,
        'refund_amount'  => $refund_amount,
        'max_refund_date' => $max_refund_date,
        'drop_refund_reason' => $drp_reason,
        'check_list'     => $checklist,
        'created_by'     => $user_id,
        'updated_by'     => $user_id,
        'status'         => 0
      ]);

      if ($insert) {
        // Update the training details
        $training_details->update([
          'status'           => 2,
          'drop_check'       => $refund_chk_drp,
          'refund_amount'    => $refund_amount,
          'refund_date_drp'  => $max_refund_date,
          'drop_reason'      => $drp_reason,
          'updated_by'       => $user_id
        ]);

        // Flash success message based on action type
        $message = $refund_chk ? 'Customer Refund Request Successfully!' : 'Customer Drop Successfully!';
        session()->flash('toastr', ['type' => 'success', 'message' => $message]);
        // return $insert;
        return $refund_chk ? redirect('/manage_customer_refund') : redirect('/manage_customer_drop');
      }
    } else {
      // Flash error message if training details not found
      session()->flash('toastr', ['type' => 'error', 'message' => 'Could not update the Drop Customer!']);
      return redirect('/manage_customer');
    }
  }

  // vasanth customer Drop END

  // akilan batch change
  public function customer_batch_change($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Split the decrypted value
        $exp = explode('~', $decryptedValue);
        $cus_sno = str_replace(' ', '', $exp[0] ?? '');

        $course_index = str_replace(' ', '', $exp[1] ?? '');
        $course_sno = str_replace(' ', '', $exp[2] ?? '');
        $batch_sno = str_replace(' ', '', $exp[3] ?? '');
        $traning_sno = str_replace(' ', '', $exp[4] ?? '');
        $selected_batch_id = $batch_sno;

        // Fetch customer details
        $customer_details = CustomerModel::where('sno', $cus_sno)->first();
        // Fetch course details based on course_sno (not cus_sno)
        $course_details = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name', 'za_course_category.course_category_name', 'za_course_type.course_days', 'za_course_type.course_duration')
            ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->leftJoin('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
            ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_course.sno', $course_sno) // Corrected the field here
            ->first();
        // Fetch batch details
        $batch_details = BatchModel::select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',
            'za_staff.staff_name'
        )
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where('za_batch.sno', $batch_sno)->first();

        // Check if course details exist
        if (!$course_details) {
            return redirect()->back()->with('error', 'Course not found.');
        }

        // Fetch the list of courses with the same course type
        $course_list = ManageCoursesModel::where('course_type_id', $course_details->course_type_id)->get();

        // Return the view with the course and customer details
        return view('content.customer.change_batch_course', [
            'course_details' => $course_details,
            'customer_details' => $customer_details,
            'batch_sno' => $batch_sno,
            'course_sno' => $course_sno,
            'course_index' => $course_index,
            'cus_sno' => $cus_sno,
            'course_list' => $course_list,
            'batch_details' => $batch_details,
            'traning_sno' => $traning_sno,

        ]);
    }

    public function batch_change_update(Request $request)
    {
        // return $request;
        // exit;
        $current_course_id = $request->current_course_id;
        $old_course_id = $request->old_course_id;
        $traning_sno = $request->traning_sno;
        $cus_sno = $request->cus_sno;
        $old_batch_id = $request->batch_id ?? 0;
        $current_batch_id = $request->batch_check_hidden_id ?? 0;
        $old_course_index = $request->old_course_index;

        // Fetch branch and user info
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $branch_check = BranchModel::where('sno', $branch_id)->first();
        $branch_code = optional($branch_check)->city_short_code; // Use optional to avoid null errors

        // Fetch batch details
        $batch_details = BatchModel::where('sno', $current_batch_id)->first();
        $batch = $batch_details ? [
            'batch_id' => $batch_details->sno,
            'slot_id' => $batch_details->slot_id ?? 0,
            'staff_id' => $batch_details->staff_id ?? 0,
            'start_date' => $batch_details->start_date ?? null,
            'end_date' => $batch_details->end_date ?? null,
        ] : null;

        // Fetch old training details
        $old_training_details = TrainingModel::where('customer_id', $cus_sno)
            ->where('sno', $traning_sno)
            ->first();
        if ($batch) {
            $old_training_details->batch_id = $batch['batch_id'];
            $old_training_details->slot_id = $batch['slot_id'];
            $old_training_details->staff_id = $batch['staff_id'];
            $old_training_details->start_date = $batch['start_date'];
            $old_training_details->end_date = $batch['end_date'];
        }

        $old_training_details->updated_by = $user_id;
        $old_training_details->update();

        $customer_details = CustomerModel::where('sno', $cus_sno)->first();
        if ($customer_details) {
            $get_old_courses = json_decode($customer_details->course_id, true) ?? [];
            $get_old_batch_id = json_decode($customer_details->batch_id, true) ?? [];

            // Update the old course and batch at the given index
            if (isset($get_old_courses[$old_course_index])) {
                $get_old_courses[$old_course_index] = $current_course_id;
            }

            if (isset($get_old_batch_id[$old_course_index]) && $current_batch_id) {
                $get_old_batch_id[$old_course_index] = $current_batch_id;
            }

            // Save updated course and batch details
            // $customer_details->course_id = json_encode($get_old_courses);
            $customer_details->batch_id = json_encode($get_old_batch_id);
            $customer_details->update();
        }

        // Flash message based on save result
        if ($old_training_details && $customer_details) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Batch Changed Successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not change the Batch!',
            ]);
        }
        return redirect('/manage_customer');
    }
    
  public function changeBranch(Request $request)
  {
    $validated = $request->validate([
      'branch_id' => 'required', // Validate that the branch exists
    ]);

    // Update the user's branch_id in the users table
    $user =  User::where('user_id', $request->user()->user_id)->first();
    if ($user) {
      $user->branch_id = $validated['branch_id'];
      $user->save();
    }

    return response()->json(['success' => true]);
  }
   public function changeRole(Request $request)
  {
    $validated = $request->validate([
      'role_id' => 'required', // Validate that the branch exists
    ]);

    // Update the user's role_id in the users table
     $user =  User::where('user_id', $request->user()->user_id)->where('role_id', $request->user()->role_id)->first();
    if ($user) {
      $user->role_id = $validated['role_id'];
      $user->save();
    }

    return response()->json(['success' => true]);
  }
   public function getUsersByRole(Request $request)
    {
        $request->validate([
            'role_id' => 'required|integer',
        ]);
        //   return $request->user()->branch_id;
    
        $users = User::where('za_staff.role_id', $request->role_id)->where('users.branch_id', $request->user()->branch_id)
                ->join('za_staff', 'users.user_id', '=', 'za_staff.sno')
                ->where('za_staff.status', 0) // Only active users
                ->get(['za_staff.sno','za_staff.staff_name']); // Fetch only required columns
    
        return response()->json(['users' => $users]);
    }
  public function changeUser(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,user_id', // Ensure user exists
        ]);
    
        $newUser = User::where('user_id', $request->user_id)->first();
    
        if (!$newUser) {
            return response()->json(['success' => false, 'message' => 'User not found.'], 404);
        }
    
        // Generate new token for the selected user
        $token = $newUser->createToken('SuperUserToken')->plainTextToken;
    
        // Store the token in session or database as per your requirement
        session(['super_user_token' => $token]); // For session-based auth
    
        // If storing in DB, update the super_user_token column
        $newUser->update(['super_user_token' => $token]);
    
        // Log in as the new user
        Auth::loginUsingId($newUser->id);
    
        return response()->json([
            'success' => true,
            'message' => 'User switched successfully.',
            'token' => $token
        ]);
    }
    public function CombinedCourse(Request $request)
    {
        $courseIds = $request->input('course_ids'); // ["7", "8"]

        $coursess = json_decode($courseIds);
        $courses = ManageCoursesModel::whereIn('sno', $coursess)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $courses
        ], 200);
    }
     public function getCourse_list(Request $request)
    {
         $course_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')->where('za_course.status', 0)->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')->orderBy('za_course.sno', 'desc')->get();

        $leadKnowledgeTags = $request->input('lead_knowledge_tags');
        $filteredCourseData = [];

        if ($leadKnowledgeTags) {
            try {
                $leadTagValues = json_decode($leadKnowledgeTags, true);
                $leadValues = array_map('strtolower', array_column($leadTagValues, 'value'));

                // Assuming you have a Course model that fetches all courses
                // Adjust as needed to fit your data source

                foreach ($course_list as $course) {
                    if ($course->knowledge_tags) {
                        try {
                            $knowledgeTags = json_decode($course->knowledge_tags, true);

                            foreach ($knowledgeTags as $tag) {
                                $tagValue = strtolower($tag['value']);
                                if (in_array($tagValue, $leadValues)) {
                                    $filteredCourseData[] = $course;
                                    break; // No need to check further tags for this course
                                }
                            }
                        } catch (Exception $e) {
                            Log::error('Error parsing knowledge_tag for course: ' . $course->course_name, ['error' => $e]);
                        }
                    }
                }
            } catch (Exception $e) {
                Log::error('Error parsing lead knowledge tags:', ['error' => $e]);
            }
        }

        return response()->json(['data' => $filteredCourseData]);
    }
    // Rajkumar
    public function change_course_offline(Request $request)
    {

    $course_sno = $request->course_sno;
    $id = $request->cus_mode_off_ch_sno;
    // return $request;
    $lead =  TrainingModel::where('customer_id', $id)->where('course_id', $course_sno)->first();
    // return $lead;
    $lead->course_mode_id  = 0;
    $lead->Update();

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Course Changed to Offline successfully!'
    ]);
    // return $request;
    return redirect('/manage_customer');
  }
  
  public function change_course_mode(Request $request)
  {
      // Extract the input values from the request
      $course_sno = $request->course_sno;
      $course_mode = $request->course_mode;
      $id = $request->cus_mode_on_ch_sno;
      $course_id = $request->inlineRadioOptions_course_online; // "1~31~null~166"
      
      // Split the $course_id value into separate components: index, course_id, batch_id, training_sno
      list($index, $course_id_from_request, $batch_id, $training_sno) = explode('~', $course_id);
      
      // Fetch the lead based on the customer ID and course ID
      $lead = TrainingModel::where('customer_id', $id)
                            ->where('course_id', $course_id_from_request)
                            ->first();

      // Check if the lead exists
      if (!$lead) {
          return response()->json([
              'success' => false,
              'message' => 'Lead not found.'
          ], 404);  // 404 Not Found
      }

      // Get the online fee for the selected course by index
      $online_fee = $request->online_fee;

      // Update the course mode
      if ($lead->course_mode_id == 1) {
          $lead->course_mode_id = $course_mode;
      } else if ($lead->course_mode_id == 0 && $lead->online_amount) {
          $lead->course_mode_id = $course_mode;
      }

      // Save the updated lead
      $lead->save();

      // Return success response as JSON
      return response()->json([
          'status'  => 200,
          'success' => true,
          'message' => 'Course changed successfully!'
      ]);
  }

  public function online_course($id,Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $branch_id = $request->user()->branch_id;

    if ($branch_id > 0) {
      $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
    } else {
      $get_course_change_days =  0;
    }
    // return $get_course_change_days;
    $customers = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.doj',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_lead.created_by as lead_created_by',
      'lead_staff.staff_name as lead_staff_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_staff.staff_name',
      'za_staff.sno as staff_sno',
      'za_branch.min_prd_cost',
    //   'za_training.course_mode_id',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
    //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_lead.created_by',
        'lead_staff.staff_name',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        // 'za_training.course_mode_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno',
        'za_branch.min_prd_cost'
      )
      ->where('za_customer.sno', $id) // Group by payment_id to get unique entries
      ->first();
        // return $customers;
    $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
    $carouselDetails = [];

    // Get payment details and course info
    $paymentDetailss = DB::table('za_payment')
        ->select('za_payment.status', 'za_payment.nextPayDate')
        ->where('za_payment.customer_id', $customers->sno)
        ->where('za_payment.status', 0)
        ->get();

    $paymentget = DB::table('za_training')
        ->where('customer_id', $customers->sno)
        ->whereIn('status', [0, 2])
        ->get();

    $courseIds = $paymentget;
    $batchIds = json_decode($customers->batch_id);

    foreach ($courseIds as $index => $courseId) {
        $batchId = $batchIds[$index] ?? [];

        // Retrieve course details
        $course = DB::table('za_course')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
            ->where('za_course.sno', $courseId->course_id)
            ->first();

        // Retrieve batch details
        $batch = DB::table('za_batch')
            ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
            ->where('za_batch.sno', $courseId->batch_id)
            ->first();

        // Retrieve payment details
        $paymentDetails = DB::table('za_training')
            ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
            ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
            ->where('za_training.customer_id', $customers->sno)
            ->where('za_training.course_id', $courseId->course_id)
            ->where('za_training.status', '!=', 3)
            ->where('za_payment.status', '!=', 3)
            ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
            ->groupBy('za_payment.total_amount')
            ->first();

        $paymentPercentage = 0;
        if ($paymentDetails && $paymentDetails->total_amount > 0) {
            $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
            if($paymentPercentage>=100){
                
                $paymentPercentage = 100;
                
            }
        }

        // Check if attendance exists for the specific batch and customer
        $attendanceRecords = AttendanceModel::where('customer_id', $customers->sno)
            ->where('batch_id', $batchId)
            ->where('attendance', 'P')
            ->get();

        // Initialize course progress percentage
        $courseProgress = 0;
        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
            ->count();
            
             $helper = new \App\Helpers\Helpers();
          $courseProgress    = $helper->get_course_percentage($courseId->sno, $customers->sno);

        // batch count by course id
        $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();

        
      $pay = PaymentModel::where('za_payment.customer_id', $customers->sno)->where('za_payment.status','!=',2)
        ->select('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name','za_payment.customer_id')
        ->join('za_course', 'za_course.sno', '=', 'za_payment.course_id') // Select only the fields you need
        ->groupBy('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name', 'za_payment.customer_id') // Group by payment_id to get unique entries
        ->get();
      // return $pay;
          
      // Get the course ID from the request
      $selectedPaymentId = $request->input('payment_id', $pay[0]->payment_id); // Use the first course if none selected

      // Retrieve payments where course_id matches any of the course IDs associated with the customer
      $payments = PaymentModel::where('payment_id', $selectedPaymentId)
        ->where('amount', '>=', 0)
        ->where('paidAmount', '>=', 0)
        ->where('gst_amount', '>=', 0)
        ->where('balanceFee', '>=', 0)
        ->where('za_payment.status','!=',2)
        ->orderBy('nextPayDate', 'asc')
        ->get();
    //   return $payments;

        // Add course and batch details to the array
        $carouselDetails[] = [
            'course_sno' => $courseId->course_id ?? null,
            'course_mode_id' => $courseId->course_mode_id ?? null,
            'online_course_fee' => $course->online_fee ?? null,
            'batch_sno' => $batchId ?? null,
            'batch_count' => $batch_count ?? 0,
            'traning_sno' => $courseId->sno ?? null,
            'traning_status' => $courseId->status ?? null,
            'course_name' => $course->course_name ?? null,
            'course_type_name' => $course->course_type_name ?? null,
            'batch_name' => $batch->batch_name ?? null,
            'start_date' => $batch->start_date ?? null,
            'end_date' => $batch->end_date ?? null,
            'slot_name' => $batch->slot_name ?? null,
            'staff_name' => $batch->staff_name ?? null,
            'payment_percentage' => $paymentPercentage,
            'course_progress' => $courseProgress,
            'payments' =>$payments
        ];
    }

    // Attach data to the customer item
    $customers->carousel_details = $carouselDetails;
    $customers->paymentDetailss = $paymentDetailss;

    $customers->cus_initial = strtoupper(substr($customers->cus_name, 0, 1));
    $customers->payment_percentage = number_format(($customers->total_paid_amount / $customers->total_amount) * 100, 1);
    $training_details = [];
    $training_details = TrainingModel::select('*')->where('customer_id', $customers->sno)->get();
    $customers->training_details = $training_details;
    // return $customers;
 
    $branch_id = $request->user()->branch_id;
    // Get branch details and calculate GST percentage
    $branch = BranchModel::where('sno', $branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    $minimumamount = $branch ? $branch->min_amnt_receive : 1000;

    // return $payments;

    $total_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
    // ->where('customer_id', $id)
        ->select('total_amount')
        ->first()
        ->total_amount ?? 0;

    $paid_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status','!=',2)
    // ->where('customer_id', $id)
        ->sum('paidAmount');

    $balance_amount = $total_amount - $paid_amount;

    // $balance_amount = $total_amount - $paid_amount;

    // $total_amount = number_format($total_amount, 2);
    // $paid_amount = number_format($paid_amount, 2);
    // $balance_amount = number_format($balance_amount, 2);

    $total_amount = $total_amount;
    $paid_amount = $paid_amount;
    $balance_amount = $balance_amount;

    $invoice_chk = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
    $year = date("Y");
    if (!$invoice_chk) {
        $invoice_id = 'EA/' . $year . '/INV2005';
    } else {
        $data = $invoice_chk->invoice_id;
        $slice = explode("/", $data);
        if (count($slice) >= 3) {
            $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
        } else {
            $next_inv_number = 2005;
        }
        $invoice_id = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
    }
    // return $customers;
    return view('content.customer.course_online', compact(
        'pay',
        'selectedPaymentId',
        'customers',
        'invoice_id',
        'total_amount',
        'paid_amount',
        'balance_amount',
        'gstPercentage', 
        'minimumamount',
        'get_course_change_days','customers'
    ));
  }

  public function change_course_Online($id, Request $request)
  {
      $helper = new \App\Helpers\Helpers();
  
      // Validation
      $validator = Validator::make($request->all(), [
          'pay_amount' => 'required|numeric',
      ]);
  
      if ($validator->fails()) {
          return response([
              'status' => 401,
              'message' => 'Incorrect format input fields',
              'error_msg' => $validator->messages()->get('*'),
              'data' => null,
          ], 200);
      }
      // return $request;
      $transactionAll = $request->input('transaction_all');

      // Check if discount_amount_hidden exists and is not null/empty
      if (!empty($transactionAll['discount_amount_hidden'])) {
          $original = $transactionAll['discount_amount_hidden'];
      } else {
          $original = $transactionAll['payment_amount'];
      }

      // Other variables
      $receipt_id = $transactionAll['receipt_id'];
      $paymentMode = $request->input('payment_mode');
      $selectedCourseId = $request->input('course_id');
      $transaction = json_encode($transactionAll);
      $initialPayDateFormatted = now()->format('Y-m-d');
     
      // Get the PaymentModel by sno (ID)
      $get_ids = PaymentModel::where('sno', $id)->where('status', '!=', 2)->first();
  
      if (!$get_ids) {
          return response([
              'status' => 404,
              'message' => 'Payment record not found',
              'error_msg' => 'Payment record not found',
              'data' => null,
          ], 404);
      }
  
      $pay = PaymentModel::where('za_payment.customer_id', $get_ids->customer_id)->where('za_payment.status', '!=', 2)
          ->select('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name')
          ->join('za_course', 'za_course.sno', '=', 'za_payment.course_id') // Select only the fields you need
          ->groupBy('za_payment.payment_id', 'za_payment.course_id', 'za_course.course_name') // Group by payment_id to get unique entries
          ->get();
  
      // Get the course ID from the request
      $selectedPaymentId = $request->input('payment_id', $pay[0]->payment_id); // Use the first course if none selected
  
      // Retrieve payments where course_id matches any of the course IDs associated with the customer
      $payments = PaymentModel::where('payment_id', $selectedPaymentId)
          ->where('amount', '>=', 0)
          ->where('paidAmount', '>=', 0)
          ->where('gst_amount', '>=', 0)
          ->where('balanceFee', '>=', 0)
          ->where('za_payment.status', '!=', 2)
          ->orderBy('nextPayDate', 'asc')
          ->get();
  
      $total_amount = PaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
          ->select('total_amount')
          ->first()
          ->total_amount ?? 0;
  
      $total_amount = number_format($total_amount, 2);
      $balance_amount = 0;
  
      // Generate the invoice ID
      $invoice_chk = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
      $year = date("Y");
      if (!$invoice_chk) {
          $invoice_id = 'EA/' . $year . '/INV2005';
      } else {
          $data = $invoice_chk->invoice_id;
          $slice = explode("/", $data);
          if (count($slice) >= 3) {
              $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
              $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
          } else {
              $next_inv_number = 2005;
          }
          $invoice_id = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
      }
  
      // Extract necessary information
      $pay_course_id = $get_ids->course_id;
      $pay_customer_id = $get_ids->customer_id;
      $total_course_amount = $get_ids->total_amount;
      // return $pay_course_id;
  
      // Retrieve payment details
      $pay_det = PaymentModel::where('course_id', $pay_course_id)
          ->where('status', '!=', 2)
          ->where('customer_id', $pay_customer_id)
          ->get();
  
      $payment_id = PaymentModel::where('sno', $id)->where('status', '!=', 2)->first();

      // return $payment_id;
      if ($payment_id) {
          $updatedTotalAmount = $payment_id->total_amount + $original;
  
          $payment_up = new PaymentModel();
          $payment_up->payment_id = $payment_id->payment_id;
          $payment_up->customer_id = $payment_id->customer_id;
          $payment_up->course_id = $payment_id->course_id;
          $payment_up->initialPayDate = date('Y-m-d');
          $payment_up->nextPayDate = date('Y-m-d');
          $payment_up->amount = $original;
  
          $payment_up->paidAmount = $original;
          $payment_up->invoice_id = $invoice_id;
          $payment_up->gst_amount = $original * 0.18;
          $payment_up->payment_mode_label = $paymentMode;
          $payment_up->transaction = $transaction;
          $payment_up->balanceFee = 0;
          $payment_up->is_online = 1;
  
          $payment_up->total_amount = $updatedTotalAmount;
          $payment_up->created_by = $request->user()->user_id;
          $payment_up->updated_by = $request->user()->user_id;
          $payment_up->branch_id = $request->user()->branch_id;
          $payment_up->status = 1;

          // return $payment_up;
          $payment_up->save();
  
          // Update related records
          foreach ($pay_det as $relatedRecord) {
              if ($relatedRecord->payment_id == $payment_id->payment_id) {
                  $relatedRecord->total_amount = $updatedTotalAmount;
                  $relatedRecord->save();
              }
          }
          $transaction = json_decode($transaction, true);  // decode JSON string into an associative array

          // return $transaction;
           //****************** */ create the usage history ManageCouponHistoryModel
           $couponid = ManageCouponModel::where('coupon_code', $transaction['new_coupon_code'])->first();

           if ($couponid) {
               ManageCouponHistoryModel::updateOrCreate(
                   [
                       'coupon_id' => $couponid->sno ?? null, // Unique identifier
                       'used_by' => $payment_id->customer_id ?? null, // The user who used the coupon
                       'amount' => $transaction['discount_amount_hidden'] ?? 0, // Discount amount
                   ],
                   [
                       'modal_id' => 2, // Reference to the customer or related model
                       'amount' => $transaction['discount_amount_hidden'] ?? 0, // Discount amount
                       'used_date' => now(), // Current timestamp
                       'coupon_desc'  => "Online",
                       'created_by' => $request->user()->user_id,
                       'updated_by' => $request->user()->user_id,
                   ]
               );
               
                 ManageCouponModel::updateOrCreate(
                 ['sno' => $couponid->sno], // Assuming 'sno' is the unique identifier for the coupon
                 [
                     'used_count' => \DB::raw('COALESCE(used_count, 0) + 1') // Increment used_count by 1, starting from 0 if null
                 ]
             );
           }
          // return $pay_det;
          // Update TrainingModel related records
          $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->where('course_id', $selectedCourseId)->where('customer_id', $payment_id->customer_id)->first();
          // return $training_id;
          if ($training_id) {
              $gstPercentage = $training_id->gst_percentage ?? 0;
              $paidGst = $payment_id->paidAmount * ($gstPercentage / 100);
  
              TrainingModel::updateOrCreate(
                  ['payment_id' => $payment_id->payment_id,
                  'course_id' => $selectedCourseId,  
                  'customer_id' => $payment_id->customer_id 
                  ],
                  [
                      'paid_amount'    => $training_id->paid_amount + $original,
                      'paid_gst'       => $training_id->paid_gst + $paidGst,
                      'balance_amount' => $training_id->balance_amount - $original,
                      'balance_gst'    => $training_id->balance_gst - $paidGst,
                      'total_amount'   => $training_id->total_amount + $original + $paidGst,
                      'course_mode_id' => 1,  // Online
                      'online_amount'  => $original,
                      'overall_fees'   => $training_id->overall_fees += $original,
                  ]
              );
              // return $training_id;
          }
        
  
          // Create SubLedger and Transaction Models
          $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();
          $customer = CustomerModel::where('sno', $payment_id->customer_id)->first();
  
          $branch_code = $branch_check->city_short_code;
          $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();
  
          if (!$ledger_check) {
              $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
          } else {
              $data = $ledger_check->subledger_id;
              $slice = explode("/", $data);
              $result_led = preg_replace('/[^0-9]/', '', $slice[2]);
              $next_number_cos = (int)$result_led + 1;
              $request_cos = sprintf("SUB%04d", $next_number_cos);
              $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
          }
  
          // Create SubLedger record
          $subledger = new SubLedgerModel();
          $subledger->ledger_id = 1;  // Example ledger ID
          $subledger->subledger_id = $subledger_id;
          $subledger->subledger_name = ucfirst($customer->cus_name);
          $subledger->subledger_desc = 'Course Mode Online fees';
          $subledger->branch_id = $branch_check->sno;
          $subledger->created_by = $request->user()->user_id;
          $subledger->updated_by = $request->user()->user_id;
          // return $subledger;
          $subledger->save();
  
          // Create Transaction entry
          $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
          if (!$tr_check) {
              $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
          } else {
              $data = $tr_check->transaction_id;
              $slice = explode("/", $data);
              $result_tra = preg_replace('/[^0-9]/', '', $slice[2]);
              $next_number_cos = (int)$result_tra + 1;
              $request_tr = sprintf("TRA%04d", $next_number_cos);
              $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
          }
  
          // Create Transaction record
          $transaction = new TransactionModel();
          $transaction->transaction_id = $transaction_id;
          $transaction->transaction_type = 'Credit';
          $transaction->transaction_name = 'Customer';
          $transaction->trans_source_id = $customer->customer_id;
          $transaction->credit = $original;
          $transaction->tax = $original * 0.18;
          $transaction->total_amount = $original + ($original * 0.18);
          $transaction->invoice_id = $payment_up->invoice_id;
          $transaction->receipt_id = $receipt_id;
          $transaction->training_id = $training_id->sno;
          $transaction->subledger_id = $subledger->sno;
          $transaction->ledger_id = 1;
          $transaction->branch_id = $branch_check->sno;
          $transaction->created_by = $request->user()->user_id;
          $transaction->updated_by = $request->user()->user_id;

          // return $transaction; 
          $transaction->save();
          
      }
  
      return response()->json([
        'status' => 200,
        'message' => 'Payment updated successfully',
        'redirect' => url('/manage_customer')
    ]);
  }
  
  public function PayEditOnline($id, Request $request)
  {
    // return $id;
    $course_id = $request->course_id;
    $invoice_id = $request->invoice_id;
    // Fetch the payment record along with course name
    $pay = PaymentModel::where('za_payment.sno', $id)->where('za_training.course_id', $course_id)->where('za_payment.status','!=', 2)
      ->leftJoin('za_training', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->select('za_payment.*', 'za_course.course_name', 'za_batch.batch_name', 'za_course.sno As course_sno') // Select relevant fields
      ->first();

      // return $pay;

    // Check if the payment record exists
    if (!$pay) {
      return response([
        'status'    => 404,
        'message'   => 'Payment not found',
        'error_msg' => 'No payment record found with the given ID',
        'data'      => null
      ], 404);
    }

    // Retrieve the GST percentage from the branch
    $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

    // If the branch doesn't exist, you can handle it here as well
    if (!$branch) {
      return response([
        'status'    => 404,
        'message'   => 'Branch not found',
        'error_msg' => 'No branch record found for the user',
        'data'      => null
      ], 404);
    }

    // Format the amount if needed (you can customize this)
    $pay->amount = $pay->amount;

    // return $pay;

    // Include the GST percentage in the response
    return response([
      'status'    => 200,
      'message'   => 'Payment details retrieved successfully',
      'error_msg' => null,
      'data'      => [
        'payment'        => $pay,
        'gst_percentage' => $branch->gst_percentage // Include GST percentage here
      ]
    ], 200);
  }
  
  public function old_customer(Request $request)
  {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $cus_fill = $request->cus_fill ?? '';
        $cus_status_fill = $request->cus_status_fill ?? '';
        
        $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
     }
          
          $notStartedCount=$notYetStartedCount;
        
        
         $old_customer_onhold=OldCustomerModel::where('za_old_customer.branch_id', $branch_id)
            ->whereDate('za_old_customer.retain_date', \Carbon\Carbon::now())
            ->where('za_old_customer.status', 4)
            ->get();
    
        foreach($old_customer_onhold as $oldcus){
          $upd_old_status =OldCustomerModel::where('za_old_customer.sno', $oldcus->sno)
          ->first();
          if($upd_old_status){
            $upd_old_status->status = 1;
            $upd_old_status->update();
          }
        }
    
        $customers = OldCustomerModel::select(
        'za_old_customer.*',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_staff.staff_name',
        DB::raw('IF(za_old_payments.customer_id IS NOT NULL, true, false) AS has_payment')
    )
    ->leftJoin('za_staff', 'za_old_customer.staff_id', '=', 'za_staff.sno')
    ->leftJoin('za_old_payments', 'za_old_customer.sno', '=', 'za_old_payments.customer_id')
    ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_old_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
    ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->groupBy(
    'za_old_customer.sno',
    'za_old_customer.customer_id',
    'za_old_customer.lead_id',
    'za_old_customer.branch_id',
    'za_old_customer.cus_name',
    'za_old_customer.cus_gender',
    'za_old_customer.cus_dob',
    'za_old_customer.cus_mobile',
    'za_old_customer.cus_cmpltd_date',
    'za_old_customer.staff_id',
    'za_old_customer.batch_st_date',
    'za_old_customer.batch_end_date',
    'za_old_customer.doj',
    'za_old_customer.total_amnt',
    'za_old_customer.course_type_id',
    'za_old_customer.course_id',
    'za_old_customer.paid_amnt',
    'za_old_customer.cert_check',
    'za_old_customer.placement_check',
    'za_old_customer.issue_date',
    'za_old_customer.retain_date',
    'za_old_customer.created_by',
    'za_old_customer.created_at',
    'za_old_customer.updated_by',
    'za_old_customer.updated_at',
    'za_old_customer.status',
    // Plus any other joined columns you SELECT
    'za_course_type.course_type_name',
    'za_course.course_name',
    'za_old_payments.customer_id',
    'za_staff.staff_name'
);


// Filter by name or mobile if provided
if (!empty($cus_fill)) {
    $customers->where(function ($query) use ($cus_fill) {
        $query->where('za_old_customer.cus_name', 'LIKE', "%{$cus_fill}%")
              ->orWhere('za_old_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
    });
}

// Filter by status if provided
if (!empty($cus_status_fill)) {
    if ($cus_status_fill == 5) {
        $customers->where('za_old_customer.status', 0);
    } else {
        $customers->where('za_old_customer.status', $cus_status_fill);
    }
} else {
    $customers->whereIn('za_old_customer.status', [0, 1, 2, 3, 4]);
}

// Paginate the final result
$customers = $customers->paginate($perpage);

        
        // return $customers;
    
        return view('content.customer.old_customer_list', [
            'customers' => $customers,
            'perpage' => $perpage,
            'cus_fill' =>$cus_fill,
            'notYetStartedCount' => $notStartedCount,
            'cus_status_fill'=>$cus_status_fill
        ]);
    }

  
  public function old_customer_add($id,Request $request)
  {

      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      // Check if decryption failed
      if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }
      // return $decryptedValue;

      $cus = LeadModel::select('lead_name', 'branch_id','sno', 'lead_mobile', 'lead_gender', 'lead_dob')->where('sno', $decryptedValue)->first();

      if ($branch_id != 0)
      {
        $staff = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->get();
      }

    // return $staff;
      return view('content.customer.old_customer_add', ['decryptedValue' => $decryptedValue, 'cus'=> $cus, 'staff' => $staff]);
  }
  public function old_customer_status_change(Request $request)
  {
    $id = $request->sts_change_id;
    $sts = $request->sts_change_type;
    $retain_date = $request->retain_date ? date('Y-m-d', strtotime($request->retain_date)): null;


    // Find the record
    $OldCustomerModel = OldCustomerModel::where('sno', $id)->select('sno', 'status')->first();

    if ($OldCustomerModel) {
      $OldCustomerModel->status = $sts;
       $OldCustomerModel->retain_date = $retain_date;
      $OldCustomerModel->save(); // Use save() instead of update()
      // return $OldCustomerModel;
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Update Status!'
      ]);
    }
    return redirect('/customer/old_customer');
  }

    public function customerAdd(Request $request)
    {
        $helper = new Helpers();
    
        $validator = Validator::make($request->all(), [
            'cus_name' => 'required|max:255'
        ]);
    
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            // return $request->all();
            
            $OldCustomerModel_chk = OldCustomerModel::where('cus_mobile', $request->cus_mobile)->where('status', 0)->first();
            
           if($OldCustomerModel_chk){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Customer alerdy Exit !'
                ]);
                return redirect('customer/old_customer');
            }
            //   return $request->cus_mobile;
            
            $branch_id = $request->user()->branch_id;
            $cus_name  = $request->cus_name;
            $cus_mobile = $request->cus_mobile;
            $cus_dob    = date('Y-m-d', strtotime($request->cus_dob));
            $lead_id    = $request->lead_id;
            $cus_gender = $request->inlineRadioOptions;
            $cus_cmpltd_date =  date('Y-m-d', strtotime($request->course_cmpltd_date));
            $staff_id      = $request->staff_id;
            $batch_st_date = date('Y-m-d', strtotime($request->batch_star_date));
            $batch_end_date = date('Y-m-d', strtotime($request->batch_end_date));
            $doj           = date('Y-m-d', strtotime($request->doj));
            $total_amnt    = $request->total_amnt;
            $course_id     = $request->course_id;
            $course_type_id = $request->course_type_id;
            $paid_amnt     = $request->paid_amnt;
            $cert_check    = $request->cert_check ?? 0;
            $placement_check = $request->placement_check ?? 0;
            $issue_date    = date('Y-m-d', strtotime($request->issue_date));
    
            $user_id        = $request->user()->user_id;
    
            // Check if customer already exists
            $chk = OldCustomerModel::where('lead_id', $lead_id)->where('status', '!=', 2)->first();
    
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Customer already been created..!'
                ]);
            } else {
                $category_check = OldCustomerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    
                if (!$category_check) {
                    $year = substr(date("y"), -2);
                    $customer_id = "OCUS-0001/" . $year;
                } else {
                    $data = $category_check->customer_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $request = sprintf("OCUS-%04d", $next_number);
                    $year = substr(date("y"), -2);
                    $customer_id = $request . '/' . $year;
                }
    
                $add_category = new OldCustomerModel();
                $add_category->customer_id       = $customer_id;
                $add_category->branch_id         = $branch_id;
                $add_category->lead_id           = $lead_id;
                $add_category->cus_name          = ucwords($cus_name);
                $add_category->cus_gender        = $cus_gender;
                $add_category->cus_dob           = $cus_dob;
                $add_category->cus_mobile        = $cus_mobile;
                $add_category->cus_cmpltd_date   = $cus_cmpltd_date;
                $add_category->staff_id          = $staff_id;
                $add_category->batch_st_date     = $batch_st_date;
                $add_category->batch_end_date    = $batch_end_date;
                $add_category->doj               = $doj;
                $add_category->total_amnt        = $total_amnt;
                $add_category->course_type_id    = $course_type_id;
                $add_category->course_id         = $course_id;
                $add_category->paid_amnt         = $paid_amnt;
                $add_category->cert_check        = $cert_check;
                $add_category->placement_check   = $placement_check;
                $add_category->issue_date        = $issue_date;
                $add_category->created_by        = $user_id;
                $add_category->updated_by        = $user_id;
    
                $add_category->save();
    
                if ($add_category) {
                     $lead_update = LeadModel::where('sno', $lead_id)->first();
                     $lead_update->status = 10;
                     $lead_update->lead_status_id = 5;
                     $lead_update->save();
                    
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Customer added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Customer!'
                    ]);
                }
            }
            // return $request;
            return redirect('customer/old_customer');
        }
    }
    public function old_customer_edit($id, Request $request)
    {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    // return $decryptedValue;
        $customers = OldCustomerModel::select(
          'za_old_customer.*',
          'za_course_type.course_type_name',
          'za_course.course_name',
          'za_staff.staff_name',
        )
      ->leftJoin('za_staff', 'za_old_customer.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_old_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_old_customer.branch_id', $branch_id)
      ->where('za_old_customer.sno', $decryptedValue)
      ->first();

    // return $customers;

    if ($branch_id != 0) {
      $staff = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->get();
    }

    return view('content.customer.old_customer_edit', ['decryptedValue' => $decryptedValue, 'cus' => $customers, 'staff' => $staff]);
  }
  
  
    public function update_old_customer(Request $request)
    {
    // Validation rules
    $validator = Validator::make($request->all(), [
      'cus_name' => 'required|max:255', // Ensuring the sno exists in old_customers table
    ]);
    
    
    $OldCustomerModel_chk = OldCustomerModel::where('cus_mobile', $request->cus_mobile)->where('sno','!=',$request->sno)->select('sno', 'status')->first();
            
    if($OldCustomerModel_chk){
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Customer alerdy Exit !'
        ]);
        return redirect('customer/old_customer');
    }

    // Extract data from the request
    $branch_id = $request->user()->branch_id;
    $cus_name = ucwords($request->cus_name);  // Capitalize customer name
    $cus_mobile = $request->cus_mobile;
    $cus_dob = date('Y-m-d', strtotime($request->cus_dob));
    $lead_id = $request->lead_id;
    $sno = $request->sno;
    $cus_gender = $request->inlineRadioOptions;
    $staff_id = $request->staff_id;
    $batch_st_date = date('Y-m-d', strtotime($request->batch_star_date));
    $batch_end_date = date('Y-m-d', strtotime($request->batch_end_date));
    $doj = date('Y-m-d', strtotime($request->doj));
    $total_amnt = $request->total_amnt;
    $course_id = $request->course_id;
    $course_type_id = $request->course_type_id;
    $paid_amnt = $request->paid_amnt;
    $cert_check = $request->cert_check ?? 0;
    $placement_check = $request->place_check ?? 0;
    $placed_company = $request->placed_company_details ?? '';
    $old_staff_name = $request->staff_name ?? '';
    $issue_date = date('Y-m-d', strtotime($request->issue_date));

    // Check if a customer with the same name exists for a different lead
    // $chk = OldCustomerModel::
    //     where('lead_id', '!=', $lead_id)  // Checking for the same name but different lead
    //   ->where('status', '!=', 2)  // Ignore deleted customers
    //   ->first();

    // if ($chk) {
    //   return response([
    //     'status' => 401,
    //     'message' => 'Error',
    //     'error_msg' => 'Name has already been assigned to another lead!',
    //     'data' => null,
    //   ], 200);
    // }
    $user_id        = $request->user()->user_id;

    // Proceed with updating or adding the customer record
    $upd_lead = OldCustomerModel::updateOrCreate(
      [
        'sno' => $sno  // Ensure we are updating the correct record by sno (unique identifier)
      ],
      [
        'branch_id' => $branch_id,
        'cus_name' => $cus_name,
        'cus_gender' => $cus_gender,
        'cus_dob' => $cus_dob,
        'cus_mobile' => $cus_mobile,
        'staff_id' => $staff_id,
        'batch_st_date' => $batch_st_date,
        'batch_end_date' => $batch_end_date,
        'doj' => $doj,
        'total_amnt' => $total_amnt,
        'course_type_id' => $course_type_id,
        'course_id' => $course_id,
        'paid_amnt' => $paid_amnt,
        'cert_check' => $cert_check,
        'placement_check' => $placement_check,
        'issue_date' => $issue_date,
        'placed_company' => $placed_company,
        'old_staff_name' => $old_staff_name,
        'updated_by' => $user_id
      ]
    );

    // Check if the customer record was successfully updated or created
    if ($upd_lead) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Customer updated/added successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update/add the customer!'
      ]);
    }

    // Redirect to the old customers page
    return redirect('customer/old_customer');
  }
    public function getCourses(Request $request)
    {
      $courseTypeId = $request->input('course_type_id');  
      
      $courses = ManageCoursesModel::where('course_type_id', $courseTypeId)
                  ->where('status', 0)  
                  ->get();

                  
      return response()->json([
          'status' => 200,
          'data' => $courses,
      ]);
  }
//   Phone Number Search 
public function LeadDetails(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $search = $request->get('term');
    
        if (!$search) {
            return response()->json(['message' => 'Phone Number is required'], 400);
        }
    
        $cus = CustomerModel::select('za_customer.cus_name', 'za_customer.cus_mobile','za_customer.created_by', 'za_customer.cus_email_id','za_course.course_name', 'za_batch.batch_name', 'za_staff.staff_name') 
            ->leftJoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno') 
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id') 
            ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_training.batch_id') 
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_training.staff_id') 
            ->where('za_customer.cus_mobile', 'LIKE', "%{$search}%")
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->first();
    
        
        $lead = Leadmodel::select('za_lead.lead_name', 'za_lead.lead_mobile', 'za_lead.lead_email_id', 'za_lead.status','za_lead.created_by', 'za_lead.lead_group', 'za_lead_source.lead_source_name','za_staff.staff_name') 
            ->leftJoin('za_lead_source', 'za_lead_source.sno', '=', 'za_lead.lead_source_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_lead.lead_mobile', 'LIKE', "%{$search}%")
            ->where('za_lead.branch_id', $branch_id)
            ->first();
    
          return response()->json([
              'status' => 200,
              'cus' => $cus,
              'lead' => $lead,
          ]);
    
        return response()->json(['message' => 'No customer or lead found'], 404);
    }
     public function getCallHistoryCustomer(Request $request)
    {
        $leadId = $request->lead_id;
        $status = '';
        $incoming_call_count = 0;
        $outgoing_call_count = 0;
        $dailed_call_count = 0;
        $missed_call_count = 0;
        $caller = DB::table('za_lead')->select('za_lead.*')
        ->where('za_lead.sno', $leadId)
        ->first();
  
        $lead_mobile =$caller->lead_mobile;
        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo; 
        
        $calls = DB::table('za_call_tracker')
            ->select('za_call_tracker.*', 'za_staff.staff_name', 'za_job_position.job_position_name')
            ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
            ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
                $query->where('customer_phone_no', $lead_mobile)
                      ->orWhere('customer_phone_no', $phoneWithCountryCode);
            })
            ->where('za_call_tracker.count_status', 1); // Moved to ensure filtering before ordering
        
        $calls = $calls->orderBy('za_call_tracker.sno', 'desc')->get();
        foreach($calls as $call) {
            if ($call->call_status == 1) {
                $status = "Incoming";
            }elseif ($call->call_status == 0) {
                $status == "Outgoing";
            } elseif ($call->call_status == 4) {
                $status == "Dialed";
            } elseif ($call->call_status == [2,3]) {
              $status == "Missed & Rejected";
            }
          }

        $incoming_call_count = DB::table('za_call_tracker')
        ->select('za_call_tracker.*', 'za_staff.staff_name', 'za_job_position.job_position_name')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
            $query->where('customer_phone_no', $lead_mobile)
                  ->orWhere('customer_phone_no', $phoneWithCountryCode);
        })
        ->where('za_call_tracker.count_status', 1)      
        ->where('za_call_tracker.call_status', 1)                            
        ->count();

        $outgoing_call_count = DB::table('za_call_tracker')
        ->select('za_call_tracker.*', 'za_staff.staff_name', 'za_job_position.job_position_name')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
            $query->where('customer_phone_no', $lead_mobile)
                  ->orWhere('customer_phone_no', $phoneWithCountryCode);
        })
        ->where('za_call_tracker.count_status', 1)         
        ->where('za_call_tracker.call_status', 0)                            
        ->count();

        $dailed_call_count = DB::table('za_call_tracker')
        ->select('za_call_tracker.*', 'za_staff.staff_name', 'za_job_position.job_position_name')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
            $query->where('customer_phone_no', $lead_mobile)
                  ->orWhere('customer_phone_no', $phoneWithCountryCode);
        })
        ->where('za_call_tracker.count_status', 1)         
        ->where('za_call_tracker.call_status', 4)                            
        ->count();

        $missed_call_count = DB::table('za_call_tracker')
        ->select('za_call_tracker.*', 'za_staff.staff_name', 'za_job_position.job_position_name')
        ->join('za_staff', 'za_staff.sno', '=', 'za_call_tracker.branch_staff_id')
        ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
            $query->where('customer_phone_no', $lead_mobile)
                  ->orWhere('customer_phone_no', $phoneWithCountryCode);
        })
        ->where('za_call_tracker.count_status', 1)         
        ->where('za_call_tracker.call_status', [2,3])                            
        ->count();
  
        // return $status;
  
        return response()->json([
            'calls' => $calls,
            'caller' => $caller,
            'status'=> $status,
            'incoming_call_count' => $incoming_call_count,
            'outgoing_call_count' => $outgoing_call_count,
            'dailed_call_count' => $dailed_call_count,
            'missed_call_count' => $missed_call_count
        ]);
    }
    
     public function fetchOldCustomerSchedule(Request $request)
    {
      $branch_id = $request->user()->branch_id;

      $customers = OldCustomerModel::where('za_old_customer.sno', $request->customer_id)->select(
                      'za_old_customer.*',
                      'za_course_type.course_type_name',
                      'za_course.course_name',
                      'za_staff.staff_name',
                      )
                      ->leftJoin('za_staff', 'za_old_customer.staff_id', '=', 'za_staff.sno')
                      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_old_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
                      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                      ->where('za_old_customer.branch_id', $branch_id)
                      ->first();

        if ($customers) {
            return response()->json([
                'success' => true,
                'data' => $customers
            ]);
        }

        return response()->json(['success' => false]);
    }
    // public function addOldCustomerSchedule(Request $request)
    // {
    //     $branch_id      = $request->user()->branch_id;
    //     $user_id        = $request->user()->user_id;
    //     $payment_amount = $request->payment_amount;
    //     $totalAmount    = $request->total_amount;
    //     $customer_id    = $request->customer_id;
    //     $course_id      = $request->course_id;
    //     $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

    //     $branch_code = $branch_check->city_short_code;
    //     // Generate Old Payment ID
    //     $category_check = PaymentOldModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    //     if (!$category_check) {
    //         $year = date("y");
    //         $old_payment_id = $year . '/' . $branch_code . '/' . "OPAY2005";
    //     } else {
    //         $data = $category_check->old_payment_id;
    //         $slice = explode("/", $data);
    //         $result = preg_replace('/[^0-9]/', '', $slice[0]);
    //         $next_number = (int)$result + 1;
    //         $request_cus = sprintf("OPAY%04d/%s", $next_number_invoi);
    //         $year = date("Y");
    //         $old_payment_id = $year . '/' . $branch_code . '/' . $request_cus;
    //     }

    //     // Generate Invoice ID
    //     $invoci_check = PaymentOldModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    //     if (!$invoci_check) {
    //         $year = date("y");
    //         $invoice_id = $year . '/' . $branch_code . '/' . "OINV2005";
    //     } else {
    //         $data = $invoci_check->invoice_id;
    //         $slice = explode("/", $data);
    //         $result = preg_replace('/[^0-9]/', '', $slice[0]);
    //         $next_number_invoi = (int)$result_coss + 1;
    //         $request_cus = sprintf("OINV%04d/%s", $next_number_invoi);
    //         $year = date("Y");
    //         $invoice_id = $year . '/' . $branch_code . '/' . $request_cus;
    //     }



    //     // Validate request input
    //     $request->validate([
    //         'schedule_dates'   => 'required|array',
    //         'schedule_dates.*' => 'required|date_format:d-M-Y',
    //         'schedule_amounts' => 'required|array',
    //         'schedule_amounts.*' => 'required|numeric|min:1',
    //     ]);

    //     // Schedule dates and amounts
    //     $schedule_dates   = $request->schedule_dates;
    //     $schedule_amounts = $request->schedule_amounts ?? []; // Ensure it's an array
    //     $total_amount     = is_array($schedule_amounts) ? array_sum($schedule_amounts) : 0;

    //     $gst_amount = ($payment_amount * 18) / 100; // GST based on first payment


    //     // **First Record (Default Entry)**
    //     $oldcustomerpay = new PaymentOldModel();
    //     $oldcustomerpay->customer_id        = $customer_id;
    //     $oldcustomerpay->old_payment_id     = $old_payment_id;
    //     $oldcustomerpay->branch_id          = $branch_id;
    //     $oldcustomerpay->course_id          = $course_id;
    //     $oldcustomerpay->schedule_date      = date('Y-m-d'); // Current date
    //     $oldcustomerpay->amount             = $totalAmount;
    //     $oldcustomerpay->paidAmount         = $payment_amount;
    //     $oldcustomerpay->gst_amount         = $gst_amount; // GST only on first record
    //     $oldcustomerpay->balanceFee         = $totalAmount - $payment_amount; // Initial balance
    //     $oldcustomerpay->total_amount       = $totalAmount;
    //     $oldcustomerpay->payment_mode_label = $request->payment_mode_label ?? null;
    //     $oldcustomerpay->invoice_id	        = $invoice_id ?? null;
    //     $oldcustomerpay->created_by         = $user_id;
    //     $oldcustomerpay->updated_by         = $user_id;
    //     $oldcustomerpay->status             = 1;
    //     $oldcustomerpay->save(); // Save first record


    //     // **Process Scheduled Payments**
    //     // Initialize remaining balance before processing installments
    //     $remaining_balance = $totalAmount - $payment_amount;

    //     // **Process Scheduled Payments**
    //     foreach ($schedule_dates as $key => $date) {
    //         $installment_amount = $schedule_amounts[$key];
    //         $gst_per_installment = ($installment_amount * 18) / 100; // Calculate GST per installment
    //         $remaining_balance -= $installment_amount;

    //         $oldcustomerpay = new PaymentOldModel();
    //         $oldcustomerpay->customer_id        = $customer_id;
    //         $oldcustomerpay->old_payment_id     = $old_payment_id;
    //         $oldcustomerpay->branch_id          = $branch_id;
    //         $oldcustomerpay->course_id          = $course_id;
    //         $oldcustomerpay->schedule_date      = date('Y-m-d', strtotime($date));
    //         $oldcustomerpay->amount             = $installment_amount;
    //         $oldcustomerpay->paidAmount         = 0;
    //         $oldcustomerpay->gst_amount         = $gst_per_installment;
    //         $oldcustomerpay->balanceFee         = $remaining_balance; // Set correct balance BEFORE deduction
    //         $oldcustomerpay->total_amount       = $totalAmount;
    //         $oldcustomerpay->payment_mode_label = $request->payment_mode_label ?? null;
    //         $oldcustomerpay->invoice_id	        = null;
    //         $oldcustomerpay->created_by         = $user_id;
    //         $oldcustomerpay->updated_by         = $user_id;
    //         $oldcustomerpay->status             = 0; // Mark as paid if balance is zero
    //         // return $oldcustomerpay;
    //         $oldcustomerpay->save();

    //         // Deduct installment from balance AFTER saving

    //     }



    //     return response()->json(['success' => true, 'message' => 'Customer schedule added successfully!']);
    // }
    
    public function addOldCustomerSchedule(Request $request)
    {
        $branch_id      = $request->user()->branch_id;
        $user_id        = $request->user()->user_id;

        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;
        // Generate Old Payment ID
        $year = date("Y");
        $prefix = $year . '/' . $branch_code . '/OPAY';
        // Get the latest Old Payment ID based on the highest number
        $category_check = PaymentOldModel::where('old_payment_id', 'LIKE', $prefix . '%')
          ->orderByRaw("CAST(SUBSTRING_INDEX(old_payment_id, 'OPAY', -1) AS UNSIGNED) DESC")
          ->first();

          if (!$category_check) {
          $old_payment_id = $prefix . '2005';
          } else {
          $last_id = $category_check->old_payment_id;
          $parts = explode("/", $last_id);
          $last_number = preg_replace('/[^0-9]/', '', end($parts)); // Extract only numbers from "OPAYxxxx"

          $next_number = (int) $last_number + 1;
          $old_payment_id = $prefix . sprintf("%04d", $next_number); // Format as OPAYxxxx
          }

          $year = date("Y");
          $invoice_prefix = 'EA/' . $year . '/INV';

          // Get the latest Invoice ID with the highest number
          $invoice_chk_cus_old = PaymentOldModel::where('invoice_id', 'LIKE', $invoice_prefix . '%')
              ->where('status', 1)
              ->orderByRaw("CAST(SUBSTRING_INDEX(invoice_id, 'INV', -1) AS UNSIGNED) DESC")
              ->first();

          if (!$invoice_chk_cus_old) {
              $invoice_id_cus_old = $invoice_prefix . '2005';
          } else {
              $last_invoice = $invoice_chk_cus_old->invoice_id;
              $parts = explode("/", $last_invoice);
              $last_inv_number = preg_replace('/[^0-9]/', '', end($parts)); // Extract numbers from "INVxxxx"

              $next_inv_number = (int) $last_inv_number + 1;
              $invoice_id_cus_old = $invoice_prefix . sprintf("%04d", $next_inv_number); // Format as INVxxxx
          }




        // Validate request input
        $request->validate([
            'schedule_dates'   => 'required|array',
            'schedule_dates.*' => 'required|date_format:d-M-Y',
            'schedule_amounts' => 'required|array',
            'schedule_amounts.*' => 'required|numeric|min:1',
        ]);
        $payment_amountgst = $request->payment_amount;
        $totalAmountgst    = $request->total_amount;
        $customer_id    = $request->customer_id;
        $course_id      = $request->course_id;
        // Schedule dates and amounts
        $schedule_dates   = $request->schedule_dates;
        $schedule_amountsgst = $request->schedule_amounts ?? []; // Ensure it's an array

        $gstRate = 18; // Assuming 18% GST

        // Convert payment amount to inclusive GST amount
        $payment_amount = round($payment_amountgst / (1 + ($gstRate / 100)));
        $totalAmount = round($totalAmountgst / (1 + ($gstRate / 100)));

        $schedule_amounts = array_map(function($amount) use ($gstRate) {
            return round($amount / (1 + ($gstRate / 100))); // Convert to exclusive amount & round
        }, $schedule_amountsgst);



        // return $schedule_amounts;

        $total_amount     = is_array($schedule_amounts) ? array_sum($schedule_amounts) : 0;

        $gst_amount = round(($payment_amount * 18) / 100); // GST based on first payment exclusive


        // **First Record (Default Entry)**
        $oldcustomerpay = new PaymentOldModel();
        $oldcustomerpay->customer_id        = $customer_id;
        $oldcustomerpay->old_payment_id     = $old_payment_id;
        $oldcustomerpay->branch_id          = $branch_id;
        $oldcustomerpay->course_id          = $course_id;
        $oldcustomerpay->schedule_date      = date('Y-m-d'); // Current date
        $oldcustomerpay->amount             = $totalAmount;
        $oldcustomerpay->paidAmount         = $payment_amount;
        $oldcustomerpay->gst_amount         = $gst_amount; // GST only on first record
        $oldcustomerpay->balanceFee         = $totalAmount - $payment_amount; // Initial balance
        $oldcustomerpay->total_amount       = $totalAmount;
        $oldcustomerpay->payment_mode_label = $request->payment_mode_label ?? null;
        $oldcustomerpay->invoice_id	        = $invoice_id_cus_old ?? null;
        $oldcustomerpay->created_by         = $user_id;
        $oldcustomerpay->updated_by         = $user_id;
        $oldcustomerpay->status             = 1;
        $oldcustomerpay->save(); // Save first record


        // **Process Scheduled Payments**
        // Initialize remaining balance before processing installments
        $remaining_balance = round($totalAmount - $payment_amount);

        // **Process Scheduled Payments**
        foreach ($schedule_dates as $key => $date) {
            $installment_amount = $schedule_amounts[$key];
            $gst_per_installment = round(($installment_amount * 18) / 100); // Calculate GST per installment
            $remaining_balance -= $installment_amount;

            $oldcustomerpay = new PaymentOldModel();
            $oldcustomerpay->customer_id        = $customer_id;
            $oldcustomerpay->old_payment_id     = $old_payment_id;
            $oldcustomerpay->branch_id          = $branch_id;
            $oldcustomerpay->course_id          = $course_id;
            $oldcustomerpay->schedule_date      = date('Y-m-d', strtotime($date));
            $oldcustomerpay->amount             = $installment_amount;
            $oldcustomerpay->paidAmount         = 0;
            $oldcustomerpay->gst_amount         = $gst_per_installment;
            $oldcustomerpay->balanceFee         = $remaining_balance; // Set correct balance BEFORE deduction
            $oldcustomerpay->total_amount       = $totalAmount;
            $oldcustomerpay->payment_mode_label = $request->payment_mode_label ?? null;
            $oldcustomerpay->invoice_id	        = null;
            $oldcustomerpay->created_by         = $user_id;
            $oldcustomerpay->updated_by         = $user_id;
            $oldcustomerpay->status             = 0; // Mark as paid if balance is zero
            // return $oldcustomerpay;
            $oldcustomerpay->save();

            // Deduct installment from balance AFTER saving

        }



        return response()->json(['success' => true, 'message' => 'Customer schedule added successfully!']);
    }
    
    
     public function payRemainderMessage(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'pay_id'  => 'required',
            
        ]);

          // If validation fails, return a response with errors
          if ($validator->fails()) {
              return response([
                  'status'    => 401,
                  'message'   => 'Incorrect format input fields',
                  'error_msg' => $validator->messages()->get('*'),
                  'data'      => null,
              ], 200);
          }
          $branch_id  = $request->user()->branch_id;
          $user_id   = $request->user()->user_id;
          $pay_id=$request->pay_id;
          //   Send Communication 
          $branch_data = BranchModel::where('sno', $branch_id)->first();
          $branch_name = " ";
          if ($branch_data->branch_type == 1) {
              $branch_name = $branch_data->branch_name;
          } elseif ($branch_data->branch_type == 2) {
              $branch_name = $branch_data->franchise_name;
          }

           $customerData=DB::table('za_payment')->select('za_payment.*','za_customer.cus_name','za_customer.cus_mobile','za_customer.cus_email_id','za_course.course_name')->leftJoin('za_customer','za_customer.sno','=','za_payment.customer_id')->leftJoin('za_course','za_course.sno','=','za_payment.course_id')->where('za_payment.sno',$pay_id)->first();

             //   SMS
             $gst_amount =isset($customerData->amount) ? round(($customerData->amount * 18) / 100) : 0;
             $totalAmount=isset($customerData->amount) ? $customerData->amount + $gst_amount:'0';
             $customer_mobiles =isset($customerData->cus_mobile)? $customerData->cus_mobile: '';
             $customer_mails = isset($customerData->cus_email_id)?$customerData->cus_email_id: '';
             $customer_names = isset($customerData->cus_name)?$customerData->cus_name: 'Mr/Mrs';
             $cre_mobile = isset($branch_data->cre_mobile) ?$branch_data->cre_mobile:'9677781155';
             $pay_course_id=isset($customerData->course_id) ?$customerData->course_id:'0';
            
             $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();

             $tempdate      = $customerData->nextPayDate ?? null;
             if ($customer_mobiles) {
                 $branch_data     = BranchModel::where('sno', $branch_id)->first();
                     $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '006_PaymentRemainder')->first();
                     $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
                     $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
                     $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
                     $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
                     $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
                     $mobile_number   = $country_code . $customer_mobiles;
 
                     // Replace placeholders with actual values
                     $replacement_values = [$customer_names, $tempdate, $cre_mobile];
                     $message_content    = preg_replace_callback(
                         '/\{#var#\}/',
                         function () use (&$replacement_values) {
                             return array_shift($replacement_values);
                         },
                         $message_content
                     );
 
                     $route    = "default";
                     $postData = [
                         'authkey' => $authkey,
                         'mobiles' => $mobile_number,
                         'message' => $message_content,
                         'sender'  => $sender_id,
                         'route'   => $route,
                     ];
 
                     // API URL
                     $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
 
                     // Initialize the resource
                     $ch = curl_init();
                     curl_setopt_array($ch, [
                         CURLOPT_URL            => $url,
                         CURLOPT_RETURNTRANSFER => true,
                         CURLOPT_POST           => true,
                         CURLOPT_POSTFIELDS     => $postData,
                         CURLOPT_SSL_VERIFYHOST => 0,
                         CURLOPT_SSL_VERIFYPEER => 0,
                     ]);
                     // Get response
                     $response = curl_exec($ch);
                     // return $response;
                     $err = curl_error($ch);
                     curl_close($ch);
                 
                 
             }
             // Email
             if ($customer_mails) {
                     $email_template_id = 9; // thank you template
                     $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
 
                     $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);
 
                     $helper             = new \App\Helpers\Helpers();
                     $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                     $paymentDate        = $tempdate;
                     $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                     $paymentAmount      = $paymentAmt . ". Rs";
                     $content            = $emailTemplate->email_subject;
                     $content            = str_replace('#name', $customer_names, $content);
                     $content            = str_replace('#course', $coursename->course_name??'Course', $content);
                     $content            = str_replace('#amount', $paymentAmount, $content);
                     $content            = str_replace('#dueDate', $paymentDate, $content);
                     $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
                     $branchNo           = $branch_data->mobile??'9677781155';
                     $branchemail        = $branch_data->mail??'info@elysiumacademy.org';
                     $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                     $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                     $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                     $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
 
                     $mailData = [
                         'url'         => 'Eapl.com',
                         'subject'     => $dynamicSubject,
                         'content'     => $content,
                         'branchNo'    => $branchNo,
                         'branchemail' => $branchemail, // Use the message content from the request
                         'fbLink'      => $fbLink,      // Use the message content from the request
                         'instaLink'   => $instaLink,   // Use the message content from the request
                         'salesMobile' => $branch_data->sales_mobile??'9677781155',
                     ];
 
                     $to_address   = $customer_mails;
                     $from_address = 'elysiumacademy@elysium.community';
                     $from_name    = 'Elysium Academy���';
                     
                     Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
 
                 
 
             }
             // Whatsapp messages
             if ($customer_mobiles) {
                 $cre          = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                 $hasHeader    = false; // Example flag: set based on template
                 $hasBody      = false; // Example flag: set based on template
                 $components   = [];
                 $couponCode   = " ";
                     // Example flag: set based on template
                     $components_trans = [];
                     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                // $currentHour = date('H'); // Get current hour in 24-hour format
                     if ($currentHour >= 5 && $currentHour < 12) {
                         $greeting = 'Good Morning';
                     } elseif ($currentHour >= 12 && $currentHour < 18) {
                         $greeting = 'Good Afternoon';
                     } else {
                         $greeting = 'Good Evening';
                     }
                      $helper             = new \App\Helpers\Helpers();
                     $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                     // $paymentDate        = date($common_date_format);
                     $paymentDate        = $tempdate;
                     $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                     $paymentAmount      = $paymentAmt . ". Rs";
 
                     $templateName = 'elysium_academy_pay_reminder2';
                     $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/payment_remainder.jpg';
                     $bodyText     = [
                         [
                             'type'           => 'text',
                             'text'           => $greeting,
                             'parameter_name' => 'greet_msg',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $customer_names,
                             'parameter_name' => 'customer_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $coursename->course_name??'Course',
                             'parameter_name' => 'course_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $paymentAmount,
                             'parameter_name' => 'amount',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $paymentDate,
                             'parameter_name' => 'due_date',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->cre_mobile ?? '9677781155',
                             'parameter_name' => 'cre_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->mail??'info@elysiumacademy.org',
                             'parameter_name' => 'contact_email',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_name??'Elysium Academy',
                             'parameter_name' => 'branch_name',
                         ],
                         [
                             'type'           => 'text',
                             'text'           => $branch_data->sales_mobile ?? '9677781155',
                             'parameter_name' => 'contact_no',
                         ],
                         
                     ];
                     $components_trans[] = [
                         'type'       => 'header',
                         'parameters' => [
                             [
                                 'type'  => 'image',
                                 'image' => [
                                     'link' => $headerImage, // Dynamically set header image
                                 ],
                             ],
                         ],
                     ];
 
                     $components_trans[] = [
                         'type'       => 'body',
                         'parameters' => $bodyText,
                     ];
                     $dynamicParameters         = $templateParameters[$templateName] ?? [];
                     $WhatsAppBusinessAccountId = $this->businessId;
                     $accessToken               = $this->accessToken;
                     $fromPhoneNumberId         = $this->phoneNumberId;
 
                     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
 
                     $to           = $customer_mobiles;
                     $languageCode = 'en';
 
                     if (strpos($to, '+91') !== 0) {
                         $to = '+91' . $to;
                     }
 
                     $message = 'test~message';
 
                     $payload = [
                         'messaging_product' => 'whatsapp',
                         'to'                => $to,
                         'type'              => 'template',
                         'template'          => [
                             'name'       => $templateName,
                             'language'   => [
                                 'code' => $languageCode,
                             ],
                             'components' => $components_trans,
                         ],
                     ];
 
                     $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                     
                     if ($response['status'] == 200) {

                        $log_branch_id =$customerData->branch_id ?? $branch_id;
                        $unique_id =$customerData->customer_id ?? 0;
                        $source ='Customer';
                        $log_phone_no =$to;
                        $log_template_name =$templateName;

                          $save_log = $this->WhatsappSendLog(
                            $response,
                            $payload,
                            $log_phone_no,
                            $log_template_name,
                            $user_id,
                            $log_branch_id,
                            $unique_id,
                            $source
                        );
                        
                     }
                     
 
                 
             }
           
            if ($response['status'] == 200) {
                    $pay_remainder_send = PaymentModel::where('sno', $pay_id)->first();
                    if ($pay_remainder_send) {
                        $pay_remainder_send->updated_by   = $user_id;
                        $pay_remainder_send->remainder_msg_date = date('Y-m-d');
                        $pay_remainder_send->update();
                    }
                // Include the webhook response in your API response
                return response([
                    'status'         => 200,
                    'message'        => 'Message sent successfully!',
                    'data'           => $response['data'],
                    'response_data'  => json_encode($response),
                ], 200);
            } else {
                return response([
                    'status'    => 404,
                    'message'   => 'Failed to send message',
                    'error_msg' => $response['error'],
                ], 400);
            }

        return response([
            'status'    => 200,
            'message'   => "Message sent successfully",
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }


   public function NotStartedCustomer(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 100);
      $offset = ($page - 1) * $perpage;

     $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->pluck('za_training.customer_id');
        
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
    }
  
      // return $processed_not_started_customers;
  
      $customers = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
      //   'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->whereNotIn('za_customer.sno', $drop_ids)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          // 'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->whereIn('za_customer.sno', $processed_not_started_customers)
        ->where('za_customer.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->paginate($perpage);
      // $customers = $customers->unique('payment_id');
      
      $customers_fill = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.doj',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->where('za_customer.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->get();
  
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->where('za_payment.status', '!=', 3)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
                
                 $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
          
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
            
            
            //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
             $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
           if (isset($end_date) && $end_date < $currentDate) {
               $allEndDate = false;
              //  break;
           }
            if (isset($start_date) && $start_date > $currentDate) {
              $allSchedule = true;//  break;
            }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
             elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
            // Increment customer count based on status
            if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
                $activeCount++;
            } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
                $notYetStartedCount++;
            } elseif ($isDropped) {
                $dropCount++;
            } elseif ($isSchedule) {
                $inactiveCount++;
            }
        
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
        $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
        $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
  
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
      // alagu
      // current month customer
       $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
          $percentageover = 0;
          
          $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
          if ($branch_id != 0) {
              $totalLeadCounts->where('za_lead.branch_id', $branch_id);
          }
          if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
              // User can only view their own data
              $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
          } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
              // User can view all data (no additional filters needed)
      
          }
          $totalLeadCount = $totalLeadCounts->count();
  
          $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
          if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
          }
          $totalCustomerCount = $totalCustomerCount->count();
  
          if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
          }
  
          $percentageover = round($percentageover) . '%';
  
          $leadOriginal = DB::table('za_customer')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_customer.created_by', '!=', 0)
          ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
  
  
      // coversion rate current month
      // Get the count of leads for the current month
      $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($branch_id != 0) {
        $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();
      $percentagecurrentmonth = 0;
      if ($currentMonthLeadCount > 0) {
        $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
      }
  
      $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
   
      // return $processed_not_started_customers;
      return view('content.customer.not_started_customer_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'customer_name_fill' => '',
        'cus_fill' => '',
        'staff_fill' => '',
        'status_fill' => '',
        'course_type_list' => $course_type_list,
        'course_type_fill' => '',
        'leadOriginalCount' => $leadOriginalCount,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'inactiveCount' => $inactiveCount,
        'percentageover' => $percentageover,
        'batch_name_fill' => '',
        'slot_list' => $slot_list,
        'perpage' => $perpage,
        'slot_name_fill' => '',
        'slot_type_list' => $slot_type_list,
        'slot_type_name_fill' => '',
        'course_name_fill' => '',
        'date_filter' => '',
        'fin_yr_fill' => '',
        'gender_fill' => '',
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
      ])->with('filter_on', false);
    }
  
    public function NotStartedListFilter(Request $request)
    {
  
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 100);
      $offset = ($page - 1) * $perpage;
      $helper = new \App\Helpers\Helpers();

      $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

        $drop_ids = DB::table('za_drop_refund')
          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
          ->where('za_drop_refund.bh_status', 1)
          ->pluck('za_training.customer_id');
          
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
    }
      
      // return $request;
      if ($branch_id) {
        $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
      } else {
        $get_branch_type = 0;
      }
      $cus_fill = $request->cus_fill ?? '';
      $customer_name_fill = $request->customer_name_fill_sno ?? '';
      $staff_fill = $request->staff_name_fill_sno ?? '';
      $status_fill = $request->input('status_fill', 'all'); 
      $mobile_fill = $request->mobile_fill ?? '';
      $gender_fill = $request->gender_fill ?? '';
      $course_type_fill = $request->course_type_fill_sno ?? '';
      $course_name_fill = $request->course_name_fill_sno ?? '';
      $batch_name_fill = $request->batch_name_fill_sno ?? '';
      $slot_name_fill = $request->slot_name_fill_sno ?? '';
      $slot_type_name_fill = $request->slot_type_name_fill ?? '';
      $date_filter = $request->dt_fill_issue_rpt;
      $from_date_filter = $request->from_date_fillter_textbox;
      $to_date_filter = $request->to_date_fillter_textbox;
      $fin_yr_fill = $request->fin_yr_fill ?? '';
  
      // return $request;
      $query = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
      //   'za_training.course_mode_id',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count')
  
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->where('za_customer.status', 0)
        ->where('za_customer.branch_id', $branch_id)
        ->whereNotIn('za_customer.sno', $drop_ids)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          // 'za_training.course_mode_id',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
  
        )
        ->whereIn('za_customer.sno', $processed_not_started_customers)
        ->orderBy('za_customer.sno', 'desc');
      // date filter query
      // Date Filtering Logic
      if ($date_filter == "today") {
        $todayDate = date("Y-m-d");
        $query->whereDate('za_customer.created_at', $todayDate);
      } elseif ($date_filter == "week") {
        $today = date('l');
        if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
      } elseif ($date_filter == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
      } elseif ($date_filter == "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $query->where('za_customer.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->where('za_customer.created_at', '<=', $toDate);
        }
      }
      // Financial year filter
      if ($fin_yr_fill) {
        $helper = new \App\Helpers\Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
    
        if ($selected_fin_year) {
            // Decode the financial month as an array
            $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
    
            // Check if $monthsArray is valid
            if (is_array($monthsArray) && count($monthsArray) > 0) {
                $currentYear = now()->year; // Current year
                
                // Filter leads that match any of the selected months
                $leads->where(function ($q) use ($monthsArray, $currentYear) {
                    $q->whereYear('za_customer.created_at', $currentYear)
                      ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
                });
            }
        }
      }
  
      if ($branch_id > 0) {
        $query->where('za_customer.branch_id', $branch_id);
      }
  
      if ($cus_fill) {
        $query->where(function ($customer) use ($cus_fill) {
          $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
        });
      }
      if ($customer_name_fill) {
        $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
      }
      if ($mobile_fill) {
        $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
      }
      if ($gender_fill) {
        $query->where('za_customer.cus_gender', $gender_fill);
      }
      if ($course_type_fill) {
        $query->where('za_course_type.sno', $course_type_fill);
      }
      if ($course_name_fill) {
        $query->where('za_course.sno', $course_name_fill);
      }
      if ($staff_fill) {
        $query->where('za_staff.sno', $staff_fill);
      }
      if ($batch_name_fill) {
        $query->where('za_batch.sno', $batch_name_fill);
      }
      if ($slot_name_fill) {
        $query->where('za_slot.sno', $slot_name_fill);
      }
      if ($slot_type_name_fill) {
        $query->where('za_slot_type.sno', $slot_type_name_fill);
      }
      
  
      // Fetch Branch list ordered by sno in descending order
      $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
               ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->whereNotIn('za_payment.status', [3,2])
                ->where('za_payment.paidAmount', '>',0)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
             $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
         
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
    
            // Set customer status based on conditions
             //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
              $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
               if (isset($end_date) && $end_date < $currentDate) {
                   $allEndDate = false;
                  //  break;
               }
               if (isset($start_date) && $start_date > $currentDate) {
                  $allSchedule = true;//  break;
                }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
              elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
        // Increment customer count based on status
        if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
            $activeCount++;
        } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
            $notYetStartedCount++;
        } elseif ($isDropped) {
            $dropCount++;
        } elseif ($isSchedule) {
            $inactiveCount++;
        }
    
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
         $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
         $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
    
      if ($status_fill) {
          if ($status_fill == 'active') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'not_started') {
              $customers = $customers->filter(function ($item) {
                  return !$item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'drop') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_cus_drop;
              });
          } elseif ($status_fill == 'inactive') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_end_date;
              });
          }
      }  
  
      session()->forget('branch_id_ses');
      session()->forget('branch_type_ses');
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
  
      // alagu
      $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
      $percentageover = 0;
          
      $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
      if ($branch_id != 0) {
          $totalLeadCounts->where('za_lead.branch_id', $branch_id);
      }
      if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
          // User can only view their own data
          $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
      } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
          // User can view all data (no additional filters needed)
  
      }
      $totalLeadCount = $totalLeadCounts->count();
  
      $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
      if ($branch_id != 0) {
        $totalCustomerCount->where('za_customer.branch_id', $branch_id);
      }
      $totalCustomerCount = $totalCustomerCount->count();
  
      if ($totalLeadCount > 0) {
        $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
      }
  
      $percentageover = round($percentageover) . '%';
  
      $leadOriginal = DB::table('za_customer')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_customer.created_by', '!=', 0)
      ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
       $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
          if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
          }
          $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();
          $percentagecurrentmonth = 0;
          if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
          }
      
          $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
    
      // return $notYetStartedCount;
      return view('content.customer.not_started_customer_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'perpage' => $perpage,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'cus_fill' => $cus_fill,
        'staff_fill' => $staff_fill,
        'status_fill' => $status_fill,
        'inactiveCount' => $inactiveCount,
        'leadOriginalCount' => $leadOriginalCount,
        'percentageover' => $percentageover,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
  
      ])->with('filter_on', true);
    }
    
    public function ScheduledCustomer(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;

      $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
    }
  
        $notStartedCount=$notYetStartedCount;
      // return $processed_not_started_customers;
  
      $customers = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
      //   'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          // 'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->whereIn('za_customer.sno', $processed_schedule_customers)
        ->where('za_customer.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->paginate($perpage);
      // $customers = $customers->unique('payment_id');
      
      $customers_fill = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.doj',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->where('za_customer.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->get();
  
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->where('za_payment.status', '!=', 3)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
                
                 $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
          
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
            
            
            //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
             $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
           if (isset($end_date) && $end_date < $currentDate) {
               $allEndDate = false;
              //  break;
           }
            if (isset($start_date) && $start_date > $currentDate) {
              $allSchedule = true;//  break;
            }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
             elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
            // Increment customer count based on status
            if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
                $activeCount++;
            } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
                $notYetStartedCount++;
            } elseif ($isDropped) {
                $dropCount++;
            } elseif ($isSchedule) {
                $inactiveCount++;
            }
        
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
        $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
         $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
  
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
      // alagu
      // current month customer
       $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
          $percentageover = 0;
          
          $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
          if ($branch_id != 0) {
              $totalLeadCounts->where('za_lead.branch_id', $branch_id);
          }
          if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
              // User can only view their own data
              $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
          } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
              // User can view all data (no additional filters needed)
      
          }
          $totalLeadCount = $totalLeadCounts->count();
  
          $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
          if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
          }
          $totalCustomerCount = $totalCustomerCount->count();
  
          if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
          }
  
          $percentageover = round($percentageover) . '%';
  
          $leadOriginal = DB::table('za_customer')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_customer.created_by', '!=', 0)
          ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
  
  
      // coversion rate current month
      // Get the count of leads for the current month
      $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($branch_id != 0) {
        $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();
      $percentagecurrentmonth = 0;
      if ($currentMonthLeadCount > 0) {
        $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
      }
  
      $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
   
      // return $processed_not_started_customers;
      return view('content.customer.customer_scheduled_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'notYetStartedCount' => $notStartedCount,
        'customer_name_fill' => '',
        'cus_fill' => '',
        'staff_fill' => '',
        'status_fill' => '',
        'course_type_list' => $course_type_list,
        'course_type_fill' => '',
        'leadOriginalCount' => $leadOriginalCount,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'inactiveCount' => $inactiveCount,
        'percentageover' => $percentageover,
        'batch_name_fill' => '',
        'slot_list' => $slot_list,
        'perpage' => $perpage,
        'slot_name_fill' => '',
        'slot_type_list' => $slot_type_list,
        'slot_type_name_fill' => '',
        'course_name_fill' => '',
        'date_filter' => '',
        'fin_yr_fill' => '',
        'gender_fill' => '',
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
      ])->with('filter_on', false);
    }
  
    public function ScheduledCustomerFilter(Request $request)
    {
  
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $helper = new \App\Helpers\Helpers();

      $batch_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        // ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        // ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();

    
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;
    
        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];
    
        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            } 
        }

        $batch_active_Data = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereNotNull('za_training.start_date')
         ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
      
        foreach ($batch_active_Data as $singledata) {
            if( !in_array($singledata->customer_id, $processed_drop_customers)){
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                } 
            }  
        }
    
        
        $batch_Data_old = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        
        // return  $processed_active_customers;
        foreach ($batch_Data_old as $singledata) {
     
                if( !in_array($singledata->customer_id, $processed_drop_customers)){
                    if( !in_array($singledata->customer_id, $processed_active_customers)){
                        if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                            continue;
                        }
                        if($singledata->start_date > \Carbon\Carbon::today()->startOfDay()){
                          $scheduleCount ++;
                          $processed_schedule_customers [] = $singledata->customer_id;
                        } 
                    }  
                }  
           
        }
        // return $processed_schedule_customers;
    
    
        $batch_notyetStated = DB::table('za_training')
        ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
        ->where('za_training.branch_id',$branch_id)
        ->where('za_customer.status',0)
        ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
        ->get();
    
        foreach ($batch_notyetStated as $singledata) {
     
          if( !in_array($singledata->customer_id, $processed_drop_customers)){
              if( !in_array($singledata->customer_id, $processed_active_customers)){
                if( !in_array($singledata->customer_id, $processed_schedule_customers)){
                  if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                  }
                 if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                  } 
              } 
            } 
          }  
     
    }
      
      $notStartedCount=$notYetStartedCount;
      // return $request;
      if ($branch_id) {
        $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
      } else {
        $get_branch_type = 0;
      }
      $cus_fill = $request->cus_fill ?? '';
      $customer_name_fill = $request->customer_name_fill_sno ?? '';
      $staff_fill = $request->staff_name_fill_sno ?? '';
      $status_fill = $request->input('status_fill', 'all'); 
      $mobile_fill = $request->mobile_fill ?? '';
      $gender_fill = $request->gender_fill ?? '';
      $course_type_fill = $request->course_type_fill_sno ?? '';
      $course_name_fill = $request->course_name_fill_sno ?? '';
      $batch_name_fill = $request->batch_name_fill_sno ?? '';
      $slot_name_fill = $request->slot_name_fill_sno ?? '';
      $slot_type_name_fill = $request->slot_type_name_fill ?? '';
      $date_filter = $request->dt_fill_issue_rpt;
      $from_date_filter = $request->from_date_fillter_textbox;
      $to_date_filter = $request->to_date_fillter_textbox;
      $fin_yr_fill = $request->fin_yr_fill ?? '';
  
      // return $request;
      $query = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
      //   'za_training.course_mode_id',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count')
  
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->where('za_customer.status', 0)
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          // 'za_training.course_mode_id',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
  
        )
        ->whereIn('za_customer.sno', $processed_schedule_customers)
        ->orderBy('za_customer.sno', 'desc');
      // date filter query
      // Date Filtering Logic
      if ($date_filter == "today") {
        $todayDate = date("Y-m-d");
        $query->whereDate('za_customer.created_at', $todayDate);
      } elseif ($date_filter == "week") {
        $today = date('l');
        if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
      } elseif ($date_filter == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
      } elseif ($date_filter == "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $query->where('za_customer.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->where('za_customer.created_at', '<=', $toDate);
        }
      }
      // Financial year filter
      if ($fin_yr_fill) {
        $helper = new \App\Helpers\Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
    
        if ($selected_fin_year) {
            // Decode the financial month as an array
            $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
    
            // Check if $monthsArray is valid
            if (is_array($monthsArray) && count($monthsArray) > 0) {
                $currentYear = now()->year; // Current year
                
                // Filter leads that match any of the selected months
                $leads->where(function ($q) use ($monthsArray, $currentYear) {
                    $q->whereYear('za_customer.created_at', $currentYear)
                      ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
                });
            }
        }
      }
  
      if ($branch_id > 0) {
        $query->where('za_customer.branch_id', $branch_id);
      }
  
      if ($cus_fill) {
        $query->where(function ($customer) use ($cus_fill) {
          $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
        });
      }
      if ($customer_name_fill) {
        $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
      }
      if ($mobile_fill) {
        $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
      }
      if ($gender_fill) {
        $query->where('za_customer.cus_gender', $gender_fill);
      }
      if ($course_type_fill) {
        $query->where('za_course_type.sno', $course_type_fill);
      }
      if ($course_name_fill) {
        $query->where('za_course.sno', $course_name_fill);
      }
      if ($staff_fill) {
        $query->where('za_staff.sno', $staff_fill);
      }
      if ($batch_name_fill) {
        $query->where('za_batch.sno', $batch_name_fill);
      }
      if ($slot_name_fill) {
        $query->where('za_slot.sno', $slot_name_fill);
      }
      if ($slot_type_name_fill) {
        $query->where('za_slot_type.sno', $slot_type_name_fill);
      }
      
  
      // Fetch Branch list ordered by sno in descending order
      $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
               ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->whereNotIn('za_payment.status', [3,2])
                ->where('za_payment.paidAmount', '>',0)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
             $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
         
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
    
            // Set customer status based on conditions
             //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
              $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
               if (isset($end_date) && $end_date < $currentDate) {
                   $allEndDate = false;
                  //  break;
               }
               if (isset($start_date) && $start_date > $currentDate) {
                  $allSchedule = true;//  break;
                }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
              elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
        // Increment customer count based on status
        if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
            $activeCount++;
        } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
            $notYetStartedCount++;
        } elseif ($isDropped) {
            $dropCount++;
        } elseif ($isSchedule) {
            $inactiveCount++;
        }
    
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
         $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
         $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
    
      if ($status_fill) {
          if ($status_fill == 'active') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'not_started') {
              $customers = $customers->filter(function ($item) {
                  return !$item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'drop') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_cus_drop;
              });
          } elseif ($status_fill == 'inactive') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_end_date;
              });
          }
      }  
  
      session()->forget('branch_id_ses');
      session()->forget('branch_type_ses');
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
  
      // alagu
      $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
      $percentageover = 0;
          
      $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
      if ($branch_id != 0) {
          $totalLeadCounts->where('za_lead.branch_id', $branch_id);
      }
      if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
          // User can only view their own data
          $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
      } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
          // User can view all data (no additional filters needed)
  
      }
      $totalLeadCount = $totalLeadCounts->count();
  
      $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
      if ($branch_id != 0) {
        $totalCustomerCount->where('za_customer.branch_id', $branch_id);
      }
      $totalCustomerCount = $totalCustomerCount->count();
  
      if ($totalLeadCount > 0) {
        $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
      }
  
      $percentageover = round($percentageover) . '%';
  
      $leadOriginal = DB::table('za_customer')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_customer.created_by', '!=', 0)
      ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
       $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
          if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
          }
          $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();
          $percentagecurrentmonth = 0;
          if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
          }
      
          $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
    
      // return $notYetStartedCount;
      return view('content.customer.customer_scheduled_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'course_type_list' => $course_type_list,
        'notYetStartedCount' => $notStartedCount,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'perpage' => $perpage,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'cus_fill' => $cus_fill,
        'staff_fill' => $staff_fill,
        'status_fill' => $status_fill,
        'inactiveCount' => $inactiveCount,
        'leadOriginalCount' => $leadOriginalCount,
        'percentageover' => $percentageover,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
  
      ])->with('filter_on', true);
    }
    
    public function customerScore(Request $request)
    {
        // Get the customer ID from the request
        $cus_id = $request->id;

        $customers = CustomerModel::select('*')->where('za_customer.sno', $cus_id)
        ->where('za_customer.status', 0)
        ->first();
        
        $points_list = StudentpointsModel::select(
                'za_students_points.*', 
                'za_points.points_name', 
                'za_points.sno AS point_sno', 
                'za_points.points', 
                'za_points.comments',
                'za_customer.cus_name', 
                'za_customer.customer_id', 
                'za_customer.points_score', 
                'za_customer.sno AS cus_sno'
            )
            ->leftJoin('za_customer', 'za_students_points.student_id', '=', 'za_customer.sno')
            ->leftJoin('za_points', 'za_students_points.points_id', '=', 'za_points.sno')
            ->where('za_customer.sno', $cus_id)
            ->where('za_students_points.student_id', $cus_id)
            ->where('za_customer.status', 0)
            ->get();
    
        // Return the result as JSON
        // return response()->json($points_list);

        return response()->json([
          'status' => 200,
          'message' => 'Student details successfully retrieved!',
          'data' => [
            'points_list' => $points_list,
            'customers' => $customers,
          ],
        ]);
    }
    
    public function customerHold(Request $request)
    {
      // return $request;
      $cus_sno = $request->cus_hold_sno;
      $hold_st_date = $request->hold_st_date;
      $hold_end_date = $request->hold_end_date;
      $hold_reason = $request->hold_reason;
      $branch_id = $request->user()->branch_id;

      $cus_chk = CustomerModel::where('sno', '=', $cus_sno)->where('status', '=', 0)->where('branch_id', '=',$branch_id)->first();

      // return $cus_chk;

      if($cus_chk){
        $cus_chk->status = 6;
        // return $cus_chk;
        $cus_chk->save();

        $cus_history = HoldHistoryModel::where('customer_id', $cus_chk->sno)->where('status', '=', 0)->first();

        if(!$cus_history){

          $add_history = new HoldHistoryModel();
          $add_history->customer_id = $cus_chk->sno;
          $add_history->branch_id   = $cus_chk->branch_id;
          $add_history->hold_start_date = date('Y-m-d', strtotime($hold_st_date));
          $add_history->hold_end_date = date('Y-m-d', strtotime($hold_end_date));

          if($hold_reason === "others"){
            $add_history->other_reason = $request->reason_text;
             $add_history->hold_reason = $hold_reason;
          }else {
            $add_history->hold_reason = $hold_reason;
          }
          $add_history->status = 0;
          $add_history->created_by = $request->user()->user_id;
          $add_history->updated_by = $request->user()->user_id;

          // return $add_history;

          $add_history->save();
        } else{
              session()->flash('toastr', [
                  'type' => 'error',
                  'message' => 'Customer Already in Hold!'
              ]);

            // Redirect after saving the customer
          return redirect('/manage_customer');
        }
      } else{
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Customer Not found!'
        ]);

        return redirect('/manage_customer');
      }
      return redirect('/manage_customer');
    }

    public function HoldCustomer(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 100);
      $offset = ($page - 1) * $perpage;

  
      $customers = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_cus_hold_history.hold_reason',
        'za_cus_hold_history.hold_start_date',
        'za_cus_hold_history.hold_end_date',
        'za_cus_hold_history.other_reason',
        'hold_staff.staff_name as hold_staff_name',
        'za_cus_hold_history.created_by as hold_cus_by',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
      //   'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_cus_hold_history',  'za_customer.sno', '=', 'za_cus_hold_history.customer_id')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->leftJoin('za_staff as hold_staff', 'za_cus_hold_history.created_by', '=', 'hold_staff.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_cus_hold_history.hold_reason',
          'za_cus_hold_history.hold_start_date',
          'za_cus_hold_history.hold_end_date',
          'za_cus_hold_history.other_reason',
          'hold_staff.staff_name',
          'za_cus_hold_history.created_by',
          'za_customer.address',
          'za_customer.course_id',
          // 'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->where('za_customer.status', 6)
        ->where('za_cus_hold_history.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->paginate($perpage);
      // $customers = $customers->unique('payment_id');

      // return $customers;
      
      $customers_fill = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_cus_hold_history.hold_reason',
        'za_cus_hold_history.hold_start_date',
        'za_cus_hold_history.other_reason',
        'za_cus_hold_history.hold_end_date',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        'za_training.course_mode_id',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_cus_hold_history',  'za_customer.sno', '=', 'za_cus_hold_history.customer_id')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.doj',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_cus_hold_history.hold_reason',
          'za_cus_hold_history.hold_start_date',
          'za_cus_hold_history.other_reason',
          'za_cus_hold_history.hold_end_date',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_customer.address',
          'za_customer.course_id',
          'za_training.course_mode_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
        )
        ->where('za_customer.status', 6)
        ->where('za_cus_hold_history.status', 0)
        ->orderBy('za_customer.sno', 'desc')
        ->get();
  
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->where('za_payment.status', '!=', 3)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
                
                 $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
          
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
            
            
            //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
             $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
           if (isset($end_date) && $end_date < $currentDate) {
               $allEndDate = false;
              //  break;
           }
            if (isset($start_date) && $start_date > $currentDate) {
              $allSchedule = true;//  break;
            }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
             elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
            // Increment customer count based on status
            if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
                $activeCount++;
            } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
                $notYetStartedCount++;
            } elseif ($isDropped) {
                $dropCount++;
            } elseif ($isSchedule) {
                $inactiveCount++;
            }
        
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
        $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
         $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
  
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
      // alagu
      // current month customer
       $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
          $percentageover = 0;
          
          $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
          if ($branch_id != 0) {
              $totalLeadCounts->where('za_lead.branch_id', $branch_id);
          }
          if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
              // User can only view their own data
              $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
          } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
              // User can view all data (no additional filters needed)
      
          }
          $totalLeadCount = $totalLeadCounts->count();
  
          $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
          if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
          }
          $totalCustomerCount = $totalCustomerCount->count();
  
          if ($totalLeadCount > 0) {
            $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
          }
  
          $percentageover = round($percentageover) . '%';
  
          $leadOriginal = DB::table('za_customer')
          ->where('za_customer.branch_id', $branch_id)
          ->where('za_customer.created_by', '!=', 0)
          ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
  
  
      // coversion rate current month
      // Get the count of leads for the current month
      $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
      if ($branch_id != 0) {
        $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
      }
      $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
        ->whereMonth('created_at', date('m'))
        ->count();
      $percentagecurrentmonth = 0;
      if ($currentMonthLeadCount > 0) {
        $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
      }
  
      $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
   
      // return $processed_not_started_customers;
      return view('content.customer.customer_hold_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'customer_name_fill' => '',
        'cus_fill' => '',
        'staff_fill' => '',
        'status_fill' => '',
        'course_type_list' => $course_type_list,
        'course_type_fill' => '',
        'leadOriginalCount' => $leadOriginalCount,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'inactiveCount' => $inactiveCount,
        'percentageover' => $percentageover,
        'batch_name_fill' => '',
        'slot_list' => $slot_list,
        'perpage' => $perpage,
        'slot_name_fill' => '',
        'slot_type_list' => $slot_type_list,
        'slot_type_name_fill' => '',
        'course_name_fill' => '',
        'date_filter' => '',
        'fin_yr_fill' => '',
        'gender_fill' => '',
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
      ])->with('filter_on', false);
    }
  
    public function HoldListFilter(Request $request)
    {
  
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 100);
      $offset = ($page - 1) * $perpage;
      $helper = new \App\Helpers\Helpers();
      
      // return $request;
      if ($branch_id) {
        $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
      } else {
        $get_branch_type = 0;
      }
      $cus_fill = $request->cus_fill ?? '';
      $customer_name_fill = $request->customer_name_fill_sno ?? '';
      $staff_fill = $request->staff_name_fill_sno ?? '';
      $status_fill = $request->input('status_fill', 'all'); 
      $mobile_fill = $request->mobile_fill ?? '';
      $gender_fill = $request->gender_fill ?? '';
      $course_type_fill = $request->course_type_fill_sno ?? '';
      $course_name_fill = $request->course_name_fill_sno ?? '';
      $batch_name_fill = $request->batch_name_fill_sno ?? '';
      $slot_name_fill = $request->slot_name_fill_sno ?? '';
      $slot_type_name_fill = $request->slot_type_name_fill ?? '';
      $date_filter = $request->dt_fill_issue_rpt;
      $from_date_filter = $request->from_date_fillter_textbox;
      $to_date_filter = $request->to_date_fillter_textbox;
      $fin_yr_fill = $request->fin_yr_fill ?? '';
  
      // return $request;
      $query = CustomerModel::select(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.doj',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.reason_request',
        'za_customer.free_status',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno as lead_id',
        'za_lead.created_by as lead_created_by',
        'lead_staff.staff_name as lead_staff_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_course.course_name',
        'za_slot.slot_name',
        'za_cus_hold_history.hold_reason',
        'za_cus_hold_history.hold_start_date',
        'za_cus_hold_history.other_reason',
        'za_cus_hold_history.hold_end_date',
        'hold_staff.staff_name as hold_staff_name',
        'za_cus_hold_history.created_by as hold_cus_by',
      //   'za_training.course_mode_id',
        'za_staff.staff_name',
        'za_staff.sno as staff_sno',
        'za_branch.min_prd_cost',
        DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
        DB::raw('MAX(za_payment.total_amount) as total_amount'),
        DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
        DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count')
  
      )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_cus_hold_history',  'za_customer.sno', '=', 'za_cus_hold_history.customer_id')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->leftJoin('za_staff as hold_staff', 'za_cus_hold_history.created_by', '=', 'hold_staff.sno')
        ->where('za_customer.status', 6)
        ->where('za_cus_hold_history.status', 0)
        ->where('za_customer.branch_id', $branch_id)
        ->groupBy(
          'za_customer.sno',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.customer_id',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.doj',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_customer.cus_marital_status',
          'za_customer.country',
          'za_customer.state',
          'za_customer.city',
          'za_cus_hold_history.hold_reason',
          'za_cus_hold_history.hold_start_date',
          'za_cus_hold_history.other_reason',
          'za_cus_hold_history.hold_end_date',
          'hold_staff.staff_name',
          'za_cus_hold_history.created_by',
          'za_customer.address',
          'za_customer.course_id',
          'za_customer.free_shd_count',
          'za_customer.request_count',
          // 'za_training.course_mode_id',
          'za_customer.free_status',
          'za_customer.reason_request',
          'za_customer.reason_reject',
          'za_customer.created_by',
          'za_customer.batch_id',
          'za_lead.sno',
          'za_lead.created_by',
          'lead_staff.staff_name',
          'za_course.course_name',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'za_staff.sno',
          'za_branch.min_prd_cost'
  
        )
        ->orderBy('za_customer.sno', 'desc');
      // date filter query
      // Date Filtering Logic
      if ($date_filter == "today") {
        $todayDate = date("Y-m-d");
        $query->whereDate('za_customer.created_at', $todayDate);
      } elseif ($date_filter == "week") {
        $today = date('l');
        if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
      } elseif ($date_filter == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
      } elseif ($date_filter == "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $query->where('za_customer.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->where('za_customer.created_at', '<=', $toDate);
        }
      }
      // Financial year filter
      if ($fin_yr_fill) {
        $helper = new \App\Helpers\Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
    
        if ($selected_fin_year) {
            // Decode the financial month as an array
            $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
    
            // Check if $monthsArray is valid
            if (is_array($monthsArray) && count($monthsArray) > 0) {
                $currentYear = now()->year; // Current year
                
                // Filter leads that match any of the selected months
                $leads->where(function ($q) use ($monthsArray, $currentYear) {
                    $q->whereYear('za_customer.created_at', $currentYear)
                      ->whereIn(\DB::raw('MONTH(za_customer.created_at)'), $monthsArray); // Use whereIn to check for multiple months
                });
            }
        }
      }
  
      if ($branch_id > 0) {
        $query->where('za_customer.branch_id', $branch_id);
      }
  
      if ($cus_fill) {
        $query->where(function ($customer) use ($cus_fill) {
          $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$cus_fill}%");
        });
      }
      if ($customer_name_fill) {
        $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
      }
      if ($mobile_fill) {
        $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
      }
      if ($gender_fill) {
        $query->where('za_customer.cus_gender', $gender_fill);
      }
      if ($course_type_fill) {
        $query->where('za_course_type.sno', $course_type_fill);
      }
      if ($course_name_fill) {
        $query->where('za_course.sno', $course_name_fill);
      }
      if ($staff_fill) {
        $query->where('za_staff.sno', $staff_fill);
      }
      if ($batch_name_fill) {
        $query->where('za_batch.sno', $batch_name_fill);
      }
      if ($slot_name_fill) {
        $query->where('za_slot.sno', $slot_name_fill);
      }
      if ($slot_type_name_fill) {
        $query->where('za_slot_type.sno', $slot_type_name_fill);
      }
      
  
      // Fetch Branch list ordered by sno in descending order
      $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);
      // Initialize counters for each category
      $activeCount = 0;
      $notYetStartedCount = 0;
      $inactiveCount = 0;
      $dropCount = 0;
  
      $customers->transform(function ($item, $key) use (&$activeCount, &$notYetStartedCount, &$inactiveCount, &$dropCount) {
        // Initialize flags for the conditions
        $allActive = false;
        $allCusDrop = false;
        $allEndDate = false;
    
        $currentDate = date('d-M-Y'); // Get current date in the format 'd-M-Y'
        $carouselDetails = [];
    
        // Get payment details and course info
        $paymentDetailss = DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $item->sno)
            ->where('za_payment.status', 0)
            ->get();
    
        $paymentget = DB::table('za_training')
            ->where('customer_id', $item->sno)
            ->whereIn('status', [0, 2])
            ->get();
    
        $courseIds = $paymentget;
        $batchIds = json_decode($item->batch_id);
    
        // Flags for tracking customer status
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true; // Assume the customer is not started by default
        $isInactive = false;
        $isSchedule = false;
    
        foreach ($courseIds as $index => $courseId) {
            $batchId = $batchIds[$index] ?? [];
    
            // Retrieve course details
            $course = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId->course_id)
                ->first();
    
            // Retrieve batch details
            $batch = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
               ->where('za_batch.sno', $courseId->batch_id)
                ->first();
    
            // Retrieve payment details
            $paymentDetails = DB::table('za_training')
                ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                ->where('za_training.customer_id', $item->sno)
                ->where('za_training.course_id', $courseId->course_id)
                ->where('za_training.status', '!=', 3)
                ->whereNotIn('za_payment.status', [3,2])
                ->where('za_payment.paidAmount', '>',0)
                ->where('za_training.status', '!=', 1)
                ->where('za_payment.status', '!=', 2)
                ->groupBy('za_payment.total_amount')
                ->first();
    
            $paymentPercentage = 0;
            if ($paymentDetails && $paymentDetails->total_amount > 0) {
                $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                if($paymentPercentage>=100){
                    
                    $paymentPercentage = 100;
                    
                }
            }
    
            // Check if attendance exists for the specific batch and customer
            $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                ->where('batch_id', $batchId)
                ->where('attendance', 'P')
                ->get();
    
            // Initialize course progress percentage
            $courseProgress = 0;
            $topicCount = 0;
            $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                ->count();
             $helper = new \App\Helpers\Helpers();
              $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);
         
    
            // batch count by course id
            $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
    
            // Set customer status based on conditions
             //*************************************************************************************
            
             $currentDate = date('Y-m-d');
             $allActive = false;
             $allCusDrop=true;
             $allEndDate=true;
              $allSchedule=false;
             
             $start_date = $batch->start_date ?? null;
             $end_date  = $batch->end_date ?? null;
             
             if ($start_date <= $currentDate && $start_date != null) {
                 $allActive = true;
              //   break;
             }
             if ( $courseId->status != 2) {
                 $allCusDrop = false;
              //   break;
             }
               if (isset($end_date) && $end_date < $currentDate) {
                   $allEndDate = false;
                  //  break;
               }
               if (isset($start_date) && $start_date > $currentDate) {
                  $allSchedule = true;//  break;
                }
            
            
            if($allActive && !$allCusDrop){
                  $isActive = true;  // Customer is active
             }
             elseif(!$allActive && !$allCusDrop && !$allSchedule){
                   $isNotStarted = true;  // Customer is not yet started
             }
              elseif($allSchedule && !$allActive && !$allCusDrop){
                    $isSchedule = true;  // Customer is inactive
              }
              elseif($allCusDrop){
              $isDropped = true;  // Customer is dropped
             }
             elseif($allEndDate){
                  $isInactive = true;  // Customer is inactive
             }
    
            // Add course and batch details to the array
            $carouselDetails[] = [
                'course_sno' => $courseId->course_id ?? null,
                'course_mode_id' => $courseId->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $batchId ?? null,
                'batch_count' => $batch_count ?? 0,
                'traning_sno' => $courseId->sno ?? null,
                'traning_status' => $courseId->status ?? null,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
            ];
        }
    
        // Increment customer count based on status
        if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
            $activeCount++;
        } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
            $notYetStartedCount++;
        } elseif ($isDropped) {
            $dropCount++;
        } elseif ($isSchedule) {
            $inactiveCount++;
        }
    
        // Attach data to the customer item
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $paymentDetailss;
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
         $item->all_schedule = $isSchedule;
    
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
         $item->payment_percentage = ($item->total_amount > 0)
      ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1)
      : 0;
    
        return $item;
      });
    
      if ($status_fill) {
          if ($status_fill == 'active') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'not_started') {
              $customers = $customers->filter(function ($item) {
                  return !$item->all_active && !$item->all_cus_drop;
              });
          } elseif ($status_fill == 'drop') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_cus_drop;
              });
          } elseif ($status_fill == 'inactive') {
              $customers = $customers->filter(function ($item) {
                  return $item->all_end_date;
              });
          }
      }  
  
      session()->forget('branch_id_ses');
      session()->forget('branch_type_ses');
      $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
      $staff_list = StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
  
  
      // alagu
      $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
              ->where('za_customer.branch_id', $branch_id)
              ->whereYear('za_customer.created_at', date('Y'))
              ->whereMonth('za_customer.created_at', date('m'))
              ->get();
  
          $currentMonthCustomerCount = 0;
          $total_business_amount     = 0;
          $total_payment             = 0;
          $total_paid_payment        = 0;
  
          if ($currentMonthCustomer->isNotEmpty()) {
              $currentMonthCustomerCount = $currentMonthCustomer->count();
              foreach ($currentMonthCustomer as $customer) {
                  $courseIds = json_decode($customer->course_id, true);
                  foreach ($courseIds as $courseId) {
                      // Fetch the course's maximum price
                      $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                      $total_payment += $payment;
                      // Fetch the total paid amount for the course
                      $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                          ->where('course_id', $courseId)
                          ->where('status', 1)
                          ->sum('paidAmount');
                      $total_paid_payment += $paid_payment;
                  }
              }
          }
  
          // Calculate averages
          $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
          $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id > 0) {
        $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
      } else {
        $get_course_change_days =  0;
      }
  
      $percentageover = 0;
          
      $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
      if ($branch_id != 0) {
          $totalLeadCounts->where('za_lead.branch_id', $branch_id);
      }
      if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
          // User can only view their own data
          $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
      } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
          // User can view all data (no additional filters needed)
  
      }
      $totalLeadCount = $totalLeadCounts->count();
  
      $totalCustomerCount = CustomerModel::where('status', 0)->where('za_customer.created_by', '!=', 0);
      if ($branch_id != 0) {
        $totalCustomerCount->where('za_customer.branch_id', $branch_id);
      }
      $totalCustomerCount = $totalCustomerCount->count();
  
      if ($totalLeadCount > 0) {
        $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
      }
  
      $percentageover = round($percentageover) . '%';
  
      $leadOriginal = DB::table('za_customer')
      ->where('za_customer.branch_id', $branch_id)
      ->where('za_customer.created_by', '!=', 0)
      ->where('za_customer.status', 0);
  
      $leadOriginalCount = 0;
      $leadOriginalCount = $leadOriginal->count();
       $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
          if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
          }
          $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();
          $percentagecurrentmonth = 0;
          if ($currentMonthLeadCount > 0) {
            $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
          }
      
          $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);
  
    
      // return $notYetStartedCount;
      return view('content.customer.customer_hold_list', [
        'customers' => $customers,
        'customers_list' => $customers_list,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'staff_list' => $staff_list,
        'perpage' => $perpage,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'cus_fill' => $cus_fill,
        'staff_fill' => $staff_fill,
        'status_fill' => $status_fill,
        'inactiveCount' => $inactiveCount,
        'leadOriginalCount' => $leadOriginalCount,
        'percentageover' => $percentageover,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'currentMonthCustomerCount' => $currentMonthCustomerCount,
        'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
        'average_business_value' => $averageBusinessValue,
        'average_collection_value' => $averageCollectionValue,
        'course_change_count' => $get_course_change_days
  
      ])->with('filter_on', true);
    }
    
    public function reactiveCustomer(Request $request)
    {
      // return $request;

      $id = $request->cus_sno;
      $reactive_reason = $request->verify_reason_react;
      $cus_history = HoldHistoryModel::where('customer_id', $id)->where('status', '=', 0)->first();
      $branch_id = $request->user()->branch_id;
      // return $cus_history;

      if($cus_history){
        $cus_history->status = 1;
        $cus_history->reactive_date = date('Y-m-d');
        $cus_history->reactive_reason = $reactive_reason;
        $cus_history->updated_by = $request->user()->user_id;

        // return $cus_history;

        $cus_history->update();
        $cus_chk = CustomerModel::where('sno', '=', $cus_history->customer_id)->where('status', '=', 6)->where('branch_id', '=',$branch_id)->first();

        if( $cus_chk){
          $cus_chk->status  = 0;
          $cus_chk->updated_by = $request->user()->user_id;
          $cus_chk->save();

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Customer Reactivated Succesfully!'
          ]);
        } else{
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Customer Not found!'
          ]);

          return redirect('/manage_hold_customer');
        }
      }else{
        session()->flash('toastr', [
          'type' => 'error',
            'message' => 'Customer not able to Reactivated!'
        ]);

        return redirect('/manage_hold_customer');
      }
      return redirect('/manage_hold_customer');
    }
    
        public function QrInvoice($id, Request $request)
    {
      // return $request;

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;
    
        if (!$decryptedValue || strpos($decryptedValue, '~') === false) {
            abort(404, 'Invalid decrypted value');
        }
    
        list($invoice_id, $index ) = explode('~', $decryptedValue);

        $payment = PaymentModel::select(
            'za_payment.invoice_id',
            'za_payment.initialPayDate',
            'za_payment.paidAmount as amount',
            'za_payment.gst_amount',
            'za_payment.payment_mode_label',
            'za_payment.transaction',
          //   'za_transaction.transaction_id',
          'za_transaction.receipt_id',
            'za_customer.cus_name',
            'za_customer.customer_id As cus_id',
            'za_customer.cus_pic',
            'za_customer.doj',
            'za_customer.cus_gender',
            'za_customer.cus_mobile',
            'za_customer.cus_email_id',
            'za_course.course_name',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mobile',
            'za_branch.branch_name',
            'za_payment.branch_id',
            'za_branch.branch_type',
            'za_branch.franchise_name',
            'za_branch.mail',
            'za_branch.area_street',
            'za_states.name as state_name',
            'za_cities.name as city_name'
        )
            ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_payment.customer_id')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_payment.course_id')
            ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_payment.branch_id')
            ->leftJoin('za_transaction', 'za_transaction.invoice_id', '=', 'za_payment.invoice_id')
            ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
            ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
            ->where('za_payment.invoice_id', $invoice_id)
            ->orderBy('za_payment.sno', 'desc')
            ->first();
            
             if ($payment && !empty($payment->transaction)) {
                  $transactionData = json_decode($payment->transaction, true);
                  $payment->transaction_id = $transactionData['Transaction ID'] ?? null;
              }
            // return $payment;  
  
        $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2','terms_3','terms_4', 'terms_5')->where('status' ,0)->get();
        // return $terms_conditions;
            
        $branch = BranchModel::where('sno', $payment->branch_id)->orderBy('sno', 'desc')->first();
        // QR Code data
          // $qrCodeData = [
          //     'Customer Name' => $payment->cus_name,
          //     'Customer ID' => $payment->customer_id,
          //     'Paid Amount' => $payment->amount
          // ];

      return view('content.customer.qr_customer_payment_view', [
          'payment' => $payment,
          'print_decryptedValue' => $index,
          'gstPercentage' => $branch->gst_percentage,
          'terms' => $terms_conditions
      ]);
    }
    
    
    public function customerUnAttendedClass(Request $request)
    {
        $cus_id = $request->id;
    
        $customers = CustomerModel::where('za_customer.sno', $cus_id)
            ->where('za_customer.status', 0)
            ->first();
    
        if (!$customers) {
            return response()->json([
                'status' => 404,
                'message' => 'Customer not found!',
                'data' => null
            ]);
        }
    
        $att_details = AttendanceModel::where('customer_id', $customers->sno)
            ->whereIn('attendance', ['A', 'L'])
            ->get();
    
        if ($att_details->isEmpty()) {
            return response()->json([
                'status' => 204,
                'message' => 'No unattended classes found for this customer.',
                'data' => [
                    'att_details' => [],
                    'customers' => $customers
                ]
            ]);
        }
    
        $data = [];
    
        foreach ($att_details as $att) {
          $syllabus = SyllabusUpdateModel::select(
            'za_syllabus_update.*', 
            'za_course_chapter.course_chapter_name', 
            'za_course_chapter.session_name',
            'za_course_chapter.topic_name',
            'za_course.course_name'
            )
            ->leftJoin('za_course_chapter', function ($join) {
                $join->on('za_course_chapter.course_chapter_id', '=', 'za_syllabus_update.chapter_id')
                    ->on('za_course_chapter.session_id', '=', 'za_syllabus_update.section_id')
                    ->on('za_course_chapter.topic_id', '=', 'za_syllabus_update.topic_id');
            })
            ->leftJoin('za_course','za_course.sno','=', 'za_syllabus_update.course_id')
            ->where('za_syllabus_update.date', $att->att_date)
            ->where('za_syllabus_update.batch_id', $att->batch_id)
            ->get();
    
            $syllabus_count = SyllabusUpdateModel::where('date', $att->att_date)
                ->where('batch_id', $att->batch_id)
                ->count();
    
            $summary = BatchSummaryModel::where('summary_date', $att->att_date)
                ->where('batch_id', $att->batch_id)
                ->get();
    
            $data[] = [
                'date' => $att->att_date,
                'attendance' => $att->attendance,
                'count' => $syllabus_count,
                'syllabus_update' => $syllabus,
                'batch_summary' => $summary
            ];
        }
    
        return response()->json([
            'status' => 200,
            'message' => 'Student details successfully retrieved!',
            'data' => [
                'customers' => $customers,
                'att_details' => $data
            ],
        ]);
    }
    
    
   public function confirmplacement($id)
  {
    $lead =  CustomerModel::where('sno', $id)->first();
    $lead->is_placement  = 1;
    $lead->Update();


    return response([
      'status'    => 200,
      'message'   => 'Set Placement Successfully Updated !',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  
   public function Add_on_course(Request $request){

      
      // return $request;
      $validator = Validator::make($request->all(), [
        'cus_id_add' => 'required|max:255',
      


      ]);
      if ($validator->fails()) {
        return  response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {


        $cus_id           = $request->cus_id_add;
        $cus_name = $request->cus_name_add;
        $course_category         = $request->course_cat;
        $course_sub_category           = $request->course_sub_cat;
        $course_type = $request->course_type;
        $course         = $request->course_add;
        $course_mode       = $request->course_mode;    
        $branch_id       = $request->user()->branch_id;        
       $user_id = $request->user()->user_id;
      }

       $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

       $cos_check = TrainingModel::orderBy('sno', 'desc')->first();
    
              // Generate training_id based on existing records or start fresh
              if (!$cos_check) {
                $year = date("Y");
                $training_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                $data = $cos_check->training_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cos + 1;
                $request_cos = sprintf("TRA%04d", $next_number_cos);
                $year = date("Y");
                $training_id = $year . '/' . $branch_code . '/' . $request_cos;
              }
      $training =  TrainingModel::updateOrCreate(
          [
              'training_id'     => $training_id,
              'branch_id'       => $branch_id,
              'customer_id'     => $cus_id,
              'course_id'       => $course, // Save each tesbo_course_id
              'batch_id'        => $batch_id->sno ?? 0,
              'slot_id'         => $batch_id->slot_id ?? null,
              'staff_id'        => $batch_id->staff_id ?? null,
              'start_date'      => $batch_id->start_date ?? null,
              'end_date'        => $batch_id->end_date ?? null,
              'overall_fees'    => $finalCourseFees ?? 0,
              'gst_amount'      => $finalCourseFees ?? 0, // Calculate GST for overall fees
              'disc_amount'     => $allData['discounted_amount_hidden'] ?? 0,
              'discount_check'  => $discounted_check ?? 0,
              'paid_amount'     => $paidAmount ?? 0,
              'paid_gst'        => $paidGst ?? 0,
              'total_amount'    => $totalAmount ?? 0,
              'balance_amount'  => $balanceAmount ?? 0,
              'balance_gst'     => $balanceGst ?? 0,
              'tesbo_check'     => 1,
              'course_mode_id'  => $course_mode ?? 0,
              'online_amount'   => $customer->online_fee ?? 0,
              'payment_id'      => $payment_auto_id ?? 0,
              'created_by'      => $user_id,
              'updated_by'      => $user_id,
          ]
          );

      if ($training) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Add On Successfully updated!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Add On!'
        ]);
      }
    
    return redirect()->back();
    
    }

//     public function validateCoupon(Request $request)
// {
//     $code = trim($request->coupon);
//     $amount = floatval($request->amount);
//     $customer_id = $request->customer_id;

//     if (!$code || $amount <= 0) {
//         return response()->json([
//             'valid' => false,
//             'message' => 'Invalid request — missing coupon or amount.'
//         ]);
//     }

//     // 1️⃣ Check if coupon exists
//     $coupon = DB::table('za_students_redeem')
//         ->where('coupon_code', $code)
//         ->first();

//     if (!$coupon) {
//         return response()->json([
//             'valid' => false,
//             'message' => 'Coupon code does not exist.'
//         ]);
//     }

//     // 2️⃣ Check if coupon belongs to this student
//     if ($coupon->student_id != $customer_id) {
//         return response()->json([
//             'valid' => false,
//             'message' => 'Coupon does not belong to this customer.'
//         ]);
//     }

//     // 3️⃣ Check if coupon is active
//     if ($coupon->status != 0) {
//         return response()->json([
//             'valid' => false,
//             'message' => 'Coupon is already used or expired.'
//         ]);
//     }


//     // Get coupon discount value
//     $discount = floatval($coupon->redeem_value);
//     $originalTotal = $amount;

//     // Prevent negative totals
//     $newTotal = max(0, $originalTotal - $discount);

//     // Calculate GST (assuming 18%)
//     $gstRate = 0.18;
//     $gstAmount = $newTotal * $gstRate;
//     $subTotal = $newTotal - $gstAmount;
//     $grandTotal = $newTotal + $gstAmount;
//     $OldgrandTotal = $originalTotal + $gstAmount;

//     // OPTIONAL: mark coupon as used if one-time
//     // DB::table('za_students_redeem')->where('coupon_code', $code)->update(['status' => 1]);

//     return response()->json([
//         'valid' => true,
//         'message' => "Coupon applied successfully! Discount: ₹{$discount}",
//         'discount' => $discount,
//         'new_total' => round($newTotal, 2),
//         'gst_amount' => round($gstAmount, 2),
//         'sub_total' => round($subTotal, 2),
//         'grand_total' => round($grandTotal, 2),
//         'old_grand_total' => round($OldgrandTotal, 2),
//         'old_pay_amount' => round($originalTotal, 2),
//         'coupon_id' => $coupon->sno,
//     ]);
// }

  public function validateCoupon(Request $request)
  {
    $code = trim($request->coupon);
    $amount = floatval($request->amount);
    $customer_id = $request->customer_id;
 
    if (!$code || $amount <= 0) {
      return response()->json([
        'valid' => false,
        'message' => 'Invalid request — missing coupon or amount.'
      ]);
    }
 
    // 1️⃣ Check if coupon exists
    $coupon = DB::table('za_students_redeem')
      ->where('coupon_code', $code)
      ->first();
 
    $coupon_details = ManageCouponModel::where('coupon_code', $code)->first();
 
    if (!$coupon && !$coupon_details) {  // fixed condition
      return response()->json([
        'valid' => false,
        'message' => 'Coupon code does not exist.'
      ]);
    }
 
    if ($coupon) { // only $coupon to come
      // 2️⃣ Check if coupon belongs to this student
      if ($coupon->student_id != $customer_id) {
        return response()->json([
          'valid' => false,
          'message' => 'Coupon does not belong to this customer.'
        ]);
      }
 
      // 3️⃣ Check if coupon is active
      if ($coupon->status != 0) {
        return response()->json([
          'valid' => false,
          'message' => 'Coupon is already used or expired.'
        ]);
      }
    }
 
    // 4️⃣ Calculate discount only if coupon_details exists
    if ($coupon_details) {
      if ($coupon_details->coupon_type == 'percentage') {
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 0;
      } else {
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 1;
      }
    } else {
      // fallback to redeem_value from coupon table if coupon_details not available
      $discount = floatval($coupon->redeem_value ?? 0);
      $discount_type = null;
    }
 
    $originalTotal = $amount;
    $newTotal = max(0, $originalTotal - $discount);
 
 
 
    // Calculate GST (assuming 18%)
    $gstRate = 0.18;
    $grandTotalGST = $originalTotal * $gstRate;
     $grandTotalGSTAmount = $originalTotal + $grandTotalGST;
    $grandTotal = max(0, $grandTotalGSTAmount - $discount);
    $gstAmount = $newTotal * $gstRate;
    $subTotal = $grandTotal / (1 + $gstRate);
    $grandTotal = $grandTotal;
    $OldgrandTotal = $originalTotal + $gstAmount;
 
    // OPTIONAL: mark coupon as used if one-time
    // DB::table('za_students_redeem')->where('coupon_code', $code)->update(['status' => 1]);
 
    return response()->json([
      'valid' => true,
      'message' => "Coupon applied successfully! Discount: ₹{$discount}",
      'discount' => $discount,
      'new_total' => round($subTotal, 2), // changed incluse
      'gst_amount' => round($gstAmount, 2),
      'sub_total' => round($subTotal, 2),
      'grand_total' => round($grandTotal, 2),
      'old_grand_total' => round($OldgrandTotal, 2),
      'old_pay_amount' => round($originalTotal, 2),
      'coupon_id' => $coupon->sno ?? null, // in case coupon is null
    ]);
  }



public function editPay(Request $request)
{
    $payment = DB::table('za_payment')->where('sno', $request->sno)->first();

    if ($payment) {
        return response()->json(['success' => true, 'data' => $payment]);
    }

    return response()->json(['success' => false, 'message' => 'Payment not found']);
}

public function updatePay(Request $request)
{
    DB::table('za_payment')->where('sno', $request->sno)->update([
        'initialPayDate' => $request->initialPayDate,
        'nextPayDate' => $request->nextPayDate,
        'amount' => $request->amount,
        'paidAmount' => $request->paidAmount,
        'gst_amount' => $request->gst_amount,
        'balanceFee' => $request->balanceFee,
        'payment_mode_label' => $request->payment_mode_label,
        'total_amount' => $request->total_amount,
        'status' => $request->status,
        'invoice_id' => $request->invoice_id,
        'payment_id' => $request->payment_id,
        'transaction' => $request->transaction,
        'updated_by' => auth()->id(),
        'updated_at' => now(),
    ]);

    return response()->json(['success' => true]);
}
  public function getTraining($customerId)
  {
    $data = TrainingModel::where('customer_id', $customerId)->get();
 
    return response()->json([
      'status' => 200,
      'data' => $data
    ]);
  }
 
  public function updateTraining(Request $request)
  {
    foreach ($request->trainings as $row) {
      TrainingModel::where('sno', $row['id'])->update([
        'course_id'      => $row['course_id'],
        'batch_id'       => $row['batch_id'],
        'slot_id'        => $row['slot_id'],
        'staff_id'       => $row['staff_id'],
        'start_date'     => $row['start_date'],
        'end_date'       => $row['end_date'],
        'overall_fees'   => $row['overall_fees'],
        'gst_amount'     => $row['gst_amount'],
        'total_amount'   => $row['total_amount'],
        'paid_amount'    => $row['paid_amount'],
        'paid_gst'       => $row['paid_gst'],
        'balance_amount' => $row['balance_amount'],
        'balance_gst'    => $row['balance_gst'],
        'payment_id'     => $row['payment_id'],
        'status'         => $row['status'],
      ]);
    }
 
    return response()->json([
      'status' => 200,
      'message' => 'Training updated successfully'
    ]);
  }
  
  
    private function WhatsappSendLog(
            array $response,
            array $payload,
            string $phone_no,
            string $template_name,
            int $user_id,
            int $branch_id = 0,
            int $unique_id = 0,
            ?string $source = null
        ) {
            $messageId = $response['data']['messages'][0]['id'] ?? null;
 
            return WhatsappTemplateLogModel::create([
                'phone_no' => $phone_no,
                'branch_id' => $branch_id,
                'unique_id' => $unique_id,
                'id_source' => $source,
                'template_name' => $template_name,
                'message_date_time' => Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s'),
                'type' => 'template',
                'from' => 1,
                'wama_id' => $messageId,
                'payload' => json_encode($payload),
                'created_by' => $user_id,
                'updated_by' => $user_id,
                'message_status' => 'sent',
            ]);
        }
         public function certificate_index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
 
        $perpage = (int) $request->input('sorting_filter', 25);
        $cus_fil   = DB::table('za_customer')->where('branch_id',$branch_id)->get();
       
 
 
        return view('content.customer.manage_certificate.certificate_print', [
            'perpage' => $perpage,
            'cus_fil' => $cus_fil,
       
 
        ]);
    }
 
     public function print_cerificate_ajax(Request $request)
    {
        try {
 
            $user = $request->user();
            // $branch_id = $user->branch_id ?? null;
            $helper = new \App\Helpers\Helpers();
           
            $branch_id = $user->branch_id ?? null;
           
            if ($branch_id === null) {
                return response()->json([
                    'status'  => false,
                    'message' => 'No Entity ID found'
                ], 200);
            }
           
            $page     = (int) $request->input('page', 1);
            $perpage  = (int) $request->input('sorting_filter', 25);
            $search_fill = $request->search_fill ?? '';
             $customer = $request->input('customer');
            $project  = $request->input('project');
            $staff    = $request->input('variant');
          $arrayOfStudentIds = RequestCertificateModel::select('za_request_certificate.student_id')
            ->where('status', 0)
            ->get()
            ->pluck('student_id');  // Extracting student IDs as an array
       
        // return $arrayOfStudentIds;
       
        // Check if there are no student IDs in the array
        if ($arrayOfStudentIds->isEmpty()) {
            // Return 0 or any other response you prefer
            return response()->json(['status' => 0, 'message' => 'No students found']);
        }
               
        $lists = RequestCertificateModel::
            where('za_request_certificate.status', 0)
            ->join('za_batch', 'za_request_certificate.batch_id', '=', 'za_batch.sno')
            ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_training', 'za_request_certificate.batch_id', '=', 'za_training.batch_id')
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
            ->leftJoin('za_certificate_logs', function ($join) {
                $join->on('za_certificate_logs.cus_id', '=', 'za_customer.sno')
                    ->on('za_certificate_logs.batch_id', '=', 'za_request_certificate.batch_id');
            })
            ->select(
                'za_request_certificate.sno',
                'za_request_certificate.batch_id',
                'za_customer.sno as customer_sno',
                'za_customer.cus_name',
                'za_customer.cus_pic',
                'za_customer.customer_id',
                'za_customer.cus_mobile',
                'za_customer.cus_gender',
                'za_request_certificate.student_id',
                'za_training.customer_id as training_customer_id',
                'za_batch.batch_name',
                'za_batch.batch_id as org_batch_id',
                'za_course.course_name',
                'za_course.course_id as org_course_id',
                'za_staff.staff_name',
                'za_staff.staff_id as org_staff_id',
                DB::raw('COALESCE(za_certificate_logs.download_count, 0) as download_count'),
 
            )
            ->where('za_customer.branch_id', $branch_id)
            ->whereIn('za_request_certificate.student_id', $arrayOfStudentIds)
            ->distinct();
 
 
        // Search filter
        if ($search_fill != '') {
            $lists->where(function ($list) use ($search_fill) {
                $list->where('za_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('za_course.course_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('za_batch.batch_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('za_customer.customer_id', 'LIKE', "%{$search_fill}%");
            });
        }
 
       
        if (!empty($customer)) {
            $lists->where('za_customer.sno', $customer);
        }
 
 
        // Pagination
        $ManageCommitmentsList = $lists
            ->orderBy('za_request_certificate.sno', 'desc')
            ->paginate($perpage, ['*'], 'page', $page);
 
        // return $ManageCommitmentsList;
 
 
        // Check empty AFTER paginate/get
        if ($ManageCommitmentsList->isEmpty()) {
            return response()->json([
                'status'  => false,
                'message' => 'No data found'
            ], 200);
        }
 
            $ManageCommitmentsList->getCollection()->transform(function ($item) use ($helper) {
                $item->encrypt_sno = isset($item->sno) && !empty($item->sno) ? $helper->encrypt_decrypt($item->sno, 'encrypt') : null;
                return $item;
            });
 
            return response()->json([
                'status' => true,
                'data'   => $ManageCommitmentsList,
            ], 200);
 
        } catch (\Throwable $e) {
 
            Log::error('certificate print list list AJAX Error', [
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
            ]);
 
            return response()->json([
                'status'  => false,
                'message' => 'Something went wrong while loading certificate print list'
            ], 500);
        }
    }
}
