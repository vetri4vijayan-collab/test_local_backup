<?php

namespace App\Http\Controllers;

use App\Services\WhatsAppConversationService;
use App\Services\WhatsAppManagerService;
use App\Support\WhatsAppTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

/** Public Meta callback. It is intentionally separate from authenticated ERP web routes. */
class MetaWhatsAppWebhookController extends Controller
{
    public function handle(Request $request, WhatsAppManagerService $manager, WhatsAppConversationService $conversations)
    {
        if ($request->isMethod('get')) {
            $verifyToken = (string) config('whatsapp.verify_token', '');
            $mode = (string) $request->query('hub_mode', $request->query('hub.mode', ''));
            $token = (string) $request->query('hub_verify_token', $request->query('hub.verify_token', ''));
            $challenge = (string) $request->query('hub_challenge', $request->query('hub.challenge', ''));
            if ($verifyToken !== '' && $mode === 'subscribe' && hash_equals($verifyToken, $token)) {
                return response($challenge, 200)->header('Content-Type', 'text/plain');
            }
            return response('Forbidden', 403);
        }

        if (!$this->validSignature($request)) {
            Log::warning('WhatsApp webhook rejected because signature validation failed.');
            return response('Invalid signature', 403);
        }

        $payload = json_decode($request->getContent(), true);
        if (!is_array($payload)) return response('Invalid JSON', 400);

        try {
            foreach (($payload['entry'] ?? []) as $entry) {
                foreach (($entry['changes'] ?? []) as $change) {
                    $value = $change['value'] ?? [];
                    $phoneNumberId = isset($value['metadata']['phone_number_id']) ? (string) $value['metadata']['phone_number_id'] : null;
                    $settings = $phoneNumberId ? DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('phone_number_id', $phoneNumberId)->first() : null;
                    $branchId = 0; // The API profile and all messages are shared by the ERP; branch filtering is only used for CRM lead/customer lists.
                    if (!$settings) continue;

                    foreach (($value['statuses'] ?? []) as $status) {
                        if (!empty($status['id']) && !empty($status['status'])) {
                            $errors = $status['errors'][0] ?? null;
                            $manager->updateOutboxStatus((string) $status['id'], (string) $status['status'], is_array($errors) ? $errors : null);
                        }
                    }

                    $names = [];
                    foreach (($value['contacts'] ?? []) as $contact) {
                        if (!empty($contact['wa_id'])) $names[preg_replace('/\D+/', '', (string) $contact['wa_id'])] = $contact['profile']['name'] ?? null;
                    }
                    foreach (($value['messages'] ?? []) as $message) {
                        $from = (string) ($message['from'] ?? '');
                        $digits = preg_replace('/\D+/', '', $from);
                        $timestamp = isset($message['timestamp']) ? (string) $message['timestamp'] : null;
                        $dateTime = null;
                        if ($timestamp !== null && ctype_digit($timestamp)) $dateTime = date('Y-m-d H:i:s', (int) $timestamp);
                        $body = (string) ($message['text']['body'] ?? '');
                        $manager->recordInboundSession($from, $timestamp, $phoneNumberId, $body, isset($message['id']) ? (string) $message['id'] : null);
                        $conversations->storeInbound($branchId, $from, $names[$digits] ?? null, $message, $dateTime);
                        // Basic opt-out command support. Consent updates preserve a source/evidence audit.
                        if (in_array(mb_strtolower(trim($body)), ['stop', 'stop all', 'unsubscribe', 'cancel', 'end', 'quit', 'opt out', 'opt-out'], true)) {
                            try {
                                $manager->recordConsent([
                                    'branch_id' => 0, 'phone' => '+' . $digits, 'category' => 'all',
                                    'consent_status' => 'opted_out', 'source' => 'inbound_whatsapp_keyword',
                                    'evidence_ref' => 'meta_message_id:' . substr((string) ($message['id'] ?? 'unknown'), 0, 120),
                                ]);
                            } catch (Throwable $e) {
                                Log::warning('WhatsApp opt-out keyword could not be applied.', ['branch_id' => $branchId]);
                            }
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            // Return 500 to let Meta retry; unique provider message IDs make the ingestion idempotent.
            Log::error('WhatsApp webhook processing failed.', ['exception' => class_basename($e)]);
            return response('Webhook processing failed', 500);
        }
        return response('EVENT_RECEIVED', 200);
    }

    private function validSignature(Request $request): bool
    {
        $secret = (string) config('whatsapp.app_secret', '');
        $signature = (string) $request->header('X-Hub-Signature-256', '');
        if ($secret === '' || !preg_match('/^sha256=([a-f0-9]{64})$/i', $signature, $matches)) return false;
        $expected = hash_hmac('sha256', $request->getContent(), $secret);
        return hash_equals($expected, strtolower($matches[1]));
    }
}
