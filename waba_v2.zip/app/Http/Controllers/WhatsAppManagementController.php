<?php

namespace App\Http\Controllers;

use App\Services\WhatsAppConversationService;
use App\Services\WhatsAppManagerService;
use App\Support\WhatsAppTables;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/** Administrative pages and AJAX endpoints. Never exposes a stored access token. */
class WhatsAppManagementController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $user = $request->user();
            $allowed = (array) config('whatsapp.admin_user_ids', []);
            $userId = (string) ($user->user_id ?? $user->id ?? '');
            if (!$user || !$allowed || !in_array($userId, array_map('strval', $allowed), true)) abort(403, 'WhatsApp Management administrator access is not configured for this account.');
            return $next($request);
        });
    }

    private function table(string $suffix): string { return WhatsAppTables::name($suffix); }
    private function branch(Request $request): int
    {
        $id = (int) $request->input('branch_id', $request->query('branch_id', $request->user()->branch_id ?? 0));
        if ($id < 1) abort(422, 'Select a valid branch.');
        return $id;
    }
    private function actor(Request $request): int { return (int) ($request->user()->user_id ?? $request->user()->id ?? 0); }
    private function ok($data = [], string $message = 'OK') { return response()->json(['ok' => true, 'message' => $message, 'data' => $data]); }
    private function fail(string $message, int $status = 422, array $details = []) { return response()->json(['ok' => false, 'message' => $message, 'details' => $details], $status); }

    private function page(string $section, ?string $kind = null)
    {
        return view('content.whatsapp_management.layout', [
            'section' => $section,
            'kind' => $kind ?: 'lead',
            'defaultBranchId' => (int) request()->query('branch_id', request()->user()->branch_id ?? 1),
            'features' => config('whatsapp.default_features', []),
        ]);
    }
    public function dashboard() { return $this->page('dashboard'); }
    public function chat(string $kind = 'lead')
    {
        if (!in_array($kind, ['lead', 'customer', 'common'], true)) abort(404);
        $flag = ['lead' => 'lead_chat', 'customer' => 'customer_chat', 'common' => 'common_chat'][$kind];
        if (!$this->featureEnabled((int) request()->query('branch_id', request()->user()->branch_id ?? 1), $flag)) abort(403, 'This WhatsApp chat menu is disabled in Setup.');
        return $this->page('chat', $kind);
    }
    public function groups(Request $request) { $this->requireFeature($request, 'custom_group_chat'); return $this->page('groups'); }
    public function broadcast(Request $request) { $this->requireFeature($request, 'broadcast_channel'); return $this->page('broadcast'); }
    public function calling(Request $request) { $this->requireFeature($request, 'calling'); return $this->page('calling'); }
    public function templatesPage() { return $this->page('templates'); }
    public function automation() { return $this->page('automation'); }
    public function campaignsPage(Request $request) { $this->requireFeature($request, 'bulk_campaigns'); return $this->page('campaigns'); }
    public function logsPage() { return $this->page('logs'); }
    public function setup() { return $this->page('setup'); }
    public function consentPage() { return $this->page('consent'); }

    private function requireFeature(Request $request, string $feature): void
    {
        if (!$this->featureEnabled(0, $feature)) abort(403, 'This WhatsApp feature is disabled in the shared ERP setup.');
    }

    private function requireChatKind(Request $request, string $kind): void
    {
        $feature = ['lead' => 'lead_chat', 'customer' => 'customer_chat', 'common' => 'common_chat'][$kind] ?? 'common_chat';
        $this->requireFeature($request, $feature);
    }

    private function contactAllowed(Request $request, WhatsAppConversationService $service, string $kind, string $phone): bool
    {
        if (!in_array($kind, ['lead', 'customer'], true)) return true;
        return $service->isContactInBranch($this->branch($request), $kind, $phone);
    }

    private function featureEnabled(int $branchId, string $feature): bool
    {
        $setting = DB::table($this->table('whatsapp_menu_settings'))->where('branch_id', 0)->where('feature_key', $feature)->value('is_enabled');
        return $setting === null ? (bool) (config('whatsapp.default_features.' . $feature, false)) : (bool) $setting;
    }
    public function features(Request $request)
    {
        $features = (array) config('whatsapp.default_features', []);
        foreach ($features as $key => $default) $features[$key] = $this->featureEnabled(0, $key);
        return $this->ok(['branch_id' => 0, 'features' => $features]);
    }

    public function saveFeatures(Request $request)
    {
        $actor = $this->actor($request); $features = (array) config('whatsapp.default_features', []);
        $values = $request->input('features', []);
        if (!is_array($values)) return $this->fail('Features must be an object.');
        foreach ($values as $key => $value) {
            if (!array_key_exists($key, $features)) continue;
            DB::table($this->table('whatsapp_menu_settings'))->updateOrInsert(
                ['branch_id' => 0, 'feature_key' => $key],
                ['is_enabled' => filter_var($value, FILTER_VALIDATE_BOOLEAN) ? 1 : 0, 'updated_by' => $actor, 'updated_at' => now(), 'created_at' => now()]
            );
        }
        return $this->features($request);
    }

    public function overview(Request $request)
    {
        $monthStart = now()->startOfMonth();
        $outbox = DB::table($this->table('whatsapp_outbox'))->where('branch_id', 0)->where('created_at', '>=', $monthStart);
        $counts = (clone $outbox)->select('status', DB::raw('COUNT(*) as total'))->groupBy('status')->pluck('total', 'status')->toArray();
        $settings = app(WhatsAppManagerService::class)->settingsForBranch(0);
        $templates = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', 0);
        return $this->ok([
            'branch_id' => 0,
            'global_kill_switch' => (bool) DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->value('kill_switch'),
            'profile_enabled' => (bool) ($settings->is_enabled ?? false),
            'profile_configured' => (bool) ($settings && $settings->phone_number_id && $settings->waba_id && $settings->access_token_encrypted),
            'templates_approved' => (clone $templates)->where('approval_status', 'APPROVED')->count(),
            'templates_total' => (clone $templates)->count(), 'counts' => $counts,
            'campaigns_month' => DB::table($this->table('whatsapp_campaigns'))->where('branch_id', 0)->where('created_at', '>=', $monthStart)->count(),
        ]);
    }

    public function analytics(Request $request)
    {
        $year = max(2000, min(2100, (int) $request->input('year', now()->year)));
        $mode = $request->input('period', 'month'); $month = max(1, min(12, (int) $request->input('month', now()->month)));
        $from = $mode === 'year' ? Carbon::create($year, 1, 1)->startOfDay() : Carbon::create($year, $month, 1)->startOfDay();
        $to = $mode === 'year' ? $from->copy()->addYear() : $from->copy()->addMonth();
        $counts = DB::table($this->table('whatsapp_outbox'))->select('status', DB::raw('COUNT(*) as total'))
            ->where('branch_id', 0)->where('created_at', '>=', $from)->where('created_at', '<', $to)->groupBy('status')->pluck('total', 'status')->toArray();
        $byMonth = DB::table($this->table('whatsapp_outbox'))->select(DB::raw('MONTH(created_at) as month_num'), 'status', DB::raw('COUNT(*) as total'))
            ->where('branch_id', 0)->where('created_at', '>=', Carbon::create($year, 1, 1))->where('created_at', '<', Carbon::create($year + 1, 1, 1))->groupBy(DB::raw('MONTH(created_at)'), 'status')->get();
        return $this->ok(['year' => $year, 'month' => $month, 'period' => $mode, 'from' => $from->toDateString(), 'to_exclusive' => $to->toDateString(), 'counts' => $counts, 'by_month' => $byMonth]);
    }

    public function configs(Request $request)
    {
        $row = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->first();
        if (!$row) return $this->ok(['branch_id' => 0, 'configured' => false, 'is_enabled' => false, 'waba_id' => '', 'phone_number_id' => '', 'graph_api_version' => config('whatsapp.api_version', 'v26.0'), 'min_send_interval_seconds' => 10]);
        return $this->ok(['branch_id' => 0, 'configured' => true, 'provider' => $row->provider, 'waba_id' => $row->waba_id, 'phone_number_id' => $row->phone_number_id, 'graph_api_version' => $row->graph_api_version, 'is_enabled' => (bool) $row->is_enabled, 'kill_switch' => (bool) $row->kill_switch, 'min_send_interval_seconds' => (int) $row->min_send_interval_seconds, 'token_saved' => !empty($row->access_token_encrypted)]);
    }

    public function saveConfig(Request $request)
    {
        $input = $request->validate(['waba_id' => 'required|string|max:100', 'phone_number_id' => 'required|string|max:100', 'graph_api_version' => ['required','regex:/^v\d+\.0$/'], 'access_token' => 'nullable|string|min:30|max:10000', 'is_enabled' => 'nullable|boolean', 'min_send_interval_seconds' => 'nullable|integer|min:5|max:60']);
        $current = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->first();
        if (!$current && empty($input['access_token'])) return $this->fail('A system-user access token is required when creating the shared ERP profile.');
        $data = ['branch_id' => 0, 'provider' => 'meta_cloud_api', 'waba_id' => trim($input['waba_id']), 'phone_number_id' => trim($input['phone_number_id']), 'graph_api_version' => $input['graph_api_version'], 'is_enabled' => (int) ($input['is_enabled'] ?? false), 'min_send_interval_seconds' => (int) ($input['min_send_interval_seconds'] ?? 10), 'updated_by' => $this->actor($request), 'updated_at' => now()];
        if (!empty($input['access_token'])) $data['access_token_encrypted'] = Crypt::encryptString($input['access_token']);
        if ($current) DB::table($this->table('whatsapp_automation_settings'))->where('id', $current->id)->update($data);
        else { $data['kill_switch'] = 0; $data['created_by'] = $this->actor($request); $data['created_at'] = now(); DB::table($this->table('whatsapp_automation_settings'))->insert($data); }
        return $this->configs($request);
    }

    public function testConfig(Request $request)
    {
        $result = app(WhatsAppManagerService::class)->testConnection(0);
        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function toggleConfig(Request $request)
    {
        $enabled = $request->boolean('enabled');
        $exists = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->exists();
        if (!$exists) return $this->fail('No shared ERP API profile found. Configure it first.');
        DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->update(['is_enabled' => $enabled ? 1 : 0, 'updated_by' => $this->actor($request), 'updated_at' => now()]);
        return $this->ok(['is_enabled' => $enabled], $enabled ? 'Shared ERP WhatsApp profile enabled.' : 'Shared ERP WhatsApp profile paused.');
    }

    public function killSwitch(Request $request)
    {
        $on = $request->boolean('enabled');
        $query = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0);
        $current = $query->first();
        if ($current) {
            $query->update(['kill_switch' => $on ? 1 : 0, 'updated_by' => $this->actor($request), 'updated_at' => now()]);
        } else {
            DB::table($this->table('whatsapp_automation_settings'))->insert([
                'branch_id' => 0, 'provider' => 'meta_cloud_api', 'waba_id' => '', 'phone_number_id' => null,
                'graph_api_version' => config('whatsapp.api_version', 'v26.0'), 'access_token_encrypted' => null,
                'is_enabled' => 0, 'kill_switch' => $on ? 1 : 0, 'min_send_interval_seconds' => 10,
                'created_by' => $this->actor($request), 'updated_by' => $this->actor($request), 'created_at' => now(), 'updated_at' => now(),
            ]);
        }
        return $this->ok(['global_kill_switch' => $on], $on ? 'Global WhatsApp sending paused.' : 'Global WhatsApp pause removed. The profile must also be enabled before sending resumes.');
    }

    public function templates(Request $request)
    {
        $rows = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', 0)->orderBy('name')->orderBy('language')->limit(500)->get(['id','name','language','category','approval_status','is_enabled','last_synced_at','components_json']);
        return $this->ok(['templates' => $rows]);
    }

    public function syncTemplates(Request $request)
    {
        $result = app(WhatsAppManagerService::class)->syncTemplates(0);
        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function toggleTemplate(Request $request)
    {
        $data = $request->validate(['id' => 'required|integer|min:1','enabled' => 'required|boolean']);
        $exists = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', 0)->where('id', $data['id'])->where('approval_status', 'APPROVED')->exists();
        if (!$exists) return $this->fail('Template not found or not approved. Only approved templates can be enabled.');
        DB::table($this->table('whatsapp_template_registry'))->where('branch_id', 0)->where('id', $data['id'])->update(['is_enabled' => (int) $data['enabled'], 'updated_at' => now()]);
        return $this->ok([], 'Shared template setting updated.');
    }

    public function workflowRules(Request $request)
    {
        return $this->ok(['rules' => DB::table($this->table('whatsapp_workflow_rules'))->where('branch_id', 0)->orderBy('event_key')->get()]);
    }

    public function saveWorkflowRule(Request $request)
    {
        $data = $request->validate(['event_key'=>['required','regex:/^[a-z][a-z0-9_.-]{1,99}$/'],'template_name'=>'required|string|max:200','language'=>'required|string|max:20','parameter_map_json'=>'nullable|string|max:12000','notes'=>'nullable|string|max:1000','is_enabled'=>'nullable|boolean']);
        $map = trim((string) ($data['parameter_map_json'] ?? ''));
        if ($map !== '') { $parsed = json_decode($map, true); if (json_last_error() !== JSON_ERROR_NONE || !is_array($parsed)) return $this->fail('Parameter mapping must be valid JSON array.'); }
        $template = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', 0)->where('name', $data['template_name'])->where('language', $data['language'])->where('approval_status', 'APPROVED')->where('is_enabled', 1)->first();
        if (!$template) return $this->fail('Select a synced, Meta APPROVED, enabled template for the shared WABA and language.');
        DB::table($this->table('whatsapp_workflow_rules'))->updateOrInsert(['branch_id' => 0, 'event_key' => $data['event_key']], ['template_name' => $data['template_name'], 'language' => $data['language'], 'parameter_map_json' => $map ?: null, 'notes' => $data['notes'] ?? null, 'is_enabled' => (int) ($data['is_enabled'] ?? true), 'updated_by' => $this->actor($request), 'updated_at' => now(), 'created_by' => $this->actor($request), 'created_at' => now()]);
        return $this->ok([], 'Shared ERP workflow rule saved. Test with a consented internal recipient before enabling production events.');
    }

    public function toggleWorkflowRule(Request $request)
    {
        $data = $request->validate(['id'=>'required|integer|min:1','enabled'=>'required|boolean']);
        $exists = DB::table($this->table('whatsapp_workflow_rules'))->where('branch_id', 0)->where('id', $data['id'])->exists();
        if (!$exists) return $this->fail('Workflow rule was not found.');
        DB::table($this->table('whatsapp_workflow_rules'))->where('branch_id', 0)->where('id', $data['id'])->update(['is_enabled' => (int) $data['enabled'], 'updated_by' => $this->actor($request), 'updated_at' => now()]);
        return $this->ok();
    }

    public function outbox(Request $request)
    {
        $period = $request->input('period', 'month'); $year = max(2000, min(2100, (int) $request->input('year', now()->year))); $month = max(1, min(12, (int) $request->input('month', now()->month)));
        $from = $period === 'year' ? Carbon::create($year, 1, 1) : Carbon::create($year, $month, 1); $to = $period === 'year' ? $from->copy()->addYear() : $from->copy()->addMonth();
        $query = DB::table($this->table('whatsapp_outbox'))->where('branch_id', 0)->where('created_at', '>=', $from)->where('created_at', '<', $to);
        if ($request->filled('status') && $request->input('status') !== 'all') $query->where('status', $request->input('status'));
        if ($request->filled('q')) { $term = trim((string) $request->input('q')); $query->where(function ($sub) use ($term) { $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $term) . '%'; $sub->where('phone_e164','like',$like)->orWhere('template_name','like',$like)->orWhere('workflow_event_key','like',$like)->orWhere('source_type','like',$like); }); }
        $rows = $query->orderByDesc('id')->paginate(50, ['id','phone_e164','message_type','template_name','language','source_type','workflow_event_key','campaign_id','status','error_code','error_message','scheduled_at','meta_message_id','sent_at','delivered_at','read_at','failed_at','created_at']);
        return $this->ok(['rows' => $rows->items(), 'page' => $rows->currentPage(), 'last_page' => $rows->lastPage(), 'total' => $rows->total()]);
    }

    public function sendTemplate(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','template_name'=>'required|string|max:200','language'=>'required|string|max:20','components'=>'nullable|string|max:20000','source_type'=>'nullable|string|max:80']);
        $components = json_decode((string) ($data['components'] ?? '[]'), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($components)) return $this->fail('Components must be valid JSON array.');
        $result = app(WhatsAppManagerService::class)->queueTemplate(['branch_id'=>0,'to'=>$data['to'],'template_name'=>$data['template_name'],'language'=>$data['language'],'components'=>$components,'source_type'=>$data['source_type'] ?? 'admin_manual','created_by'=>$this->actor($request),'idempotency_key'=>'manual:'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendText(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','text'=>'required|string|max:4096','kind'=>'nullable|in:lead,customer,common']);
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch. Use Common Chat for a new contact.', 404);
        $result = app(WhatsAppManagerService::class)->queueText(['branch_id'=>0,'to'=>$data['to'],'text'=>$data['text'],'source_type'=>'chat_text_'.$kind,'created_by'=>$this->actor($request),'idempotency_key'=>'chat:'.$kind.':'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function bulkSend(Request $request)
    {
        $this->requireFeature($request, 'bulk_campaigns');
        $data = $request->validate([
            'name' => 'required|string|max:191',
            'template_name' => 'required|string|max:200',
            'language' => 'required|string|max:20',
            'components' => 'nullable|string|max:20000',
            'recipients' => 'nullable|string|max:30000',
            'audience_id' => 'nullable|integer|min:1',
        ]);
        $branch = 0;
        $recipients = [];
        $lines = preg_split('/[\r\n,;]+/', (string) ($data['recipients'] ?? ''));
        $recipients = array_merge($recipients, array_filter(array_map('trim', $lines)));

        if (!empty($data['audience_id'])) {
            $audience = DB::table($this->table('whatsapp_audiences'))
                ->where('branch_id', 0)->where('id', (int) $data['audience_id'])->first();
            if (!$audience) return $this->fail('Selected saved audience was not found in this branch.');
            $memberPhones = DB::table($this->table('whatsapp_audience_members'))
                ->where('branch_id', 0)->where('audience_id', $audience->id)
                ->orderBy('id')->pluck('phone_e164')->all();
            $recipients = array_merge($recipients, $memberPhones);
        }
        $recipients = array_values(array_unique(array_filter(array_map('trim', $recipients))));
        $max = (int) config('whatsapp.bulk_max_recipients', 250);
        if (!$recipients || count($recipients) > $max) {
            return $this->fail('Recipient count must be between 1 and ' . $max . '. Choose a saved audience or enter international numbers.');
        }
        $components = json_decode((string) ($data['components'] ?? '[]'), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($components)) return $this->fail('Components must be valid JSON array.');

        $campaignId = DB::table($this->table('whatsapp_campaigns'))->insertGetId([
            'campaign_uuid' => (string) Str::uuid(), 'branch_id' => $branch, 'name' => $data['name'],
            'template_name' => $data['template_name'], 'language' => $data['language'], 'state' => 'queued',
            'total_recipients' => count($recipients), 'queued_count' => 0, 'blocked_count' => 0,
            'created_by' => $this->actor($request), 'created_at' => now(), 'updated_at' => now(),
        ]);
        $queued = 0; $blocked = 0; $results = [];
        $spacing = (int) config('whatsapp.default_bulk_pacing_seconds', 10);
        foreach ($recipients as $idx => $to) {
            $result = app(WhatsAppManagerService::class)->queueTemplate([
                'branch_id' => $branch, 'to' => $to, 'template_name' => $data['template_name'],
                'language' => $data['language'], 'components' => $components, 'source_type' => 'bulk_campaign',
                'campaign_id' => $campaignId, 'created_by' => $this->actor($request), 'delay_seconds' => $idx * $spacing,
                'idempotency_key' => 'campaign:' . $campaignId . ':' . hash('sha256', $to),
            ]);
            if (!empty($result['ok'])) $queued++; else $blocked++;
            // Do not echo recipient numbers back in the campaign response; details belong in secured logs.
            $results[] = ['recipient_ref' => substr(hash('sha256', $to), 0, 12), 'status' => $result['status'] ?? 'blocked', 'reason' => $result['reason'] ?? null, 'outbox_id' => $result['id'] ?? null];
        }
        DB::table($this->table('whatsapp_campaigns'))->where('id', $campaignId)->update([
            'state' => $queued ? ($blocked ? 'partially_queued' : 'queued') : 'blocked',
            'queued_count' => $queued, 'blocked_count' => $blocked, 'updated_at' => now(),
        ]);
        return $this->ok(['campaign_id' => $campaignId, 'total' => count($recipients), 'queued' => $queued, 'blocked' => $blocked, 'results' => $results], 'Campaign queue request processed; queue admission is not final delivery. Check Message Logs for provider receipts.');
    }

    public function conversations(Request $request, WhatsAppConversationService $service)
    {
        $kind = (string) $request->input('kind','all'); $term = trim((string) $request->input('q',''));
        $branch = in_array($kind, ['lead','customer'], true) ? $this->branch($request) : 0;
        if (!in_array($kind, ['all','lead','customer','common'], true)) $kind = 'all';
        if ($kind !== 'all') {
            $feature = ['lead'=>'lead_chat','customer'=>'customer_chat','common'=>'common_chat'][$kind];
            $this->requireFeature($request, $feature);
        } elseif (!$this->featureEnabled(0, 'lead_chat') && !$this->featureEnabled(0, 'customer_chat') && !$this->featureEnabled(0, 'common_chat')) {
            abort(403, 'All WhatsApp chat features are disabled for the selected branch.');
        }
        return $this->ok(['conversations'=>$service->listConversations($branch,$kind,$term)]);
    }
    public function conversationMessages(Request $request, string $phone, WhatsAppConversationService $service)
    {
        $kind = (string) $request->query('kind', 'common');
        if (!in_array($kind, ['lead','customer','common'], true)) $kind = 'common';
        $this->requireChatKind($request, $kind);
        try {
            $phone = urldecode($phone);
            if (in_array($kind, ['lead','customer'], true)) {
                $branch = $this->branch($request);
                if (!$service->isContactInBranch($branch, $kind, $phone)) abort(404, 'This contact is not in the selected branch.');
            }
            $result = $service->conversationFor(0, $phone, $kind);
        } catch (\Symfony\Component\HttpKernel\Exception\HttpException $e) { throw $e; }
          catch (Throwable $e) { return $this->fail('Conversation phone or branch is invalid.'); }
        return $this->ok($result);
    }

    public function createContact(Request $request, WhatsAppConversationService $service)
    {
        $data = $request->validate(['phone' => 'required|string|max:40', 'display_name' => 'nullable|string|max:191', 'kind' => 'nullable|in:lead,customer,common,unknown']);
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, in_array($kind, ['lead','customer'], true) ? $kind : 'common');
        try {
            $normalizedPhone = $service->normalizeE164($data['phone']);
            if (in_array($kind, ['lead','customer'], true)) {
                $branch = $this->branch($request);
                if (!$service->isContactInBranch($branch, $kind, $normalizedPhone)) return $this->fail('New unsaved numbers belong in Common Chat. This tab is limited to saved CRM contacts in the selected branch.');
            } else {
                $kind = 'common';
            }
            $contact = $service->getOrCreateContact(0, $normalizedPhone, $data['display_name'] ?? null, $kind);
        } catch (Throwable $e) { return $this->fail('Invalid international phone number.'); }
        return $this->ok(['contact' => $contact], 'Contact saved. Outside the 24-hour window, initiate with an approved template.');
    }

    public function sendMedia(Request $request)
    {
        $request->validate(['to' => 'required|string|max:40', 'kind' => 'nullable|in:lead,customer,common', 'caption' => 'nullable|string|max:1024', 'media' => 'required|file|max:20480']);
        $kind = (string) $request->input('kind', 'common');
        if (in_array($kind, ['lead','customer'], true)) $this->branch($request);
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, (string) $request->input('to'))) return $this->fail('This number is not a saved contact in the selected branch. Use Common Chat for a new contact.', 404);
        $file = $request->file('media');
        $mime = strtolower((string) $file->getMimeType());
        $extension = strtolower((string) $file->getClientOriginalExtension());
        $requestedType = (string) $request->input('media_type', '');
        if ($requestedType === 'sticker' && $mime === 'image/webp') $type = 'sticker';
        elseif (in_array($mime, ['image/jpeg','image/png','image/webp'], true)) $type = 'image';
        elseif (in_array($mime, ['video/mp4','video/3gpp'], true)) $type = 'video';
        elseif (in_array($mime, ['audio/aac','audio/mp4','audio/mpeg','audio/amr','audio/ogg','audio/opus','audio/wav','audio/x-wav'], true)) $type = 'audio';
        elseif (in_array($mime, ['application/pdf','text/plain','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','text/csv'], true)) $type = 'document';
        else return $this->fail('Unsupported attachment type. Use JPG/PNG/WebP, MP4/3GP, supported audio, PDF, Office documents, or CSV.');
        $relativePath = $file->store('whatsapp-pending', 'local');
        $result = app(WhatsAppManagerService::class)->queueCloudMessage([
            'branch_id' => 0, 'to' => $request->input('to'), 'message_type' => $type, 'media_path' => $relativePath,
            'media_filename' => basename((string) $file->getClientOriginalName()), 'media_mime_type' => $mime,
            'media_caption' => $request->input('caption'), 'source_type' => 'chat_media_' . $kind,
            'created_by' => $this->actor($request), 'idempotency_key' => 'media:' . Str::uuid(),
            'payload' => [],
        ]);
        if (empty($result['ok'])) \Illuminate\Support\Facades\Storage::disk('local')->delete($relativePath);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendReaction(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','target_message_id'=>'required|string|max:160','emoji'=>'required|string|max:20','kind'=>'nullable|in:lead,customer,common']);
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        if (!preg_match('/^wamid\./', $data['target_message_id'])) return $this->fail('Reaction target must be a Meta message ID.');
        try { $reactionPhone = app(WhatsAppConversationService::class)->normalizeE164($data['to']); }
        catch (Throwable $e) { return $this->fail('Invalid recipient number.', 422); }
        $contactId = DB::table($this->table('whatsapp_contacts'))->where('branch_id', 0)->where('phone_e164', $reactionPhone)->value('id');
        $targetContactId = DB::table($this->table('whatsapp_messages'))->where('branch_id', 0)->where('meta_message_id', $data['target_message_id'])->value('contact_id');
        if (!$contactId || !$targetContactId || (int) $contactId !== (int) $targetContactId) return $this->fail('Reaction target does not belong to this conversation.', 404);
        $result = app(WhatsAppManagerService::class)->queueCloudMessage([
            'to'=>$data['to'], 'message_type'=>'reaction', 'payload'=>['type'=>'reaction','reaction'=>['message_id'=>$data['target_message_id'],'emoji'=>$data['emoji']]],
            'source_type'=>'chat_reaction_'.$kind, 'created_by'=>$this->actor($request), 'idempotency_key'=>'reaction:'.Str::uuid(),
        ]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendContactCard(Request $request)
    {
        $data = $request->validate([
            'to' => 'required|string|max:40', 'contact_name' => 'required|string|max:191',
            'contact_phone' => 'required|string|max:40', 'kind' => 'nullable|in:lead,customer,common',
        ]);
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        try { $contactPhone = app(WhatsAppConversationService::class)->normalizeE164($data['contact_phone']); }
        catch (Throwable $e) { return $this->fail('Shared contact phone number is invalid.', 422); }
        $name = trim($data['contact_name']);
        $payload = ['type' => 'contacts', 'contacts' => [[
            'name' => ['formatted_name' => $name, 'first_name' => mb_substr($name, 0, 80)],
            'phones' => [['phone' => $contactPhone, 'type' => 'CELL', 'wa_id' => ltrim($contactPhone, '+')]],
        ]]];
        $result = app(WhatsAppManagerService::class)->queueCloudMessage([
            'to' => $data['to'], 'message_type' => 'contacts', 'payload' => $payload,
            'source_type' => 'chat_contact_card_' . $kind, 'created_by' => $this->actor($request),
            'idempotency_key' => 'contact-card:' . Str::uuid(),
        ]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendLocation(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','latitude'=>'required|numeric|between:-90,90','longitude'=>'required|numeric|between:-180,180','name'=>'nullable|string|max:100','address'=>'nullable|string|max:255','kind'=>'nullable|in:lead,customer,common']);
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        $result = app(WhatsAppManagerService::class)->queueCloudMessage([
            'to'=>$data['to'], 'message_type'=>'location', 'payload'=>['type'=>'location','location'=>array_filter(['latitude'=>(float)$data['latitude'],'longitude'=>(float)$data['longitude'],'name'=>$data['name'] ?? null,'address'=>$data['address'] ?? null], function($v){return $v!==null && $v!=='';})],
            'source_type'=>'chat_location_'.$kind, 'created_by'=>$this->actor($request), 'idempotency_key'=>'location:'.Str::uuid(),
        ]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendInteractive(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','interactive_json'=>'required|string|max:12000','kind'=>'nullable|in:lead,customer,common']);
        $interactive = json_decode($data['interactive_json'], true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($interactive) || !in_array($interactive['type'] ?? '', ['button','list'], true)) return $this->fail('Interactive payload must be a valid WhatsApp button or list object.');
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        $result = app(WhatsAppManagerService::class)->queueCloudMessage(['to'=>$data['to'],'message_type'=>'interactive','payload'=>['type'=>'interactive','interactive'=>$interactive], 'source_type'=>'chat_interactive_'.$kind,'created_by'=>$this->actor($request),'idempotency_key'=>'interactive:'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    public function sendFlow(Request $request)
    {
        $data = $request->validate(['to'=>'required|string|max:40','flow_id'=>'required|string|max:100','flow_token'=>'required|string|max:200','flow_cta'=>'required|string|max:30','body'=>'required|string|max:1024','flow_action'=>'nullable|in:navigate,data_exchange','flow_action_payload'=>'nullable|string|max:5000','kind'=>'nullable|in:lead,customer,common']);
        $actionPayload = json_decode((string)($data['flow_action_payload'] ?? '{}'), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($actionPayload)) return $this->fail('Flow action payload must be a JSON object.');
        $interactive = ['type'=>'flow','body'=>['text'=>$data['body']],'action'=>['name'=>'flow','parameters'=>['flow_message_version'=>'3','flow_id'=>$data['flow_id'],'flow_token'=>$data['flow_token'],'flow_cta'=>$data['flow_cta'],'flow_action'=>$data['flow_action'] ?? 'navigate','flow_action_payload'=>$actionPayload]]];
        $kind = $data['kind'] ?? 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $data['to'])) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        $result = app(WhatsAppManagerService::class)->queueCloudMessage(['to'=>$data['to'],'message_type'=>'interactive','payload'=>['type'=>'interactive','interactive'=>$interactive], 'source_type'=>'chat_flow_'.$kind,'created_by'=>$this->actor($request),'idempotency_key'=>'flow:'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }

    /** Secure media proxy: the Meta media URL is never exposed to the browser. */
    public function mediaContent(Request $request, int $messageId)
    {
        $message = DB::table($this->table('whatsapp_messages'))->join($this->table('whatsapp_contacts'), $this->table('whatsapp_contacts') . '.id', '=', $this->table('whatsapp_messages') . '.contact_id')->where($this->table('whatsapp_messages') . '.branch_id',0)->where($this->table('whatsapp_messages') . '.id',$messageId)->first([$this->table('whatsapp_messages') . '.media_id',$this->table('whatsapp_messages') . '.media_mime_type',$this->table('whatsapp_messages') . '.media_filename',$this->table('whatsapp_contacts') . '.phone_e164']);
        if (!$message || empty($message->media_id)) abort(404);
        $kind = (string) $request->query('kind', 'common');
        if (!in_array($kind, ['lead','customer','common'], true)) $kind = 'common';
        $this->requireChatKind($request, $kind);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $message->phone_e164)) abort(404);
        $settings = app(WhatsAppManagerService::class)->settingsForBranch(0);
        if (!$settings || empty($settings->phone_number_id)) abort(503, 'WhatsApp profile unavailable.');
        try {
            $token = app(WhatsAppManagerService::class)->accessTokenForSettings($settings);
        } catch (Throwable $e) { $token = null; }
        if (!$token) abort(503, 'WhatsApp media credentials unavailable.');
        $version = ltrim((string)($settings->graph_api_version ?: config('whatsapp.api_version','v26.0')), '/');
        $meta = \Illuminate\Support\Facades\Http::withToken($token)->acceptJson()->timeout(20)->get('https://graph.facebook.com/'.$version.'/'.rawurlencode($message->media_id));
        if (!$meta->successful()) abort(502, 'Meta media metadata request failed.');
        $mediaUrl = (string)($meta->json('url') ?? '');
        $host = strtolower((string)parse_url($mediaUrl, PHP_URL_HOST));
        if (strtolower((string)parse_url($mediaUrl, PHP_URL_SCHEME)) !== 'https' || !($host === 'facebook.com' || str_ends_with($host, '.facebook.com') || $host === 'fbcdn.net' || str_ends_with($host, '.fbcdn.net') || $host === 'fbsbx.com' || str_ends_with($host, '.fbsbx.com') || $host === 'whatsapp.net' || str_ends_with($host, '.whatsapp.net'))) abort(502, 'Meta returned an untrusted media host.');
        $media = \Illuminate\Support\Facades\Http::withToken($token)->timeout(45)->get($mediaUrl);
        if (!$media->successful()) abort(502, 'Meta media download failed.');
        return response($media->body(), 200, ['Content-Type'=>$message->media_mime_type ?: ($media->header('Content-Type') ?: 'application/octet-stream'), 'Content-Disposition'=>'inline; filename="'.str_replace('"','',(string)($message->media_filename ?: ('whatsapp-'.$messageId))).'"', 'X-Content-Type-Options'=>'nosniff', 'Cache-Control'=>'private, no-store']);
    }

    public function markConversationRead(Request $request, string $phone)
    {
        $data = $request->validate(['kind' => 'required|in:lead,customer,common']);
        $kind = $data['kind'];
        $this->requireChatKind($request, $kind);
        $phone = urldecode($phone);
        if (!$this->contactAllowed($request, app(WhatsAppConversationService::class), $kind, $phone)) return $this->fail('This number is not a saved contact in the selected branch.', 404);
        try { $normalizedPhone = app(WhatsAppConversationService::class)->normalizeE164($phone); }
        catch (Throwable $e) { return $this->fail('Invalid contact number.', 422); }
        $contact = DB::table($this->table('whatsapp_contacts'))->where('branch_id', 0)->where('phone_e164', $normalizedPhone)->first();
        if (!$contact) return $this->ok(['marked' => 0], 'No stored inbound messages to mark as read.');
        $ids = DB::table($this->table('whatsapp_messages'))->where('branch_id', 0)->where('contact_id', $contact->id)->where('direction', 'inbound')->where('status', 'received')->whereNotNull('meta_message_id')->orderByDesc('id')->limit(20)->pluck('meta_message_id')->all();
        $manager = app(WhatsAppManagerService::class); $marked = 0; $failed = 0;
        foreach ($ids as $id) { $result = $manager->markAsRead((string) $id); if (!empty($result['ok'])) $marked++; else $failed++; }
        return $this->ok(['marked' => $marked, 'failed' => $failed], $marked ? 'Recent inbound messages marked as read.' : ($failed ? 'Meta did not confirm read receipts.' : 'No unread inbound messages.'));
    }

    public function recordConsent(Request $request)
    {
        $data = $request->validate(['phone'=>'required|string|max:40','category'=>'required|in:all,marketing,utility,authentication','consent_status'=>'required|in:opted_in,opted_out','source'=>'required|string|max:100','evidence_ref'=>'required|string|max:1000']);
        $data['branch_id'] = 0; $data['created_by'] = $this->actor($request);
        $result = app(WhatsAppManagerService::class)->recordConsent($data);
        return response()->json($result, !empty($result['ok']) ? 200 : 422);
    }

    public function audiences(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        return $this->ok(['audiences'=>DB::table($this->table('whatsapp_audiences'))->where('branch_id',0)->orderByDesc('id')->limit(100)->get()]);
    }

    public function createAudience(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        $data = $request->validate(['name'=>'required|string|max:191','description'=>'nullable|string|max:1000']);
        $id = DB::table($this->table('whatsapp_audiences'))->insertGetId(['branch_id'=>0,'name'=>$data['name'],'description'=>$data['description'] ?? null,'created_by'=>$this->actor($request),'created_at'=>now(),'updated_at'=>now()]);
        return $this->ok(['id'=>$id], 'ERP audience created. This is a recipient list, not a native WhatsApp group.');
    }

    public function addAudienceMembers(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        $data = $request->validate(['audience_id'=>'required|integer|min:1','recipients'=>'required|string|max:30000']);
        $aud = DB::table($this->table('whatsapp_audiences'))->where('branch_id',0)->where('id',$data['audience_id'])->first(); if (!$aud) return $this->fail('Audience not found.');
        $lines = preg_split('/[\\r\\n,;]+/', (string)$data['recipients']); $phones = array_values(array_unique(array_filter(array_map('trim',$lines)))); if (count($phones)>250) return $this->fail('Add at most 250 audience members per operation.');
        $inserted = 0; $manager = app(WhatsAppManagerService::class);
        foreach ($phones as $phone) { try { $normal = $manager->normalizePhone($phone); } catch (Throwable $e) { continue; }
            DB::table($this->table('whatsapp_audience_members'))->updateOrInsert(['branch_id'=>0,'audience_id'=>$aud->id,'phone_e164'=>$normal],['consent_verified'=>0,'created_at'=>now(),'updated_at'=>now()]); $inserted++;
        }
        return $this->ok(['members_saved'=>$inserted], 'Recipients saved. Consent is checked separately before sending.');
    }

    public function campaigns(Request $request)
    {
        $this->requireFeature($request, 'bulk_campaigns');
        return $this->ok(['campaigns'=>DB::table($this->table('whatsapp_campaigns'))->where('branch_id',0)->orderByDesc('id')->limit(100)->get()]);
    }


}
