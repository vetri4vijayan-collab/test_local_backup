<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Temporary migration bridge for the five legacy controllers that built Meta payloads inline.
 * The old payload supplies source values only. The admin workflow selects the real template and maps parameters.
 */
class WhatsAppLegacyDispatchService
{
    private function controllerKey(string $class): string
    {
        $name = strtolower(class_basename($class));
        if (strpos($name, 'managecustomer') !== false) return 'customer';
        if (strpos($name, 'manageleadappointment') !== false) return 'lead_appointment';
        if ($name === 'lead' || strpos($name, 'managepotentiallead') !== false) return 'lead';
        if ($name === 'events') return 'events';
        if ($name === 'cronjobs') return 'cronjob';
        return Str::slug($name, '_');
    }

    private function scalarValue(array $parameter, string $type): ?string
    {
        if (isset($parameter['text']) && is_scalar($parameter['text'])) return (string) $parameter['text'];
        foreach (['image', 'video', 'document', 'audio', 'sticker'] as $mediaType) {
            if (isset($parameter[$mediaType]) && is_array($parameter[$mediaType])) {
                $media = $parameter[$mediaType];
                return (string) ($media['link'] ?? $media['id'] ?? '');
            }
        }
        if (isset($parameter['payload']) && is_scalar($parameter['payload'])) return (string) $parameter['payload'];
        return null;
    }

    private function flattenComponents(array $components, string $templateName, string $language, string $phone): array
    {
        $variables = [
            'legacy_template_name' => $templateName,
            'legacy_language' => $language,
            'recipient_phone' => $phone,
        ];
        foreach ($components as $component) {
            if (!is_array($component)) continue;
            $type = strtolower((string) ($component['type'] ?? 'body'));
            $parameters = $component['parameters'] ?? [];
            if (!is_array($parameters)) continue;
            $buttonIndex = isset($component['index']) ? (int) $component['index'] : 0;
            foreach (array_values($parameters) as $index => $parameter) {
                if (!is_array($parameter)) continue;
                $paramType = strtolower((string) ($parameter['type'] ?? 'text'));
                $value = $this->scalarValue($parameter, $paramType);
                if ($value === null || $value === '') continue;
                if ($type === 'button') $key = 'button_' . $buttonIndex . '_' . ($index + 1);
                else $key = $type . '_' . ($index + 1);
                $variables[$key] = $value;
                if (in_array($paramType, ['image','video','document','audio','sticker'], true)) {
                    $variables[$type . '_' . $paramType] = $value;
                    $variables[$paramType . '_url'] = $value;
                }
            }
        }
        return $variables;
    }

    public function dispatch(string $controllerClass, string $callerMethod, array $payload): array
    {
        $type = strtolower((string) ($payload['type'] ?? ''));
        $template = $payload['template'] ?? null;
        if ($type !== 'template' || !is_array($template) || empty($template['name'])) {
            Log::warning('Legacy WhatsApp helper rejected a non-template payload; migrate this send site explicitly.', [
                'controller' => class_basename($controllerClass), 'method' => $callerMethod,
            ]);
            return ['status' => 422, 'error' => 'Legacy dispatch only supports template payloads; configure an Automation rule and migrate the sender.'];
        }
        $phone = trim((string) ($payload['to'] ?? ''));
        $oldTemplate = trim((string) $template['name']);
        $language = (string) ($template['language']['code'] ?? 'en');
        $category = $this->controllerKey($controllerClass);
        $method = Str::slug($callerMethod, '_');
        $templateSlug = Str::slug($oldTemplate, '_');
        $eventKey = 'legacy.' . $category . '.' . $method . '.' . $templateSlug;
        if (strlen($eventKey) > 100) {
            // Keep the database/route key within VARCHAR(100) without losing uniqueness for long method/template names.
            $suffix = '_' . substr(sha1($eventKey), 0, 10);
            $eventKey = rtrim(substr($eventKey, 0, 100 - strlen($suffix)), '._-') . $suffix;
        }
        $oldComponents = (array) ($template['components'] ?? []);
        $variables = $this->flattenComponents($oldComponents, $oldTemplate, $language, $phone);
        $needsParameterMap = false;
        foreach ($oldComponents as $oldComponent) {
            if (is_array($oldComponent) && !empty($oldComponent['parameters']) && is_array($oldComponent['parameters'])) {
                $needsParameterMap = true;
                break;
            }
        }

        try {
            $result = app(WhatsAppManagerService::class)->queueWorkflow([
                'branch_id' => 0,
                'event_key' => $eventKey,
                'to' => $phone,
                'variables' => $variables,
                'require_parameter_map' => $needsParameterMap,
                'source_type' => 'legacy.' . $category . '.' . $method,
                'created_by' => (int) (auth()->user()->user_id ?? auth()->id() ?? 0),
                'idempotency_key' => 'legacy:' . $eventKey . ':' . hash('sha256', $phone . '|' . json_encode($variables) . '|' . now()->format('YmdHi')),
            ]);
            if (!empty($result['ok'])) {
                return ['status' => 202, 'queued' => true, 'queue_status' => $result['status'] ?? 'queued', 'outbox_id' => $result['id'] ?? null, 'data' => []];
            }
            return ['status' => 422, 'queued' => false, 'queue_status' => $result['status'] ?? 'blocked', 'outbox_id' => $result['id'] ?? null, 'error' => 'Workflow was blocked: ' . ($result['reason'] ?? 'configure the required Automation rule.')];
        } catch (\Throwable $e) {
            Log::error('Legacy WhatsApp workflow adapter failed.', [
                'event_key' => $eventKey, 'controller' => class_basename($controllerClass),
                'outbox_status' => 'not_queued', 'exception' => class_basename($e),
            ]);
            return ['status' => 422, 'queued' => false, 'error' => 'WhatsApp workflow adapter failed; the source business operation should remain successful.'];
        }
    }
}
