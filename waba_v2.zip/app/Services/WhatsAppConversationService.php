<?php

namespace App\Services;

use App\Support\WhatsAppTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/** WABA-wide chat history with branch-filtered lead/customer lists from the CRM tables. */
class WhatsAppConversationService
{
    private function table(string $suffix): string { return WhatsAppTables::name($suffix); }
    private function digits(string $phone): string { return preg_replace('/\D+/', '', $phone); }

    public function normalizeE164(string $phone): string
    {
        $digits = $this->digits($phone);
        if (strlen($digits) === 10) {
            $country = preg_replace('/\D+/', '', (string) config('whatsapp.default_country_code', '91'));
            $digits = $country . $digits;
        }
        if (strlen($digits) < 8 || strlen($digits) > 15 || $digits[0] === '0') {
            throw new \InvalidArgumentException('Enter a phone number with country code, such as +919876543210.');
        }
        return '+' . $digits;
    }

    /** Contact/message store is global. The branch argument is retained for old call sites only. */
    public function getOrCreateContact(int $branchId, string $phone, ?string $displayName = null, string $kind = 'unknown', ?int $sourceId = null): object
    {
        $phoneE164 = $this->normalizeE164($phone);
        $table = $this->table('whatsapp_contacts');
        $contact = DB::table($table)->where('branch_id', 0)->where('phone_e164', $phoneE164)->first();
        if ($contact) {
            $update = ['updated_at' => now()];
            if ($displayName && trim($displayName) !== '') $update['display_name'] = mb_substr(trim($displayName), 0, 191);
            if (in_array($kind, ['lead', 'customer', 'common', 'unknown'], true) && $kind !== 'unknown') $update['contact_kind'] = $kind;
            if ($sourceId) $update['source_id'] = $sourceId;
            DB::table($table)->where('id', $contact->id)->update($update);
            return DB::table($table)->where('id', $contact->id)->first();
        }
        $id = DB::table($table)->insertGetId([
            'branch_id' => 0, 'phone_e164' => $phoneE164,
            'display_name' => mb_substr(trim((string) ($displayName ?: $phoneE164)), 0, 191),
            'contact_kind' => in_array($kind, ['lead', 'customer', 'common', 'unknown'], true) ? $kind : 'unknown',
            'source_id' => $sourceId, 'last_message_at' => null, 'last_message_preview' => null,
            'is_archived' => 0, 'created_at' => now(), 'updated_at' => now(),
        ]);
        return DB::table($table)->where('id', $id)->first();
    }

    private function safeIdentifier(string $value): string
    {
        if (!preg_match('/^[A-Za-z][A-Za-z0-9_]*$/', $value)) throw new \InvalidArgumentException('Invalid configured CRM identifier.');
        return $value;
    }

    /**
     * Query only one selected CRM module and always apply its branch filter.
     * When term is blank, this returns a recent contact page, not a full unbounded table scan.
     */
    public function searchCrmContacts(int $branchId, string $kind, string $term, int $limit = 40): array
    {
        if ($branchId < 1 || !in_array($kind, ['lead', 'customer'], true)) return [];
        $cfg = config('whatsapp.crm', []);
        $prefix = $kind === 'lead' ? 'lead_' : 'customer_';
        $table = $this->safeIdentifier((string) ($cfg[$prefix . 'table'] ?? ''));
        $idCol = $this->safeIdentifier((string) ($cfg[$prefix . 'id'] ?? 'sno'));
        $nameCol = $this->safeIdentifier((string) ($cfg[$prefix . 'name'] ?? ''));
        $phoneCol = $this->safeIdentifier((string) ($cfg[$prefix . 'phone'] ?? ''));
        $branchCol = $this->safeIdentifier((string) ($cfg[$prefix . 'branch'] ?? 'branch_id'));
        $statusCol = $this->safeIdentifier((string) ($cfg[$prefix . 'status'] ?? 'status'));
        try {
            $query = DB::table($table)->select([$idCol . ' as source_id', $nameCol . ' as display_name', $phoneCol . ' as crm_phone'])
                ->where($branchCol, $branchId)->whereNotNull($phoneCol)->where($phoneCol, '!=', '')
                ->orderByDesc($idCol)->limit(max(1, min(80, $limit)));
            if (trim($term) !== '') {
                $needle = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($term)) . '%';
                $query->where(function ($sub) use ($nameCol, $phoneCol, $needle) {
                    $sub->where($nameCol, 'like', $needle)->orWhere($phoneCol, 'like', $needle);
                });
            }
            if ($statusCol !== '') $query->where($statusCol, '!=', 2);
            $rows = $query->get();
            $result = [];
            foreach ($rows as $row) {
                try { $phone = $this->normalizeE164((string) $row->crm_phone); } catch (Throwable $e) { continue; }
                $chatContact = DB::table($this->table('whatsapp_contacts'))->where('branch_id', 0)->where('phone_e164', $phone)->first();
                $session = DB::table($this->table('whatsapp_sessions'))->where('branch_id', 0)->where('phone_e164', $phone)->first();
                $result[] = [
                    'contact_id' => $chatContact->id ?? null,
                    'phone_e164' => $phone,
                    'display_name' => (string) ($row->display_name ?: $phone),
                    'contact_kind' => $kind,
                    'source_id' => (int) $row->source_id,
                    'last_message_preview' => $chatContact->last_message_preview ?? 'Saved ERP contact · open conversation',
                    'last_message_at' => $chatContact->last_message_at ?? null,
                    'session_open' => $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24)),
                    'from_crm' => true,
                ];
            }
            return $result;
        } catch (Throwable $e) {
            Log::notice('WhatsApp CRM contact search unavailable for configured module.', ['kind' => $kind, 'exception' => class_basename($e)]);
            return [];
        }
    }

    /** Verify that a lead/customer chat belongs to the currently selected ERP branch. */
    public function isContactInBranch(int $branchId, string $kind, string $phone): bool
    {
        if ($branchId < 1 || !in_array($kind, ['lead', 'customer'], true)) return false;
        $cfg = config('whatsapp.crm', []);
        $prefix = $kind === 'lead' ? 'lead_' : 'customer_';
        $table = $this->safeIdentifier((string) ($cfg[$prefix . 'table'] ?? ''));
        $phoneCol = $this->safeIdentifier((string) ($cfg[$prefix . 'phone'] ?? ''));
        $branchCol = $this->safeIdentifier((string) ($cfg[$prefix . 'branch'] ?? 'branch_id'));
        $statusCol = $this->safeIdentifier((string) ($cfg[$prefix . 'status'] ?? 'status'));
        try {
            $normalized = $this->normalizeE164($phone);
            $digits = $this->digits($normalized);
            // Narrow by branch and trailing subscriber digits, then compare normalized full numbers.
            $query = DB::table($table)->select([$phoneCol . ' as crm_phone'])
                ->where($branchCol, $branchId)->where($phoneCol, 'like', '%' . substr($digits, -10))
                ->whereNotNull($phoneCol)->limit(80);
            if ($statusCol !== '') $query->where($statusCol, '!=', 2);
            foreach ($query->get() as $row) {
                try { if ($this->normalizeE164((string) $row->crm_phone) === $normalized) return true; }
                catch (Throwable $ignored) {}
            }
            return false;
        } catch (Throwable $e) {
            Log::notice('WhatsApp CRM branch contact validation failed.', ['kind' => $kind, 'exception' => class_basename($e)]);
            return false;
        }
    }

    public function storeInbound(int $branchId, string $phone, ?string $profileName, array $message, ?string $messageDateTime = null): void
    {
        $metaId = (string) ($message['id'] ?? '');
        if ($metaId === '') return;
        $type = strtolower((string) ($message['type'] ?? 'unknown'));
        $body = $this->extractBody($message, $type);
        $contact = $this->getOrCreateContact(0, $phone, $profileName, 'unknown');
        $at = $messageDateTime ?: now()->toDateTimeString();
        $values = [
            'branch_id' => 0, 'contact_id' => $contact->id, 'direction' => 'inbound', 'message_type' => $type,
            'body' => mb_substr($body, 0, 20000), 'media_id' => $message[$type]['id'] ?? null,
            'media_mime_type' => $message[$type]['mime_type'] ?? null, 'media_filename' => $message[$type]['filename'] ?? null,
            'meta_message_id' => $metaId, 'outbox_id' => null, 'template_name' => null, 'status' => 'received',
            'context_json' => json_encode($message, JSON_UNESCAPED_UNICODE), 'created_by' => null,
            'sent_at' => $at, 'delivered_at' => null, 'read_at' => null, 'failed_at' => null,
            'created_at' => now(), 'updated_at' => now(),
        ];
        DB::table($this->table('whatsapp_messages'))->insertOrIgnore($values);
        DB::table($this->table('whatsapp_contacts'))->where('id', $contact->id)->update([
            'last_message_at' => $at, 'last_message_preview' => mb_substr($body, 0, 255), 'updated_at' => now(),
        ]);
    }

    private function extractBody(array $message, string $type): string
    {
        if ($type === 'text') return (string) ($message['text']['body'] ?? '');
        if (in_array($type, ['button', 'interactive'], true)) return (string) ($message['button']['text'] ?? $message['interactive']['button_reply']['title'] ?? $message['interactive']['list_reply']['title'] ?? '[Interactive response]');
        if ($type === 'reaction') return (string) ($message['reaction']['emoji'] ?? '[Reaction]');
        if ($type === 'location') return '[Location] ' . ($message['location']['name'] ?? '') . ' ' . ($message['location']['address'] ?? '');
        if ($type === 'contacts') return '[Contact card]';
        if (in_array($type, ['image', 'video', 'audio', 'document', 'sticker'], true)) return (string) ($message[$type]['caption'] ?? '[' . ucfirst($type) . ' received]');
        return '[' . ucfirst($type) . ' message received]';
    }

    public function storeOutbound(object $outbox, string $messageId): void
    {
        $contact = $this->getOrCreateContact(0, (string) $outbox->phone_e164, null, 'unknown');
        $body = $outbox->message_type === 'text' ? (string) $outbox->text_body : '[' . ucfirst((string) $outbox->message_type) . '] ' . (string) ($outbox->template_name ?? '');
        DB::table($this->table('whatsapp_messages'))->insertOrIgnore([
            'branch_id' => 0, 'contact_id' => (int) $contact->id, 'direction' => 'outbound', 'message_type' => (string) $outbox->message_type,
            'body' => mb_substr($body, 0, 20000), 'media_id' => $outbox->uploaded_media_id ?? null, 'media_mime_type' => $outbox->media_mime_type ?? null, 'media_filename' => $outbox->media_filename ?? null,
            'meta_message_id' => $messageId, 'outbox_id' => (int) $outbox->id, 'template_name' => $outbox->template_name,
            'status' => 'sent', 'context_json' => null, 'created_by' => $outbox->created_by, 'sent_at' => now(),
            'delivered_at' => null, 'read_at' => null, 'failed_at' => null, 'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table($this->table('whatsapp_contacts'))->where('id', $contact->id)->update([
            'last_message_at' => now(), 'last_message_preview' => mb_substr($body, 0, 255), 'updated_at' => now(),
        ]);
    }

    public function updateStatusByMetaId(string $messageId, string $status, ?array $error = null): void
    {
        if (!in_array($status, ['sent', 'delivered', 'read', 'failed'], true)) return;
        $row = DB::table($this->table('whatsapp_messages'))->where('meta_message_id', $messageId)->first(['id', 'status']);
        if (!$row) return;
        $rank = ['queued' => 0, 'sent' => 1, 'delivered' => 2, 'read' => 3, 'received' => 3, 'failed' => 4];
        if ($status !== 'failed' && ($rank[$status] ?? 0) < ($rank[$row->status] ?? 0)) return;
        $data = ['status' => $status, 'updated_at' => now()];
        if ($status === 'delivered') $data['delivered_at'] = now();
        if ($status === 'read') $data['read_at'] = now();
        if ($status === 'failed') { $data['failed_at'] = now(); $data['context_json'] = json_encode(['errors' => $error ?: []], JSON_UNESCAPED_UNICODE); }
        DB::table($this->table('whatsapp_messages'))->where('id', $row->id)->update($data);
    }

    public function conversationFor(int $branchId, string $phone, string $kind = 'common', ?string $displayName = null): array
    {
        $e164 = $this->normalizeE164($phone);
        $contact = $this->getOrCreateContact(0, $e164, $displayName, $kind);
        $messages = DB::table($this->table('whatsapp_messages'))->where('branch_id', 0)->where('contact_id', $contact->id)
            ->orderByDesc('id')->limit(200)->get()->reverse()->values();
        $session = DB::table($this->table('whatsapp_sessions'))->where('branch_id', 0)->where('phone_e164', $e164)->first();
        $open = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        return ['contact' => $contact, 'messages' => $messages, 'session_open' => (bool) $open, 'last_inbound_at' => $session->last_inbound_at ?? null];
    }

    public function listConversations(int $branchId, string $kind = 'all', string $term = ''): array
    {
        if (in_array($kind, ['lead', 'customer'], true)) return $this->searchCrmContacts($branchId, $kind, $term, (int) config('whatsapp.conversation_page_size', 80));
        $q = DB::table($this->table('whatsapp_contacts'))->where('branch_id', 0)->where('is_archived', 0)->orderByDesc('last_message_at');
        if ($kind === 'common') $q->whereIn('contact_kind', ['common', 'unknown']);
        if (trim($term) !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($term)) . '%';
            $q->where(function ($sub) use ($like) { $sub->where('phone_e164', 'like', $like)->orWhere('display_name', 'like', $like); });
        }
        $rows = $q->limit((int) config('whatsapp.conversation_page_size', 80))->get();
        foreach ($rows as $row) {
            $session = DB::table($this->table('whatsapp_sessions'))->where('branch_id', 0)->where('phone_e164', $row->phone_e164)->first();
            $row->session_open = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
            $row->from_crm = false;
        }
        return $rows->all();
    }
}
