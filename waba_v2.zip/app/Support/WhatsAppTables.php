<?php

namespace App\Support;

/** Resolve all new WhatsApp table names from one validated prefix. */
final class WhatsAppTables
{
    public static function name(string $suffix): string
    {
        $prefix = (string) config('whatsapp.table_prefix', 'za_');
        if (!preg_match('/^[A-Za-z0-9_]*$/', $prefix) || !preg_match('/^[A-Za-z0-9_]+$/', $suffix)) {
            throw new \InvalidArgumentException('Invalid WhatsApp database table prefix/name configuration.');
        }
        return $prefix . $suffix;
    }
}
