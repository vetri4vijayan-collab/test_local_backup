<?php

$adminIdsRaw = (string) env('WHATSAPP_ADMIN_USER_IDS', '');
$adminIdsRaw = preg_replace('/[^0-9,]/', '', $adminIdsRaw);

return [
    'api_version' => env('WHATSAPP_GRAPH_API_VERSION', 'v26.0'),
    'verify_token' => env('WHATSAPP_VERIFY_TOKEN'),
    'app_secret' => env('META_APP_SECRET'),
    // Retained only for the Events controller's unrelated URL-shortener integration; configure/rotate separately.
    'shortener_api_token' => env('CHOTTA_LINK_API_TOKEN'),
    'table_prefix' => env('WHATSAPP_TABLE_PREFIX', 'za_'),
    // Fail closed: configure comma-separated authenticated ERP user_id values in .env.
    'admin_user_ids' => array_values(array_filter(array_map('trim', explode(',', $adminIdsRaw)))),
    'default_country_code' => env('WHATSAPP_DEFAULT_COUNTRY_CODE', '91'),
    'default_header_image_url' => env('WHATSAPP_DEFAULT_HEADER_IMAGE_URL', ''),
    'public_media_base_url' => env('WHATSAPP_PUBLIC_MEDIA_BASE_URL', env('APP_URL', '')),
    'bulk_max_recipients' => max(1, min(500, (int) env('WHATSAPP_BULK_MAX_RECIPIENTS', 250))),
    'default_bulk_pacing_seconds' => max(5, min(60, (int) env('WHATSAPP_BULK_PACING_SECONDS', 10))),
    'max_template_sync_pages' => max(1, min(50, (int) env('WHATSAPP_TEMPLATE_SYNC_MAX_PAGES', 20))),
    'conversation_page_size' => max(25, min(150, (int) env('WHATSAPP_CONVERSATION_PAGE_SIZE', 80))),
    'crm' => [
        'lead_table' => env('WHATSAPP_LEAD_TABLE', 'za_lead'),
        'lead_id' => env('WHATSAPP_LEAD_ID_COLUMN', 'sno'),
        'lead_name' => env('WHATSAPP_LEAD_NAME_COLUMN', 'lead_name'),
        'lead_phone' => env('WHATSAPP_LEAD_PHONE_COLUMN', 'lead_mobile'),
        'lead_branch' => env('WHATSAPP_LEAD_BRANCH_COLUMN', 'branch_id'),
        'lead_status' => env('WHATSAPP_LEAD_STATUS_COLUMN', 'status'),
        'customer_table' => env('WHATSAPP_CUSTOMER_TABLE', 'za_customer'),
        'customer_id' => env('WHATSAPP_CUSTOMER_ID_COLUMN', 'sno'),
        'customer_name' => env('WHATSAPP_CUSTOMER_NAME_COLUMN', 'cus_name'),
        'customer_phone' => env('WHATSAPP_CUSTOMER_PHONE_COLUMN', 'cus_mobile'),
        'customer_branch' => env('WHATSAPP_CUSTOMER_BRANCH_COLUMN', 'branch_id'),
        'customer_status' => env('WHATSAPP_CUSTOMER_STATUS_COLUMN', 'status'),
    ],
    'default_features' => [
        'lead_chat' => true,
        'customer_chat' => true,
        'common_chat' => true,
        'custom_group_chat' => true,
        'broadcast_channel' => true,
        'bulk_campaigns' => true,
        // Calling is shown separately but remains disabled until account eligibility/integration is confirmed.
        'calling' => false,
    ],
];
