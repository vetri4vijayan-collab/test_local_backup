# EAPL WhatsApp Management — shared Meta profile overlay

This is an **overlay patch** for the uploaded EAPL ERP source. It is not a full WhatsApp Web clone and has not been run against the live production database or Meta account. Install on a staging clone first.

## Design changes

- **One shared Meta profile:** configuration, WABA/phone ID, encrypted access token, template registry, workflow rules, campaigns, outbox, consent and conversation history are stored with `branch_id = 0` as the ERP-global sentinel. The application no longer expects a separate Meta access token per branch.
- **Branch filtering only for CRM pickers:** Lead Chat queries `za_lead` with the selected `branch_id`; Customer Chat queries `za_customer` with that branch. Before opening/sending from these tabs, the server validates that the number belongs to the selected CRM branch. Common Chat can create/start a conversation with a new number.
- **Dynamic legacy send bridge:** the active Customer, Lead, Lead Appointment, Events and Cronjobs controller send helpers pass the old payload's values to `WhatsAppLegacyDispatchService`, which constructs an event key such as `legacy.customer.method_name.old_template_name`. The admin rule selects the actual approved Meta template and parameter mapping. Old template literals are not used as an API send command by the bridge.
- **Chat coverage:** text with emojis; reactions; image, video, audio, document and WebP-sticker attachments; contact cards; location; supported interactive buttons; Flow message initiation; inbound/outbound history; signed webhook receipts; mark-as-read; safe media download proxy; 24-hour window checks. Sending media, text, reaction, location and interactive messages is blocked outside the 24-hour customer-service window; use a template to initiate messaging outside that window.
- **Calling:** the feature is gated off by default. A button/page is not an implementation of call setup, signaling, lifecycle events or media. Enable only after a separate integration is verified as available for the Business Account/phone number. Native WhatsApp groups and Channels publishing are not represented as available just because Cloud API is enabled.

## File map

- `app/Services/WhatsAppManagerService.php` — shared configuration, approved templates, workflow rule resolution, outbox, Cloud API sends, receipts, consent and pacing.
- `app/Services/WhatsAppConversationService.php` — global thread history and branch-scoped CRM contact search/validation.
- `app/Services/WhatsAppLegacyDispatchService.php` — compatibility bridge for static template sends in the five active controller areas.
- `app/Http/Controllers/WhatsAppManagementController.php` — protected admin UI and AJAX APIs.
- `app/Http/Controllers/MetaWhatsAppWebhookController.php` — public Meta callback: GET challenge + POST HMAC verification.
- `app/Http/Controllers/WhatsAppWebhookController.php` — compatibility redirects for older chat URLs/API names.
- `app/Http/Controllers/customer/ManageCustomer.php`
- `app/Http/Controllers/sales/lead/Lead.php`
- `app/Http/Controllers/sales/lead_appointment/ManageLeadAppointment.php`
- `app/Http/Controllers/placements_events/Events.php`
- `app/Http/Controllers/dashboard/Cronjobs.php`
- `resources/views/content/whatsapp_management/` — menu-wise admin frontend.
- `resources/menu/verticalMenu.json` — WhatsApp menu directly after Monitoring Tools.
- `routes/web.php` — new management routes and public signed webhook callback.
- `database/whatsapp_management_upgrade.sql` — additive schema.
- `database/za_whatsapp_shared_profile_upgrade.sql` — consolidates existing branch config/history into the shared ERP profile and disables sends pending review.
- `database/za_whatsapp_legacy_import.sql` — idempotent import from `za_wb_contacts` / `za_wb_messages`, retaining source IDs and leaving legacy tables intact.
- `.env.whatsapp.example` — placeholders only; no production secrets.

## Deployment steps (staging first)

1. Back up both application code and the `eapl` database. Diff each controller replacement against the live version before copying; these controller files are large and deployments may have changed after the uploaded archive was made.
2. Apply `database/whatsapp_management_upgrade.sql` once. It creates only `za_whatsapp_*` management tables.
3. If legacy `za_wb_*` data has not been imported yet, run `database/za_whatsapp_shared_profile_upgrade.sql` then `database/za_whatsapp_legacy_import.sql`. If you already imported the legacy history, still run the shared-profile migration; it consolidates profiles and conversation rows and disables old templates/rules for review. The legacy import uses `legacy_source_table` + `legacy_source_id` to avoid importing the same row twice.
4. Verify source DB says MariaDB 10.4/MySQL 8 compatible. The import uses MariaDB 10.4 `REGEXP_REPLACE`, and the profile migration uses temporary tables and information_schema dynamic `ALTER TABLE`; run only after backup and test the SQL on a restored copy before production.
5. Merge `.env.whatsapp.example` values into the real `.env`; never replace the whole file. Keep exactly one setting for `WHATSAPP_VERIFY_TOKEN`, `META_APP_SECRET`, `WHATSAPP_ADMIN_USER_IDS` and `WHATSAPP_TABLE_PREFIX`. Configure admin IDs as comma-separated numbers (e.g. `123,456` (replace with actual ERP admin IDs)), not PHP array syntax. Confirm CRM table/column names.
6. Remove the prior `/webhook_whatsapp` route from inside authenticated route groups if one remains. The current `routes/web.php` routes `/webhook_whatsapp`, `/meta_whatsapp_callback`, and the legacy `/test_webhook` alias to the same public signature-verifying controller; management pages remain inside `auth:web`/`timezone`. Update Meta to the canonical `/webhook_whatsapp` URL and remove old aliases after validating the cutover. Keep `webhook_whatsapp` in the existing CSRF exception list only; do not disable CSRF globally. The webhook still verifies `X-Hub-Signature-256` using `META_APP_SECRET`.
7. After copying config/routes, run `php artisan config:clear`, `php artisan route:clear`, `php artisan view:clear`, then (if used) rebuild config cache. Verify `php artisan route:list --path=wa-management` and inspect all routes for duplicates.
8. Configure a durable queue backend and supervised worker in production; do not use `QUEUE_CONNECTION=sync` for paced campaigns. The outbox worker uses `queue=whatsapp`, with one attempt after an ambiguous send result to avoid duplicate messages.
9. Visit `/wa-management/setup`, save the single global WABA ID, phone-number ID, API version and system-user token (stored with Laravel encryption), test the credentials, sync templates, then enable only approved templates deliberately. The shared-profile SQL intentionally sets sending disabled/global kill switch ON.
10. Configure Meta's HTTPS callback to `/webhook_whatsapp` and subscribe to `messages` webhook events. Test GET verification and signed POST receipts using Meta's test tools.
11. For each event, create an Automation rule with the exact event key seen in Message Logs when a legacy attempt is blocked. Static template sends use `legacy.<controller>.<caller_method>.<legacy_template_slug>`; examples are in the controller inventory below. Select an approved template, match its exact component order, add the parameter source map, and test with a consented internal recipient.
12. Gradually pilot. Inspect queued/sent/delivered/read/failed counts, `unknown` network outcomes, Meta account quality, template quality and opt-out receipts before increasing message volume.

## Automation rules for the five controller areas

The bridge captures scalar values from the old template payload, but admins must choose the final Meta-approved template and mapping. It builds variable names such as `body_1`, `header_1`, `image_url`, `video_url`, `document_url`, and `button_0_1`, plus `legacy_template_name`, `legacy_language`, and `recipient_phone`. Use the exact `workflow_event_key` shown in Message Logs to create the rule. A missing/mismatched rule blocks the message and logs the reason; it does not use a silent static-template fallback.

For new integrations, call `WhatsAppManagerService::queueWorkflow()` from a CRM transaction *after it commits*, passing an explicit `event_key`, recipient in E.164, a map of scalar variables, `source_type`, `source_id`, and a stable `idempotency_key`. Configure the mapping on the Automation page. For example:

```php
$result = app(\App\Services\WhatsAppManagerService::class)->queueWorkflow([
    'branch_id' => 0,
    'event_key' => 'academy.event_certificate',
    'to' => '+919876543210',
    'variables' => [
        'student_name' => (string) $student->student_name,
        'event_name' => (string) $event->event_name,
        'certificate_url' => (string) $publicHttpsCertificateUrl,
    ],
    'source_type' => 'academy.event_certificate',
    'source_id' => (int) $certificate->id,
    'created_by' => (int) (auth()->user()->user_id ?? 0),
    'idempotency_key' => 'academy.event_certificate:' . (int) $certificate->id,
]);
```

Example parameter map for a two-text-variable body:

```json
[{"type":"body","parameters":[{"type":"text","source":"student_name"},{"type":"text","source":"event_name"}]}]
```

The mapping must exactly match the template approved on Meta. Missing variables, non-HTTPS header media URLs, consent failures, missing template approvals and global pauses should block and log the send, not fail the CRM transaction.

## Chat feature boundaries

Supported in this overlay: text, emoji insertion, reactions (to a message in the same conversation only), images/video/audio/documents/sticker uploads, location, interactive button payloads and initiating a configured/published WhatsApp Flow. Inbound media metadata and outbound uploaded-media IDs are stored; a secure media proxy retrieves Meta media after authorization. Provider/account message limits and media format/size constraints still apply.

Not in this overlay: a pixel-identical WhatsApp Web client, native consumer group management, Channels publishing, end-to-end voice/video calling, recording/transcription, or complete Flow designer/data-exchange backend. Those require separate Meta endpoints, eligibility and event handlers; the Calling menu is hidden by default. Do not advertise these as live just because a UI switch exists.

## Security notes

- The `.env` file uploaded for analysis exposed active-looking third-party secrets (including Meta credentials). **Rotate/revoke these secrets immediately** in the relevant provider consoles, then remove duplicate placeholder env lines. Never include `.env` in this ZIP or source control.
- The EAPL Events controller also contained a hard-coded URL-shortener credential; this overlay moves it to `CHOTTA_LINK_API_TOKEN`. Rotate that separate provider credential too if the shortener is used. Ensure `APP_ENV=production`, `APP_DEBUG=false`, a durable queue connection, HTTPS `APP_URL`, secure server-side file storage, a stable `APP_KEY`, least-privilege Meta system user, verified webhook, and restricted admin IDs.
- A phone in an ERP table is not evidence of WhatsApp opt-in. Import consent only where real evidence exists; monitor STOP/unsubscribe handling, template quality, service-window rules and failures. Meta can restrict an app, WABA, phone number, business or template; no code can guarantee otherwise.

## Validation limits

PHP syntax, JavaScript syntax, menu JSON and schema/table-name consistency are checked in the package build. No live DB was modified; no Meta API call or production send was performed. Full Laravel boot, Blade compilation, queue worker, actual webhook signatures, MariaDB migration execution and end-to-end media/Flows tests must pass on the target staging server before production rollout.
