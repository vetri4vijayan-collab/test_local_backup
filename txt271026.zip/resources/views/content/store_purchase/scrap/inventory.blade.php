@extends('layouts/layoutMaster')

@section('title', 'Scrap inventory')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])


@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])


@section('content')

<div class="container-fluid ">

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div class="d-flex align-items-center gap-3">

                    <div class="scrap-header-icon">
                        <i class="mdi mdi-cube-outline"></i>
                    </div>

                    <div>
                        <h5 class="fw-bold text-dark mb-0" style="font-size:16px;">
                            Store &amp; Purchase Management System
                        </h5>
                        <p class="text-muted mb-0" style="font-size:12.5px;">
                            Fully automated material procurement lifecycle.
                        </p>
                    </div>

                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <button type="button"
                            class="scrap-tab-arrow"
                            id="scrapTabScrollLeft"
                            aria-label="Scroll tabs left">
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <div class="scrap-tabs-scroller">
                        <div class="scrap-tabs-track" id="scrapTabsTrack">

                            <a href="{{ route('store-purchase.scrap-management') }}"
                               class="scrap-tab-pill {{ request()->routeIs('store-purchase.scrap-management') ? 'active' : '' }}">
                               Scrap Inventory Registry
                            </a>

                            <a href="{{ route('store-purchase.scrap-disposal') }}"
                               class="scrap-tab-pill {{ request()->routeIs('store-purchase.scrap-disposal') ? 'active' : '' }}">
                               Disposal Sales & Gate Passes
                            </a>

                        </div>
                    </div>

                    <button type="button"
                            class="scrap-tab-arrow"
                            id="scrapTabScrollRight"
                            aria-label="Scroll tabs right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <button type="button"
                            class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1 px-3 ms-2"
                            style="height:38px;white-space:nowrap;"
                            data-bs-toggle="modal"
                            data-bs-target="#logScrapMaterialModal">

                        <i class="mdi mdi-plus"></i>
                        <span>Log Scrap Material Entry</span>
                    </button>

                </div>

            </div>

        </div>
    </div>


    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Total Scrap Valuation in Stock
                    </span>
                    <span class="d-block fw-bold text-dark" style="font-size:22px;">
                        ₹6.96 <span style="font-size:16px;">Lakhs</span>
                    </span>
                    <span class="d-block text-secondary small mt-1">
                        Ready for auction tendering
                    </span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Steel Scrap Reserve
                    </span>
                    <span class="d-block fw-bold text-dark" style="font-size:22px;">
                        18.5 <span style="font-size:16px;">MT</span>
                    </span>
                    <span class="d-block text-secondary small mt-1">
                        @ ~₹34,000 / MT market rate
                    </span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Cleared Disposal Revenue
                    </span>
                    <span class="d-block fw-bold" style="font-size:22px;color:#1a8a4d;">
                        ₹4.46 <span style="font-size:16px;">Lakhs</span>
                    </span>
                    <span class="d-block small mt-1" style="color:#1a8a4d;">
                        100% payments received
                    </span>
                </div>
            </div>
        </div>

    </div>


    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4 pb-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h6 class="fw-bold mb-1 text-uppercase" style="font-size:13px;letter-spacing:.04em;">
                        Scrap &amp; Residual Material Master
                    </h6>
                    <p class="text-muted small mb-0">
                        Track cut reinforcement steel, shuttering wood scrap and replaced equipment parts
                    </p>
                </div>
                <span class="scrap-records-badge">
                    4 Records Listed
                </span>
            </div>
        </div>


        <div class="scrap-filter-bar">

            <div class="scrap-filter-item scrap-filter-search">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="mdi mdi-magnify text-muted"></i>
                    </span>
                    <input type="text"
                           class="form-control border-start-0"
                           id="scrapSearchInput"
                           placeholder="Search scrap ref, item, site...">
                </div>
            </div>

            <div class="scrap-filter-item">
                <select class="form-select form-select-sm" id="scrapProjectFilter">
                    <option value="">All Projects</option>
                    <option value="MMRP SITE">MMRP SITE</option>
                    <option value="NTRP SITE">NTRP SITE</option>
                    <option value="MAIN WARE HOUSE STORE">MAIN WARE HOUSE STORE</option>
                    <option value="Solar Equipment Store">Solar Equipment Store</option>
                </select>
            </div>

            <div class="scrap-filter-item">
                <select class="form-select form-select-sm" id="scrapCategoryFilter">
                    <option value="">All Categories</option>
                    <option value="Steel Scrap">Steel Scrap</option>
                    <option value="Wooden Shuttering">Wooden Shuttering</option>
                    <option value="Bitumen Drums">Bitumen Drums</option>
                    <option value="Used Machinery Parts">Used Machinery Parts</option>
                </select>
            </div>

            <div class="scrap-filter-item">
                <select class="form-select form-select-sm" id="scrapSiteFilter">
                    <option value="">All Sites</option>
                    <option value="NH Highway Roadwork Sector A">NH Highway Roadwork Sector A</option>
                    <option value="Flyover Pier Construction Yard">Flyover Pier Construction Yard</option>
                    <option value="Villupuram Maintenance Bay">Villupuram Maintenance Bay</option>
                </select>
            </div>
        </div>


        <div class="table-responsive">
            <table class="table scrap-table mb-0" id="scrapTable">

                <thead>
                    <tr>
                        <th class="text-start">Scrap Ref &amp; Category</th>
                        <th class="text-start">Project Name</th>
                        <th class="text-start">Item Description</th>
                        <th class="text-start">Originating Site</th>
                        <th class="text-start">Quantity</th>
                        <th class="text-end">Est. Unit Rate (₹)</th>
                        <th class="text-end">Total Valuation</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>

                <tbody>

                    <tr class="scrap-row"
                        data-project="MMRP SITE"
                        data-category="Steel Scrap"
                        data-site="NH Highway Roadwork Sector A">
                        <td>
                            <div class="scrap-ref">SCR-2026-001</div>
                            <div class="scrap-cat">Steel Scrap</div>
                        </td>

                        <td>
                            <span class="scrap-desc">MMRP SITE</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Cut TMT Reinforcement Steel Ends (8mm - 25mm)</span>
                        </td>
                        <td>
                            <span class="scrap-site">NH Highway Roadwork Sector A</span>
                        </td>
                        <td>
                            <span class="scrap-qty">18.5 MT</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-rate">₹34,000 / MT</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-value">₹629,000</span>
                        </td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="scrap-row"
                        data-project="NTRP SITE"
                        data-category="Wooden Shuttering"
                        data-site="Flyover Pier Construction Yard">
                        <td>
                            <div class="scrap-ref">SCR-2026-002</div>
                            <div class="scrap-cat">Wooden Shuttering</div>
                        </td>

                         <td>
                            <span class="scrap-desc">NTRP SITE</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Damaged Plywood &amp; Timber Centering Runners</span>
                        </td>
                        <td>
                            <span class="scrap-site">Flyover Pier Construction Yard</span>
                        </td>
                        <td>
                            <span class="scrap-qty">450 Pcs</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-rate">₹150 / Pcs</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-value">₹67,500</span>
                        </td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="scrap-row"
                        data-project="MAIN WARE HOUSE STORE"
                        data-category="Bitumen Drums"
                        data-site="NH Highway Roadwork Sector A">
                        <td>
                            <div class="scrap-ref">SCR-2026-003</div>
                            <div class="scrap-cat">Bitumen Drums</div>
                        </td>

                        <td>
                            <span class="scrap-desc">MAIN WARE HOUSE STORE</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Empty Steel Bitumen Drums 200L</span>
                        </td>
                        <td>
                            <span class="scrap-site">NH Highway Roadwork Sector A</span>
                        </td>
                        <td>
                            <span class="scrap-qty">320 Drums</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-rate">₹450 / Drums</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-value">₹144,000</span>
                        </td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr class="scrap-row"
                        data-project="Solar Equipment Store"
                        data-category="Used Machinery Parts"
                        data-site="Villupuram Maintenance Bay">
                        <td>
                            <div class="scrap-ref">SCR-2026-004</div>
                            <div class="scrap-cat">Used Machinery Parts</div>
                        </td>

                         <td>
                            <span class="scrap-desc">Solar Equipment Store</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Worn Excavator Bucket Teeth &amp; Hydraulic Hoses</span>
                        </td>
                        <td>
                            <span class="scrap-site">Villupuram Maintenance Bay</span>
                        </td>
                        <td>
                            <span class="scrap-qty">1,200 KG</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-rate">₹32 / KG</span>
                        </td>
                        <td class="text-end">
                            <span class="scrap-value">₹38,400</span>
                        </td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr id="scrapNoResults" style="display:none;">
                        <td colspan="8" class="text-center text-muted py-4">
                            No scrap records match the selected filters.
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>


    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 small text-muted">
        <span>SRK INFRA DEVELOPERS ERP v8.4 | SECURED LOCAL CACHE</span>
        <span>
            SYSTEM TIME:
            <span id="scrapSystemTime"></span>
            | UTC -07:00
        </span>
    </div>

</div>


<div class="modal fade" id="logScrapMaterialModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-3 border-0 shadow-lg">

            <div class="modal-header bg-primary text-white">
                <div>
                    <h5 class="modal-title fw-bold mb-1 text-white">
                        Log Scrap Material Entry
                    </h5>
                    <p class="text-white mb-0" style="font-size:11px;opacity:.9;">
                        Record new scrap item into the residual material master
                    </p>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body px-3 py-3">
                <form id="logScrapMaterialForm">
                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Scrap Category *</label>
                            <select class="form-select form-select-sm">
                                <option>Steel Scrap</option>
                                <option>Wooden Shuttering</option>
                                <option>Bitumen Drums</option>
                                <option>Used Machinery Parts</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Originating Site *</label>
                            <select class="form-select form-select-sm">
                                <option>NH Highway Roadwork Sector A</option>
                                <option>Flyover Pier Construction Yard</option>
                                <option>Villupuram Maintenance Bay</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold small">Item Description *</label>
                            <input type="text" class="form-control form-control-sm"
                                   placeholder="e.g. Cut TMT Reinforcement Steel Ends">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Quantity *</label>
                            <input type="number" class="form-control form-control-sm" value="0" step="0.01">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Unit *</label>
                            <select class="form-select form-select-sm">
                                <option>MT</option>
                                <option>Pcs</option>
                                <option>Drums</option>
                                <option>KG</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Est. Unit Rate (₹) *</label>
                            <input type="number" class="form-control form-control-sm" value="0" step="0.01">
                        </div>

                    </div>
                </form>
            </div>

            <div class="modal-footer border-0 pt-0 px-3 pb-3">
                <button type="button" class="btn btn-light btn-sm px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-sm px-4">
                    <i class="mdi mdi-plus me-1"></i> Log Scrap Material
                </button>
            </div>

        </div>
    </div>
</div>



<style>

.scrap-header-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #e8eef5;
    color: #16659E;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.scrap-header-icon i {
    font-size: 24px;
    line-height: 1;
}

.scrap-tab-arrow {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #8a97a8;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
    transition: all .15s ease;
}

.scrap-tab-arrow:hover {
    background: #f8f9fa;
    color: #16659E;
    border-color: #16659E;
}

.scrap-tab-arrow i {
    font-size: 18px;
    line-height: 1;
}

.scrap-tabs-scroller {
    overflow: hidden;
    max-width: 100%;
    min-width: 0;
}

.scrap-tabs-track {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.scrap-tabs-track::-webkit-scrollbar {
    display: none;
}

.scrap-tab-pill {
    white-space: nowrap;
    padding: 8px 20px;
    border-radius: 50px;
    background: #eef1f4;
    color: #566a7f;
    font-size: .85rem;
    font-weight: 600;
    text-decoration: none;
    transition: all .2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 38px;
    flex-shrink: 0;
    border: 0;
}

.scrap-tab-pill:hover {
    background: #e2e6ea;
    color: #16659E;
    text-decoration: none;
}

.scrap-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.scrap-tab-pill.active:hover {
    background: #124f7c;
    color: #fff;
}

.scrap-records-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 14px;
    border-radius: 8px;
    background: #eef1f4;
    color: #566a7f;
    font-size: 11.5px;
    font-weight: 600;
    white-space: nowrap;
}

.scrap-filter-bar {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    padding: 12px 24px;
    background: #f7f8fa;
    border-top: 1px solid #eef0f4;
    border-bottom: 1px solid #eef0f4;
}

.scrap-filter-item {
    flex: 1 1 180px;
    min-width: 160px;
}

.scrap-filter-search {
    flex: 2 1 260px;
    min-width: 220px;
}

.scrap-filter-bar .form-select-sm,
.scrap-filter-bar .form-control,
.scrap-filter-bar .input-group-sm .form-control,
.scrap-filter-bar .input-group-sm .input-group-text {
    height: 34px;
    font-size: 12.5px;
    border-radius: 7px;
}

.scrap-filter-bar .input-group-sm .input-group-text {
    border-right: 0;
}

.scrap-filter-bar .input-group-sm .form-control {
    border-left: 0;
}

.scrap-table {
    table-layout: auto;
    width: 100% !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    font-size: 12px;
}

.scrap-table thead th {
    background: #ffffff;
    color: #566a7f;
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    padding: 14px 24px;
    border-top: 1px solid #eef0f4;
    border-bottom: 1px solid #eef0f4;
    white-space: nowrap;
}

.scrap-table tbody td {
    padding: 18px 24px;
    vertical-align: middle;
    border-bottom: 1px solid #eef0f4;
    background: #ffffff;
    white-space: nowrap;
}

.scrap-table tbody tr:last-child td {
    border-bottom: 0;
}

.scrap-table tbody tr:hover td {
    background: #fbfdff;
}

.scrap-ref {
    display: block;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 500;
    line-height: 15px;
    white-space: nowrap;
}

.scrap-cat {
    display: block;
    margin-top: 4px;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    line-height: 16px;
    white-space: nowrap;
}

.scrap-desc {
    display: inline-block;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    line-height: 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
    vertical-align: middle;
}

.scrap-site {
    display: inline-block;
    color: #334155;
    font-size: 12px;
    font-weight: 500;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
    vertical-align: middle;
}

.scrap-qty {
    display: inline-block;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    white-space: nowrap;
}

.scrap-rate {
    display: inline-block;
    color: #334155;
    font-size: 12px;
    font-weight: 500;
    font-family: 'Courier New', monospace;
    white-space: nowrap;
}

.scrap-value {
    display: inline-block;
    color: #1a8a4d;
    font-size: 13px;
    font-weight: 800;
    font-family: 'Courier New', monospace;
    white-space: nowrap;
}

.scrap-action-buttons {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 14px;
}

.scrap-action-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    margin: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    background: transparent;
    cursor: pointer;
    font-size: 20px;
    line-height: 1;
    transition: all .15s ease;
}

.scrap-view {
    color: #1565c0;
}

.scrap-view:hover {
    color: #0d47a1;
    transform: scale(1.15);
}

.scrap-edit {
    color: #2563eb;
}

.scrap-edit:hover {
    color: #1d4ed8;
    transform: scale(1.15);
}

.scrap-delete {
    color: #94a3b8;
}

.scrap-delete:hover {
    color: #dc2626;
    transform: scale(1.15);
}

@media (max-width: 992px) {

    .scrap-table {
        min-width: 1000px;
    }

    .scrap-tabs-scroller {
        max-width: 100%;
    }

    .scrap-tabs-track {
        max-width: 100%;
    }
}

@media (max-width: 768px) {

    .scrap-filter-bar {
        padding: 12px 16px;
    }

    .scrap-filter-item,
    .scrap-filter-search {
        flex: 1 1 100%;
        min-width: 0;
    }
}

@media (max-width: 576px) {

    .scrap-table thead th,
    .scrap-table tbody td {
        padding: 14px 16px;
    }
}

</style>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('scrapTabsTrack');
    const leftBtn = document.getElementById('scrapTabScrollLeft');
    const rightBtn = document.getElementById('scrapTabScrollRight');

    if (track && leftBtn) {
        leftBtn.addEventListener('click', function () {
            track.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (track && rightBtn) {
        rightBtn.addEventListener('click', function () {
            track.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }

    const timeEl = document.getElementById('scrapSystemTime');

    function updateTime() {
        if (!timeEl) return;
        const now = new Date();

        const y  = now.getFullYear();
        const m  = String(now.getMonth() + 1).padStart(2, '0');
        const d  = String(now.getDate()).padStart(2, '0');
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');

        timeEl.textContent = y + '-' + m + '-' + d + ' | ' + hh + ':' + mm;
    }

    updateTime();
    setInterval(updateTime, 60000);


    const searchInput    = document.getElementById('scrapSearchInput');
    const projectFilter  = document.getElementById('scrapProjectFilter');
    const categoryFilter = document.getElementById('scrapCategoryFilter');
    const siteFilter     = document.getElementById('scrapSiteFilter');
    const rows           = document.querySelectorAll('#scrapTable tbody .scrap-row');
    const noResultsRow   = document.getElementById('scrapNoResults');

    function applyScrapFilter() {
        const search   = (searchInput?.value || '').toLowerCase().trim();
        const project  = (projectFilter?.value || '').toLowerCase().trim();
        const category = (categoryFilter?.value || '').toLowerCase().trim();
        const site     = (siteFilter?.value || '').toLowerCase().trim();

        let visible = 0;

        rows.forEach(function (row) {
            const rowProject  = (row.getAttribute('data-project')  || '').toLowerCase();
            const rowCategory = (row.getAttribute('data-category') || '').toLowerCase();
            const rowSite     = (row.getAttribute('data-site')     || '').toLowerCase();
            const rowText     = row.innerText.toLowerCase();

            const match =
                (search   === '' || rowText.includes(search)) &&
                (project  === '' || rowProject === project) &&
                (category === '' || rowCategory === category) &&
                (site     === '' || rowSite === site);

            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });

        if (noResultsRow) {
            noResultsRow.style.display = (visible === 0) ? '' : 'none';
        }
    }

    if (searchInput)    searchInput.addEventListener('input', applyScrapFilter);
    if (projectFilter)  projectFilter.addEventListener('change', applyScrapFilter);
    if (categoryFilter) categoryFilter.addEventListener('change', applyScrapFilter);
    if (siteFilter)     siteFilter.addEventListener('change', applyScrapFilter);


    document.querySelectorAll('.scrap-view').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            const ref = row.querySelector('.scrap-ref')?.innerText.trim() || '';
            const cat = row.querySelector('.scrap-cat')?.innerText.trim() || '';
            const desc = row.querySelector('.scrap-desc')?.innerText.trim() || '';

            const projectCell = row.querySelectorAll('.scrap-desc')[0]?.innerText.trim() || '';
            const site = row.querySelector('.scrap-site')?.innerText.trim() || 'MMRP SITE';

            const params = new URLSearchParams({
                site: projectCell || site || 'MMRP SITE',
                desc: desc || cat || ref
            });

            window.location.href = "{{ route('store-purchase.scrap-material-view') }}?" + params.toString();
        });
    });

    document.querySelectorAll('.scrap-edit').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            const ref = row.querySelector('.scrap-ref')?.innerText.trim() || '';
            alert('Edit scrap item: ' + ref);
        });
    });

    document.querySelectorAll('.scrap-delete').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            const ref = row.querySelector('.scrap-ref')?.innerText.trim() || 'this item';

            if (confirm('Are you sure you want to delete ' + ref + '?')) {
                row.remove();
                applyScrapFilter();
            }
        });
    });

});
</script>

@endsection