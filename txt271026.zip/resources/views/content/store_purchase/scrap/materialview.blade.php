@extends('layouts/layoutMaster')

@section('title', 'Material View')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="container-fluid py-3">

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex align-items-center flex-wrap gap-3">

                <div class="d-flex align-items-center gap-3">

             <a href="{{ url()->previous() }}"
                   class="btn btn-primary border btn-sm d-inline-flex align-items-center gap-1 px-3"
                   style="height:38px;">
                    <i class="mdi mdi-arrow-left"></i>
                    <span>Back</span>
                </a>
</div>
                    
                    <div>
                        <h5 class="fw-bold text-dark mb-0" style="font-size:16px;" id="mvPageTitle">
                            Material Info — MMRP SITE
                        </h5>
                        <p class="text-muted mb-0" style="font-size:12.5px;">
                            Vendor-wise weight &amp; quantity ledger
                        </p>
                    
</div>
                </div>

            </div>

        </div>
    </div>


    <div class="card shadow-sm border-0 rounded-3 mb-3">

        <div class="mv-site-panel">
            <div class="mv-site-title">
                CONTRACTOR WISE SCRAP DETAILS - <span id="mvSiteName">MMRP SITE</span>
            </div>
            <div class="mv-site-search">
                <label for="mvSearchInput">Search:</label>
                <input type="text"
                       id="mvSearchInput"
                       class="mv-search-input"
                       autocomplete="off">
            </div>
        </div>

        <div class="material-view-wrapper">
            <table class="table material-view-table mb-0">
                <thead>
                    <tr id="materialViewHeaderRow">
                        <th class="mv-th-material">Material Info</th>
                        <th class="mv-th-vendor">AquaLine Plumbing Works</th>
                        <th class="mv-th-vendor">PowerGrid Electrical Services</th>
                        <th class="mv-th-vendor">Sadhan Ray</th>
                        <th class="mv-th-vendor">Rabiul Aowal</th>
                        <th class="mv-th-vendor">Ranjan Barman</th>
                        <th class="mv-th-vendor">Manga Singh</th>
                        <th class="mv-th-vendor">Jeya Shri Baliaji Constructions</th>
                        <th class="mv-th-vendor">Pappu Kumar Chauhan</th>
                        <th class="mv-th-vendor">Diwakar Enterprises</th>
                        <th class="mv-th-total">Total</th>
                        <th class="mv-th-dispose">Dispose</th>
                        <th class="mv-th-remaining">Remaining</th>
                    </tr>
                </thead>
                <tbody id="materialViewBody">
                </tbody>
            </table>
        </div>

    </div>


    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 small text-muted">
        <span>SRK INFRA DEVELOPERS ERP v8.4 | SECURED LOCAL CACHE</span>
        <span>
            SYSTEM TIME:
            <span id="scrapSystemTime"></span>
            | UTC -07:00
        </span>
    </div>

</div>


<style>

.mv-page-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #e8eef5;
    color: #16659E;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.mv-page-icon i {
    font-size: 24px;
    line-height: 1;
}

.mv-site-panel {
    background: #f7f8fa;
    border-bottom: 1px solid #dfe3e8;
    padding: 14px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    flex-wrap: wrap;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}

.mv-site-title {
    color: #566a7f;
    font-size: 12.5px;
    font-weight: 600;
    letter-spacing: .04em;
    text-transform: uppercase;
    white-space: nowrap;
}

.mv-site-search {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    color: #334155;
}

.mv-site-search label {
    margin: 0;
    font-weight: 500;
}

.mv-search-input {
    height: 30px;
    padding: 3px 10px;
    border: 1px solid #cfd6dd;
    border-radius: 4px;
    background: #ffffff;
    font-size: 12px;
    outline: none;
    min-width: 200px;
}

.mv-search-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .12);
}

.material-view-wrapper {
    width: 100%;
    max-height: 72vh;
    overflow: auto;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
}

/* ===== Borderless / no side-margin table style (matches reference image) ===== */

.material-view-table {
    width: 100%;
    min-width: 1400px;
    border-collapse: collapse;
    font-size: 12px;
    background: #ffffff;
}

.material-view-table thead th {
    background: #ffffff;
    color: #566a7f;
    font-size: 11.5px;
    font-weight: 700;
    text-align: left;
    vertical-align: middle;
    padding: 14px 20px 14px 0;
    border: none;
    border-bottom: 1px solid #e2e6ea;
    white-space: normal;
    line-height: 1.3;
    text-transform: uppercase;
    letter-spacing: .02em;
}

.material-view-table thead th:first-child {
    padding-left: 20px;
}

.material-view-table thead th.mv-th-material {
    text-align: left;
    width: 190px;
    min-width: 190px;
    position: sticky;
    left: 0;
    z-index: 3;
    background: #ffffff;
}

.material-view-table thead th.mv-th-vendor {
    min-width: 120px;
    background: #ffffff;
}

.material-view-table thead th.mv-th-total,
.material-view-table thead th.mv-th-dispose,
.material-view-table thead th.mv-th-remaining {
    min-width: 110px;
    background: #ffffff;
}

.material-view-table tbody td {
    padding: 16px 20px 16px 0;
    border: none;
    border-bottom: 1px solid #eef1f4;
    vertical-align: middle;
    text-align: left;
    background: #ffffff;
    color: #111827;
    font-size: 12px;
    white-space: nowrap;
}

.material-view-table tbody td:first-child {
    padding-left: 20px;
}

.material-view-table tbody td.mv-td-material {
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 2;
    background: #ffffff;
    vertical-align: top;
}

.material-view-table tbody tr:hover td {
    background: #fbfdff;
}

.material-view-table tbody tr:hover td.mv-td-material {
    background: #fbfdff;
}

.mv-material-code {
    display: block;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 500;
    line-height: 14px;
    white-space: nowrap;
}

.mv-material-name {
    display: block;
    margin-top: 4px;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    line-height: 16px;
    white-space: normal;
    word-break: break-word;
}

.mv-material-spec {
    display: block;
    margin-top: 4px;
    color: #334155;
    font-size: 11.5px;
    font-weight: 500;
    line-height: 15px;
    white-space: nowrap;
}

.mv-material-unit {
    display: block;
    margin-top: 2px;
    color: #64748b;
    font-size: 11px;
    font-weight: 500;
    line-height: 14px;
    white-space: nowrap;
}

.mv-wgt {
    display: block;
    color: #334155;
    font-size: 11.5px;
    font-weight: 500;
    line-height: 15px;
    white-space: nowrap;
}

.mv-qty {
    display: block;
    margin-top: 2px;
    color: #334155;
    font-size: 11.5px;
    font-weight: 500;
    line-height: 15px;
    white-space: nowrap;
}

.mv-num {
    display: inline-block;
    color: #111827;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
}

@media (max-width: 576px) {

    .material-view-table thead th,
    .material-view-table tbody td {
        padding: 12px 12px 12px 0;
    }

    .material-view-table thead th:first-child,
    .material-view-table tbody td:first-child {
        padding-left: 12px;
    }
}

</style>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const timeEl = document.getElementById('scrapSystemTime');

    function updateTime() {
        if (!timeEl) return;
        const now = new Date();

        const y  = now.getFullYear();
        const m  = String(now.getMonth() + 1).padStart(2, '0');
        const d  = String(now.getDate()).padStart(2, '0');
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');

        timeEl.textContent = y + '-' + m + '-' + d + ' | ' + hh + ':' + mm;
    }

    updateTime();
    setInterval(updateTime, 60000);


    const urlParams = new URLSearchParams(window.location.search);
    const siteParam = urlParams.get('site');
    const descParam = urlParams.get('desc');

    if (siteParam) {
        const siteNameEl = document.getElementById('mvSiteName');
        if (siteNameEl) siteNameEl.textContent = siteParam.toUpperCase();
    }

    if (descParam) {
        const pageTitle = document.getElementById('mvPageTitle');
        if (pageTitle) pageTitle.textContent = 'Material Info — ' + descParam;
    }


    const VENDORS = [
        'AquaLine Plumbing Works',
        'PowerGrid Electrical Services',
        'Sadhan Ray',
        'Rabiul Aowal',
        'Ranjan Barman',
        'Manga Singh',
        'Jeya Shri Baliaji Constructions',
        'Pappu Kumar Chauhan',
        'Diwakar Enterprises'
    ];

    const MATERIALS = [
        {
            code: 'ALM1424-76042100',
            name: 'Aluminium Section Channel',
            spec: '6000-50-25',
            unit: 'Kgs.',
            weights:    [12, 0, 5, 0, 10, 0, 7, 0, 3],
            quantities: [3, 0, 1, 0, 2, 0, 2, 0, 1],
            dispose: 8,
            remaining: 52
        },
        {
            code: 'CMT1428-25232930',
            name: 'Birla OPC 53 Grade Cement',
            spec: '600-400-120',
            unit: 'Bag',
            weights:    [50, 0, 10, 0, 30, 0, 20, 0, 15],
            quantities: [25, 0, 5, 0, 15, 0, 10, 0, 8],
            dispose: 30,
            remaining: 165
        },
        {
            code: 'COM1407-8471',
            name: 'Keyboard',
            spec: '0-0-0',
            unit: 'Nos.',
            weights:    [2, 0, 0, 0, 1, 0, 0, 0, 0],
            quantities: [2, 0, 0, 0, 1, 0, 0, 0, 0],
            dispose: 1,
            remaining: 5
        },
        {
            code: 'ALM1424-76042101',
            name: 'MS Square Pipe',
            spec: '6000-40-40',
            unit: 'Kgs.',
            weights:    [20, 0, 8, 0, 12, 0, 9, 0, 6],
            quantities: [5, 0, 2, 0, 3, 0, 2, 0, 2],
            dispose: 10,
            remaining: 72
        }
    ];

    function buildMaterialRows(materialList) {
        const tbody = document.getElementById('materialViewBody');
        if (!tbody) return;

        let html = '';

        materialList.forEach(function (m) {
            html += '<tr>';

            html +=
                '<td class="mv-td-material">' +
                    '<span class="mv-material-code">' + m.code + '</span>' +
                    '<span class="mv-material-name">' + m.name + '</span>' +
                    '<span class="mv-material-spec">' + m.spec + '</span>' +
                    '<span class="mv-material-unit">' + m.unit + '</span>' +
                '</td>';

            let totalWgt = 0;
            let totalQty = 0;

            VENDORS.forEach(function (vendor, idx) {
                const wgt = (m.weights && m.weights[idx] !== undefined) ? m.weights[idx] : 0;
                const qty = (m.quantities && m.quantities[idx] !== undefined) ? m.quantities[idx] : 0;

                totalWgt += wgt;
                totalQty += qty;

                html +=
                    '<td>' +
                        '<span class="mv-wgt">Wgt - ' + wgt + '</span>' +
                        '<span class="mv-qty">Qty - ' + qty + '</span>' +
                    '</td>';
            });

            html +=
                '<td>' +
                    '<span class="mv-wgt">Wgt - ' + totalWgt + '</span>' +
                    '<span class="mv-qty">Qty - ' + totalQty + '</span>' +
                '</td>';

            html += '<td><span class="mv-num">' + (m.dispose || 0) + '</span></td>';
            html += '<td><span class="mv-num">' + (m.remaining || 0) + '</span></td>';

            html += '</tr>';
        });

        tbody.innerHTML = html;
    }

    buildMaterialRows(MATERIALS);


    const mvSearch = document.getElementById('mvSearchInput');

    if (mvSearch) {
        mvSearch.addEventListener('input', function () {
            const term = this.value.toLowerCase().trim();
            const rows = document.querySelectorAll('#materialViewBody tr');

            rows.forEach(function (row) {
                const text = row.innerText.toLowerCase();
                row.style.display = (term === '' || text.includes(term)) ? '' : 'none';
            });
        });
    }

});
</script>

@endsection