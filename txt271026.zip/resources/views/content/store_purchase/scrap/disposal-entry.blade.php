@extends('layouts/layoutMaster')

@section('title', 'Scrap Entry Disposal')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])



@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])



@section('content')

<div class="container-fluid py-3">

    <div class="mb-3">
        <a href="{{ route('store-purchase.scrap-disposal') }}"
           class="btn btn-sm btn-light border d-inline-flex align-items-center gap-1">
            <i class="mdi mdi-chevron-left"></i>
            <span>Back</span>
        </a>
    </div>

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <h5 class="fw-bold text-secondary text-uppercase mb-3"
                style="font-size:13px;letter-spacing:.05em;">
                Scrap Disposal
            </h5>

            <div class="row g-3 align-items-end mb-4">

                <div class="col-12 col-md-4 col-lg-3">
                    <label class="form-label fw-semibold small mb-1">
                        Location<span class="text-danger">*</span>
                    </label>

                    <select class="form-select form-select-sm" id="sdLocation">
                        <option value="">Select Location</option>
                        <option value="MMRP SITE">MMRP SITE</option>
                        <option value="NTRP SITE">NTRP SITE</option>
                        <option value="MAIN WARE HOUSE STORE">MAIN WARE HOUSE STORE</option>
                        <option value="Solar Equipment Store">Solar Equipment Store</option>
                        <option value="FLYOVER STORE">FLYOVER STORE</option>
                    </select>
                </div>

                <div class="col-12 col-md-auto">
                    <button type="button"
                            class="btn btn-primary btn-sm px-3"
                            id="sdGoBtn">
                        Go
                    </button>
                </div>

                <div class="col-12 col-md-auto ms-md-auto">
                    <div class="d-flex align-items-center gap-2">
                        <label for="sdSearch" class="mb-0 small text-muted">Search:</label>
                        <input type="text"
                               id="sdSearch"
                               class="form-control form-control-sm"
                               style="width:180px;"
                               autocomplete="off">
                    </div>
                </div>

            </div>

            <div class="table-responsive">

                <table class="table sd-table mb-0" id="sdTable">

                    <thead>
                        <tr>
                            <th class="text-center" style="width:60px;">S.no</th>
                            <th>Material Info</th>
                            <th class="text-center" style="width:100px;">Scrap in Store</th>
                            <th class="text-center" style="width:130px;">Dispose Scrap Value</th>
                            <th class="text-center" style="width:90px;">Balance</th>
                            <th class="text-center" style="width:90px;">Scrap (qty)</th>
                            <th class="text-center" style="width:120px;">Dispose Scrap (qty)</th>
                            <th class="text-center" style="width:100px;">Balance (qty)</th>
                            <th class="text-center" style="width:110px;">Dispose Rate</th>
                            <th class="text-center" style="width:120px;">Dispose Amount</th>
                            <th class="text-center" style="width:180px;">Description</th>
                        </tr>
                    </thead>

                    <tbody id="sdTableBody">
                    </tbody>

                </table>

            </div>

            <!-- <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3 small text-muted">

                <div class="d-flex align-items-center gap-2">
                    <span>Show</span>
                    <select id="sdPageSize" class="form-select form-select-sm" style="width:70px;">
                        <option value="25" selected>25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span>entries</span>
                </div>

                <div>
                    <span id="sdEntriesInfo">1 - 3 of 3 entries</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <button type="button" class="btn btn-sm btn-light border" id="sdPrevBtn">Previous</button>
                    <button type="button" class="btn btn-sm btn-light border fw-bold" id="sdPageBtn">1</button>
                    <button type="button" class="btn btn-sm btn-light border" id="sdNextBtn">Next</button>
                </div>

            </div> -->

            <div class="d-flex justify-content-end gap-2 mt-3">
                <a href="{{ route('store-purchase.scrap-disposal') }}"
                   class="btn btn-sm btn-light border px-4">
                    Cancel
                </a>

                <button type="button"
                        class="btn btn-primary btn-sm px-4"
                        id="sdDisposeBtn">
                    Dispose Scrap
                </button>
            </div>

        </div>
    </div>

</div>


<style>

.sd-table {
    width: 100% !important;
    border-collapse: collapse !important;
    font-size: 12px;
}

.sd-table thead th {
    background: #ffffff;
    color: #333;
    font-size: 11.5px;
    font-weight: 700;
    text-align: left;
    padding: 12px 10px;
    border: 1px solid #d9dee3;
    white-space: normal;
    line-height: 1.3;
    vertical-align: middle;
}

.sd-table thead th.text-center {
    text-align: center;
}

.sd-table tbody td {
    padding: 10px;
    border: 1px solid #d9dee3;
    vertical-align: middle;
    color: #111827;
    font-size: 12px;
    background: #ffffff;
}

.sd-sno {
    text-align: center;
    font-weight: 600;
}

.sd-material-code {
    display: block;
    color: #111827;
    font-size: 12px;
    font-weight: 700;
    line-height: 15px;
    white-space: nowrap;
}

.sd-material-name {
    display: block;
    margin-top: 3px;
    color: #111827;
    font-size: 12px;
    font-weight: 700;
    line-height: 15px;
    white-space: normal;
    word-break: break-word;
}

.sd-material-spec {
    display: block;
    margin-top: 3px;
    color: #334155;
    font-size: 11.5px;
    font-weight: 500;
    line-height: 14px;
}

.sd-num {
    text-align: center;
    font-weight: 600;
    color: #111827;
}

.sd-input {
    width: 100%;
    height: 34px;
    padding: 4px 8px;
    border: 1px solid #cfd6dd;
    border-radius: 4px;
    font-size: 12px;
    text-align: center;
    outline: none;
    background: #ffffff;
}

.sd-input:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .15);
}

.sd-input.is-invalid {
    border-color: #dc2626 !important;
    background: #fef2f2 !important;
    box-shadow: 0 0 0 2px rgba(220, 38, 38, .12) !important;
}

.sd-input[readonly] {
    background: #f4f6f9;
    cursor: not-allowed;
}

.sd-desc {
    width: 100%;
    min-height: 38px;
    padding: 5px 8px;
    border: 1px solid #cfd6dd;
    border-radius: 4px;
    font-size: 12px;
    outline: none;
    resize: vertical;
    background: #ffffff;
}

.sd-desc:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, .15);
}

@media (max-width: 992px) {

    .sd-table {
        min-width: 1100px;
    }
}

</style>


<script>

    const urlParams  = new URLSearchParams(window.location.search);
const editGpNo   = urlParams.get('edit') || '';
const isEditMode = editGpNo !== '';

const disposeBtn = document.getElementById('sdDisposeBtn');

if (isEditMode && disposeBtn) {
    disposeBtn.textContent = 'Update Disposal Scrap';

    /* Optionally pre-fill location and rows from localStorage */
    try {
        const queue = JSON.parse(localStorage.getItem('scrap_disposal_queue_v1') || '[]');
        const found = queue.find(it => it.gpNo === editGpNo);
        if (found) {
            const locSel = document.getElementById('sdLocation');
            if (locSel) locSel.value = found.location;
        }
    } catch (e) {}
}
document.addEventListener('DOMContentLoaded', function () {

    const DISPOSAL_STORAGE_KEY = 'scrap_disposal_queue_v1';

    const MATERIALS = [
        {
            code: 'ALM1424-76042100',
            name: 'Aluminium Section Channel',
            spec: '6000-50-25',
            scrapInStore: 2,
            scrapValue: 0,
            scrapQty: 5
        },
        {
            code: 'CMT1428-25232930',
            name: 'Birla OPC 53 Grade Cement',
            spec: '600-400-120',
            scrapInStore: 0,
            scrapValue: 0,
            scrapQty: 2
        },
        {
            code: 'CPR1426-74081100',
            name: 'Copper Wire 4 sqmm',
            spec: '1000-5-5',
            scrapInStore: 50,
            scrapValue: 0,
            scrapQty: 10
        }
    ];

    const tbody       = document.getElementById('sdTableBody');
    const searchInput = document.getElementById('sdSearch');
    const entriesInfo = document.getElementById('sdEntriesInfo');

    function buildRows(list) {
        if (!tbody) return;

        let html = '';

        list.forEach(function (m, idx) {
            html += '<tr data-code="' + m.code + '">';

            html += '<td class="sd-sno">' + (idx + 1) + '</td>';

            html +=
                '<td>' +
                    '<span class="sd-material-code">' + m.code + '</span>' +
                    '<span class="sd-material-name">' + m.name + '</span>' +
                    '<span class="sd-material-spec">' + m.spec + '</span>' +
                '</td>';

            html += '<td class="sd-num sd-store">' + m.scrapInStore + '</td>';

            html +=
                '<td>' +
                    '<input type="number" min="0" step="0.01" ' +
                           'class="sd-input sd-dispose-value" value="' + m.scrapValue + '">' +
                '</td>';

            html += '<td class="sd-num sd-balance">0</td>';

            html += '<td class="sd-num sd-scrap-qty">' + m.scrapQty + '</td>';

            html +=
                '<td>' +
                    '<input type="number" min="0" step="0.01" ' +
                           'class="sd-input sd-dispose-qty" value="0">' +
                '</td>';

            html += '<td class="sd-num sd-balance-qty">' + m.scrapQty + '</td>';

            html +=
                '<td>' +
                    '<input type="number" min="0" step="0.01" ' +
                           'class="sd-input sd-dispose-rate" value="0">' +
                '</td>';

            html += '<td class="sd-num sd-dispose-amount">0</td>';

            html += '<td><textarea class="sd-desc" rows="2"></textarea></td>';

            html += '</tr>';
        });

        tbody.innerHTML = html;

        bindRowInputs();
    }

    function bindRowInputs() {
        document.querySelectorAll('#sdTableBody tr').forEach(function (row) {

            const disposeValueInput = row.querySelector('.sd-dispose-value');
            const balanceCell       = row.querySelector('.sd-balance');
            const scrapQtyCell      = row.querySelector('.sd-scrap-qty');
            const disposeQtyInput   = row.querySelector('.sd-dispose-qty');
            const balanceQtyCell    = row.querySelector('.sd-balance-qty');
            const disposeRateInput  = row.querySelector('.sd-dispose-rate');
            const disposeAmountCell = row.querySelector('.sd-dispose-amount');

            function recalc() {
                const dispValue = parseFloat(disposeValueInput?.value) || 0;
                if (balanceCell) balanceCell.textContent = dispValue;

                const scrapQty = parseFloat(scrapQtyCell?.textContent) || 0;

                let disposeQty = parseFloat(disposeQtyInput?.value);
                if (isNaN(disposeQty)) disposeQty = 0;

                const effectiveQty = disposeQty > 0 ? disposeQty : scrapQty;

                const balanceQty = scrapQty - disposeQty;
                if (balanceQtyCell) balanceQtyCell.textContent = balanceQty;

                const disposeRate   = parseFloat(disposeRateInput?.value) || 0;
                const disposeAmount = effectiveQty * disposeRate;
                if (disposeAmountCell) {
                    disposeAmountCell.textContent = disposeAmount.toLocaleString('en-IN');
                }

                if (disposeQty > scrapQty) {
                    if (disposeQtyInput) {
                        disposeQtyInput.classList.add('is-invalid');
                        disposeQtyInput.title =
                            'Dispose Qty cannot exceed Scrap Qty (' + scrapQty + ')';
                    }
                } else {
                    if (disposeQtyInput) {
                        disposeQtyInput.classList.remove('is-invalid');
                        disposeQtyInput.title = '';
                    }
                }
            }

            if (disposeValueInput) {
                disposeValueInput.addEventListener('input',  recalc);
                disposeValueInput.addEventListener('change', recalc);
            }

            if (disposeQtyInput) {
                disposeQtyInput.addEventListener('input',  recalc);
                disposeQtyInput.addEventListener('change', recalc);
            }

            if (disposeRateInput) {
                disposeRateInput.addEventListener('input',  recalc);
                disposeRateInput.addEventListener('change', recalc);
            }

            recalc();
        });
    }

    function applySearch() {
        const term = (searchInput?.value || '').toLowerCase().trim();
        const rows = document.querySelectorAll('#sdTableBody tr');

        let visible = 0;

        rows.forEach(function (row) {
            const text = row.innerText.toLowerCase();
            const match = term === '' || text.includes(term);
            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });

        if (entriesInfo) {
            entriesInfo.textContent =
                '1 - ' + visible + ' of ' + visible + ' entries';
        }
    }

    if (searchInput) searchInput.addEventListener('input', applySearch);

    const goBtn = document.getElementById('sdGoBtn');
    if (goBtn) {
        goBtn.addEventListener('click', function () {
            const loc = document.getElementById('sdLocation');
            if (!loc || loc.value === '') {
                alert('Please select a Location.');
                loc?.focus();
                return;
            }
            buildRows(MATERIALS);
            applySearch();
        });
    }

    const disposeBtn = document.getElementById('sdDisposeBtn');
    if (disposeBtn) {
        disposeBtn.addEventListener('click', function () {

            const loc = document.getElementById('sdLocation');
            if (!loc || loc.value === '') {
                alert('Please select a Location.');
                loc?.focus();
                return;
            }

            const rows = document.querySelectorAll('#sdTableBody tr');
            let validCount = 0;
            let hasError   = false;

            rows.forEach(function (row) {
                const scrapQty    = parseFloat(row.querySelector('.sd-scrap-qty')?.textContent) || 0;
                const disposeQty  = parseFloat(row.querySelector('.sd-dispose-qty')?.value)      || 0;
                const disposeRate = parseFloat(row.querySelector('.sd-dispose-rate')?.value)     || 0;

                if (disposeQty > scrapQty) hasError = true;
                if (disposeQty > 0 && disposeRate > 0) validCount++;
            });

            if (hasError) {
                alert('Some rows have Dispose Qty greater than Scrap Qty. Please correct them.');
                return;
            }

            if (validCount === 0) {
                alert('Please enter Dispose Scrap (qty) and Dispose Rate for at least one material.');
                return;
            }

            const items = [];
            let totalValue = 0;

            rows.forEach(function (row) {
                const code        = row.dataset.code;
                const scrapQty    = parseFloat(row.querySelector('.sd-scrap-qty')?.textContent) || 0;
                const disposeQty  = parseFloat(row.querySelector('.sd-dispose-qty')?.value)      || 0;
                const disposeRate = parseFloat(row.querySelector('.sd-dispose-rate')?.value)     || 0;
                const desc        = row.querySelector('.sd-desc')?.value || '';

                const effectiveQty = disposeQty > 0 ? disposeQty : scrapQty;

                if (effectiveQty > 0 && disposeRate > 0) {
                    const amount = effectiveQty * disposeRate;
                    totalValue += amount;

                    items.push({
                        code:        code,
                        disposeQty:  effectiveQty,
                        disposeRate: disposeRate,
                        amount:      amount,
                        description: desc
                    });
                }
            });

            let queue = [];
            try {
                queue = JSON.parse(localStorage.getItem(DISPOSAL_STORAGE_KEY) || '[]');
            } catch (e) {
                queue = [];
            }

            const nextNum = queue.length > 0
                ? (parseInt(queue[queue.length - 1].gpNo.replace(/\D/g, ''), 10) + 1)
                : 1;

            const gpNo = 'GP-2026-' + String(nextNum).padStart(3, '0');

            const now = new Date();
            const y   = now.getFullYear();
            const m   = String(now.getMonth() + 1).padStart(2, '0');
            const d   = String(now.getDate()).padStart(2, '0');
            const gpDate = y + '-' + m + '-' + d;

            queue.push({
                gpNo:        gpNo,
                gpDate:      gpDate,
                scrapRef:    items.length ? items[0].code : '-',
                location:    loc.value,
                requestedBy: 'Admin',
                totalValue:  totalValue,
                status:      'Awaiting Approval',
                items:       items
            });

            localStorage.setItem(DISPOSAL_STORAGE_KEY, JSON.stringify(queue));

            alert('Scrap Disposal saved successfully.');

            window.location.href = "{{ route('store-purchase.scrap-disposal') }}";
        });
    }

    buildRows(MATERIALS);
    applySearch();

});
</script>

@endsection