@extends('layouts/layoutMaster')

@section('title', 'Disposal Sales & Gate Passes')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])


@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])


@section('content')

<div class="container-fluid ">

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div class="d-flex align-items-center gap-3">

                    <div class="scrap-header-icon">
                        <i class="mdi mdi-cube-outline"></i>
                    </div>

                    <div>
                        <h5 class="fw-bold text-dark mb-0" style="font-size:16px;">
                            Store &amp; Purchase Management System
                        </h5>
                        <p class="text-muted mb-0" style="font-size:12.5px;">
                            Fully automated material procurement lifecycle.
                        </p>
                    </div>

                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <button type="button"
                            class="scrap-tab-arrow"
                            id="scrapTabScrollLeft"
                            aria-label="Scroll tabs left">
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <div class="scrap-tabs-scroller">
                        <div class="scrap-tabs-track" id="scrapTabsTrack">

                            <a href="{{ route('store-purchase.scrap-management') }}"
                               class="scrap-tab-pill {{ request()->routeIs('store-purchase.scrap-management') ? 'active' : '' }}">
                               Scrap Inventory Registry
                            </a>

                            <a href="{{ route('store-purchase.scrap-disposal') }}"
                               class="scrap-tab-pill {{ request()->routeIs('store-purchase.scrap-disposal') ? 'active' : '' }}">
                               Disposal Sales & Gate Passes
                            </a>

                        </div>
                    </div>

                    <button type="button"
                            class="scrap-tab-arrow"
                            id="scrapTabScrollRight"
                            aria-label="Scroll tabs right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <a href="{{ route('store-purchase.scrap-disposal-entry') }}"
                       class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1 px-3 ms-2"
                       style="height:38px;white-space:nowrap;">

                        <i class="mdi mdi-plus"></i>
                        <span>Dispose new scrap</span>
                    </a>

                </div>

            </div>

        </div>
    </div>


    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Total Disposal Sales Value
                    </span>
                    <span class="d-block fw-bold text-dark" style="font-size:22px;">
                        ₹4.46 <span style="font-size:16px;">Lakhs</span>
                    </span>
                    <span class="d-block text-secondary small mt-1">
                        Cleared payments received
                    </span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Gate Passes Issued
                    </span>
                    <span class="d-block fw-bold text-dark" style="font-size:22px;">
                        6 <span style="font-size:16px;">Passes</span>
                    </span>
                    <span class="d-block text-secondary small mt-1">
                        Approved &amp; dispatched
                    </span>
                </div>
            </div>
        </div>

       <div class="col-12 col-md-4">
            <div class="card shadow-sm border-0 rounded-3 h-100">
                <div class="card-body p-3">
                    <span class="d-block text-uppercase fw-bold text-secondary small mb-2"
                          style="letter-spacing:.05em;font-size:10px;">
                        Cleared Disposal Revenue
                    </span>
                    <span class="d-block fw-bold" style="font-size:22px;color:#1a8a4d;">
                        ₹4.46 <span style="font-size:16px;">Lakhs</span>
                    </span>
                    <span class="d-block small mt-1" style="color:#1a8a4d;">
                        100% payments received
                    </span>
                </div>
            </div>
        </div>

    </div>


    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4 pb-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h6 class="fw-bold mb-1 text-uppercase" style="font-size:13px;letter-spacing:.04em;">
                        Disposal Sales &amp; Gate Passes
                    </h6>
                    <p class="text-muted small mb-0">
                        Track scrap disposal sales, gate pass issuance, and cleared payments
                    </p>
                </div>
                <span class="scrap-records-badge" id="disposalCountBadge">
                    4 Records Listed
                </span>
            </div>
        </div>

        {{-- ===================== FILTER SECTION ===================== --}}
        <div class="px-3 px-md-4 pb-3">
            <div class="row g-2 align-items-end">

                <div class="col-12 col-sm-6 col-md-4">
                    <label for="fltSearch" class="form-label small text-muted mb-1">Search</label>
                    <input type="text"
                           id="fltSearch"
                           class="form-control form-control-sm"
                           placeholder="GP no, scrap ref, location…"
                           autocomplete="off">
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                    <label for="fltLocation" class="form-label small text-muted mb-1">Location</label>
                    <select id="fltLocation" class="form-select form-select-sm">
                        <option value="">All Locations</option>
                        <option value="FLYOVER STORE">FLYOVER STORE</option>
                        <option value="Solar Equipment Store">Solar Equipment Store</option>
                        <option value="Chennai Industrial Traders">Chennai Industrial Traders</option>
                    </select>
                </div>

                <div class="col-12 col-sm-6 col-md-4">
                    <label for="fltStatus" class="form-label small text-muted mb-1">Status</label>
                    <select id="fltStatus" class="form-select form-select-sm">
                        <option value="">All Status</option>
                        <option value="Approved">Approved</option>
                        <option value="Awaiting Approval">Awaiting Approval</option>
                        <!-- <option value="Pending">Pending</option>
                        <option value="Rejected">Rejected</option> -->
                    </select>
                </div>

                <!-- <div class="col-12 col-sm-6 col-md-3 d-flex gap-2">
                    <button type="button" class="btn btn-primary btn-sm flex-fill" id="fltApplyBtn">
                        <i class="mdi mdi-filter-outline me-1"></i> Filter
                    </button>
                    <button type="button" class="btn btn-light border btn-sm flex-fill" id="fltResetBtn">
                        <i class="mdi mdi-refresh me-1"></i> Reset
                    </button>
                </div> -->

            </div>
        </div>
        {{-- =================== /FILTER SECTION ====================== --}}

        <div class="table-responsive">
            <table class="table scrap-table mb-0" id="disposalTable">

                <thead>
                    <tr>
                        <th class="text-start">Gate Pass &amp; Date</th>
                        <th class="text-start">Scrap Ref</th>
                        <th class="text-start">Location</th>
                        <th class="text-start">Requested by</th>
                        <th class="text-end">Total Value</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>

                <tbody id="disposalTableBody">

                    {{-- GP-2026-001 — Approved --}}
                    <tr class="scrap-row" data-gp-no="GP-2026-001" data-status="Approved">
                        <td>
                            <div class="scrap-ref">GP-2026-001</div>
                            <div class="scrap-cat">2026-07-15</div>
                        </td>
                        <td>
                            <span class="scrap-desc">SCR-2026-001</span>
                        </td>
                        <td>
                            <span class="scrap-desc">FLYOVER STORE</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Admin</span>
                        </td>
                       
                        <td class="text-end">
                            <span class="scrap-value">₹360,000</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#effff8;color:#008f68;border:1px solid #8be1c1;font-size:11px;font-weight:600;">
                                Approved
                            </span>
                        </td>
                    
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-approve" title="Approve">
                                    <i class="mdi mdi-check-circle-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- GP-2026-002 --}}
                    <tr class="scrap-row" data-gp-no="GP-2026-002" data-status="Approved">
                        <td>
                            <div class="scrap-ref">GP-2026-002</div>
                            <div class="scrap-cat">2026-09-23</div>
                        </td>
                        <td>
                            <span class="scrap-desc">CPR1426-74081100</span>
                        </td>
                        <td>
                            <span class="scrap-desc">Solar Equipment Store</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Admin</span>
                        </td>
                       
                        <td class="text-end">
                            <span class="scrap-value">₹10,000</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#effff8;color:#008f68;border:1px solid #8be1c1;font-size:11px;font-weight:600;">
                                Approved
                            </span>
                        </td>

                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-approve" title="Approve">
                                    <i class="mdi mdi-check-circle-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- GP-2026-004 --}}
                    <tr class="scrap-row" data-gp-no="GP-2026-004" data-status="Approved">
                        <td>
                            <div class="scrap-ref">GP-2026-004</div>
                            <div class="scrap-cat">2026-07-24</div>
                        </td>
                        <td>
                            <span class="scrap-desc">SCR-2026-004</span>
                        </td>
                        <td>
                            <span class="scrap-desc">Chennai Industrial Traders</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Admin</span>
                        </td>
                       
                        <td class="text-end">
                            <span class="scrap-value">₹27,200</span>
                        </td>
                        <td class="text-center">
                           <span class="badge rounded-pill px-3 py-2"
                                  style="background:#effff8;color:#008f68;border:1px solid #8be1c1;font-size:11px;font-weight:600;">
                                Approved
                            </span>
                        </td>

                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-approve" title="Approve">
                                    <i class="mdi mdi-check-circle-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- GP-2026-2026002 — Awaiting Approval --}}
                    <tr class="scrap-row" data-gp-no="GP-2026-2026002" data-status="Awaiting Approval">
                        <td>
                            <div class="scrap-ref">GP-2026-2026002</div>
                            <div class="scrap-cat">2026-09-24</div>
                        </td>
                        <td>
                            <span class="scrap-desc">ALM1424-76042100</span>
                        </td>
                        <td>
                            <span class="scrap-desc">Solar Equipment Store</span>
                        </td>

                        <td>
                            <span class="scrap-desc">Admin</span>
                        </td>
                       
                        <td class="text-end">
                            <span class="scrap-value">₹2,500</span>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill px-3 py-2"
                                  style="background:#fffaf0;color:#d97706;border:1px solid #f3cf67;font-size:11px;font-weight:600;">
                                Awaiting Approval
                            </span>
                        </td>

                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-approve" title="Approve">
                                    <i class="mdi mdi-check-circle-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>


    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 small text-muted">
        <span>SRK INFRA DEVELOPERS ERP v8.4 | SECURED LOCAL CACHE</span>
        <span>
            SYSTEM TIME:
            <span id="scrapSystemTime"></span>
            | UTC -07:00
        </span>
    </div>



    <!-- Approve Scrap Value Modal -->
    <div class="modal fade" id="approveScrapModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-3 border-0 shadow-lg">

                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold mb-0" style="font-size:15px;">
                        Scrap Value Approve
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body py-4 px-4">
                    <p class="mb-0 text-dark" style="font-size:13.5px;">
                        Are you Sure to Approve this Scrap Disposal?
                    </p>
                    <input type="hidden" id="approveGpNo">
                </div>

                <div class="modal-footer border-0 pt-0 px-4 pb-3">
                    <button type="button"
                            class="btn btn-light btn-sm px-4"
                            data-bs-dismiss="modal">
                        No
                    </button>
                    <button type="button"
                            class="btn btn-primary btn-sm px-4 text-white"
                            id="approveYesBtn">
                        Yes
                    </button>
                </div>

            </div>
        </div>
    </div>

</div>



<style>

.scrap-header-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #e8eef5;
    color: #16659E;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.scrap-header-icon i {
    font-size: 24px;
    line-height: 1;
}

.scrap-tab-arrow {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #8a97a8;
    flex-shrink: 0;
    padding: 0;
    cursor: pointer;
    transition: all .15s ease;
}

.scrap-tab-arrow:hover {
    background: #f8f9fa;
    color: #16659E;
    border-color: #16659E;
}

.scrap-tab-arrow i {
    font-size: 18px;
    line-height: 1;
}

.scrap-tabs-scroller {
    overflow: hidden;
    max-width: 100%;
    min-width: 0;
}

.scrap-tabs-track {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
}

.scrap-tabs-track::-webkit-scrollbar {
    display: none;
}

.scrap-tab-pill {
    white-space: nowrap;
    padding: 8px 20px;
    border-radius: 50px;
    background: #eef1f4;
    color: #566a7f;
    font-size: .85rem;
    font-weight: 600;
    text-decoration: none;
    transition: all .2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 38px;
    flex-shrink: 0;
    border: 0;
}

.scrap-tab-pill:hover {
    background: #e2e6ea;
    color: #16659E;
    text-decoration: none;
}

.scrap-tab-pill.active {
    background: #16659E;
    color: #fff;
}

.scrap-tab-pill.active:hover {
    background: #124f7c;
    color: #fff;
}

.scrap-records-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 14px;
    border-radius: 8px;
    background: #eef1f4;
    color: #566a7f;
    font-size: 11.5px;
    font-weight: 600;
    white-space: nowrap;
}

.scrap-table {
    table-layout: auto;
    width: 100% !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    font-size: 12px;
}

.scrap-table thead th {
    background: #ffffff;
    color: #566a7f;
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    padding: 14px 24px;
    border-top: 1px solid #eef0f4;
    border-bottom: 1px solid #eef0f4;
    white-space: nowrap;
}

.scrap-table tbody td {
    padding: 18px 24px;
    vertical-align: middle;
    border-bottom: 1px solid #eef0f4;
    background: #ffffff;
    white-space: nowrap;
}

.scrap-table tbody tr:last-child td {
    border-bottom: 0;
}

.scrap-table tbody tr:hover td {
    background: #fbfdff;
}

.scrap-ref {
    display: block;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 500;
    line-height: 15px;
    white-space: nowrap;
}

.scrap-cat {
    display: block;
    margin-top: 4px;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    line-height: 16px;
    white-space: nowrap;
}

.scrap-desc {
    display: inline-block;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    line-height: 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
    vertical-align: middle;
}

.scrap-qty {
    display: inline-block;
    color: #111827;
    font-size: 12.5px;
    font-weight: 700;
    white-space: nowrap;
}

.scrap-rate {
    display: inline-block;
    color: #334155;
    font-size: 12px;
    font-weight: 500;
    font-family: 'Courier New', monospace;
    white-space: nowrap;
}

.scrap-value {
    display: inline-block;
    color: #1a8a4d;
    font-size: 13px;
    font-weight: 800;
    font-family: 'Courier New', monospace;
    white-space: nowrap;
}

.scrap-action-buttons {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
}

.scrap-action-btn {
    width: 22px;
    height: 22px;
    padding: 0;
    margin: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    background: transparent;
    cursor: pointer;
    font-size: 16px;
    line-height: 1;
    transition: all .15s ease;
}

.scrap-action-btn i {
    font-size: 16px;
    line-height: 1;
}

.scrap-view {
    color: #1a73e8;
}

.scrap-view:hover {
    color: #0d47a1;
    transform: scale(1.15);
}

.scrap-approve {
    color: #17a2b8;
}

.scrap-approve:hover {
    color: #0d7a8c;
    transform: scale(1.15);
}

.scrap-edit {
    color: #1a73e8;
}

.scrap-edit:hover {
    color: #0d47a1;
    transform: scale(1.15);
}

.scrap-delete {
    color: #94a3b8;
}

.scrap-delete:hover {
    color: #dc2626;
    transform: scale(1.15);
}

/* ---- Approved rows: lock the edit button ---- */
.scrap-row[data-status="Approved"] .scrap-edit {
    color: #cbd5e1;
    cursor: not-allowed;
    pointer-events: none;
    opacity: .5;
}

.scrap-row[data-status="Approved"] .scrap-edit:hover {
    color: #cbd5e1;
    transform: none;
}

/* Hide a filtered-out row */
.scrap-row.flt-hidden {
    display: none !important;
}

@media (max-width: 992px) {

    .scrap-table {
        min-width: 1000px;
    }

    .scrap-tabs-scroller {
        max-width: 100%;
    }

    .scrap-tabs-track {
        max-width: 100%;
    }
}

@media (max-width: 576px) {

    .scrap-table thead th,
    .scrap-table tbody td {
        padding: 14px 16px;
    }
}

</style>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const DISPOSAL_STORAGE_KEY = 'scrap_disposal_queue_v1';

    /* ---------- Tab scroll arrows ---------- */
    const track   = document.getElementById('scrapTabsTrack');
    const leftBtn = document.getElementById('scrapTabScrollLeft');
    const rightBtn = document.getElementById('scrapTabScrollRight');

    if (track && leftBtn) {
        leftBtn.addEventListener('click', function () {
            track.scrollBy({ left: -200, behavior: 'smooth' });
        });
    }

    if (track && rightBtn) {
        rightBtn.addEventListener('click', function () {
            track.scrollBy({ left: 200, behavior: 'smooth' });
        });
    }


    /* ---------- System clock ---------- */
    const timeEl = document.getElementById('scrapSystemTime');

    function updateTime() {
        if (!timeEl) return;
        const now = new Date();

        const y  = now.getFullYear();
        const m  = String(now.getMonth() + 1).padStart(2, '0');
        const d  = String(now.getDate()).padStart(2, '0');
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');

        timeEl.textContent = y + '-' + m + '-' + d + ' | ' + hh + ':' + mm;
    }

    updateTime();
    setInterval(updateTime, 60000);


    /* ---------- Elements ---------- */
    const tbody        = document.getElementById('disposalTableBody');
    const countBadge   = document.getElementById('disposalCountBadge');
    const approveModal = document.getElementById('approveScrapModal');
    const approveGpNo  = document.getElementById('approveGpNo');
    const approveYes   = document.getElementById('approveYesBtn');

    /* ---------- Filter elements ---------- */
    const fltSearch   = document.getElementById('fltSearch');
    const fltLocation = document.getElementById('fltLocation');
    const fltStatus   = document.getElementById('fltStatus');
    const fltApplyBtn = document.getElementById('fltApplyBtn');
    const fltResetBtn = document.getElementById('fltResetBtn');


    /* ---------- Lock the Edit button if the row is Approved ---------- */
    function syncEditLock(row) {
        if (!row) return;

        const editBtn = row.querySelector('.scrap-edit');
        if (!editBtn) return;

        const status = (row.dataset.status || '').trim();

        if (status === 'Approved') {
            editBtn.disabled = true;
            editBtn.setAttribute('aria-disabled', 'true');
            editBtn.title = 'Approved — cannot edit';
            editBtn.style.pointerEvents = 'none';
            editBtn.style.opacity = '.5';
            editBtn.style.cursor = 'not-allowed';
        } else {
            editBtn.disabled = false;
            editBtn.removeAttribute('aria-disabled');
            editBtn.title = 'Edit';
            editBtn.style.pointerEvents = '';
            editBtn.style.opacity = '';
            editBtn.style.cursor = '';
        }
    }


    /* ---------- Build row from localStorage item ---------- */
    function buildRowFromItem(item) {
        const tr = document.createElement('tr');
        tr.className = 'scrap-row';
        tr.dataset.gpNo     = item.gpNo;
        tr.dataset.location = item.location;
        tr.dataset.status   = item.status || 'Awaiting Approval';

        tr.innerHTML =
            '<td>' +
                '<div class="scrap-ref">' + item.gpNo + '</div>' +
                '<div class="scrap-cat">' + item.gpDate + '</div>' +
            '</td>' +
            '<td>' +
                '<span class="scrap-desc">' + (item.scrapRef || '-') + '</span>' +
            '</td>' +
            '<td>' +
                '<span class="scrap-desc">' + item.location + '</span>' +
            '</td>' +
            '<td>' +
                '<span class="scrap-desc">' + (item.requestedBy || 'Admin') + '</span>' +
            '</td>' +
            '<td class="text-end">' +
                '<span class="scrap-value">₹' + Number(item.totalValue || 0).toLocaleString('en-IN') + '</span>' +
            '</td>' +
            '<td class="text-center">' +
                '<span class="badge rounded-pill px-3 py-2 disposal-status-badge"></span>' +
            '</td>' +
            '<td class="text-center">' +
                '<div class="scrap-action-buttons">' +
                    '<button type="button" class="scrap-action-btn scrap-view" title="View">' +
                        '<i class="mdi mdi-eye-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="scrap-action-btn scrap-approve" title="Approve">' +
                        '<i class="mdi mdi-check-circle-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="scrap-action-btn scrap-edit" title="Edit">' +
                        '<i class="mdi mdi-pencil-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="scrap-action-btn scrap-delete" title="Delete">' +
                        '<i class="mdi mdi-trash-can-outline"></i>' +
                    '</button>' +
                '</div>' +
            '</td>';

        return tr;
    }


    /* ---------- Apply status pill colour ---------- */
    function applyStatusBadge(tr) {
        const badge = tr.querySelector('.disposal-status-badge');
        if (!badge) return;

        const status = tr.dataset.status || 'Awaiting Approval';

        if (status === 'Approved') {
            badge.textContent = 'Approved';
            badge.style.background = '#effff8';
            badge.style.color = '#008f68';
            badge.style.border = '1px solid #8be1c1';
            badge.style.fontSize = '11px';
            badge.style.fontWeight = '600';
        } else if (status === 'Pending') {
            badge.textContent = 'Pending';
            badge.style.background = '#fffaf0';
            badge.style.color = '#d97706';
            badge.style.border = '1px solid #f3cf67';
            badge.style.fontSize = '11px';
            badge.style.fontWeight = '600';
        } else if (status === 'Rejected') {
            badge.textContent = 'Rejected';
            badge.style.background = '#fef2f2';
            badge.style.color = '#dc2626';
            badge.style.border = '1px solid #fca5a5';
            badge.style.fontSize = '11px';
            badge.style.fontWeight = '600';
        } else {
            badge.textContent = 'Awaiting Approval';
            badge.style.background = '#fffaf0';
            badge.style.color = '#d97706';
            badge.style.border = '1px solid #f3cf67';
            badge.style.fontSize = '11px';
            badge.style.fontWeight = '600';
        }
    }


    /* ---------- Bind per-row action buttons ---------- */
    function bindRowButtons(row) {
        if (row.dataset.bound === '1') return;
        row.dataset.bound = '1';

        const gpNo = row.dataset.gpNo || '';

        /* View → open disposal-view page */
        const viewBtn = row.querySelector('.scrap-view');
        if (viewBtn) {
            viewBtn.addEventListener('click', function () {
                window.location.href =
                    "{{ route('store-purchase.scrap-disposal-view') }}" +
                    "?gp=" + encodeURIComponent(gpNo);
            });
        }

        /* Approve → open the confirmation modal */
        const approveBtn = row.querySelector('.scrap-approve');
        if (approveBtn) {
            approveBtn.addEventListener('click', function () {
                if (approveGpNo) approveGpNo.value = gpNo;

                if (approveModal) {
                    bootstrap.Modal.getOrCreateInstance(approveModal).show();
                }
            });
        }

        /* Edit → navigate to entry page (only if not approved) */
        const editBtn = row.querySelector('.scrap-edit');
        if (editBtn) {
            editBtn.addEventListener('click', function (e) {
                /* hard guard — even if CSS is bypassed */
                if ((row.dataset.status || '') === 'Approved') {
                    e.preventDefault();
                    e.stopPropagation();
                    return;
                }

                window.location.href =
                    "{{ route('store-purchase.scrap-disposal-entry') }}" +
                    "?edit=" + encodeURIComponent(gpNo);
            });
        }

        /* Delete → remove from localStorage + DOM */
        const delBtn = row.querySelector('.scrap-delete');
        if (delBtn) {
            delBtn.addEventListener('click', function () {
                if (confirm('Delete ' + (gpNo || 'this row') + '?')) {

                    let q = [];
                    try {
                        q = JSON.parse(localStorage.getItem(DISPOSAL_STORAGE_KEY) || '[]');
                    } catch (e) {
                        q = [];
                    }
                    q = q.filter(function (it) { return it.gpNo !== gpNo; });
                    localStorage.setItem(DISPOSAL_STORAGE_KEY, JSON.stringify(q));

                    row.remove();

                    refreshCountBadge();
                }
            });
        }

        /* Make sure the edit lock is applied on first bind */
        syncEditLock(row);
    }


    /* ---------- Count badge (only counts visible rows) ---------- */
    function refreshCountBadge() {
        if (!countBadge || !tbody) return;
        const total = tbody.querySelectorAll('.scrap-row:not(.flt-hidden)').length;
        countBadge.textContent = total + ' Records Listed';
    }


    /* ---------- Filtering ---------- */
    function readRowData(row) {
        const gpEl   = row.querySelector('.scrap-ref');
        const dateEl = row.querySelector('.scrap-cat');
        const cells  = row.querySelectorAll('td');

        const scrapRef  = cells[1] ? cells[1].innerText.trim() : '';
        const location  = cells[2] ? cells[2].innerText.trim() : '';
        const requested = cells[3] ? cells[3].innerText.trim() : '';
        const value     = cells[4] ? cells[4].innerText.trim() : '';

        return {
            gpNo:        (gpEl ? gpEl.innerText.trim() : ''),
            gpDate:      (dateEl ? dateEl.innerText.trim() : ''),
            scrapRef:    scrapRef,
            location:    location,
            requestedBy: requested,
            totalValue:  value,
            status:      (row.dataset.status || '').trim()
        };
    }

    function applyFilters() {
        if (!tbody) return;

        const term     = (fltSearch?.value || '').toLowerCase().trim();
        const location = (fltLocation?.value || '').trim();
        const status   = (fltStatus?.value || '').trim();

        const rows = tbody.querySelectorAll('.scrap-row');

        rows.forEach(function (row) {
            const d = readRowData(row);

            /* Search box — checks gp no, scrap ref, location, requested by */
            const haystack = (
                d.gpNo + ' ' +
                d.gpDate + ' ' +
                d.scrapRef + ' ' +
                d.location + ' ' +
                d.requestedBy + ' ' +
                d.totalValue + ' ' +
                d.status
            ).toLowerCase();

            const matchSearch   = term === '' || haystack.includes(term);
            const matchLocation = location === '' || d.location === location;
            const matchStatus   = status === '' || d.status === status;

            if (matchSearch && matchLocation && matchStatus) {
                row.classList.remove('flt-hidden');
            } else {
                row.classList.add('flt-hidden');
            }
        });

        refreshCountBadge();
    }

    function resetFilters() {
        if (fltSearch)   fltSearch.value = '';
        if (fltLocation) fltLocation.value = '';
        if (fltStatus)   fltStatus.value = '';
        applyFilters();
    }

    if (fltSearch)   fltSearch.addEventListener('input', applyFilters);
    if (fltLocation) fltLocation.addEventListener('change', applyFilters);
    if (fltStatus)   fltStatus.addEventListener('change', applyFilters);
    if (fltApplyBtn) fltApplyBtn.addEventListener('click', applyFilters);
    if (fltResetBtn) fltResetBtn.addEventListener('click', resetFilters);


    /* ---------- Approve Yes handler ---------- */
    if (approveYes) {
        approveYes.addEventListener('click', function () {
            const gpNo = approveGpNo ? approveGpNo.value : '';

            /* Update localStorage status to Approved */
            let q = [];
            try {
                q = JSON.parse(localStorage.getItem(DISPOSAL_STORAGE_KEY) || '[]');
            } catch (e) {
                q = [];
            }

            const idx = q.findIndex(function (it) { return it.gpNo === gpNo; });
            if (idx >= 0) {
                q[idx].status = 'Approved';
                localStorage.setItem(DISPOSAL_STORAGE_KEY, JSON.stringify(q));
            }

            /* Update the matching row's status badge */
            const row = document.querySelector(
                '#disposalTableBody tr[data-gp-no="' + gpNo + '"]'
            );
            if (row) {
                row.dataset.status = 'Approved';
                applyStatusBadge(row);
                syncEditLock(row);   /* ← disable the edit button now */
            }

            /* Hide modal */
            if (approveModal) {
                bootstrap.Modal.getOrCreateInstance(approveModal).hide();
            }

            /* Re-run filters so status filter stays accurate */
            applyFilters();
        });
    }


    /* ---------- Load queue from localStorage ---------- */
    function loadDisposalQueue() {
        if (!tbody) return;

        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(DISPOSAL_STORAGE_KEY) || '[]');
        } catch (e) {
            queue = [];
        }

        if (Array.isArray(queue) && queue.length > 0) {
            queue.forEach(function (item) {
                const existing = document.querySelector(
                    '#disposalTableBody tr[data-gp-no="' + item.gpNo + '"]'
                );

                /* If row already exists (static), just sync its status + lock */
                if (existing) {
                    existing.dataset.status = item.status || existing.dataset.status;
                    applyStatusBadge(existing);
                    syncEditLock(existing);
                    return;
                }

                const tr = buildRowFromItem(item);
                tbody.appendChild(tr);
                applyStatusBadge(tr);
                syncEditLock(tr);
            });
        }

        refreshCountBadge();

        /* Bind buttons on all rows + apply status + lock */
        document.querySelectorAll('#disposalTableBody .scrap-row').forEach(function (row) {
            applyStatusBadge(row);
            syncEditLock(row);
            bindRowButtons(row);
        });

        /* Run filters once after load so counts are correct */
        applyFilters();
    }

    loadDisposalQueue();

});
</script>

@endsection