@extends('layouts/layoutMaster')

@section('title', 'Scrap view Details')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])



@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])



@section('content')

<div class="container-fluid py-3">

    {{-- Back button (top-left) --}}
    <div class="mb-3">
        <button type="button"
                class="btn btn-sm btn-light border d-inline-flex align-items-center gap-1 px-3"
                id="dvBackBtn"
                style="height:34px;">
            <i class="mdi mdi-chevron-left"></i>
            <span>Back</span>
        </button>
    </div>

    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <h5 class="fw-bold text-secondary text-uppercase mb-0"
                    style="font-size:14px;letter-spacing:.05em;">
                    SCRAP DETAILS - <span id="dvGpNo">GP-2026-001</span>
                </h5>

                <span class="text-muted small">
                    Date : <span id="dvDate">03-07-2026</span>
                </span>
            </div>

            <div class="text-center my-3">
               <span class="badge rounded-pill px-3 py-2 bg-primary text-white" style="font-size:12px; font-weight:600;">
                    No. of Materials Scraped : <span id="dvMaterialCount">2</span>
                </span>
            </div>

            <div class="d-flex justify-content-end align-items-center gap-2 mb-3">
                <label for="dvSearch" class="mb-0 small text-muted">Search:</label>
                <input type="text"
                       id="dvSearch"
                       class="form-control form-control-sm"
                       style="width:200px;"
                       autocomplete="off">
            </div>

            <div class="table-responsive">
                <table class="table dv-table mb-0" id="dvTable">
                    <thead>
                        <tr>
                            <th class="text-start">Material Name</th>
                            <th class="text-center" style="width:80px;">Unit</th>
                            <th class="text-start">Description</th>
                            <th class="text-center" style="width:150px;">Disposed (in weight)</th>
                            <th class="text-center" style="width:120px;">Dispose Rate</th>
                            <th class="text-center" style="width:130px;">Dispose Amount</th>
                        </tr>
                    </thead>
                    <tbody id="dvTableBody">
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-end mt-3">
                <button type="button"
                        class="btn btn-sm btn-light border px-4"
                        id="dvCloseBtn">
                    Close
                </button>
            </div>

        </div>
    </div>

</div>


<style>

.dv-table {
    width: 100% !important;
    border-collapse: collapse !important;
    font-size: 12.5px;
}

.dv-table thead th {
    background: #ffffff;
    color: #111827;
    font-size: 11.5px;
    font-weight: 700;
    padding: 12px 12px;
    border-top: 0;
    border-bottom: 1px solid #d9dee3;
    white-space: nowrap;
    vertical-align: middle;
}

.dv-table tbody td {
    padding: 14px 12px;
    border-bottom: 1px solid #eef0f4;
    vertical-align: middle;
    color: #111827;
    font-size: 12.5px;
    background: #ffffff;
}

.dv-table tbody tr:hover td {
    background: #fbfdff;
}

</style>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const DISPOSAL_STORAGE_KEY = 'scrap_disposal_queue_v1';

    const urlParams = new URLSearchParams(window.location.search);
    const gpNo      = urlParams.get('gp') || '';

    const dvGpNo   = document.getElementById('dvGpNo');
    const dvDate   = document.getElementById('dvDate');
    const dvCount  = document.getElementById('dvMaterialCount');
    const tbody    = document.getElementById('dvTableBody');
    const searchIn = document.getElementById('dvSearch');
    const info     = document.getElementById('dvEntriesInfo');

    const backBtn  = document.getElementById('dvBackBtn');
    const closeBtn = document.getElementById('dvCloseBtn');


    /* ---------- Shared navigation back to disposal page ---------- */
    function goBackToDisposal() {
        window.location.href = "{{ route('store-purchase.scrap-disposal') }}";
    }

    if (backBtn)  backBtn.addEventListener('click', goBackToDisposal);
    if (closeBtn) closeBtn.addEventListener('click', goBackToDisposal);


    /* ---------- Sample fallback if no localStorage match ---------- */
    const FALLBACK_ITEMS = [
        {
            name: 'ALM1424 - Aluminium Section Channel',
            unit: 'Kgs',
            description: 'Sold to local recycler',
            disposed: 1,
            rate: 200,
            amount: 200
        },
        {
            name: 'CPR1426 - Copper Wire 4 sqmm',
            unit: 'MT',
            description: 'Copper scrap sold',
            disposed: 40,
            rate: 250,
            amount: 10000
        }
    ];

    function loadData() {
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(DISPOSAL_STORAGE_KEY) || '[]');
        } catch (e) {
            queue = [];
        }

        let found = null;
        if (gpNo) {
            found = queue.find(function (it) { return it.gpNo === gpNo; });
        }

        if (found) {
            if (dvGpNo)  dvGpNo.textContent  = found.gpNo;
            if (dvDate)  dvDate.textContent  = found.gpDate;

            const items = Array.isArray(found.items) ? found.items : [];
            const rows  = items.map(function (it) {
                return {
                    name:        it.code || '-',
                    unit:        it.unit || '-',
                    description: it.description || '-',
                    disposed:    it.disposeQty || 0,
                    rate:        it.disposeRate || 0,
                    amount:      it.amount || (it.disposeQty || 0) * (it.disposeRate || 0)
                };
            });

            renderRows(rows.length ? rows : FALLBACK_ITEMS);
        } else {
            /* Fall back to sample rows */
            if (dvGpNo)  dvGpNo.textContent = gpNo || 'GP-2026-001';
            if (dvDate)  dvDate.textContent = '03-07-2026';
            renderRows(FALLBACK_ITEMS);
        }
    }

    function renderRows(rows) {
        if (!tbody) return;

        let html = '';

        rows.forEach(function (r) {
            html += '<tr>';
            html += '<td>' + r.name + '</td>';
            html += '<td class="text-center">' + r.unit + '</td>';
            html += '<td>' + r.description + '</td>';
            html += '<td class="text-center">' + r.disposed + '</td>';
            html += '<td class="text-center">' + Number(r.rate).toFixed(2) + '</td>';
            html += '<td class="text-center">' + Number(r.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 }) + '</td>';
            html += '</tr>';
        });

        tbody.innerHTML = html;

        if (dvCount) dvCount.textContent = rows.length;
        if (info) {
            info.textContent = '1 - ' + rows.length + ' of ' + rows.length + ' entries';
        }
    }

    function applySearch() {
        const term = (searchIn?.value || '').toLowerCase().trim();
        const rows = document.querySelectorAll('#dvTableBody tr');

        let visible = 0;

        rows.forEach(function (row) {
            const match = term === '' || row.innerText.toLowerCase().includes(term);
            row.style.display = match ? '' : 'none';
            if (match) visible++;
        });

        if (info) {
            info.textContent = '1 - ' + visible + ' of ' + visible + ' entries';
        }
    }

    if (searchIn) searchIn.addEventListener('input', applySearch);

    loadData();

});
</script>

@endsection