@extends('layouts/layoutMaster')

@section('title', 'Site Indent (PR)')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
  .audit-timeline {
  position: relative;
  padding-left: 1.5rem;
}

.audit-timeline-item {
  position: relative;
  padding-bottom: 1.25rem;
}

.audit-timeline-item:last-child {
  padding-bottom: 0;
}

.audit-timeline-item::before {
  content: '';
  position: absolute;
  left: -1.5rem;
  top: 0.35rem;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #16659E;
}

.audit-timeline-item::after {
  content: '';
  position: absolute;
  left: -1.28rem;
  top: 0.85rem;
  bottom: -0.4rem;
  width: 1px;
  background: #e2e6ea;
}

.audit-timeline-item:last-child::after {
  display: none;
}

.audit-timeline-date {
  font-size: 0.72rem;
  color: #6c757d;
  font-family: monospace;
}

.audit-timeline-label {
  font-weight: 600;
  font-size: 0.9rem;
  color: #212529;
}

.audit-timeline-actor {
  font-size: 0.78rem;
  color: #6c757d;
}
</style>

@php
  $warehouseTabs = [
    ['key' => 'materail_master','label' => 'Material Master DB','route' => 'store-purchase.material_master'],
    ['key' => 'site_indents','label' => 'Site Indents (PR)','route' => 'store-purchase.site_indent'],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_master'    => 'materail_master',
      'store-purchase.site_indent' => 'site_indents',
      default                                 => 'site_indents',
  };
  
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller"> 
            @foreach ($warehouseTabs as $tab) 
                @if (isset($tab['children'])) 
                    @php 
                        $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                    @endphp 
                    <div class="settings-tab-dropdown"> 
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                            {{ $tab['label'] }} 
                            <span class="ms-1"> 
                                <i class="mdi mdi-chevron-down"></i> 
                            </span> 
                        </button> 
                        <div class="settings-tab-dropdown-menu"> 
                            @foreach ($tab['children'] as $child) 
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                {{ $child['label'] }} 
                            </a> 
                            @endforeach 
                        </div> 
                    </div> 
                    @else 
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                        {{ $tab['label'] }} 
                    </a> 
                @endif 
            @endforeach 
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>

<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body p-3 p-md-4">

        {{-- Header --}}
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
            <div>
                <h5 class="fw-bold mb-0">Site Material Indents</h5>
                <small class="text-muted">Track, approve, and convert site material requests into purchase orders</small>
            </div>
            <button type="button" class="btn btn-outline-secondary btn-sm" id="exportIndentsBtn">
                <i class="mdi mdi-export me-1"></i> Export Indents
            </button>
        </div>

        {{-- Stat cards --}}
        <div class="row g-3 mb-4">
            <div class="col-6 col-lg-3">
                <div class="border rounded-3 p-3 h-100 d-flex align-items-center gap-3">
                    <div class="rounded-3 bg-primary bg-opacity-10 text-white d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                        <i class="mdi mdi-clipboard-edit-outline fs-3"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold lh-1" id="statTotal">0</div>
                        <small class="text-muted">Total Indents (30d)</small>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="border rounded-3 p-3 h-100 d-flex align-items-center gap-3">
                    <div class="rounded-3 bg-warning bg-opacity-25 text-black d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                        <i class="mdi mdi-timer-sand fs-3"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold lh-1" id="statPending">0</div>
                        <small class="text-muted"><i class="mdi mdi-exclamation-circle-fill text-warning me-1"></i>Pending Approval</small>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="border rounded-3 p-3 h-100 d-flex align-items-center gap-3">
                    <div class="rounded-3 bg-info bg-opacity-25 text-info d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                        <i class="mdi mdi-receipt-text-outline fs-3"></i>
                    </div>
                    <div>
                        <div class="fs-4 fw-bold lh-1" id="statPO">0</div>
                        <small class="text-muted">PO Generated</small>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="border rounded-3 p-3 h-100 d-flex align-items-center gap-3">
                    <div class="rounded-3 bg-success bg-opacity-25 text-success d-flex align-items-center justify-content-center flex-shrink-0" style="width:44px;height:44px;">
                        <i class="mdi mdi-currency-rupee fs-3"></i>
                    </div>
                    <div>
                        <div class="fs-5 fw-bold lh-1" id="statValue">₹0 L</div>
                        <small class="text-muted">Total Value (Approved)</small>
                    </div>
                </div>
            </div>
        </div>

        {{-- Status filter pills --}}
        <div class="d-flex flex-wrap gap-2 mb-3" id="statusFilters">
            <button type="button" class="btn btn-sm btn-primary status-filter-btn" data-status="all">All Indents</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="draft">Draft</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="engineer_approved">Engineer Approved</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="pm_approved">PM Approved</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="purchase_dept">In Purchase Dept</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="po_created">PO Created</button>
            <button type="button" class="btn btn-sm btn-outline-secondary status-filter-btn" data-status="rejected">Rejected</button>
        </div>

        {{-- Search & controls --}}
        <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
            <div class="flex-grow-1" style="min-width:220px;">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                    <input type="text" class="form-control" id="searchInput" placeholder="Search by project, site, indent ID or requester...">
                </div>
            </div>
            <select class="form-select form-select-sm" id="positionFilter" style="width:auto;">
                <option value="">All Positions</option>
            </select>
            <select class="form-select form-select-sm" id="departmentFilter" style="width:auto;">
                <option value="">All Departments</option>
            </select>
            <button type="button" class="btn btn-sm btn-outline-secondary" id="collapseAllBtn">
                <i class="mdi mdi-arrow-collapse me-1 text-primary"></i><span id="collapseAllLabel">Collapse All</span>
            </button>
            <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#createIndentModal">
                <i class="mdi mdi-plus me-1"></i> Create Indent (PO)
            </button>
        </div>

        {{-- Empty state --}}
        <div id="emptyState" class="text-center text-primary py-5 d-none">
            <i class="mdi mdi-inbox fs-1 d-block mb-2"></i>
            No indents match your filters.
        </div>

        {{-- Indent list --}}
        <div id="indentList"></div>

    </div>
</div>

{{-- Create Indent modal --}}
<div class="modal fade" id="createIndentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <form id="createIndentForm">
        <div class="modal-header">
          <h5 class="modal-title"><i class="mdi mdi-plus-circle me-2"></i>New Material Indent</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Project Name</label>
              <input type="text" class="form-control form-control-sm" name="project" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Site / Location</label>
              <input type="text" class="form-control form-control-sm" name="site" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Department</label>
              <input type="text" class="form-control form-control-sm" name="department" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Requested By</label>
              <input type="text" class="form-control form-control-sm" name="requestedBy" required>
            </div>
            <div class="col-md-4">
              <label class="form-label small fw-semibold">Role</label>
              <input type="text" class="form-control form-control-sm" name="requestedByRole" placeholder="e.g. Site Engineer" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Needed By</label>
              <input type="date" class="form-control form-control-sm" name="neededBy" required>
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Priority</label>
              <select class="form-select form-select-sm" name="priority">
                <option value="High">High</option>
                <option value="Medium" selected>Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label small fw-semibold">Note</label>
              <textarea class="form-control form-control-sm" name="note" rows="2" placeholder="Why is this material required?"></textarea>
            </div>
          </div>

          <hr>

          <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="fw-semibold mb-0">Materials</h6>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addMaterialRowBtn">
              <i class="mdi mdi-plus"></i> Add Material
            </button>
          </div>
          <div id="materialRows"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Save as Draft</button>
        </div>
      </form>
    </div>
  </div>
</div>

{{-- Audit Log modal --}}
<div class="modal fade" id="auditLogModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header border-0 pb-2">
        <h6 class="modal-title fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-clock-outline text-primary fs-5"></i>
          Indent Audit Trail Log &amp; History
        </h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body pt-1">
        <div class="border rounded-3 p-3 bg-light mb-3">
          <div class="small text-muted font-monospace mb-1" id="auditLogIndentId"></div>
          <div class="fw-bold" id="auditLogProject"></div>
          <div class="small text-muted" id="auditLogSiteDept"></div>
        </div>

        <div class="audit-timeline" id="auditLogTimeline"></div>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-dark btn-sm w-100" data-bs-dismiss="modal">Close Audit Log</button>
      </div>
    </div>
  </div>
</div>

<style>
    .btn-orange { background-color:#fd7e14; border-color:#fd7e14; color:#fff; }
    .btn-orange:hover, .btn-orange:focus { background-color:#e8590c; border-color:#e8590c; color:#fff; }
    .indent-card { transition: box-shadow .15s ease; }
    .indent-card:hover { box-shadow: 0 .25rem .75rem rgba(0,0,0,.06); }
    .chevron-toggle .bi-chevron-down { transition: transform .15s ease; }
    .chevron-toggle[aria-expanded="true"] .bi-chevron-down { transform: rotate(180deg); }
    .material-row-card { background:#f8f9fb; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    // ---------------------------------------------------------------
    // 1. SAMPLE DATA (frontend only — replace with real data later)
    // ---------------------------------------------------------------
    let indents = [
        {
            id: 'IND-482',
            project: 'Chennai Metro Phase 2 - Corridor 6',
            site: 'Poonamallee Site Station',
            department: 'Civil Engineering',
            requestedBy: 'Dinesh Karthik',
            requestedByRole: 'Site Engineer',
            neededBy: '2024-05-01',
            priority: 'High',
            tags: ['Material Ready'],
            status: 'engineer_approved',
            note: 'Required for station corridor 6 waterproofing and aggregate flooring works.',
            attachments: 2,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'Cement OPC 53 Grade', spec: '53 Grade', category: 'Cement', qty: 1500, unit: 'bags', unitPrice: 340, remarks: 'Confirm cement mill test certificate' },
                { name: 'Coarse Aggregates 20mm', spec: '20mm Aggregate', category: 'Aggregates', qty: 950, unit: 'MT', unitPrice: 1250, remarks: 'For concrete batch mixing' },
            ],
        },
        {
            id: 'IND-479',
            project: 'Chennai Metro Phase 2 - Corridor 6',
            site: 'Poonamallee Site Station',
            department: 'Civil Engineering',
            requestedBy: 'Dinesh Karthik',
            requestedByRole: 'Site Engineer',
            neededBy: '2024-05-05',
            priority: 'Medium',
            tags: ['PM Approved'],
            status: 'pm_approved',
            note: 'Rebar reinforcement lay-out for pier cap, PM sign-off received.',
            attachments: 1,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'TMT Reinforcement Steel 16mm', spec: 'Fe500 Grade', category: 'Reinforcement Steel', qty: 25, unit: 'MT', unitPrice: 61500, remarks: 'Main pier cage reinforcement' },
                { name: 'Cement OPC 53 Grade', spec: '53 Grade', category: 'Cement', qty: 800, unit: 'bags', unitPrice: 340, remarks: 'Pier pedestal grouting' },
            ],
        },
        {
            id: 'IND-455',
            project: 'East Coast Road Revetted Bridge',
            site: 'Abutment A1 Site',
            department: 'Highway Division',
            requestedBy: 'Ganesh Pandian',
            requestedByRole: 'Site Engineer',
            neededBy: '2024-05-19',
            priority: 'Medium',
            tags: ['Ready for PO'],
            status: 'purchase_dept',
            note: 'Preparing road base ahead of paving next month.',
            attachments: 3,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'Paving Bitumen 60/70', spec: 'VG-30 Grade', category: 'Bitumen', qty: 120, unit: 'drums', unitPrice: 18500, remarks: 'BT wearing course preparation' },
                { name: 'Coarse Aggregates 20mm', spec: '20mm Aggregate', category: 'Aggregates', qty: 480, unit: 'MT', unitPrice: 1150, remarks: 'BM layer base spreading' },
            ],
        },
        {
            id: 'IND-441',
            project: 'Adyar Fivestar Residence',
            site: 'Block-A Plumbing Shaft',
            department: 'Plumbing & MEP',
            requestedBy: 'Rajesh Kumar',
            requestedByRole: 'MEP Engineer',
            neededBy: '2024-05-12',
            priority: 'Low',
            tags: ['PO Created'],
            status: 'po_created',
            note: 'UPVC piping run for vertical discharge stack.',
            attachments: 1,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'PVC Plumbing Pipe 4" (6m)', spec: 'Class-3', category: 'Plumbing', qty: 450, unit: 'pcs', unitPrice: 590, remarks: 'Vertical discharge stack' },
            ],
        },
        {
            id: 'IND-430',
            project: 'Coimbatore IT Park - Tower B',
            site: 'Basement Structural Zone',
            department: 'Structural Engineering',
            requestedBy: 'Priya Suresh',
            requestedByRole: 'Site Engineer',
            neededBy: '2024-05-28',
            priority: 'Low',
            tags: ['Draft'],
            status: 'draft',
            note: 'Draft request pending line-item confirmation from site store.',
            attachments: 0,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'Cement OPC 43 Grade', spec: '43 Grade', category: 'Cement', qty: 300, unit: 'bags', unitPrice: 320, remarks: 'Blinding concrete' },
            ],
        },
        {
            id: 'IND-410',
            project: 'Madurai Ring Road Extension',
            site: 'Chainage 12+400',
            department: 'Highway Division',
            requestedBy: 'Vignesh Raja',
            requestedByRole: 'Site Engineer',
            neededBy: '2024-04-22',
            priority: 'Medium',
            tags: ['Rate mismatch'],
            status: 'rejected',
            note: 'Rejected: vendor rate exceeded approved rate contract, resubmit with revised quote.',
            attachments: 1,
            history: [
                { date: '2024-04-20 10:00', label: 'Draft', actionBy: 'Dinesh Karthik' },
                { date: '2024-04-21 14:30', label: 'Project Engineer Approved', actionBy: 'Sivakumar Ramasamy' },
            ],
            materials: [
                { name: 'Coarse Aggregates 40mm', spec: '40mm Aggregate', category: 'Aggregates', qty: 600, unit: 'MT', unitPrice: 1300, remarks: 'Sub-base layer' },
            ],
        },
    ];

    // ---------------------------------------------------------------
    // 2. STATE
    // ---------------------------------------------------------------
    let activeStatus = 'all';
    let searchTerm = '';
    let positionTerm = '';
    let departmentTerm = '';
    let allCollapsed = false;
    let editingIndentId = null; // null = create mode; set = editing that indent    
    // ---------------------------------------------------------------
    // 3. HELPERS
    // ---------------------------------------------------------------
    const fmtINR = (n) => '₹' + Math.round(n).toLocaleString('en-IN');
    const fmtLakh = (n) => '₹' + (n / 100000).toFixed(2) + ' L';
    const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: '2-digit' });

    const lineTotal = (m) => m.qty * m.unitPrice;
    const indentTotal = (ind) => ind.materials.reduce((sum, m) => sum + lineTotal(m), 0);

    const categoryColor = (cat) => ({
        'Cement': 'primary',
        'Aggregates': 'warning',
        'Reinforcement Steel': 'dark',
        'Bitumen': 'danger',
        'Plumbing': 'info',
    }[cat] || 'secondary');

    const priorityColor = (p) => ({ High: 'danger', Medium: 'warning', Low: 'secondary' }[p] || 'secondary');

    const statusMeta = (status) => ({
        draft:              { label: 'Draft',           badge: 'secondary' },
        engineer_approved:  { label: 'In Review',       badge: 'info' },
        pm_approved:        { label: 'Awaiting PO',     badge: 'warning' },
        purchase_dept:      { label: 'Ready for PO',    badge: 'primary' },
        po_created:         { label: 'PO Created',      badge: 'success' },
        rejected:           { label: 'Rejected',        badge: 'danger' },
    }[status] || { label: status, badge: 'secondary' });

    function actionButtonsHtml(ind) {
        switch (ind.status) {
            case 'draft':
                return `
                    <button class="btn btn-sm btn-outline-secondary fs-8" data-action="edit" data-id="${ind.id}">Edit</button>
                    <button class="btn btn-sm btn-primary fs-8" data-action="submit" data-id="${ind.id}">Submit for Approval</button>`;
            case 'engineer_approved':
                return `
                    <button class="btn btn-sm btn-outline-danger fs-8" data-action="reject" data-id="${ind.id}">Reject</button>
                    <button class="btn btn-sm btn-primary fs-8" data-action="approve_pm" data-id="${ind.id}">Approve (PM)</button>`;
            case 'pm_approved':
                return `
                    <button class="btn btn-sm btn-outline-danger fs-8" data-action="reject" data-id="${ind.id}">Reject</button>
                    <button class="btn btn-sm btn-orange fs-8" data-action="send_purchase" data-id="${ind.id}">Send to Purchase Dept</button>`;
            case 'purchase_dept':
                return `<button class="btn btn-sm btn-success fs-8" data-action="generate_po" data-id="${ind.id}">Generate PO</button>`;
            case 'po_created':
                return `<button class="btn btn-sm btn-outline-primary fs-8" data-action="view_po" data-id="${ind.id}">View PO</button>`;
            case 'rejected':
                return `<button class="btn btn-sm btn-outline-secondary fs-8" data-action="reopen" data-id="${ind.id}">Reopen</button>`;
            default:
                return '';
        }
    }

    // ---------------------------------------------------------------
    // 4. RENDER
    // ---------------------------------------------------------------
    function renderStats() {
        document.getElementById('statTotal').textContent = indents.length;
        document.getElementById('statPending').textContent =
            indents.filter(i => ['engineer_approved', 'pm_approved'].includes(i.status)).length;
        document.getElementById('statPO').textContent =
            indents.filter(i => i.status === 'po_created').length;
        const approvedValue = indents
            .filter(i => ['pm_approved', 'purchase_dept', 'po_created'].includes(i.status))
            .reduce((sum, i) => sum + indentTotal(i), 0);
        document.getElementById('statValue').textContent = fmtLakh(approvedValue);
    }

    function populateDropdowns() {
        const positions = [...new Set(indents.map(i => i.requestedByRole))].sort();
        const departments = [...new Set(indents.map(i => i.department))].sort();
        const posSel = document.getElementById('positionFilter');
        const depSel = document.getElementById('departmentFilter');
        const prevPos = posSel.value, prevDep = depSel.value;
        posSel.innerHTML = '<option value="">All Positions</option>' +
            positions.map(p => `<option value="${p}">${p}</option>`).join('');
        depSel.innerHTML = '<option value="">All Departments</option>' +
            departments.map(d => `<option value="${d}">${d}</option>`).join('');
        if (positions.includes(prevPos)) posSel.value = prevPos;
        if (departments.includes(prevDep)) depSel.value = prevDep;
    }

    function materialRowsHtml(ind) {
        return ind.materials.map(m => `
            <tr>
                <td class="fw-semibold">${m.name}</td>
                <td><span class="badge bg-light text-dark border">${m.spec}</span></td>
                <td><span class="badge text-bg-${categoryColor(m.category)}">${m.category}</span></td>
                <td class="fw-semibold">${m.qty.toLocaleString('en-IN')}</td>
                <td><span class="badge bg-light text-dark border">${m.unit}</span></td>
                <td class="text-end">${fmtINR(m.unitPrice)}</td>
                <td class="text-end fw-semibold">${fmtINR(lineTotal(m))}</td>
                <td class="text-muted fst-italic small">${m.remarks || '—'}</td>
            </tr>
        `).join('');
    }

    function cardHtml(ind) {
        const sm = statusMeta(ind.status);
        const total = indentTotal(ind);
        return `
        <div class="indent-card border rounded-3 p-3 mb-3" data-indent-id="${ind.id}">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-2">
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <span class="badge bg-light text-dark border font-monospace rounded fs-8">${ind.id}</span>
                    <span class="badge text-bg-${priorityColor(ind.priority)} rounded fs-8">${ind.priority} Priority</span>
                    ${ind.tags.map(t => `<span class="badge bg-light rounded fs-8 text-dark border">${t}</span>`).join('')}
                </div>
                <div class="text-end">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                        <div class="fw-bold fs-6 d-flex flex-column">
                            <span class="fs-9 text-muted">
                                Est. Requisition Value
                            </span>
                            <span>${fmtINR(total)}</span>
                        </div>
                            <div class="d-flex flex-wrap gap-2">
                                ${actionButtonsHtml(ind)}
                                <button class="btn btn-sm btn-outline-secondary" data-action="history" data-id="${ind.id}" title="View Audit Log">
                                    <i class="mdi mdi-clock-outline"></i>
                                </button>
                            </div>
                            <button class="btn btn-sm btn-link text-decoration-none shadow-none border bg-gray-100 chevron-toggle fs-8" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#materials-${ind.id}" aria-expanded="true">
                                <span class="toggle-label">Hide Items</span> <i class="mdi mdi-chevron-down"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="mb-2 d-flex flex-row aling-items-center justify-content-start gap-2">
                    <h6 class="fw-bold mb-0">${ind.project}</h6>
                    |
                    <small class="text-muted">${ind.site}</small>
                </div>

                <div class="d-flex flex-wrap align-items-center gap-3 text-muted small mb-2">
                    <span><i class="mdi mdi-map-marker-outline me-1"></i>${ind.department}</span>
                    <span><i class="mdi mdi-account-outline me-1"></i>Requested by ${ind.requestedBy} (${ind.requestedByRole})</span>
                    <span><i class="mdi mdi-calendar-blank-outline me-1"></i>Needed by ${fmtDate(ind.neededBy)}</span>
                </div>

           

            <div class="collapse show materials-collapse" id="materials-${ind.id}">
                <div class="small fw-bold text-black text-uppercase mb-2" style="letter-spacing:.03em;">
                    Requested Materials Breakdown &amp; Quantity (${ind.materials.length})
                </div>
                <div class="table-responsive">
                    <table class="table table-sm align-middle rounded mb-0">
                        <thead class="table-light fs-7">
                            <tr class="text-muted small text-uppercase">
                                <th>Material Name</th>
                                <th>Specification / Grade</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit</th>
                                <th class="text-end">Est. Unit Price</th>
                                <th class="text-end">Est. Total</th>
                                <th>Vendor Remarks</th>
                            </tr>
                        </thead>
                        <tbody class="fs-8 fw-semibold">${materialRowsHtml(ind)}</tbody>
                    </table>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center border-top pt-2 mt-2">
                <small class="text-muted"><i class="mdi mdi-paperclip me-1"></i>${ind.attachments} attachment${ind.attachments === 1 ? '' : 's'}</small>
                <span class="badge rounded fs-8 text-bg-${sm.badge}">${sm.label}</span>
            </div>
        </div>`;
    }

    function renderList() {
        const term = searchTerm.trim().toLowerCase();
        const filtered = indents.filter(ind => {
            const matchesStatus = activeStatus === 'all' || ind.status === activeStatus;
            const matchesPosition = !positionTerm || ind.requestedByRole === positionTerm;
            const matchesDepartment = !departmentTerm || ind.department === departmentTerm;
            const matchesSearch = !term ||
                ind.id.toLowerCase().includes(term) ||
                ind.project.toLowerCase().includes(term) ||
                ind.site.toLowerCase().includes(term) ||
                ind.requestedBy.toLowerCase().includes(term);
            return matchesStatus && matchesPosition && matchesDepartment && matchesSearch;
        });

        const listEl = document.getElementById('indentList');
        const emptyEl = document.getElementById('emptyState');

        if (filtered.length === 0) {
            listEl.innerHTML = '';
            emptyEl.classList.remove('d-none');
        } else {
            emptyEl.classList.add('d-none');
            listEl.innerHTML = filtered.map(cardHtml).join('');
        }
    }

    function renderAll() {
        renderStats();
        renderList();
    }

    // ---------------------------------------------------------------
    // 5. EVENTS
    // ---------------------------------------------------------------
    document.getElementById('statusFilters').addEventListener('click', (e) => {
        const btn = e.target.closest('.status-filter-btn');
        if (!btn) return;
        document.querySelectorAll('.status-filter-btn').forEach(b => {
            b.classList.remove('btn-primary');
            b.classList.add('btn-outline-secondary');
        });
        btn.classList.remove('btn-outline-secondary');
        btn.classList.add('btn-primary');
        activeStatus = btn.dataset.status;
        renderList();
    });

    document.getElementById('searchInput').addEventListener('input', (e) => {
        searchTerm = e.target.value;
        renderList();
    });
    document.getElementById('positionFilter').addEventListener('change', (e) => {
        positionTerm = e.target.value;
        renderList();
    });
    document.getElementById('departmentFilter').addEventListener('change', (e) => {
        departmentTerm = e.target.value;
        renderList();
    });

    document.getElementById('collapseAllBtn').addEventListener('click', () => {
        allCollapsed = !allCollapsed;
        document.querySelectorAll('.materials-collapse').forEach(el => {
            const collapse = bootstrap.Collapse.getOrCreateInstance(el, { toggle: false });
            allCollapsed ? collapse.hide() : collapse.show();
        });
        document.getElementById('collapseAllLabel').textContent = allCollapsed ? 'Expand All' : 'Collapse All';
    });

    // Toggle "Hide Items" / "Show Items" label per card (delegated — survives re-renders)
    document.getElementById('indentList').addEventListener('shown.bs.collapse', (e) => {
        const btn = document.querySelector(`[data-bs-target="#${e.target.id}"]`);
        if (btn) btn.querySelector('.toggle-label').textContent = 'Hide Items';
    });
    document.getElementById('indentList').addEventListener('hidden.bs.collapse', (e) => {
        const btn = document.querySelector(`[data-bs-target="#${e.target.id}"]`);
        if (btn) btn.querySelector('.toggle-label').textContent = 'Show Items';
    });

    // Action buttons (event delegation — works after innerHTML re-renders)
    document.getElementById('indentList').addEventListener('click', (e) => {
        const el = e.target.closest('[data-action]');
        if (!el) return;
        e.preventDefault();
        const id = el.dataset.id;
        const ind = indents.find(i => i.id === id);
        if (!ind) return;

        const stamp = () => new Date().toISOString().slice(0, 16).replace('T', ' ');
        const actor = 'Admin User'; // swap for the logged-in user once wired to a backend

        const logChange = (label) => {
            ind.history = ind.history || [];
            ind.history.push({ date: stamp(), label, actionBy: actor });
        };

        switch (el.dataset.action) {
            case 'submit':        ind.status = 'engineer_approved'; logChange('Submitted for Approval'); break;
            case 'approve_pm':    ind.status = 'pm_approved'; logChange('Project Engineer Approved'); break;
            case 'send_purchase': ind.status = 'purchase_dept'; logChange('Sent to Purchase Dept'); break;
            case 'generate_po':   ind.status = 'po_created'; logChange('PO Generated'); break;
            case 'reject':        ind.status = 'rejected'; logChange('Rejected'); break;
            case 'reopen':        ind.status = 'draft'; logChange('Reopened as Draft'); break;
            case 'view_po':       alert(`Opening PO for ${ind.id} (demo).`); return;
            case 'duplicate': {
                const copy = JSON.parse(JSON.stringify(ind));
                copy.id = 'IND-' + Math.floor(100 + Math.random() * 900);
                copy.status = 'draft';
                copy.tags = ['Draft'];
                copy.history = [{ date: stamp(), label: 'Draft (duplicated from ' + ind.id + ')', actionBy: actor }];
                indents.unshift(copy);
                break;
            }
            case 'history':       openAuditLog(ind); return;
            case 'edit':           handleEdit(ind); return;
        }
        renderAll();
    });

    document.getElementById('exportIndentsBtn').addEventListener('click', () => {
        const headers = ['Indent ID','Project','Site','Department','Requested By','Role','Needed By','Priority','Status','Total Value'];
        const rows = indents.map(ind => [
            ind.id, ind.project, ind.site, ind.department, ind.requestedBy, ind.requestedByRole,
            ind.neededBy, ind.priority, statusMeta(ind.status).label, indentTotal(ind),
        ]);
        const csv = [headers, ...rows]
            .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(','))
            .join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'site-indents.csv';
        a.click();
        URL.revokeObjectURL(url);
    });

    // ---------------------------------------------------------------
    // 6. CREATE INDENT MODAL
    // ---------------------------------------------------------------
    let materialRowCount = 0;
    function handleEdit(ind) {
        editingIndentId = ind.id;

        document.getElementById('indentModalTitle').textContent = 'Edit Material Indent';
        document.getElementById('indentModalSubmitBtn').textContent = 'Update Indent';

        const form = document.getElementById('createIndentForm');
        form.elements['project'].value = ind.project;
        form.elements['site'].value = ind.site;
        form.elements['department'].value = ind.department;
        form.elements['requestedBy'].value = ind.requestedBy;
        form.elements['requestedByRole'].value = ind.requestedByRole;
        form.elements['neededBy'].value = ind.neededBy;
        form.elements['priority'].value = ind.priority;
        form.elements['note'].value = ind.note || '';

        // Rebuild material rows from the indent's existing materials
        const rowsWrap = document.getElementById('materialRows');
        rowsWrap.innerHTML = '';
        materialRowCount = 0;
        ind.materials.forEach(m => {
            addMaterialRow();
            const lastRow = rowsWrap.lastElementChild;
            lastRow.querySelector('[name="mat_name[]"]').value = m.name;
            lastRow.querySelector('[name="mat_spec[]"]').value = m.spec;
            lastRow.querySelector('[name="mat_category[]"]').value = m.category;
            lastRow.querySelector('[name="mat_qty[]"]').value = m.qty;
            lastRow.querySelector('[name="mat_unit[]"]').value = m.unit;
            lastRow.querySelector('[name="mat_price[]"]').value = m.unitPrice;
        });

        bootstrap.Modal.getOrCreateInstance(document.getElementById('createIndentModal')).show();
    }
    function addMaterialRow() {
        materialRowCount++;
        const wrap = document.createElement('div');
        wrap.className = 'material-row-card border rounded-3 p-2 mb-2';
        wrap.dataset.rowId = materialRowCount;
        wrap.innerHTML = `
            <div class="row g-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label small mb-1">Material Name</label>
                    <input type="text" class="form-control form-control-sm" name="mat_name[]" required>
                </div>
                <div class="col-md-2">
                    <label class="form-label small mb-1">Spec/Grade</label>
                    <input type="text" class="form-control form-control-sm" name="mat_spec[]">
                </div>
                <div class="col-md-2">
                    <label class="form-label small mb-1">Category</label>
                    <input type="text" class="form-control form-control-sm" name="mat_category[]">
                </div>
                <div class="col-md-1">
                    <label class="form-label small mb-1">Qty</label>
                    <input type="number" min="0" step="any" class="form-control form-control-sm" name="mat_qty[]" required>
                </div>
                <div class="col-md-1">
                    <label class="form-label small mb-1">Unit</label>
                    <input type="text" class="form-control form-control-sm" name="mat_unit[]">
                </div>
                <div class="col-md-2">
                    <label class="form-label small mb-1">Unit Price (₹)</label>
                    <input type="number" min="0" step="any" class="form-control form-control-sm" name="mat_price[]" required>
                </div>
                <div class="col-md-1 d-grid">
                    <button type="button" class="btn btn-sm btn-outline-danger remove-material-row" title="Remove">
                        <i class="mdi mdi-trash"></i>
                    </button>
                </div>
            </div>`;
        document.getElementById('materialRows').appendChild(wrap);
    }

    document.getElementById('addMaterialRowBtn').addEventListener('click', addMaterialRow);
    document.getElementById('materialRows').addEventListener('click', (e) => {
        const btn = e.target.closest('.remove-material-row');
        if (!btn) return;
        btn.closest('.material-row-card').remove();
    });

    document.getElementById('createIndentModal').addEventListener('show.bs.modal', (e) => {
        if (document.getElementById('materialRows').children.length === 0 && editingIndentId === null) {
            addMaterialRow();
        }
    });

    document.getElementById('createIndentModal').addEventListener('hidden.bs.modal', () => {
        editingIndentId = null;
        document.getElementById('indentModalTitle').textContent = 'New Material Indent';
        document.getElementById('indentModalSubmitBtn').textContent = 'Save as Draft';
        document.getElementById('createIndentForm').reset();
        document.getElementById('materialRows').innerHTML = '';
    });

    document.getElementById('createIndentForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const names = fd.getAll('mat_name[]');
        const specs = fd.getAll('mat_spec[]');
        const cats = fd.getAll('mat_category[]');
        const qtys = fd.getAll('mat_qty[]');
        const units = fd.getAll('mat_unit[]');
        const prices = fd.getAll('mat_price[]');

        const materials = names.map((n, i) => ({
            name: n, spec: specs[i] || '—', category: cats[i] || 'General',
            qty: parseFloat(qtys[i]) || 0, unit: units[i] || 'pcs', unitPrice: parseFloat(prices[i]) || 0,
            remarks: '',
        })).filter(m => m.name);

        const finalMaterials = materials.length
            ? materials
            : [{ name: 'Untitled item', spec: '—', category: 'General', qty: 1, unit: 'pcs', unitPrice: 0, remarks: '' }];

        if (editingIndentId) {
            // Update existing indent in place — status/history/id untouched
            const ind = indents.find(i => i.id === editingIndentId);
            if (ind) {
                ind.project = fd.get('project');
                ind.site = fd.get('site');
                ind.department = fd.get('department');
                ind.requestedBy = fd.get('requestedBy');
                ind.requestedByRole = fd.get('requestedByRole');
                ind.neededBy = fd.get('neededBy');
                ind.priority = fd.get('priority');
                ind.note = fd.get('note') || '';
                ind.materials = finalMaterials;

                ind.history = ind.history || [];
                ind.history.push({
                    date: new Date().toISOString().slice(0, 16).replace('T', ' '),
                    label: 'Indent details updated',
                    actionBy: 'Admin User', // swap for the logged-in user once wired to a backend
                });
            }
        } else {
            const newIndent = {
                id: 'IND-' + Math.floor(500 + Math.random() * 400),
                project: fd.get('project'),
                site: fd.get('site'),
                department: fd.get('department'),
                requestedBy: fd.get('requestedBy'),
                requestedByRole: fd.get('requestedByRole'),
                neededBy: fd.get('neededBy'),
                priority: fd.get('priority'),
                tags: ['Draft'],
                status: 'draft',
                note: fd.get('note') || '',
                attachments: 0,
                history: [
                    { date: new Date().toISOString().slice(0, 16).replace('T', ' '), label: 'Draft', actionBy: fd.get('requestedBy') || 'Unknown' },
                ],
                materials: finalMaterials,
            };
            indents.unshift(newIndent);
        }

        populateDropdowns();
        renderAll();

        bootstrap.Modal.getInstance(document.getElementById('createIndentModal')).hide();
    });

    // ---------------------------------------------------------------
    // 7. INIT
    // ---------------------------------------------------------------
    populateDropdowns();
    renderAll();
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });

    function openAuditLog(ind) {
        document.getElementById('auditLogIndentId').textContent = ind.id;
        document.getElementById('auditLogProject').textContent = ind.project;
        document.getElementById('auditLogSiteDept').textContent = `${ind.site} • ${ind.department}`;

        const entries = ind.history && ind.history.length
            ? ind.history
            : [{ date: '—', label: statusMeta(ind.status).label, actionBy: '—' }];

        document.getElementById('auditLogTimeline').innerHTML = entries.map(h => `
            <div class="audit-timeline-item">
                <div class="audit-timeline-date">${h.date}</div>
                <div class="audit-timeline-label">${h.label}</div>
                <div class="audit-timeline-actor">Action by: ${h.actionBy}</div>
            </div>
        `).join('');

        const modalEl = document.getElementById('auditLogModal');
        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }
</script>
@endsection