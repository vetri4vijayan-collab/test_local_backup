@extends('layouts/layoutMaster')

@section('title', 'Material Master DB')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  .material-count-badge {
    background: #ecf7ff;
    color: #16659E;
    font-weight: 600;
    font-size: .75rem;
  }

  .material-master-table thead th {
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
    border-bottom: 2px solid #e2e6ea;
    white-space: nowrap;
  }

  .material-variation-badge {
    background: #f3e8ff;
    color: #7c3aed;
    border-radius: 50rem;
    padding: .4rem .8rem;
    font-weight: 500;
    font-size: .78rem;
  }

  .type-badge {
    background: #e7f5ff;
    color: #1971c2;
    border-radius: 6px;
    font-weight: 500;
    font-size: .78rem;
  }

  .uom-badge {
    background: #fff3cd;
    color: #997404;
    border-radius: 6px;
    font-weight: 600;
    font-size: .78rem;
  }

  .status-badge {
    border-radius: 6px;
    font-weight: 500;
    font-size: .78rem;
    padding: .4rem .7rem;
  }
  .status-badge-active   { background: #d3f9d8; color: #2b8a3e; }
  .status-badge-low      { background: #ffe3e3; color: #c92a2a; }
  .status-badge-inactive { background: #e9ecef; color: #495057; }

  .btn-rates-toggle {
    background: #16659E;
    color: #fff;
    border-radius: 6px;
    font-size: .78rem;
    font-weight: 500;
    padding: .35rem .75rem;
    display: inline-flex;
    align-items: center;
    border: none;
  }
  .btn-rates-toggle:hover { background: #124f7d; color: #fff; }
  .btn-rates-toggle.active .rates-chevron { transform: rotate(180deg); }
  .rates-chevron { transition: transform .15s ease; }

  .btn-icon {
    width: 32px;
    height: 32px;
    padding: 0;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .regional-rates-panel {
    background: #f8fbff;
    border-top: 1px solid #e7f0f7;
    border-bottom: 1px solid #e7f0f7;
    padding: 1rem 1.25rem;
  }

  .regional-rates-table thead th {
    font-size: .7rem;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
    border-bottom: 1px solid #e2e6ea;
    white-space: nowrap;
  }

  .btn-add-price-point {
    background: #2b9e5b;
    color: #fff;
    border-radius: 6px;
    font-size: .78rem;
    font-weight: 500;
    border: none;
  }
  .btn-add-price-point:hover { background: #23824b; color: #fff; }
</style>
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
    /* Stat Cards */
  .stat-card {
    border: 1px solid #edf0f3;
    border-radius: 10px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
  }

  .stat-label {
    font-size: .74rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
  }

  .stat-value {
    font-size: 1.6rem;
    font-weight: 700;
    color: #212529;
  }

  .stat-sub { font-size: .74rem; }
  .stat-sub-purple { color: #7c3aed; }
  .stat-sub-green  { color: #2b9e5b; }
  .stat-sub-orange { color: #e8590c; }

  .stat-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
  }
  .stat-icon-blue   { background: #ecf7ff; color: #16659E; }
  .stat-icon-purple { background: #f3e8ff; color: #7c3aed; }
  .stat-icon-green  { background: #e6f9ee; color: #2b9e5b; }
  .stat-icon-orange { background: #fff3e0; color: #e8590c; }

  /* Toolbar */
  .toolbar-search-wrap { min-width: 260px; }
  .toolbar-search-wrap .input-group-text,
  .toolbar-search-wrap .form-control {
    background: #fff;
    border-color: #dee2e6;
  }
  .toolbar-search-wrap .form-control:focus {
    box-shadow: none;
    border-color: #16659E;
  }

  .toolbar-select {
    width: auto;
    min-width: 150px;
    font-size: .85rem;
  }

  .toolbar-btn {
    font-size: .85rem;
    font-weight: 500;
    white-space: nowrap;
  }

  .btn-add-material {
    background: #16659E;
    color: #fff;
    border: none;
  }
  .btn-add-material:hover {
    background: #124f7d;
    color: #fff;
  }

  @media (max-width: 767px) {
    .toolbar-search-wrap { min-width: 100%; order: -1; }
  }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const expandBtn = document.getElementById('expandAllRatesBtn');
    if (expandBtn) {
        let allExpanded = false;
        expandBtn.addEventListener('click', function () {
            allExpanded = !allExpanded;
            document.querySelectorAll('.rates-panel-row').forEach(row => {
                row.classList.toggle('d-none', !allExpanded);
            });
            document.querySelectorAll('.btn-rates-toggle').forEach(btn => {
                btn.classList.toggle('active', allExpanded);
            });
            expandBtn.innerHTML = allExpanded
                ? '<i class="mdi mdi-chevron-up me-1"></i> Collapse Rates'
                : '<i class="mdi mdi-chevron-down me-1"></i> Expand Rates';
        });
    }

    // TODO: wire these to real routes
    document.getElementById('exportCsvBtn')?.addEventListener('click', () => {
    });
    document.getElementById('bulkImportBtn')?.addEventListener('click', () => {
        // open your bulk-import modal here
    });
    document.getElementById('addMaterialBtn')?.addEventListener('click', () => {
        // open your add-material modal/offcanvas here
    });
});
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>
@php
  $warehouseTabs = [
    ['key' => 'materail_master','label' => 'Material Master DB','route' => 'store-purchase.material_master'],
    ['key' => 'site_indents','label' => 'Site Indents (PR)','route' => 'store-purchase.site_indent'],
  ];

  $currentRoute = Route::currentRouteName();
  $activeTab = $activeTab ?? match ($currentRoute) {
      'store-purchase.material_master'    => 'materail_master',
      'store-purchase.site_indent' => 'site_indents',
      default                                 => 'materail_master',
  };
  
@endphp
<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller"> 
            @foreach ($warehouseTabs as $tab) 
                @if (isset($tab['children'])) 
                    @php 
                        $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                    @endphp 
                    <div class="settings-tab-dropdown"> 
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                            {{ $tab['label'] }} 
                            <span class="ms-1"> 
                                <i class="mdi mdi-chevron-down"></i> 
                            </span> 
                        </button> 
                        <div class="settings-tab-dropdown-menu"> 
                            @foreach ($tab['children'] as $child) 
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                {{ $child['label'] }} 
                            </a> 
                            @endforeach 
                        </div> 
                    </div> 
                    @else 
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                        {{ $tab['label'] }} 
                    </a> 
                @endif 
            @endforeach 
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>
@php
  $materials = [
    [
        'variation'   => '53 Grade',
        'code'        => 'MAT-CEM-OPC53',
        'name'        => 'Cement OPC 53 Grade',
        'description' => 'Ordinary Portland Cement Grade 53 co...',
        'type'        => 'Cement',
        'hsn'         => '25232910',
        'uom'         => 'Bags',
        'brand'       => 'Ultratech Cement',
        'unit_price'  => 400,
        'length'      => '0.6m',
        'breadth'     => '0.4m',
        'depth'       => '0.15m',
        'status'      => 'Active',
        'rates' => [
            ['city' => 'Madurai',    'vendor' => 'Apex Cement Industries Ltd', 'base_price' => 385, 'transport' => 25, 'loading' => 10, 'gst' => 28, 'total_landed' => 537.60, 'effective_date' => '2026-07-01', 'last_updated' => '2026-07-24 10:15'],
            ['city' => 'Coimbatore', 'vendor' => 'Apex Cement Industries Ltd', 'base_price' => 395, 'transport' => 22, 'loading' => 11, 'gst' => 28, 'total_landed' => 547.84, 'effective_date' => '2026-07-01', 'last_updated' => '2026-07-22 11:30'],
            ['city' => 'Trichy',     'vendor' => 'Apex Cement Industries Ltd', 'base_price' => 390, 'transport' => 24, 'loading' => 11, 'gst' => 28, 'total_landed' => 544.00, 'effective_date' => '2026-07-01', 'last_updated' => '2026-07-23 09:40'],
        ],
    ],
    [
        'variation'   => '16mm Fe550D',
        'code'        => 'MAT-STL-TMT16',
        'name'        => 'TMT Reinforcement Steel 16mm',
        'description' => 'High Strength Thermo-Mechanically Tre...',
        'type'        => 'Steel',
        'hsn'         => '72142090',
        'uom'         => 'MT',
        'brand'       => 'TATA Tiscon',
        'unit_price'  => 62000,
        'length'      => '12m',
        'breadth'     => '-',
        'depth'       => '16mm',
        'status'      => 'Active',
        'rates' => [
            ['city' => 'Madurai',    'vendor' => 'Sri Sakthi Steel Traders', 'base_price' => 61200, 'transport' => 450, 'loading' => 150, 'gst' => 18, 'total_landed' => 72862.00, 'effective_date' => '2026-06-15', 'last_updated' => '2026-07-20 09:10'],
            ['city' => 'Coimbatore', 'vendor' => 'Sri Sakthi Steel Traders', 'base_price' => 61800, 'transport' => 400, 'loading' => 150, 'gst' => 18, 'total_landed' => 73456.00, 'effective_date' => '2026-06-15', 'last_updated' => '2026-07-19 14:25'],
            ['city' => 'Trichy',     'vendor' => 'Sri Sakthi Steel Traders', 'base_price' => 61500, 'transport' => 420, 'loading' => 150, 'gst' => 18, 'total_landed' => 73150.60, 'effective_date' => '2026-06-15', 'last_updated' => '2026-07-21 11:00'],
        ],
    ],
    [
        'variation'   => '20mm Graded',
        'code'        => 'MAT-AGG-20MM',
        'name'        => 'Coarse Aggregates 20mm',
        'description' => 'Hard granite broken stone aggregates, ...',
        'type'        => 'Aggregates',
        'hsn'         => '25171010',
        'uom'         => 'Cu.m',
        'brand'       => 'Titan Aggregates',
        'unit_price'  => 1200,
        'length'      => '-',
        'breadth'     => '-',
        'depth'       => '20mm',
        'status'      => 'Active',
        'rates' => [
            ['city' => 'Madurai', 'vendor' => 'Titan Quarry Supplies', 'base_price' => 1150, 'transport' => 40, 'loading' => 20, 'gst' => 5, 'total_landed' => 1272.00, 'effective_date' => '2026-07-05', 'last_updated' => '2026-07-25 08:45'],
            ['city' => 'Trichy',   'vendor' => 'Titan Quarry Supplies', 'base_price' => 1170, 'transport' => 35, 'loading' => 20, 'gst' => 5, 'total_landed' => 1289.25, 'effective_date' => '2026-07-05', 'last_updated' => '2026-07-24 16:30'],
            ['city' => 'Madurai',  'vendor' => 'Rockfort Aggregates',   'base_price' => 1160, 'transport' => 38, 'loading' => 22, 'gst' => 5, 'total_landed' => 1281.00, 'effective_date' => '2026-07-03', 'last_updated' => '2026-07-22 10:05'],
        ],
    ],
    [
        'variation'   => '60/70 Pen Grade',
        'code'        => 'MAT-OIL-BIT60',
        'name'        => 'Paving Bitumen 60/70',
        'description' => 'Paving grade bitumen penetration valu...',
        'type'        => 'Bitumen',
        'hsn'         => '27132000',
        'uom'         => 'Drums',
        'brand'       => 'IOCL Bitumen',
        'unit_price'  => 8500,
        'length'      => '0.9m',
        'breadth'     => '0.6m',
        'depth'       => '0.6m',
        'status'      => 'Low Stock (35)',
        'rates' => [
            ['city' => 'Madurai',    'vendor' => 'IOCL Authorized Dealer', 'base_price' => 8300, 'transport' => 120, 'loading' => 40, 'gst' => 18, 'total_landed' => 10122.40, 'effective_date' => '2026-07-10', 'last_updated' => '2026-07-26 12:15'],
            ['city' => 'Coimbatore', 'vendor' => 'IOCL Authorized Dealer', 'base_price' => 8350, 'transport' => 110, 'loading' => 40, 'gst' => 18, 'total_landed' => 10182.00, 'effective_date' => '2026-07-10', 'last_updated' => '2026-07-25 15:40'],
        ],
    ],
    [
        'variation'   => 'Class A 4"',
        'code'        => 'MAT-PIP-PVC4IN',
        'name'        => 'PVC Plumbing Pipe 4" (6m)',
        'description' => 'Schedule 40 High Density PVC Pipe, len...',
        'type'        => 'Pipes & Fittings',
        'hsn'         => '39172310',
        'uom'         => 'Pcs',
        'brand'       => 'Supreme Pipes',
        'unit_price'  => 650,
        'length'      => '6.0m',
        'breadth'     => '110mm',
        'depth'       => '3.2mm',
        'status'      => 'Active',
        'rates' => [
            ['city' => 'Madurai', 'vendor' => 'Supreme Pipes Distributor', 'base_price' => 620, 'transport' => 15, 'loading' => 8, 'gst' => 18, 'total_landed' => 758.14, 'effective_date' => '2026-07-08', 'last_updated' => '2026-07-23 13:20'],
            ['city' => 'Trichy',  'vendor' => 'Supreme Pipes Distributor', 'base_price' => 625, 'transport' => 14, 'loading' => 8, 'gst' => 18, 'total_landed' => 764.66, 'effective_date' => '2026-07-08', 'last_updated' => '2026-07-22 09:55'],
        ],
    ],
  ];
  // Derived stats for the summary cards
  $totalMasterItems   = count($materials);
  $materialVariations = collect($materials)->pluck('variation')->unique()->count();
  $locationsMapped    = collect($materials)->flatMap(fn($m) => collect($m['rates'] ?? [])->pluck('city'))->unique()->count();
  $stockAlerts        = collect($materials)->filter(fn($m) => str_starts_with($m['status'] ?? '', 'Low Stock'))->count();

  // Unique material types for the filter dropdown
  $materialTypes = collect($materials)->pluck('type')->unique()->values();
@endphp

<!-- Summary Stat Cards -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card stat-card h-100">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="stat-label">Total Master Items</span>
          <span class="stat-icon stat-icon-blue"><i class="mdi mdi-cube-outline"></i></span>
        </div>
        <h4 class="stat-value mb-1">{{ $totalMasterItems }}</h4>
        <small class="stat-sub text-muted">Catalogued SKU Master Items</small>
      </div>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="card stat-card h-100">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="stat-label">Material Variations</span>
          <span class="stat-icon stat-icon-purple"><i class="mdi mdi-tag-outline"></i></span>
        </div>
        <h4 class="stat-value mb-1">{{ $materialVariations }}</h4>
        <small class="stat-sub stat-sub-purple">Grades, Gauges &amp; Specs</small>
      </div>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="card stat-card h-100">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="stat-label">Locations Mapped</span>
          <span class="stat-icon stat-icon-green"><i class="mdi mdi-map-marker-outline"></i></span>
        </div>
        <h4 class="stat-value mb-1">{{ $locationsMapped }}</h4>
        <small class="stat-sub stat-sub-green">City Regional Price Index</small>
      </div>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="card stat-card h-100">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <span class="stat-label">Stock Alerts</span>
          <span class="stat-icon stat-icon-orange"><i class="mdi mdi-alert-circle-outline"></i></span>
        </div>
        <h4 class="stat-value mb-1">{{ $stockAlerts }}</h4>
        <small class="stat-sub stat-sub-orange">At/Below Min Reorder Level</small>
      </div>
    </div>
  </div>
</div>

<!-- Toolbar: Search + Filters + Actions -->
<div class="card mb-4 border-0 shadow-sm">
  <div class="card-body">
    <form method="GET" class="d-flex align-items-center flex-wrap gap-2">

      <div class="flex-grow-1 toolbar-search-wrap">
        <div class="input-group">
          <span class="input-group-text bg-white border-end-0">
            <i class="mdi mdi-magnify text-muted"></i>
          </span>
          <input type="text"
                 name="search"
                 class="form-control border-start-0 ps-0"
                 placeholder="Search Material Variation, Code, Name, HSN, Brand..."
                 value="{{ request('search') }}">
        </div>
      </div>

      <select name="material_type" class="form-select select3 toolbar-select" onchange="this.form.submit()">
        <option value="">All Material Types</option>
        @foreach ($materialTypes as $type)
          <option value="{{ $type }}" {{ request('material_type') === $type ? 'selected' : '' }}>
            {{ $type }}
          </option>
        @endforeach
      </select>

      <select name="status" class="form-select select3 toolbar-select" onchange="this.form.submit()">
        <option value="">All Statuses</option>
        <option value="Active" {{ request('status') === 'Active' ? 'selected' : '' }}>Active</option>
        <option value="Low Stock" {{ request('status') === 'Low Stock' ? 'selected' : '' }}>Low Stock</option>
        <option value="Inactive" {{ request('status') === 'Inactive' ? 'selected' : '' }}>Inactive</option>
      </select>

      <button type="button" class="btn btn-outline-secondary toolbar-btn" id="expandAllRatesBtn">
        <i class="mdi mdi-chevron-down me-1"></i> Expand Rates
      </button>

      <button type="button" class="btn btn-outline-secondary toolbar-btn" id="exportCsvBtn">
        <i class="mdi mdi-tray-arrow-down me-1"></i> Export CSV
      </button>

      <button type="button" class="btn btn-outline-secondary toolbar-btn" id="bulkImportBtn">
        <i class="mdi mdi-tray-arrow-up me-1"></i> Bulk Import
      </button>

      <button type="button" class="btn btn-add-material toolbar-btn" id="addMaterialBtn" data-bs-toggle="modal" data-bs-target="#add_material_modal">
        <i class="mdi mdi-plus me-1"></i> Add Material
      </button>
    </form>
  </div>
</div>


<div class="card mb-4 border-0 shadow-sm">
  <div class="card-body">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
      <div class="d-flex align-items-center gap-2">
        <h6 class="mb-0 fw-bold text-uppercase" style="letter-spacing:.3px;">Material Master Database</h6>
        <span class="badge material-count-badge rounded-pill">{{ count($materials ?? []) }} Items</span>
      </div>
      <small class="text-muted">Click on dropdown toggle in Actions column to view location-wise rates</small>
    </div>

    <div class="table-responsive">
      <table class="table material-master-table align-middle mb-0">
        <thead>
          <tr>
            <th>Material Variation</th>
            <th>Material Code</th>
            <th>Material Name</th>
            <th>Material Type</th>
            <th>HSN Code</th>
            <th>UOM</th>
            <th>Brand</th>
            <th>Unit Price</th>
            <th>L</th>
            <th>B</th>
            <th>D</th>
            <th>Status</th>
            <th class="text-end">Actions &amp; Location Rates</th>
          </tr>
        </thead>
        <tbody>
          @forelse ($materials ?? [] as $material)
            <tr>
              <td><span class="badge material-variation-badge">{{ $material['variation'] }}</span></td>
              <td class="fw-semibold">{{ $material['code'] }}</td>
              <td>
                <div class="fw-semibold">{{ $material['name'] }}</div>
                <small class="text-muted">{{ Str::limit($material['description'] ?? '', 42) }}</small>
              </td>
              <td><span class="badge type-badge">{{ $material['type'] }}</span></td>
              <td>{{ $material['hsn'] }}</td>
              <td><span class="badge uom-badge">{{ $material['uom'] }}</span></td>
              <td>{{ $material['brand'] }}</td>
              <td class="fw-semibold">₹{{ number_format($material['unit_price']) }}</td>
              <td>{{ $material['length'] ?? '-' }}</td>
              <td>{{ $material['breadth'] ?? '-' }}</td>
              <td>{{ $material['depth'] ?? '-' }}</td>
              <td>
                @php $status = $material['status'] ?? 'Active'; @endphp
                @if ($status === 'Active')
                  <span class="badge status-badge status-badge-active">Active</span>
                @elseif (str_starts_with($status, 'Low Stock'))
                  <span class="badge status-badge status-badge-low">{{ $status }}</span>
                @else
                  <span class="badge status-badge status-badge-inactive">{{ $status }}</span>
                @endif
              </td>
              <td class="text-end">
                <div class="d-flex justify-content-end align-items-center gap-1">
                  <button type="button"
                          class="btn-rates-toggle"
                          onclick="toggleRatesPanel(this, '{{ $material['code'] }}')">
                    Rates ({{ count($material['rates'] ?? []) }})
                    <i class="mdi mdi-chevron-down ms-1 rates-chevron"></i>
                  </button>
                  <button type="button" class="btn btn-sm btn-icon btn-outline-primary" title="Add" data-bs-toggle="modal" data-bs-target="#add_location_modal">
                    <i class="mdi mdi-plus"></i>
                  </button>
                  <button type="button" class="btn btn-sm btn-icon btn-outline-primary" title="Edit Material" data-bs-toggle="modal" data-bs-target="#edit_material_modal">
                    <i class="mdi mdi-pencil-outline"></i>
                  </button>
                  <button type="button" class="btn btn-sm btn-icon btn-outline-danger" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_material_modal">
                    <i class="mdi mdi-trash-can-outline"></i>
                  </button>
                </div>
              </td>
            </tr>

            <tr class="rates-panel-row d-none" id="rates-panel-{{ $material['code'] }}">
              <td colspan="13" class="p-0">
                <div class="regional-rates-panel">
                  <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
                    <div class="d-flex align-items-center gap-2">
                      <i class="mdi mdi-map-marker text-primary"></i>
                      <span class="fw-bold text-uppercase small">Regional Location Rates &amp; Supplier Index</span>
                      <span class="badge bg-label-secondary">{{ $material['code'] }} - {{ $material['name'] }}</span>
                    </div>
                    <button type="button" class="btn btn-sm btn-add-price-point" data-bs-toggle="modal" data-bs-target="#add_location_modal">
                      <i class="mdi mdi-plus me-1"></i> Add Price Point
                    </button>
                  </div>

                  <div class="table-responsive">
                    <table class="table table-sm regional-rates-table mb-0">
                      <thead>
                        <tr>
                          <th>Location (City)</th>
                          <th>Supplier Vendor</th>
                          <th>Base Purchase Price</th>
                          <th>Transportation Cost</th>
                          <th>Loading Charges</th>
                          <th>GST %</th>
                          <th>Total Landed Rate</th>
                          <th>Effective Date</th>
                          <th>Last Updated</th>
                          <th class="text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach ($material['rates'] ?? [] as $rate)
                          <tr>
                            <td><i class="mdi mdi-map-marker-outline text-danger me-1"></i>{{ $rate['city'] }}</td>
                            <td>{{ $rate['vendor'] }}</td>
                            <td>₹{{ number_format($rate['base_price']) }}</td>
                            <td>₹{{ number_format($rate['transport']) }}</td>
                            <td>₹{{ number_format($rate['loading']) }}</td>
                            <td>{{ $rate['gst'] }}%</td>
                            <td class="fw-bold text-success">₹{{ number_format($rate['total_landed'], 2) }}</td>
                            <td>{{ $rate['effective_date'] }}</td>
                            <td class="text-muted">{{ $rate['last_updated'] }}</td>
                            <td class="text-center">
                              <a href="javascript:void(0)"
                                 class="text-danger remove-rate-link"
                                 data-bs-toggle="modal"
                                 data-bs-target="#delete_price_modal"
                                 data-code="{{ $material['code'] }}"
                                 data-city="{{ $rate['city'] }}">
                                <i class="mdi mdi-close"></i>
                              </a>
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="13" class="text-center text-muted py-4">No materials found.</td>
            </tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>


{{-- Add / Edit Material Modal --}}

<div class="modal fade" id="add_material_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content text-start">

            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center gap-2">
                    <i class="mdi mdi-cube-outline"></i>
                    Add Material Master SKU Item
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <form id="materialForm">

                <div class="modal-body text-start">

                    <div class="row g-2 mb-3">

                        <div class="col-lg-6">
                            <label for="material_code" class="form-label">
                                Material Code <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="material_code"
                                id="material_code"
                                class="form-control"
                                placeholder="e.g. MAT-CEM-OPC53"
                                value="MAT-CEM-OPC53"
                                required
                            >
                        </div>

                        <div class="col-lg-6">
                            <label for="material_name" class="form-label">
                                Material Name <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="material_name"
                                id="material_name"
                                class="form-control"
                                placeholder="e.g. UltraTech Ordinary Portland Cement"
                                value="UltraTech Ordinary Portland Cement"
                                required
                            >
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-4">
                            <label for="material_variation"
                                   class="form-label text-primary fw-semibold">
                                Material Variation
                            </label>

                            <input
                                type="text"
                                name="material_variation"
                                id="material_variation"
                                class="form-control"
                                placeholder="e.g. 53 Grade / 16mm Fe550D"
                                value="53 Grade"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="material_type" class="form-label">
                                Material Type (Category)
                            </label>

                            <select name="material_type"
                                    id="material_type"
                                    class="form-select select3">

                                <option value="Cement" selected>Cement</option>
                                <option value="Steel">Steel</option>
                                <option value="Aggregate">Aggregate</option>
                                <option value="Bricks/Blocks">Bricks/Blocks</option>
                                <option value="Electrical">Electrical</option>
                                <option value="Plumbing">Plumbing</option>

                            </select>
                        </div>

                        <div class="col-lg-4">
                            <label for="uom" class="form-label">
                                UOM (Unit)
                            </label>

                            <select name="uom"
                                    id="uom"
                                    class="form-select select3">

                                <option value="Bags" selected>Bags</option>
                                <option value="Kg">Kg</option>
                                <option value="Ton">Ton</option>
                                <option value="Nos">Nos</option>
                                <option value="Meter">Meter</option>
                                <option value="Sq.Ft">Sq.Ft</option>
                                <option value="Litre">Litre</option>

                            </select>
                        </div>

                    </div>

                    <div class="row g-2 rounded-3 bg-label-primary border p-2 mb-3">

                        <label class="form-label text-black fw-semibold text-uppercase small mb-2">
                            Material Dimensions &amp; Price Baseline
                        </label>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="unit_price" class="form-label text-black">
                                Unit Price (₹)
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="unit_price"
                                id="unit_price"
                                class="form-control"
                                placeholder="e.g. 400"
                                value="420.00"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="length" class="form-label text-black">
                                Length (L)
                            </label>

                            <input
                                type="text"
                                name="length"
                                id="length"
                                class="form-control"
                                placeholder="e.g. 12m"
                                value="12m"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="breadth" class="form-label text-black">
                                Breadth (B)
                            </label>

                            <input
                                type="text"
                                name="breadth"
                                id="breadth"
                                class="form-control"
                                placeholder="e.g. 4ft"
                                value="4ft"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="depth" class="form-label text-black">
                                Depth (D)
                            </label>

                            <input
                                type="text"
                                name="depth"
                                id="depth"
                                class="form-control"
                                placeholder="e.g. 16mm"
                                value="16mm"
                            >
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-6">
                            <label for="brand" class="form-label">
                                Brand / Manufacturer
                            </label>

                            <input
                                type="text"
                                name="brand"
                                id="brand"
                                class="form-control"
                                placeholder="e.g. UltraTech / TATA Tiscon"
                                value="UltraTech"
                            >
                        </div>

                        <div class="col-lg-6">
                            <label for="hsn_code" class="form-label">
                                HSN Code <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="hsn_code"
                                id="hsn_code"
                                maxlength="8"
                                pattern="\d{8}"
                                class="form-control"
                                placeholder="8 Digit HSN code"
                                value="25232910"
                                required
                            >

                            <div class="form-text">
                                Must be exactly 8 digits.
                            </div>
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-12">
                            <label for="spec_description" class="form-label">
                                Specification Description
                            </label>

                            <textarea
                                name="spec_description"
                                id="spec_description"
                                rows="3"
                                class="form-control"
                                placeholder="Compliance IS code, grade parameters..."
                            >Ordinary Portland Cement, 53 Grade, conforming to IS 12269 specifications.</textarea>
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-4">
                            <label for="min_stock_alert" class="form-label">
                                Min Stock Alert Level
                            </label>

                            <input
                                type="number"
                                min="0"
                                name="min_stock_alert"
                                id="min_stock_alert"
                                class="form-control"
                                value="100"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="max_stock_cap" class="form-label">
                                Max Stock Cap
                            </label>

                            <input
                                type="number"
                                min="0"
                                name="max_stock_cap"
                                id="max_stock_cap"
                                class="form-control"
                                value="5000"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="gst_rate" class="form-label">
                                GST Rate %
                            </label>

                            <select name="gst_rate"
                                    id="gst_rate"
                                    class="form-select select3">

                                <option value="0">0%</option>
                                <option value="5">5%</option>
                                <option value="12">12%</option>
                                <option value="18" selected>18%</option>
                                <option value="28">28%</option>

                            </select>
                        </div>

                    </div>

                    <div class="row g-2 mb-2">

                        <div class="col-lg-12">
                            <label for="default_vendor" class="form-label">
                                Default Vendor Supplier
                            </label>

                            <select name="default_vendor"
                                    id="default_vendor"
                                    class="form-select select3">

                                <option value="direct_sourcing" selected>
                                    Direct Sourcing / Spot Market
                                </option>

                                <option value="ultratech">
                                    UltraTech Cement
                                </option>

                                <option value="tata">
                                    TATA Steel
                                </option>

                                <option value="ramco">
                                    Ramco Cements
                                </option>

                            </select>
                        </div>

                    </div>

                </div>

                <div class="modal-footer border-top">

                    <button type="button"
                            class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="button"
                            class="btn btn-primary d-flex align-items-center gap-1"
                            id="saveMaterialBtn">

                        <i class="mdi mdi-check"></i>

                        <span>Save Material to Master</span>

                    </button>

                </div>

            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="edit_material_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content text-start">

            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center gap-2">
                    <i class="mdi mdi-cube-outline"></i>
                    Update Material Master SKU Item
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <form id="materialForm">

                <div class="modal-body text-start">

                    <div class="row g-2 mb-3">

                        <div class="col-lg-6">
                            <label for="material_code" class="form-label">
                                Material Code <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="material_code"
                                id="material_code"
                                class="form-control"
                                placeholder="e.g. MAT-CEM-OPC53"
                                value="MAT-CEM-OPC53"
                                required
                            >
                        </div>

                        <div class="col-lg-6">
                            <label for="material_name" class="form-label">
                                Material Name <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="material_name"
                                id="material_name"
                                class="form-control"
                                placeholder="e.g. UltraTech Ordinary Portland Cement"
                                value="UltraTech Ordinary Portland Cement"
                                required
                            >
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-4">
                            <label for="material_variation"
                                   class="form-label text-primary fw-semibold">
                                Material Variation
                            </label>

                            <input
                                type="text"
                                name="material_variation"
                                id="material_variation"
                                class="form-control"
                                placeholder="e.g. 53 Grade / 16mm Fe550D"
                                value="53 Grade"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="material_type" class="form-label">
                                Material Type (Category)
                            </label>

                            <select name="material_type"
                                    id="material_type"
                                    class="form-select select3">

                                <option value="Cement" selected>Cement</option>
                                <option value="Steel">Steel</option>
                                <option value="Aggregate">Aggregate</option>
                                <option value="Bricks/Blocks">Bricks/Blocks</option>
                                <option value="Electrical">Electrical</option>
                                <option value="Plumbing">Plumbing</option>

                            </select>
                        </div>

                        <div class="col-lg-4">
                            <label for="uom" class="form-label">
                                UOM (Unit)
                            </label>

                            <select name="uom"
                                    id="uom"
                                    class="form-select select3">

                                <option value="Bags" selected>Bags</option>
                                <option value="Kg">Kg</option>
                                <option value="Ton">Ton</option>
                                <option value="Nos">Nos</option>
                                <option value="Meter">Meter</option>
                                <option value="Sq.Ft">Sq.Ft</option>
                                <option value="Litre">Litre</option>

                            </select>
                        </div>

                    </div>

                    <div class="row g-2 rounded-3 bg-label-primary border p-2 mb-3">

                        <label class="form-label text-black fw-semibold text-uppercase small mb-2">
                            Material Dimensions &amp; Price Baseline
                        </label>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="unit_price" class="form-label text-black">
                                Unit Price (₹)
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="unit_price"
                                id="unit_price"
                                class="form-control"
                                placeholder="e.g. 400"
                                value="420.00"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="length" class="form-label text-black">
                                Length (L)
                            </label>

                            <input
                                type="text"
                                name="length"
                                id="length"
                                class="form-control"
                                placeholder="e.g. 12m"
                                value="12m"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="breadth" class="form-label text-black">
                                Breadth (B)
                            </label>

                            <input
                                type="text"
                                name="breadth"
                                id="breadth"
                                class="form-control"
                                placeholder="e.g. 4ft"
                                value="4ft"
                            >
                        </div>

                        <div class="col-lg-3 col-6 mb-2">
                            <label for="depth" class="form-label text-black">
                                Depth (D)
                            </label>

                            <input
                                type="text"
                                name="depth"
                                id="depth"
                                class="form-control"
                                placeholder="e.g. 16mm"
                                value="16mm"
                            >
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-6">
                            <label for="brand" class="form-label">
                                Brand / Manufacturer
                            </label>

                            <input
                                type="text"
                                name="brand"
                                id="brand"
                                class="form-control"
                                placeholder="e.g. UltraTech / TATA Tiscon"
                                value="UltraTech"
                            >
                        </div>

                        <div class="col-lg-6">
                            <label for="hsn_code" class="form-label">
                                HSN Code <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="hsn_code"
                                id="hsn_code"
                                maxlength="8"
                                pattern="\d{8}"
                                class="form-control"
                                placeholder="8 Digit HSN code"
                                value="25232910"
                                required
                            >

                            <div class="form-text">
                                Must be exactly 8 digits.
                            </div>
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-12">
                            <label for="spec_description" class="form-label">
                                Specification Description
                            </label>

                            <textarea
                                name="spec_description"
                                id="spec_description"
                                rows="3"
                                class="form-control"
                                placeholder="Compliance IS code, grade parameters..."
                            >Ordinary Portland Cement, 53 Grade, conforming to IS 12269 specifications.</textarea>
                        </div>

                    </div>

                    <div class="row g-2 mb-3">

                        <div class="col-lg-4">
                            <label for="min_stock_alert" class="form-label">
                                Min Stock Alert Level
                            </label>

                            <input
                                type="number"
                                min="0"
                                name="min_stock_alert"
                                id="min_stock_alert"
                                class="form-control"
                                value="100"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="max_stock_cap" class="form-label">
                                Max Stock Cap
                            </label>

                            <input
                                type="number"
                                min="0"
                                name="max_stock_cap"
                                id="max_stock_cap"
                                class="form-control"
                                value="5000"
                            >
                        </div>

                        <div class="col-lg-4">
                            <label for="gst_rate" class="form-label">
                                GST Rate %
                            </label>

                            <select name="gst_rate"
                                    id="gst_rate"
                                    class="form-select select3">

                                <option value="0">0%</option>
                                <option value="5">5%</option>
                                <option value="12">12%</option>
                                <option value="18" selected>18%</option>
                                <option value="28">28%</option>

                            </select>
                        </div>

                    </div>

                    <div class="row g-2 mb-2">

                        <div class="col-lg-12">
                            <label for="default_vendor" class="form-label">
                                Default Vendor Supplier
                            </label>

                            <select name="default_vendor"
                                    id="default_vendor"
                                    class="form-select select3">

                                <option value="direct_sourcing" selected>
                                    Direct Sourcing / Spot Market
                                </option>

                                <option value="ultratech">
                                    UltraTech Cement
                                </option>

                                <option value="tata">
                                    TATA Steel
                                </option>

                                <option value="ramco">
                                    Ramco Cements
                                </option>

                            </select>
                        </div>

                    </div>

                </div>

                <div class="modal-footer border-top">

                    <button type="button"
                            class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="button"
                            class="btn btn-primary d-flex align-items-center gap-1"
                            id="saveMaterialBtn">

                        <i class="mdi mdi-check"></i>

                        <span>Save Material to Master</span>

                    </button>

                </div>

            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="add_location_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content text-start">

            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center gap-2">
                    <i class="mdi mdi-map-marker-radius"></i>
                    Add Location Rate & Price Point
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <form id="locationRateForm">

                <div class="modal-body">

                    <div class="rounded-3 border bg-light p-3 mb-4">

                        <div class="d-flex align-items-center gap-2 mb-3">
                            <i class="mdi mdi-cube-outline text-primary fs-4"></i>

                            <div>
                                <div class="fw-bold text-dark">
                                    MAT-CEM-OPC53
                                </div>

                                <div class="text-dark">
                                    Cement OPC 53 Grade
                                </div>

                                <div class="small text-muted mt-1">
                                    Variation:
                                    <strong>53 Grade</strong>
                                    <span class="mx-1">•</span>
                                    GST:
                                    <strong>28%</strong>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row g-3">

                        <div class="col-lg-6">
                            <label for="target_location" class="form-label">
                                Target Location (City)
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="target_location"
                                id="target_location"
                                class="form-select select3"
                                required
                            >
                                <option value="" selected disabled>
                                    Select city
                                </option>
                                <option value="Chennai">Chennai</option>
                                <option value="Madurai">Madurai</option>
                                <option value="Coimbatore">Coimbatore</option>
                                <option value="Villupuram">Villupuram</option>
                                <option value="Trichy">Trichy</option>
                                <option value="Salem">Salem</option>
                            </select>
                        </div>

                        <div class="col-lg-6">
                            <label for="supplier_vendor" class="form-label">
                                Supplier Vendor
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="supplier_vendor"
                                id="supplier_vendor"
                                class="form-select select3"
                                required
                            >
                                <option value="" selected disabled>
                                    Select supplier
                                </option>
                                <option value="apex_cement">
                                    Apex Cement Industries Ltd
                                </option>
                                <option value="national_steel">
                                    National Steel Corporation
                                </option>
                                <option value="titan_aggregates">
                                    Titan Aggregates Group
                                </option>
                                <option value="southern_bitumen">
                                    Southern Bitumen &amp; Oil Corp
                                </option>
                                <option value="supreme_pipes">
                                    Supreme Pipes &amp; Sanitary Mart
                                </option>
                            </select>
                        </div>

                    </div>

                    <div class="rounded-3 border p-3 mt-4">

                        <div class="fw-semibold text-uppercase small text-dark mb-3">
                            Rate & Price Details
                        </div>

                        <div class="row g-3">

                            <div class="col-lg-4">
                                <label for="purchase_price" class="form-label">
                                    Purchase Price (₹)
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="number"
                                    name="purchase_price"
                                    id="purchase_price"
                                    class="form-control"
                                    placeholder="e.g. 420"
                                    min="0"
                                    step="0.01"
                                    value="420.00"
                                    required
                                >
                            </div>

                            <div class="col-lg-4">
                                <label for="freight" class="form-label">
                                    Freight (₹)
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="number"
                                    name="freight"
                                    id="freight"
                                    class="form-control"
                                    placeholder="e.g. 25"
                                    min="0"
                                    step="0.01"
                                    value="25.00"
                                    required
                                >
                            </div>

                            <div class="col-lg-4">
                                <label for="loading" class="form-label">
                                    Loading (₹)
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="number"
                                    name="loading"
                                    id="loading"
                                    class="form-control"
                                    placeholder="e.g. 10"
                                    min="0"
                                    step="0.01"
                                    value="10.00"
                                    required
                                >
                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer border-top">

                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        class="btn btn-primary d-flex align-items-center gap-1"
                        id="applyRatePointBtn"
                    >
                        <i class="mdi mdi-check"></i>
                        <span>Apply Rate Point</span>
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="delete_price_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete Price Chart?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-danger px-3">Delete</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="delete_material_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete Material Master?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-danger px-3">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
function toggleRatesPanel(button, code) {
    const panel = document.getElementById('rates-panel-' + code);
    if (!panel) return;

    const isOpen = !panel.classList.contains('d-none');

    // close every other open panel/button first
    document.querySelectorAll('.rates-panel-row').forEach(row => row.classList.add('d-none'));
    document.querySelectorAll('.btn-rates-toggle').forEach(btn => btn.classList.remove('active'));

    if (!isOpen) {
        panel.classList.remove('d-none');
        button.classList.add('active');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.remove-rate-link').forEach(function (link) {
        link.addEventListener('click', function () {
            const code = this.dataset.code;
            const city = this.dataset.city;
            // TODO: call your delete route, e.g.:
            // axios.delete(`/store-purchase/material/${code}/rate/${city}`).then(() => location.reload());
            console.log('Remove rate', code, city);
        });
    });
});
</script>

@endsection