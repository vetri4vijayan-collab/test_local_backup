@extends('layouts/layoutMaster')

@section('title', 'Purchase Management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<style>
  .material-count-badge {
    background: #ecf7ff;
    color: #16659E;
    font-weight: 600;
    font-size: .75rem;
  }

  .material-master-table thead th {
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
    border-bottom: 2px solid #e2e6ea;
    white-space: nowrap;
  }

  .material-variation-badge {
    background: #f3e8ff;
    color: #7c3aed;
    border-radius: 50rem;
    padding: .4rem .8rem;
    font-weight: 500;
    font-size: .78rem;
  }

  .type-badge {
    background: #e7f5ff;
    color: #1971c2;
    border-radius: 6px;
    font-weight: 500;
    font-size: .78rem;
  }

  .uom-badge {
    background: #fff3cd;
    color: #997404;
    border-radius: 6px;
    font-weight: 600;
    font-size: .78rem;
  }

  .status-badge {
    border-radius: 6px;
    font-weight: 500;
    font-size: .78rem;
    padding: .4rem .7rem;
  }
  .status-badge-active   { background: #d3f9d8; color: #2b8a3e; }
  .status-badge-low      { background: #ffe3e3; color: #c92a2a; }
  .status-badge-inactive { background: #e9ecef; color: #495057; }

  .btn-rates-toggle {
    background: #16659E;
    color: #fff;
    border-radius: 6px;
    font-size: .78rem;
    font-weight: 500;
    padding: .35rem .75rem;
    display: inline-flex;
    align-items: center;
    border: none;
  }
  .btn-rates-toggle:hover { background: #124f7d; color: #fff; }
  .btn-rates-toggle.active .rates-chevron { transform: rotate(180deg); }
  .rates-chevron { transition: transform .15s ease; }

  .btn-icon {
    width: 32px;
    height: 32px;
    padding: 0;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .regional-rates-panel {
    background: #f8fbff;
    border-top: 1px solid #e7f0f7;
    border-bottom: 1px solid #e7f0f7;
    padding: 1rem 1.25rem;
  }

  .regional-rates-table thead th {
    font-size: .7rem;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
    border-bottom: 1px solid #e2e6ea;
    white-space: nowrap;
  }

  .btn-add-price-point {
    background: #2b9e5b;
    color: #fff;
    border-radius: 6px;
    font-size: .78rem;
    font-weight: 500;
    border: none;
  }
  .btn-add-price-point:hover { background: #23824b; color: #fff; }
</style>
<style>
  .settings-header-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: #ecf7ff;
    color: #16659E;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    flex-shrink: 0;
  }

  .settings-tabs-wrapper {
    max-width: 100%;
  }

  .settings-tabs-scroller {
    overflow: hidden;
    max-width: 480px;
  }

  .settings-tabs-track {
    display: flex;
    gap: 0.5rem;
    overflow-x: auto;
    scroll-behavior: smooth;
    scrollbar-width: none;
    padding: 2px;
  }

  .settings-tabs-track::-webkit-scrollbar {
    display: none;
  }

  .settings-tab-pill {
    white-space: nowrap;
    padding: 0.45rem 1rem;
    border-radius: 50rem;
    background: #f1f3f5;
    color: #495057;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all .15s ease;
    flex-shrink: 0;
  }

  .settings-tab-pill:hover {
    background: #e2e6ea;
    color: #212529;
  }

  .settings-tab-pill.active {
    background: #16659E;
    color: #fff;
  }

  .settings-tab-scroll-btn {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1px solid #e2e6ea;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    flex-shrink: 0;
  }

  .settings-tab-scroll-btn:hover {
    background: #f8f9fa;
  }

  @media (max-width: 767px) {
    .settings-tabs-scroller {
      max-width: 220px;
    }
  }
    /* Stat Cards */
  .stat-card {
    border: 1px solid #edf0f3;
    border-radius: 10px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
  }

  .stat-label {
    font-size: .74rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .3px;
    color: #6c757d;
  }

  .stat-value {
    font-size: 1.6rem;
    font-weight: 700;
    color: #212529;
  }

  .stat-sub { font-size: .74rem; }
  .stat-sub-purple { color: #7c3aed; }
  .stat-sub-green  { color: #2b9e5b; }
  .stat-sub-orange { color: #e8590c; }

  .stat-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
  }
  .stat-icon-blue   { background: #ecf7ff; color: #16659E; }
  .stat-icon-purple { background: #f3e8ff; color: #7c3aed; }
  .stat-icon-green  { background: #e6f9ee; color: #2b9e5b; }
  .stat-icon-orange { background: #fff3e0; color: #e8590c; }

  /* Toolbar */
  .toolbar-search-wrap { min-width: 260px; }
  .toolbar-search-wrap .input-group-text,
  .toolbar-search-wrap .form-control {
    background: #fff;
    border-color: #dee2e6;
  }
  .toolbar-search-wrap .form-control:focus {
    box-shadow: none;
    border-color: #16659E;
  }

  .toolbar-select {
    width: auto;
    min-width: 150px;
    font-size: .85rem;
  }

  .toolbar-btn {
    font-size: .85rem;
    font-weight: 500;
    white-space: nowrap;
  }

  .btn-add-material {
    background: #16659E;
    color: #fff;
    border: none;
  }
  .btn-add-material:hover {
    background: #124f7d;
    color: #fff;
  }

  @media (max-width: 767px) {
    .toolbar-search-wrap { min-width: 100%; order: -1; }
  }

  .progress-cement {
    background-color: #16659E;
}

.progress-steel {
    background-color: #6f42c1;
}

.progress-sand {
    background-color: #d4a72c;
}

.progress-concrete {
    background-color: #4dc142;
}
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const expandBtn = document.getElementById('expandAllRatesBtn');
    if (expandBtn) {
        let allExpanded = false;
        expandBtn.addEventListener('click', function () {
            allExpanded = !allExpanded;
            document.querySelectorAll('.rates-panel-row').forEach(row => {
                row.classList.toggle('d-none', !allExpanded);
            });
            document.querySelectorAll('.btn-rates-toggle').forEach(btn => {
                btn.classList.toggle('active', allExpanded);
            });
            expandBtn.innerHTML = allExpanded
                ? '<i class="mdi mdi-chevron-up me-1"></i> Collapse Rates'
                : '<i class="mdi mdi-chevron-down me-1"></i> Expand Rates';
        });
    }

    // TODO: wire these to real routes
    document.getElementById('exportCsvBtn')?.addEventListener('click', () => {
    });
    document.getElementById('bulkImportBtn')?.addEventListener('click', () => {
        // open your bulk-import modal here
    });
    document.getElementById('addMaterialBtn')?.addEventListener('click', () => {
        // open your add-material modal/offcanvas here
    });
});
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev  = document.getElementById('settingsTabPrev');
    const next  = document.getElementById('settingsTabNext');

    if (!track || !prev || !next) return;

    const step = 160;

    // Previous / Next buttons
    prev.addEventListener('click', function () {
        track.scrollBy({
            left: -step,
            behavior: 'smooth'
        });
    });

    next.addEventListener('click', function () {
        track.scrollBy({
            left: step,
            behavior: 'smooth'
        });
    });

    // -------------------------------------------------------
    // Automatically scroll the ACTIVE tab into view
    // -------------------------------------------------------
    const activeTab = track.querySelector('.settings-tab-pill.active');

    if (activeTab) {
        setTimeout(function () {
            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'center'
            });
        }, 100);
    }

});
</script>
<script>
    function toggleWarehouseDropdown(button) {
        const dropdown = button.closest('.settings-tab-dropdown');

        document
            .querySelectorAll('.settings-tab-dropdown')
            .forEach(item => {
                if (item !== dropdown) {
                    item.classList.remove('open');
                }
            });

        dropdown.classList.toggle('open');
    }

    document.addEventListener('click', function (event) {
        if (!event.target.closest('.settings-tab-dropdown')) {
            document
                .querySelectorAll('.settings-tab-dropdown')
                .forEach(item => {
                    item.classList.remove('open');
                });
        }
    });
</script>
@php
    $warehouseTabs = [
        [
            'key' => 'quotation_comparison',
            'label' => 'Quotation Comparison',
            'route' => 'store-purchase.quotation-comparison',
        ],
        [
            'key' => 'receipt_inspect',
            'label' => 'Receipt Inspect (GRN)',
            'route' => 'store-purchase.receipt-inspect',
        ],
        [
            'key' => 'analytical-reports',
            'label' => 'Analytical Report',
            'route' => 'store-purchase.analytical-report',
        ],
    ];

    $currentRoute = Route::currentRouteName();

    $activeTab = match ($currentRoute) {
        'store-purchase.quotation-comparison' => 'quotation_comparison',
        'store-purchase.receipt-inspect' => 'receipt_inspect',
        'store-purchase.analytical-report' => 'analytical-reports',
        default => 'quotation_comparison',
    };
@endphp

<div class="card mb-4">
  <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">
      <div class="settings-header-icon">
        <i class="mdi mdi-package-variant-closed"></i>
      </div>
      <div>
        <h5 class="mb-0 fw-bold">{{ $settingsTitle ?? 'Store & Purchase Management System' }}</h5>
        <small class="text-muted">{{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}</small>
      </div>
    </div>

    <div class="settings-tabs-wrapper d-flex align-items-center">
      <button type="button" class="settings-tab-scroll-btn me-1" id="settingsTabPrev">
        <i class="mdi mdi-chevron-left"></i>
      </button>

      <div class="settings-tabs-scroller">
        <div class="settings-tabs-track" id="warehouseTabScroller"> 
            @foreach ($warehouseTabs as $tab) 
                @if (isset($tab['children'])) 
                    @php 
                        $childActive = collect($tab['children']) ->contains('key', $activeTab); 
                    @endphp 
                    <div class="settings-tab-dropdown"> 
                        <button type="button" class="settings-tab-pill {{ $childActive || $activeTab === $tab['key'] ? 'active' : '' }}" onclick="toggleWarehouseDropdown(this)" > 
                            {{ $tab['label'] }} 
                            <span class="ms-1"> 
                                <i class="mdi mdi-chevron-down"></i> 
                            </span> 
                        </button> 
                        <div class="settings-tab-dropdown-menu"> 
                            @foreach ($tab['children'] as $child) 
                            <a href="{{ Route::has($child['route']) ? route($child['route']) : 'javascript:void(0)' }}" class="settings-tab-dropdown-item {{ $activeTab === $child['key'] ? 'active' : '' }}" > 
                                {{ $child['label'] }} 
                            </a> 
                            @endforeach 
                        </div> 
                    </div> 
                    @else 
                    <a href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}" class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}" > 
                        {{ $tab['label'] }} 
                    </a> 
                @endif 
            @endforeach 
        </div>
      </div>

      <button type="button" class="settings-tab-scroll-btn ms-1" id="settingsTabNext">
        <i class="mdi mdi-chevron-right"></i>
      </button>
    </div>

  </div>
</div>

<div class="card mb-3">
    <div class="card-body p-3 ms-3">

        <div class="d-flex mb-4 gap-2 text-primary">
            <i class="mdi mdi-format-list-bulleted"></i>
            <label class="fw-bold fs-6 text-dark">
                Filter Regional Analytical Scope
            </label>
        </div>

        <div class="d-flex gap-3">
            <div class="d-flex flex-column flex-fill">
                <label class="text-light fw-bold fs-7 mb-1">
                    Region
                </label>

                <select class="form-select border rounded-pill p-2 w-100">
                    <option value="">All Regions (North, South, East, West)</option>
                    <option value="1">South</option>
                    <option value="2">West</option>
                    <option value="3">North</option>
                    <option value="4">East</option>
                </select>
            </div>

            <div class="d-flex flex-column flex-fill">
                <label class="text-light fw-bold fs-7 mb-1">
                    State
                </label>

                <select class="form-select border rounded-pill p-2 w-100">
                    <option value="">All States</option>
                    <option value="1">Tamil Nadu</option>
                </select>
            </div>

            <div class="d-flex flex-column flex-fill">
                <label class="text-light fw-bold fs-7 mb-1">
                    Project Mapping
                </label>

                <select class="form-select border rounded-pill p-2 w-100">
                    <option value="">All Active Construction Project</option>
                    <option value="1">Chennai Metro Phase 2 - Corridor 4</option>
                    <option value="2">Adyar Premium Residences</option>
                    <option value="3">East Coast Elevated Bridge</option>
                    <option value="4">SIPCOT Industrial Park</option>
                    <option value="5">ELCOT IT Park</option>
                </select>
            </div>
        </div>
    </div>
</div>

<div class="d-flex mb-4 gap-3">
    <div class="w-100 h-full bg-white border rounded-3 p-3">
        <div class="mb-3">
            <label class="text-dark fw-bold fs-6">Top Consumed Materials</label>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    OPC 53 Grade Cement
                </label>

                <div class="text-dark fw-semibold fs-8">
                    4,850 Bags
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-cement"
                    role="progressbar"
                    style="width: 85%;"
                    aria-valuenow="85"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    TMT Steel Rebars 12mm
                </label>

                <div class="text-dark fw-semibold fs-8">
                    22 Tons
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-steel"
                    role="progressbar"
                    style="width: 65%;"
                    aria-valuenow="65"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    River Sand (Coarse)
                </label>

                <div class="text-dark fw-semibold fs-8">
                    180 Unit
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-sand"
                    role="progressbar"
                    style="width: 55%;"
                    aria-valuenow="55"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    Ready Mix Concrete M25
                </label>

                <div class="text-dark fw-semibold fs-8">
                    320 Cum 
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-concrete"
                    role="progressbar"
                    style="width: 35%;"
                    aria-valuenow="35"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>
    </div>
    <div class="w-100 h-full bg-white border rounded-3 p-3">
        <div class="mb-3">
            <label class="text-dark fw-bold fs-6">Purchase value breakdown</label>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    Steel & Reinforcements
                </label>

                <div class="text-dark fw-semibold fs-8">
                    ₹14.8 Lakh
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-cement"
                    role="progressbar"
                    style="width: 55%;"
                    aria-valuenow="55"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    Cement & Binding Materials
                </label>

                <div class="text-dark fw-semibold fs-8">
                    ₹8.4 Lakh
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-steel"
                    role="progressbar"
                    style="width: 35%;"
                    aria-valuenow="35"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    Electricals & Plumbing
                </label>

                <div class="text-dark fw-semibold fs-8">
                    ₹2.2 Lakh
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-sand"
                    role="progressbar"
                    style="width: 15%;"
                    aria-valuenow="15"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>

        <div class="d-flex flex-column mb-3">
            <div class="d-flex justify-content-between mb-1">
                <label class="text-light fs-8">
                    Aggregates & Silt
                </label>

                <div class="text-dark fw-semibold fs-8">
                    ₹1.1 Lakh
                </div>
            </div>

            <div class="progress w-100 rounded-pill" style="height: 8px;">
                <div
                    class="progress-bar rounded-pill progress-concrete"
                    role="progressbar"
                    style="width: 10%;"
                    aria-valuenow="10"
                    aria-valuemin="0"
                    aria-valuemax="100">
                </div>
            </div>
        </div>
    </div>
    <div class="w-100 h-full bg-white border rounded-3 p-3">
        <div class="d-flex flex-column mb-6">
            <label class="text-dark fw-bold fs-6">
                <i class="mdi mdi-download text-warning me-2"></i>
                Download Statutory Compliance Records</label>
            <p class="text-light fw-semibold fs-9 mt-2">Compile and package audit files containing location-based prices, driver logs, GST parameters, and material consumption sheets for financial evaluation.</p>
        </div>

        <div class="d-flex flex-column mt-4">
            <div class="border rounded-pill p-2 mb-2">
                <div class="d-flex justify-content-between">
                    <div class="d-flex gap-2">
                        <i class="mdi mdi-file-download text-danger"></i>
                        <label class="fs-8 text-dark">Download Landed Cost Audit (PDF)</label>
                    </div>

                    <div>
                        <i class="mdi mdi-chevron-right"></i>
                    </div>
                </div>
            </div>
            <div class="border rounded-pill p-2 mb-2">
                <div class="d-flex justify-content-between">
                    <div class="d-flex gap-2">
                        <i class="mdi mdi-file-download text-success"></i>
                        <label class="fs-8 text-dark">Export Inventory Reconciliation (XLSX)</label>
                    </div>

                    <div>
                        <i class="mdi mdi-chevron-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleRatesPanel(button, code) {
    const panel = document.getElementById('rates-panel-' + code);
    if (!panel) return;

    const isOpen = !panel.classList.contains('d-none');

    // close every other open panel/button first
    document.querySelectorAll('.rates-panel-row').forEach(row => row.classList.add('d-none'));
    document.querySelectorAll('.btn-rates-toggle').forEach(btn => btn.classList.remove('active'));

    if (!isOpen) {
        panel.classList.remove('d-none');
        button.classList.add('active');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.remove-rate-link').forEach(function (link) {
        link.addEventListener('click', function () {
            const code = this.dataset.code;
            const city = this.dataset.city;
            // TODO: call your delete route, e.g.:
            // axios.delete(`/store-purchase/material/${code}/rate/${city}`).then(() => location.reload());
            console.log('Remove rate', code, city);
        });
    });
});
</script>

@endsection