@extends('layouts/layoutMaster')

@section('title', 'Receipt Inspect')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<style>
    /* =========================================================
       PAGE HEADER
    ========================================================= */

    .settings-header-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: .45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }


    /* =========================================================
       GRN CARDS
    ========================================================= */

    .grn-card {
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        background: #fff;
        margin-bottom: 1rem;
        box-shadow: 0 1px 2px rgba(0, 0, 0, .03);
    }

    .grn-card:hover {
        border-color: #cbd5e1;
    }

    .grn-code {
        background: #eaf4fb;
        color: #16659E;
        font-size: .75rem;
        font-weight: 600;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .po-ref {
        background: #f8f9fa;
        color: #495057;
        font-size: .75rem;
        font-weight: 500;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .status-approved {
        background: #d3f9d8;
        color: #2b8a3e;
        font-size: .75rem;
        font-weight: 600;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .status-pending {
        background: #fff3cd;
        color: #997404;
        font-size: .75rem;
        font-weight: 600;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .quality-damaged {
        background: #ffe3e3;
        color: #c92a2a;
        font-size: .75rem;
        font-weight: 600;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .quality-excellent {
        background: #e6f9ee;
        color: #2b9e5b;
        font-size: .75rem;
        font-weight: 600;
        padding: .4rem .7rem;
        border-radius: 6px;
    }

    .material-name {
        font-size: 1rem;
        font-weight: 700;
        color: #212529;
    }

    .vendor-name {
        font-size: .82rem;
        color: #6c757d;
    }

    .quantity-box {
        background: #f8fbff;
        border: 1px solid #e7f0f7;
        border-radius: 8px;
    }

    .quantity-label {
        font-size: .7rem;
        font-weight: 600;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: .3px;
    }

    .quantity-value {
        font-size: .9rem;
        font-weight: 700;
        color: #212529;
    }

    .accepted-value {
        color: #2b9e5b;
    }

    .rejected-value {
        color: #c92a2a;
    }

    .audit-box {
        background: #fff8e1;
        border: 1px solid #ffe69c;
        border-radius: 8px;
    }

    .audit-title {
        font-size: .8rem;
        font-weight: 600;
        color: #856404;
    }

    .audit-action {
        font-size: .78rem;
        color: #6c757d;
        margin-top: .25rem;
    }

    .inspector {
        font-size: .8rem;
        font-weight: 600;
        color: #495057;
    }

    .logged-date {
        font-size: .75rem;
        color: #6c757d;
        margin-top: .25rem;
    }

    .btn-log-grn {
        background: #16659E;
        color: #fff;
        border: none;
        font-size: .85rem;
        font-weight: 600;
        border-radius: 7px;
    }

    .btn-log-grn:hover {
        background: #124f7d;
        color: #fff;
    }

    .btn-reject {
        background: #fff;
        color: #c92a2a;
        border: 1px solid #c92a2a;
        font-size: .78rem;
        font-weight: 600;
    }

    .btn-reject:hover {
        background: #c92a2a;
        color: #fff;
    }

    .btn-approve {
        background: #2b9e5b;
        color: #fff;
        border: 1px solid #2b9e5b;
        font-size: .78rem;
        font-weight: 600;
    }

    .btn-approve:hover {
        background: #23824b;
        color: #fff;
    }


    /* =========================================================
       GRN INSPECTION MODAL
    ========================================================= */

    .grn-inspection-modal .modal-dialog {
        max-width: 500px;
    }

    .grn-inspection-modal .modal-content {
        border: 0;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 15px 40px rgba(0, 0, 0, .20);
    }

    .grn-inspection-modal .modal-header {
        padding: 17px 20px 14px;
        border-bottom: 1px solid #edf0f3;
        background: #fff;
    }

    .grn-inspection-modal .modal-title {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #27364a;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: .2px;
    }

    .grn-modal-shield {
        color: #16659E;
        font-size: 15px;
    }

    .grn-inspection-modal .btn-close {
        width: 10px;
        height: 15px;
        padding: 10px;
        opacity: .45;
    }

    .grn-inspection-modal .modal-body {
        padding: 16px 20px 18px;
    }

    .grn-field {
        margin-bottom: 15px;
    }

    .grn-field-label {
        display: block;
        margin-bottom: 6px;
        color: #637083;
        font-size: 8px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .35px;
    }

    .grn-inspection-modal .form-control,
    .grn-inspection-modal .form-select {
        min-height: 45px;
        border: 1px solid #dce3eb;
        border-radius: 8px;
        background-color: #fff;
        color: #344054;
        font-size: 11px;
        box-shadow: none;
    }

    .grn-inspection-modal .form-control::placeholder {
        color: #a6afba;
        opacity: 1;
    }

    .grn-inspection-modal .form-control:focus,
    .grn-inspection-modal .form-select:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .08);
    }

    .grn-inspection-modal .form-select {
        padding-right: 30px;
    }

    .grn-inspection-modal textarea.form-control {
        min-height: 52px;
        resize: vertical;
    }

    .grn-inspection-modal .row {
        --bs-gutter-x: 12px;
    }

    .grn-modal-footer {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 8px;
        border-top: 1px solid #edf0f3;
        padding-top: 13px;
        margin-top: 3px;
    }

    .grn-btn-cancel {
        min-height: 30px;
        padding: 5px 15px;
        border: 1px solid #dce3eb;
        border-radius: 8px;
        background: #fff;
        color: #4b5563;
        font-size: 10px;
        font-weight: 600;
    }

    .grn-btn-cancel:hover {
        background: #f8f9fa;
    }

    .grn-btn-submit {
        min-height: 30px;
        padding: 6px 14px;
        border: 1px solid #16659E;
        border-radius: 8px;
        background: #16659E;
        color: #fff;
        font-size: 10px;
        font-weight: 600;
    }

    .grn-btn-submit:hover {
        background: #124f7d;
        border-color: #124f7d;
        color: #fff;
    }

    /* Remove Bootstrap default modal padding difference */
    .grn-inspection-modal .modal-body > .grn-field:last-of-type {
        margin-bottom: 12px;
    }


    /* =========================================================
       RESPONSIVE
    ========================================================= */

    @media (max-width: 767px) {

        .settings-tabs-scroller {
            max-width: 220px;
        }

        .settings-tabs-wrapper {
            width: 100%;
            justify-content: center;
        }

        .grn-card-header {
            flex-direction: column;
        }

        .grn-inspection-modal .modal-dialog {
            max-width: calc(100% - 20px);
            margin: 10px auto;
        }

        .grn-inspection-modal .modal-body {
            padding: 15px;
        }

        .grn-inspection-modal .modal-header {
            padding: 15px;
        }
    }
</style>


@php
    $warehouseTabs = [
        [
            'key' => 'quotation_comparison',
            'label' => 'Quotation Comparison',
            'route' => 'store-purchase.quotation-comparison',
        ],
        [
            'key' => 'receipt_inspect',
            'label' => 'Receipt Inspect (GRN)',
            'route' => 'store-purchase.receipt-inspect',
        ],
        [
            'key' => 'analytical-reports',
            'label' => 'Analytical Report',
            'route' => 'store-purchase.analytical-report',
        ],
    ];

    $currentRoute = Route::currentRouteName();

    $activeTab = match ($currentRoute) {
        'store-purchase.quotation-comparison' => 'quotation_comparison',
        'store-purchase.receipt-inspect' => 'receipt_inspect',
        'store-purchase.analytical-report' => 'analytical-reports',
        default => 'receipt_inspect',
    };
@endphp


<!-- =========================================================
     PAGE HEADER
========================================================= -->

<div class="card mb-4">

    <div class="card-body">

        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">

            <div class="d-flex align-items-center gap-3">

                <div class="settings-header-icon">
                    <i class="mdi mdi-package-variant-closed"></i>
                </div>

                <div>

                    <h5 class="mb-0 fw-bold">
                        {{ $settingsTitle ?? 'Store & Purchase Management System' }}
                    </h5>

                    <small class="text-muted">
                        {{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}
                    </small>

                </div>

            </div>


            <!-- Tabs -->

            <div class="settings-tabs-wrapper d-flex align-items-center">

                <button
                    type="button"
                    class="settings-tab-scroll-btn me-1"
                    id="settingsTabPrev"
                >
                    <i class="mdi mdi-chevron-left"></i>
                </button>


                <div class="settings-tabs-scroller">

                    <div
                        class="settings-tabs-track"
                        id="warehouseTabScroller"
                    >

                        @foreach ($warehouseTabs as $tab)

                            <a
                                href="{{ route($tab['route']) }}"
                                class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}"
                            >
                                {{ $tab['label'] }}
                            </a>

                        @endforeach

                    </div>

                </div>


                <button
                    type="button"
                    class="settings-tab-scroll-btn ms-1"
                    id="settingsTabNext"
                >
                    <i class="mdi mdi-chevron-right"></i>
                </button>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     GRN REGISTRY HEADER
========================================================= -->

<div class="card mb-3">

    <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3 mb-2">

        <div>

            <h5 class="mb-1 fw-bold">
                Goods Receipt Notes (GRN) Registry
            </h5>

            <p class="mb-0 text-muted small">
                Record of incoming supply load dispatches and quality control status
            </p>

        </div>


        <!-- OPEN MODAL BUTTON -->

        <button
            type="button"
            class="btn btn-log-grn border rounded-pill px-3 py-2"
            data-bs-toggle="modal"
            data-bs-target="#grnInspectionModal"
        >

            <i class="bx bx-plus me-1"></i>

            Log Incoming Dispatch (GRN)

        </button>

    </div>

</div>


<!-- =========================================================
     GRN CARD 1
========================================================= -->

<div class="grn-card border rounded-3 bg-white shadow-sm mb-3">

    <div class="p-3">

        <div class="row g-3">

            <div class="col-12 col-lg-10">

                <div class="d-flex flex-wrap align-items-center gap-2 mb-3">

                    <span class="grn-code">
                        GRN-2026-001
                    </span>

                    <span class="po-ref">
                        PO Ref: PO-2026-879
                    </span>

                    <span class="status-approved">
                        Approved
                    </span>

                    <span class="quality-damaged">
                        Quality: Damaged
                    </span>

                </div>


                <div class="material-name mb-1">
                    PAVING BITUMEN 60/70
                </div>

                <div class="vendor-name mb-3">
                    Vendor Supplier: Southern Bitumen & Oil Corp
                </div>


                <div class="quantity-box border rounded-3 p-3 mb-3">

                    <div class="row g-3">

                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Ordered Qty
                            </div>

                            <div class="quantity-value">
                                50 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Received Qty
                            </div>

                            <div class="quantity-value">
                                50 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Accepted Qty
                            </div>

                            <div class="quantity-value accepted-value">
                                48 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Rejected Qty
                            </div>

                            <div class="quantity-value rejected-value">
                                2 Units
                            </div>

                        </div>

                    </div>

                </div>


                <div class="audit-box border rounded-3 p-3">

                    <div class="audit-title">

                        <i class="mdi mdi-alert-circle-outline me-1"></i>

                        Rejection Audited: 2 Drums found leaking during unloading.

                    </div>

                    <div class="audit-action mt-1">
                        Action Triggered: Vendor Return
                    </div>

                </div>

            </div>


            <div class="col-12 col-lg-2">

                <div class="border rounded-3 p-3 bg-light h-100">

                    <div class="inspector mb-2">

                        <label class="d-block text-muted small">
                            Inspector
                        </label>

                        <span class="fw-semibold">
                            K. Subramaniam
                        </span>

                    </div>

                    <hr class="my-3">

                    <div class="inspector">

                        <label class="d-block text-muted small">
                            Logged Date
                        </label>

                        <span class="fw-semibold">
                            2026-07-25
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     GRN CARD 2
========================================================= -->

<div class="grn-card border rounded-3 bg-white shadow-sm mb-3">

    <div class="p-3">

        <div class="row g-3">

            <div class="col-12 col-lg-10">

                <div class="d-flex flex-wrap align-items-center gap-2 mb-3">

                    <span class="grn-code">
                        GRN-2026-002
                    </span>

                    <span class="po-ref">
                        PO Ref: PO-2026-880
                    </span>

                    <span class="status-pending">
                        Pending Inspection
                    </span>

                    <span class="quality-excellent">
                        Quality: Excellent
                    </span>

                </div>


                <div class="material-name mb-1">
                    CEMENT OPC 53 GRADE
                </div>

                <div class="vendor-name mb-3">
                    Vendor Supplier: Apex Cement Industries Ltd
                </div>


                <div class="quantity-box border rounded-3 p-3">

                    <div class="row g-3">

                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Ordered Qty
                            </div>

                            <div class="quantity-value">
                                1500 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Received Qty
                            </div>

                            <div class="quantity-value">
                                1500 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Accepted Qty
                            </div>

                            <div class="quantity-value accepted-value">
                                1500 Units
                            </div>

                        </div>


                        <div class="col-6 col-md-3">

                            <div class="quantity-label">
                                Rejected Qty
                            </div>

                            <div class="quantity-value">
                                0 Units
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-12 col-lg-2">

                <div class="d-flex flex-column gap-2">

                    <button
                        type="button"
                        class="btn btn-reject w-100"
                    >

                        <i class="mdi mdi-close-circle-outline me-1"></i>

                        Reject Audit

                    </button>


                    <button
                        type="button"
                        class="btn btn-approve w-100"
                    >

                        <i class="mdi mdi-check-circle-outline me-1"></i>

                        Approve & Load Stock

                    </button>

                </div>


                <div class="border rounded-3 p-3 bg-light mt-3">

                    <div class="inspector mb-2">

                        <label class="d-block text-muted small">
                            Inspector
                        </label>

                        <span class="fw-semibold">
                            Vignesh Kumar
                        </span>

                    </div>

                    <hr class="my-3">

                    <div class="inspector">

                        <label class="d-block text-muted small">
                            Logged Date
                        </label>

                        <span class="fw-semibold">
                            2026-07-27
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     GRN INSPECTION MODAL
========================================================= -->

<div
    class="modal fade grn-inspection-modal"
    id="grnInspectionModal"
    tabindex="-1"
    aria-labelledby="grnInspectionModalLabel"
    aria-hidden="true"
>

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">


            <!-- =================================================
                 MODAL HEADER
            ================================================== -->

            <div class="modal-header">

                <h5
                    class="modal-title"
                    id="grnInspectionModalLabel"
                >

                    <i class="mdi mdi-shield-check-outline grn-modal-shield"></i>

                    INSPECT &amp; LOG ARRIVING DISPATCH (GRN)

                </h5>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>

            </div>


            <!-- =================================================
                 FORM
            ================================================== -->

            <form
                method="POST"
                action="{{ url('/store-purchase/receipt-inspect') }}"
                id="grnInspectionForm"
            >
                @csrf



                <div class="modal-body">


                    <!-- =========================================
                         DISPATCHED PO
                    ========================================== -->

                    <div class="grn-field">

                        <label
                            for="dispatch_po"
                            class="grn-field-label"
                        >
                            Select Dispatched PO Reference
                        </label>


                        <select
                            name="dispatch_po"
                            id="dispatch_po"
                            class="form-select"
                            required
                        >

                            <option value="">
                                -- Active Dispatched POs --
                            </option>

                            <option value="PO-2026-879">
                                PO-2026-879
                            </option>

                            <option value="PO-2026-880">
                                PO-2026-880
                            </option>

                            <option value="PO-2026-881">
                                PO-2026-881
                            </option>

                        </select>

                    </div>


                    <!-- =========================================
                         RECEIVED / ACCEPTED QUANTITY
                    ========================================== -->

                    <div class="row">

                        <!-- Total Received -->

                        <div class="col-6">

                            <div class="grn-field">

                                <label
                                    for="received_quantity"
                                    class="grn-field-label"
                                >
                                    Total Received Quantity
                                </label>


                                <input
                                    type="number"
                                    name="received_quantity"
                                    id="received_quantity"
                                    class="form-control"
                                    placeholder="Arrived quantity"
                                    min="0"
                                    step="0.01"
                                    required
                                >

                            </div>

                        </div>


                        <!-- Accepted -->

                        <div class="col-6">

                            <div class="grn-field">

                                <label
                                    for="accepted_quantity"
                                    class="grn-field-label"
                                >
                                    Passed / Accepted Quantity
                                </label>


                                <input
                                    type="number"
                                    name="accepted_quantity"
                                    id="accepted_quantity"
                                    class="form-control"
                                    placeholder="Approved quantity"
                                    min="0"
                                    step="0.01"
                                    required
                                >

                            </div>

                        </div>

                    </div>


                    <!-- =========================================
                         QUALITY / REJECTION ACTION
                    ========================================== -->

                    <div class="row">

                        <!-- Quality -->

                        <div class="col-6">

                            <div class="grn-field">

                                <label
                                    for="quality_check"
                                    class="grn-field-label"
                                >
                                    Quality Assessment Check
                                </label>


                                <select
                                    name="quality_check"
                                    id="quality_check"
                                    class="form-select"
                                    required
                                >

                                    <option value="good">
                                        Good (Passed Standard Quality)
                                    </option>

                                    <option value="minor_defect">
                                        Minor Defect
                                    </option>

                                    <option value="major_defect">
                                        Major Defect
                                    </option>

                                    <option value="failed">
                                        Failed Quality Check
                                    </option>

                                </select>

                            </div>

                        </div>


                        <!-- Rejection Action -->

                        <div class="col-6">

                            <div class="grn-field">

                                <label
                                    for="rejection_trigger"
                                    class="grn-field-label"
                                >
                                    Rejected Action Trigger
                                </label>


                                <select
                                    name="rejection_trigger"
                                    id="rejection_trigger"
                                    class="form-select"
                                    required
                                >

                                    <option value="none">
                                        None (Standard pass)
                                    </option>

                                    <option value="vendor_return">
                                        Vendor Return
                                    </option>

                                    <option value="replacement">
                                        Replacement
                                    </option>

                                    <option value="credit_note">
                                        Credit Note
                                    </option>

                                    <option value="dispose">
                                        Dispose
                                    </option>

                                </select>

                            </div>

                        </div>

                    </div>


                    <!-- =========================================
                         REJECTION NOTES
                    ========================================== -->

                    <div class="grn-field">

                        <label
                            for="rejection_notes"
                            class="grn-field-label"
                        >
                            Rejection Auditing Notes
                        </label>


                        <textarea
                            name="rejection_notes"
                            id="rejection_notes"
                            class="form-control"
                            rows="2"
                            placeholder="Elaborate on defect details if any quantity was rejected..."
                        ></textarea>

                    </div>


                    <!-- =========================================
                         MODAL FOOTER
                    ========================================== -->

                    <div class="grn-modal-footer">

                        <button
                            type="button"
                            class="grn-btn-cancel"
                            data-bs-dismiss="modal"
                        >
                            Cancel
                        </button>


                        <button
                            type="submit"
                            class="grn-btn-submit"
                        >
                            Submit GRN to Inspection
                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script>

document.addEventListener('DOMContentLoaded', function () {

    /* =========================================================
       TAB SCROLL
    ========================================================= */

    const track = document.getElementById('warehouseTabScroller');
    const prev = document.getElementById('settingsTabPrev');
    const next = document.getElementById('settingsTabNext');

    if (track && prev && next) {

        const step = 160;


        prev.addEventListener('click', function () {

            track.scrollBy({
                left: -step,
                behavior: 'smooth'
            });

        });


        next.addEventListener('click', function () {

            track.scrollBy({
                left: step,
                behavior: 'smooth'
            });

        });


        const activeTab =
            track.querySelector('.settings-tab-pill.active');


        if (activeTab) {

            setTimeout(function () {

                activeTab.scrollIntoView({
                    behavior: 'smooth',
                    block: 'nearest',
                    inline: 'center'
                });

            }, 100);

        }

    }


    /* =========================================================
       GRN QUANTITY VALIDATION
    ========================================================= */

    const receivedQuantity =
        document.getElementById('received_quantity');

    const acceptedQuantity =
        document.getElementById('accepted_quantity');

    if (receivedQuantity && acceptedQuantity) {

        acceptedQuantity.addEventListener('input', function () {

            const received =
                parseFloat(receivedQuantity.value) || 0;

            const accepted =
                parseFloat(acceptedQuantity.value) || 0;


            if (accepted > received) {

                acceptedQuantity.setCustomValidity(
                    'Accepted quantity cannot be greater than received quantity.'
                );

            } else {

                acceptedQuantity.setCustomValidity('');

            }

        });


        receivedQuantity.addEventListener('input', function () {

            const received =
                parseFloat(receivedQuantity.value) || 0;

            const accepted =
                parseFloat(acceptedQuantity.value) || 0;


            if (accepted > received) {

                acceptedQuantity.setCustomValidity(
                    'Accepted quantity cannot be greater than received quantity.'
                );

            } else {

                acceptedQuantity.setCustomValidity('');

            }

        });

    }


    /* =========================================================
       SHOW / HIDE REJECTION NOTES
    ========================================================= */

    const rejectionTrigger =
        document.getElementById('rejection_trigger');

    const rejectionNotes =
        document.getElementById('rejection_notes');


    if (rejectionTrigger && rejectionNotes) {

        rejectionTrigger.addEventListener('change', function () {

            if (this.value === 'none') {

                rejectionNotes.placeholder =
                    'Elaborate on defect details if any quantity was rejected...';

            } else {

                rejectionNotes.placeholder =
                    'Enter details about the rejected quantity, defect and action taken...';

            }

        });

    }

});

</script>

@endsection
