@extends('layouts/layoutMaster')

@section('title', 'Quotaytion comparison')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<style>

    .settings-header-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: .5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: .45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: .85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: 0;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }

    .po-register-card {
        border: 1px solid #e1e6eb;
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 1px 3px rgba(0, 0, 0, .04);
    }

    .po-register-header {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid #edf0f3;
        background: #fff;
    }

    .po-register-title {
        font-size: .92rem;
        font-weight: 700;
        color: #17202a;
        margin-bottom: 2px;
        text-transform: uppercase;
    }

    .po-register-subtitle {
        font-size: .72rem;
        color: #6c757d;
    }

    .po-count-badge {
        background: #f1f5f9;
        color: #475569;
        border: 1px solid #e2e8f0;
        border-radius: 5px;
        padding: .3rem .55rem;
        font-size: .7rem;
        font-weight: 600;
    }

    .po-table-wrapper {
        width: 100%;
        overflow-x: auto;
    }

    .po-register-table {
        width: 100%;
        min-width: 1050px;
        margin-bottom: 0;
        border-collapse: separate;
        border-spacing: 0;
    }

    .po-register-table thead th {
        background: #f8fafc;
        color: #667085;
        font-size: .62rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: .25px;
        padding: .75rem .75rem;
        border-bottom: 1px solid #e7ebef;
        white-space: nowrap;
        vertical-align: middle;
    }

    .po-register-table tbody td {
        padding: .85rem .75rem;
        font-size: .73rem;
        color: #344054;
        border-bottom: 1px solid #edf0f3;
        vertical-align: middle;
    }

    .po-register-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .po-register-table tbody tr:hover {
        background: #fbfdff;
    }

    .po-ref {
        color: #16659E;
        font-weight: 600;
        text-decoration: none;
        font-size: .72rem;
    }

    .po-ref:hover {
        color: #124f7d;
        text-decoration: underline;
    }

    .po-date {
        color: #667085;
        font-size: .7rem;
        white-space: nowrap;
    }

    .vendor-name {
        font-weight: 600;
        color: #17202a;
        font-size: .73rem;
        white-space: nowrap;
    }

    .material-name {
        color: #17202a;
        font-weight: 700;
        font-size: .72rem;
        margin-bottom: 2px;
    }

    .material-qty {
        color: #667085;
        font-size: .64rem;
        margin-bottom: 1px;
    }

    .material-location {
        color: #7c8a9a;
        font-size: .62rem;
        font-style: italic;
    }

    .po-value {
        color: #008c72;
        font-size: .72rem;
        font-weight: 700;
        white-space: nowrap;
    }

    /* Status badges */

    .po-status {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 5px;
        padding: .32rem .58rem;
        font-size: .62rem;
        font-weight: 600;
        white-space: nowrap;
    }

    .po-status-approved {
        background: #edf7ff;
        color: #1971c2;
        border: 1px solid #cfe8ff;
    }

    .po-status-confirmed {
        background: #eef0ff;
        color: #4c5bd4;
        border: 1px solid #dce0ff;
    }

    .po-status-completed {
        background: #e9fbf1;
        color: #198754;
        border: 1px solid #c8f0da;
    }

    /* Action buttons */

    .po-action-btn {
        border-radius: 6px;
        padding: .3rem .6rem;
        font-size: .62rem;
        font-weight: 500;
        white-space: nowrap;
    }

    .po-action-dispatch {
        background: #f0f8ff;
        border: 1px solid #cfe8ff;
        color: #16659E;
    }

    .po-action-dispatch:hover {
        background: #16659E;
        border-color: #16659E;
        color: #fff;
    }

    .po-action-fulfilled {
        color: #008c72;
        font-size: .65rem;
        font-weight: 600;
        white-space: nowrap;
    }

    .po-action-fulfilled i {
        font-size: .75rem;
    }

    .po-toolbar {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid #edf0f3;
        background: #fff;
    }

    .po-filter {
        min-width: 140px;
        font-size: .75rem;
    }

    .po-export-btn {
        font-size: .72rem;
        white-space: nowrap;
    }

    .po-empty-state {
        display: none;
        text-align: center;
        padding: 3rem 1rem;
        color: #98a2b3;
    }

    .po-empty-state i {
        font-size: 2.5rem;
        display: block;
        margin-bottom: .5rem;
    }

    .po-detail-label {
        font-size: .65rem;
        color: #98a2b3;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: .3px;
    }

    .po-detail-value {
        font-size: .8rem;
        color: #17202a;
        font-weight: 600;
    }

    .po-modal-material-table th {
        font-size: .65rem;
        color: #667085;
        text-transform: uppercase;
        background: #f8fafc;
    }

    .po-modal-material-table td {
        font-size: .72rem;
    }

    /* -------------------------------------------------------
   PO / QUOTATION INNER TABS
------------------------------------------------------- */

.po-inner-tabs-card {
    border: 1px solid #e1e6eb;
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 1px 3px rgba(0, 0, 0, .04);
    overflow: hidden;
}

.po-inner-tabs-header {
    padding: .85rem 1rem;
    border-bottom: 1px solid #edf0f3;
    background: #fff;
}

.po-inner-tabs {
    display: flex;
    align-items: center;
    gap: .5rem;
    flex-wrap: wrap;
}

.po-inner-tab {
    border: 1px solid #e2e6ea;
    background: #f8f9fa;
    color: #667085;
    border-radius: 7px;
    padding: .5rem .9rem;
    font-size: .75rem;
    font-weight: 600;
    cursor: pointer;
    transition: all .15s ease;
    white-space: nowrap;
}

.po-inner-tab:hover {
    background: #f1f5f9;
    color: #344054;
}

.po-inner-tab.active {
    background: #16659E;
    border-color: #16659E;
    color: #fff;
}

.po-inner-tab .tab-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 18px;
    padding: 0 .35rem;
    margin-left: .35rem;
    border-radius: 50rem;
    background: rgba(255,255,255,.2);
    font-size: .62rem;
}

.po-inner-tab:not(.active) .tab-count {
    background: #e9eef3;
    color: #667085;
}

.po-inner-tab-content {
    display: none;
}

.po-inner-tab-content.active {
    display: block;
}

.quotation-board-placeholder {
    padding: 2.5rem 1.5rem;
    text-align: center;
    color: #667085;
}

.quotation-board-placeholder i {
    font-size: 2.5rem;
    color: #16659E;
    margin-bottom: .75rem;
}

.quotation-board-placeholder-title {
    font-size: .9rem;
    font-weight: 700;
    color: #17202a;
    margin-bottom: .25rem;
}

.quotation-board-placeholder-text {
    font-size: .72rem;
    color: #98a2b3;
}

.priority-medium {
    background: #fff3cd;
    color: #997404;
    border: 1px solid #ffe69c;
}

.priority {
    background: #0a5c18;
    color: #fffffe;
    border: 1px solid #0a5c18;
}

.indents {
    border: 1px solid #e2e6ea !important;
    transition: all 0.2s ease;
    cursor: pointer;
}

.indents:hover {
    border-color: #0f649d !important;
    box-shadow: 0 0 0 3px rgba(15, 100, 157, 0.10),
                0 4px 10px rgba(15, 112, 157, 0.12);
    background: #f8fcff;
}

.cost-quotation {
    background: #fffff;
    cursor: pointer;
}

.cost-quotation :hover {
    background: #f3f9ff;
}

</style>

@php
    $warehouseTabs = [
        [
            'key' => 'quotation_comparison',
            'label' => 'Quotation Comparison',
            'route' => 'store-purchase.quotation-comparison',
        ],
        [
            'key' => 'receipt_inspect',
            'label' => 'Receipt Inspect (GRN)',
            'route' => 'store-purchase.receipt-inspect',
        ],
        [
            'key' => 'analytical-reports',
            'label' => 'Analytical Report',
            'route' => 'store-purchase.analytical-report',
        ],
    ];

    $currentRoute = Route::currentRouteName();

    $activeTab = match ($currentRoute) {
        'store-purchase.quotation-comparison' => 'quotation_comparison',
        'store-purchase.receipt-inspect' => 'receipt_inspect',
        'store-purchase.analytical-report' => 'analytical-reports',
        default => 'quotation_comparison',
    };
@endphp


<div class="card mb-4">
    <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
            <div class="settings-header-icon">
                <i class="mdi mdi-package-variant-closed"></i>
            </div>

            <div>
                <h5 class="mb-0 fw-bold">
                    {{ $settingsTitle ?? 'Store & Purchase Management System' }}
                </h5>

                <small class="text-muted">
                    {{ $settingsSubtitle ?? 'Fully automated material procurement lifecycle.' }}
                </small>
            </div>
        </div>


        <div class="settings-tabs-wrapper d-flex align-items-center">
            <button
                type="button"
                class="settings-tab-scroll-btn me-1"
                id="settingsTabPrev">
                <i class="mdi mdi-chevron-left"></i>
            </button>

            <div class="settings-tabs-scroller">
                <div
                    class="settings-tabs-track"
                    id="warehouseTabScroller">
                    @foreach ($warehouseTabs as $tab)
                        <a
                            href="{{ Route::has($tab['route']) ? route($tab['route']) : 'javascript:void(0)' }}"
                            class="settings-tab-pill {{ $activeTab === $tab['key'] ? 'active' : '' }}">
                            {{ $tab['label'] }}
                        </a>
                    @endforeach
                </div>
            </div>

            <button
                type="button"
                class="settings-tab-scroll-btn ms-1"
                id="settingsTabNext">
                <i class="mdi mdi-chevron-right"></i>
            </button>
        </div>
    </div>
</div>

<div class="po-inner-tabs-card mb-4">
    <div class="po-inner-tabs-header">
        <div class="po-inner-tabs">
            <button
                type="button"
                class="po-inner-tab active"
                data-inner-tab="po-register">

                <i class="mdi mdi-file-document-outline me-1"></i>
                PO Register Directory
            </button>

            <button
                type="button"
                class="po-inner-tab"
                data-inner-tab="quotation-board">

                <i class="mdi mdi-compare-horizontal me-1"></i>

                Quotation Comparison Board
                <span class="tab-count">
                    2
                </span>
            </button>
        </div>
    </div>
</div>

<div
        class="po-inner-tab-content active"
        id="po-register">
        <div class="po-register-card mt-3">
            <div class="po-register-header">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                    <div>
                        <div class="po-register-title">
                            Purchase Orders (PO) Register
                        </div>

                        <div class="po-register-subtitle">
                            Official commercial orders issued to vendors for material supply
                        </div>
                    </div>

                    <span
                        class="po-count-badge"
                        id="poCountBadge">
                        3 Issued
                    </span>
                </div>
            </div>

            <div class="po-table-wrapper">
                <table class="table po-register-table">
                    <thead>
                        <tr>
                            <th class="fs-8" style="width: 10%;">
                                PO Ref No
                            </th>

                            <th class="fs-8" style="width: 9%;">
                                PO Date
                            </th>

                            <th class="fs-8" style="width: 18%;">
                                Vendor Partner
                            </th>

                            <th class="fs-8" style="width: 20%;">
                                Material Details
                            </th>

                            <th class="fs-8" style="width: 14%;">
                                Total Value (Landed)
                            </th>

                            <th class="fs-8" style="width: 12%;">
                                Status
                            </th>

                            <th
                                style="width: 14%;"
                                class="text-start fs-8">
                                Actions
                            </th>
                        </tr>
                    </thead>

                    <tbody id="poTableBody">
                        <tr
                            class="po-row"
                            data-status="approved"
                            data-search="po-2026-881 national steel corporation tmt reinforcement steel 16mm chennai metro phase 2 corridor 4">

                            <td>
                                <a
                                    href="#"
                                    class="po-ref"
                                    data-bs-toggle="modal"
                                    data-bs-target="#poDetailsModal"
                                    data-po="PO-2026-880"    
                                >
                                    PO-2026-881
                                </a>
                            </td>

                            <td>
                                <span class="po-date">
                                    2026-07-25
                                </span>
                            </td>

                            <td>
                                <div class="vendor-name">
                                    National Steel Corporation
                                </div>
                            </td>

                            <td>
                                <div class="material-name">
                                    TMT Reinforcement Steel 16mm
                                </div>

                                <div class="material-qty">
                                    25 MT @ ₹62000/MT
                                </div>

                                <div class="material-location">
                                    Chennai Metro Phase 2 - Corridor 4
                                </div>
                            </td>

                            <td>
                                <span class="po-value">
                                    ₹1,829,000
                                </span>
                            </td>

                            <td>
                                <span class="po-status po-status-approved">
                                    Approved
                                </span>
                            </td>

                            <td class="text-start">
                                <button
                                    type="button"
                                    class="btn po-action-btn po-action-dispatch"
                                    data-bs-toggle="modal"
                                    data-bs-target="#log_distance"
                                    data-dispatch="PO-2026-881"
                                >
                                    <i class="mdi mdi-truck-outline me-1"></i>
                                    Log Dispatch Loads
                                </button>
                            </td>
                        </tr>

                        <tr
                            class="po-row"
                            data-status="vendor_confirmed"
                            data-search="po-2026-880 apex cement industries ltd cement opc 53 grade chennai metro phase 2 corridor 4">
                            <td>

                                <a
                                    href="#"
                                    class="po-ref"
                                    data-bs-toggle="modal"
                                    data-bs-target="#poDetailsModal"
                                    data-po="PO-2026-880">

                                    PO-2026-880

                                </a>

                            </td>

                            <td>

                                <span class="po-date">
                                    2026-07-24
                                </span>

                            </td>

                            <td>

                                <div class="vendor-name">
                                    Apex Cement Industries Ltd
                                </div>

                            </td>

                            <td>

                                <div class="material-name">
                                    Cement OPC 53 Grade
                                </div>

                                <div class="material-qty">
                                    1500 BAGS @ ₹400/UNIT
                                </div>

                                <div class="material-location">
                                    Chennai Metro Phase 2 - Corridor 4
                                </div>

                            </td>

                            <td>

                                <span class="po-value">
                                    ₹768,000
                                </span>

                            </td>

                            <td>

                                <span class="po-status po-status-confirmed">
                                    Vendor Confirmed
                                </span>

                            </td>

                            <td class="text-start">
                            </td>
                        </tr>

                        <tr
                            class="po-row"
                            data-status="completed"
                            data-search="po-2026-879 southern bitumen oil corp paving bitumen 60 70 east coast road elevated bridge">
                            <td>
                                <a
                                    href="#"
                                    class="po-ref"
                                    data-bs-toggle="modal"
                                    data-bs-target="#poDetailsModal"
                                    data-po="PO-2026-879">

                                    PO-2026-879
                                </a>
                            </td>

                            <td>
                                <span class="po-date">
                                    2026-07-20
                                </span>
                            </td>

                            <td>
                                <div class="vendor-name">
                                    Southern Bitumen &amp; Oil Corp
                                </div>
                            </td>

                            <td>
                                <div class="material-name">
                                    Paving Bitumen 60/70
                                </div>

                                <div class="material-qty">
                                    50 DRUMS @ ₹8800/UNIT
                                </div>

                                <div class="material-location">
                                    East Coast Road Elevated Bridge
                                </div>
                            </td>

                            <td>
                                <span class="po-value">
                                    ₹519,200
                                </span>
                            </td>

                            <td>
                                <span class="po-status po-status-completed">
                                    Completed
                                </span>
                            </td>

                            <td class="text-start">
                                <span class="po-action-fulfilled">
                                    <i class="mdi mdi-check-circle-outline me-1"></i>
                                    Fulfilled
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div
                    id="poEmptyState"
                    class="po-empty-state">
                    <i class="mdi mdi-file-search-outline"></i>
                    <div class="fw-semibold">
                        No purchase orders found
                    </div>

                    <small>
                        Try changing your search or status filter.
                    </small>
                </div>
            </div>
        </div>
    </div>

    <div class="po-inner-tab-content" id="quotation-board">
        <div class="d-flex gap-3 mt-3">
            <div
                class="card border rounded p-3"
                style="width: 35%; height: 30%">

                <div class="d-flex align-items-center pb-2 border-bottom">
                    <span class="text-primary fw-semibold me-2">
                        1.
                    </span>

                    <label class="text-primary mb-0 fs-7 fw-bold">
                        SELECT OPEN INDENTS
                    </label>
                </div>

                <div class="indents border rounded p-3 mt-3 hover:border-blue-700">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <span class="border rounded text-primary px-2 py-1 text-muted fs-8 fw-semibold">
                            REQ-002
                        </span>
                        <span class="badge priority-medium rounded px-2 py-1">
                            Critical
                        </span>
                    </div>

                    <div class="d-flex flex-column">
                        <label class="fw-bold text-dark fs-6 mb-1">
                            TMT Reinforcement Steel 16mm
                        </label>
                        <span class="fw-bold text-dark fs-8">
                            25 MT
                        </span>
                        <p class="text-muted fs-8 mb-0 mt-1">
                            Chennai Metro Phase 2
                        </p>
                    </div>
                </div>

                <div class="indents border rounded p-3 mt-3">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <span class="border rounded text-primary px-2 py-1 text-muted fs-8 fw-semibold">
                            REQ-003
                        </span>
                        <span class="badge priority-medium rounded px-2 py-1">
                            Medium
                        </span>
                    </div>

                    <div class="d-flex flex-column">
                        <label class="fw-bold text-dark fs-6 mb-1">
                            Paving Bitumen 60/70
                        </label>
                        <span class="fw-bold text-dark fs-8">
                            120 Drums
                        </span>
                        <p class="text-muted fs-8 mb-0 mt-1">
                            East Coast Road Elevated Bridge
                        </p>
                    </div>
                </div>
            </div>

            <div
                class="card border rounded p-3"
                style="width: 64%;">
                <div class="d-flex justify-content-between align-items-start pb-3 border-bottom">
                    <div class="d-flex flex-column">
                        <div class="d-flex align-items-center">
                            <span class="text-primary fw-semibold me-2">
                                2.
                            </span>

                            <label class="text-primary mb-0 fs-7 fw-bold">
                                LANDED COST QUOTATION COMPARISON SHEET
                            </label>
                        </div>
                        <p class="text-muted fs-8 mb-0 mt-0 ms-0">
                            Comparing quotation parameters for
                            <span class="fw-semibold text-dark">
                                120 Drums
                            </span>
                            of
                            <span class="fw-semibold text-dark">
                                Paving Bitumen 60/70
                            </span>
                        </p>
                    </div>

                    <div class="ms-3">
                        <span class="badge bg-light text-secondary border rounded px-2 py-1">
                            HSN: 27132000
                        </span>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="cost-quotation col-12 col-md-6 col-lg-6">
                        <div class="border rounded p-3 mt-3 h-100">
                            <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-3">
                                <div class="d-flex flex-column">
                                    <label class="fw-bold text-dark mb-1">
                                        National Steel Corporation
                                    </label>

                                    <span class="fw-semibold text-muted fs-8">
                                        Vendor rating: 4.5 Stars
                                    </span>
                                </div>

                                <span class="badge priority rounded px-2 py-1">
                                    Lowest Landed Cost Recommendation
                                </span>
                            </div>

                            <div class="d-flex flex-column border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Base Unit Rate:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹62,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Total Base Cost:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹1,550,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Freight & Trans:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹37,500
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Loading Charges:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹20,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <label class="text-muted fw-semibold fs-8">
                                        GST Tax (18%):
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹289,350
                                    </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column">
                                    <label class="text-muted fw-semibold fs-8 mb-1">
                                        Landed Price
                                    </label>

                                    <span class="text-dark fw-bold fs-5">
                                        ₹1,896,850
                                    </span>
                                </div>
                                <span class="btn btn-primary btn-sm rounded-pill px-3">
                                    Selected
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="cost-quotation col-12 col-md-6 col-lg-6">
                        <div class="border rounded p-3 mt-3 h-100">
                            <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-3">
                                <div class="d-flex flex-column">
                                    <label class="fw-bold text-dark mb-1">
                                        National Steel Corporation
                                    </label>

                                    <span class="fw-semibold text-muted fs-8">
                                        Vendor rating: 4.5 Stars
                                    </span>
                                </div>

                                <span class="badge priority rounded px-2 py-1">
                                    Lowest Landed Cost Recommendation
                                </span>
                            </div>

                            <div class="d-flex flex-column border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Base Unit Rate:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹62,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Total Base Cost:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹1,550,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Freight & Trans:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹37,500
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Loading Charges:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹20,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <label class="text-muted fw-semibold fs-8">
                                        GST Tax (18%):
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹289,350
                                    </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column">
                                    <label class="text-muted fw-semibold fs-8 mb-1">
                                        Landed Price
                                    </label>

                                    <span class="text-dark fw-bold fs-5">
                                        ₹1,896,850
                                    </span>
                                </div>
                                <span class="btn btn-primary btn-sm rounded-pill px-3">
                                    Selected
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="cost-quotation col-12 col-md-6 col-lg-6">
                        <div class="border rounded p-3 mt-3 h-100">
                            <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-3">
                                <div class="d-flex flex-column">
                                    <label class="fw-bold text-dark mb-1">
                                        National Steel Corporation
                                    </label>

                                    <span class="fw-semibold text-muted fs-8">
                                        Vendor rating: 4.5 Stars
                                    </span>
                                </div>

                                <span class="badge priority rounded px-2 py-1">
                                    Lowest Landed Cost Recommendation
                                </span>
                            </div>

                            <div class="d-flex flex-column border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Base Unit Rate:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹62,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Total Base Cost:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹1,550,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Freight & Trans:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹37,500
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <label class="text-muted fw-semibold fs-8">
                                        Loading Charges:
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹20,000
                                    </span>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <label class="text-muted fw-semibold fs-8">
                                        GST Tax (18%):
                                    </label>

                                    <span class="text-muted fw-semibold fs-8">
                                        ₹289,350
                                    </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex flex-column">
                                    <label class="text-muted fw-semibold fs-8 mb-1">
                                        Landed Price
                                    </label>

                                    <span class="text-dark fw-bold fs-5">
                                        ₹1,896,850
                                    </span>
                                </div>
                                <span class="btn btn-primary btn-sm rounded-pill px-3">
                                    Selected
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Log Dispatch Load Modal -->
<div
    class="modal fade"
    id="log_distance"
    tabindex="-1"
    aria-labelledby="logDistanceLabel"
    aria-hidden="true"
>
    <div
        class="modal-dialog modal-dialog-centered"
        style="max-width: 500px;"
    >
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header px-4 py-3 border-bottom">
                <h5
                    class="modal-title d-flex align-items-center gap-2 text-uppercase"
                    id="logDistanceLabel"
                >
                    <i class="mdi mdi-truck-outline"></i>
                    Log Dispatch Load Parameters
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body p-4">

                <!-- PO Information -->
                <div
                    class="border rounded-2 border-primary bg-primary-subtle p-3 mb-4"
                >
                    <div class="d-flex flex-column gap-1">
                        <span class="text-muted fs-9">
                            PO-2026-881
                        </span>

                        <label class="text-dark fs-7 fw-bold mb-0">
                            TMT Reinforcement Steel 16mm (25 MT)
                        </label>

                        <span class="text-muted fs-8">
                            Vendor: National Steel Corporation
                        </span>
                    </div>
                </div>

                <!-- 4 Fields Grid -->
                <div class="row g-4">

                    <!-- Vehicle Number -->
                    <div class="col-md-6">
                        <label
                            class="text-dark fs-8 text-uppercase mb-2"
                        >
                            Transit Vehicle Number
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            placeholder="e.g. TN-01-AX-9912"
                        />
                    </div>

                    <!-- Driver Name & Contact -->
                    <div class="col-md-6">
                        <label
                            class="text-dark fs-8 text-uppercase mb-2"
                        >
                            Driver Name & Contact
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            placeholder="e.g. M. Sundar"
                        />
                    </div>

                    <!-- Actual Dispatch Date -->
                    <div class="col-md-6">
                        <label
                            class="text-dark fs-8 text-uppercase mb-2"
                        >
                            Actual Dispatch Date
                        </label>

                        <input
                            type="date"
                            class="form-control"
                            value="2026-09-22"
                        />
                    </div>

                    <!-- Expected Arrival Date -->
                    <div class="col-md-6">
                        <label
                            class="text-dark fs-8 text-uppercase mb-2"
                        >
                            Expected Arrival Date
                        </label>

                        <input
                            type="date"
                            class="form-control"
                            value="2026-09-24"
                        />
                    </div>

                </div>

            </div>

            <!-- Modal Footer -->
            <div
                class="modal-footer px-4 py-3 border-top"
            >

                <button
                    type="button"
                    class="btn btn-light px-4"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="button"
                    class="btn btn-primary px-4"
                >
                    <i class="mdi mdi-truck-outline me-1"></i>
                    Log Dispatch
                </button>

            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const innerTabs =
        document.querySelectorAll('.po-inner-tab');

    const innerTabContents =
        document.querySelectorAll('.po-inner-tab-content');


    innerTabs.forEach(function (tab) {

        tab.addEventListener('click', function () {

            const target =
                this.dataset.innerTab;

            innerTabs.forEach(function (item) {

                item.classList.remove('active');

            });

            innerTabContents.forEach(function (content) {

                content.classList.remove('active');

            });

            this.classList.add('active');


            const targetContent =
                document.getElementById(target);


            if (targetContent) {

                targetContent.classList.add('active');

            }

        });
    });

});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const track = document.getElementById('warehouseTabScroller');
    const prev = document.getElementById('settingsTabPrev');
    const next = document.getElementById('settingsTabNext');

    if (track && prev && next) {

        const step = 160;

        prev.addEventListener('click', function () {

            track.scrollBy({
                left: -step,
                behavior: 'smooth'
            });

        });

        next.addEventListener('click', function () {

            track.scrollBy({
                left: step,
                behavior: 'smooth'
            });

        });


        const activeTab =
            track.querySelector('.settings-tab-pill.active');

        if (activeTab) {

            setTimeout(function () {

                activeTab.scrollIntoView({
                    behavior: 'smooth',
                    block: 'nearest',
                    inline: 'center'
                });

            }, 100);

        }

    }

    const searchInput =
        document.getElementById('poSearchInput');

    const statusFilter =
        document.getElementById('poStatusFilter');

    const rows =
        document.querySelectorAll('.po-row');

    const emptyState =
        document.getElementById('poEmptyState');

    const countBadge =
        document.getElementById('poCountBadge');


    function filterPOs() {

        const search =
            searchInput.value
                .trim()
                .toLowerCase();

        const status =
            statusFilter.value;

        let visibleCount = 0;


        rows.forEach(function (row) {

            const rowSearch =
                row.dataset.search.toLowerCase();

            const rowStatus =
                row.dataset.status;

            const matchesSearch =
                !search ||
                rowSearch.includes(search);

            const matchesStatus =
                !status ||
                rowStatus === status;


            if (matchesSearch && matchesStatus) {

                row.style.display = '';

                visibleCount++;

            } else {

                row.style.display = 'none';

            }

        });


        if (visibleCount === 0) {

            emptyState.style.display = 'block';

        } else {

            emptyState.style.display = 'none';

        }


        countBadge.textContent =
            visibleCount + ' Issued';

    }


    searchInput.addEventListener(
        'input',
        filterPOs
    );

    statusFilter.addEventListener(
        'change',
        filterPOs
    );

    document
        .getElementById('exportPoBtn')
        .addEventListener('click', function () {

            const headers = [
                'PO Ref No',
                'PO Date',
                'Vendor Partner',
                'Material Details',
                'Total Value',
                'Status'
            ];


            const data = [
                [
                    'PO-2026-881',
                    '2026-07-25',
                    'National Steel Corporation',
                    'TMT Reinforcement Steel 16mm',
                    '1829000',
                    'Approved'
                ],
                [
                    'PO-2026-880',
                    '2026-07-24',
                    'Apex Cement Industries Ltd',
                    'Cement OPC 53 Grade',
                    '768000',
                    'Vendor Confirmed'
                ],
                [
                    'PO-2026-879',
                    '2026-07-20',
                    'Southern Bitumen & Oil Corp',
                    'Paving Bitumen 60/70',
                    '519200',
                    'Completed'
                ]
            ];


            const csvRows = [
                headers,
                ...data
            ];


            const csv = csvRows
                .map(function (row) {

                    return row.map(function (value) {

                        return '"' +
                            String(value)
                                .replace(/"/g, '""') +
                            '"';

                    }).join(',');

                })
                .join('\n');


            const blob = new Blob(
                [csv],
                {
                    type: 'text/csv;charset=utf-8;'
                }
            );


            const url =
                URL.createObjectURL(blob);

            const link =
                document.createElement('a');

            link.href = url;
            link.download = 'purchase-orders.csv';

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);

        });

    const poData = {

        'PO-2026-881': {

            ref: 'PO-2026-881',

            date: '2026-07-25',

            vendor:
                'National Steel Corporation',

            project:
                'Chennai Metro Phase 2 - Corridor 4',

            status:
                'Approved',

            statusClass:
                'po-status-approved',

            material:
                'TMT Reinforcement Steel 16mm',

            specification:
                'Fe500 Grade',

            quantity:
                '25 MT',

            unitPrice:
                '₹62,000',

            total:
                '₹1,829,000'

        },


        'PO-2026-880': {

            ref: 'PO-2026-880',

            date: '2026-07-24',

            vendor:
                'Apex Cement Industries Ltd',

            project:
                'Chennai Metro Phase 2 - Corridor 4',

            status:
                'Vendor Confirmed',

            statusClass:
                'po-status-confirmed',

            material:
                'Cement OPC 53 Grade',

            specification:
                '53 Grade',

            quantity:
                '1500 Bags',

            unitPrice:
                '₹400',

            total:
                '₹768,000'

        },


        'PO-2026-879': {

            ref: 'PO-2026-879',

            date: '2026-07-20',

            vendor:
                'Southern Bitumen & Oil Corp',

            project:
                'East Coast Road Elevated Bridge',

            status:
                'Completed',

            statusClass:
                'po-status-completed',

            material:
                'Paving Bitumen 60/70',

            specification:
                'VG-30 Grade',

            quantity:
                '50 Drums',

            unitPrice:
                '₹8,800',

            total:
                '₹519,200'

        }

    };


    document
        .querySelectorAll('.po-ref')
        .forEach(function (link) {

            link.addEventListener('click', function () {

                const poNumber =
                    this.dataset.po;

                const po =
                    poData[poNumber];

                if (!po) return;


                document
                    .getElementById('modalPoRef')
                    .textContent = po.ref;


                document
                    .getElementById('modalPoNumber')
                    .textContent = po.ref;


                document
                    .getElementById('modalPoDate')
                    .textContent = po.date;


                document
                    .getElementById('modalVendor')
                    .textContent = po.vendor;


                document
                    .getElementById('modalProject')
                    .textContent = po.project;


                document
                    .getElementById('modalPoStatus')
                    .innerHTML =
                        `<span class="po-status ${po.statusClass}">
                            ${po.status}
                        </span>`;


                document
                    .getElementById('modalMaterialBody')
                    .innerHTML = `

                        <tr>

                            <td class="fw-semibold">
                                ${po.material}
                            </td>

                            <td>
                                ${po.specification}
                            </td>

                            <td>
                                ${po.quantity}
                            </td>

                            <td>
                                ${po.unitPrice}
                            </td>

                            <td class="text-end fw-semibold">
                                ${po.total}
                            </td>

                        </tr>

                    `;


                document
                    .getElementById('modalTotal')
                    .textContent =
                        po.total;

            });

        });


    document
        .querySelectorAll('[data-dispatch]')
        .forEach(function (button) {

            button.addEventListener('click', function () {

                const po =
                    this.dataset.dispatch;

                alert(
                    'Log Dispatch Loads for ' +
                    po
                );

            });

        });

});
</script>

@endsection
