@extends('layouts.layoutMaster')

@section('title', 'Fuel Reconciliation list - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')



<!-- Page Header -->
<div class="d-flex flex-wrap align-items-center justify-content-start gap-3 mb-4">
    <a href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation  ']) }}"
        class="btn rounded-3 d-flex align-items-center gap-2 px-3">
        <i class="mdi mdi-arrow-left fs-5"></i>
    </a>
    <div>
        <h4 class="fw-semibold mb-1">Fuel Reconciliation Summary
            </h4>
        <p class="text-muted mb-0 small">
            Enter the month and GST calculation details below.
        </p>
    </div>
</div>

    <div class="card border-0 shadow-sm rounded-2 bg-white mb-4">
        <div class="card-body p-3">
            <div class="filter-layout d-flex flex-column flex-xl-row align-items-stretch align-items-xl-center  gap-3">

                {{-- Left Side: Date Filters --}}
                <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2 flex-grow-1">

                   <div class="col-md-4">
                <div class="d-flex align-items-center gap-2">

                    <label
                        for="store_name"
                        class="fw-semibold mb-0 text-nowrap text-secondary">

                        Store Name

                    </label>

                    <select
                        name="store_name"
                        id="store_name"
                        class="form-select">

                        <option value="">All Stores</option>

                        <option value="1">Head Office</option>
                        <option value="4">Cube</option>
                        <option value="5">Central Storage Hub</option>
                        <option value="7">Central Material Warehouse</option>
                        <option value="8">North Zone Steel Warehouse</option>

                        <option value="2">CPRR Site</option>
                        <option value="3">NTRP Site</option>
                        <option value="5">MMRP Site</option>
                        <option value="6">Flyover Store</option>
                        <option value="7">Main Warehouse Store</option>
                        <option value="8">Drainage Materials Store</option>
                        <option value="9">Solar Equipment Store</option>
                        <option value="10">Road Works Store</option>
                        <option value="11">Interior Materials Store</option>
                        <option value="12">Plant Equipment Store</option>
                        <option value="13">IT Infrastructure Store</option>
                        <option value="15">Electrical & Plumbing Store</option>
                    </select>
                </div>   
           </div>

                    <div class="d-flex align-items-center gap-2">

                    <label
                        for="store_name"
                        class="fw-semibold mb-0 text-nowrap text-secondary">
                        Type
                    </label>

                    <select
                        name="type"
                        id="type"
                        class="form-select">

                        <option value="">All Types</option>

                        <option value="1">Petrol</option>
                        <option value="4">Diesel</option>
                        

                    </select>

                </div>
                </div>

                <div class="align-items-center flex-shrink-0 ">
                <a href=""
                    class="btn btn-primary btm-sm rounded-3 d-flex align-items-center gap-2 px-3">
                    <span>Export</span>
                </a>
                </div>
            </div>
        </div>
    </div>


<!-- Table Container -->

<div class="table-responsive">
    <table class="table table-hover align-middle mb-0 fuel-table table-light">
        <tbody>
            {{-- Main Title --}}
            <tr>
                <th
                    colspan="4"
                    class="text-center fw-bold text-primary py-3 ">
                    Fuel Reconciliation Statement
                </th>
            </tr>


            {{-- Project & Type --}}
            <tr class="bg-white">
                <td
                    colspan="2"
                    class="fw-semibold text-dark py-3">
                    Project :
                    <span class="fw-bold">
                        Drainage Materials Store
                    </span>
                </td>
                <td
                    colspan="2"
                    class="text-end fw-semibold text-dark py-3">

                    Type :
                    <span class="fw-bold">
                        Petrol
                    </span>

                </td>

            </tr>


            {{-- Column Headers --}}
            <tr>

                <th
                    class="text-center fw-semibold text-dark"
                    style="min-width: 160px;">

                    Date

                </th>

                <th
                    class="text-end fw-semibold text-dark"
                    style="min-width: 160px;">

                    Received Qty

                </th>

                <th
                    class="text-end fw-semibold  text-dark"
                    style="min-width: 160px;">

                    Returned Qty

                </th>

                <th
                    class="text-end fw-semibold text-dark"
                    style="min-width: 160px;">

                    Balance

                </th>

            </tr>

            


            {{-- Data Row --}}
            <tr>

                <td class="text-center fw-medium text-dark bg-white">
                    12-04-2026
                </td>

                <td class="text-end text-muted bg-white">
                    -
                </td>

                <td class="text-end fw-semibold text-danger bg-white">
                    25.00
                </td>

                <td class="text-end fw-semibold text-danger bg-white">
                    -25.00
                </td>

            </tr>

             <tr>
                <td class="text-center fw-medium text-dark bg-white">
                    12-04-2026
                </td>
                <td class="text-end text-muted bg-white">
                    -
                </td>
                <td class="text-end fw-semibold text-danger bg-white">
                    25.00
                </td>
                <td class="text-end fw-semibold text-danger bg-white">
                    -25.00
                </td>
            </tr>


            {{-- Balance Row --}}
            <tr class="table-light">
                <td class="text-end fw-bold text-dark">
                    Balance
                </td>
                <td class="text-end fw-semibold text-dark">
                    -
                </td>
                <td class="text-end fw-semibold text-danger">
                    25.00
                </td>
                <td class="text-end fw-bold text-danger">
                    -25.00
                </td>
            </tr>
        </tbody>

    </table>

</div>





<!-- Footer Section: Show entries and Pagination -->
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-center p-3 border-top gap-3">

    <!-- Show Entries -->
    <div class="d-flex align-items-center gap-2 small text-muted">
        <span>Show</span>
        <select class="form-select form-select-sm" style="width: auto;">
            <option value="20">20</option>
            <option value="40">40</option>
            <option value="100">100</option>
        </select>
        <span>entries</span>
    </div>

    <!-- Pagination Info & Buttons -->
    <div class="d-flex flex-column flex-sm-row align-items-center gap-3">
        <span class="small text-muted">1 - 12 of 12 entries</span>
        <nav aria-label="Table navigation">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                </li>
                <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">1</a>
                </li>

                <li class="page-item disabled">
                    <a class="page-link" href="#">Next</a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection