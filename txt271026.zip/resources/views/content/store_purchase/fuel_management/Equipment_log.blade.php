@extends('layouts.layoutMaster')

@section('title', 'Equipment Fuel Log - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>
           
            <div>
                <h4 class="mb-1 fw-bold text-primary fs-5">
                    Equipment Fuel Log
                </h4>

                <p class="text-muted mb-0 fs-8">
                    Track bulk diesel and petrol inward entries received across all stores.
                </p>
            </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>

                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_log']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_log' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>

<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-4">

        {{-- Card Header: Title on left, Button on right --}}
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4">
            <div>
                <h5 class="fw-bold mb-1">Equipment Refueling Log</h5>
                <p class="text-muted mb-0" style="font-size: 13px;">
                    Live logs of diesel dispensed to excavators, tippers, generators, and bowsers
                </p>
            </div>
            
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-label-primary rounded-pill px-3 py-2 fw-semibold" style="font-size: 13px;">
                    4 Refuels Logged
                </span>
                {{-- Trigger Button for Modal --}}
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#recordRefuelModal">
                    <i class="mdi mdi-plus-circle-outline"></i> Record Fuel / Refuel
                </button>
            </div>
        </div>

        {{-- Table --}}
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Log Date &amp; Time</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Source Fuel Tank</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Equipment / Vehicle No</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Project Site</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small text-end">Fuel Issued (Liters)</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Issued To Driver</th>
                        <th scope="col" class="fw-semibold text-uppercase text-secondary small">Purpose / Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-medium text-dark" style="white-space: nowrap;">2026-07-27 08:30</td>
                        <td class="text-muted">Main HSD Yard Tank - 01</td>
                        <td>
                            <div class="fw-medium text-dark">EX-CAT-320D</div>
                            <div class="text-muted small">Heavy Excavator</div>
                        </td>
                        <td class="text-muted">NH Highway Roadwork Sector A</td>
                        <td class="text-end fw-semibold text-dark">180 L</td>
                        <td class="text-muted">M. Senthil</td>
                        <td class="text-muted">Earthmoving &amp; Trenching</td>
                    </tr>

                    <tr>
                        <td class="fw-medium text-dark" style="white-space: nowrap;">2026-07-26 16:15</td>
                        <td class="text-muted">Mobile Bowser Tank - SRK-08</td>
                        <td>
                            <div class="fw-medium text-dark">TKR-TN-09-551</div>
                            <div class="text-muted small">Tipper Truck 10 Wheeler</div>
                        </td>
                        <td class="text-muted">NH Highway Roadwork Sector A</td>
                        <td class="text-end fw-semibold text-dark">120 L</td>
                        <td class="text-muted">P. Arumugam</td>
                        <td class="text-muted">Aggregate Haulage</td>
                    </tr>

                    <tr>
                        <td class="fw-medium text-dark" style="white-space: nowrap;">2026-07-26 11:45</td>
                        <td class="text-muted">Generator Reserve Tank - Flyover Site</td>
                        <td>
                            <div class="fw-medium text-dark">GEN-350KVA-02</div>
                            <div class="text-muted small">Diesel Generator</div>
                        </td>
                        <td class="text-muted">Flyover Pier Construction Yard</td>
                        <td class="text-end fw-semibold text-dark">250 L</td>
                        <td class="text-muted">Gen Operator</td>
                        <td class="text-muted">Night Shift Concrete Batching</td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>



<div class="modal fade" id="recordRefuelModal" tabindex="-1" aria-labelledby="recordRefuelModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            
            {{-- Modal Header --}}
            <div class="modal-header bg-primary" >
                <h5 class="modal-title fw-bold text-white" id="recordRefuelModalLabel">
                    Record Equipment Refueling / Dispense
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            {{-- Modal Body (Form) --}}
            <div class="modal-body">
                <form>
                    {{-- Select Source Fuel Tank --}}
                    <div class="mb-3">
                        <label for="sourceTank" class="form-label fw-semibold">Select Source Fuel Tank</label>
                        <select class="form-select" id="sourceTank">
                            <option selected disabled>Choose a tank...</option>
                            <option value="1">Main HSD Yard Tank - 01 (Available: 17746 L)</option>
                            <option value="2">Mobile Bowser Tank - SRK-08 (Available: 5000 L)</option>
                            <option value="3">Generator Reserve Tank - Flyover Site (Available: 2000 L)</option>
                        </select>
                    </div>

                    {{-- Equipment / Vehicle No --}}
                    <div class="mb-3">
                        <label for="equipmentNo" class="form-label fw-semibold">Equipment / Vehicle No <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="equipmentNo" placeholder="e.g. EX-CAT-320D" required>
                    </div>

                    {{-- Liters Issued --}}
                    <div class="mb-3">
                        <label for="litersIssued" class="form-label fw-semibold">Liters Issued <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="litersIssued" placeholder="e.g. 150" required>
                    </div>

                    {{-- Equipment Type --}}
                    <div class="mb-3">
                        <label for="equipmentType" class="form-label fw-semibold">Equipment Type</label>
                        <select class="form-select" id="equipmentType">
                            <option selected disabled>Select Type...</option>
                            <option value="heavy_excavator">Heavy Excavator</option>
                            <option value="tipper_truck">Tipper Truck 10 Wheeler</option>
                            <option value="diesel_generator">Diesel Generator</option>
                            <option value="mobile_bowser">Mobile Bowser</option>
                        </select>
                    </div>

                    {{-- Driver / Operator Name --}}
                    <div class="mb-3">
                        <label for="driverName" class="form-label fw-semibold">Driver / Operator Name</label>
                        <input type="text" class="form-control" id="driverName" placeholder="e.g. M. Senthil">
                    </div>

                    {{-- Project Site --}}
                    <div class="mb-3">
                        <label for="projectSite" class="form-label fw-semibold">Project Site</label>
                        <input type="text" class="form-control" id="projectSite" placeholder="e.g. Chennai Metro Phase 2 - Corridor 4">
                    </div>

                </form>
            </div>

            {{-- Modal Footer (Buttons) --}}
            <div class="modal-footer">
                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary">Deduct &amp; Issue Fuel</button>
            </div>

        </div>
    </div>
</div>
<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>

@endsection