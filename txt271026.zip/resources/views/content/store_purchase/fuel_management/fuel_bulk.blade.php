@extends('layouts.layoutMaster')

@section('title', 'Fuel Bulk Inward Ledger - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>
           
            <div>
                <h4 class="mb-1 fw-bold text-primary fs-5">
                    Fuel Bulk Inward Ledger
                </h4>

                <p class="text-muted mb-0 fs-8">
                    Track bulk diesel and petrol inward entries received across all stores.
                </p>
            </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>
                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>

{{-- BULK DIESEL INWARD RECORDS CARD --}}
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-4">

        {{-- Card Header: Title on left, Badge on right --}}
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4">
            <div>
                <h5 class="fw-bold mb-1 text-uppercase" style="font-size: 16px;">Bulk Fuel Delivery Inward Records</h5>
                <p class="text-muted mb-0" style="font-size: 13px;">Inward receipts from oil marketing companies (IOCL / HPCL / BPCL)</p>
            </div>
            
            {{-- Density Verified Safe Badge --}}
            <span class="badge bg-label-success rounded-pill px-3 py-2 d-flex align-items-center gap-1">
                <i class="mdi mdi-check-circle-outline"></i> Density Verified Safe
            </span>
        </div>

        {{-- Stats Row: 3 Equal Columns --}}
        <div class="row g-3">
            
            {{-- Stat Box 1: Total Diesel Consumed --}}
            <div class="col-md-4">
                <div class="border rounded-3 p-4 h-100">
                    <div class="text-uppercase text-muted fw-semibold mb-2" style="font-size: 11px; letter-spacing: 0.5px;">
                        Total Diesel Consumed (This Month)
                    </div>
                    <div class="fw-bold text-dark mb-2" style="font-size: 24px;">
                        14,850 Liters
                    </div>
                    <div class="text-success d-flex align-items-center" style="font-size: 13px;">
                        <i class="mdi mdi-arrow-up-short fs-6"></i> 4.2% efficiency vs last month
                    </div>
                </div>
            </div>

            {{-- Stat Box 2: Average Diesel Cost Rate --}}
            <div class="col-md-4">
                <div class="border rounded-3 p-4 h-100">
                    <div class="text-uppercase text-muted fw-semibold mb-2" style="font-size: 11px; letter-spacing: 0.5px;">
                        Average Diesel Cost Rate
                    </div>
                    <div class="fw-bold text-dark mb-2" style="font-size: 24px;">
                        ₹92.40 / Liter
                    </div>
                    <div class="text-muted" style="font-size: 13px;">
                        Central OMC Bulk Rate
                    </div>
                </div>
            </div>

            {{-- Stat Box 3: Tank Capacity Reserve --}}
            <div class="col-md-4">
                <div class="border rounded-3 p-4 h-100">
                    <div class="text-uppercase text-muted fw-semibold mb-2" style="font-size: 11px; letter-spacing: 0.5px;">
                        Tank Capacity Reserve
                    </div>
                    <div class="fw-bold text-dark mb-2" style="font-size: 24px;">
                        25,550 / 41,000 L
                    </div>
                    <div class="text-muted" style="font-size: 13px;">
                        62% total storage filled
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>

@endsection