@extends('layouts.layoutMaster')

@section('title', 'Fuel Purchase Entry - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                    Fuel Purchase Entry List
                </h4>

                   <p class="text-muted mb-0 fs-8">
                    Track revenue, expenses, and net profit/loss for the selected period.
                </p>
              </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>
                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>

<div class="card rounded-2 shadow-0">
    <div class="card-body">

        <div class="row g-3 align-items-end">

            <!-- Store Name -->
            <div class="col-md-3">
                <label for="store_name" class="form-label fw-semibold">
                    Store Name
                </label>

                <select name="store_name" id="store_name" class="form-select">
                    <option value="">Select</option>

                    <option value="1">Head Office</option>
                    <option value="4">cube</option>
                    <option value="5">Central Storage Hub</option>
                    <option value="7">Central Material Warehouse</option>
                    <option value="8">North Zone Steel Warehouse</option>

                    <option value="2">CPRR Site</option>
                    <option value="3">NTRP Site</option>
                    <option value="5">MMRP Site</option>
                    <option value="6">Flyover store</option>
                    <option value="7">Main Warehouse Store</option>
                    <option value="8">Drainage Materials Store</option>
                    <option value="9">Solar Equipment Store</option>
                    <option value="10">Road Works Store</option>
                    <option value="11">Interior Materials Store</option>
                    <option value="12">Plant Equipment Store</option>
                    <option value="13">IT Infrastructure Store</option>
                    <option value="15">Electrical & Plumbing Store</option>
                </select>
            </div>

            <!-- Fuel Type -->
            <div class="col-md-3">
                <label for="fuel_type" class="form-label fw-semibold">
                    Fuel Type
                </label>

                <select name="fuel_type" id="fuel_type" class="form-select">
                    <option value="">Select</option>
                    <option value="petrol">Petrol</option>
                    <option value="diesel">Diesel</option>
                </select>
            </div>

            <!-- From Date -->
            <div class="col-md-2">
                <label for="from_date" class="form-label fw-semibold">
                    From Date
                </label>

                <input
                    type="date"
                    name="from_date"
                    id="from_date"
                    class="form-control"
                >
            </div>

            <!-- To Date -->
            <div class="col-md-2">
                <label for="to_date" class="form-label fw-semibold">
                    To Date
                </label>

                <input
                    type="date"
                    name="to_date"
                    id="to_date"
                    class="form-control"
                >
            </div>

            <!-- Buttons -->
            <div class="col-md-2">
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-secondary">
                        Reset
                    </button>

                    <button type="submit" class="btn btn-primary">
                        Search
                    </button>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="card mt-3 border rounded-2">
    <div class="card-body  ">
        <!-- Table Header -->
        <div class="d-flex justify-content-between align-items-center mb-3 ">
            <div>
                <h5 class="mb-1 fw-bold">Fuel Entry List</h5>
                <p class="text-muted mb-0">
                    Manage fuel entries and consumption details
                </p>
            </div>

            <button type="button" class="btn btn-primary"
                    data-bs-toggle = "modal"
                    data-bs-target = "#createFuelEntry">
                <i class="mdi mdi-plus me-1"></i>
                Create Fuel Entry
            </button>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="fw-semibold text-secondary" style="min-width: 120px;">
                            Date
                        </th>

                        <th class="fw-semibold text-secondary" style="min-width: 300px;">
                            Store
                        </th>

                        <th class="fw-semibold text-secondary" style="min-width: 120px;">
                            Type
                        </th>

                        <th class="fw-semibold text-secondary text-end" style="min-width: 120px;">
                            Quantity
                        </th>

                        <th class="fw-semibold text-secondary text-end" style="min-width: 130px;">
                            Rate
                        </th>

                        <th class="fw-semibold text-secondary text-end" style="min-width: 150px;">
                            Total Rate
                        </th>
                    </tr>
                </thead>

                <tbody>

                    <!-- Fuel Entry Row 1 -->
                    <tr>
                        <td>22-09-2026</td>
                        <td>North Zone Steel Warehouse</td>
                        <td>Diesel</td>
                        <td class="text-end">22</td>
                        <td class="text-end">3,333.00</td>
                        <td class="text-end">73,326.00</td>
                    </tr>

                    <!-- Fuel Entry Row 2 -->
                    <tr>
                        <td>01-06-2026</td>
                        <td>North Zone Steel Warehouse</td>
                        <td>Petrol</td>
                        <td class="text-end">50</td>
                        <td class="text-end">5,100.00</td>
                        <td class="text-end">2,55,000.00</td>
                    </tr>

                    <!-- Fuel Entry Row 3 -->
                    <tr>
                        <td>10-04-2026</td>
                        <td>Drainage Materials Store</td>
                        <td>Petrol</td>
                        <td class="text-end">75</td>
                        <td class="text-end">100.00</td>
                        <td class="text-end">7,500.00</td>
                    </tr>

                    <!-- Fuel Entry Row 4 -->
                    <tr>
                        <td>01-04-2026</td>
                        <td>Main Warehouse Store</td>
                        <td>Diesel</td>
                        <td class="text-end">1,000</td>
                        <td class="text-end">1,00,000.00</td>
                        <td class="text-end">10,00,00,000.00</td>
                    </tr>

                    <!-- Fuel Entry Row 5 -->
                    <tr>
                        <td>17-03-2026</td>
                        <td>Head Office</td>
                        <td>Petrol</td>
                        <td class="text-end">45</td>
                        <td class="text-end">3,750.00</td>
                        <td class="text-end">1,68,750.00</td>
                    </tr>

                    <!-- Total -->
                    <tr class="table-light">
                        <td></td>
                        <td class="fw-semibold">Fuel Entry Total</td>
                        <td></td>
                        <td class="text-end fw-semibold">1,242</td>
                        <td class="text-end fw-semibold">—</td>
                        <td class="text-end fw-semibold">10,04,94,576.00</td>
                    </tr>

                </tbody>

            </table>
        </div>
    </div>
</div>


<div class="modal fade" id="createFuelEntry" tabindex="-1" aria-labelledby="createFuelEntryLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header bg-primary">
                <h5 class="modal-title fw-bold text-white p-2" id="createFuelEntryLabel">
                    Create Fuel Entry
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body">

                <div class="row g-3">

                    <!-- Store Name -->
                    <div class="col-md-6">
                        <label for="fuel_store_name" class="form-label fw-semibold">
                            Store Name <span class="text-danger">*</span>
                        </label>

                        <select name="store_name"
                                id="fuel_store_name"
                                class="form-select"
                                required>

                            <option value="">Select</option>

                            <option value="warehouse_1">
                                Head Office
                            </option>

                            <option value="warehouse_4">
                                cube
                            </option>

                            <option value="warehouse_5">
                                Central Storage Hub
                            </option>

                            <option value="warehouse_7">
                                Central Material Warehouse
                            </option>

                            <option value="warehouse_8">
                                North Zone Steel Warehouse
                            </option>

                            <option value="site_2">
                                CPRR Site
                            </option>

                            <option value="site_3">
                                NTRP Site
                            </option>

                            <option value="site_5">
                                MMRP Site
                            </option>

                            <option value="site_6">
                                Flyover store
                            </option>

                            <option value="site_7">
                                Main Warehouse Store
                            </option>

                            <option value="site_8">
                                Drainage Materials Store
                            </option>

                            <option value="site_9">
                                Solar Equipment Store
                            </option>

                            <option value="site_10">
                                Road Works Store
                            </option>

                            <option value="site_11">
                                Interior Materials Store
                            </option>

                            <option value="site_12">
                                Plant Equipment Store
                            </option>

                            <option value="site_13">
                                IT Infrastructure Store
                            </option>

                            <option value="site_15">
                                Electrical & Plumbing Store
                            </option>

                        </select>
                    </div>

                    <!-- Date -->
                    <div class="col-md-6">
                        <label for="fuel_date" class="form-label fw-semibold">
                            Date <span class="text-danger">*</span>
                        </label>

                        <input type="date"
                               name="date"
                               id="fuel_date"
                               class="form-control"
                               required>
                    </div>

                    <!-- Type -->
                    <div class="col-md-6">
                        <label for="fuel_type" class="form-label fw-semibold">
                            Type <span class="text-danger">*</span>
                        </label>

                        <select name="fuel_type"
                                id="fuel_type"
                                class="form-select"
                                required>

                            <option value="">Select Type</option>
                            <option value="diesel">Diesel</option>
                            <option value="petrol">Petrol</option>

                        </select>
                    </div>

                    <!-- Quantity -->
                    <div class="col-md-6">
                        <label for="fuel_quantity" class="form-label fw-semibold">
                            Quantity <span class="text-danger">*</span>
                        </label>

                        <input type="number"
                               name="quantity"
                               id="fuel_quantity"
                               class="form-control"
                               placeholder="Enter quantity"
                               min="0"
                               step="0.01"
                               required>
                    </div>

                    <!-- Rate -->
                    <div class="col-md-6">
                        <label for="fuel_rate" class="form-label fw-semibold">
                            Rate <span class="text-danger">*</span>
                        </label>

                        <input type="number"
                               name="rate"
                               id="fuel_rate"
                               class="form-control"
                               placeholder="Enter rate"
                               min="0"
                               step="0.01"
                               required>
                    </div>

                    <!-- Total Rate -->
                    <div class="col-md-6">
                        <label for="fuel_total_rate" class="form-label fw-semibold">
                            Total Rate
                        </label>

                        <input type="text"
                               id="fuel_total_rate"
                               class="form-control"
                               placeholder="0.00"
                               readonly>
                    </div>

                </div>

            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">

                <button type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="submit"
                        class="btn btn-primary">
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Fuel Entry
                </button>

            </div>

        </div>
    </div>
</div>
<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection