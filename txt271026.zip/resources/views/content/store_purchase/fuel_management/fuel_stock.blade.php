@extends('layouts.layoutMaster')

@section('title', 'Fuel Stock - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

              <div>
                  <h4 class="mb-1 fw-bold text-primary fs-5">
                    Fuel Stock List
                </h4>

                   <p class="text-muted mb-0 fs-8">
                    Track revenue, expenses, and net profit/loss for the selected period.
                </p>
              </div>

          </div>


          {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>
                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_log']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_log' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>

<div class="card rounded-2 p-3">
    <div class="row g-3 align-items-end">

        {{-- Search --}}
        <div class="col-md-3">
            <div class="position-relative">
                <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                    style="pointer-events: none;">
                    <i class="mdi mdi-magnify fs-5"></i>
                </span>

                <input id="hr-search-field"
                    type="text"
                    placeholder="Search store, diesel, petrol"
                    class="form-control ps-7 bg-light border-0 rounded-3 text-secondary" />
            </div>
        </div>

        {{-- Store Name --}}
        <div class="col-md-4">
            <div class="d-flex align-items-center gap-2">

                <label for="store_name" class="fw-semibold mb-0 text-nowrap">
                    Store Name
                </label>

                <select name="store_name"
                    id="store_name"
                    class="form-select">

                    <option value="">Select</option>

                    <option value="1">Head Office</option>
                    <option value="4">cube</option>
                    <option value="5">Central Storage Hub</option>
                    <option value="7">Central Material Warehouse</option>
                    <option value="8">North Zone Steel Warehouse</option>

                    <option value="2">CPRR Site</option>
                    <option value="3">NTRP Site</option>
                    <option value="5">MMRP Site</option>
                    <option value="6">Flyover store</option>
                    <option value="7">Main Warehouse Store</option>
                    <option value="8">Drainage Materials Store</option>
                    <option value="9">Solar Equipment Store</option>
                    <option value="10">Road Works Store</option>
                    <option value="11">Interior Materials Store</option>
                    <option value="12">Plant Equipment Store</option>
                    <option value="13">IT Infrastructure Store</option>
                    <option value="15">Electrical & Plumbing Store</option>

                </select>

            </div>
        </div>



        {{-- Add Fuel Entry --}}
        <div class="col-md-5 d-flex justify-content-end">
            <button type="button"
                class="btn btn-primary"
                data-bs-toggle="modal"
                data-bs-target="#addFuelEntryModal">
                <i class="mdi mdi-plus me-1"></i>
                Add Fuel Entry
            </button>
        </div>

    </div>
</div>

<div class="card rounded-2 shadow-0 mt-4">
    <div class="card-body p-3">
        {{-- Table --}}
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="fw-semibold text-secondary">
                            Store
                        </th>

                        <th class="fw-semibold text-secondary text-end">
                            Diesel
                        </th>

                        <th class="fw-semibold text-secondary text-end">
                            Petrol
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td class="fw-semibold text-dark">
                            Head Office
                        </td>

                        <td class="text-end">
                            35
                        </td>

                        <td class="text-end">
                            75
                        </td>
                    </tr>

                    <tr>
                        <td class="fw-semibold text-dark">
                            North Zone Steel Warehouse
                        </td>

                        <td class="text-end">
                            22
                        </td>

                        <td class="text-end text-danger">
                            -45
                        </td>
                    </tr>

                    <tr>
                        <td class="fw-semibold text-dark">
                            Main Warehouse Store
                        </td>

                        <td class="text-end">
                            900
                        </td>

                        <td class="text-end">
                            0
                        </td>
                    </tr>
                </tbody>

            </table>
        </div>

    </div>
</div>


{{-- Add Fuel Entry Modal --}}
<div
    class="modal fade"
    id="addFuelEntryModal"
    tabindex="-1"
    aria-labelledby="addFuelEntryModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-2">

            {{-- Modal Header --}}
            <div class="modal-header bg-primary">
                <h5 class="modal-title fw-semibold text-white" id="addFuelEntryModalLabel">
                    Add Fuel Entry
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            {{-- Modal Body --}}
            <div class="modal-body">

                <form>
                    @csrf

                    {{-- Store --}}
                    <div class="mb-3">
                        <label for="store" class="form-label fw-semibold text-secondary">
                            Store
                        </label>

                        <select
                            name="store"
                            id="store"
                            class="form-select"
                            required
                        >
                            <option value="">Select Store</option>

                            <option value="head_office">
                                Head Office
                            </option>

                            <option value="north_zone_steel_warehouse">
                                North Zone Steel Warehouse
                            </option>

                            <option value="main_warehouse_store">
                                Main Warehouse Store
                            </option>
                        </select>
                    </div>


                    {{-- Fuel Type --}}
                    <div class="mb-3">
                        <label for="fuel_type" class="form-label fw-semibold text-secondary">
                            Fuel Type
                        </label>

                        <select
                            name="fuel_type"
                            id="fuel_type"
                            class="form-select"
                            required
                        >
                            <option value="">Select Fuel Type</option>
                            <option value="diesel">Diesel</option>
                            <option value="petrol">Petrol</option>
                        </select>
                    </div>


                    {{-- Quantity --}}
                    <div class="mb-3">
                        <label for="quantity" class="form-label fw-semibold text-secondary">
                            Quantity
                        </label>

                        <input
                            type="number"
                            name="quantity"
                            id="quantity"
                            class="form-control"
                            placeholder="Enter quantity"
                            min="0"
                            step="0.01"
                            required
                        >
                    </div>

                </form>

            </div>

            {{-- Modal Footer --}}
            <div class="modal-footer">
                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    form="addFuelEntryForm"
                    class="btn btn-primary"
                >
                    Add Entry
                </button>
            </div>

        </div>
    </div>
</div>


<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>
@endsection