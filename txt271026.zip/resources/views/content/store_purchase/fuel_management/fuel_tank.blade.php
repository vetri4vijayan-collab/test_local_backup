@extends('layouts.layoutMaster')

@section('title', 'Fuel Purchase Entry - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')


<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

             
                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-5">
                        Fuel Tanks & Level Gauges
                    </h4>

                    <p class="text-muted mb-0 fs-8">
                        Monitor fuel tank capacity, current levels, and available diesel and petrol stock.
                    </p>
                </div>



          </div>


           {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>

                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_log']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_log' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>



{{-- Fuel Tank Filter Section --}}
<div class="card border-0 shadow-sm rounded-3 mb-3">

    <div class="card-body p-3">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">

            {{-- Left Side: Search + Type --}}
            <div class="d-flex flex-column flex-sm-row align-items-sm-end gap-3">

                {{-- Search --}}
                <div>

                    <div class="position-relative">

                        <span
                            class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events: none;">

                            <i class="mdi mdi-magnify fs-5"></i>

                        </span>

                        <input
                            type="text"
                            id="tank_search"
                            class="form-control ps-7"
                            style="min-width: 250px;"
                            placeholder="Search tank or location">

                    </div>

                </div>


                {{-- Type --}}
                <div class="d-flex align-items-center gap-2">

                    <label
                        for="tank_type"
                        class="form-label fw-semibold text-secondary mb-0 text-nowrap">

                        Type

                    </label>

                    <select
                        name="fuel_type"
                        id="tank_type"
                        class="form-select"
                        style="min-width: 150px;">

                        <option value="">
                            All Types
                        </option>

                      

                        <option value="Petrol">
                            Petrol
                        </option>

                        <option value="Engine">
                            Engine
                        </option>

                    </select>

                </div>

            </div>


            {{-- Right Side: Add Tank --}}
            <div class="flex-shrink-0">

                <button
                    type="button"
                    class="btn btn-primary rounded-3"
                    data-bs-toggle="modal"
                    data-bs-target="#addFuelTankModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Add Tank

                </button>

            </div>

        </div>

    </div>

</div>


<div class="table-responsive">

    <table class="table table-hover table-striped align-middle mb-0">

        <thead class="table-light">

            <tr>

                <th class="fw-semibold text-uppercase text-secondary small">
                    Tank ID
                </th>

                <th class="fw-semibold text-uppercase text-secondary small">
                    Tank Name
                </th>

                <th class="fw-semibold text-uppercase text-secondary small">
                    Location
                </th>

                <th class="fw-semibold text-uppercase text-secondary small">
                    Type
                </th>

                <th class="fw-semibold text-uppercase text-secondary small text-end">
                    Tank Level
                </th>

                <th class="fw-semibold text-uppercase text-secondary small text-end">
                    Capacity
                </th>

                <th class="fw-semibold text-uppercase text-secondary small">
                    Refilled Date
                </th>

                <th class="fw-semibold text-uppercase text-secondary small text-center">
                    Status
                </th>

            </tr>

        </thead>


        <tbody>

            {{-- Tank 01 --}}
            <tr>

                <td class="fw-semibold text-primary">
                    TNK-01
                </td>

                <td class="fw-medium text-dark">
                    Main HSD Yard Tank - 01
                </td>

                <td class="text-muted">
                    Chennai Central Yard
                </td>

                <td>
                    <span class="badge bg-light text-dark">
                        HSD
                    </span>
                </td>

                <td class="text-end">

                    <div class="fw-semibold text-dark">
                        18,400 L
                    </div>

                    <div class="progress mt-1"
                         style="height: 6px; min-width: 100px;">

                        <div
                            class="progress-bar bg-success"
                            role="progressbar"
                            style="width: 74%;"
                            aria-valuenow="74"
                            aria-valuemin="0"
                            aria-valuemax="100">
                        </div>

                    </div>

                    <small class="text-success fw-semibold">
                        74%
                    </small>

                </td>

                <td class="text-end text-muted">
                    25,000 L
                </td>

                <td class="text-muted">
                    24-07-2026
                </td>

                <td class="text-center">

                    <span class="badge rounded-pill bg-success-subtle text-success">
                        <i class="mdi mdi-check-circle-outline me-1"></i>
                        Optimal
                    </span>

                </td>

            </tr>

            {{-- Tank 02 --}}
            <tr>

                <td class="fw-semibold text-primary">
                    TNK-02
                </td>

                <td class="fw-medium text-dark">
                    Mobile Bowser Tank - SRK-08
                </td>

                <td class="text-muted">
                    NH-45 Highway Project Site
                </td>

                <td>
                    <span class="badge bg-light text-dark">
                        HSD
                    </span>
                </td>

                <td class="text-end">

                    <div class="fw-semibold text-dark">
                        2,100 L
                    </div>

                    <div class="progress mt-1"
                         style="height: 6px; min-width: 100px;">

                        <div
                            class="progress-bar bg-warning"
                            role="progressbar"
                            style="width: 26%;"
                            aria-valuenow="26"
                            aria-valuemin="0"
                            aria-valuemax="100">
                        </div>

                    </div>

                    <small class="text-warning fw-semibold">
                        26%
                    </small>

                </td>

                <td class="text-end text-muted">
                    8,000 L
                </td>

                <td class="text-muted">
                    22-07-2026
                </td>

                <td class="text-center">

                    <span class="badge rounded-pill bg-warning-subtle text-warning">
                        <i class="mdi mdi-alert-circle-outline me-1"></i>
                        Low Level
                    </span>

                </td>

            </tr>

           {{-- Tank 03 --}}
            <tr>

                <td class="fw-semibold text-primary">
                    TNK-03
                </td>

                <td class="fw-medium text-dark">
                    Generator Reserve Tank - Flyover Site
                </td>

                <td class="text-muted">
                    Chennai Pier Yard
                </td>

                <td>
                    <span class="badge bg-light text-dark">
                        HSD
                    </span>
                </td>

                <td class="text-end">

                    <div class="fw-semibold text-dark">
                        4,200 L
                    </div>

                    <div class="progress mt-1"
                        style="height: 6px; min-width: 100px;">

                        <div
                            class="progress-bar bg-success"
                            role="progressbar"
                            style="width: 84%;"
                            aria-valuenow="84"
                            aria-valuemin="0"
                            aria-valuemax="100">
                        </div>

                    </div>

                    <small class="text-success fw-semibold">
                        84%
                    </small>

                </td>

                <td class="text-end text-muted">
                    5,000 L
                </td>

                <td class="text-muted">
                    25-07-2026
                </td>

                <td class="text-center">

                    <span class="badge rounded-pill bg-success-subtle text-success">
                        <i class="mdi mdi-check-circle-outline me-1"></i>
                        Optimal
                    </span>

                </td>

            </tr>

        </tbody>

    </table>

</div>


{{-- Add Fuel Tank Modal --}}
<div class="modal fade"
     id="addFuelTankModal"
     tabindex="-1"
     aria-labelledby="addFuelTankModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 rounded-3 shadow">

            {{-- Header --}}
            <div class="modal-header bg-primary">

                <div>
                    <h5 class="modal-title fw-bold text-white"
                        id="addFuelTankModalLabel">

                        <i class="mdi mdi-fuel me-1 fs-2"></i>
                        Add Fuel Tank

                    </h5>

                    <p class="text-muted mb-0 small">
                        Add a new fuel tank and its current level details.
                    </p>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>

            </div>


            {{-- Form --}}
            <form>

                @csrf

                <div class="modal-body">

                    <div class="row g-3">

                        {{-- Tank ID --}}
                        <div class="col-md-6">

                            <label for="tank_id"
                                   class="form-label fw-semibold">

                                Tank ID
                                <span class="text-danger">*</span>

                            </label>

                            <input type="text"
                                   name="tank_id"
                                   id="tank_id"
                                   class="form-control"
                                   placeholder="Example: TNK-05"
                                   required>

                        </div>


                        {{-- Tank Name --}}
                        <div class="col-md-6">

                            <label for="tank_name"
                                   class="form-label fw-semibold">

                                Tank Name
                                <span class="text-danger">*</span>

                            </label>

                            <input type="text"
                                   name="tank_name"
                                   id="tank_name"
                                   class="form-control"
                                   placeholder="Example: Main HSD Tank"
                                   required>

                        </div>


                        {{-- Location --}}
                        <div class="col-md-6">

                            <label for="location"
                                   class="form-label fw-semibold">

                                Location
                                <span class="text-danger">*</span>

                            </label>

                            <input type="text"
                                   name="location"
                                   id="location"
                                   class="form-control"
                                   placeholder="Example: Chennai Central Yard"
                                   required>

                        </div>


                        {{-- Type --}}
                        <div class="col-md-6">

                            <label for="fuel_type"
                                   class="form-label fw-semibold">

                                Type
                                <span class="text-danger">*</span>

                            </label>

                            <select name="fuel_type"
                                    id="fuel_type"
                                    class="form-select"
                                    required>

                                <option value="">
                                    Select Type
                                </option>

                                <option value="HSD">
                                    HSD
                                </option>

                                <option value="Petrol">
                                    Petrol
                                </option>

                                <option value="Engine">
                                    Engine
                                </option>

                            </select>

                        </div>


                        {{-- Current Tank Level --}}
                        <div class="col-md-6">

                            <label for="current_level"
                                   class="form-label fw-semibold">

                                Current Tank Level
                                <span class="text-danger">*</span>

                            </label>

                            <div class="input-group">

                                <input type="number"
                                       name="current_level"
                                       id="current_level"
                                       class="form-control"
                                       placeholder="Example: 4200"
                                       min="0"
                                       step="0.01"
                                       required>

                                <span class="input-group-text">
                                    L
                                </span>

                            </div>

                        </div>


                        {{-- Maximum Capacity --}}
                        <div class="col-md-6">

                            <label for="max_capacity"
                                   class="form-label fw-semibold">

                                Maximum Capacity
                                <span class="text-danger">*</span>

                            </label>

                            <div class="input-group">

                                <input type="number"
                                       name="max_capacity"
                                       id="max_capacity"
                                       class="form-control"
                                       placeholder="Example: 5000"
                                       min="1"
                                       step="0.01"
                                       required>

                                <span class="input-group-text">
                                    L
                                </span>

                            </div>

                        </div>


                        {{-- Refilled Date --}}
                        <div class="col-md-6">

                            <label for="refilled_date"
                                   class="form-label fw-semibold">

                                Refilled Date
                                <span class="text-danger">*</span>

                            </label>

                            <input type="date"
                                   name="refilled_date"
                                   id="refilled_date"
                                   class="form-control"
                                   required>

                        </div>


                        {{-- Status --}}
                        <div class="col-md-6">

                            <label for="status"
                                   class="form-label fw-semibold">

                                Status
                                <span class="text-danger">*</span>

                            </label>

                            <select name="status"
                                    id="status"
                                    class="form-select"
                                    required>

                                <option value="">
                                    Select Status
                                </option>

                                <option value="optimal">
                                    Optimal
                                </option>

                                <option value="low">
                                    Low Level
                                </option>

                            </select>

                        </div>

                    </div>

                </div>


                {{-- Footer --}}
                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-light"
                            data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit"
                            class="btn btn-primary">

                        <i class="mdi mdi-content-save-outline me-1"></i>
                        Save Tank

                    </button>

                </div>

            </form>

        </div>
    </div>
</div>


<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>

@endsection