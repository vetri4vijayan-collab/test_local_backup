@extends('layouts.layoutMaster')

@section('title', 'Fuel Reconciliation list - Fuel management')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="card shadow-sm rounded-2 mb-4">
  <div class="card-body p-3 p-md-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">

          {{-- Title & Icon --}}
          <div class="d-flex align-items-center gap-3">

              <div class="settings-header-icon">
                  <i class="mdi mdi-receipt-text-outline"></i>
              </div>

                <div>
                    <h4 class="mb-1 fw-bold text-primary fs-5">
                        Fuel Reconciliation List
                    </h4>

                    <p class="text-muted mb-0 fs-8">
                        Reconcile fuel receipts, usage, and closing stock across all stores.
                    </p>
                </div>
          </div>


         {{-- Navigation --}}
          <div class="settings-tabs-wrapper d-flex align-items-center">

              {{-- Previous Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn me-1"
                  id="settingsTabPrev">

                  <i class="mdi mdi-chevron-left"></i>

              </button>


              {{-- Tabs --}}
              <div class="settings-tabs-scroller">

                  <div
                      class="settings-tabs-track"
                      id="settingsTabScroller">

                      @php
                          $activeTab = request('tab', 'entry');
                      @endphp


                      {{-- Fuel Purchase Entry --}}
                      <a
                          href="{{ route('store-purchase.fuel-management', ['tab' => 'entry']) }}"
                          class="settings-tab-pill {{ $activeTab === 'entry' ? 'active' : '' }}">

                          <i class="mdi mdi-file-document-edit-outline me-1"></i>

                         Fuel Purchase Entry List

                      </a>


                      {{-- Fuel Stock List --}}
                      <a
                          href="{{ route('store-purchase.fuel-stock', ['tab' => 'fuel_stock']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_stock' ? 'active' : '' }}">

                          <i class="mdi mdi-calculator-variant-outline me-1"></i>

                            Fuel Stock List
                      </a>


                      {{-- Fuel Reconciliation List --}}
                      <a
                          href="{{ route('store-purchase.fuel-reconciliation', ['tab' => 'fuel_reconciliation']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_reconciliation' ? 'active' : '' }}">

                          <i class="mdi mdi-cash-check me-1"></i>

                         Fuel Reconciliation List

                      </a>

                       {{-- Fuel Tanks & Level Gauges --}}
                       <a href="{{ route('store-purchase.fuel-tank-level', ['tab' => 'fuel_tank']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_tank' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Fuel Tanks & Level Gauges
                        </a>
                       <a href="{{ route('store-purchase.fuel_log', ['tab' => 'fuel_log']) }}"
                          class="settings-tab-pill {{ $activeTab === 'fuel_log' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                          Equipment Refueling Log
                        </a>
                        
                         {{-- Bulk Diesel Inward Ledger --}}
                         <a href="{{ route('store-purchase.bulk_diesel', ['tab' => 'bulk_diesel']) }}"
                          class="settings-tab-pill {{ $activeTab === 'bulk_diesel' ? 'active' : '' }}">
                            <i class="mdi mdi-clipboard-check-outline me-1"></i>
                            Bulk Diesel Inward Ledger
                        </a>

                  </div>

              </div>


              {{-- Next Button --}}
              <button
                  type="button"
                  class="settings-tab-scroll-btn ms-1"
                  id="settingsTabNext">

                  <i class="mdi mdi-chevron-right"></i>

              </button>

          </div>
      </div>
  </div>
</div>



<div class="card rounded-2 p-3 mb-4">
    <div class="row g-3 align-items-end">

        {{-- Search --}}
        <div class="col-md-4">
            <div class="position-relative">
                <span
                    class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                    style="pointer-events: none;">
                    <i class="mdi mdi-magnify fs-5"></i>
                </span>

                <input
                    id="hr-search-field"
                    type="text"
                    placeholder="Search store, diesel, petrol"
                    class="form-control ps-7 bg-light border-0 rounded-3 text-secondary"
                />
            </div>
        </div>


        {{-- Store Name --}}
        <div class="col-md-4">
            <div class="d-flex align-items-center gap-2">

                <label
                    for="store_name"
                    class="fw-semibold mb-0 text-nowrap text-secondary">

                    Store Name

                </label>

                <select
                    name="store_name"
                    id="store_name"
                    class="form-select">

                    <option value="">All Stores</option>

                    <option value="1">Head Office</option>
                    <option value="4">Cube</option>
                    <option value="5">Central Storage Hub</option>
                    <option value="7">Central Material Warehouse</option>
                    <option value="8">North Zone Steel Warehouse</option>

                    <option value="2">CPRR Site</option>
                    <option value="3">NTRP Site</option>
                    <option value="5">MMRP Site</option>
                    <option value="6">Flyover Store</option>
                    <option value="7">Main Warehouse Store</option>
                    <option value="8">Drainage Materials Store</option>
                    <option value="9">Solar Equipment Store</option>
                    <option value="10">Road Works Store</option>
                    <option value="11">Interior Materials Store</option>
                    <option value="12">Plant Equipment Store</option>
                    <option value="13">IT Infrastructure Store</option>
                    <option value="15">Electrical & Plumbing Store</option>

                </select>

            </div>
        </div>


        {{-- Action Buttons --}}
        <div class="col-md-4">
            <div class="d-flex justify-content-md-end gap-2">

                {{-- Summary --}}
              
                <a
                    href="{{ route('store-purchase.fuel-reconciliation.summary') }}"
                    class="btn btn-outline-primary">

                    <i class="mdi mdi-chart-box-outline me-1"></i>
                    Summary

                </a>




                {{-- Add Reconciliation --}}
                <button
                    type="button"
                    class="btn btn-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#fuelReconciliationModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Add Reconciliation

                </button>

            </div>
        </div>
    </div>
</div>





<div class="card mt-4 rounded-0">
    <div class= " table-responsive">
        <table class="table table-hover align-middle mb-0">

            <thead class="table-light">
                <tr>
                    <th class="fw-semibold text-secondary" style="min-width: 120px;">
                        Date
                    </th>

                    <th class="fw-semibold text-secondary" style="min-width: 300px;">
                        Store
                    </th>

                    <th class="fw-semibold text-secondary" style="min-width: 120px;">
                        Type
                    </th>

                    <th class="fw-semibold text-secondary text-end" style="min-width: 120px;">
                        Quantity
                    </th>

                    <th class="fw-semibold text-secondary text-center" style="min-width: 180px;">
                        Reconciliation Status
                    </th>
                </tr>
            </thead>

            <tbody>

                {{-- Reconciliation Row 1 --}}
                <tr>
                    <td>
                        25-06-2026
                    </td>

                    <td class="fw-semibold text-dark">
                        North Zone Steel Warehouse
                    </td>

                    <td>
                        Diesel
                    </td>

                    <td class="text-end">
                        45
                    </td>

                    <td class="text-center">
                        <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill">
                            Returned
                        </span>
                    </td>
                </tr>


                {{-- Reconciliation Row 2 --}}
                <tr>
                    <td>
                        12-04-2026
                    </td>

                    <td class="fw-semibold text-dark">
                        Drainage Materials Store
                    </td>

                    <td>
                        Petrol
                    </td>

                    <td class="text-end">
                        25
                    </td>

                    <td class="text-center">
                        <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill">
                            Returned
                        </span>
                    </td>
                </tr>


                {{-- Reconciliation Row 3 --}}
                <tr>
                    <td>
                        10-04-2026
                    </td>

                    <td class="fw-semibold text-dark">
                        Main Warehouse Store
                    </td>

                    <td>
                        Diesel
                    </td>

                    <td class="text-end">
                        100
                    </td>

                    <td class="text-center">
                        <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill">
                            Returned
                        </span>
                    </td>
                </tr>


                {{-- Reconciliation Row 4 --}}
                <tr>
                    <td>
                        17-03-2026
                    </td>

                    <td class="fw-semibold text-dark">
                        Head Office
                    </td>

                    <td>
                        Petrol
                    </td>

                    <td class="text-end">
                        30
                    </td>

                    <td class="text-center">
                        <span class="badge bg-success-subtle text-success px-3 py-2 rounded-pill">
                            Received
                        </span>
                    </td>
                </tr>


                {{-- Reconciliation Row 5 --}}
                <tr>
                    <td>
                        17-03-2026
                    </td>

                    <td class="fw-semibold text-dark">
                        Head Office
                    </td>

                    <td>
                        Diesel
                    </td>

                    <td class="text-end">
                        15
                    </td>

                    <td class="text-center">
                        <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill">
                            Returned
                        </span>
                    </td>
                </tr>


                {{-- Total --}}
                <tr class="table-light">
                    <td></td>

                    <td class="fw-semibold">
                        Reconciliation Total
                    </td>

                    <td></td>

                    <td class="text-end fw-semibold">
                        215
                    </td>

                    <td class="text-center fw-semibold">
                        —
                    </td>
                </tr>

            </tbody>

        </table>
    </div>
</div>


{{-- Fuel Reconciliation Modal --}}
<div
    class="modal fade"
    id="fuelReconciliationModal"
    tabindex="-1"
    aria-labelledby="fuelReconciliationModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content rounded-3 border-0 shadow">

            {{-- Modal Header --}}
            <div class="modal-header border-bottom bg-primary">

                <div>
                    <h5
                        class="modal-title fw-bold text-white"
                        id="fuelReconciliationModalLabel">

                        <i class="mdi mdi-cash-check me-1 fs-3"></i>
                        Create Petrol / Diesel Reconciliation

                    </h5>

                    <p class="text-muted mb-0 mt-1 fs-8 p-1">
                        Record fuel receipts, returns, and reconciliation details.
                    </p>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- Modal Body --}}
            <div class="modal-body p-4">

                <form
                    action="#"
                    method="POST"
                    id="fuelReconciliationForm">

                    @csrf

                    <div class="row g-3">

                        {{-- Store Name --}}
                        <div class="col-md-6">

                            <label
                                for="reconciliation_store"
                                class="form-label fw-semibold text-secondary">

                                Store Name
                                <span class="text-danger">*</span>

                            </label>

                            <select
                                name="store_name"
                                id="reconciliation_store"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Store
                                </option>

                                <option value="1">
                                    Head Office
                                </option>

                                <option value="4">
                                    Cube
                                </option>

                                <option value="5">
                                    Central Storage Hub
                                </option>

                                <option value="7">
                                    Central Material Warehouse
                                </option>

                                <option value="8">
                                    North Zone Steel Warehouse
                                </option>

                                <option value="2">
                                    CPRR Site
                                </option>

                                <option value="3">
                                    NTRP Site
                                </option>

                                <option value="5">
                                    MMRP Site
                                </option>

                                <option value="6">
                                    Flyover Store
                                </option>

                                <option value="7">
                                    Main Warehouse Store
                                </option>

                                <option value="8">
                                    Drainage Materials Store
                                </option>

                                <option value="9">
                                    Solar Equipment Store
                                </option>

                                <option value="10">
                                    Road Works Store
                                </option>

                                <option value="11">
                                    Interior Materials Store
                                </option>

                                <option value="12">
                                    Plant Equipment Store
                                </option>

                                <option value="13">
                                    IT Infrastructure Store
                                </option>

                                <option value="15">
                                    Electrical & Plumbing Store
                                </option>

                            </select>

                        </div>


                        {{-- Date --}}
                        <div class="col-md-6">

                            <label
                                for="reconciliation_date"
                                class="form-label fw-semibold text-secondary">

                                Date
                                <span class="text-danger">*</span>

                            </label>

                            <input
                                type="date"
                                name="date"
                                id="reconciliation_date"
                                class="form-control"
                                required>

                        </div>


                        {{-- Fuel Type --}}
                        <div class="col-md-6">

                            <label
                                for="reconciliation_type"
                                class="form-label fw-semibold text-secondary">

                                Type
                                <span class="text-danger">*</span>

                            </label>

                            <select
                                name="type"
                                id="reconciliation_type"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Type
                                </option>

                                <option value="petrol">
                                    Petrol
                                </option>

                                <option value="diesel">
                                    Diesel
                                </option>

                            </select>

                        </div>


                        {{-- Reconciliation Status --}}
                        <div class="col-md-6">

                            <label
                                for="reconciliation_status"
                                class="form-label fw-semibold text-secondary">

                                Reconciliation Status
                                <span class="text-danger">*</span>

                            </label>

                            <select
                                name="reconciliation_status"
                                id="reconciliation_status"
                                class="form-select"
                                required>

                                <option value="">
                                    Select Reconciliation Status
                                </option>

                                <option value="received">
                                    Received
                                </option>

                                <option value="returned">
                                    Returned
                                </option>

                            </select>

                        </div>


                        {{-- Quantity --}}
                        <div class="col-md-6">

                            <label
                                for="reconciliation_quantity"
                                class="form-label fw-semibold text-secondary">

                                Quantity
                                <span class="text-danger">*</span>

                            </label>

                            <div class="input-group">

                                <input
                                    type="number"
                                    name="quantity"
                                    id="reconciliation_quantity"
                                    class="form-control"
                                    placeholder="Enter quantity"
                                    min="0"
                                    step="0.01"
                                    required>

                                <span class="input-group-text bg-light text-muted">
                                    Litres
                                </span>

                            </div>

                        </div>


                        {{-- Description --}}
                        <div class="col-12">

                            <label
                                for="reconciliation_description"
                                class="form-label fw-semibold text-secondary">

                                Description

                            </label>

                            <textarea
                                name="description"
                                id="reconciliation_description"
                                class="form-control"
                                rows="3"
                                placeholder="Enter reconciliation details or remarks..."></textarea>

                        </div>

                    </div>

                </form>

            </div>


            {{-- Modal Footer --}}
            <div class="modal-footer border-top">

                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal">

                    Cancel

                </button>

                <button
                    type="submit"
                    form="fuelReconciliationForm"
                    class="btn btn-primary">

                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Reconciliation

                </button>

            </div>

        </div>

    </div>
</div>





<style>
    .settings-header-icon {
        width: 50px;
        height: 40px;
        border-radius: 10px;
        background: #ecf7ff;
        color: #16659E;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }

    .settings-tabs-wrapper {
        max-width: 100%;
    }

    .settings-tabs-scroller {
        overflow: hidden;
        max-width: 480px;
    }

    .settings-tabs-track {
        display: flex;
        gap: 0.5rem;
        overflow-x: auto;
        scroll-behavior: smooth;
        scrollbar-width: none;
        padding: 2px;
    }

    .settings-tabs-track::-webkit-scrollbar {
        display: none;
    }

    .settings-tab-pill {
        white-space: nowrap;
        padding: 0.45rem 1rem;
        border-radius: 50rem;
        background: #f1f3f5;
        color: #495057;
        font-size: 0.85rem;
        font-weight: 500;
        text-decoration: none;
        transition: all .15s ease;
        flex-shrink: 0;
        border: none;
    }

    .settings-tab-pill:hover {
        background: #e2e6ea;
        color: #212529;
    }

    .settings-tab-pill.active {
        background: #16659E;
        color: #fff;
    }

    .settings-tab-scroll-btn {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 1px solid #e2e6ea;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        flex-shrink: 0;
        padding: 0;
    }

    .settings-tab-scroll-btn:hover {
        background: #f8f9fa;
    }

    @media (max-width: 767px) {
        .settings-tabs-scroller {
            max-width: 220px;
        }
    }


</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const scroller = document.getElementById('settingsTabScroller');
    const prevBtn = document.getElementById('settingsTabPrev');
    const nextBtn = document.getElementById('settingsTabNext');

    const scrollAmount = 250;


    // Make sure all required elements exist
    if (!scroller || !prevBtn || !nextBtn) {
        return;
    }


    // Update left/right button state
    function updateButtons() {

        const maxScroll = scroller.scrollWidth - scroller.clientWidth;

        // Disable previous button at the beginning
        prevBtn.disabled = scroller.scrollLeft <= 0;

        // Disable next button at the end
        nextBtn.disabled = scroller.scrollLeft >= maxScroll - 1;
    }


    // Previous button
    prevBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });

    });


    // Next button
    nextBtn.addEventListener('click', function () {

        scroller.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });

    });


    // Update buttons when scrolling
    scroller.addEventListener('scroll', updateButtons);


    // Update buttons when window size changes
    window.addEventListener('resize', updateButtons);


    // Automatically show the active tab
    const activeTab = scroller.querySelector('.settings-tab-pill.active');

    if (activeTab) {

        setTimeout(function () {

            activeTab.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: 'nearest'
            });

            setTimeout(function () {
                updateButtons();
            }, 300);

        }, 100);
    }


    // Initial button state
    updateButtons();

});
</script>

@endsection