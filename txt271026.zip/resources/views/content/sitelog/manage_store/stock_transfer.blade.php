@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<!-- Header section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-package-variant-closed fs-1 text-primary"></i>
                <div>
                    <h4 class="mb-1 fw-bold text-primary">Manage store</h4>
                    <p class="text-muted mb-0 fs-7">Site Operations Management & Logs</p>
                </div>
            </div>
            <!-- Updated button to call setViewMode('form') -->
            <!-- <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" onclick="setViewMode('form')">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Vendor
                </button> -->

            <div class="nav-scroll-wrapper">

                {{--  Sites & Warehouses--}}
                <div class="nav-scroll-container gap-3 ">
                    {{-- Salary Structure & Wages Rate Link --}}
                    @php
                    $isSalaryActive = request()->is('/site/manage-store/site&warehouse');
                    @endphp
                    <a href="{{ url('/site/manage-store/site&warehouse') }}"
                        class="btn btn-sm rounded-3  text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
                        <span class="mdi mdi-domain pe-2"></span>
                        Sites & Warehouses
                    </a>

                    {{--  Stock Inventory Register --}}
                    @php
                    $isStockInventoryActive = request()->is('/site/manage-store/stock_inventory');
                    @endphp
                    <a href="{{ url('/site/manage-store/stock_inventory') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockInventoryActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-cube-outline pe-2"></i>
                        Stock Inventory Register
                    </a>

                    {{-- Stock Transfers --}}
                    @php
                    $isStockTransferActive = request()->is('site/manage-store/stock_transfer');
                    @endphp
                    <a href="{{ url('/site/manage-store/stock_transfer') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockTransferActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-swap-horizontal pe-2"></i>
                        Stock Transfers
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-2 p-md-3">

        <div class="d-flex flex-column flex-xl-row justify-content-between align-items-xl-center gap-2">
            <!-- Search Input -->
            <div class="input-group input-group-sm flex-shrink-0" style="max-width: 340px;">
                <span class="input-group-text border-end-0 text-muted bg-white px-2">
                    <i class="mdi mdi-magnify" style="font-size: 14px;"></i>
                </span>
                <input type="text" id="search_store" class="form-control border-start-0 ps-1 shadow-none"
                    style="font-size: 13px;" placeholder="Search store, location, material ...">
            </div>
            <!-- Filters Wrapper -->
            <div class="d-flex align-items-center gap-2 flex-grow-1 flex-xl-grow-0">
                <div class="d-flex align-items-center gap-1 text-dark flex-shrink-0">
                    <i class="mdi mdi-filter-outline text-secondary" style="font-size: 14px;"></i>
                    <span class="fw-bold text-uppercase text-nowrap text-secondary" style="font-size: 10px;">
                        Project:
                    </span>
                </div>
                <div class="flex-grow-1 flex-xl-grow-0" style="width: 100%; max-width: 310px;">
                    <select
                        class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold text-truncate w-100"
                        style="font-size: 11px; height: 31px;">
                        <option value="ALL">All Project (Global View)</option>
                        <option value="Chennai Metro Phase 2">Chennai Metro Phase 2 - Corridor 4</option>
                        <option value="Promotion with Increment">Promotion with Increment</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid px-0 inter-site-transfer-container">
    <!-- Header Section -->
    <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-2 mb-3">
        <h3 class="text-uppercase fw-black text-secondary fs-7 mb-0 inter-transfer-title">
            Inter-Site Material Transfers Log (<span class="transfer-count">0</span>)
        </h3>
        <!-- <button type="button"
            class="btn btn-primary btn-sm d-inline-flex fs-8 align-items-center justify-content-center gap-2 px-2 py-1 fw-bold shadow-sm initiate-transfer-btn"
            onclick="setShowTransferModal(true)">
            <i class="mdi mdi-swap-horizontal fs-4"></i>
            <span>Initiate Stock Transfer</span>
        </button> -->
        <button type="button"
            class="btn btn-sm btn-primary d-flex align-items-center justify-content-center gap-1 fw-bold px-2 py-1 text-nowrap facility-trigger-btn"
            data-bs-toggle="modal" data-bs-target="#addInitiateTransfer" style="font-size: 11px;">
            <i class="mdi mdi-plus" style="font-s
            ize: 14px;"></i>
            <span>
                Initiate Stock Transfer
            </span>
        </button>
    </div>

    <!-- Transfers List Wrapper -->
    <div class="d-flex flex-column gap-3 inter-transfer-list">
        <!-- TRANSFER CARD ITEM (Loop template) -->
        <!-- Card 1 -->
        <div class="card bg-white rounded-3 border border-secondary-subtle p-3 shadow-sm inter-site-transfer-card">
            <!-- Card Header: Number & Status -->
            <div
                class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2 pb-2 border-bottom border-light">
                <div class="d-flex align-items-center gap-2 flex-wrap pt-1">
                    <!-- Transfer No -->
                    <span
                        class="font-monospace fw-bold text-primary bg-primary-subtle px-2 py-1 rounded border border-primary-subtle"
                        style="font-size: 13px;">
                        TRF-2026-001
                    </span>
                    <!-- Status Badge -->
                    <span
                        class="badge bg-success-subtle text-success border border-success text-uppercase fw-extrabold px-2 py-1"
                        style="font-size: 10px;">
                        Delivered
                    </span>
                </div>
                <div class="text-muted font-monospace small" style="font-size: 13px;">
                    Dispatch: 24 Aug 2026, 10:30 AM
                </div>
            </div>
            <!-- Transfer Route Visualizer Grid -->
            <div
                class="row g-3 align-items-center justify-center bg-light bg-opacity-50 rounded-3 my-0 transfer-route-grid px-2">
                <!-- Source Store -->
                <div class="col-12 col-md-4 m-0">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">From (Source
                        Store)</span>
                    <strong class="text-dark d-block  text-truncate" style="font-size: 14px;">
                        Apex Steel & Industrial Works
                    </strong>
                </div>
                <!-- Item & Distance Center Pill -->
                <div class="col-12 col-md-4 text-center py-2 py-md-0  ">
                    <div class="text-primary fw-bold d-flex align-items-center justify-content-center gap-1 flex-wrap"
                        style="font-size: 13px;">
                        <i class="mdi mdi-truck-fast"></i>
                        <span>Steel Rods (500 Tons)</span>
                    </div>
                    <span class="text-muted font-monospace d-block mt-1" style="font-size: 13px;">
                        Distance: 4.2 km
                    </span>
                </div>
                <!-- Destination Site -->
                <div class="col-12 col-md-4 text-start text-md-end">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">To ( Destination
                        Site )</span>
                    <strong class="text-primary-emphasis d-block mt-1 text-truncate" style="font-size: 14px;">
                        Chennai Metro Phase 2
                    </strong>
                    <span class="text-muted d-block mb-2" style="font-size: 11px;">Project Alpha</span>
                </div>
            </div>
            <!-- Card Footer Details -->
            <div class="d-flex flex-wrap align-items-center justify-content-between text-muted pt-3 small gap-2"
                style="font-size: 11px;">
                <span>Transporter: <strong class="text-dark">Express Logistics</strong> (<span
                        class="font-monospace">TN-01-AB-1234</span>)</span>
                <span>Requested By: <strong class="text-dark">John Doe</strong></span>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="card bg-white rounded-3 border border-secondary-subtle p-3 shadow-sm inter-site-transfer-card">
            <!-- Card Header: Number & Status -->
            <div
                class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2 pb-2 border-bottom border-light">
                <div class="d-flex align-items-center gap-2 flex-wrap pt-1">
                    <!-- Transfer No -->
                    <span
                        class="font-monospace fw-bold text-primary bg-primary-subtle px-2 py-1 rounded border border-primary-subtle"
                        style="font-size: 13px;">
                        TRF-2026-001
                    </span>
                    <!-- Status Badge -->
                    <span
                        class="badge bg-primary-subtle text-primary border border-primary text-uppercase fw-extrabold px-2 py-1"
                        style="font-size: 10px;">
                        In Transit
                    </span>
                </div>
                <div class="text-muted font-monospace small" style="font-size: 13px;">
                    Dispatch: 24 Aug 2026, 10:30 AM
                </div>
            </div>
            <!-- Transfer Route Visualizer Grid -->
            <div
                class="row g-3 align-items-center justify-center bg-light bg-opacity-50 rounded-3 my-0 transfer-route-grid px-2">
                <!-- Source Store -->
                <div class="col-12 col-md-4 m-0">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">From (Source
                        Store)</span>
                    <strong class="text-dark d-block  text-truncate" style="font-size: 14px;">
                        Apex Steel & Industrial Works
                    </strong>
                </div>
                <!-- Item & Distance Center Pill -->
                <div class="col-12 col-md-4 text-center py-2 py-md-0  ">
                    <div class="text-primary fw-bold d-flex align-items-center justify-content-center gap-1 flex-wrap"
                        style="font-size: 13px;">
                        <i class="mdi mdi-truck-fast"></i>
                        <span>PPC 53 Grade Cement (500 Bags)</span>
                    </div>
                    <span class="text-muted font-monospace d-block mt-1" style="font-size: 13px;">
                        Distance: 4.2 km
                    </span>
                </div>
                <!-- Destination Site -->
                <div class="col-12 col-md-4 text-start text-md-end">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">To ( Destination
                        Site )</span>
                    <strong class="text-primary-emphasis d-block mt-1 text-truncate" style="font-size: 14px;">
                        Chennai Metro Phase 2
                    </strong>
                    <span class="text-muted d-block mb-2" style="font-size: 11px;">Project Alpha</span>
                </div>
            </div>
            <!-- Card Footer Details -->
            <div class="d-flex flex-wrap align-items-center justify-content-between text-muted pt-3 small gap-2"
                style="font-size: 11px;">
                <span>Transporter: <strong class="text-dark">Express Logistics</strong> (<span
                        class="font-monospace">TN-01-AB-1234</span>)</span>
                <span>Requested By: <strong class="text-dark">John Doe</strong></span>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="card bg-white rounded-3 border border-secondary-subtle p-3 shadow-sm inter-site-transfer-card">
            <!-- Card Header: Number & Status -->
            <div
                class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-2 pb-2 border-bottom border-light">
                <div class="d-flex align-items-center gap-2 flex-wrap pt-1">
                    <!-- Transfer No -->
                    <span
                        class="font-monospace fw-bold text-primary bg-primary-subtle px-2 py-1 rounded border border-primary-subtle"
                        style="font-size: 13px;">
                        TRF-2026-001
                    </span>
                    <!-- Status Badge -->
                    <span
                        class="badge bg-warning-subtle text-dark border border-warning text-uppercase fw-extrabold px-2 py-1"
                        style="font-size: 10px;">
                        Pending Dispatch
                    </span>
                </div>
                <div class="text-muted font-monospace small" style="font-size: 13px;">
                    Dispatch: 24 Aug 2026, 10:30 AM
                </div>
            </div>
            <!-- Transfer Route Visualizer Grid -->
            <div
                class="row g-3 align-items-center justify-center bg-light bg-opacity-50 rounded-3 my-0 transfer-route-grid px-2">
                <!-- Source Store -->
                <div class="col-12 col-md-4 m-0">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">From (Source
                        Store)</span>
                    <strong class="text-dark d-block  text-truncate" style="font-size: 14px;">
                        Apex Steel & Industrial Works
                    </strong>
                </div>
                <!-- Item & Distance Center Pill -->
                <div class="col-12 col-md-4 text-center py-2 py-md-0  ">
                    <div class="text-primary fw-bold d-flex align-items-center justify-content-center gap-1 flex-wrap"
                        style="font-size: 13px;">
                        <i class="mdi mdi-truck-fast"></i>
                        <span>Steel Rods (500 Tons)</span>
                    </div>
                    <span class="text-muted font-monospace d-block mt-1" style="font-size: 13px;">
                        Distance: 4.2 km
                    </span>
                </div>
                <!-- Destination Site -->
                <div class="col-12 col-md-4 text-start text-md-end">
                    <span class="text-uppercase fw-bold text-muted d-block" style="font-size: 11px;">To ( Destination
                        Site )</span>
                    <strong class="text-primary-emphasis d-block mt-1 text-truncate" style="font-size: 14px;">
                        Chennai Metro Phase 2
                    </strong>
                    <span class="text-muted d-block mb-2" style="font-size: 11px;">Project Alpha</span>
                </div>
            </div>
            <!-- Card Footer Details -->
            <div class="d-flex flex-wrap align-items-center justify-content-between text-muted pt-3 small gap-2"
                style="font-size: 11px;">
                <span>Transporter: <strong class="text-dark">Express Logistics</strong> (<span
                        class="font-monospace">TN-01-AB-1234</span>)</span>
                <span>Requested By: <strong class="text-dark">John Doe</strong></span>
            </div>
        </div>
    </div>
</div>


<!-- Initiate Stock Transfer Modal -->

<div class="modal fade transfer-modal-backdrop" id="addInitiateTransfer" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg transfer-modal-dialog">
        <div
            class="modal-content bg-white rounded-4 overflow-hidden shadow-lg border border-secondary-subtle transfer-modal-content">

            <!-- Modal Header -->
            <div
                class="modal-header bg-primary text-white px-4 py-3 transfer-modal-header border-0 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-swap-horizontal text-white fs-5"></i>
                    <h4 class="modal-title fw-black text-white fs-6 mb-0">
                        Initiate Inter-Store Material Transfer
                    </h4>
                </div>
                <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>

            <!-- Modal Form Body -->
            <form class="modal-body p-4 p-md-4 transfer-modal-form">
                <div class="row g-3">

                    <!-- Source Store Selection -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Source
                            Store / Yard *</label>
                        <select id="trfSourceId"
                            class="select3 form-select form-select-sm  border-secondary-subtle fw-semibold rounded-3 p-2 source-store-select">
                            <!-- Loop options dynamically -->
                            <option value="1">Apex Steel & Industrial Works</option>
                            <option value="2">South Region Central Warehouse</option>
                        </select>
                    </div>

                    <!-- Destination Site Selection -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Destination
                            Site Yard *</label>
                        <select id="trfDestId"
                            class="select3 form-select form-select-sm border-secondary-subtle fw-semibold rounded-3 p-2 dest-site-select">
                            <!-- Loop options dynamically -->
                            <option value="1">Chennai Metro Phase 2 (Project Alpha)</option>
                        </select>
                    </div>

                    <!-- Material Name -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Material
                            Name *</label>
                        <input type="text" required placeholder="e.g. PPC Cement / 20mm TMT Steel" id="trfItemName"
                            class="form-control form-control-sm  border-secondary-subtle fw-bold rounded-3 p-2 material-name-input" />
                    </div>

                    <!-- Quantity -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Quantity
                            *</label>
                        <input type="number" required placeholder="e.g. 50" id="trfQty"
                            class="form-control form-control-sm  border-secondary-subtle font-monospace fw-bold rounded-3 p-2 qty-input" />
                    </div>

                    <!-- Vehicle / Truck No. -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Vehicle /
                            Truck No.</label>
                        <input type="text" placeholder="e.g. TN-09-CB-4521" id="trfVehicle"
                            class="form-control form-control-sm  border-secondary-subtle font-monospace rounded-3 p-2 vehicle-input" />
                    </div>

                    <!-- Transporter Name -->
                    <div class="col-12 col-md-6">
                        <label class="form-label text-uppercase fw-bold text-muted" style="font-size: 10px;">Transporter
                            Name</label>
                        <input type="text" placeholder="e.g. SRK Logistics Division" id="trfTransporter"
                            class="form-control form-control-sm  border-secondary-subtle rounded-3 p-2 transporter-input" />
                    </div>

                </div>

                <!-- Modal Footer Actions -->
                <div
                    class="d-flex align-items-center justify-content-end gap-2 pt-3 mt-4 border-top border-light modal-footer-actions">
                    <button type="button" class="btn btn-light btn-sm fw-bold text-secondary px-3 rounded-2"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit"
                        class="btn btn-sm btn-primary fw-bold rounded-pill px-3 py-2 shadow-sm submit-transfer-btn">
                        Dispatch Stock Transfer
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>
<style>
.inter-site-transfer-card:hover {
    border-color: var(--bs-primary) !important;
    transform: translateY(-2px);
}
</style>
@endsection
