@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<!-- Header section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-package-variant-closed fs-1 text-primary"></i>
                <div>
                    <h4 class="mb-1 fw-bold text-primary">Manage store</h4>
                    <p class="text-muted mb-0 fs-7">Site Operations Management & Logs</p>
                </div>
            </div>
            <!-- Updated button to call setViewMode('form') -->
            <!-- <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" onclick="setViewMode('form')">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Vendor
                </button> -->

            <div class="nav-scroll-wrapper">

                {{-- Scrollable Tabs Container --}}
                <div class="nav-scroll-container gap-3 ">
                    {{-- Salary Structure & Wages Rate Link --}}
                    @php
                    $isSalaryActive = request()->is('site/manage-store/site&warehouse');
                    @endphp
                    <a href="{{ url('/site/manage-store/site&warehouse') }}"
                        class="btn btn-sm rounded-3  text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
                        <span class="mdi mdi-domain pe-2"></span>
                        Sites & Warehouses
                    </a>

                    {{-- Promotion & Appraisal Link --}}
                    @php
                    $isStockInventoryActive = request()->is('/site/manage-store/stock_inventory');
                    @endphp
                    <a href="{{ url('/site/manage-store/stock_inventory') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockInventoryActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-cube-outline pe-2"></i>
                        Stock Inventory Register
                    </a>

                    {{-- Loan Disbursement & Recovery Link --}}
                    @php
                    $isStockTransferActive = request()->is('/site/manage-store/stock_transfer');
                    @endphp
                    <a href="{{ url('/site/manage-store/stock_transfer') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockTransferActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-swap-horizontal pe-2"></i>
                        Stock Transfers
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-2 p-md-3">

        <div class="d-flex flex-column flex-xl-row justify-content-between align-items-xl-center gap-2">
            <!-- Search Input -->
            <div class="input-group input-group-sm flex-shrink-0" style="max-width: 340px;">
                <span class="input-group-text border-end-0 text-muted bg-white px-2">
                    <i class="mdi mdi-magnify" style="font-size: 14px;"></i>
                </span>
                <input type="text" id="search_store" class="form-control border-start-0 ps-1 shadow-none"
                    style="font-size: 13px;" placeholder="Search store, location, material ...">
            </div>
            <!-- Filters Wrapper -->
            <div class="d-flex align-items-center justify-content-end flex-nowrap gap-3 w-100">
                <!-- Project Filter Group -->
                <div class="d-flex align-items-center gap-2 flex-shrink-0">
                    <div class="d-flex align-items-end gap-1 text-dark flex-shrink-0">
                        <i class="mdi mdi-filter-outline" style="font-size: 14px;"></i>
                        <span class="fw-semibold text-nowrap" style="font-size: 9px;">
                            Project Filters:
                        </span>
                    </div>
                    <div class="flex-shrink-0" style="width: 249px;">
                        <select
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold text-truncate w-100"
                            style="width: 220px !important; min-width: 220px !important; max-width: 220px !important; font-size: 9px;">
                            <option value="ALL">
                                All Project (Global View)
                            </option>
                            <option value="Chennai Metro Phase 2">
                                Chennai Metro Phase 2 - Corridor 4
                            </option>
                            <option value="Promotion with Increment">
                                Promotion with Increment
                            </option>
                        </select>
                    </div>
                </div>


                <!-- Facility Type Filter Group -->
                <div class="d-flex align-items-center gap-2 flex-shrink-0">
                    <div class="d-flex align-items-center flex-shrink-0">
                        <span class="fw-semibold text-nowrap" style="font-size: 11px;">
                            Facility Types:
                        </span>
                    </div>
                    <div class="flex-shrink-0" style="width: 200px; min-width: 200px; max-width: 200px;">
                        <select
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold text-truncate w-100"
                            style="width: 190px !important; min-width: 190px !important; max-width: 190px !important; font-size: 11px;">
                            <option value="ALL">
                                All Facility Types
                            </option>
                            <option value="Site Yard">
                                Site Yard
                            </option>
                            <option value="Central Warehouse">
                                Central Warehouse
                            </option>
                            <option value="Regional Depot">
                                Regional Depot
                            </option>
                            <option value="Batching Yard">
                                Batching Yard
                            </option>
                        </select>
                    </div>
                </div>
                <!-- Reset Filter -->
                <a href="#" class="text-primary text-decoration-underline text-nowrap fw-semibold flex-shrink-0"
                    style="font-size: 11px;">
                    Reset Filter
                </a>
                <!-- Register Button -->
                <button type="button"
                    class="btn btn-sm btn-primary d-inline-flex align-items-center justify-content-center gap-1 fw-bold  text-nowrap rounded-2 facility-trigger-btn ms-0   flex-shrink-0"
                    data-bs-toggle="modal" data-bs-target="#addFacilityModal" style="font-size: 11px;">
                    <i class="mdi mdi-plus" style="font-size: 14px;"></i>
                    <span>
                        Register Site / Warehouse
                    </span>
                </button>

            </div>
        </div>
    </div>
</div>

<div class=" gap-3 facility-section-wrapper">
    <div
        class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-2 facility-title-container">
        <!-- Section Heading -->
        <h3 class="text-secondary fw-black text-uppercase tracking-wider fs-7 mb-0 facility-main-heading"
            style="font-size: 11px;">
            Registered Sites & Warehouses
            <span class="facility-count-value">( 5 )</span>
        </h3>
        <!-- Description Subtitle -->
        <span class="text-muted facility-sub-description" style="font-size: 11px;">
            Showing storage facilities mapped against selected projects
        </span>
    </div>
</div>

<div class="row g-4 pt-3">
    <!-- CARD 1 -->
    <div class="col-12 col-md-6">
        <div
            class="card bg-white rounded-3 border border-secondary-subtle p-3 p-md-4 shadow-sm facility-card facility-card-hover d-flex flex-column h-100">
            <div class="flex-grow-1">
                <!-- Facility Header -->
                <div class="d-flex align-items-start justify-content-between gap-2">
                    <div class="d-flex align-items-center gap-3 flex-grow-1">
                        <div class="p-2 rounded-3 border bg-blue-subtle text-primary flex-shrink-0">
                            <i class="mdi mdi-office-building fs-2"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <span class="font-monospace text-muted fw-bold" style="font-size: 10px;">
                                    VEND-001
                                </span>
                                <span
                                    class="badge bg-success-subtle text-success border border-success-subtle text-uppercase fw-extrabold"
                                    style="font-size: 9px;">
                                    Active Operational
                                </span>
                            </div>
                            <h4 class="text-dark fw-bolder fs-6 mt-1 mb-0 text-truncate">
                                Apex Steel & Industrial Works
                            </h4>
                        </div>
                    </div>
                    <span class="badge bg-light text-secondary fw-bold px-2 py-1 flex-shrink-0"
                        style="font-size: 10px;">
                        Site Yard
                    </span>
                </div>
                <!-- Location -->
                <div class="mt-3 p-3 bg-light rounded-3 border border-light-subtle small">
                    <div class="d-flex align-items-start gap-2 text-secondary fw-medium">
                        <i class="mdi mdi-map-marker text-primary flex-shrink-0"></i>
                        <span>
                            123 Industrial Estate, Main Road
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted mt-1" style="font-size: 11px;">
                        <i class="mdi mdi-navigation text-primary flex-shrink-0"></i>
                        <span>
                            Proximity to Project:
                            <strong class="text-dark">4.2 km</strong>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted mt-1 pt-1 border-top border-secondary-subtle"
                        style="font-size: 11px;">
                        <i class="mdi mdi-layers text-info flex-shrink-0"></i>
                        <span>
                            Mapped Project:
                            <strong class="text-dark">Project Alpha</strong>
                        </span>
                    </div>
                </div>
                <!-- Manager -->
                <div class="mt-3 row g-2">
                    <div class="col-12 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-2 bg-light p-2 rounded-2 border border-light-subtle h-100">
                            <i class="mdi mdi-account text-muted flex-shrink-0"></i>
                            <span class="fw-bold text-dark text-truncate" style="font-size: 11px;">
                                John Doe
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6">
                        <a href="tel:+1234567890"
                            class="d-flex align-items-center gap-2 bg-primary-subtle p-2 rounded-2 border border-primary-subtle text-primary fw-bold text-decoration-none h-100"
                            style="font-size: 11px;">
                            <i class="mdi mdi-phone text-primary flex-shrink-0"></i>
                            <span class="text-truncate">
                                +1 234 567 890
                            </span>
                        </a>
                    </div>
                </div>

                <!-- Capacity -->
                <div class="mt-3">
                    <div class="d-flex justify-content-between align-items-center fw-bold mb-1"
                        style="font-size: 10px;">
                        <span class="text-muted text-uppercase">
                            Yard Capacity (2,500 Sqm)
                        </span>
                        <span class="text-dark font-monospace">
                            75% Utilized
                        </span>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-primary rounded-pill" role="progressbar" style="width: 75%;"
                            aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                        </div>
                    </div>
                </div>
                <!-- Materials -->
                <div class="mt-3 pt-3 border-top border-light">
                    <span class="text-muted fw-bold text-uppercase d-block" style="font-size: 10px;">
                        Top Materials Stored:
                    </span>
                    <div class="d-flex flex-wrap gap-1 mt-1">
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Steel Rods
                        </span>
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Cement Bags
                        </span>
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Bricks
                        </span>
                    </div>
                </div>
            </div>
            <!-- Actions -->
            <div
                class="pt-3 mt-3 border-top border-light d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center justify-content-end gap-2">
                <a href="{{ url('/site/manage-store/stock_inventory') }}"
                    class="btn btn-sm btn-outline-primary d-flex align-items-center justify-content-center gap-1 fw-bold px-2 py-1 text-decoration-none"
                    style="font-size: 11px;">
                    <i class="mdi mdi-package-variant"></i>
                    <span>
                        View Stock (12)
                    </span>
                </a>
            </div>
        </div>
    </div>

    <!-- CARD 2 -->
    <div class="col-12 col-md-6">
        <div
            class="card bg-white rounded-3 border border-secondary-subtle p-3 p-md-4 shadow-sm facility-card facility-card-hover d-flex flex-column h-100">
            <div class="flex-grow-1">
                <!-- Facility Header -->
                <div class="d-flex align-items-start justify-content-between gap-2">
                    <div class="d-flex align-items-center gap-3 flex-grow-1">
                        <div class="p-2 rounded-3 border bg-blue-subtle text-primary flex-shrink-0">
                            <i class="mdi mdi-warehouse fs-2"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <span class="font-monospace text-muted fw-bold" style="font-size: 10px;">
                                    VEND-002
                                </span>
                                <span
                                    class="badge text-xl bg-success-subtle text-success border border-success-subtle text-uppercase fw-extrabold"
                                    style="font-size: 9px;">
                                    Active Operational
                                </span>
                            </div>
                            <h4 class="text-dark fw-bolder fs-6 mt-1 mb-0 text-truncate">
                                South Region Central Warehouse
                            </h4>
                        </div>
                    </div>
                    <span class="badge bg-light text-secondary fw-bold px-2 py-1 flex-shrink-0"
                        style="font-size: 10px;">
                        Central Warehouse
                    </span>
                </div>
                <!-- Location -->
                <div class="mt-3 p-3 bg-light rounded-3 border border-light-subtle small">
                    <div class="d-flex align-items-start gap-2 text-secondary fw-medium">
                        <i class="mdi mdi-map-marker text-primary flex-shrink-0"></i>
                        <span>
                            123 Industrial Estate, Main Road
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted mt-1" style="font-size: 11px;">
                        <i class="mdi mdi-navigation text-primary flex-shrink-0"></i>
                        <span>
                            Proximity to Project:
                            <strong class="text-dark">4.2 km</strong>
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2 text-muted mt-1 pt-1 border-top border-secondary-subtle"
                        style="font-size: 11px;">
                        <i class="mdi mdi-layers text-info flex-shrink-0"></i>
                        <span>
                            Mapped Project:
                            <strong class="text-dark">Project Alpha</strong>
                        </span>
                    </div>
                </div>

                <!-- Manager -->
                <div class="mt-3 row g-2">
                    <div class="col-12 col-sm-6">
                        <div
                            class="d-flex align-items-center gap-2 bg-light p-2 rounded-2 border border-light-subtle h-100">
                            <i class="mdi mdi-account text-muted flex-shrink-0"></i>
                            <span class="fw-bold text-dark text-truncate" style="font-size: 11px;">
                                K. Senthil Kumar
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6">
                        <a href="tel:+1234567890"
                            class="d-flex align-items-center gap-2 bg-primary-subtle p-2 rounded-2 border border-primary-subtle text-primary fw-bold text-decoration-none h-100"
                            style="font-size: 11px;">
                            <i class="mdi mdi-phone text-primary flex-shrink-0"></i>
                            <span class="text-truncate">
                                +1 234 567 890
                            </span>
                        </a>
                    </div>
                </div>

                <!-- Capacity -->
                <div class="mt-3">
                    <div class="d-flex justify-content-between align-items-center fw-bold mb-1"
                        style="font-size: 10px;">
                        <span class="text-muted text-uppercase">
                            Yard Capacity (10,000 Sqm)
                        </span>
                        <span class="text-dark font-monospace">
                            65% Utilized
                        </span>
                    </div>
                    <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-primary rounded-pill" role="progressbar" style="width: 65%;"
                            aria-valuenow="65" aria-valuemin="0" aria-valuemax="100">
                        </div>
                    </div>
                </div>

                <!-- Materials -->
                <div class="mt-3 pt-3 border-top border-light">
                    <span class="text-muted fw-bold text-uppercase d-block" style="font-size: 10px;">
                        Top Materials Stored:
                    </span>
                    <div class="d-flex flex-wrap gap-1 mt-1">
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Steel Rods
                        </span>
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Cement Bags
                        </span>
                        <span class="badge bg-light text-secondary fw-semibold" style="font-size: 10px;">
                            Bricks
                        </span>
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <div
                class="pt-3 mt-3 border-top border-light d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center justify-content-end gap-2">
                <a href="{{ url('/site/manage-store/stock_inventory') }}"
                    class="btn btn-sm btn-outline-primary d-flex align-items-center justify-content-center gap-1 fw-bold px-2 py-1 text-decoration-none"
                    style="font-size: 11px;">
                    <i class="mdi mdi-package-variant"></i>
                    <span>
                        View Stock (12)
                    </span>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Modal Component -->
<div class="modal fade facility-modal-wrapper" id="addFacilityModal" tabindex="-1"
    aria-labelledby="addFacilityModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 600px;">
        <div
            class="modal-content bg-white rounded-4 shadow-lg border border-secondary-subtle overflow-hidden facility-modal-container">

            <!-- Modal Header -->
            <div
                class="bg-primary text-white px-4 py-3 d-flex justify-content-between align-items-center facility-modal-header">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-office-building text-white fs-4 facility-modal-header-icon"></i>
                    <h4 class="font-weight-black fs-6 text-white mb-0 facility-modal-title" id="addFacilityModalLabel">
                        Register Project Site Yard or Warehouse</h4>
                </div>
                <button type="button" class="btn-close btn-close-white facility-modal-close-btn" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>

            <!-- Modal Form Body -->
            <form onsubmit="handleAddFacility(event)" class="p-4 vstack gap-3 small facility-modal-form">

                <!-- Row 1: Name & Code -->
                <div class="row g-2">
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Facility Name *</label>
                        <input type="text" required placeholder="e.g. Koyambedu Central Yard A"
                            class="form-control form-control-sm  fw-semibold facility-name-input" />
                    </div>
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Facility Code</label>
                        <input type="text" required placeholder="e.g. STR-MTR-01"
                            class="form-control form-control-sm font-monospace facility-code-input" />
                    </div>
                </div>

                <!-- Row 2: Type & Mapped Project -->
                <div class="row g-2">
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Facility Type *</label>
                        <select
                            class="select3  required form-select form-select-sm required fw-semibold facility-type-select select3 bg-primary ">
                            <option value="Site Yard">Site Yard</option>
                            <option value="Central Warehouse">Central Warehouse</option>
                            <option value="Regional Depot">Regional Depot</option>
                            <option value="Batching Yard">Batching Yard</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1" style="font-size: 10px;">Mapped
                            Project *</label>
                        <select class="select3 form-select form-select-sm rounded-3 row"
                            style="width: 220px; font-size: 11px;">
                            <option value="ALL">
                                All Project (Global View)
                            </option>
                            <option value="Annual Appraisal">
                                Chennai Metro Phase 2 - Corridor 4
                            </option>
                            <option value="Promotion with Increment">
                                Promotion with Increment
                            </option>
                        </select>
                    </div>
                </div>

                <!-- Row 3: Physical Location -->
                <div class="facility-input-group">
                    <label class="form-label text-muted fw-bold text-uppercase mb-1" style="font-size: 10px;">Physical
                        Location & Address *</label>
                    <input type="text" required placeholder="e.g. Inner Ring Road, Koyambedu, Chennai - 600107"
                        class="form-control form-control-sm facility-location-input" />
                </div>

                <!-- Row 4: Distance & Capacity -->
                <div class="row g-2">
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Distance / Proximity to Project</label>
                        <input type="text" required placeholder="e.g. 2.4 km (8 mins drive)"
                            class="form-control form-control-sm facility-distance-input" />
                    </div>
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Storage Capacity (Sqm)</label>
                        <input type="number" required placeholder="e.g. 3000"
                            class="form-control form-control-sm font-monospace facility-capacity-input" />
                    </div>
                </div>

                <!-- Row 5: Manager & Phone -->
                <div class="row g-2 pt-2 ">
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1" style="font-size: 10px;">Store
                            Manager In-charge</label>
                        <input type="text" required placeholder="e.g. M. Loganathan"
                            class="form-control form-control-sm  facility-manager-input" />
                    </div>
                    <div class="col-12 col-md-6 facility-input-group">
                        <label class="form-label text-muted fw-bold text-uppercase mb-1"
                            style="font-size: 10px;">Contact Phone</label>
                        <input type="text" required placeholder="e.g. +91 98400 11223"
                            class="form-control form-control-sm facility-phone-input" />
                    </div>
                </div>

                <!-- Modal Actions Footer -->
                <div
                    class="d-flex justify-content-end gap-2 pt-3 border-top border-secondary-subtle facility-modal-footer">
                    <button type="button"
                        class="btn btn-sm btn-light text-secondary fw-bold px-3 py-2 rounded-3 facility-cancel-btn"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit"
                        class="btn btn-sm btn-primary fw-bold px-3 py-2 rounded-3 shadow-sm facility-submit-btn">
                        Save Storage Facility
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.facility-card-hover {
    transition: all 0.2s ease-in-out;
}

.facility-card-hover:hover {

    border-color: var(--bs-primary) !important;
    transform: translateY(-2px);

}
</style>
@endsection
