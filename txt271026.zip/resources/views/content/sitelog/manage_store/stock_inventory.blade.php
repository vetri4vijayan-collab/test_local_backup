@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<!-- Header section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3 p-md-4">
        <div
            class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
            <div class="d-flex align-items-center gap-3">
                <i class="mdi mdi-package-variant-closed fs-1 text-primary"></i>
                <div>
                    <h4 class="mb-1 fw-bold text-primary">Manage store</h4>
                    <p class="text-muted mb-0 fs-7">Site Operations Management & Logs</p>
                </div>
            </div>
            <!-- Updated button to call setViewMode('form') -->
            <!-- <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" onclick="setViewMode('form')">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Vendor
                </button> -->

            <div class="nav-scroll-wrapper">

                {{--  Sites & Warehouses--}}
                <div class="nav-scroll-container gap-3 ">
                    {{-- Salary Structure & Wages Rate Link --}}
                    @php
                    $isSalaryActive = request()->is('/site/manage-store/site&warehouse');
                    @endphp
                    <a href="{{ url('/site/manage-store/site&warehouse') }}"
                        class="btn btn-sm rounded-3  text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
                        <span class="mdi mdi-domain pe-2"></span>
                        Sites & Warehouses
                    </a>

                    {{--  Stock Inventory Register --}}
                    @php
                    $isStockInventoryActive = request()->is('site/manage-store/stock_inventory');
                    @endphp
                    <a href="{{ url('/admin-hr/wages/permanent-staff/promotion&appraisal') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockInventoryActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-cube-outline pe-2"></i>
                        Stock Inventory Register
                    </a>

                    {{-- Stock Transfers --}}
                    @php
                    $isStockTransferActive = request()->is('/site/manage-store/stock_transfer');
                    @endphp
                    <a href="{{ url('/site/manage-store/stock_transfer') }}"
                        class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isStockTransferActive ? 'btn-primary' : 'btn-light' }}">
                        <i class="mdi mdi-swap-horizontal pe-2"></i>
                        Stock Transfers
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter section -->
<div class="card shadow-sm rounded-2 mb-4">
    <div class="card-body p-3">
        <div class="row align-items-center g-3">

            <!-- Search Input Column -->
            <div class="col-12 col-xl-4">
                <div class="input-group input-group-sm w-100 border border-secondary-subtle rounded-3 bg-white overflow-hidden shadow-none transition-all"
                    style="transition: all 0.2s ease-in-out;">
                    <span class="input-group-text text-muted bg-transparent px-2 border-0">
                        <i class="mdi mdi-magnify" style="font-size: 14px;"></i>
                    </span>
                    <input type="text" id="search_store" class="form-control border-0 ps-1 shadow-none bg-transparent"
                        style="font-size: 12px;" placeholder="Search store, location, material ...">
                </div>
            </div>

            <!-- Filters & Actions Column -->
            <div class="col-12 col-xl-8">
                <div class="d-flex flex-wrap align-items-center justify-content-xl-end gap-3">

                    <!-- Project Filter Group -->
                    <div class="d-flex align-items-center gap-2 flex-grow-1 flex-xl-grow-0">
                        <div class="d-flex align-items-center gap-1 text-dark flex-shrink-0">
                            <i class="mdi mdi-filter-outline text-secondary" style="font-size: 14px;"></i>
                            <span class="fw-bold text-uppercase text-nowrap text-secondary" style="font-size: 10px;">
                                Project:
                            </span>
                        </div>
                        <div class="flex-grow-1 flex-xl-grow-0" style="width: 100%; max-width: 310px;">
                            <select
                                class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold text-truncate w-100"
                                style="font-size: 11px; height: 31px;">
                                <option value="ALL">All Project (Global View)</option>
                                <option value="Chennai Metro Phase 2">Chennai Metro Phase 2 - Corridor 4</option>
                                <option value="Promotion with Increment">Promotion with Increment</option>
                            </select>
                        </div>
                    </div>

                    <!-- Facility Type Filter Group -->
                    <div class="d-flex align-items-center gap-2 flex-grow-1 flex-xl-grow-0">
                        <div class="d-flex align-items-center flex-shrink-0">
                            <span class="fw-bold text-uppercase text-nowrap text-secondary" style="font-size: 10px;">
                                Material Category:
                            </span>
                        </div>
                        <div class="flex-grow-1 flex-xl-grow-0" style="width: 100%; max-width: 180px;">
                            <select
                                class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold text-truncate w-100"
                                style="font-size: 11px; height: 31px;">
                                <option value="ALL">All Categories</option>
                                <option value="Site Yard">Civil Materials</option>
                                <option value="Central Warehouse">Steel Reinforcement</option>
                                <option value="Regional Depot">Aggregates</option>
                                <option value="Batching Yard">Fuel & Oil</option>
                                <option value="Hardware & Fittings">Hardware & Fittings</option>
                                <option value="Safety & Consumables">Safety & Consumables</option>
                            </select>
                        </div>

                        <!-- Reset Filter -->
                        <a href="#" class="text-primary text-decoration-underline text-nowrap fw-semibold flex-shrink-0"
                            style="font-size: 11px;">
                            Reset Filter
                        </a>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<div class="container-fluid p-0">
    <!-- Header Section -->
    <div class="d-flex flex-column flex-sm-row align-items-sm-center justify-content-between gap-2 mb-3">
        <h3 class="fs-6 fw-black text-uppercase text-secondary mb-0">
            Site Inventory & Material Stock Register
        </h3>
        <button type="button" class="btn btn-primary btn-sm fw-bold px-3 py-1.5 rounded-2 d-inline-flex align-items-center gap-1 shadow-sm
            " style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#addStockModal">
            <i class=" mdi mdi-plus"></i>
            <span>Add Stock Item</span>
        </button>
    </div>

    <!-- Table Card Section -->
    <div class="card border-0 shadow-sm rounded-0 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="font-size: 0.75rem;">
                <thead class="fw-semibold text-black fs-8 uppercase bg-light"
                    style="font-size: 10px; letter-spacing: 0.05em;">
                    <tr>
                        <th class="p-2 pb-3 min-w-100px text-black text-center">SKU / Item Code</th>
                        <th class="p-3 min-w-100px text-black text-center">Material Description & Category</th>
                        <th class="p-3 min-w-100px text-black text-center">Storage Facility / Yard Location</th>
                        <th class="p-3 min-w-100px text-black text-center">Mapped Project</th>
                        <th class="p-3 min-w-100px text-black text-end text-center">Current Stock</th>
                        <th class="p-3 min-w-100px text-black text-end text-center">Reorder Threshold</th>
                        <th class="p-3 min-w-100px text-black text-end text-center">Unit Price (₹)</th>
                        <th class="p-3 min-w-100px text-black text-center">Status</th>
                        <th class="p-3 min-w-100px text-black text-center">Action</th>
                    </tr>
                </thead>
                <tbody class="fw-medium text-dark border-top-0">
                    <!-- Loop Item Row Example -->
                    <tr>
                        <td class="p-3 font-monospace fw-bold text-primary text-center">MAT-STL-20</td>
                        <td class="p-3">
                            <span class="fw-bold text-dark d-block">Portland Cement Grade 53</span>
                            <span class="text-muted d-block" style="font-size: 10px;">Raw Materials</span>
                        </td>
                        <td class="p-3">
                            <div class="d-flex align-items-center gap-1 text-dark fw-bold">
                                <i class="bi bi-warehouse text-muted" style="font-size: 13px;"></i>
                                <span>Central Warehouse - Yard A</span>
                            </div>
                        </td>
                        <td class="p-3 text-muted" style="font-size: 11px;">Alpha Tower Project</td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            1,250 <span class="fw-normal text-muted" style="font-size: 10px;">Bags</span>
                        </td>
                        <td class="p-3 text-center font-monospace text-muted">
                            200 Bags
                        </td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            ₹ 380
                        </td>
                        <td class="p-3 text-center">
                            <span
                                class="badge bg-success bg-opacity-10 text-success border border-success fw-bold px-2 py-1 rounded-2"
                                style="font-size: 10px;">
                                In Stock
                            </span>
                        </td>
                        <td class="p-3 text-center text-primary" style="cursor: pointer;" data-bs-toggle="modal"
                            data-bs-target="#transferModal">
                            <i class="mdi mdi-swap-horizontal fs-5 align-middle"></i>
                            <span class="bg-none fw-bold" style="font-size: 11px;">Transfer</span>
                        </td>
                    </tr>

                    <tr>
                        <td class="p-3 font-monospace fw-bold text-primary text-center">MAT-CEM-01</td>
                        <td class="p-3">
                            <span class="fw-bold text-dark d-block">Portland Cement Grade 53</span>
                            <span class="text-muted d-block" style="font-size: 10px;">Raw Materials</span>
                        </td>
                        <td class="p-3">
                            <div class="d-flex align-items-center gap-1 text-dark fw-bold">
                                <i class="bi bi-warehouse text-muted" style="font-size: 13px;"></i>
                                <span>Central Warehouse - Yard A</span>
                            </div>
                        </td>
                        <td class="p-3 text-muted" style="font-size: 11px;">Alpha Tower Project</td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            1,250 <span class="fw-normal text-muted" style="font-size: 10px;">Bags</span>
                        </td>
                        <td class="p-3 text-center font-monospace text-muted">
                            200 Bags
                        </td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            ₹ 380
                        </td>
                        <td class="p-3 text-center">
                            <span
                                class="badge bg-warning bg-opacity-10 text-warning border border-warning fw-bold px-2 py-1 rounded-2"
                                style="font-size: 10px;">
                                Low Stock
                            </span>
                        </td>
                        <td class="p-3 text-center text-primary" style="cursor: pointer;" data-bs-toggle="modal"
                            data-bs-target="#transferModal">
                            <i class="mdi mdi-swap-horizontal fs-5 align-middle"></i>
                            <span class="bg-none fw-bold" style="font-size: 11px;">Transfer</span>
                        </td>
                    </tr>

                    <tr>
                        <td class="p-3 font-monospace fw-bold text-primary text-center">MAT-STL-20</td>
                        <td class="p-3">
                            <span class="fw-bold text-dark d-block">Portland Cement Grade 53</span>
                            <span class="text-muted d-block" style="font-size: 10px;">Raw Materials</span>
                        </td>
                        <td class="p-3">
                            <div class="d-flex align-items-center gap-1 text-dark fw-bold">
                                <i class="bi bi-warehouse text-muted" style="font-size: 13px;"></i>
                                <span>Central Warehouse - Yard A</span>
                            </div>
                        </td>
                        <td class="p-3 text-muted" style="font-size: 11px;">Alpha Tower Project</td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            1,250 <span class="fw-normal text-muted" style="font-size: 10px;">Bags</span>
                        </td>
                        <td class="p-3 text-center font-monospace text-muted">
                            200 Bags
                        </td>
                        <td class="p-3 text-center font-monospace fw-bold text-dark">
                            ₹ 380
                        </td>
                        <td class="p-3 text-center">
                            <span
                                class="badge bg-danger bg-opacity-10 text-danger border border-danger fw-bold px-2 py-1 rounded-2"
                                style="font-size: 10px;">
                                Critical
                            </span>
                        </td>
                        <td class="p-3 text-center text-primary" style="cursor: pointer;" data-bs-toggle="modal"
                            data-bs-target="#transferModal">
                            <i class="mdi mdi-swap-horizontal fs-5 align-middle"></i>
                            <span class="bg-none fw-bold" style="font-size: 11px;">Transfer</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Container with matching ID -->
<div class="modal fade" id="transferModal" tabindex="-1" aria-labelledby="transferModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg mx-auto " style="max-width: 600px;">
        <div class="modal-content border border-secondary-subtle shadow-lg rounded-4   overflow-hidden">

            <!-- Modal Header -->
            <div class="bg-primary text-white px-4 py-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-swap-horizontal text-white fs-4"></i>
                    <h4 class="fw-black text-white fs-6 mb-0" id="transferModalLabel">Initiate Inter-Store Material
                        Transfer</h4>
                </div>
                <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>

            <!-- Modal Body Form -->
            <form class="p-4 fs-7">

                <!-- Row 1: Source & Destination -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label text-[8px] fw-bold text-secondary text-uppercase mb-1">
                            Select Source Store / Yard *
                        </label>
                        <select id="trfSourceId"
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold">
                            <option value="">Select Source Store</option>
                            <option value="metro-central-a">Metro Central Yard A</option>
                            <option value="south-region-warehouse">South Region Central Warehouse</option>
                            <option value="adyar-site-b">Adyar Site Yard B</option>
                            <option value="ecr-bridge-c">ECR Bridge Batching & Material Yard C</option>
                            <option value="sriperumbudur-depot">Sriperumbudur Regional Materials Yard</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Destination Site Yard *
                        </label>
                        <select id="trfDestId"
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold">
                            <option value="">Select Destination Yard</option>
                            <option value="south-region-warehouse">South Region Central Warehouse (Multi-project
                                Central)Depot
                            </option>
                            <option value="adyar-site-b">Adyar Site Yard B</option>
                        </select>
                    </div>
                </div>

                <!-- Row 2: Material Name & Quantity -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">Material
                            Name
                            *</label>
                        <input type="text" required placeholder="e.g. PPC Cement / 20mm TMT Steel" id="trfItemName"
                            class="form-control form-control-sm  border-secondary-subtle rounded-3 fw-bold" />
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">Quantity
                            *</label>
                        <input type="number" required placeholder="e.g. 50" id="trfQty"
                            class="form-control form-control-sm    border-secondary-subtle rounded-3 font-monospace fw-bold" />
                    </div>
                </div>

                <!-- Row 3: Vehicle & Transporter -->
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">Vehicle /
                            Truck
                            No.</label>
                        <input type="text" required placeholder="e.g. TN-09-CB-4521" id="trfVehicle"
                            class="form-control form-control-sm  border-secondary-subtle rounded-3 font-monospace" />
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">Transporter
                            Name</label>
                        <input type="text" required placeholder="e.g. SRK Logistics Division" id="trfTransporter"
                            class="form-control form-control-sm border-secondary-subtle rounded-3" />
                    </div>
                </div>

                <!-- Modal Footer Buttons -->
                <div class="d-flex justify-content-end gap-2 pt-3 border-top border-light">
                    <button type="button" class="btn btn-light btn-sm fw-bold text-secondary px-3 rounded-2"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary btn-sm fw-bold text-white px-3 rounded-2 shadow-sm">
                        Dispatch Stock Transfer
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<!-- Add Stock Item Modal Container -->
<div class="modal fade" id="addStockModal" tabindex="-1" aria-labelledby="addStockModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg mx-auto" style="max-width: 600px;">
        <div class="modal-content border border-secondary-subtle shadow-lg rounded-3 overflow-hidden">

            <!-- Modal Header -->
            <div class="bg-primary text-white px-4 py-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-package-variant text-white fs-4"></i>
                    <h4 class="fw-black text-white fs-6 mb-0" id="addStockModalLabel">
                        Record Material Stock Item Entry
                    </h4>
                </div>
                <button type="button" class="btn-close text-white btn-close-white shadow-none" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>

            <!-- Modal Body Form -->
            <form class="p-4 fs-7">

                <!-- Row 1: Facility Yard & Item SKU -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Select Facility Yard *
                        </label>
                        <select id="stockFacilityId"
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold">
                            <option value="All">Select Facility Yard</option>
                            <option value="metrocentralyard">Metro Central Yard A (Site Yard)</option>
                            <option value="southregioncentral">South Region Central Warehouse (Central Warehouse)
                            </option>
                            <option value="siteyard">Adyar City Yard B (Site Yard)</option>
                            <option value="batchingyard">ECR Bridge Batching & Material Yard C (Batching Yard)</option>
                            <option value="regionaldepot">Sriperumbudur Regional Materials Depot (Regional Depot)
                            </option>
                        </select>
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Item SKU / Code
                        </label>
                        <input type="text" required placeholder="e.g. MAT-CEM-01" id="stockItemCode"
                            class="form-control form-control-sm border-secondary-subtle rounded-2 font-monospace" />
                    </div>
                </div>

                <!-- Row 2: Material Name & Category -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Material Name *
                        </label>
                        <input type="text" required placeholder="e.g. 20mm TMT Steel Fe550D" id="stockName"
                            class="form-control form-control-sm border-secondary-subtle rounded-2 fw-bold" />
                    </div>

                    <div class="col-12 col-md-6">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Category *
                        </label>
                        <select id="stockCategory"
                            class="select3 form-select form-select-sm bg-light border-secondary-subtle rounded-0 fw-semibold">
                            <option value="" disabled selected>Select Category</option>
                            <option value="Civil Materials">Civil Materials</option>
                            <option value="Steel Reinforcement">Steel Reinforcement</option>
                            <option value="Aggregates">Aggregates</option>
                            <option value="Fuel & Oil">Fuel & Oil</option>
                            <option value="Hardware & Fittings">Hardware & Fittings</option>
                            <option value="Safety & Consumables">Safety & Consumables</option>
                            <option value="Electrical & Wiring">Electrical & Wiring</option>
                            <option value="Plumbing & Sanitary">Plumbing & Sanitary</option>
                            <option value="Tools & Equipment">Tools & Equipment</option>
                        </select>
                    </div>
                </div>

                <!-- Row 3: Initial Stock Qty, Unit, & Reorder Level -->
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-4">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Initial Stock Qty *
                        </label>
                        <input type="number" required placeholder="e.g. 500" id="stockQty"
                            class="form-control form-control-sm border-secondary-subtle rounded-2 font-monospace fw-bold" />
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Unit
                        </label>
                        <input type="text" required placeholder="e.g. Bags / MT / Ltr" id="stockUnit"
                            class="form-control form-control-sm border-secondary-subtle rounded-2" />
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label text-[10px] fw-bold text-secondary text-uppercase mb-1">
                            Reorder Level
                        </label>
                        <input type="number" required placeholder="e.g. 100" id="stockReorder"
                            class="form-control form-control-sm border-secondary-subtle rounded-2 font-monospace" />
                    </div>
                </div>

                <!-- Modal Footer Buttons -->
                <div class="d-flex justify-content-end gap-2 pt-3 border-top border-light">
                    <button type="button" class="btn btn-light btn-sm fw-bold text-secondary px-3 rounded-2"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary btn-sm fw-bold text-white px-3 rounded-2 shadow-sm">
                        Save Stock Item
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<style>
/* Target the dropdown options container generated by your select plugin */
.select2-results__options,
.select3-results__options,
.dropdown-menu {
    max-height: 200px !important;
    overflow-y: auto !important;
}
</style>
@endsection
