@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
  /* Hide cursor globally except inside inputs */
  * {
    caret-color: transparent !important;
  }
  input, textarea, select {
    caret-color: auto !important;
  }
</style>

<div id="vendorListView">
    <!-- Header section -->
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            <div
                class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                <div class="d-flex align-items-center gap-3">
                    <i class="mdi mdi-truck-outline fs-1 text-primary"></i>
                    <div>
                        <h4 class="mb-1 fw-bold text-primary">Vendor</h4>
                        <p class="text-muted mb-0 fs-7">Site Operations Management & Logs</p>
                    </div>
                </div>
                <!-- Updated button to call setViewMode('form') -->
                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" onclick="setViewMode('form')">
                    <i class="mdi mdi-plus me-1"></i>
                    Add Vendor
                </button>
            </div>
        </div>
    </div>

    <!-- Filter section -->
    <div class="card shadow-sm rounded-2 mb-4">
        <div class="card-body p-3 p-md-4">
            
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                <div>
                <span>Show</span>
                <select id="perpage" class="form-select form-select-sm w-75px"
                    onchange="loadThemes(1)">
                        @php $options = [5,10, 25, 100, 500]; @endphp
                        @foreach ($options as $option)
                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                         {{ $option }}
                        </option>
                        @endforeach
                </select>
            </div>
                <div class="position-relative mt-4" style="max-width: 500px; width: 100%;">
                  <i class="mdi mdi-magnify position-absolute top-50 start-0 translate-middle-y ms-3 text-muted fs-5"></i>
                  <input
                      type="search"
                      class="form-control ps-5 rounded"
                      placeholder="Search by vendor, company type..." id="search_filter"
                  />
              </div>
                <div class="text-muted fs-7 mt-4 mb-0">
                    Showing active <span class="fw-semibold text-dark">{{$count}}</span> records
                </div>
            </div>
        </div>
    </div>

    <!-- List content  -->
    <div class="card  shadow-sm bg-white mb-0 mt-3 rounded-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle  text-dark" style="font-size: 0.85rem;">
                <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                    <tr>
                        <th class="py-3 px-3 esi-th-company min-w-100px text-black">Vendor Code & Company</th>
                        <th class="py-3 px-3 esi-th-type min-w-100px text-black">Vendor Type</th>
                        <th class="py-3 px-3 esi-th-contact min-w-100px text-black">Contact Representative</th>
                        <th class="py-3 px-3 esi-th-location min-w-100px text-black">City / District</th>
                        <th class="py-3 px-3 esi-th-tax min-w-100px text-black">PAN / GST No</th>
                        <th class="py-3 px-3 esi-th-bank min-w-100px text-black ">NEFT / RTGS Bank
                        <th class="py-3 px-3 text-center esi-th-machinery min-w-100px text-black ">Machinery Supply</th>
                        <th class="py-3 px-3 text-center esi-th-actions min-w-100px text-black">Actions</th>
                    </tr>
                </thead>
                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                        <tr class="skeleton-loader" id="skeleton-loader">
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                           </td>
                        </tr> 
                    </tbody>
            </table>
        </div>
        <div class="text-center my-3" id="pagination-container">
            <!-- Pagination buttons will appear here -->
        </div>
    </div>

</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteVendorModal" tabindex="-1" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content    shadow">

            <!-- Modal Header -->
            <div class="modal-header align-items-center pb-2">
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-alert-circle-outline text-danger fs-2"></i>
                    <h5 class="modal-title fw-bold text-dark mb-0" id="deleteModalLabel">Confirm Deletion</h5>
                </div>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body text-center py-0">

                <p class="text-muted mb-0" id="delete_message">Are you sure you want to delete this vendor record? <br> <strong
                        class="text-dark">This action cannot be undone.</strong></p>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer border-top-0 d-flex justify-content-center pt-0">
                <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger rounded-3 px-4" id="confirmDeleteBtn" onclick="deletelevel()">Yes,
                    Delete</button>
            </div>

        </div>
    </div>
</div>

<!-- VIEW 2: ADD VENDOR FORM VIEW (Hidden by default) -->
<div id="vendorFormView" style="display: none;">
    <div class="container py-4">
        <div class="card bg-white border border-secondary-subtle rounded-0 shadow-sm text-secondary">

            <!-- Top Bar / Header -->
            <div
                class="card-header px-4 py-3 border-bottom border-secondary-subtle bg-light d-flex align-items-center justify-content-between rounded-0">
                <div class="d-flex align-items-center gap-2">
                    <button type="button" onclick="setViewMode('list')" class="btn p-1" title="Back to Vendor List">
                        <i class="mdi mdi-arrow-left text-dark"></i>
                    </button>
                    <h2 class="fs-6 fw-bold text-dark text-uppercase m-0" id="formHeaderTitle">
                        ADD VENDOR
                    </h2>
                </div>
                <span class="text-muted font-monospace" style="font-size: 11px;">
                    Vendor Code: <span>NEW</span>
                </span>
            </div>

            <!-- Form Body -->
            <form action="{{ route('add_vendor') }}" method="POST" enctype="multipart/form-data" class="card-body p-4 p-md-5 fs-7" autocomplete="off" id="addvendorForm">
                @csrf
                <!-- ROW 1: Vendor Type*, Name Of The Company*, Vendor Name* -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Type<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="vendorType" name="vendorType"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            >
                            <option value="">Select Vendor Type</option>
                            @foreach ($vendor_list as $i=> $list) 
                            <option value="{{$list->sno}}" >{{$list->vendor_name}}</option> 
                            @endforeach
                        </select>
                        <div class="text-danger" id="vendor_type_err"></div>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Name Of The Company<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorCompany" name="vendorCompany" placeholder="e.g. EIBS COMPANY"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            <div class="text-danger" id="vendor_company_err"></div>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Name<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="vendorName" name="vendorName" required placeholder="e.g. John Doe"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div class="text-danger" id="vendor_name_err"></div>
                    </div>
                </div>

                <!-- ROW 2: Product Purchase Details, Address, Town/City -->
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Product Purchase Details
                        </label>
                        <input type="text" id="productPurchaseInput" placeholder="eg: cement, steel etc.."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div id="productPurchaseTags" class="mt-2 d-flex flex-wrap gap-1"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Country<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="country_id" name="country_id"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" onchange="countrychange()"
                            >   
                            <option value="">Select Country</option>
                            @foreach ($country_list as $i=> $list) 
                            <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                            @endforeach
                        </select>
                        <div class="text-danger" id="country_id_err"></div>
                    </div>
                    
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            State<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="state_id" name="state_id"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" onchange="statechange()"
                            >
                            <option value="">Select State</option>
                        </select>
                        <div class="text-danger" id="state_id_err"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            City<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="city_id" name="city_id"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" 
                            >
                            <option value="">Select City</option>
                        </select>
                        <div class="text-danger" id="city_id_err"></div>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Address (Door no. / Area)
                        </label>
                        <textarea
                           placeholder="Street address, industrial estate..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" 
                            style="resize: none;" rows="1" id="address" name="address"
                        ></textarea>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">
                            Pincode
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace"
                            placeholder="625001" id="pin_code" name="pin_code"
                        />
                        <div class="text-danger" id="pin_code_err"></div>
                        </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">PAN No<span class="text-danger fw-bold ms-1">*</span></label>
                        <input type="text" id="panNo" name ="panNo" placeholder="PAN No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />

                            <div class="text-danger" id="pan_number_err"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">GST No<span class="text-danger fw-bold ms-1">*</span></label>
                        <input type="text" id="gstNo" name="gstNo" placeholder="GST No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                        <div class="text-danger" id="gst_number_err"></div>
                    </div>
                      <!-- CORRECTED CHECKBOX ALIGNMENT -->
                        <div class="d-flex align-items-center justify-content-start mt-2">
                            <input type="checkbox"
                                    id="isSupply"
                                    onclick="SupplyValue(this)"
                                    style="width: 1rem; height: 1rem; cursor: pointer;">

                                <label for="isSupply">Is Supply Machinery</label>
                        </div>
                    
            

                <!-- SECTION: Person Details (Primary & Secondary) -->
                <div id="addPersonContainer">
                    <div class="mb-3">
                        <label class="text-dark fw-bold fs-6">Primary</label>
                    </div>
                    <div class="row g-3 mb-3 person-row">
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Type<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <select id="prmy_person_type" name="persons[0][person_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                <option value="">Select Type</option>
                                <option value="1">Technical</option>
                                <option value="2">Commercial</option>
                                <option value="3">Sales</option>
                                <option value="4">Management</option>
                            </select>
                            <div class="text-danger" id="prmy_person_type_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Name<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" id="prmy_person_name" name="persons[0][person_name]" placeholder="Project Manager EiBS"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            <div class="text-danger" id="prmy_person_name_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Mobile No<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" id="prmy_person_number" name="persons[0][person_number]" placeholder="9874561230"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            <div class="text-danger" id="prmy_person_number_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                                Id</label>
                            <input type="email" id="prmy_person_email" name="persons[0][person_email]" placeholder="projectmanager@eibsglobal.com"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                                No</label>
                            <input type="text" id="prmy_person_teleno" name="persons[0][person_teleno]" placeholder="Telephone No"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Person -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="addVendorPerson()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Contact Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- SECTION: Details for Making Payment by NEFT / RTGS (Primary & Secondary) -->
                <div id="addBankContainer">
                    <div class="pt-3 border-top border-secondary-subtle">
                        <div class="mb-3">
                            <label class="text-dark fw-bold fs-6 mb-2">Primary Bank Details</label><br>
                            <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                                Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                                Vendors' Account
                            </h3>
                        </div>

                        <div class="row g-3 mb-3 bank-row">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Name<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_name" name="banks[0][bank_name]" placeholder="Bank Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                 <div class="text-danger" id="prmy_bank_name_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Branch<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_branch" name="banks[0][bank_branch]" placeholder="Bank Branch"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="prmy_bank_branch_err"></div>
                            </div>
                               
                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Country <span class="text-danger">*</span></label>
                                <select id="prmy_bank_country_id" name="banks[0][bank_country]"
                                    class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    onchange="bankcountrychange()">
                                    <option value="">Select Country</option>
                                    @foreach ($country_list as $list)
                                        <option value="{{ $list->sno }}">
                                            {{ $list->country_name }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="text-danger" id="prmy_bank_country_id_err"></div> 
                            </div>
                    
                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State <span class="text-danger">*</span></label>
                                <select id="prmy_bank_state_id" name="banks[0][bank_state]"
                                class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    onchange="bankstatechange()" >
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="prmy_bank_state_id_err"></div> 
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">City <span class="text-danger">*</span></label>
                                <select id="prmy_bank_city_id" name="banks[0][bank_city]"
                                    class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="prmy_bank_city_id_err"></div> 
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Address<span class="text-danger">*</span></label>
                                <textarea rows="1" id="prmy_bank_address" name="banks[0][bank_address]" placeholder="Bank Address"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    style="resize: none;"></textarea>
                                    <div class="text-danger" id="prmy_bank_address_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Pincode<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_pin_code" name="banks[0][bank_pincode]" placeholder="600018"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="prmy_bank_pin_code_err"></div>
                            </div>
                        
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Name<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_acc_name" name="banks[0][bank_acc_name]" placeholder="Bank Account Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="prmy_bank_acc_name_err"></div>
                            </div>
                            
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Type<span class="text-danger">*</span></label>
                                <select id="prmy_bank_acc_type" name="banks[0][bank_acc_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="">Select Account Type</option>
                                    <option value="1">Current Account</option>
                                    <option value="2">Savings Account</option>
                                    <option value="3">Cash Credit (CC)</option>
                                    <option value="4">Overdraft (OD)</option>
                                </select>
                                <div class="text-danger" id="prmy_bank_acc_type_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Number<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_acc_number" name="banks[0][bank_acc_number]" placeholder="Bank Account Number"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                                    <div class="text-danger" id="prmy_bank_acc_number_err"></div>
                            </div>
                       

                        
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                                    of Bank<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_micr" name="banks[0][bank_micr]" placeholder="MICR Code of Bank"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                                    <div class="text-danger" id="prmy_bank_micr_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                                    RTGS Code No. of the Bank<span class="text-danger">*</span></label>
                                <input type="text" id="prmy_bank_ifsc" name="banks[0][bank_ifsc]" placeholder="IFSC / RTGS Code No."
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                                    <div class="text-danger" id="prmy_bank_ifsc_err"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Plus Action Button Icon for Bank -->
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="addVendorBank()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Bank Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

                <!-- Bottom Right Action Buttons -->
                <div
                    class="d-flex align-items-center justify-content-end gap-2 pt-4 border-top border-secondary-subtle">
                    <button type="button" onclick="setViewMode('list')"
                        class="btn btn-sm btn-light border border-secondary-subtle text-dark rounded-1 fw-semibold">
                        Cancel
                    </button>
                    <button type="button" id="submitBtn"
                        class="btn btn-sm text-white bg-primary rounded-1 fw-bold border-0">
                        <span id="submitBtnText" onclick="AddValidation()">Add Vendor</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
</div>

<!-- VIEW 3: UPDATE VENDOR FORM VIEW (Hidden by default) -->
<div id="vendorUpdateView" style="display: none;">
    <div class="container py-4">
        <div class="card bg-white border border-secondary-subtle rounded-0 shadow-sm text-secondary">

            <div
                class="card-header px-4 py-3 border-bottom border-secondary-subtle bg-light d-flex align-items-center justify-content-between rounded-0">
                <div class="d-flex align-items-center gap-2">
                    <button type="button" onclick="setViewMode('list')" class="btn p-1" title="Back to Vendor List">
                        <i class="mdi mdi-arrow-left text-dark"></i>
                    </button>
                    <h2 class="fs-6 fw-bold text-dark text-uppercase m-0" id="formHeaderTitle">
                        UPDATE VENDOR
                    </h2>
                </div>
                
                <span id="vendorCodeDisplay" style="font-size: 11px;">
                  </span>
            </div>

 
            <form id="vendorForm" onsubmit="handleSubmitForm(event)" class="card-body p-4 p-md-5 fs-7">

                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Type<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select 
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            id="update_vendorType" name="update_vendorType">
                            <option value="">Select Vendor Type</option>
                            @foreach ($vendor_list as $i=> $list) 
                            <option value="{{$list->sno}}" >{{$list->vendor_name}}</option> 
                            @endforeach
                        </select>
                        <div class="text-danger" id="update_vendorType_err"></div>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Name Of The Company<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="update_vendorCompany" name="update_vendorCompany" placeholder="e.g. EIBS COMPANY"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            <div class="text-danger" id="update_vendorCompany_err"></div>
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Vendor Name<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <input type="text" id="update_vendorName" name="update_vendorName" placeholder="e.g. John Doe"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                            <div class="text-danger" id="update_vendorName_err"></div>
                    </div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Product Purchase Details
                        </label>
                        <input type="text" id="update_productPurchase" name="update_productPurchase" placeholder="Type product & press Enter..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div id="updateProductPurchaseTags" class="mt-2 d-flex flex-wrap gap-1"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Country<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="update_Country" name="update_Country"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" onchange="update_country_change()"
                            >   
                            <option value="">Select Country</option>
                            @foreach ($country_list as $i=> $list) 
                            <option value="{{$list->sno}}" >{{$list->country_name}}</option> 
                            @endforeach
                        </select>
                        <div class="text-danger" id="update_Country_err"></div>
                    </div>
                    
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            State<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="update_State" name="update_State"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" onchange="update_state_change()"
                            >
                            <option value="">Select State</option>
                        </select>
                        <div class="text-danger" id="update_State_err"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            City<span class="text-danger fw-bold ms-1">*</span>
                        </label>
                        <select id="update_City" name="update_City"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" 
                            >
                            <option value="">Select City</option>
                        </select>
                        <div class="text-danger" id="update_City_err"></div>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                            Address (Door no. / Area)
                        </label>
                        <textarea
                           placeholder="Street address, industrial estate..."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" 
                            style="resize: none;" rows="1" id="update_Address" name="update_Address"
                        ></textarea>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1"
                            style="font-size: 11px;">
                            Pincode
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace"
                            placeholder="625001" id="update_Pincode" name="update_Pincode"
                        />
                        <div class="text-danger" id="update_Pincode_err"></div>
                    </div>                    
                
                    
                </div>

                <div class="row g-3 mb-3 align-items-start">
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">PAN
                            No</label>
                        <input type="text" id="update_panNo" name="update_panNo" placeholder="PAN No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            <div class="text-danger" id="update_panNo_err"></div>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">GST
                            No</label>
                        <input type="text" id="update_gstNo" name="update_gstNo" placeholder="GST No"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            <div class="text-danger" id="update_gstNo_err"></div>
                        
                       
                    </div>
                        <div class="d-flex align-items-center justify-content-start mt-2">
                            <input type="checkbox"
                                    id="isSupplyMachinery"
                                    onclick="updateSupplyValue(this)"
                                    style="width: 1rem; height: 1rem; cursor: pointer;">

                                <label for="isSupplyMachinery">Is Supply Machinery</label>
                        </div>
                    
                </div>
                <div id="updatePersonContainer">
                    <div class="mb-3">
                        <label class="text-dark fw-bold fs-6">Primary</label>
                    </div>
                    <div class="row g-3 mb-3 person-row">
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Type<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <select id="update_personType" name="update_personType" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                <option value="">Select Type</option>
                                <option value="1">Technical</option>
                                <option value="2">Commercial</option>
                                <option value="3">Sales</option>
                                <option value="4">Management</option>
                            </select>
                            <div class="text-danger" id="update_personType_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Person Name<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" id="update_personName" name="update_personName" placeholder="Project Manager EiBS"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                <div class="text-danger" id="update_personName_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                                Mobile No<span class="text-danger fw-bold ms-1">*</span>
                            </label>
                            <input type="text" id="update_personNumber" name="update_personNumber" placeholder="9874561230"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                                <div class="text-danger" id="update_personNumber_err"></div>
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                                Id</label>
                            <input type="email" id="update_personEmail" name="update_personEmail" placeholder="projectmanager@eibsglobal.com"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        </div>
                        <div class="col-12 col-sm-6 col-md">
                            <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                                No</label>
                            <input type="text" id="update_personTeleno" name="update_personTeleno" placeholder="Telephone No"
                                class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                        </div>
                    </div>
                </div>


                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="updateVendorPerson()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Contact Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

      
                <div id="updateBankContainer">
                    <div class="pt-3 border-top border-secondary-subtle">
                        <div class="mb-3">
                            <label class="text-dark fw-bold fs-6 mb-2">Primary Bank Details</label><br>
                            <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                                Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                                Vendors' Account
                            </h3>
                        </div>

                        <div class="row g-3 mb-3 bank-row">
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Name<span class="text-danger">*</span></label>
                                <input type="text" id="update_bankName" name="banks[0][bank_name]" placeholder="Bank Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="update_bankName_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Branch<span class="text-danger">*</span></label>
                                <input type="text" id="update_bankBranch" name="banks[0][bank_branch] placeholder="Bank Branch"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="update_bankBranch_err"></div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Country <span class="text-danger">*</span></label>
                                <select id="update_bankCountry" name="banks[0][bank_country]"
                                    class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    onchange="update_bank_country()">
                                    <option value="">Select Country</option>
                                    @foreach ($country_list as $list)
                                        <option value="{{ $list->sno }}">
                                            {{ $list->country_name }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="text-danger" id="update_bankCountry_err"></div> 
                            </div>
                    
                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State <span class="text-danger">*</span></label>
                                <select id="update_bankState" name="banks[0][bank_state]"
                                class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    onchange="update_bank_state()" >
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="update_bankState_err"></div> 
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">City <span class="text-danger">*</span></label>
                                <select id="update_bankCity" name="banks[0][bank_city]"
                                    class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="update_bankCity_err"></div> 
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Address<span class="text-danger">*</span></label>
                                <textarea rows="1" id="update_bankAddress" name="banks[0][bank_address]" placeholder="Bank Address"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                                    style="resize: none;"></textarea>
                                    <div class="text-danger" id="update_bankAddress_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Pincode<span class="text-danger">*</span></label>
                                <input type="text" id="update_bankPincode" name="banks[0][bank_pincode]" placeholder="600018"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="update_bankPincode_err"></div>
                            </div>
                         
                  
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Name<span class="text-danger">*</span></label>
                                <input type="text" id="update_accName" name="banks[0][bank_acc_name]" placeholder="Bank Account Name"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                                    <div class="text-danger" id="update_accName_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Type<span class="text-danger">*</span></label>
                                <select id="update_accType" name="banks[0][bank_acc_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                                    <option value="">Select Account Type</option>
                                    <option value="1">Current Account</option>
                                    <option value="2">Savings Account</option>
                                    <option value="3">Cash Credit (CC)</option>
                                    <option value="4">Overdraft (OD)</option>
                                </select>
                                <div class="text-danger" id="update_accType_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                                    Account Number<span class="text-danger">*</span></label>
                                <input type="text" id="update_accNumber" name="banks[0][bank_acc_number]" placeholder="Bank Account Number"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                                    <div class="text-danger" id="update_accNumber_err"></div>
                            </div>
                    
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                                    of Bank<span class="text-danger">*</span></label>
                                <input type="text" id="update_bankMicr" name="banks[0][bank_micr]" placeholder="MICR Code of Bank"
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                                    <div class="text-danger" id="update_bankMicr_err"></div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                                    RTGS Code No. of the Bank<span class="text-danger">*</span></label>
                                <input type="text" id="update_bankIfsc" name="banks[0][bank_ifsc]" placeholder="IFSC / RTGS Code No."
                                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                                    <div class="text-danger" id="update_bankIfsc_err"></div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="d-flex justify-content-end pe-1 mb-4">
                    <button type="button" onclick="updateVendorBank()"
                        class="btn btn-sm text-white rounded-1 bg-primary d-flex align-items-center justify-content-center border-0 shadow-none"
                        style="width: 28px; height: 28px;" title="Add Bank Entry">
                        <i class="mdi mdi-plus"></i>
                    </button>
                </div>

        
                <div
                    class="d-flex align-items-center justify-content-end gap-2 pt-4 border-top border-secondary-subtle">
                    <button type="button" onclick="setViewMode('list')"
                        class="btn btn-sm btn-light border border-secondary-subtle text-dark rounded-1 fw-semibold">
                        Cancel
                    </button>
                    <button type="button" id="submitBtn"
                        class="btn btn-sm text-white bg-primary rounded-1 fw-bold border-0" onclick="saveUpdatevendor()">
                        <span id="submitBtnText">Update Vendor</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
function setViewMode(mode) {
    console.log('Requested mode:', mode);

    const listView = document.getElementById('vendorListView');
    const formView = document.getElementById('vendorFormView');
    const updateView = document.getElementById('vendorUpdateView');

    console.log({
        listViewFound: !!listView,
        formViewFound: !!formView,
        updateViewFound: !!updateView
    });

    if (listView) listView.style.display = 'none';
    if (formView) formView.style.display = 'none';
    if (updateView) updateView.style.display = 'none';

    if (mode === 'list' && listView) {
        listView.style.display = 'block';
    } else if (mode === 'form' && formView) {
        formView.style.display = 'block';
    } else if (mode === 'update' && updateView) {
        updateView.style.display = 'block';
    }
}

// Function to dynamically add Person (Add Form) - Fax No removed
let personCount = 1;
function addVendorPerson() {
    
    const container = document.getElementById('addPersonContainer');
    const newRow = document.createElement('div');
  
    newRow.className = 'mt-4 secondary-person';
    newRow.innerHTML = `
        <div class="mb-3 border-top border-secondary-subtle pt-4">
            <label class="text-dark fw-bold fs-6">Secondary</label>
        </div>
        <div class="row g-3 mb-3 person-row">
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Type<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <select name="persons[${personCount}][person_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                
                    <option value="">Select Type</option>
                    <option value="1">Technical</option>
                    <option value="2">Commercial</option>
                    <option value="3">Sales</option>
                    <option value="4">Management</option>
                </select>
                <div class="text-danger person-type-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Name<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" name="persons[${personCount}][person_name]" placeholder="Project Manager EiBS"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                <div class="text-danger person-name-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Mobile No<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" name="persons[${personCount}][person_number]" placeholder="9874561230"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                <div class="text-danger person-number-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                    Id</label>
                <input type="email" name="persons[${personCount}][person_email]" placeholder="projectmanager@eibsglobal.com"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                <div class="text-danger person-email-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                    No</label>
                <input type="text" placeholder="Telephone No" name="persons[${personCount}][person_teleno]"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
    personCount++;
}

// Function to dynamically add Bank (Add Form)

let bankCount = 1;
function addVendorBank() {
    const container = document.getElementById('addBankContainer');
    const newRow = document.createElement('div');
    const index = bankCount++;
     newRow.className = 'mt-4 border-top pt-4 secondary-bank';
    newRow.innerHTML = `
        <div class="pt-4 border-top border-secondary-subtle">
            <div class="mb-3">
                <label class="text-dark fw-bold fs-6 mb-2">Secondary Bank Details</label><br>
                <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                    Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                    Vendors' Account
                </h3>
            </div>

            <div class="row g-3 mb-3 bank-row">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Name <span class="text-danger">*</span></label>
                    <input type="text" name="banks[${index}][bank_name]" placeholder="Bank Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    <div class="text-danger bank-name-error"></div> 
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Branch<span class="text-danger">*</span></label>
                    <input type="text" name="banks[${index}][bank_branch]" placeholder="Bank Branch"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div class="text-danger bank-branch-error"></div> 
                </div>
                
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Country <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_country]"
                            class="select3 form-select form-select-sm bank-country bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            onchange="bankCountryChange(this)">
                            <option value="">Select Country</option>
                            @foreach ($country_list as $list)
                                <option value="{{ $list->sno }}">
                                    {{ $list->country_name }}
                                </option>
                            @endforeach
                        </select>
                        <div class="text-danger bank-country-error"></div> 
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_state]"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none  bank-state"
                            onchange="bankStateChange(this)">
                            <option value="">Select State</option>
                        </select>
                        <div class="text-danger bank-state-error"></div> 
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">City <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_city]"
                            class="select3 bank-city form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                            <option value="">Select City</option>
                        </select>
                        <div class="text-danger bank-city-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold">Bank
                            Address<span class="text-danger">*</span></label>
                        <textarea rows="1" name="banks[${index}][bank_address]" placeholder="Bank Address"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></textarea>
                            <div class="text-danger bank-address-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold">Bank
                            Pincode<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_pincode]" placeholder="600018"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></input>
                            <div class="text-danger bank-pincode-error"></div> 
                    </div>
                
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Name<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_acc_name]" placeholder="Bank Account Name"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div class="text-danger bank-acc-name-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Type<span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_acc_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                            <option value="">Select Account Type</option>
                            <option value="1">Current Account</option>
                            <option value="2">Savings Account</option>
                            <option value="3">Cash Credit (CC)</option>
                            <option value="4">Overdraft (OD)</option>
                        </select>
                        <div class="text-danger bank-acc-type-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Number<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_acc_number]" placeholder="Bank Account Number"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            <div class="text-danger bank-acc-no-error"></div> 
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                            of Bank<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_micr]" placeholder="MICR Code of Bank"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            <div class="text-danger bank-micr-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                            RTGS Code No. of the Bank<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_ifsc]" placeholder="IFSC / RTGS Code No."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            <div class="text-danger bank-ifsc-error"></div> 
                    </div>
                </div>
            <div class="col-12 d-flex justify-content-end pb-3">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}

// Function to dynamically add Person (Update Form) - Fax No removed





// Add a small script to handle the Product Purchase Tags dynamically
document.addEventListener('DOMContentLoaded', function() {
    function setupProductTags(inputId, containerId) {
        const input = document.getElementById(inputId);
        const container = document.getElementById(containerId);
        if(!input || !container) return;

        let tags = [];
        
        function renderTags() {
            container.innerHTML = '';
            tags.forEach((tag, index) => {
                const chip = document.createElement('span');
                chip.className = 'badge bg-primary-subtle text-primary border border-primary rounded-pill px-2 py-1 d-inline-flex align-items-center gap-1';
                chip.style.fontSize = '10px';
                chip.innerHTML = `
                    ${tag}
                    <i class="mdi mdi-close cursor-pointer" style="font-size: 12px;" onclick="removeTag_${inputId}(${index})"></i>
                `;
                container.appendChild(chip);
            });
        }

        window[`removeTag_${inputId}`] = function(index) {
            tags.splice(index, 1);
            renderTags();
        };

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                const val = input.value.trim();
                if (val && !tags.includes(val)) {
                    tags.push(val);
                    input.value = '';
                    renderTags();
                }
            }
        });
    }

    setupProductTags('productPurchaseInput', 'productPurchaseTags');
    setupProductTags('updateProductPurchaseInput', 'updateProductPurchaseTags');
});
</script>

<script>
    let updatePersonCount = 1;
function updateVendorPerson() {
    
    const container = document.getElementById('updatePersonContainer');
    const newRow = document.createElement('div');
  const index = updatePersonCount++;
    newRow.className = 'mt-4 secondary-person';
    newRow.innerHTML = `
        <div class="mb-3 border-top border-secondary-subtle pt-4">
            <label class="text-dark fw-bold fs-6">Secondary</label>
        </div>
        <div class="row g-3 mb-3 person-row">
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Type<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <select name="persons[${index}][person_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                
                    <option value="">Select Type</option>
                    <option value="1">Technical</option>
                    <option value="2">Commercial</option>
                    <option value="3">Sales</option>
                    <option value="4">Management</option>
                </select>
                <div class="text-danger person-type-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Person Name<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" name="persons[${index}][person_name]" placeholder="Project Manager EiBS"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                <div class="text-danger person-name-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">
                    Mobile No<span class="text-danger fw-bold ms-1">*</span>
                </label>
                <input type="text" name="persons[${index}][person_number]" placeholder="9874561230"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                <div class="text-danger person-number-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Email
                    Id</label>
                <input type="email" name="persons[${index}][person_email]" placeholder="projectmanager@eibsglobal.com"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                <div class="text-danger person-email-error"></div>
            </div>
            <div class="col-12 col-sm-6 col-md">
                <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Telephone
                    No</label>
                <input type="text" placeholder="Telephone No" name="persons[${index}][person_teleno]"
                    class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
            </div>
            <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
    
}

// Function to dynamically add Bank (Update Form)

let updatebankCount = 0;
function updateVendorBank() {
    const container = document.getElementById('updateBankContainer');
    const newRow = document.createElement('div');
    const index = updatebankCount++;
     newRow.className = 'mt-4 border-top pt-4 secondary-bank';
    newRow.innerHTML = `
        <div class="pt-4 border-top border-secondary-subtle">
            <div class="mb-3">
                <label class="text-dark fw-bold fs-6 mb-2">Secondary Bank Details</label><br>
                <h3 class="fw-bold text-dark mb-3" style="font-size: 11px;">
                    Details for Making Payment by NEFT / RTGS, with the NEFT / RTGS bank charges to Suppliers' /
                    Vendors' Account
                </h3>
            </div>

            <div class="row g-3 mb-3 bank-row">
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Name <span class="text-danger">*</span></label>
                    <input type="text" name="banks[${index}][bank_name]" placeholder="Bank Name"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                    <div class="text-danger bank-name-error"></div> 
                </div>
                <div class="col-12 col-md-4">
                    <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                        Branch<span class="text-danger">*</span></label>
                    <input type="text" name="banks[${index}][bank_branch]" placeholder="Bank Branch"
                        class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div class="text-danger bank-branch-error"></div> 
                </div>
                
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Country <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_country]"
                            class="select3 form-select form-select-sm bank-country bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            onchange="bankCountryChange(this)">
                            <option value="">Select Country</option>
                            @foreach ($country_list as $list)
                                <option value="{{ $list->sno }}">
                                    {{ $list->country_name }}
                                </option>
                            @endforeach
                        </select>
                        <div class="text-danger bank-country-error"></div> 
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">State <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_state]"
                            class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none  bank-state"
                            onchange="bankStateChange(this)">
                            <option value="">Select State</option>
                        </select>
                        <div class="text-danger bank-state-error"></div> 
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">City <span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_city]"
                            class="select3 bank-city form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                            <option value="">Select City</option>
                        </select>
                        <div class="text-danger bank-city-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold">Bank
                            Address<span class="text-danger">*</span></label>
                        <textarea rows="1" name="banks[${index}][bank_address]" placeholder="Bank Address"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></textarea>
                            <div class="text-danger bank-address-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold">Bank
                            Pincode<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_pincode]" placeholder="600018"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none"
                            style="resize: none;"></input>
                            <div class="text-danger bank-pincode-error"></div> 
                    </div>
                
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Name<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_acc_name]" placeholder="Bank Account Name"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none" />
                        <div class="text-danger bank-acc-name-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Type<span class="text-danger">*</span></label>
                        <select name="banks[${index}][bank_acc_type]" class="select3 form-select form-select-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none">
                            <option value="">Select Account Type</option>
                            <option value="1">Current Account</option>
                            <option value="2">Savings Account</option>
                            <option value="3">Cash Credit (CC)</option>
                            <option value="4">Overdraft (OD)</option>
                        </select>
                        <div class="text-danger bank-acc-type-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">Bank
                            Account Number<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_acc_number]" placeholder="Bank Account Number"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            <div class="text-danger bank-acc-no-error"></div> 
                    </div>

                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">MICR Code
                            of Bank<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_micr]" placeholder="MICR Code of Bank"
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace" />
                            <div class="text-danger bank-micr-error"></div> 
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label fw-semibold text-secondary mb-1" style="font-size: 11px;">IFSC /
                            RTGS Code No. of the Bank<span class="text-danger">*</span></label>
                        <input type="text" name="banks[${index}][bank_ifsc]" placeholder="IFSC / RTGS Code No."
                            class="form-control form-control-sm bg-white border-secondary-subtle text-dark rounded-1 shadow-none font-monospace text-uppercase" />
                            <div class="text-danger bank-ifsc-error"></div> 
                    </div>
                </div>
            <div class="col-12 d-flex justify-content-end pb-3">
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('.mt-4').remove()">
                    <i class="mdi mdi-delete-outline"></i> Remove
                </button>
            </div>
        </div>
    `;
    container.appendChild(newRow);
}
</script>

<script>
    function AddValidation() {
            let err=0;  
            var vendor_type=$('#vendorType').val();
            var vendor_company_name=$('#vendorCompany').val();
            var vendor_name=$('#vendorName').val();
            var country_id=$('#country_id').val();
            var state_id=$('#state_id').val();
            var city_id=$('#city_id').val();
            var address=$('#address').val();
            var pin_code=$('#pin_code').val();
            var pan_number=$('#panNo').val();
            var gst_number=$('#gstNo').val();
            var aadhar_no=$('#aadhar_no').val();
            var esi_no=$('#esi_no').val();
            var epf_no=$('#epf_no').val();
            var primary_person_type=$('#prmy_person_type').val().trim();
            var primary_person_name=$('#prmy_person_name').val().trim();
            var primary_person_number=$('#prmy_person_number').val().trim();
            var primary_person_email=$('#prmy_person_email').val().trim();
            var primary_person_teleno=$('#prmy_person_teleno').val().trim();
            var primary_bank_name=$('#prmy_bank_name').val();
            var primary_bank_branch=$('#prmy_bank_branch').val();
            var primary_bank_address=$('#prmy_bank_address').val();
            console.log(primary_bank_address);
            var primary_acc_name=$('#prmy_bank_acc_name').val();
            var primary_acc_type=$('#prmy_bank_acc_type').val();
            var primary_acc_no=$('#prmy_bank_acc_number').val();
            var primary_bank_micr=$('#prmy_bank_micr').val();
            var primary_bank_ifsc=$('#prmy_bank_ifsc').val();
            var primary_bank_country_id=$('#prmy_bank_country_id').val();
            var primary_bank_state_id=$('#prmy_bank_state_id').val();
            var primary_bank_city_id=$('#prmy_bank_city_id').val();
            var primary_bank_pin_code=$('#prmy_bank_pin_code').val();
            var isSupply=isSupply;
       
            $('.secondary-person').each(function () {
            const row = $(this);

            const type = row.find('[name$="[person_type]"]');
            const name = row.find('[name$="[person_name]"]');
            const mobile = row.find('[name$="[person_number]"]');
            const email = row.find('[name$="[person_email]"]');
            const teleno = row.find('[name$="[person_teleno]"]');

            row.find('.person-type-error, .person-name-error, .person-number-error, .person-email-error')
                    .text('');

            if (!type.val()) {
                type.siblings('.person-type-error').text('Person Type is required');
            err++;
            }

            if (!name.val().trim()) {
                name.siblings('.person-name-error').text('Person Name is required');
                err++;
            }

            if (!mobile.val().trim()) {
                mobile.siblings('.person-number-error').text('Mobile No is required');
                err++;
            }

            if (email.val().trim() &&
                !/^\S+@\S+\.\S+$/.test(email.val().trim())) {
                email.siblings('.person-email-error').text('Enter a valid email');
                err++;
            }
        });


             $('.secondary-bank').each(function () {
                const row = $(this);
                const bankName = row.find('[name$="[bank_name]"]');
                const branch = row.find('[name$="[bank_branch]"]');
                const country = row.find('[name$="[bank_country]"]');
                const state = row.find('[name$="[bank_state]"]');
                const city = row.find('[name$="[bank_city]"]');
                const address = row.find('[name$="[bank_address]"]');
                const pin = row.find('[name$="[bank_pincode]"]');
                const accName = row.find('[name$="[bank_acc_name]"]');
                const accType = row.find('[name$="[bank_acc_type]"]');
                const accNo = row.find('[name$="[bank_acc_number]"]');  
                const micr = row.find('[name$="[bank_micr]"]');
                const ifsc = row.find('[name$="[bank_ifsc]"]');

                row.find(
                    '.bank-name-error, .bank-branch-error, .bank-country-error, ' +
                    '.bank-state-error, .bank-city-error, .bank-address-error, ' +
                    '.bank-pincode-error, .bank-acc-name-error, .bank-acc-type-error, ' +
                    '.bank-acc-no-error, .bank-micr-error, .bank-ifsc-error'
                ).text('');

                if (!bankName.val().trim()) {
                    row.find('.bank-name-error').text('Bank Name is required');
                    err++;
                }

                if (!branch.val().trim()) {
                    row.find('.bank-branch-error').text('Bank Branch is required');
                    err++;
                }

                if (!country.val()) {
                    row.find('.bank-country-error').text('Country is required');
                    err++;
                }

                if (!state.val()) {
                    row.find('.bank-state-error').text('State is required');
                    err++;
                }

                if (!city.val()) {
                    row.find('.bank-city-error').text('City is required');
                    err++;
                }

                if (!address.val().trim()) {
                    row.find('.bank-address-error').text('Bank Address is required');
                    err++;
                }

                if (!pin.val().trim()) {
                    row.find('.bank-pincode-error').text('Bank Pincode is required');
                    err++;
                } else if (!/^\d{6}$/.test(pin.val().trim())) {
                    row.find('.bank-pincode-error').text('Pincode must be 6 digits');
                    err++;
                }

                if (!accName.val().trim()) {
                    row.find('.bank-acc-name-error').text('Account Name is required');
                    err++;
                }

                if (!accType.val()) {
                    row.find('.bank-acc-type-error').text('Account Type is required');
                    err++;
                }

                if (!accNo.val().trim()) {
                    row.find('.bank-acc-no-error').text('Account Number is required');
                    err++;
                }

                if (!micr.val().trim()) {
                    row.find('.bank-micr-error').text('MICR Code is required');
                    err++;
                }

                if (!ifsc.val().trim()) {
                    row.find('.bank-ifsc-error').text('IFSC Code is required');
                    err++;
                }
            });
            
             
            if(vendor_type == ""){
                $('#vendor_type_err').text('Vendor type is required')
                err++
            }
            if(vendor_company_name == ""){
                $('#vendor_company_err').text('Vendor company name is required')
                err++
            }
            
            if(vendor_name == ""){
                $('#vendor_name_err').text('Vendor name is required')
                err++
            }
            
            if(country_id == ""){
                $('#country_id_err').text('Country is required')
                err++
            }
            if(state_id == ""){
                $('#state_id_err').text('State is required')
                err++
            }
            if(city_id == ""){
                $('#city_id_err').text('City is required')
                err++
            }
            
            if(pin_code == ""){
                $('#pin_code_err').text('Pincode is required')
                err++
            }
            if(pan_number == ""){
                $('#pan_number_err').text('PAN Number is required')
                err++
            }
            if(gst_number == ""){
                $('#gst_number_err').text('GST Number is required')
                err++
            }
            if(pin_code == ""){
                $('#pin_code_err').text('Pincode is required')
                err++
            }
            if(pin_code != "" && pin_code.length!=6){
                $('#pin_code_err').text('Pincode Must be 6 digit')
                err++
            }
            if(aadhar_no == ""){
                $('#aadhar_no_err').text('Aadhar Number is required')
                err++
            }
            if (primary_person_email != '' && !/^\S+@\S+\.\S+$/.test(primary_person_email)) {
                 $('#prmy_person_email_err').text('Enter valid email')
                err++
            }
            if(primary_person_type == ""){
                $('#prmy_person_type_err').text('Person Type is required')
                err++
            }
            if(primary_person_name == ""){
                $('#prmy_person_name_err').text('Person Name is required')
                err++
            }
            if(primary_person_number == ""){
                $('#prmy_person_number_err').text('Mobile No is required')
                err++
            }
            
            if(primary_bank_name == ""){
                $('#prmy_bank_name_err').text('Bank Name is required')
                err++
            }
            if(primary_bank_branch == ""){
                $('#prmy_bank_branch_err').text('Branch is required')
                err++
            }
            if(primary_bank_address == ""){
                $('#prmy_bank_address_err').text('Branch is required')
                err++
            }
            if(primary_bank_country_id == ""){
                $('#prmy_bank_country_id_err').text('Country is required')
                err++
            }
            if(primary_bank_state_id == ""){
                $('#prmy_bank_state_id_err').text('State is required')
                err++
            }
            if(primary_bank_city_id == ""){
                $('#prmy_bank_city_id_err').text('City is required')
                err++
            }
            if(primary_bank_pin_code == ""){
                $('#prmy_bank_pin_code_err').text('Pincode is required')
                err++
            }
            if(primary_acc_name == ""){
                $('#prmy_bank_acc_name_err').text('Account Name is required')
                err++
            }
            if(primary_acc_type == ""){
                $('#prmy_bank_acc_type_err').text('Account Type is required')
                err++
            }
            if(primary_acc_no == ""){
                $('#prmy_bank_acc_number_err').text('Account Number is required')
                err++
            }
            if(primary_bank_micr == ""){
                $('#prmy_bank_micr_err').text('MICR Code is required')
                err++
            }
            if(primary_bank_ifsc == ""){
                $('#prmy_bank_ifsc_err').text('IFSC Code is required')
                err++
            }
            
            if (err>0){
            return false;
            }
            else{ 
                Addvendor();
            }
}
function Addvendor() {

        const reloadPage = tableState.currentPage;
        
        const form = document.getElementById("addvendorForm");
        console.log(form);
        const submitBtn = document.getElementById("submitBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_vendor') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Vendor Added successfully!');
                    //    location.reload(reloadPage);
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Vendor Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>


    <script>
        function countrychange() { 
            var countryId = $('#country_id').val();
            var stateDropdown = $('#state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('vendor_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                    } 
                }); 
            } 
        
        } 
            function statechange() { 
                var stateId = $('#state_id').val(); 
                var countryId = $('#country_id').val(); 
                var cityDropdown = $('#city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('vendor_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                        } 
                    }); 
                } 
            }
</script>

<script>
        function bankcountrychange() { 
            console.log('hi');
            var countryId = $('#prmy_bank_country_id').val();
            var stateDropdown = $('#prmy_bank_state_id'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('bank_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                    } 
                }); 
            } 
        
        } 
            function bankstatechange() { 
                var stateId = $('#prmy_bank_state_id').val(); 
                var countryId = $('#prmy_bank_country_id').val(); 
                var cityDropdown = $('#prmy_bank_city_id'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('bank_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            
                        } 
                    }); 
                } 
            } 
            function bankCountryChange(element) {
                const bank = $(element).closest('.secondary-bank');
                const countryId = $(element).val();
                const stateDropdown = bank.find('.bank-state');
                const cityDropdown = bank.find('.bank-city');
                
                stateDropdown.html('<option value="">Select State</option>');
                cityDropdown.html('<option value="">Select City</option>');

                if (countryId) {
                    $.ajax({
                        url: "{{ route('bank_state_listing') }}",
                        type: "GET",
                        data: { country_id: countryId },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append(
                                        $('<option></option>')
                                            .val(state.sno)
                                            .text(state.state_name)
                                    );
                                });
                            }
                        }
                    });
                }
            }
            function bankStateChange(element) {
                const bank = $(element).closest('.secondary-bank');
                const stateId = $(element).val();
                const countryId = bank.find('.bank-country').val();
                const cityDropdown = bank.find('.bank-city');
                

                cityDropdown.html('<option value="">Select City</option>');

                if (stateId) {
                    $.ajax({
                        url: "{{ route('bank_city_listing') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append(
                                        $('<option></option>')
                                            .val(city.sno)
                                            .text(city.city_name)
                                    );
                                });
                            }
                        }
                    });
                }
            }
    </script>



<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let tableState = {
        currentPage: 1
    };

    
    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        return `
            <tr>
                <td>
                    <div class="d-flex flex-column justify-content-between gap-2">
                        <label class="fw-bold text-dark d-block">${item.vendor_company_name}</label>
                        <span class="font-monospace small text-info px-3 py-0.5 bg-info bg-opacity-10 rounded-pill d-inline-block mt-1 border border-info border-opacity-25">
                            ${item.vendor_code}
                        </span>
                    </div>
                </td>               
                <td>
                    <div class="d-flex flex-column align-items-start">
                        <span class="fw-semibold text-secondary bg-light px-2 py-1 rounded small">
                                ${item.vendor_type}
                        </span>
                        
                    </div>
                </td>    
                <td>
                    <div class="d-flex flex-column">
                        <div class="fw-bold text-dark">
                            <span class="text-dark fw-semibold fs-7">${item.primary_person_name}</span>
                        </div>
                        <div class="text-muted small font-monospace mt-0.5 d-flex align-items-center gap-1">
                            <i class="mdi mdi-phone text-secondary"></i>
                            <span class="text-muted fs-8">${item.primary_person_number}</span>
                        </div>
                        <div class="text-muted text-truncate" style="max-width: 150px; font-size: 0.75rem;">
                            <span class="text-dark fw-semibold fs-7">${item.primary_person_email}</span>
                        </div>
                    </div>
                </td>          
                <td>
                    <div class="d-flex flex-column">
                                  <span class="fw-semibold text-dark fs-7">${item.city_name}</span>
                                  <small class="text-muted">${item.state_name} - ${item.pin_code}</small>
                              </div>
                </td> 
                <td>
                    <div class="d-flex flex-column py-3 px-3 font-monospace">
                        <div class="d-flex">
                            <label class="text-muted font-sans text-uppercase" style="font-size: 0.7rem;">pan:</label>
                            <span class="text-dark">${item.pan_number}</span>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted font-sans text-uppercase"  style="font-size: 0.7rem;">gst:</label>
                            <span class="text-info">${item.gst_number}</span>
                        </div>
                    </div>  
                </td> 
                <td>
                    <div class="d-flex flex-column py-3 px-3 font-monospace" style="font-size: 0.8rem;">
                        <div class="">
                            <label class="fw-semibold text-dark font-sans text-truncate esi-bank-name" style="max-width: 150px;">${item.primary_bank_name}</label>
                        </div>
                        <div class="d-flex">
                            <label class="text-muted text-uppercase">A/C :</label>
                            <span class="text-dark ">${item.primary_acc_no}</span>
                        </div>
                        <div class="d-flex text-success fw-bold">
                            <label class="text-uppercase">IFSC :</label>
                            <span class="" style="font-size: 0.75rem;">${item.primary_bank_ifsc}</span>
                        </div>
                    </div>
                </td> 
                <td>
                 ${item.supply_machine == 1 ? `
                    <div class="py-3 px-3 text-center">
                        <span class="badge bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-2 py-1">Machinery</span>
                        <i class="mdi mdi-tools me-1"></i>
                    </div>
                    ` : ''}
                 ${item.supply_machine == 0 ? `
                    <div class="py-3 px-3 text-center">
                        <span class="badge bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-2 py-1">Material Only</span>
                    </div>
                    ` : ''}
                    
                </td>
                <td>
                    <div class="d-flex dropdown">
                        <button class="btn p-0 text-decoration-none waves-effect waves-light" type="button" onclick="showUpdateVendor('${item.sno}')">
                            <i class="mdi mdi-pencil-outline fs-4 text-dark"></i>
                        </button>
                        <button class="btn p-0 text-decoration-none esi-btn-delete waves-effect waves-light" type="button" data-bs-toggle="modal"
                                data-bs-target="#deleteVendorModal" onclick="confirmDelete('${item.sno}','${item.vendor_company_name}')">
                            <i class="mdi mdi-trash-can-outline fs-4 text-danger"></i>
                        </button>
                    </div>
                </td>
                
            </tr>
        `;
    }
    function loadThemes(page = 1) {
         tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        
        const search = document.getElementById('search_filter').value;
        
        const url = `/site/vendor?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();
         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
               if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }
    

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>             
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

  

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>


<script>
     function confirmDelete(id, name) {
            document.querySelector('#deleteVendorModal .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('Are you sure you want to delete Vendor record <br> <b class="text-danger"> ' + name +
                '</b> ? This action cannot be undone.');
        }

        function deletelevel() {
            const reloadPage = tableState.currentPage;
            var id = document.querySelector('#deleteVendorModal .btn-danger').getAttribute('data-id');

            fetch('/delete_vendor/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Vendor Deleted successfully!');
                        location.reload(reloadPage);

                    } else {
                        toastr.error('Failed to delete Vendor');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>

<script>
function showUpdateVendor(id) {
    global_state_id = null;
    global_city_id = null;
    global_bank_state_id = null;
    global_bank_city_id = null;
    currentCategoryId = id;
    setViewMode('update');


    // Remove previously rendered secondary records
    resetUpdatePersons();

    document.querySelectorAll(
        '#updateBankContainer .secondary-bank'
    ).forEach(bank => bank.remove());

    fetch('/vendor_view/' + id, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status !== 200) {
            console.error(data.message || 'Vendor not found');
            return;
        }

        const com = data.data;
        console.log(com);
        // Set Supply Machinery checkbox based on database value


        $('#update_vendorType').val(com.vendor_type_id).change();
        $('#update_vendorCompany').val(com.vendor_company_name);
        $('#vendorCodeDisplay').html('Vendor Code: ' + com.vendor_code);
        $('#update_vendorName').val(com.vendor_name);

        $('#update_Pincode').val(com.pin_code);
        $('#update_Address').val(com.address||'-');

        $('#update_Country').val(com.country_id).change();
        $('#isSupplyMachinery').prop('checked', Number(com.supply_machinery) === 1);
        global_state_id = com.state_id;
        global_city_id = com.city_id;

        $('#update_gstNo').val(com.gst_number);
        $('#update_panNo').val(com.pan_number);

        // Decode JSON arrays if necessary
        const persons = Array.isArray(com.persons)
            ? com.persons
            : JSON.parse(com.persons || '[]');

        const banks = Array.isArray(com.banks)
            ? com.banks
            : JSON.parse(com.banks || '[]');

        // ----------------------------------
        // PRIMARY PERSON - index 0
        // ----------------------------------
        const primaryPerson = persons[0] || {};

        $('#update_personName').val(primaryPerson.person_name || '');
        $('#update_personType').val(primaryPerson.person_type || '').change();
        $('#update_personNumber').val(primaryPerson.person_number || '');
        $('#update_personEmail').val(primaryPerson.person_email || '');
        $('#update_personTeleno').val(primaryPerson.person_teleno || '');

        // ----------------------------------
        // SECONDARY PERSONS - index 1 onwards
        // ----------------------------------
        persons.slice(1).forEach(function (person) {
            updateVendorPerson();

            const row = $('#updatePersonContainer .secondary-person').last();

            row.find('[name$="[person_type]"]').val(person.person_type || '');
            row.find('[name$="[person_name]"]').val(person.person_name || '');
            row.find('[name$="[person_number]"]').val(person.person_number || '');
            row.find('[name$="[person_email]"]').val(person.person_email || '');
            row.find('[name$="[person_teleno]"]').val(person.person_teleno || '');
        });

        // Continue indexes after existing secondary persons
        updatePersonCount = persons.length;

        // ----------------------------------
        // PRIMARY BANK - index 0
        // ----------------------------------
        const primaryBank = banks[0] || {};

        $('#update_bankName').val(primaryBank.bank_name || '');
        $('#update_bankBranch').val(primaryBank.bank_branch || '');
        $('#update_bankAddress').val(primaryBank.bank_address || '');

        $('#update_bankCountry').val(primaryBank.bank_country || '').trigger('change');

        global_bank_state_id = primaryBank.bank_state || null;
        global_bank_city_id = primaryBank.bank_city || null;

        $('#update_accName').val(primaryBank.bank_acc_name || '');
        $('#update_accType').val(primaryBank.bank_acc_type || '').change();
        $('#update_bankPincode').val(primaryBank.bank_pincode || '');
        $('#update_accNumber').val(primaryBank.bank_acc_number || '');
        $('#update_bankMicr').val(primaryBank.bank_micr || '');
        $('#update_bankIfsc').val(primaryBank.bank_ifsc || '');

        
        banks.slice(1).forEach(function (bank) {
            updateVendorBank();

            const row = $('#updateBankContainer .secondary-bank').last();

            row.find('[name$="[bank_name]"]').val(bank.bank_name || '');
            row.find('[name$="[bank_branch]"]').val(bank.bank_branch || '');
            row.find('[name$="[bank_address]"]').val(bank.bank_address || '');
            row.find('[name$="[bank_pincode]"]').val(bank.bank_pincode || '');
            row.find('[name$="[bank_acc_name]"]').val(bank.bank_acc_name || '');
            row.find('[name$="[bank_acc_type]"]').val(bank.bank_acc_type || '');
            row.find('[name$="[bank_acc_number]"]').val(bank.bank_acc_number || '');
            row.find('[name$="[bank_micr]"]').val(bank.bank_micr || '');
            row.find('[name$="[bank_ifsc]"]').val(bank.bank_ifsc || '');

           function waitForOption(dropdown, value, callback, attempts = 30) {
                const timer = setInterval(function () {
                    const optionExists = dropdown.find('option').filter(function () {
                        return String(this.value) === String(value);
                    }).length > 0;

                    if (optionExists) {
                        clearInterval(timer);
                        dropdown.val(String(value)).trigger('change');

                        if (callback) callback();
                    } else if (--attempts <= 0) {
                        clearInterval(timer);
                        console.warn('Option not found:', value, dropdown.attr('name'));
                    }
                }, 100);
            }

            const countryDropdown = row.find('[name$="[bank_country]"]');
            countryDropdown.val(bank.bank_country || '').trigger('change');

            if (bank.bank_country) {
                bankCountryChange(countryDropdown[0]);

                const stateDropdown = row.find('[name$="[bank_state]"]');

                waitForOption(stateDropdown, bank.bank_state, function () {
                    if (bank.bank_state) {
                        bankStateChange(stateDropdown[0]);

                        const cityDropdown = row.find('[name$="[bank_city]"]');

                        waitForOption(cityDropdown, bank.bank_city);
                    }
                });
            }
                    });

                    updateBankCount = banks.length;
                    if (primaryBank.bank_country) {
                        setTimeout(function () {
                            $('#updateBankState').val(global_bank_state_id).trigger('change');

                            setTimeout(function () {
                                $('#updateBankCity').val(global_bank_city_id);
                            }, 300);
                        }, 300);
                    }

                })
                .catch(error => {
                    console.error('Error fetching Vendor:', error);
                });
            }


    function update_country_change() { 
            var countryId = $('#update_Country').val();
            var stateDropdown = $('#update_State'); 
            console.log('hi')
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('vendor_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        }   
                        if(global_state_id){
                            var changes=global_state_id;
                            stateDropdown.val(changes).change();
                          }
                    } 
                }); 
            } 
        
        } 

            function update_state_change() { 
                var stateId = $('#update_State').val(); 
                var countryId = $('#update_Country').val(); 
                var cityDropdown = $('#update_City'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('vendor_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            if(global_city_id){
                            var changes=global_city_id;
                            cityDropdown.val(changes).change();
                          }
                        } 
                    }); 
                } 
            }
            function update_bank_country() { 
            var countryId = $('#update_bankCountry').val();
            var stateDropdown = $('#update_bankState'); 
            stateDropdown.empty().append('<option value="">Select State</option>');
            if (countryId) {
                $.ajax({ 
                    url: "{{ route('bank_state_listing') }}",
                    type: "GET", 
                    data: { country_id: countryId }, 
                    success: function(response) { 
                        if (response.status === 200 && response.data) { 
                            response.data.forEach(function(state) { 
                                stateDropdown.append($('<option></option>').val(state.sno).text(state.state_name)); 
                            }); 
                        } 
                        if(global_bank_state_id){
                            var changes=global_bank_state_id;
                            stateDropdown.val(changes).change();
                          }  
                    } 
                }); 
            } 
        
        } 
            function update_bank_state() { 
                var stateId = $('#update_bankState').val(); 
                var countryId = $('#update_bankCountry').val(); 
                var cityDropdown = $('#update_bankCity'); 
                cityDropdown.empty().append('<option value="">Select City</option>'); 
                if (stateId) {  
                    $.ajax({ url: "{{ route('bank_city_listing') }}", 
                        type: "GET", 
                        data: { country_id: countryId, state_id: stateId }, 
                        success: function(response) { 
                            if (response.status === 200 && response.data) { 
                                response.data.forEach(function(city) { 
                                    cityDropdown.append($('<option></option>').val(city.sno).text(city.city_name)); 
                                }); 
                            } 
                            if(global_bank_city_id){
                            var changes=global_bank_city_id;
                            cityDropdown.val(changes).change();
                          }
                        } 
                    }); 
                } 
            } 


    function resetUpdatePersons() {
        updatePersonCount = 1;

        document.querySelectorAll(
            '#updatepersoncontainer .secondary-person'
        ).forEach(person => person.remove());
    }

    document.getElementById('vendorUpdateView').classList.remove('d-none');
  </script>


<script>

async function saveUpdatevendor() {
    console.log('Hello');
    let err = 0;
    const reloadPage = tableState.currentPage;
    const id = currentCategoryId;
    const csrfToken = document.querySelector(
        'meta[name="csrf-token"]'
    ).getAttribute('content');

    // Clear existing errors
    $('[id$="_err"]').text('');

   


    const vendor = {
        vendor_type: $('#update_vendorType').val(),
        vendor_company_name: $('#update_vendorCompany').val().trim(),
        vendor_name: $('#update_vendorName').val().trim(),
        pin_code: $('#update_Pincode').val().trim(),
        address: $('#update_Address').val().trim(),
        country_id: $('#update_Country').val(),
        state_id: $('#update_State').val(),
        city_id: $('#update_City').val(),
        gst_number: $('#update_gstNo').val().trim(),
        pan_number: $('#update_panNo').val().trim(),
        is_supply: isSupplyValue,
    };


        console.log('Value sent:', vendor.is_supply);
    

    // Validate contractor details
    const requiredFields = [
        ['vendor_type', 'update_vendorType_err', 'Vendor type'],
        ['vendor_company_name', 'update_vendorCompany_err', 'Vendor company name'],
        ['country_id', 'update_Country_err', 'Country'],
        ['state_id', 'update_State_err', 'State'],
        ['city_id', 'update_City_err', 'City'],
        ['pin_code', 'update_Pincode_err', 'Pincode'],
        ['pan_number', 'update_panNo_err', 'PAN Number'],
        ['gst_number', 'update_gstNo_err', 'GST Number'],
      
    ];

    requiredFields.forEach(([field, errorId, label]) => {
        if (!vendor[field]) {
            $('#' + errorId).text(label + ' is required');
            err++;
        }
    });

    if (vendor.pin_code &&
        !/^\d{6}$/.test(vendor.pin_code)) {
        $('#updatePincode_err').text('Pincode must be 6 digits');
        err++;
    }

    // Collect primary person (index 0)
    const persons = [{
        person_type: $('#update_personType').val(),
        person_name: $('#update_personName').val().trim(),
        person_number: $('#update_personNumber').val().trim(),
        person_email: $('#update_personEmail').val().trim(),
        person_teleno: $('#update_personTeleno').val().trim()
    }];

    // Validate primary person
    if (!persons[0].person_type) {
        $('#update_personType_err').text('Person Type is required');
        err++;
    }

    if (!persons[0].person_name) {
        $('#update_personName_err').text('Person Name is required');
        err++;
    }

    if (!persons[0].person_number) {
        $('#update_personNumber_err').text('Mobile No is required');
        err++;
    }

    if (persons[0].person_email &&
        !/^\S+@\S+\.\S+$/.test(persons[0].person_email)) {
        $('#update_personEmail_err').text('Enter a valid email');
        err++;
    }

    // Collect secondary persons
    $('#updatePersonContainer .secondary-person').each(function () {
        const row = $(this);

        const person = {
            person_type: row.find('[name$="[person_type]"]').val(),
            person_name: row.find('[name$="[person_name]"]').val().trim(),
            person_number: row.find('[name$="[person_number]"]').val().trim(),
            person_email: row.find('[name$="[person_email]"]').val().trim(),
            person_teleno: row.find('[name$="[person_teleno]"]').val().trim()
        };

        row.find(
            '.person-type-error, .person-name-error, ' +
            '.person-number-error, .person-email-error'
        ).text('');

        if (!person.person_type) {
            row.find('.person-type-error').text('Person Type is required');
            err++;
        }

        if (!person.person_name) {
            row.find('.person-name-error').text('Person Name is required');
            err++;
        }

        if (!person.person_number) {
            row.find('.person-number-error').text('Mobile No is required');
            err++;
        }

        if (person.person_email &&
            !/^\S+@\S+\.\S+$/.test(person.person_email)) {
            row.find('.person-email-error').text('Enter a valid email');
            err++;
        }

        persons.push(person);
    });

    // Collect primary bank (index 0)
    const banks = [{
        bank_name: $('#update_bankName').val().trim(),
        bank_branch: $('#update_bankBranch').val().trim(),
        bank_country: $('#update_bankCountry').val(),
        bank_state: $('#update_bankState').val(),
        bank_city: $('#update_bankCity').val(),
        bank_address: $('#update_bankAddress').val().trim(),
        bank_pincode: $('#update_bankPincode').val().trim(),
        bank_acc_name: $('#update_accName').val().trim(),
        bank_acc_type: $('#update_accType').val(),
        bank_acc_number: $('#update_accNumber').val().trim(),
        bank_micr: $('#update_bankMicr').val().trim(),
        bank_ifsc: $('#update_bankIfsc').val().trim()
    }];

    // Validate primary bank
    const primaryBankErrors = [
        ['bank_name', 'update_bankName_err', 'Bank Name'],
        ['bank_branch', 'update_bankBranch_err', 'Bank Branch'],
        ['bank_country', 'update_bankCountry_err', 'Country'],
        ['bank_state', 'update_bankState_err', 'State'],
        ['bank_city', 'update_bankCity_err', 'City'],
        ['bank_address', 'update_bankAddress_err', 'Bank Address'],
        ['bank_pincode', 'update_bankPincode_err', 'Pincode'],
        ['bank_acc_name', 'update_accName_err', 'Account Name'],
        ['bank_acc_type', 'update_accType_err', 'Account Type'],
        ['bank_acc_number', 'update_accNumber_err', 'Account Number'],
        ['bank_micr', 'update_bankMicr_err', 'MICR Code'],
        ['bank_ifsc', 'update_bankIfsc_err', 'IFSC Code']
    ];

    primaryBankErrors.forEach(([field, errorId, label]) => {
        if (!banks[0][field]) {
            $('#' + errorId).text(label + ' is required');
            err++;
        }
    });

    if (banks[0].bank_pincode &&
        !/^\d{6}$/.test(banks[0].bank_pincode)) {
        $('#updateBankPincode_err').text('Pincode must be 6 digits');
        err++;
    }

    // Collect secondary banks
    $('#updateBankContainer .secondary-bank').each(function () {
        const row = $(this);

        const bank = {
            bank_name: row.find('[name$="[bank_name]"]').val().trim(),
            bank_branch: row.find('[name$="[bank_branch]"]').val().trim(),
            bank_country: row.find('[name$="[bank_country]"]').val(),
            bank_state: row.find('[name$="[bank_state]"]').val(),
            bank_city: row.find('[name$="[bank_city]"]').val(),
            bank_address: row.find('[name$="[bank_address]"]').val().trim(),
            bank_pincode: row.find('[name$="[bank_pincode]"]').val().trim(),
            bank_acc_name: row.find('[name$="[bank_acc_name]"]').val().trim(),
            bank_acc_type: row.find('[name$="[bank_acc_type]"]').val(),
            bank_acc_number: row.find('[name$="[bank_acc_number]"]').val().trim(),
            bank_micr: row.find('[name$="[bank_micr]"]').val().trim(),
            bank_ifsc: row.find('[name$="[bank_ifsc]"]').val().trim()
        };

        const bankFields = [
            ['bank_name', '.bank-name-error', 'Bank Name'],
            ['bank_branch', '.bank-branch-error', 'Bank Branch'],
            ['bank_country', '.bank-country-error', 'Country'],
            ['bank_state', '.bank-state-error', 'State'],
            ['bank_city', '.bank-city-error', 'City'],
            ['bank_address', '.bank-address-error', 'Bank Address'],
            ['bank_pincode', '.bank-pin-error', 'Pincode'],
            ['bank_acc_name', '.bank-acc-name-error', 'Account Name'],
            ['bank_acc_type', '.bank-acc-type-error', 'Account Type'],
            ['bank_acc_number', '.bank-acc-no-error', 'Account Number'],
            ['bank_micr', '.bank-micr-error', 'MICR Code'],
            ['bank_ifsc', '.bank-ifsc-error', 'IFSC Code']
        ];

        row.find(
            '.bank-name-error, .bank-branch-error, .bank-country-error, ' +
            '.bank-state-error, .bank-city-error, .bank-address-error, ' +
            '.bank-pin-error, .bank-acc-name-error, .bank-acc-type-error, ' +
            '.bank-acc-no-error, .bank-micr-error, .bank-ifsc-error'
        ).text('');

        bankFields.forEach(([field, errorClass, label]) => {
            if (!bank[field]) {
                row.find(errorClass).text(label + ' is required');
                err++;
            }
        });

        if (bank.bank_pincode &&
            !/^\d{6}$/.test(bank.bank_pincode)) {
            row.find('.bank-pin-error').text('Pincode must be 6 digits');
            err++;
        }

        banks.push(bank);
    });

    if (err > 0) {
        return false;
    }

    // Send contractor, person array and bank array

        fetch(`/vendor_updates/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                            ...vendor,
                            persons: persons,
                            banks: banks
                    })
                })
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Vendors Updated successfully!');
                          location.reload(reloadPage);
                    } else {
                        toastr.error('Vendors Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating Vendors:', error);

                });
    
}
</script>
<script>

    let isSupplyValue = 0;

    function updateSupplyValue(checkbox) {
        isSupplyValue = checkbox.checked ? 1 : 0;
        console.log('is_supply:', isSupplyValue);
    }
</script>
<script>

    let isSupply = 0;

    function SupplyValue(checkbox) {
        isSupply = checkbox.checked ? 1 : 0;
        console.log('is_supply:', isSupply);
    }
</script>
@endsection