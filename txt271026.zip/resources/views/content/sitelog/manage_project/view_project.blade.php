@extends('layouts/contentNavbarLayout')

@section('title', 'Manage Project')

@section('content')

<style>
.rounded-16 {
    border-radius: 16px;
}

.badge-soft-blue {
    background: #eaf1ff;
    color: #2f6fed;
    font-weight: 600;
}

.badge-soft-green {
    background: #e8f9ee;
    color: #1c9a4b;
    font-weight: 600;
}

.btn-dark-navy {
    background: #131a2b;
    color: #fff;
    border: none;
}

.btn-dark-navy:hover {
    background: #1f2941;
    color: #fff;
}

.btn-light-outline {
    background: #eef1f6;
    color: #131a2b;
    border: none;
}

.btn-light-outline:hover {
    background: #e2e6ee;
}

.hero-card {
    background: linear-gradient(180deg, #1a4a7c 0%, #123a63 100%);
    color: #fff;
}

.hero-label {
    color: #8fa3c9;
    font-size: .75rem;
    letter-spacing: .3px;
}

.hero-value {
    color: #39d98a;
    font-weight: 700;
}

.hero-chip {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: rgba(255, 255, 255, .08);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #8fa3c9;
    flex-shrink: 0;
}

.hero-budget-box {
    background: rgba(57, 217, 138, .08);
    border: 1px solid rgba(57, 217, 138, .25);
    border-radius: 12px;
    padding: .85rem 1.25rem;
    min-width: 200px;
}

.hero-divider {
    border-color: rgba(255, 255, 255, .08);
    opacity: 1;
}

.hero-meta-item {
    flex: 1 1 200px;
}

.stat-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.icon-blue {
    background: #eaf1ff;
    color: #2f6fed;
}

.icon-green {
    background: #e8f9ee;
    color: #1c9a4b;
}

.icon-teal {
    background: #e6faf7;
    color: #12b3a3;
}

.icon-purple {
    background: #f2eaff;
    color: #8b5cf6;
}

.stat-label {
    font-size: .72rem;
    color: #8a93a3;
    letter-spacing: .2px;
}

.progress {
    height: 8px;
}

.divider-vert {
    border-left: 1px solid rgba(255, 255, 255, .08);
}

.fw-medium {
    font-weight: 500;
}

.back-link {
    font-size: .8rem;
    font-weight: 500;
}

.back-link:hover {
    color: #131a2b !important;
}

.back-btn {
    background: #fff;
    border: 1px solid #e5e9f0;
    color: #4a5568;
    font-size: .8rem;
    font-weight: 500;
    padding: .35rem .75rem .35rem .35rem;
    border-radius: 50px;
    transition: background .15s ease, border-color .15s ease;
}

.back-btn:hover {
    background: #f4f6f9;
    border-color: #d7deea;
    color: #131a2b;
}

.back-btn-icon {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #eef1f6;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .75rem;
    color: #131a2b;
}

.badge-soft-blue {
    background: #eaf1ff;
    color: #2f6fed;
    font-weight: 500;
    font-size: .72rem;
}

.badge-soft-info {
    background: #FFF3CD;
    color: #B45309;
    font-weight: 500;
    font-size: .72rem;
}

/* Tab navigation */
.tabs-card {
    background: linear-gradient(180deg, #1a4a7c 0%, #123a63 100%);
    border-radius: 14px;
    padding: .4rem .5rem 0;
}

.tabs-row {
    display: flex;
    align-items: center;
    gap: .25rem;
}

.tabs-scroll-btn {
    flex: 0 0 auto;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: rgba(255, 255, 255, .12);
    border: none;
    color: #dce8f7;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .7rem;
}

.tabs-scroll-btn:hover {
    background: rgba(255, 255, 255, .22);
    color: #fff;
}

.tabs-scroll {
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    scroll-behavior: smooth;
    gap: .25rem;
    padding-bottom: .5rem;
    flex: 1 1 auto;
}

.tabs-scroll::-webkit-scrollbar {
    height: 6px;
}

.tabs-scroll::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, .08);
    border-radius: 10px;
}

.tabs-scroll::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, .35);
    border-radius: 10px;
}

.tabs-scroll::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, .5);
}

.tab-item {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: .45rem;
    white-space: nowrap;
    padding: .6rem .95rem;
    font-size: .76rem;
    font-weight: 600;
    letter-spacing: .2px;
    color: #cfe0f5;
    border-radius: 9px;
    text-decoration: none;
    cursor: pointer;
    border: none;
    background: transparent;
    transition: background .15s ease, color .15s ease;
}

.tab-item:hover {
    background: rgba(255, 255, 255, .08);
    color: #fff;
}

.tab-item.active {
    background: #0e2b4d;
    color: #fff;
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .08);
}

.tab-item i {
    font-size: .82rem;
}

.tab-icon-yellow {
    color: #f5c542;
}

.tab-icon-orange {
    color: #f0883e;
}

.tab-icon-green {
    color: #5fd688;
}

.tab-icon-red {
    color: #f0564f;
}

.tab-icon-blue {
    color: #6cb4f0;
}

.tab-icon-light {
    color: #e7edf5;
}

.tab-pane {
    display: none;
}

.tab-pane.active {
    display: block;
}

.project-tab-content {
    padding: 10px;
    background: #fff;
    border: 1px solid #dce5ef;
    border-radius: 10px;
}

@media (max-width: 767px) {

    /* Page header card */
    .card-body.p-3 .d-flex.align-items-center.gap-3 {
        flex-wrap: wrap;
    }

    /* Sub-header: back button + title + action buttons */
    .card.rounded-16.shadow-sm.border-0.mb-3 .card-body.py-3.px-4>.d-flex {
        flex-direction: column;
        align-items: stretch !important;
        gap: 1rem !important;
    }

    .card.rounded-16.shadow-sm.border-0.mb-3 .card-body.py-3.px-4 .d-flex.gap-2:last-child {
        width: 100%;
    }

    .card.rounded-16.shadow-sm.border-0.mb-3 .card-body.py-3.px-4 .d-flex.gap-2:last-child .btn {
        flex: 1;
        justify-content: center;
    }

    .back-btn span:last-child {
        font-size: .75rem;
    }

    /* title + badges wrap cleanly */
    .fs-6.fw-medium.text-dark {
        font-size: .95rem !important;
    }


    /* Hero card */
    .hero-card .card-body {
        padding: 1rem !important;
    }

    .hero-card .d-flex.flex-wrap.justify-content-between.align-items-start {
        flex-direction: column;
    }

    .hero-budget-box {
        width: 100%;
        min-width: 0;
        text-align: left !important;
    }

    .hero-card h4.fw-bold {
        font-size: 1.15rem;
    }

    .hero-meta-item {
        flex: 1 1 45%;
        min-width: 0;
    }

    .hero-meta-item .fw-semibold {
        font-size: .85rem;
        word-break: break-word;
    }

    .hero-divider {
        margin: 1.25rem 0 !important;
    }


    /* Stat cards */
    .stat-label {
        font-size: .65rem;
    }

    .fs-4.fw-bold {
        font-size: 1.15rem !important;
    }


    /* Tabs */
    .tabs-card {
        padding: .3rem .3rem 0;
    }

    .tab-item {
        padding: .55rem .75rem;
        font-size: .72rem;
    }

    .tabs-scroll-btn {
        width: 22px;
        height: 22px;
        font-size: .65rem;
    }


    /* Tab content padding */
    .project-tab-content {
        padding: 8px;
    }
}


@media (max-width: 575px) {

    .hero-meta-item {
        flex: 1 1 100%;
    }

    .back-btn {
        width: 100%;
        justify-content: center;
    }

    .d-flex.flex-wrap.align-items-center.gap-2 .badge {
        font-size: .68rem;
        padding: .4rem .6rem !important;
    }

    /* action buttons stack full-width */
    .card.rounded-16.shadow-sm.border-0.mb-3 .card-body.py-3.px-4 .d-flex.gap-2:last-child {
        flex-direction: column;
    }

    .card.rounded-16.shadow-sm.border-0.mb-3 .card-body.py-3.px-4 .d-flex.gap-2:last-child .btn {
        width: 100%;
    }
}
</style>
<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<div class="container-fluid">

    <!-- Page Header Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body p-3">
            <div class="d-flex align-items-center gap-3">
                <div class="bg-primary-subtle rounded-3 px-2 py-1">
                    <i class="bi bi-briefcase text-primary fs-6"></i>
                </div>

                <div>
                    <h6 class="fw-bold mb-1">Manage Project</h6>
                    <small class="text-primary">
                        Site Operations Management & Logs
                    </small>
                </div>
            </div>
        </div>
    </div>
    <!-- Sub header: back link, badges, title, actions -->

    <div class="card rounded-16 shadow-sm border-0 mb-3">
        <div class="card-body py-3 px-4">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">

                <div class="d-flex flex-column gap-2">
                    <button class="btn btn-sm back-btn d-inline-flex align-items-center gap-2"
                        style="width: fit-content;box-shadow:none"
                        onclick="window.location.href='{{ route('site.manage-project') }}'">
                        <span class=" back-btn-icon">
                            <i class="bi bi-arrow-left"></i>
                        </span>
                        <span>Back to Projects List</span>
                    </button>

                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <span class="fs-6 fw-medium text-dark">Chennai Metro Phase 2 - Corridor 4</span>
                        <span class="badge badge-soft-blue rounded-pill px-3 py-2">PRJ-CMRL-04</span>
                        <span class="badge badge-soft-info rounded-pill px-3 py-2">In Progress</span>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-dark-navy btn-sm rounded-3 d-flex align-items-center gap-1 px-3">
                        <i class="bi bi-pencil-square"></i> Edit Project
                    </button>
                    <button class="btn btn-light-outline btn-sm rounded-3 px-3">Close Profile</button>
                </div>

            </div>
        </div>
    </div>
    <!-- Hero dark card -->
    <div class="card hero-card rounded-16 shadow-sm border-0 mb-3">
        <div class="card-body p-4">

            <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
                <div>
                    <div class="hero-label mb-2 d-flex align-items-center gap-2">
                        <span class="hero-chip"><i class="bi bi-building"></i></span>
                        MAPPED CLIENT: CHENNAI METRO RAIL LIMITED (CMRL)
                    </div>
                    <h4 class="fw-bold mb-2 text-white">Chennai Metro Phase 2 - Corridor 4</h4>
                    <div class="hero-label mb-0 d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt"></i> Porur to Power House Corridor, Chennai
                    </div>
                </div>

                <div class="hero-budget-box text-lg-end">
                    <div class="hero-label mb-1">TOTAL PROJECT BUDGET</div>
                    <div class="hero-value fs-4">₹48.50 Cr</div>
                </div>
            </div>

            <hr class="hero-divider my-4">

            <div class="d-flex flex-wrap gap-4">
                <div class="hero-meta-item d-flex align-items-center gap-3">
                    <span class="hero-chip"><i class="bi bi-person-badge"></i></span>
                    <div>
                        <div class="hero-label mb-1">PROJECT MANAGER</div>
                        <div class="fw-semibold text-white">Er. Dinesh Karthik</div>
                    </div>
                </div>

                <div class="hero-meta-item d-flex align-items-center gap-3">
                    <span class="hero-chip"><i class="bi bi-person-gear"></i></span>
                    <div>
                        <div class="hero-label mb-1">SITE ENGINEER IN-CHARGE</div>
                        <div class="fw-semibold text-white">R. Vigneshwar</div>
                    </div>
                </div>

                <div class="hero-meta-item d-flex align-items-center gap-3">
                    <span class="hero-chip"><i class="bi bi-calendar-event"></i></span>
                    <div>
                        <div class="hero-label mb-1">START DATE</div>
                        <div class="fw-semibold text-white">2025-08-15</div>
                    </div>
                </div>

                <div class="hero-meta-item d-flex align-items-center gap-3">
                    <span class="hero-chip"><i class="bi bi-flag"></i></span>
                    <div>
                        <div class="hero-label mb-1">TARGET END DATE</div>
                        <div class="fw-semibold text-white">2027-12-31</div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Stat cards -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-3">
            <div class="card rounded-16 shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="stat-label text-uppercase">Structure Units Count</span>
                        <div class="stat-icon icon-blue"><i class="bi bi-layers fs-6"></i></div>
                    </div>
                    <div class="fs-4 fw-bold mb-1">14 Units</div>
                    <div class="text-muted small">Elevated piers &amp; foundation structures</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-3">
            <div class="card rounded-16 shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="stat-label text-uppercase">Physical Execution Progress</span>
                        <div class="stat-icon icon-blue"><i class="bi bi-graph-up-arrow fs-6"></i></div>
                    </div>
                    <div class="fs-4 fw-bold mb-2 text-primary">42%</div>
                    <div class="progress rounded-pill">
                        <div class="progress-bar bg-primary" style="width:42%"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-3">
            <div class="card rounded-16 shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="stat-label text-uppercase">Estimated Spent / Costs</span>
                        <div class="stat-icon icon-green"><i class="bi bi-currency-dollar fs-6"></i></div>
                    </div>
                    <div class="fs-4 fw-bold mb-1">₹14.20 Cr</div>
                    <div class="text-success small">Within sanctioned budget limit</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-3">
            <div class="card rounded-16 shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <span class="stat-label text-uppercase">Assigned Sub-Contractors</span>
                        <div class="stat-icon icon-purple"><i class="bi bi-people fs-5"></i></div>
                    </div>
                    <div class="fs-4 fw-bold mb-1">2 Agencies</div>
                    <div class="text-muted small">Active site execution partners</div>
                </div>
            </div>
        </div>
    </div>
    <!--Tabs -->
    <div class="tabs-card mb-3">
        <div class="tabs-row">

            <button type="button" class="tabs-scroll-btn"
                onclick="document.getElementById('projectTabsScroll').scrollBy({left:-200,behavior:'smooth'})">
                <i class="bi bi-chevron-left"></i>
            </button>

            <div class="tabs-scroll" id="projectTabsScroll">

                <button type="button" class="tab-item active" data-tab="project-details">
                    <i class="bi bi-file-earmark-text-fill tab-icon-yellow"></i>
                    Project Details
                </button>

                <button type="button" class="tab-item" data-tab="structure">
                    <i class="bi bi-bricks tab-icon-orange"></i>
                    Structure
                </button>

                <button type="button" class="tab-item" data-tab="client-work-order">
                    <i class="bi bi-file-earmark-fill tab-icon-light"></i>
                    Client Work Order
                </button>

                <button type="button" class="tab-item" data-tab="material-details">
                    <i class="bi bi-box-seam-fill tab-icon-orange"></i>
                    Material Details
                </button>

                <button type="button" class="tab-item" data-tab="machinery-details">
                    <i class="bi bi-gear-fill tab-icon-green"></i>
                    Machinery Details
                </button>

                <button type="button" class="tab-item" data-tab="fuel-details">
                    <i class="bi bi-fuel-pump-fill tab-icon-red"></i>
                    Fuel Details
                </button>

                <button type="button" class="tab-item" data-tab="labour-attendance">
                    <i class="bi bi-person-fill tab-icon-yellow"></i>
                    Labour Attendance
                </button>

                <!--  <button type="button" class="tab-item" data-tab="plan-vs-achieved">
                    <i class="bi bi-bar-chart-fill tab-icon-blue"></i>
                    Plan vs Achieved
                </button> -->

                <button type="button" class="tab-item" data-tab="scrap-details">
                    <i class="bi bi-recycle tab-icon-green"></i>
                    Scrap Details
                </button>

                <button type="button" class="tab-item" data-tab="client-report">
                    <i class="bi bi-file-earmark-bar-graph-fill tab-icon-light"></i>
                    Client Report
                </button>

                <button type="button" class="tab-item" data-tab="vendor-report">
                    <i class="bi bi-truck tab-icon-red"></i>
                    Vendor Report
                </button>

                <button type="button" class="tab-item" data-tab="contractor-report">
                    <i class="bi bi-file-earmark-ruled-fill tab-icon-orange"></i>
                    Contractor Report
                </button>

            </div>

            <button type="button" class="tabs-scroll-btn"
                onclick="document.getElementById('projectTabsScroll').scrollBy({left:200,behavior:'smooth'})">
                <i class="bi bi-chevron-right"></i>
            </button>

        </div>
    </div>
    <div class="project-tab-content">

        <div class="tab-pane active" id="project-details">
            @include('content.sitelog.manage_project.tabs.project-details')
        </div>
        <div class="tab-pane" id="structure">
            @include('content.sitelog.manage_project.tabs.struture')
        </div>
        <div class="tab-pane" id="client-work-order">
            @include('content.sitelog.manage_project.tabs.client-work-order')
        </div>
        <div class="tab-pane" id="material-details">
            @include('content.sitelog.manage_project.tabs.material-details')
        </div>
        <div class="tab-pane" id="machinery-details">
            @include('content.sitelog.manage_project.tabs.machinery-details')
        </div>
        <div class="tab-pane" id="fuel-details">
            @include('content.sitelog.manage_project.tabs.fuel-details')
        </div>
        <div class="tab-pane" id="labour-attendance">
            @include('content.sitelog.manage_project.tabs.labour-attendance')
        </div>
        <div class="tab-pane" id="scrap-details">
            @include('content.sitelog.manage_project.tabs.scrap-details')
        </div>
        <div class="tab-pane" id="client-report">
            @include('content.sitelog.manage_project.tabs.client-report')
        </div>
        <div class="tab-pane" id="vendor-report">
            @include('content.sitelog.manage_project.tabs.vendor-report')
        </div>
        <div class="tab-pane" id="contractor-report">
            @include('content.sitelog.manage_project.tabs.contractor-report')
        </div>
    </div>


</div>
<script>
document.querySelectorAll('.tab-item').forEach(tab => {

    tab.addEventListener('click', function() {

        document.querySelectorAll('.tab-item').forEach(t => {
            t.classList.remove('active');
        });

        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });

        this.classList.add('active');

        const tabId = this.dataset.tab;

        document.getElementById(tabId).classList.add('active');
    });

});
// Activate a specific tab on page load, based on ?tab=<tabId> in the URL
document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const requestedTab = params.get('tab');

    if (requestedTab) {
        const targetTabButton = document.querySelector('.tab-item[data-tab="' + requestedTab + '"]');

        if (targetTabButton) {
            targetTabButton.click();

            // Scroll the tabs row so the active tab is visible, in case it's off-screen
            targetTabButton.scrollIntoView({
                behavior: 'smooth',
                inline: 'center',
                block: 'nearest'
            });
        }
    }
});
</script>
@endsection