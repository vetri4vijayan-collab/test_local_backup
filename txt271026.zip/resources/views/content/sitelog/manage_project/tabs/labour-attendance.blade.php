<div class="labour-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-strength">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-label">TOTAL DAILY LABOR STRENGTH</div>
                <div class="stat-value">148 <span>Workers</span></div>
                <div class="stat-desc">Across assigned sub-contractors</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-wages">
                    <i class="bi bi-cash-stack"></i>
                </div>
                <div class="stat-label">DAILY LABOR WAGES OUTLAY</div>
                <div class="stat-value text-success-custom">₹2,11,000</div>
                <div class="stat-desc">Includes Overtime bonuses</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-overtime">
                    <i class="bi bi-clock-history"></i>
                </div>
                <div class="stat-label">CUMULATIVE OVERTIME LOGS</div>
                <div class="stat-value">34 <span>Man-Hrs</span></div>
                <div class="stat-desc text-success-custom">Under safety limits</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: SHIFT LEDGER -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-clipboard-data"></i> Labor Strength Roll &amp; Contractor Shift Ledger
                    </h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export Attendance
                    </button>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table labour-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>CONTRACTOR CREW NAME</th>
                                    <th>SHIFT</th>
                                    <th class="text-end">SKILLED</th>
                                    <th class="text-end">SEMI-SKILLED</th>
                                    <th class="text-end">UNSKILLED HELPERS</th>
                                    <th class="text-end">OT HOURS</th>
                                    <th class="text-end">DAILY COST</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <div class="crew-name">Apex Structural Sub-Contractors</div>
                                        <div class="crew-meta">Date: 2026-07-24 &bull; Shift Entry</div>
                                    </td>
                                    <td class="shift-name">Day Shift</td>
                                    <td class="text-end count-value">25</td>
                                    <td class="text-end count-value">15</td>
                                    <td class="text-end count-value">30</td>
                                    <td class="text-end ot-hours">+14 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end daily-cost">₹98,000</td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="crew-name">Star Bar-Bending &amp; Rebar Works</div>
                                        <div class="crew-meta">Date: 2026-07-24 &bull; Shift Entry</div>
                                    </td>
                                    <td class="shift-name">Day Shift</td>
                                    <td class="text-end count-value">15</td>
                                    <td class="text-end count-value">20</td>
                                    <td class="text-end count-value">10</td>
                                    <td class="text-end ot-hours">+8 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end daily-cost">₹62,000</td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="crew-name">Vanguard Piling &amp; Foundations</div>
                                        <div class="crew-meta">Date: 2026-07-24 &bull; Shift Entry</div>
                                    </td>
                                    <td class="shift-name">Night Shift</td>
                                    <td class="text-end count-value">10</td>
                                    <td class="text-end count-value">8</td>
                                    <td class="text-end count-value">15</td>
                                    <td class="text-end ot-hours">+12 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end daily-cost">₹51,000</td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


        <!-- RIGHT: RECORD SHIFT MUSTER ROLL -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-journal-check"></i> Record Shift Muster Roll
                    </h6>
                    <button type="button" class="btn btn-sm muster-entry-btn d-flex align-items-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#musterShiftModal">
                        <i class="bi bi-plus-lg"></i> Muster Shift Entry
                    </button>
                </div>

                <div class="card-body">

                    <div class="compliance-banner">
                        <div class="compliance-header">
                            <i class="bi bi-exclamation-triangle-fill"></i> Compliance Warning
                        </div>
                        <p class="compliance-text mb-0">
                            Every laborer is verified against ESIC and EPF enrollment. Ensure site safety induction is
                            complete before work commences.
                        </p>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>

<!-- Record Shift Muster Roll Modal -->
@include('content.sitelog.manage_project.tabs.modal.muster-shift-entry')


<style>
.labour-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #ffffff;
    border: 1px solid #dce5ef;
    border-radius: 12px;
    padding: 18px 16px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
}

.stat-icon.icon-strength {
    background: #eaf2fb;
    color: #17649b;
}

.stat-icon.icon-wages {
    background: #e6fbf3;
    color: #00a875;
}

.stat-icon.icon-overtime {
    background: #fff4e6;
    color: #e5871d;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a7bc;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
    padding-right: 40px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #071d35;
    line-height: 1;
    margin-bottom: 8px;
}

.stat-value span {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: #7790ac;
}

.stat-desc {
    font-size: 8.5px;
    color: #7790ac;
}

.text-success-custom {
    color: #00a875 !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 11.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.panel-title i {
    color: #17649b;
    font-size: 14px;
}

.panel-card .card-body {
    padding: 18px;
}


/* Buttons */
.export-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}

.muster-entry-btn {
    background: #17649b;
    border: 0;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.muster-entry-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Labour table */
.labour-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.labour-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 18px;
    white-space: nowrap;
}

.labour-table tbody td {
    padding: 12px 18px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.labour-table tbody tr:last-child td {
    border-bottom: 0;
}

.crew-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
    font-size: 10px;
    margin-bottom: 2px;
}

.crew-meta {
    font-size: 7.5px;
    color: #a4b4c6;
}

.shift-name {
    color: #17649b;
    font-weight: 600;
}

.count-value {
    color: #142c47;
    font-weight: 600;
}

.ot-hours {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #17649b;
}

.unit-text {
    color: #a4b4c6;
    font-weight: 400;
}

.daily-cost {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #00a875;
}


/* Compliance banner */
.compliance-banner {
    background: #fff8ee;
    border: 1px solid #f2dfb3;
    border-radius: 10px;
    padding: 14px 16px;
}

.compliance-header {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
    font-weight: 800;
    color: #b5730f;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
}

.compliance-header i {
    font-size: 12px;
}

.compliance-text {
    font-size: 9px;
    color: #8a6621;
    line-height: 1.6;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 16px 14px;
    }

    .stat-label {
        padding-right: 44px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn,
    .muster-entry-btn {
        justify-content: center;
    }

    .labour-table {
        min-width: 700px;
    }
}
</style>