<div class="row g-3">

    <!-- Left column -->
    <div class="col-lg-8">

        <!-- Scope of Work & Client Details -->
        <div class="section-card">
            <div class="section-header">
                <h6 class="section-title">Scope of Work &amp; Client Details</h6>
                <span class="scope-id">ID: PRJ-001</span>
            </div>
            <p class="scope-text">
                Construction of 14 elevated pier stations, pre-stressed box girders, and track bed slabs.
            </p>
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="info-box">
                        <div class="info-label">Client Organization</div>
                        <div class="info-value">Chennai Metro Rail Limited (CMRL)</div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-box">
                        <div class="info-label">Principal Site Manager</div>
                        <div class="info-value">Er. Dinesh Karthik</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Execution Phases & Milestones -->
        <div class="section-card">
            <div class="section-header">
                <h6 class="section-title">Execution Phases &amp; Milestones</h6>
                <span class="section-meta">Total 5 Recorded Phases</span>
            </div>

            <div class="phase-item">
                <div>
                    <div class="phase-title">Phase 1: Soil testing &amp; deep piling foundations</div>
                    <div class="phase-meta">Code: MS-1 &bull; Target Phase</div>
                </div>
                <div class="phase-progress-wrap">
                    <div class="progress">
                        <div class="progress-bar bg-success" style="width:100%"></div>
                    </div>
                    <span class="phase-percent">100%</span>
                    <span class="status-pill status-completed">COMPLETED</span>
                </div>
            </div>

            <div class="phase-item">
                <div>
                    <div class="phase-title">Phase 2: Elevated piers &amp; cast-in-situ pier caps</div>
                    <div class="phase-meta">Code: MS-2 &bull; Target Phase</div>
                </div>
                <div class="phase-progress-wrap">
                    <div class="progress">
                        <div class="progress-bar bg-primary" style="width:60%"></div>
                    </div>
                    <span class="phase-percent">60%</span>
                    <span class="status-pill status-progress">IN PROGRESS</span>
                </div>
            </div>

            <div class="phase-item">
                <div>
                    <div class="phase-title">Phase 3: Pre-stressed box girders launching</div>
                    <div class="phase-meta">Code: MS-3 &bull; Target Phase</div>
                </div>
                <div class="phase-progress-wrap">
                    <div class="progress">
                        <div class="progress-bar bg-primary" style="width:20%"></div>
                    </div>
                    <span class="phase-percent">20%</span>
                    <span class="status-pill status-progress">IN PROGRESS</span>
                </div>
            </div>

            <div class="phase-item">
                <div>
                    <div class="phase-title">Phase 4: Track bed slab casting &amp; curing</div>
                    <div class="phase-meta">Code: MS-4 &bull; Target Phase</div>
                </div>
                <div class="phase-progress-wrap">
                    <div class="progress">
                        <div class="progress-bar" style="width:0%"></div>
                    </div>
                    <span class="phase-percent">0%</span>
                    <span class="status-pill status-planned">PLANNED</span>
                </div>
            </div>

            <div class="phase-item">
                <div>
                    <div class="phase-title">Phase 5: Station mechanical, electrical &amp; plumbing works</div>
                    <div class="phase-meta">Code: MS-5 &bull; Target Phase</div>
                </div>
                <div class="phase-progress-wrap">
                    <div class="progress">
                        <div class="progress-bar" style="width:0%"></div>
                    </div>
                    <span class="phase-percent">0%</span>
                    <span class="status-pill status-planned">PLANNED</span>
                </div>
            </div>
        </div>

        <!-- Engineering Blueprint & Document Repository -->
        <div class="section-card mb-0">
            <div class="section-header">
                <h6 class="section-title">Engineering Blueprint &amp; Document Repository</h6>
                <a href="#" class="section-link" data-bs-toggle="modal" data-bs-target="#uploadDocumentModal">
                    + Upload Document
                </a>
            </div>
            <div class="doc-list">
                <div class="doc-item">
                    <div class="d-flex align-items-center gap-3">
                        <div class="doc-icon"><i class="bi bi-file-earmark-pdf-fill"></i></div>
                        <div>
                            <div class="doc-name">Approved Structural Blueprint.pdf</div>
                            <div class="doc-meta">Size: 24.2 MB &bull; Category: Blueprint &bull; 2025-08-20</div>
                        </div>
                    </div>
                    <a href="#" class="doc-download">[ DOWNLOAD ]</a>
                </div>

                <div class="doc-item">
                    <div class="d-flex align-items-center gap-3">
                        <div class="doc-icon"><i class="bi bi-file-earmark-pdf-fill"></i></div>
                        <div>
                            <div class="doc-name">Geotech Soil Testing Report.pdf</div>
                            <div class="doc-meta">Size: 12.5 MB &bull; Category: Testing &bull; 2025-08-25</div>
                        </div>
                    </div>
                    <a href="#" class="doc-download">[ DOWNLOAD ]</a>
                </div>

                <div class="doc-item">
                    <div class="d-flex align-items-center gap-3">
                        <div class="doc-icon"><i class="bi bi-file-earmark-pdf-fill"></i></div>
                        <div>
                            <div class="doc-name">CMRL Joint Venture Agreement.pdf</div>
                            <div class="doc-meta">Size: 8.1 MB &bull; Category: Contract &bull; 2025-09-02</div>
                        </div>
                    </div>
                    <a href="#" class="doc-download">[ DOWNLOAD ]</a>
                </div>

                <div class="doc-item">
                    <div class="d-flex align-items-center gap-3">
                        <div class="doc-icon"><i class="bi bi-file-earmark-pdf-fill"></i></div>
                        <div>
                            <div class="doc-name">Safety Compliance Audit Q1.pdf</div>
                            <div class="doc-meta">Size: 3.4 MB &bull; Category: Safety &bull; 2025-10-10</div>
                        </div>
                    </div>
                    <a href="#" class="doc-download">[ DOWNLOAD ]</a>
                </div>
            </div>
        </div>

    </div>

    <!-- Right column -->
    <div class="col-lg-4">

        <!-- Site Team & Officers -->
        <div class="section-card">
            <div class="section-header">
                <h6 class="section-title">Site Team &amp; Officers</h6>
                <a href="#" class="section-link" data-bs-toggle="modal" data-bs-target="#assignMemberModal">
                    + Assign Member
                </a>
            </div>

            <div class="team-item">
                <div>
                    <div class="team-name">Er. Dinesh Karthik</div>
                    <div class="team-contact">dinesh.k@srkinfra.com &bull; +91 98401 23456</div>
                </div>
                <span class="role-badge">Project Manager</span>
            </div>

            <div class="team-item">
                <div>
                    <div class="team-name">R. Vigneshwar</div>
                    <div class="team-contact">vignesh.r@srkinfra.com &bull; +91 98401 78910</div>
                </div>
                <span class="role-badge">Site Engineer</span>
            </div>

            <div class="team-item">
                <div>
                    <div class="team-name">Priya Nair</div>
                    <div class="team-contact">priya.n@srkinfra.com &bull; +91 97890 12345</div>
                </div>
                <span class="role-badge">Quantity Surveyor (QS)</span>
            </div>

            <div class="team-item">
                <div>
                    <div class="team-name">S. Kumar</div>
                    <div class="team-contact">kumar.s@srkinfra.com &bull; +91 96770 98765</div>
                </div>
                <span class="role-badge">Safety Officer</span>
            </div>
        </div>

        <!-- Project Risk Register -->
        <div class="section-card mb-0">
            <div class="section-header">
                <h6 class="section-title">Project Risk Register</h6>
                <a href="#" class="section-link" data-bs-toggle="modal" data-bs-target="#addRiskModal">+ Register
                    Risk</a>
            </div>
            <div class="risk-list">
                <div class="risk-item">
                    <div class="d-flex align-items-start justify-content-between mb-2">
                        <div class="risk-title">Coastal Monsoon Waterlogging</div>
                        <span class="severity-pill severity-high">HIGH</span>
                    </div>
                    <div class="risk-mitigation"><b>Mitigation:</b> Install heavy-duty sump pumps &amp; construct
                        drainage detours</div>
                </div>

                <div class="risk-item">
                    <div class="d-flex align-items-start justify-content-between mb-2">
                        <div class="risk-title">Steel &amp; Cement Price Escalation</div>
                        <span class="severity-pill severity-medium">MEDIUM</span>
                    </div>
                    <div class="risk-mitigation"><b>Mitigation:</b> Procure bulk quantity in advance &amp; fix vendor
                        price locks</div>
                </div>

                <div class="risk-item">
                    <div class="d-flex align-items-start justify-content-between mb-2">
                        <div class="risk-title">Utility Line Clash during Piling</div>
                        <span class="severity-pill severity-high">HIGH</span>
                    </div>
                    <div class="risk-mitigation"><b>Mitigation:</b> Run GPR ground scans and consult CMRL utility maps
                    </div>
                </div>
            </div>
        </div>

    </div>
    <style>
    .section-card {
        background: #fff;
        border-radius: 14px;
        border: 1px solid #eef1f6;
        padding: 1.25rem 1.5rem;
        margin-bottom: 1rem;
    }

    .section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: .75rem;
        margin-bottom: 1rem;
        border-bottom: 1px solid #eef1f6;
    }

    .section-title {
        font-size: .78rem;
        font-weight: 700;
        letter-spacing: .3px;
        color: #1a1f2b;
        text-transform: uppercase;
        margin: 0;
    }

    .section-link {
        font-size: .75rem;
        font-weight: 600;
        color: #2f6fed;
        text-decoration: none;
    }

    .section-link:hover {
        text-decoration: underline;
        color: #2f6fed;
    }

    .section-meta {
        font-size: .72rem;
        color: #98a2b3;
    }

    /* Scope of work */
    .scope-id {
        font-size: .72rem;
        color: #98a2b3;
        font-weight: 600;
    }

    .scope-text {
        font-size: .85rem;
        color: #4a5568;
        line-height: 1.6;
    }

    .info-box {
        background: #f7f9fc;
        border-radius: 10px;
        padding: .85rem 1rem;
        height: 100%;
    }

    .info-label {
        font-size: .68rem;
        color: #98a2b3;
        text-transform: uppercase;
        letter-spacing: .3px;
        margin-bottom: .3rem;
    }

    .info-value {
        font-size: .85rem;
        font-weight: 600;
        color: #1a1f2b;
    }

    /* Site team */
    .team-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: .75rem 0;
        border-bottom: 1px solid #f2f4f8;
    }

    .team-item:last-child {
        border-bottom: none;
    }

    .team-name {
        font-size: .85rem;
        font-weight: 700;
        color: #1a1f2b;
        margin-bottom: .2rem;
    }

    .team-contact {
        font-size: .72rem;
        color: #98a2b3;
    }

    .role-badge {
        font-size: .68rem;
        font-weight: 600;
        color: #2f6fed;
        background: #eaf1ff;
        border-radius: 20px;
        padding: .3rem .7rem;
        white-space: nowrap;
    }

    /* Execution phases */
    .phase-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: .85rem 0;
        border-bottom: 1px solid #f2f4f8;
    }

    .phase-item:last-child {
        border-bottom: none;
    }

    .phase-title {
        font-size: .85rem;
        font-weight: 700;
        color: #1a1f2b;
        margin-bottom: .25rem;
    }

    .phase-meta {
        font-size: .72rem;
        color: #98a2b3;
    }

    .phase-progress-wrap {
        display: flex;
        align-items: center;
        gap: .6rem;
        flex: 0 0 auto;
        width: 230px;
    }

    .phase-progress-wrap .progress {
        height: 6px;
        width: 110px;
        border-radius: 10px;
        background: #eef1f6;
    }

    .phase-percent {
        font-size: .75rem;
        font-weight: 700;
        color: #1a1f2b;
        width: 34px;
    }

    .status-pill {
        font-size: .65rem;
        font-weight: 700;
        letter-spacing: .2px;
        border-radius: 20px;
        padding: .3rem .65rem;
        white-space: nowrap;
    }

    .status-completed {
        background: #e8f9ee;
        color: #1c9a4b;
    }

    .status-progress {
        background: #eaf1ff;
        color: #2f6fed;
    }

    .status-planned {
        background: #f2f4f8;
        color: #98a2b3;
    }

    /* Document repository */
    .doc-list {
        max-height: 260px;
        overflow-y: auto;
        padding-right: .5rem;
    }

    .doc-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #f7f9fc;
        border-radius: 10px;
        padding: .75rem 1rem;
        margin-bottom: .6rem;
    }

    .doc-item:last-child {
        margin-bottom: 0;
    }

    .doc-icon {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: #eaf1ff;
        color: #2f6fed;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .doc-name {
        font-size: .82rem;
        font-weight: 600;
        color: #1a1f2b;
    }

    .doc-meta {
        font-size: .7rem;
        color: #98a2b3;
    }

    .doc-download {
        font-size: .72rem;
        font-weight: 600;
        color: #2f6fed;
        text-decoration: none;
        white-space: nowrap;
    }

    .doc-download:hover {
        text-decoration: underline;
        color: #2f6fed;
    }

    /* Risk register */
    .risk-list {
        max-height: 260px;
        overflow-y: auto;
        padding-right: .5rem;
    }

    .risk-item {
        border: 1px solid #f2f4f8;
        border-radius: 10px;
        padding: .85rem 1rem;
        margin-bottom: .6rem;
    }

    .risk-item:last-child {
        margin-bottom: 0;
    }

    .risk-title {
        font-size: .83rem;
        font-weight: 700;
        color: #1a1f2b;
        margin-bottom: .35rem;
    }

    .risk-mitigation {
        font-size: .75rem;
        color: #98a2b3;
    }

    .risk-mitigation b {
        color: #4a5568;
        font-weight: 600;
    }

    .severity-pill {
        font-size: .65rem;
        font-weight: 700;
        border-radius: 20px;
        padding: .25rem .6rem;
        white-space: nowrap;
    }

    .severity-high {
        background: #fdeceb;
        color: #e0433c;
    }

    .severity-medium {
        background: #fef6e6;
        color: #c98a13;
    }

    .severity-low {
        background: #e8f9ee;
        color: #1c9a4b;
    }


    /* =========================
   MOBILE RESPONSIVE FIXES
   ========================= */

    @media (max-width: 767px) {

        .section-card {
            padding: 1rem 1.1rem;
        }

        .section-header {
            flex-wrap: wrap;
            gap: .4rem;
        }

        .section-title {
            font-size: .74rem;
        }

        /* Execution phases: stack title above progress bar */
        .phase-item {
            flex-direction: column;
            align-items: stretch !important;
            gap: .5rem;
        }

        .phase-progress-wrap {
            width: 100%;
            justify-content: space-between;
        }

        .phase-progress-wrap .progress {
            width: 100%;
            flex: 1 1 auto;
        }

        .phase-percent {
            width: auto;
        }

        /* Site team: stack name/contact above role badge */
        .team-item {
            flex-direction: column;
            align-items: flex-start !important;
            gap: .4rem;
        }

        .role-badge {
            align-self: flex-start;
        }

        /* Document list: stack icon+name above download link */
        .doc-item {
            flex-direction: column;
            align-items: stretch !important;
            gap: .6rem;
        }

        .doc-download {
            align-self: flex-end;
        }

        .doc-name {
            font-size: .78rem;
        }

        .doc-meta {
            font-size: .68rem;
        }

        /* Risk items: severity pill wraps under title if needed */
        .risk-item .d-flex.align-items-start.justify-content-between {
            flex-wrap: wrap;
            gap: .4rem;
        }

        .risk-title {
            font-size: .8rem;
        }

        /* Info boxes (Client / Site Manager): tighten padding on small screens */
        .info-box {
            padding: .75rem .9rem;
        }
    }


    @media (max-width: 575px) {

        .doc-list,
        .risk-list {
            max-height: none;
        }

        .scope-text {
            font-size: .8rem;
        }

        /* section header ("+ Upload Document" / "+ Assign Member" / "+ Register Risk")
       drops below title cleanly instead of squeezing beside it */
        .section-header {
            flex-direction: column;
            align-items: flex-start !important;
        }

        .section-link,
        .section-meta,
        .scope-id {
            align-self: flex-start;
        }
    }
    </style>
</div>

<!-- Assign Member Modal -->
@include('content.sitelog.manage_project.tabs.modal.assign-members')
<!-- Project Risk  -->
@include('content.sitelog.manage_project.tabs.modal.project-risk')
<!-- Upload Documents  -->
@include('content.sitelog.manage_project.tabs.modal.upload-documents')