<div class="material-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-value">
                    <i class="bi bi-box-seam-fill"></i>
                </div>
                <div class="stat-label">ASSIGNED STOCK VALUE</div>
                <div class="stat-value">₹1.88 <span>Cr</span></div>
                <div class="stat-desc text-success-custom">Fully certified catalog</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-alert">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                </div>
                <div class="stat-label">CRITICAL REORDER ALERTER</div>
                <div class="stat-value text-warning-custom">1 <span>Material Item</span></div>
                <div class="stat-desc">M45 ReadyMix requires top up</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-waste">
                    <i class="bi bi-recycle"></i>
                </div>
                <div class="stat-label">MONTHLY MATERIAL WASTE</div>
                <div class="stat-value text-danger-custom">0.42<span>%</span></div>
                <div class="stat-desc">Within industry tolerance (0.5%)</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: STOCK LEDGER -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-clipboard-data"></i> Site Stock Catalog &amp; Procurement Ledger
                    </h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export Stock Ledger
                    </button>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table stock-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>MATERIAL SPEC NAME</th>
                                    <th>CATEGORY</th>
                                    <th class="text-end">IN-SITE STOCK</th>
                                    <th class="text-end">PROCURED COST</th>
                                    <th class="text-center">STATUS</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td class="material-name">Cement Grade 53 (OPC)</td>
                                    <td class="material-category">Binder</td>
                                    <td class="text-end">4,200 <span class="unit-text">Bags</span></td>
                                    <td class="text-end amount-text">₹18,90,000</td>
                                    <td class="text-center"><span
                                            class="status-pill status-sufficient">Sufficient</span></td>
                                </tr>

                                <tr>
                                    <td class="material-name">Rebar TMT Steel (16mm)</td>
                                    <td class="material-category">Reinforcement</td>
                                    <td class="text-end">85 <span class="unit-text">Tons</span></td>
                                    <td class="text-end amount-text">₹55,25,000</td>
                                    <td class="text-center"><span
                                            class="status-pill status-sufficient">Sufficient</span></td>
                                </tr>

                                <tr>
                                    <td class="material-name">Ready-Mix Concrete M45</td>
                                    <td class="material-category">Concrete</td>
                                    <td class="text-end">1,800 <span class="unit-text">Cum</span></td>
                                    <td class="text-end amount-text">₹90,00,000</td>
                                    <td class="text-center"><span class="status-pill status-reorder">Reorder Soon</span>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="material-name">Prestressed Cables &amp; Tendons</td>
                                    <td class="material-category">Reinforcement</td>
                                    <td class="text-end">12 <span class="unit-text">Tons</span></td>
                                    <td class="text-end amount-text">₹24,00,000</td>
                                    <td class="text-center"><span
                                            class="status-pill status-sufficient">Sufficient</span></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


        <!-- RIGHT: MATERIAL INDENT REQUESTS -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-inboxes"></i> Material Indent Requests
                    </h6>
                    <button type="button" class="btn btn-sm submit-request-btn d-flex align-items-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#indentRequestModal">
                        <i class="bi bi-plus-lg"></i> Submit Request
                    </button>
                </div>

                <div class="card-body">

                    <div class="indent-item">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="indent-title">Rebar TMT Steel (16mm)</div>
                            <span class="indent-code">MR-092</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-1 mb-1">
                            <span class="indent-qty">Quantity: 40 Tons</span>
                            <span class="indent-requester">Requester: <strong>R. Vigneshwar</strong></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="indent-date">2026-07-20</span>
                            <span class="indent-status status-approved"><i class="bi bi-check-circle-fill"></i>
                                Approved</span>
                        </div>
                    </div>

                    <div class="indent-item">
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <div class="indent-title">Cement Grade 53 (OPC)</div>
                            <span class="indent-code">MR-095</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-1 mb-1">
                            <span class="indent-qty">Quantity: 500 Bags</span>
                            <span class="indent-requester">Requester: <strong>Er. Dinesh Karthik</strong></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="indent-date">2026-07-24</span>
                            <span class="indent-status status-pending"><i class="bi bi-hourglass-split"></i> Pending
                                Approval</span>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>

<!-- Material Indent Request Modal -->
@include('content.sitelog.manage_project.tabs.modal.material-indent-request')
<style>
.material-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #ffffff;
    border: 1px solid #dce5ef;
    border-radius: 12px;
    padding: 18px 16px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
}

.stat-icon.icon-value {
    background: #e6fbf3;
    color: #00a875;
}

.stat-icon.icon-alert {
    background: #fff4e6;
    color: #e5871d;
}

.stat-icon.icon-waste {
    background: #fdeceb;
    color: #d9423b;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a7bc;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
    padding-right: 40px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #071d35;
    line-height: 1;
    margin-bottom: 8px;
}

.stat-value span {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: #7790ac;
}

.stat-value.text-warning-custom {
    color: #e5871d;
}

.stat-value.text-danger-custom {
    color: #d9423b;
}

.stat-desc {
    font-size: 8.5px;
    color: #7790ac;
}

.text-success-custom {
    color: #00a875 !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 11.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.panel-title i {
    color: #17649b;
    font-size: 14px;
}

.panel-card .card-body {
    padding: 18px;
}


/* Export button */
.export-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}

/* Submit request button */
.submit-request-btn {
    background: #17649b;
    border: 0;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.submit-request-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Stock ledger table */
.stock-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.stock-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 18px;
    white-space: nowrap;
}

.stock-table tbody td {
    padding: 12px 18px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.stock-table tbody tr:last-child td {
    border-bottom: 0;
}

.material-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
}

.material-category {
    color: #5a7fb8;
}

.unit-text {
    color: #94a7bc;
    font-weight: 400;
}

.amount-text {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
}

.status-pill {
    display: inline-block;
    font-size: 7.5px;
    font-weight: 700;
    border-radius: 20px;
    padding: 5px 12px;
    white-space: nowrap;
}

.status-sufficient {
    color: #00a875;
    background: #f4fffb;
    border: 1px solid #8be7c7;
}

.status-reorder {
    color: #e5871d;
    background: #fff8ee;
    border: 1px solid #f2cf70;
}


/* Material indent requests */
.indent-item {
    background: #f8fafc;
    border: 1px solid #edf1f5;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 12px;
}

.indent-item:last-child {
    margin-bottom: 0;
}

.indent-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 10px;
    font-weight: 700;
    color: #142c47;
}

.indent-code {
    font-size: 7.5px;
    font-weight: 700;
    color: #17649b;
    background: #edf6fd;
    border: 1px solid #d7e8f6;
    border-radius: 5px;
    padding: 3px 8px;
    white-space: nowrap;
}

.indent-qty {
    font-size: 8.5px;
    color: #5a7fb8;
}

.indent-requester {
    font-size: 8.5px;
    color: #7790ac;
}

.indent-requester strong {
    color: #142c47;
    font-weight: 700;
}

.indent-date {
    font-size: 8px;
    color: #a4b4c6;
}

.indent-status {
    font-size: 7.5px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.indent-status i {
    font-size: 9px;
}

.status-approved {
    color: #00a875;
}

.status-pending {
    color: #e5871d;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 16px 14px;
    }

    .stat-label {
        padding-right: 44px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn,
    .submit-request-btn {
        justify-content: center;
    }

    .stock-table {
        min-width: 620px;
    }

    .indent-item .d-flex.justify-content-between.align-items-center.flex-wrap {
        flex-direction: column;
        align-items: flex-start !important;
        gap: 4px;
    }
}
</style>