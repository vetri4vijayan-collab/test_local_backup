<div class="machinery-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-registered">
                    <i class="bi bi-truck-front-fill"></i>
                </div>
                <div class="stat-label">REGISTERED MACHINERY</div>
                <div class="stat-value">4 <span>Heavy Units</span></div>
                <div class="stat-desc text-success-custom">Fully operational in-site fleet</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-utilization">
                    <i class="bi bi-speedometer2"></i>
                </div>
                <div class="stat-label">AVERAGE SITE UTILIZATION</div>
                <div class="stat-value text-primary-custom">82.4<span>%</span></div>
                <div class="stat-desc text-success-custom">Exceeds target efficiency (80%)</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-down">
                    <i class="bi bi-tools"></i>
                </div>
                <div class="stat-label">DOWN FOR SERVICE/REPAIRS</div>
                <div class="stat-value text-danger-custom">1 <span>Rig Unit</span></div>
                <div class="stat-desc text-danger-custom">Under Mait mechanical service</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: FLEET MATRIX -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-diagram-3"></i> Heavy Machinery Deployment &amp; Operators Matrix
                    </h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export Fleet Logs
                    </button>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table machinery-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>MACHINERY PLANT DESCRIPTION</th>
                                    <th>ASSIGNED OPERATOR</th>
                                    <th class="text-end">ACTIVE RUN HRS</th>
                                    <th class="text-end">IDLE HOURS</th>
                                    <th class="text-end">UTILIZATION</th>
                                    <th class="text-center">OPERATIONAL STATUS</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <div class="machinery-name">Sany Heavy Crane (150T)</div>
                                        <div class="machinery-meta">Code: MAC-1 &bull; Next Service: 2026-08-15</div>
                                    </td>
                                    <td class="operator-name">Muthu Pillai</td>
                                    <td class="text-end run-hrs">142 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end idle-hrs">12 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end utilization-value">92%</td>
                                    <td class="text-center"><span class="status-pill status-active">Active</span></td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="machinery-name">Mait HR180 Piling Rig</div>
                                        <div class="machinery-meta">Code: MAC-2 &bull; Next Service: 2026-07-29</div>
                                    </td>
                                    <td class="operator-name">R. Jagdish</td>
                                    <td class="text-end run-hrs">98 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end idle-hrs">24 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end utilization-value">80%</td>
                                    <td class="text-center"><span
                                            class="status-pill status-maintenance">Maintenance</span></td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="machinery-name">Schwing Stetter Batching Plant</div>
                                        <div class="machinery-meta">Code: MAC-3 &bull; Next Service: 2026-08-20</div>
                                    </td>
                                    <td class="operator-name">Sunil Kumar</td>
                                    <td class="text-end run-hrs">210 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end idle-hrs">8 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end utilization-value">96%</td>
                                    <td class="text-center"><span class="status-pill status-active">Active</span></td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="machinery-name">Concrete Boom Placer 36M</div>
                                        <div class="machinery-meta">Code: MAC-4 &bull; Next Service: 2026-08-10</div>
                                    </td>
                                    <td class="operator-name">Vikram Singh</td>
                                    <td class="text-end run-hrs">85 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end idle-hrs">32 <span class="unit-text">Hrs</span></td>
                                    <td class="text-end utilization-value">72%</td>
                                    <td class="text-center"><span class="status-pill status-active">Active</span></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


        <!-- RIGHT: DEPLOY MACHINERY -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-truck-flatbed"></i> Deploy Machinery to Site
                    </h6>
                    <button type="button" class="btn btn-sm register-fleet-btn d-flex align-items-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#registerFleetModal">
                        <i class="bi bi-plus-lg"></i> Register Fleet Plant
                    </button>
                </div>

                <div class="card-body">

                    <div class="telematics-banner">
                        <div class="telematics-header">
                            <i class="bi bi-info-circle-fill"></i> Telematics Integration
                        </div>
                        <p class="telematics-text mb-0">
                            Machine telemetry data is synchronized in real-time. Idle hours alert if any vehicle exceeds
                            4 hours without active hydraulic torque load.
                        </p>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>

<!-- Register Fleet Plant  Modal -->
@include('content.sitelog.manage_project.tabs.modal.register-fleet-plant')
<style>
.machinery-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #ffffff;
    border: 1px solid #dce5ef;
    border-radius: 12px;
    padding: 18px 16px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
}

.stat-icon.icon-registered {
    background: #eaf2fb;
    color: #17649b;
}

.stat-icon.icon-utilization {
    background: #eaf2fb;
    color: #17649b;
}

.stat-icon.icon-down {
    background: #fdeceb;
    color: #d9423b;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a7bc;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
    padding-right: 40px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #071d35;
    line-height: 1;
    margin-bottom: 8px;
}

.stat-value span {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: #7790ac;
}

.stat-value.text-primary-custom {
    color: #17649b;
}

.stat-value.text-danger-custom {
    color: #d9423b;
}

.stat-desc {
    font-size: 8.5px;
    color: #7790ac;
}

.text-success-custom {
    color: #00a875 !important;
}

.text-danger-custom.stat-desc {
    color: #d9423b !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 11.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.panel-title i {
    color: #17649b;
    font-size: 14px;
}

.panel-card .card-body {
    padding: 18px;
}


/* Buttons */
.export-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}

.register-fleet-btn {
    background: #17649b;
    border: 0;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.register-fleet-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Machinery table */
.machinery-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.machinery-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 18px;
    white-space: nowrap;
}

.machinery-table tbody td {
    padding: 12px 18px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.machinery-table tbody tr:last-child td {
    border-bottom: 0;
}

.machinery-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
    font-size: 10px;
    margin-bottom: 2px;
}

.machinery-meta {
    font-size: 7.5px;
    color: #a4b4c6;
}

.operator-name {
    color: #17649b;
    font-weight: 600;
}

.run-hrs {
    color: #142c47;
    font-weight: 600;
}

.idle-hrs {
    color: #a4b4c6;
}

.unit-text {
    color: #a4b4c6;
    font-weight: 400;
}

.utilization-value {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #17649b;
}

.status-pill {
    display: inline-block;
    font-size: 7.5px;
    font-weight: 700;
    border-radius: 20px;
    padding: 5px 12px;
    white-space: nowrap;
}

.status-active {
    color: #00a875;
    background: #f4fffb;
    border: 1px solid #8be7c7;
}

.status-maintenance {
    color: #d9423b;
    background: #fdeceb;
    border: 1px solid #f3c9c9;
}


/* Telematics banner */
.telematics-banner {
    background: #eaf2fb;
    border: 1px solid #d7e8f6;
    border-radius: 10px;
    padding: 14px 16px;
}

.telematics-header {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
    font-weight: 800;
    color: #17649b;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
}

.telematics-header i {
    font-size: 12px;
}

.telematics-text {
    font-size: 9px;
    color: #4d6f96;
    line-height: 1.6;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 16px 14px;
    }

    .stat-label {
        padding-right: 44px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn,
    .register-fleet-btn {
        justify-content: center;
    }

    .machinery-table {
        min-width: 680px;
    }
}
</style>