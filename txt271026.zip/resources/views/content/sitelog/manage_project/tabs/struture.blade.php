<div class="structure-dashboard">

    <div class="row g-3 mb-3">

        <div class="col-xl-3 col-md-6">
            <div class="summary-card">
                <div class="summary-label">TOTAL STRUCTURAL UNITS</div>
                <div class="summary-value">4 <span>Units</span></div>
                <div class="summary-description">Registered on this project</div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="summary-card">
                <div class="summary-label">COMPLETED STRUCTURES</div>
                <div class="summary-value completed">2 <span>Units</span></div>
                <div class="summary-description completed-text">Ready for final QA handoff</div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="summary-card">
                <div class="summary-label">IN-PROGRESS UNITS</div>
                <div class="summary-value">2 <span>Units</span></div>
                <div class="summary-description">Under active work/curing</div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="summary-card">
                <div class="summary-label">AVERAGE PROGRESS</div>
                <div class="summary-value progress-value">78%</div>
                <div class="summary-description">Overall project completion</div>
            </div>
        </div>

    </div>


    <div class="structure-toolbar mb-3">

        <div class="structure-search">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Search structures...">
        </div>

        <button type="button" class="register-btn" data-bs-toggle="modal" data-bs-target="#newStructureModal">
            <i class="bi bi-plus-lg"></i>
            Register Structure Unit
        </button>

    </div>


    <div class="row g-3 mb-3">

        <div class="col-xl-6 col-lg-6">
            <div class="structure-card">

                <div class="structure-card-header">

                    <div>
                        <span class="project-code">PRJ-001-STR1</span>
                        <h5>Pier P41 Pillar</h5>
                    </div>

                    <span class="status-badge status-completed">
                        COMPLETED
                    </span>

                </div>

                <div class="progress-section">

                    <div class="progress-title">
                        <span>Pouring Progress (120 / 120 cu.m)</span>
                        <strong>100%</strong>
                    </div>

                    <div class="progress-bar-wrapper">
                        <div class="progress-bar-fill completed-progress" style="width: 100%;">
                        </div>
                    </div>

                </div>

                <div class="structure-divider"></div>

                <div class="structure-details">
                    <span><b>Type:</b> Pillar</span>
                    <span><b>Mix:</b> M50 Grade</span>
                    <span><b>QC:</b> <strong class="qc-success">7-Day Passed</strong></span>
                </div>

            </div>
        </div>


        <div class="col-xl-6 col-lg-6">
            <div class="structure-card">

                <div class="structure-card-header">

                    <div>
                        <span class="project-code">PRJ-001-STR2</span>
                        <h5>Pier P42 Pier Cap</h5>
                    </div>

                    <span class="status-badge status-curing">
                        CURING
                    </span>

                </div>

                <div class="progress-section">

                    <div class="progress-title">
                        <span>Pouring Progress (80 / 100 cu.m)</span>
                        <strong>80%</strong>
                    </div>

                    <div class="progress-bar-wrapper">
                        <div class="progress-bar-fill" style="width: 80%;">
                        </div>
                    </div>

                </div>

                <div class="structure-divider"></div>

                <div class="structure-bottom">

                    <div class="structure-details">
                        <span><b>Type:</b> Pier Cap</span>
                        <span><b>Mix:</b> M55 Grade</span>
                        <span><b>QC:</b> Pending Testing</span>
                    </div>

                    <div class="card-actions">
                        <button class="action-btn pour-btn">
                            + POUR 20 CU.M
                        </button>

                        <button class="action-btn complete-btn">
                            COMPLETE
                        </button>
                    </div>

                </div>

            </div>
        </div>


        <div class="col-xl-6 col-lg-6">
            <div class="structure-card">

                <div class="structure-card-header">

                    <div>
                        <span class="project-code">PRJ-001-STR3</span>
                        <h5>Segment S12 Box Girder</h5>
                    </div>

                    <span class="status-badge status-progress">
                        FORMWORK IN-PROGRESS
                    </span>

                </div>

                <div class="progress-section">

                    <div class="progress-title">
                        <span>Pouring Progress (45 / 150 cu.m)</span>
                        <strong>30%</strong>
                    </div>

                    <div class="progress-bar-wrapper">
                        <div class="progress-bar-fill" style="width: 30%;">
                        </div>
                    </div>

                </div>

                <div class="structure-divider"></div>

                <div class="structure-bottom">

                    <div class="structure-details">
                        <span><b>Type:</b> Girder</span>
                        <span><b>Mix:</b> M60 Grade</span>
                        <span><b>QC:</b> Pending Testing</span>
                    </div>

                    <div class="card-actions">
                        <button class="action-btn pour-btn">
                            + POUR 20 CU.M
                        </button>

                        <button class="action-btn complete-btn">
                            COMPLETE
                        </button>
                    </div>

                </div>

            </div>
        </div>


        <div class="col-xl-6 col-lg-6">
            <div class="structure-card">

                <div class="structure-card-header">

                    <div>
                        <span class="project-code">PRJ-001-STR4</span>
                        <h5>Abutment A1 Foundation</h5>
                    </div>

                    <span class="status-badge status-completed">
                        COMPLETED
                    </span>

                </div>

                <div class="progress-section">

                    <div class="progress-title">
                        <span>Pouring Progress (200 / 200 cu.m)</span>
                        <strong>100%</strong>
                    </div>

                    <div class="progress-bar-wrapper">
                        <div class="progress-bar-fill completed-progress" style="width: 100%;">
                        </div>
                    </div>

                </div>

                <div class="structure-divider"></div>

                <div class="structure-details">
                    <span><b>Type:</b> Foundation</span>
                    <span><b>Mix:</b> M40 Grade</span>
                    <span><b>QC:</b> <strong class="qc-success">28-Day Passed</strong></span>
                </div>

            </div>
        </div>

    </div>

    <div class="checklist-setup p-3 p-md-4 bg-white border rounded-3 mb-3">

        <div class="d-flex align-items-start gap-3">
            <div class="setup-header-icon d-flex align-items-center justify-content-center rounded-3">
                <i class="bi bi-stack"></i>
            </div>
            <div>
                <h4 class="mb-1 fw-bold setup-title">Structure Type Mapping &amp; Checklist Setup</h4>
                <p class="mb-0 setup-subtitle">Map standard or custom structure process templates to your registered
                    units, customize checklist items, edit step descriptions, and monitor field completion status.</p>
            </div>
        </div>

        <hr class="my-3 my-md-4">

        <div class="row g-3">

            <!-- LEFT PANEL -->
            <div class="col-lg-3">
                <div class="unit-panel bg-light border rounded-3 p-3 h-100">

                    <div class="panel-label mb-2">SELECT UNIT TO MANAGE</div>
                    <select class="form-select form-select-sm mb-3 unit-select">
                        <option>Pier P41 Pillar (PRJ-001-STR1) — Pillar</option>
                    </select>

                    <div class="panel-label mb-2">UNIT SPECIFICATIONS</div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <div class="spec-box border rounded-3 p-2 h-100">
                                <div class="spec-label">GRADE</div>
                                <div class="spec-value">M50 Grade</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="spec-box border rounded-3 p-2 h-100">
                                <div class="spec-label">TARGET VOL</div>
                                <div class="spec-value">120 m³</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="spec-box border rounded-3 p-2 h-100">
                                <div class="spec-label">STATUS</div>
                                <div class="spec-value d-flex align-items-center gap-1 text-success">
                                    <span class="status-dot"></span> Completed
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="spec-box border rounded-3 p-2 h-100">
                                <div class="spec-label">POURED</div>
                                <div class="spec-value">120 m³</div>
                            </div>
                        </div>
                    </div>

                    <div class="panel-label mb-2">MAPPED TEMPLATES</div>
                    <div class="d-flex flex-column gap-2">
                        <div
                            class="mapped-row d-flex justify-content-between align-items-center border rounded-3 px-2 py-2">
                            <span>Pier Structure</span>
                            <strong class="text-success">8/8 Done</strong>
                        </div>
                        <div
                            class="mapped-row d-flex justify-content-between align-items-center border rounded-3 px-2 py-2">
                            <span>Bridge Abutment</span>
                            <strong class="text-warning">0/6 Done</strong>
                        </div>
                    </div>

                </div>
            </div>

            <!-- RIGHT PANEL -->
            <div class="col-lg-9">

                <div class="d-flex justify-content-between align-items-baseline mb-2 flex-wrap gap-1">
                    <h5 class="mb-0 fw-bold panel-heading">AVAILABLE STRUCTURE TEMPLATES</h5>
                    <span class="panel-hint">Click to instantly map a process checklist template</span>
                </div>
                <div class="d-flex flex-column flex-sm-row gap-2 mt-3 mb-3">
                    <input type="text" class="form-control form-control-sm"
                        placeholder="Or create custom process template...">
                    <button
                        class="btn btn-sm add-custom-btn d-flex align-items-center justify-content-center gap-1 flex-shrink-0"
                        type="button">
                        <i class="bi bi-plus-lg"></i> Add Custom Template
                    </button>
                </div>

                <div class="row g-2 g-md-3">

                    <div class="col-md-4">
                        <div class="template-card mapped border rounded-3 p-3 h-100" data-name="Pier Structure">
                            <h6 class="fw-bold mb-1">Pier Structure</h6>
                            <span class="item-count d-block mb-3">8 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button" disabled>
                                <i class="bi bi-check-lg"></i> Mapped
                            </button>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="template-card border rounded-3 p-3 h-100" data-name="RC Column">
                            <h6 class="fw-bold mb-1">RC Column</h6>
                            <span class="item-count d-block mb-3">6 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button">
                                <i class="bi bi-plus-lg"></i> Map Template
                            </button>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="template-card mapped border rounded-3 p-3 h-100" data-name="Bridge Abutment">
                            <h6 class="fw-bold mb-1">Bridge Abutment</h6>
                            <span class="item-count d-block mb-3">6 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button" disabled>
                                <i class="bi bi-check-lg"></i> Mapped
                            </button>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="template-card border rounded-3 p-3 h-100" data-name="Prestressed Girder">
                            <h6 class="fw-bold mb-1">Prestressed Girder</h6>
                            <span class="item-count d-block mb-3">7 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button">
                                <i class="bi bi-plus-lg"></i> Map Template
                            </button>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="template-card border rounded-3 p-3 h-100" data-name="Slab Deck">
                            <h6 class="fw-bold mb-1">Slab Deck</h6>
                            <span class="item-count d-block mb-3">6 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button">
                                <i class="bi bi-plus-lg"></i> Map Template
                            </button>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="template-card border rounded-3 p-3 h-100" data-name="Pipe Culvert">
                            <h6 class="fw-bold mb-1">Pipe Culvert</h6>
                            <span class="item-count d-block mb-3">10 Checklist Items</span>
                            <button
                                class="btn btn-sm w-100 map-btn d-flex align-items-center justify-content-center gap-1"
                                type="button">
                                <i class="bi bi-plus-lg"></i> Map Template
                            </button>
                        </div>
                    </div>

                </div>



            </div>

        </div>

    </div>

    <div class="checklist-wrapper p-3 p-md-4 bg-white border rounded-3 mb-3">

        <div class="mb-3">
            <h4 class="mb-1 fw-bold page-title">Mapped Process Checklists</h4>
            <p class="mb-0 page-subtitle">Execution steps tracked under unit <strong>Pier P41 Pillar</strong></p>
        </div>

        <!-- CARD 1 -->
        <div class="card checklist-card mb-3">

            <div class="card-header d-flex align-items-center justify-content-between" data-bs-toggle="collapse"
                data-bs-target="#pierStructureBody" role="button" aria-expanded="true">

                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-chevron-down toggle-icon"></i>
                    <span class="group-title">PIER STRUCTURE</span>
                    <span class="group-count">8 / 8 COMPLETED</span>
                </div>

                <div class="d-flex align-items-center gap-3" onclick="event.stopPropagation()">
                    <div class="group-progress d-none d-md-flex align-items-center gap-2">
                        <div class="progress group-progress-bar">
                            <div class="progress-bar" style="width: 100%;"></div>
                        </div>
                        <span class="progress-pct">100%</span>
                    </div>
                    <button class="btn btn-sm complete-all-btn d-flex align-items-center gap-1" type="button">
                        <i class="bi bi-check-lg"></i> Complete All
                    </button>
                    <button class="icon-btn" type="button" title="Delete group">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>

            </div>

            <div class="collapse show" id="pierStructureBody">
                <div class="card-body p-0">

                    <div class="add-item-row d-flex flex-column flex-md-row gap-2 p-3">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add checklist item name...">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add specification description...">
                        <button
                            class="btn btn-sm add-item-btn d-flex align-items-center justify-content-center gap-1 flex-shrink-0"
                            type="button">
                            <i class="bi bi-plus-lg"></i> Add Item
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table checklist-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th class="text-nowrap">STATUS</th>
                                    <th class="text-end">ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td class="item-name">Excavation</td>
                                    <td class="item-desc">Excavating soil to required depth as per structural drawings.
                                    </td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">PCC Bedding</td>
                                    <td class="item-desc">Laying plain cement concrete layer for foundation base.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Rebar Caging &amp; Binding</td>
                                    <td class="item-desc">Fabricating steel reinforcement cage and binding with binding
                                        wire.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Formwork Erection</td>
                                    <td class="item-desc">Assembling and aligning plywood/steel shuttering with rigid
                                        supports.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Concrete Pouring</td>
                                    <td class="item-desc">Discharging ready-mix concrete of design grade with
                                        compaction.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Concrete Curing</td>
                                    <td class="item-desc">Ponding or wet hessian cloth covering for hydration
                                        development.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">QC Slump &amp; Cube Test</td>
                                    <td class="item-desc">Sampling and casting test cubes, slump flow check at site.
                                    </td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Formwork Stripping</td>
                                    <td class="item-desc">Stripping side shutters after specified setting time safely.
                                    </td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-completed">
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option selected>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>


        <!-- CARD 2 (collapsed by default) -->
        <div class="card checklist-card mb-3">

            <div class="card-header d-flex align-items-center justify-content-between collapsed"
                data-bs-toggle="collapse" data-bs-target="#bridgeAbutmentBody" role="button" aria-expanded="false">

                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-chevron-down toggle-icon"></i>
                    <span class="group-title">BRIDGE ABUTMENT</span>
                    <span class="group-count partial">0 / 6 COMPLETED</span>
                </div>

                <div class="d-flex align-items-center gap-3" onclick="event.stopPropagation()">
                    <div class="group-progress d-none d-md-flex align-items-center gap-2">
                        <div class="progress group-progress-bar">
                            <div class="progress-bar bg-warning" style="width: 0%;"></div>
                        </div>
                        <span class="progress-pct">0%</span>
                    </div>
                    <button class="btn btn-sm complete-all-btn d-flex align-items-center gap-1" type="button">
                        <i class="bi bi-check-lg"></i> Complete All
                    </button>
                    <button class="icon-btn" type="button" title="Delete group">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>

            </div>

            <div class="collapse" id="bridgeAbutmentBody">
                <div class="card-body p-0">
                    <div class="add-item-row d-flex flex-column flex-md-row gap-2 p-3">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add checklist item name...">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add specification description...">
                        <button
                            class="btn btn-sm add-item-btn d-flex align-items-center justify-content-center gap-1 flex-shrink-0"
                            type="button">
                            <i class="bi bi-plus-lg"></i> Add Item
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table checklist-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th class="text-nowrap">STATUS</th>
                                    <th class="text-end">ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td class="item-name">Soil Compaction &amp; Stabilization</td>
                                    <td class="item-desc">Vibratory roller compaction of earth to reach maximum dry
                                        density.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Bore Piling Operations</td>
                                    <td class="item-desc">Drilling boreholes, cleaning bentonite slurry, and pile
                                        casting.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Abutment Rebar Fitting</td>
                                    <td class="item-desc">Fixing heavy structural rebar for bridge retaining abutment
                                        walls.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Abutment Formwork Assembly</td>
                                    <td class="item-desc">Erection of high-rise heavy formwork with tie rods.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Concrete Pouring (M60)</td>
                                    <td class="item-desc">Mass concreting of M60 design mix under cold temperature
                                        control.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Curing &amp; Backfilling</td>
                                    <td class="item-desc">Backfilling soil in layers after curing of concrete wall.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

        <!-- CARD 3  -->
        <div class="card checklist-card mb-3">

            <div class="card-header d-flex align-items-center justify-content-between collapsed"
                data-bs-toggle="collapse" data-bs-target="#rcColumnBody" role="button" aria-expanded="false">

                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-chevron-down toggle-icon"></i>
                    <span class="group-title">RC COLUMN</span>
                    <span class="group-count partial">0 / 6 COMPLETED</span>
                </div>

                <div class="d-flex align-items-center gap-3" onclick="event.stopPropagation()">
                    <div class="group-progress d-none d-md-flex align-items-center gap-2">
                        <div class="progress group-progress-bar">
                            <div class="progress-bar bg-warning" style="width: 0%;"></div>
                        </div>
                        <span class="progress-pct">0%</span>
                    </div>
                    <button class="btn btn-sm complete-all-btn d-flex align-items-center gap-1" type="button">
                        <i class="bi bi-check-lg"></i> Complete All
                    </button>
                    <button class="icon-btn" type="button" title="Delete group">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>

            </div>

            <div class="collapse" id="rcColumnBody">
                <div class="card-body p-0">

                    <div class="add-item-row d-flex flex-column flex-md-row gap-2 p-3">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add checklist item name...">
                        <input type="text" class="form-control form-control-sm"
                            placeholder="Add specification description...">
                        <button
                            class="btn btn-sm add-item-btn d-flex align-items-center justify-content-center gap-1 flex-shrink-0"
                            type="button">
                            <i class="bi bi-plus-lg"></i> Add Item
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table checklist-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>ITEM NAME</th>
                                    <th>SPECIFICATION DESCRIPTION</th>
                                    <th class="text-nowrap">STATUS</th>
                                    <th class="text-end">ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td class="item-name">Foundation Excavation</td>
                                    <td class="item-desc">Digging foundation trench with JCB up to firm soil layer.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Pillar Rebar Cage</td>
                                    <td class="item-desc">Tying and placing vertical steel cage for pillar columns.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Column Formwork</td>
                                    <td class="item-desc">Erecting vertical steel column casings with scaffolding.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Column Concreting</td>
                                    <td class="item-desc">Pouring concrete using bucket or pump with high frequency
                                        vibration.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Curing Process</td>
                                    <td class="item-desc">Water sprinkling or curing compound application on exposed
                                        column faces.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="item-name">Concrete Core Compression Test</td>
                                    <td class="item-desc">Crushing concrete cubes at 7 and 28 days for quality
                                        assurance.</td>
                                    <td>
                                        <select class="form-select form-select-sm status-select status-notstarted">
                                            <option selected>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                        </select>
                                    </td>
                                    <td class="text-end">
                                        <button class="icon-btn" type="button" title="Delete item"><i
                                                class="bi bi-trash"></i></button>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
<!-- Register Struture Modal -->
@include('content.sitelog.manage_project.tabs.modal.register-struture-unit')
<script>
document.querySelectorAll('.template-card:not(.mapped) .map-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var card = btn.closest('.template-card');
        card.classList.add('mapped');
        btn.innerHTML = '<i class="bi bi-check-lg"></i> Mapped';
        btn.disabled = true;
        // hook your actual "map template" API call here, e.g.:
        // mapTemplateToUnit(card.dataset.name);
    });
});
// Recolor status <select> based on chosen value
document.querySelectorAll('.status-select').forEach(function(select) {
    function applyStatusClass() {
        select.classList.remove('status-completed', 'status-inprogress', 'status-notstarted');
        var val = select.value;
        if (val === 'Completed') select.classList.add('status-completed');
        else if (val === 'In Progress') select.classList.add('status-inprogress');
        else select.classList.add('status-notstarted');
    }
    select.addEventListener('change', applyStatusClass);
    applyStatusClass();
});

// Rotate chevron on collapse toggle (Bootstrap collapse events)
document.querySelectorAll('.group-header').forEach(function(header) {
    var targetSel = header.getAttribute('data-bs-target');
    var target = document.querySelector(targetSel);
    if (!target) return;
    target.addEventListener('show.bs.collapse', function() {
        header.classList.remove('collapsed');
    });
    target.addEventListener('hide.bs.collapse', function() {
        header.classList.add('collapsed');
    });
});
</script>
<style>
.structure-dashboard {
    width: 100%;
    padding: 0;
    font-family: 'Inter', sans-serif;
}

.summary-card {
    background: #fff;
    border: 1px solid #dce5ef;
    border-radius: 10px;
    padding: 20px 14px;
    min-height: 84px;
}

.summary-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    text-transform: uppercase;
    margin-bottom: 7px;
}

.summary-value {
    font-size: 15px;
    font-weight: 700;
    color: #0c3d72;
    line-height: 1;
}

.summary-value span {
    font-size: 14px;
    font-weight: 600;
}

.summary-value.completed {
    color: #00a875;
}

.summary-value.progress-value {
    color: #6c35d9;
}

.summary-description {
    font-size: 8px;
    color: #67809c;
    margin-top: 7px;
}

.completed-text {
    color: #00a875;
}


.structure-toolbar {
    min-height: 47px;
    padding: 9px;
    border: 1px solid #dce5ef;
    border-radius: 10px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
}

.structure-search {
    width: 257px;
    height: 26px;
    border: 1px solid #bfd0e2;
    background: #F8FAFC;
    border-radius: 6px;
    display: flex;
    align-items: center;
    padding: 0 9px;
}

.structure-search i {
    font-size: 12px;
    color: #7891ad;
    margin-right: 8px;
}

.structure-search input {
    width: 100%;
    border: 0;
    outline: 0;
    font-size: 9px;
    color: #334e68;
    background: #F8FAFC;
}

.structure-search input::placeholder {
    color: #8094aa;
}

.register-btn {
    height: 26px;
    padding: 0 13px;
    border: 0;
    border-radius: 6px;
    background: #17649b;
    color: #ffffff;
    font-size: 9px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 6px;
}

.register-btn:hover {
    background: #0f5689;
}

.register-btn i {
    font-size: 10px;
}


.structure-card {
    background: #ffffff;
    border: 1px solid #d8e2ed;
    border-radius: 11px;
    padding: 17px 16px;
    min-height: 158px;
    transition: all 0.2s ease;
}

.structure-card:hover {
    border-color: #b8ccdf;
    box-shadow: 0 4px 15px rgba(30, 70, 110, 0.08);
}

.structure-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 10px;
}

.project-code {
    display: inline-block;
    padding: 3px 7px;
    border-radius: 4px;
    background: #edf6fd;
    border: 1px solid #d7e8f6;
    color: #17649b;
    font-size: 7px;
    font-weight: 700;
    margin-bottom: 6px;
}

.structure-card h5 {
    margin: 0;
    font-size: 12px;
    font-weight: 700;
    color: #071d35;
}

.status-badge {
    white-space: nowrap;
    border-radius: 12px;
    padding: 4px 10px;
    font-size: 7px;
    font-weight: 700;
    letter-spacing: 0.2px;
}

.status-completed {
    color: #00a875;
    border: 1px solid #8be7c7;
    background: #f4fffb;
}

.status-curing {
    color: #e5a400;
    border: 1px solid #f2cf70;
    background: #fffdf5;
}

.status-progress {
    color: #17649b;
    border: 1px solid #b7d4eb;
    background: #f5faff;
}


.progress-section {
    margin-top: 14px;
}

.progress-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 8px;
    color: #195084;
    margin-bottom: 7px;
}

.progress-title strong {
    font-size: 8px;
    color: #111827;
}

.progress-bar-wrapper {
    height: 6px;
    width: 100%;
    border-radius: 5px;
    background: #edf1f5;
    overflow: hidden;
}

.progress-bar-fill {
    height: 100%;
    border-radius: 5px;
    background: #1769a5;
}

.completed-progress {
    background: #00b77b;
}


.structure-divider {
    height: 1px;
    background: #edf1f5;
    margin: 20px 0 10px;
}

.structure-details {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 13px;
    font-size: 8px;
    color: #607993;
}

.structure-details b {
    color: #185083;
    font-weight: 700;
}

.qc-success {
    color: #00a875 !important;
}


.structure-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.card-actions {
    display: flex;
    gap: 6px;
    flex-shrink: 0;
}

.action-btn {
    height: 20px;
    padding: 0 8px;
    border-radius: 3px;
    font-size: 7px;
    font-weight: 700;
    background: #ffffff;
}

.pour-btn {
    color: #17649b;
    border: 1px solid #b7d4eb;
}

.complete-btn {
    color: #00a875;
    border: 1px solid #75dfbc;
}

.pour-btn:hover,
.complete-btn:hover {
    background: #f5f9fc;
}

.checklist-setup {
    font-family: 'Inter', sans-serif;
    border-color: #dce5ef !important;
}

.setup-header-icon {
    width: 34px;
    height: 34px;
    min-width: 34px;
    background: #eaf2fb;
    color: #17649b;
    font-size: 15px;
}

.setup-title {
    font-size: 13px;
    color: #071d35;
    letter-spacing: 0.2px;
}

.setup-subtitle {
    font-size: 9.5px;
    color: #6b8199;
    line-height: 1.5;
    max-width: 680px;
}

.panel-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
}

.panel-heading {
    font-size: 10px;
    color: #142c47;
    letter-spacing: 0.3px;
}

.panel-hint {
    font-size: 8px;
    color: #94a7bc;
}

.unit-panel {
    background: #f8fafc !important;
    border-color: #dce5ef !important;
}

.unit-select {
    font-size: 9.5px;
    color: #17324f;
    border-color: #bfd0e2;
}

.spec-box {
    background: #ffffff;
    border-color: #e2e9f1 !important;
}

.spec-label {
    font-size: 6.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    margin-bottom: 4px;
}

.spec-value {
    font-size: 9.5px;
    font-weight: 700;
    color: #142c47;
}

.status-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #00a875;
    display: inline-block;
}

.mapped-row {
    background: #ffffff;
    border-color: #e2e9f1 !important;
    font-size: 9px;
    color: #17324f;
}

.mapped-row strong {
    font-size: 8.5px;
}

/* Template cards */
.template-card {
    background: #ffffff;
    border-color: #dce5ef !important;
    transition: all 0.18s ease;
}

.template-card:hover {
    border-color: #b8ccdf !important;
    box-shadow: 0 4px 15px rgba(30, 70, 110, 0.08);
}

.template-card.mapped {
    border-color: #8be7c7 !important;
    background: #fbfffd;
}

.template-card h6 {
    font-size: 10px;
    color: #071d35;
}

.item-count {
    font-size: 8px;
    color: #8397ad;
}

.map-btn {
    height: 26px;
    border-radius: 6px;
    border: 1px solid #b7d4eb;
    background: #f5faff;
    color: #17649b;
    font-size: 8.5px;
    font-weight: 700;
}

.map-btn:hover:not(:disabled) {
    background: #eaf3fc;
    color: #17649b;
}

.template-card.mapped .map-btn {
    border-color: #75dfbc;
    background: #e6fbf3;
    color: #00a875;
    opacity: 1;
}

.custom-template-row input,
.checklist-setup .form-control {
    font-size: 9px;
    color: #334e68;
    border-color: #dce5ef;
}

.add-custom-btn {
    height: 30px;
    border-radius: 7px;
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    white-space: nowrap;
}

.add-custom-btn:hover {
    background: #0f5689;
    color: #ffffff;
}

/* check list  */
.checklist-wrapper {
    font-family: 'Inter', sans-serif;
}

.page-title {
    font-size: 15px;
    color: #071d35;
}

.page-subtitle {
    font-size: 9.5px;
    color: #7790ac;
}

/* Card shell */
.checklist-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 1px 2px rgba(20, 44, 71, 0.03);
}

.checklist-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 16px;
    cursor: pointer;
    user-select: none;
}

.checklist-card .card-header:hover {
    background: #f1f6fb;
}

/* when collapsed, the collapse itself has no visible body, so header keeps its bottom border only while open */
.checklist-card .card-header.collapsed {
    border-bottom-color: #dce5ef;
}

.toggle-icon {
    font-size: 11px;
    color: #17649b;
    transition: transform 0.2s ease;
}

.card-header.collapsed .toggle-icon {
    transform: rotate(-90deg);
}

.group-title {
    font-size: 11px;
    font-weight: 800;
    color: #142c47;
    letter-spacing: 0.3px;
}

.group-count {
    font-size: 9px;
    font-weight: 700;
    color: #17649b;
}

.group-count.partial {
    color: #e5a400;
}

.group-progress-bar {
    width: 120px;
    height: 6px;
    border-radius: 5px;
    background: #edf1f5;
}

.group-progress-bar .progress-bar {
    background: #00b77b;
    border-radius: 5px;
}

.progress-pct {
    font-size: 9px;
    font-weight: 700;
    color: #142c47;
    min-width: 30px;
}

.complete-all-btn {
    border: 1px solid #75dfbc;
    background: #f4fffb;
    color: #00a875;
    font-size: 8.5px;
    font-weight: 700;
    height: 26px;
    padding: 0 10px;
    border-radius: 6px;
}

.complete-all-btn:hover {
    background: #e6fbf3;
    color: #00a875;
}

.icon-btn {
    width: 26px;
    height: 26px;
    border-radius: 6px;
    border: 1px solid #f3c9c9;
    background: #ffffff;
    color: #c04343;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
}

.icon-btn:hover {
    background: #fdf2f2;
    border-color: #f3c9c9;
    color: #d9534f;
}

/* Card body */
.add-item-row {
    background: #fbfcfe;
    border-bottom: 1px solid #edf1f5;
}

.add-item-row .form-control {
    font-size: 9.5px;
    border-color: #dce5ef;
}

.add-item-btn {
    height: 30px;
    padding: 0 14px;
    border-radius: 6px;
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9px;
    font-weight: 700;
    white-space: nowrap;
}

.add-item-btn:hover {
    background: #0f5689;
    color: #ffffff;
}

.checklist-table {
    font-size: 9.5px;
}

.checklist-table thead th {
    font-size: 8.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    border-bottom: 1px solid #edf1f5;
    padding: 10px 16px;
    white-space: nowrap;
}

.checklist-table tbody td {
    padding: 10px 16px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
}

.checklist-table tbody tr:last-child td {
    border-bottom: 0;
}

.item-name {
    font-weight: 700;
    color: #142c47;
}

.item-desc {
    color: #6b8199;
}

.status-select {
    font-size: 8.5px;
    font-weight: 700;
    border-radius: 6px;
    padding: 4px 24px 4px 10px;
    min-width: 110px;
}

.status-completed {
    color: #00a875;
    border-color: #8be7c7;
    background-color: #f4fffb;
}

.status-inprogress {
    color: #e5a400;
    border-color: #f2cf70;
    background-color: #fffdf5;
}

.status-notstarted {
    color: #6b7684;
    border-color: #dbe1e8;
    background-color: #f8f9fb;
}

.empty-state {
    font-size: 9.5px;
}

@media (max-width: 767px) {

    .structure-toolbar {
        flex-direction: column;
        align-items: stretch;
    }

    .structure-search {
        width: 100%;
    }

    .register-btn {
        justify-content: center;
    }

    .structure-bottom {
        flex-direction: column;
        align-items: flex-start;
    }

    .card-actions {
        width: 100%;
    }

}

@media (max-width: 767px) {

    /* Summary cards: tighter padding on small screens */
    .summary-card {
        padding: 14px 12px;
        min-height: auto;
    }


    /* Structure card header: code/title + status badge can wrap */
    .structure-card-header {
        flex-wrap: wrap;
    }

    .structure-card {
        min-height: auto;
        padding: 14px 14px;
    }

    .structure-details {
        gap: 8px;
    }


    /* Checklist Setup section */
    .checklist-setup .d-flex.align-items-start.gap-3 {
        flex-direction: column;
    }

    .setup-header-icon {
        margin-bottom: 4px;
    }

    /* panel heading + hint text stack instead of squeezing side by side */
    .panel-heading-row,
    .checklist-setup .d-flex.justify-content-between.align-items-baseline {
        flex-direction: column;
        align-items: flex-start !important;
    }

    /* custom template row: input + button stack */
    .checklist-setup .d-flex.flex-column.flex-sm-row {
        flex-direction: column;
    }

    .add-custom-btn {
        width: 100%;
        justify-content: center;
    }


    /* Checklist card header (collapsible group header):
       chevron+title / progress+buttons stack instead of overflowing */
    .checklist-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
        padding: 12px 14px;
    }

    .checklist-card .card-header>.d-flex.align-items-center.gap-3 {
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 8px;
    }

    .group-progress {
        display: none !important;
    }

    .complete-all-btn {
        flex: 1;
        justify-content: center;
    }


    /* Add item row already stacks via flex-md-row, just tighten padding */
    .add-item-row {
        padding: 12px !important;
    }


    /* Checklist table: allow horizontal scroll, shrink font slightly */
    .checklist-table {
        font-size: 8.5px;
        min-width: 640px;
    }

    .checklist-table thead th,
    .checklist-table tbody td {
        padding: 8px 10px;
    }

    .status-select {
        min-width: 95px;
    }
}


@media (max-width: 575px) {

    /* Template cards: single column already via row g-2, just tighten */
    .template-card {
        padding: 12px;
    }

    .unit-panel .spec-box {
        padding: 8px;
    }

    /* Register button already handled by your .structure-toolbar rule,
       tighten the search box text a touch */
    .structure-search input {
        font-size: 10px;
    }
}
</style>