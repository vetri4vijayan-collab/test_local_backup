<div class="fuel-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-filled">
                    <i class="bi bi-fuel-pump-fill"></i>
                </div>
                <div class="stat-label">TOTAL HSD DIESEL FILLED</div>
                <div class="stat-value">1,350 <span>Liters</span></div>
                <div class="stat-desc">To-date cumulative site dispatch</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-expenditure">
                    <i class="bi bi-currency-rupee"></i>
                </div>
                <div class="stat-label">AGGREGATE FUEL EXPENDITURE</div>
                <div class="stat-value text-success-custom">₹1,28,250</div>
                <div class="stat-desc">Average Rate: ₹95.25 / Liter</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-vendors">
                    <i class="bi bi-shop"></i>
                </div>
                <div class="stat-label">AUTHORIZED FUEL STATIONS</div>
                <div class="stat-value">2 <span>Vendors</span></div>
                <div class="stat-desc text-success-custom">Contract rate lock active</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: DISPENSARY LOGS -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-journal-text"></i> HSD High Speed Diesel Dispensary Logs
                    </h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export Fuel Receipts
                    </button>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table fuel-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>REFUELING RECEIPT ID</th>
                                    <th>MACHINERY PLANT TARGET</th>
                                    <th class="text-end">REFUELED VOLUME</th>
                                    <th class="text-end">RECEIPT COST</th>
                                    <th>AUTHORIZED OPERATOR</th>
                                    <th>FUEL SUPPLIER</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td><span class="receipt-id">FE-4021</span></td>
                                    <td class="machinery-target">Sany Heavy Crane (150T)</td>
                                    <td class="text-end refueled-volume">400 <span class="unit-text">Liters</span></td>
                                    <td class="text-end receipt-cost">₹38,000</td>
                                    <td class="operator-name">Muthu Pillai</td>
                                    <td class="fuel-supplier">BPCL Fuel Station</td>
                                </tr>

                                <tr>
                                    <td><span class="receipt-id">FE-4022</span></td>
                                    <td class="machinery-target">Schwing Stetter Batching Plant</td>
                                    <td class="text-end refueled-volume">650 <span class="unit-text">Liters</span></td>
                                    <td class="text-end receipt-cost">₹61,750</td>
                                    <td class="operator-name">Sunil Kumar</td>
                                    <td class="fuel-supplier">Shell Commercial</td>
                                </tr>

                                <tr>
                                    <td><span class="receipt-id">FE-4023</span></td>
                                    <td class="machinery-target">Mait HR180 Piling Rig</td>
                                    <td class="text-end refueled-volume">300 <span class="unit-text">Liters</span></td>
                                    <td class="text-end receipt-cost">₹28,500</td>
                                    <td class="operator-name">R. Jagdish</td>
                                    <td class="fuel-supplier">BPCL Fuel Station</td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


        <!-- RIGHT: RECORD FUEL DELIVERY -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">
                        <i class="bi bi-fuel-pump"></i> Record HSD Fuel Delivery
                    </h6>
                    <button type="button" class="btn btn-sm record-fuel-btn d-flex align-items-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#recordFuelModal">
                        <i class="bi bi-plus-lg"></i> Record Fuel Entry
                    </button>
                </div>

                <div class="card-body">

                    <div class="protocol-banner">
                        <div class="protocol-header">
                            <i class="bi bi-shield-check"></i> Fuel Dispensary Protocol
                        </div>
                        <p class="protocol-text mb-0">
                            All fuel dispatches must correspond to machinery running hours. Variance thresholds above 8%
                            trigger IT audit flags.
                        </p>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>

<!-- Record Fuel Entry Modal -->
@include('content.sitelog.manage_project.tabs.modal.fuel-entry')


<style>
.fuel-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #ffffff;
    border: 1px solid #dce5ef;
    border-radius: 12px;
    padding: 18px 16px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
}

.stat-icon.icon-filled {
    background: #eaf2fb;
    color: #17649b;
}

.stat-icon.icon-expenditure {
    background: #e6fbf3;
    color: #00a875;
}

.stat-icon.icon-vendors {
    background: #f2ecfc;
    color: #7a3fd1;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a7bc;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    margin-bottom: 8px;
    padding-right: 40px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #071d35;
    line-height: 1;
    margin-bottom: 8px;
}

.stat-value span {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: #7790ac;
}

.stat-desc {
    font-size: 8.5px;
    color: #7790ac;
}

.text-success-custom {
    color: #00a875 !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 11.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.panel-title i {
    color: #17649b;
    font-size: 14px;
}

.panel-card .card-body {
    padding: 18px;
}


/* Buttons */
.export-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}

.record-fuel-btn {
    background: #17649b;
    border: 0;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.record-fuel-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Fuel table */
.fuel-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.fuel-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 18px;
    white-space: nowrap;
}

.fuel-table tbody td {
    padding: 12px 18px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.fuel-table tbody tr:last-child td {
    border-bottom: 0;
}

.receipt-id {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #17649b;
}

.machinery-target {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
}

.refueled-volume {
    font-weight: 600;
    color: #142c47;
}

.unit-text {
    color: #a4b4c6;
    font-weight: 400;
}

.receipt-cost {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #00a875;
}

.operator-name {
    color: #334e68;
}

.fuel-supplier {
    color: #7891ad;
}


/* Protocol banner */
.protocol-banner {
    background: #e6fbf3;
    border: 1px solid #b8ecd6;
    border-radius: 10px;
    padding: 14px 16px;
}

.protocol-header {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
    font-weight: 800;
    color: #00a875;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 8px;
}

.protocol-header i {
    font-size: 12px;
}

.protocol-text {
    font-size: 9px;
    color: #2f8f6b;
    line-height: 1.6;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 16px 14px;
    }

    .stat-label {
        padding-right: 44px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn,
    .record-fuel-btn {
        justify-content: center;
    }

    .fuel-table {
        min-width: 680px;
    }
}
</style>