<!-- MODAL -->
<div class="modal fade" id="indentRequestModal" tabindex="-1" aria-labelledby="indentRequestModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content indent-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="indentRequestModalLabel">Material Indent Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">SELECT MATERIAL CATALOG</label>
                    <select class="form-select form-select-sm">
                        <option>Cement Grade 53 (OPC)</option>
                        <option>Rebar TMT Steel (16mm)</option>
                        <option>Ready-Mix Concrete M45</option>
                        <option>Prestressed Cables &amp; Tendons</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">QUANTITY REQUIRED</label>
                    <input type="text" class="form-control form-control-sm" placeholder="e.g. 100 Bags">
                </div>

                <div class="mb-0">
                    <label class="form-label">INDENT REQUESTER NAME</label>
                    <input type="text" class="form-control form-control-sm" placeholder="e.g. Er. Dinesh Karthik">
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm dispatch-btn w-100">
                    Dispatch Indent Request
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.indent-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.indent-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.indent-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.indent-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.indent-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.indent-modal .form-control,
.indent-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.indent-modal .form-control::placeholder {
    color: #a4b4c6;
}

.indent-modal .form-control:focus,
.indent-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.indent-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.dispatch-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.dispatch-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>