<div class="modal fade" id="uploadDocumentModal" tabindex="-1" aria-labelledby="uploadDocumentModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="uploadDocumentModalLabel">
                    Upload Document
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <div class="modal-body">

                <div class="upload-dropzone text-center" id="documentDropzone">

                    <div class="upload-icon mb-3">
                        <i class="bi bi-cloud-arrow-up"></i>
                    </div>

                    <h6 class="mb-2">
                        Drag &amp; Drop your technical drawing here
                    </h6>

                    <p class="text-muted mb-3">
                        or click to browse local files (PDF, DWG, BIM)
                    </p>

                    <label for="technicalDocument" class="btn btn-outline-primary">
                        <i class="bi bi-folder2-open me-1"></i>
                        Select Document
                    </label>

                    <input type="file" class="d-none" id="technicalDocument" name="document" accept=".pdf,.dwg,.bim">

                    <div class="selected-file mt-3 d-none" id="selectedFile">
                    </div>

                </div>

                <div class="text-center my-4">
                    <span class="text-muted small fw-semibold">
                        — OR FILL MANUALLY —
                    </span>
                </div>

                <div class="mb-3">
                    <label for="documentName" class="form-label">
                        Document Name
                    </label>

                    <input type="text" class="form-control" id="documentName" name="document_name"
                        placeholder="Enter document name">
                </div>

                <div class="mb-3">
                    <label for="documentCategory" class="form-label">
                        Category
                    </label>

                    <select class="form-select" id="documentCategory" name="category">

                        <option value="" selected disabled>
                            Select category
                        </option>

                        <option value="technical-drawing">
                            Technical Drawing
                        </option>

                        <option value="structural-drawing">
                            Structural Drawing
                        </option>

                        <option value="architectural-drawing">
                            Architectural Drawing
                        </option>

                        <option value="bim">
                            BIM
                        </option>

                        <option value="work-order">
                            Work Order
                        </option>

                        <option value="other">
                            Other
                        </option>

                    </select>
                </div>

            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary">
                    <i class="bi bi-upload me-1"></i>
                    Upload Document
                </button>

            </div>

        </div>
    </div>
</div>
<style>
.upload-dropzone {
    border: 2px dashed #d5d9df;
    border-radius: 10px;
    padding: 35px 20px;
    background: #fafbfc;
    cursor: pointer;
    transition: all 0.2s ease;
}

.upload-dropzone:hover {
    border-color: #0d6efd;
    background: #f5f9ff;
}

.upload-icon {
    font-size: 42px;
    color: #0d6efd;
}

.upload-dropzone h6 {
    font-weight: 600;
}

.selected-file {
    padding: 10px 14px;
    border-radius: 6px;
    background: #eef5ff;
    color: #0d6efd;
    font-size: 14px;
}
</style>