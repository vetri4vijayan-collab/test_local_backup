<div class="modal fade" id="musterShiftModal" tabindex="-1" aria-labelledby="musterShiftModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content muster-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="musterShiftModalLabel">Record Shift Muster Roll</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">CONTRACTOR CREW</label>
                    <select class="form-select form-select-sm">
                        <option>Apex Structural Sub-Contractors</option>
                        <option>Star Bar-Bending &amp; Rebar Works</option>
                        <option>Vanguard Piling &amp; Foundations</option>
                    </select>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label class="form-label">SCHEDULED SHIFT</label>
                        <select class="form-select form-select-sm">
                            <option>Day Shift (08:00 - 17:00)</option>
                            <option>Night Shift (20:00 - 05:00)</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label">OVERTIME (MAN-HRS)</label>
                        <input type="text" class="form-control form-control-sm" value="8">
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-4">
                        <label class="form-label">SKILLED (1K/D)</label>
                        <input type="text" class="form-control form-control-sm" value="20">
                    </div>
                    <div class="col-4">
                        <label class="form-label">SEMI-SKLD (700/D)</label>
                        <input type="text" class="form-control form-control-sm" value="15">
                    </div>
                    <div class="col-4">
                        <label class="form-label">UNSKILLED (500/D)</label>
                        <input type="text" class="form-control form-control-sm" value="25">
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm verify-wages-btn w-100">
                    Verify Wages &amp; Submit Muster
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.muster-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.muster-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.muster-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.muster-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.muster-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.muster-modal .form-control,
.muster-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.muster-modal .form-control:focus,
.muster-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.muster-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.verify-wages-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.verify-wages-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>