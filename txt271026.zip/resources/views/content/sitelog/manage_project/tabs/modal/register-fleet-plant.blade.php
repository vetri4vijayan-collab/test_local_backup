<!-- MODAL -->
<div class="modal fade" id="registerFleetModal" tabindex="-1" aria-labelledby="registerFleetModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content fleet-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="registerFleetModalLabel">Register Fleet Plant</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">MACHINERY MODEL / NAME</label>
                    <input type="text" class="form-control form-control-sm"
                        placeholder="e.g. Caterpillar Excavator 320D">
                </div>

                <div class="mb-3">
                    <label class="form-label">HEAVY PLANT OPERATOR IN-CHARGE</label>
                    <input type="text" class="form-control form-control-sm" placeholder="e.g. Gurmail Singh">
                </div>

                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label">PLANT CATEGORY</label>
                        <select class="form-select form-select-sm">
                            <option>Lifting Crane</option>
                            <option>Piling Rig</option>
                            <option>Batching Plant</option>
                            <option>Concrete Boom Placer</option>
                            <option>Excavator</option>
                        </select>
                    </div>

                    <div class="col-6">
                        <label class="form-label">NEXT SERVICE DATE</label>
                        <input type="date" class="form-control form-control-sm" value="2026-08-30">
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm deploy-btn w-100">
                    Deploy and Verify Operator
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.fleet-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.fleet-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.fleet-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.fleet-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.fleet-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.fleet-modal .form-control,
.fleet-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.fleet-modal .form-control::placeholder {
    color: #a4b4c6;
}

.fleet-modal .form-control:focus,
.fleet-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.fleet-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.deploy-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.deploy-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>