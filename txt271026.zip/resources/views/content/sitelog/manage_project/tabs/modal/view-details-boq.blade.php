<!-- MODAL -->
<div class="modal fade" id="boqModal" tabindex="-1" aria-labelledby="boqModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content boq-modal">

            <div class="modal-header">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-stack boq-header-icon"></i>
                    <h5 class="modal-title mb-0" id="boqModalLabel">Itemized Structure Breakdown (BOQ)</h5>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="ref-doc-badge">Ref Doc: N/A (Standard Issue)</span>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>

            <div class="modal-body p-0">
                <div class="table-responsive">
                    <table class="table boq-table mb-0 align-middle">
                        <thead>
                            <tr>
                                <th style="width: 60px;">SR. NO</th>
                                <th>STRUCTURE / BOQ ITEM</th>
                                <th>DESCRIPTION</th>
                                <th class="text-nowrap">UNIT</th>
                                <th class="text-end">TENTATIVE QUANTITY</th>
                                <th class="text-end">RATE (₹)</th>
                                <th class="text-end">AMOUNT (₹)</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr class="boq-section-row">
                                <td>1</td>
                                <td colspan="6" class="boq-section-name">Piling &amp; Deep Foundations</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Piling Excavation (25m depth)</td>
                                <td class="boq-item-desc">Bored cast-in-situ piling using bentonite slurry</td>
                                <td>CuM</td>
                                <td class="text-end">1,200</td>
                                <td class="text-end">₹ 25,000</td>
                                <td class="text-end boq-amount">₹ 3,00,00,000</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Reinforcing Steel Cage Fabrication</td>
                                <td class="boq-item-desc">Fe 550D TMT reinforcement steel bars</td>
                                <td>MT</td>
                                <td class="text-end">180</td>
                                <td class="text-end">₹ 65,000</td>
                                <td class="text-end boq-amount">₹ 1,17,00,000</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Piling Concrete Pouring</td>
                                <td class="boq-item-desc">M35 Grade high-slump tremie concrete</td>
                                <td>CuM</td>
                                <td class="text-end">1,200</td>
                                <td class="text-end">₹ 7,500</td>
                                <td class="text-end boq-amount">₹ 90,00,000</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Sonic Integrity Testing</td>
                                <td class="boq-item-desc">Cross-hole sonic logging tests on piles</td>
                                <td>Nos.</td>
                                <td class="text-end">12</td>
                                <td class="text-end">₹ 1,50,000</td>
                                <td class="text-end boq-amount">₹ 18,00,000</td>
                            </tr>

                            <tr class="boq-section-row">
                                <td>2</td>
                                <td colspan="6" class="boq-section-name">Substructure &amp; Piers</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Pile Cap Concrete</td>
                                <td class="boq-item-desc">M40 Grade structural concrete</td>
                                <td>CuM</td>
                                <td class="text-end">850</td>
                                <td class="text-end">₹ 8,200</td>
                                <td class="text-end boq-amount">₹ 69,70,000</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Pier Pedestal Fabrication</td>
                                <td class="boq-item-desc">Reinforcing steel and template alignment</td>
                                <td>MT</td>
                                <td class="text-end">95</td>
                                <td class="text-end">₹ 68,000</td>
                                <td class="text-end boq-amount">₹ 64,60,000</td>
                            </tr>

                            <tr>
                                <td class="text-muted">–</td>
                                <td class="boq-item-name">Pier Column Casting</td>
                                <td class="boq-item-desc">M45 Grade self-compacting concrete</td>
                                <td>CuM</td>
                                <td class="text-end">600</td>
                                <td class="text-end">₹ 9,000</td>
                                <td class="text-end boq-amount">₹ 54,00,000</td>
                            </tr>

                        </tbody>
                        <tfoot>
                            <tr class="boq-grand-total-row">
                                <td colspan="6" class="text-end">GRAND TOTAL BOQ VALUE</td>
                                <td class="text-end boq-grand-total-amount">₹ 7,13,30,000</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm cancel-btn" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm print-boq-btn d-flex align-items-center gap-1">
                    <i class="bi bi-printer"></i> Print BOQ
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.boq-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.boq-modal .modal-header {
    padding: 14px 20px;
    border-bottom: 1px solid #edf1f5;
    background: #f8fafc;
}

.boq-header-icon {
    font-size: 15px;
    color: #17649b;
}

.boq-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.3px;
}

.ref-doc-badge {
    font-size: 8px;
    font-weight: 600;
    color: #7790ac;
    background: #ffffff;
    border: 1px solid #dce5ef;
    border-radius: 5px;
    padding: 4px 10px;
    white-space: nowrap;
}

.boq-modal .modal-body {
    background: #ffffff;
}

/* Table */
.boq-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.boq-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 16px;
    white-space: nowrap;
    position: sticky;
    top: 0;
    z-index: 1;
}

.boq-table tbody td,
.boq-table tfoot td {
    padding: 10px 16px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.boq-section-row td {
    background: #f8fafc;
    font-weight: 800;
    color: #142c47;
    border-bottom: 1px solid #edf1f5;
}

.boq-section-name {
    font-family: 'Urbanist', sans-serif;
    font-size: 10px;
    font-weight: 800;
    color: #142c47;
}

.boq-item-name {
    font-weight: 700;
    color: #142c47;
}

.boq-item-desc {
    font-style: italic;
    color: #5a7fb8;
}

.boq-amount {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #142c47;
}

.boq-grand-total-row td {
    background: #eaf2fb;
    font-family: 'Urbanist', sans-serif;
    font-weight: 800;
    font-size: 10.5px;
    color: #071d35;
    border-top: 2px solid #17649b;
    border-bottom: 0;
}

.boq-grand-total-amount {
    color: #17649b;
}

/* Footer */
.boq-modal .modal-footer {
    padding: 12px 20px;
    border-top: 1px solid #edf1f5;
}

.print-boq-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9px;
    font-weight: 700;
    padding: 6px 16px;
    border-radius: 6px;
}

.print-boq-btn:hover {
    background: #0f5689;
    color: #ffffff;
}

@media (max-width: 767px) {

    /* Modal header: icon+title vs badge+close button stack */
    .boq-modal .modal-header {
        gap: 10px;
        padding: 12px 14px;
    }

    .boq-modal .modal-header>.d-flex.align-items-center.gap-2:first-child {
        width: 100%;
    }

    .boq-modal .modal-title {
        font-size: 11px;
    }

    .ref-doc-badge {
        font-size: 7.5px;
        padding: 4px 8px;
    }

    .boq-header-icon {
        font-size: 13px;
    }


    /* Table: enforce min-width so table-responsive scrolls
       horizontally instead of squashing columns unreadably */
    .boq-table {
        min-width: 720px;
        font-size: 9px;
    }

    .boq-table thead th,
    .boq-table tbody td,
    .boq-table tfoot td {
        padding: 8px 10px;
    }

    .boq-section-name {
        font-size: 9px;
    }

    .boq-grand-total-row td {
        font-size: 9.5px;
    }


    /* Footer: Close + Print buttons go full-width side-by-side */
    .boq-modal .modal-footer {
        padding: 10px 14px;
    }

    .boq-modal .modal-footer .btn {
        flex: 1;
        justify-content: center;
    }
}


@media (max-width: 768px) {

    /* On very small phones, stack footer buttons fully */
    .boq-modal .modal-footer {
        flex-direction: column-reverse;
        gap: 8px;
    }

    .boq-modal .modal-footer .btn {
        width: 100%;
    }

    .cancel-btn,
    .print-boq-btn {
        margin: 0 !important;
    }

    .modal-content .modal-header .modal-title {
        font-size: 0.7rem;
    }
}
</style>