<div class="modal fade" id="newStructureModal" tabindex="-1" aria-labelledby="newStructureModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content structure-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="newStructureModalLabel">New Structural Unit Specification</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="newStructureForm">
                    <div class="row g-3">

                        <div class="col-6">
                            <label for="structureName" class="form-label">STRUCTURE NAME</label>
                            <input type="text" class="form-control form-control-sm" id="structureName"
                                placeholder="e.g. Pier P43 Pillar">
                        </div>

                        <div class="col-6">
                            <label for="structureCode" class="form-label">STRUCTURE CODE</label>
                            <input type="text" class="form-control form-control-sm" id="structureCode"
                                placeholder="e.g. P43-C1">
                        </div>

                        <div class="col-6">
                            <label for="structureType" class="form-label">TYPE</label>
                            <select class="form-select form-select-sm" id="structureType">
                                <option>Pillar / Pier</option>
                                <option>Pier Cap</option>
                                <option>Girder</option>
                                <option>Foundation</option>
                                <option>Abutment</option>
                                <option>Slab Deck</option>
                                <option>Pipe Culvert</option>
                            </select>
                        </div>

                        <div class="col-6">
                            <label for="concreteGrade" class="form-label">CONCRETE GRADE</label>
                            <select class="form-select form-select-sm" id="concreteGrade">
                                <option>M50 Grade</option>
                                <option>M40 Grade</option>
                                <option>M55 Grade</option>
                                <option>M60 Grade</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <label for="targetVolume" class="form-label">TARGET VOLUME (CU.M)</label>
                            <input type="number" class="form-control form-control-sm" id="targetVolume"
                                placeholder="100">
                        </div>

                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm cancel-btn" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm add-structure-btn" id="addStructureBtn">Add Structure</button>
            </div>

        </div>
    </div>
</div>
<style>
.structure-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.structure-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.structure-modal .modal-title {
    font-size: 13px;
    font-weight: 900;
    color: #071d35;
    letter-spacing: 0.2px;
}

.structure-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.structure-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.structure-modal .form-control,
.structure-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.structure-modal .form-control::placeholder {
    color: #a4b4c6;
}

.structure-modal .form-control:focus,
.structure-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.structure-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.cancel-btn {
    border: 1px solid #dce5ef;
    background: #ffffff;
    color: #334e68;
    font-size: 9px;
    font-weight: 700;
    padding: 6px 16px;
    border-radius: 6px;
}

.cancel-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}

.add-structure-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9px;
    font-weight: 700;
    padding: 6px 18px;
    border-radius: 6px;
}

.add-structure-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>


<script>
document.getElementById('addStructureBtn').addEventListener('click', function() {
    var payload = {
        name: document.getElementById('structureName').value,
        code: document.getElementById('structureCode').value,
        type: document.getElementById('structureType').value,
        grade: document.getElementById('concreteGrade').value,
        targetVolume: document.getElementById('targetVolume').value
    };

    // hook your actual "create structure" logic here, e.g.:
    // createStructureUnit(payload);
    console.log('New structure payload:', payload);

    var modalEl = document.getElementById('newStructureModal');
    var modalInstance = bootstrap.Modal.getInstance(modalEl);
    if (modalInstance) modalInstance.hide();
});
</script>