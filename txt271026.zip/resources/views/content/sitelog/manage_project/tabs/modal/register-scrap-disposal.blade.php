<div class="modal fade" id="registerScrapModal" tabindex="-1" aria-labelledby="registerScrapModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content scrap-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="registerScrapModalLabel">Register Scrap Disposal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">SCRAP MATERIAL DESCRIPTION</label>
                    <input type="text" class="form-control form-control-sm"
                        placeholder="e.g. Cut pieces of structural H-beams">
                </div>

                <div class="mb-3">
                    <label class="form-label">BUYER/RECYCLING AGENCY</label>
                    <select class="form-select form-select-sm">
                        <option>Maruthi Steel Recyclers</option>
                        <option>Local Brick Kiln Fuel Co.</option>
                        <option>Pending Disposal</option>
                    </select>
                </div>

                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label">QUANTITY (TONS/KGS)</label>
                        <input type="text" class="form-control form-control-sm" value="1.2 Tons">
                    </div>
                    <div class="col-6">
                        <label class="form-label">SALE REVENUE (₹)</label>
                        <input type="text" class="form-control form-control-sm" value="24000">
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm verify-sale-btn w-100">
                    Verify Sale &amp; Log Credits
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.scrap-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.scrap-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.scrap-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.scrap-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.scrap-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.scrap-modal .form-control,
.scrap-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.scrap-modal .form-control:focus,
.scrap-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.scrap-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.verify-sale-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.verify-sale-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>