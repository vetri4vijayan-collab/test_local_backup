<div class="modal fade" id="addRiskModal" tabindex="-1" aria-labelledby="addRiskModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="addRiskModalLabel">
                    Add Risk
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label for="riskTitle" class="form-label">
                        Risk Title/Event
                    </label>

                    <input type="text" class="form-control" id="riskTitle" name="risk_title"
                        placeholder="Enter risk title or event">
                </div>

                <div class="row g-3">

                    <div class="col-md-6">
                        <label for="severityImpact" class="form-label">
                            Severity Impact
                        </label>

                        <select class="form-select" id="severityImpact" name="severity_impact">

                            <option value="" selected disabled>
                                Select severity
                            </option>

                            <option value="low">
                                Low
                            </option>

                            <option value="medium">
                                Medium
                            </option>

                            <option value="high">
                                High
                            </option>

                            <option value="critical">
                                Critical
                            </option>

                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="probability" class="form-label">
                            Probability
                        </label>

                        <select class="form-select" id="probability" name="probability">

                            <option value="" selected disabled>
                                Select probability
                            </option>

                            <option value="rare">
                                Rare
                            </option>

                            <option value="unlikely">
                                Unlikely
                            </option>

                            <option value="possible">
                                Possible
                            </option>

                            <option value="likely">
                                Likely
                            </option>

                            <option value="almost-certain">
                                Almost Certain
                            </option>

                        </select>
                    </div>

                </div>

                <div class="mt-3">
                    <label for="mitigationPlan" class="form-label">
                        Proposed Mitigation Plan
                    </label>

                    <textarea class="form-control" id="mitigationPlan" name="mitigation_plan" rows="4"
                        placeholder="Enter proposed mitigation plan"></textarea>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary">
                    Add Risk
                </button>
            </div>

        </div>
    </div>
</div>