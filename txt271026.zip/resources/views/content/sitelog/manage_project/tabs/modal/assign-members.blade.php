<div class="modal fade" id="assignMemberModal" tabindex="-1" aria-labelledby="assignMemberModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="assignMemberModalLabel">
                    Assign Member
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label for="fullName" class="form-label">
                        Full Name
                    </label>

                    <input type="text" class="form-control" id="fullName" name="full_name"
                        placeholder="Enter full name">
                </div>

                <div class="mb-3">
                    <label for="designatedRole" class="form-label">
                        Designated Role
                    </label>

                    <select class="form-select" id="designatedRole" name="designated_role">
                        <option value="" selected disabled>Select designated role</option>
                        <option value="project-manager">Project Manager</option>
                        <option value="site-engineer">Site Engineer</option>
                        <option value="qs-engineer">QS Engineer</option>
                        <option value="site-supervisor">Site Supervisor</option>
                        <option value="safety-officer">Safety Officer</option>
                        <option value="store-manager">Store Manager</option>
                        <option value="accountant">Accountant</option>
                    </select>
                </div>
                <div class="row">
                    <div class="mb-3 col-6">
                        <label for="email" class="form-label">
                            Email
                        </label>

                        <input type="email" class="form-control" id="email" name="email"
                            placeholder="Enter email address">
                    </div>

                    <div class="mb-3 col-6">
                        <label for="phone" class="form-label">
                            Phone
                        </label>

                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter phone number">
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" class="btn btn-primary">
                    Assign Member
                </button>
            </div>

        </div>
    </div>
</div>