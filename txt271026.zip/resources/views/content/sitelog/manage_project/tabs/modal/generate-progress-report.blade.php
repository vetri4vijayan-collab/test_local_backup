<div class="modal fade" id="generateReportModal" tabindex="-1" aria-labelledby="generateReportModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content report-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="generateReportModalLabel">Generate Progress Report</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">REPORT DESIGNATION NAME</label>
                    <input type="text" class="form-control form-control-sm"
                        placeholder="e.g. June Slab Casting Progress & Testing Report">
                </div>

                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label">BILLING PERIOD</label>
                        <input type="text" class="form-control form-control-sm" value="July 2026">
                    </div>
                    <div class="col-6">
                        <label class="form-label">INVOICE VALUE (₹)</label>
                        <input type="text" class="form-control form-control-sm" value="12000000">
                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm verify-dispatch-btn w-100">
                    <i class="bi bi-check2-circle"></i> Verify Measurements &amp; Dispatch
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.report-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.report-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.report-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.report-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.report-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.report-modal .form-control {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.report-modal .form-control:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.report-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.verify-dispatch-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.verify-dispatch-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>