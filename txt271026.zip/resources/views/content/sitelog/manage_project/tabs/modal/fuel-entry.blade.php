<!-- MODAL -->
<div class="modal fade" id="recordFuelModal" tabindex="-1" aria-labelledby="recordFuelModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content fuel-modal">

            <div class="modal-header">
                <h5 class="modal-title" id="recordFuelModalLabel">Record HSD Fuel Delivery</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label class="form-label">SELECT MACHINERY PLANT</label>
                    <select class="form-select form-select-sm">
                        <option>Sany Heavy Crane (150T)</option>
                        <option>Mait HR180 Piling Rig</option>
                        <option>Schwing Stetter Batching Plant</option>
                        <option>Concrete Boom Placer 36M</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">AUTHORIZING DRIVER / OPERATOR</label>
                    <input type="text" class="form-control form-control-sm" placeholder="e.g. Muthu Pillai">
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label class="form-label">VOLUME (LITERS)</label>
                        <input type="text" class="form-control form-control-sm" value="150 Liters">
                    </div>
                    <div class="col-6">
                        <label class="form-label">RATE (₹ / LITER)</label>
                        <input type="text" class="form-control form-control-sm" value="95">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">AUTHORIZED FUEL SUPPLIER</label>
                    <select class="form-select form-select-sm">
                        <option>BPCL Fuel Station</option>
                        <option>Shell Commercial</option>
                    </select>
                </div>

                <div class="total-cost-row d-flex justify-content-end align-items-center">
                    <span class="total-cost-label">Total Cost:</span>
                    <span class="total-cost-value">₹14,250</span>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm verify-log-btn w-100">
                    Verify &amp; Log dispensary Receipt
                </button>
            </div>

        </div>
    </div>
</div>


<style>
.fuel-modal {
    font-family: 'Inter', sans-serif;
    border-radius: 12px;
    border: 1px solid #dce5ef;
}

.fuel-modal .modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #edf1f5;
}

.fuel-modal .modal-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 12.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.fuel-modal .modal-body {
    padding: 20px;
    background: #fbfcfe;
}

.fuel-modal .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.fuel-modal .form-control,
.fuel-modal .form-select {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
    height: 34px;
}

.fuel-modal .form-control::placeholder {
    color: #a4b4c6;
}

.fuel-modal .form-control:focus,
.fuel-modal .form-select:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.total-cost-row {
    background: #f1f6fb;
    border: 1px solid #dce5ef;
    border-radius: 8px;
    padding: 10px 14px;
    gap: 8px;
}

.total-cost-label {
    font-size: 9px;
    font-weight: 700;
    color: #334e68;
}

.total-cost-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 12px;
    font-weight: 800;
    color: #17649b;
}

.fuel-modal .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid #edf1f5;
}

.verify-log-btn {
    border: 0;
    background: #17649b;
    color: #ffffff;
    font-size: 9.5px;
    font-weight: 700;
    padding: 9px 18px;
    border-radius: 6px;
}

.verify-log-btn:hover {
    background: #0f5689;
    color: #ffffff;
}
</style>