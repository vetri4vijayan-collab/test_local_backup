<div class="scrap-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-label">RECYCLED/SOLD METAL SCRAP</div>
                <div class="stat-value">15.7 <span>Tons</span></div>
                <div class="stat-desc">Primarily cut-piece steel reinforcement</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-label">GENERATED REVENUE TO SITE</div>
                <div class="stat-value text-success-custom">₹6,68,500</div>
                <div class="stat-desc">Credited to general project account</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-label">PENDING CLEARANCE</div>
                <div class="stat-value text-warning-custom">2.8 <span>Tons</span></div>
                <div class="stat-desc">Corrugated utility pipe joints</div>
            </div>
        </div>

    </div>


    <div class="row g-3">

        <!-- LEFT: SCRAP DISPOSAL & BUYER LEDGER -->
        <div class="col-lg-8">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">SITE SCRAP DISPOSAL &amp; BUYER LEDGER</h6>
                    <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                        <i class="bi bi-download"></i> Export scrap logs
                    </button>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table scrap-table mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th>SCRAP ITEM DESCRIPTION</th>
                                    <th class="text-end">QUANTITY</th>
                                    <th>REGISTERED BUYER NAME</th>
                                    <th class="text-end">REVENUE GENERATED</th>
                                    <th class="text-end">DISPOSAL STATUS</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <div class="item-name">Cut-piece TMT Reinforcement Steel</div>
                                        <div class="item-meta">ID: SCR-1 &bull; Date: 2026-07-10</div>
                                    </td>
                                    <td class="text-end qty-value">14.5 <span class="unit-text">Tons</span></td>
                                    <td class="buyer-name">Maruthi Steel Recyclers</td>
                                    <td class="text-end revenue-value">₹6,52,500</td>
                                    <td class="text-end">
                                        <span class="status-pill status-collected">SOLD &amp; COLLECTED</span>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="item-name">Damaged Corrugated Utility Sleeves</div>
                                        <div class="item-meta">ID: SCR-2 &bull; Date: 2026-07-22</div>
                                    </td>
                                    <td class="text-end qty-value">2.8 <span class="unit-text">Tons</span></td>
                                    <td class="buyer-name">Pending Disposal</td>
                                    <td class="text-end revenue-value">&mdash;</td>
                                    <td class="text-end">
                                        <span class="status-pill status-pending">PENDING CLEARANCE</span>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <div class="item-name">Used Plywood Formwork Shuttering Sheets</div>
                                        <div class="item-meta">ID: SCR-3 &bull; Date: 2026-07-18</div>
                                    </td>
                                    <td class="text-end qty-value">80 <span class="unit-text">Pcs</span></td>
                                    <td class="buyer-name">Local Brick Kiln Fuel Co.</td>
                                    <td class="text-end revenue-value">₹16,000</td>
                                    <td class="text-end">
                                        <span class="status-pill status-collected">SOLD &amp; COLLECTED</span>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>


        <!-- RIGHT: REGISTER SCRAP DISPOSAL -->
        <div class="col-lg-4">
            <div class="card panel-card h-100">

                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <h6 class="mb-0 panel-title">REGISTER SCRAP DISPOSAL</h6>
                    <a href="javascript:void(0)" class="record-sale-link" data-bs-toggle="modal"
                        data-bs-target="#registerScrapModal">
                        [ + Record scrap sale ]
                    </a>
                </div>

                <div class="card-body">

                    <div class="compliance-banner">
                        <div class="compliance-header">RECYCLING COMPLIANCE</div>
                        <p class="compliance-text mb-0">
                            All steel scrap must be weighed at certified weighbridges. Submit receipts to the site QS
                            quantity surveyor for reconciliation.
                        </p>
                    </div>

                </div>

            </div>
        </div>

    </div>

</div>
<!-- Modal Register Srap Disposal-->
@include('content.sitelog.manage_project.tabs.modal.register-scrap-disposal')

<style>
.scrap-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 18px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1;
    margin-bottom: 6px;
}

.stat-value span {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
}

.stat-desc {
    font-size: 8.5px;
    color: #64748b;
}

.text-success-custom {
    color: #16a34a !important;
}

.text-warning-custom {
    color: #d97706 !important;
}


/* Panel cards */
.panel-card {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 10.5px;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: 0.4px;
}

.panel-card .card-body {
    padding: 18px;
}

.record-sale-link {
    font-size: 9px;
    font-weight: 700;
    color: #2563eb;
    text-decoration: none;
    white-space: nowrap;
}

.record-sale-link:hover {
    color: #1d4ed8;
    text-decoration: underline;
}


/* Buttons */
.export-btn {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    color: #334155;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f8fafc;
    color: #334155;
}


/* Scrap table */
.scrap-table {
    font-size: 9.5px;
    margin-bottom: 0;
}

.scrap-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a3b8;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    padding: 10px 18px;
    white-space: nowrap;
}

.scrap-table tbody td {
    padding: 12px 18px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
    color: #334155;
}

.scrap-table tbody tr:last-child td {
    border-bottom: 0;
}

.item-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #0f172a;
    font-size: 10px;
    margin-bottom: 2px;
}

.item-meta {
    font-size: 7.5px;
    color: #94a3b8;
}

.qty-value {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #0f172a;
}

.unit-text {
    color: #94a3b8;
    font-weight: 400;
}

.buyer-name {
    color: #2563eb;
    font-weight: 600;
}

.revenue-value {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #16a34a;
}

.status-pill {
    display: inline-block;
    font-size: 7.5px;
    font-weight: 700;
    letter-spacing: 0.2px;
    padding: 4px 10px;
    border-radius: 20px;
    white-space: nowrap;
}

.status-collected {
    background: #dcfce7;
    color: #15803d;
}

.status-pending {
    background: #fef3c7;
    color: #b45309;
}


/* Compliance banner */
.compliance-banner {
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 10px;
    padding: 14px 16px;
}

.compliance-header {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
    font-weight: 800;
    color: #b45309;
    margin-bottom: 6px;
}

.compliance-text {
    font-size: 9px;
    color: #92400e;
    line-height: 1.6;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 14px 16px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn {
        justify-content: center;
    }

    .scrap-table {
        min-width: 650px;
    }
}
</style>