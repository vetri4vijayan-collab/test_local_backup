@extends('layouts/contentNavbarLayout')

@section('title', 'Manage Project')

@section('content')
<div class="container-fluid">

    <div class="wo-form-wrapper">

        <!-- PAGE HEADER -->
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
            <div class="d-flex align-items-center gap-2">
                <div class="page-header-icon"><i class="bi bi-file-earmark-plus"></i></div>
                <div>
                    <h5 class="mb-0 page-heading">Create Client Work Order</h5>
                    <span class="page-subheading">Chennai Metro Phase 2 – Corridor 4 (PRJ-CMRL-04)</span>
                </div>
            </div>
            <a href="{{ route('sitelog.manage_project.view', ['tab' => 'client-work-order']) }}"
                class="btn btn-sm back-to-list-btn d-flex align-items-center gap-1">
                <i class="bi bi-arrow-left"></i> Back to Work Orders
            </a>
        </div>


        <!-- BASIC DETAILS CARD -->
        <div class="card wo-form-card mb-3">
            <div class="card-header d-flex align-items-center gap-2">
                <i class="bi bi-1-circle-fill step-icon"></i>
                <h6 class="mb-0">Work Order Basic Details</h6>
            </div>

            <div class="card-body">

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label">WORK ORDER NO <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm" placeholder="Enter Work Order No">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">WORK ORDER DATE <span class="text-danger">*</span></label>
                        <input type="date" class="form-control form-control-sm" value="{{ date('Y-m-d') }}">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">REF DOC</label>
                        <div class="d-flex align-items-center gap-2">
                            <label class="btn btn-sm choose-file-btn mb-0" for="refDocInput">Choose File</label>
                            <span class="file-chosen-text" id="refDocFileName">No file chosen</span>
                            <input type="file" id="refDocInput" class="d-none"
                                accept=".png,.jpg,.jpeg,.xls,.pdf,.doc,.docx">
                        </div>
                        <div class="file-hint mt-1">Allowed file types: png, jpg, jpeg, xls, pdf, doc, docx</div>
                    </div>
                </div>

                <hr class="wo-form-divider">

                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">CONTRACT TITLE</label>
                        <input type="text" class="form-control form-control-sm"
                            placeholder="e.g. Underground Drainage Contract">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">CLIENT SIGNATORY / DESIGNEE</label>
                        <input type="text" class="form-control form-control-sm"
                            placeholder="e.g. Er. Rajesh Gopal (CMRL)">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">GENERAL SCOPE / REMARKS SUMMARY</label>
                        <input type="text" class="form-control form-control-sm"
                            placeholder="e.g. Trenching, drainage system, and pipe laying works">
                    </div>
                </div>

            </div>
        </div>


        <!-- BOQ CARD -->
        <div class="card wo-form-card mb-3">

            <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-2-circle-fill step-icon"></i>
                    <h6 class="mb-0">Work Order BOQ / Itemized Structures</h6>
                </div>
                <span class="link-active-badge">
                    <i class="bi bi-check-circle-fill"></i> Project Structure Checklist Link Active
                </span>
            </div>

            <div class="card-body p-0">

                <!-- TAB SWITCHER: Project Checklist vs Standard Demo -->
                <ul class="nav nav-tabs boq-source-tabs px-3 pt-3" id="boqSourceTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="project-checklist-tab" data-bs-toggle="tab"
                            data-bs-target="#projectChecklistPane" type="button" role="tab"
                            aria-controls="projectChecklistPane" aria-selected="true">
                            <i class="bi bi-stack"></i> Project Checklist
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="standard-demo-tab" data-bs-toggle="tab"
                            data-bs-target="#standardDemoPane" type="button" role="tab" aria-controls="standardDemoPane"
                            aria-selected="false">
                            <i class="bi bi-magic"></i> Standard Demo
                        </button>
                    </li>
                </ul>

                <div class="boq-source-hint px-3 py-2">
                    <i class="bi bi-info-circle"></i>
                    <span id="boqSourceHintText">Item names and specification descriptions are synced directly with
                        <strong>4 structure units</strong> mapped to this project.</span>
                </div>

                <div class="tab-content" id="boqSourceTabContent">

                    <!-- PROJECT CHECKLIST TAB -->
                    <div class="tab-pane fade show active" id="projectChecklistPane" role="tabpanel"
                        aria-labelledby="project-checklist-tab">
                        <div class="table-responsive">
                            <table class="table boq-form-table mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th style="width: 55px;">SR. NO</th>
                                        <th>STRUCTURE / WORK ITEM</th>
                                        <th>DESCRIPTION</th>
                                        <th class="text-nowrap">UNIT</th>
                                        <th class="text-nowrap">TENTATIVE QUANTITY</th>
                                        <th class="text-nowrap">RATE</th>
                                        <th class="text-nowrap">AMOUNT (₹)</th>
                                        <th>REMARKS</th>
                                        <th style="width: 40px;"></th>
                                    </tr>
                                </thead>
                                <tbody id="projectChecklistBody">

                                    <tr class="boq-category-row" data-category="1">
                                        <td>1</td>
                                        <td colspan="7"><strong>Pier P41 Pillar (Pier Structure)</strong></td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="1">+ ADD ITEM</button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Excavation</td>
                                        <td class="item-desc-cell">Excavating soil to required depth</td>
                                        <td>CuM</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">PCC Bedding</td>
                                        <td class="item-desc-cell">Laying plain cement concrete</td>
                                        <td>CuM</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Rebar Caging &amp; Binding</td>
                                        <td class="item-desc-cell">Fabricating steel reinforcement</td>
                                        <td>MT</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Formwork Erection</td>
                                        <td class="item-desc-cell">Assembling and aligning shuttering</td>
                                        <td>Rmt.</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>


                                    <tr class="boq-category-row" data-category="2">
                                        <td>2</td>
                                        <td colspan="7"><strong>Pier P42 Pier Cap (Pier Structure)</strong></td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="2">+ ADD ITEM</button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="2">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Formwork Stripping</td>
                                        <td class="item-desc-cell">Stripping side shutters</td>
                                        <td>Rmt.</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>


                                    <tr class="boq-category-row" data-category="3">
                                        <td>3</td>
                                        <td colspan="7"><strong>Segment S12 Box Girder (Prestressed Girder)</strong>
                                        </td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="3">+ ADD ITEM</button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="3">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Steam Curing</td>
                                        <td class="item-desc-cell">Accelerated steam curing process</td>
                                        <td>Rmt.</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="150"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="2500"></td>
                                        <td class="text-end amount-cell">3,75,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>


                                    <tr class="boq-category-row" data-category="4">
                                        <td>4</td>
                                        <td colspan="7"><strong>Abutment A1 Foundation (Bridge Abutment)</strong></td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="4">+ ADD ITEM</button></td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>

                        <div
                            class="boq-footer-bar d-flex flex-column flex-md-row justify-content-between align-items-stretch align-items-md-center gap-2 px-3 py-3">
                            <div class="d-flex flex-column flex-sm-row gap-2 flex-grow-1">
                                <input type="text" class="form-control form-control-sm new-category-input"
                                    placeholder="Add new structure/category name (e.g. Tunnel Portal)">
                                <button type="button" class="btn btn-sm add-category-btn flex-shrink-0">
                                    <i class="bi bi-plus-lg"></i> Add Structure Category
                                </button>
                            </div>
                            <div class="cumulative-total text-md-end">
                                <div class="cumulative-label">CUMULATIVE FORM TOTAL</div>
                                <div class="cumulative-value">₹ <span class="cumulative-amount">37,50,000</span></div>
                            </div>
                        </div>
                    </div>


                    <!-- STANDARD DEMO TAB -->
                    <div class="tab-pane fade" id="standardDemoPane" role="tabpanel"
                        aria-labelledby="standard-demo-tab">
                        <div class="table-responsive">
                            <table class="table boq-form-table mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th style="width: 55px;">SR. NO</th>
                                        <th>STRUCTURE / WORK ITEM</th>
                                        <th>DESCRIPTION</th>
                                        <th class="text-nowrap">UNIT</th>
                                        <th class="text-nowrap">TENTATIVE QUANTITY</th>
                                        <th class="text-nowrap">RATE</th>
                                        <th class="text-nowrap">AMOUNT (₹)</th>
                                        <th>REMARKS</th>
                                        <th style="width: 40px;"></th>
                                    </tr>
                                </thead>
                                <tbody id="standardDemoBody">

                                    <tr class="boq-category-row" data-category="1">
                                        <td>1</td>
                                        <td colspan="7"><strong>Standard RCC Foundation</strong></td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="1">+ ADD ITEM</button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Earthwork Excavation</td>
                                        <td class="item-desc-cell">General excavation for footing</td>
                                        <td>CuM</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="100"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="1200"></td>
                                        <td class="text-end amount-cell">1,20,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="1">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">PCC Levelling Course</td>
                                        <td class="item-desc-cell">Plain cement concrete base layer</td>
                                        <td>CuM</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="60"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="4800"></td>
                                        <td class="text-end amount-cell">2,88,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-category-row" data-category="2">
                                        <td>2</td>
                                        <td colspan="7"><strong>Standard RCC Column</strong></td>
                                        <td class="text-end"><button type="button" class="add-item-inline-btn"
                                                data-category="2">+ ADD ITEM</button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="2">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Column Reinforcement</td>
                                        <td class="item-desc-cell">Standard Fe500 TMT bars</td>
                                        <td>MT</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="12"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="62000"></td>
                                        <td class="text-end amount-cell">7,44,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                    <tr class="boq-item-row" data-category="2">
                                        <td class="text-muted">–</td>
                                        <td class="item-name-cell">Column Concreting</td>
                                        <td class="item-desc-cell">M40 grade structural concrete</td>
                                        <td>CuM</td>
                                        <td><input type="number" class="form-control form-control-sm qty-input"
                                                value="40"></td>
                                        <td><input type="number" class="form-control form-control-sm rate-input"
                                                value="8200"></td>
                                        <td class="text-end amount-cell">3,28,000</td>
                                        <td><input type="text" class="form-control form-control-sm remarks-input"
                                                placeholder="Remarks"></td>
                                        <td class="text-end"><button type="button" class="row-delete-btn"><i
                                                    class="bi bi-trash"></i></button></td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>

                        <div
                            class="boq-footer-bar d-flex flex-column flex-md-row justify-content-between align-items-stretch align-items-md-center gap-2 px-3 py-3">
                            <div class="d-flex flex-column flex-sm-row gap-2 flex-grow-1">
                                <input type="text" class="form-control form-control-sm new-category-input"
                                    placeholder="Add new structure/category name (e.g. Tunnel Portal)">
                                <button type="button" class="btn btn-sm add-category-btn flex-shrink-0">
                                    <i class="bi bi-plus-lg"></i> Add Structure Category
                                </button>
                            </div>
                            <div class="cumulative-total text-md-end">
                                <div class="cumulative-label">CUMULATIVE FORM TOTAL</div>
                                <div class="cumulative-value">₹ <span class="cumulative-amount">14,80,000</span></div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>


        <!-- FORM ACTIONS -->
        <div class="d-flex justify-content-end gap-2 mb-4">
            <button type="button" class="btn btn-sm form-cancel-btn">Cancel</button>
            <button type="button" class="btn btn-sm form-submit-btn">Create Work Order</button>
        </div>

    </div>

</div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
.wo-form-wrapper {
    font-family: 'Inter', sans-serif;
}

/* Page header */
.page-header-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: #eaf2fb;
    color: #17649b;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
}

.page-heading {
    font-family: 'Urbanist', sans-serif;
    font-size: 14px;
    font-weight: 800;
    color: #071d35;
}

.page-subheading {
    font-size: 9.5px;
    color: #7790ac;
}

.back-to-list-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 9px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
}

.back-to-list-btn:hover {
    background: #f5f8fb;
    color: #334e68;
}


/* Cards */
.wo-form-card {
    border: 1px solid #dce5ef;
    border-radius: 12px;
    overflow: hidden;
}

.wo-form-card .card-header {
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 14px 20px;
}

.wo-form-card .card-header h6 {
    font-family: 'Urbanist', sans-serif;
    font-size: 11.5px;
    font-weight: 800;
    color: #071d35;
    letter-spacing: 0.2px;
}

.step-icon {
    font-size: 15px;
    color: #17649b;
}

.wo-form-card .card-body {
    padding: 20px;
}

.wo-form-wrapper .form-label {
    font-size: 8px;
    font-weight: 700;
    color: #7790ac;
    letter-spacing: 0.3px;
    margin-bottom: 6px;
}

.wo-form-wrapper .form-control {
    font-size: 9.5px;
    color: #142c47;
    border-color: #dce5ef;
}

.wo-form-wrapper .form-control::placeholder {
    color: #a4b4c6;
}

.wo-form-wrapper .form-control:focus {
    border-color: #79b3dd;
    box-shadow: 0 0 0 0.2rem rgba(23, 100, 155, 0.12);
}

.wo-form-divider {
    border: none;
    height: 1px;
    background: #edf1f5;
    margin: 4px 0 16px;
}

.choose-file-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 8.5px;
    font-weight: 700;
    padding: 6px 14px;
    border-radius: 6px;
    cursor: pointer;
}

.choose-file-btn:hover {
    background: #f5f8fb;
}

.file-chosen-text {
    font-size: 8.5px;
    color: #7790ac;
}

.file-hint {
    font-size: 7.5px;
    color: #a4b4c6;
}

.link-active-badge {
    font-size: 8px;
    font-weight: 700;
    color: #17649b;
    background: #edf6fd;
    border: 1px solid #d7e8f6;
    border-radius: 20px;
    padding: 5px 12px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
}


/* TAB SWITCHER */
.boq-source-tabs {
    border-bottom: 1px solid #edf1f5;
    gap: 4px;
}

.boq-source-tabs .nav-link {
    border: 1px solid transparent;
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    font-size: 9.5px;
    font-weight: 700;
    color: #7790ac;
    padding: 9px 16px;
    display: flex;
    align-items: center;
    gap: 6px;
    background: transparent;
}

.boq-source-tabs .nav-link i {
    font-size: 11px;
}

.boq-source-tabs .nav-link:hover {
    color: #17649b;
    background: #f5faff;
}

.boq-source-tabs .nav-link.active {
    color: #17649b;
    background: #ffffff;
    border-color: #dce5ef;
    border-bottom-color: #ffffff;
    margin-bottom: -1px;
}

.boq-source-hint {
    background: #f8fafc;
    border-bottom: 1px solid #edf1f5;
    font-size: 8.5px;
    color: #6b8199;
    display: flex;
    align-items: center;
    gap: 6px;
}

.boq-source-hint i {
    color: #17649b;
    font-size: 11px;
}

.boq-source-hint strong {
    color: #142c47;
}


/* BOQ table */
.boq-form-table {
    font-size: 9px;
    margin-bottom: 0;
}

.boq-form-table thead th {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    background: #f8fafc;
    border-bottom: 1px solid #dce5ef;
    padding: 10px 12px;
    white-space: nowrap;
}

.boq-form-table tbody td {
    padding: 8px 12px;
    border-bottom: 1px solid #f3f6f9;
    vertical-align: middle;
    color: #334e68;
}

.boq-category-row td {
    background: #f8fafc;
    color: #142c47;
    border-bottom: 1px solid #edf1f5;
}

.boq-category-row strong {
    font-family: 'Urbanist', sans-serif;
    font-size: 9.5px;
}

.add-item-inline-btn {
    background: #ffffff;
    border: 1px solid #b7d4eb;
    color: #17649b;
    font-size: 7.5px;
    font-weight: 700;
    padding: 5px 10px;
    border-radius: 5px;
    white-space: nowrap;
}

.add-item-inline-btn:hover {
    background: #f5faff;
}

.item-name-cell {
    font-weight: 700;
    color: #142c47;
    min-width: 130px;
}

.item-desc-cell {
    color: #7891ad;
    font-style: italic;
    min-width: 150px;
}

.qty-input,
.rate-input {
    min-width: 75px;
    text-align: right;
}

.remarks-input {
    min-width: 100px;
    color: #a4b4c6;
}

.amount-cell {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    color: #071d35;
    white-space: nowrap;
    min-width: 90px;
}

.row-delete-btn {
    width: 24px;
    height: 24px;
    border: 0;
    background: transparent;
    color: #c04343;
    font-size: 10px;
    border-radius: 5px;
}

.row-delete-btn:hover {
    background: #fdf2f2;
}


/* Footer bar */
.boq-footer-bar {
    background: #fbfcfe;
    border-top: 1px solid #edf1f5;
}

.new-category-input {
    min-width: 200px;
}

.add-category-btn {
    background: #131a2b;
    border: 0;
    color: #ffffff;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
}

.add-category-btn:hover {
    background: #1f2941;
    color: #ffffff;
}

.cumulative-label {
    font-size: 7.5px;
    font-weight: 700;
    color: #94a7bc;
    letter-spacing: 0.3px;
    margin-bottom: 2px;
}

.cumulative-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 14px;
    font-weight: 800;
    color: #17649b;
    white-space: nowrap;
}


/* Form-level buttons */
.form-cancel-btn {
    background: #ffffff;
    border: 1px solid #dce5ef;
    color: #334e68;
    font-size: 9px;
    font-weight: 700;
    padding: 7px 18px;
    border-radius: 6px;
}

.form-cancel-btn:hover {
    background: #f5f8fb;
}

.form-submit-btn {
    background: #17649b;
    border: 0;
    color: #ffffff;
    font-size: 9px;
    font-weight: 700;
    padding: 7px 20px;
    border-radius: 6px;
}

.form-submit-btn:hover {
    background: #0f5689;
    color: #ffffff;
}


/* Mobile */
@media (max-width: 767px) {

    .wo-form-card .card-body {
        padding: 14px;
    }

    .boq-source-tabs {
        overflow-x: auto;
        flex-wrap: nowrap;
    }

    .boq-form-table {
        min-width: 900px;
    }

    .boq-footer-bar {
        padding: 12px 14px !important;
    }

    .cumulative-total {
        text-align: left !important;
    }

    .add-category-btn {
        justify-content: center;
    }
}

@media (max-width: 575px) {

    .form-cancel-btn,
    .form-submit-btn {
        flex: 1;
    }
}
</style>


<script>
document.addEventListener('DOMContentLoaded', function() {

    function formatINR(num) {
        return num.toLocaleString('en-IN', {
            maximumFractionDigits: 0
        });
    }

    function wireTable(tbody, totalEl) {
        function recalcRow(row) {
            var qty = parseFloat(row.querySelector('.qty-input')?.value) || 0;
            var rate = parseFloat(row.querySelector('.rate-input')?.value) || 0;
            var amount = qty * rate;
            var amountCell = row.querySelector('.amount-cell');
            if (amountCell) amountCell.textContent = formatINR(amount);
            return amount;
        }

        function recalcAll() {
            var total = 0;
            tbody.querySelectorAll('.boq-item-row').forEach(function(row) {
                total += recalcRow(row);
            });
            totalEl.textContent = formatINR(total);
        }

        tbody.addEventListener('input', function(e) {
            if (e.target.classList.contains('qty-input') || e.target.classList.contains('rate-input')) {
                recalcAll();
            }
        });

        tbody.addEventListener('click', function(e) {
            var delBtn = e.target.closest('.row-delete-btn');
            if (delBtn) {
                delBtn.closest('tr').remove();
                recalcAll();
            }

            var addBtn = e.target.closest('.add-item-inline-btn');
            if (addBtn) {
                var categoryId = addBtn.dataset.category;
                var rows = tbody.querySelectorAll('tr[data-category="' + categoryId + '"]');
                var lastRow = rows[rows.length - 1];

                var newRow = document.createElement('tr');
                newRow.className = 'boq-item-row';
                newRow.setAttribute('data-category', categoryId);
                newRow.innerHTML =
                    '<td class="text-muted">–</td>' +
                    '<td class="item-name-cell"><input type="text" class="form-control form-control-sm" value="New Item"></td>' +
                    '<td class="item-desc-cell"><input type="text" class="form-control form-control-sm" placeholder="Description"></td>' +
                    '<td>CuM</td>' +
                    '<td><input type="number" class="form-control form-control-sm qty-input" value="0" placeholder="Quantity"></td>' +
                    '<td><input type="number" class="form-control form-control-sm rate-input" value="0"></td>' +
                    '<td class="text-end amount-cell">0</td>' +
                    '<td><input type="text" class="form-control form-control-sm remarks-input" placeholder="Remarks"></td>' +
                    '<td class="text-end"><button type="button" class="row-delete-btn"><i class="bi bi-trash"></i></button></td>';

                lastRow.after(newRow);
                newRow.querySelector('.item-name-cell input').focus();
            }
        });

        recalcAll();
    }

    // Wire both tables independently
    wireTable(document.getElementById('projectChecklistBody'), document.querySelector(
        '#projectChecklistPane .cumulative-amount'));
    wireTable(document.getElementById('standardDemoBody'), document.querySelector(
        '#standardDemoPane .cumulative-amount'));

    // Update the hint text when switching tabs
    var hintText = document.getElementById('boqSourceHintText');
    document.getElementById('project-checklist-tab').addEventListener('shown.bs.tab', function() {
        hintText.innerHTML =
            'Item names and specification descriptions are synced directly with <strong>4 structure units</strong> mapped to this project.';
    });
    document.getElementById('standard-demo-tab').addEventListener('shown.bs.tab', function() {
        hintText.innerHTML =
            'Loaded from a <strong>standard demo template</strong> — edit freely before saving this work order.';
    });

    // Add-category buttons (each pane has its own)
    document.querySelectorAll('.add-category-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var pane = btn.closest('.tab-pane');
            var input = pane.querySelector('.new-category-input');
            var tbody = pane.querySelector('tbody');
            var name = input.value.trim();
            if (!name) {
                input.focus();
                return;
            }

            var newId = tbody.querySelectorAll('.boq-category-row').length + 1;
            var row = document.createElement('tr');
            row.className = 'boq-category-row';
            row.setAttribute('data-category', newId);
            row.innerHTML =
                '<td>' + newId + '</td>' +
                '<td colspan="7"><strong>' + name + '</strong></td>' +
                '<td class="text-end"><button type="button" class="add-item-inline-btn" data-category="' +
                newId + '">+ ADD ITEM</button></td>';

            tbody.appendChild(row);
            input.value = '';
        });
    });

    // Ref doc filename
    document.getElementById('refDocInput').addEventListener('change', function() {
        var fileName = this.files.length ? this.files[0].name : 'No file chosen';
        document.getElementById('refDocFileName').textContent = fileName;
    });

});
</script>

@endsection