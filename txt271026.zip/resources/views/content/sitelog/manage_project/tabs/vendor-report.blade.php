<div class="vendor-report-dashboard">

    <!-- STAT CARDS -->
    <div class="row g-3 mb-3">

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-vendors">
                    <i class="bi bi-truck"></i>
                </div>
                <div class="stat-label">ACTIVE MATERIALS SUPPLIERS</div>
                <div class="stat-value">3 <span>Mapped Vendors</span></div>
                <div class="stat-desc">Ultratech, Tata Steel, Shell Lubricants</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-delivery">
                    <i class="bi bi-clock-history"></i>
                </div>
                <div class="stat-label">SUPPLIER DELIVERY TIMELINES</div>
                <div class="stat-value text-info-custom">94.5% <span>On-Time</span></div>
                <div class="stat-desc text-success-custom">Exceeds SLAs standard (90%)</div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card h-100">
                <div class="stat-icon icon-quality">
                    <i class="bi bi-patch-check-fill"></i>
                </div>
                <div class="stat-label">VENDOR QUALITY INDEX</div>
                <div class="stat-value text-success-custom">98.2 <span>/ 100</span></div>
                <div class="stat-desc">Based on batch QC crush tests</div>
            </div>
        </div>

    </div>


    <!-- VENDOR PERFORMANCE MATRIX -->
    <div class="card panel-card">

        <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
            <h6 class="mb-0 panel-title">VENDOR PERFORMANCE MATRIX</h6>
            <button type="button" class="btn btn-sm export-btn d-flex align-items-center gap-1">
                <i class="bi bi-download"></i> Export scorecard
            </button>
        </div>

        <div class="card-body">
            <div class="row g-3">

                <div class="col-md-4">
                    <div class="vendor-card h-100">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="vendor-name">Ultratech Cement Ltd</div>
                                <div class="vendor-category">Material category: Binder / OPC</div>
                            </div>
                            <span class="grade-pill">98% Grade</span>
                        </div>
                        <hr class="vendor-divider">
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-truck"></i> On-Time delivery:</span>
                            <span class="metric-value">94.2%</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-award"></i> Quality Index:</span>
                            <span class="metric-value">98/100</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-star-fill"></i> Overall Rating:</span>
                            <span class="metric-value star-rating">
                                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="vendor-card h-100">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="vendor-name">TATA Steel Infrastructure</div>
                                <div class="vendor-category">Material category: Reinforcement</div>
                            </div>
                            <span class="grade-pill">99% Grade</span>
                        </div>
                        <hr class="vendor-divider">
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-truck"></i> On-Time delivery:</span>
                            <span class="metric-value">89.5%</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-award"></i> Quality Index:</span>
                            <span class="metric-value">99/100</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-star-fill"></i> Overall Rating:</span>
                            <span class="metric-value star-rating">
                                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="vendor-card h-100">
                        <div class="d-flex align-items-start justify-content-between">
                            <div>
                                <div class="vendor-name">Shell Commercial Oils</div>
                                <div class="vendor-category">Material category: Fuel / Lubricants</div>
                            </div>
                            <span class="grade-pill">96% Grade</span>
                        </div>
                        <hr class="vendor-divider">
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-truck"></i> On-Time delivery:</span>
                            <span class="metric-value">100.0%</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-award"></i> Quality Index:</span>
                            <span class="metric-value">96/100</span>
                        </div>
                        <div class="vendor-metric">
                            <span class="metric-label"><i class="bi bi-star-fill"></i> Overall Rating:</span>
                            <span class="metric-value star-rating">
                                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                                    class="bi bi-star-fill"></i>
                            </span>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

</div>


<style>
.vendor-report-dashboard {
    font-family: 'Inter', sans-serif;
    width: 100%;
}

/* Stat cards */
.stat-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
    position: relative;
}

.stat-icon {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.stat-icon.icon-vendors {
    background: #f1f5f9;
    color: #475569;
}

.stat-icon.icon-delivery {
    background: #dbeafe;
    color: #2563eb;
}

.stat-icon.icon-quality {
    background: #dcfce7;
    color: #16a34a;
}

.stat-label {
    font-size: 8px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
    padding-right: 36px;
}

.stat-value {
    font-family: 'Urbanist', sans-serif;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1;
    margin-bottom: 6px;
}

.stat-value span {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
}

.stat-desc {
    font-size: 8.5px;
    color: #64748b;
}

.text-success-custom {
    color: #16a34a !important;
}

.text-info-custom {
    color: #2563eb !important;
}


/* Panel card */
.panel-card {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
}

.panel-card .card-header {
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 18px;
}

.panel-title {
    font-family: 'Urbanist', sans-serif;
    font-size: 10.5px;
    font-weight: 800;
    color: #0f172a;
    letter-spacing: 0.4px;
}

.panel-card .card-body {
    padding: 18px;
}

.export-btn {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    color: #334155;
    font-size: 8.5px;
    font-weight: 700;
    padding: 7px 14px;
    border-radius: 6px;
    white-space: nowrap;
}

.export-btn:hover {
    background: #f8fafc;
    color: #334155;
}


/* Vendor cards */
.vendor-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 16px 18px;
}

.vendor-name {
    font-family: 'Urbanist', sans-serif;
    font-weight: 700;
    font-size: 11px;
    color: #0f172a;
    margin-bottom: 2px;
}

.vendor-category {
    font-size: 8px;
    color: #94a3b8;
}

.grade-pill {
    display: inline-block;
    font-size: 7.5px;
    font-weight: 700;
    letter-spacing: 0.2px;
    padding: 4px 10px;
    border-radius: 20px;
    background: #dcfce7;
    color: #15803d;
    white-space: nowrap;
}

.vendor-divider {
    margin: 12px 0;
    border-top: 1px solid #e2e8f0;
    opacity: 1;
}

.vendor-metric {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 9px;
    margin-bottom: 8px;
}

.vendor-metric:last-child {
    margin-bottom: 0;
}

.metric-label {
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 5px;
}

.metric-label i {
    font-size: 9px;
    color: #94a3b8;
}

.metric-value {
    font-weight: 700;
    color: #0f172a;
}

.star-rating i {
    color: #f59e0b;
    font-size: 9px;
    margin-left: 1px;
}


/* Mobile */
@media (max-width: 767px) {

    .stat-card {
        padding: 14px 16px;
    }

    .panel-card .card-header {
        flex-direction: column;
        align-items: stretch !important;
        gap: 10px;
    }

    .export-btn {
        justify-content: center;
    }
}
</style>