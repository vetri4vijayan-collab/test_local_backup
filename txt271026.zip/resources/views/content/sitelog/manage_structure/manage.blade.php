@extends('layouts/layoutMaster')

@section('title', 'Manage Structure')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection


@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection



@section('content')

<div class="container-fluid">

    {{-- ===================== HEADER CARD ===================== --}}
    <div class="card shadow-sm border-0 rounded-3 mb-3">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                <div class="d-flex align-items-center gap-3">

                    <div class="scrap-header-icon">
                        <i class="mdi mdi-cube-outline"></i>
                    </div>

                    <div>
                        <h5 class="fw-bold text-dark mb-0" style="font-size:16px;">
                            Manage Structure
                        </h5>
                        <p class="text-muted mb-0" style="font-size:12.5px;">
                            Site Operations Management &amp; Logs
                        </p>
                    </div>

                </div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <button type="button"
                            class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1 px-3 ms-2"
                            style="height:38px;white-space:nowrap;"
                            id="openStructureModalBtn"
                            data-bs-toggle="modal"
                            data-bs-target="#structureDetailsModal">

                        <i class="mdi mdi-plus"></i>
                        <span>Structure Management details</span>
                    </button>

                </div>

            </div>

        </div>
    </div>


    {{-- ===================== TABLE CARD ===================== --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4 pb-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h6 class="fw-bold mb-1 text-uppercase" style="font-size:13px;letter-spacing:.04em;">
                        Structure Registry
                    </h6>
                    <p class="text-muted small mb-0">
                        All project structures mapped with chainage details
                    </p>
                </div>
                <span class="scrap-records-badge" id="structureCountBadge">
                    5 Records Listed
                </span>
            </div>
        </div>

        {{-- ===================== FILTER SECTION ===================== --}}
        <div class="px-3 px-md-4 pb-3">
            <div class="row g-2 align-items-end">

                <div class="col-12 col-sm-6 col-md-3">
                    <label for="fltSearch" class="form-label small text-muted mb-1">Search</label>
                    <input type="text"
                           id="fltSearch"
                           class="form-control form-control-sm"
                           placeholder="Company, project, type, engineer…"
                           autocomplete="off">
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <label for="fltCompany" class="form-label small text-muted mb-1">Company</label>
                    <select id="fltCompany" class="form-select form-select-sm">
                        <option value="">All Companies</option>
                        <option value="SRK Infra Developers">SRK Infra Developers</option>
                        <option value="SRK Constructions">SRK Constructions</option>
                        <option value="SRK Projects Pvt Ltd">SRK Projects Pvt Ltd</option>
                    </select>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <label for="fltType" class="form-label small text-muted mb-1">Structure Type</label>
                    <select id="fltType" class="form-select form-select-sm">
                        <option value="">All Types</option>
                        <option value="Water Treatment Plant Structure">Water Treatment Plant Structure</option>
                        <option value="Warehouse Structure">Warehouse Structure</option>
                        <option value="Underground Drainage System">Underground Drainage System</option>
                        <option value="Interior Fit-out Structure">Interior Fit-out Structure</option>
                        <option value="Rooftop Solar Structure">Rooftop Solar Structure</option>
                        <option value="Roadway Structure">Roadway Structure</option>
                        <option value="IT Park Building">IT Park Building</option>
                    </select>
                </div>


            </div>
        </div>
        {{-- =================== /FILTER SECTION ====================== --}}

        <div class="table-responsive">
            <table class="table scrap-table mb-0" id="structureTable">

                <thead>
                    <tr>
                        <th class="text-start">Company Name</th>
                        <th class="text-start">Project Name</th>
                        <th class="text-start">Structure Type</th>
                        <th class="text-start">Site Engineer</th>
                        <th class="text-start">Chainage From</th>
                        <th class="text-start">Chainage To</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>

                <tbody id="structureTableBody">

                    {{-- Row 1 --}}
                    <tr class="structure-row">
                        <td><span class="scrap-desc">SRK Infra Developers</span></td>
                        <td><span class="scrap-desc">Flyover</span></td>
                        <td><span class="scrap-desc">Water Treatment Plant Structure</span></td>
                        <td class="text-center engineer-cell">
                            <button type="button" class="struct-sync-btn" title="Assign site engineer">
                                <i class="mdi mdi-sync"></i>
                            </button>
                        </td>
                        <td><span class="scrap-desc">4556565</span></td>
                        <td><span class="scrap-desc">566545446</span></td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 2 --}}
                    <tr class="structure-row">
                        <td><span class="scrap-desc">SRK Infra Developers</span></td>
                        <td><span class="scrap-desc">Industrial Warehouse Construction</span></td>
                        <td><span class="scrap-desc">Warehouse Structure</span></td>
                        <td class="text-center engineer-cell">
                            <button type="button" class="struct-sync-btn" title="Assign site engineer">
                                <i class="mdi mdi-sync"></i>
                            </button>
                        </td>
                        <td><span class="scrap-desc">0+000</span></td>
                        <td><span class="scrap-desc">0+300</span></td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 3 --}}
                    <tr class="structure-row">
                        <td><span class="scrap-desc">SRK Infra Developers</span></td>
                        <td><span class="scrap-desc">Smart City Drainage Upgrade</span></td>
                        <td><span class="scrap-desc">Underground Drainage System</span></td>
                        <td class="text-center engineer-cell">
                            <button type="button" class="struct-sync-btn" title="Assign site engineer">
                                <i class="mdi mdi-sync"></i>
                            </button>
                        </td>
                        <td><span class="scrap-desc">1+200</span></td>
                        <td><span class="scrap-desc">1+800</span></td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 4 --}}
                    <tr class="structure-row">
                        <td><span class="scrap-desc">SRK Infra Developers</span></td>
                        <td><span class="scrap-desc">Commercial Complex Interior Setup</span></td>
                        <td><span class="scrap-desc">Interior Fit-out Structure</span></td>
                        <td class="text-center engineer-cell">
                            <button type="button" class="struct-sync-btn" title="Assign site engineer">
                                <i class="mdi mdi-sync"></i>
                            </button>
                        </td>
                        <td><span class="scrap-desc">0+000</span></td>
                        <td><span class="scrap-desc">0+200</span></td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    {{-- Row 5 --}}
                    <tr class="structure-row">
                        <td><span class="scrap-desc">SRK Infra Developers</span></td>
                        <td><span class="scrap-desc">Solar Power Plant Installation</span></td>
                        <td><span class="scrap-desc">Rooftop Solar Structure</span></td>
                        <td class="text-center engineer-cell">
                            <button type="button" class="struct-sync-btn" title="Assign site engineer">
                                <i class="mdi mdi-sync"></i>
                            </button>
                        </td>
                        <td><span class="scrap-desc">0+000</span></td>
                        <td><span class="scrap-desc">0+050</span></td>
                        <td class="text-center">
                            <div class="scrap-action-buttons">
                                <button type="button" class="scrap-action-btn scrap-view" title="View">
                                    <i class="mdi mdi-eye-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-edit" title="Edit">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="scrap-action-btn scrap-delete" title="Delete">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>

            </table>
        </div>

    </div>

</div>



{{-- ===================== STRUCTURE MANAGEMENT MODAL (ADD / EDIT) ===================== --}}
<div class="modal fade" id="structureDetailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg struct-modal-tall">
        <div class="modal-content rounded-3 border-0 shadow-lg overflow-hidden">

            <div class="modal-header struct-modal-header border-0 px-4 py-3">
                <div>
                    <h5 class="modal-title fw-bold mb-1 text-white"
                        id="structureModalTitle"
                        style="font-size:16px;">
                        Log Structure Management Details
                    </h5>
                    <p class="mb-0 struct-modal-subtitle">
                        Record new Structure Management details
                    </p>
                </div>
                <button type="button"
                        class="btn-close btn-close-white"
                        data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body py-4 px-4 struct-modal-body">

                <form id="structureForm" autocomplete="off">
                    <div class="row g-3">

                        <div class="col-12 col-md-6">
                            <label for="stCompany" class="form-label struct-label mb-1">
                                Company Name <span class="text-danger">*</span>
                            </label>
                            <select id="stCompany" class="form-select" required>
                                <option value="">-- Select Company --</option>
                                <option value="SRK Infra Developers" selected>SRK Infra Developers</option>
                                <option value="SRK Constructions">SRK Constructions</option>
                                <option value="SRK Projects Pvt Ltd">SRK Projects Pvt Ltd</option>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="stProject" class="form-label struct-label mb-1">
                                Project Name <span class="text-danger">*</span>
                            </label>
                            <select id="stProject" class="form-select" required>
                                <option value="">-- Select Project --</option>
                                <option value="Flyover">Flyover</option>
                                <option value="Industrial Warehouse Construction">Industrial Warehouse Construction</option>
                                <option value="Smart City Drainage Upgrade">Smart City Drainage Upgrade</option>
                                <option value="Commercial Complex Interior Setup">Commercial Complex Interior Setup</option>
                                <option value="Solar Power Plant Installation">Solar Power Plant Installation</option>
                                <option value="Highway Road Expansion Phase 2">Highway Road Expansion Phase 2</option>
                                <option value="Water Treatment Plant Setup">Water Treatment Plant Setup</option>
                                <option value="IT Park Infrastructure Development">IT Park Infrastructure Development</option>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="stType" class="form-label struct-label mb-1">
                                Structure Type <span class="text-danger">*</span>
                            </label>
                            <select id="stType" class="form-select" required>
                                <option value="">-- Select Structure Type --</option>
                                <option value="Water Treatment Plant Structure">Water Treatment Plant Structure</option>
                                <option value="Warehouse Structure">Warehouse Structure</option>
                                <option value="Underground Drainage System">Underground Drainage System</option>
                                <option value="Interior Fit-out Structure">Interior Fit-out Structure</option>
                                <option value="Rooftop Solar Structure">Rooftop Solar Structure</option>
                                <option value="Roadway Structure">Roadway Structure</option>
                                <option value="IT Park Building">IT Park Building</option>
                            </select>
                        </div>

                        <select id="stEngineer" class="d-none">
                            <option value="Admin" selected>Admin</option>
                        </select>

                        <div class="col-12 col-md-6">
                            <label for="stFrom" class="form-label struct-label mb-1">
                                Chainage From <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   id="stFrom"
                                   class="form-control"
                                   placeholder="e.g. 0+000"
                                   required>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="stTo" class="form-label struct-label mb-1">
                                Chainage To <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   id="stTo"
                                   class="form-control"
                                   placeholder="e.g. 0+500"
                                   required>
                        </div>

                    </div>
                </form>

            </div>

            <div class="modal-footer border-0 pt-0 px-4 pb-4">
                <button type="button"
                        class="btn btn-light border px-4"
                        data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button"
                        class="btn btn-primary px-4 text-white d-inline-flex align-items-center gap-1 struct-save-btn"
                        id="structureSaveBtn">
                    <i class="mdi mdi-plus"></i>
                    <span>Add the details</span>
                </button>
            </div>

        </div>
    </div>
</div>



{{-- ===================== ASSIGN SITE ENGINEER MODAL ===================== --}}
<div class="modal fade" id="assignEngineerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered assign-engineer-dialog">
        <div class="modal-content rounded-3 border-0 shadow-lg overflow-hidden">

            <div class="modal-header border-0 px-4 py-3">
                <h5 class="modal-title fw-normal text-secondary mb-0"
                    id="assignEngineerTitle"
                    style="font-size:17px;">
                    Assign Site Engineer
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body px-4 pb-3 pt-2">

                <div class="d-flex align-items-center gap-2 mb-3">
                    <span class="fw-bold text-dark" style="font-size:14px;">
                        Site Engineers Already Assigned :
                    </span>
                    <span class="badge rounded-pill assign-count-badge"
                          id="assignedCountBadge">0</span>
                </div>

                <div class="assigned-list mb-3" id="assignedList">
                    <div class="assigned-empty text-muted small">
                        No engineers assigned yet.
                    </div>
                </div>

                <hr class="my-3">

                <div class="mb-2">
                    <span class="fw-bold text-dark" style="font-size:13.5px;">
                        Add Engineers :
                    </span>
                </div>

                <div class="assign-engineer-list" id="assignEngineerList">
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Rajendran. J">
                        <span>Rajendran. J</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Veerakaleeswaran. V">
                        <span>Veerakaleeswaran. V</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Muthuraj. M">
                        <span>Muthuraj. M</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Karuppasamy. A">
                        <span>Karuppasamy. A</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Parthiban. B">
                        <span>Parthiban. B</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Sudharsan. K">
                        <span>Sudharsan. K</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Sivakumar. M">
                        <span>Sivakumar. M</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Janardan Ram">
                        <span>Janardan Ram</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Kaliraj. S">
                        <span>Kaliraj. S</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Dharan">
                        <span>Dharan</span>
                    </label>
                    <label class="assign-item">
                        <input type="checkbox" class="assign-checkbox" value="Manoj Kumar">
                        <span>Manoj Kumar</span>
                    </label>
                </div>

            </div>

            <div class="modal-footer border-0 px-4 pb-4 pt-3">
                <button type="button"
                        class="btn btn-light border px-4"
                        data-bs-dismiss="modal">
                    Close
                </button>
                <button type="button"
                        class="btn btn-primary px-4 text-white assign-btn"
                        id="assignEngineerBtn">
                    Assign Project
                </button>
            </div>

        </div>
    </div>
</div>



<style>

.scrap-header-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #e8eef5;
    color: #16659E;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.scrap-header-icon i {
    font-size: 24px;
    line-height: 1;
}

.scrap-records-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 14px;
    border-radius: 8px;
    background: #eef1f4;
    color: #566a7f;
    font-size: 11.5px;
    font-weight: 600;
    white-space: nowrap;
}

.scrap-table {
    table-layout: auto;
    width: 100% !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    font-size: 12px;
}

.scrap-table thead th {
    background: #ffffff;
    color: #566a7f;
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    padding: 14px 24px;
    border-top: 1px solid #eef0f4;
    border-bottom: 1px solid #eef0f4;
    white-space: nowrap;
}

.scrap-table tbody td {
    padding: 14px 24px;
    vertical-align: middle;
    border-bottom: 1px solid #eef0f4;
    background: #ffffff;
    white-space: nowrap;
}

.scrap-table tbody tr:last-child td {
    border-bottom: 0;
}

.scrap-table tbody tr:hover td {
    background: #fbfdff;
}

.scrap-desc {
    display: inline-block;
    color: #111827;
    font-size: 12.5px;
    font-weight: 600;
    line-height: 16px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
    vertical-align: middle;
}

/* ---------- Sync button ---------- */
.struct-sync-btn {
    width: 26px;
    height: 26px;
    border: 0;
    background: transparent;
    color: #1a73e8;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    border-radius: 50%;
    transition: all .15s ease;
    vertical-align: middle;
}

.struct-sync-btn i {
    font-size: 16px;
    line-height: 1;
}

.struct-sync-btn:hover {
    color: #0d47a1;
    transform: rotate(90deg);
}

/* ---------- Engineer dropdown inside a row ---------- */
.engineer-select {
    font-size: 12px;
    padding: 4px 8px;
    border: 1px solid #dfe3e8;
    border-radius: 6px;
    background-color: #fff;
    color: #111827;
    min-width: 150px;
    max-width: 190px;
    cursor: pointer;
    vertical-align: middle;
}

.engineer-select:focus {
    border-color: #16659E;
    outline: none;
    box-shadow: 0 0 0 .15rem rgba(22,101,158,.15);
}

/* ---------- Action buttons ---------- */
.scrap-action-buttons {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
}

.scrap-action-btn {
    width: 22px;
    height: 22px;
    padding: 0;
    margin: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    background: transparent;
    cursor: pointer;
    font-size: 16px;
    line-height: 1;
    transition: all .15s ease;
}

.scrap-action-btn i {
    font-size: 16px;
    line-height: 1;
}

.scrap-view   { color: #1a73e8; }
.scrap-view:hover   { color: #0d47a1; transform: scale(1.15); }

.scrap-edit   { color: #1a73e8; }
.scrap-edit:hover   { color: #0d47a1; transform: scale(1.15); }

.scrap-delete { color: #94a3b8; }
.scrap-delete:hover { color: #dc2626; transform: scale(1.15); }

/* ---------- Filter row (new) ---------- */
#fltSearch,
#fltCompany,
#fltType {
    height: 34px;
    font-size: 13px;
    border-radius: 6px;
}

#fltApplyBtn,
#fltResetBtn {
    height: 34px;
}

/* Hide a filtered-out row */
.structure-row.flt-hidden {
    display: none !important;
}

/* ==========================================================
   STRUCTURE MANAGEMENT MODAL
   ========================================================== */

#structureDetailsModal .modal-content {
    border-radius: 12px;
    overflow: hidden;
}

#structureDetailsModal .struct-modal-header {
    background: #16659E;
    border-radius: 0;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
}

#structureDetailsModal .struct-modal-subtitle {
    color: rgba(255, 255, 255, 0.85);
    font-size: 12px;
    font-weight: 400;
}

#structureDetailsModal .struct-modal-header .btn-close {
    margin-top: 4px;
    opacity: .85;
}

#structureDetailsModal .struct-modal-header .btn-close:hover {
    opacity: 1;
}

.struct-label {
    font-size: 12.5px;
    font-weight: 600;
    color: #344054;
}

#structureDetailsModal .form-select,
#structureDetailsModal .form-control {
    font-size: 13.5px;
    height: 44px;
    border-radius: 6px;
    border: 1px solid #d0d5dd;
    background-color: #ffffff;
    color: #111827;
    padding-left: 14px;
}

#structureDetailsModal .form-select:focus,
#structureDetailsModal .form-control:focus {
    border-color: #16659E;
    box-shadow: 0 0 0 .15rem rgba(22,101,158,.15);
}

#structureDetailsModal .form-select::placeholder,
#structureDetailsModal .form-control::placeholder {
    color: #98a2b3;
}

#structureDetailsModal .text-danger {
    color: #dc2626 !important;
    font-weight: 700;
}

#structureDetailsModal .struct-save-btn {
    background: #16659E;
    border: 1px solid #16659E;
    font-weight: 600;
    font-size: 13.5px;
    padding: 9px 18px;
    border-radius: 6px;
}

#structureDetailsModal .struct-save-btn:hover {
    background: #124f7c;
    border-color: #124f7c;
}

#structureDetailsModal .modal-footer .btn-light {
    background: #f2f4f7;
    border: 1px solid #e4e7ec !important;
    font-size: 13.5px;
    font-weight: 600;
    padding: 9px 20px;
    border-radius: 6px;
    color: #344054;
}

#structureDetailsModal .modal-footer .btn-light:hover {
    background: #e4e7ec;
}

.struct-modal-tall .modal-content {
    min-height: 460px;
}

.struct-modal-body {
    min-height: 280px;
}

/* ==========================================================
   ASSIGN SITE ENGINEER MODAL
   ========================================================== */

.assign-engineer-dialog {
    max-width: 640px;
}

#assignEngineerModal .modal-content {
    border-radius: 6px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.18) !important;
}

#assignEngineerModal .modal-header {
    border-bottom: 1px solid #eef0f4;
    padding: 18px 22px 14px;
}

#assignEngineerModal .modal-title {
    font-weight: 400;
    color: #7b8a9a;
    font-size: 17px;
}

#assignEngineerModal .modal-body {
    padding: 24px 22px 12px;
}

.assign-count-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 22px;
    height: 22px;
    padding: 0 7px;
    font-size: 12px;
    font-weight: 700;
    background: #29ABE2;
    color: #fff;
    border-radius: 11px;
}

/* ---------- Assigned chips ---------- */
.assigned-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-height: 180px;
    overflow-y: auto;
    padding-right: 4px;
}

.assigned-empty {
    padding: 6px 0;
    font-style: italic;
}

.assigned-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 10px;
    background: #f7f9fb;
    border: 1px solid #eef0f4;
    border-radius: 6px;
    font-size: 13.5px;
    color: #1f2933;
    font-weight: 500;
}

.assigned-row .assigned-name {
    flex: 1;
}

.assigned-row .assigned-actions {
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.assigned-action {
    border: 0;
    background: transparent;
    cursor: pointer;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    line-height: 1;
    transition: all .15s ease;
}

.assigned-action.assigned-edit   { color: #1a73e8; }
.assigned-action.assigned-edit:hover   { color: #0d47a1; transform: scale(1.15); }

.assigned-action.assigned-remove { color: #94a3b8; }
.assigned-action.assigned-remove:hover { color: #dc2626; transform: scale(1.15); }

/* ---------- Add engineers checklist ---------- */
.assign-engineer-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    max-height: 260px;
    overflow-y: auto;
    padding-right: 6px;
}

.assign-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    color: #1f2933;
    font-weight: 500;
    cursor: pointer;
    padding: 2px 0;
    user-select: none;
}

.assign-item input[type="checkbox"] {
    width: 16px;
    height: 16px;
    margin: 0;
    cursor: pointer;
    accent-color: #16659E;
}

.assign-item span {
    line-height: 1.2;
}

#assignEngineerModal .modal-footer {
    border-top: 1px solid #eef0f4;
    padding: 16px 22px;
    gap: 10px;
}

#assignEngineerModal .btn-light {
    background: #f0f2f5;
    border: 1px solid #e4e7ec;
    color: #344054;
    font-weight: 600;
    font-size: 13.5px;
    padding: 9px 22px;
    border-radius: 4px;
}

#assignEngineerModal .btn-light:hover {
    background: #e4e7ec;
}

#assignEngineerModal .assign-btn {
    background: #29ABE2;
    border: 1px solid #29ABE2;
    color: #fff;
    font-weight: 700;
    font-size: 13.5px;
    padding: 9px 22px;
    border-radius: 4px;
}

#assignEngineerModal .assign-btn:hover {
    background: #1e95c7;
    border-color: #1e95c7;
}

@media (max-width: 992px) {
    .scrap-table { min-width: 1000px; }
}

@media (max-width: 576px) {
    .scrap-table thead th,
    .scrap-table tbody td {
        padding: 12px 16px;
    }
}

</style>



<script>
document.addEventListener('DOMContentLoaded', function () {

    const tbody      = document.getElementById('structureTableBody');
    const countBadge = document.getElementById('structureCountBadge');
    const saveBtn    = document.getElementById('structureSaveBtn');
    const modalEl    = document.getElementById('structureDetailsModal');
    const modalTitle = document.getElementById('structureModalTitle');

    /* ---------- Filter elements ---------- */
    const fltSearch   = document.getElementById('fltSearch');
    const fltCompany  = document.getElementById('fltCompany');
    const fltType     = document.getElementById('fltType');
    const fltApplyBtn = document.getElementById('fltApplyBtn');
    const fltResetBtn = document.getElementById('fltResetBtn');

    /* ---------- Assign Engineer modal refs ---------- */
    const assignModal    = document.getElementById('assignEngineerModal');
    const assignList     = document.getElementById('assignEngineerList');
    const assignCount    = document.getElementById('assignedCountBadge');
    const assignBtn      = document.getElementById('assignEngineerBtn');
    const assignedListEl = document.getElementById('assignedList');
    let currentRow       = null;
    let currentAssigned  = [];

    /* ---------- Field refs ---------- */
    const stCompany  = document.getElementById('stCompany');
    const stProject  = document.getElementById('stProject');
    const stType     = document.getElementById('stType');
    const stEngineer = document.getElementById('stEngineer');
    const stFrom     = document.getElementById('stFrom');
    const stTo       = document.getElementById('stTo');

    /* ---------- Mode tracking ---------- */
    let currentMode = 'add';
    let editingRow  = null;


    /* ==========================================================
       localStorage — persist assigned engineers per row
       ========================================================== */
    const ENGINEERS_STORAGE_KEY = 'manage_structure_engineers_v1';

    function rowKey(row) {
        const cells = row.querySelectorAll('td');
        const company = cells[0] ? cells[0].innerText.trim() : '';
        const project = cells[1] ? cells[1].innerText.trim() : '';
        const type    = cells[2] ? cells[2].innerText.trim() : '';
        const from    = cells[4] ? cells[4].innerText.trim() : '';
        const to      = cells[5] ? cells[5].innerText.trim() : '';
        return [company, project, type, from, to].join('||');
    }

    function readStore() {
        try {
            return JSON.parse(localStorage.getItem(ENGINEERS_STORAGE_KEY) || '{}');
        } catch (e) {
            return {};
        }
    }

    function writeStore(obj) {
        try {
            localStorage.setItem(ENGINEERS_STORAGE_KEY, JSON.stringify(obj));
        } catch (e) { /* ignore quota errors */ }
    }

    function saveEngineers(row) {
        if (!row) return;
        const key = rowKey(row);
        const list = row.dataset.engineers
            ? row.dataset.engineers.split('||').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        const store = readStore();
        if (list.length === 0) {
            delete store[key];
        } else {
            store[key] = list;
        }
        writeStore(store);
    }

    function removeEngineersFor(row) {
        if (!row) return;
        const key = rowKey(row);
        const store = readStore();
        if (store[key]) {
            delete store[key];
            writeStore(store);
        }
    }

    function loadEngineers() {
        const store = readStore();

        tbody.querySelectorAll('.structure-row').forEach(function (row) {
            const key = rowKey(row);
            const saved = store[key];
            if (!saved || !saved.length) return;

            row.dataset.engineers = saved.join('||');

            const engineerCell = row.querySelector('.engineer-cell');
            if (engineerCell) {
                engineerCell.innerHTML = buildEngineerCell(saved);
                if (typeof row._attachSync === 'function') {
                    row._attachSync();
                }
            }
        });
    }


    /* ---------- Count badge (visible rows only) ---------- */
    function refreshCount() {
        if (!countBadge || !tbody) return;
        const total = tbody.querySelectorAll('.structure-row:not(.flt-hidden)').length;
        countBadge.textContent = total + ' Records Listed';
    }


    /* ---------- Reset form ---------- */
    function resetForm() {
        if (stCompany)  stCompany.value  = 'SRK Infra Developers';
        if (stProject)  stProject.value  = '';
        if (stType)     stType.value     = '';
        if (stEngineer) stEngineer.value = 'Admin';
        if (stFrom)     stFrom.value     = '';
        if (stTo)       stTo.value       = '';
    }


    /* ---------- ADD mode ---------- */
    function setAddMode() {
        currentMode = 'add';
        editingRow  = null;

        if (modalTitle) modalTitle.textContent = 'Log Structure Management Details';
        if (saveBtn) {
            saveBtn.innerHTML =
                '<i class="mdi mdi-plus"></i>' +
                '<span>Add the details</span>';
        }

        resetForm();
    }


    /* ---------- EDIT mode ---------- */
    function setEditMode(row) {
        currentMode = 'edit';
        editingRow  = row;

        if (modalTitle) modalTitle.textContent = 'Edit Structure Management Details';
        if (saveBtn) {
            saveBtn.innerHTML =
                '<i class="mdi mdi-check"></i>' +
                '<span>Update the details</span>';
        }

        const cells = row.querySelectorAll('td');

        if (stCompany)  stCompany.value  = cells[0].innerText.trim();
        if (stProject)  stProject.value  = cells[1].innerText.trim();
        if (stType)     stType.value     = cells[2].innerText.trim();
        if (stEngineer) stEngineer.value = 'Admin';
        if (stFrom)     stFrom.value     = cells[4].innerText.trim();
        if (stTo)       stTo.value       = cells[5].innerText.trim();
    }


    /* ---------- Build engineer cell ---------- */
    function buildEngineerCell(names) {
        let inner = '';

        if (!names || names.length === 0) {
            inner = '';
        } else if (names.length === 1) {
            inner =
                '<span class="scrap-desc me-2" title="' + names[0] + '">' +
                    names[0] +
                '</span>';
        } else {
            let opts = '';
            names.forEach(function (n) {
                opts += '<option value="' + n + '">' + n + '</option>';
            });
            inner = '<select class="engineer-select me-2">' + opts + '</select>';
        }

        return inner +
            '<button type="button" class="struct-sync-btn" title="Edit / Remove engineers">' +
                '<i class="mdi mdi-sync"></i>' +
            '</button>';
    }


    /* ---------- Render assigned list with Edit / Remove ---------- */
    function renderAssignedList() {
        if (!assignedListEl) return;

        if (currentAssigned.length === 0) {
            assignedListEl.innerHTML =
                '<div class="assigned-empty text-muted small">No engineers assigned yet.</div>';
        } else {
            let html = '';
            currentAssigned.forEach(function (name, idx) {
                html +=
                    '<div class="assigned-row" data-idx="' + idx + '">' +
                        '<span class="assigned-name">' + name + '</span>' +
                        '<span class="assigned-actions">' +
                            '<button type="button" class="assigned-action assigned-edit" ' +
                                    'data-idx="' + idx + '" title="Edit name">' +
                                '<i class="mdi mdi-pencil-outline"></i>' +
                            '</button>' +
                            '<button type="button" class="assigned-action assigned-remove" ' +
                                    'data-idx="' + idx + '" title="Remove">' +
                                '<i class="mdi mdi-trash-can-outline"></i>' +
                            '</button>' +
                        '</span>' +
                    '</div>';
            });
            assignedListEl.innerHTML = html;
        }

        if (assignCount) assignCount.textContent = currentAssigned.length;
    }


    /* ---------- Open assign modal for a row ---------- */
    function openAssignModal(row) {
        currentRow = row;

        currentAssigned = row.dataset.engineers
            ? row.dataset.engineers.split('||').map(function (s) { return s.trim(); }).filter(Boolean)
            : [];

        assignList.querySelectorAll('.assign-checkbox').forEach(function (cb) {
            if (currentAssigned.indexOf(cb.value) !== -1) {
                cb.checked = true;
                cb.disabled = true;
                const item = cb.closest('.assign-item');
                if (item) item.style.opacity = '0.5';
            } else {
                cb.checked = false;
                cb.disabled = false;
                const item = cb.closest('.assign-item');
                if (item) item.style.opacity = '';
            }
        });

        renderAssignedList();

        if (assignModal) {
            bootstrap.Modal.getOrCreateInstance(assignModal).show();
        }
    }


    /* ---------- Bind row ---------- */
    function bindRow(row) {
        if (row.dataset.bound === '1') return;
        row.dataset.bound = '1';

        const viewBtn = row.querySelector('.scrap-view');
        const editBtn = row.querySelector('.scrap-edit');
        const delBtn  = row.querySelector('.scrap-delete');

        function attachSync() {
            const syncBtn = row.querySelector('.struct-sync-btn');
            if (syncBtn && syncBtn.dataset.bound !== '1') {
                syncBtn.dataset.bound = '1';
                syncBtn.addEventListener('click', function () {
                    openAssignModal(row);
                });
            }
        }

        attachSync();

        /* View → open the separate view page with this row's data */
        if (viewBtn) {
            viewBtn.addEventListener('click', function () {
                const cells = row.querySelectorAll('td');

                const company  = cells[0] ? cells[0].innerText.trim() : '';
                const project  = cells[1] ? cells[1].innerText.trim() : '';
                const type     = cells[2] ? cells[2].innerText.trim() : '';
                const engineer = row.dataset.engineers
                    ? row.dataset.engineers.split('||').join(', ')
                    : '';
                const from     = cells[4] ? cells[4].innerText.trim() : '';
                const to       = cells[5] ? cells[5].innerText.trim() : '';

                const url = "{{ route('site.manage-structure.view') }}" +
                    '?company='  + encodeURIComponent(company)  +
                    '&project='  + encodeURIComponent(project)  +
                    '&type='     + encodeURIComponent(type)     +
                    '&engineer=' + encodeURIComponent(engineer) +
                    '&from='     + encodeURIComponent(from)     +
                    '&to='       + encodeURIComponent(to);

                window.location.href = url;
            });
        }

        if (editBtn) {
            editBtn.addEventListener('click', function () {
                setEditMode(row);
                if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        }

        if (delBtn) {
            delBtn.addEventListener('click', function () {
                if (confirm('Delete this structure record?')) {
                    removeEngineersFor(row);
                    row.remove();
                    refreshCount();
                }
            });
        }

        row._attachSync = attachSync;
    }


    /* ==========================================================
       Filtering
       ========================================================== */
    function readRowData(row) {
        const cells = row.querySelectorAll('td');

        return {
            company:  cells[0] ? cells[0].innerText.trim() : '',
            project:  cells[1] ? cells[1].innerText.trim() : '',
            type:     cells[2] ? cells[2].innerText.trim() : '',
            engineer: row.dataset.engineers
                ? row.dataset.engineers.split('||').map(function (s) { return s.trim(); }).join(', ')
                : (cells[3] ? cells[3].innerText.trim() : ''),
            from:     cells[4] ? cells[4].innerText.trim() : '',
            to:       cells[5] ? cells[5].innerText.trim() : ''
        };
    }

    function applyFilters() {
        if (!tbody) return;

        const term    = (fltSearch?.value  || '').toLowerCase().trim();
        const company = (fltCompany?.value || '').trim();
        const type    = (fltType?.value    || '').trim();

        tbody.querySelectorAll('.structure-row').forEach(function (row) {
            const d = readRowData(row);

            const haystack = (
                d.company + ' ' +
                d.project + ' ' +
                d.type + ' ' +
                d.engineer + ' ' +
                d.from + ' ' +
                d.to
            ).toLowerCase();

            const matchSearch  = term === '' || haystack.indexOf(term) !== -1;
            const matchCompany = company === '' || d.company === company;
            const matchType    = type === '' || d.type === type;

            if (matchSearch && matchCompany && matchType) {
                row.classList.remove('flt-hidden');
            } else {
                row.classList.add('flt-hidden');
            }
        });

        refreshCount();
    }

    function resetFilters() {
        if (fltSearch)  fltSearch.value  = '';
        if (fltCompany) fltCompany.value = '';
        if (fltType)    fltType.value    = '';
        applyFilters();
    }

    if (fltSearch)   fltSearch.addEventListener('input', applyFilters);
    if (fltCompany)  fltCompany.addEventListener('change', applyFilters);
    if (fltType)     fltType.addEventListener('change', applyFilters);
    if (fltApplyBtn) fltApplyBtn.addEventListener('click', applyFilters);
    if (fltResetBtn) fltResetBtn.addEventListener('click', resetFilters);


    /* ---------- Assign button click ---------- */
    if (assignBtn) {
        assignBtn.addEventListener('click', function () {
            if (!currentRow) return;

            assignList.querySelectorAll('.assign-checkbox:checked').forEach(function (cb) {
                if (currentAssigned.indexOf(cb.value) === -1) {
                    currentAssigned.push(cb.value);
                }
            });

            currentRow.dataset.engineers = currentAssigned.join('||');

            const engineerCell = currentRow.querySelector('.engineer-cell');
            if (engineerCell) {
                engineerCell.innerHTML = buildEngineerCell(currentAssigned);

                if (typeof currentRow._attachSync === 'function') {
                    currentRow._attachSync();
                }
            }

            saveEngineers(currentRow);

            if (assignModal) {
                bootstrap.Modal.getOrCreateInstance(assignModal).hide();
            }

            /* Reapply filters because engineer data changed */
            applyFilters();
        });
    }


    /* ---------- Edit / Remove in assigned list ---------- */
    if (assignedListEl) {
        assignedListEl.addEventListener('click', function (e) {

            const editBtn   = e.target.closest('.assigned-edit');
            const removeBtn = e.target.closest('.assigned-remove');

            /* ----- EDIT ----- */
            if (editBtn) {
                const idx = parseInt(editBtn.dataset.idx, 10);
                const oldName = currentAssigned[idx];
                const newName = prompt('Edit engineer name:', oldName);

                if (newName !== null && newName.trim() !== '' && newName.trim() !== oldName) {
                    const clean = newName.trim();
                    currentAssigned[idx] = clean;

                    assignList.querySelectorAll('.assign-checkbox').forEach(function (cb) {
                        if (cb.value === oldName) {
                            cb.value = clean;
                            const label = cb.closest('.assign-item');
                            if (label) {
                                const span = label.querySelector('span');
                                if (span) span.textContent = clean;
                            }
                        }
                    });

                    renderAssignedList();
                }
                return;
            }

            /* ----- REMOVE ----- */
            if (removeBtn) {
                const idx = parseInt(removeBtn.dataset.idx, 10);
                const removed = currentAssigned[idx];

                if (confirm('Remove "' + removed + '" from assigned engineers?')) {
                    currentAssigned.splice(idx, 1);

                    assignList.querySelectorAll('.assign-checkbox').forEach(function (cb) {
                        if (cb.value === removed) {
                            cb.checked = false;
                            cb.disabled = false;
                            const item = cb.closest('.assign-item');
                            if (item) item.style.opacity = '';
                        }
                    });

                    renderAssignedList();
                }
            }
        });
    }


    /* ---------- Header button → ADD mode ---------- */
    const openBtn = document.getElementById('openStructureModalBtn');
    if (openBtn) {
        openBtn.addEventListener('click', function () {
            setAddMode();
        });
    }


    /* ---------- Save / Update button ---------- */
    if (saveBtn) {
        saveBtn.addEventListener('click', function () {

            if (!stCompany.value || !stProject.value || !stType.value ||
                !stFrom.value || !stTo.value) {
                alert('Please fill all fields before saving.');
                return;
            }

            if (currentMode === 'edit' && editingRow) {
                updateRowFromForm(editingRow);
            } else {
                const tr = buildRowFromForm();
                tbody.appendChild(tr);
                bindRow(tr);
            }

            if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).hide();

            setAddMode();

            /* Reapply filters after DOM change */
            applyFilters();
        });
    }


    /* ---------- Update row from form ---------- */
    function updateRowFromForm(row) {
        if (!row) return;

        const cells = row.querySelectorAll('td');

        if (cells[0]) cells[0].innerHTML = '<span class="scrap-desc">' + stCompany.value + '</span>';
        if (cells[1]) cells[1].innerHTML = '<span class="scrap-desc">' + stProject.value + '</span>';
        if (cells[2]) cells[2].innerHTML = '<span class="scrap-desc">' + stType.value + '</span>';
        if (cells[4]) cells[4].innerHTML = '<span class="scrap-desc">' + stFrom.value + '</span>';
        if (cells[5]) cells[5].innerHTML = '<span class="scrap-desc">' + stTo.value + '</span>';
    }


    /* ---------- Build new row from form ---------- */
    function buildRowFromForm() {
        const tr = document.createElement('tr');
        tr.className = 'structure-row';

        tr.innerHTML =
            '<td><span class="scrap-desc">' + stCompany.value + '</span></td>' +
            '<td><span class="scrap-desc">' + stProject.value + '</span></td>' +
            '<td><span class="scrap-desc">' + stType.value + '</span></td>' +
            '<td class="text-center engineer-cell">' +
                '<button type="button" class="struct-sync-btn" title="Assign site engineer">' +
                    '<i class="mdi mdi-sync"></i>' +
                '</button>' +
            '</td>' +
            '<td><span class="scrap-desc">' + stFrom.value + '</span></td>' +
            '<td><span class="scrap-desc">' + stTo.value + '</span></td>' +
            '<td class="text-center">' +
                '<div class="scrap-action-buttons">' +
                    '<button type="button" class="scrap-action-btn scrap-view" title="View">' +
                        '<i class="mdi mdi-eye-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="scrap-action-btn scrap-edit" title="Edit">' +
                        '<i class="mdi mdi-pencil-outline"></i>' +
                    '</button>' +
                    '<button type="button" class="scrap-action-btn scrap-delete" title="Delete">' +
                        '<i class="mdi mdi-trash-can-outline"></i>' +
                    '</button>' +
                '</div>' +
            '</td>';

        return tr;
    }


    /* ---------- Bind existing rows ---------- */
    document.querySelectorAll('#structureTableBody .structure-row').forEach(bindRow);

    /* ---------- Restore any saved engineers from localStorage ---------- */
    loadEngineers();

    /* ---------- Apply initial filters ---------- */
    applyFilters();

});
</script>

@endsection