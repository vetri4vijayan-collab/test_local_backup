@extends('layouts/layoutMaster')

@section('title', 'Structure Details')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection


@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection




@section('content')

<div class="container-fluid py-3">

    {{-- ===================== BACK BUTTON ===================== --}}
    <div class="mb-3">
        <button type="button"
                class="btn btn-sm btn-light border d-inline-flex align-items-center gap-1 px-3"
                id="svBackBtn"
                style="height:34px;">
            <i class="mdi mdi-chevron-left"></i>
            <span>Back</span>
        </button>
    </div>


    {{-- ===================== STRUCTURE DETAILS CARD ===================== --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">

        {{-- Header row: title on the left, contractor badge centered --}}
        <div class="card-body p-3 p-md-4 pb-2">
            <div class="sv-header-row">

                <h6 class="fw-bold mb-0 text-uppercase sv-header-title"
                    style="font-size:12.5px;letter-spacing:.05em;color:#6b7280;">
                    Structure Details
                </h6>

                <span class="badge rounded-pill sv-contractor-badge"
                      style="background:#29ABE2; color:#fff; font-size:12px; font-weight:600; padding:7px 18px;">
                    No. of Contractors : <span id="svContractorCount">1</span>
                </span>

                {{-- Spacer to balance the flex layout so the badge stays centered --}}
                <span class="sv-header-spacer" aria-hidden="true"></span>

            </div>
        </div>

        <hr class="my-0" style="border-color:#16659E; opacity:1;">

        <div class="card-body p-4 p-md-5">

            {{-- 2 rows × 3 columns of label / value pairs --}}
            <div class="row gy-4 gx-4 gx-md-5">

                <div class="col-12 col-md-4">
                    <span class="sv-label">Company:</span>
                    <span class="sv-value" id="svCompany">SRK Infra Developers</span>
                </div>

                <div class="col-12 col-md-4">
                    <span class="sv-label">Project Name:</span>
                    <span class="sv-value" id="svProject">Water Treatment Plant Setup</span>
                </div>

                <div class="col-12 col-md-4">
                    <span class="sv-label">Site Engineer Name:</span>
                    <span class="sv-value" id="svEngineer"></span>
                </div>

                <div class="col-12 col-md-4">
                    <span class="sv-label">Structure Type:</span>
                    <span class="sv-value" id="svType">Water Treatment Plant Structure</span>
                </div>

                <div class="col-12 col-md-4">
                    <span class="sv-label">Chainage From:</span>
                    <span class="sv-value" id="svFrom">0+000</span>
                </div>

                <div class="col-12 col-md-4">
                    <span class="sv-label">Chainage To:</span>
                    <span class="sv-value" id="svTo">0+120</span>
                </div>

            </div>

        </div>

    </div>


    {{-- ===================== STRUCTURE ITEMS CARD ===================== --}}
    <div class="card shadow-sm border-0 rounded-3 mb-4">

        <div class="card-body p-3 p-md-4 pb-2">
            <h6 class="fw-bold mb-0 text-uppercase"
                style="font-size:12.5px;letter-spacing:.05em;color:#6b7280;">
                Structure Items
            </h6>
        </div>

        <hr class="my-0" style="border-color:#16659E; opacity:1;">

        {{-- Search row --}}
        <div class="d-flex justify-content-end align-items-center gap-2 px-3 px-md-4 py-3">
            <label for="svSearch" class="mb-0 small text-muted">Search:</label>
            <input type="text"
                   id="svSearch"
                   class="form-control form-control-sm"
                   style="width:200px;"
                   autocomplete="off">
        </div>

        {{-- Table --}}
        <div class="table-responsive">
            <table class="table sv-table mb-0" id="svTable">

                <thead>
                    <tr>
                        <th class="text-start">
                            Structure Type Item
                            <i class="mdi mdi-swap-vertical sv-sort-icon"></i>
                        </th>
                        <th class="text-start">
                            Description
                            <i class="mdi mdi-swap-vertical sv-sort-icon"></i>
                        </th>
                    </tr>
                </thead>

                <tbody id="svTableBody">
                    <tr>
                        <td>RCC Tank Construction</td>
                        <td>Raw water storage tank construction with reinforced concrete design</td>
                    </tr>
                </tbody>

            </table>
        </div>

    </div>

</div>



<style>

/* ---------- Header row: 3-column grid for true centering ---------- */
.sv-header-row {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
}

.sv-header-title {
    justify-self: start;
}

.sv-header-spacer {
    display: block;
}

/* ---------- Label / value pairs ---------- */
.sv-label {
    color: #4b5563;
    font-size: 13px;
    font-weight: 500;
    margin-right: 4px;
}

.sv-value {
    color: #111827;
    font-size: 13px;
    font-weight: 700;
}

/* ---------- Table ---------- */
.sv-table {
    width: 100% !important;
    border-collapse: collapse !important;
    font-size: 12.5px;
}

.sv-table thead th {
    background: #ffffff;
    color: #111827;
    font-size: 11.5px;
    font-weight: 700;
    padding: 12px 24px;
    border-top: 1px solid #eef0f4;
    border-bottom: 1px solid #d9dee3;
    white-space: nowrap;
    vertical-align: middle;
}

.sv-table tbody td {
    padding: 14px 24px;
    border-bottom: 1px solid #eef0f4;
    vertical-align: middle;
    color: #111827;
    font-size: 12.5px;
    font-weight: 500;
    background: #ffffff;
}

.sv-table tbody tr:last-child td {
    border-bottom: 0;
}

.sv-table tbody tr:hover td {
    background: #fbfdff;
}

.sv-sort-icon {
    font-size: 12px;
    color: #b0b8c1;
    margin-left: 4px;
    vertical-align: middle;
}

/* ---------- Contractor badge ---------- */
.sv-contractor-badge {
    box-shadow: 0 2px 6px rgba(41,171,226,.25);
    justify-self: center;
}

</style>



<script>
document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Back button → Manage Structure page ---------- */
    const backBtn = document.getElementById('svBackBtn');
    if (backBtn) {
        backBtn.addEventListener('click', function () {
            window.location.href = "{{ route('site.manage-structure') }}";
        });
    }


    /* ---------- Read row data from URL params ---------- */
    const urlParams = new URLSearchParams(window.location.search);

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el && value) el.textContent = value;
    }

    setText('svCompany',  urlParams.get('company'));
    setText('svProject',  urlParams.get('project'));
    setText('svType',     urlParams.get('type'));
    setText('svFrom',     urlParams.get('from'));
    setText('svTo',       urlParams.get('to'));
    setText('svEngineer', urlParams.get('engineer'));


    /* ---------- Search box ---------- */
    const searchIn = document.getElementById('svSearch');
    const tbody    = document.getElementById('svTableBody');
    const info     = document.getElementById('svEntriesInfo');

    if (searchIn) {
        searchIn.addEventListener('input', function () {
            const term = searchIn.value.toLowerCase().trim();
            let visible = 0;

            tbody.querySelectorAll('tr').forEach(function (row) {
                const match = term === '' || row.innerText.toLowerCase().includes(term);
                row.style.display = match ? '' : 'none';
                if (match) visible++;
            });

            if (info) info.textContent = '1 - ' + visible + ' of ' + visible + ' entries';
        });
    }

});
</script>

@endsection