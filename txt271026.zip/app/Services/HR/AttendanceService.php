<?php

namespace App\Services\HR;

use App\Models\HR\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AttendanceService
{
    public function __construct(private StaffService $staffService) {}

    public function paginate(string $type, array $filters)
    {
        $query = StaffAttendanceModel::query()->from('ryans_staff_attendance as a')
            ->join('ryans_staff as s', 's.sno', '=', 'a.staff_id')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id');

        $this->staffService->applyCategoryScope($query, 's', $type);

        $this->staffService->applyNotDeletedScope($query, 's');

        $query->where('a.status', 0);
        
        if (($filters['search'] ?? '') !== '') {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => 
                $q->where('s.staff_name', 'like', $term)
                    ->orWhere('s.staff_id', 'like', $term)
                    ->orWhere('a.attendance', 'like', $term)
                    ->orWhere('d.department_name', 'like', $term)
            );
        }

        if (!empty($filters['month']) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $filters['month'])){
            $query->whereRaw("DATE_FORMAT(a.date, '%Y-%m') = ?", [$filters['month']]);
        } 

        if (!empty($filters['date'])){
            $query->whereDate('a.date', $filters['date']);
        } 

        $sortMap = [
            'date' => 'a.date',
            'staff' => 's.staff_name', 
            'department' => 'd.department_name', 
            'status' => 'a.attendance', 
            'in_time' => 'a.in_time', 
            'out_time' => 'a.out_time'
        ];

        $sort = $filters['sort'] ?? 'date';

        $direction = strtolower((string) ($filters['direction'] ?? 'desc')) === 'asc' ? 'asc' : 'desc';

        $query->orderBy($sortMap[$sort] ?? $sortMap['date'], $direction)
                ->orderBy('a.sno', 'desc');

        return $query->select([
            'a.sno as id', 
            'a.date', 
            'a.attendance', 
            'a.in_time', 
            'a.out_time', 
            'a.type', 
            'a.reason',
            's.sno as staff_pk', 
            's.staff_id as staff_code', 
            's.staff_name', 
            's.mobile_no', 
            'd.department_name'
        ])->paginate((int) ($filters['per_page'] ?? 10))
        ->withQueryString();
    }

    /** Monthly matrix feed for the existing table and calendar screens. */
    public function matrix(string $type, array $filters): array
    {
        $month = (string) ($filters['month'] ?? now()->format('Y-m'));
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            throw ValidationException::withMessages(['month' => 'Month must use YYYY-MM format.']);
        }
        $first = $month . '-01';
        $last = date('Y-m-t', strtotime($first));
        $query = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        if (!empty($filters['department_id'])) $query->where('s.department_id', (int) $filters['department_id']);
        if (!empty($filters['department']) && $filters['department'] !== 'ALL') $query->where('d.department_name', (string) $filters['department']);
        if (!empty($filters['search'])) {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $term)
                ->orWhere('s.staff_id', 'like', $term)->orWhere('d.department_name', 'like', $term));
        }
        $page = $query->orderBy('s.staff_name')->select([
            's.sno as id', 's.staff_id', 's.staff_name as name', 's.mobile_no',
            's.department_id', 'd.department_name as department', 's.designation_id', 'dg.designation',
        ])->paginate((int) ($filters['per_page'] ?? 50))->withQueryString();
        $ids = $page->getCollection()->pluck('id')->map(fn ($id) => (int) $id)->all();
        $rows = $ids ? DB::table('ryans_staff_attendance')->whereIn('staff_id', $ids)
            ->where('status', 0)->whereBetween('date', [$first, $last])
            ->orderBy('date')->orderBy('sno')->get([
                'sno', 'staff_id', 'date', 'attendance', 'in_time', 'out_time', 'type', 'reason'
            ]) : collect();
        $attendance = [];
        foreach ($rows as $row) {
            $date = (string) $row->date;
            $attendance[(int) $row->staff_id][$date] = [
                'id' => (int) $row->sno, 'attendance' => (string) $row->attendance,
                'in_time' => $row->in_time, 'out_time' => $row->out_time,
                'type' => $row->type, 'reason' => $row->reason,
            ];
        }
        return [
            'data' => $page->items(),
            'attendance' => $attendance,
            'meta' => ['current_page' => $page->currentPage(), 'last_page' => $page->lastPage(), 'per_page' => $page->perPage(), 'total' => $page->total()],
            'month' => $month,
            'days_in_month' => (int) date('t', strtotime($first)),
        ];
    }

    public function saveManual(string $type, array $data, int $actor): void
    {
        $employment = $this->staffService->employmentValue($type);
        $staff = DB::table('ryans_staff as s')->where('s.sno', (int) $data['staff_id'])
            ->where(function ($q) use ($employment) {
                $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                    $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                        $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                    });
                });
            })->first(['s.sno', 's.status', 's.hr_status']);
        if (!$staff || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) === 2) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category or is deleted.']);
        DB::transaction(function () use ($data, $actor) {
            $existing = StaffAttendanceModel::query()->where('staff_id', (int) $data['staff_id'])->whereDate('date', $data['date'])->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            $now = now();
            if ($existing) {
                foreach (['attendance', 'in_time', 'out_time', 'type', 'reason'] as $field) if (array_key_exists($field, $data)) $existing->{$field} = $data[$field];
                $existing->updated_by = $actor; $existing->updated_at = $now; $existing->save();
                return;
            }
            StaffAttendanceModel::query()->create([
                'staff_attendance_id' => 'ATT-' . $data['staff_id'] . '-' . str_replace('-', '', $data['date']),
                'date' => $data['date'], 'staff_id' => (int) $data['staff_id'], 'attendance' => $data['attendance'],
                'in_time' => $data['in_time'] ?? null, 'out_time' => $data['out_time'] ?? null,
                'type' => $data['type'] ?? 'Manual', 'reason' => $data['reason'] ?? null,
                'created_by' => $actor, 'updated_by' => $actor, 'status' => 0,
            ]);
        }, 3);
    }

    public function checkIn(int $staffId, int $employment, int $actor): array
    {
        return DB::transaction(function () use ($staffId, $employment, $actor) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw ValidationException::withMessages(['staff' => 'Active staff profile was not found for this account.']);
            }
            $today = now()->toDateString();
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', $today)->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if ($row && $row->in_time) throw ValidationException::withMessages(['check_in' => 'You have already checked in today.']);
            if ($row) {
                $row->attendance = 'P'; $row->in_time = now()->format('H:i:s'); $row->type = 'Mobile'; $row->updated_by = $actor; $row->save();
            } else {
                $row = StaffAttendanceModel::query()->create([
                    'staff_attendance_id' => 'ATT-' . $staffId . '-' . now()->format('Ymd'), 'date' => $today,
                    'staff_id' => $staffId, 'attendance' => 'P', 'in_time' => now()->format('H:i:s'),
                    'type' => 'Mobile', 'reason' => null, 'created_by' => $actor, 'updated_by' => $actor, 'status' => 0,
                ]);
            }
            return ['id' => $row->sno, 'date' => $today, 'in_time' => $row->in_time, 'attendance' => $row->attendance];
        }, 3);
    }

    public function checkOut(int $staffId, int $employment, int $actor): array
    {
        return DB::transaction(function () use ($staffId, $employment, $actor) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw ValidationException::withMessages(['staff' => 'Active staff profile was not found for this account.']);
            }
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', now()->toDateString())->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if (!$row || !$row->in_time) throw ValidationException::withMessages(['check_out' => 'Check-in is required before check-out.']);
            if ($row->out_time) throw ValidationException::withMessages(['check_out' => 'You have already checked out today.']);
            $row->out_time = now()->format('H:i:s'); $row->updated_by = $actor; $row->save();
            return ['id' => $row->sno, 'date' => (string) $row->date, 'in_time' => $row->in_time, 'out_time' => $row->out_time];
        }, 3);
    }

    public function history(int $staffId, string $month, int $perPage = 31)
    {
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) throw ValidationException::withMessages(['month' => 'Month must use YYYY-MM format.']);
        return StaffAttendanceModel::query()->where('staff_id', $staffId)->where('status', 0)->whereRaw("DATE_FORMAT(`date`, '%Y-%m') = ?", [$month])->orderBy('date')->paginate($perPage);
    }

    private function legacyStatus(int $status): int
    {
        return match ($status) { 0 => 0, 1,4 => 1, 2 => 2, 5,6,7 => 3, default => 3 };
    }
}
