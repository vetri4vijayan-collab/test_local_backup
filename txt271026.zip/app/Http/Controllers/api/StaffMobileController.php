<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Services\HR\AttendanceService;
use App\Services\HR\LeaveService;
use App\Services\HR\MobileAuthService;
use App\Services\HR\StaffService;
use Illuminate\Http\Request;

class StaffMobileController extends Controller
{
    public function __construct(
        private MobileAuthService $mobileAuthService,
        private StaffService $staffService,
        private AttendanceService $attendanceService,
        private LeaveService $leaveService
    ) {}

    public function login(Request $request)
    {
        $v = $request->validate([
            'identifier' => ['required_without:email', 'string', 'max:190'],
            'email' => ['required_without:identifier', 'nullable', 'email', 'max:190'],
            'password' => ['required', 'string', 'max:200'],
        ]);
        $identifier = $v['identifier'] ?? $v['email'];
        return response()->json(['success' => true, 'data' => $this->mobileAuthService->login($identifier, $v['password'])]);
    }

    public function profile(Request $request)
    {
        $mapping = $this->mobileAuthService->staffForUser($request->user());
        $detail = $this->staffService->find($mapping['staff_id']);
        $staff = (array) $detail['staff'];
        unset($staff['password'], $staff['user_name'], $staff['credential']);
        return response()->json(['success' => true, 'data' => ['staff' => $staff, 'profile' => $detail['profile'], 'remuneration' => $detail['remuneration'],
            'education' => $detail['education'], 'experience' => $detail['experience'],
            'family' => $detail['family'], 'attachments' => $detail['attachments']]]);
    }

    public function leaveRequest(Request $request)
    {
        $mapping = $this->mobileAuthService->staffForUser($request->user());
        $v = $request->validate(['leave_type' => ['required', 'string', 'max:80'], 'from_date' => ['required', 'date', 'after_or_equal:today'], 'to_date' => ['required', 'date', 'after_or_equal:from_date'], 'reason' => ['required', 'string', 'max:2000']]);
        $leave = $this->leaveService->createRequest($mapping['staff_id'], $v);
        return response()->json(['success' => true, 'message' => 'Leave request submitted for approval.', 'data' => $leave], 201);
    }

    public function checkIn(Request $request)
    {
        $mapping = $this->mobileAuthService->staffForUser($request->user());
        $data = $this->attendanceService->checkIn($mapping['staff_id'], $mapping['employment_type'], (int) $request->user()->user_id);
        return response()->json(['success' => true, 'message' => 'Checked in successfully.', 'data' => $data]);
    }

    public function checkOut(Request $request)
    {
        $mapping = $this->mobileAuthService->staffForUser($request->user());
        $data = $this->attendanceService->checkOut($mapping['staff_id'], $mapping['employment_type'], (int) $request->user()->user_id);
        return response()->json(['success' => true, 'message' => 'Checked out successfully.', 'data' => $data]);
    }

    public function attendanceHistory(Request $request)
    {
        $mapping = $this->mobileAuthService->staffForUser($request->user());
        $v = $request->validate(['month' => ['required', 'date_format:Y-m'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100']]);
        $p = $this->attendanceService->history($mapping['staff_id'], $v['month'], (int) ($v['per_page'] ?? 31));
        return response()->json(['success' => true, 'data' => $p->items(), 'meta' => ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()]]);
    }
}
