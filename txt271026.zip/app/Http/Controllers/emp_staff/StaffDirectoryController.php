<?php

namespace App\Http\Controllers\emp_staff;

use App\Http\Controllers\Controller;
use App\Services\HR\StaffService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class StaffDirectoryController extends Controller
{
    public function __construct(private StaffService $staffService) {}

    public function options()
    {
        return response()->json([
            'success' => true, 
            'data' => $this->staffService->options()
        ]);
    }

    public function unclassified(Request $request)
    {
        $perPage = max(5, min(100, (int) $request->query('per_page', 10)));
        $page = $this->staffService->unclassified($perPage);
        return response()->json([
            'success' => true, 
            'data' => $page->items(), 
            'meta' => $this->meta($page)
        ]);
    }

    public function index(Request $request, string $type)
    {
        $this->staffService->employmentValue($type); // rejects unrecognized category
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'], 
            'department_id' => ['nullable', 'integer', 'min:1'],
            'status' => ['nullable', 'integer', Rule::in([0, 1, 3])],
            'sort' => ['nullable', Rule::in(['name', 'staff_id', 'email', 'mobile', 'department', 'designation', 'wage', 'status', 'joining_date'])],
            'direction' => ['nullable', Rule::in(['asc', 'desc'])], 
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $page = $this->staffService->paginate($type, array_merge(['per_page' => 10], $filters));

        return response()->json([
            'success' => true, 
            'data' => $page->items(), 
            'meta' => $this->meta($page)
        ]);
    }

    public function show(int $id)
    {
        $detail = $this->staffService->find($id);
        return response()->json(['success' => true, 'data' => array_merge((array) $detail['staff'], [
            'profile' => $detail['profile'], 'remuneration' => $detail['remuneration'],
            'education' => $detail['education'], 'experience' => $detail['experience'],
            'family' => $detail['family'], 'attachments' => $detail['attachments'],
        ])]);
    }

    public function store(Request $request, string $type)
    {
        $this->staffService->employmentValue($type);
        $data = $request->validate([
            'staff_name' => ['required', 'string', 'max:180'],
            'department_id' => ['required', 'integer', Rule::exists('ryans_department', 'sno')->where('status', 0)],
            'designation_id' => ['nullable', 'integer', Rule::exists('rayans_designation', 'sno')->where('status', 0)],
            'job_role_id' => ['nullable', 'integer', Rule::exists('ryans_job_role', 'sno')->where('status', 0)],
            'division_id' => ['nullable', 'integer', 'min:0'],
            'role_id' => ['required_if:login_access,1', 'nullable', 'integer', Rule::exists('ryans_user_role', 'sno')->where('status', 0)],
            'mobile_no' => ['nullable', 'regex:/^[0-9+()\-\s]{7,20}$/'],
            'email_id' => ['nullable', 'email', 'max:190'], 
            'gender' => ['nullable', Rule::in(['Male', 'Female', 'Other', '1', '2', '3'])],
            'dob' => ['nullable', 'date', 'before:today'], 
            'date_of_joining' => ['nullable', 'date'],
            'staff_last_date' => ['nullable', 'date', 'after_or_equal:date_of_joining'],
            'alternative_no' => ['nullable', 'string', 'max:30'], 
            'address' => ['nullable', 'string', 'max:5000'],
            'residential_address' => ['nullable', 'string', 'max:5000'], 
            'contact_person_name' => ['nullable', 'string', 'max:180'],
            'contact_person_no' => ['nullable', 'string', 'max:40'],
            'relation_id' => ['nullable', 'integer', Rule::exists('ryans_relationship', 'sno')->where('status', 0)],
            'blood_group_id' => ['nullable', 'integer', Rule::exists('rayans_blood_group', 'sno')->where('status', 0)],
            'martial_status' => ['nullable', Rule::in([0, 1, 2, 3, 4])], 'mother_tongue' => ['nullable', 'string', 'max:150'],
            'languages' => ['nullable', 'array'], 
            'languages.*' => ['integer', Rule::exists('ryans_languages', 'sno')->where('status', 0)],
            'hobby' => ['nullable', 'string', 'max:2000'], 
            'description' => ['nullable', 'string', 'max:5000'],
            'basic_salary' => ['nullable', 'numeric', 'min:0', 'max:999999999'], 
            'per_hour_cost' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'login_access' => ['nullable', 'boolean'], 
            'username' => ['required_if:login_access,1', 'nullable', 'string', 'max:100', 'regex:/^[A-Za-z0-9._-]{3,100}$/'],
            'login_pin' => ['required_if:login_access,1', 'nullable', 'regex:/^[0-9]{4,6}$/'],
            'profile_photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'profile_data' => ['nullable', 'array'],
            'remuneration' => ['nullable', 'array'], 
            'remuneration.*.type_id' => ['required', 'integer'],
            'remuneration.*.amount' => ['required', 'numeric', 'min:0', 'max:999999999'],
        ]);
        $id = $this->staffService->create($type, $data, $request->file('profile_photo'), $this->actor($request));
        return response()->json([
            'success' => true, 
            'message' => 'Staff created successfully.', 
            'data' => [
                'id' => $id
            ]
        ], 201);
    }

    public function update(Request $request, int $id)
    {
        $data = $request->validate([
            'staff_name' => ['sometimes', 'required', 'string', 'max:180'],
            'department_id' => ['sometimes', 'required', 'integer', Rule::exists('ryans_department', 'sno')->where('status', 0)],
            'designation_id' => ['sometimes', 'nullable', 'integer', Rule::exists('rayans_designation', 'sno')->where('status', 0)],
            'job_role_id' => ['sometimes', 'nullable', 'integer', Rule::exists('ryans_job_role', 'sno')->where('status', 0)],
            'division_id' => ['sometimes', 'nullable', 'integer', 'min:0'],
            'role_id' => ['sometimes', 'nullable', 'integer', Rule::exists('ryans_user_role', 'sno')->where('status', 0)],
            'mobile_no' => ['sometimes', 'nullable', 'regex:/^[0-9+()\-\s]{7,20}$/'], 
            'email_id' => ['sometimes', 'nullable', 'email', 'max:190'],
            'gender' => ['sometimes', 'nullable', Rule::in(['Male', 'Female', 'Other', '1', '2', '3'])], 
            'dob' => ['sometimes', 'nullable', 'date', 'before:today'],
            'date_of_joining' => ['sometimes', 'nullable', 'date'], 
            'staff_last_date' => ['sometimes', 'nullable', 'date'],
            'alternative_no' => ['sometimes', 'nullable', 'string', 'max:30'], 
            'address' => ['sometimes', 'nullable', 'string', 'max:5000'],
            'residential_address' => ['sometimes', 'nullable', 'string', 'max:5000'], 
            'contact_person_name' => ['sometimes', 'nullable', 'string', 'max:180'],
            'contact_person_no' => ['sometimes', 'nullable', 'string', 'max:40'], 
            'relation_id' => ['sometimes', 'nullable', 'integer', Rule::exists('ryans_relationship', 'sno')->where('status', 0)],
            'blood_group_id' => ['sometimes', 'nullable', 'integer', Rule::exists('rayans_blood_group', 'sno')->where('status', 0)],
            'martial_status' => ['sometimes', 'nullable', Rule::in([0, 1, 2, 3, 4])], 
            'mother_tongue' => ['sometimes', 'nullable', 'string', 'max:150'],
            'languages' => ['sometimes', 'nullable', 'array'], 
            'languages.*' => ['integer', Rule::exists('ryans_languages', 'sno')->where('status', 0)],
            'hobby' => ['sometimes', 'nullable', 'string', 'max:2000'], 
            'description' => ['sometimes', 'nullable', 'string', 'max:5000'],
            'basic_salary' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:999999999'], 
            'per_hour_cost' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:999999999'],
            'username' => ['sometimes', 'nullable', 'string', 'max:100', 'regex:/^[A-Za-z0-9._-]{3,100}$/'],
            'dep_reason' => ['sometimes', 'nullable', 'string', 'max:1000'], 
            'profile_data' => ['sometimes', 'nullable', 'array'],
            'remuneration' => ['sometimes', 'array'], 
            'remuneration.*.type_id' => ['required', 'integer'], 
            'remuneration.*.amount' => ['required', 'numeric', 'min:0', 'max:999999999'],
            'education' => ['sometimes', 'array'], 
            'education.*.qualification_type' => ['nullable', 'integer', 'min:0'],
            'education.*.degree_name' => ['nullable', 'string', 'max:255'], 
            'education.*.major' => ['nullable', 'string', 'max:255'],
            'education.*.university_name' => ['nullable', 'string', 'max:255'], 
            'education.*.year' => ['nullable', 'string', 'max:50'],
            'education.*.grade' => ['nullable', 'string', 'max:80'],
            'experience' => ['sometimes', 'array'], 
            'experience.*.position' => ['nullable', 'string', 'max:255'],
            'experience.*.company_name' => ['nullable', 'string', 'max:255'], 
            'experience.*.period' => ['nullable', 'string', 'max:100'],
            'experience.*.start_date' => ['nullable', 'date'], 
            'experience.*.end_date' => ['nullable', 'date', 'after_or_equal:experience.*.start_date'],
            'experience.*.year_of_experience' => ['nullable', 'integer', 'min:0', 'max:80'], 
            'experience.*.salary' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'experience.*.responsibilities' => ['nullable', 'string', 'max:5000'], 
            'experience.*.exit_reason' => ['nullable', 'string', 'max:1000'],
            'profile_photo' => ['sometimes', 'nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);
        $this->staffService->update($id, $data, $request->file('profile_photo'), $this->actor($request));
        return response()->json([
            'success' => true, 
            'message' => 'Staff profile updated successfully.'
        ]);
    }

    public function status(Request $request, int $id)
    {
        $data = $request->validate([
            'status' => ['required', 'integer', Rule::in([0, 1, 3])],
            'exit_reason' => ['required_if:status,3', 'nullable', 'string', 'max:1000'],
            'staff_last_date' => ['required_if:status,3', 'nullable', 'date'],
        ]);
        $this->staffService->setStatus(
            $id,
            (int) $data['status'],
            $data['exit_reason'] ?? null,
            $data['staff_last_date'] ?? null,
            $this->actor($request)
        );
        return response()->json([
            'success' => true, 
            'message' => 'Staff status updated.'
        ]);
    }

    public function destroy(Request $request, int $id)
    {
        $this->staffService->delete($id, $this->actor($request));
        return response()->json([
            'success' => true, 
            'message' => 'Staff moved to deleted status.'
        ]);
    }

    public function classify(Request $request, int $id)
    {
        $data = $request->validate(['employment_type' => ['required', Rule::in(['permanent', 'contract'])]]);
        $this->staffService->classify($id, $data['employment_type'], $this->actor($request));
        return response()->json([
            'success' => true, 
            'message' => 'Employment category assigned.'
        ]);
    }

    private function actor(Request $request): int
    {
        return (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1)));
    }

    private function meta($paginator): array
    {
        return [
            'current_page' => $paginator->currentPage(), 
            'last_page' => $paginator->lastPage(), 
            'per_page' => $paginator->perPage(), 
            'total' => $paginator->total()
        ];
    }
}
