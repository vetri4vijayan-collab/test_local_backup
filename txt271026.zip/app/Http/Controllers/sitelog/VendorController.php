<?php

namespace App\Http\Controllers\sitelog;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\VendorSettingsModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\VendorModel;

class VendorController extends Controller
{
  public function vendor_controller (Request $request)
  {
    $perpage = (int) $request->input('sorting_filter', 10);
    $page = $request->input('page', 1);

    $search_filter = $request->input('search_filter', '');

    $helper = new \App\Helpers\Helpers();
    $level = VendorModel::where('ryans_vendors.status', '!=', 2)
        ->select('ryans_vendors.*','ryans_countries.country_name as country_name','ryans_states.state_name as state_name',
            'ryans_cities.city_name as city_name','ryans_vendor_type.vendor_name as vendor_name')
        ->join('ryans_countries','ryans_vendors.country_id','=','ryans_countries.sno')
        ->join('ryans_states','ryans_vendors.state_id', '=', 'ryans_states.sno')
        ->join('ryans_cities','ryans_vendors.city_id','=','ryans_cities.sno')
        ->join( 'ryans_vendor_type','ryans_vendors.vendor_type_id','=','ryans_vendor_type.sno');

    // Search filter
    if ($search_filter !== '') {
        $level->where(function ($query) use ($search_filter) {
            $query->where('ryans_vendors.vendor_company_name', 'LIKE', "%{$search_filter}%")
            ->orWhere('ryans_vendors.vendor_company_name','LIKE',"%{$search_filter}%")
            ->orWhere('ryans_vendors.vendor_code','LIKE',"%{$search_filter}%");
        });
    }
  

    $level = $level
        ->orderBy('ryans_vendors.sno', 'ASC')
        ->paginate($perpage);

    if ($request->ajax()) {
        $items = $level->getCollection();

        $items->transform(function ($item) {
            $banks = $item->banks ?? [];
            
            if (is_string($banks)) {
                $banks = json_decode($banks, true) ?? [];
            }
            if (!is_array($banks)) {
                $banks = [];
            }
            $item->primary_bank = $banks[0] ?? [];

            $persons = $item->persons ?? [];
            if (is_string($persons)) {
                $persons = json_decode($persons, true) ?? [];
            }
            if (!is_array($persons)) {
                $persons = [];
            }
            $item->primary_person = $persons[0] ?? [];

            return $item;
        });
        $countryIds = [];
        $stateIds = [];
        $cityIds = [];


        foreach ($items as $item) {
            $bank = $item->primary_bank;

            if (!empty($bank['bank_country'])) {
                $countryIds[] = $bank['bank_country'];
            }

            if (!empty($bank['bank_state'])) {
                $stateIds[] = $bank['bank_state'];
            }

            if (!empty($bank['bank_city'])) {
                $cityIds[] = $bank['bank_city'];
            }
        }

        // Fetch location names
        $countries = \DB::table('ryans_countries')
            ->whereIn('sno', array_unique($countryIds))
            ->pluck('country_name', 'sno');

        $states = \DB::table('ryans_states')
            ->whereIn('sno', array_unique($stateIds))
            ->pluck('state_name', 'sno');

        $cities = \DB::table('ryans_cities')
            ->whereIn('sno', array_unique($cityIds))
            ->pluck('city_name', 'sno');

     
        // Prepare AJAX response
        $data = $items->map(function ($item) use (
            $countries,
            $states,
            $cities,
        ) {
            $bank = $item->primary_bank;
            $persons =$item->primary_person;
            $countryId = $bank['bank_country'] ?? null;
            $stateId = $bank['bank_state'] ?? null;
            $cityId = $bank['bank_city'] ?? null;   


            return [
                'sno' => $item->sno,
                'vendor_code' => $item->vendor_code,
                'vendor_type' => $item->vendor_name,
                'vendor_company_name' => $item->vendor_company_name,
                'vendor_name' => $item->vendor_name,
                'country_name' => $item->country_name,
                'state_name' => $item->state_name,
                'city_name' => $item->city_name,
                'address' => $item->address,
                'gst_number' => $item->gst_number,
                'pan_number' => $item->pan_number,
                'pin_code' => $item->pin_code,
                'supply_machine' => $item->supply_machinery,
               
                'primary_person_type' => $persons['person_type'] ?? null,
                'primary_person_name' => $persons['person_name'] ?? null,
                'primary_person_email' => $persons['person_email'] ?? null,
                'primary_person_number' => $persons['person_number'] ?? null,
                'primary_person_teleno' => $persons['person_teleno'] ?? null,
                'primary_bank_name' => $bank['bank_name'] ?? null,
                'primary_bank_branch' => $bank['bank_branch'] ?? null,
                'primary_bank_country_id' => $countryId,
                'primary_bank_country_name' => $countries->get($countryId),
                'primary_bank_state_id' => $stateId,
                'primary_bank_state_name' => $states->get($stateId),
                'primary_bank_city_id' => $cityId,
                'primary_bank_city_name' => $cities->get($cityId),
                'primary_bank_address' => $bank['bank_address'] ?? null,
                'primary_bank_pincode' => $bank['bank_pincode'] ?? null,
                'primary_acc_name' => $bank['bank_acc_name'] ?? null,
                'primary_acc_type' => $bank['bank_acc_type'] ?? null,
                'primary_acc_no' => $bank['bank_acc_number'] ?? null,
                'primary_bank_micr' => $bank['bank_micr'] ?? null,
                'primary_bank_ifsc' => $bank['bank_ifsc'] ?? null,

                'status' => $item->status,
                'item' => $item,
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $level->currentPage(),
            'last_page' => $level->lastPage(),
            'total' => $level->total(),
        ]);
    }

    $vendor_list = VendorSettingsModel::where('status', 0)
        ->select('sno', 'vendor_name')
        ->orderBy('vendor_name', 'asc')
        ->get();

    $country_list = CountryModel::where('status', 0)
        ->select('sno', 'country_name')
        ->orderBy('country_name', 'asc')
        ->get();

        $count=VendorModel::where('ryans_vendors.status','!=',2)
            ->count('ryans_vendors.sno');

    return view('content.sitelog.vendor',[
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'vendor_list' => $vendor_list,
        'country_list' => $country_list,
        'count' => $count,
    ]);
  }

  public function Add(Request $request)
{

    $user_id = $request->user()->user_id ?? 1;

    // Validation
    $validator = Validator::make($request->all(), [
        'country_id' => 'required|exists:ryans_countries,sno',
        'state_id' => 'required|exists:ryans_states,sno',
        'city_id' => 'required|exists:ryans_cities,sno',
        'vendorType' => 'required|exists:ryans_vendor_type,sno',

        'vendorCompany' => 'required|string|max:255',
        'vendorName' => 'required|string|max:255',
        'pin_code' => 'required|digits:6',
        'panNo' => 'required|string|max:10',
        'gstNo' => 'required|string|max:15',

        // Primary and Secondary persons
        'persons' => 'required|array|min:1',
        'persons.0.person_type' => 'required|in:1,2,3',
        'persons.0.person_name' => 'required|string|max:255',
        'persons.0.person_number' => 'required|string|max:20',

        'persons.*.person_type' => 'required|in:1,2,3',
        'persons.*.person_name' => 'required|string|max:255',
        'persons.*.person_number' => 'required|string|max:20',
        'persons.*.person_email' => 'nullable|email|max:255',
        'persons.*.person_teleno' => 'nullable|string|max:30',

        'banks' => 'required|array|min:1',
        'banks.0.bank_name' => 'required|string|max:255',
        'banks.0.bank_branch' => 'required|string|max:255',

        'banks.*.bank_name' => 'required|string|max:255',
        'banks.*.bank_branch' => 'required|string|max:255',
        'banks.*.bank_country' => 'required|exists:ryans_countries,sno',
        'banks.*.bank_state' => 'required|exists:ryans_states,sno',
        'banks.*.bank_city' => 'required|exists:ryans_cities,sno',
        'banks.*.bank_address' => 'required|string|max:255',
        'banks.*.bank_pincode' => 'required|digits:6',
        'banks.*.bank_acc_name' => 'required|string|max:255',
        'banks.*.bank_acc_type' => 'required|in:1,2,3',
        'banks.*.bank_acc_number' => 'required|string|max:50',
        'banks.*.bank_micr' => 'required|string|max:20',
        'banks.*.bank_ifsc' => 'required|string|max:20',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 401,
            'message' => 'Validation failed',
            'error_msg' => $validator->errors()->all(),
            'errors' => $validator->errors(),
            'data' => null,
        ], 200);
    }

    $vendor_type = $request->input('vendorType');
    $vendor_company_name = $request->input('vendorCompany');

    // Check duplicate vendor
    $check_vendor = VendorModel::where(
        'vendor_type_id',
        $vendor_type
    )
        ->where('vendor_company_name', $vendor_company_name)
        ->where('status', '!=', 2)
        ->first();

    if ($check_vendor) {
        return response()->json([
            'status' => 409,
            'message' => 'Vendor has already been created!',
            'data' => null,
        ], 200);
    }

    // Generate vendor code
    $category_check = VendorModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();

    $year = date('y');
    $month = date('m');

    if (!$category_check) {
        $vendor_code = 'VEN-001/' . $month . '/' . $year;
    } else {
        $data = $category_check->vendor_code;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int) $result + 1;
        $code_request = sprintf('VEN-%03d', $next_number);

        $vendor_code = $code_request . '/' . $month . '/' . $year;
    }

    
    $add_vendor = new VendorModel();

    $add_vendor->vendor_code = $vendor_code;
    $add_vendor->vendor_type_id = $vendor_type;
    $add_vendor->vendor_company_name = $vendor_company_name;
    $add_vendor->vendor_name = $request->vendorName;

    $add_vendor->country_id = $request->country_id;
    $add_vendor->state_id = $request->state_id;
    $add_vendor->city_id = $request->city_id;
    $add_vendor->address = $request->address;
    $add_vendor->pin_code = $request->pin_code;

    $add_vendor->gst_number = $request->gstNo;
    $add_vendor->pan_number = $request->panNo;
    $add_vendor->supply_machinery = $request->isSupply;
   
    // Store Primary and Secondary persons in one JSON column
    $persons = array_values($request->input('persons', []));

    // Mark the first person as Primary and the rest as Secondary
    foreach ($persons as $index => &$person) {
        $person['person_role'] = $index === 0 ? 'Primary' : 'Secondary';
    }
    unset($person);

    $banks = array_values($request->input('banks', []));
    foreach ($banks as $index => &$bank) {
        $bank['bank_role'] = $index === 0 ? 'Primary' : 'Secondary';
    }
    unset($bank);
    $add_vendor->persons = $persons;
    $add_vendor->banks = $banks;

    $add_vendor->created_by = $user_id;
    $add_vendor->updated_by = $user_id;

    $add_vendor->save();

    return response()->json([
        'status' => 200,
        'message' => 'Vendor added successfully',
        'data' => $add_vendor,
    ]);
}

public function BankStateList(Request $request)
  {
      $country_id = $request->country_id;
      $country = StateModel::where('status', 0)->where('country_id',$country_id)->get();
         
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $country
      ], 200);
  }
  public function BankCityList(Request $request)
  {
      $state_id = $request->state_id;
      $state = CityModel::where('status', 0)->where('state_id',$state_id)->get();
      
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $state
      ], 200);
  }

   public function VendorStateList(Request $request)
  {

      $country_id = $request->country_id;
      $country = StateModel::where('status', 0)->where('country_id',$country_id)->get();
         
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $country
      ], 200);
  }
  public function VendorCityList(Request $request)
  {
   
      $state_id = $request->state_id;
      $state = CityModel::where('status', 0)->where('state_id',$state_id)->get();
      
      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $state
      ], 200);
  }

  public function Delete($id)
    {
        $upd_vendorModel = VendorModel::where('sno', $id)->first();
        $upd_vendorModel->status = 2;
        $upd_vendorModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function View($id){
      
    $data = VendorModel::where('ryans_vendors.status', '!=', 2)
        ->select(
            'ryans_vendors.*',
            'ryans_countries.country_name as country_name',
            'ryans_states.state_name as state_name',
            'ryans_cities.city_name as city_name',
            'ryans_vendor_type.vendor_name as vendor_type'
        )
        ->join('ryans_countries','ryans_vendors.country_id','=','ryans_countries.sno')
        ->join('ryans_states','ryans_vendors.state_id','=','ryans_states.sno')
        ->join('ryans_cities', 'ryans_vendors.city_id', '=','ryans_cities.sno')
        ->join('ryans_vendor_type','ryans_vendors.vendor_type_id','=','ryans_vendor_type.sno')
        ->where('ryans_vendors.sno', $id)
        ->first();

    if (!$data) {
        return response([
            'status' => 404,
            'message' => 'Vendor not found!',
        ], 404);
    }

    // Decode the bank JSON array
    $banks = is_array($data->banks)
        ? $data->banks
        : json_decode($data->banks ?? '[]', true);

    // Get the first bank
    $primaryBank = $banks[0] ?? [];

    // Fetch primary bank country, state and city names
    $primaryBank['country_name'] = \DB::table('ryans_countries')
        ->where('sno', $primaryBank['bank_country'] ?? null)
        ->value('country_name');

    $primaryBank['state_name'] = \DB::table('ryans_states')
        ->where('sno', $primaryBank['bank_state'] ?? null)
        ->value('state_name');

    $primaryBank['city_name'] = \DB::table('ryans_cities')
        ->where('sno', $primaryBank['bank_city'] ?? null)
        ->value('city_name');

        $persons = is_array($data->persons)
        ? $data->persons
        : json_decode($data->persons ?? '[]', true);

    $primaryPerson = $persons[0] ?? [];
    $data->primary_bank = $primaryBank;
    $data->primary_person = $primaryPerson;

    return response([
        'status' => 200,
        'message' => 'Vendor fetched successfully!',
        'data' => $data,
    ], 200);
}

public function Update($id, Request $request)
{
    $user_id = $request->user()->user_id ?? 1;
    

    $validator = Validator::make($request->all(), [
        'country_id' => 'required|exists:ryans_countries,sno',
        'state_id' => 'required|exists:ryans_states,sno',
        'city_id' => 'required|exists:ryans_cities,sno',
        'vendor_type' => 'required|exists:ryans_vendor_type,sno',

        'vendor_company_name' => 'required|string|max:255',
        'vendor_name' => 'nullable|string|max:255',
        'pin_code' => 'required|digits:6',
        'pan_number' => 'required|string|max:10',
        'gst_number' => 'required|string|max:15',
        

        // Primary and Secondary persons
        'persons' => 'required|array|min:1',
        'persons.0.person_type' => 'required|in:1,2,3',
        'persons.0.person_name' => 'required|string|max:255',
        'persons.0.person_number' => 'required|string|max:20',

        'persons.*.person_type' => 'required|in:1,2,3',
        'persons.*.person_name' => 'required|string|max:255',
        'persons.*.person_number' => 'required|string|max:20',
        'persons.*.person_email' => 'nullable|email|max:255',
        'persons.*.person_teleno' => 'nullable|string|max:30',

        'banks' => 'required|array|min:1',
        'banks.0.bank_name' => 'required|string|max:255',
        'banks.0.bank_branch' => 'required|string|max:255',

        'banks.*.bank_name' => 'required|string|max:255',
        'banks.*.bank_branch' => 'required|string|max:255',
        'banks.*.bank_country' => 'required|exists:ryans_countries,sno',
        'banks.*.bank_state' => 'required|exists:ryans_states,sno',
        'banks.*.bank_city' => 'required|exists:ryans_cities,sno',
        'banks.*.bank_address' => 'required|string|max:255',
        'banks.*.bank_pincode' => 'required|digits:6',
        'banks.*.bank_acc_name' => 'required|string|max:255',
        'banks.*.bank_acc_type' => 'required|in:1,2,3',
        'banks.*.bank_acc_number' => 'required|string|max:50',
        'banks.*.bank_micr' => 'required|string|max:20',
        'banks.*.bank_ifsc' => 'required|string|max:20',
    ]);

    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput();
    }

    $upd_VendorModel = VendorModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

    if (!$upd_VendorModel) {
        return redirect()->back()
            ->with('toastr', [
                'type' => 'error',
                'message' => 'Vendoror not found!'
            ]);
    }

     

            $upd_VendorModel->country_id = $request->country_id;
            $upd_VendorModel->state_id = $request->state_id;
            $upd_VendorModel->city_id = $request->city_id;

            $upd_VendorModel->vendor_type_id = $request->vendor_type;
            $upd_VendorModel->vendor_company_name =$request->vendor_company_name;
            $upd_VendorModel->vendor_name = $request->vendor_name;

            $upd_VendorModel->address = $request->address;
            $upd_VendorModel->gst_number = $request->gst_number;
            $upd_VendorModel->pan_number = $request->pan_number;
            $upd_VendorModel->supply_machinery = $request->is_supply;


            $persons = $request->input('persons', []);

            $updatedPersons = [];

            foreach (array_values($persons) as $index => $person) {
                $person['person_role'] = ($index === 0)
                    ? 'Primary'
                    : 'Secondary';

                $updatedPersons[] = $person;
            }

            // Get all banks submitted from the form
            $banks = $request->input('banks', []);

            $updatedBanks = [];

            foreach (array_values($banks) as $index => $bank) {
                $bank['bank_role'] = ($index === 0)
                    ? 'Primary'
                    : 'Secondary';

                $updatedBanks[] = $bank;
            }

            // Save the updated arrays
            $upd_VendorModel->persons = $updatedPersons;
            $upd_VendorModel->banks = $updatedBanks;

            $upd_VendorModel->updated_by = $user_id;

            $upd_VendorModel->save();
                
            
        
        if ($upd_VendorModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Vendor updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Vendor !'
          ]);
        }
     }
}
