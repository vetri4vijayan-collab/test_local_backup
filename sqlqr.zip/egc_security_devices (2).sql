-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2026 at 03:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_security_devices`
--

CREATE TABLE `egc_security_devices` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `staff_id` bigint(20) UNSIGNED NOT NULL,
  `device_uuid` varchar(255) NOT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `device_model` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `android_version` varchar(100) DEFAULT NULL,
  `app_version` varchar(100) DEFAULT NULL,
  `firebase_token` text DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_security_devices`
--

INSERT INTO `egc_security_devices` (`sno`, `staff_id`, `device_uuid`, `device_name`, `device_model`, `manufacturer`, `android_version`, `app_version`, `firebase_token`, `last_login_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 122, '3b92b3d5', 'Vetri Phone 1', 'SM-S928B', 'Samsung', '15', '1.0.0', 'xxxxx', '2026-08-10 09:40:10', 1, '2026-08-10 04:09:25', '2026-08-10 04:10:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_security_devices`
--
ALTER TABLE `egc_security_devices`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uk_device_uuid` (`device_uuid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_security_devices`
--
ALTER TABLE `egc_security_devices`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
