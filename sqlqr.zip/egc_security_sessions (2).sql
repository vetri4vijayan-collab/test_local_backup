-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2026 at 03:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_security_sessions`
--

CREATE TABLE `egc_security_sessions` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `session_uuid` char(36) NOT NULL,
  `module_id` bigint(20) UNSIGNED NOT NULL,
  `record_id` bigint(20) UNSIGNED NOT NULL,
  `requested_staff_id` bigint(20) UNSIGNED NOT NULL,
  `verified_staff_id` bigint(20) UNSIGNED DEFAULT NULL,
  `device_id` bigint(20) UNSIGNED DEFAULT NULL,
  `qr_token` varchar(255) NOT NULL,
  `pin_hash` varchar(255) DEFAULT NULL,
  `pin_attempts` int(11) NOT NULL DEFAULT 0,
  `generated_at` datetime NOT NULL,
  `qr_expires_at` datetime NOT NULL,
  `pin_generated_at` datetime DEFAULT NULL,
  `pin_expires_at` datetime DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `access_expires_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `status` enum('CREATED','SCANNED','PIN_GENERATED','VERIFIED','EXPIRED','FAILED','CLOSED') NOT NULL DEFAULT 'CREATED',
  `ip_address` varchar(100) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_security_sessions`
--

INSERT INTO `egc_security_sessions` (`sno`, `session_uuid`, `module_id`, `record_id`, `requested_staff_id`, `verified_staff_id`, `device_id`, `qr_token`, `pin_hash`, `pin_attempts`, `generated_at`, `qr_expires_at`, `pin_generated_at`, `pin_expires_at`, `verified_at`, `access_expires_at`, `closed_at`, `status`, `ip_address`, `user_agent`, `created_at`, `updated_at`) VALUES
(1, 'b07cf279-3a9f-44f2-bac7-0c1de5a576ad', 1, 122, 0, NULL, NULL, 'c0bf99f1ec933575eb312d01ce6a1e718cb9fb54998d8b974cc8c5bf6b7f6d4d', NULL, 0, '2026-08-10 05:52:48', '2026-08-10 09:12:48', NULL, NULL, NULL, NULL, '2026-08-10 05:54:23', 'EXPIRED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 00:22:48', '2026-08-10 00:24:23'),
(2, '8f61f785-2142-4da0-9c1b-eff82ac5c227', 1, 122, 0, NULL, NULL, 'c1af66d802ea2dc919cbf43f57590fcf43aad364abea4534335c88f31233a597', NULL, 0, '2026-08-10 05:54:23', '2026-08-10 09:14:23', NULL, NULL, NULL, NULL, '2026-08-10 09:37:35', 'EXPIRED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 00:24:23', '2026-08-10 04:07:35'),
(3, 'dcae1fbd-3e80-4c97-8631-7c2d08805fc5', 1, 122, 0, NULL, 1, 'a8e47626c9eedbd7b06366869f7f39ae6bbcb612946392af9797c8d81311e378', '$2y$12$qkRXFOSN.D3ADlGg4ZoGBu6uxQDUsgrExZMRNzkmkoYsiRxoRHK8e', 0, '2026-08-10 09:37:35', '2026-08-10 12:57:35', '2026-08-10 09:40:11', '2026-08-10 13:00:11', NULL, NULL, '2026-08-10 12:07:11', 'EXPIRED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 04:07:35', '2026-08-10 06:37:11'),
(4, '0b639851-1d1a-4d43-8d7b-e9b4ce6df8c4', 1, 293, 0, NULL, NULL, '236e0ea3dbe875d8db6663b57b288fdf6c7b4af65c12b8bb70a2f0a1484a4413', NULL, 0, '2026-08-10 12:01:07', '2026-08-10 15:21:07', NULL, NULL, NULL, NULL, '2026-08-10 12:01:21', 'EXPIRED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 06:31:07', '2026-08-10 06:31:21'),
(5, '7cef0399-f684-49b3-85f3-d3299d3d4cc9', 1, 293, 0, NULL, NULL, '4a263338f7ac97c64a2818e6f141535e18e848e91edba053f8d276d0272017f9', NULL, 0, '2026-08-10 12:01:21', '2026-08-10 15:21:21', NULL, NULL, NULL, NULL, NULL, 'CREATED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 06:31:21', '2026-08-10 06:31:21'),
(6, '06f5e8ba-cba4-4fd0-ae12-8b1999106538', 1, 122, 0, NULL, NULL, '5afb1054b82c0a69790ac26da9e2195c7387b6802bf8a6c5b4b781eb799547fd', NULL, 0, '2026-08-10 12:07:11', '2026-08-10 15:27:11', NULL, NULL, NULL, NULL, NULL, 'CREATED', '192.168.3.122', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', '2026-08-10 06:37:11', '2026-08-10 06:37:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uk_session_uuid` (`session_uuid`),
  ADD KEY `idx_module_record` (`module_id`,`record_id`),
  ADD KEY `idx_status` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `egc_security_sessions`
--
ALTER TABLE `egc_security_sessions`
  ADD CONSTRAINT `fk_session_module` FOREIGN KEY (`module_id`) REFERENCES `egc_security_modules` (`sno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
