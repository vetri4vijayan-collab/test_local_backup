-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2026 at 03:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_security_module_settings`
--

CREATE TABLE `egc_security_module_settings` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `module_id` bigint(20) UNSIGNED NOT NULL,
  `pin_length` tinyint(4) NOT NULL DEFAULT 6,
  `pin_expiry_seconds` int(11) NOT NULL DEFAULT 120,
  `access_expiry_seconds` int(11) NOT NULL DEFAULT 120,
  `qr_expiry_seconds` int(11) NOT NULL DEFAULT 120,
  `max_attempts` tinyint(4) NOT NULL DEFAULT 5,
  `allow_multiple_devices` tinyint(1) NOT NULL DEFAULT 0,
  `allow_rescan` tinyint(1) NOT NULL DEFAULT 1,
  `require_login` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_security_module_settings`
--

INSERT INTO `egc_security_module_settings` (`sno`, `module_id`, `pin_length`, `pin_expiry_seconds`, `access_expiry_seconds`, `qr_expiry_seconds`, `max_attempts`, `allow_multiple_devices`, `allow_rescan`, `require_login`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 12000, 12000, 12000, 5, 0, 1, 1, 1, '2026-08-05 13:24:30', '2026-08-06 06:33:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_security_module_settings`
--
ALTER TABLE `egc_security_module_settings`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uk_module_setting` (`module_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_security_module_settings`
--
ALTER TABLE `egc_security_module_settings`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `egc_security_module_settings`
--
ALTER TABLE `egc_security_module_settings`
  ADD CONSTRAINT `fk_security_setting_module` FOREIGN KEY (`module_id`) REFERENCES `egc_security_modules` (`sno`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
