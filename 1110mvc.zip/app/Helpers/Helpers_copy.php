<?php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;
use App\Models\GeneralSettingsModel;
use App\Models\ManageCoursesModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\JobRollModel;
use App\Models\PreSkillSetModel;
use App\Models\BrandModel;
use App\Models\GroupModel;
use App\Models\KnowledgeLevelModel;
use App\Models\CourseActionModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\DocumentTypeModel;
use App\Models\BranchTypeModel;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\JobpositionModel;
use App\Models\TimeZoneModel;
use App\Models\CurrencyFormatModel;
use App\Models\FacilityModel;
use App\Models\TrainingModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\InterviewTypeModel;
use App\Models\HrDirectoryModel;
use App\Models\JobDirectoryModel;
use App\Models\ManageQuestionModel;
use App\Models\UserRolePermissionModel;
use App\Models\FinancialYearModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\Rules_guidelinesModel;
use App\Models\ShiftTimeModel;
use App\Models\SyllabusUpdateModel;
use App\Models\SlotModel;
use App\Models\BatchModel;
use App\Models\NotificationTypeModel;
use App\Models\NotificationModel;
class Helpers
{
  protected static $branch_id = 1;
  public static function appClasses()
  {
    $data = config('custom.custom');
    // default data array
    $DefaultData = [
      'myLayout' => 'vertical',
      'myTheme' => 'theme-default',
      'myStyle' => 'light',
      'myRTLSupport' => true,
      'myRTLMode' => true,
      'hasCustomizer' => true,
      'showDropdownOnHover' => true,
      'displayCustomizer' => true,
      'contentLayout' => 'compact',
      'headerType' => 'fixed',
      'navbarType' => 'fixed',
      'menuFixed' => true,
      'menuCollapsed' => false,
      'footerFixed' => false,
      'menuFlipped' => false,
      // 'menuOffcanvas' => false,
      'customizerControls' => [
        'rtl',
        'style',
        'headerType',
        'contentLayout',
        'layoutCollapsed',
        'showDropdownOnHover',
        'layoutNavbarOptions',
        'themes',
      ],
      //   'defaultLanguage'=>'en',
    ];
    // if any key missing of array from custom.php file it will be merge and set a default value from dataDefault array and store in data variable
    $data = array_merge($DefaultData, $data);

    // All options available in the template
    $allOptions = [
      'myLayout' => ['vertical', 'horizontal', 'blank', 'front'],
      'menuCollapsed' => [true, false],
      'hasCustomizer' => [true, false],
      'showDropdownOnHover' => [true, false],
      'displayCustomizer' => [true, false],
      'contentLayout' => ['compact', 'wide'],
      'headerType' => ['fixed', 'static'],
      'navbarType' => ['fixed', 'static', 'hidden'],
      'myStyle' => ['light', 'dark', 'system'],
      'myTheme' => ['theme-default', 'theme-bordered', 'theme-semi-dark'],
      'myRTLSupport' => [true, false],
      'myRTLMode' => [true, false],
      'menuFixed' => [true, false],
      'footerFixed' => [true, false],
      'menuFlipped' => [true, false],
      // 'menuOffcanvas' => [ true, false ],
      'customizerControls' => [],
      // 'defaultLanguage'=>array( 'en'=>'en', 'fr'=>'fr', 'de'=>'de', 'ar'=>'ar' ),
    ];

    //if myLayout value empty or not match with default options in custom.php config file then set a default value
    foreach ($allOptions as $key => $value) {
      if (array_key_exists($key, $DefaultData)) {
        if (gettype($DefaultData[$key]) === gettype($data[$key])) {
          // data key should be string
          if (is_string($data[$key])) {
            // data key should not be empty
            if (isset($data[$key]) && $data[$key] !== null) {
              // data key should not be exist inside allOptions array's sub array
              if (!array_key_exists($data[$key], $value)) {
                // ensure that passed value should be match with any of allOptions array value
                $result = array_search($data[$key], $value, 'strict');
                if (empty($result) && $result !== 0) {
                  $data[$key] = $DefaultData[$key];
                }
              }
            } else {
              // if data key not set or
              $data[$key] = $DefaultData[$key];
            }
          }
        } else {
          $data[$key] = $DefaultData[$key];
        }
      }
    }
    $styleVal = $data['myStyle'] == "dark" ? "dark" : "light";
    if (isset($_COOKIE['mode'])) {
      if ($_COOKIE['mode'] === "system") {
        if (isset($_COOKIE['colorPref'])) {
          $styleVal = Str::lower($_COOKIE['colorPref']);
        }
      } else {
        $styleVal = $_COOKIE['mode'];
      }
    }
    isset($_COOKIE['theme']) ? $themeVal = $_COOKIE['theme'] : $themeVal = $data['myTheme'];
    //layout classes
    $layoutClasses = [
      'layout' => $data['myLayout'],
      'theme' => $themeVal,
      'themeOpt' => $data['myTheme'],
      'style' => $styleVal,
      'styleOpt' => $data['myStyle'],
      'rtlSupport' => $data['myRTLSupport'],
      'rtlMode' => $data['myRTLMode'],
      'textDirection' => $data['myRTLMode'],
      'menuCollapsed' => $data['menuCollapsed'],
      'hasCustomizer' => $data['hasCustomizer'],
      'showDropdownOnHover' => $data['showDropdownOnHover'],
      'displayCustomizer' => $data['displayCustomizer'],
      'contentLayout' => $data['contentLayout'],
      'headerType' => $data['headerType'],
      'navbarType' => $data['navbarType'],
      'menuFixed' => $data['menuFixed'],
      'footerFixed' => $data['footerFixed'],
      'menuFlipped' => $data['menuFlipped'],
      'customizerControls' => $data['customizerControls'],
    ];

    // sidebar Collapsed
    if ($layoutClasses['menuCollapsed'] == true) {
      $layoutClasses['menuCollapsed'] = 'layout-menu-collapsed';
    }

    // Header Type
    if ($layoutClasses['headerType'] == 'fixed') {
      $layoutClasses['headerType'] = 'layout-menu-fixed';
    }
    // Navbar Type
    if ($layoutClasses['navbarType'] == 'fixed') {
      $layoutClasses['navbarType'] = 'layout-navbar-fixed';
    } elseif ($layoutClasses['navbarType'] == 'static') {
      $layoutClasses['navbarType'] = '';
    } else {
      $layoutClasses['navbarType'] = 'layout-navbar-hidden';
    }

    // Menu Fixed
    if ($layoutClasses['menuFixed'] == true) {
      $layoutClasses['menuFixed'] = 'layout-menu-fixed';
    }


    // Footer Fixed
    if ($layoutClasses['footerFixed'] == true) {
      $layoutClasses['footerFixed'] = 'layout-footer-fixed';
    }

    // Menu Flipped
    if ($layoutClasses['menuFlipped'] == true) {
      $layoutClasses['menuFlipped'] = 'layout-menu-flipped';
    }

    // Menu Offcanvas
    // if ($layoutClasses['menuOffcanvas'] == true) {
    //   $layoutClasses['menuOffcanvas'] = 'layout-menu-offcanvas';
    // }

    // RTL Supported template
    if ($layoutClasses['rtlSupport'] == true) {
      $layoutClasses['rtlSupport'] = '/rtl';
    }

    // RTL Layout/Mode
    if ($layoutClasses['rtlMode'] == true) {
      $layoutClasses['rtlMode'] = 'rtl';
      $layoutClasses['textDirection'] = 'rtl';
    } else {
      $layoutClasses['rtlMode'] = 'ltr';
      $layoutClasses['textDirection'] = 'ltr';
    }

    // Show DropdownOnHover for Horizontal Menu
    if ($layoutClasses['showDropdownOnHover'] == true) {
      $layoutClasses['showDropdownOnHover'] = true;
    } else {
      $layoutClasses['showDropdownOnHover'] = false;
    }

    // To hide/show display customizer UI, not js
    if ($layoutClasses['displayCustomizer'] == true) {
      $layoutClasses['displayCustomizer'] = true;
    } else {
      $layoutClasses['displayCustomizer'] = false;
    }

    return $layoutClasses;
  }

  public static function updatePageConfig($pageConfigs)
  {
    $demo = 'custom';
    if (isset($pageConfigs)) {
      if (count($pageConfigs) > 0) {
        foreach ($pageConfigs as $config => $val) {
          // Config::set('custom.' . $demo . '.' . $config, $val);
        }
      }
    }
  }

  function Logo_pic($pic)
  {
    if ($pic) {
      return url('logos/' . $pic);
    } else {
      return ""; // Return an empty string if no picture is provided
    }
  }

  function Fav_Icon_pic($pic)
  {
    if ($pic) {
      return url('fav_icons/' . $pic);
    } else {
      return ''; // Return an empty string if no picture is provided
    }
  }
  // ******************************** Vasanth ****************************
  
  // Attendance amount calc student
  function get_student_attendance_amount($cus_sno, $batch_sno, $course_sno)
  {
    $attendance = AttendanceModel::selectRaw('SUM(total_cost) AS total_att_amount, SUM(total_duration) AS total_att_hours')
      ->where('status', 1)
      ->where('attendance', 'P')
      ->where('customer_id', $cus_sno)
      ->where('batch_id', $batch_sno)
      ->where('course_id', $course_sno)
      ->first();

    // Handle null values by using the null coalescing operator
    $totalAttAmount = $attendance->total_att_amount ?? 0;
    $totalAttHours = $attendance->total_att_hours ?? 0;

    // Return both values as an array
    return [
      'total_att_amount' => $totalAttAmount,
      'total_att_hours' => $totalAttHours,
    ];
  }
  function get_payment_percentage($tran_sno, $cus_sno)
  {
    // Retrieve summed paidAmount and individual total_amounts for the specific course and batch
    $paymentDetails = TrainingModel::selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
      ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->where('za_training.customer_id', $cus_sno)
      ->where('za_training.sno', $tran_sno)
      ->groupBy('za_payment.total_amount')
      ->get(); // Use `get()` to handle multiple rows

    // Initialize total variables
    $totalPaidAmount = 0;
    $totalAmount = 0;

    // Iterate over the result set to accumulate values
    foreach ($paymentDetails as $payment) {
      $totalPaidAmount += $payment->total_paid_amount;
      $totalAmount += $payment->total_amount;
    }

    // Initialize payment percentage to 0
    $paymentPercentage = 0;

    // Calculate payment percentage if valid data is retrieved
    if ($totalAmount > 0) {
      $paymentPercentage = number_format(
        ($totalPaidAmount / $totalAmount) * 100,
        1
      );
    }

    // Return the calculated percentage
    return $paymentPercentage;
  }
  function get_course_percentage($tran_sno, $cus_sno)
  {
    // Fetch training details
    $training = TrainingModel::find($tran_sno);

    if (!$training) {
      return 0; // If no training record found, return 0% progress
    }

    $batch_id = $training->batch_id;
    $course_id = $training->course_id;

    // Fetch attendance records with 'P' status
    $attendanceRecords = AttendanceModel::where('customer_id', $cus_sno)
      ->where('batch_id', $batch_id)
      ->where('attendance', 'P')
      ->get();

    // Fetch the total number of course topics
    $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)
      ->count();

    // Initialize counters
    $topicCount = 0;
    $courseProgress = 0;

    // Calculate topic progress based on attendance
    if ($attendanceRecords->isNotEmpty() && $course_topic_count > 0) {
      foreach ($attendanceRecords as $attendance) {
        // Fetch syllabus updates for matching batch and attendance date
        $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batch_id)
          ->whereDate('date', $attendance->att_date)
          ->get();

        // Increment topic count for each syllabus update with 100% completion
        foreach ($syllabusUpdates as $syllabusUpdate) {
          if ($syllabusUpdate->percentage == 100) {
            $topicCount++;
          }
        }
      }
      // Calculate course progress as a percentage
      $courseProgress = ($topicCount / $course_topic_count) * 100;

      // Cap the progress at 100%
      $courseProgress = min($courseProgress, 100);

      // Format the progress to 2 decimal places
      $courseProgress = number_format($courseProgress, 2);
    }

    // Return the calculated percentage
    return $courseProgress;
  }
  
  // schedule_messages
  public function scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId)
  {
    try {
      $addMessage = new Schedule_message_model();
      $addMessage->config_id = $configId;
      $addMessage->source_type_id = $sourceTypeId;
      $addMessage->source_id  = $sourceId;
      $addMessage->branch_id  = $branchId;
      $addMessage->created_by = $userId;
      $addMessage->updated_by = $userId;
      $addMessage->save();
      return response()->json([
        'status' => 200,
        'message' => 'Successfully scheduled message!',
        'error_msg' => null,
        'data' => $addMessage,
      ], 200);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Error scheduling message.',
        'error_msg' => $e->getMessage(),
        'data' => null,
      ], 500);
    }
  }
  
//   GET ROLE USRMANAGEMENT
  function get_roles_list()
  {
    // Fetch roles from the UserRoleModel
    $roles = UserRoleModel::where('status', 0)->get();

    // Fetch the role IDs from UserRolePermissionModel
    $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

    // Filter roles to exclude those that are in userRolePermissions
    $filteredRoles = $roles->filter(function ($role) use ($userRolePermissions) {
      return !in_array($role->sno, $userRolePermissions); // Exclude roles with matching role_id
    });

    return $filteredRoles;
  }

  // Get SmS Tempalate
  function get_sms_template($id = '')
  {
    $result = SmsTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Whatsapp Template
  function get_whatsapp_template($id = '')
  {
    $result = WhatsappTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Email Template
  function get_email_template($id = '')
  {
    $result = EmailTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Branch and Franchise list based on user_id
  function get_branch_control_list($user_id)
  {
    // Fetch the user based on user_id
    $user = StaffModel::where('sno', $user_id)->first();

    if ($user !== null) {
      // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
      $accessibleBranches = json_decode($user->multi_branch_access, true);

      if (!empty($accessibleBranches)) {
        // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
        $branches = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 1)
          ->get();

        $franchises = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 2)
          ->get();

        return ['branches' => $branches, 'franchises' => $franchises];
      }
    } else {
      // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
      $branches = BranchModel::where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();
      return ['branches' => $branches, 'franchises' => $franchises];
    }
  }


  // common Date Format
  function general_setting_data()
  {
    $sno = 1;
    $result = GeneralSettingsModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // encrypt_decrypt
  function encrypt_decrypt($string, $action = 'encrypt')
  {
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'EAPL'; // Change this to your secret key
    $secret_iv = 'YourSecretIV'; // Change this to your secret IV

    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

    if ($action == 'encrypt') {
      $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
      $output = base64_encode($output);
    } elseif ($action == 'decrypt') {
      $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    } else {
      $output = false;
    }

    return $output;
  }
  // Get Country Names by ID
  function get_country_data($id = '')
  {
    $result = CountryModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get State Names by ID
  function get_state_data($id = '')
  {
    $result = StateModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get City Names by ID
  function get_city_data($id = '')
  {
    $result = CityModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // Get Branch list
  function get_branch_list()
  {
    $result = BranchModel::where('status', 0)->where('branch_type', 1)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Franchise list
  function get_franchise_list()
  {
    $result = BranchModel::where('status', 0)->where('branch_type', 2)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Branch id
  function get_branch_id($sno = "")
  {
    $result = BranchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Franchise list
  function get_franchise_id($sno = "")
  {
    $result = BranchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Role list
  function get_role_list()
  {
    $result = UserRoleModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Role id
  function get_role_id($sno = "")
  {
    $result = UserRoleModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Staff by id
  function get_staff_data($id = '')
  {
    $result = StaffModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Staff list
  function get_staff_list()
  {
    $result = StaffModel::where('status', 0)->orderBy('staff_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Name imgae user
  function name_image($ins = "A", $gender)
  {
    // Array of all avatar divs
    if ($gender === 1) {
      $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-success'>" . $ins . "</span>
            </div>";
    } else if ($gender === 2) {
      $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-info'>" . $ins . "</span>
            </div>";
    } else {
      $divs = "<div class='avatar  me-2'>
              <span class='avatar-initial rounded-circle bg-label-warning'>" . $ins . "</span>
            </div>";
    }

    return $divs;
  }
  // get course type data
  function get_course_type_data($sno = '')
  {
    $result = CourseTypeModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_course_data($sno = '')
  {
    $result = ManageCoursesModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_batch_data($sno = '')
  {
    $result = BatchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_slot_data($sno = '')
  {
    $result = SlotModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function tcourse_data($sno = '')
  {
    $result = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')
      ->from('za_course')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.sno', $sno)
      ->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // Get course category data
  function get_course_category_data($sno = '')
  {
    $result = CourseCategoryModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get course Sub category data
  function get_course_subcategory_data($sno = '')
  {
    $result = CourseSubCategoryModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Brand
  function get_course_brand_data($sno = '')
  {
    $result = BrandModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Group
  function get_course_group_data($sno = '')
  {
    $result = GroupModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Jobe Roll
  function get_course_job_role_data($sno = '')
  {
    $result = JobRollModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //pre skill set
  function get_course_pre_skill_data($sno = '')
  {
    $result = PreSkillSetModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //knowledge level list by id
  function get_knowledge_level_data($sno = '')
  {
    $result = KnowledgeLevelModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // knowledge level list
  function get_knowledge_level_list()
  {
    $result = KnowledgeLevelModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list
  function get_course_action_data($id = '')
  {
    $result = CourseActionModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list
  function get_course_action_list()
  {
    $result = CourseActionModel::where('status', 0)->orderBy('course_action_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list Count in Chapter
  function get_course_action_count_list($id = '')
  {

    $result = ManageCoursesSyllabusModel::selectRaw('COUNT(za_course_chapter.course_action_id) AS count, MAX(za_course_action.course_action_icon) AS course_action_icon, MAX(za_course_action.course_action_name) AS course_action_name')
      ->leftJoin('za_course_action', 'za_course_chapter.course_action_id', '=', 'za_course_action.sno')
      ->where('za_course_chapter.course_chapter_id', $id)
      ->where('za_course_chapter.status', 0)
      ->groupBy('za_course_chapter.course_action_id')
      ->get();
    return $result->isEmpty() ? null : $result;
  }
  //Course Chapter Get by course id
  function get_course_chapter_id($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('course_id', $id)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Chapter Get by course id Group
  function get_course_chapter_group_id($id = '')
  {
    $result = ManageCoursesSyllabusModel::selectRaw('MAX( sno ) AS max_sno')
      ->where('course_id', $id)
      ->where('status', 0)
      ->groupBy('course_chapter_id')
      ->get();

    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Chapter
  function get_course_chapter_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('course_chapter_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course section
  function get_course_section_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('session_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Topic
  function get_course_topic_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('topic_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function topic_complete_data($id = '', $batch = '')
  {
    $result = SyllabusUpdateModel::where('topic_id', $id)->where('batch_id', $batch)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_course_section_com_percentage($id = '', $batch = '')
  {
    $ses_count = ManageCoursesSyllabusModel::where('session_id', $id)->where('status', 0)->count();
    $complete  = SyllabusUpdateModel::where('section_id', $id)->where('batch_id', $batch)->where('status', 0)->count();
    if ($ses_count > 0) {
      $percentage = ($complete / $ses_count) * 100;
    } else {
      $percentage = 0;
    }
    return round($percentage, 2);
  }
  function get_question_bank_count($id = '')
  {
    $result = ManageQuestionModel::where('question_bank_id', $id)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // document type List
  function get_document_type_list()
  {
    $result = DocumentTypeModel::where('status', 0)->orderBy('documenttype_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // branch Category List
  function get_branch_category_list()
  {
    $result = BranchTypeModel::where('status', 0)->orderBy('branchtype_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Department List
  function get_department_list()
  {
    $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // branch Category ID
  function get_branch_category_id($id = '')
  {
    $result = BranchTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // branch time zone ID
  function get_time_zone_id($id = '')
  {
    $result = TimeZoneModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // branch currency format ID
  function get_currency_format_id($id = '')
  {
    $result = CurrencyFormatModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_department_id($id = '')
  {
    $result = DepartmentModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //position
  function get_position_id($id = '')
  {
    $result = JobpositionModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Document By id
  function get_document_id($id = '')
  {
    $result = DocumentTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function absent_list_two_days()
    {
      
      $startDate = now()->subDays(2)->startOfDay();
      $endDate = now()->endOfDay();


      $attendance = StaffAttendanceModel::where('attendance', 'A')
      ->whereBetween('date', [$startDate, $endDate])
      ->pluck('staff_id');

      return $attendance;
    }

    function absent_list_seven_days()
    {
      
      $startDate = now()->subDays(7)->startOfDay();
      $endDate = now()->endOfDay();


      $attendance = StaffAttendanceModel::where('attendance', 'A')
      ->whereBetween('date', [$startDate, $endDate])
      ->pluck('staff_id');

      return $attendance;
    }

  // Course assign By branch id
  function get_course_assign_branchid($id = '')
  {
    $result = CourseAssigne_model::where('branch_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // rosini
  function get_chapter_status($chapter_id, $batch_id, $section_id)
  {
      // Get the count of topics associated with the chapter
      $topics = ManageCoursesSyllabusModel::selectRaw('COUNT(za_course_chapter.course_action_id) AS count')
          ->leftJoin('za_course_action', 'za_course_chapter.course_action_id', '=', 'za_course_action.sno')
          ->where('za_course_chapter.course_chapter_id', $chapter_id)
          ->where('za_course_chapter.status', 0)
          ->groupBy('za_course_chapter.course_action_id')
          ->get()
          ->sum('count'); // Sum the counts for total topics
  
      // Get the count of completed topics
      $completedTopics = SyllabusUpdateModel::where('chapter_id', $chapter_id)
          ->where('percentage', 100)
          ->where('status', 0)
          ->distinct('topic_id')
          ->count('topic_id');
  
      // Calculate the total completion percentage
      $totalPercentage = $topics > 0 ? ($completedTopics / $topics) * 100 : 0;
  
      // Determine badge label and color
      $badgeLabel = '';
  

      // if ($completedTopics ===  $topics) {
      //     $color = '#82cfa5'; // Completed
      // } elseif ($completedTopics > 0 && $completedTopics < $topics) {
      //     $color = '#6badbd'; // In Progress
      // } elseif ($completedTopics === 0) {
      //     $color = '#f2f4f5'; // Not yet Started
      // }
  
      // Determine badge label
      if ($completedTopics === $topics) {
          $badgeLabel = 'Completed';
      } elseif ($completedTopics > 0) {
          $badgeLabel = 'In Progress';
      } else {
          $badgeLabel = 'Not yet Started';
      }
  
      // Return the results as JSON
      return json_encode([
          'total_sections' => $topics,
          'completed_topics' => $completedTopics,
          'completion_percentage' => $totalPercentage,
          'badge_label' => $badgeLabel, // Include badge label in the response
      ]);
  }
  function get_chapter_color($chapter_id, $batch_id, $section_id)
  {
      // Get the count of topics associated with the chapter
      $topics = ManageCoursesSyllabusModel::selectRaw('COUNT(za_course_chapter.course_action_id) AS count')
          ->leftJoin('za_course_action', 'za_course_chapter.course_action_id', '=', 'za_course_action.sno')
          ->where('za_course_chapter.course_chapter_id', $chapter_id)
          ->groupBy('za_course_chapter.course_action_id')
          ->get()
          ->sum('count'); // Sum the counts for total topics
  
      // Get the count of completed topics
      $completedTopics = SyllabusUpdateModel::where('chapter_id', $chapter_id)->where('section_id', $section_id)
          ->where('percentage', 100)
          ->distinct('topic_id')
          ->count('topic_id');
  
      // Calculate the total completion percentage
      $totalPercentage = $topics > 0 ? ($completedTopics / $topics) * 100 : 0;
  
      // Determine badge label and color
      $badgeLabel = '';
  

      // if ($completedTopics ===  $topics) {
      //     $color = '#82cfa5'; // Completed
      // } elseif ($completedTopics > 0 && $completedTopics < $topics) {
      //     $color = '#6badbd'; // In Progress
      // } elseif ($completedTopics === 0) {
      //     $color = '#f2f4f5'; // Not yet Started
      // }
  
      // Determine badge label
      if ($completedTopics === $topics) {
          $badgeLabel = 'Completed';
      } elseif ($completedTopics > 0) {
          $badgeLabel = 'In Progress';
      } else {
          $badgeLabel = 'Not yet Started';
      }
  
      // Return the results as JSON
      return json_encode([
          'total_sections' => $topics,
          'completed_topics' => $completedTopics,
          'completion_percentage' => $totalPercentage,
          'badge_label' => $badgeLabel, // Include badge label in the response
      ]);
  }

  // get financial year list
    function get_fin_yr()
    {
      $result = FinancialYearModel::where('status', 0)->get();
      if ($result !== null) {
        return $result;
      } else {
        return null;
      }
    }
    function get_fin_year_by_sno($id = '')
    {
        $result = FinancialYearModel::where('sno', $id)->where('status', 0)->first();
        
        // Check if a record was found
        if ($result !== null) {
            return $result; // Return the single instance
        } else {
            return null; // Return null if no results found
        }
    }
  // facility Roll
   function get_branch_staff_list($branch_id)
  {
    $result = StaffModel::where('status', 0)->where('branch_id', $branch_id)->orderBy('staff_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_facility_data($sno = '')
  {
    $result = FacilityModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Shift time list
  function get_shift_time()
  {
    $result = ShiftTimeModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Shift time id
  function get_shift_time_id($sno = " ")
  {
    $result = ShiftTimeModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }



  function get_course_syllabus_data($batch, $chapter, $sec, $topic='')
  {
    // return $batch;
    $result =  SyllabusUpdateModel::where('batch_id', $batch)
      ->where('chapter_id', $chapter)
      ->where('section_id', $sec)
      // ->whereIn('topic_id', $latest_topics->pluck('topic_id')->toArray())
      // ->where('staff_id', $batch->staff_id)
      ->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // ********************************* Rajkumar I Start **************************************
  
  // Get rules
  function get_rules_data($id = '')
  {
    $result = Rules_guidelinesModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  
  // Get Hr Sub Branch 

  function get_hr_sub_branch($id = '')
  {
    $result = HrDirectoryBranchModel::where('company_id', $id)->where('status', 0)->get();
    return $result;
  }

  //interview type ID
  function get_interview_type_id($id = '')
  {
    $result = InterviewTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Company Hr Directory BY ID
  function get_company_hr_id($id = '')
  {
    $result = HrDirectoryModel::where('sno', $id)->first();
    // return $result;

    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  
    function get_total_vacancy_by_company_id($id = '')
  {
    // Retrieve all records for the given company ID
    $results = JobDirectoryModel::select('vacancy_count')->where('job_company_id', $id)->get();

    // Initialize total vacancy count
    $total_count_vacancy = 0;

    // Iterate through each result
    foreach ($results as $result) {
      // Decode JSON
      $vacancy_count = json_decode($result->vacancy_count, true);

      // Check if the decoded value is an array
      if (is_array($vacancy_count)) {
        // Sum the values
        $total_count_vacancy += array_sum($vacancy_count);
      }
    }

    return $total_count_vacancy; // Return the total count
  }



  // ********************************* Rajkumar I End **************************************


  function GRADE_LOGO_PIC_PATH($pic)
  {
    if ($pic) {
      return url('grade_logo/' . $pic);
    } else {
      return '';
    }
  }


  function get_profile_image_url($staff_image, $default = 'assets/eapl_images/Super-Admin.png')
  {
    $path = public_path($staff_image);
    return file_exists($path) ? asset($staff_image) : asset($default);
  }
  
  //here need create helfer funtion for notification message from notification type based to fetch 

  public function createNotification(array $data, $notificationtype)
  {
    // Step 1: Find the Notification Type based on the name
    $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();

    // Check if notification type exists and proceed
    if ($notificationType) {
      // Decode the JSON string array of roles
      $rolesArray = json_decode($notificationType->notification_roles, true);

      // Step 2: Fetch staff based on branch, status, and roles array
      $staffMembers = StaffModel::where('branch_id', $data['branch_id'])
        ->where('status', 0) // Assuming 0 is the active status
        ->whereIn('role_id', $rolesArray)
        ->get();

      // Step 3: Prepare notifications for each staff member
      $notifications = [];
      foreach ($staffMembers as $staff) {
        $notificationData = [
          'branch_id'            => $data['branch_id'] ?? 0,
          'notification_type_id' => $notificationType->sno,
          'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
          'notification_content' => $data['notification_content'],
          'notification_date'    => now(),
          'who'                  => $data['who'] ?? '0',
          'whom'                 => $staff->sno,
          'created_by'           => $data['created_by'] ?? 0,
          'updated_by'           => $data['updated_by'] ?? 0,
          'status'               => $data['status'] ?? 0
        ];

        // Insert the notification and store the result
        $notifications[] = NotificationModel::create($notificationData);
      }

      return $notifications; // Return all created notifications
    }

    // Return null if notification type was not found
    return null;
  }
}
