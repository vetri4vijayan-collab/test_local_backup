<?php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;
use App\Models\GeneralSettingsModel;
use App\Models\ManageCoursesModel;
use App\Models\CourseTypeModel;
use App\Models\CourseCategoryModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CourseAssigne_model;
use App\Models\BatchHistoryModel;
use App\Models\JobRollModel;
use App\Models\PreSkillSetModel;
use App\Models\BrandModel;
use App\Models\GroupModel;
use App\Models\BatchExtensionModel;
use App\Models\KnowledgeLevelModel;
use App\Models\CourseActionModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\DocumentTypeModel;
use App\Models\BranchTypeModel;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\JobpositionModel;
use App\Models\TimeZoneModel;
use App\Models\CurrencyFormatModel;
use App\Models\FacilityModel;
use App\Models\TrainingModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\InterviewTypeModel;
use App\Models\HrDirectoryModel;
use App\Models\JobDirectoryModel;
use App\Models\ManageQuestionModel;
use App\Models\UserRolePermissionModel;
use App\Models\FinancialYearModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\Rules_guidelinesModel;
use App\Models\ShiftTimeModel;
use App\Models\SyllabusUpdateModel;
use App\Models\SlotModel;
use App\Models\GiftModel;
use App\Models\BatchModel;
use App\Models\NotificationTypeModel;
use App\Models\NotificationModel;
use App\Models\ExamModel;
use App\Models\MaterialTypeModel;
use App\Models\MarketingModel;
use App\Models\Student;
use App\Models\PointsModel;
use App\Models\CustomerPlacementModel;
use App\Models\ManageCouponHistoryModel;
use App\Models\ManageCouponModel;
use App\Models\BatchSummaryModel;
use Illuminate\Support\Facades\DB;

use App\Models\AppointmentModel;
use App\Models\LeadAppointmentModel;
use App\Models\BugsListModel;

use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use Carbon\Carbon;

class Helpers
{
  protected static $branch_id = 1;
  protected static $temp = [];
  public static function appClasses()
  {
      
    $data = config('custom.custom');
    // default data array
    $DefaultData = [
      'myLayout' => 'vertical',
      'myTheme' => 'theme-default',
      'myStyle' => 'light',
      'myRTLSupport' => true,
      'myRTLMode' => true,
      'hasCustomizer' => true,
      'showDropdownOnHover' => true,
      'displayCustomizer' => true,
      'contentLayout' => 'compact',
      'headerType' => 'fixed',
      'navbarType' => 'fixed',
      'menuFixed' => true,
      'menuCollapsed' => false,
      'footerFixed' => false,
      'menuFlipped' => false,
      // 'menuOffcanvas' => false,
      'customizerControls' => [
        'rtl',
        'style',
        'headerType',
        'contentLayout',
        'layoutCollapsed',
        'showDropdownOnHover',
        'layoutNavbarOptions',
        'themes',
      ],
      //   'defaultLanguage'=>'en',
    ];
    // if any key missing of array from custom.php file it will be merge and set a default value from dataDefault array and store in data variable
    $data = array_merge($DefaultData, $data);

    // All options available in the template
    $allOptions = [
      'myLayout' => ['vertical', 'horizontal', 'blank', 'front'],
      'menuCollapsed' => [true, false],
      'hasCustomizer' => [true, false],
      'showDropdownOnHover' => [true, false],
      'displayCustomizer' => [true, false],
      'contentLayout' => ['compact', 'wide'],
      'headerType' => ['fixed', 'static'],
      'navbarType' => ['fixed', 'static', 'hidden'],
      'myStyle' => ['light', 'dark', 'system'],
      'myTheme' => ['theme-default', 'theme-bordered', 'theme-semi-dark'],
      'myRTLSupport' => [true, false],
      'myRTLMode' => [true, false],
      'menuFixed' => [true, false],
      'footerFixed' => [true, false],
      'menuFlipped' => [true, false],
      // 'menuOffcanvas' => [ true, false ],
      'customizerControls' => [],
      // 'defaultLanguage'=>array( 'en'=>'en', 'fr'=>'fr', 'de'=>'de', 'ar'=>'ar' ),
    ];

    //if myLayout value empty or not match with default options in custom.php config file then set a default value
    foreach ($allOptions as $key => $value) {
      if (array_key_exists($key, $DefaultData)) {
        if (gettype($DefaultData[$key]) === gettype($data[$key])) {
          // data key should be string
          if (is_string($data[$key])) {
            // data key should not be empty
            if (isset($data[$key]) && $data[$key] !== null) {
              // data key should not be exist inside allOptions array's sub array
              if (!array_key_exists($data[$key], $value)) {
                // ensure that passed value should be match with any of allOptions array value
                $result = array_search($data[$key], $value, 'strict');
                if (empty($result) && $result !== 0) {
                  $data[$key] = $DefaultData[$key];
                }
              }
            } else {
              // if data key not set or
              $data[$key] = $DefaultData[$key];
            }
          }
        } else {
          $data[$key] = $DefaultData[$key];
        }
      }
    }
    $styleVal = $data['myStyle'] == "dark" ? "dark" : "light";
    if (isset($_COOKIE['mode'])) {
      if ($_COOKIE['mode'] === "system") {
        if (isset($_COOKIE['colorPref'])) {
          $styleVal = Str::lower($_COOKIE['colorPref']);
        }
      } else {
        $styleVal = $_COOKIE['mode'];
      }
    }
    isset($_COOKIE['theme']) ? $themeVal = $_COOKIE['theme'] : $themeVal = $data['myTheme'];
    //layout classes
    $layoutClasses = [
      'layout' => $data['myLayout'],
      'theme' => $themeVal,
      'themeOpt' => $data['myTheme'],
      'style' => $styleVal,
      'styleOpt' => $data['myStyle'],
      'rtlSupport' => $data['myRTLSupport'],
      'rtlMode' => $data['myRTLMode'],
      'textDirection' => $data['myRTLMode'],
      'menuCollapsed' => $data['menuCollapsed'],
      'hasCustomizer' => $data['hasCustomizer'],
      'showDropdownOnHover' => $data['showDropdownOnHover'],
      'displayCustomizer' => $data['displayCustomizer'],
      'contentLayout' => $data['contentLayout'],
      'headerType' => $data['headerType'],
      'navbarType' => $data['navbarType'],
      'menuFixed' => $data['menuFixed'],
      'footerFixed' => $data['footerFixed'],
      'menuFlipped' => $data['menuFlipped'],
      'customizerControls' => $data['customizerControls'],
    ];

    // sidebar Collapsed
    if ($layoutClasses['menuCollapsed'] == true) {
      $layoutClasses['menuCollapsed'] = 'layout-menu-collapsed';
    }

    // Header Type
    if ($layoutClasses['headerType'] == 'fixed') {
      $layoutClasses['headerType'] = 'layout-menu-fixed';
    }
    // Navbar Type
    if ($layoutClasses['navbarType'] == 'fixed') {
      $layoutClasses['navbarType'] = 'layout-navbar-fixed';
    } elseif ($layoutClasses['navbarType'] == 'static') {
      $layoutClasses['navbarType'] = '';
    } else {
      $layoutClasses['navbarType'] = 'layout-navbar-hidden';
    }

    // Menu Fixed
    if ($layoutClasses['menuFixed'] == true) {
      $layoutClasses['menuFixed'] = 'layout-menu-fixed';
    }


    // Footer Fixed
    if ($layoutClasses['footerFixed'] == true) {
      $layoutClasses['footerFixed'] = 'layout-footer-fixed';
    }

    // Menu Flipped
    if ($layoutClasses['menuFlipped'] == true) {
      $layoutClasses['menuFlipped'] = 'layout-menu-flipped';
    }

    // Menu Offcanvas
    // if ($layoutClasses['menuOffcanvas'] == true) {
    //   $layoutClasses['menuOffcanvas'] = 'layout-menu-offcanvas';
    // }

    // RTL Supported template
    if ($layoutClasses['rtlSupport'] == true) {
      $layoutClasses['rtlSupport'] = '/rtl';
    }

    // RTL Layout/Mode
    if ($layoutClasses['rtlMode'] == true) {
      $layoutClasses['rtlMode'] = 'rtl';
      $layoutClasses['textDirection'] = 'rtl';
    } else {
      $layoutClasses['rtlMode'] = 'ltr';
      $layoutClasses['textDirection'] = 'ltr';
    }

    // Show DropdownOnHover for Horizontal Menu
    if ($layoutClasses['showDropdownOnHover'] == true) {
      $layoutClasses['showDropdownOnHover'] = true;
    } else {
      $layoutClasses['showDropdownOnHover'] = false;
    }

    // To hide/show display customizer UI, not js
    if ($layoutClasses['displayCustomizer'] == true) {
      $layoutClasses['displayCustomizer'] = true;
    } else {
      $layoutClasses['displayCustomizer'] = false;
    }

    return $layoutClasses;
  }

  public static function updatePageConfig($pageConfigs)
  {
    $demo = 'custom';
    if (isset($pageConfigs)) {
      if (count($pageConfigs) > 0) {
        foreach ($pageConfigs as $config => $val) {
          // Config::set('custom.' . $demo . '.' . $config, $val);
        }
      }
    }
  }

  function Logo_pic($pic)
  {
    if ($pic) {
      return url('logos/' . $pic);
    } else {
      return ""; // Return an empty string if no picture is provided
    }
  }

  function Fav_Icon_pic($pic)
  {
    if ($pic) {
      return url('fav_icons/' . $pic);
    } else {
      return ''; // Return an empty string if no picture is provided
    }
  }
  // ******************************** Vasanth ****************************
  // exam Questions 
  public function getStaffGoal_progress_bar($staff_id_get, $departmentId, $month_id, $year_id, $branchId)
  {
    $month_id = $month_id;
    $month    = $month_id;
    $year     = date('Y');
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::whereMonth('za_goal_set_staff.goal_date', $month_id)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->where('za_goal_set_staff.staff_id', $staff_id_get)
      ->first();

    if (!$goalsetRecords) {
      return 0;
    }

    $current_date = date('Y-m-d');
    $branch_id = $branchId;
    $departmentId = $departmentId;

    if ($goalsetRecords->goal_completed == 1) {
      // Sales
      if ($departmentId == 1) {
        $actual = $goalsetRecords->conversion_actual ?? 0;
        $target = $goalsetRecords->conversion ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return round($goal_progress) ;
      }
      // Production
      if ($departmentId == 2) {
        $actual = $goalsetRecords->min_no_of_students_actual ?? 0;
        $target = $goalsetRecords->min_no_of_students ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return round($goal_progress) ;
      }
      // PC
      if ($departmentId == 5) {
        $actual = $goalsetRecords->productions_actual ?? 0;
        $target = $goalsetRecords->productions ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return round($goal_progress);
      }
      // CRE
      if ($departmentId == 6) {
        $actual = $goalsetRecords->no_of_reviews_actual ?? 0;
        $target = $goalsetRecords->no_of_reviews ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return round($goal_progress);
      }
      // Collection Executive
      if ($departmentId == 7) {
        $actual = $goalsetRecords->conversion_actual ?? 0;
        $target = $goalsetRecords->conversion ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return 0;
      }
      // Placement Executive
      if ($departmentId == 8) {
        $actual = $goalsetRecords->mou_actual ?? 0;
        $target = $goalsetRecords->mou ?? 0;
        $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
        // if ($goal_progress > 100) {
        //   $goal_progress = 100;
        // }
        return round($goal_progress);
      }
    }
    // Sales
    if ($departmentId == 1) {
      $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status',[0,6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_lead.created_by', $staff_id_get)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->count();
      $actual = $customerConvertCount ?? 0;
      $target = $goalsetRecords->conversion ?? 0;
      $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
    //   if ($goal_progress > 100) {
    //     $goal_progress = 100;
    //   }
      return round($goal_progress);
    }
    // Production
    if ($departmentId == 2) {

      $current_date = date('Y-m-d'); // Define the current date
      $std_count = TrainingModel::where('za_training.status', 0)
        ->where('za_batch.status', 0)
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->where('za_training.staff_id', $staff_id_get)
        ->where('za_batch.start_date', '<=', $current_date)
        ->where('za_batch.end_date', '>=', $current_date)
        ->count();


      $actual = $std_count ?? 0;
      $target = $goalsetRecords->min_no_of_students ?? 0;
      $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
    //   if ($goal_progress > 100) {
    //     $goal_progress = 100;
    //   }

      return round($goal_progress);
      // Production Goal*********************************************** 
    }
    // PC
    if ($departmentId == 5) {
      // PC Goal *****************************************************
      $staff_pc = StaffModel::where('za_staff.branch_id', $branch_id)
        ->where('za_staff.department_id', 2)
        ->where('za_staff.status', 0)
        ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
        ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
        ->orderBy('staff_name', 'ASC')
        ->get([
          'za_staff.sno',
          'za_staff.staff_name',
          'za_staff.nick_name',
          'za_staff.gender',
          'za_staff.staff_image',
          'za_department.department_name',
          'za_user_role.role_name'
        ]);

      $totalcosting_amount = 0;
      $totalrefferal_count = 0;
      $total_basic_pay_pro = 0;
      foreach ($staff_pc as $staff_pc_list) {
        // Production Goal***********************************************
        $staffproduction = StaffModel::select(
          'za_staff.sno',
          'za_staff.staff_id',
          'za_staff.staff_name',
          'za_staff.gender',
          'za_staff.dob',
          'za_staff.mobile_no',
          'za_staff.email_id',
          'za_staff.staff_image',
          'za_staff.nick_name',
          'za_staff.knowledge_tag',
          'za_staff.per_hour_cost',
          'za_job_position.job_position_name',
          'za_staff.avaiable_points',
          'za_staff.basic_salary',
          'za_staff.status AS staff_status'
        )
          ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
          ->where([
            ['za_staff.status', 0],
            ['za_staff.branch_id', $branch_id],
            ['za_staff.sno', $staff_pc_list->sno]
          ])
          ->orderByDesc('za_staff.sno')
          ->first();

        // Initialize variables
        $total_batch = $total_student = $total_free_batch = $total_staff = 0;
        $overall_earned = $overall_earned_per = $success_staff_count = 0;
        $slotType = $staffproduction;

        $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
        $slotType->present_count = $slotType->course_count = 0;
        $slotType->slotDetails = [];
        $slotType->avg_amnt = $slotType->salary = 0;

        // Fetch batch IDs associated with staff
        $batchIds = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->distinct()
          ->pluck('batch_id')
          ->toArray();

        $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

        foreach ($slotType->batch_ids as $batchId) {
          // Fetch slot details for the staff's batches
          $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
              ->where('staff_id', $slotType->sno)
              ->where(function ($query) use ($month, $year) {
                $query->whereMonth('start_date', '<=', $month)
                  ->whereYear('start_date', '<=', $year)
                  ->whereMonth('end_date', '>=', $month)
                  ->whereYear('end_date', '>=', $year);
              })
              ->pluck('batch_id'))
            ->where('za_batch.status', 0)
            ->get();

          $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

          // Fetch batch details
          $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
            ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->find($batchId);

          if ($batch) {
            $startTime = Carbon::parse($batch->start_time);
            $endTime = Carbon::parse($batch->end_time);
            $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

            // Fetch attendance records
            $attendanceRecords = AttendanceModel::select('per_hr_cost')
              ->where([
                ['batch_id', $batch->sno],
                ['staff_id', $slotType->sno],
                ['attendance', 'P']
              ])
              ->whereMonth('att_date', $month)
              ->whereYear('att_date', $year)
              ->get();

            foreach ($attendanceRecords as $attendance) {
              $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
            }
          }
        }

        // Student count
        $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('customer_id')
          ->count('customer_id');

        // Course count
        $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('course_id')
          ->count('course_id');

        // Batch count
        $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->distinct('batch_id')
          ->count('batch_id');

        // Salary calculation
        $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
        // Average earned percentage calculation
        $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
        // Calculate free batch count
        $total_free_batch = max(0, 8 - $slotType->batch_count);
        $overall_earned += $slotType->earned_amount;
        $overall_earned_per += $slotType->avg_amnt;
        // Count success staff
        if ($slotType->salary < $slotType->earned_amount) {
          $success_staff_count++;
        }
        $staffproduction = $slotType;
        $totalcosting_amount += $staffproduction->earned_amount ?? 0;
        $total_basic_pay_pro += $slotType->basic_salary ?? 0;

        $refferal_count = DB::table('za_referral_persons')
          ->where('branch_id', $branch_id)
          ->where('referral_id', $staff_pc_list->sno)
          ->where('status', 0)
          ->where('referral_type', 2)
          ->whereYear('created_at', $year)
          ->whereMonth('created_at', $month)
          ->count();

        $totalrefferal_count += $refferal_count ?? 0;
      }
      $productions_asign   = $goalsetRecords->productions ?? 0;
      //   return $totalcosting_amount . ' / ' . $total_basic_pay_pro.'*'.$productions_asign;
      $totalcosting_amount2 = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro) *  $productions_asign : 0;

      $actual = $totalcosting_amount2 ?? 0;
      $target = $goalsetRecords->productions ?? 0;
      // return $actual . ' / ' . $target;
      $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
    //   if ($goal_progress > 100) {
    //     $goal_progress = 100;
    //   }

      return round($goal_progress);
      // PC Goal *****************************************************

    }
    // CRE
    if ($departmentId == 6) {
      // CRE Goal *****************************************************
      $review_count = DB::table('za_review')
        ->where('branch_id', $branch_id)
        ->where('created_by', $staff_id_get)
        ->where('status', 0)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();
      $actual = $review_count ?? 0;
      $target = $goalsetRecords->no_of_reviews ?? 0;
      // return $actual . ' / ' . $target;
      $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
    //   if ($goal_progress > 100) {
    //     $goal_progress = 100;
    //   }

      return round($goal_progress);
      // CRE Goal *****************************************************
    }
    // Collection Executive
    if ($departmentId == 7) {
      return 0;
      // Collection Exc *****************************************************
      $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_drop_refund.branch_id', $branch_id)
        ->pluck('za_training.payment_id');

      $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount', '>', 0)
        ->whereIn('za_customer.status',[0,6])
        ->whereMonth('za_payment.nextPayDate', $month)
        ->whereYear('za_payment.nextPayDate', $year)
        ->orderBy('za_payment.sno', 'asc')
        ->count();

      $post_sale_count = DB::table('za_training')
        ->where('created_by', $staff_id_get)
        ->where('post_sale_check', 1)
        ->whereYear('post_sale_date', $year)
        ->whereMonth('post_sale_date', $month)
        ->distinct()
        ->count('customer_id');


      $hacAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->where('za_payment.status', 1) // paid amount
        ->whereIn('za_customer.status',[0,6])
        ->whereYear('za_payment.initialPayDate', $year)
        ->whereMonth('za_payment.initialPayDate', $month)
        ->where('za_payment.branch_id', $branch_id)
        ->sum('za_payment.paidAmount');

      // Collection Exc *****************************************************
    }
    // Placement Executive
    if ($departmentId == 8) {
      $placement_count = DB::table('za_placement_interview')
        ->where('updated_by', $staff_id_get)
        ->where('status', 4)
        ->whereYear('selected_date', $year)
        ->whereMonth('selected_date', $month)
        ->distinct()
        ->count('customer_id');

      $actual = $placement_count ?? 0;
      $target = $goalsetRecords->mou ?? 0;
      // return $actual . ' / ' . $target;
      $goal_progress = $target > 0 ? ($actual / $target) * 100 : 0;
    //   if ($goal_progress > 100) {
    //     $goal_progress = 100;
    //   }

      return round($goal_progress);
    }
    return 0;
  }

  function get_ai_question_data($sno = '')
  {
    $query = DB::table('za_exam_ai_question');

    if (!empty($sno)) {
      $query->where('question_bank_id', $sno);
    }

    return $query->orderBy('sno', 'desc')->first();
  }

  //goalset
  function goal_staff_student_count_data($staff_id = '')
  {
    $current_date = date('Y-m-d'); // Define the current date

    return TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staff_id)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();
  }

  function goal_staff_costing($staff_id = '')
  {
    $result = TrainingModel::where('za_training.status', 0)->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staff_id)->count();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //goalset


  function get_tracker_last_login_data($staff_mobile)
  {

    $other_db = DB::connection('mysql_secondary');
    $select_users = $other_db
      ->table('user as u')
      ->select('u.user_id', 'u.last_sync_date', 'u.last_sync_time')
      ->where('u.phone_no', $staff_mobile)
      ->first();
    return $select_users;
  }

  function get_branch_staff_list_by_id($branch_id)
  {
    $result = StaffModel::select('za_staff.sno', 'za_staff.branch_id', 'za_staff.status', 'za_staff.staff_name', 'za_job_position.job_position_name')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', 0)
      ->where('za_staff.branch_id', $branch_id)


      ->orderBy('za_staff.staff_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_points_by_id($id = '')
  {
    $result = PointsModel::where('status', 0)->where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // Dashboard
  function get_batch_student_count_data($batch = '')
  {
    $result = TrainingModel::where('status', 0)->where('batch_id', $batch)->count();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_batch_today_syllabus_count_data($batch = '')
  {
    $result = SyllabusUpdateModel::where('batch_id', $batch)->whereDate('created_at', '=', date('Y-m-d'))->count();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_staff_student_count_data($staff_id = '')
  {
    $result = TrainingModel::where('za_training.status', 0)->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staff_id)->count();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_staff_courrse_count_data($staff_id = '')
  {
    $result = TrainingModel::where('status', 0)
      ->where('staff_id', $staff_id)
      ->groupBy('course_id')
      ->count();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_staff_student_feedback($staff_id = '')
  {
    // Ensure staff_id is provided and is a valid value
    if (empty($staff_id)) {
      return null;
    }

    // Fetch the results based on the criteria
    $result = AttendanceModel::select("za_attendance.*", "za_course.course_name", "za_batch.batch_name", "za_customer.cus_name", "za_customer.cus_pic", "za_customer.cus_gender")
      ->where('za_attendance.attendance', 'P')
      ->where('za_attendance.feedback', '!=', '')
      ->leftJoin('za_course', 'za_attendance.course_id', '=', 'za_course.sno')
      ->leftJoin('za_customer', 'za_attendance.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_batch', 'za_attendance.batch_id', '=', 'za_batch.sno')
      ->where('za_attendance.staff_id', $staff_id)
      ->orderBy('za_attendance.sno', 'DESC')
      ->limit(5)
      ->get();

    // Return null if no results are found, otherwise return the results
    return $result->isEmpty() ? null : $result;
  }
  function get_staff_student_today_atten($batch_id = '')
  {
    // Ensure batch_id is provided and is a valid value
    if (empty($batch_id)) {
      return null;
    }

    // Fetch the count of records where batch_id matches and created_at is today's date
    $result = AttendanceModel::where('batch_id', $batch_id)
      ->whereDate('created_at', '=', date('Y-m-d'))
      ->orderBy('sno', 'DESC')
      ->count();

    // Return the count if records are found, otherwise return 0
    return $result > 0 ? $result : 0;
  }
  function get_atten_data_student($batch_id = '', $customer_id = '', $date ='')
  {
    // Validate inputs
    if (empty($batch_id) || empty($customer_id) || empty($date)) {
      return ''; // Return an empty string if required inputs are missing
    }

    // Format the date
    $atten_date = date('Y-m-d', strtotime($date));

    // Fetch the first matching record
    $result = AttendanceModel::where('batch_id', $batch_id)
      ->where('att_date', $atten_date)
      ->where('customer_id', $customer_id)
      ->first();

    // Return attendance if the record exists, otherwise return an empty string
    return $result ? $result->attendance : '';
  }
  function get_atten_data_staff($staff_id = '', $date="")
  {
    // Validate inputs
    if (empty($staff_id) || empty($date)) {
      return ''; // Return an empty string if required inputs are missing
    }

    // Format the date
    $atten_date = date('Y-m-d', strtotime($date));

    $result = StaffAttendanceModel::where('date', $atten_date)
      ->where('staff_id', $staff_id)
      ->first();

    // Return attendance if the record exists, otherwise return an empty string
    return $result ? $result->attendance : '';
  }
  // Attendance amount calc student
  function get_student_attendance_amount($cus_sno, $batch_sno, $course_sno)
  {
    $attendance = AttendanceModel::selectRaw('SUM(total_cost) AS total_att_amount, SUM(total_duration) AS total_att_hours')
      ->where('status', 1)
      ->where('attendance', 'P')
      ->where('customer_id', $cus_sno)
      ->where('batch_id', $batch_sno)
      ->where('course_id', $course_sno)
      ->first();

    // Handle null values by using the null coalescing operator
    $totalAttAmount = $attendance->total_att_amount ?? 0;
    $totalAttHours = $attendance->total_att_hours ?? 0;

    // Return both values as an array
    return [
      'total_att_amount' => $totalAttAmount,
      'total_att_hours' => $totalAttHours,
    ];
  }
  function get_payment_percentage($tran_sno, $cus_sno)
  {
    // Retrieve summed paidAmount and individual total_amounts for the specific course and batch
    $paymentDetails = TrainingModel::selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
      ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->where('za_training.customer_id', $cus_sno)
      ->where('za_training.sno', $tran_sno)
      ->groupBy('za_payment.total_amount')
      ->get(); // Use `get()` to handle multiple rows

    // Initialize total variables
    $totalPaidAmount = 0;
    $totalAmount = 0;

    // Iterate over the result set to accumulate values
    foreach ($paymentDetails as $payment) {
      $totalPaidAmount += $payment->total_paid_amount;
      $totalAmount += $payment->total_amount;
    }

    // Initialize payment percentage to 0
    $paymentPercentage = 0;

    // Calculate payment percentage if valid data is retrieved
    if ($totalAmount > 0) {
      $paymentPercentage = number_format(
        ($totalPaidAmount / $totalAmount) * 100,
        1
      );
    }

    // Return the calculated percentage
    return $paymentPercentage;
  }
  
  function get_payment_paid_amount($tran_sno, $cus_sno)
  {
    // Retrieve summed paidAmount and individual total_amounts for the specific course and batch
    $paymentDetails = TrainingModel::selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
      ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->where('za_training.customer_id', $cus_sno)
      ->where('za_training.sno', $tran_sno)
      ->groupBy('za_payment.total_amount')
      ->get(); // Use `get()` to handle multiple rows

    // Initialize total variables
    $totalPaidAmount = 0;
    $totalAmount = 0;

    // Iterate over the result set to accumulate values
    foreach ($paymentDetails as $payment) {
      $totalPaidAmount += $payment->total_paid_amount;
      $totalAmount += $payment->total_amount;
    }

    // Initialize payment percentage to 0
    $paymentPercentage = 0;

    // Calculate payment percentage if valid data is retrieved
    if ($totalAmount > 0) {
      $paymentPercentage = number_format(
        ($totalPaidAmount / $totalAmount) * 100,
        1
      );
    }

    // Return the calculated percentage
    return $totalPaidAmount;
  }
  function get_long_absent_customers($cus_sno)
  {
    $absentDates = AttendanceModel::where('customer_id', $cus_sno)
      ->where('attendance', 'A')
      ->orderBy('att_date', 'desc')
      ->pluck('att_date')
      ->toArray();

    $consecutiveCount = 1;
    for ($i = 1; $i < count($absentDates); $i++) {
      $prev = strtotime($absentDates[$i - 1]);
      $curr = strtotime($absentDates[$i]);

      if ($prev === strtotime('+1 day', $curr)) {
        $consecutiveCount++;
      } else {
        // break; // Stop when not continuous
      }
    }

    return $consecutiveCount;
  }




  function get_course_percentage($tran_sno, $cus_sno)
  {
    // Fetch training details
    $training = TrainingModel::find($tran_sno);
    if (!$training) {
      return 0; // If no training record found, return 0% progress
    }

    $batch_id = $training->batch_id;
    $course_id = $training->course_id;

    // Fetch attendance records with 'P' status
    $attendanceDates = AttendanceModel::where('customer_id', $cus_sno)
      ->where('batch_id', $batch_id)
      ->where('attendance', 'P')
      ->pluck('att_date'); // Fetch only dates for efficiency

    if ($attendanceDates->isEmpty()) {
      return 0; // No attendance records, return 0% progress
    }

    // Fetch the total number of course topics
    $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)->where('status', 0)->count();

    if ($course_topic_count == 0) {
      return 0; // Avoid division by zero
    }

    // Fetch syllabus updates for the attended dates
    $topicCount = SyllabusUpdateModel::where('batch_id', $batch_id)
      // ->whereIn('date', $attendanceDates)
      ->where('percentage', '100')
      ->distinct()
      ->count('sno'); // Ensure distinct topic count

    // Calculate course progress as a percentage
    $courseProgress = ($topicCount / $course_topic_count) * 100;

    // Cap the progress at 100% and format to 2 decimal places
    return number_format(min($courseProgress, 100), 2);
  }
  
  function get_course_total_days($tran_sno, $cus_sno)
  {
      // Fetch training details
      $training = TrainingModel::find($tran_sno);
      if (!$training) {
          return 0; // If no training record found, return 0
      }
 
      $batch_id = $training->batch_id;
      $course_id = $training->course_id;
 
   
      $totalCoursesDays = ManageCoursesModel::where('sno', $course_id)
          ->where('status', 0)
          ->first();
 
      return $totalCoursesDays->course_days;
  }
  
  function get_course_drop_percentage($tran_sno, $cus_sno)
  {
    // Fetch training details
    $training = TrainingModel::find($tran_sno);
    if (!$training) {
      return 0; // If no training record found, return 0% progress
    }
 
    $batch_id = $training->batch_id;
    $course_id = $training->course_id;
 
    // Fetch attendance records with 'P' status
    $attendanceDates = AttendanceModel::where('customer_id', $cus_sno)
      ->where('batch_id', $batch_id)
      ->where('attendance', 'P')
      ->pluck('att_date'); // Fetch only dates for efficiency
 
    if ($attendanceDates->isEmpty()) {
      return 0; // No attendance records, return 0% progress
    }
 
    $attendanceCount = AttendanceModel::where('customer_id', $cus_sno)
      ->where('batch_id', $batch_id)
      ->where('attendance', 'P')
      ->count(); // Fetch only dates for efficiency
 
    // Fetch the total number of course topics
    $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)->where('status', 0)->count();
 
    if ($course_topic_count == 0) {
      return 0; // Avoid division by zero
    }
 
    // Fetch syllabus updates for the attended dates
    $topicCount = SyllabusUpdateModel::where('batch_id', $batch_id)
      // ->whereIn('date', $attendanceDates)
      ->where('percentage', '100')
      ->distinct()
      ->count('sno'); // Ensure distinct topic count
 
    // Calculate course progress as a percentage
    $courseProgress = ($attendanceCount / $topicCount) * 100;
 
 
    // Cap the progress at 100% and format to 2 decimal places
    return number_format(min($courseProgress, 100), 2);
  }
  
  
   function get_course_present_days($tran_sno, $cus_sno)
{
    // Fetch training details
    $training = TrainingModel::find($tran_sno);
    if (!$training) {
        return 0; // If no training record found, return 0
    }

    $batch_id = $training->batch_id;

    // Count the number of 'P' (present) attendances for this customer in the batch
    $presentDays = AttendanceModel::where('customer_id', $cus_sno)
        ->where('batch_id', $batch_id)
        ->where('attendance', 'P')
        ->count();

    return $presentDays;
}



  // schedule_messages
  public function scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId)
  {
    try {
      $addMessage = new Schedule_message_model();
      $addMessage->config_id = $configId;
      $addMessage->source_type_id = $sourceTypeId;
      $addMessage->source_id  = $sourceId;
      $addMessage->branch_id  = $branchId;
      $addMessage->created_by = $userId;
      $addMessage->updated_by = $userId;
      $addMessage->save();
      return response()->json([
        'status' => 200,
        'message' => 'Successfully scheduled message!',
        'error_msg' => null,
        'data' => $addMessage,
      ], 200);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Error scheduling message.',
        'error_msg' => $e->getMessage(),
        'data' => null,
      ], 500);
    }
  }

  //   GET ROLE USRMANAGEMENT
  function get_roles_list()
  {
    // Fetch roles from the UserRoleModel
    $roles = UserRoleModel::where('status', 0)->get();

    // Fetch the role IDs from UserRolePermissionModel
    $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

    // Filter roles to exclude those that are in userRolePermissions
    $filteredRoles = $roles->filter(function ($role) use ($userRolePermissions) {
      return !in_array($role->sno, $userRolePermissions); // Exclude roles with matching role_id
    });

    return $filteredRoles;
  }
  
  //   GET ROLE USRMANAGEMENT
  function get_roles_task()
  {
    // Fetch roles from the UserRoleModel
    $roles = UserRoleModel::where('status', 0)->whereNotIn('sno', [1,9])->get();

    // Filter roles to exclude those that are in userRolePermissions
    $filteredRoles = $roles;

    return $filteredRoles;
  }

  // Get SmS Tempalate
  function get_sms_template($id = '')
  {
    $result = SmsTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Whatsapp Template
  function get_whatsapp_template($id = '')
  {
    $result = WhatsappTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Email Template
  function get_email_template($id = '')
  {
    $result = EmailTemplateModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_roles_list_nav($user_id = null)
    {
        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();
    
        // Get the user details
        $user = StaffModel::where('sno', $user_id)->first();
    
        // Special case for user with sno = 124
        if ($user && $user->sno == 124) {
            // Exclude roles with ID 1 and 11
            $matchingRoles = UserRoleModel::where('status', 0)
                ->whereNotIn('sno', [9])
                ->whereIn('sno', $userRolePermissions)
                ->get();
        } else {
            $matchingRoles = UserRoleModel::where('status', 0)
                ->whereIn('sno', $userRolePermissions)
                ->get();
        }
    
        return $matchingRoles;
    }

  // Get Branch and Franchise list based on user_id
  function get_branch_control_list($user_id)
  {
    // Fetch the user based on user_id
    $user = StaffModel::where('sno', $user_id)->first();

    if ($user && ($user->sno == 124 || $user->sno == 259)) {
      $branches = BranchModel::whereNotIn('sno', [1,11,18])
        ->where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();

      return ['branches' => $branches, 'franchises' => $franchises];
    } elseif ($user !== null) {
      // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
      $accessibleBranches = json_decode($user->multi_branch_access, true);

      if (!empty($accessibleBranches)) {
        // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
        $branches = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 1)
          ->get();

        $franchises = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 2)
          ->get();

        return ['branches' => $branches, 'franchises' => $franchises];
      }
    } else {
      // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
      $branches = BranchModel::where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();
      return ['branches' => $branches, 'franchises' => $franchises];
    }
  }
  
       // Get Branch and Franchise list based on user_id
  function get_branch_control_list_job($user_id)
  {
    // Fetch the user based on user_id
    $user = StaffModel::where('sno', $user_id)->first();
 
   
      $branches = BranchModel::whereNotIn('sno', [1,11,18])
        ->where('status', 0)
        ->where('branch_type', 1)
        ->get();
 
      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();
 
      return ['branches' => $branches, 'franchises' => $franchises];
   
  }
  
  // Get Branch and Franchise list based on user_id
  function get_branch_control_list_user($user_id)
  {
    // Fetch the user based on user_id
    $user = StaffModel::where('sno', $user_id)->first();

    if ($user && ($user->sno == 124 || $user->sno == 259)) {
      $branches = BranchModel::whereNotIn('sno', [1,11,18])
        ->where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();

      return ['branches' => $branches, 'franchises' => $franchises];
    } elseif ($user !== null) {
      // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
      $accessibleBranches = json_decode($user->multi_branch_access, true);

      if (!empty($accessibleBranches)) {
        // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
        $branches = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 1)
          ->get();

        $franchises = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 2)
          ->get();

        return ['branches' => $branches, 'franchises' => $franchises];
      }
    } else {
      // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
      $branches = BranchModel::where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();
      return ['branches' => $branches, 'franchises' => $franchises];
    }
  }


  // common Date Format
  function general_setting_data()
  {
    $sno = 1;
    $result = GeneralSettingsModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // encrypt_decrypt
  function encrypt_decrypt($string, $action = 'encrypt')
  {
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'EAPL'; // Change this to your secret key
    $secret_iv = 'YourSecretIV'; // Change this to your secret IV

    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

    if ($action == 'encrypt') {
      $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
      $output = base64_encode($output);
    } elseif ($action == 'decrypt') {
      $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    } else {
      $output = false;
    }

    return $output;
  }
  // Get Country Names by ID
  function get_country_data($id = '')
  {
    $result = CountryModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get State Names by ID
  function get_state_data($id = '')
  {
    $result = StateModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get City Names by ID
  function get_city_data($id = '')
  {
    $result = CityModel::where('id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // Get Branch list
  function get_branch_list()
  {
    $result = BranchModel::where('status', 0)->where('branch_type', 1)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_branch_franchise_list()
  {
    $result = BranchModel::where('status', 0)->where('sno', '!=', 1)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  
  public static function maskMobileNumber($mobileNumber, $roleId, $hideRoles = [])
    {
        // If role ID is in the list of roles that should have the mobile number masked
        if (in_array($roleId, $hideRoles)) {
            // Mask last 5 digits with '*'
            $length = strlen($mobileNumber);
            if ($length >= 5) {
                return substr($mobileNumber, 0, $length - 5) . str_repeat('x', 5);
            }
        }
     
        // Return full mobile number if not in hideRoles or number is too short
        return $mobileNumber;
    }

  // Get Franchise list
  function get_franchise_list()
  {
    $result = BranchModel::where('status', 0)->where('branch_type', 2)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Branch id
  function get_branch_id($sno = "")
  {
    $result = BranchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get Franchise list
  function get_franchise_id($sno = "")
  {
    $result = BranchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Role list
  function get_role_list()
  {
    $result = UserRoleModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // get Role list
  function get_role_list_ceo()
  {
    $result = UserRoleModel::where('status', 0)->where('sno', '!=', 1)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_role_list_branch()
  {
    $result = UserRoleModel::where('status', 0)
      ->where('sno', '!=', 1)
      ->whereIn('sno', [11, 12, 13, 15, 16, 22, 25, 21, 14, 24,38,40])
      ->get();

    if ($result->isNotEmpty()) {
      return $result;
    } else {
      return null;
    }
  }

  // get Role id
  function get_role_id($sno = "")
  {
    $result = UserRoleModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Staff by id
  function get_staff_data($id = '')
  {
    $result = StaffModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Staff list
  function get_staff_list()
  {
    $result = StaffModel::where('status', 0)->orderBy('staff_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Name imgae user
  function name_image($ins = "A", $gender ="1")
  {
    // Array of all avatar divs
    if ($gender === 1) {
      $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-success'>" . $ins . "</span>
            </div>";
    } else if ($gender === 2) {
      $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-info'>" . $ins . "</span>
            </div>";
    } else {
      $divs = "<div class='avatar  me-2'>
              <span class='avatar-initial rounded-circle bg-label-warning'>" . $ins . "</span>
            </div>";
    }

    return $divs;
  }
  // get course type data
  function get_course_type_data($sno = '')
  {
    $result = CourseTypeModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_course_data($sno = '')
  {
    $result = ManageCoursesModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_course_name_by_id($sno = '')
  {
    $result = ManageCoursesModel::select('course_name')->where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_batch_data($sno = '')
  {
    $result = BatchModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_slot_data($sno = '')
  {
    $result = SlotModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function tcourse_data($sno = '')
  {
    $result = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name')
      ->from('za_course')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.sno', $sno)
      ->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // Get course category data
  function get_course_category_data($sno = '')
  {
    $result = CourseCategoryModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Get course Sub category data
  function get_course_subcategory_data($sno = '')
  {
    $result = CourseSubCategoryModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Brand
  function get_course_brand_data($sno = '')
  {
    $result = BrandModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Group
  function get_course_group_data($sno = '')
  {
    $result = GroupModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Jobe Roll
  function get_course_job_role_data($sno = '')
  {
    $result = JobRollModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Free gigt
  function get_gifts_data($sno = '')
  {
    $result = GiftModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_event_name_data($sno = '')
  {
    $result = DB::table('za_event')->where('sno', $sno)->select('sno','event_name')->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  
  //pre skill set
  function get_course_pre_skill_data($sno = '')
  {
    $result = PreSkillSetModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //knowledge level list by id
  function get_knowledge_level_data($sno = '')
  {
    $result = KnowledgeLevelModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // knowledge level list
  function get_knowledge_level_list()
  {
    $result = KnowledgeLevelModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list
  function get_course_action_data($id = '')
  {
    $result = CourseActionModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list
  function get_course_action_list()
  {
    $result = CourseActionModel::where('status', 0)->orderBy('course_action_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Course Action list Count in Chapter
  function get_course_action_count_list($id = '')
  {

    $result = ManageCoursesSyllabusModel::selectRaw('COUNT(za_course_chapter.course_action_id) AS count, MAX(za_course_action.course_action_icon) AS course_action_icon, MAX(za_course_action.course_action_name) AS course_action_name')
      ->leftJoin('za_course_action', 'za_course_chapter.course_action_id', '=', 'za_course_action.sno')
      ->where('za_course_chapter.course_chapter_id', $id)
      ->where('za_course_chapter.status', 0)
      ->groupBy('za_course_chapter.course_action_id')
      ->get();
    return $result->isEmpty() ? null : $result;
  }
  //Course Chapter Get by course id
  function get_course_chapter_id($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('course_id', $id)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Chapter Get by course id Group
  function get_course_chapter_group_id($id = '')
  {
    $result = ManageCoursesSyllabusModel::selectRaw('MAX( sno ) AS max_sno')
      ->where('course_id', $id)
      ->where('status', 0)
      ->groupBy('course_chapter_id')
      ->get();

    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Chapter
  function get_course_chapter_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('course_chapter_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course section
  function get_course_section_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('session_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //Course Topic
  function get_course_topic_data($id = '')
  {
    $result = ManageCoursesSyllabusModel::where('topic_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function topic_complete_data($id = '', $batch = '')
  {
    $result = SyllabusUpdateModel::where('topic_id', $id)->where('batch_id', $batch)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_course_section_com_percentage($currentSessionId = '', $batch = '', $course = '', $chapterId = '')
  {
    if (empty($currentSessionId) || empty($batch)) {
      return [
        'percentage' => 0,
        'prev_percentage' => 0
      ];
    }

    // Total syllabus sections for the current session
    $ses_count = ManageCoursesSyllabusModel::where('session_id', $currentSessionId)
      ->where('course_id', $course)
      // ->where('course_chapter_id', $chapterId)
      ->where('status', 0)
      ->count();

    // Completed syllabus sections for the current session
    $complete = SyllabusUpdateModel::where('section_id', $currentSessionId)
      ->where('batch_id', $batch)
      ->where('status', 0)
      ->count();

    $percentage = ($ses_count > 0) ? round(($complete / floatval($ses_count)) * 100, 2) : 0;

    $current_ses = ManageCoursesSyllabusModel::where('session_id', $currentSessionId)
      ->where('course_id', $course)
      ->where('status', 0)
      //  ->where('course_chapter_id', $chapterId)
      ->orderBy('session_id', 'desc')
      ->first();
    // Get previous session
    $previousSession = ManageCoursesSyllabusModel::where('session_id', '<', $currentSessionId)
      ->where('course_id', $course)
      ->where('status', 0)
      ->orderBy('session_id', 'desc')
      ->first();
    $prev_percentage = 0;

    if ($previousSession) {
      $prev_ses_count = ManageCoursesSyllabusModel::where('session_id', $previousSession->session_id)
        ->where('course_id', $course)
        ->where('status', 0)
        ->count();

      $prev_complete = SyllabusUpdateModel::where('section_id', $previousSession->session_id)
        ->where('batch_id', $batch)
        ->where('status', 0)
        ->count();

      $prev_percentage = ($prev_ses_count > 0) ? round(($prev_complete / floatval($prev_ses_count)) * 100, 2) : 0;
    }

    return [
      'percentage' => $percentage,
      'prev_percentage' => $prev_percentage
    ];
  }

  function get_course_section_com_percentage_batch_summary($id = '', $batch = '')
  {
    $ses_count = ManageCoursesSyllabusModel::where('session_id', $id)->where('status', 0)->count();
    $complete  = SyllabusUpdateModel::where('section_id', $id)->where('batch_id', $batch)->where('status', 0)->count();
    if ($ses_count > 0) {
      $percentage = ($complete / $ses_count) * 100;
    } else {
      $percentage = 0;
    }
    return round($percentage, 2);
  }
  function get_question_bank_count($id = '')
  {
    $result = ManageQuestionModel::where('question_bank_id', $id)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_examers_count($id = '')
  {
    $result = Student::where('exam_id', $id)->count();
    if ($result !== null) {
      return $result;
    } else {
      return 0;
    }
  }
  function exam_details($exam_id)
  {

    $results = ExamModel::select('*')->where('sno', $exam_id)->get();

    return $results;
  }
  // document type List
  function get_document_type_list()
  {
    $result = DocumentTypeModel::where('status', 0)->orderBy('documenttype_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // branch Category List
  function get_branch_category_list()
  {
    $result = BranchTypeModel::where('status', 0)->orderBy('branchtype_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Department List
  function get_department_list()
  {
    $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }


  function get_department_list_mngment()
  {
    $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }


  // branch Category ID
  function get_branch_category_id($id = '')
  {
    $result = BranchTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // branch time zone ID
  function get_time_zone_id($id = '')
  {
    $result = TimeZoneModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // branch currency format ID
  function get_currency_format_id($id = '')
  {
    $result = CurrencyFormatModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_department_id($id = '')
  {
    $result = DepartmentModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  //position
  function get_position_id($id = '')
  {
    $result = JobpositionModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Document By id
  function get_document_id($id = '')
  {
    $result = DocumentTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function absent_list_two_days()
  {

    $startDate = now()->subDays(2)->startOfDay();
    $endDate = now()->endOfDay();


    $attendance = StaffAttendanceModel::where('attendance', 'A')
      ->whereBetween('date', [$startDate, $endDate])
      ->pluck('staff_id');

    return $attendance;
  }

  function absent_list_seven_days()
  {

    $startDate = now()->subDays(7)->startOfDay();
    $endDate = now()->endOfDay();


    $attendance = StaffAttendanceModel::where('attendance', 'A')
      ->whereBetween('date', [$startDate, $endDate])
      ->pluck('staff_id');

    return $attendance;
  }

  // Course assign By branch id
  function get_course_assign_branchid($id = '')
  {
    $result = CourseAssigne_model::where('branch_id', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  // rosini
  function getFollowupCount($lead_id)
  {
    $lead =  AppointmentModel::select('*')->where('lead_id', $lead_id)->where('progressed', '=', 1)->count();

    return $lead ? $lead : 0;
  }
  function get_coupon_used_by_id($modal_id = "", $user_id = "")
  {

    if ($modal_id == 1) {
      $coupon_usage_history = ManageCouponHistoryModel::select(
        'za_lead.lead_name as person_name',
        'za_lead.lead_mobile as mobile_no'
      )
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_coupon_usage_history.used_by')
        ->where('za_lead.sno', $user_id)
        ->first();
      if ($coupon_usage_history) {
        return '
            <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
            <div class="d-block">
                <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
            </div>';
      }
    } elseif ($modal_id == 2) {

      $coupon_usage_history = ManageCouponHistoryModel::select(
        'za_customer.cus_name as person_name',
        'za_customer.cus_mobile as mobile_no'
      )
        ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_coupon_usage_history.used_by')
        ->where('za_customer.sno', $user_id)
        ->first();
      if ($coupon_usage_history) {
        return '
              <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
              <div class="d-block">
                  <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
              </div>';
      }
    }
  }
  function get_coupon($branch_id)
  {

    $coupon_list = ManageCouponModel::select('*')
      ->where('za_manage_coupon.public_check', 1)
      ->where('za_manage_coupon.status', 0)
      ->where('za_manage_coupon.branch_id', $branch_id)
      ->get();


    return $coupon_list;
  }
  public function convertNumberToWords($number)
  {
    $words = [
      '0' => 'Zero',
      '1' => 'One',
      '2' => 'Two',
      '3' => 'Three',
      '4' => 'Four',
      '5' => 'Five',
      '6' => 'Six',
      '7' => 'Seven',
      '8' => 'Eight',
      '9' => 'Nine',
      '10' => 'Ten',
      '11' => 'Eleven',
      '12' => 'Twelve',
      '13' => 'Thirteen',
      '14' => 'Fourteen',
      '15' => 'Fifteen',
      '16' => 'Sixteen',
      '17' => 'Seventeen',
      '18' => 'Eighteen',
      '19' => 'Nineteen',
      '20' => 'Twenty',
      '30' => 'Thirty',
      '40' => 'Forty',
      '50' => 'Fifty',
      '60' => 'Sixty',
      '70' => 'Seventy',
      '80' => 'Eighty',
      '90' => 'Ninety'
    ];

    $suffixes = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];

    // For numbers less than 21, we can directly return the word.
    if ($number < 21) {
      return $words[$number];
    }

    // Handle numbers less than 100
    elseif ($number < 100) {
      $tens = floor($number / 10) * 10;
      $ones = $number % 10;
      return $words[$tens] . ($ones ? ' ' . $words[$ones] : '');
    }

    // Handle numbers less than 1000
    elseif ($number < 1000) {
      $hundreds = floor($number / 100);
      $remainder = $number % 100;
      $wordsString = $words[$hundreds] . ' ' . $suffixes[1];
      if ($remainder) {
        $wordsString .= ' ' . $this->convertNumberToWords($remainder);
      }
      return $wordsString;
    }

    // Handle numbers in the thousands range
    elseif ($number < 100000) {
      $thousands = floor($number / 1000);
      $remainder = $number % 1000;
      $wordsString = $this->convertNumberToWords($thousands) . ' ' . $suffixes[2];
      if ($remainder) {
        $wordsString .= ' ' . $this->convertNumberToWords($remainder);
      }
      return $wordsString;
    }

    // Handle numbers in the lakhs range
    elseif ($number < 10000000) {
      $lakhs = floor($number / 100000);
      $remainder = $number % 100000;
      $wordsString = $this->convertNumberToWords($lakhs) . ' ' . $suffixes[3];
      if ($remainder) {
        $wordsString .= ' ' . $this->convertNumberToWords($remainder);
      }
      return $wordsString;
    }

    // Handle numbers in the crores range
    elseif ($number < 1000000000) {
      $crores = floor($number / 10000000);
      $remainder = $number % 10000000;
      $wordsString = $this->convertNumberToWords($crores) . ' ' . $suffixes[4];
      if ($remainder) {
        $wordsString .= ' ' . $this->convertNumberToWords($remainder);
      }
      return $wordsString;
    }
  }
  public function batch_completed_days($id = '')
  {
    $customer_count = BatchHistoryModel::where('batch_id', $id)->where('attendance', 'P')->count();
    return $customer_count > 0 ? $customer_count : 0;
  }
  public function customer_fee_not_paid_count($id = '')
  {
    $customer_data = TrainingModel::where('batch_id', $id)->get();

    $fee_unpaid_count = 0;

    foreach ($customer_data as $customer) {
      if ($customer->total_amount > $customer->paid_amount) {
        $fee_unpaid_count++;
      }
    }

    return $fee_unpaid_count;
  }
  public function branch_franchise($id = '')
  {

    $branch_data = BranchModel::where('sno', $id)->first();

    if ($branch_data) {
      if ($branch_data->branch_type == 2) {
        return $branch_data->franchise_name;
      } else {
        return $branch_data->branch_name;
      }
    }
    return $branch_data;
  }
  function get_rules_data($id = '')
  {
    $user = StaffModel::select('za_staff.*', 'za_department.department_name', 'za_sub_department.sub_department_name')
      ->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->leftJoin('za_sub_department', 'za_staff.sub_department_id', '=', 'za_sub_department.sno')
      ->where('za_staff.status', '!=', 2)
      ->where('za_staff.sno', $id)
      ->first();


    $editcategory = Rules_guidelinesModel::select('za_rules_guidelines.*', 'za_department.department_name', 'za_sub_department.sub_department_name')
      ->leftJoin('za_department', 'za_rules_guidelines.department_id', '=', 'za_department.sno')
      ->leftJoin('za_sub_department', 'za_rules_guidelines.sub_dept_id', '=', 'za_sub_department.sno')
      ->where('za_rules_guidelines.status', '!=', 2)
      ->where('za_department.sno', $user->department_id)
      ->where('za_sub_department.sno', $user->sub_department_id)
      ->first();

    // return $editcategory;

    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $editcategory
    ], 200);
  }
  function get_chapter_status($chapter_id, $batch_id)
  {
    // Get the total number of topics associated with the chapter (status = 0)
    $totalTopics = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
      ->where('status', 0)  // Filter by status (not completed)
      ->count();

    // Get the count of completed topics (status = 1, or based on your requirement)
    $completedTopics = SyllabusUpdateModel::where('chapter_id', $chapter_id)
      ->where('batch_id', $batch_id)
      ->where('status', 0) // Assuming 1 means completed, adjust as needed
      ->count();

    // Calculate the total completion percentage (avoid division by zero)
    $totalPercentage = ($totalTopics > 0) ? ($completedTopics / $totalTopics) * 100 : 0;

    // Determine badge label based on completion
    if ($completedTopics === $totalTopics) {
      $badgeLabel = 'Completed';
    } elseif ($totalPercentage > 0) {
      $badgeLabel = 'In Progress';
    } else {
      $badgeLabel = 'Not yet Started';
    }
    return $badgeLabel;
  }

  // get financial year list
  function get_fin_yr()
  {
    $result = FinancialYearModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_fin_year_by_sno($id = '')
  {
    $result = FinancialYearModel::where('sno', $id)->where('status', 0)->first();

    // Check if a record was found
    if ($result !== null) {
      return $result; // Return the single instance
    } else {
      return null; // Return null if no results found
    }
  }
  // facility Roll
  function get_branch_staff_list($branch_id)
  {
    $result = StaffModel::where('status', 0)->where('branch_id', $branch_id)->orderBy('staff_name', "ASC")->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  function get_facility_data($sno = '')
  {
    $result = FacilityModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Shift time list
  function get_shift_time()
  {
    $result = ShiftTimeModel::where('status', 0)->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // get Shift time id
  function get_shift_time_id($sno = " ")
  {
    $result = ShiftTimeModel::where('sno', $sno)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }



  function get_course_syllabus_data($batch, $chapter, $sec, $topic = '')
  {
    // return $batch;
    $result =  SyllabusUpdateModel::where('batch_id', $batch)
      ->where('chapter_id', $chapter)
      ->where('section_id', $sec)
      // ->whereIn('topic_id', $latest_topics->pluck('topic_id')->toArray())
      // ->where('staff_id', $batch->staff_id)
      ->get();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // ********************************* Rajkumar I Start **************************************
  // Get Hr Sub Branch 

  function get_hr_sub_branch($id = '')
  {
    $result = HrDirectoryBranchModel::where('company_id', $id)->where('status', 0)->get();
    return $result;
  }

  //interview type ID
  function get_interview_type_id($id = '')
  {
    $result = InterviewTypeModel::where('sno', $id)->first();
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }
  // Company Hr Directory BY ID
  function get_company_hr_id($id = '')
  {
    $result = HrDirectoryModel::where('sno', $id)->first();
    // return $result;

    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  function get_total_vacancy_by_company_id($id = '')
  {
    // Retrieve all records for the given company ID
    $results = JobDirectoryModel::select('vacancy_count')->where('job_company_id', $id)->get();

    // Initialize total vacancy count
    $total_count_vacancy = 0;

    // Iterate through each result
    foreach ($results as $result) {
      // Decode JSON
      $vacancy_count = json_decode($result->vacancy_count, true);

      // Check if the decoded value is an array
      if (is_array($vacancy_count)) {
        // Sum the values
        $total_count_vacancy += array_sum($vacancy_count);
      }
    }

    return $total_count_vacancy; // Return the total count
  }


  function Student_attendance($id = '', $customer_id = '')
  {
    $result = SyllabusUpdateModel::select('za_attendance.attendance')->where('topic_id', $id)
      ->where('za_attendance.customer_id', $customer_id)
      ->leftJoin('za_attendance', 'za_attendance.att_date', '=', 'za_syllabus_update.date')
      ->first();

    return $result->attendance ?? '';
  }
  function course_topic_date($id = '')
  {
    $result = SyllabusUpdateModel::select('za_syllabus_update.date')->where('topic_id', $id)
      ->first();
    // dd($result);
    return $result && $result->date ? $result->date : 0;

    // return $result->date ?? '';
  }
  function get_customer_course_section_com_percentage($id = '', $batch = '')
  {

    $ses_count = ManageCoursesSyllabusModel::where('session_id', $id)->where('status', 0)->count();

    $complete  = SyllabusUpdateModel::where('section_id', $id)->where('batch_id', $batch)->where('status', 0)->count();
    if ($ses_count > 0) {
      $percentage = ($complete / $ses_count) * 100;
    } else {
      $percentage = 0;
    }
    // dd( $percentage);
    return round($percentage, 2);
  }

  function Student_attendance_calculation($id = '', $att = '')
  {
    $result = AttendanceModel::where('customer_id', $id)
      ->where('attendance', $att)
      ->where('status', 1)
      ->count(); // Use count() instead of SUM(*)
    // return 0;

    return $result > 0 ? $result : 0; // Return result or null

  }
  function calculate_percentage($part, $total)
  {
    // dd($part, $total);
    if ($total == 0) {
      return 0; // Avoid division by zero
    }
    return ($part / $total) * 100;
  }
  function paymentnumberToWords($num)
  {
    $ones = [
      '',
      'First',
      'Second',
      'Third',
      'Fourth',
      'Fifth',
      'Sixth',
      'Seventh',
      'Eighth',
      'Ninth',
      'Tenth',
      'Eleventh',
      'Twelfth',
      'Thirteenth',
      'Fourteenth',
      'Fifteenth',
      'Sixteenth',
      'Seventeenth',
      'Eighteenth',
      'Nineteenth'
    ];

    $tens = [
      '',
      '',
      'Twentieth',
      'Thirtieth',
      'Fortieth',
      'Fiftieth',
      'Sixtieth',
      'Seventieth',
      'Eightieth',
      'Ninetieth'
    ];

    $thousands = ['', 'Thousand'];

    // Return "Initial" for zero payment
    if ($num == 0) {
      return 'Initial';
    }

    $words = '';

    if ($num >= 1000) {
      $words .= $ones[intval($num / 1000)] . ' ' . $thousands[1] . ' ';
      $num %= 1000;
    }

    if ($num >= 100) {
      $words .= $ones[intval($num / 100)] . ' Hundred ';
      $num %= 100;
    }

    if ($num >= 20) {
      $words .= $tens[intval($num / 10)] . ' ';
      $num %= 10;
    }

    if ($num > 0) {
      $words .= $ones[$num] . ' ';
    }

    return trim($words);
  }

  function get_verify_activity_count($id = '')
  {
    $count = MarketingModel::where('status', 0)
      ->where('sno', $id)
      ->first();

    if ($count !== null) {
      return $count;
    } else {
      return null;
    }
  }


  // ********************************* Rajkumar I End **************************************
  function get_total_interested_by_job_id($id = " ")
  {
    $results = CustomerPlacementModel::where('job_name_id', $id)->get(); // To get the records
    $results_count = $results->count(); // To get the count of records
    // dd($results_count);


    return $results_count;
  }


  function GRADE_LOGO_PIC_PATH($pic)
  {
    if ($pic) {
      return url('grade_logo/' . $pic);
    } else {
      return '';
    }
  }


  function get_profile_image_url($staff_image, $default = 'assets/eapl_images/Super-Admin.png')
  {
    $path = public_path($staff_image);
    return file_exists($path) ? asset($staff_image) : asset($default);
  }
  // material type name by id
  function get_material_typeName($sno = '')
  {
    // return $sno;
    $result = MaterialTypeModel::where('sno', $sno)->value('material_type_name');
    if ($result !== null) {
      return $result;
    } else {
      return null;
    }
  }

  //here need create helfer funtion for notification message from notification type based to fetch 

  public function createNotification(array $data, $notificationtype)
  {
    // Step 1: Find the Notification Type based on the name
    $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();

    // Check if notification type exists and proceed
    if ($notificationType) {
      // Decode the JSON string array of roles
      $rolesArray = json_decode($notificationType->notification_roles, true);

      // Step 2: Fetch staff based on branch, status, and roles array
      $staffMembers = StaffModel::where('branch_id', $data['branch_id'])
        ->where('status', 0) // Assuming 0 is the active status
        ->whereIn('role_id', $rolesArray)
        ->get();

      // Step 3: Prepare notifications for each staff member
      $notifications = [];
      foreach ($staffMembers as $staff) {
        $notificationData = [
          'branch_id'            => $data['branch_id'] ?? 0,
          'notification_type_id' => $notificationType->sno,
          'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
          'notification_content' => $data['notification_content'],
          'notification_date'    => now(),
          'who'                  => $data['who'] ?? '0',
          'whom'                 => $staff->sno,
          'created_by'           => $data['created_by'] ?? 0,
          'updated_by'           => $data['updated_by'] ?? 0,
          'status'               => $data['status'] ?? 0
        ];

        // Insert the notification and store the result
        $notifications[] = NotificationModel::create($notificationData);
      }

      return $notifications; // Return all created notifications
    }

    // Return null if notification type was not found
    return null;
  }
  //   AK max
  // incoming call
  function incoming_call_count($staff_id)
  {
    $incoming_call_count = DB::table('za_call_tracker')->select('za_call_tracker.sno')
      ->where('za_call_tracker.branch_staff_id', $staff_id)
      // ->where('a.call_date >=', $call_start_date)
      // ->where('a.call_date <=', $call_end_date)
      ->where('za_call_tracker.call_status', 1)        // Status is 1
      ->count();

    return $incoming_call_count ? $incoming_call_count : 0;
  }

  // outcoming_call
  function outcoming_call_count($staff_id)
  {
    $outgoingcall_count = DB::table('za_call_tracker')->select('za_call_tracker.sno')
      ->where('za_call_tracker.branch_staff_id', $staff_id)        // Filter by user ID
      // ->where('za_call_tracker.call_date >=', $call_start_date)
      // ->where('za_call_tracker.call_date <=', $call_end_date)

      ->where('za_call_tracker.call_status', 0)                  // Status is 0
      ->where('za_call_tracker.call_duration', '!=', '00:00:00') // Duration is not '00:00:00'
      ->count();

    return $outgoingcall_count ? $outgoingcall_count : 0;
  }

  // missed_call
  function missed_call_count($staff_id)
  {
    $missedcall_count = DB::table('za_call_tracker')->select('za_call_tracker.sno')
      ->where('za_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
      // ->where('za_call_tracker.call_date >=', $call_start_date)
      // ->where('za_call_tracker.call_date <=', $call_end_date)

      ->where('za_call_tracker.call_status', 2)
      ->count();

    return $missedcall_count ? $missedcall_count : 0;
  }

  // rejected_call
  function rejected_call_count($staff_id)
  {
    $rejected_call = DB::table('za_call_tracker')->select('za_call_tracker.sno')
      ->where('za_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
      // ->where('za_call_tracker.call_date >=', $call_start_date)
      // ->where('za_call_tracker.call_date <=', $call_end_date)
      ->where('za_call_tracker.call_status', 3)           // Status is 3 for rejected calls
      ->count();

    return $rejected_call ? $rejected_call : 0;
  }




  // incoming call lead
  function incoming_call_count_mob($mobile)
  {
    $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

    $contact_book = DB::table('za_contact_book')->where('phone_no', $mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)
      ->orderBy('za_contact_book.contact_book_id', 'desc')->first();

    $contact_book_id     = $contact_book->contact_book_id ?? '0';
    $incoming_call_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.contact_book_id', $contact_book_id)
      // ->where('a.call_date >=', $call_start_date)
      // ->where('a.call_date <=', $call_end_date)
      ->where('za_call_log.redirected_to', 0) // Redirected to 0
      ->where('za_call_log.status', 1)        // Status is 1
      ->count();

    return $incoming_call_count ? $incoming_call_count : 0;
  }

  // outcoming_call lead
  function outcoming_call_count_mob($mobile)
  {
    $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

    $contact_book = DB::table('za_contact_book')->where('phone_no', $mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)
      ->orderBy('za_contact_book.contact_book_id', 'desc')->first();
    $contact_book_id    = $contact_book->contact_book_id ?? '0';
    $outgoingcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.contact_book_id', $contact_book_id) // Filter by user ID
      // ->where('za_call_log.call_date >=', $call_start_date)
      // ->where('za_call_log.call_date <=', $call_end_date)
      ->where('za_call_log.redirected_to', 0)                  // Redirected to 0
      ->where('za_call_log.status', 0)                         // Status is 0
      ->where('za_call_log.duration', '!=', '00:00:00')        // Duration is not '00:00:00'
      ->count();

    return $outgoingcall_count ? $outgoingcall_count : 0;
  }

  // missed_call lead
  function missed_call_count_mob($mobile)
  {
    $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

    $contact_book = DB::table('za_contact_book')->where('phone_no', $mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)
      ->orderBy('za_contact_book.contact_book_id', 'desc')->first();

    $contact_book_id  = $contact_book->contact_book_id ?? '0';
    $missedcall_count = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.contact_book_id', $contact_book_id)
      // ->where('za_call_log.call_date >=', $call_start_date)
      // ->where('za_call_log.call_date <=', $call_end_date)
      ->where('za_call_log.redirected_to', 0) // Redirected to 0
      ->where('za_call_log.status', 2)        // Status is 2 for missed calls
      ->where('za_call_log.missed_status', 0) // Missed status is 0
      ->count();

    return $missedcall_count ? $missedcall_count : 0;
  }

  // rejected_call lead
  function rejected_call_count_mob($mobile)
  {
    $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
    $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

    $contact_book = DB::table('za_contact_book')->where('phone_no', $mobile)
      ->orWhere('phone_no', $phoneWithCountryCode)
      ->orderBy('za_contact_book.contact_book_id', 'desc')->first();

    $contact_book_id = $contact_book->contact_book_id ?? '0';
    $rejected_call   = DB::table('za_call_log')
      ->join('za_contact_book', 'za_call_log.contact_book_id', '=', 'za_contact_book.contact_book_id')
      ->where('za_call_log.contact_book_id', $contact_book_id)
      // ->where('za_call_log.call_date >=', $call_start_date)
      // ->where('za_call_log.call_date <=', $call_end_date)
      ->where('za_call_log.redirected_to', 0) // Redirected to 0
      ->where('za_call_log.status', 3)        // Status is 3 for rejected calls
      ->count();

    return $rejected_call ? $rejected_call : 0;
  }

  function batch_extended($batch_id)
  {
    // return $batch_id;
    return $batchCount = BatchExtensionModel::where('batch_id', $batch_id)->count();
  }


  function get_batch_summary_data($batch_id)
  {
    $summary_data = BatchSummaryModel::select('*')
      ->where('batch_id', $batch_id)
      ->where('summary_date', '=', date('Y-m-d'))
      ->where(function ($query) {
        $query->where('summary', '=', 'Test Session')
          ->orWhere('summary', '=', 'Practical Session');
      })
      ->where('status', 0)
      ->first();

    return $summary_data ? 0 : 1;
  }

  function get_extended_batch_data($batch_id)
  {
    $extended_batch = BatchExtensionModel::select('*')->where('batch_id', '=', $batch_id)->orderBy('sno', 'desc')->first();
    return $extended_batch;
  }
  // Helper



public static function getCorpOrgType($org_id)
  {
    if($org_id == 2){
      return "Corporate";
    }else{
      return "College";
    }
  }

  public static function getCorpGstType($id)
  {
    if($id == 2){
      return "Exclusive";
    }else{
      return "Inclusive";
    }
  }

  public static function getCorpSessionType($id)
  {
    if($id == 1){
      return "Day";
    }else if($id == 2){
      return "Hour";
    }else{
      return "Fixed";
    }
  }

  public static function getCorpAssignStaffType($id)
  {
    if($id == 2){
      return "External Staff";
    }else{
      return "Internal Staff";
    }
  }

  public static function getTrainingWorkType($id)
  {
    if($id == 1){
      return "Fresher";
    }else{
      return "Experience";
    }
  }

  public static function getCollegeName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['CollegeName'])) {
        self::$temp['CollegeName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['CollegeName'][$id])) {
        $state = DB::table('za_college')->select('college_name')->where('sno', $id)->first();
        self::$temp['CollegeName'][$id] = $state ? $state->college_name : null;
    }
    return self::$temp['CollegeName'][$id];
  }

  public static function getCorporateSettingName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['CorporateSettingName'])) {
        self::$temp['CorporateSettingName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['CorporateSettingName'][$id])) {
        $state = DB::table('za_corporate_settings')->select('corporate_name')->where('sno', $id)->first();
        self::$temp['CorporateSettingName'][$id] = $state ? $state->corporate_name : null;
    }
    return self::$temp['CorporateSettingName'][$id];
  }
  public static function getCorporateInteralStaffName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['CorporateInteralStaffName'])) {
        self::$temp['CorporateInteralStaffName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['CorporateInteralStaffName'][$id])) {
        $state = DB::table('za_staff')->select('staff_name')->where('sno', $id)->first();
        self::$temp['CorporateInteralStaffName'][$id] = $state ? $state->staff_name : null;
    }
    return self::$temp['CorporateInteralStaffName'][$id];
  }
  public static function getCorporateExteralStaffName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['CorporateExteralStaffName'])) {
        self::$temp['CorporateExteralStaffName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['CorporateExteralStaffName'][$id])) {
        $state = DB::table('za_training_database')->select('trainer_name')->where('sno', $id)->first();
        self::$temp['CorporateExteralStaffName'][$id] = $state ? $state->trainer_name : null;
    }
    return self::$temp['CorporateExteralStaffName'][$id];
  }
  
  
  function get_branch_All_list($user_id)
  {
      $branches = BranchModel::whereNotIn('sno', [1,11])
        ->where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();

      return ['branches' => $branches, 'franchises' => $franchises];
    
  }
  
    public function showTicker($branch_id = '', $role_id = '')
    {
        $now = \Carbon\Carbon::now();
    
        $ticker = DB::table('za_news_broadcast')
            ->where('status', 0)
             ->whereJsonContains('branch_id', (string) $branch_id) // cast to string if stored as strings
        ->whereJsonContains('role_ids', (string) $role_id)  
            ->where('start_date', '<=', $now)
            ->where('end_date', '>=', $now)
            ->orderBy('sno', 'desc')
            ->first();
    
        if ($ticker) {
            $settings = json_decode($ticker->theme_style, true);
            $news = json_decode($ticker->information, true);
    
            // Attach news data to settings (plugin expects "data")
            $settings['data'] = $news ?? [];
            return $settings;
        }
    
        return null;
    }
    
    //Vasanth Staff Exam 
    function get_Qbank_section_count($id)
    {
        $data = DB::table('za_exam_questions')
            ->where('bank_id', $id)
            ->distinct('section_id')  // only unique sections
            ->count('section_id');
    
        return $data;
    }
    
    // function get_nav_points($user_id) {
    //     return $data = DB::table('za_staff_exam_points')
    //         ->leftJoin('za_exam_badge', 'za_exam_badge.sno', '=', 'za_staff_exam_points.badge_id')
    //         ->leftJoin('za_manage_exam', 'za_manage_exam.sno', '=', 'za_staff_exam_points.badge_id')
    //         ->where('za_staff_exam_points.staff_id', $user_id)
    //         ->where('za_exam_badge.prize_id', 2)
    //         ->where('za_exam_badge.status', 0)
    //         ->where('za_staff_exam_points.status', 0)
    //         ->select(
    //             'za_staff_exam_points.points',
    //             'za_staff_exam_points.created_at',
    //             'za_manage_exam.exam_name'
    //         )
    //         ->sum('za_staff_exam_points.points');
    // }
    
    function get_nav_points($user_id)
    {
        // Exam-based points
        $history = DB::table('za_staff_exam_points')
            ->leftJoin('za_exam_badge', 'za_exam_badge.sno', '=', 'za_staff_exam_points.badge_id')
            ->leftJoin('za_manage_exam', 'za_manage_exam.sno', '=', 'za_staff_exam_points.badge_id')
            ->where('za_staff_exam_points.staff_id', $user_id)
            ->where('za_exam_badge.prize_id', 2)
            ->where('za_exam_badge.status', 0)
            ->where('za_staff_exam_points.status', 0)
            ->where('za_manage_exam.status', 0)
            ->select(
                'za_staff_exam_points.points',
                'za_staff_exam_points.created_at',
                DB::raw("'Assessment' as type"),
                'za_manage_exam.exam_name as name'
            )
            ->orderByDesc('za_staff_exam_points.created_at') // Sorting at DB level
            ->get();
 
        // Manual staff points
        $history2 = DB::table('za_staff_points')
            ->leftJoin('za_points', 'za_staff_points.points_id', '=', 'za_points.sno')
            ->where('za_staff_points.staff_id', $user_id)
            ->where('za_staff_points.status', 0)
            ->where('za_points.status', 0)
            ->select(
                'za_staff_points.points',
                'za_staff_points.created_at',
                DB::raw("'General' as type"),
                'za_points.points_name as name'
            )
            ->orderByDesc('za_staff_points.created_at') // Sorting at DB level
            ->get();
 
        // Merge both collections
        $merged = $history->merge($history2);
 
        // Total points
        $total_points = $merged->sum('points');
 
        return $total_points;
    }
    // GET Exam New Limits
    function get_new_exam_limits($exam_sno, $staff_sno)
    {
        $data = DB::table('za_exam_limit_increase')
            ->where('exam_id', $exam_sno)
            ->where('staff_id', $staff_sno)
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->first();

        return $data->new_limit ?? 0;
    }
    function staff_details($sno)
    {
        $result = StaffModel::select('za_staff.sno', 'za_staff.branch_id', 'za_staff.staff_image', 'za_staff.status', 'za_staff.staff_name',  'za_staff.nick_name', 'za_job_position.job_position_name')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where('za_staff.status', 0)
            ->where('za_staff.sno', $sno)
            ->orderBy('za_staff.staff_name', "ASC")->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    
    public function createNotificationAssessment(array $data, $notificationtype, $staff)
    {
        // Step 1: Find the Notification Type based on the name
        $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();
 
        // Check if notification type exists and proceed
        if ($notificationType) {
            $staffMembers = StaffModel::where('status', 0)
                ->where('sno', $staff)
                ->get();
 
            // Step 3: Prepare notifications for each staff member
            $notifications = [];
            foreach ($staffMembers as $staff) {
                $notificationData = [
                    'branch_id'            => $data['branch_id'] ?? 0,
                    'notification_type_id' => $notificationType->sno,
                    'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
                    'notification_content' => $data['notification_content'],
                    'notification_date'    => now(),
                    'who'                  => $data['who'] ?? '0',
                    'whom'                 => $staff->sno,
                    'created_by'           => $data['created_by'] ?? 0,
                    'updated_by'           => $data['updated_by'] ?? 0,
                    'status'               => $data['status'] ?? 0
                ];
 
                // Insert the notification and store the result
                $notifications[] = NotificationModel::create($notificationData);
            }
 
            return $notifications; // Return all created notifications
        }
 
        // Return null if notification type was not found
        return null;
    }

//   public function get_total_bugs_count($bug_branch_id){

//       $bugs = BugsListModel::where('status', '!=', 2)->where('branch_id', $bug_branch_id)->where('bug_status', 1)->get();

//       $total_bugs = 0;

//       foreach ($bugs as $bug) {

//         if ($bug->bug_status == 1) {

//           $assigned_staff_ids = isset($bug->assigned_to) && !empty($bug->assigned_to) ? json_decode($bug->assigned_to, true) : [];

//           // If assigned staffs exists count 1 bug
//           if (count($assigned_staff_ids) <= 0) {
//             $total_bugs++;
//           }
//         }
//       }

//       return $total_bugs;
//     }

public function get_total_bugs_count($bug_branch_id){
 
      $bugs  = BugsListModel::where('status', '!=', 2)->whereNotNull('bug_status')->whereIn('bug_status', [1,3,6,9])->get();
 
      $total_bugs = 0;
 
      foreach ($bugs as $bug) {
 
        if (in_array($bug->bug_status, [1,3,6,9])) {
 
            // $assigned_staff_ids = isset($bug->assigned_to) && !empty($bug->assigned_to) ? json_decode($bug->assigned_to, true) : [];
 
            // If assigned staffs exists count 1 bug
            // if (count($assigned_staff_ids) <= 0) {
            $total_bugs++;
            // }
        }
      }
 
      return $total_bugs;
    }
    
    
    public function generateAvatarColors(int $id = 0)
    {
        // Generate hue based on ID (0 - 360)
        $hue = ($id * 137) % 360; // 137 gives better color distribution
 
        // Dark background color using HSL
        $bg = "hsl($hue, 45%, 30%)";   // 30% lightness = dark
        $text = "hsl($hue, 90%, 90%)"; // Light text for contrast
 
        return [
        'bg'   => $bg,
        'text' => $text,
        ];
    }
    
     public function getServerType($host = '')
  {
    $host = strtolower($host);

    if (strpos($host, 'epro') !== false || strpos($host, 'elysiumpro') !== false) {
      return 'epro';
    }

    if (strpos($host, 'etpl') !== false || strpos($host, 'elysiumtechnologies') !== false) {
      return 'staff';
    }

    if (strpos($host, 'eapl') !== false || strpos($host, 'elysium.academy') !== false) {
      return 'eapl';
    }

    return 'eapl';
  }

    
}