<?php

namespace App\Http\Controllers\goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
class ManageTarget extends Controller
{
    
  public function index()
    {
        return view('content.goal_set.manage_target');
    }

       public function getTargets(Request $request)
    {
        // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    
        // Fetch target record for given branch and date
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->first();
    
        return response()->json(['status' => 200, 'data' => $targets]);
    }
    
    public function getTargetsTeam(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
    
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
    
        // Old payments
        $totalPaidAmountOld = DB::table('za_old_payments')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->where('za_old_customer.branch_id', $request->branch_id)
            ->where('za_old_payments.status', '!=', 2)
            ->whereIn('za_old_customer.status', [1, 4])
            ->where('za_old_payments.amount', '>', 0)
            ->whereYear('za_old_payments.created_at', $year)
            ->whereMonth('za_old_payments.created_at', $month)
            ->sum('za_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $request->branch_id)
            ->where('za_payment.status', 1)
            ->where('za_customer.status', 0)
            ->where('za_payment.amount', '>', 0)
            ->whereYear('za_payment.initialPayDate', $year)
            ->whereMonth('za_payment.initialPayDate', $month)
            ->sum('za_payment.paidAmount');
    
             $transaction = DB::table('za_transaction')
                     ->where('za_transaction.branch_id', $request->branch_id)
                      ->whereYear('za_transaction.transaction_date', $year)
                    ->whereMonth('za_transaction.transaction_date', $month)
                     ->sum('za_transaction.credit');
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $transaction;
    
        // Post-sale & pre-sale actuals (count only)
        // $postSaleActual = CustomerModel::whereIn('status', [0, 6])
        //     ->where('post_sale_check', 1)
        //     ->where('branch_id', $request->branch_id)
        //     ->whereYear('created_at', $year)
        //     ->whereMonth('created_at', $month)
        //     ->count();
        $postSaleActual = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->whereIn('za_customer.status', [0, 6])
            ->where('za_customer.post_sale_check', 1)
            ->where('za_training.post_sale_check', 1)
            ->where('za_training.branch_id', $request->branch_id)
            ->whereYear('za_training.created_at', $year)
            ->whereMonth('za_training.created_at', $month)
            ->distinct('za_training.sno')
            ->count('za_training.sno');
    
        $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            // ->where('post_sale_check', 0)
            ->where('branch_id', $request->branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
    
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
            ]
        ]);
    }


    public function updateTargets(Request $request)
{
    $request->validate([
        'branch_id' => 'required|integer',
        'no_of_registrations' => 'required|integer|min:0',
        'post_sale' => 'required|integer|min:0',
        'monthly_target' => 'required|integer|min:0',
    ]);

    // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    $userId = auth()->user()->user_id ?? 0; // Get current logged-in user

    // Check if record already exists
    $existing = ManageTargetModel::where('branch_id', $request->branch_id)
                ->where('date', $targetDate)
                ->first();

    if ($existing) {
        // Update path
        $existing->no_of_registrations = $request->no_of_registrations;
        $existing->post_sale = $request->post_sale;
        $existing->monthly_target = $request->monthly_target;
        $existing->franchise_share = $request->franchise_share;
        $existing->work_capital = $request->work_capital;
        $existing->intern_share = $request->intern_share;
        $existing->updated_by = $userId;
        $existing->save();
    } else {
        // Insert path
        ManageTargetModel::create([
            'branch_id' => $request->branch_id,
            'date' => $targetDate,
            'no_of_registrations' => $request->no_of_registrations,
             'post_sale' => $request->post_sale,
            'monthly_target' => $request->monthly_target,
            'franchise_share' => $request->franchise_share,
            'work_capital' => $request->work_capital,
            'intern_share' => $request->intern_share,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Target saved successfully.'
    ]);
}



}
