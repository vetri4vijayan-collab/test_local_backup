<?php

namespace App\Http\Controllers\goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use App\Models\ManageFranchiseModel;
use App\Models\GeneralSettingsModel;
use App\Models\BranchModel;
use App\Models\WhatsappApiConfigureModel;
use Illuminate\Support\Facades\Http;
use PDF;
class ManageFranchise extends Controller
{


  public function index()
    {
        return view('content.goal_set.manage_franchise');
    }

    public function getShare(Request $request)
  {
    $branch_id = $request->branch_id;
    $year      = $request->year;

    // Get branch target details (franchise_share%, work_capital, etc.)
    $target = ManageTargetModel::where('branch_target.branch_id', $branch_id)
        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->whereYear('branch_target.date', $year)
        ->select('branch_target.*', 'branch_target.franchise_share', 'branch_target.work_capital')
        ->get();
        // return $target;

    if (!$target) {
        return response()->json(['status' => 404, 'message' => 'No targets found']);
    }

    $result = [];
    $totalSharePaid = 0;
    $totalShare = 0;
    // Loop through all months Janâ€“Dec
    for ($m = 1; $m <= 12; $m++) {
        $monthName = date('M', mktime(0, 0, 0, $m, 1, $year));
    
        $transaction = DB::table('za_transaction')
            ->where('branch_id', $branch_id)
            ->whereYear('transaction_date', $year)
            ->whereMonth('transaction_date', $m)
            ->sum('credit');
    
        $transaction = $transaction ?? 0;
    
        // Get target for this month
        $targetForMonth = $target->firstWhere(function($item) use ($year, $m) {
            return date('Y-m', strtotime($item->date)) === sprintf('%s-%02d', $year, $m);
        });
    
        $workCapital = $targetForMonth->work_capital ?? 0;
        $franchiseSharePercent = $targetForMonth->franchise_share ?? 0;
    
        $value = max(0, $transaction - $workCapital);
        $franchisePay = round(($value * $franchiseSharePercent) / 100);
    
        $shareRecord = DB::table('za_franchise_share')
            ->where('branch_id', $branch_id)
            ->whereYear('month_year', $year)
            ->whereMonth('month_year', $m)
            ->first();
            
        $sharePaid = DB::table('za_franchise_share')
            ->where('branch_id', $branch_id)
            ->whereYear('month_year', $year)
            ->whereMonth('month_year', $m)
            ->sum('share_amount');
    
        $status = $shareRecord->status ?? 0;
        $franchisePay = $franchisePay; // override if exists
    
        // Add to total
        $totalSharePaid += $sharePaid;
        $totalShare += $franchisePay;
    
        $result[] = [
            'month'         => $monthName . ' ' . $year,
            'month_no'        => $m,
            'transaction'   => $transaction,
            'workCapital'   => $workCapital,
            'franchisePay'  => $franchisePay,
            'sharepaid'          => $sharePaid,
            'sharePercentage'   => $franchiseSharePercent,
            'status'        => $status
        ];
    }

     return response()->json([
        'status'       => 200,
        'data'         => $result,
        'paid_amount' => $totalSharePaid,
        'total_amount' => $totalShare
    ]);
}
    public function getPaymentHistory(Request $request)
  {
    $branchId = $request->branch_id;
    $year     = $request->year;
    $month    = $request->month;

    $payments = DB::table('za_franchise_share')
        ->where('branch_id', $branchId)
        ->whereYear('month_year', $year)
        ->whereMonth('month_year', $month)
        ->select(
             'invoice_id', 
            DB::raw('DATE_FORMAT(month_year, "%d %b %Y") as pay_date'),  // ðŸ‘‰ 25 Jun 2025
            DB::raw('DATE_FORMAT(month_year, "%h:%i %p") as pay_time'), 
            'share_amount as amount',
            'method as method',
            DB::raw('JSON_UNQUOTE(JSON_EXTRACT(transaction_all, "$.receipt_id")) as receipt_id'),
            DB::raw('JSON_UNQUOTE(JSON_EXTRACT(transaction_all, "$.payment_amount")) as payment_amount'),
            DB::raw('JSON_UNQUOTE(JSON_EXTRACT(transaction_all, "$.Descri")) as description')
        )
        ->orderBy('month_year', 'asc')
        ->get();
       $helper = new Helpers();
      // ✅ encrypt invoice_id before sending
        $payments->transform(function ($item) use ($helper) {
            $item->encrypted_id = $helper->encrypt_decrypt($item->invoice_id, 'encrypt');
            return $item;
        });
    return response()->json([
        'status' => 200,
        'data'   => $payments
    ]);
}

  public function getYearlyPaymentHistory(Request $request)
  {
    $branchId = $request->branch_id;
    $year     = $request->year;

    $payments = DB::table('za_franchise_share')
        ->where('branch_id', $branchId)
        ->whereYear('month_year', $year)
        ->select(
             'invoice_id', 
            DB::raw('DATE_FORMAT(month_year, "%d %b %Y") as pay_date'),    // e.g. 16 Jul 2025
            DB::raw('DATE_FORMAT(month_year, "%h:%i %p") as pay_time'),    // e.g. 10:14 AM
            'share_amount as amount',
            'method as method',
            DB::raw('JSON_UNQUOTE(JSON_EXTRACT(transaction_all, "$.Descri")) as description')
        )
        ->orderBy('month_year', 'asc')
        ->get();
        $helper = new Helpers();

        // ✅ encrypt invoice_id before sending
        $payments->transform(function ($item) use ($helper) {
            $item->encrypted_id = $helper->encrypt_decrypt($item->invoice_id, 'encrypt');
            return $item;
        });

    return response()->json([
        'status' => 200,
        'data'   => $payments
    ]);
}
   
  public function getPaymentSummary(Request $request)
  {
    $branch_id = $request->branch_id;

    // Get all targets for this branch
    $targets = ManageTargetModel::where('branch_id', $branch_id)->get();

    $totalFranchisePay = 0;

    // Sum all transactions once
    $totalTransaction = DB::table('za_transaction')
        ->where('branch_id', $branch_id)
        ->sum('credit') ?? 0;

    // Sum work capital
    $totalWorkCapital = $targets->sum('work_capital');

    // Calculate average franchise_share for targets where franchise_share > 0
    $positiveShares = $targets->where('franchise_share', '>', 0);
    $franchisePercent = 0;
    if ($positiveShares->count() > 0) {
        $franchisePercent = $positiveShares->sum('franchise_share') / $positiveShares->count();
    }
    // return $totalTransaction;
    // Calculate franchise pay
    $franchisePay = max(0, $totalTransaction - $totalWorkCapital) * ($franchisePercent / 100);
    $totalFranchisePay = round($franchisePay, 2);

    // Total paid so far for this branch
    $totalPaid = DB::table('za_franchise_share')
        ->where('branch_id', $branch_id)
        ->sum('share_amount') ?? 0;

    $balance = $totalFranchisePay - $totalPaid ?? 0;

    // Branch info
    $branch = DB::table('za_branch')->where('sno', $branch_id)->first();

    return response()->json([
        'status' => 200,
        'data' => [
            'branch_name' => $branch->franchise_name ?? '',
            'total' => $totalFranchisePay,
            'paid' => $totalPaid,
            'balance' => $balance,
        ]
    ]);
}

   public function updateShare(Request $request)
  {
    $request->validate([
        'branch_id' => 'required|integer',
        'year'      => 'required|integer',
        'pay_amount' => 'required|numeric',
        'payment_mode' => 'required',
    ]);

    $branchId = $request->branch_id;
    $year     = $request->year;
    $payment_mode     = $request->payment_mode;
    $userId   = auth()->user()->user_id ?? 0;

    // Get total transaction of that year
    $transaction = DB::table('za_transaction')
        ->where('branch_id', $branchId)
        ->whereYear('transaction_date', $year)
        ->sum('credit');
        $year = date('Y');
        $month = date('m');
        
        // Get the last invoice for this year & month
        $lastInvoice = ManageFranchiseModel::lockForUpdate()
            ->where('invoice_id', 'like', 'MC/%/'.$year) // match by year
            ->orderBy('sno', 'desc')
            ->first();
        
        if (!$lastInvoice) {
            // No invoice found → start fresh
            $invoice_id = 'MC/INV-00001/' . $month . '/' . $year;
        } else {
            // Extract and increment last number
            $lastInvoiceId = $lastInvoice->invoice_id;
            $parts = explode('/', $lastInvoiceId); // e.g. MC/INV-00023/09/2025
            $numberPart = preg_replace('/[^0-9]/', '', $parts[1]); // get 00023
            $nextNumber = (int)$numberPart + 1;
            $newNumber = sprintf('INV-%05d', $nextNumber);
        
            $invoice_id = 'MC/' . $newNumber . '/' . $month . '/' . $year;
        }
    
   
        // Insert
       $sharepay = ManageFranchiseModel::create([
            'invoice_id'      => $invoice_id,
            'branch_id'      => $branchId,
            'month_year'     => now(),
            'monthly_target' => $transaction,
            'method'         => $payment_mode,
            'share_amount'   => $request->pay_amount,
            'transaction_all'=> json_encode($request->transaction_all),
            'created_by'     => $userId,
            'updated_by'     => $userId,
        ]);
        
         // Send email if email flag is set to true
         $helper = new \App\Helpers\Helpers();
          $encrypted_values = $helper->encrypt_decrypt($sharepay->sno, 'encrypt');
    
       
           $Link =url('/print/invoice/pdf/' . $encrypted_values);
        
        
            if(!$sharepay->shot_url){
                 $channelId = 13;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                 
                 if($shortUrl){
                        DB::table('za_franchise_share')
                        ->where('sno', $sharepay->sno)
                        ->update(['shot_url' => $shortUrl]);
                 }
                 
              }
              
              $participantData=DB::table('za_franchise_share')->where('za_franchise_share.sno',$sharepay->sno)->first();
              $shortsendUrl = $participantData->shot_url ;
              
              $certificate_key = basename($shortsendUrl);
              $branch = BranchModel::where('sno', $branchId)->first();
              $branchconta = BranchModel::where('sno', 6)->first();
              $lead_mobile = 9677482114;
              $currentdate = now()->format('d-F-Y');
              if($request->whatsappCheckbox == 1){
                if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "frainchisee_payment_receipt_confirmation";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'frainchisee_payment_receipt_confirmation') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                $headerImage =  url('public/assets/eapl_images/Franchisee-Payment.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           =>  $branch->business_name ?? "Franchise",
                                        'parameter_name' => 'fran_person_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           =>  $request->pay_amount,
                                        'parameter_name' => 'amount',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           =>  $currentdate,
                                        'parameter_name' => 'payment_date',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $invoice_id,
                                        'parameter_name' => 'invoice_number',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $payment_mode ?? 'Cash',
                                        'parameter_name' => 'payment_mode',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => 'Narayanan',
                                        'parameter_name' => 'ho_contact_name',
                                    ],
                                     [
                                        'type'           => 'text',
                                        'text'           =>  '7845736972',
                                        'parameter_name' => 'contact_number',
                                    ]
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $certificate_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                               $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
                                $accessToken               = $this->accessData($request)->access_tokken;
                                $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                             $mobile = preg_replace('/\D/', '', $lead_mobile); // remove any non-digits
                                if (strpos($lead_mobile, '+') === 0) {
                                    $to = $lead_mobile;
                                } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                                    $to = '+' . $mobile;
                                } else {
                                    $to = '+91' . $mobile;
                                }
                            $languageCode = 'en';
                
                            // if (strpos($to, $countryCode) !== 0) {
                            //     $to = $countryCode . $to;
                            // }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {
                             
                         }
                         else{
                              
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                   'certificate_status'=>2,
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
              }

    return response()->json([
        'status'  => 200,
        'message' => 'Franchise share updated successfully.'
    ]);
}


     public function accessData(Request $request){
        $branchId = $request->user()->branch_id; 
        $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', $branchId)->first();
        return $whatsappConfig;
    }

    private function sendRequestToWhatsApp($url, $token, $data)
    {
      try {
        $client = new \GuzzleHttp\Client();
        $response = $client->post($url, [
          'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json',
          ],
          'json' => $data,
          
        ]);
  
        return [
          'status' => $response->getStatusCode(),
          'data' => json_decode($response->getBody(), true),
        ];
      } catch (\Exception $e) {
        return [
          'status' => 400,
          'error' => $e->getMessage(),
        ];
      }
    }
 
    public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
  public function printInvoice($id)
 {
    
    $helper = new Helpers();
    $decryptedInvoiceId = $helper->encrypt_decrypt($id, 'decrypt'); // ✅ only decrypt once

    // Fetch payment + branch info
    $payment = ManageFranchiseModel::select(
            'za_franchise_share.share_amount as amount',
            'za_franchise_share.transaction_all',
            'za_franchise_share.monthly_target',
            'za_franchise_share.month_year',
            'za_franchise_share.branch_id as branch_id',
            'za_franchise_share.method',
            'za_franchise_share.invoice_id',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.branch_name',
            'za_branch.business_name',
            'za_branch.branch_id AS branch_id_auto',
            'za_branch.branch_type',
            'za_branch.franchise_name',
            'za_branch.mail',
            'za_branch.area_street',
            'za_states.name as state_name',
            'za_cities.name as city_name'
        )
        ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_franchise_share.branch_id')
        ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
        ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
        ->where('za_franchise_share.invoice_id', $decryptedInvoiceId) // ✅ match decrypted invoice
        ->first();

    if (!$payment) {
        return response()->view('errors.404', [], 404);
    }

    // Decode transactions & pick the one matching decrypted invoice_id
    
    
        $decoded = json_decode($payment->transaction_all, true);
        $selectedTransaction = null;
        
        if (is_array($decoded)) {
            // If first level is numeric array (multiple transactions)
            if (array_keys($decoded) === range(0, count($decoded) - 1)) {
                $selectedTransaction = $decoded[0]; // first transaction
            } else {
                // Single transaction object
                $selectedTransaction = $decoded;
            }
        }
        
        // Safe access
        $paidAmount = $selectedTransaction['payment_amount'] ?? 0;

    // Terms & conditions
    $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2', 'terms_3', 'terms_4', 'terms_5')
        ->where('status', 0)
        ->get();

    // Branch GST %
    $branch = BranchModel::where('sno', 6)->orderBy('sno', 'desc')->first();
    $qrCodeData = [
        'Customer Name' => $payment->business_name,
        'Customer ID'   => $payment->branch_id_auto,
        'Paid Amount'   => $paidAmount
    ];
   
    return view('content.goal_set.franchise_print', [
        'payment'       => $payment,
        'transaction'   => $selectedTransaction,
        'gstPercentage' => $branch->gst_percentage ?? 0,
        'branch'        => $branch,
    ]);
}

  public function printInvoicedownload($id)
  {
    // return $id;
    $helper = new Helpers();
    $decryptedInvoiceId = $helper->encrypt_decrypt($id, 'decrypt'); // ✅ only decrypt once
    // return $decryptedInvoiceId;
    // Fetch payment + branch info
    $payment = ManageFranchiseModel::select(
            'za_franchise_share.share_amount as amount',
            'za_franchise_share.transaction_all',
            'za_franchise_share.monthly_target',
            'za_franchise_share.month_year',
            'za_franchise_share.branch_id as branch_id',
            'za_franchise_share.method',
            'za_franchise_share.invoice_id',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.branch_name',
            'za_branch.business_name',
            'za_branch.branch_id AS branch_id_auto',
            'za_branch.branch_type',
            'za_branch.franchise_name',
            'za_branch.mail',
            'za_branch.area_street',
            'za_states.name as state_name',
            'za_cities.name as city_name'
        )
        ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_franchise_share.branch_id')
        ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
        ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
        ->where('za_franchise_share.sno', $decryptedInvoiceId) // ✅ match decrypted invoice
        ->first();
     // return $payment;
     if (!$payment) {
        return response()->view('errors.404', [], 404);
    }

    // Decode transactions & pick the one matching decrypted invoice_id
    
    
        $decoded = json_decode($payment->transaction_all, true);
        $selectedTransaction = null;
        
        if (is_array($decoded)) {
            // If first level is numeric array (multiple transactions)
            if (array_keys($decoded) === range(0, count($decoded) - 1)) {
                $selectedTransaction = $decoded[0]; // first transaction
            } else {
                // Single transaction object
                $selectedTransaction = $decoded;
            }
        }
        
        // Safe access
        $paidAmount = $selectedTransaction['payment_amount'] ?? 0;

    // Terms & conditions
    $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2', 'terms_3', 'terms_4', 'terms_5')
        ->where('status', 0)
        ->get();
    $helper = new Helpers();
    $common_date_format = $helper->general_setting_data()?->date_format ?? 'd-M-Y';
    // Branch GST %
    $branch = BranchModel::where('sno', 6)->orderBy('sno', 'desc')->first();
    $qrCodeData = [
        'Customer Name' => $payment->business_name,
        'Customer ID'   => $payment->branch_id_auto,
        'Paid Amount'   => $paidAmount
    ];
    
   $pdf = PDF::loadView('content.goal_set.franchise_pdf', [
                'payment'       => $payment,
                'transaction'   => $selectedTransaction,
                'gstPercentage' => $branch->gst_percentage ?? 0,
                'branch'        => $branch,
                'common_date_format'        => $common_date_format,
            ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)  
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
            // return $pdf;  
             return $pdf->download('Franchise-invoice.pdf');
            //  return $pdf->stream('Franchise-invoice.pdf');
    // return view('content.goal_set.franchise_pdf', [
    //     'payment'       => $payment,
    //     'transaction'   => $selectedTransaction,
    //     'gstPercentage' => $branch->gst_percentage ?? 0,
    //     'branch'        => $branch,
    //     'common_date_format'        => $common_date_format,
    // ]);
}



}
