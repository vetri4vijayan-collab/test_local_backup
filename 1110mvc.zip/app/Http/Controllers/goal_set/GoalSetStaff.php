<?php

namespace App\Http\Controllers\goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\PaymentModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\TrainingModel;
use App\Models\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;

class GoalSetStaff extends Controller
{


  public function index()
  {

    return view('content.goal_set.goal_set');
  }
  // Fetch Departments based on Branch
  public function getDepartmentsGoal(Request $request)
  {

    $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
  }


  //  public function getTeamGoal(Request $request)
  // {
  //     $branchId = $request->user()->branch_id;
  //     $departmentId = $request->department_id;
  //     $month_id = $request->month_id;

  //     // Convert month name to number if necessary
  //     if (!empty($request->month_id)) {
  //         if (!is_numeric($request->month_id)) {
  //             $monthNumber = date('m', strtotime($request->month_id . ' 1'));
  //             $request->month_id = (int) $monthNumber;
  //         } else {
  //             $request->month_id = (int) $request->month_id;
  //         }
  //     }

  //     // Fetch the department details
  //     $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

  //     // Get goal records for the selected department and month
  //     $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
  //         ->where('branch_id', $branchId)
  //         ->where('team_goal_month', $request->month_id)
  //         ->first();

  //     // Prepare goal details response
  //     $goalteamDetails = [
  //         'department_name' => $department->department_name ?? '',
  //         'department_id'   => $department->sno ?? '',
  //         'team_id'         => $goalteam->sno ?? '',
  //         'cr_over_all'     => $goalteam->cr_over_all ?? 0,
  //         'cr_check'        => $goalteam->cr_check ?? 0,
  //         'cr_type'         => $goalteam->cr_type ?? 0,
  //         'abv_over_all'    => $goalteam->abv_over_all ?? 0,
  //         'abv_check'       => $goalteam->abv_check ?? 0,
  //         'abv_type'        => $goalteam->abv_type ?? 0,
  //         'acv_over_all'    => $goalteam->acv_over_all ?? 0,
  //         'acv_check'       => $goalteam->acv_check ?? 0,
  //         'acv_type'        => $goalteam->acv_type ?? 0,
  //         'avg_call_out_over_all' => $goalteam->avg_call_out_over_all ?? 0,
  //         'avg_call_out_check'    => $goalteam->avg_call_out_check ?? 0,
  //         'avg_call_out_type'     => $goalteam->avg_call_out_type ?? 0,
  //         'no_of_walk_over_all'   => $goalteam->no_of_walk_over_all ?? 0,
  //         'no_of_walk_check'      => $goalteam->no_of_walk_check ?? 0,
  //         'no_of_walk_type'       => $goalteam->no_of_walk_type ?? 0,
  //         'status' => isset($goalteam) && $goalteam->status == 1 ? 'Goal Set' : 'Pending',
  //         'month'  => $month_id
  //     ];

  //     return response()->json([
  //         'status' => 200,
  //         'data'   => $goalteamDetails
  //     ]);
  // }

  // public function getTeamGoal(Request $request)
  // {
  //   $branchId = $request->user()->branch_id;
  //   $departmentId = $request->department_id;
  //   $month_id = $request->month_id;
  //   $month = date('n', strtotime($month_id)); // Returns 3
  //   $year = $request->year;
  //   $branch_id = $request->user()->branch_id;


  //   // Convert month name to number if necessary
  //   if (!empty($request->month_id)) {
  //     if (!is_numeric($request->month_id)) {
  //       $monthNumber = date('m', strtotime($request->month_id . ' 1'));
  //       $request->month_id = (int) $monthNumber;
  //     } else {
  //       $request->month_id = (int) $request->month_id;
  //     }
  //   }

  //   $month = (int)$request->month_id; // 2

  //   // Fetch the department details
  //   $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

  //   // Get goal records for the selected department and month
  //   $goalteam = GoalSetTeamModel::where('za_goal_set_team.department_id', $departmentId)->where('za_goal_set_team.branch_id', $branchId)
  //     ->where('za_goal_set_team.team_goal_month', $request->month_id)
  //     ->where('za_goal_set_team.team_goal_year', $year)
  //     ->first();

  //   $staff = StaffModel::where('za_staff.branch_id', $branch_id)
  //     ->where('za_staff.department_id', $departmentId)
  //     ->where('za_staff.status', 0)
  //     ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
  //     ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
  //     ->orderBy('staff_name', 'ASC')
  //     ->get([
  //       'za_staff.sno',
  //       'za_staff.staff_name',
  //       'za_staff.nick_name',
  //       'za_staff.gender',
  //       'za_staff.staff_image',
  //       'za_staff.basic_salary',
  //       'za_department.department_name',
  //       'za_user_role.role_name'
  //     ]);

  //   // Initialize Totals
  //   $totalDepartmentAllLead = 0;
  //   $totalDepartmentMonthLead = 0;
  //   $totalDepartmentHotLead = 0;
  //   $totalDepartmentSpamLead = 0;
  //   $totalDepartmentDeadLead = 0;
  //   $totalDepartmentConvertCustomer = 0;
  //   $totalDepartmentBusinessValue = 0;
  //   $totalDepartmentCollectionValue = 0;
  //   $totalDepartmentPaidPayment = 0;
  //   $totalDepartmentTotalPayment = 0;
  //   $totalmonthFollowupCount = 0;
  //   $totalmonthwalkincount = 0;
  //   $totalmonthcall_outcount = 0;

  //   $totalcosting_amount = 0;
  //   $totalrefferal_count = 0;
  //   $totalreview_count   = 0;
  //   $OutstandingPayment_count_total   = 0;
  //   $post_sale_count_total   = 0;
  //   $hacAmount_total   = 0;
  //   $placement_count_total   = 0;
  //   $std_count_total   = 0;
  //   $total_basic_salary   = 0;
  //   $totalmou_count   = 0;

  //   foreach ($staff as $member) {

  //     // Leads Count
  //     $allLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
  //       ->where('branch_id', $branch_id)
  //       ->whereNotIn('status', [2, 6])
  //       ->where('spam_verified', 0)
  //       ->where('drop_verified', 0)
  //       ->where('internal_status', 0)
  //       ->count();

  //     $monthLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
  //       ->where('branch_id', $branch_id)
  //       ->whereYear('registered_date', $year)
  //       ->whereMonth('registered_date', $month)
  //       ->whereNotIn('status', [2, 6])
  //       ->where('spam_verified', 0)
  //       ->where('drop_verified', 0)
  //       ->where('internal_status', 0)
  //       ->count();

  //     $hotLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
  //       ->where('branch_id', $branch_id)
  //       ->whereYear('registered_date', $year)
  //       ->whereMonth('registered_date', $month)
  //       ->whereNotIn('status', [2, 6])
  //       ->where('lead_status_id', 3)
  //       ->where('internal_status', 0)
  //       ->where('spam_verified', 0)
  //       ->where('drop_verified', 0)
  //       ->count();

  //     $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
  //       ->where('za_customer.branch_id', $branch_id)
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_lead.created_by', $member->sno)
  //       ->whereYear('za_customer.created_at', $year)
  //       ->whereMonth('za_customer.created_at', $month)
  //       ->count();

  //     $spamLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
  //       ->where('branch_id', $branch_id)
  //       ->whereYear('registered_date', $year)
  //       ->whereMonth('registered_date', $month)
  //       ->where('spam_verified', 1)
  //       ->where('status', 7)
  //       ->count();

  //     $deadLeadCount = DB::table('za_lead')->where('created_by', $member->sno)
  //       ->where('branch_id', $branch_id)
  //       ->whereYear('registered_date', $year)
  //       ->whereMonth('registered_date', $month)
  //       ->where('drop_verified', 1)
  //       ->where('status', 5)
  //       ->count();

  //     // Follow-ups & Walk-ins
  //     $monthFollowupCount = DB::table('za_appointment')
  //       ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
  //       ->whereIn('za_lead.status', [0, 4])
  //       ->where('za_appointment.created_by', $member->sno)
  //       ->whereYear('za_appointment.appointment_date', $year)
  //       ->whereMonth('za_appointment.appointment_date', $month)
  //       ->count();

  //     $monthwalkincount = DB::table('za_lead_appointment')
  //       ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
  //       ->where('za_lead_appointment.appointment_category', 'walk-in')
  //       ->where('za_lead_appointment.created_by', $member->sno)
  //       ->whereYear('za_lead_appointment.appointment_date', $year)
  //       ->whereMonth('za_lead_appointment.appointment_date', $month)
  //       ->count();

  //     // Call Out Count
  //     $monthcall_out = DB::table('za_call_tracker')
  //       ->whereYear('call_start_date', $year)
  //       ->whereMonth('call_start_date', $month)
  //       ->where('za_call_tracker.branch_id', $branch_id)
  //       ->where('za_call_tracker.branch_staff_id', $member->sno)
  //       ->where('call_status', 0)
  //       ->count();

  //     // Update Department Totals
  //     $totalDepartmentAllLead += $allLeadCount;
  //     $totalDepartmentMonthLead += $monthLeadCount;
  //     $totalDepartmentHotLead += $hotLeadCount;
  //     $totalDepartmentSpamLead += $spamLeadCount;
  //     $totalDepartmentDeadLead += $deadLeadCount;
  //     $totalDepartmentConvertCustomer += $customerConvertCount;
  //     $totalmonthFollowupCount += $monthFollowupCount;
  //     $totalmonthwalkincount += $monthwalkincount;
  //     $totalmonthcall_outcount += $monthcall_out;

  //     // Payments Calculation
  //     $totalPayment = 0;
  //     $totalPaidPayment = 0;

  //     if ($customerConvertCount > 0) {
  //       $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
  //         ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
  //         ->where('za_customer.branch_id', $branch_id)
  //         ->whereIn('za_customer.status', [0, 6])
  //         ->where('za_lead.created_by', $member->sno)
  //         ->whereYear('za_customer.created_at', $year)
  //         ->whereMonth('za_customer.created_at', $month)
  //         ->get();

  //       // foreach ($currentMonthCustomer as $customer) {
  //       //     $courseIds = json_decode($customer->course_id, true);
  //       //     if (is_array($courseIds)) {
  //       //         $payment = ManageCoursesModel::whereIn('sno', $courseIds)->sum('course_max_price');
  //       //         $totalPayment += $payment;

  //       //         $paid_payment = PaymentModel::where('customer_id', $customer->sno)
  //       //             ->whereIn('course_id', $courseIds)
  //       //             ->where('status', 1)
  //       //             ->sum('paidAmount');

  //       //         $totalPaidPayment += $paid_payment;
  //       //     }
  //       // }
  //       if ($currentMonthCustomer->isNotEmpty()) {
  //         foreach ($currentMonthCustomer as $customer) {

  //           $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
  //             ->where('za_training.customer_id', $customer->sno)
  //             ->where('za_training.tesbo_check', 0)
  //             ->sum('za_training.overall_fees');

  //           $totalPayment += $payment;


  //           $latestTraining = DB::table('za_training')
  //             ->where('customer_id', $customer->sno)
  //             ->where('tesbo_check', 2)
  //             ->orderByDesc('sno')
  //             ->first();

  //           if ($latestTraining) {
  //             $totalPayment += $latestTraining->overall_fees;
  //           }

  //           $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
  //             ->where('za_training.customer_id', $customer->sno)
  //             ->sum('za_training.paid_amount');

  //           $totalPaidPayment += $paid_payment;
  //         }
  //       }
  //     }

  //     // Update Total Department Payments
  //     $totalDepartmentTotalPayment += $totalPayment;
  //     $totalDepartmentPaidPayment += $totalPaidPayment;


  //     // Production Goal***********************************************

  //     $current_date = date('Y-m-d'); // Define the current date
  //     $std_count = TrainingModel::where('za_training.status', 0)
  //       ->where('za_batch.status', 0)
  //       ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
  //       ->where('za_training.staff_id', $member->sno)
  //       ->where('za_batch.start_date', '<=', $current_date)
  //       ->where('za_batch.end_date', '>=', $current_date)
  //       ->count();

  //     $std_count_total = $std_count;

  //     $staffproduction = StaffModel::select(
  //       'za_staff.sno',
  //       'za_staff.staff_id',
  //       'za_staff.staff_name',
  //       'za_staff.gender',
  //       'za_staff.dob',
  //       'za_staff.mobile_no',
  //       'za_staff.email_id',
  //       'za_staff.staff_image',
  //       'za_staff.nick_name',
  //       'za_staff.knowledge_tag',
  //       'za_staff.per_hour_cost',
  //       'za_job_position.job_position_name',
  //       'za_staff.avaiable_points',
  //       'za_staff.basic_salary',
  //       'za_staff.status AS staff_status'
  //     )
  //       ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
  //       ->where([
  //         ['za_staff.status', 0],
  //         ['za_staff.branch_id', $branch_id],
  //         ['za_staff.sno', $member->sno]
  //       ])
  //       ->orderByDesc('za_staff.sno')
  //       ->first();

  //     // Initialize variables
  //     $total_batch = $total_student = $total_free_batch = $total_staff = 0;
  //     $overall_earned = $overall_earned_per = $success_staff_count = 0;
  //     $slotType = $staffproduction;

  //     $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
  //     $slotType->present_count = $slotType->course_count = 0;
  //     $slotType->slotDetails = [];
  //     $slotType->avg_amnt = $slotType->salary = 0;

  //     // Fetch batch IDs associated with staff
  //     $batchIds = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->distinct()
  //       ->pluck('batch_id')
  //       ->toArray();

  //     $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

  //     foreach ($slotType->batch_ids as $batchId) {
  //       // Fetch slot details for the staff's batches
  //       $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
  //         ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //         ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
  //           ->where('staff_id', $slotType->sno)
  //           ->where(function ($query) use ($month, $year) {
  //             $query->whereMonth('start_date', '<=', $month)
  //               ->whereYear('start_date', '<=', $year)
  //               ->whereMonth('end_date', '>=', $month)
  //               ->whereYear('end_date', '>=', $year);
  //           })
  //           ->pluck('batch_id'))
  //         ->where('za_batch.status', 0)
  //         ->get();

  //       $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

  //       // Fetch batch details
  //       $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
  //         ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //         ->find($batchId);

  //       if ($batch) {
  //         $startTime = Carbon::parse($batch->start_time);
  //         $endTime = Carbon::parse($batch->end_time);
  //         $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

  //         // Fetch attendance records
  //         $attendanceRecords = AttendanceModel::select('per_hr_cost')
  //           ->where([
  //             ['batch_id', $batch->sno],
  //             ['staff_id', $slotType->sno],
  //             ['attendance', 'P']
  //           ])
  //           ->whereMonth('att_date', $month)
  //           ->whereYear('att_date', $year)
  //           ->get();

  //         foreach ($attendanceRecords as $attendance) {
  //           $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
  //         }
  //       }
  //     }

  //     // Student count
  //     $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where('za_training.status', 0)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       // ->distinct('customer_id')
  //       ->count('customer_id');

  //     // Course count
  //     $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       ->distinct('course_id')
  //       ->count('course_id');

  //     // Batch count
  //     $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       ->distinct('batch_id')
  //       ->count('batch_id');

  //     // Salary calculation
  //     $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
  //     // Average earned percentage calculation
  //     $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
  //     // Calculate free batch count
  //     $total_free_batch = max(0, 8 - $slotType->batch_count);
  //     $overall_earned += $slotType->earned_amount;
  //     $overall_earned_per += $slotType->avg_amnt;
  //     // Count success staff
  //     if ($slotType->salary < $slotType->earned_amount) {
  //       $success_staff_count++;
  //     }
  //     $staffproduction = $slotType;



  //     $totalcosting_amount += $staffproduction->earned_amount ?? 0;

  //     $refferal_count = DB::table('za_referral_persons')
  //       ->where('branch_id', $branch_id)
  //       ->where('referral_id', $member->sno)
  //       ->where('status', 0)
  //       ->where('referral_type', 2)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();

  //     $totalrefferal_count += $refferal_count ?? 0;

  //     $review_count = DB::table('za_review')
  //       ->where('branch_id', $branch_id)
  //       ->where('created_by', $member->sno)
  //       ->where('status', 0)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();

  //     $totalreview_count += $review_count ?? 0;

  //     $mou_count = DB::table('za_placement_company')
  //       ->where('branch_id', $branch_id)
  //       ->where('created_by', $member->sno)
  //       ->where('mou_status', 1)
  //       ->whereYear('mou_upload_date', $year)
  //       ->whereMonth('mou_upload_date', $month)
  //       ->count();

  //     $totalmou_count += $mou_count ?? 0;




  //     // Sales Exc *****************************************************
  //     $drop_ids = DB::table('za_drop_refund')
  //       ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
  //       ->where('za_drop_refund.bh_status', 1)
  //       ->where('za_drop_refund.branch_id', $branch_id)
  //       ->pluck('za_training.payment_id');

  //     $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
  //       ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
  //       ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
  //       ->whereNotIn('za_payment.payment_id', $drop_ids)
  //       ->where('za_payment.status', 0)
  //       ->where('za_payment.amount', '>', 0)
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_payment.created_by', $member->sno)
  //       ->whereMonth('za_payment.nextPayDate', $month)
  //       ->whereYear('za_payment.nextPayDate', $year)
  //       ->orderBy('za_payment.sno', 'asc')
  //       ->count();

  //     //   $post_sale_count = DB::table('za_training')
  //     //     ->where('created_by', $member->sno)
  //     //     ->where('post_sale_check', 1)
  //     //     ->whereYear('post_sale_date', $year)
  //     //     ->whereMonth('post_sale_date', $month)
  //     //     ->distinct()
  //     //     ->count('customer_id');

  //     $post_sale_count  = DB::table('za_referral_persons')
  //       ->where('branch_id', $branch_id)
  //       ->where('referral_id', $member->sno)
  //       ->where('status', 0)
  //       ->where('referral_type', 2)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();

  //     $placement_count = DB::table('za_placement_interview')
  //       ->where('updated_by', $member->sno)
  //       ->where('status', 4)
  //       ->whereYear('selected_date', $year)
  //       ->whereMonth('selected_date', $month)
  //       ->distinct()
  //       ->count('sno');




  //     $OutstandingPayment_count_total += $OutstandingPayment_count;
  //     $post_sale_count_total += $post_sale_count;
  //     $placement_count_total += $placement_count;

  //     $current = Carbon::create($year, $month, 1);
  //     $startDateold = $current->copy()->subYears(20)->startOfMonth();
  //     $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month



  //     $dropoutCustomers = DB::table('za_training')
  //       ->where('status', 2)
  //       ->pluck('customer_id')
  //       ->toArray();

  //     $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_customer.branch_id', $branchId)
  //       ->whereNotIn('za_customer.sno', $dropoutCustomers)
  //       ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
  //       ->pluck('za_customer.sno')
  //       ->toArray();
  //     // return $prevMonthConvertedCustomers;

  //     // first condition


  //     // here $secondPaymentCustomers  we need colclude the dat get $hacAmount
  //     $hacAmount = DB::table('za_payment')
  //       ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
  //       ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
  //       ->where('za_payment.status', 1) // paid amoun
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->whereYear('za_payment.initialPayDate', $year)
  //       ->whereMonth('za_payment.initialPayDate', $month)
  //       ->where('za_payment.branch_id', $branchId)
  //       ->sum('za_payment.paidAmount');

  //     $hacAmount_total += $hacAmount;
  //     $total_basic_salary += $member->basic_salary ?? 0;
  //     // Sales Exc ****************************************************

  //   }

  //   // Business and Collection Value Calculation
  //   $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

  //   $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

  //   // Conversion Rate
  //   $convertion_rate = $totalDepartmentMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

  //   $totalConvertRatio = number_format($convertion_rate, 2);


  //   $startDate = Carbon::create($year, $month, 1);
  //   $currentDate = Carbon::now();
  //   $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
  //   $dayCount = $startDate->diffInDays($endDate) + 1;
  //   $total_staff = count($staff) ?? 0;
  //   $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
  //   $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
  //   $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;


  //   $basic_pay = $total_basic_salary ?? 0;
  //   $total_basic_pay_pro  = $total_basic_salary * 10;
  //   $costing_amount_asign = optional($goalteam)->production_costing_over_all ?? 0;
  //   // $totalcosting_amount  = $basic_pay > 0  ? round(($totalcosting_amount /  $basic_pay) *  $costing_amount_asign) : 0;
  //   $totalcosting_amount  = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $costing_amount_asign : 0;



  //   if (isset($goalteam->goal_completed)) {
  //     if ($goalteam->goal_completed == 1) {
  //       $totalDepartmentConvertCustomer =  $goalteam->conversion_actual;
  //       $totalConvertRatio =  $goalteam->cr_actual;
  //       $totalDepartmentBusinessValue =  $goalteam->abv_actual;
  //       $totalDepartmentCollectionValue =  $goalteam->acv_actual;
  //       $totalmonthcall_outcount =  $goalteam->avg_call_out_actual;
  //       $totalmonthwalkincount =  $goalteam->no_of_walk_actual;
  //       $totalmonthFollowupCount =  $goalteam->no_of_followup_actual;
  //       $hacAmount_total =  $goalteam->hac_actual;
  //       $post_sale_count_total =  $goalteam->no_of_post_sale_actual;
  //       $OutstandingPayment_count =  $goalteam->no_of_outstanding_actual;
  //       $std_count_total =  $goalteam->min_no_of_students_actual;
  //       $totalcosting_amount =  $goalteam->production_costing_actual;
  //       $totalreview_count =  $goalteam->no_of_reviews_actual;
  //       // $placement_count_total =  $goalteam->no_of_placements_actual;
  //       $totalmou_count =  $goalteam->mou_actual;
  //       $totalcosting_amount =  $goalteam->productions_actual;
  //       $totalrefferal_count =  $goalteam->reference_sales_actual;
  //     }
  //   }
  //   // return $placement_count_total;


  //   // Prepare goal details response
  //   $goalteamDetails = [
  //     'department_name' => optional($department)->department_name ?? '',
  //     'department_id'   => optional($department)->sno ?? '',
  //     'team_id'         => optional($goalteam)->sno ?? '',
  //     'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),

  //     'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
  //     'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
  //     'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
  //     'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

  //     'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
  //     'cr_check'                      => optional($goalteam)->cr_check ?? 0,
  //     'cr_type'                       => optional($goalteam)->cr_type ?? 0,
  //     'cr_actual'                     => $totalConvertRatio ?? 'N/A',


  //     'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
  //     'abv_check'                     => optional($goalteam)->abv_check ?? 0,
  //     'abv_type'                      => optional($goalteam)->abv_type ?? 0,
  //     'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

  //     'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
  //     'acv_check'                     => optional($goalteam)->acv_check ?? 0,
  //     'acv_type'                      => optional($goalteam)->acv_type ?? 0,
  //     'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

  //     'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
  //     'avg_call_out_check'            => optional($goalteam)->avg_call_out_check ?? 0,
  //     'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
  //     'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

  //     'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
  //     'no_of_walk_check'              => optional($goalteam)->no_of_walk_check ?? 0,
  //     'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
  //     'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

  //     'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
  //     'no_of_followup_check'          => optional($goalteam)->no_of_followup_check ?? 0,
  //     'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
  //     'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

  //     'hac_over_all'                  => optional($goalteam)->hac_over_all ?? 0,
  //     'hac_check'                     => optional($goalteam)->hac_check ?? 0,
  //     'hac_type'                      => optional($goalteam)->hac_type ?? 0,
  //     'hac_actual'                    => $hacAmount_total ?? 0,

  //     'no_of_post_sale_over_all'      => optional($goalteam)->no_of_post_sale_over_all ?? 0,
  //     'no_of_post_sale_check'         => optional($goalteam)->no_of_post_sale_check ?? 0,
  //     'no_of_post_sale_type'          => optional($goalteam)->no_of_post_sale_type ?? 0,
  //     'no_of_post_sale_actual'        => $post_sale_count_total ?? 0,

  //     'no_of_outstanding_over_all'    => optional($goalteam)->no_of_outstanding_over_all ?? 0,
  //     'no_of_outstanding_check'       => optional($goalteam)->no_of_outstanding_check ?? 0,
  //     'no_of_outstanding_type'        => optional($goalteam)->no_of_outstanding_type ?? 0,
  //     'no_of_outstanding_actual'      => $OutstandingPayment_count ?? 0,

  //     'min_no_of_students_over_all'   => optional($goalteam)->min_no_of_students_over_all ?? 0,
  //     'min_no_of_students_check'      => optional($goalteam)->min_no_of_students_check ?? 0,
  //     'min_no_of_students_type'       => optional($goalteam)->min_no_of_students_type ?? 0,
  //     'min_no_of_students_actual'     => $std_count_total ?? 0,

  //     'production_costing_over_all'   => optional($goalteam)->production_costing_over_all ?? 0,
  //     'production_costing_check'      => optional($goalteam)->production_costing_check ?? 0,
  //     'production_costing_type'       => optional($goalteam)->production_costing_type ?? 0,
  //     'production_costing_actual'     => $totalcosting_amount ?? 0,

  //     'productions_over_all'          => optional($goalteam)->productions_over_all ?? 0,
  //     'productions_check'             => optional($goalteam)->productions_check ?? 0,
  //     'productions_type'              => optional($goalteam)->productions_type ?? 0,
  //     'productions_actual'            => $totalcosting_amount ?? 0,

  //     'no_of_reviews_over_all'        => optional($goalteam)->no_of_reviews_over_all ?? 0,
  //     'no_of_reviews_check'           => optional($goalteam)->no_of_reviews_check ?? 0,
  //     'no_of_reviews_type'            => optional($goalteam)->no_of_reviews_type ?? 0,
  //     'no_of_reviews_actual'          => $totalreview_count ?? 0,

  //     'no_of_placements_over_all'     => optional($goalteam)->no_of_placements_over_all ?? 0,
  //     'no_of_placements_check'        => optional($goalteam)->no_of_placements_check ?? 0,
  //     'no_of_placements_type'         => optional($goalteam)->no_of_placements_type ?? 0,
  //     'no_of_placements_actual'       => $placement_count_total ?? 0,

  //     'mou_over_all'                  => optional($goalteam)->mou_over_all ?? 0,
  //     'mou_check'                     => optional($goalteam)->mou_check ?? 0,
  //     'mou_type'                      => optional($goalteam)->mou_type ?? 0,
  //     'mou_actual'                    => $totalmou_count ?? 0,

  //     'reference_sales_over_all'      => optional($goalteam)->reference_sales_over_all ?? 0,
  //     'reference_sales_check'         => optional($goalteam)->reference_sales_check ?? 0,
  //     'reference_sales_type'          => optional($goalteam)->reference_sales_type ?? 0,
  //     'reference_sales_actual'        => $totalrefferal_count ?? 0,

  //     'status' => optional($goalteam)->status == 1 ? true : false,
  //     'month'  => $month_id
  //   ];

  //   return response()->json([
  //     'status' => 200,
  //     'data'   => $goalteamDetails
  //   ]);
  // }

  // public function getStaffGoal(Request $request)
  // {
  //   $branchId = $request->user()->branch_id;
  //   $departmentId = $request->department_id;
  //   $month_id = $request->month_id; // "March"
  //   $month = date('n', strtotime($month_id)); // Returns 3
  //   $year = $request->year;
  //   $branch_id = $request->user()->branch_id;
  //   $helper             = new \App\Helpers\Helpers();


  //   if (!empty($month_id)) {
  //     if (!is_numeric($month_id)) {
  //       // Convert month name (e.g., "February") to its numeric value
  //       $monthNumber = date('m', strtotime($month_id . ' 1'));
  //       $request->merge(['month_id' => (int)$monthNumber]);
  //     } else {
  //       // Ensure month_id is an integer if it's already numeric
  //       $request->merge(['month_id' => (int)$month_id]);
  //     }
  //   }


  //   //  return $request->all();
  //   // return $request->month_id;
  //   // Get staff members with department and role details
  //   $staff = StaffModel::where('za_staff.branch_id', $branchId)
  //     ->where('za_staff.department_id', $departmentId)
  //     ->where('za_staff.status', 0)
  //     ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
  //     ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
  //     ->orderBy('staff_name', 'ASC')
  //     ->get([
  //       'za_staff.sno',
  //       'za_staff.staff_name',
  //       'za_staff.nick_name',
  //       'za_staff.gender',
  //       'za_staff.avaiable_points',
  //       'za_staff.staff_image',
  //       'za_staff.basic_salary',
  //       'za_department.department_name',
  //       'za_user_role.role_name'
  //     ]);
  //   $goalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', $departmentId)->where('za_goal_set_team.branch_id', $branchId)
  //     ->where('za_goal_set_team.team_goal_month', $request->month_id)
  //     ->where('za_goal_set_team.team_goal_year', $year)
  //     ->first();
  //   // Get goal records for the selected department and month
  //   $goalsetRecords = GoalSetStaffModel::where('za_goal_set_staff.department_id', $departmentId)->where('za_goal_set_staff.branch_id', $branchId)
  //     ->where('za_goal_set_staff.goal_month', $request->month_id)
  //     ->whereMonth('za_goal_set_staff.goal_date', $request->month_id)
  //     ->whereYear('za_goal_set_staff.goal_date', $year)
  //     ->get();
  //   // return $goalsetRecords;
  //   // Convert goalsetRecords to an associative array for easy lookup
  //   $goalsetData = [];
  //   foreach ($goalsetRecords as $goal) {
  //     $goalsetData[$goal->staff_id] = $goal;
  //   }

  //   $helper = new \App\Helpers\Helpers();


  //   $totalAverageBusinessValue = 0;
  //   $totalAverageCollectionValue     = 0;
  //   $totalAverageconvertRatio     = 0;
  //   $totalconvertRatio     = 0;
  //   $totalSpamLeadRatio     = 0;
  //   $totalDeadLeadRatio     = 0;
  //   $totalAllLead             = 0;
  //   $totalMonthLead            = 0;
  //   $totalconvertCustomer            = 0;
  //   $totalHotLead        = 0;
  //   $totalSpamLead      = 0;
  //   $totalDeadLead    = 0;

  //   $totalAllPayment             = 0;
  //   $totalAllPaidPayment        = 0;
  //   $total_basic_pay_pro = 0;


  //   // Attach goal details to staff members
  //   $staffDetails = [];
  //   foreach ($staff as $member) {

  //     $current_date = date('Y-m-d'); // Define the current date
  //     $std_count = TrainingModel::where('za_training.status', 0)
  //       ->where('za_batch.status', 0)
  //       ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
  //       ->where('za_training.staff_id', $member->sno)
  //       ->where('za_batch.start_date', '<=', $current_date)
  //       ->where('za_batch.end_date', '>=', $current_date)
  //       ->count();

  //     //Sales Team

  //     $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->whereNotIn('za_lead.status', [2, 6])
  //       ->where('za_lead.spam_verified', 0)
  //       ->where('za_lead.drop_verified', 0)
  //       ->where('za_lead.internal_status', 0)
  //       ->count();

  //     $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->whereYear('za_lead.registered_date', $year)
  //       ->whereMonth('za_lead.registered_date', $month)
  //       ->whereNotIn('za_lead.status', [2, 6])
  //       ->where('za_lead.spam_verified', 0)
  //       ->where('za_lead.drop_verified', 0)
  //       ->where('za_lead.internal_status', 0)
  //       ->count();

  //     $hotLeadCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->whereYear('za_lead.registered_date', $year)
  //       ->whereMonth('za_lead.registered_date', $month)
  //       ->whereNotIn('za_lead.status', [2, 6])
  //       ->where('za_lead.lead_status_id', 3)
  //       ->where('za_lead.internal_status', 0)
  //       ->where('za_lead.spam_verified', 0)
  //       ->where('za_lead.drop_verified', 0)
  //       ->count();

  //     $customerConvertCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->whereYear('za_lead.registered_date', $year)
  //       ->whereMonth('za_lead.registered_date', $month)
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->where('za_lead.status', 4)->count();

  //     $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])
  //       ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_customer.branch_id', $branch_id)
  //       ->where('za_lead.created_by', $member->sno)
  //       ->whereYear('za_customer.created_at', $year)
  //       ->whereMonth('za_customer.created_at', $month)
  //       ->count();

  //     $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->whereYear('za_lead.registered_date', $year)
  //       ->whereMonth('za_lead.registered_date', $month)
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.spam_verified', 1)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->where('za_lead.status', 7)->count();

  //     $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
  //       ->whereYear('za_lead.registered_date', $year)
  //       ->whereMonth('za_lead.registered_date', $month)
  //       ->where('za_lead.created_by', $member->sno)
  //       ->where('za_lead.drop_verified', 1)
  //       ->where('za_lead.branch_id', $branch_id)
  //       ->where('za_lead.status', 5)->count();

  //     $monthFollowupCount = DB::table('za_appointment')
  //       ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
  //       ->whereIn('za_lead.status', [0, 4])
  //       ->where('za_appointment.created_by', $member->sno)
  //       ->whereYear('za_appointment.appointment_date', $year)
  //       ->whereMonth('za_appointment.appointment_date', $month)
  //       ->count();
  //     $monthwalkincount = DB::table('za_lead_appointment')
  //       ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
  //       ->where('za_lead_appointment.appointment_category', 'walk-in') // Fixed the table reference
  //       ->where('za_lead_appointment.created_by', $member->sno)
  //       ->whereYear('za_lead_appointment.appointment_date', $year)
  //       ->whereMonth('za_lead_appointment.appointment_date', $month)
  //       ->count();

  //     $monthcall_out = DB::table('za_call_tracker')
  //       ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
  //       ->whereYear('call_start_date', $year)
  //       ->whereMonth('call_start_date', $month)
  //       ->where('za_call_tracker.branch_id', $branch_id)
  //       ->where('za_call_tracker.branch_staff_id', $member->sno)
  //       ->first();
  //     $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;


  //     // Spam Ratio
  //     $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
  //     $spam_lead_ratio = number_format($spam_lead_ratio, 2);

  //     // Dead ratio
  //     $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
  //     $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

  //     // customer ratio
  //     $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
  //     $convertion_rate = number_format($convertion_rate, 2);

  //     //acr
  //     $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
  //     $averager_convertion_rate = number_format($averager_convertion_rate, 2);



  //     $currentMonthCustomerCount = 0;
  //     $total_business_amount     = 0;
  //     $total_payment             = 0;
  //     $total_paid_payment        = 0;
  //     $averageBusinessValue      = 0;
  //     $averageCollectionValue    = 0;

  //     if ($customerConvertCount > 0) {
  //       $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->whereIn('za_customer.status', [0, 6])
  //         ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
  //         ->where('za_customer.branch_id', $branch_id)
  //         ->whereIn('za_customer.status', [0, 6])
  //         ->where('za_lead.created_by', $member->sno)
  //         ->whereYear('za_customer.created_at', $year)
  //         ->whereMonth('za_customer.created_at', $month)
  //         ->get();

  //       // if ($currentMonthCustomer->isNotEmpty()) {
  //       //     $currentMonthCustomerCount = $currentMonthCustomer->count();
  //       //     foreach ($currentMonthCustomer as $customer) {
  //       //         $courseIds = json_decode($customer->course_id, true);
  //       //         foreach ($courseIds as $courseId) {
  //       //             // Fetch the course's maximum price
  //       //             $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
  //       //             $total_payment += $payment;
  //       //             // Fetch the total paid amount for the course
  //       //             $paid_payment = PaymentModel::where('customer_id', $customer->sno)
  //       //                 ->where('course_id', $courseId)
  //       //                 ->where('status', 1)
  //       //                 ->sum('paidAmount');
  //       //             $total_paid_payment += $paid_payment;
  //       //         }
  //       //     }
  //       // }
  //       if ($currentMonthCustomer->isNotEmpty()) {
  //         foreach ($currentMonthCustomer as $customer) {

  //           $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
  //             ->where('za_training.customer_id', $customer->sno)
  //             ->where('za_training.tesbo_check', 0)
  //             ->sum('za_training.overall_fees');

  //           $total_payment += $payment;


  //           $latestTraining = DB::table('za_training')
  //             ->where('customer_id', $customer->sno)
  //             ->where('tesbo_check', 2)
  //             ->orderByDesc('sno')
  //             ->first();

  //           if ($latestTraining) {
  //             $total_payment += $latestTraining->overall_fees;
  //           }

  //           $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
  //             ->where('za_training.customer_id', $customer->sno)
  //             ->sum('za_training.paid_amount');

  //           $total_paid_payment += $paid_payment;
  //         }
  //       }

  //       // average
  //       $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
  //       $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

  //       $totalAllPayment += $total_payment;
  //       $totalAllPaidPayment += $total_paid_payment;
  //     }

  //     // Production Goal***********************************************


  //     $staffproduction = StaffModel::select(
  //       'za_staff.sno',
  //       'za_staff.staff_id',
  //       'za_staff.staff_name',
  //       'za_staff.gender',
  //       'za_staff.dob',
  //       'za_staff.mobile_no',
  //       'za_staff.email_id',
  //       'za_staff.staff_image',
  //       'za_staff.nick_name',
  //       'za_staff.knowledge_tag',
  //       'za_staff.per_hour_cost',
  //       'za_job_position.job_position_name',
  //       'za_staff.avaiable_points',
  //       'za_staff.basic_salary',
  //       'za_staff.status AS staff_status'
  //     )
  //       ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
  //       ->where([
  //         ['za_staff.status', 0],
  //         ['za_staff.branch_id', $branch_id],
  //         ['za_staff.sno', $member->sno]
  //       ])
  //       ->orderByDesc('za_staff.sno')
  //       ->first();

  //     // Initialize variables
  //     $total_batch = $total_student = $total_free_batch = $total_staff = 0;
  //     $overall_earned = $overall_earned_per = $success_staff_count = 0;
  //     $slotType = $staffproduction;

  //     $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
  //     $slotType->present_count = $slotType->course_count = 0;
  //     $slotType->slotDetails = [];
  //     $slotType->avg_amnt = $slotType->salary = 0;

  //     // Fetch batch IDs associated with staff
  //     $batchIds = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->distinct()
  //       ->pluck('batch_id')
  //       ->toArray();

  //     $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

  //     foreach ($slotType->batch_ids as $batchId) {
  //       // Fetch slot details for the staff's batches
  //       $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
  //         ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //         ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
  //           ->where('staff_id', $slotType->sno)
  //           ->where(function ($query) use ($month, $year) {
  //             $query->whereMonth('start_date', '<=', $month)
  //               ->whereYear('start_date', '<=', $year)
  //               ->whereMonth('end_date', '>=', $month)
  //               ->whereYear('end_date', '>=', $year);
  //           })
  //           ->pluck('batch_id'))
  //         ->where('za_batch.status', 0)
  //         ->get();

  //       $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

  //       // Fetch batch details
  //       $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
  //         ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //         ->find($batchId);

  //       if ($batch) {
  //         $startTime = Carbon::parse($batch->start_time);
  //         $endTime = Carbon::parse($batch->end_time);
  //         $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

  //         // Fetch attendance records
  //         $attendanceRecords = AttendanceModel::select('per_hr_cost')
  //           ->where([
  //             ['batch_id', $batch->sno],
  //             ['staff_id', $slotType->sno],
  //             ['attendance', 'P']
  //           ])
  //           ->whereMonth('att_date', $month)
  //           ->whereYear('att_date', $year)
  //           ->get();

  //         foreach ($attendanceRecords as $attendance) {
  //           $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
  //         }
  //       }
  //     }

  //     // Student count
  //     $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where('za_training.status', 0)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       // ->distinct('customer_id')
  //       ->count('customer_id');

  //     // Course count
  //     $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       ->distinct('course_id')
  //       ->count('course_id');

  //     // Batch count
  //     $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
  //       ->where('staff_id', $slotType->sno)
  //       ->where(function ($query) use ($month, $year) {
  //         $query->whereMonth('start_date', '<=', $month)
  //           ->whereYear('start_date', '<=', $year)
  //           ->whereMonth('end_date', '>=', $month)
  //           ->whereYear('end_date', '>=', $year);
  //       })
  //       ->distinct('batch_id')
  //       ->count('batch_id');

  //     // Salary calculation
  //     $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
  //     // Average earned percentage calculation
  //     $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
  //     // Calculate free batch count
  //     $total_free_batch = max(0, 8 - $slotType->batch_count);
  //     $overall_earned += $slotType->earned_amount;
  //     $overall_earned_per += $slotType->avg_amnt;
  //     // Count success staff
  //     if ($slotType->salary < $slotType->earned_amount) {
  //       $success_staff_count++;
  //     }
  //     $staffproduction = $slotType;
  //     $costing_amount = $staffproduction->earned_amount ?? 0;

  //     $refferal_count = DB::table('za_referral_persons')
  //       ->where('branch_id', $branch_id)
  //       ->where('referral_id', $member->sno)
  //       ->where('status', 0)
  //       ->where('referral_type', 2)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();

  //     // Production Goal***********************************************
  //     // CRE Goal *****************************************************
  //     $review_count = DB::table('za_review')
  //       ->where('branch_id', $branch_id)
  //       ->where('created_by', $member->sno)
  //       ->where('status', 0)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();

  //     // CRE Goal *****************************************************
  //     // PC Goal *****************************************************

  //     $staff_pc = StaffModel::where('za_staff.branch_id', $branch_id)
  //       ->where('za_staff.department_id', 2)
  //       ->where('za_staff.status', 0)
  //       ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
  //       ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
  //       ->orderBy('staff_name', 'ASC')
  //       ->get([
  //         'za_staff.sno',
  //         'za_staff.staff_name',
  //         'za_staff.nick_name',
  //         'za_staff.gender',
  //         'za_staff.staff_image',
  //         'za_department.department_name',
  //         'za_user_role.role_name'
  //       ]);

  //     $totalcosting_amount = 0;
  //     $totalrefferal_count = 0;

  //     foreach ($staff_pc as $staff_pc_list) {

  //       // Production Goal***********************************************


  //       $staffproduction = StaffModel::select(
  //         'za_staff.sno',
  //         'za_staff.staff_id',
  //         'za_staff.staff_name',
  //         'za_staff.gender',
  //         'za_staff.dob',
  //         'za_staff.mobile_no',
  //         'za_staff.email_id',
  //         'za_staff.staff_image',
  //         'za_staff.nick_name',
  //         'za_staff.knowledge_tag',
  //         'za_staff.per_hour_cost',
  //         'za_job_position.job_position_name',
  //         'za_staff.avaiable_points',
  //         'za_staff.basic_salary',
  //         'za_staff.status AS staff_status'
  //       )
  //         ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
  //         ->where([
  //           ['za_staff.status', 0],
  //           ['za_staff.branch_id', $branch_id],
  //           ['za_staff.sno', $staff_pc_list->sno]
  //         ])
  //         ->orderByDesc('za_staff.sno')
  //         ->first();

  //       // Initialize variables
  //       $total_batch = $total_student = $total_free_batch = $total_staff = 0;
  //       $overall_earned = $overall_earned_per = $success_staff_count = 0;
  //       $slotType = $staffproduction;

  //       $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
  //       $slotType->present_count = $slotType->course_count = 0;
  //       $slotType->slotDetails = [];
  //       $slotType->avg_amnt = $slotType->salary = 0;

  //       // Fetch batch IDs associated with staff
  //       $batchIds = TrainingModel::where('branch_id', $branch_id)
  //         ->where('staff_id', $slotType->sno)
  //         ->distinct()
  //         ->pluck('batch_id')
  //         ->toArray();

  //       $slotType->batch_ids = (array) $batchIds; // Ensure it's an array

  //       foreach ($slotType->batch_ids as $batchId) {
  //         // Fetch slot details for the staff's batches
  //         $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
  //           ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //           ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
  //             ->where('staff_id', $slotType->sno)
  //             ->where(function ($query) use ($month, $year) {
  //               $query->whereMonth('start_date', '<=', $month)
  //                 ->whereYear('start_date', '<=', $year)
  //                 ->whereMonth('end_date', '>=', $month)
  //                 ->whereYear('end_date', '>=', $year);
  //             })
  //             ->pluck('batch_id'))
  //           ->where('za_batch.status', 0)
  //           ->get();

  //         $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

  //         // Fetch batch details
  //         $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
  //           ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
  //           ->find($batchId);

  //         if ($batch) {
  //           $startTime = Carbon::parse($batch->start_time);
  //           $endTime = Carbon::parse($batch->end_time);
  //           $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

  //           // Fetch attendance records
  //           $attendanceRecords = AttendanceModel::select('per_hr_cost')
  //             ->where([
  //               ['batch_id', $batch->sno],
  //               ['staff_id', $slotType->sno],
  //               ['attendance', 'P']
  //             ])
  //             ->whereMonth('att_date', $month)
  //             ->whereYear('att_date', $year)
  //             ->get();

  //           foreach ($attendanceRecords as $attendance) {
  //             $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
  //           }
  //         }
  //       }

  //       // Student count
  //       $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
  //         ->where('staff_id', $slotType->sno)
  //         ->where('za_training.status', 0)
  //         ->where(function ($query) use ($month, $year) {
  //           $query->whereMonth('start_date', '<=', $month)
  //             ->whereYear('start_date', '<=', $year)
  //             ->whereMonth('end_date', '>=', $month)
  //             ->whereYear('end_date', '>=', $year);
  //         })
  //         //   ->distinct('customer_id')
  //         ->count('customer_id');

  //       // Course count
  //       $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
  //         ->where('staff_id', $slotType->sno)
  //         ->where(function ($query) use ($month, $year) {
  //           $query->whereMonth('start_date', '<=', $month)
  //             ->whereYear('start_date', '<=', $year)
  //             ->whereMonth('end_date', '>=', $month)
  //             ->whereYear('end_date', '>=', $year);
  //         })
  //         ->distinct('course_id')
  //         ->count('course_id');

  //       // Batch count
  //       $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
  //         ->where('staff_id', $slotType->sno)
  //         ->where(function ($query) use ($month, $year) {
  //           $query->whereMonth('start_date', '<=', $month)
  //             ->whereYear('start_date', '<=', $year)
  //             ->whereMonth('end_date', '>=', $month)
  //             ->whereYear('end_date', '>=', $year);
  //         })
  //         ->distinct('batch_id')
  //         ->count('batch_id');

  //       // Salary calculation
  //       $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
  //       // Average earned percentage calculation
  //       $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
  //       // Calculate free batch count
  //       $total_free_batch = max(0, 8 - $slotType->batch_count);
  //       $overall_earned += $slotType->earned_amount;
  //       $overall_earned_per += $slotType->avg_amnt;
  //       // Count success staff
  //       if ($slotType->salary < $slotType->earned_amount) {
  //         $success_staff_count++;
  //       }
  //       $staffproduction = $slotType;



  //       $totalcosting_amount += $staffproduction->earned_amount ?? 0;
  //       $total_basic_pay_pro += $slotType->basic_salary ?? 0;

  //       $refferal_count = DB::table('za_referral_persons')
  //         ->where('branch_id', $branch_id)
  //         ->where('referral_id', $staff_pc_list->sno)
  //         ->where('status', 0)
  //         ->where('referral_type', 2)
  //         ->whereYear('created_at', $year)
  //         ->whereMonth('created_at', $month)
  //         ->count();

  //       $totalrefferal_count += $refferal_count ?? 0;
  //     }

  //     if ($departmentId == 5) {
  //       $review_count = $totalrefferal_count;
  //     }

  //     // PC Goal *****************************************************

  //     // Sales Exc *****************************************************
  //     $drop_ids = DB::table('za_drop_refund')
  //       ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
  //       ->where('za_drop_refund.bh_status', 1)
  //       ->where('za_drop_refund.branch_id', $branch_id)
  //       ->pluck('za_training.payment_id');

  //     //   $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
  //     //     ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
  //     //     ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
  //     //     ->whereNotIn('za_payment.payment_id', $drop_ids)
  //     //     ->where('za_payment.status', 0)
  //     //     ->where('za_payment.amount', '>', 0)
  //     //     ->whereIn('za_customer.status',[0,6])
  //     //     ->whereMonth('za_payment.nextPayDate', $month)
  //     //     ->whereYear('za_payment.nextPayDate', $year)
  //     //     ->orderBy('za_payment.sno', 'asc')
  //     //     ->count();

  //     $OutstandingPayment_count = DB::table('za_payment')->where('za_payment.branch_id', $branch_id)
  //       ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
  //       ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
  //       ->whereNotIn('za_payment.payment_id', $drop_ids)
  //       ->where('za_payment.status', 0)
  //       ->where('za_payment.amount', '>', 0)
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_payment.created_by', $member->sno)
  //       ->whereMonth('za_payment.nextPayDate', $month)
  //       ->whereYear('za_payment.nextPayDate', $year)
  //       ->orderBy('za_payment.sno', 'asc')
  //       ->count();

  //     //   $post_sale_count = DB::table('za_training')
  //     //     ->where('created_by', $member->sno)
  //     //     ->where('post_sale_check', 1)
  //     //     ->whereYear('post_sale_date', $year)
  //     //     ->whereMonth('post_sale_date', $month)
  //     //     ->distinct()
  //     //     ->count('customer_id');

  //     $post_sale_count  = DB::table('za_referral_persons')
  //       ->where('branch_id', $branch_id)
  //       ->where('referral_id', $member->sno)
  //       ->where('status', 0)
  //       ->where('referral_type', 2)
  //       ->whereYear('created_at', $year)
  //       ->whereMonth('created_at', $month)
  //       ->count();


  //     $current = Carbon::create($year, $month, 1);
  //     $startDateold = $current->copy()->subYears(20)->startOfMonth();
  //     $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month



  //     $dropoutCustomers = DB::table('za_training')
  //       ->where('status', 2)
  //       ->pluck('customer_id')
  //       ->toArray();

  //     $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->where('za_customer.branch_id', $branchId)
  //       ->whereNotIn('za_customer.sno', $dropoutCustomers)
  //       ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
  //       ->pluck('za_customer.sno')
  //       ->toArray();
  //     // return $prevMonthConvertedCustomers;

  //     // first condition


  //     // here $secondPaymentCustomers  we need colclude the dat get $hacAmount
  //     $hacAmount = DB::table('za_payment')
  //       ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
  //       ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
  //       ->where('za_payment.status', 1) // paid amoun
  //       ->whereIn('za_customer.status', [0, 6])
  //       ->whereYear('za_payment.initialPayDate', $year)
  //       ->whereMonth('za_payment.initialPayDate', $month)
  //       ->where('za_payment.branch_id', $branchId)
  //       ->sum('za_payment.paidAmount');

  //     // Sales Exc *****************************************************

  //     $placement_count = DB::table('za_placement_interview')
  //       ->where('updated_by', $member->sno)
  //       ->where('status', 4)
  //       ->whereYear('selected_date', $year)
  //       ->whereMonth('selected_date', $month)
  //       ->distinct()
  //       ->count('sno');

  //     $mou_count = DB::table('za_placement_company')
  //       ->where('branch_id', $branch_id)
  //       ->where('created_by', $member->sno)
  //       ->where('mou_status', 1)
  //       ->whereYear('mou_upload_date', $year)
  //       ->whereMonth('mou_upload_date', $month)
  //       ->count();


  //     $startDate = Carbon::create($year, $month, 1);
  //     $currentDate = Carbon::now();
  //     $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
  //     $dayCount = $startDate->diffInDays($endDate) + 1;
  //     $monthcall_out = $dayCount > 0  ? round($monthcall_out /  $dayCount) : 0;
  //     $monthwalkincount = $dayCount > 0  ? round($monthwalkincount /  $dayCount) : 0;
  //     $monthFollowupCount = $dayCount > 0  ? round($monthFollowupCount /  $dayCount) : 0;

  //     $basic_pay = $member->basic_salary > 0 ? ($member->basic_salary * 10) : 0;
  //     $costing_amount_asign = $goalsetData[$member->sno]->production_costing ?? 0;
  //     $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
  //     $costing_amount = $costing_amount2;




  //     $productions_asign   = $goalsetData[$member->sno]->productions ?? 0;
  //     $total_basic_pay_pro = $total_basic_pay_pro * 10;
  //     $totalcosting_amount = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $productions_asign : 0;

  //     if (isset($goalsetData[$member->sno]->goal_completed)) {
  //       if ($goalsetData[$member->sno]->goal_completed == 1) {
  //         $customerConvertCount = $goalsetData[$member->sno]->conversion_actual ?? 0;
  //         $convertion_rate = $goalsetData[$member->sno]->CR_actual ?? 0;
  //         $averageBusinessValue = $goalsetData[$member->sno]->ABV_actual ?? 0;
  //         $averageCollectionValue = $goalsetData[$member->sno]->ACV_actual ?? 0;
  //         $monthcall_out = $goalsetData[$member->sno]->avg_call_out_actual ?? 0;
  //         $monthwalkincount = $goalsetData[$member->sno]->no_of_walk_actual ?? 0;
  //         $monthFollowupCount = $goalsetData[$member->sno]->no_of_followup_actual ?? 0;
  //         $std_count = $goalsetData[$member->sno]->min_no_of_students_actual ?? 0;
  //         $costing_amount = $goalsetData[$member->sno]->production_costing_actual ?? 0;
  //         $review_count = $goalsetData[$member->sno]->no_of_reviews_actual ?? 0;
  //         $placement_count = $goalsetData[$member->sno]->no_of_placements_actual ?? 0;
  //         $mou_count = $goalsetData[$member->sno]->mou_actual ?? 0;
  //         $totalcosting_amount = $goalsetData[$member->sno]->productions_actual ?? 0;
  //         $hacAmount = $goalsetData[$member->sno]->hac_actual ?? 0;
  //         $post_sale_count = $goalsetData[$member->sno]->no_of_post_sale_actual ?? 0;
  //         $OutstandingPayment_count = $goalsetData[$member->sno]->no_of_outstanding_actual ?? 0;
  //         $refferal_count = $goalsetData[$member->sno]->reference_sales_actual ?? 0;
  //       }
  //     }

  //     // $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, $departmentId , $month, $year, $branch_id) ?? 0;



  //     $currentMonth = $month;
  //     $currentYear  = $year;

  //     $startDate = Carbon::create($currentYear, $currentMonth, 1);
  //     $currentDate = Carbon::now();
  //     $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

  //     $dayCounts = 0;
  //     $dateSrt = $startDate->copy();

  //     while ($dateSrt->lte($endDate)) {
  //       if (!$dateSrt->isSunday()) {
  //         $dayCounts++;
  //       }
  //       $dateSrt->addDay();
  //     }
  //     $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
  //       ->where('branch_id', $branchId)
  //       ->whereIn('attendance', ['P', 'HD'])
  //       ->whereMonth('date', $month)
  //       ->whereYear('date', $year)
  //       ->count();
  //     //  return $dayCounts;
  //     $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

  //     if ($presentDays == 0) {
  //       $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  //     } elseif ($presentDays > 0 && $presentDays < 50) {
  //       $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  //     } elseif ($presentDays >= 50 && $presentDays < 75) {
  //       $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  //     } elseif ($presentDays >= 75 && $presentDays < 100) {
  //       $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  //     } elseif ($presentDays == 100) {
  //       $heart = '<img src="' . asset('assets/eapl_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  //     }



  //     $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, $departmentId, $month, $year, $branch_id) ?? 0;
  //     $ratio = $goal_progress;
  //     if ($ratio > 100) {
  //       $color = '#7854c7'; // Purple
  //     } elseif ($ratio >= 80) {
  //       $color = '#34C759'; // Green
  //     } elseif ($ratio >= 40) {
  //       $color = '#FFCC00'; // Yellow
  //     } else {
  //       $color = '#FF3B30'; // Red
  //     }

  //     if ($departmentId == 1) {
  //       // return $actualMonthLeadCount;
  //       $promisecount = DB::table('za_sales_promise')
  //         ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
  //         ->where('za_staff.department_id', 1)
  //         ->where('za_sales_promise.branch_id', $branch_id)
  //         ->whereYear('za_sales_promise.promise_date', $year)
  //         ->whereMonth('za_sales_promise.promise_date', $month)
  //         ->where('za_sales_promise.status', 0)
  //         ->where('za_staff.sno', $member->sno)
  //         ->sum('za_sales_promise.promise_count');

  //       $successcount = DB::table('za_sales_promise')
  //         ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
  //         ->where('za_staff.department_id', 1)
  //         ->where('za_sales_promise.branch_id', $branch_id)
  //         ->whereYear('za_sales_promise.promise_date', $year)
  //         ->whereMonth('za_sales_promise.promise_date', $month)
  //         ->where('za_sales_promise.status', 1)
  //         ->where('za_staff.sno', $member->sno)
  //         ->sum('za_sales_promise.promise_count');

  //       // Avoid division by zero
  //       $formattedPromiseSuccess = 0;

  //       if ($promisecount > 0) {
  //         $rawScore = ($successcount / $promisecount) * 10;
  //         $score = min(round($rawScore), 10); // round to whole number and cap at 10
  //         $formattedPromiseSuccess = str_pad($score, 2, '0', STR_PAD_LEFT); // ensure 2 digits like 02, 10
  //       } else {
  //         $formattedPromiseSuccess = '00';
  //       }

  //       // Determine badge color
  //       $trustBadgeColor = 'bg-danger';
  //       if ($formattedPromiseSuccess >= 5 && $formattedPromiseSuccess <= 8) {
  //         $trustBadgeColor = 'bg-warning';
  //       } elseif ($formattedPromiseSuccess >= 9) {
  //         $trustBadgeColor = 'bg-success';
  //       }

  //       $promise = '<div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
  //                     <div class="fs-8 fw-semibold text-dark">TS</div>
  //                     <div class="fs-8 fw-semibold text-black">
  //                       <label class="badge ' . $trustBadgeColor . ' fw-semibold fs-8">' . $formattedPromiseSuccess  . '</label>
  //                     </div>
  //                   </div>';
  //     } else {
  //       $promise = '';
  //     }



  //     $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
  //                   <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
  //       . $heart .
  //       '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
  //                   </div>
  //                   <div class="cursor-pointer">
  //                     <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
  //                      <div class="progress-bar progress-bar-striped progress-bar-animated"
  //                        role="progressbar"
  //                        style="width: ' . $goal_progress . '%; background: ' . $color . ';"
  //                        aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
  //                     </div>
  //                     <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
  //                   </div>
  //                   ' . $promise . '
  //                   <div class="mb-0 text-center">
  //                     <div class="fs-8 fw-semibold text-dark">Points</div>
  //                     <div class="fs-8 fw-semibold text-black">
  //                       <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
  //                     </div>
  //                   </div>
  //                 </div>';




  //     $staffDetails2 = [
  //       'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
  //       'conversion_actual'         => $customerConvertCount ?? 0,
  //       'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
  //       'cr_actual'                 => $convertion_rate ?? 0,
  //       'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
  //       'abv_actual'                => $averageBusinessValue ?? 0,
  //       'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
  //       'acv_actual'                => $averageCollectionValue ?? 0,
  //       'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
  //       'avg_call_out_actual'       => $monthcall_out ?? 0,
  //       'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
  //       'no_of_walk_actual'         => $monthwalkincount ?? 0,
  //       'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
  //       'no_of_followup_actual'     => $monthFollowupCount ?? 0,
  //       'min_no_of_students'        => $goalsetData[$member->sno]->min_no_of_students ?? 0,
  //       'min_no_of_students_actual' => $std_count ?? 0,
  //       'production_costing'        => $goalsetData[$member->sno]->production_costing ?? 0,
  //       'production_costing_actual' => $costing_amount ?? 0,
  //       'no_of_reviews'             => $goalsetData[$member->sno]->no_of_reviews ?? 0,
  //       'no_of_reviews_actual'      => $review_count ?? 0,
  //       'no_of_placements'          => $goalsetData[$member->sno]->no_of_placements ?? 0,
  //       'no_of_placements_actual'   => $placement_count ?? 0,
  //       'mou'                       => $goalsetData[$member->sno]->mou ?? 0,
  //       'mou_actual'                => $mou_count ?? 0,
  //       'productions'               => $goalsetData[$member->sno]->productions ?? 0,
  //       'productions_actual'        => $totalcosting_amount ?? 0,
  //       'hac'                       => $goalsetData[$member->sno]->hac ?? 0,
  //       'hac_actual'                => $hacAmount ?? 0,
  //       'no_of_post_sale'           => $goalsetData[$member->sno]->no_of_post_sale ?? 0,
  //       'no_of_post_sale_actual'    => $post_sale_count ?? 0,
  //       'no_of_outstanding'         => $goalsetData[$member->sno]->no_of_outstanding ?? 0,
  //       'no_of_outstanding_actual'  => $OutstandingPayment_count ?? 0,
  //       'reference_sales'           => $goalsetData[$member->sno]->reference_sales ?? 0,
  //       'reference_sales_actual'    => $refferal_count ?? '0',
  //     ];
  //     $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
  //     $goal_achievements = false;
  //     if (isset($ten_x)) {
  //       foreach ($ten_x as $key => $value) {
  //         $isChecked = $value === "1";
  //         if ($isChecked) {
  //           $type2 = str_replace("_10x", "", $key);
  //           $goal_value = $staffDetails2[$type2] ?? 0;
  //           $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
  //           if ($goal_value > 0) {
  //             if ($actual_value < $goal_value) {
  //               $goal_achievements = true; // Not Achieved
  //               break; // No need to continue checking if one goal failed
  //             }
  //           } else {
  //             $goal_achievements = true; // Invalid goal
  //             break;
  //           }
  //         }
  //       }
  //     }


  //     $staffDetails[] = [
  //       'sno'                       => $member->sno,
  //       'staff_name'                => $member->staff_name,
  //       'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
  //       'goal_achievements'         => $goal_achievements,
  //       'nick_name'                 => $member->nick_name,
  //       'gender'                    => $member->gender,
  //       'staff_image'               => $member->staff_image,
  //       'department_name'           => $member->department_name,
  //       'role_name'                 => $member->role_name,
  //       'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
  //       'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
  //       'month'                     => $month_id,
  //       'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,

  //       'conversion_check'          => $goalsetteam->conversion_check ?? 0,
  //       'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
  //       'conversion_actual'         => $customerConvertCount ?? 0,

  //       'cr_check'                  => $goalsetteam->cr_check ?? 0,
  //       'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
  //       'cr_actual'                 => $convertion_rate ?? 0,

  //       'abv_check'                 => isset($goalsetteam->abv_check) ? $goalsetteam->abv_check : 0,
  //       'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
  //       'abv_actual'                => $averageBusinessValue ?? 0,

  //       'acv_check'                 => isset($goalsetteam->acv_check) ? $goalsetteam->acv_check : 0,
  //       'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
  //       'acv_actual'                => $averageCollectionValue ?? 0,

  //       'avg_call_out_check'        => $goalsetteam->avg_call_out_check ?? 0,
  //       'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
  //       'avg_call_out_actual'       => $monthcall_out ?? 0,

  //       'no_of_walk_check'          => $goalsetteam->no_of_walk_check ?? 0,
  //       'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
  //       'no_of_walk_actual'         => $monthwalkincount ?? 0,

  //       'no_of_followup_check'      => $goalsetteam->no_of_followup_check ?? 0,
  //       'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
  //       'no_of_followup_actual'     => $monthFollowupCount ?? 0,

  //       'min_no_of_students_check'  => $goalsetteam->min_no_of_students_check ?? 0,
  //       'min_no_of_students'        => $goalsetData[$member->sno]->min_no_of_students ?? 0,
  //       'min_no_of_students_actual' => $std_count ?? 0,


  //       'production_costing_check'  => $goalsetteam->production_costing_check ?? 0,
  //       'production_costing'        => $goalsetData[$member->sno]->production_costing ?? 0,
  //       'production_costing_actual' => $costing_amount ?? 0,

  //       'no_of_reviews_check'       => $goalsetteam->no_of_reviews_check ?? 0,
  //       'no_of_reviews'             => $goalsetData[$member->sno]->no_of_reviews ?? 0,
  //       'no_of_reviews_actual'      => $review_count ?? 0,

  //       'no_of_placements_check'    => $goalsetteam->no_of_placements_check ?? 0,
  //       'no_of_placements'          => $goalsetData[$member->sno]->no_of_placements ?? 0,
  //       'no_of_placements_actual'   => $placement_count ?? 0,

  //       'mou_check'                 => $goalsetteam->mou_check ?? 0,
  //       'mou'                       => $goalsetData[$member->sno]->mou ?? 0,
  //       'mou_actual'                => $mou_count ?? 0,

  //       'productions_check'         => $goalsetteam->productions_check ?? 0,
  //       'productions'               => $goalsetData[$member->sno]->productions ?? 0,
  //       'productions_actual'        => $totalcosting_amount ?? 0,

  //       'hac_check'                 => $goalsetteam->hac_check ?? 0,
  //       'hac'                       => $goalsetData[$member->sno]->hac ?? 0,
  //       'hac_actual'                => $hacAmount ?? 0,

  //       'no_of_post_sale_check'     => $goalsetteam->no_of_post_sale_check ?? 0,
  //       'no_of_post_sale'           => $goalsetData[$member->sno]->no_of_post_sale ?? 0,
  //       'no_of_post_sale_actual'    => $post_sale_count ?? 0,

  //       'no_of_outstanding_check'   => $goalsetteam->no_of_outstanding_check ?? 0,
  //       'no_of_outstanding'         => $goalsetData[$member->sno]->no_of_outstanding ?? 0,
  //       'no_of_outstanding_actual'  => $OutstandingPayment_count ?? 0,

  //       'reference_sales'           => $goalsetData[$member->sno]->reference_sales ?? 0,
  //       'reference_sales_check'     => $goalsetteam->reference_sales_check ?? 0,
  //       'reference_sales_actual'    => $refferal_count ?? '0',

  //       'sales_lead_checks'    => $goalsetData[$member->sno]->sales_lead_check ?? 0,


  //       'score_td'    => $score_td ?? '-',


  //     ];
  //   }

  //   return response()->json([
  //     'status' => 200,
  //     'data' => $staffDetails
  //   ]);
  // }

  public function getTeamGoal(Request $request)
  {
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $year = $request->year;

    // Convert month name to number
    if (!empty($month_id)) {
      if (!is_numeric($month_id)) {
        $monthNumber = date('m', strtotime($month_id . ' 1'));
        $month = (int) $monthNumber;
      } else {
        $month = (int) $month_id;
      }
    }

    // Fetch department and goal
    $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);
    $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    $staff = StaffModel::where('za_staff.branch_id', $branchId)
      ->where('za_staff.department_id', $departmentId)
      ->where('za_staff.status', 0)
      ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'za_staff.sno',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.department_id',
        'za_staff.branch_id',
        'za_staff.staff_image',
        'za_staff.basic_salary',
        'za_department.department_name',
        'za_user_role.role_name'
      ]);

    if ($staff->isEmpty()) {
      return response()->json(['status' => 200, 'data' => $this->getEmptyTeamGoalArray($department, $goalteam, $month_id)]);
    }

    $staffIds = $staff->pluck('sno')->toArray();

    // Batch fetch all data
    $batchData = $this->batchFetchTeamData($staffIds, $branchId, $month, $year);

    // Calculate totals
    $totals = $this->calculateTeamTotals($staff, $batchData, $month, $year);

    $totals = $this->calculateFinalTeamMetrics($totals, $staff->count(), $month, $year);

    // Apply goal overrides if completed
    if ($goalteam && $goalteam->goal_completed == 1) {
      $totals = $this->applyTeamGoalOverrides($goalteam, $totals);
    }

    // Calculate final metrics

    // Build response
    $goalteamDetails = $this->buildTeamGoalResponseArray($department, $goalteam, $totals, $month_id);

    return response()->json(['status' => 200, 'data' => $goalteamDetails]);
  }

  /**
   * Batch fetch all team data
   */
  private function batchFetchTeamData($staffIds, $branchId, $month, $year)
  {
    // Lead counts
    $allLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereNotIn('status', [2, 6])
      ->where('spam_verified', 0)
      ->where('drop_verified', 0)
      ->where('internal_status', 0)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $monthLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->whereNotIn('status', [2, 6])
      ->where('spam_verified', 0)
      ->where('drop_verified', 0)
      ->where('internal_status', 0)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $spamLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->where('spam_verified', 1)
      ->where('status', 7)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $deadLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->where('drop_verified', 1)
      ->where('status', 5)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    // Converted customers
    $convertedCustomers = DB::table('za_customer')
      ->select('za_lead.created_by', DB::raw('COUNT(za_customer.sno) as count'))
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_lead.created_by', $staffIds)
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->groupBy('za_lead.created_by')
      ->get()
      ->keyBy('created_by');

    // Followups and walkins
    $followups = DB::table('za_appointment')
      ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_lead.status', [0, 4])
      ->whereIn('za_appointment.created_by', $staffIds)
      ->whereYear('za_appointment.appointment_date', $year)
      ->whereMonth('za_appointment.appointment_date', $month)
      ->select('za_appointment.created_by', DB::raw('COUNT(*) as count'))
      ->groupBy('za_appointment.created_by')
      ->get()
      ->keyBy('created_by');

    $walkins = DB::table('za_lead_appointment')
      ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
      ->where('za_lead_appointment.appointment_category', 'walk-in')
      ->whereIn('za_lead_appointment.created_by', $staffIds)
      ->whereYear('za_lead_appointment.appointment_date', $year)
      ->whereMonth('za_lead_appointment.appointment_date', $month)
      ->select('za_lead_appointment.created_by', DB::raw('COUNT(*) as count'))
      ->groupBy('za_lead_appointment.created_by')
      ->get()
      ->keyBy('created_by');

    // Call outs
    $callOuts = DB::table('za_call_tracker')
      ->select('branch_staff_id', DB::raw('COUNT(*) as count'))
      ->whereIn('branch_staff_id', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('call_status', 0)
      ->groupBy('branch_staff_id')
      ->get()
      ->keyBy('branch_staff_id');

    // Payment data
    $paymentData = $this->batchFetchPaymentData($staffIds, $branchId, $year, $month);

    // In batchFetchTeamData method, fix student counts with proper table prefixes:
    $currentDate = date('Y-m-d');
    $studentCounts = DB::table('za_training')
      ->select('za_training.staff_id', DB::raw('COUNT(DISTINCT za_training.customer_id) as student_count'))
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where('za_batch.start_date', '<=', $currentDate)
      ->where('za_batch.end_date', '>=', $currentDate)
      ->groupBy('za_training.staff_id')
      ->get()
      ->keyBy('staff_id');

    // Production costing (earned amount from attendance)
    $earnedAmounts = $this->batchFetchEarnedAmounts($staffIds, $branchId, $month, $year);

    // Referrals, reviews, MOU, placements
    $referrals = DB::table('za_referral_persons')
      ->select('referral_id', DB::raw('COUNT(*) as count'))
      ->whereIn('referral_id', $staffIds)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->groupBy('referral_id')
      ->get()
      ->keyBy('referral_id');

    $reviews = DB::table('za_review')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $mouCounts = DB::table('za_placement_company')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->where('mou_status', 1)
      ->whereYear('mou_upload_date', $year)
      ->whereMonth('mou_upload_date', $month)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $placements = DB::table('za_placement_interview')
      ->select('updated_by', DB::raw('COUNT(DISTINCT sno) as count'))
      ->whereIn('updated_by', $staffIds)
      ->where('status', 4)
      ->whereYear('selected_date', $year)
      ->whereMonth('selected_date', $month)
      ->groupBy('updated_by')
      ->get()
      ->keyBy('updated_by');

    // Outstanding payments
    $dropIds = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->where('za_drop_refund.branch_id', $branchId)
      ->pluck('za_training.payment_id')
      ->toArray();

    $outstandings = DB::table('za_payment')
      ->select('za_payment.created_by', DB::raw('COUNT(*) as count'))
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.created_by', $staffIds)
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_payment.payment_id', $dropIds)
      ->where('za_payment.status', 0)
      ->where('za_payment.amount', '>', 0)
      ->whereIn('za_customer.status', [0, 6])
      ->whereMonth('za_payment.nextPayDate', $month)
      ->whereYear('za_payment.nextPayDate', $year)
      ->groupBy('za_payment.created_by')
      ->get()
      ->keyBy('created_by');

    // HAC amounts
    $hacAmounts = $this->batchFetchHACAmounts($branchId, $year, $month);

    return [
      'all_leads' => $allLeads,
      'month_leads' => $monthLeads,
      'spam_leads' => $spamLeads,
      'dead_leads' => $deadLeads,
      'converted_customers' => $convertedCustomers,
      'followups' => $followups,
      'walkins' => $walkins,
      'call_outs' => $callOuts,
      'payment_data' => $paymentData,
      'student_counts' => $studentCounts,
      'earned_amounts' => $earnedAmounts,
      'referrals' => $referrals,
      'reviews' => $reviews,
      'mou_counts' => $mouCounts,
      'placements' => $placements,
      'outstandings' => $outstandings,
      'hac_amounts' => $hacAmounts,
    ];
  }

  /**
   * Batch fetch payment data
   */
  private function batchFetchPaymentData($staffIds, $branchId, $year, $month)
  {
    $customers = DB::table('za_customer')
      ->select('za_customer.sno', 'za_lead.created_by')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_lead.created_by', $staffIds)
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    $paymentData = [];
    foreach ($staffIds as $staffId) {
      $paymentData[$staffId] = ['total_payment' => 0, 'paid_payment' => 0];
    }

    foreach ($customers as $customer) {
      // Training fees (tesbo_check = 0)
      $trainingSum = DB::table('za_training')
        ->where('customer_id', $customer->sno)
        ->where('tesbo_check', 0)
        ->sum('overall_fees');
      $paymentData[$customer->created_by]['total_payment'] += $trainingSum;

      // Latest training (tesbo_check = 2)
      $latestTraining = DB::table('za_training')
        ->where('customer_id', $customer->sno)
        ->where('tesbo_check', 2)
        ->orderByDesc('sno')
        ->first();
      if ($latestTraining) {
        $paymentData[$customer->created_by]['total_payment'] += $latestTraining->overall_fees;
      }

      // Paid amount
      $paidAmount = DB::table('za_training')
        ->where('customer_id', $customer->sno)
        ->sum('paid_amount');
      $paymentData[$customer->created_by]['paid_payment'] += $paidAmount;
    }

    return $paymentData;
  }

  /**
   * Batch fetch earned amounts from attendance
   */
  private function batchFetchEarnedAmounts($staffIds, $branchId, $month, $year)
  {
    $earnedAmounts = [];
    foreach ($staffIds as $staffId) {
      $earnedAmounts[$staffId] = 0;
    }

    // Get all trainings for these staff with active batches in the month/year range
    $trainings = DB::table('za_training')
      ->select('za_training.staff_id', 'za_training.batch_id')
      ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.branch_id', $branchId)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('za_training.start_date', '<=', $month)
          ->whereYear('za_training.start_date', '<=', $year)
          ->whereMonth('za_training.end_date', '>=', $month)
          ->whereYear('za_training.end_date', '>=', $year);
      })
      ->distinct()
      ->get();

    if ($trainings->isEmpty()) {
      return $earnedAmounts;
    }

    $batchIds = $trainings->pluck('batch_id')->unique()->toArray();

    // Get batches with slot times
    $batches = DB::table('za_batch')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->whereIn('za_batch.sno', $batchIds)
      ->where('za_batch.status', 0)
      ->select('za_batch.sno', 'za_slot.start_time', 'za_slot.end_time')
      ->get()
      ->keyBy('sno');

    // Get attendance records with per_hr_cost from attendance table (not calculated)
    $attendances = DB::table('za_attendance')
      ->select('za_attendance.batch_id', 'za_attendance.staff_id', 'za_attendance.per_hr_cost')
      ->whereIn('za_attendance.batch_id', $batchIds)
      ->whereIn('za_attendance.staff_id', $staffIds)
      ->where('za_attendance.attendance', 'P')
      ->whereMonth('za_attendance.att_date', $month)
      ->whereYear('za_attendance.att_date', $year)
      ->get();

    foreach ($attendances as $attendance) {
      $batch = $batches[$attendance->batch_id] ?? null;
      if ($batch && $batch->start_time && $batch->end_time) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $duration = $startTime->diffInMinutes($endTime) / 60;

        // Use per_hr_cost from attendance table (as in old code)
        $earnedAmounts[$attendance->staff_id] += ($attendance->per_hr_cost * $duration);
      }
    }

    return $earnedAmounts;
  }

  /**
   * Batch fetch HAC amounts - FIXED to match old code logic
   */
  private function batchFetchHACAmounts($branchId, $year, $month)
  {
    // Old code: HAC is sum of paidAmount from za_payment where status=1,
    // customer status in [0,6], and initialPayDate matches month/year
    $hacAmounts = [];

    $hacData = DB::table('za_payment')
      ->select('za_payment.created_by', DB::raw('SUM(za_payment.paidAmount) as total_hac'))
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->where('za_payment.status', 1) // paid amount
      ->whereIn('za_customer.status', [0, 6])
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->where('za_payment.branch_id', $branchId)
      ->groupBy('za_payment.created_by')
      ->get();

    foreach ($hacData as $data) {
      $hacAmounts[$data->created_by] = $data->total_hac;
    }

    return $hacAmounts;
  }

  /**
   * Calculate team totals from batch data
   */
  private function calculateTeamTotals($staff, $batchData, $month, $year)
  {
    $totals = [
      'all_lead' => 0,
      'month_lead' => 0,
      'spam_lead' => 0,
      'dead_lead' => 0,
      'converted_customers' => 0,
      'followup_count' => 0,
      'walkin_count' => 0,
      'call_out_count' => 0,
      'total_payment' => 0,
      'paid_payment' => 0,
      'student_count' => 0,
      'earned_amount' => 0,
      'referral_count' => 0,
      'review_count' => 0,
      'mou_count' => 0,
      'placement_count' => 0,
      'outstanding_count' => 0,
      'hac_amount' => 0,
      'total_basic_salary' => 0,
      'production_costing_assign' => 0, // Add this
      'production_costing_actual' => 0, // Add this
    ];
    // Get goal team for production costing assign
    $goalteam = GoalSetTeamModel::where('department_id', $staff->first()->department_id ?? 0)
      ->where('branch_id', $staff->first()->branch_id ?? 0)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();
    
    // return $goalteam;
    
    if ($goalteam) {
      $totals['production_costing_assign'] = $goalteam->production_costing_over_all ?? 0;
    }

    foreach ($staff as $member) {
      $staffId = $member->sno;

      $totals['all_lead'] += $batchData['all_leads'][$staffId]->count ?? 0;
      $totals['month_lead'] += $batchData['month_leads'][$staffId]->count ?? 0;
      $totals['spam_lead'] += $batchData['spam_leads'][$staffId]->count ?? 0;
      $totals['dead_lead'] += $batchData['dead_leads'][$staffId]->count ?? 0;
      $totals['converted_customers'] += $batchData['converted_customers'][$staffId]->count ?? 0;
      $totals['followup_count'] += $batchData['followups'][$staffId]->count ?? 0;
      $totals['walkin_count'] += $batchData['walkins'][$staffId]->count ?? 0;
      $totals['call_out_count'] += $batchData['call_outs'][$staffId]->count ?? 0;
      $totals['total_payment'] += $batchData['payment_data'][$staffId]['total_payment'] ?? 0;
      $totals['paid_payment'] += $batchData['payment_data'][$staffId]['paid_payment'] ?? 0;
      $totals['student_count'] += $batchData['student_counts'][$staffId]->student_count ?? 0;
      $totals['earned_amount'] += $batchData['earned_amounts'][$staffId] ?? 0;
      $totals['referral_count'] += $batchData['referrals'][$staffId]->count ?? 0;
      $totals['review_count'] += $batchData['reviews'][$staffId]->count ?? 0;
      $totals['mou_count'] += $batchData['mou_counts'][$staffId]->count ?? 0;
      $totals['placement_count'] += $batchData['placements'][$staffId]->count ?? 0;
      $totals['outstanding_count'] += $batchData['outstandings'][$staffId]->count ?? 0;
      $totals['total_basic_salary'] += $member->basic_salary ?? 0;
    }

    $totals['hac_amount'] = array_sum($batchData['hac_amounts']);

    return $totals;
  }

  /**
   * Apply team goal overrides
   */
  private function applyTeamGoalOverrides($goalteam, $totals)
  {
    $overrides = [
      'converted_customers' => 'conversion_actual',
      'convertion_rate' => 'cr_actual',
      'business_value' => 'abv_actual',
      'collection_value' => 'acv_actual',
      'call_out_count' => 'avg_call_out_actual',
      'walkin_count' => 'no_of_walk_actual',
      'followup_count' => 'no_of_followup_actual',
      'hac_amount' => 'hac_actual',
      'referral_count' => 'reference_sales_actual',
      'outstanding_count' => 'no_of_outstanding_actual',
      'student_count' => 'min_no_of_students_actual',
      'review_count' => 'no_of_reviews_actual',
      'mou_count' => 'mou_actual',
      'placement_count' => 'no_of_placements_actual',
    ];

    foreach ($overrides as $key => $field) {
      if (isset($goalteam->$field)) {
        $totals[$key] = $goalteam->$field;
      }
    }

    // Add production costing override
    if (isset($goalteam->production_costing_actual)) {
      $totals['production_costing'] = $goalteam->production_costing_actual;
    }

    if (isset($goalteam->productions_actual)) {
      $totals['productions_actual'] = $goalteam->productions_actual;
    }

    // Recalculate derived values only if not overridden
    if (!isset($goalteam->abv_actual)) {
      $totals['total_payment'] = ($totals['converted_customers'] ?? 0) * ($totals['business_value'] ?? 0);
    }
    if (!isset($goalteam->acv_actual)) {
      $totals['paid_payment'] = ($totals['converted_customers'] ?? 0) * ($totals['collection_value'] ?? 0);
    }

    return $totals;
  }

  /**
   * Calculate final team metrics
   */
  private function calculateFinalTeamMetrics($totals, $staffCount, $month, $year)
  {
    // Conversion rate
    $totals['convertion_rate'] = ($totals['month_lead'] ?? 0) > 0
      ? number_format(($totals['converted_customers'] / $totals['month_lead']) * 100, 2)
      : 0;

    // Business and collection values
    $totals['business_value'] = ($totals['converted_customers'] ?? 0) > 0
      ? round($totals['total_payment'] / $totals['converted_customers'], 2)
      : 0;

    $totals['collection_value'] = ($totals['converted_customers'] ?? 0) > 0
      ? round($totals['paid_payment'] / $totals['converted_customers'], 2)
      : 0;

    // Daily averages
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
      ? $currentDate
      : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;

    $totals['avg_call_out'] = ($dayCount > 0 && $staffCount > 0)
      ? round($totals['call_out_count'] / ($staffCount * $dayCount))
      : 0;

    $totals['avg_walkin'] = ($dayCount > 0 && $staffCount > 0)
      ? round($totals['walkin_count'] / ($staffCount * $dayCount))
      : 0;

    $totals['avg_followup'] = ($dayCount > 0 && $staffCount > 0)
      ? round($totals['followup_count'] / ($staffCount * $dayCount))
      : 0;

    // Production costing
    $totalBasicPayPro = ($totals['total_basic_salary'] ?? 0) * 10;
    $costingAmountAsign = $totals['production_costing_assign'] ?? 0;
    $totals['production_costing'] = $totalBasicPayPro > 0
      ? ($totals['earned_amount'] / $totalBasicPayPro) * $costingAmountAsign
      : 0;

    // productions_actual should be the same as production_costing in old code
    $totals['productions_actual'] = $totals['production_costing'];

    return $totals;
  }

  /**
   * Build team goal response array
   */
  private function buildTeamGoalResponseArray($department, $goalteam, $totals, $month_id)
  {
    return [
      'department_name' => optional($department)->department_name ?? '',
      'department_id' => optional($department)->sno ?? '',
      'team_id' => optional($goalteam)->sno ?? '',
      'ten_x' => json_decode(optional($goalteam)->ten_x ?? '{}', true),

      'conversion_over_all' => optional($goalteam)->conversion_over_all ?? 0,
      'conversion_check' => optional($goalteam)->conversion_check ?? 0,
      'conversion_type' => optional($goalteam)->conversion_type ?? 0,
      'conversion_actual' => $totals['converted_customers'] ?? 0,

      'cr_over_all' => optional($goalteam)->cr_over_all ?? 0,
      'cr_check' => optional($goalteam)->cr_check ?? 0,
      'cr_type' => optional($goalteam)->cr_type ?? 0,
      'cr_actual' => $totals['convertion_rate'] ?? 'N/A',

      'abv_over_all' => optional($goalteam)->abv_over_all ?? 0,
      'abv_check' => optional($goalteam)->abv_check ?? 0,
      'abv_type' => optional($goalteam)->abv_type ?? 0,
      'abv_actual' => $totals['business_value'] ?? 0,

      'acv_over_all' => optional($goalteam)->acv_over_all ?? 0,
      'acv_check' => optional($goalteam)->acv_check ?? 0,
      'acv_type' => optional($goalteam)->acv_type ?? 0,
      'acv_actual' => $totals['collection_value'] ?? 0,

      'avg_call_out_over_all' => optional($goalteam)->avg_call_out_over_all ?? 0,
      'avg_call_out_check' => optional($goalteam)->avg_call_out_check ?? 0,
      'avg_call_out_type' => optional($goalteam)->avg_call_out_type ?? 0,
      'avg_call_out_actual' => $totals['avg_call_out'] ?? 0,

      'no_of_walk_over_all' => optional($goalteam)->no_of_walk_over_all ?? 0,
      'no_of_walk_check' => optional($goalteam)->no_of_walk_check ?? 0,
      'no_of_walk_type' => optional($goalteam)->no_of_walk_type ?? 0,
      'no_of_walk_actual' => $totals['avg_walkin'] ?? 0,

      'no_of_followup_over_all' => optional($goalteam)->no_of_followup_over_all ?? 0,
      'no_of_followup_check' => optional($goalteam)->no_of_followup_check ?? 0,
      'no_of_followup_type' => optional($goalteam)->no_of_followup_type ?? 0,
      'no_of_followup_actual' => $totals['avg_followup'] ?? 0,

      'hac_over_all' => optional($goalteam)->hac_over_all ?? 0,
      'hac_check' => optional($goalteam)->hac_check ?? 0,
      'hac_type' => optional($goalteam)->hac_type ?? 0,
      'hac_actual' => $totals['hac_amount'] ?? 0,

      'no_of_post_sale_over_all' => optional($goalteam)->no_of_post_sale_over_all ?? 0,
      'no_of_post_sale_check' => optional($goalteam)->no_of_post_sale_check ?? 0,
      'no_of_post_sale_type' => optional($goalteam)->no_of_post_sale_type ?? 0,
      'no_of_post_sale_actual' => $totals['referral_count'] ?? 0,

      'no_of_outstanding_over_all' => optional($goalteam)->no_of_outstanding_over_all ?? 0,
      'no_of_outstanding_check' => optional($goalteam)->no_of_outstanding_check ?? 0,
      'no_of_outstanding_type' => optional($goalteam)->no_of_outstanding_type ?? 0,
      'no_of_outstanding_actual' => $totals['outstanding_count'] ?? 0,

      'min_no_of_students_over_all' => optional($goalteam)->min_no_of_students_over_all ?? 0,
      'min_no_of_students_check' => optional($goalteam)->min_no_of_students_check ?? 0,
      'min_no_of_students_type' => optional($goalteam)->min_no_of_students_type ?? 0,
      'min_no_of_students_actual' => $totals['student_count'] ?? 0,

      'production_costing_over_all' => optional($goalteam)->production_costing_over_all ?? 0,
      'production_costing_check' => optional($goalteam)->production_costing_check ?? 0,
      'production_costing_type' => optional($goalteam)->production_costing_type ?? 0,
      'production_costing_actual' => $totals['production_costing'] ?? 0,

      'productions_over_all' => optional($goalteam)->productions_over_all ?? 0,
      'productions_check' => optional($goalteam)->productions_check ?? 0,
      'productions_type' => optional($goalteam)->productions_type ?? 0,
      'productions_actual' => $totals['productions_actual'] ?? 0,

      'no_of_reviews_over_all' => optional($goalteam)->no_of_reviews_over_all ?? 0,
      'no_of_reviews_check' => optional($goalteam)->no_of_reviews_check ?? 0,
      'no_of_reviews_type' => optional($goalteam)->no_of_reviews_type ?? 0,
      'no_of_reviews_actual' => $totals['review_count'] ?? 0,

      'no_of_placements_over_all' => optional($goalteam)->no_of_placements_over_all ?? 0,
      'no_of_placements_check' => optional($goalteam)->no_of_placements_check ?? 0,
      'no_of_placements_type' => optional($goalteam)->no_of_placements_type ?? 0,
      'no_of_placements_actual' => $totals['placement_count'] ?? 0,

      'mou_over_all' => optional($goalteam)->mou_over_all ?? 0,
      'mou_check' => optional($goalteam)->mou_check ?? 0,
      'mou_type' => optional($goalteam)->mou_type ?? 0,
      'mou_actual' => $totals['mou_count'] ?? 0,

      'reference_sales_over_all' => optional($goalteam)->reference_sales_over_all ?? 0,
      'reference_sales_check' => optional($goalteam)->reference_sales_check ?? 0,
      'reference_sales_type' => optional($goalteam)->reference_sales_type ?? 0,
      'reference_sales_actual' => $totals['referral_count'] ?? 0,

      'status' => optional($goalteam)->status == 1 ? true : false,
      'month' => $month_id
    ];
  }

  /**
   * Get empty team goal array
   */
  private function getEmptyTeamGoalArray($department, $goalteam, $month_id)
  {
    return [
      'department_name' => optional($department)->department_name ?? '',
      'department_id' => optional($department)->sno ?? '',
      'team_id' => optional($goalteam)->sno ?? '',
      'ten_x' => [],
      'status' => optional($goalteam)->status == 1 ? true : false,
      'month' => $month_id
    ];
  }
  public function getStaffGoal(Request $request)
  {
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $year = $request->year;

    // Optimize month conversion
    $month = $this->convertMonthToNumeric($month_id);
    $request->merge(['month_id' => $month]);

    // Get all needed data in fewer queries
    $staff = $this->getStaffWithDetails($branchId, $departmentId);

    if ($staff->isEmpty()) {
      return response()->json(['status' => 200, 'data' => []]);
    }

    $staffIds = $staff->pluck('sno')->toArray();

    // Get all goals in single query
    $goalsetRecords = GoalSetStaffModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('goal_month', $month)
      ->whereYear('goal_date', $year)
      ->get()
      ->keyBy('staff_id');

    $goalsetteam = GoalSetTeamModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('team_goal_month', $month)
      ->where('team_goal_year', $year)
      ->first();

    // Batch process all metrics
    $metrics = $this->batchProcessMetrics($staffIds, $branchId, $departmentId, $month, $year);

    // Process PC staff if needed
    $pcMetrics = [];
    if ($departmentId == 2 || $departmentId == 5) {
      $pcMetrics = $this->processPCStaffMetrics($branchId, $month, $year);
    }

    // Prepare staff details
    $staffDetails = [];
    foreach ($staff as $member) {
      $staffMetric = $metrics[$member->sno] ?? [];
      $goalData = $goalsetRecords[$member->sno] ?? null;

      $staffDetails[] = $this->buildStaffDetailArray(
        $member,
        $goalData,
        $goalsetteam,
        $staffMetric,
        $pcMetrics,
        $branchId,
        $departmentId,
        $month,
        $year
      );
    }

    return response()->json([
      'status' => 200,
      'data' => $staffDetails
    ]);
  }

  /**
   * Convert month name to numeric value
   */
  private function convertMonthToNumeric($month_id)
  {
    if (empty($month_id)) return null;

    if (!is_numeric($month_id)) {
      return (int) date('n', strtotime($month_id . ' 1'));
    }
    return (int) $month_id;
  }

  /**
   * Get staff with department and role details
   */
  private function getStaffWithDetails($branchId, $departmentId)
  {
    return StaffModel::where('za_staff.branch_id', $branchId)
      ->where('za_staff.department_id', $departmentId)
      ->where('za_staff.status', 0)
      ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
      ->join('za_user_role', 'za_staff.role_id', '=', 'za_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'za_staff.sno',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.avaiable_points',
        'za_staff.staff_image',
        'za_staff.basic_salary',
        'za_department.department_name',
        'za_user_role.role_name'
      ]);
  }

  /**
   * Batch process all metrics for staff members
   */
  private function batchProcessMetrics($staffIds, $branchId, $departmentId, $month, $year)
  {
    if (empty($staffIds)) return [];

    $metrics = [];
    $yearMonthCondition = function ($query) use ($year, $month) {
      $query->whereYear('registered_date', $year)->whereMonth('registered_date', $month);
    };

    // Get all leads in batch queries
    $allLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereNotIn('status', [2, 6])
      ->where('spam_verified', 0)
      ->where('drop_verified', 0)
      ->where('internal_status', 0)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $monthLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->whereNotIn('status', [2, 6])
      ->where('spam_verified', 0)
      ->where('drop_verified', 0)
      ->where('internal_status', 0)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $hotLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->whereNotIn('status', [2, 6])
      ->where('lead_status_id', 3)
      ->where('internal_status', 0)
      ->where('spam_verified', 0)
      ->where('drop_verified', 0)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    // Get converted customers
    $convertedCustomers = DB::table('za_customer')
      ->select('za_lead.created_by', DB::raw('COUNT(za_customer.sno) as count'))
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_lead.created_by', $staffIds)
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->groupBy('za_lead.created_by')
      ->get()
      ->keyBy('created_by');

    // Get spam and dead leads
    $spamLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->where('spam_verified', 1)
      ->where('status', 7)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    $deadLeads = DB::table('za_lead')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('registered_date', $year)
      ->whereMonth('registered_date', $month)
      ->where('drop_verified', 1)
      ->where('status', 5)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    // Get appointments and walk-ins
    $followups = DB::table('za_appointment')
      ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_lead.status', [0, 4])
      ->whereIn('za_appointment.created_by', $staffIds)
      ->whereYear('za_appointment.appointment_date', $year)
      ->whereMonth('za_appointment.appointment_date', $month)
      ->select('za_appointment.created_by', DB::raw('COUNT(*) as count'))
      ->groupBy('za_appointment.created_by')
      ->get()
      ->keyBy('created_by');

    $walkins = DB::table('za_lead_appointment')
      ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
      ->where('za_lead_appointment.appointment_category', 'walk-in')
      ->whereIn('za_lead_appointment.created_by', $staffIds)
      ->whereYear('za_lead_appointment.appointment_date', $year)
      ->whereMonth('za_lead_appointment.appointment_date', $month)
      ->select('za_lead_appointment.created_by', DB::raw('COUNT(*) as count'))
      ->groupBy('za_lead_appointment.created_by')
      ->get()
      ->keyBy('created_by');

    // Get call tracker data
    $callOuts = DB::table('za_call_tracker')
      ->select('branch_staff_id', DB::raw('COUNT(CASE WHEN call_status = 0 THEN 1 END) as count'))
      ->whereIn('branch_staff_id', $staffIds)
      ->where('branch_id', $branchId)
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->groupBy('branch_staff_id')
      ->get()
      ->keyBy('branch_staff_id');

    // Get training data for all staff
    $trainings = $this->getBatchTrainingMetrics($staffIds, $branchId, $month, $year);

    // Get referrals
    $referrals = DB::table('za_referral_persons')
      ->select('referral_id', DB::raw('COUNT(*) as count'))
      ->whereIn('referral_id', $staffIds)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->groupBy('referral_id')
      ->get()
      ->keyBy('referral_id');

    // Get reviews
    $reviews = DB::table('za_review')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    // Get placements and MOU
    $placements = DB::table('za_placement_interview')
      ->select('updated_by', DB::raw('COUNT(DISTINCT sno) as count'))
      ->whereIn('updated_by', $staffIds)
      ->where('status', 4)
      ->whereYear('selected_date', $year)
      ->whereMonth('selected_date', $month)
      ->groupBy('updated_by')
      ->get()
      ->keyBy('updated_by');

    $mouCounts = DB::table('za_placement_company')
      ->select('created_by', DB::raw('COUNT(*) as count'))
      ->whereIn('created_by', $staffIds)
      ->where('branch_id', $branchId)
      ->where('mou_status', 1)
      ->whereYear('mou_upload_date', $year)
      ->whereMonth('mou_upload_date', $month)
      ->groupBy('created_by')
      ->get()
      ->keyBy('created_by');

    // Get outstanding payments
    $dropIds = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->where('za_drop_refund.branch_id', $branchId)
      ->pluck('za_training.payment_id')
      ->toArray();

    $outstandings = DB::table('za_payment')
      ->select('za_payment.created_by', DB::raw('COUNT(*) as count'))  // Specify table prefix
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.created_by', $staffIds)  // Specify table prefix
      ->where('za_payment.branch_id', $branchId)     // Specify table prefix
      ->whereNotIn('za_payment.payment_id', $dropIds) // Specify table prefix
      ->where('za_payment.status', 0)                // Specify table prefix
      ->where('za_payment.amount', '>', 0)           // Specify table prefix
      ->whereIn('za_customer.status', [0, 6])
      ->whereMonth('za_payment.nextPayDate', $month) // Specify table prefix
      ->whereYear('za_payment.nextPayDate', $year)   // Specify table prefix
      ->groupBy('za_payment.created_by')             // Specify table prefix
      ->get()
      ->keyBy('created_by');

    // Get HAC amount
    $hacAmounts = $this->getHACAmounts($branchId, $year, $month);

    // Compile metrics for each staff
    foreach ($staffIds as $staffId) {
      $monthLeadCount = $monthLeads[$staffId]->count ?? 0;
      $allLeadCount = $allLeads[$staffId]->count ?? 0;
      $customerCount = $convertedCustomers[$staffId]->count ?? 0;
      $spamCount = $spamLeads[$staffId]->count ?? 0;
      $deadCount = $deadLeads[$staffId]->count ?? 0;

      $metrics[$staffId] = [
        'all_lead_count' => $allLeadCount,
        'month_lead_count' => $monthLeadCount,
        'hot_lead_count' => $hotLeads[$staffId]->count ?? 0,
        'customer_count' => $customerCount,
        'spam_count' => $spamCount,
        'dead_count' => $deadCount,
        'spam_ratio' => $monthLeadCount > 0 ? number_format(($spamCount / $monthLeadCount) * 100, 2) : 0,
        'dead_ratio' => $monthLeadCount > 0 ? number_format(($deadCount / $monthLeadCount) * 100, 2) : 0,
        'conversion_rate' => $allLeadCount > 0 ? number_format(($customerCount / $allLeadCount) * 100, 2) : 0,
        'avg_conversion_rate' => $monthLeadCount > 0 ? number_format(($customerCount / $monthLeadCount) * 100, 2) : 0,
        'followup_count' => $followups[$staffId]->count ?? 0,
        'walkin_count' => $walkins[$staffId]->count ?? 0,
        'call_out_count' => $callOuts[$staffId]->count ?? 0,
        'training_metrics' => $trainings[$staffId] ?? null,
        'referral_count' => $referrals[$staffId]->count ?? 0,
        'review_count' => $reviews[$staffId]->count ?? 0,
        'placement_count' => $placements[$staffId]->count ?? 0,
        'mou_count' => $mouCounts[$staffId]->count ?? 0,
        'outstanding_count' => $outstandings[$staffId]->count ?? 0,
        'hac_amount' => $hacAmounts[$staffId] ?? 0,
        'business_value' => 0,
        'collection_value' => 0,
      ];

      // Calculate business and collection values for converted customers
      if ($customerCount > 0) {
        $paymentMetrics = $this->getCustomerPaymentMetrics($staffId, $branchId, $year, $month);
        $metrics[$staffId]['business_value'] = $paymentMetrics['business_value'];
        $metrics[$staffId]['collection_value'] = $paymentMetrics['collection_value'];
        $metrics[$staffId]['total_payment'] = $paymentMetrics['total_payment'];
        $metrics[$staffId]['total_paid_payment'] = $paymentMetrics['total_paid_payment'];
      }
    }

    return $metrics;
  }

  /**
   * Get batch training metrics for staff
   */
  private function getBatchTrainingMetrics($staffIds, $branchId, $month, $year)
  {
    $metrics = [];
    foreach ($staffIds as $staffId) {
      $metrics[$staffId] = [
        'student_count' => 0,
        'course_count' => 0,
        'batch_count' => 0,
        'earned_amount' => 0,
      ];
    }

    // Get staff basic salaries for per_hr_cost calculation
    $staffSalaries = DB::table('za_staff')
      ->whereIn('sno', $staffIds)
      ->where('branch_id', $branchId)
      ->pluck('basic_salary', 'sno');

    // Get trainings with active batches
    $trainings = DB::table('za_training')
      ->select('za_training.staff_id', 'za_training.batch_id', 'za_training.customer_id', 'za_training.course_id')
      ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.branch_id', $branchId)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('za_training.start_date', '<=', $month)
          ->whereYear('za_training.start_date', '<=', $year)
          ->whereMonth('za_training.end_date', '>=', $month)
          ->whereYear('za_training.end_date', '>=', $year);
      })
      ->get();

    if ($trainings->isEmpty()) {
      return $metrics;
    }

    // Get distinct counts using separate queries with proper table prefixes
    $studentCounts = DB::table('za_training')
      ->select('za_training.staff_id', DB::raw('COUNT(DISTINCT za_training.customer_id) as student_count'))
      ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.branch_id', $branchId)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('za_training.start_date', '<=', $month)
          ->whereYear('za_training.start_date', '<=', $year)
          ->whereMonth('za_training.end_date', '>=', $month)
          ->whereYear('za_training.end_date', '>=', $year);
      })
      ->groupBy('za_training.staff_id')
      ->get()
      ->keyBy('staff_id');

    $courseCounts = DB::table('za_training')
      ->select('za_training.staff_id', DB::raw('COUNT(DISTINCT za_training.course_id) as course_count'))
      ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.branch_id', $branchId)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('za_training.start_date', '<=', $month)
          ->whereYear('za_training.start_date', '<=', $year)
          ->whereMonth('za_training.end_date', '>=', $month)
          ->whereYear('za_training.end_date', '>=', $year);
      })
      ->groupBy('za_training.staff_id')
      ->get()
      ->keyBy('staff_id');

    $batchCounts = DB::table('za_training')
      ->select('za_training.staff_id', DB::raw('COUNT(DISTINCT za_training.batch_id) as batch_count'))
      ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->whereIn('za_training.staff_id', $staffIds)
      ->where('za_training.branch_id', $branchId)
      ->where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('za_training.start_date', '<=', $month)
          ->whereYear('za_training.start_date', '<=', $year)
          ->whereMonth('za_training.end_date', '>=', $month)
          ->whereYear('za_training.end_date', '>=', $year);
      })
      ->groupBy('za_training.staff_id')
      ->get()
      ->keyBy('staff_id');

    // Update metrics with distinct counts
    foreach ($staffIds as $staffId) {
      if (isset($studentCounts[$staffId])) {
        $metrics[$staffId]['student_count'] = $studentCounts[$staffId]->student_count;
      }
      if (isset($courseCounts[$staffId])) {
        $metrics[$staffId]['course_count'] = $courseCounts[$staffId]->course_count;
      }
      if (isset($batchCounts[$staffId])) {
        $metrics[$staffId]['batch_count'] = $batchCounts[$staffId]->batch_count;
      }
    }

    // Calculate earned amounts from attendance
    $batchIds = $trainings->pluck('batch_id')->unique()->toArray();

    if (!empty($batchIds)) {
      $batches = DB::table('za_batch')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->whereIn('za_batch.sno', $batchIds)
        ->where('za_batch.status', 0)
        ->select('za_batch.sno', 'za_slot.start_time', 'za_slot.end_time')
        ->get()
        ->keyBy('sno');

      $attendances = DB::table('za_attendance')
        ->select('za_attendance.batch_id', 'za_attendance.staff_id', 'za_attendance.per_hr_cost')
        ->whereIn('za_attendance.batch_id', $batchIds)
        ->whereIn('za_attendance.staff_id', $staffIds)
        ->where('za_attendance.attendance', 'P')
        ->whereMonth('za_attendance.att_date', $month)
        ->whereYear('za_attendance.att_date', $year)
        ->get();

      foreach ($attendances as $attendance) {
        $batch = $batches[$attendance->batch_id] ?? null;
        if ($batch && $batch->start_time && $batch->end_time) {
          $startTime = Carbon::parse($batch->start_time);
          $endTime = Carbon::parse($batch->end_time);
          $duration = $startTime->diffInMinutes($endTime) / 60;
          $metrics[$attendance->staff_id]['earned_amount'] += ($attendance->per_hr_cost * $duration);
        }
      }
    }

    return $metrics;
  }

  /**
   * Calculate batch duration in hours
   */
  private function calculateBatchDuration($batch)
  {
    $startTime = Carbon::parse($batch->start_time);
    $endTime = Carbon::parse($batch->end_time);
    return $startTime->diffInMinutes($endTime) / 60;
  }

  /**
   * Get customer payment metrics
   */
  private function getCustomerPaymentMetrics($staffId, $branchId, $year, $month)
  {
    $customers = CustomerModel::whereIn('za_customer.status', [0, 6])  // Specify table
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->pluck('za_customer.sno');  // Specify table

    $totalPayment = 0;
    $totalPaidPayment = 0;

    if ($customers->isEmpty()) {
      return [
        'business_value' => 0,
        'collection_value' => 0,
        'total_payment' => 0,
        'total_paid_payment' => 0,
      ];
    }

    // Get training fees
    $trainingResults = DB::table('za_training')
      ->select(
        'customer_id',
        DB::raw('SUM(CASE WHEN tesbo_check = 0 THEN overall_fees ELSE 0 END) as training_fees'),
        DB::raw('SUM(paid_amount) as paid_amount')
      )
      ->whereIn('customer_id', $customers)
      ->groupBy('customer_id')
      ->get();

    foreach ($trainingResults as $result) {
      $totalPayment += $result->training_fees;
      $totalPaidPayment += $result->paid_amount;
    }

    // Check for latest training with tesbo_check = 2
    $latestTrainings = DB::table('za_training')
      ->select('customer_id', 'overall_fees')
      ->whereIn('customer_id', $customers)
      ->where('tesbo_check', 2)
      ->orderByDesc('sno')
      ->get()
      ->groupBy('customer_id');

    foreach ($latestTrainings as $customerId => $trainings) {
      $totalPayment += $trainings->first()->overall_fees;
    }

    $customerCount = $customers->count();

    return [
      'business_value' => $customerCount > 0 ? $totalPayment / $customerCount : 0,
      'collection_value' => $customerCount > 0 ? $totalPaidPayment / $customerCount : 0,
      'total_payment' => $totalPayment,
      'total_paid_payment' => $totalPaidPayment,
    ];
  }

  /**
   * Get HAC amounts for staff
   */
  private function getHACAmounts($branchId, $year, $month)
  {
    $current = Carbon::create($year, $month, 1);
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth();

    $dropoutCustomers = DB::table('za_training')
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    $prevMonthCustomers = CustomerModel::select('za_customer.sno', 'za_lead.created_by')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->get();

    $hacAmounts = [];
    foreach ($prevMonthCustomers as $customer) {
      $amount = DB::table('za_payment')
        ->where('customer_id', $customer->sno)
        ->where('status', 1)
        ->whereYear('initialPayDate', $year)
        ->whereMonth('initialPayDate', $month)
        ->where('branch_id', $branchId)
        ->sum('paidAmount');

      if ($amount > 0) {
        $hacAmounts[$customer->created_by] = ($hacAmounts[$customer->created_by] ?? 0) + $amount;
      }
    }

    return $hacAmounts;
  }

  /**
   * Process PC staff metrics
   */
  private function processPCStaffMetrics($branchId, $month, $year)
  {
    $pcStaff = StaffModel::where('branch_id', $branchId)
      ->where('department_id', 2)
      ->where('status', 0)
      ->pluck('sno');

    $totalCostingAmount = 0;
    $totalBasicPay = 0;
    $totalReferralCount = 0;

    foreach ($pcStaff as $staffId) {
      $metrics = $this->getStaffProductionMetrics($staffId, $branchId, $month, $year);
      $totalCostingAmount += $metrics['earned_amount'];
      $totalBasicPay += $metrics['basic_salary'] * 10;

      $referralCount = DB::table('za_referral_persons')
        ->where('branch_id', $branchId)
        ->where('referral_id', $staffId)
        ->where('status', 0)
        ->where('referral_type', 2)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      $totalReferralCount += $referralCount;
    }

    return [
      'total_costing' => $totalCostingAmount,
      'total_basic_pay' => $totalBasicPay,
      'total_referral' => $totalReferralCount,
    ];
  }

  /**
   * Get staff production metrics
   */
  private function getStaffProductionMetrics($staffId, $branchId, $month, $year)
  {
    $staff = StaffModel::select('basic_salary', 'sno')
      ->where('sno', $staffId)
      ->where('branch_id', $branchId)
      ->first();

    if (!$staff) {
      return ['earned_amount' => 0, 'basic_salary' => 0];
    }

    $earnedAmount = 0;

    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $staffId)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct()
      ->pluck('batch_id');

    if ($batchIds->isEmpty()) {
      return ['earned_amount' => 0, 'basic_salary' => $staff->basic_salary ?? 0];
    }

    $batches = BatchModel::with('slot')
      ->whereIn('sno', $batchIds)
      ->where('status', 0)
      ->get()
      ->keyBy('sno');

    $attendances = AttendanceModel::whereIn('batch_id', $batchIds)
      ->where('staff_id', $staffId)
      ->where('attendance', 'P')
      ->whereMonth('att_date', $month)
      ->whereYear('att_date', $year)
      ->get();

    $perHrCost = ($staff->basic_salary ?? 0) / (30 * 8);

    foreach ($attendances as $attendance) {
      $batch = $batches[$attendance->batch_id] ?? null;
      if ($batch) {
        $duration = $this->calculateBatchDuration($batch);
        $earnedAmount += $perHrCost * $duration;
      }
    }

    return [
      'earned_amount' => $earnedAmount,
      'basic_salary' => $staff->basic_salary ?? 0,
    ];
  }
  /**
   * Build staff detail array
   */
  private function buildStaffDetailArray($member, $goalData, $goalsetteam, $staffMetric, $pcMetrics, $branchId, $departmentId, $month, $year)
  {
    // Get actual values (from metrics or goal overrides)
    $actualValues = $this->getActualValues($member, $goalData, $staffMetric, $pcMetrics, $branchId, $departmentId, $month, $year);

    // Calculate day-based averages
    $dayCount = $this->calculateWorkingDaysCount($year, $month);
    $avgCallOut = $dayCount > 0 ? round(($actualValues['call_out_count'] ?? 0) / $dayCount) : 0;
    $avgWalkin = $dayCount > 0 ? round(($actualValues['walkin_count'] ?? 0) / $dayCount) : 0;
    $avgFollowup = $dayCount > 0 ? round(($actualValues['followup_count'] ?? 0) / $dayCount) : 0;

    // Get goal values
    $goalValues = $this->getGoalValues($goalData);

    // Check if goal completed (override)
    if ($goalData && $goalData->goal_completed == 1) {
      $actualValues = $this->overrideWithGoalActuals($goalData, $actualValues);
      $costingAmount = $goalData->production_costing_actual ?? 0;
      $productionAmount = $goalData->productions_actual ?? 0;
    }

    // Calculate costing
    $basicPay = ($member->basic_salary > 0) ? ($member->basic_salary * 10) : 0;
    $costingAmount = $this->calculateCostingAmount(
      $actualValues['earned_amount'] ?? 0,
      $basicPay,
      $goalData->production_costing ?? 0
    );

    $productionAmount = $this->calculateProductionAmount(
      $pcMetrics['total_costing'] ?? 0,
      $pcMetrics['total_basic_pay'] ?? 0,
      $goalData->productions ?? 0
    );

    // Calculate attendance and score
    $attendanceMetrics = $this->getAttendanceMetrics($member->sno, $branchId, $year, $month);
    $goalProgress = $this->getGoalProgress($member->sno, $departmentId, $month, $year, $branchId);
    $heartImage = $this->getHeartImage($attendanceMetrics['present_percentage']);
    $trustScore = $this->getTrustScore($member->sno, $branchId, $year, $month, $departmentId);

    $scoreTd = $this->buildScoreTD($heartImage, $goalProgress, $trustScore, $member->avaiable_points);

    // Check ten X achievements
    $tenX = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $goalAchievements = $this->checkTenXAchievements($tenX, $goalValues, $actualValues);

    return [
      'sno' => $member->sno,
      'staff_name' => $member->staff_name,
      'ten_x' => $tenX,
      'goal_achievements' => $goalAchievements,
      'nick_name' => $member->nick_name,
      'gender' => $member->gender,
      'staff_image' => $member->staff_image,
      'department_name' => $member->department_name,
      'role_name' => $member->role_name,
      'team_id' => $goalData->team_id ?? 0,
      'status' => $goalData ? ($goalData->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
      'month' => $month,
      'goal_completed' => $goalData->goal_completed ?? 0,
      'score_td' => $scoreTd,

      // Dynamic goal fields
      'conversion_check' => $goalsetteam->conversion_check ?? 0,
      'conversion' => $goalData->conversion ?? 0,
      'conversion_actual' => $actualValues['customer_count'] ?? 0,

      'cr_check' => $goalsetteam->cr_check ?? 0,
      'cr' => $goalData->CR ?? 0,
      'cr_actual' => $actualValues['conversion_rate'] ?? 0,

      'abv_check' => $goalsetteam->abv_check ?? 0,
      'abv' => $goalData->ABV ?? 0,
      'abv_actual' => $actualValues['business_value'] ?? 0,

      'acv_check' => $goalsetteam->acv_check ?? 0,
      'acv' => $goalData->ACV ?? 0,
      'acv_actual' => $actualValues['collection_value'] ?? 0,

      'avg_call_out_check' => $goalsetteam->avg_call_out_check ?? 0,
      'avg_call_out' => $goalData->avg_call_out ?? 0,
      'avg_call_out_actual' => $avgCallOut,

      'no_of_walk_check' => $goalsetteam->no_of_walk_check ?? 0,
      'no_of_walk' => $goalData->no_of_walk ?? 0,
      'no_of_walk_actual' => $avgWalkin,

      'no_of_followup_check' => $goalsetteam->no_of_followup_check ?? 0,
      'no_of_followup' => $goalData->no_of_followup ?? 0,
      'no_of_followup_actual' => $avgFollowup,

      'min_no_of_students_check' => $goalsetteam->min_no_of_students_check ?? 0,
      'min_no_of_students' => $goalData->min_no_of_students ?? 0,
      'min_no_of_students_actual' => $actualValues['student_count'] ?? 0,

      'production_costing_check' => $goalsetteam->production_costing_check ?? 0,
      'production_costing' => $goalData->production_costing ?? 0,
      'production_costing_actual' => $costingAmount,

      'no_of_reviews_check' => $goalsetteam->no_of_reviews_check ?? 0,
      'no_of_reviews' => $goalData->no_of_reviews ?? 0,
      'no_of_reviews_actual' => $actualValues['review_count'] ?? 0,

      'no_of_placements_check' => $goalsetteam->no_of_placements_check ?? 0,
      'no_of_placements' => $goalData->no_of_placements ?? 0,
      'no_of_placements_actual' => $actualValues['placement_count'] ?? 0,

      'mou_check' => $goalsetteam->mou_check ?? 0,
      'mou' => $goalData->mou ?? 0,
      'mou_actual' => $actualValues['mou_count'] ?? 0,

      'productions_check' => $goalsetteam->productions_check ?? 0,
      'productions' => $goalData->productions ?? 0,
      'productions_actual' => $productionAmount,

      'hac_check' => $goalsetteam->hac_check ?? 0,
      'hac' => $goalData->hac ?? 0,
      'hac_actual' => $actualValues['hac_amount'] ?? 0,

      'no_of_post_sale_check' => $goalsetteam->no_of_post_sale_check ?? 0,
      'no_of_post_sale' => $goalData->no_of_post_sale ?? 0,
      'no_of_post_sale_actual' => $actualValues['referral_count'] ?? 0,

      'no_of_outstanding_check' => $goalsetteam->no_of_outstanding_check ?? 0,
      'no_of_outstanding' => $goalData->no_of_outstanding ?? 0,
      'no_of_outstanding_actual' => $actualValues['outstanding_count'] ?? 0,

      'reference_sales_check' => $goalsetteam->reference_sales_check ?? 0,
      'reference_sales' => $goalData->reference_sales ?? 0,
      'reference_sales_actual' => $actualValues['referral_count'] ?? 0,

      'sales_lead_checks' => $goalData->sales_lead_check ?? 0,
    ];
  }

  /**
   * Get actual values from metrics or defaults
   */
  private function getActualValues($member, $goalData, $staffMetric, $pcMetrics, $branchId, $departmentId, $month, $year)
  {
    return [
      'customer_count' => $staffMetric['customer_count'] ?? 0,
      'conversion_rate' => $staffMetric['conversion_rate'] ?? 0,
      'business_value' => $staffMetric['business_value'] ?? 0,
      'collection_value' => $staffMetric['collection_value'] ?? 0,
      'call_out_count' => $staffMetric['call_out_count'] ?? 0,
      'walkin_count' => $staffMetric['walkin_count'] ?? 0,
      'followup_count' => $staffMetric['followup_count'] ?? 0,
      'student_count' => $staffMetric['training_metrics']['student_count'] ?? 0,
      'earned_amount' => $staffMetric['training_metrics']['earned_amount'] ?? 0,
      'review_count' => ($departmentId == 5 ? ($pcMetrics['total_referral'] ?? 0) : ($staffMetric['review_count'] ?? 0)),
      'placement_count' => $staffMetric['placement_count'] ?? 0,
      'mou_count' => $staffMetric['mou_count'] ?? 0,
      'hac_amount' => $staffMetric['hac_amount'] ?? 0,
      'referral_count' => $staffMetric['referral_count'] ?? 0,
      'outstanding_count' => $staffMetric['outstanding_count'] ?? 0,
    ];
  }

  /**
   * Get goal values from goal data
   */
  private function getGoalValues($goalData)
  {
    return [
      'conversion' => $goalData->conversion ?? 0,
      'cr' => $goalData->CR ?? 0,
      'abv' => $goalData->ABV ?? 0,
      'acv' => $goalData->ACV ?? 0,
      'avg_call_out' => $goalData->avg_call_out ?? 0,
      'no_of_walk' => $goalData->no_of_walk ?? 0,
      'no_of_followup' => $goalData->no_of_followup ?? 0,
      'min_no_of_students' => $goalData->min_no_of_students ?? 0,
      'production_costing' => $goalData->production_costing ?? 0,
      'no_of_reviews' => $goalData->no_of_reviews ?? 0,
      'no_of_placements' => $goalData->no_of_placements ?? 0,
      'mou' => $goalData->mou ?? 0,
      'productions' => $goalData->productions ?? 0,
      'hac' => $goalData->hac ?? 0,
      'no_of_post_sale' => $goalData->no_of_post_sale ?? 0,
      'no_of_outstanding' => $goalData->no_of_outstanding ?? 0,
      'reference_sales' => $goalData->reference_sales ?? 0,
    ];
  }

  /**
   * Override values with goal actuals when goal is completed
   */
  private function overrideWithGoalActuals($goalData, $actualValues)
  {
    $overrides = [
      'customer_count' => 'conversion_actual',
      'conversion_rate' => 'CR_actual',
      'business_value' => 'ABV_actual',
      'collection_value' => 'ACV_actual',
      'call_out_count' => 'avg_call_out_actual',
      'walkin_count' => 'no_of_walk_actual',
      'followup_count' => 'no_of_followup_actual',
      'student_count' => 'min_no_of_students_actual',
      'earned_amount' => 'production_costing_actual',
      'review_count' => 'no_of_reviews_actual',
      'placement_count' => 'no_of_placements_actual',
      'mou_count' => 'mou_actual',
      'production_amount' => 'productions_actual',
      'hac_amount' => 'hac_actual',
      'referral_count' => 'reference_sales_actual',
      'outstanding_count' => 'no_of_outstanding_actual',
    ];

    foreach ($overrides as $key => $field) {
      if (isset($goalData->$field)) {
        $actualValues[$key] = $goalData->$field;
      }
    }

    return $actualValues;
  }

  /**
   * Calculate costing amount
   */
  private function calculateCostingAmount($earnedAmount, $basicPay, $costingAssign)
  {
    if ($basicPay <= 0 || $costingAssign <= 0) {
      return 0;
    }
    return ($earnedAmount / $basicPay) * $costingAssign;
  }

  /**
   * Calculate production amount
   */
  private function calculateProductionAmount($totalCosting, $totalBasicPay, $productionsAssign)
  {
    if ($totalBasicPay <= 0 || $productionsAssign <= 0) {
      return 0;
    }
    return ($totalCosting / $totalBasicPay) * $productionsAssign;
  }

  /**
   * Calculate working days count (excluding Sundays)
   */
  private function calculateWorkingDaysCount($year, $month)
  {
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
      ? $currentDate
      : $startDate->copy()->endOfMonth();

    $dayCount = 0;
    $dateIter = $startDate->copy();

    while ($dateIter->lte($endDate)) {
      if (!$dateIter->isSunday()) {
        $dayCount++;
      }
      $dateIter->addDay();
    }

    return $dayCount;
  }

  /**
   * Get attendance metrics for staff
   */
  private function getAttendanceMetrics($staffId, $branchId, $year, $month)
  {
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
      ? $currentDate
      : $startDate->copy()->endOfMonth();

    $totalWorkingDays = 0;
    $dateIter = $startDate->copy();

    while ($dateIter->lte($endDate)) {
      if (!$dateIter->isSunday()) {
        $totalWorkingDays++;
      }
      $dateIter->addDay();
    }

    $presentDays = StaffAttendanceModel::where('staff_id', $staffId)
      ->where('branch_id', $branchId)
      ->whereIn('attendance', ['P', 'HD'])
      ->whereMonth('date', $month)
      ->whereYear('date', $year)
      ->count();

    $percentage = $totalWorkingDays > 0 ? round(($presentDays / $totalWorkingDays) * 100) : 0;

    return [
      'present_days' => $presentDays,
      'total_days' => $totalWorkingDays,
      'present_percentage' => $percentage,
    ];
  }

  /**
   * Get heart image based on attendance percentage
   */
  private function getHeartImage($percentage)
  {
    if ($percentage == 0) {
      $file = 'h_0.png';
    } elseif ($percentage < 50) {
      $file = 'h_25.png';
    } elseif ($percentage < 75) {
      $file = 'h_50.png';
    } elseif ($percentage < 100) {
      $file = 'h_75.png';
    } else {
      $file = 'h_100.png';
    }

    return '<img src="' . asset('assets/eapl_images/staff_rate/' . $file) . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
  }

  /**
   * Get goal progress
   */
  private function getGoalProgress($staffId, $departmentId, $month, $year, $branchId)
  {
    $helper = new \App\Helpers\Helpers();
    return $helper->getStaffGoal_progress_bar($staffId, $departmentId, $month, $year, $branchId) ?? 0;
  }

  /**
   * Get trust score for sales department
   */
  private function getTrustScore($staffId, $branchId, $year, $month, $departmentId)
  {
    if ($departmentId != 1) {
      return ['badge' => '', 'score' => '00'];
    }

    $promiseCount = DB::table('za_sales_promise')
      ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
      ->where('za_staff.department_id', 1)
      ->where('za_sales_promise.branch_id', $branchId)
      ->whereYear('za_sales_promise.promise_date', $year)
      ->whereMonth('za_sales_promise.promise_date', $month)
      ->where('za_staff.sno', $staffId)
      ->sum('za_sales_promise.promise_count');

    $successCount = DB::table('za_sales_promise')
      ->join('za_staff', 'za_staff.sno', '=', 'za_sales_promise.staff_id')
      ->where('za_staff.department_id', 1)
      ->where('za_sales_promise.branch_id', $branchId)
      ->whereYear('za_sales_promise.promise_date', $year)
      ->whereMonth('za_sales_promise.promise_date', $month)
      ->where('za_sales_promise.status', 1)
      ->where('za_staff.sno', $staffId)
      ->sum('za_sales_promise.promise_count');

    if ($promiseCount > 0) {
      $rawScore = ($successCount / $promiseCount) * 10;
      $score = min(round($rawScore), 10);
      $formattedScore = str_pad($score, 2, '0', STR_PAD_LEFT);

      $badgeColor = 'bg-danger';
      if ($score >= 5 && $score <= 8) {
        $badgeColor = 'bg-warning';
      } elseif ($score >= 9) {
        $badgeColor = 'bg-success';
      }

      return [
        'badge' => '<label class="badge ' . $badgeColor . ' fw-semibold fs-8">' . $formattedScore . '</label>',
        'score' => $formattedScore
      ];
    }

    return ['badge' => '<label class="badge bg-danger fw-semibold fs-8">00</label>', 'score' => '00'];
  }

  /**
   * Build score TD HTML
   */
  private function buildScoreTD($heartImage, $goalProgress, $trustScore, $availablePoints)
  {
    $color = '#FF3B30'; // Red
    if ($goalProgress >= 80) {
      $color = '#34C759'; // Green
    } elseif ($goalProgress >= 40) {
      $color = '#FFCC00'; // Yellow
    } elseif ($goalProgress > 100) {
      $color = '#7854c7'; // Purple
    }

    $pointsFormatted = sprintf('%02d', $availablePoints ?? 0);

    return '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
        <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">
            ' . $heartImage . '
            <div class="fs-8 fw-semibold text-center text-black">' . $goalProgress . '%</div>
        </div>
        <div class="cursor-pointer">
            <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                <div class="progress-bar progress-bar-striped progress-bar-animated"
                     role="progressbar"
                     style="width: ' . $goalProgress . '%; background: ' . $color . ';"
                     aria-valuenow="' . $goalProgress . '" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="fs-8 fw-semibold text-center text-black">' . $goalProgress . '%</div>
        </div>
        <div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
            <div class="fs-8 fw-semibold text-dark">TS</div>
            <div class="fs-8 fw-semibold text-black">' . $trustScore['badge'] . '</div>
        </div>
        <div class="mb-0 text-center">
            <div class="fs-8 fw-semibold text-dark">Points</div>
            <div class="fs-8 fw-semibold text-black">
                <label class="badge bg-danger fw-semibold fs-8">' . $pointsFormatted . '</label>
            </div>
        </div>
    </div>';
  }

  /**
   * Check if all ten X goals are achieved
   */
    private function checkTenXAchievements($tenX, $goalValues, $actualValues)
  {
    if (empty($tenX)) {
      return false;
    }
 
    foreach ($tenX as $key => $value) {
      if ($value === "1") {
        $type2 = str_replace("_10x", "", $key);
        $goalValue = $goalValues[$type2] ?? 0;
        $actualValue = $actualValues[$type2] ?? 0;
 
        if ($goalValue > 0) {
          if ($actualValue < $goalValue) {
            return false; // Not achieved
          }
        } else {
          return false; // Invalid goal
        }
      }
    }
 
    return true; // All achieved
  }
  
//   private function checkTenXAchievements($tenX, $goalValues, $actualValues)
//   {
//     if (empty($tenX)) {
//       return false;
//     }

//     foreach ($tenX as $key => $value) {
//       if ($value === "1") {
//         $type2 = str_replace("_10x", "", $key);
//         $goalValue = $goalValues[$type2] ?? 0;
//         $actualValue = $actualValues[$type2] ?? 0;

//         if ($goalValue > 0) {
//           if ($actualValue < $goalValue) {
//             return true; // Not achieved
//           }
//         } else {
//           return true; // Invalid goal
//         }
//       }
//     }

//     return false; // All achieved
//   }




  // public function saveTeamGoal(Request $request)
  // {
  //     // Validate incoming data
  //     $validatedData = $request->validate([
  //         'conversion_over_all'=> 'nullable|numeric',
  //         'conversion_check'=> 'nullable|numeric',
  //         'conversion_type'=> 'nullable|numeric',
  //         'cr_over_all'             => 'nullable|numeric',
  //         'cr_check'                => 'nullable|numeric',
  //         'cr_type'                 => 'nullable|numeric',
  //         'abv_over_all'            => 'nullable|numeric',
  //         'abv_check'               => 'nullable|numeric',
  //         'abv_type'                => 'nullable|numeric',
  //         'acv_over_all'            => 'nullable|numeric',
  //         'acv_type'                => 'nullable|numeric',
  //         'acv_check'               => 'nullable|numeric',
  //         'avg_call_out_over_all'   => 'nullable|numeric',
  //         'avg_call_out_check'      => 'nullable|numeric',
  //         'avg_call_out_type'       => 'nullable|numeric',
  //         'no_of_walk_over_all'     => 'nullable|numeric',
  //         'no_of_walk_check'        => 'nullable|numeric',
  //         'no_of_walk_type'         => 'nullable|numeric',
  //         'no_of_followup_over_all' => 'nullable|numeric',
  //         'no_of_followup_check'    => 'nullable|numeric',
  //         'no_of_followup_type'      => 'nullable|numeric',
  //         'hac_over_all'           => 'nullable|numeric',
  //         'hac_check'              => 'nullable|numeric',
  //         'hac_type'                 => 'nullable|numeric',
  //         'no_of_post_sale_over_all' => 'nullable|numeric',
  //         'no_of_post_sale_check' => 'nullable|numeric',
  //         'no_of_post_sale_type'   => 'nullable|numeric',
  //         'no_of_outstanding_over_all' => 'nullable|numeric',
  //         'no_of_outstanding_check' => 'nullable|numeric',
  //         'no_of_outstanding_type' => 'nullable|numeric',
  //         'min_no_of_students_over_all' => 'nullable|numeric',
  //         'min_no_of_students_check' => 'nullable|numeric',
  //         'min_no_of_students_type'   => 'nullable|numeric',
  //         'production_costing_over_all' => 'nullable|numeric',
  //         'production_costing_check'  => 'nullable|numeric',
  //         'production_costing_type'  => 'nullable|numeric',
  //         'productions_over_all'  => 'nullable|numeric',
  //         'productions_check'     => 'nullable|numeric',
  //         'productions_type'      => 'nullable|numeric',
  //         'no_of_reviews_over_all' => 'nullable|numeric',
  //         'no_of_reviews_check'   => 'nullable|numeric',
  //         'no_of_reviews_type'     => 'nullable|numeric',
  //         'given_links_over_all'   => 'nullable|numeric',
  //         'given_links_check'     => 'nullable|numeric',
  //         'given_links_type'      => 'nullable|numeric',
  //         'no_of_placements_over_all' => 'nullable|numeric',
  //         'no_of_placements_check'  => 'nullable|numeric',
  //         'no_of_placements_type'  => 'nullable|numeric',
  //         'mou_over_all'          => 'nullable|numeric',
  //         'mou_check'             => 'nullable|numeric',
  //         'mou_type'              => 'nullable|numeric',
  //         'reference_sales_over_all' => 'nullable|numeric',
  //         'reference_sales_check' => 'nullable|numeric',
  //         'reference_sales_type'   => 'nullable|numeric',
  //     ]);

  //     $branchId = $request->user()->branch_id;
  //     $departmentId = $request->department_id;
  //     $month_id = $request->month_id;
  //     $createdBy = $request->user()->user_id;
  //      return $request->all();
  //     if (!empty($month_id)) {
  //         if (!is_numeric($month_id)) {
  //             // Convert month name (e.g., "February") to its numeric value
  //             $monthNumber = date('m', strtotime($month_id . ' 1'));
  //             $request->merge(['month_id' => (int)$monthNumber]);
  //         } else {
  //             // Ensure month_id is an integer if it's already numeric
  //             $request->merge(['month_id' => (int)$month_id]);
  //         }
  //     }

  //     // Update or create the goal record
  //     $goal = GoalSetTeamModel::updateOrCreate(
  //         [
  //             'team_goal_month' => $request->month_id,
  //             'branch_id'       => $branchId,
  //             'department_id'   => $departmentId,
  //         ],
  //         [
  //             'cr_over_all'            => $validatedData['cr_over_all'] ?? 0,
  //             'cr_check'               => $validatedData['cr_check'] ?? null,
  //             'cr_type'                => $validatedData['cr_type'] ?? null,
  //             'abv_over_all'           => $validatedData['abv_over_all'] ?? 0,
  //             'abv_check'              => $validatedData['abv_check'] ?? null,
  //             'abv_type'               => $validatedData['abv_type'] ?? null,
  //             'acv_over_all'           => $validatedData['acv_over_all'] ?? 0,
  //             'acv_type'               => $validatedData['acv_type'] ?? null,
  //             'acv_check'              => $validatedData['acv_check'] ?? null,
  //             'avg_call_out_over_all'  => $validatedData['avg_call_out_over_all'] ?? 0,
  //             'avg_call_out_check'     => $validatedData['avg_call_out_check'] ?? null,
  //             'avg_call_out_type'      => $validatedData['avg_call_out_type'] ?? null,
  //             'no_of_walk_over_all'    => $validatedData['no_of_walk_over_all'] ?? 0,
  //             'no_of_walk_check'       => $validatedData['no_of_walk_check'] ?? null,
  //             'no_of_walk_type'        => $validatedData['no_of_walk_type'] ?? null,
  //             'created_by'             => $createdBy,
  //             'updated_by'             => $createdBy,
  //             'status'                 => 1 // Mark as 'Goal Set'
  //         ]
  //     );

  //     return response()->json([
  //         'status' => 200,
  //         'message' => 'Team goal successfully updated!',
  //         'data' => $goal
  //     ]);
  // }

  public function saveTeamGoal(Request $request)
  {
    // Validate incoming data
    $validatedData = $request->validate([
      'department_id' => 'required|numeric',
      'month_id'      => 'required',
      'year_id'      => 'required',
      'branch_id'      => 'required',
      'conversion_over_all' => 'nullable|numeric',
      'conversion_check' => 'nullable|numeric',
      'conversion_type' => 'nullable|numeric',
      'cr_over_all'   => 'nullable|numeric',
      'cr_check'      => 'nullable|numeric',
      'cr_type'       => 'nullable|numeric',
      'abv_over_all'  => 'nullable|numeric',
      'abv_check'     => 'nullable|numeric',
      'abv_type'      => 'nullable|numeric',
      'acv_over_all'  => 'nullable|numeric',
      'acv_type'      => 'nullable|numeric',
      'acv_check'     => 'nullable|numeric',
      'avg_call_out_over_all'   => 'nullable|numeric',
      'avg_call_out_check'      => 'nullable|numeric',
      'avg_call_out_type'       => 'nullable|numeric',
      'no_of_walk_over_all'     => 'nullable|numeric',
      'no_of_walk_check'        => 'nullable|numeric',
      'no_of_walk_type'         => 'nullable|numeric',
      'no_of_followup_over_all' => 'nullable|numeric',
      'no_of_followup_check'    => 'nullable|numeric',
      'no_of_followup_type'     => 'nullable|numeric',
      'hac_over_all'            => 'nullable|numeric',
      'hac_check'               => 'nullable|numeric',
      'hac_type'                => 'nullable|numeric',
      'no_of_post_sale_over_all' => 'nullable|numeric',
      'no_of_post_sale_check'    => 'nullable|numeric',
      'no_of_post_sale_type'     => 'nullable|numeric',
      'no_of_outstanding_over_all' => 'nullable|numeric',
      'no_of_outstanding_check'    => 'nullable|numeric',
      'no_of_outstanding_type'     => 'nullable|numeric',
      'min_no_of_students_over_all' => 'nullable|numeric',
      'min_no_of_students_check'    => 'nullable|numeric',
      'min_no_of_students_type'     => 'nullable|numeric',
      'production_costing_over_all' => 'nullable|numeric',
      'production_costing_check'    => 'nullable|numeric',
      'production_costing_type'     => 'nullable|numeric',
      'productions_over_all'  => 'nullable|numeric',
      'productions_check'     => 'nullable|numeric',
      'productions_type'      => 'nullable|numeric',
      'no_of_reviews_over_all' => 'nullable|numeric',
      'no_of_reviews_check'   => 'nullable|numeric',
      'no_of_reviews_type'    => 'nullable|numeric',
      'given_links_over_all'  => 'nullable|numeric',
      'given_links_check'     => 'nullable|numeric',
      'given_links_type'      => 'nullable|numeric',
      'no_of_placements_over_all' => 'nullable|numeric',
      'no_of_placements_check'  => 'nullable|numeric',
      'no_of_placements_type'  => 'nullable|numeric',
      'mou_over_all'          => 'nullable|numeric',
      'mou_check'             => 'nullable|numeric',
      'mou_type'              => 'nullable|numeric',
      'reference_sales_over_all' => 'nullable|numeric',
      'reference_sales_check'    => 'nullable|numeric',
      'reference_sales_type'     => 'nullable|numeric',
    ]);

    $branchId = $validatedData['branch_id'];
    $departmentId = $validatedData['department_id'];
    $month_id = $validatedData['month_id'];
    $year_id = $validatedData['year_id'];
    $createdBy = $request->user()->user_id;
    return $year_id;
    // Convert month_id if it's a string
    if (!is_numeric($month_id)) {
      $month_id = date('m', strtotime($month_id . ' 1'));
    }

    // Update or create the goal record
    $goal = GoalSetTeamModel::updateOrCreate(
      [
        'team_goal_month' => (int)$month_id,
        'team_goal_year'  => (int)$year_id,
        'branch_id'       => $branchId,
        'department_id'   => $departmentId,
      ],
      array_merge($validatedData, [
        'created_by' => $createdBy,
        'updated_by' => $createdBy,
        'status'     => 1 // Mark as 'Goal Set'
      ])
    );

    return response()->json([
      'status'  => 200,
      'message' => 'Team goal successfully updated!',
      'data'    => $goal
    ]);
  }





  public function addOrUpdateStaffGoal(Request $request)
  {
    // Convert month name to numeric format
    $monthName = $request->input('month_id');
    $monthNumber = date('m', strtotime($monthName . ' 1')); // Converts "February" to "02"

    // Replace month_id in the request before validation
    $request->merge(['month_id' => (int)$monthNumber]);
    $validatedData = $request->validate([
      'team_id' => 'required|integer',
      'month_id' => 'required|integer',
      'year' => 'required|integer',
      'department_id' => 'required|integer',
      'staff_goals' => 'required|array',
      'staff_goals.*.staff_id' => 'required|integer',
      'staff_goals.*.conversion' => 'nullable|integer',
      'staff_goals.*.cr' => 'nullable|integer',
      'staff_goals.*.abv' => 'nullable|integer',
      'staff_goals.*.acv' => 'nullable|integer',
      'staff_goals.*.avg_call_out' => 'nullable|integer',
      'staff_goals.*.no_of_walk' => 'nullable|integer',
      'staff_goals.*.no_of_followup' => 'nullable|integer',
      'staff_goals.*.hac' => 'nullable|integer',
      'staff_goals.*.no_of_post_sale' => 'nullable|integer',
      'staff_goals.*.no_of_outstanding' => 'nullable|integer',
      'staff_goals.*.production_costing' => 'nullable|integer',
      'staff_goals.*.min_no_of_students' => 'nullable|integer',
      'staff_goals.*.productions' => 'nullable|integer',
      'staff_goals.*.no_of_reviews' => 'nullable|integer',
      'staff_goals.*.no_of_placements' => 'nullable|integer',
      'staff_goals.*.mou' => 'nullable|integer',
      'staff_goals.*.reference_sales' => 'nullable|integer',
    ]);

    $branchId = $request->user()->branch_id;
    $departmentId = $validatedData['department_id'];
    $month = $validatedData['month_id'];
    $year = $validatedData['year'];
    $team_id = $validatedData['team_id'];
    $createdBy = $request->user()->user_id;
    // return $request->all();
    $branch_check = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first();

    $branch_code = $branch_check->city_short_code;


    foreach ($validatedData['staff_goals'] as $goalData) {
      GoalSetStaffModel::updateOrCreate(
        [
          'goal_month' => $month,
          'goal_date' => "{$year}-{$month}-01", // Proper date format
          'branch_id' => $branchId,
          'department_id' => $departmentId,
          'staff_id' => $goalData['staff_id'],
        ],
        [
          'team_id' => $team_id,
          'conversion' => $goalData['conversion'] ?? 0,
          'CR' => $goalData['cr'] ?? 0,
          'ABV' => $goalData['abv'] ?? 0,
          'ACV' => $goalData['acv'] ?? 0,
          'avg_call_out' => $goalData['avg_call_out'] ?? 0,
          'no_of_walk' => $goalData['no_of_walk'] ?? 0,
          'no_of_followup' => $goalData['no_of_followup'] ?? 0,
          'hac' => $goalData['hac'] ?? 0,
          'no_of_post_sale' => $goalData['no_of_post_sale'] ?? 0,
          'no_of_outstanding' => $goalData['no_of_outstanding'] ?? 0,
          'production_costing' => $goalData['production_costing'] ?? 0,
          'min_no_of_students' => $goalData['min_no_of_students'] ?? 0,
          'productions' => $goalData['productions'] ?? 0,
          'no_of_reviews' => $goalData['no_of_reviews'] ?? 0,
          'no_of_placements' => $goalData['no_of_placements'] ?? 0,
          'mou' => $goalData['mou'] ?? 0,
          'reference_sales' => $goalData['reference_sales'] ?? 0,
          'created_by' => $createdBy,
          'updated_by' => $createdBy,
          'status' => 1, // Default status
        ]
      );
    }


    return response()->json([
      'status' => 200,
      'message' => 'Goals updated successfully'
    ]);
  }
}