<?php

namespace App\Http\Controllers\CounsellorApp;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\settings\counsellor\SelfAssessment;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\StaffModel;
use App\Models\TrainingModel;
use App\Models\LeadModel;
use App\Models\CourseCategoryModel;
use App\Models\OtpModel;
use App\Models\SmsConfigModel;
use App\Models\LeadQuestionModel;
use App\Models\ManageCoursesModel;
use App\Models\LeadAppointmentModel;
use App\Models\AppointmentModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CounsellorAssessmentSave;
use App\Models\CostingModel;
use App\Models\CounsellorCategorySave;
use App\Models\CategoryQuestionModel;
use App\Models\JobRollModel;
use App\Models\CourseTypeModel;
use App\Models\CounsellorCourseSave;
use App\Models\CounsellorFeedbackSave;
use App\Models\CourseQuestionModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CustomerModel;
use App\Models\FeedbackQuestionModel;
use App\Models\OfferzoneModel;
use App\Models\PaymentModel;
use App\Models\PushNotification;
use App\Models\SelfAssessmentModel;
use DateTime;
use App\Models\CugManagementModel;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Auth;
use App\Services\ElysiumQrCodeService;
use Illuminate\Support\Str; // Add this at the top to use Str::uuid()
use App\Models\SmsTemplateModel;
use Carbon\Carbon;

class CounsellorAppController extends Controller
{
    protected $elysiumQrCodeService;

    public function __construct(ElysiumQrCodeService $elysiumQrCodeService)
    {
        $this->elysiumQrCodeService = $elysiumQrCodeService;
    }

    public function CounsellorLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $key      = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {

           
            $staffuser = CugManagementModel::where('staff_mobile', $mobile_no)->where('status', 0)->first();
            
            
            // return $user;
            if ($staffuser) {
                 $user = StaffModel::where('za_staff.sno', $staffuser->staff_id)
                ->where('za_staff.status', 0)
                ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
                ->select('za_staff.*', 'za_branch.branch_name','za_branch.key_id','za_branch.key_secret')
                ->first();

                if( $mobile_no == "9790464324"){
                    $otp_value  = 123456; // Random 6-digit OTP
                }else{
                    $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                }

                // Generate OTP
                

                // Save OTP to Database
                $otp = new OtpModel();

                $otp->user_id                  = $user->sno;
                $otp->mobile_no                =  $mobile_no;
                $otp->otp_number               = $otp_value;
                $otp->created_by               = $user->sno;
                $otp->updated_by               = $user->sno;
                $otp->save();
                
                // sms otp 
                 if( $mobile_no != "9790464324"){
                    if ($otp_value) {

                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $mobile_no;

                    $app_name = "Guidy";
                    // $app_link = 'https://elysiumacademy.org/';
                    $app_code = "JU9LB0y7N1L";
                    // Replace placeholders with actual values
                    $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);

                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
                }
                 }

                // Send OTP via SMS
                // $this->sendSms($mobile_no, $otp_value);

                // $user = Auth::user();
                // $token = $user->createToken('MobileApp')->plainTextToken;
                $usertable = User::where('user_id', $user->sno)->first();
                $token = $usertable->createToken('authToken')->accessToken;
                // $token = $usertable->createToken('authToken')->plainTextToken;
                // $token = $usertable->createToken('authToken', ['counsellor-access'])->plainTextToken;
                // $token = $usertable->createToken('authToken')->accessToken;
                // $token = $usertable->createToken('authToken', ['counsellor-access'])->plainTextToken;


                $baseUrl = 'https://erp.elysium.academy/staff_images/';
                return response()->json([
                    // 'api_token'         => $token,
                    'tokenValue'         => $token->token,
                    'otp'               => $otp_value,
                    'counsellor_name'   => $user->staff_name,
                    'counsellor_id'     => strval($user->sno),
                    'branch_name'       => $user->branch_name,
                    'razorpay_key'       => $user->key_id,
                    'key_secret'       => $user->key_secret ?? "",
                    'mobile_no'         => strval($user->mobile_no),
                    'email_id'          => strval($user->email_id),
                    'alternative_no'    => strval($user->alternative_no),
                    'contact_person_name' => $user->contact_person_name,
                    'contact_person_no' => strval($user->contact_person_no),
                    'martial_status'    => strval($user->martial_status),
                    'address'           => $user->address,
                    'staff_image'       => $baseUrl . $user->staff_image ?? null,
                    'knowledge_tag'     => $user->knowledge_tag ?? "[]",
                    'nick_name'         => $user->nick_name,
                    'date_of_joinig'     => strval($user->date_of_joinig),
                    'position_role'     => strval($user->position_role),
                    'credential'        => $user->credential ?? "",
                    'attatchment'       => $user->attatchment ?? "",
                    'description'       => $user->description ?? "",
                    'modified_on'       => $user->modified_on ?? "",
                    'modified_by'       => $user->modified_by ?? "",
                    'created_on'        => $user->created_on ?? "",
                    'created_by'        => $user->created_by,
                    'status'            => strval($user->status),

                ], 200);
            } else {
                $response = [
                    'status' => "2",
                    'message' => 'User does not exist',
                    "error_msg" => null,
                    'data' => null
                ];
                return response($response, 200);
            }
        }
    }
   public function verifyOtp(Request $request)
  {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        $expiryTime = $createdAt->copy()->addMinutes(2);
        $currentTime = Carbon::now('UTC');
    
        if ($currentTime->greaterThan($expiryTime)) {
            return response()->json([
                'status'  => false,
                'message' => 'OTP expired. Please request a new one.'
            ], 410);
        }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }


    // public function sendSms($phone, $otp_number)
    // {
    //     $config = SmsConfigModel::where('sms_config_id', 1)->first();

    //     if (!$config) {
    //         return response()->json(['status' => 500, 'message' => 'SMS configuration not found.'], 500);
    //     }

    //     $authkey        = $config->api_key;
    //     $sender_id      = $config->sender_id;
    //     $DLT_TE_ID      = $config->DLT_TE_ID;
    //     $country_code   = $config->country_code;
    //     $content        = 'Your OTP for member registration is {#var#} DESIYA MURPOKKU DRAVIDA KAZHAGAM';
    //     $mobile_number  = $country_code . $phone;
    //     // $otp            = $otp_number;

    //     // here change otp number

    //     $message_content = str_replace('{#var#}', $otp_number, $content);


    //     $url = 'http://control.yourbulksms.com/api/sendhttp.php?authkey=' . $authkey . '&mobiles=' . $mobile_number . '&message=' . urlencode($message_content) . '&sender=' . $sender_id . '&route=2&country=' . $country_code . '&DLT_TE_ID=' . $DLT_TE_ID;

    //     $response = Http::post($url);

    //     if ($response->failed()) {
    //         return response()->json(['status' => 500, 'message' => 'Failed to send SMS.'], 500);
    //     }
    // }

    // public function send_sms($phone, $otp_number)
    // {
    //     $result = $this->db->select('*')->from('sms_config')->where("sms_config_id", 1)->get()->row();
    //     $authkey = $result ? $result->api_key : '';
    //     $sender_id = $result ? $result->sender_id : '';
    //     $DLT_TE_ID = $result ? $result->DLT_TE_ID : '';
    //     $country_code = $result ? $result->country_code : '';
    //     $message_content = $content;
    //     $mobile_number = $country_code . $phone;

    //     $url = 'http://control.yourbulksms.com/api/sendhttp.php?authkey=' . $authkey . '&mobiles=' . $mobile_number . '&message=' . urlencode($message_content) . '&sender=' . $sender_id . '&route=2&country=' . $country_code . '&DLT_TE_ID=' . $DLT_TE_ID;
    //     $ch = curl_init($url);
    //     curl_setopt($ch, CURLOPT_POST, 1);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $url);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     $response = curl_exec($ch);
    //     curl_close($ch);
    // }

    // public function CounsellorLogin(Request $request)
    // {
    //     $mobile_no = $request->mobile_no;
    //     $key = $request->key ? $request->key : 'null';

    //     $validator = Validator::make($request->all(), [
    //         'mobile_no' => 'required|max:255',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 422,
    //             'message' => 'Validation Error',
    //             'error_msg' => $validator->errors(),
    //             'data' => null
    //         ], 422);
    //     } else {
    //         $user = StaffModel::where('mobile_no', $mobile_no)
    //             ->where('accessible_app', 1)
    //             ->where('status', 0)
    //             ->first();

    //         if ($user) {
    //             $usertable = User::where('user_id', $user->sno)->first();
    //             $token = $usertable->createToken('authToken')->plainTextToken;
    //             $baseUrl = 'https://erp.elysium.academy/staff_images/';

    //             // Prepare the response data
    //             $responseData = [
    //                 'api_token'         => $token,
    //                 'counsellor_name'   => $user->staff_name,
    //                 'counsellor_id'     => strval($user->sno),
    //                 'mobile_no'         => strval($user->mobile_no),
    //                 'email_id'          => strval($user->email_id),
    //                 'alternative_no'    => strval($user->alternative_no),
    //                 'contact_person_name' => $user->contact_person_name,
    //                 'contact_person_no' => strval($user->contact_person_no),
    //                 'martial_status'    => strval($user->martial_status),
    //                 'address'           => $user->address,
    //                 'knowledge_tag'     => $user->knowledge_tag,
    //                 'nick_name'         => $user->nick_name,
    //                 'date_of_joinig'    => strval($user->date_of_joinig),
    //                 'position_role'     => strval($user->position_role),
    //                 'credential'        => $user->credential,
    //                 'attatchment'       => $user->attatchment,
    //                 'description'       => $user->description,
    //                 'modified_on'       => $user->modified_on,
    //                 'modified_by'       => $user->modified_by,
    //                 'created_on'        => $user->created_on,
    //                 'created_by'        => $user->created_by,
    //                 'status'            => strval($user->status),
    //             ];

    //             // Add staff_image only if it exists
    //             if (!empty($user->staff_image)) {
    //                 $responseData['staff_image'] = $baseUrl . $user->staff_image;
    //             }

    //             return response()->json($responseData, 200);
    //         } else {
    //             $response = [
    //                 'status' => "2",
    //                 'message' => 'User does not exist',
    //                 "error_msg" => null,
    //                 'data' => null
    //             ];
    //             return response($response, 200);
    //         }
    //     }
    // }


     public function CounsellorSaveNo(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_mobile' => 'required|max:25'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            $lead_mobile                = $request->lead_mobile;
            $user_id                    = $request->counsellor_id;
            $pages                      = $request->pages;

            // return $request->Counsellor_id;
            $chk = LeadModel::where('lead_mobile', ucwords($lead_mobile))->where('status', '!=', 2)->first();

            if ($chk) {

                // $data = collect($chk->toArray())->mapWithKeys(function ($value, $key) {
                //     // Replace 'sno' with 'lead_id' if necessary
                //     if ($key === 'sno') {
                //         $key = 'le_id';
                //     }
                //     // Convert values to string
                //     return [$key => strval($value)];
                // });
                // $lead_dob = $chk->lead_dob; // Assuming $chk->lead_dob is a valid date string
                $otp_value = rand(100000, 999999); // Random 6-digit OTP

                // Save OTP to Database
                $otp = new OtpModel();

                $otp->user_id    = $chk->sno;
                $otp->otp_number = $otp_value;
                $otp->created_by = $chk->sno;
                $otp->updated_by = $chk->sno;
                $otp->save();
                
                 if ($otp_value) {

                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $lead_mobile;

                    $app_name = "Guidy";
                    // $app_link = 'https://elysiumacademy.org/';

                    // Replace placeholders with actual values
                    $replacement_values = [$chk->lead_name, $app_name, $otp_value];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);

                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
                }
                
                $formatted_lead_dob = date('d-M-Y', strtotime($chk->lead_dob));
                $responseData = [
                    'le_id'         => (string) $chk->sno,
                    'lead_mobile'   => (string) $chk->lead_mobile,
                    'otp'                 => $otp_value,
                    'lead_name'     => $chk->lead_name,
                    'lead_dob'      => (string) $formatted_lead_dob,
                    'lead_gender'   => (string) $chk->lead_gender,
                    'lead_marital_status'   => (string) $chk->lead_marital_status,
                    'lead_email_id' => $chk->lead_email_id,
                    'qualification' => $chk->qualification,
                    'field'         => (string) $chk->field,
                    'address'       => $chk->address,
                    'status'        => (string) $chk->status,
                    'pages'         => (string) $chk->pages,
                    'created_by'    => (string) $chk->created_by,
                    'updated_by'    => (string) $chk->updated_by
                ];
                // Convert collection to array if needed
                // $data = $data->toArray();
                return response()->json([
                    'status'    => "1",
                    'message'   => 'Mobile Number already have',
                    'error_msg' => null,
                    'data'      => $responseData,
                ], 200);
            } else {

                $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                $branch = StaffModel::where('sno', $user_id)->first();
                $branch_check = BranchModel::where('sno', $branch->branch_id)->orderBy('sno', 'desc')->first();

                $branch_code = $branch_check->city_short_code;

                $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $year = date("Y");
                if (!$category_check) {
                    $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
                } else {
                    $data = $category_check->lead_id;
                    $slice = explode("/", $data);
                    $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number = (int)$resultcus + 1;
                    $request_pay = sprintf("LED%04d", $next_number);
                    $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
                }


                $add_category = new LeadModel();
                $add_category->lead_id                  = $lead_id;
                $add_category->lead_mobile              = $lead_mobile;
                $add_category->lead_name                = null;
                $add_category->lead_dob                 = null;
                $add_category->lead_gender              = null;
                $add_category->lead_email_id            = null;
                $add_category->qualification            = null;
                $add_category->field                    = null;
                $add_category->address                  = null;
                $add_category->lead_marital_status      = null;
                $add_category->lead_source_id           = 4;
                $add_category->status                   = 3;
                $add_category->pages                    = $pages;
                $add_category->created_by               = $user_id;
                $add_category->updated_by               = $user_id;




                // $add_category->lead_name " ",
                // $add_category->lead_mobile "7896321455",
                // $add_category->lead_alternate_mobile " ",
                // $add_category->lead_email_id " ",
                // $add_category->lead_gender " ",
                // $add_category->lead_dob " ",
                // $add_category->lead_marital_status " ",
                // $add_category->country " ",
                // $add_category->state " ",
                // $add_category->city " ",
                // $add_category->address " ",
                // $add_category->field " ",
                // "qualification "",
                // "course_id "",
                // "lead_source_id "4",
                // "lead_type_id "",
                // "lead_question_id "",
                // "lead_answer "",
                // "lead_score "",
                // "lead_comments "",
                // "pages "1",
                // "created_by "12",
                // "created_at "2024-08-13T04:11:43.000000Z",
                // "updated_by "12",
                // "updated_at "2024-08-13T04:11:43.000000Z",
                // "status "3"
                // return $add_category;
                $add_category->save();
                if ($add_category) {

                    // $data = collect($add_category)->map(function ($item) {
                    //     // Check if $item is an array, if not convert it to an array
                    //     if (is_object($item)) {
                    //         $item = (array) $item;
                    //     }
                    //     if (is_array($item)) {

                    //         return array_map('strval', $item);
                    //     } else {
                    //         // Handle case where $item is not an array
                    //         return (string) $item;
                    //     }
                    // });

                    $data = collect($add_category->toArray())->mapWithKeys(function ($value, $key) {
                        // Replace 'sno' with 'lead_id' if necessary
                        if ($key === 'sno') {
                            $key = 'le_id';
                        }
                        // if ($key === 'lead_dob') {
                        //     $value = null;
                        // }
                        // Convert values to string
                        return [$key => strval($value)];
                    });
                    // Convert collection to array if needed
                    $data = $data->toArray();
                    return response()->json([
                        'status'    => "0",
                        'message'   => 'Mobile Number added successfully',
                        'error_msg' => null,
                        'data'      => $data,
                    ], 200);
                } else {
                    return response()->json([
                        'status'    => 400,
                        'message'   => 'Mobile Number not added',
                        'error_msg' => null,
                        'data'      => null,

                    ], 200);
                }
            }
        }
    }

    public function CounsellorQuickAdd(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $lead_id             = $request->lead_id;
            $lead_name           = $request->lead_name;
            // $lead_mobile         = $request->lead_mobile;
            $lead_email_id       = $request->lead_email_id;
            $lead_gender         = $request->lead_gender;
            // $lead_dob            = $request->lead_dob;
            $address             = $request->address;
            $field               = $request->field;
            $lead_marital_status = $request->lead_marital_status;
            $qualification       = $request->qualification;
            $user_id             = $request->counsellor_id;
            $pages                       = $request->pages;
            $lead_dob = DateTime::createFromFormat('d-M-Y', $request->lead_dob);
            $add_category =  LeadModel::where('sno', $lead_id)->first();
            // $chk = LeadModel::where('lead_mobile', ucwords($lead_mobile))->where('status', '!=', 2)->first();

            // if ($chk) {
            //     session()->flash('toastr', [
            //         'type' => 'error',
            //         'message' => 'Name has been  already created!'
            //     ]);
            // } else {


            $add_category->lead_name               = Ucfirst($lead_name);
            // $add_category->lead_mobile             = $lead_mobile;
            $add_category->lead_email_id           = $lead_email_id;
            $add_category->lead_dob                = $lead_dob->format('Y-m-d');
            $add_category->lead_gender             = $lead_gender;
            $add_category->address                 = $address;
            $add_category->field                   = $field;
            $add_category->lead_marital_status     = $lead_marital_status;
            $add_category->qualification           = $qualification;
            $add_category->lead_source_id          = 4;
            $add_category->status                  = 0;
            $add_category->pages                  = $pages;
            $add_category->created_by              = $user_id;
            $add_category->updated_by              = $user_id;

            $add_category->update();

            if ($add_category) {
                // $data = collect($add_category)->map(function ($item) {
                //     // Check if $item is an array, if not convert it to an array
                //     if (is_object($item)) {
                //         $item = (array) $item;
                //     }
                //     if (is_array($item)) {
                //         return array_map('strval', $item);
                //     } else {
                //         // Handle case where $item is not an array
                //         return (string) $item;
                //     }
                // });
                $data = collect($add_category->toArray())->mapWithKeys(function ($value, $key) {
                    // Replace 'sno' with 'lead_id' if necessary
                    if ($key === 'sno') {
                        $key = 'le_id';
                    }
                    // Convert values to string
                    return [$key => strval($value)];
                });
                // Convert collection to array if needed
                $data = $data->toArray();
                return response()->json([
                    'status'    => 200,
                    'message'   => 'Lead added successfully',
                    'error_msg' => null,
                    'data'      =>  $data,
                ], 200);
            } else {
                return response()->json([
                    'status'    => 400,
                    'message'   => 'Lead not added',
                    'error_msg' => null,
                    'data'      => null,

                ], 200);
            }
            // }
        }
    }

    public function CourseCategoryList()
    {


        $CourseCategory = CourseSubCategoryModel::select('za_course_subcategory.*')
            ->join('za_category_question', 'za_course_subcategory.sno', '=', 'za_category_question.category_id')
            ->where('za_course_subcategory.status', 0)
            ->orderBy('za_course_subcategory.sno', 'desc')
            ->distinct() // Ensure that the query returns distinct rows
            ->get()
            ->map(function ($item) {
                $array = $item->toArray();
                return array_map('strval', $array);
            });
        // Log the data instead of using dd()
        // Log::info('CourseCategory Data:', $CourseCategory->toArray());
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function LeadQuestionList()
    {
        $leadquestion = LeadQuestionModel::where('status', 0)
            ->get()->map(function ($item) {
                $array = $item->toArray();

                // Check if lead_question_option is a valid JSON string
                $leadQuestionOption = json_decode($array['lead_question_option'], true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($leadQuestionOption)) {
                    // Restructure the lead_question_option field
                    $formattedOptions = [];
                    foreach ($leadQuestionOption as $index => $option) {
                        $formattedOptions[strval($index + 1)] = $option['value'];
                    }
                    $array['lead_question_option'] = $formattedOptions;
                } else {
                    $array['lead_question_option'] = [];
                }

                // Convert all top-level values to strings
                foreach ($array as $key => $value) {
                    if (is_array($value)) {
                        continue; // Skip arrays
                    }
                    $array[$key] = strval($value);
                }

                return $array;
            });

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $leadquestion
        ], 200);
    }

    

    public function AppointmentCommon(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => '888 format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
    
            $lead_id          = $request->lead_id;
            $staff_id         = $request->staff_id;
            $appointment_time = $request->appointment_time; // e.g. 12:00:00
            $reason           = $request->reason;
            $appointment_date = $request->appointment_date; // e.g. 24-01-2025
            $demo_type        = $request->demo_type;
            $user_id          = $request->counsellor_id;
    
            $staff_data    = StaffModel::where('status', 0)->first();
            $category_check = LeadAppointmentModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();
    
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $appointment_id = "LDAP-0001/" . $year;
            } else {
                $data = $category_check->lead_appointment_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestCode = sprintf("LDAP-%04d", $next_number);
                $year = substr(date("y"), -2);
                $appointment_id = $requestCode . '/' . $year;
            }
    
            // ✅ Combine date + time into one datetime
            $appointmentDateTime = Carbon::createFromFormat(
                'd-M-Y H:i',
                $appointment_date . ' ' . $appointment_time
              );
    
            $add_category = new LeadAppointmentModel();
            $add_category->lead_appointment_id     = $appointment_id;
            $add_category->branch_id               = $staff_data->branch_id;
            $add_category->lead_id                 = $lead_id;
            $add_category->staff_id                = $staff_id;
            $add_category->appointment_date        = $appointmentDateTime; // will save as 2025-01-24 12:00:00
            $add_category->convo_message           = $reason;
            $add_category->appointment_category    = $demo_type;
            $add_category->department_id           = 1; // sales
            $add_category->appointment_status      = 1; // new 
            $add_category->status                  = 0;
            $add_category->created_by              = $user_id;
            $add_category->updated_by              = $user_id;
    
            $add_category->save();
    
            if ($add_category) {
                return response()->json([
                    'status'    => 200,
                    'message'   => 'Appointment added successfully',
                    'error_msg' => null,
                    'data'      => $add_category,
                ], 200);
            } else {
                return response()->json([
                    'status'    => 400,
                    'message'   => 'Appointment not added',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            }
        }
    }


    public function NotYetDecided(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_id' => 'required'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'hhgfhh format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


           $lead_id          = $request->lead_id;
            $staff_id         = $request->staff_id;
            $appointment_time = $request->appointment_time; // e.g. 12:00:00
            $reason           = $request->reason;
            $appointment_date = $request->appointment_date; // e.g. 24-01-2025
            $demo_type        = $request->demo_type;
            $user_id          = $request->counsellor_id;
    
            $staff_data    = StaffModel::where('status', 0)->first();
            $category_check = LeadAppointmentModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();
    
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $appointment_id = "LDAP-0001/" . $year;
            } else {
                $data = $category_check->lead_appointment_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestCode = sprintf("LDAP-%04d", $next_number);
                $year = substr(date("y"), -2);
                $appointment_id = $requestCode . '/' . $year;
            }
    
            // ✅ Combine date + time into one datetime
            $appointmentDateTime = Carbon::createFromFormat('d-m-Y H:i:s', $appointment_date . ' ' . $appointment_time);
    
            $add_category = new LeadAppointmentModel();
            $add_category->lead_appointment_id     = $appointment_id;
            $add_category->branch_id               = $staff_data->branch_id;
            $add_category->lead_id                 = $lead_id;
            $add_category->staff_id                = $staff_id;
            $add_category->appointment_date        = $appointmentDateTime; // will save as 2025-01-24 12:00:00
            $add_category->convo_message           = $reason;
            $add_category->appointment_category    = $demo_type;
            $add_category->department_id           = 1; // sales
            $add_category->appointment_status      = 1; // new 
            $add_category->status                  = 0;
            $add_category->created_by              = $user_id;
            $add_category->updated_by              = $user_id;
    
            $add_category->save();
            
            if ($add_category) {
                return response()->json([
                    'status'    => 200,
                    'message'   => 'Updated successfully',
                    'error_msg' => null,
                    'data'      => $add_category,
                ], 200);
            } else {
                return response()->json([
                    'status'    => 400,
                    'message'   => 'Not Updated',
                    'error_msg' => null,
                    'data'      => null,

                ], 200);
            }
        }
    }

    public function Appointment(Request $request)
    {

        $validator = Validator::make($request->all(), [
            // 'appointment_date' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => '889 format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


             $lead_id          = $request->lead_id;
            $staff_id         = $request->staff_id;
            // $appointment_time = $request->appointment_time; // e.g. 12:00:00
            $reason           = $request->reason;
            // $appointment_date = $request->appointment_date; // e.g. 24-01-2025
            $demo_type        = $request->demo_type;
            $user_id          = $request->counsellor_id;
    
            $staff_data    = StaffModel::where('status', 0)->first();
            $category_check = LeadAppointmentModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();
    
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $appointment_id = "LDAP-0001/" . $year;
            } else {
                $data = $category_check->lead_appointment_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestCode = sprintf("LDAP-%04d", $next_number);
                $year = substr(date("y"), -2);
                $appointment_id = $requestCode . '/' . $year;
            }
    
            // ✅ Combine date + time into one datetime
            $appointmentDateTime = Carbon::createFromFormat('d-m-Y H:i', $appointment_date . ' ' . $appointment_time);
    
            $add_category = new LeadAppointmentModel();
            $add_category->lead_appointment_id     = $appointment_id;
            $add_category->branch_id               = $staff_data->branch_id;
            $add_category->lead_id                 = $lead_id;
            $add_category->staff_id                = $staff_id;
            $add_category->appointment_date        = $appointmentDateTime; // will save as 2025-01-24 12:00:00
            $add_category->convo_message           = $reason;
            $add_category->appointment_category    = $demo_type;
            $add_category->department_id           = 1; // sales
            $add_category->appointment_status      = 1; // new 
            $add_category->status                  = 0;
            $add_category->created_by              = $user_id;
            $add_category->updated_by              = $user_id;
    
            $add_category->save();
    

            if ($add_category) {
                return response()->json([
                    'status'    => 200,
                    'message'   => 'Appointment added successfully',
                    'error_msg' => null,
                    'data'      => $add_category,
                ], 200);
            } else {
                return response()->json([
                    'status'    => 400,
                    'message'   => 'Appointment not added',
                    'error_msg' => null,
                    'data'      => null,

                ], 200);
            }
        }
    }

    public function AssessmentQuestionList()
    {

        $startTime = microtime(true);
        $course = SelfAssessmentModel::where('status', 0)
            ->orderBy('sno', 'asc')
            ->get()->map(function ($item) {
                $array = $item->toArray();
                return array_map('strval', $array);
            });
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $course,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }


    public function SelectedCategory(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'data' => 'required|array',
            'data.*.answer' => 'required|integer',
            'data.*.category_id' => 'required|string',
        ]);

        // Extract the data from the request
        $data = $request->input('data');
        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');

        $branch = StaffModel::where('sno', $counsellor_id)->first();

        // Start timing
        $startTime = microtime(true);

        // Initialize an array to store selected category IDs
        $selectedCategories = [];

        // Loop through the data to find categories where 'answer' == 1
        foreach ($data as $item) {
            if (isset($item['answer']) && $item['answer'] == 1) {
                $selectedCategories[] = $item['category_id'];
            }
            // Save the assessment data into the table
            CounsellorAssessmentSave::updateOrCreate(
                [
                    'lead_id' => $lead_id,
                    'category_id' => $item['category_id'],
                    'assessment_question_id' => $item['sno'], // assuming 'sno' is the assessment question ID
                ],
                [
                    'branch_id' => $branch->branch_id,
                    'assessment_question_answer' => json_encode($item['answer']), // Store the answer as JSON
                    'created_by' => $counsellor_id,
                    'updated_by' => $counsellor_id,
                ]
            );
        }

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Selected Category data saved successfully',
            'error_msg' => null,
            'Category Ids' => $selectedCategories,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }


    public function CategoryQuestionList(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'category_ids' => 'required|array',
            'category_ids.*' => 'integer',
        ]);

        // Extract the category_ids from the request
        $category_ids = $request->input('category_ids');

        // Start timing
        $startTime = microtime(true);


        // Fetch categories
        $categories = collect(CourseSubCategoryModel::whereIn('sno', $category_ids)->get()->keyBy('sno'));

        // Fetch questions and join with categories
        $questions = collect(
            CategoryQuestionModel::whereIn('category_id', $category_ids)
                ->where('za_category_question.status', 0)
                ->join('za_course_subcategory', 'za_course_subcategory.sno', '=', 'za_category_question.category_id')
                ->select('za_course_subcategory.sno as category_id', 'za_course_subcategory.course_subcategory_name', 'za_category_question.*')
                ->orderBy('za_category_question.sno', 'asc')
                ->get()
                ->groupBy('category_id')
        );
        // return $questions;
        // Format the response
        $response = $categories->map(function ($category) use ($questions) {
            return [
                'category_id'   => $category->sno,
                'category_name' => $category->course_subcategory_name,
                'question'      => $questions->get($category->sno, collect([]))
                    ->map(function ($question) {
                        return [
                            'category_question_id' => strval($question->sno),
                            'category_id' => strval($question->category_id),
                            'category_question_name' => strval($question->category_question_name),
                            'category_question_type' => strval($question->category_question_type),
                            // Ensure proper JSON handling
                            'category_question_option' => json_decode($question->category_question_option, true) ?? [],
                            'created_by' => strval($question->created_by),
                            'created_at' => $question->created_at->toISOString(),
                            'updated_by' => strval($question->updated_by),
                            'updated_at' => $question->updated_at->toISOString(),
                            'status' => strval($question->status),
                        ];
                    })
                    ->toArray()
            ];
        });



        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status'    => 200,
            'message'   => 'Category Question List',
            'error_msg' => null,
            'data'      => $response,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }


    public function CategoryQuestionSave(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'data' => 'required|array',
            'data.*.category_id' => 'required|integer',
            'data.*.category_question_id' => 'required|integer',
            'data.*.category_question_option' => 'required|array',
            'lead_id' => 'required|integer',
            'counsellor_id' => 'required|integer',
        ]);

        // Extract data from the request
        $data = $request->input('data');
        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');

        $branch = StaffModel::where('sno', $counsellor_id)->first();
        // Start timing
        $startTime = microtime(true);

        foreach ($data as $item) {
            // Extract the options
            $options = $item['category_question_option'];

            // Fetch all question options and their scores
            $allOptions = CategoryQuestionModel::where('sno', $item['category_question_id'])
                ->pluck('category_question_option') // Fetch all JSON data
                ->toArray();

            // Decode JSON and extract scores
            $optionScores = [];
            foreach ($allOptions as $json) {
                $decoded = json_decode($json, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $option) {
                        $optionScores[$option['value']] = $option['score'];
                    }
                }
            }

            // Calculate the total score
            $totalScore = array_reduce($options, function ($carry, $option) use ($optionScores) {
                return $carry + ($optionScores[$option] ?? 0);
            }, 0);

            // Update or create the record
            $cat = CounsellorCategorySave::updateOrCreate(
                [
                    'lead_id' => $lead_id,
                    'category_id' => $item['category_id'],
                    'category_question_id' => $item['category_question_id']
                ],
                [
                    'branch_id' => $branch->branch_id,
                    'category_question_answer' => json_encode($options), // Store the options as JSON
                    'score' => $totalScore, // Store the total score
                    'created_by' => $counsellor_id,
                    'updated_by' => $counsellor_id
                ]
            );
        }
        if ($lead_id) {
            $lead_id           = $lead_id;
            $upd_lead          =  LeadModel::where('sno', $lead_id)->first();
            $upd_lead->pages   = 2;
        }

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => 'Successfully',
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }


    public function ScoreBoard(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'lead_id' => 'required|integer',
            'counsellor_id' => 'required|integer',
            'category_ids' => 'required|array', // Changed to array
            'category_ids.*' => 'integer' // Ensure each item in the array is an integer
        ]);

        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');
        $category_ids = $request->input('category_ids'); // This should be an array

        // Start timing
        $startTime = microtime(true);

        // Get all scores for the given lead and counsellor
        $scores = CounsellorCategorySave::where('lead_id', $lead_id)
            ->where('created_by', $counsellor_id)
            ->whereIn('category_id', $category_ids)
            ->select('category_id', \DB::raw('SUM(score) as total_score'))
            ->groupBy('category_id')
            ->get();

        // Get category details based on the category_id
        $categoryIds = $scores->pluck('category_id');
        $categories = CourseSubCategoryModel::whereIn('sno', $categoryIds)->get()->keyBy('sno');

        // Prepare data for the response
        $data = $scores->map(function ($score) use ($categories) {
            return [
                'category_id' => (string) $score->category_id, // Ensure category_id is a string
                'Category_name' => $categories[$score->category_id]->course_subcategory_name ?? 'Unknown',
                'Category_score' => $score->total_score,
            ];
        });
        
        // ✅ Find the highest score category
        $highScore = $data->sortByDesc('Category_score')->first();
        $highScoreCourse = $highScore['Category_name'] ?? null;
        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => "Category Score Board",
            'error_msg' => null,
            'data' => $data,
            'lead_id' => (string) $lead_id,
             'high_score_course' => $highScoreCourse, // 👈 Added here
            'counsellor_id' => (string) $counsellor_id,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function CourseQuestion(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            // Add validation rules if needed
        ]);

        // Start timing
        $startTime = microtime(true);

        // Retrieve and customize course questions
        $course = CourseQuestionModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get()->map(function ($item) {
                // Convert item to array

                $array = $item->toArray();

                // Decode the JSON encoded `course_question_option`
                $array['course_question_option'] = json_decode($array['course_question_option'], true);
                if (isset($array['sno'])) {
                    $array['course_question_id'] = strval($array['sno']);
                    unset($array['sno']);
                }
                unset($array['course_question_type']);
                return $array;
            });

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => "Course Question",
            'error_msg' => null,
            'data' => $course,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function CourseQuestionSave(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'data.required' => 'The data field is required.',
            'data.array' => 'The data field must be an array.',
            'data.*.category_id.required' => 'The category ID is required for each item.',
            'data.*.category_id.integer' => 'The category ID must be an integer.',
            'data.*.course_question_id.required' => 'The course question ID is required for each item.',
            'data.*.course_question_id.integer' => 'The course question ID must be an integer.',
            'data.*.course_question_option.required' => 'The course question options are required for each item.',
            'data.*.course_question_option.array' => 'The course question options must be an array.',
            'lead_id.required' => 'The lead ID is required.',
            'lead_id.integer' => 'The lead ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'data' => 'required|array',
            'data.*.category_id' => 'required|integer',
            'data.*.course_question_id' => 'required|integer',
            'data.*.course_question_option' => 'required|array',
            'lead_id' => 'required|integer',
            'counsellor_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract data from the request
        $data = $request->input('data');
        $lead_id = intval($request->input('lead_id'));
        $counsellor_id = intval($request->input('counsellor_id'));
        $branch = StaffModel::where('sno', $counsellor_id)->first();
        // Start timing
        $startTime = microtime(true);

        foreach ($data as $item) {
            // Extract the options
            $category_id = intval($item['category_id']);
            $course_question_id = intval($item['course_question_id']);
            $options = $item['course_question_option'];

            // Fetch the existing question options for the given course_question_id
            $allOptions = CourseQuestionModel::where('sno', $course_question_id)
                ->pluck('course_question_option')
                ->toArray();

            // Decode JSON and create an array of option values and their associated courses
            $optionCourse = [];
            foreach ($allOptions as $json) {
                $decoded = json_decode($json, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $option) {
                        $optionCourses = json_decode($option['courses'], true);
                        if (is_array($optionCourses)) {
                            $optionCourse[$option['value']] = $optionCourses;
                        }
                    }
                }
            }



            // Initialize an array to hold valid courses
            $matchedCourses = [];

            // Check each option in $options against $optionCourse
            foreach ($options as $optionValue) {
                if (isset($optionCourse[$optionValue])) {
                    // If option exists in optionCourse, add to matchedCourses
                    $matchedCourses = array_merge($matchedCourses, $optionCourse[$optionValue]);
                }
            }

            // Remove duplicate course IDs
            $matchedCourses = array_unique($matchedCourses);


            // return  $matchedCourses;
            // Filter courses based on category_id
            $filteredCourses = [];
            foreach ($matchedCourses as $courseId) {
                $course = ManageCoursesModel::where('status', 0)
                    ->where('course_subcategory_id', $category_id)
                    ->where('sno', $courseId)
                    ->first();

                if ($course) {
                    $filteredCourses[] = $courseId;
                }
            }
            // return  $filteredCourses;
            // Convert filtered courses array to a string or appropriate format
            //  $totalCourses = implode(',', array_unique($filteredCourses));
            $totalCourses = json_encode($filteredCourses);


            // Update or create the record
            $savec = CounsellorCourseSave::updateOrCreate(
                [
                    'lead_id' => $lead_id,
                    'category_id' => $category_id,
                    'course_question_id' => $course_question_id
                ],
                [
                    'branch_id' => $branch->branch_id,
                    'course_question_answer' => json_encode($options),
                    'courses' => $totalCourses, // Store the total courses as a comma-separated string
                    'created_by' => $counsellor_id,
                    'updated_by' => $counsellor_id
                ]
            );
        }
        if ($lead_id) {
            $lead_id           = $lead_id;
            $upd_lead          =  LeadModel::where('sno', $lead_id)->first();
            $upd_lead->pages   = 2;
        }
        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Successfully saved',
            'error_msg' => null,
            'data' => 'Successfully',
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function GetCourse(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'lead_id.required' => 'The lead ID is required.',
            'lead_id.integer' => 'The lead ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
            'category_id.integer' => 'The category ID must be an integer.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required|integer',
            'counsellor_id' => 'required|integer',
            'category_id' => 'integer', // Make category_id optional
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract input values
        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');
        $category_id = $request->input('category_id'); // Optional

        // Start timing
        $startTime = microtime(true);

        // Get all scores for the given lead and counsellor
        $query = CounsellorCourseSave::where('lead_id', $lead_id)
            ->where('created_by', $counsellor_id);

        if ($category_id) {
            $query->where('category_id', $category_id);
        }

        $getcourses = $query->select('courses')->get();
        // return $getcourses;
        // Extract and deduplicate course IDs from the response
        $coursesIds = $getcourses->pluck('courses')->map(function ($course) {
            return json_decode($course, true); // Decode JSON string to array
        })->flatten()->unique()->toArray();

        // Fetch course details from ManageCoursesModel
        $courses = ManageCoursesModel::whereIn('sno', $coursesIds)->get()->keyBy('sno');
        $jobRollIds = []; // Array to hold all job roll IDs for fetching names and CTCs

        // Prepare a unique list of courses
        $uniqueCourses = [];
        foreach ($coursesIds as $courseId) {
            if (isset($courses[$courseId])) {
                $course = $courses[$courseId];

                // Decode the job roll names and CTCs from JSON strings
                $jobRollNames = json_decode($course->job_roll_id, true); // Decoding job roll IDs from course
                $jobRollIds = array_merge($jobRollIds, $jobRollNames); // Collect job roll IDs for lookup
                $course_type = CourseTypeModel::where('sno', $course->course_type_id)->first();
                $course_subcategory = CourseSubcategoryModel::where('sno', $course->course_subcategory_id)->first();

                // Prepare a list of unique courses with job roll IDs (no need to decode fresher_ctc and experience_ctc here)
                $uniqueCourses[$courseId] = [
                    'course_id'         => (string) $courseId,
                    'course_name'       => $course->course_name,
                    'job_roll_id'       => $jobRollNames, // Store array of job roll IDs
                    'course_hours'      => (string) $course->course_duration,
                    'course_type'       => (string) $course->course_type_id,
                    'course_type_name'  => (string) $course_type->course_type_name,
                    'course_subcategory_name'  => (string) $course_subcategory->course_subcategory_name,
                    'course_fee'        => (string) $course->course_max_price,
                    'short_description' => $course->course_future_scope,
                ];
            }
        }

        // Remove duplicates from job roll IDs
        $jobRollIds = array_unique($jobRollIds);

        // Fetch job rolls from the database
        $jobRolls = JobRollModel::whereIn('sno', $jobRollIds)->get()->keyBy('sno');

        // Combine job roll data with the courses
        foreach ($uniqueCourses as &$course) {
            $course['job_roll_details'] = []; // To store job roll name, fresher_ctc, and experience_ctc only once per job roll

            foreach ($course['job_roll_id'] as $jobRollId) {
                if (isset($jobRolls[$jobRollId])) {
                    $jobRoll = $jobRolls[$jobRollId];

                    // Avoid duplicating CTC values; Add job roll details only once per job roll
                    $course['job_roll_details'][] = [
                        'job_roll_name'     => $jobRoll->job_roll_name,
                        'fresher_ctc'       => $jobRoll->fresher_ctc,
                        'experience_ctc'    => $jobRoll->experience_ctc,
                    ];
                } else {
                    Log::warning('Job roll ID not found', ['job_roll_id' => $jobRollId]);
                }
            }
        }

        // Combine all unique courses into a single array
        $data = [
            'courses' => array_values($uniqueCourses) // Convert associative array to indexed array
        ];

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Course List',
            'error_msg' => null,
            'data' => $data,
            'lead_id' => (string) $lead_id,
            'counsellor_id' => (string) $counsellor_id,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }
   public function SelectedCourse(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'course_id.integer' => 'The Course ID must be an integer.',
            'course_id.required' => 'The Course ID is required.',
            'counsellor_id.required' => 'The Counsellor ID is required.',
            'lead_id.required' => 'The Lead ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'course_id' => 'required|integer',
            'counsellor_id' => 'required', // Added validation for counsellor_id
            'lead_id' => 'required', // Added validation for lead_id
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract input values
        $course_id = $request->input('course_id');
        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');

        // Start timing
        $startTime = microtime(true);

        // Fetch branch and customer details
        $branch = StaffModel::where('sno', $counsellor_id)->first();
        if (!$branch) {
            return response()->json([
                'status' => 404,
                'message' => 'Counsellor not found',
                'data' => null,
            ], 200);
        }

        $branch_amount = BranchModel::where('sno', $branch->branch_id)->first();
        $customer = CustomerModel::where('lead_id', $lead_id)->first();
        if (!$customer) {
            $payment = 0;
        }else{
            $training = TrainingModel::where('customer_id', $customer->sno)->first();
            $payment = $training ? 1 : 0; // Set payment based on training existence
        }

        // Get course details
        $data = ManageCoursesModel::where('sno', $course_id)->where('status', 0)->first();
        if (!$data) {
            return response()->json([
                'status' => 404,
                'message' => 'Course not found',
                'data' => null,
            ], 200);
        }

        // Prepare response data
        $data = [
            'course_id' => $data->sno,
            'course_name' => $data->course_name,
            'course_duration' => $data->course_duration,
            'course_max_price' => $data->course_max_price,
        ];

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Course List',
            'error_msg' => null,
            'data' => $data,
            'Advance Amount' => $branch_amount->min_prd_cost ?? 0, // Handle potential null
            'Payment' => $payment,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }


    public function CourseOffer(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'course_id.integer' => 'The Course ID must be an integer.',
            'course_id.required' => 'The Course ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'course_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract input values
        $course_id = $request->input('course_id');

        // Start timing
        $startTime = microtime(true);

        // Get the course details
        $data = OfferzoneModel::where('offered_courses', $course_id)
            ->where('branch_id', 1)
            ->where('status', 0)
            ->get();

        if (!$data) {
            return response()->json([
                'status' => 404,
                'message' => 'Offer not found',
                'error_msg' => null,
                'data' => null,
                'execution_time' => (microtime(true) - $startTime) . ' seconds',
            ], 200);
        }

        // Define the base URL or path for images
        // $baseUrl = 'https://example.com/images/'; 
        // $baseUrl = 'http://192.168.3.132:8000/coupon_images/'; // Replace with your actual base URL or path
        $baseUrl = 'https://erp.elysium.academy/coupon_images/'; // Replace with your actual base URL or path

        // Prepare data for the response
        $responseData = $data->map(function ($item) use ($baseUrl) {
            return [
                'offer_id' => (string) $item->sno,
                'offer_name' => $item->offer_name,
                'offer_image' => $baseUrl . $item->coupon_image, // Construct the full URL for the image
                'offer_type' => $item->offer_type,
                'coupon_code' => $item->coupon_code,
                'offer_amount' => $item->offer_amount,
                'course_id' => $item->offered_courses,
                'offer_percent' => $item->offer_percent,
                'display_on_dashboard' => $item->display_on_dashboard,
            ];
        });

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Offers List',
            'error_msg' => null,
            'data' => $responseData,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }
    public function couponCode(Request $request)
    {
        // Define custom validation messages
        $messages = [
            // 'course_id.integer' => 'The Course ID must be an integer.',
            // 'course_id.required' => 'The Course ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            // 'coupon_code' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract input values
        // $course_id = $request->input('course_id');
        $coupon_code = $request->input('coupon_code');

        // Start timing
        $startTime = microtime(true);

        // Get the course details
        $data = OfferzoneModel::where('coupon_code', $coupon_code)
            ->where('branch_id', 1)
            ->where('status', 0)
            ->first();

        if (!$data) {
            return response()->json([
                'status' => 404,
                'message' => 'No Offer',
                'error_msg' => null,
                'data' => null,
                'execution_time' => (microtime(true) - $startTime) . ' seconds',
            ], 200);
        }

        // Define the base URL or path for images
        // $baseUrl = 'https://example.com/images/'; 
        // $baseUrl = 'http://192.168.3.132:8000/coupon_images/'; // Replace with your actual base URL or path
        $baseUrl = 'https://erp.elysium.academy/coupon_images/'; // Replace with your actual base URL or path

        // Prepare data for the response
        $responseData = [
            'offer_id' => $data->sno,
            'offer_name' => $data->offer_name,
            'offer_image' => $baseUrl . $data->coupon_image, // Construct the full URL for the image
            'offer_type' => $data->offer_type,
            'coupon_code' => $data->coupon_code,
            'offer_amount' => $data->offer_amount,
            'course_id' => $data->offered_courses,
            'offer_percent' => $data->offer_percent,
            'display_on_dashboard' => $data->display_on_dashboard,
        ];

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Offers List',
            'error_msg' => null,
            'data' => $responseData,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function Feedback()
    {
        $startTime = microtime(true);

        // Get feedback questions with status 0
        $courses = FeedbackQuestionModel::where('status', 0)
            ->orderBy('sno', 'asc')
            ->get()
            ->map(function ($item) {


                return [
                    'feedback_question_id' => strval($item->sno),
                    'feedback_question_name' => strval($item->feedback_question_name),
                    'feedback_question_option' => json_decode($item->feedback_question_option),
                ];
            });

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $courses,  // Return the structured data
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function FeedbackSave(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'data.required' => 'The data field is required.',
            'data.array' => 'The data field must be an array.',
            'lead_id.required' => 'The lead ID is required.',
            'lead_id.integer' => 'The lead ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'data' => 'required|array',
            'data.*.feedback_question_id' => 'required|integer',
            'data.*.feedback_question_option' => 'required|array',
            'lead_id' => 'required|integer',
            'counsellor_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        // Extract data from the request
        $data = $request->input('data');
        $lead_id = intval($request->input('lead_id'));
        $counsellor_id = intval($request->input('counsellor_id'));
        $rating = intval($request->input('rating'));
        $comments = $request->input('comments');
        $branch = StaffModel::where('sno', $counsellor_id)->first();
        // Start timing
        $startTime = microtime(true);

        foreach ($data as $item) {
            // Extract the options

            $feedback_question_id = intval($item['feedback_question_id']);
            $options = $item['feedback_question_option'];

            // Update or create the record
            CounsellorFeedbackSave::updateOrCreate(
                [
                    'lead_id' => $lead_id,
                    'feedback_question_id' => $feedback_question_id
                ],
                [
                    'branch_id' => $branch->branch_id,
                    'feedback_question_answer' => json_encode($options),
                    'counsellor_id' => $counsellor_id,
                    'rating' => $rating,
                    'comments' => $comments,
                    'created_by' => $counsellor_id,
                    'updated_by' => $counsellor_id
                ]
            );
        }

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Successfully saved',
            'error_msg' => null,
            'data' => 'Successfully',
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }
    public function OfferPage(Request $request)
    {
        // Start timing
        $startTime = microtime(true);

        // Get the offer details
        $offers = OfferzoneModel::where('branch_id', 1)
            ->where('status', 0)
            ->get();

        if ($offers->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No offers found',
                'error_msg' => null,
                'data' => null,
                'execution_time' => (microtime(true) - $startTime) . ' seconds',
            ], 200);
        }

        // Define the base URL or path for images
        // $baseUrl = 'http://192.168.3.132:8000/coupon_images/'; // Replace with your actual base URL or path
        $baseUrl = 'https://erp.elysium.academy/coupon_images/'; // Replace with your actual base URL or path

        // Prepare data for the response
        $responseData = $offers->map(function ($offer) use ($baseUrl) {
            return [
                'offer_id' => (string) $offer->sno,
                'offer_name' => $offer->offer_name,
                'offer_image' => $baseUrl . $offer->coupon_image, // Construct the full URL for the image
                'offer_type' => $offer->offer_type,
                'coupon_code' => $offer->coupon_code,
                'offer_amount' => $offer->offer_amount,
                'offer_percent' => $offer->offer_percent,
                'display_on_dashboard' => $offer->display_on_dashboard,
            ];
        });

        // End timing
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status' => 200,
            'message' => 'Offers List',
            'error_msg' => null,
            'data' => $responseData,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function BatchList(Request $request)
    {

        $counsellor_id               = $request->counsellor_id;

        $branch = StaffModel::where('za_staff.status', 0)->where('sno', $counsellor_id)->first();
        $startTime = microtime(true);
        $course = BatchModel::where('za_batch.status', 0)->where('za_batch.branch_id', $branch->branch_id)->select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.course_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time'
        )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->orderBy('za_batch.sno', 'desc')
            ->get()->map(function ($item) {
                $array = $item->toArray();
                // Decode the JSON field
                $array['slot_type_days'] = json_decode($array['slot_type_days'], true);

                // Convert other fields to strings, except 'slot_type_days'
                foreach ($array as $key => $value) {
                    if ($key !== 'slot_type_days') {
                        $array[$key] = strval($value);
                    }
                }

                return $array;
            });

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        return response([
            'status'    => 200,
            'message'   => "Batch List",
            'error_msg' => null,
            'data'      => $course,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    public function Payment(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'course_id' => 'required',
            'counsellor_id' => 'required'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'input format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $lead_id                     = $request->lead_id;
            $course_id                   = $request->course_id;
            $counsellor_id               = $request->counsellor_id;
            $offer_id                    = $request->offer_id;
            $gst                         = $request->gst;
            $amount                      = $request->amount;
            $user_id                     = $counsellor_id;


            $course =  ManageCoursesModel::where('sno', $course_id)->first();
            // Check if course_id is a single value and convert it to an array
            if (!is_array($course_id)) {
                $courseId = [$course_id];
            }

            // Convert the array to a JSON string
            $courseIdJson = json_encode($courseId);
            $branch_check = BranchModel::where('sno', 1)->orderBy('sno', 'desc')->first();

            $branch_code = $branch_check->city_short_code;

            $category_check = CustomerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $year = date("Y");
            if (!$category_check) {
                $customer_id = $year . '/' . $branch_code . '/' . "CUS0001";
            } else {
                $data = $category_check->customer_id;
                $slice = explode("/", $data);
                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number = (int)$resultcus + 1;
                $request_pay = sprintf("CUS%04d", $next_number);
                $customer_id = $year . '/' . $branch_code . '/' . $request_pay;
            }

            $lead =  LeadModel::where('sno', $lead_id)->first();
            // return  $course->fees_schedule;
            $customer = CustomerModel::updateOrCreate(
                ['lead_id' => $lead_id],
                [

                    'cus_name'             => ucfirst($lead->lead_name ?? null),
                    'branch_id'            => $branch_check->sno,
                    'customer_id'          => $customer_id,
                    'cus_gender'           => $lead->lead_gender ?? null,
                    'cus_dob'              => isset($lead->lead_dob) ?  $lead->lead_dob : null,
                    'cus_mobile'           => $lead->lead_mobile ?? null,
                    'cus_email_id'         => $lead->lead_email_id ?? null,
                    'cus_marital_status'   => $lead->lead_marital_status ?? null,
                    'address'              => $lead->address ?? null,
                    'coupon_code_ref'      => $offer_id,
                    'course_id'            => $courseIdJson ?? null,

                    'free_shd_count'       => $course->fees_schedule ?? null,
                    'cus_edcuation'        => '', // this appears to be intentionally empty
                    'status'               => 3,
                    'final_fee'            => $amount,
                    'created_by'           => $user_id,
                    'updated_by'           => $user_id,
                ]
                // return  $offer_id;
            );
            // return  $customer;
            // foreach ($allData['tableData'] as $row) {
            //     // Generate payment ID
            //     $pay_check = PaymentModel::orderBy('sno', 'desc')->first();
            //     $year = date("Y");
            //     if (!$pay_check) {
            //         $payment_auto_id = $year . '/' . $branch_code . '/' . "PAY0001";
            //     } else {
            //         $data = $pay_check->payment_id;
            //         $slice = explode("/", $data);
            //         $result = preg_replace('/[^0-9]/', '', $slice[2]);
            //         $next_number = (int)$result + 1;
            //         $request_pay = sprintf("PAY%04d", $next_number);
            //         $payment_auto_id = $year . '/' . $branch_code . '/' . $request_pay;
            //     }

            //     // Ensure $row is valid
            //     if (is_array($row)) {
            //         // Handle "N/A" for initialPayDate
            //         if ($row['initialPayDate'] === 'N/A') {
            //             $initialPayDateFormatted = now()->format('Y-m-d');
            //         } else {
            //             $initialPayDate = DateTime::createFromFormat('d-m-Y', $row['initialPayDate']);
            //             if ($initialPayDate === false) {
            //                 // Log invalid initialPayDate format

            //                 continue; // Skip this row or handle the error as needed
            //             }
            //             $initialPayDateFormatted = $initialPayDate->format('Y-m-d');
            //         }

            //         // Handle nextPayDate
            //         $nextPayDate = DateTime::createFromFormat('d-m-Y', $row['nextPayDate']);
            //         if ($nextPayDate === false) {
            //             // Log invalid nextPayDate format

            //             continue; // Skip this row or handle the error as needed
            //         }
            //         $nextPayDateFormatted = $nextPayDate->format('Y-m-d');

            //         // Determine payment status
            //         $status = $row['status'] === 'Paid' ? 1 : 0;

            //         // Update or create payment record
            //         PaymentModel::updateOrCreate(
            //             [
            //                 'payment_id'     => $payment_auto_id,
            //                 'customer_id'    => $customer->sno,
            //                 'course_id'      => $course_batch_hidden_id,
            //                 'initialPayDate' => $initialPayDateFormatted,
            //                 'nextPayDate' => $nextPayDateFormatted,
            //                 'amount' => $row['amount'],
            //                 'paidAmount' => $row['paidAmount'],
            //                 'balanceFee' => $row['balanceFee'],
            //                 'total_amount' => $allData['final_course_fees'],
            //                 'status' => $status,
            //                 'created_by' => $user_id,
            //                 'updated_by' => $user_id,
            //             ]
            //         );
            //     }
            // }
            if ($customer) {

                $lead_id           = $customer->lead_id;
                $upd_lead =  LeadModel::where('sno', $lead_id)->first();
                $upd_lead->status = 4;
                $upd_lead->pages  = 4;
                // dd($upd_lead);

                $upd_lead->update();

                return response()->json([
                    'status'    => 200,
                    'message'   => 'Customer added successfully',
                    'error_msg' => null,
                    'data'      => '',
                ], 200);
            } else {
                return response()->json([
                    'status'    => 400,
                    'message'   => 'Customer not added',
                    'error_msg' => null,
                    'data'      => null,

                ], 200);
            }
        }
    }

    // public function generateQrCode(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'lead_id' => 'required',
    //         'amount' => 'required|numeric',
    //         'counsellor_id' => 'required'
    //     ]);

    //     if ($validator->fails()) {
    //         return response([
    //             'status' => 401,
    //             'message' => 'Input format error in fields',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data' => null,
    //         ], 200);
    //     }

    //     $lead_id = $request->lead_id;
    //     $counsellor_id = $request->counsellor_id;
    //     $upi_amount = $request->amount;
    //     $upi_currency = 'INR';
    //     $upi_transaction_id = '1234560'; // Replace with your logic to generate a unique transaction ID
    //     $upi_payee_name = 'Counsellor';
    //     $upi_transaction_note = 'Payment for course';
    //     $apiKey = 'fc9b011f102ec3bc64b17ee86fd1b0cc'; // Replace with your actual API key

    //     try {
    //         // Send the POST request using multipart/form-data and include the Authorization header
    //         $response = Http::withHeaders([
    //             'Authorization' => 'Bearer ' . $apiKey, // Include your API key in the Authorization header
    //         ])->asMultipart()->post('https://qr.elysium.community/api/qr-codes', [
    //             'name'                   => 'Payment Request',
    //             'type'                   => 'upi',
    //             'upi_payee_name'         => $upi_payee_name,
    //             'upi_currency'           => $upi_currency,
    //             'upi_amount'             => $upi_amount,
    //             'upi_transaction_id'     => $upi_transaction_id,
    //             'upi_transaction_note'   => $upi_transaction_note,
    //         ]);

    //         if (!$response->successful()) {
    //             throw new \Exception("Failed to generate QR code. Response: " . $response->body());
    //         }

    //         // Parse the JSON response
    //         $qrCodeData = $response->json();

    //         if (!isset($qrCodeData['qr_code_url'])) {
    //             throw new \Exception("QR code URL not found in the response. Full Response: " . json_encode($qrCodeData));
    //         }

    //         $qrCodeUrl = $qrCodeData['qr_code_url'];

    //         return response()->json([
    //             'status' => 200,
    //             'message' => 'QR Code generated successfully',
    //             'error_msg' => null,
    //             'data' => $qrCodeUrl,
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 500,
    //             'message' => 'QR Code generation failed',
    //             'error_msg' => $e->getMessage(),
    //             'qr_code_url' => null,
    //         ], 500);
    //     }
    // }
    // public function generateQrCode(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'lead_id' => 'required',
    //         'amount' => 'required|numeric',
    //         'counsellor_id' => 'required'
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 401,
    //             'message' => 'Input format error in fields',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data' => null,
    //         ], 200);
    //     }

    //     $lead_id = $request->lead_id;
    //     $counsellor_id = $request->counsellor_id;
    //     $upi_amount = $request->amount;
    //     $upi_currency = 'INR';
    //     $upi_transaction_id = '1234560'; // Replace with your logic to generate a unique transaction ID
    //     $upi_payee_name = 'Counsellor';
    //     $upi_transaction_note = 'Payment for course';
    //     $apiKey = 'fc9b011f102ec3bc64b17ee86fd1b0cc'; // Replace with your actual API key

    //     try {
    //         // Send the POST request using multipart/form-data and include the Authorization header
    //         $response = Http::withHeaders([
    //             'Authorization' => 'Bearer ' . $apiKey, // Include your API key in the Authorization header
    //         ])->asMultipart()->post('https://qr.elysium.community/api/qr-codes', [
    //             'name'                   => 'Payment Request',
    //             'type'                   => 'upi',
    //             'upi_payee_name'         => $upi_payee_name,
    //             'upi_currency'           => $upi_currency,
    //             'upi_amount'             => $upi_amount,
    //             'upi_transaction_id'     => $upi_transaction_id,
    //             'upi_transaction_note'   => $upi_transaction_note,
    //         ]);

    //         if (!$response->successful()) {
    //             throw new \Exception("Failed to generate QR code. Response: " . $response->body());
    //         }

    //         // Parse the JSON response
    //         $qrCodeData = $response->json();

    //         if (!isset($qrCodeData['qr_code_url'])) {
    //             throw new \Exception("QR code URL not found in the response. Full Response: " . json_encode($qrCodeData));
    //         }

    //         // Assuming you need to return the ID of the generated QR code
    //         // Replace this with actual ID if available in response
    //         $qrCodeId = $qrCodeData['id'] ?? null;

    //         return response()->json([
    //             'data' => [
    //                 'id' => $qrCodeId,
    //             ],
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => 500,
    //             'message' => 'QR Code generation failed',
    //             'error_msg' => $e->getMessage(),
    //             'data' => null,
    //         ], 500);
    //     }
    // }
    public function generateQrCode(Request $request)
    {
        // Validate the input
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'amount' => 'required|numeric',
            'counsellor_id' => 'required'
        ]);

        // If validation fails, return an error response
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Input format error in fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        // Extract data from the request
        $lead_id = $request->lead_id;
        $counsellor_id = $request->counsellor_id;
        $upi_amount = $request->amount;
        $upi_currency = 'INR';
        // $upi_transaction_id = Str::uuid()->toString(); // Generate unique ID
        $upi_transaction_id = time() . mt_rand(1000, 9999); // Generates a unique number using timestamp and random digits
        $upi_payee_name = 'Counsellor';  // Replace with actual counsellor name if available
        $upi_transaction_note = 'Payment for course';

        // Construct the UPI payment URL
        $upiUrl = 'upi://pay?pa=counsellor@upi&pn=' . urlencode($upi_payee_name) .
            '&am=' . $upi_amount .
            '&cu=' . $upi_currency .
            '&tn=' . urlencode($upi_transaction_note) .
            '&tid=' . $upi_transaction_id;

        // Generate QR code URL using QRCode API
        $qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' . urlencode($upiUrl);

        // Return success response with the QR code URL
        return response()->json([
            'status' => 200,
            'message' => 'QR code generated successfully',
            'data' => [
                'lead_id'        => $lead_id,
                'counsellor_id'  => $counsellor_id,
                'transaction_id' => $upi_transaction_id,
                'qr_code_url'    => $qrCodeUrl, // This is the URL of the QR code image
            ]
        ]);
    }
    
    public function customerPayment(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'course_id' => 'required',
            'counsellor_id' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Input format incorrect for required fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        // Extracting the request data
        $lead_id           = $request->lead_id;
        $course_id         = $request->course_id;
        $counsellor_id     = $request->counsellor_id;
        $initial_pay       = $request->initial_pay;
        $total_payment     = $request->total_payment;
        $decimal_count_str = $request->decimal_count;

        $bal_payment       = $total_payment - $initial_pay;
        $user_id           = $counsellor_id;
        // return $request;
        // Parsing decimal_count into an array
        $decimal_count = $this->parseDecimalCount($decimal_count_str);

        // Fetching models
        $staff    = StaffModel::where('sno', $counsellor_id)->first();
        $course   = ManageCoursesModel::where('sno', $course_id)->first();
        $customer = CustomerModel::where('lead_id', $lead_id)->first();
        $branch_check = BranchModel::where('sno', $staff->branch_id)->orderBy('sno', 'desc')->first();

        // Generating branch code
        $branch_code = $branch_check->city_short_code;

        // Calculating initialPayDate based on min_prd_days and excluding Sundays
        $initialPayDate = now();
        $min_prd_days = $branch_check->min_prd_days;

        $nextPayDate = $initialPayDate->copy()->addDays($min_prd_days);
        while ($nextPayDate->isSunday()) {
            $nextPayDate->addDay();
        }
        $nextPayDateFormatted = $nextPayDate->format('Y-m-d');

        // Payment ID generation logic
        $pay_check = PaymentModel::orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$pay_check) {
            $payment_auto_id = $year . '/' . $branch_code . '/' . "PAY0001";
        } else {
            $data = $pay_check->payment_id;
            $slice = explode("/", $data);
            $result = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_number = (int)$result + 1;
            $request_pay = sprintf("PAY%04d", $next_number);
            $payment_auto_id = $year . '/' . $branch_code . '/' . $request_pay;
        }

        // Updating or creating the payment record
        PaymentModel::updateOrCreate(
            ['payment_id' => $payment_auto_id],
            [
                'customer_id'    => $customer->sno,
                'course_id'      => $course_id,
                'initialPayDate' => now()->format('Y-m-d'),
                'nextPayDate'    => $nextPayDateFormatted,
                'amount'         => $branch_check->min_prd_cost,
                'paidAmount'     => $initial_pay,
                'gst_amount'     => $initial_pay * 0.18,
                'balanceFee'     => $bal_payment,
                'total_amount'   => $total_payment,
                'status'         => 1,
                'created_by'     => $user_id,
                'updated_by'     => $user_id,
            ]
        );

        // Costing ID generation logic
        $cos_check = TrainingModel::orderBy('sno', 'desc')->first();
        if (!$cos_check) {
            $year = date("Y");
            $training_id = $year . '/' . $branch_code . '/' . "TRA0001";
        } else {
            $data = $cos_check->training_id;
            $slice = explode("/", $data);
            $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_number_cos = (int)$result_cos + 1;
            $request_cos = sprintf("TRA%04d", $next_number_cos);
            $year = date("Y");
            $training_id = $year . '/' . $branch_code . '/' . $request_cos;
        }

        // Updating or creating the costing record
        // TrainingModel::updateOrCreate(
        //     ['costing_id' => $training_id],
        //     [
        //         'customer_id'      => $customer->sno,
        //         'course_id'        => $course_id,
        //         'free_split_count' => $course->fees_schedule,
        //         'created_by'       => $user_id,
        //         'updated_by'       => $user_id,
        //     ]
        // );
        TrainingModel::updateOrCreate(
            [
                'training_id'     => $training_id,
                'branch_id'       => $branch_check->sno,
                'customer_id'     => $customer->sno,
                'course_id'       => $course_id, // Use the normal course_id
                'batch_id'        => $batch_id->sno ?? 0,
                'slot_id'         => $batch_id->slot_id ?? null,
                'staff_id'        => $batch_id->staff_id ?? null,
                'start_date'      => $batch_id->start_date ?? null,
                'end_date'        => $batch_id->end_date ?? null,
                'overall_fees'    => $total_payment,
                'gst_amount'      => $total_payment * 0.18, // Calculate GST for overall fees
                'disc_amount'     => 0, // No discount set
                'paid_amount'     => $initial_pay,
                'paid_gst'        => $initial_pay * 0.18,
                'total_amount'    => $initial_pay + $initial_pay * 0.18,
                'balance_amount'  => $total_payment - $initial_pay,
                'balance_gst'     => $total_payment - $initial_pay * 0.18,
                'payment_id'      => $payment_auto_id ?? null,
                'created_by'      => $user_id,
                'updated_by'      => $user_id,
            ]
        );
        $batch_id = ["0"];
        // Updating customer status
        $customer_cos = CustomerModel::updateOrCreate(
            ['lead_id' => $lead_id],
            [
                'status'        => 0,
                'batch_id'        => json_encode($batch_id),
                'decimal_count' => json_encode($decimal_count), // Store as JSON if needed
                'updated_by'    => $user_id,
            ]
        );
        if ($customer_cos) {
            $lead_id           =  $lead_id;
            $upd_lead          =  LeadModel::where('sno', $lead_id)->first();
            $upd_lead->pages   = 5;
            $upd_lead->save();
        }
        return response()->json([
            'status'    => 200,
            'message'   => 'Customer Payment successfully processed',
            'error_msg' => null,
            'data'      => '',
        ], 200);
    }

    /**
     * Helper function to parse the decimal_count string into an array.
     */
    private function parseDecimalCount($decimal_count_str)
    {
        $parsed_array = [];
        $items = explode(',', $decimal_count_str);

        foreach ($items as $item) {
            list($value, $count) = explode('*', $item);
            $parsed_array[] = [
                'value' => (int)$value,
                'count' => (int)$count
            ];
        }

        return $parsed_array;
    }




    public function BatchSave(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'course_id' => 'required',
            'batch_id'     => 'required',
            'counsellor_id' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'    => 401,
                'message'   => 'Input format incorrect for required fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        // Extracting the request data
        $lead_id       = $request->lead_id;
        $course_id     = $request->course_id;
        $batch_id      = $request->batch_id;
        $counsellor_id = $request->counsellor_id;
        $user_id       = $counsellor_id;

        // Fetching models
        $batch    = BatchModel::where('sno', $batch_id)->first();
        $customer = CustomerModel::where('lead_id', $lead_id)->first();

        if (!$batch || !$customer) {
            return response()->json([
                'status'    => 404,
                'message'   => 'Batch or Customer not found',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }

        $branch_check = BranchModel::where('sno', $batch->staff_id)->orderBy('sno', 'desc')->first();

        // Updating or creating the costing record
        $cos_check = TrainingModel::updateOrCreate(
            [
                'customer_id' => $customer->sno,
                'course_id'   => $course_id,
            ],
            [
                'batch_id'    => $batch_id,
                'slot_id'     => $batch->slot_id,
                'staff_id'    => $batch->staff_id,
                'start_date'  => $batch->start_date ?? null,
                'end_date'    => $batch->end_date ?? null,
                'created_by'  => $user_id,
                'updated_by'  => $user_id,
            ]
        );
        if ($cos_check) {
            $lead_id           = $lead_id;
            $upd_lead          =  LeadModel::where('sno', $lead_id)->first();
            $upd_lead->pages   = 7;
            $upd_lead->save();
            
            $batch_id_arr = $cos_check->batch_id;
    
            // Ensure batch_id is in an array format
            if (!is_array($batch_id_arr)) {
                $batch_id_arr = [$batch_id_arr];
            }
            if (empty($batch_id_arr) || $batch_id_arr === [null]) {
                $batch_id_arr = ["0"];
            }
            // Convert the batch ID array to a JSON string
            $batchIdJson = json_encode($batch_id_arr);
    
            // Update or create the customer record with the batch_id
            $customer = CustomerModel::updateOrCreate(
                ['sno' => $cos_check->customer_id,],
                [
                    'batch_id' => $batchIdJson ?? null,
                ]
            );
        }
        if ($cos_check) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Batch saved successfully',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response()->json([
                'status'    => 400,
                'message'   => 'Batch could not be saved',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function TrackList(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'counsellor_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        $counsellor_id = $request->input('counsellor_id');
        $startTime = microtime(true);

        // Get the track list from the model
        $tracklist = CustomerModel::where('status', '!=', 2)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->get();
        // return $tracklist;
        // Transform the data to the desired format
        $responseData = $tracklist->map(function ($track) {
            // Access properties directly as they are objects
            return [
                'lead_id'     => (string) $track->lead_id,
                'lead_name'   => $track->cus_name,
                'lead_mobile' => $track->cus_mobile,
                'lead_gender' => $track->cus_gender,
                'student_status'      => (string) $track->status,
                'pages'       => $track->pages,
            ];
        });

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        return response([
            'status'          => 200,
            'message'         => "Track List",
            'error_msg'       => null,
            'data'            => $responseData,
            'execution_time'  => $executionTime . ' seconds'
        ], 200);
    }


    public function TrackView(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'lead_id.required' => 'The Lead ID is required.',
            'counsellor_id.required' => 'The counsellor ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'counsellor_id' => 'required',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        $lead_id = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');
        $startTime = microtime(true);

        // Get the track list from the model
        $tracklist = CustomerModel::where('status', '!=', 2)
            ->where('lead_id', $lead_id)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->first();

        // Check if tracklist is found
        if (!$tracklist) {
            return response()->json([
                'status' => 404,
                'message' => 'Tracklist not found',
                'data' => null,
            ], 200);
        }

        $payment = PaymentModel::where('status', '!=', 2)
            ->where('customer_id', $tracklist->sno)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->pluck('paidAmount')
            ->sum();

        $lead = LeadModel::where('status', '!=', 2)
            ->where('sno', $lead_id)
            ->orderBy('sno', 'desc')
            ->first();

        // Check if lead is found
        if (!$lead) {
            return response()->json([
                'status' => 404,
                'message' => 'Lead not found',
                'data' => null,
            ], 200);
        }

        $app = AppointmentModel::where('status', '!=', 2)
            ->where('lead_id', $lead_id)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->first();

        $coupon = OfferzoneModel::where('status', '!=', 2)
            ->where('sno', $tracklist->coupon_code_ref ?? null)
            ->orderBy('sno', 'desc')
            ->first();

        $staff = StaffModel::where('status', '!=', 2)
            ->where('sno', $app->staff_id ?? null)
            ->orderBy('sno', 'desc')
            ->first();

        $course = ManageCoursesModel::where('status', 0)
            ->whereIn('sno', json_decode($tracklist->course_id))
            ->orderBy('sno', 'desc')
            ->first();

        // Prepare response data
        $responseData = [
            'lead_id'     => (string) $tracklist->sno,
            'lead_name'   => $tracklist->cus_name,
            'lead_mobile' => $tracklist->cus_mobile,
            'lead_gender' => $tracklist->cus_gender,
            'address'     => $tracklist->address,
            'discount_fee' => (int)$tracklist->final_fee,
        ];

        $responseDatacourse = [
            'course_id'     => (string) ($course->sno ?? 'N/A'),
            'course_name'   => $course->course_name ?? 'N/A',
            'hours'         => (string) ($course->course_duration ?? 'N/A'),
            'actual_fee'    => (string) ($course->course_max_price ?? 'N/A'),
            'paid_fee'      => (string) $payment,
        ];

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        return response()->json([
            'status'          => 200,
            'message'         => "Track View",
            'error_msg'       => null,
            'lead'            => $responseData,
            'course'          => $responseDatacourse,
            'staff_name'      => $staff->staff_name ?? null,
            'coupon'          => $coupon->coupon_code ?? null,
            'Page'            => $lead->pages ?? null,
            'execution_time'  => $executionTime . ' seconds'
        ], 200);
    }



    public function StaffList(Request $request)
    {
        
         $counsellor_id = $request->input('counsellor_id');
          $roleId       = StaffModel::where('status', 0)->where('sno', $counsellor_id)->first();
            $branch_check = BranchModel::where('sno', $roleId->branch_id)->orderBy('sno', 'desc')->first();
        $staff = StaffModel::where('status', 0)->where('branch_id', $branch_check->sno)->select('staff_name', 'sno as staff_id')
            ->orderBy('staff_name', 'asc')->get();
        // ->where( 'branch_id', self::$branch_id )
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }

    public function CourseList()
    {

        $startTime = microtime(true);
        $course = ManageCoursesModel::where('za_course.status', 0)
            ->select('course_name', 'course_id', 'course_max_price as fees', 'course_duration as hours', 'course_desc', 'za_course_subcategory.course_subcategory_name')

            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->orderBy('za_course.sno', 'desc')
            ->get()->map(function ($item) {
                $array = $item->toArray();
                return array_map('strval', $array);
            });
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $course,
            'execution_time' => $executionTime . ' seconds'
        ], 200);
    }

    // public function AppointmentList(Request $request)
    // {
    //     // Define custom validation messages
    //     $messages = [
    //         'counsellor_id.integer' => 'The counsellor ID must be an integer.',
    //         'counsellor_id.required' => 'The counsellor ID is required.',
    //     ];

    //     // Create a validator instance
    //     $validator = Validator::make($request->all(), [
    //         'counsellor_id' => 'required|integer',
    //     ], $messages);

    //     // Check if validation fails
    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 401,
    //             'message' => 'Invalid input fields',
    //             'error_msg' => $validator->messages()->all(),
    //             'data' => null,
    //         ], 200);
    //     }

    //     $counsellor_id = $request->input('counsellor_id');
    //     $startTime = microtime(true);

       
    //     $tracklist = LeadAppointmentModel::where('za_lead_appointment.status', '!=', 2)
    //         ->where('za_lead_appointment.created_by', $counsellor_id)
    //         ->leftjoin('za_customer', 'za_lead_appointment.lead_id', '=', 'za_customer.lead_id')
    //         ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
    //         ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
    //         ->where('za_lead.status', '!=', [1, 2])
    //         ->where(
    //             'za_staff.status',
    //             '!=',
    //             [1, 2]
    //         )
    //         ->orderBy('za_lead_appointment.sno', 'desc')
    //         ->select('za_lead_appointment.sno', 'za_lead_appointment.lead_id', 'za_lead.lead_name', 'za_lead.lead_mobile', 'za_lead_appointment.demo_type', 'za_lead_appointment.appointment_date', 'za_lead_appointment.appointment_time', 'za_staff.staff_name', 'za_lead_appointment.reason')
    //         ->groupBy('za_lead_appointment.sno', 'za_lead_appointment.lead_id', 'za_lead.lead_name', 'za_lead.lead_mobile', 'za_lead_appointment.demo_type', 'za_lead_appointment.appointment_date', 'za_lead_appointment.appointment_time', 'za_staff.staff_name', 'za_lead_appointment.reason')
    //         ->get();


    //     // return $tracklist;
    //     // Transform the data to the desired format
    //     $responseData = $tracklist->map(function ($track) {
    //         // Access properties directly as they are objects
    //         return [
    //             'lead_id'          => (string) $track->lead_id,
    //             'lead_name'        => $track->lead_name,
    //             'lead_mobile'      => (string) $track->lead_mobile,
    //             'appointment_date' => (string) $track->appointment_date,
    //             'appointment_time' => (string) $track->appointment_time,
    //             'demo_type'        => $track->demo_type,
    //             'reason'           => $track->reason,
    //             'staff_name'       => $track->staff_name,
    //         ];
    //     });

    //     $endTime = microtime(true);
    //     $executionTime = $endTime - $startTime;

    //     return response([
    //         'status'          => 200,
    //         'message'         => "App List",
    //         'error_msg'       => null,
    //         'data'            => $responseData,
    //         'execution_time'  => $executionTime . ' seconds'
    //     ], 200);
    // }
    

    public function AppointmentList(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
        ];
    
        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'counsellor_id' => 'required|integer',
        ], $messages);
    
        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }
    
        $counsellor_id = $request->input('counsellor_id');
        $startTime = microtime(true);
    
        $tracklist = LeadAppointmentModel::where('za_lead_appointment.status', '!=', 2)
            ->where('za_lead_appointment.created_by', $counsellor_id)
            ->leftJoin('za_customer', 'za_lead_appointment.lead_id', '=', 'za_customer.lead_id')
            ->join('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
            ->join('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->whereNotIn('za_lead.status', [1, 2])
            ->whereNotIn('za_lead.status', [1, 2])
            ->whereNotIn('za_staff.status', [1, 2])
            ->orderBy('za_lead_appointment.sno', 'desc')
            ->select(
                'za_lead_appointment.sno',
                'za_lead_appointment.lead_id',
                'za_lead.lead_name',
                'za_lead.lead_mobile',
                'za_lead_appointment.appointment_category as demo_type',   // ✅ corrected
                'za_lead_appointment.appointment_date',                    // ✅ has datetime
                'za_staff.staff_name',
                'za_lead_appointment.convo_message as reason'              // ✅ corrected
            )
            ->get();
    
        // Transform the data to the desired format
        $responseData = $tracklist->map(function ($track) {
            $dt = Carbon::parse($track->appointment_date);
    
            return [
                'lead_id'          => (string) $track->lead_id,
                'lead_name'        => $track->lead_name,
                'lead_mobile'      => (string) $track->lead_mobile,
                'appointment_date' => $dt->format('Y-m-d'),   // ✅ only date
                'appointment_time' => $dt->format('H:i:s'),   // ✅ only time
                'demo_type'        => $track->demo_type,
                'reason'           => $track->reason,
                'staff_name'       => $track->staff_name,
            ];
        });
    
        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;
    
        return response([
            'status'          => 200,
            'message'         => "App List",
            'error_msg'       => null,
            'data'            => $responseData,
            'execution_time'  => $executionTime . ' seconds'
        ], 200);
    }



    public function Dashboard(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'counsellor_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        $counsellor_id = $request->input('counsellor_id');
        $branch = StaffModel::where('sno', $counsellor_id)->first();
        $startTime = microtime(true);

        $courseCount = ManageCoursesModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->count();


        $offerzone = OfferzoneModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->count();

        $appointment = AppointmentModel::where('za_appointment.status', '!=', 2)
            ->where('za_appointment.appointment_date', '=', date('Y-m-d'))
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->count();
        $leadCount = LeadModel::where('status', 0)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->count();
        $customerCount = CustomerModel::where('status', 0)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->count();


        // return $tracklist;

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        return response([
            'status'          => 200,
            'message'         => "Dashboard List",
            'error_msg'       => null,
            'Course Count'    => $courseCount,
            'Offer Count'     => $offerzone,
            'Appointment Count'    => $appointment,
            'execution_time'  => $executionTime . ' seconds'
        ], 200);
    }

    public function leadList(Request $request)
    {

        // Define custom validation messages
        $messages = [
            'counsellor_id.integer' => 'The counsellor ID must be an integer.',
            'counsellor_id.required' => 'The counsellor ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'counsellor_id' => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        $counsellor_id = $request->input('counsellor_id');
        $staff = LeadModel::where('status', 0)->where('created_by', $counsellor_id)
            ->select('lead_name', 'sno as lead_id')
            ->orderBy('sno', 'asc')->get();
        // ->where( 'branch_id', self::$branch_id )
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $staff,
        ], 200);
    }
    
    public function appUpdateCheck(Request $request)
  {
    return response()->json([
      'status' => 200,
      'message' => 'Data Retrieved Successfully',
      'data' => [
        'app_name'       => 'Guidy',
        'play_store_id'  => 'com.eapl.guidyapp',
        'apple_id'       => '',
        'android'        => '1.0.6',
        'android_build'  => 6,
        'ios'            => '',
        'ios_build'      => 0,
      ]
    ], 200);
  }
  
    // public function Report(Request $request)
    // {
    //     // Define custom validation messages
    //     $messages = [
    //         'lead_id.required' => 'The Lead ID is required.',
    //         'counsellor_id.required' => 'The counsellor ID is required.',
    //     ];

    //     // Create a validator instance
    //     $validator = Validator::make($request->all(), [
    //         'counsellor_id' => 'required|integer',
    //         'lead_id'       => 'required|integer',
    //     ], $messages);

    //     // Check if validation fails
    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 401,
    //             'message' => 'Invalid input fields',
    //             'error_msg' => $validator->messages()->all(),
    //             'data' => null,
    //         ], 200);
    //     }
    //     $lead_id       = $request->input('lead_id');
    //     $counsellor_id = $request->input('counsellor_id');

    //     $startTime = microtime(true);

    //     $branch = StaffModel::where('sno', $counsellor_id)->first();

    //     $assessment = CounsellorAssessmentSave::where('status', 0)
    //         ->where('lead_id', $branch->lead_id)
    //         ->where('branch_id', $branch->branch_id)
    //         ->where('created_by', $counsellor_id)
    //         ->orderBy('sno', 'desc')
    //         ->get();

    //     $Common = CounsellorCourseSave::where('status', 0)
    //         ->where('lead_id', $branch->lead_id)
    //         ->where('branch_id', $branch->branch_id)
    //         ->where('created_by', $counsellor_id)
    //         ->orderBy('sno', 'desc')
    //         ->get();

    //     $feedback = CounsellorFeedbackSave::where('status', 0)
    //         ->where('lead_id', $branch->lead_id)
    //         ->where('branch_id', $branch->branch_id)
    //         ->where('created_by', $counsellor_id)
    //         ->orderBy('sno', 'desc')
    //         ->get();


    //     foreach ($assessment as $key => $value) {
    //         $value->assessment_question_name = SelfAssessmentModel::where('sno', $value->assessment_question_id)->first()->assessment_question_name;
    //         $value->assessment_question_option = SelfAssessmentModel::where('sno', $value->assessment_question_id)->first()->assessment_question_option;
    //     }

    //     foreach ($Common as $key => $value) {
    //         $value->category_question_name = CategoryQuestionModel::where('sno', $value->course_question_id)->first()->category_question_name;
    //         $value->category_question_option = CategoryQuestionModel::where('sno', $value->course_question_id)->first()->category_question_option;
    //     }

    //     foreach ($feedback as $key => $value) {
    //         $value->feedback_question_name = FeedbackQuestionModel::where('sno', $value->feedback_question_id)->first()->feedback_question_name;
    //         $value->feedback_question_option = FeedbackQuestionModel::where('sno', $value->feedback_question_id)->first()->feedback_question_option;
    //     }


    //     return $assessment;

    //     $endTime = microtime(true);
    //     $executionTime = $endTime - $startTime;

    //     return response([
    //         'status'          => 200,
    //         'message'         => "Report List",
    //         'error_msg'       => null,
    //         'Assessment'      => $assessment,
    //         'Common Question' => $Common,
    //         'Feedback'        => $feedback,
    //         'execution_time'  => $executionTime . ' seconds'
    //     ], 200);
    // }
    
    
    
    public function Report(Request $request)
    {
        // Define custom validation messages
        $messages = [
            'lead_id.required' => 'The Lead ID is required.',
            'counsellor_id.required' => 'The Counsellor ID is required.',
        ];

        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'counsellor_id' => 'required|integer',
            'lead_id'       => 'required|integer',
        ], $messages);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Invalid input fields',
                'error_msg' => $validator->messages()->all(),
                'data' => null,
            ], 200);
        }

        $lead_id       = $request->input('lead_id');
        $counsellor_id = $request->input('counsellor_id');

        $startTime = microtime(true);

        // Fetch the branch information
        $branch = StaffModel::where('sno', $counsellor_id)->first();

        if (!$branch) {
            return response()->json([
                'status' => 404,
                'message' => 'Branch not found for the given counsellor',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        // Fetch assessments, common questions, and feedback
        $assessment = CounsellorAssessmentSave::where('status', 0)
            ->where('lead_id', $lead_id)
            ->where('branch_id', $branch->branch_id)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->get();

        $common = CounsellorCourseSave::where('status', 0)
            ->where('lead_id', $lead_id)
            ->where('branch_id', $branch->branch_id)
            ->where('created_by', $counsellor_id)
            ->orderBy('sno', 'desc')
            ->get();

        $feedback = CounsellorFeedbackSave::where('status', 0)
            ->where('lead_id', $lead_id)
            ->where('branch_id', $branch->branch_id)
            ->where('created_by', $counsellor_id)
            ->select('sno', 'branch_id', 'lead_id', 'feedback_question_id', 'feedback_question_answer', 'counsellor_id', 'rating')
            ->orderBy('sno', 'desc')
            ->get();
        // return $common;
        // Fetch related question names and options in bulk
        $assessmentQuestionIds = $assessment->pluck('assessment_question_id')->unique();
        $courseQuestionIds = $common->pluck('course_question_id')->unique();
        $feedbackQuestionIds = $feedback->pluck('feedback_question_id')->unique();

        $assessmentQuestions = SelfAssessmentModel::whereIn('sno', $assessmentQuestionIds)->get()->keyBy('sno');
        $courseQuestions = CourseQuestionModel::whereIn('sno', $courseQuestionIds)->get()->keyBy('sno');
        $feedbackQuestions = FeedbackQuestionModel::whereIn('sno', $feedbackQuestionIds)->get()->keyBy('sno');

        // Attach question names and options
        foreach ($assessment as $item) {
            $question = $assessmentQuestions->get($item->assessment_question_id);
            $item->assessment_question_name = $question ? $question->assessment_question_name : 'N/A';
            // $item->assessment_question_option = $question ? json_decode($question->assessment_question_option) : 'N/A';
            if ($question && $question->assessment_question_option) {
                $options = json_decode($question->assessment_question_option, true);
                $item->assessment_question_option = array_map(function ($option) {
                    return $option['value'];
                }, $options);
            } else {
                $item->assessment_question_option = 'N/A';
            }
            $item->assessment_question_type = $question ? $question->assessment_question_type : 'N/A';
            $item->assessment_question_answer = json_decode($item->assessment_question_answer, true);
        }

        foreach ($common as $item) {
            $question = $courseQuestions->get($item->course_question_id);
            $item->course_question_name = $question ? $question->course_question_name : 'N/A';
            // $item->category_question_option = $question ? json_decode($question->category_question_option) : 'N/A';
            if ($question && $question->course_question_option) {
                $options = json_decode($question->course_question_option, true);
                $item->course_question_option = array_map(function ($option) {
                    return $option['value'];
                }, $options);
            } else {
                $item->course_question_option = 'N/A';
            }
            $item->course_question_type = $question ? $question->course_question_type : 'N/A';
            $item->course_question_answer = json_decode($item->course_question_answer, true);
        }

        foreach ($feedback as $item) {
            $question = $feedbackQuestions->get($item->feedback_question_id);
            $item->feedback_question_name = $question ? $question->feedback_question_name : 'N/A';
            if ($question && $question->feedback_question_option) {
                $options = json_decode($question->feedback_question_option, true);
                $item->feedback_question_option = array_map(function ($option) {
                    return $option['value'];
                }, $options);
            } else {
                $item->feedback_question_option = 'N/A';
            }
            $item->feedback_question_type = $question ? $question->feedback_question_type : 'N/A';
            $item->feedback_question_answer = json_decode($item->feedback_question_answer, true);
        }

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Return the response
        return response()->json([
            'status'          => 200,
            'message'         => "Report List",
            'error_msg'       => null,
            'Assessment'      => $assessment,
            'CommonQuestions' => $common,
            'Feedback'        => $feedback,
            'execution_time'  => $executionTime . ' seconds'
        ], 200);
    }


    public function CounsellorLogout(Request $request)
    {
        try {
            $user = $request->user()->token()->revoke();
            if ($user) {
                $response = [
                    'status' => 200,
                    'message' => 'You have been successfully logged out!',
                    'error_msg' => null,
                    'data' => null
                ];
                return response($response, 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'User Not Found',
                    'error_msg' => null,
                    'data' => null
                ], 500);
            }
        } catch (\Throwable $th) {
            return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
        }
    }
}