<?php

namespace App\Http\Controllers\ai_suggestion;

use App\Http\Controllers\Controller;
use App\Models\MarketingKitModel;
use App\Models\VariableModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\AISuggestionModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use App\Services\ChatGPTService;
use Carbon\Carbon;
use App\Models\GoalSetTeamModel;
use App\Models\ManageTargetModel;
use App\Helpers\Helpers;
class AISuggestion extends Controller
{
  protected $chatGPTService;

  public function __construct(ChatGPTService $chatGPTService)
  {
    $this->chatGPTService = $chatGPTService;
  }
  public function index()
  {
    $suggestions = [
      'Sales Suggestion',
      'Sales Team Suggestion',
      'Sales Executive Suggestion',
      'Production Suggestion',
      'Production Team Suggestion',
      'Production Executive Suggestion',
      'Customer Care Suggestion',
      'Placement Suggestion',
      'Business Suggestion',
      'Management Suggestion',
  ];
     // Fetch distinct role_ids that have suggestions in history
      $historyRoleIds = DB::table('za_ai_suggestion')
      ->where('status', 1) // optional filter if you use status
      ->distinct()
      ->pluck('role_id')
      ->toArray();
      return view('content.ai_suggestion.ai_suggestion', compact('suggestions', 'historyRoleIds'));
  }
  public function getExecutives(Request $request)
  {
    $branch_id = $request->user()->branch_id;
      $department = $request->department_id;
      $roleId = $request->role_id;
      $executives = StaffModel::where('role_id', $roleId)
                        ->where('department_id', $department)
                        ->where('branch_id', $branch_id)
                        ->get(['sno', 'staff_name']);

      return response()->json($executives);
  }
 public function getActions(Request $request)
    {
        // Fetch all actions from the 'za_ai_sugg' table
        $actions = DB::table('za_ai_sugg')->get();
    
        // Return the result as a JSON response
        return response()->json($actions);
    }

    //   public function Suggestion(Request $request)
    // {
    //     $category = $request->input('category');
    //     $suggestion = 'No suggestion generated.';
    //     $userId = auth()->id(); // Or set manually if needed
    //     $now = now();
    //     $branch_id = $request->user()->branch_id;
    //     // Dynamically find role_id from UserRoleModel by name match
    //     $role = UserRoleModel::where('user_role', 'LIKE', '%' . $category . '%')->first();
    //     $branch = BranchModel::where('sno',$branch_id )->first();
    //     //branch_type 1 means branch_name if 2 means franchise_name
    //     if ($role) {
    //         // Get staff under this role
    //         $staff = StaffModel::where('role_id', $role->sno)->where('branch_id', $branch_id)->pluck('name')->toArray();
    //         if($role->sno == 11){ // we need send there performance how they performent this month cc,abv,acv,lead like that this data and next how to they improve and achive there skil to get more achivement

    //           $salesStaff = DB::table('za_staff')
    //           ->select(
    //               'za_staff.sno',
    //               'za_staff.staff_name',
    //               'za_staff.staff_image',
    //               'za_staff.gender',
    //               'za_staff.mobile_no',
    //               'za_staff.lead_bank_count',
    //               'za_staff.status as staff_status'
    //           )
    //           ->where('role_id', $role->sno)
    //           ->where('za_staff.branch_id', $branch_id)
    //           ->where(function($query) use ($year, $month) {
    //               // Add conditions for status 4
    //               $query->where(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 4)
    //                           ->whereYear('za_staff.notice_end_date', '>=', $year)
    //                           ->whereMonth('za_staff.notice_end_date', '>=', $month);
    //                   })
    //                   // Add conditions for status 5
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 5)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                   })
    //                   // Add conditions for status 6
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 6)
    //                           ->whereYear('za_staff.staff_last_date', '>=', $year)
    //                           ->whereMonth('za_staff.staff_last_date', '>=', $month);
    //                   })
    //                   // Add conditions for status 7
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 7)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                   })
    //                   // Include status 0 regardless of date
    //                   ->orWhere('za_staff.status', 0);
    //           });

    //       if ($lead_fill != '') {
    //           $salesStaff->where(function ($query) use ($lead_fill) {
    //               $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
    //                   ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
    //                   ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
    //                   ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
    //           });
    //       }
    //         $total_staff=$salesStaff->count();
    //         $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);


    //         $totalconvertRatio     = 0;
    //         $totalSpamLeadRatio     = 0;
    //         $totalDeadLeadRatio     = 0;

    //         $totalAllPayment             = 0;
    //         $totalAllPaidPayment        = 0;

    //         foreach ($salesStaff as $staff) {


    //             $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
    //             ->where('za_lead.created_by', $staff->sno)
    //             ->where('za_lead.branch_id', $branch_id)
    //             ->whereYear('za_lead.registered_date', $year)
    //             ->whereMonth('za_lead.registered_date', $month)
    //             ->whereNotIn('za_lead.status',[2,6])
    //             ->where('za_lead.spam_verified',0)
    //             ->where('za_lead.internal_status',0)
    //             ->count();


    //             $customerConvertCount = CustomerModel::select('za_customer.sno')->where('za_customer.status', 0)
    //             ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //             ->where('za_customer.branch_id', $branch_id)
    //             ->where('za_customer.status', 0)
    //             ->where('za_lead.created_by', $staff->sno)
    //             ->whereYear('za_customer.created_at', $year)
    //             ->whereMonth('za_customer.created_at', $month)
    //             ->count();

    //             $spamLeadCount = DB::table('za_lead')->select('za_lead.sno')
    //             ->whereYear('za_lead.registered_date', $year)
    //             ->whereMonth('za_lead.registered_date', $month)
    //             ->where('za_lead.created_by', $staff->sno)
    //             ->where('za_lead.spam_verified',1)
    //             ->where('za_lead.branch_id', $branch_id)
    //             ->where('za_lead.status', 7)->count();

    //             $deadLeadCount = DB::table('za_lead')->select('za_lead.sno')
    //                 ->whereYear('za_lead.registered_date', $year)
    //                 ->whereMonth('za_lead.registered_date', $month)
    //                 ->where('za_lead.created_by', $staff->sno)
    //                 ->where('za_lead.branch_id', $branch_id)
    //                 ->where('za_lead.status', 5)->count();



    //             $currentMonthCustomerCount = 0;
    //             $total_business_amount     = 0;
    //             $total_payment             = 0;
    //             $total_paid_payment        = 0;
    //             $averageBusinessValue      = 0;
    //             $averageCollectionValue    = 0;

    //             // if ($customerConvertCount > 0) {
    //             //     $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
    //             //         ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //             //         ->where('za_customer.branch_id', $branch_id)
    //             //         ->where('za_customer.status', 0)
    //             //         ->where('za_lead.created_by', $staff->sno)
    //             //         ->whereYear('za_customer.created_at', $year)
    //             //         ->whereMonth('za_customer.created_at', $month)
    //             //         ->get();

    //             //     if ($currentMonthCustomer->isNotEmpty()) {
    //             //           foreach ($currentMonthCustomer as $customer) {

    //             //             $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
    //             //                           ->where('za_training.customer_id', $customer->sno)
    //             //                           ->where('za_training.tesbo_check', 0)
    //             //                           ->sum('za_training.overall_fees');

    //             //             $total_payment += $payment;


    //             //             $latestTraining = DB::table('za_training')
    //             //                 ->where('customer_id', $customer->sno)
    //             //                 ->where('tesbo_check', 2)
    //             //                 ->orderByDesc('sno')
    //             //                 ->first();

    //             //             if ($latestTraining) {
    //             //                 $total_payment += $latestTraining->overall_fees;
    //             //             }

    //             //             $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno','za_training.customer_id')
    //             //                               ->where('za_training.customer_id', $customer->sno)
    //             //                               ->sum('za_training.paid_amount');

    //             //             $total_paid_payment += $paid_payment;

    //             //           }
    //             //       }


    //             //     // average
    //             //     $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    //             //     $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;
    //             //     $totalAllPayment +=$total_payment;
    //             //     $totalAllPaidPayment +=$total_paid_payment;
    //             // }

    //             $staff->allLeadCount           = $allLeadCount;
    //             $staff->monthLeadCount       = $monthLeadCount;
    //             $staff->hotLeadCount        = $hotLeadCount;
    //             $staff->customerConvertCount      = $customerConvertCount;
    //             $staff->spamLeadCount            = $spamLeadCount;
    //             $staff->deadLeadCount      = $deadLeadCount;
    //             $staff->spam_lead_ratio            = $spam_lead_ratio;
    //             $staff->dead_lead_ratio      = $dead_lead_ratio;
    //             $staff->convertion_rate   = $convertion_rate;
    //             $staff->averager_convertion_rate   = $averager_convertion_rate;
    //             $staff->averageBusinessValue = $averageBusinessValue;
    //             $staff->averageCollectionValue    = $averageCollectionValue;

    //         }

    //         }
    //         //we need to send  $branch->name ,branch_type 1 means branch_name if 2 means franchise_name
    //         // Build AI prompt
    //         $prompt = "As a business AI assistant, suggest one actionable improvement idea for the {$category}.";
    //         if (!empty($staff)) {
    //             $prompt .= "\nHere are the current team members:\n" . implode(', ', $staff) . ".";
    //         }
    //         $prompt .= "\nYour suggestion should be practical and performance-focused.";

    //         // Get AI response
    //         $response = $this->chatGPTService->ask($prompt);
    //         $suggestion = $response ?: $suggestion;

    //         // Save to database
    //         AISuggestionModel::create([
    //             'date'               => $now->format('Y-m-d'),
    //             'suggestion_content' => $suggestion,
    //             'role_id'            => $role->sno,
    //             'created_by'         => $userId,
    //             'updated_by'         => $userId,
    //             'status'             => 1,
    //         ]);
    //     }

    //     return response()->json(['suggestion' => $suggestion]);
    // }

    // public function Suggestion(Request $request)
    // {
    //     $category = $request->input('category'); // we can send int from frontend okay
    //     $suggestion = 'No suggestion generated.';
    //     $userId = auth()->id();
    //     $now = now();
    //     $year = $now->year;
    //     $month = $now->month;
    //     $branch_id = $request->user()->branch_id;

    //     $role = UserRoleModel::where('sno', $category)->first();
    //     $branch = BranchModel::where('sno', $branch_id)->first();

    //     if ($role && $role->sno == 11) {
    //         $staffList = StaffModel::where('role_id', $role->sno)
    //             ->where('branch_id', $branch_id)
    //             ->where(function($query) use ($year, $month) {
    //               // Add conditions for status 4
    //               $query->where(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 4)
    //                           ->whereYear('za_staff.notice_end_date', '>=', $year)
    //                           ->whereMonth('za_staff.notice_end_date', '>=', $month);
    //                   })
    //                   // Add conditions for status 5
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 5)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                   })
    //                   // Add conditions for status 6
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 6)
    //                           ->whereYear('za_staff.staff_last_date', '>=', $year)
    //                           ->whereMonth('za_staff.staff_last_date', '>=', $month);
    //                   })
    //                   // Add conditions for status 7
    //                   ->orWhere(function($query) use ($year, $month) {
    //                       $query->where('za_staff.status', 7)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                   })
    //                   // Include status 0 regardless of date
    //                   ->orWhere('za_staff.status', 0);
    //           })->get();

    //         $allStaffStats = [];
    //         $overallConvert = 0;
    //         $overallSpam = 0;
    //         $overallDead = 0;

    //         foreach ($staffList as $staff) {
    //             $monthLeadCount = DB::table('za_lead')
    //                 ->where('created_by', $staff->sno)
    //                 ->where('branch_id', $branch_id)
    //                 ->whereYear('registered_date', $year)
    //                 ->whereMonth('registered_date', $month)
    //                 ->whereNotIn('status', [2, 6])
    //                 ->where('spam_verified', 0)
    //                 ->where('internal_status', 0)
    //                 ->count();

    //             $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //                 ->where('za_customer.branch_id', $branch_id)
    //                 ->where('za_customer.status', 0)
    //                 ->where('za_lead.created_by', $staff->sno)
    //                 ->whereYear('za_customer.created_at', $year)
    //                 ->whereMonth('za_customer.created_at', $month)
    //                 ->count();

    //             $spamLeadCount = DB::table('za_lead')
    //                 ->where('created_by', $staff->sno)
    //                 ->where('branch_id', $branch_id)
    //                 ->whereYear('registered_date', $year)
    //                 ->whereMonth('registered_date', $month)
    //                 ->where('spam_verified', 1)
    //                 ->where('status', 7)
    //                 ->count();

    //             $deadLeadCount = DB::table('za_lead')
    //                 ->where('created_by', $staff->sno)
    //                 ->where('branch_id', $branch_id)
    //                 ->whereYear('registered_date', $year)
    //                 ->whereMonth('registered_date', $month)
    //                 ->where('status', 5)
    //                 ->count();

    //             $allStaffStats[] = [
    //                 'name' => $staff->staff_name,
    //                 'monthLeadCount' => $monthLeadCount,
    //                 'customerConvertCount' => $customerConvertCount,
    //                 'spamLeadCount' => $spamLeadCount,
    //                 'deadLeadCount' => $deadLeadCount,
    //             ];

    //             $overallConvert += $customerConvertCount;
    //             $overallSpam += $spamLeadCount;
    //             $overallDead += $deadLeadCount;
    //         }

    //         // === Build the AI Prompt ===
    //         $branchLabel = $branch->branch_type == 1 ? 'Branch' : 'Franchise';
    //         $branchName = $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name;
    //         $prompt = "You are a performance coach AI for a sales team in a {$branchLabel} named '{$branchName}'. This is a summary of their performance for {$month}/{$year}:\n";
    //         $prompt .= "Total Conversions: {$overallConvert}\n";
    //         $prompt .= "Spam Leads: {$overallSpam}\n";
    //         $prompt .= "Dead Leads: {$overallDead}\n";
    //         $prompt .= "Goal: Help the team increase conversions and reduce spam/dead leads next month.\n";
    //         $prompt .= "Suggest a practical, skill-based improvement they can implement immediately.";

    //         $response = $this->chatGPTService->ask($prompt);
    //         $suggestion = $response ?: $suggestion;

    //         AISuggestionModel::create([
    //             'date' => $now->format('Y-m-d'),
    //             'suggestion_content' => $suggestion,
    //             'role_id' => $role->sno,
    //             'created_by' => $userId,
    //             'updated_by' => $userId,
    //             'status' => 1,
    //         ]);
    //     }

    //     return response()->json(['suggestion' => $suggestion]);
    // }
    // public function Suggestion(Request $request)
    // {
    //     $category = $request->input('category');
    //     $role_id = $request->input('role_id');
    //     $executiveId = $request->input('executive_id');
    //     $suggestion = 'No suggestion generated.';
    //     $userId = auth()->id();
    //     $now = now();
    //     $year = $now->year;
    //     $month = $now->month;
    //     $branch_id = $request->user()->branch_id;

    //     $role = UserRoleModel::where('sno', $role_id)->first();
    //     $branch = BranchModel::where('sno', $branch_id)->first();
    //     // return $role;
    //     if ($role && $role->sno == 13 || $role->sno == 11) {
    //       if (!empty($executiveId)) {
    //         // For single executive - one staff record
    //         $staffList = StaffModel::where('sno', $executiveId)
    //             ->where('role_id', $role->sno)
    //             ->where('branch_id', $branch_id)
    //             ->where(function($query) use ($year, $month) {
    //                 $query
    //                     ->orWhere(function($q) use ($year, $month) {
    //                         $q->where('za_staff.status', 4)
    //                           ->whereYear('za_staff.notice_end_date', '>=', $year)
    //                           ->whereMonth('za_staff.notice_end_date', '>=', $month);
    //                     })
    //                     ->orWhere(function($q) use ($year, $month) {
    //                         $q->where('za_staff.status', 5)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                     })
    //                     ->orWhere(function($q) use ($year, $month) {
    //                         $q->where('za_staff.status', 6)
    //                           ->whereYear('za_staff.staff_last_date', '>=', $year)
    //                           ->whereMonth('za_staff.staff_last_date', '>=', $month);
    //                     })
    //                     ->orWhere(function($q) use ($year, $month) {
    //                         $q->where('za_staff.status', 7)
    //                           ->whereYear('za_staff.updated_at', '>=', $year)
    //                           ->whereMonth('za_staff.updated_at', '>=', $month);
    //                     })
    //                     ->orWhere('za_staff.status', 0);
    //             })
    //             ->first();

    //         // Wrap single staff in array for consistent processing below
    //         $staffList = $staffList ? [$staffList] : [];
    //         // return $staffList;
    //       } else {
    //           // For team - multiple staff
    //           $staffList = StaffModel::where('role_id', $role->sno)
    //               ->where('branch_id', $branch_id)
    //               ->where(function($query) use ($year, $month) {
    //                   $query
    //                       ->orWhere(function($q) use ($year, $month) {
    //                           $q->where('za_staff.status', 4)
    //                             ->whereYear('za_staff.notice_end_date', '>=', $year)
    //                             ->whereMonth('za_staff.notice_end_date', '>=', $month);
    //                       })
    //                       ->orWhere(function($q) use ($year, $month) {
    //                           $q->where('za_staff.status', 5)
    //                             ->whereYear('za_staff.updated_at', '>=', $year)
    //                             ->whereMonth('za_staff.updated_at', '>=', $month);
    //                       })
    //                       ->orWhere(function($q) use ($year, $month) {
    //                           $q->where('za_staff.status', 6)
    //                             ->whereYear('za_staff.staff_last_date', '>=', $year)
    //                             ->whereMonth('za_staff.staff_last_date', '>=', $month);
    //                       })
    //                       ->orWhere(function($q) use ($year, $month) {
    //                           $q->where('za_staff.status', 7)
    //                             ->whereYear('za_staff.updated_at', '>=', $year)
    //                             ->whereMonth('za_staff.updated_at', '>=', $month);
    //                       })
    //                       ->orWhere('za_staff.status', 0);
    //               })
    //               ->get();
    //       }

    //       // Now loop through $staffList as usual:
    //       $allStaffStats = [];
    //       $overallConvert = $overallSpam = $overallDead = 0;

    //       foreach ($staffList as $staff) {
    //           $monthLeadCount = DB::table('za_lead')
    //               ->where('created_by', $staff->sno)
    //               ->where('branch_id', $branch_id)
    //               ->whereYear('registered_date', $year)
    //               ->whereMonth('registered_date', $month)
    //               ->whereNotIn('status', [2, 6])
    //               ->where('spam_verified', 0)
    //               ->where('internal_status', 0)
    //               ->count();

    //           $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
    //               ->where('za_customer.branch_id', $branch_id)
    //               ->where('za_customer.status', 0)
    //               ->where('za_lead.created_by', $staff->sno)
    //               ->whereYear('za_customer.created_at', $year)
    //               ->whereMonth('za_customer.created_at', $month)
    //               ->count();

    //           $spamLeadCount = DB::table('za_lead')
    //               ->where('created_by', $staff->sno)
    //               ->where('branch_id', $branch_id)
    //               ->whereYear('registered_date', $year)
    //               ->whereMonth('registered_date', $month)
    //               ->where('spam_verified', 1)
    //               ->where('status', 7)
    //               ->count();

    //           $deadLeadCount = DB::table('za_lead')
    //               ->where('created_by', $staff->sno)
    //               ->where('branch_id', $branch_id)
    //               ->whereYear('registered_date', $year)
    //               ->whereMonth('registered_date', $month)
    //               ->where('status', 5)
    //               ->count();

    //           $allStaffStats[] = [
    //               'name' => $staff->staff_name,
    //               'monthLeadCount' => $monthLeadCount,
    //               'customerConvertCount' => $customerConvertCount,
    //               'spamLeadCount' => $spamLeadCount,
    //               'deadLeadCount' => $deadLeadCount,
    //           ];

    //           $overallConvert += $customerConvertCount;
    //           $overallSpam += $spamLeadCount;
    //           $overallDead += $deadLeadCount;
    //       }


    //         $branchLabel = $branch->branch_type == 1 ? 'Branch' : 'Franchise';
    //         $branchName = $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name;

    //         $prompt = '';

    //       $prompt .= "You are a performance coach AI specialized in sales performance improvement. ";
    //       $prompt .= "You are assisting a " . ($roleTitle ?? 'sales team member') . " working at a {$branchLabel} named '{$branchName}'. ";

    //         // 2. Executive-specific (if executive_id is not null)
    //         if (!empty($executiveId) && isset($staffList[0])) {
    //           $executiveName = $staffList[0]->staff_name ?? 'Executive';
    //             $prompt .= "You are analyzing performance for the executive named '{$executiveName}' for {$month}/{$year}.\n";
    //             $prompt .= "🎨 Please highlight only the executive name '{$executiveName}' using bold formatting and a randomly chosen pleasant color (like #4A90E2, #B388EB, #00B894).\n";
    //             $prompt .= "Wrap just the executive name in a <span> tag with inline style for color and bold text (e.g., <span style=\"color:#4A90E2; font-weight:bold\">John Doe</span>).\n";
    //         } else {
    //             $prompt .= "This is a summary for the {$category} team for {$month}/{$year}.\n";
    //         }
    //         // Goal Ratio Section (Individual only)

    //         if (!empty($executiveId) && isset($staffList[0])) {
    //             $helper = new \App\Helpers\Helpers();
    //             $goalProgress = $helper->getStaffGoal_progress_bar($staffList[0]->sno, 1, date('m'), date('Y'), $staffList[0]->branch_id) ?? 0;
    //             $prompt .= "🎯 Goal Achievement Ratio: {$goalProgress}% of target achieved.\n";
    //             $prompt .= "Please analyze whether this ratio is satisfactory and how it can be improved.\n";

    //             $currentProgress = $goal_progress ?? 0; // Example: 72.5%
    //             $estimatedTarget = round($overallConvert / ($currentProgress / 100)); // Reverse goal

    //             $pushTarget = ceil($estimatedTarget * 1.10); // Add 10% push-up

    //             $prompt .= "📈 Goals for Next Month: Set realistic, measurable goals.\n";
    //             $prompt .= "🧮 Based on current goal progress of {$goal_progress}%, the projected target was approximately {$estimatedTarget} conversions.\n";
    //             $prompt .= "🎯 Set a push target of {$pushTarget} conversions for next month. Include this number in your suggestion and explain how it can be achieved through strategic effort.\n";
    //         }

    //         // 3. Always include high-level data
    //         $prompt .= "Total Conversions: {$overallConvert}\n";
    //         $prompt .= "Spam Leads: {$overallSpam}\n";
    //         $prompt .= "Dead Leads: {$overallDead}\n";
    //         $prompt .= "🎯 Goal: Help improve results by increasing conversions and reduce spam/dead leads in the next month.\n";
    //         // 4. Dynamic Suggestion Sections
    //         $prompt .= "Provide a detailed, professional guide ";

    //         if (!empty($executiveId)) {
    //             $prompt .= "for the executive, including:\n";
    //         } else {
    //             $prompt .= "for the team, including:\n";
    //         }

    //         // 5. Conditionally include Pros section
    //         if (!empty($pros)) {
    //             $prompt .= "- ✅ Highlight these strengths (Pros).\n";
    //         }

    //         // 6. Conditionally include Cons section
    //         if (!empty($cons)) {
    //             $prompt .= "- ⚠️ Note these weaknesses and need to improvement (Cons).\n";
    //         }

    //           // 5. Instruction to AI on Output Style
    //           $prompt .= "🧠 Generate a clear and visually appealing performance summary using emoji icons instead of markdown headers (like ###).\n";
    //           $prompt .= "Please structure your response with the following sections, each starting with a relevant emoji:\n";
    //           $prompt .= "🔍 Current Status: Mention key metrics and what they indicate.\n";
    //           $prompt .= "✅ Strengths (if any): Highlight what went well.\n";
    //           $prompt .= "⚠️ Weaknesses (if any): Briefly point out issues.\n";
    //           $prompt .= "🛠️ Actionable Steps: Specific suggestions to improve conversions and reduce spam/dead leads.\n";
    //           $prompt .= "💡 Skill Development: Suggest skills like rapport-building, objection handling, active listening.\n";
    //           $prompt .= "🔗 Keep it short, structured, and UI-friendly for frontend display (no image links, no markdown titles).\n";


    //         // Get response from AI
    //         $response = $this->chatGPTService->ask($prompt);
    //         $suggestion = $response ?: $suggestion;

    //     }

    //     return response()->json([
    //         'suggestion' => $suggestion,
    //         'prompt' => $prompt
    //     ]);
    // }
   public function Suggestion(Request $request)
    {
        $category = $request->input('category');
        $role_id = $request->input('role_id');
        $executiveId = $request->input('executive_id');
        $suggestion = 'No suggestion generated.';
        $userId = auth()->id();
        $now = now();
        $year = $now->year;
        $month = $now->month;
        $branch_id = $request->user()->branch_id;
        $actions =$request->input('actions');

         $date= $request->input('date');
         // Parse it with format j-M-Y
         $parsedDate = Carbon::createFromFormat('j-M-Y', strtolower($date));
        
        // Get full month name and year
        $monthname = $parsedDate->format('F'); // Full month name, e.g., 'June'
        $yearfull  = $parsedDate->format('Y'); // e.g., '2025'
         // Convert to DB format
            try {
                $targetDate = Carbon::createFromFormat('d-M-Y', $date)
                                ->startOfMonth()
                                ->format('Y-m-d');  // Will be like '2025-06-01'
            } catch (\Exception $e) {
                return back()->with('error', 'Invalid date format provided.');
            }
          $actins= $request->input('actions');
        $role = UserRoleModel::where('sno', $role_id)->first();
        $branch = BranchModel::where('sno', $branch_id)->first();
        // return $role;
       if ($role && $role->sno == 13 || $role->sno == 11) {
        if (!empty($executiveId)) {
          // For single executive - one staff record
          $staffList = StaffModel::where('sno', $executiveId)
              ->where('role_id', $role->sno)
              ->where('branch_id', $branch_id)
              ->where(function($query) use ($year, $month) {
                  $query
                      ->orWhere(function($q) use ($year, $month) {
                          $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $year)
                            ->whereMonth('za_staff.notice_end_date', '>=', $month);
                      })
                      ->orWhere(function($q) use ($year, $month) {
                          $q->where('za_staff.status', 5)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                      })
                      ->orWhere(function($q) use ($year, $month) {
                          $q->where('za_staff.status', 6)
                            ->whereYear('za_staff.staff_last_date', '>=', $year)
                            ->whereMonth('za_staff.staff_last_date', '>=', $month);
                      })
                      ->orWhere(function($q) use ($year, $month) {
                          $q->where('za_staff.status', 7)
                            ->whereYear('za_staff.updated_at', '>=', $year)
                            ->whereMonth('za_staff.updated_at', '>=', $month);
                      })
                      ->orWhere('za_staff.status', 0);
              })
              ->first();

          // Wrap single staff in array for consistent processing below
          $staffList = $staffList ? [$staffList] : [];
        //   return '$staffList';
        } else {
          // return '$staffList';

            // For team - multiple staff
           $staffList = StaffModel::where('role_id', 11)
              ->where('branch_id', $branch_id)
              ->where('status', 0)
              ->get();
                // return $staffList;
        }

        // Now loop through $staffList as usual:
        $allStaffStats = [];
        $overallConvert = $overallSpam = $overallDead = 0;
        $totalAllPayment = $totalAllPaidPayment = 0; // Ensure initialization
        $totalAverageBusinessValue = 0;
        $totalAverageCollectionValue     = 0;
        $totalAverageconvertRatio     = 0;
        $totalconvertRatio     = 0;
        $totalSpamLeadRatio     = 0;
        $totalDeadLeadRatio     = 0;
        $totalAllLead             = 0;
        $totalMonthLead            = 0;
        $totalconvertCustomer            = 0;
        $totalHotLead        = 0;
        $totalSpamLead      = 0;
        $totalDeadLead    = 0;

        $totalAllPayment             = 0;
        $totalAllPaidPayment        = 0;
        $goalteam = GoalSetTeamModel::where('department_id', 1)
            ->where('branch_id', $branch_id)
            ->where('team_goal_month', $month)
            ->first();

        // return $staffList;
        foreach ($staffList as $staff) {

             $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
              ->where('za_lead.created_by', $staff->sno)
              ->where('za_lead.branch_id', $branch_id)
              ->whereNotIn('za_lead.status',[2,6])
              ->where('za_lead.spam_verified',0)
              ->where('za_lead.drop_verified', 0)
              ->where('za_lead.internal_status',0)
              ->count();

            $monthLeadCount = DB::table('za_lead')
                ->where('created_by', $staff->sno)
                ->where('branch_id', $branch_id)
                ->whereYear('registered_date', $year)
                ->whereMonth('registered_date', $month)
                ->whereNotIn('status', [2, 6])
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->count();

            $customerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branch_id)
                ->whereIn('za_customer.status', [0, 6])
                ->where('za_lead.created_by', $staff->sno)
                ->whereYear('za_customer.created_at', $year)
                ->whereMonth('za_customer.created_at', $month)
                ->count();

            $spamLeadCount = DB::table('za_lead')
                ->where('created_by', $staff->sno)
                ->where('branch_id', $branch_id)
                ->whereYear('registered_date', $year)
                ->whereMonth('registered_date', $month)
                ->where('spam_verified', 1)
                ->where('status', 7)
                ->count();

            $deadLeadCount = DB::table('za_lead')
                ->where('created_by', $staff->sno)
                ->where('branch_id', $branch_id)
                ->whereYear('registered_date', $year)
                ->whereMonth('registered_date', $month)
                ->where('status', 5)
                ->count();

            // Conversion and Ratio Calculations
            $convertion_rate = $allLeadCount > 0 ? number_format(($customerConvertCount / $allLeadCount) * 100, 2) : 0;
            $averager_convertion_rate = $monthLeadCount > 0 ? number_format(($customerConvertCount / $monthLeadCount) * 100, 2) : 0;

            // Business and Collection values
            $total_payment = $total_paid_payment = 0;
            $averageBusinessValue = $averageCollectionValue = 0;

            if ($customerConvertCount > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->whereIn('za_customer.status', [0, 6])
                    ->where('za_lead.created_by', $staff->sno)
                    ->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', $month)
                    ->get();

                foreach ($currentMonthCustomer as $customer) {
                    $payment = DB::table('za_training')
                        ->where('customer_id', $customer->sno)
                        ->where('tesbo_check', 0)
                        ->sum('overall_fees');
                    $total_payment += $payment;

                    $latestTraining = DB::table('za_training')
                        ->where('customer_id', $customer->sno)
                        ->where('tesbo_check', 2)
                        ->orderByDesc('sno')
                        ->first();

                    if ($latestTraining) {
                        $total_payment += $latestTraining->overall_fees;
                    }

                    $paid_payment = DB::table('za_training')
                        ->where('customer_id', $customer->sno)
                        ->sum('paid_amount');
                    $total_paid_payment += $paid_payment;
                }

                $averageBusinessValue = $total_payment / $customerConvertCount;
                $averageCollectionValue = $total_paid_payment / $customerConvertCount;
                $totalAllPayment += $total_payment;
                $totalAllPaidPayment += $total_paid_payment;
            }

            // Append to staff stats
            $allStaffStats[] = [
                'name' => $staff->staff_name,
                'monthLeadCount' => $monthLeadCount,
                'customerConvertCount' => $customerConvertCount,
                'spamLeadCount' => $spamLeadCount,
                'deadLeadCount' => $deadLeadCount,
                'allLeadCount' => $allLeadCount,
                'averager_convertion_rate' => $averager_convertion_rate,
                'averageBusinessValue' => $averageBusinessValue,
                'averageCollectionValue' => $averageCollectionValue,
            ];

            // Aggregate overall stats
             $totalAllLead             += $allLeadCount;
              $totalMonthLead            += $monthLeadCount;
            $overallConvert += $customerConvertCount;
             $totalconvertCustomer            += $customerConvertCount;
            $overallSpam += $spamLeadCount;
            $overallDead += $deadLeadCount;
        }
         // customer ratio
        $totalconvertRatio = $totalAllLead > 0 ? ($totalconvertCustomer / $totalAllLead) * 100 : 0;
        $totalconvertRatio = number_format($totalconvertRatio, 2);

        //acr
        $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalconvertCustomer / $totalMonthLead) * 100 : 0;
        $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);

        $totalAverageBusinessValue   = $totalconvertCustomer > 0 ? $totalAllPayment / $totalconvertCustomer : 0;
        $totalAverageCollectionValue = $totalconvertCustomer > 0 ? $totalAllPaidPayment / $totalconvertCustomer : 0;

        // Compute total leads across all staff
        $totalLeadCount = array_sum(array_column($allStaffStats, 'allLeadCount'));
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
         $targetss = $targets->monthly_target ?? 0; // PHP 8+ safe property access
         $targetFormatted = number_format($targetss, 2);
        // Old payments
        $totalPaidAmountOld = DB::table('za_old_payments')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->where('za_old_customer.branch_id', $branch_id)
            ->where('za_old_payments.status', '!=', 2)
            ->whereIn('za_old_customer.status', [1, 4])
            ->where('za_old_payments.amount', '>', 0)
            ->whereYear('za_old_payments.created_at', $year)
            ->whereMonth('za_old_payments.created_at', $month)
            ->sum('za_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_payment.status', 1)
            ->where('za_customer.status', 0)
            ->where('za_payment.amount', '>', 0)
            ->whereYear('za_payment.initialPayDate', $year)
            ->whereMonth('za_payment.initialPayDate', $month)
            ->sum('za_payment.paidAmount');
    
        $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
        $targetActualFormatted =  number_format($targetActual, 2);
        // Branch Info
        $branchLabel = $branch->branch_type == 1 ? 'Branch' : 'Franchise';
        $branchName = $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name;

        $prompt = '';

        // Executive Prompt or Branch Summary
        if (!empty($executiveId) && isset($staffList[0])) {
            $executiveName = $staffList[0]->staff_name ?? 'Executive';
            $prompt .= "You are analyzing performance for the executive named '{$executiveName}' for {$month}/{$year}.\n";
        } else {
            $prompt .= 'Our Company Name is "Elysium Academy". We run a training institute offering computer Software and Networking training courses for students. Our ' . $branchLabel . ' Name: "' . $branchName . '". Please act as a Business and Sales Analyst for the information below and give a proper sales analysis report (Like: ' . implode(', ', $actions) . ' ). In ' . $monthname . '-' . $yearfull . ', our Branch Leads are ' . $totalLeadCount . ', and the number of converted students is ' . $overallConvert . ' and Monthly Target Achieved ' . $targetActualFormatted . ' (Rule 1: Our ' . $monthname . '-' . $yearfull . ' Month Conversion Target is ' . ($goalteam->conversion_over_all ?? 'N/A') . ' and Monthly Target Value ' . $targetFormatted . '), resulting in a Conversion Rate of ' . $totalconvertRatio . '% (Rule 2: The best Conversion Rate is ' . ($goalteam->cr_over_all ?? 'N/A') . '%). Average Business Value (ABV) Per Conversion: ' . number_format($totalAverageBusinessValue, 2) . ' Rupees (Rule 3: The Best Average Business Value is ' . ($goalteam->abv_over_all ?? 'N/A') . ' Rupees). Average Collection Value (ACV) Per Conversion ' . number_format($totalAverageCollectionValue, 2) . ' Rupees (Rule 4: The Best Average Collection Value is ' . ($goalteam->acv_over_all ?? 'N/A') . ' Rupees).';
           

        }

        $prompt .= " Please present the sales analysis report in a professional HTML table format with clean structure and include sections like Summary, Pros, Cons, and Recommendations using <table>, <thead>, <tbody>, and <tr> tags. Avoid plain text.";

            // Get response from AI
            $response = $this->chatGPTService->ask($prompt);
            $suggestion = $response ?: $suggestion;

        }

        return response()->json([
            'suggestion' => $suggestion,
            'prompt' => $prompt
        ]);
    }

  public function Suggestionsave(Request $request)
  {
      $userId = auth()->id(); // or however you handle user auth
      $now = Carbon::now();

      $validated = $request->validate([
          'suggestion' => 'required|string',
          'role_id' => 'required|integer',
          'category' => 'nullable|string'
      ]);

      AISuggestionModel::create([
          'date' => $now->format('Y-m-d'),
          'suggestion_content' => $validated['suggestion'],
          'role_id' => $validated['role_id'],
          'category' => $validated['category'] ?? null,
          'created_by' => $userId,
          'updated_by' => $userId,
          'status' => 1,
      ]);

      return response()->json(['success' => true]);
  }
  public function history(Request $request)
  {
      $title = $request->query('title');
      $roleId = $request->query('role_id');

      $history = DB::table('za_ai_suggestion')
          ->where('role_id', $roleId)
          ->orderByDesc('created_at')
          ->get()
          ->map(function ($row) {
              return [
                  'date' => Carbon::parse($row->created_at)->format('d M Y'),
                  'content' => $row->suggestion_content
              ];
          });

      return response()->json($history);

  }
}
