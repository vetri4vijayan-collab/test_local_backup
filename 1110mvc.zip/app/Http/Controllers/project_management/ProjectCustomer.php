<?php

namespace App\Http\Controllers\project_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\ProjectPaymentModel;
use App\Models\BranchModel;
use App\Models\ProjectLeadModel;
use App\Models\ProjectCustomerModel;
use App\Models\ManageProjectModel;
use App\Models\ServicesModel;
use App\Models\TransactionModel;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Exception;

class ProjectCustomer extends Controller
{
  // ************************************* Lead List Pages **************************
  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_fill = $request->search_fill ?? '';
    $branch_id = $request->user()->branch_id;
    $query = ProjectCustomerModel::where('za_project_customer.status', '!=', 2)
      ->select(
        'za_project_customer.*'
      )
      ->leftJoin('epro_services', 'epro_services.customer_id', '=', 'za_project_customer.sno')
      ->where('za_project_customer.branch_id', $branch_id)
      ->orderBy('za_project_customer.sno', 'desc');

    if ($search_fill != '') {
      $query->where(function ($list) use ($search_fill) {
        $list->where('za_project_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('za_project_customer.customer_id', 'LIKE', "%{$search_fill}%");
      });
    }

    $customers = $query->paginate($perpage);

    foreach ($customers as $customer) {

      $projects = DB::table('epro_services')
        ->select(
          'epro_services.*',
          'et_manage_project.project_title',
          'et_manage_project.domain_id',
          'et_language.language_name',
          'et_database.db_name'
        )
        ->leftJoin('et_manage_project', 'et_manage_project.sno', '=', 'epro_services.project_id')
        ->leftJoin('et_language', 'et_language.sno', '=', 'et_manage_project.language_id')
        ->leftJoin('et_database', 'et_database.sno', '=', 'et_manage_project.database_id')
        ->where('customer_id', $customer->sno)
        ->get();

      foreach ($projects as $proj) {

        if ((int) $proj->project_id === 0) {
          $proj->project_title = 'None';
          $proj->domain_names = [];
          $proj->language_name = 'None';
          $proj->db_name = 'None';
          continue;
        }

        $domainIds = json_decode($proj->domain_id, true);

        if (is_numeric($domainIds)) {
          $domainIds = [$domainIds];
        }

        if (!is_array($domainIds)) {
          $domainIds = [];
        }

        $proj->domain_names = DB::table('et_project_domain')
          ->whereIn('sno', $domainIds)
          ->pluck('domain_name')
          ->toArray();
      }

      $customer->projects = $projects;
    }


    // return $customers;

    return view('content.project.customer.customer_list', [
      'lists' => $customers,
      'perpage' => $perpage,
      'search_fill' => $search_fill
    ]);
  }
  public function edit($id)
  {
    $data = ProjectCustomerModel::where('status', 0)
      ->where('sno', $id)
      ->first();

    return response([
      'status' => 200,
      'message' => 'Customer data fetched successfully!',
      'error_msg' => 'Customer data fetching failed!',
      'data' => $data
    ], 200);
  }

  public function update(Request $request, $id)
  {
    try {
      DB::beginTransaction();

      $customer = ProjectCustomerModel::where('status', 0)
        ->where('sno', $id)
        ->first();

      if (!$customer) {
        return response()->json([
          'status' => 404,
          'message' => 'Customer not found!',
          'error_msg' => 'Customer not found!'
        ]);
      }

      $customer->cus_name       = $request->cus_name;
      $customer->cus_gender     = $request->cus_gender;
      if ($request->cus_dob) {
        $customer->cus_dob = Carbon::createFromFormat('d/m/Y', $request->cus_dob)
          ->format('Y-m-d');
      } else {
        $customer->cus_dob = null;
      }
      $customer->cus_mobile     = $request->cus_mobile;
      $customer->cus_mail       = $request->cus_mail;
      $customer->college_id     = $request->college_id;
      $customer->department_id  = $request->department_id;
      $customer->address        = $request->address;
      $customer->country_code   = $request->country_code;

      $customer->save();

      DB::commit();

      return response()->json([
        'status' => 200,
        'message' => 'Customer updated successfully'
      ]);
    } catch (\Exception $e) {
      DB::rollBack();

      return response()->json([
        'status' => 500,
        'message' => 'Error while updating customer',
        'error_msg' => $e->getMessage()
      ]);
    }
  }

  public function EproLanguage()
  {
    $domain = DB::table('et_language')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $domain
    ], 200);
  }
  public function EproDatabase()
  {
    $facility = DB::table('et_database')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }
  public function EproDomain()
  {
    $facility = DB::table('et_project_domain')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }
  public function EproProject()
  {
    $facility = DB::table('et_manage_project')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }

  public function AddCustomer(Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $id  = $request->id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $id = $helper->encrypt_decrypt($id, 'decrypt');

    // Get the last customer ID to generate next one
    $data = ProjectLeadModel::where('sno', $id)
      ->first();


    $branch = BranchModel::find($branch_id);
    if (!$branch || !$branch->city_short_code) {
      return response([
        'status'    => 500,
        'message'   => 'Branch configuration missing',
        'error_msg' => 'branch not found',
        'data'      => null,
      ], 200);
    }

    // return $data;
    return view('content.project.customer.customer_add', compact(
      'data',
      'branch',
      'id',
    ));
  }

  public function check_customer_details(Request $request)
  {
    $cus_mobile = $request->customerMobile;
    $cus_mail = $request->customerMail;

    // Check for exact matches on both mobile and email
    $check_customer = ProjectCustomerModel::where(function ($query) use ($cus_mobile, $cus_mail) {
      if (!empty($cus_mobile)) {
        $query->where('cus_mobile', $cus_mobile);
      }
      if (!empty($cus_mail)) {
        $query->orWhere('cus_mail', $cus_mail);
      }
    })->first();

    if ($check_customer) {
      $conflicting_fields = [];

      // Check which fields actually match
      if (!empty($cus_mobile) && $check_customer->cus_mobile == $cus_mobile) {
        $conflicting_fields[] = 'mobile';
      }
      if (!empty($cus_mail) && $check_customer->cus_mail == $cus_mail) {
        $conflicting_fields[] = 'email';
      }

      // Only return conflict if there are actual matching fields
      if (!empty($conflicting_fields)) {
        return response([
          'status' => 200,
          'message' => 'Customer Already Exists!',
          'error_msg' => 'Customer with same ' . implode(', ', $conflicting_fields) . ' already exists',
          'conflicting_fields' => $conflicting_fields,
          'data' => $check_customer
        ], 200);
      }
    }

    // If no customer found or no actual conflicts
    return response([
      'status' => 404,
      'message' => 'Customer not found',
      'error_msg' => null,
      'conflicting_fields' => [],
      'data' => null
    ], 200);
  }
  public function get_payment_min_and_max($id)
  {
    $payment = DB::table('et_manage_project')
      ->where('sno', $id)
      ->select('min_amt', 'max_amt') // add max if exists
      ->first();

    if (!$payment) {
      return response()->json([
        'status' => 204,
        'message' => 'No payment data found',
        'error_msg' => null,
        'data' => null
      ], 200);
    }

    return response()->json([
      'status' => 200,
      'message' => 'Data fetched successfully',
      'error_msg' => null,
      'data' => [
        'min_amt' => $payment->min_amt,
        'max_amt' => $payment->max_amt ?? null
      ]
    ], 200);
  }
  public function lead_to_cus_data($id)
  {
    $data = DB::table('za_project_lead')
      ->where('sno', $id)
      ->first();

    return response([
      'status' => 200,
      'message' => 'Lead Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
  public function get_payment_mode_option()
  {
    $data = DB::table('epro_payment_mode')
      ->where('status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => 'Payment Mode Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function get_payment_option($id)
  {
    $data = DB::table('epro_payment_option')
      ->where('payment_mode_id', $id)
      ->where('status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => 'Payment Mode Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
  public function get_project_name($id)
  {
    $data = DB::table('et_manage_project')
      ->where('sno', $id)
      ->where('status', 0)
      ->select('project_title')
      ->first();

    return response([
      'status' => 200,
      'message' => 'Project Title Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
  public function create_customer(Request $request)
  {
    try {
      $validated = $request->validate([
        'lead_id' => 'required|integer',
        'customer_name' => 'required|string|max:255',
        'gender' => 'required',
        'dob' => 'nullable',
        'cus_mobile' => 'nullable',
        'cus_email' => 'nullable',
        'college_id' => 'required',
        'dept_id' => 'required|integer',
        'address' => 'nullable|string',
        'project_type' => 'required',
        'project_id' => 'nullable',
        'project_title' => 'nullable',
        'language_id' => 'nullable',
        'database_id' => 'nullable',
        'total_amount' => 'required',
      ]);

      $user_id = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $lead_id = $request->lead_id;

      $query = ProjectCustomerModel::query();

      if (!empty($validated['cus_mobile'])) {
        $query->where('cus_mobile', $validated['cus_mobile']);
      }

      if (!empty($validated['cus_email'])) {
        $query->orWhere('cus_mail', $validated['cus_email']);
      }

      $existing_customer = $query->first();

      if ($existing_customer) {
        return response([
          'status' => 409,
          'message' => 'Customer with this mobile or email already exists!',
          'data' => null
        ], 409);
      }

      $lead = ProjectLeadModel::where('sno', $validated['lead_id'])
        ->where('za_project_lead.status', 0)
        ->first();



      DB::beginTransaction();

      // ! Generate customer ID

      $currentYear = date("Y");
      $latestProject = ProjectCustomerModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();

      if (!$latestProject) {
        $customerId = "CUS0001/{$currentYear}";
      } else {
        $lastProjectId = $latestProject->customer_id;
        $parts = explode("/", $lastProjectId);
        $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
        $nextNumber = (int)$numericPart + 1;
        $customerId = sprintf("CUS%04d/%s", $nextNumber, $currentYear);
      }

      $customer = ProjectCustomerModel::create([
        'customer_id' => $customerId,
        'lead_id' => $validated['lead_id'],
        'cus_name' => $validated['customer_name'],
        'entity_id' => $lead->entity_id,
        'cus_gender' => $validated['gender'],
        'cus_dob' => $validated['dob'],
        'country_code' => $request->country_code ?? 91,
        'cus_mobile' => $validated['cus_mobile'],
        'cus_mail' => $validated['cus_email'],
        'college_id' => $validated['college_id'],
        'department_id' => $validated['dept_id'],
        'address' => $validated['address'],
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'branch_id' => $branch_id
      ]);

      if (!$customer) {
        throw new Exception('Failed to create customer.');
      }

      if ($lead) {
        $lead->status = 4;
        $lead->update();
      }

      $project_sno = $validated['project_id'];

      if ($validated['project_type'] == 1 && !empty($validated['project_title'])) {
        $existing_project = ManageProjectModel::where('project_title', $validated['project_title'])
          ->where('status', '!=', 2)
          ->exists();

        if ($existing_project) {
          DB::rollBack();
          return response([
            'status' => 302,
            'message' => 'Project name already exists!',
            'error_msg' => null,
            'data' => null
          ], 302);
        }

        $currentYear = date("Y");
        $latestProject = ManageProjectModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

        if (!$latestProject) {
          $newProjectId = "PRJ0001/{$currentYear}";
        } else {
          $lastProjectId = $latestProject->project_id;
          $parts = explode("/", $lastProjectId);
          $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
          $nextNumber = (int)$numericPart + 1;
          $newProjectId = sprintf("PRJ%04d/%s", $nextNumber, $currentYear);
        }

        $newProject = new ManageProjectModel();
        $newProject->project_id = $newProjectId;
        $newProject->project_title = $validated['project_title'];
        $newProject->domain_id = json_encode($request->domainId, true);
        $newProject->language_id = $validated['language_id'] ?? null;
        $newProject->database_id = $validated['database_id'] ?? null;
        $newProject->project_type_id = $validated['type_id'] ?? null;
        $newProject->max_amt = $validated['total_amount'];
        $newProject->min_amt = $validated['total_amount'];
        $newProject->project_year = $currentYear;
        $newProject->upload_type = $request->upload_type;
        $newProject->production_check = $validated['project_type'];
        $newProject->project_desc = "Created from customer conversion - Customer: " . $validated['customer_name'];
        $newProject->branch_id = $branch_id;
        $newProject->created_by = $user_id;
        $newProject->updated_by = $user_id;

        if (!$newProject->save()) {
          throw new \Exception('Failed to save project in manage_project');
        }
        $project_sno = $newProject->sno;

        if ($request->upload_type == 0) {

          if (!empty($request->project_files)) {
            $savedFiles = $this->handle_project_files($request, $user_id, $newProject->sno);

            // Update project with attachments if files were saved
            if (!empty($savedFiles)) {
              $newProject->project_attachment = implode(',', $savedFiles);
              $newProject->save();
            }
          }
        } else {
          $newProject->google_drive_link = $request->google_drive;
          $newProject->save();
        }
      }

      // ! Generate Service ID
      $latestService = ServicesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");
      if (!$latestService) {
        $serviceId = "SER0001" . '/' . $year;
      } else {
        $latestServiceId = $latestService->service_id; // e.g. "CUS0007/2025"
        $parts = explode("/", $latestServiceId);
        $numericPart = preg_replace('/[^0-9]/', '', $parts[0]); // "0007"
        $nextNumber = (int)$numericPart + 1; // 8
        $serviceId = sprintf("SER%04d/%s", $nextNumber, $year);
      }

      $service = ServicesModel::create([
        'branch_id' => $branch_id,
        'service_id' => $serviceId,
        'lead_id' => $validated['lead_id'],
        'customer_id' => $customer->sno,
        'is_production' => $validated['project_type'] == 0 ? 1 : 0,
        'project_id' => $project_sno,
        'total_amount' => $validated['total_amount'],
        'created_by' => $user_id,
        'updated_by' => $user_id
      ]);

      if (!$service) {
        throw new Exception('Failed to create service.');
      }
      $payment_data = [];

      if (!empty($request->payment_data)) {
        $payment_data = json_decode($request->payment_data, true);
      }

      $latestPayment = ProjectPaymentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");
      if (!$latestPayment) {
        $paymentId = "PAY0001" . '/' . $year;
        $invoiceId = "INV0001" . '/' . $year;
      } else {
        $lastPaymentId = $latestPayment->payment_id;
        $lastInvoiceId = $latestPayment->invoice_id;

        $paymentNumeric = preg_replace('/[^0-9]/', '', explode("/", $lastPaymentId)[0]);
        $invoiceNumeric = preg_replace('/[^0-9]/', '', explode("/", $lastInvoiceId)[0]);

        $nextPaymentNumber = (int)$paymentNumeric + 1;
        $nextInvoiceNumber = (int)$invoiceNumeric + 1;

        $paymentId = sprintf("PAY%04d/%s", $nextPaymentNumber, $year);
        $invoiceId = sprintf("INV%04d/%s", $nextInvoiceNumber, $year);
      }

      $total = floatval($request->total_amount);
      $initial = floatval($request->initial_amount);
      $balance = $total - $initial;

      $payment = ProjectPaymentModel::create([
        'payment_id' => $paymentId,
        'invoice_id' => $invoiceId,
        'branch_id' => $branch_id,
        'customer_id' => $customer->sno,
        'total_amount' => $total,
        'initial_amount' => $initial,
        'balance_amount' => $balance,
        'gst_per' => $payment_data['gst_per'] ?? 0,
        'gst_amount' => $payment_data['gst_amount'] ?? 0,
        'payment_mode' => isset($payment_data['payment_mode']) ? trim($payment_data['payment_mode']) : 'N/A',
        'transaction_all' => json_encode($payment_data),
        'next_pay_date' => date('Y-m-d', strtotime($payment_data['next_pay_date'])) ?? null,
        'service_id' => $service->sno,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'status' => 1, // paid status
      ]);
      // i need here another static recor to create
      // Create pending payment if balance exists
      if ($payment->balance_amount > 0) {
        $pendingPaymentId = sprintf("PAY%04d/%s", $nextPaymentNumber + 1, $year);
        $pendingInvoiceId = sprintf("INV%04d/%s", $nextPaymentNumber + 1, $year);

        $nextPayDate = null;
        if (!empty($payment_data['next_pay_date'])) {
          $nextPayDate = date('Y-m-d', strtotime($payment_data['next_pay_date']));
        }

        ProjectPaymentModel::create([
          'branch_id' => $branch_id,
          'payment_id' => $payment->payment_id,
          'invoice_id' => null,
          'customer_id' => $customer->sno,
          'service_id' => $service->sno,
          'total_amount' => $payment->balance_amount,
          'initial_amount' => 0,
          'gst_per' => 0,
          'gst_amount' => 0,
          'balance_amount' => 0,
          'payment_mode' => 'Pending',
          'transaction_all' => null,
          'next_pay_date' => $nextPayDate,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 0, // Pending status
        ]);
      }

      if (!$payment) {
        throw new Exception('Failed to create payment.');
      }

      $latestTransaction = TransactionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");
      if (!$latestTransaction) {
        $transactionId = "TRA0001" . '/' . $year;
      } else {
        $latestTransactionId = $latestTransaction->transaction_id;
        $parts = explode("/", $latestTransactionId);
        $numericPart = preg_replace('/[^0-9]/', '', $parts[0]);
        $nextNumber = (int)$numericPart + 1; // 8
        $transactionId = sprintf("TRA%04d/%s", $nextNumber, $year);
      }

      // 🔹 Create Transaction Record
      $transaction = TransactionModel::create([
        'branch_id' => $branch_id,
        'transaction_id' => $transactionId,
        'transaction_date' => now(),
        'transaction_name' => "FYP Student",
        'trans_source_id' => $customer->customer_id,
        'transaction_type' => isset($payment_data['payment_mode']) ? trim($payment_data['payment_mode']) : 'N/A',
        'payment_id' => $payment->sno,
        'credit' => $request->initial_amount,
        'total_amount' => $request->total_amount,
        'debit' => 0,
        'gst_per' => $payment_data['gst_per'] ?? 0,
        'tax' => $payment_data['gst_amount'] ?? 0,
        'receipt_id' => $payment_data['receipt_id'] ?? null,
        'paid_status' => 1,
        'created_by' => $user_id,
        'updated_by' => $user_id,
      ]);

      if (!$transaction) {
        throw new Exception('Failed to create transaction.');
      }

      if ($service) {
        $notificationData = [
          'branch_id' => $branch_id,
          'notification_content' => '
              <div class="d-flex align-items-center">
              <div class="me-3">
                <span class="badge bg-gray-300"><i class="mdi mdi-account fs-3 text-black"></i></span>
              </div>
              <div class="me-2">
                <a href="#" class="fs-7 text-primary fw-bold">Manage Customer</a>
                <div class="text-secondary fs-8 fw-semibold">' . $customer->cus_name . ' New Customer Converted.</div>
              </div>
            </div>',
          'who' => $user_id,
          'created_by' => $user_id,
          'updated_by' => $user_id,
          'status' => 0
        ];

        $notificationtype = 'Customer';
        $newNotification = new \App\Helpers\Helpers();

        $newNotification->createNotification($notificationData, $notificationtype);
      }

      DB::commit();

      return response([
        'status' => 200,
        'message' => 'Customer, service, and payment created successfully!',
        'data' => [
          'customer_id' => $customer->customer_id,
          'service_id' => $service->sno,
        ]
      ]);
    } catch (\Illuminate\Validation\ValidationException $e) {
      DB::rollBack();
      return response([
        'status' => 422,
        'message' => 'Validation failed',
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 422);
    } catch (\Exception $e) {
      DB::rollBack();
      return response([
        'status' => 500,
        'message' => 'Failed to create customer. Please try again.' . $e->getMessage(),
        'error_msg' => $e->getMessage(),
        'data' => null,
      ], 500);
    }
  }
  public function customerView(Request $request, $id)
  {
    $helper = new \App\Helpers\Helpers();
    $id = $helper->encrypt_decrypt($id, 'decrypt');

    /* ---------------- Customer Basic Info ---------------- */
    $customer = ProjectCustomerModel::select(
      'za_project_customer.*',
      'et_college.college_name',
      'et_college_department.dept_name as department_name'
    )
      ->leftJoin('et_college', 'et_college.sno', '=', 'za_project_customer.college_id')
      ->leftJoin('et_college_department', 'et_college_department.sno', '=', 'za_project_customer.department_id')
      ->where('za_project_customer.sno', $id)
      ->first();

    /* ---------------- Project Allocation ---------------- */
    $project = DB::table('epro_services')
      ->select(
        'et_manage_project.project_title',
        'et_project_domain.domain_name',
        'et_language.language_name',
        'et_database.db_name as database_name'
      )
      ->join('et_manage_project', 'et_manage_project.sno', '=', 'epro_services.project_id')
      ->leftJoin('et_project_domain', 'et_project_domain.sno', '=', 'et_manage_project.domain_id')
      ->leftJoin('et_language', 'et_language.sno', '=', 'et_manage_project.language_id')
      ->leftJoin('et_database', 'et_database.sno', '=', 'et_manage_project.database_id')
      ->where('epro_services.customer_id', $customer->sno)
      ->first();

    /* ---------------- Payment Information ---------------- */
    $payments = DB::table('epro_payment')
      ->where('customer_id', $customer->sno)
      ->orderBy('created_at', 'asc')
      ->get()
      ->groupBy('service_id');

    return view(
      'content.project.customer.customer_view',
      compact('customer', 'project', 'payments')
    );
  }

  public function customer_add_payment($id, Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    //   return $id;
    $customers = ProjectCustomerModel::where('sno', $id) // Group by payment_id to get unique entries
      ->first();
    // dd($courseIds);
    $branch_id = $request->user()->branch_id;
    // Get branch details and calculate GST percentage
    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();
    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    $minimumamount = $branch ? $branch->min_amnt_receive : 1000;
    $pay = ProjectPaymentModel::where('epro_payment.customer_id', $id)->where('epro_payment.status', '!=', 2)
      ->select('epro_payment.payment_id', 'et_manage_project.project_id', 'et_manage_project.project_title')
      ->join('epro_services', 'epro_services.sno', '=', 'epro_payment.service_id') // Select only the fields you need
      ->join('et_manage_project', 'et_manage_project.sno', '=', 'epro_services.project_id') // Select only the fields you need
      ->groupBy('epro_payment.payment_id', 'et_manage_project.project_id', 'et_manage_project.project_title') // Group by payment_id to get unique entries
      ->get();
    // return $pay;

    // Get the course ID from the request
    $selectedPaymentId = $request->input('payment_id', $pay[0]->payment_id); // Use the first course if none selected

    // Retrieve payments where course_id matches any of the course IDs associated with the customer
    $payments = ProjectPaymentModel::where('payment_id', $selectedPaymentId)
      // ->where('amount', '>=', 0)
      // ->where('paidAmount', '>=', 0)
      // ->where('gst_amount', '>=', 0)
      // ->where('balanceFee', '>=', 0)
      ->where('epro_payment.status', '!=', 2)
      ->orderBy('next_pay_date', 'asc')
      ->get();
    // return $payments;
    $total_amount = ProjectPaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
      // ->where('customer_id', $id)
      ->select('total_amount')
      ->first()
      ->total_amount ?? 0;

    $paid_amount = ProjectPaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
      // ->where('customer_id', $id)
      ->sum('initial_amount');

    $balance_amount = $total_amount - $paid_amount;

    $balance_amount = $total_amount - $paid_amount;

    $total_amount = $total_amount;
    $paid_amount = $paid_amount;
    $balance_amount = $balance_amount;


    $year = date("Y");

    $lastNumber = ProjectPaymentModel::where('status', 1)
      ->where('invoice_id', 'like', 'EA/' . $year . '/INV%')
      ->selectRaw("MAX(CAST(SUBSTRING(invoice_id, LENGTH('EA/$year/INV') + 1) AS UNSIGNED)) as max_inv")
      ->value('max_inv');

    $nextNumber = $lastNumber ? $lastNumber + 1 : 2005;

    $invoice_id = 'EA/' . $year . '/INV' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    //   return $payments;
    return view('content.project.customer.customer_payment', compact(
      'payments',
      'pay',
      'selectedPaymentId',
      'customers',
      'invoice_id',
      'total_amount',
      'paid_amount',
      'balance_amount',
      'gstPercentage',
      'minimumamount'
    ));
  }
  public function add_payment(Request $request)
  {
    // Get the selected payment ID from the request
    $selectedPaymentId = $request->input('payment_id');

    // Get the branch ID from the logged-in user
    $branch_id = $request->user()->branch_id;

    // Get branch details and calculate GST percentage
    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();
    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    $minimumamount = $branch ? $branch->min_amnt_receive : 1000;

    // Retrieve payments based on the selected payment ID
    $payments = ProjectPaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
      ->orderBy('nextPayDate', 'asc')
      ->get();


    // Calculate total, paid, and balance amounts
    $total_amount = ProjectPaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
      ->select('total_amount')
      ->first()
      ->total_amount ?? 0;
    //  return $total_amount;
    $paid_amount = ProjectPaymentModel::where('payment_id', $selectedPaymentId)->where('status', '!=', 2)
      ->sum('paidAmount');

    $balance_amount = $total_amount - $paid_amount;

    // Format amounts for the response
    $total_amount = $total_amount;
    $paid_amount = $paid_amount;
    $balance_amount = $balance_amount;

    // Get date format from general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';


    $encryptedValue = $helper->encrypt_decrypt($request->invoice_id, 'encrypt');
    $printValue = $helper->encrypt_decrypt($request->index + 1, 'encrypt');
    // Format payment data according to the date format
    $formattedPayments = $payments->map(function ($payment, $index) use ($dateFormat, $gstPercentage, $helper) {
      return [
        'sno' => $payment->sno,
        'branch_id' => $payment->branch_id,
        'customer_id' => $payment->customer_id,
        'course_id' => $payment->course_id,
        'initialPayDate' => date($dateFormat, strtotime($payment->initialPayDate)),
        'nextPayDate' => date($dateFormat, strtotime($payment->nextPayDate)),
        // 'amount' => number_format($payment->amount, 2),
        'amount' => $payment->amount,
        // 'paidAmount' => number_format($payment->paidAmount, 2),
        'paidAmount' => $payment->paidAmount,
        // 'gst_amount' => number_format($payment->gst_amount, 2),
        'gst_amount' => $payment->gst_amount,
        // 'balanceFee' => number_format($payment->balanceFee, 2),
        'balanceFee' => $payment->balanceFee,
        'invoice_id' => $payment->invoice_id,
        'encryptedValue' => $helper->encrypt_decrypt($payment->invoice_id, 'encrypt'),
        'printValue' => $helper->encrypt_decrypt($index + 1, 'encrypt'), // $index is automatically passed by `map()`
        'status' => $payment->status,
        'gst_percentage' => $gstPercentage,
        // 'minimumamount' => $minimumamount ?? 1000,
      ];
    });

    // If the request is AJAX, return a JSON response
    if ($request->ajax()) {
      return response()->json([
        'total_amount' => $total_amount,
        'paid_amount' => $paid_amount,
        'balance_amount' => $balance_amount,
        'payments' => $formattedPayments,
        'gst_percentage' => $gstPercentage,
        'minimumamount' => $minimumamount
      ]);
    }

    // If not an AJAX request, you may return a different response here as needed
  }
}
