<?php

namespace App\Http\Controllers\project_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\ProjectLeadModel;
use App\Models\ProjectCustomerModel;
use App\Models\StaffModel;
use App\Models\EducationModel;
use App\Models\CollegeModel;
use App\Models\WhatsappApiConfigureModel;
use App\Services\DoubletickService;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Pagination\CursorPaginator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\StaffpointsModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;


class ProjectLead extends Controller
{

  // ************************************* Lead List Pages **************************
  public function index(Request $request)
  {
    $perPage = (int) $request->input('sorting_filter', 25);
    $branch_id = $request->user()->branch_id;
    $login_branch_data =  BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
    $startTime = microtime(true);

    $query = ProjectLeadModel::query();

    $query->join('za_college', 'za_project_lead.college_id', '=', 'za_college.sno');
    $query->join('za_education', 'za_project_lead.department_id', '=', 'za_education.sno');
    $query->join('za_staff', 'za_project_lead.created_by', '=', 'za_staff.sno');

    $query->where('za_project_lead.branch_id', $branch_id);
    $query->select([
      'za_project_lead.*',  // Keeps ALL columns from za_project_lead (including sno)
      'za_project_lead.sno',  // Adds the alias you want
      'za_college.college_name',     // adjust actual column name
      'za_education.education', // adjust if needed
      'za_staff.staff_name',      // adjust if needed
    ]);

    if ($request->filled('search')) {
      $search = $request->input('search');
      $query->where(function ($q) use ($search) {
        $q->where('za_project_lead.lead_name', 'like', "%{$search}%")
          ->orWhere('za_project_lead.lead_mobile', 'like', "%{$search}%") // Fixed typo
          ->orWhere('za_project_lead.lead_email', 'like', "%{$search}%");
      });
    }

    // Monthly leads
    $monthlyLeadCount = (clone $query)
      ->whereMonth('za_project_lead.registered_date', now()->month)
      ->whereYear('za_project_lead.registered_date', now()->year)
      ->count();

    // Total leads
    $totalLeadCount = $query->count();

    // === Add customer/conversion counts (adjust logic as needed) ===
    $totalCustomerCount = (clone $query)->where('za_project_lead.status', '!=', 0)->count();

    $monthlyCustomerCount = (clone $query)
      ->where('za_project_lead.status', 4)
      ->whereMonth('za_project_lead.registered_date', now()->month)
      ->whereYear('za_project_lead.registered_date', now()->year)
      ->count();

    // Percentages
    $percentageOverall = $totalLeadCount > 0
      ? round(($totalCustomerCount / $totalLeadCount) * 100, 2)
      : 0;

    $percentageCurrentMonth = $monthlyLeadCount > 0
      ? round(($monthlyCustomerCount / $monthlyLeadCount) * 100, 2)
      : 0;

    $percentageOverall .= '%';
    $percentageCurrentMonth .= '%';

    // Paginated results
    $leads = $query
      ->orderBy('registered_date', 'desc')
      ->paginate($perPage)
      ->withQueryString();

    $executionTime = microtime(true) - $startTime;
    // return $leads;
    return view('content.project.lead.lead_list', compact(
      'leads',
      'totalLeadCount',
      'monthlyLeadCount', // renamed for clarity
      'percentageOverall',
      'percentageCurrentMonth',
      'login_branch_data',
      'executionTime'
    ));
  }


  public function checkMobileExists(Request $request)
  {
    $lead_mobile = $request->input('mobile');

    // Assuming you have a Lead model with a mobile field
    $exists = ProjectLeadModel::where('lead_mobile', $lead_mobile)->exists();

    return response()->json(['exists' => $exists]);
  }

  public function CollegeList(Request $request)
  {

    $College = DB::table('et_college')->where('status', 0)->orderBy('sno', 'desc')->get();


    // return $College;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $College
    ], 200);
  }

  public function DepartmentList()
  {
    $Education = DB::table('et_college_department')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Education
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name       = $request->lead_name;
      $lead_gender       = $request->lead_gender;
      $lead_mobile       = $request->lead_mobile_create;
      $lead_email_id       = $request->lead_email;
      $college_id       = $request->college_id;
      $department_id       = $request->department_id;
      $user_id            = $request->user()->user_id;
      $branch_id       = $request->user()->branch_id;
      $chk = ProjectLeadModel::where('lead_mobile', $lead_mobile)->where('za_project_lead.branch_id', $branch_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Mobile has been  already created!'
        ]);
      } else {
        $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

        $branch_code = $branch_check->city_short_code;

        $category_check = ProjectLeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $year = date("Y");
        if (!$category_check) {
          $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
        } else {
          $data = $category_check->lead_id;
          $slice = explode("/", $data);
          $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number = (int)$resultcus + 1;
          $request_pay = sprintf("LED%04d", $next_number);
          $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
        }


        $add_category = new ProjectLeadModel();
        $add_category->lead_id                 = $lead_id;
        $add_category->lead_name               = Ucfirst($lead_name);
        $add_category->lead_mobile             = $lead_mobile;
        $add_category->lead_gender             = $lead_gender;
        $add_category->lead_email              = $lead_email_id;
        $add_category->college_id              = $college_id;
        $add_category->department_id           = $department_id;
        $add_category->branch_id               = $branch_id;
        $add_category->created_by              = $user_id;
        $add_category->updated_by              = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Lead added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Lead!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Lead Created successfully!');
    }
  }

  public function Edit($id)
  {


    $lead = ProjectLeadModel::select(
      'za_project_lead.*',
      'za_college.college_name',
      'za_education.education as education_name',
      'za_staff.staff_name',
    )
      ->leftJoin('za_college', 'za_project_lead.college_id', '=', 'za_college.sno')
      ->leftJoin('za_education', 'za_project_lead.department_id', '=', 'za_education.sno')
      ->leftJoin('za_staff', 'za_project_lead.created_by', '=', 'za_staff.sno')
      ->where('za_project_lead.sno', $id)
      ->orderBy('za_project_lead.sno', 'desc')
      ->first();

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // return $lead;

    if ($lead && !empty($lead->registered_date)) {
      $lead->registered_date = date($common_date_format, strtotime($lead->registered_date));
    } else {
      $lead->registered_date = date($common_date_format); // Fallback to current date if lead_dob is null or empty
    }


    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  public function View($id)
  {
    // Fetch the lead data with necessary joins and fields
    $lead = ProjectLeadModel::select(
      'za_project_lead.*',
      'za_college.college_name',
      'za_education.education as department_name',
      'za_staff.staff_name',
    )
      ->leftJoin('za_college', 'za_project_lead.college_id', '=', 'za_college.sno')
      ->leftJoin('za_education', 'za_project_lead.department_id', '=', 'za_education.sno')
      ->leftJoin('za_staff', 'za_project_lead.created_by', '=', 'za_staff.sno')
      ->where('za_project_lead.sno', $id)
      ->orderBy('za_project_lead.sno', 'desc')
      ->first();

    // Check if lead exists before proceeding
    if (!$lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'error_msg' => 'No lead data found for the given ID',
        'data'      => null,
      ], 404);
    }



    // return $lead;
    // Helper to format date
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

    // Format lead_dob if it exists, else use current date
    $lead->registered_date = !empty($lead->registered_date) ? date($common_date_format, strtotime($lead->registered_date)) : date($common_date_format); // Fallback to current date if lead_dob is null or empty

    // Return response with the lead data
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'lead_name' => 'required|max:255',
      'lead_mobile' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $lead_name        = $request->lead_name;
      $lead_id          = $request->lead_id;
      $lead_reg_date_up = isset($request->lead_reg_date_up) ? date('Y-m-d', strtotime($request->lead_reg_date_up)) : null;
      $upd_lead =  ProjectLeadModel::where('sno', $lead_id)->first();

      $chk = ProjectLeadModel::where('lead_name', ucwords($lead_name))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $lead_id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
        } else {
        }
      }

      $upd_lead->lead_name             = Ucfirst($lead_name);
      $upd_lead->lead_mobile           = $request->lead_mobile;
      $upd_lead->college_id            = $request->college_id;
      $upd_lead->department_id         = $request->department_id;
      $upd_lead->lead_email            = $request->lead_email_id;
      $upd_lead->lead_gender           = $request->lead_gender;
      $upd_lead->registered_date       = $lead_reg_date_up;
      $upd_lead->update();


      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      // return $result;
    }

    return redirect('project/manage_lead');
  }

  // public function ConvertCustomer(Request $request)
  // {
  //   $helper = new \App\Helpers\Helpers();
  //   $validator = Validator::make($request->all(), [
  //     'lead_id' => 'required',
  //   ]);

  //   if ($validator->fails()) {
  //     return response([
  //       'status'    => 401,
  //       'message'   => 'Validation failed',
  //       'error_msg' => $validator->errors()->all(),
  //       'data'      => null,
  //     ], 200);
  //   }

  //   $lead_id = $request->lead_id;
  //   $user_id = $request->user()->user_id;
  //   $branch_id = $request->user()->branch_id;

  //   // Find the lead
  //   $lead = ProjectLeadModel::where('sno', $lead_id)
  //     ->where('branch_id', $branch_id) // Security: ensure it belongs to user's branch
  //     ->where('status', 0)             // Optional: only convert fresh leads
  //     ->first();

  //   if (!$lead) {
  //     return response([
  //       'status'    => 404,
  //       'message'   => 'Lead not found or already converted',
  //       'error_msg' => 'Invalid lead_id',
  //       'data'      => null,
  //     ], 200);
  //   }

  //   // Generate Customer ID (unique per year + branch)
  //   $branch = BranchModel::find($branch_id);
  //   if (!$branch || !$branch->city_short_code) {
  //     return response([
  //       'status'    => 500,
  //       'message'   => 'Branch configuration missing',
  //       'error_msg' => 'city_short_code not found',
  //       'data'      => null,
  //     ], 200);
  //   }

  //   $year = date("Y");
  //   $branch_code = $branch->city_short_code;

  //   // Get the last customer ID to generate next one
  //   $lastCustomer = ProjectCustomerModel::where('status', '!=', 2)
  //     ->where('customer_id', 'LIKE', "{$year}/{$branch_code}/%")
  //     ->orderBy('sno', 'desc')
  //     ->first();

  //   if ($lastCustomer) {
  //     preg_match('/CUS(\d{4})/', $lastCustomer->customer_id, $matches);
  //     $next_number = isset($matches[1]) ? (int)$matches[1] + 1 : 1;
  //   } else {
  //     $next_number = 1;
  //   }

  //   $customer_id = $year . '/' . $branch_code . '/' . sprintf("CUS%04d", $next_number);

  //   // Use updateOrCreate to either create new customer or update existing (prevents duplicates)
  //   $customer = ProjectCustomerModel::updateOrCreate(
  //     ['lead_id' => $lead->sno], // Unique identifier (foreign key to lead)
  //     [
  //       'customer_id'    => $customer_id,
  //       'cus_name'       => ucfirst(strtolower($lead->lead_name)),
  //       'cus_mobile'     => $lead->lead_mobile,
  //       'cus_gender'     => $lead->lead_gender,
  //       'cus_email'      => $lead->lead_email,
  //       'college_id'     => $lead->college_id,
  //       'department_id'  => $lead->department_id,
  //       'branch_id'      => $lead->branch_id,
  //       'created_by'     => $user_id,
  //       'updated_by'     => $user_id,
  //     ]
  //   );

  //   // Update the original lead to mark as converted (e.g., status = 4)
  //   $lead->status = 4; // Assuming 4 means "Converted to Customer"
  //   $lead->updated_by = $user_id;
  //   $lead->save();

  //   // Success response

  //  $encrypted_values = $helper->encrypt_decrypt($lead_id . '~' . '1', 'encrypt');
  //   return redirect()->route('customer_add', ['id' => $encrypted_values]);
  //   // If you really want to return a view instead (for web route), uncomment below:
  //   return redirect()->route('project-add-customer')->with('success', 'Lead converted successfully!');
  // }

  public function ConvertCustomer(Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Validation failed',
        'error_msg' => $validator->errors()->all(),
        'data'      => null,
      ], 200);
    }

    $lead_id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    // Find the lead
    $lead = ProjectLeadModel::where('sno', $lead_id)
      ->where('branch_id', $branch_id) // Security: ensure it belongs to user's branch
      ->where('status', 0)             // Optional: only convert fresh leads
      ->first();

    if (!$lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found or already converted',
        'error_msg' => 'Invalid lead_id',
        'data'      => null,
      ], 200);
    }

    // Success response

    $encrypted_values = $helper->encrypt_decrypt($lead_id, 'encrypt');
    return redirect()->route('project-add-customer', ['id' => $encrypted_values]);
  }


  public function Delete($id, Request $request)
  {

    $user_id              = $request->user()->user_id;
    $branch_id            = $request->user()->branch_id;
    $lead =  ProjectLeadModel::where('sno', $id)->first();
    $staff =  StaffModel::where('sno', $user_id)->first();
    $lead->status  = 2;
    $lead->Update();

    if ($lead) {
      // Embed the lead_name directly in notification content
      $notificationData = [
        'branch_id' => $branch_id,
        'notification_content' => '
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <span class="badge bg-gray-300">
                                <i class="mdi mdi-account-multiple-outline fs-3 text-black"></i>
                            </span>
                        </div>
                        <div class="me-2">
                            <a href="#" class="fs-7 text-primary fw-bold">Manage Lead</a>
                            <div class="text-secondary fs-8 fw-semibold"> Lead ' . $lead->lead_name . ' Dropped by ' . $staff->staff_name . '</div>
                        </div>
                    </div>',
        'who' => $user_id,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'status' => 0
      ];
      $notificationtype = 'CheckList';
      $newNotification = new \App\Helpers\Helpers();

      $newNotification->createNotification($notificationData, $notificationtype);
    }
    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $lead =  ProjectLeadModel::where('sno', $id)->first();

    $lead->status = $request->status;
    // return  $lead;
    if ($request->status == 0) {
      $lead->lead_status_id = 1;
      $lead->spam_reason = null;
      $lead->drop_reason = null;
      $lead->spam_comments = null;
      $lead->drop_comments = null;
      $lead->update();
    }
    $lead->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
