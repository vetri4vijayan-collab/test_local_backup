<?php

namespace App\Http\Controllers\project_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\ProjectPaymentModel;
use App\Models\BranchModel;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Exception;

class ProjectPayment extends Controller
{
  // ************************************* Lead List Pages **************************


  public function index(Request $request)
  {
    $page     = $request->input('page', 1);
    $perpage  = (int) $request->input('sorting_filter', 25);
    $search   = $request->search_fill ?? '';
    $today    = Carbon::today()->toDateString();

    $query = DB::table('epro_payment')
      ->select(
        'epro_payment.*',
        'za_project_customer.cus_name',
        'za_project_customer.cus_gender',
        'za_project_customer.cus_mobile',
        'za_project_customer.customer_id',
        'za_project_customer.sno as customer_sno',
        'et_manage_project.project_title',
        'et_manage_project.sno as project_sno',
        'et_manage_project.project_id'
      )
      ->join('za_project_customer', 'za_project_customer.sno', '=', 'epro_payment.customer_id')
      ->join('epro_services', 'epro_services.sno', '=', 'epro_payment.service_id')
      ->join('et_manage_project', 'et_manage_project.sno', '=', 'epro_services.project_id')
      ->where('epro_payment.status', 0) // Pending
      ->whereDate('epro_payment.next_pay_date', '<=', $today) // ✅ KEY CONDITION
      ->orderBy('epro_payment.next_pay_date', 'asc'); // overdue first

    if ($search != '') {
      $query->where(function ($q) use ($search) {
        $q->where('za_project_customer.cus_name', 'LIKE', "%{$search}%")
          ->orWhere('za_project_customer.customer_id', 'LIKE', "%{$search}%");
      });
    }
    $pendingpayment = $query->paginate($perpage);

    $branch = BranchModel::where('sno', auth()->user()->branch_id)->first();
    $gstPercentage = ($branch->gst_percentage ?? 0) / 100;


    $total_amount = DB::table('epro_payment')
      ->where('status', 0)
      ->whereDate('next_pay_date', '<=', $today)
      ->sum('total_amount');

    $balance_amount = DB::table('epro_payment')
      ->where('status', 0)
      ->whereDate('next_pay_date', '<=', $today)
      ->sum('balance_amount');


    return view('content.project.payment.payment_list', [
      'pendingpayment' => $pendingpayment,
      'gstPercentage'  => $gstPercentage,
      'totalAmount'  => $total_amount,
      'balanceAmount'  => $balance_amount,
      'perpage'        => $perpage,
      'search_fill'    => $search
    ]);
  }
}
