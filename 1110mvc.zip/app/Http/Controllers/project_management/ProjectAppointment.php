<?php

namespace App\Http\Controllers\project_management;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;

class ProjectAppointment extends Controller
{

  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_fill = $request->search_fill ?? '';

    $query = DB::table('epro_appointments')->where('epro_appointments.status', '!=', 2)
      ->select(
        'za_staff.staff_name',
        'epro_appointments.reason_id',
        'epro_appointments.status',
        'epro_appointments.sno',
        'za_project_customer.cus_name',
        'za_project_customer.customer_id',
        'epro_appointment_reason.reason',
        'epro_appointments.reason_id',
        'epro_appointments.others',
        'epro_appointments.appt_date'
      )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'epro_appointments.staff_id')
      ->leftJoin('za_project_customer', 'za_project_customer.sno', '=', 'epro_appointments.cus_id')
      ->leftJoin('epro_appointment_reason', 'epro_appointment_reason.sno', '=', 'epro_appointments.reason_id')
      ->orderBy('epro_appointments.sno', 'desc');

    if ($search_fill != '') {
      $query->where(function ($list) use ($search_fill) {
        $list->where('za_project_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('epro_appointment_reason.reason', 'LIKE', "%{$search_fill}%")
          ->orWhere('za_staff.staff_name', 'LIKE', "%{$search_fill}%");
      });
    }

    $lists = $query->get();

    return view('content.project.appointments.manage_appointments', [
      'lists' => $lists,
      'perpage' => $perpage,
      'search_fill' => $search_fill
    ]);
  }
  public function list()
  {
    $domain = DB::table('epro_appointment_reason')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $domain
    ], 200);
  }
  public function fetch_appointment_lead()
  {
    $leads = DB::table('za_project_lead')
      ->where('status', 0)
      ->select(
        'lead_name',
        'lead_id',
        'sno'
      )
      ->get();

    return response([
      'status' => 200,
      'message' => 'Lead Data Fetched!',
      'data' => $leads
    ], 200);
  }

  public function fetch_appointment_customer()
  {
    $customers = DB::table('za_project_customer')
      ->where('status', 0)
      ->select(
        'cus_name',
        'customer_id',
        'sno'
      )
      ->get();

    return response([
      'status' => 200,
      'message' => 'Customer Data Fetched!',
      'data' => $customers
    ], 200);
  }

  public function fetch_appointment_staff()
  {
    $staffs = DB::table('za_staff')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', 0)
      ->where('za_staff.sno', '>', 1)
      ->select(
        'za_staff.sno',
        'za_staff.staff_name',
        'za_job_position.job_position_name'
      )
      ->get();

    return response([
      'status' => 200,
      'message' => 'Customer Data Fetched!',
      'data' => $staffs
    ], 200);
  }

  public function add_appointment(Request $request)

  {
    $cusId      = $request->cus_id;
    $staffId    = $request->staff_id;
    $reasonId   = $request->reason_id;
    $others     = $request->others;
    $description = $request->description;
    $user_id    = $request->user()->user_id;


    $apptDate = Carbon::createFromFormat(
      'd-M-Y h:i A',
      $request->appointment_date
    )->format('Y-m-d H:i:s');


    $othersValue = ($reasonId == 0) ? $others : null;

    DB::table('epro_appointments')->insert([
      'cus_id'        => $cusId,
      'staff_id'      => $staffId,
      'appt_date'     => $apptDate,
      'reason_id'     => $reasonId,
      'others'        => $othersValue,
      'description'   => $description,
      'created_by'    => $user_id,
      'updated_by'    => $user_id,
      'created_at'    => now(),
      'updated_at'    => now(),
    ]);

    return response()->json([
      'status'    => 200,
      'message'   => 'Appointment Created Successfully!',
      'error_msg' => null,
      'data'      => null
    ], 200);
  }


  public function edit($id)
  {
    $data = DB::table('epro_appointments')
      ->where('status', '!=', 2)
      ->where('sno', $id)
      ->first();

    return response([
      'status' => 200,
      'message' => 'Data fetched successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function update(Request $request)
  {

    $cus_id = $request->cus_id;
    $others = $request->others;
    $apptDate = Carbon::createFromFormat('d-M-Y h:i A', $request->apptDate)->format('Y-m-d H:i:s');
    $staffId = $request->staffId;
    $reasonId = $request->reason_id;
    $description = $request->description;
    $user_id = $request->user()->user_id;
    $id = $request->id;

    $add = AppointmentModel::where('status', '!=', 2)->where('sno', $id)->first();
    $add->cus_id = $cus_id;
    $add->staff_id = $staffId;
    $add->appt_date = $apptDate;
    $add->reason_id = $reasonId;

    if ($reasonId == 0) {
      $add->others = $others;
    }

    $add->description = $description;
    $add->created_by = $user_id;
    $add->updated_by = $user_id;
    $add->update();

    return response([
      'status' => 200,
      'message' => 'Appointment Updated Successfully!',
      'error_msg' => null,
      'data' => null
    ], 200);
  }

  public function view($id)
  {
    $data = DB::table('epro_appointments')
      ->select(
        'epro_appointments.appt_date',
        'epro_appointment_reason.reason',
        'epro_appointments.reason_id',
        'epro_appointments.others',
        'epro_appointments.reply_message',
        'epro_appointments.status',
        'za_project_customer.cus_name',
        'za_project_customer.customer_id',
        'za_staff.staff_name'
      )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'epro_appointments.staff_id')
      ->leftJoin('za_project_customer', 'za_project_customer.sno', '=', 'epro_appointments.cus_id')
      ->leftJoin('epro_appointment_reason', 'epro_appointment_reason.sno', '=', 'epro_appointments.reason_id')
      ->where('epro_appointments.status', '!=', 2)
      ->where('epro_appointments.sno', $id)
      ->first();

    if ($data) {
      return response([
        'status' => 200,
        'message' => 'Data Fetched Successfully!',
        'error_msg' => null,
        'data' => $data
      ], 200);
    }
  }

  public function appointmentStatusChange(Request $request)
  {
    $id = $request->id;
    $replyMessage = $request->reply_message;

    // ✅ check record exists
    $appointment = DB::table('epro_appointments')
      ->where('status', '!=', 2)
      ->where('sno', $id)
      ->first();

    if (!$appointment) {
      return response()->json([
        'status' => 404,
        'message' => 'Appointment not found',
        'error_msg' => null,
        'data' => null
      ], 404);
    }

    // ✅ update using query builder
    DB::table('epro_appointments')
      ->where('sno', $id)
      ->update([
        'reply_message' => $replyMessage,
        'status'        => 1,
        'updated_at'    => now()
      ]);

    return response()->json([
      'status' => 200,
      'message' => 'Status Updated Successfully!',
      'error_msg' => null,
      'data' => null
    ], 200);
  }
}
