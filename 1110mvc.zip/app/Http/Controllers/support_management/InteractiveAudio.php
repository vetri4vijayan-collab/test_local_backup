<?php

namespace App\Http\Controllers\support_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LanguageModel;
use App\Models\InteractiveAudioModel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
class InteractiveAudio extends Controller
{
//   public function index()
//     {
//         // Fetch interactive audios along with course and course type
//         $interactive = InteractiveAudioModel::select(
//             'za_interactive_audio.*',
//             'za_audio_category.audio_category',
//             'za_course.course_name',
//             'za_course_type.course_type_name'
//         )
//         ->leftjoin('za_audio_category', 'za_audio_category.sno', '=', 'za_interactive_audio.category_id')
//         ->leftjoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')
//         ->leftjoin('za_course_type', 'za_course_type.sno', '=', 'za_interactive_audio.course_type_id')
//         ->get();
    
//         // Load all languages globally
//         $allLanguages = LanguageModel::pluck('name', 'iso_639_1'); // ['ar' => 'Arabic', ...]

//         return view('content.support_management.interactive_audio.interactive_audio_list', compact('interactive', 'allLanguages'));
//     }
//   public function index(Request $request)
// {
    
//     $branch_id = $request->user()->branch_id;
//     $search_fill = $request->search_fill ?? '';
//     $perpage = (int) $request->input('sorting_filter', 25);

//     $interactive = InteractiveAudioModel::select(
//             'za_interactive_audio.*',
//             'za_audio_category.audio_category',
//             'za_course.course_name',
//             'za_course_type.course_type_name'
//         )
//         ->leftJoin('za_audio_category', 'za_audio_category.sno', '=', 'za_interactive_audio.category_id')
//         ->leftJoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')
//         ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_interactive_audio.course_type_id');

//     if (!empty($search_fill)) {
//         $interactive->where(function ($query) use ($search_fill) {
//             $query->where('za_interactive_audio.description', 'LIKE', "%{$search_fill}%")
//                 ->orWhere('za_audio_category.audio_category', 'LIKE', "%{$search_fill}%");
//         });
//     }

//     $interactive = $interactive->orderBy('za_interactive_audio.sno', 'desc')
//                               ->paginate($perpage);

//     $allLanguages = LanguageModel::pluck('name', 'iso_639_1'); // English names
//     $allLanguagesNative = LanguageModel::pluck('native_name', 'iso_639_1'); // Native names

//     return view('content.support_management.interactive_audio.interactive_audio_list', compact('interactive', 'allLanguages','allLanguagesNative', 'perpage', 'search_fill'));
// }


public function index(Request $request)
{
    $branch_id  = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $perpage    = (int) $request->input('sorting_filter', 25);

    // Step 1: Fetch only categories (paginated)
    $categories = \DB::table('za_audio_category')
        ->select('za_audio_category.sno', 'za_audio_category.audio_category')
        ->join('za_interactive_audio', 'za_interactive_audio.category_id', '=', 'za_audio_category.sno')
        ->when($search_fill, function ($query, $search_fill) {
            $query->where(function ($q) use ($search_fill) {
                $q->where('za_interactive_audio.description', 'LIKE', "%{$search_fill}%")
                  ->orWhere('za_audio_category.audio_category', 'LIKE', "%{$search_fill}%");
            });
        })
        ->groupBy('za_audio_category.sno', 'za_audio_category.audio_category')
        ->orderBy('za_audio_category.sno', 'asc')
        ->paginate($perpage);

    // Step 2: Fetch all interactive audios for the selected categorie
    $interactive = InteractiveAudioModel::select(
            'za_interactive_audio.*',
            'za_course.course_name',
            'za_audio_category.audio_category',
            'za_course_type.course_type_name'
        )
        ->leftJoin('za_audio_category', 'za_audio_category.sno', '=', 'za_interactive_audio.category_id')
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')
        ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_interactive_audio.course_type_id')
        ->whereIn('za_interactive_audio.category_id', $categories->pluck('sno'))
        ->where('za_interactive_audio.status','!=', 2)
        ->get()
        ->groupBy('audio_category'); // key = category_id

    // Step 3: Languages
    $allLanguages       = LanguageModel::pluck('name', 'iso_639_1');
    $allLanguagesNative = LanguageModel::pluck('native_name', 'iso_639_1');

    return view('content.support_management.interactive_audio.interactive_audio_list', compact(
        'categories', 'interactive', 'allLanguages', 'allLanguagesNative', 'perpage', 'search_fill'
    ));
}



  public function audio_qr($id)
{
    $decodedId = base64_decode($id);

    $interactive = InteractiveAudioModel::select(
            'za_interactive_audio.*',
            'za_course.course_name',
            'za_course.course_days',
            'za_course.course_duration',
            'za_course.course_version',
            'za_course_type.course_type_name'
        )
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')
        ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_interactive_audio.course_type_id')
        ->where('za_interactive_audio.sno', $decodedId)
        ->where('za_interactive_audio.status', 0)
        ->first();

    // Flag to indicate availability
    $isAvailable = $interactive ? true : false;

    $allLanguages = LanguageModel::pluck('name', 'iso_639_1')->toArray();
    $audios = [];

    if ($interactive) {
        $audios = json_decode($interactive->interactive_audios, true) ?? [];

        foreach ($audios as &$item) {
            $item['language_name'] = $allLanguages[$item['language_id']] ?? $item['language_id'];
            $item['language_native_name'] = LanguageModel::where('iso_639_1', $item['language_id'])->value('native_name') ?? '';
            $item['url'] = asset($item['path']); 
        }
    }

    return view(
        'content.support_management.interactive_audio.interactive_audio_qr', 
        compact('interactive', 'allLanguages', 'audios', 'isAvailable')
    );
}

  public function languages()
    {
        return response()->json(\DB::table('za_languages')->get());
    }
  public function checkCourseExists(Request $request)
  {
    $courseId = $request->get('course_id');

    // Load all languages
    $allLanguages = LanguageModel::pluck('name', 'iso_639_1'); // ['ar' => 'Arabic', ...]

    // Fetch course data
    $course = DB::table('za_interactive_audio as ia')
        ->leftJoin('za_audio_category as cat', 'cat.sno', '=', 'ia.category_id')
        ->leftJoin('za_course as c', 'c.sno', '=', 'ia.course_id')
        ->leftJoin('za_course_type as ct', 'ct.sno', '=', 'ia.course_type_id')
        ->where('ia.course_id', $courseId)
        ->select(
            'ia.description',
            'ia.interactive_audios', // JSON array
            'c.course_name',
            'ct.course_type_name',
            'cat.audio_category as category_name'
        )
        ->first();

    if ($course) {
        $interactiveAudios = json_decode($course->interactive_audios, true);

        // Map language IDs to language names
        if ($interactiveAudios) {
            foreach ($interactiveAudios as &$audio) {
                $audio['language_name'] = $allLanguages[$audio['language_id']] ?? $audio['language_id'];
            }
        }

        return response()->json([
            'status' => 200,
            'exists' => true,
            'data' => [
                'description' => $course->description,
                'course_name' => $course->course_name,
                'course_type_name' => $course->course_type_name,
                'category_name' => $course->category_name,
                'interactive_audios' => $interactiveAudios
            ]
        ]);
    }

    return response()->json([
        'status' => 200,
        'exists' => false
    ]);
}


    public function upload(Request $request)
    {
        $request->validate([
            'item_id'    => 'required',
            'language'   => 'required',
            'audio_file' => 'required', 
            'duration_ms'=> 'required|integer',
        ]);
    
        $item = InteractiveAudioModel::findOrFail($request->item_id);
    
        $file = $request->file('audio_file');
        $filename = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('uploads/audio'), $filename);
        $path = 'uploads/audio/' . $filename;
    
        // Decode existing audios safely
        $audios = json_decode($item->interactive_audios, true) ?? [];
    
        // Add new audio entry
        $audios[] = [
            'language_id'   => $request->language,
            'path'          => $path,
            'original_name' => $file->getClientOriginalName(),
            'duration_ms'   => (int) $request->duration_ms,
        ];
    
        // Save back as JSON
        $item->interactive_audios = json_encode($audios);
        $item->save();
    
        // Count updated
        $count = count($audios);
    
        return response()->json([
            'success'  => true,
            'message'  => 'Uploaded successfully',
            'language' => $request->language,
            'count'    => $count,
        ]);
    }


    public function add(Request $request)
       {
        // Validate required fields
        $request->validate([
            'languages'      => 'required|array',
            'audios'         => 'required|array',
            'audios.*'       => 'required', // max 10MB
            'duration_ms'    => 'required|array',
        ]);
    
        DB::beginTransaction();
    
        try {
            $languages = $request->input('languages');
            $audios    = $request->file('audios');
            $durations = $request->input('duration_ms');
    
            $payloadItems = [];
    
            foreach ($audios as $i => $audioFile) {
                $language = $languages[$i] ?? null;
                $duration = $durations[$i] ?? 0;
    
                if (!$language) continue;
    
                // Save file in public/interactive_audios
                $filename = time() . '_' . $audioFile->getClientOriginalName();
                $path = 'interactive_audios/' . $filename;
                $audioFile->move(public_path('interactive_audios'), $filename);
    
                $payloadItems[] = [
                    'language_id'   => $language,
                    'path'          => $path, // relative path inside /public
                    'original_name' => $audioFile->getClientOriginalName(),
                    'duration_ms'   => (int) $duration,
                ];
            }
    
            // Create DB record
            $model = InteractiveAudioModel::create([
                'branch_id'          => $request->user()->branch_id ?? null,
                'course_type_id'     => $request->input('course_type_id'),
                'category_id'        => $request->input('category_id'),
                'title'              => $request->input('title'),
                'course_id'          => $request->input('course_id'),
                'interactive_audios' => json_encode($payloadItems),
                'description'        => $request->input('description'),
                'created_by'         => $request->user()->user_id ?? null,
                'updated_by'         => $request->user()->user_id ?? null,
            ]);
    
            // Generate QR code URL using Google Charts API
            $qrCodeUrl = 'https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl=' 
                . urlencode(url("/interactive_audio_qr/{$model->sno}"));
    
            // Save QR code URL directly in DB
            $model->qr_code_path = $qrCodeUrl;
            $model->save();
    
            DB::commit();
    
            return response()->json([
                'status'  => 200,
                'message' => 'Interactive audio saved successfully',
                'data'    => $model
            ]);
    
        } catch (\Exception $e) {
            DB::rollBack();
    
            return response()->json([
                'status'  => 500,
                'message' => 'Error saving interactive audio: ' . $e->getMessage(),
            ], 500);
        }
    }
    public function update(Request $request)
       {
    $request->validate([
        'edit_id'        => 'required|integer',
        'course_type_id' => 'required|integer',
        'course_id'      => 'required|integer',
        'languages'      => 'required|array',
        'duration_ms'    => 'required|array',
        'audios.*'       => 'nullable', // optional if replacing
    ]);
    // return $request->all();

    DB::beginTransaction();
    try {
        $model = InteractiveAudioModel::findOrFail($request->edit_id);

        $languages = $request->input('languages');
        $durations = $request->input('duration_ms');
        $audios    = $request->file('audios') ?? [];

        $existingAudios = $request->input('existing_audios', []); // keep old audios
        $payloadItems   = [];

        foreach ($languages as $i => $lang) {
            $duration = $durations[$i] ?? 0;

            if (isset($audios[$i])) {
                $audioFile = $audios[$i];
                $filename = time() . '_' . $audioFile->getClientOriginalName();
                $path = 'interactive_audios/' . $filename;
                $audioFile->move(public_path('interactive_audios'), $filename);
            } else {
                $path = $existingAudios[$i] ?? null;
            }

            if ($path) {
                $payloadItems[] = [
                    'language_id'   => $lang,
                    'path'          => $path,
                    'original_name' => basename($path),
                    'duration_ms'   => (int) $duration,
                ];
            }
        }

        $model->update([
            'course_type_id'     => $request->course_type_id,
            'course_id'          => $request->course_id,
            'description'        => $request->description,
            'interactive_audios' => json_encode($payloadItems),
            'updated_by'         => $request->user()->user_id ?? null,
        ]);

        DB::commit();

        return response()->json([
            'status'  => 200,
            'message' => 'Interactive Audio updated successfully',
            'data'    => $model,
        ]);
    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json([
            'status'  => 500,
            'message' => 'Error updating interactive audio: ' . $e->getMessage(),
        ], 500);
    }
}


 public function view($id)
{
    $interactive = InteractiveAudioModel::select(
            'za_interactive_audio.*',
            'za_audio_category.audio_category',
            'za_course.course_name',
            'za_course_type.course_type_name'
        )
         ->leftjoin('za_audio_category', 'za_audio_category.sno', '=', 'za_interactive_audio.category_id')
        ->leftjoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')
        ->leftjoin('za_course_type', 'za_course_type.sno', '=', 'za_interactive_audio.course_type_id')
        ->where('za_interactive_audio.sno', $id)
        ->first();

   // Get language names
    $allLanguages = LanguageModel::pluck('name', 'iso_639_1')->toArray();
    // Decode JSON audio items
  
    $audios = json_decode($interactive->interactive_audios, true);

    foreach ($audios as &$item) {
        $item['language_name'] = $allLanguages[$item['language_id']] ?? $item['language_id'];
    
        // Correct URL (because files are in public/interactive_audios)
        $item['url'] = asset($item['path']); 
    }

    return response()->json([
        'status' => 200,
        'data' => [
            'title' => $interactive->title ?? 'N/A',
            'type_id' => $interactive->type_id ?? 'N/A',
            'audio_category' => $interactive->audio_category ?? 'N/A',
            'course_name' => $interactive->course_name ?? 'N/A',
            'course_type' => $interactive->course_type_name ?? 'N/A',
            'audios'      => $audios
        ]
    ]);
}
public function edit($id)
{
    $interactive = InteractiveAudioModel::where('sno', $id)->first();

    if (!$interactive) {
        return response()->json([
            'status' => 404,
            'message' => 'Record not found'
        ], 404);
    }

    // Decode JSON audio items
    $audios = json_decode($interactive->interactive_audios, true) ?? [];

    // Add language names and URLs
    $allLanguages = LanguageModel::pluck('name', 'iso_639_1')->toArray();
    foreach ($audios as &$item) {
        $item['language_name'] = $allLanguages[$item['language_id']] ?? $item['language_id'];
        $item['url'] = asset($item['path']);
    }

    return response()->json([
        'status' => 200,
        'data' => [
            'sno'                => $interactive->sno,
            'title'              => $interactive->title,
            'category_id'        => $interactive->category_id,
            'type_id'            => $interactive->type_id,
            'course_type_id'     => $interactive->course_type_id,
            'course_id'          => $interactive->course_id,
            'description'        => $interactive->description,
            'interactive_audios' => json_encode($audios), // send as JSON string
        ]
    ]);
}


public function generateQr($id)
{
    $interactive = $interactive = InteractiveAudioModel::select(
            'za_interactive_audio.*',
            'za_course.course_name'
        )
        ->leftJoin('za_course', 'za_course.sno', '=', 'za_interactive_audio.course_id')->findOrFail($id);
    // Encode sno in base64 (shorter than Crypt)
    $encodedId = base64_encode($interactive->sno);

    $qrContent = url("/interactive_audio_qr/{$encodedId}");

    // Generate QR as base64 image
    $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=300x300";
    $qrImageData = @file_get_contents($qrServerUrl);
    $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;

    return response()->json([
        'status'    => $qrBase64 ? 200 : 500,
        'qr_base64' => $qrBase64,
        'link'      => $qrContent,
        'course_name' => $interactive->course_name ?? 'course',
    ]);
}

 public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  InteractiveAudioModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
 public function Delete($id)
  {
    $upd_CourseCategoryModel =  InteractiveAudioModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


}
?>