<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Education;
use App\Models\Course;
use App\Models\Batch;
use App\Models\Payment;

class CustomerController extends Controller
{
    public function save(Request $request)
    {
        // Get the current step from the request
        $step = $request->input('step');

        // Save the step data to the session
        session(['customer_form_step_' . $step => $request->except(['_token', 'step'])]);

        // If it's the final step, process the data and save to the database
        if ($step == 5) {
            $basicDetails = session('customer_form_step_1', []);
            $educationDetails = session('customer_form_step_2', []);
            $courseDetails = session('customer_form_step_3', []);
            $batchDetails = session('customer_form_step_4', []);
            $paymentDetails = $request->except(['_token', 'step']);

            // Save to database
            $customer = Customer::create($basicDetails);
            Education::create(array_merge($educationDetails, ['customer_id' => $customer->id]));
            Course::create(array_merge($courseDetails, ['customer_id' => $customer->id]));
            Batch::create(array_merge($batchDetails, ['customer_id' => $customer->id]));
            Payment::create(array_merge($paymentDetails, ['customer_id' => $customer->id]));

            // Clear the session data
            session()->forget(['customer_form_step_1', 'customer_form_step_2', 'customer_form_step_3', 'customer_form_step_4', 'customer_form_step_5']);

            return redirect()->route('customer.success');
        }

        // Redirect to the next step
        return redirect()->route('customer.add', ['step' => $step + 1]);
    }

    public function add($step = 1)
    {
        $stepData = session('customer_form_step_' . $step, []);
        return view('customer.add', compact('step', 'stepData'));
    }
}