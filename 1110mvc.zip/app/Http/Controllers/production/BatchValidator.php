<?php

namespace App\Http\Controllers\production;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\StaffModel;
use App\Models\GeneralSettingsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class BatchValidator extends Controller
{
  public function index(Request $request)
  {
      $monitor = DB::table('et_cronjob_monitor')
      ->where('sno', 14)
      ->first();

    return view('content.production.batch_validator.batch_validator_list', [
            'monitor' => $monitor,
        ]);
  }


  public function batchTaskList(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'type' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status'  => 422,
        'message' => 'Validation Error',
        'errors'  => $validator->errors()
      ], 422);
    }


    //  Base Query
    $query = DB::table('za_batch_daily_task')
      ->join('za_batch', 'za_batch.sno', '=', 'za_batch_daily_task.batch_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch_daily_task.slot_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_staff', 'za_batch_daily_task.resolved_by', '=', 'za_staff.sno')
      ->where('za_batch.status', 0);

    $tasks = $query->select(  
      'za_batch.sno',
      'za_batch.batch_name',
      'za_course.course_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot_type.slot_type_name',
      'za_batch_daily_task.status',
      'za_batch_daily_task.date',
      'za_batch_daily_task.task_check_list',
      'za_batch_daily_task.task_description',
      'za_batch_daily_task.task_attachment',
      'za_batch_daily_task.grievance_data',
      'za_batch_daily_task.acknowledgement',
      'za_staff.staff_name',
      'za_batch_daily_task.resolved_date'


    )->get();
    
    // return $tasks;

    $today = Carbon::now();
    $nowTime = Carbon::now()->format('H:i:s');

    $result = [];

    //  Dashboard counters
    $total = 0;
    $todaycount = 0;
    $completed = 0;
    $pending = 0;
    $issue = 0;
    $resolved = 0;


    foreach ($tasks as $task) {

      $total++;

      $startDate = Carbon::parse($task->start_date);
      $endDate = Carbon::parse($task->end_date);

      //  Progress %
      $totalDays = $startDate->diffInDays($endDate) ?: 1;
      $completedDays = $startDate->diffInDays($today, false);
      $progress = max(0, min(100, ($completedDays / $totalDays) * 100));

      

      //  Time Unlock
      $isUnlocked = false;
      if ($task->start_time && $task->end_time) {
        $isUnlocked = ($nowTime >= $task->start_time && $nowTime <= $task->end_time);
      }


      $taskDate = Carbon::parse($task->date)->format('Y-m-d');
    $todayDate = Carbon::today()->format('Y-m-d');

    $statusLabel = 'Not Started';

    if ($task->status == 1) {

        $statusLabel = 'Completed';
        $completed++;

    } elseif ($task->status == 3) {

        $statusLabel = 'Issue';
        $issue++;

    } elseif ($task->status == 4) {

        $statusLabel = 'Resolved';
        $resolved++;

    } else {

        // Previous date => Pending
        if ($taskDate < $todayDate) {

            $statusLabel='Pending';
            $pending++;

        }

        // Today's task
        elseif ($taskDate == $todayDate) {

            $statusLabel='Not Started';
            $todaycount++;
        }
    }

      // //  STATUS LOGIC (IMPORTANT)
      // $statusLabel = 'Not Started';

      // if ($task->status == 1) {
      //   $statusLabel = 'Completed';
      //   $completed++;
      // } elseif ($task->status == 3) {
      //   $statusLabel = 'Issue';
      //   $issue++;
      // }elseif ($task->status == 4) {
      //   $statusLabel = 'Resolved';
      //   $resolved++;
      // } else {
      //   // Not completed → check time
      //   if ($nowTime > $task->end_time) {
      //     $statusLabel = 'Pending';
      //     $pending++;
      //   } else {
      //     $statusLabel = 'Not Started';
      //     $todaycount++;
      //   }
      // }


      //  FILTER TYPE (after status calculation)
      if (strtolower($request->type) == 'completed' && $statusLabel != 'Completed') continue;
      if (strtolower($request->type) == 'issue' && $statusLabel != 'Issue') continue;
      if (strtolower($request->type) == 'pending' && $statusLabel != 'Pending') continue;
      if (strtolower($request->type) == 'resolved' && $statusLabel != 'Resolved') continue;
      if (strtolower($request->type) == 'today' && !in_array($statusLabel,['Not Started','Pending'])){ continue;}


      $result[] = [
        'batch_id'    => $task->sno ?? '-',
        'batch_name'  => $task->batch_name ?? '-',
        'course_name' => $task->course_name ?? '-',
        'start_date'  => $startDate->format('d M Y'),
        'end_date'    => $endDate->format('d M Y'),
        'start_time'  => date('gA', strtotime($task->start_time)),
        'end_time'    => date('gA', strtotime($task->end_time)),
        'slot_type'   => $task->slot_type_name ?? '-',

        'progress'    => number_format($progress, 2),
        'is_unlocked' => $isUnlocked,

        'status'      => $statusLabel,

        'task_check_list' => $task->task_check_list
            ? json_decode($task->task_check_list, true)
            : [],

        'task_description' => $task->task_description ?? '',

        'task_attachment' => $task->task_attachment
            ? json_decode($task->task_attachment, true)
            : [],

        'grievance_data' => $task->grievance_data
            ? json_decode($task->grievance_data, true)
            : [],

        'acknowledge_note' => $task->acknowledgement ?? null,

        'resolved_by' => $task->staff_name ?? null,

        'resolved_date' => !empty($task->resolved_date)
            ? Carbon::parse($task->resolved_date)
                ->format('d M Y h:i A')
            : null,
      ];
    }

    //  Completion %
    // $completionPercentage = number_format(($completed / $total) * 100, 2, '.', '');
    $completionPercentage = ($total > 0)
      ? number_format(($completed / $total) * 100, 1)
      : 0;



    return response()->json([
      'status' => 200,
      'message' => 'Daily Task successfully',

      'dashboard' => [
        'total_task_count' => $total,
        'today_count'      => $todaycount + $pending,
        'completed_count'  => $completed,
        'pending_count'    => $pending,
        'issue_count'      => $issue,
        'resolved_count'      => $resolved,

        'completion_percentage' => $completionPercentage
      ],

      'data' => $result
    ]);
  }

  public function batchCommonSave(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'type' => 'required|in:checklist,grievance',
      'data' => 'required|array'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => false,
        'message' => 'Validation Error',
        'errors' => $validator->errors()
      ], 422);
    }

    $column = $request->type == 'checklist'
      ? 'batch_check_list'
      : 'batch_grievance';

    GeneralSettingsModel::updateOrCreate(
      ['sno' => 1],
      [$column => json_encode($request->data)]
    );

    return response()->json([
      'status' => true,
      'message' => ucfirst($request->type) . ' saved successfully'
    ]);
  }

  public function batchCommonFetch(Request $request)
  {
    $type = $request->type;

    $column = $type == 'checklist'
      ? 'batch_check_list'
      : 'batch_grievance';

    $genset = GeneralSettingsModel::where('sno', 1)->first();

    $data = [];

    if ($genset && $genset->$column) {
      $data = json_decode($genset->$column, true);
    }

    return response()->json([
      'status' => true,
      'data' => $data
    ]);
  }

    public function acknowledgeTaskIssue(Request $request)
  {
      $user_id = auth()->user()->user_id;
      $request->validate([
          'batch_id'=>'required',
          'remarks'=>'required|string'
      ]);

      DB::table('za_batch_daily_task')
      ->where('batch_id',$request->batch_id)
      ->update([
          'acknowledgement'=>$request->remarks,
          'resolved_by'=>$user_id,
          'resolved_date'=>now(),
          'status'=>4,
          'updated_at'=>now()
      ]);
      // DB::table('za_batch_daily_task')
      //     ->where('batch_id', $request->batch_id)
      //     ->update([
      //         'status' => 4, // acknowledged
      //         'updated_at' => now()
      //     ]);

      return response()->json([
          'status' => 200,
          'message' => 'Issue acknowledged successfully'
      ]);
  }

    public function updateSwitch(Request $request)
  {
    $newStatus = $request->status;

    // Example: update in settings table
    DB::table('et_cronjob_monitor')
      ->where('sno', 14)
      ->update(['status' => $newStatus]);

    return response()->json([
      'status' => true,
      'new_status' => $newStatus
    ]);
  }

}
