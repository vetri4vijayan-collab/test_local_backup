<?php

namespace App\Http\Controllers\production;

use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchHistoryModel;
use App\Models\BatchModel;
use App\Models\CourseTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchExtensionModel;
use App\Models\PaymentModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\StaffModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\LeadModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;


class ManageCosting extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->query('branch_id', $request->user()->branch_id); // Use branch_id from query or user session
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;

        $batch = BatchModel::select('za_batch.*', 'za_staff.staff_name','za_slot.slot_type_id','za_batch_extension.status AS exten_status', 'za_staff.nick_name', 'za_course.course_type_id', 'za_course.course_duration', 'za_slot.start_time', 'za_slot.end_time', 'za_batch.start_date', 'za_batch.end_date')
            ->leftjoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
            ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
            ->leftjoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            })->where('za_batch.status', '!=', [2, 3]);

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }

        $batchResults = $batch->orderBy('sno', 'desc')->paginate($perpage);
        $batch->batch_duration = 0;

        foreach ($batchResults as $batch) {
            // Convert start_time and end_time to Carbon instances
            $startTime = Carbon::parse($batch->start_time);
            $endTime = Carbon::parse($batch->end_time);

            // Calculate the duration in minutes
            $durationInMinutes = $startTime->diffInMinutes($endTime);

            // Convert minutes to hours and minutes
            $hours = floor($durationInMinutes / 60);
            $minutes = $durationInMinutes % 60;

            // Format the batch duration as "X hr Y mins"
            $batch->batch_duration = "{$hours} hr " . ($minutes > 0 ? "{$minutes} min" : '');

            // Calculate total duration in hours (you can use minutes too, depending on how you want to store it)
            $totalDurationInHours = $hours + ($minutes / 60);

            // Check attendance for each day between start_date and end_date
            $currentDate = Carbon::parse($batch->start_date);
            $endDate = Carbon::parse($batch->end_date);

            while ($currentDate->lte($endDate)) {
                // Check if there is attendance for the current day
                $attendanceExists = \DB::table('za_batch_history')
                    ->where('batch_id', $batch->sno)
                    ->whereDate('att_date', $currentDate)  // Check for attendance on the current date
                    ->whereNotNull('attendance')  // Assuming attendance column must not be null
                    ->exists();

                if ($attendanceExists) {
                    // Ensure spending_hrs is initialized
                    if (!isset($batch->spending_hrs)) {
                        $batch->spending_hrs = 0;
                    }

                    // Add the total duration (in hours) to spending_hrs for the current day
                    $batch->spending_hrs += $totalDurationInHours;
                }

                // Move to the next day
                $currentDate->addDay();
            }
        }

        foreach ($batchResults as $slotType) {

            $cos = TrainingModel::where('branch_id', $branch_id)
                ->where('batch_id', $slotType->sno)
                ->get();

            // Initialize total amount
            $slotType->total_amount = 0;
            $slotType->actual_amount = 0;
            $slotType->paid_amount = 0;
            $slotType->student_count = 0;

            // Iterate over each costing item in the collection
            foreach ($cos as $costing) {
                // Calculate total payment for the current course in the current month
                $slotType->total_amount += AttendanceModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->where('attendance', '=', 'P')
                    ->whereBetween('att_date', [$costing->start_date, $costing->end_date])  // Adding the date range check
                    ->sum('total_cost');

                // Calculate actual amount based on training details
                $slotType->actual_amount += TrainingModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->whereBetween('start_date', [$costing->start_date, $costing->end_date])
                    ->whereBetween('end_date', [$costing->start_date, $costing->end_date])
                    ->sum('overall_fees');

                $slotType->paid_amount += TrainingModel::where('branch_id', $costing->branch_id)
                ->where('customer_id', $costing->customer_id)
                ->where('course_id', $costing->course_id)
                ->whereBetween('start_date', [$costing->start_date, $costing->end_date])
                ->whereBetween('end_date', [$costing->start_date, $costing->end_date])
                ->sum('paid_amount');

                $slotType->student_count += TrainingModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->distinct('customer_id')
                    ->count('customer_id');
            }
        }

        // return $batch;
        // Prepare data for the chart
        $batchNames = [];
        $batchTotals = [];

        foreach ($batchResults as $category) {
            $batchNames[] = $category->batch_name;
            $batchTotals[] = (float) $category->total_amount;
        }

        $batch_list = BatchModel::where('za_batch.status', 0)
            // Filter batches where the end date is after or within the current month
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }
        $batch_list = $batch_list->orderBy('sno', 'desc')->get();

        $pageConfigs = ['myLayout' => 'default'];

        // return $batchResults;

        return view(
            'content.production.manage_costing.costing_batch_list',
            [
                'batch' => $batchResults,
                'perpage'    => $perpage,
                'pageConfigs' => $pageConfigs,
                'batchNames' => $batchNames,
                'batchTotals' => $batchTotals,
                'batch_name_fill' => "",
                'fin_yr_fill' => '',
                'date_filter' => '',
                'batch_list' => $batch_list
            ]
        )->with('filter_on', false);
    }

    public function batch_Filter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        // return $request;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        // return $perpage;

        $batch_name_fill = $request->batch_name_fill_sno ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';

        $query = BatchModel::select('za_batch.*', 'za_staff.staff_name', 'za_staff.nick_name', 'za_course.course_type_id', 'za_course.course_duration', 'za_slot.start_time', 'za_slot.end_time', 'za_batch.start_date', 'za_batch.end_date')
            ->leftjoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_course', 'za_batch.course_id', '=', 'za_course.sno')
            ->leftjoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_batch.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_batch.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_batch.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_batch.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_batch.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_batch.created_at', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_batch.created_at', $condition['year'])
                                        ->whereMonth('za_batch.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }

        if ($batch_name_fill) {
            $query->where('za_batch.sno', $batch_name_fill);
        }
        if ($branch_id != 0) {
            $query->where('za_batch.branch_id', $branch_id);
        }

        $batch = $query->paginate($perpage);

        $batch->batch_duration = 0;

        foreach ($batch as $bat) {
            // Convert start_time and end_time to Carbon instances
            $startTime = Carbon::parse($bat->start_time);
            $endTime = Carbon::parse($bat->end_time);

            // Calculate the duration in minutes
            $durationInMinutes = $startTime->diffInMinutes($endTime);

            // Convert minutes to hours and minutes
            $hours = floor($durationInMinutes / 60);
            $minutes = $durationInMinutes % 60;

            // Format the bat duration as "X hr Y mins"
            $bat->batch_duration = "{$hours} hr " . ($minutes > 0 ? "{$minutes} min" : '');

            // Calculate total duration in hours (you can use minutes too, depending on how you want to store it)
            $totalDurationInHours = $hours + ($minutes / 60);

            // Check attendance for each day between start_date and end_date
            $currentDate = Carbon::parse($bat->start_date);
            $endDate = Carbon::parse($bat->end_date);

            while ($currentDate->lte($endDate)) {
                // Check if there is attendance for the current day
                $attendanceExists = \DB::table('za_batch_history')
                    ->where('batch_id', $bat->sno)
                    ->whereDate('att_date', $currentDate)  // Check for attendance on the current date
                    ->whereNotNull('attendance')  // Assuming attendance column must not be null
                    ->exists();

                if ($attendanceExists) {
                    // Ensure spending_hrs is initialized
                    if (!isset($bat->spending_hrs)) {
                        $bat->spending_hrs = 0;
                    }

                    // Add the total duration (in hours) to spending_hrs for the current day
                    $bat->spending_hrs += $totalDurationInHours;
                }

                // Move to the next day
                $currentDate->addDay();
            }
        }

        foreach ($batch as $slotType) {

            $cos = TrainingModel::where('branch_id', $branch_id)
                ->where('batch_id', $slotType->sno)
                ->get();

            // Initialize total amount
            $slotType->total_amount = 0;
            $slotType->actual_amount = 0;
            $slotType->paid_amount = 0;
            $slotType->student_count = 0;
            $customerIds = $cos->pluck('customer_id')->unique();
                
            // Iterate over each costing item in the collection
            foreach ($cos as $costing) {
                // Calculate total payment for the current course in the current month
                $slotType->total_amount += AttendanceModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->where('attendance', '=', 'P')
                    ->whereBetween('att_date', [$costing->start_date, $costing->end_date])  // Adding the date range check
                    ->sum('total_cost');

                // Calculate actual amount based on training details
                $slotType->actual_amount += TrainingModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->whereMonth('start_date', $currentMonth)
                    ->whereYear('end_date', $currentYear)
                    ->sum('overall_fees');

                $slotType->paid_amount += TrainingModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->whereMonth('start_date', $currentMonth)
                    ->whereYear('end_date', $currentYear)
                    ->sum('paid_amount');
                
                $slotType->student_count += TrainingModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->distinct('customer_id')
                    ->count('customer_id');
            }
        }
        // dd($batch);
        // Prepare data for the chart
        $batchNames = [];
        $batchTotals = [];

        foreach ($batch as $category) {
            $batchNames[] = $category->batch_name;
            $batchTotals[] = (float) $category->total_amount;
        }

        $batch_list = BatchModel::where('za_batch.status', 0)
            // Filter batches where the end date is after or within the current month
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }
        $batch_list = $batch_list->orderBy('sno', 'desc')->get();

        $pageConfigs = ['myLayout' => 'default'];
        // return $perpage;

        // return $batch;

        // Return the view with filter variables and session flash for filter_on
        return view('content.production.manage_costing.costing_batch_list', [
            'batch' => $batch,
            'perpage' => $perpage,
            'batchNames' => $batchNames,
            'batchTotals' => $batchTotals,
            'batch_list' => $batch_list,
            'batch_name_fill' => $batch_name_fill,
            'date_filter' => $date_filter,
            'fin_yr_fill' => $fin_yr_fill,
        ])->with('filter_on', true);
    }

    public function studentDetailsBatch(Request $request)
    {
        $batch_id = $request->input('batch_id');
        $branch_id = auth()->user()->branch_id; // Assuming branch ID is tied to the current user
        
        // Get course details
        $cos = TrainingModel::where('branch_id', $branch_id)
            ->where('batch_id', $batch_id)
            ->get();
    
        $cos->studDetails = [];
    
        // Get student details for the batch
        $cos->studDetails = LeadModel::select('za_lead.lead_name', 'za_lead.lead_mobile', 'za_staff.staff_name', 
            'za_staff.position_role', 'za_job_position.job_position_name', 'za_customer.lead_id', 
            'za_customer.sno as cus_sno', 'za_training.customer_id', 'za_training.course_id', 
            'za_training.branch_id', 'za_training.overall_fees', 'za_training.paid_amount', 
            'za_training.balance_amount', 'za_training.created_at as training_created', 
            'za_course.course_name', 'za_course.course_type_id', 'za_course_type.course_type_name')
        ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
        ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
        ->leftJoin('za_customer', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
        ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->where('za_lead.status', 4)
        ->where('za_lead.created_by', '>', 0)
        ->where('za_training.branch_id', $branch_id)
        ->where('za_training.batch_id', $batch_id)
        ->get()
        ->groupBy('customer_id');
        
        // Loop through each customer and calculate the total cost
        foreach ($cos->studDetails as $customer) {
            foreach ($customer as $details) {
                $total_cost = AttendanceModel::select('total_cost')->where('branch_id', $branch_id) 
                    ->where('customer_id', $details->customer_id) 
                    ->where('course_id', $details->course_id)
                    ->where('attendance', '=', 'P') 
                    ->sum('total_cost');  
    
                // Add the total_cost to the customer's details
                $details->total_cost = $total_cost;
            }
        }

        // return $cos->studDetails;
    
    
        // Return the response with the updated details
        return response()->json(['status' => 200, 'data' => $cos->studDetails]);
    }
    
    public function staffList(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $year  = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek;

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        $datesInMonth = collect();

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        $staff = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_staff.staff_image',
            // 'za_batch.end_date',
            // 'za_batch.slot_id',
            // 'za_slot.start_time',
            // 'za_slot.end_time',
            // 'za_batch.sno as batch_ids',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status AS staff_status',
        )
        // ->leftJoin('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        // ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        // ->where(function ($query) use ($month, $year) {
        //     $query->whereYear('za_batch.end_date', '>', $year)
        //         ->orWhere(function ($query) use ($month, $year) {
        //             $query->whereYear('za_batch.end_date', '=', $year)
        //                 ->whereMonth('za_batch.end_date', '>=', $month);
        //         });
        // })
        // ->leftJoin('za_training', function ($join) {
        //     $join->on('za_training.batch_id', '=', 'za_batch.sno');
        // })
        ->where('za_staff.status', '!=', 2)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            // 'za_batch.end_date',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.sno', // za_batch.sno as batch_ids for groupBy
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc')
        ->paginate(25);
        // ->get();
        // return  $staff;

        $staff = $staff->unique('staff_id'); 

        foreach ($staff as $slotType) {
            
            $slotType->earned_amount = 0;
            $slotType->batch_count = 0;
            $slotType->student_count = 0;
            $slotType->present_count = 0;
            $slotType->course_count = 0;
            $slotType->slotDetails = [];
        
            $batchIds = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct()
                ->pluck('batch_id')
                ->toArray(); // Ensure it's an array
        
            $slotType->batch_ids = $batchIds; // Save batch IDs

            // return $slotType;
      
            foreach ($slotType->batch_ids as $batchId) {
                // Fetch the batch details
                $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->find($batchId);
            
                if ($batch) {
                    
                    $presentCount = \DB::table('za_attendance')
                        ->where('batch_id', $batch->sno)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->count('customer_id'); // Count the customer_id for present students
            
                 
                    $slotType->present_count = $presentCount;

                    $attendanceRecords = \DB::table('za_attendance')
                        ->select('*')
                        ->where('batch_id', $batch->sno)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->get();
                    
                    foreach ($attendanceRecords as $attendance) {
            
                        $slotType->earned_amount +=  $attendance->per_hr_cost;
                    }
                }
            }
            
                // return $slotType;
            $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('customer_id') 
                ->count('customer_id');
        
            $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('course_id') 
                ->count('course_id');
        
            $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('batch_id')
                ->count('batch_id');
            
        
            $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->pluck('batch_id')) 
                ->where('za_batch.status', 0)
                ->get();

           
        }
        
        $staffNames = [];
        $staffTotals = [];

        foreach ($staff as $category) {
            $staffNames[] = $category->staff_name;
            $staffTotals[] = (float) $category->present_count * $category->per_hr_cost;
        }
       

        // return $staff;   

        $staff_list = StaffModel::select('za_staff.sno', 'za_staff.staff_name', 'za_staff.nick_name')
            ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where(function ($query) use ($month, $year) {
                // Only include batches that end in the current month or future
                $query->whereYear('za_batch.end_date', '>', $year)
                    ->orWhere(function ($query) use ($month, $year) {
                        $query->whereYear('za_batch.end_date', '=', $year)
                            ->whereMonth('za_batch.end_date', '>=', $month);
                    });
            })
            ->where('za_staff.status', 0)
            ->orderBy('za_staff.sno', 'desc')
            ->distinct('za_staff.staff_id') 
            ->get();

        // $staff_list = $staff_list->unique('staff_id');
        // dd($staff);

        $paginatedStaff = new LengthAwarePaginator(
            $staff->slice($offset, $perpage)->values(),
            $staff->count(), 
            $perpage, 
            $page, 
            ['path' => request()->url(), 'query' => request()->query()] 
        );
        
        return view(
            'content.production.manage_costing.costing_staff_list',
            [
                'staff' => $paginatedStaff, 
                'perpage' => $perpage,
                'staff_list' => $staff_list,
                'staffNames' => $staffNames,
                'staffTotals' => $staffTotals,
                'staff_name_fill' => "",
                'per_hr_cost_fill' => "",
                'fin_yr_fill' => '',
                'date_filter' => '',
                'month_chk' => $month_chk,
                'previousMonth' => $previousMonth,
                'previousYear' => $previousYear,
                'nextMonth' => $nextMonth,
                'nextYear' => $nextYear,
                'startDayOfWeek' => $startDayOfWeek,
            ]
        )->with('filter_on', false);
        
    }

    public function StaffFilter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        // Get current year and month from the request, defaulting to the current date if not provided
        $year  = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        // Calculate the previous and next month/year
        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        // Get the first day of the selected month
        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek;

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        $datesInMonth = collect();

        $staff_name_fill = $request->staff_name_fill ?? '';
        $per_hr_cost_fill = $request->per_hr_cost_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        // return $perpage;

        $query = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_staff.staff_image',
            // 'za_batch.end_date',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.sno as batch_ids', // Using za_batch.sno as batch_ids for matching
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status AS staff_status',
        )
        // ->leftJoin('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        // ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        // ->where(function ($query) use ($month, $year) {
        //     // Only include batches that end in the current month or future
        //     $query->whereYear('za_batch.end_date', '>', $year)
        //         ->orWhere(function ($query) use ($month, $year) {
        //             $query->whereYear('za_batch.end_date', '=', $year)
        //                 ->whereMonth('za_batch.end_date', '>=', $month);
        //         });
        // })
        // ->leftJoin('za_training', function ($join) {
        //     // Ensure za_training is joined on za_batch.sno (as batch_ids)
        //     $join->on('za_training.batch_id', '=', 'za_batch.sno');
        // })
        ->where('za_staff.status', '!=', 2)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.end_date',
            // 'za_batch.sno', // za_batch.sno as batch_ids for groupBy
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc');


        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_staff.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_staff.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_staff.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_staff.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_staff.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_staff.created_at', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_staff.created_at', $condition['year'])
                                        ->whereMonth('za_staff.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }

        if ($staff_name_fill) {
            $query->where('za_staff.sno', $staff_name_fill);
        }
        if ($per_hr_cost_fill) {
            $query->where('per_hour_cost', $per_hr_cost_fill);
        }
        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }

        $staff = $query->paginate(25);

        $staff = $staff->unique('staff_id'); // Ensure uniqueness on staff_id
        foreach ($staff as $slotType) {
            
            $slotType->earned_amount = 0;
            $slotType->batch_count = 0;
            $slotType->student_count = 0;
            $slotType->present_count = 0;
            $slotType->course_count = 0;
            $slotType->slotDetails = [];
        
            $batchIds = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct()
                ->pluck('batch_id')
                ->toArray(); // Ensure it's an array
        
            $slotType->batch_ids = $batchIds; // Save batch IDs

            // return $slotType;
      
            foreach ($slotType->batch_ids as $batchId) {
                // Fetch the batch details
                $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->find($batchId);
            
                if ($batch) {
                    
                    $presentCount = \DB::table('za_attendance')
                        ->where('batch_id', $batch->sno)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->count('customer_id'); // Count the customer_id for present students
            
                 
                    $slotType->present_count = $presentCount;

                    $attendanceRecords = \DB::table('za_attendance')
                        ->select('*')
                        ->where('batch_id', $batch->sno)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->get();
                    
                    foreach ($attendanceRecords as $attendance) {
            
                        $slotType->earned_amount +=  $attendance->per_hr_cost;
                    }
                }
            }
            
                // return $slotType;
            $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('customer_id') 
                ->count('customer_id');
        
            $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('course_id') 
                ->count('course_id');
        
            $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('batch_id')
                ->count('batch_id');
            
        
            $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->pluck('batch_id')) 
                ->where('za_batch.status', 0)
                ->get();

           
        }
        
        $staffNames = [];
        $staffTotals = [];

        foreach ($staff as $category) {
            $staffNames[] = $category->staff_name;
            $staffTotals[] = (float) $category->present_count * $category->per_hr_cost;
        }
       

        // return $staff; 

        $staff_list = StaffModel::select('za_staff.sno', 'za_staff.staff_name', 'za_staff.nick_name')
            ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where(function ($query) use ($month, $year) {
                // Only include batches that end in the current month or future
                $query->whereYear('za_batch.end_date', '>', $year)
                    ->orWhere(function ($query) use ($month, $year) {
                        $query->whereYear('za_batch.end_date', '=', $year)
                            ->whereMonth('za_batch.end_date', '>=', $month);
                    });
            })
            ->where('za_staff.status', 0)
            ->orderBy('za_staff.sno', 'desc')
            ->distinct('za_staff.staff_id') // Ensure distinct staff_id
            ->get();

        // $staff_list = $staff_list->unique('staff_id');
        // dd($staff);

        $paginatedStaff = new LengthAwarePaginator(
            $staff->slice($offset, $perpage)->values(), // Paginate manually
            $staff->count(), // Total records count
            $perpage, // Items per page
            $page, // Current page
            ['path' => request()->url(), 'query' => request()->query()] // Preserve filters
        );

        
        return view(
            'content.production.manage_costing.costing_staff_list',
            [
                'staff' => $paginatedStaff, // ✅ Now pagination works
                'perpage' => $perpage,
                'staff_list' => $staff_list,
                'staffNames' => $staffNames,
                'staffTotals' => $staffTotals,
                'staff_name_fill' => $staff_name_fill,
                'per_hr_cost_fill' => $per_hr_cost_fill,
                'fin_yr_fill' => $fin_yr_fill,
                'date_filter' => $date_filter,
                'month_chk' => $month_chk,
                'previousMonth' => $previousMonth,
                'previousYear' => $previousYear,
                'nextMonth' => $nextMonth,
                'nextYear' => $nextYear,
                'startDayOfWeek' => $startDayOfWeek,
            ]
        )->with('filter_on', true);
        
    }


    public function courseList(Request $request)
    {
        $branch_id = $request->query('branch_id', $request->user()->branch_id);

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
    
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
    
        $batch = ManageCoursesModel::select(
            'za_course.course_name',
            'za_course.sno',
            'za_course.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.batch_name',
            'za_batch.start_date',  
            'za_batch.branch_id',
            'za_course.status',
            'za_training.customer_id', // Include customer_id
            'za_training.batch_id' // Include batch_id from the training table
        )
        ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
        ->where('za_course.status', '!=', 2)
        ->where(function ($query) use ($currentMonth, $currentYear) {
            $query->whereYear('za_batch.end_date', '>', $currentYear)
                ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                    $query->whereYear('za_batch.end_date', '=', $currentYear)
                        ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                });
        })
        ->groupBy(
            'za_course.course_name',
            'za_course.sno',
            'za_course.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.branch_id',
            'za_course.status',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_training.customer_id',
            'za_training.batch_id'
        );
        
        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }
        
        $batch = $batch->distinct()
            ->orderBy('za_course.sno', 'desc')
            ->paginate($perpage);
        
        // Group by course_id
        $groupedByCourse = [];
        
        // Loop through the data to group by course_id and batch_id
        foreach ($batch as $item) {
            $courseId = $item['sno'];
            $batchId = $item['batch_id'];
        
            // Ensure the course_id exists in the grouped array
            if (!isset($groupedByCourse[$courseId])) {
                $groupedByCourse[$courseId] = [
                    'course_name' => $item['course_name'],
                    'course_days' => $item['course_days'],
                    'course_duration' => $item['course_duration'],
                    'course_type_name' => $item['course_type_name'],
                    'end_date' => $item['end_date'],
                    'branch_id' => $item['branch_id'],
                    'status' => $item['status'],
                    'batch_count' => 0,
                    'student_count' => 0,
                    'batches' => [] // Placeholder for batch info
                ];
            }
        
            // Now group by batch_id within each course
            if (!isset($groupedByCourse[$courseId]['batches'][$batchId])) {
                $groupedByCourse[$courseId]['batches'][$batchId] = [
                    'batch_id' => $batchId,
                    'batch_name' => $item['batch_name'], // Added batch_name
                    'start_date' => $item['start_date'], // Added start_date
                    'end_date' => $item['end_date'], // Added end_date
                    'customer_ids' => []
                ];
            }
        
            // Add customer_id to the correct batch
            $groupedByCourse[$courseId]['batches'][$batchId]['customer_ids'][] = $item['customer_id'];
        }

        foreach ($groupedByCourse as $courseId => &$courseData) {
            // Count the unique batches for each course
            $courseData['batch_count'] = count($courseData['batches']);
        
            // Count the unique students (customer_ids) across all batches of the course
            $uniqueCustomerIds = [];
            foreach ($courseData['batches'] as $batchId => $batchData) {
                foreach ($batchData['customer_ids'] as $customerId) {
                    $uniqueCustomerIds[$customerId] = true; // Use array keys to ensure uniqueness
                }
            }
            $courseData['student_count'] = count($uniqueCustomerIds);
        }
        
        // Result
        $result = [];
        foreach ($groupedByCourse as $courseId => $courseData) {
            $batches = [];
            foreach ($courseData['batches'] as $batchId => $batchData) {
                $batches[] = [
                    'batch_id' => $batchId,
                    'batch_name' => $batchData['batch_name'], // Included batch_name
                    'start_date' => $batchData['start_date'], // Included start_date
                    'end_date' => $batchData['end_date'], // Included end_date
                    'customer_ids' => $batchData['customer_ids']
                ];
            }
        
            $result[] = [
                'course_name' => $courseData['course_name'],
                'sno' => $courseId,
                'course_days' => $courseData['course_days'],
                'course_duration' => $courseData['course_duration'],
                'course_type_name' => $courseData['course_type_name'],
                'end_date' => $courseData['end_date'],
                'branch_id' => $courseData['branch_id'],
                'status' => $courseData['status'],
                'batch_count' => $courseData['batch_count'],
                'student_count' => $courseData['student_count'],
                'batches' => $batches
            ];
        }       

        // return $result;
    
        // Calculate total cost for each customer
        $customerTotals = [];

        foreach ($result as $course) {
            foreach ($course['batches'] as $batch) {
                foreach ($batch['customer_ids'] as $customerId) {
                    $batchStartDate = $batch['start_date'];
                    $batchEndDate = $batch['end_date'];

                    // Fetch the customer fees for the current course, batch, and branch
                    $totalCost = TrainingModel::where('branch_id', $course['branch_id'])
                        ->where('customer_id', $customerId)
                        ->where('course_id', $course['sno'])
                        ->get();

                    $totalAmount = 0; // Initialize total amount for the customer in this batch

                    // Loop through the fetched training records and calculate the total amount
                    foreach ($totalCost as $training) {
                        $totalAmount += $training->overall_fees; // Add the fees to the total amount
                    }

                    // Add the total amount to the customer totals array
                    if (!isset($customerTotals[$customerId])) {
                        $customerTotals[$customerId] = 0;
                    }
                    $customerTotals[$customerId] += $totalAmount; // Sum the total cost for the customer
                }
            }
        }

        // Add customer totals to each course
        foreach ($result as &$course) {
            $course['customer_totals'] = 0;  // Initialize customer_totals as a numeric value to store the sum.

            foreach ($course['batches'] as $batch) {
                foreach ($batch['customer_ids'] as $customerId) {
                    if (isset($customerTotals[$customerId])) {
                        $course['customer_totals'] += $customerTotals[$customerId];  // Add the amount to the sum.
                    }
                }
            }
        }

        // return $course;
    
        // Now calculate the total cost for each course based on customer totals
        $courseTotals = [];
        $courseNames = [];
        foreach ($result as $course) {
            $courseTotal = 0;
            foreach ($course['batches'] as $batch) {
                foreach ($batch['customer_ids'] as $customerId) {
                    if (isset($customerTotals[$customerId])) {
                        $courseTotal += $customerTotals[$customerId];
                    }
                }
            }
            
            $courseTotals[] = (float) $courseTotal;
            $courseNames[] = $course['course_name'];
        }
    
        // Fetch course types
        $course_type = ManageCoursesModel::select(
            'za_course_type.sno',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.branch_id',
            'za_course.course_type_id'
        )
            ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
            ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
            ->where('za_course.status', '!=', 2)
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });
    
        if ($branch_id != 0) {
            $course_type->where('za_batch.branch_id', $branch_id);
        }
    
        $course_type = $course_type->distinct('za_course_type.sno')
            ->orderBy('za_course.course_type_id', 'desc')->get();
        $course_type = $course_type->unique('sno');

        $paginatedBatch = new LengthAwarePaginator(
            array_slice($result, $offset, $perpage), // Sliced array data
            count($result), // Total items
            $perpage, // Items per page
            $page, // Current page
            ['path' => request()->url(), 'query' => request()->query()] // Keep query parameters
        );
    
        // return $result;
        return view('content.production.manage_costing.costing_course_list', [
            'batch' => $paginatedBatch,
            'courseNames' => $courseNames,
            'courseTotals' => $courseTotals,
            'course_type' => $course_type,
            'perpage' => $perpage,
            'course_type_fill' => '',
            'course_fill' => '',
            'fin_yr_fill' => '',
            'date_filter' => '',
        ])->with('filter_on', false);
    }
    

    public function courseFilter(Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        // return $request;

        $course_type_fill = $request->course_type_fill ?? '';
        $course_fill = $request->course_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        $query = ManageCoursesModel::select(
            'za_course.course_name',
            'za_course.sno',
            'za_course.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.branch_id',
            'za_course.status',
            'za_training.customer_id', // Include customer_id
            'za_training.batch_id' // Include batch_id from the training table
        )
        ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
        ->where('za_course.status', '!=', 2)
        ->where(function ($query) use ($currentMonth, $currentYear) {
            $query->whereYear('za_batch.end_date', '>', $currentYear)
                ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                    $query->whereYear('za_batch.end_date', '=', $currentYear)
                        ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                });
        })
        ->groupBy(
            'za_course.course_name',
            'za_course.sno',
            'za_course.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.branch_id',
            'za_course.status',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_training.customer_id',
            'za_training.batch_id'
        )->distinct()
        ->orderBy('za_course.sno', 'desc');
        
        if ($branch_id != 0) {
            $query->where('za_batch.branch_id', $branch_id);
        }

        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_course.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_course.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_course.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_course.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_course.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_course.created_at', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_course.created_at', $condition['year'])
                                        ->whereMonth('za_course.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }
        if ($course_type_fill) {
            $query->where('za_course.course_type_id', $course_type_fill);
        }
        if ($course_fill) {
            $query->where('za_course.sno', $course_fill);
        }

        $batch = $query->paginate($perpage);

       // Group by course_id
       $groupedByCourse = [];
        
       // Loop through the data to group by course_id and batch_id
       foreach ($batch->items() as $item) {
            $courseId = $item['sno'];
            $batchId = $item['batch_id'];

           // Ensure the course_id exists in the grouped array
           if (!isset($groupedByCourse[$courseId])) {
               $groupedByCourse[$courseId] = [
                   'course_name' => $item['course_name'],
                   'course_days' => $item['course_days'],
                   'course_duration' => $item['course_duration'],
                   'course_type_name' => $item['course_type_name'],
                   'end_date' => $item['end_date'],
                   'branch_id' => $item['branch_id'],
                   'status' => $item['status'],
                   'batch_count' => 0,
                   'student_count' => 0,
                   'batches' => [] // Placeholder for batch info
               ];
           }
       
           // Now group by batch_id within each course
           if (!isset($groupedByCourse[$courseId]['batches'][$batchId])) {
               $groupedByCourse[$courseId]['batches'][$batchId] = [
                   'batch_id' => $batchId,
                   'batch_name' => $item['batch_name'], // Added batch_name
                   'start_date' => $item['start_date'], // Added start_date
                   'end_date' => $item['end_date'], // Added end_date
                   'customer_ids' => []
               ];
           }
       
           // Add customer_id to the correct batch
           $groupedByCourse[$courseId]['batches'][$batchId]['customer_ids'][] = $item['customer_id'];
       }

       foreach ($groupedByCourse as $courseId => &$courseData) {
           // Count the unique batches for each course
           $courseData['batch_count'] = count($courseData['batches']);
       
           // Count the unique students (customer_ids) across all batches of the course
           $uniqueCustomerIds = [];
           foreach ($courseData['batches'] as $batchId => $batchData) {
               foreach ($batchData['customer_ids'] as $customerId) {
                   $uniqueCustomerIds[$customerId] = true; // Use array keys to ensure uniqueness
               }
           }
           $courseData['student_count'] = count($uniqueCustomerIds);
       }
       
       // Result
       $result = [];
       foreach ($groupedByCourse as $courseId => $courseData) {
           $batches = [];
           foreach ($courseData['batches'] as $batchId => $batchData) {
               $batches[] = [
                   'batch_id' => $batchId,
                   'batch_name' => $batchData['batch_name'], // Included batch_name
                   'start_date' => $batchData['start_date'], // Included start_date
                   'end_date' => $batchData['end_date'], // Included end_date
                   'customer_ids' => $batchData['customer_ids']
               ];
           }
       
           $result[] = [
               'course_name' => $courseData['course_name'],
               'sno' => $courseId,
               'course_days' => $courseData['course_days'],
               'course_duration' => $courseData['course_duration'],
               'course_type_name' => $courseData['course_type_name'],
               'end_date' => $courseData['end_date'],
               'branch_id' => $courseData['branch_id'],
               'status' => $courseData['status'],
               'batch_count' => $courseData['batch_count'],
               'student_count' => $courseData['student_count'],
               'batches' => $batches
           ];
       }       
   
       // Calculate total cost for each customer
       $customerTotals = [];
   
       foreach ($result as $course) {
           foreach ($course['batches'] as $batch) {
               foreach ($batch['customer_ids'] as $customerId) {
                   $batchStartDate = $batch['start_date'];
                   $batchEndDate = $batch['end_date'];
                   
                   // Fetch total cost where attendance is present and within the date range
                   $totalCost = AttendanceModel::where('branch_id', $course['branch_id'])
                       ->where('customer_id', $customerId)
                       ->where('course_id', $course['sno'])
                       ->where('attendance', '=', 'P')
                       ->whereBetween('att_date', [$batchStartDate, $batchEndDate])
                       ->sum('total_cost');
                   
                   if (!isset($customerTotals[$customerId])) {
                       $customerTotals[$customerId] = 0;
                   }
   
                   $customerTotals[$customerId] += $totalCost;
               }
           }
       }
   
       // Add customer totals to each course
       foreach ($result as &$course) {
           $course['customer_totals'] = 0;  // Initialize customer_totals as a numeric value to store the sum.
       
           foreach ($course['batches'] as $batch) {
               foreach ($batch['customer_ids'] as $customerId) {
                   if (isset($customerTotals[$customerId])) {
                       $course['customer_totals'] += $customerTotals[$customerId];  // Add the amount to the sum.
                   }
               }
           }
       }
       
   
       // Now calculate the total cost for each course based on customer totals
       $courseTotals = [];
       $courseNames = [];
       foreach ($result as $course) {
           $courseTotal = 0;
           foreach ($course['batches'] as $batch) {
               foreach ($batch['customer_ids'] as $customerId) {
                   if (isset($customerTotals[$customerId])) {
                       $courseTotal += $customerTotals[$customerId];
                   }
               }
           }
           
           $courseTotals[] = (float) $courseTotal;
           $courseNames[] = $course['course_name'];
       }

        $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();

        $paginatedBatch = new LengthAwarePaginator(
            array_slice($result, $offset, $perpage), // Sliced array data
            count($result), // Total items
            $perpage, // Items per page
            $page, // Current page
            ['path' => request()->url(), 'query' => request()->query()] // Keep query parameters
        );

        return view('content.production.manage_costing.costing_course_list', [
            'batch' => $paginatedBatch,
            'perpage' => $perpage,  
            'course_type' => $course_type,
            'courseNames' => $courseNames,
            'courseTotals' => $courseTotals,
            'course_type_fill' => $course_type_fill,
            'course_fill' => $course_fill,
            'date_filter' => $date_filter,
            'fin_yr_fill' => $fin_yr_fill,
        ])->with('filter_on', true);        
    }

    public function slotList(Request $request)
    {
        $branch_id = $request->query('branch_id', $request->user()->branch_id); // Use branch_id from query or user session

        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        // Fetch only batches where the end_date is >= the first day of the current month
        $slot = SlotModel::select(
            'za_slot.slot_name',
            'za_slot.branch_id',
            'za_slot.sno',
            'za_slot.slot_type_id',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.status',
            'za_slot_type.slot_type_name',
            // 'za_batch.end_date',
            // 'za_batch.branch_id',
        )
            // ->leftJoin('za_batch', 'za_batch.slot_id', '=', 'za_slot.sno')
            // ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->where('za_slot.status', '!=', 2);
            // Filter batches where the end date is after or within the current month
            // ->where(function ($query) use ($currentMonth, $currentYear) {
            //     $query->whereYear('za_batch.end_date', '>', $currentYear)
            //         ->orWhere(function ($query) use ($currentMonth, $currentYear) {
            //             $query->whereYear('za_batch.end_date', '=', $currentYear)
            //                 ->whereMonth('za_batch.end_date', '>=', $currentMonth);
            //         });
            // });

        if ($branch_id != 0) {
            $slot->where('za_slot.branch_id', $branch_id);
        }

        // Use distinct to avoid duplicate entries
        $slot = $slot->distinct()
            ->groupBy(
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.branch_id',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                // 'za_batch.end_date',
                // 'za_batch.branch_id'
            )
            ->orderBy('za_slot.sno', 'desc')
            ->paginate($perpage);

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        foreach ($slot as $slotType) {
            $dayIndices = json_decode($slotType->slot_type_days);
            $dayNames = [];

            if (is_array($dayIndices)) {
                // Convert start_time and end_time to 12-hour format with AM/PM
                $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->start_time)->format('h:i A');
                $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->end_time)->format('h:i A');
                foreach ($dayIndices as $index) {
                    // Ensure the index is within the valid range
                    $dayIndex = (int) $index;

                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-'; // Handle invalid indices
                    }
                }
            }

            // Assign the day names to each slot instance
            $slotType->dayNames = implode(', ', $dayNames);

            $slotType->student_count = 0;
            $slotType->batch_count = 0;

            $cos = TrainingModel::where('branch_id', $branch_id)
                ->where('slot_id', $slotType->sno)
                ->get();

            // Initialize total amount
            $slotType->total_amount = 0;

            // Iterate over each costing item in the collection
            foreach ($cos as $costing) {
                // Calculate total payment for the current course in the current month
                $slotType->total_amount += AttendanceModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->where('attendance', '=', 'P')
                    ->whereBetween('att_date', [$costing->start_date, $costing->end_date])  // Adding the date range check
                    ->sum('total_cost');

                $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('slot_id', $slotType->sno)
                    // ->whereMonth('updated_at', $month)
                    // ->whereYear('updated_at', $year)
                    ->distinct('customer_id') 
                    ->count('customer_id');
    
                $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('slot_id', $slotType->sno)
                    // ->whereMonth('updated_at', $month)
                    // ->whereYear('updated_at', $year)
                    ->distinct('batch_id') 
                    ->count('batch_id');
            }
        }

        // return $slot;

        // Prepare data for the chart
        $slotNames = [];
        $slotTotals = [];

        foreach ($slot as $category) {
            $slotNames[] = $category->slot_name;
            $slotTotals[] = (float) $category->total_amount;
        }
        // Debugging statement if needed
        // dd($slotNames);

        $slot_list = SlotModel::select(
            'za_slot.slot_name',
            'za_slot.sno',
            'za_slot.slot_type_id',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.status',
            'za_slot_type.slot_type_name',
            'za_batch.end_date',
            'za_batch.branch_id',
            // Count distinct students in each batch
        )
            ->leftJoin('za_batch', 'za_batch.slot_id', '=', 'za_slot.sno')
            // ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->where('za_slot.status', '!=', 2)
            // Filter batches where the end date is after or within the current month
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $slot_list->where('za_batch.branch_id', $branch_id);
        }

        // Use distinct to avoid duplicate entries
        $slot_list = $slot_list->distinct()
            ->groupBy(
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.sno',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                'za_batch.end_date',
                'za_batch.branch_id'
            )
            ->orderBy('za_slot.sno', 'asc')
            ->get();
        $slot_type_list = SlotTypeModel::where('status', 0)
            ->orderBy('sno', 'asc');
        if ($branch_id != 0) {
            $slot_type_list->where('branch_id', $branch_id);
        }
        $slot_type_list = $slot_type_list->get();

        // Render the view and pass the $slot data
        return view(
            'content.production.manage_costing.costing_slot_list',
            [
                'slot' => $slot,
                'slotNames' => $slotNames,
                'slotTotals' => $slotTotals,
                'slot_list' => $slot_list,
                'slot_type_list' => $slot_type_list,
                'slot_type_fill' => "",
                'slot_fill' => "",
                'date_filter' => "",
                'fin_yr_fill' => "",
                'perpage' => $perpage,
            ]
        );
    }

    public function slotFilter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        // return $request;

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        $slot_type_fill = $request->slot_type_fill ?? '';
        $slot_fill = $request->slot_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';

        $query = SlotModel::select(
            'za_slot.slot_name',
            'za_slot.sno',
            'za_slot.branch_id',
            'za_slot.slot_type_id',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.status',
            'za_slot_type.slot_type_name',
            // 'za_batch.end_date',
            // 'za_batch.branch_id',
        )
            // ->join('za_batch', 'za_batch.slot_id', '=', 'za_slot.sno')
            // ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->where('za_slot.status', '!=', 2);
            // Filter batches where the end date is after or within the current month
            // ->where(function ($query) use ($currentMonth, $currentYear) {
            //     $query->whereYear('za_batch.end_date', '>', $currentYear)
            //         ->orWhere(function ($query) use ($currentMonth, $currentYear) {
            //             $query->whereYear('za_batch.end_date', '=', $currentYear)
            //                 ->whereMonth('za_batch.end_date', '>=', $currentMonth);
            //         });
            // });

        if ($branch_id != 0) {
            $query->where('za_slot.branch_id', $branch_id);
        }

        // Use distinct to avoid duplicate entries
        $query = $query->distinct()
            ->groupBy(
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.branch_id',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                // 'za_batch.end_date',
                // 'za_batch.branch_id'
            )
            ->orderBy('za_slot.sno', 'desc');
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_slot.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_slot.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_slot.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_slot.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_slot.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_slot.created_at', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_slot.created_at', $condition['year'])
                                        ->whereMonth('za_slot.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }
        if ($slot_type_fill) {
            $query->where('za_slot.slot_type_id', $slot_type_fill);
        }
        if ($slot_fill) {
            $query->where('za_slot.sno', $slot_fill);
        }

        $slot = $query->paginate($perpage);

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        foreach ($slot as $slotType) {
            $dayIndices = json_decode($slotType->slot_type_days);
            $dayNames = [];

            if (is_array($dayIndices)) {
                // Convert start_time and end_time to 12-hour format with AM/PM
                $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->start_time)->format('h:i A');
                $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->end_time)->format('h:i A');
                foreach ($dayIndices as $index) {
                    // Ensure the index is within the valid range
                    $dayIndex = (int) $index;

                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-'; // Handle invalid indices
                    }
                }
            }

            // Assign the day names to each slot instance
            $slotType->dayNames = implode(', ', $dayNames);

            $cos = TrainingModel::where('branch_id', $branch_id)
                ->where('slot_id', $slotType->sno)
                ->get();

            // Initialize total amount
            $slotType->total_amount = 0;
            $slotType->student_count = 0;
            $slotType->batch_count = 0;

            // Iterate over each costing item in the collection
            foreach ($cos as $costing) {
                // Calculate total payment for the current course in the current month
                $slotType->total_amount += AttendanceModel::where('branch_id', $costing->branch_id)
                    ->where('customer_id', $costing->customer_id)
                    ->where('course_id', $costing->course_id)
                    ->where('attendance', '=', 'P')
                    ->whereBetween('att_date', [$costing->start_date, $costing->end_date])  // Adding the date range check
                    ->sum('total_cost');

                $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('slot_id', $slotType->sno)
                    // ->whereMonth('updated_at', $month)
                    // ->whereYear('updated_at', $year)
                    ->distinct('customer_id') 
                    ->count('customer_id');
    
                $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                    ->where('slot_id', $slotType->sno)
                    // ->whereMonth('updated_at', $month)
                    // ->whereYear('updated_at', $year)
                    ->distinct('batch_id') 
                    ->count('batch_id');
            }
        }

        // Prepare data for the chart
        $slotNames = [];
        $slotTotals = [];

        foreach ($slot as $category) {
            $slotNames[] = $category->slot_name;
            $slotTotals[] = (float) $category->total_amount;
        }

        $slot_list = SlotModel::select(
            'za_slot.slot_name',
            'za_slot.sno',
            'za_slot.slot_type_id',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.status',
            'za_slot_type.slot_type_name',
            // 'za_batch.end_date',
            // 'za_batch.branch_id',
            'za_slot.branch_id'
            // Count distinct students in each batch
        )
            // ->join('za_batch', 'za_batch.slot_id', '=', 'za_slot.sno')
            // ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->where('za_slot.status', '!=', 2);
            // Filter batches where the end date is after or within the current month
        //     ->where(function ($query) use ($currentMonth, $currentYear) {
        //         $query->whereYear('za_batch.end_date', '>', $currentYear)
        //             ->orWhere(function ($query) use ($currentMonth, $currentYear) {
        //                 $query->whereYear('za_batch.end_date', '=', $currentYear)
        //                     ->whereMonth('za_batch.end_date', '>=', $currentMonth);
        //             });
        //     });

        if ($branch_id != 0) {
            $slot_list->where('za_slot.branch_id', $branch_id);
        }

        // Use distinct to avoid duplicate entries
        $slot_list = $slot_list->distinct()
            ->groupBy(
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.branch_id',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                // 'za_batch.end_date',
                // 'za_batch.branch_id'
            )
            ->orderBy('za_slot.sno', 'asc')
            ->get();
        $slot_type_list = SlotTypeModel::where('status', 0)
            ->orderBy('sno', 'asc');
        if ($branch_id != 0) {
            $slot_type_list->where('branch_id', $branch_id);
        }
        $slot_type_list = $slot_type_list->get();

        return view('content.production.manage_costing.costing_slot_list', [
            'slot' => $slot,
            'perpage' => $perpage,
            'slotNames' => $slotNames,
            'slotTotals' => $slotTotals,
            'slot_list' => $slot_list,
            'slot_type_list' => $slot_type_list,
            'slot_type_fill' => $slot_type_fill,
            'slot_fill' => $slot_fill,
            'date_filter' => $date_filter,
            'fin_yr_fill' => $fin_yr_fill,
        ])->with('filter_on', true);
    }

    public function batchcost_view($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        // return $decryptedValue;
        $id = $decryptedValue;
        $branch_id = $request->query('branch_id', $request->user()->branch_id);
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;


        $batchDetails = BatchModel::where('za_batch.sno', $id)->select(
            'za_batch.*',
            'za_slot.slot_name',
            'za_course.course_name',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_class_room.class_room_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_course.course_days',
            'za_course.course_max_price',
            'za_staff.staff_name',
            'za_staff.per_hour_cost',
            'za_slot.slot_type_days',
        )

        ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
        ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        ->leftJoin('za_syllabus_update', 'za_syllabus_update.batch_id', '=', 'za_batch.sno')
        ->first();

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        if ($batchDetails) {
            // Decode the slot type days from the batch details
            $dayIndices = json_decode($batchDetails->slot_type_days);
            $dayNames = [];
            $days_count = 0;
            if (is_array($dayIndices)) {
                // Convert start_time and end_time to Carbon instances
                $startTime = Carbon::parse($batchDetails->start_time);
                $endTime = Carbon::parse($batchDetails->end_time);

                // Calculate the duration in minutes
                $durationInMinutes = $startTime->diffInMinutes($endTime);

                // Convert minutes to hours and minutes
                $hours = floor($durationInMinutes / 60);
                $minutes = $durationInMinutes % 60;

                // Format the batch duration as "X hr Y mins"
                $batchDetails->batch_duration = "{$hours} hr " . ($minutes > 0 ? "{$minutes} min" : '');

                // Calculate total duration in hours
                $totalDurationInHours = $hours + ($minutes / 60);

                // Check attendance for each day between start_date and end_date
                $currentDate = Carbon::parse($batchDetails->start_date);
                $endDate = Carbon::parse($batchDetails->end_date);

                // Initialize spending_hrs if not already set
                if (!isset($batchDetails->spending_hrs)) {
                    $batchDetails->spending_hrs = 0;
                }

                while ($currentDate->lte($endDate)) {
                    // Check if there is attendance for the current day
                    $attendanceExists = \DB::table('za_batch_history')
                        ->where('batch_id', $batchDetails->sno)
                        ->whereDate('att_date', $currentDate) // Check attendance for the exact date
                        ->whereNotNull('attendance') // Assuming attendance column must not be null
                        ->exists();

                    if ($attendanceExists) {
                        // Add the total duration (in hours) to spending_hrs for the current day
                        $batchDetails->spending_hrs += $totalDurationInHours;
                    }

                    // Move to the next day
                    $currentDate->addDay();
                }

                // Convert spending_hrs to spending_days
                $spending_days = $batchDetails->spending_hrs / 1.5; // If you want to use 24 hours as one day
                $batchDetails->spending_days = round($spending_days, 2); // You can round it to 2 decimal places

                // Loop to assign day names
                foreach ($dayIndices as $index) {
                    // Ensure the index is within the valid range
                    $dayIndex = (int) $index;
                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-'; // Handle invalid indices
                    }
                }

                // Assign the day names to the batchDetails object
                $batchDetails->dayNames = implode(', ', $dayNames);

                // Get the count of distinct attendance days
                $days_count = AttendanceModel::distinct('att_date')->where('batch_id', $batchDetails->sno)->count();
                $batchDetails->days_count = $days_count;
            }
            
            // Assuming $batchDetails->sno is the batch_id you're searching for
            $batch = BatchExtensionModel::where('batch_id', '=', $batchDetails->sno)->first();

            // Check if batch exists
            if ($batch) {
                // Calculate the difference between end_date and change_date
                $endDate = \Carbon\Carbon::parse($batch->end_date);
                $changeDate = \Carbon\Carbon::parse($batch->change_date);
                $dayDifference = $endDate->diffInDays($changeDate);
                $batchDetails->dayDifference = $dayDifference;
            }
        }
        // return $batchDetails;

        // Fetch only batches where the end_date is >= the first day of the current month
        $batch = TrainingModel::select('za_training.*', 'za_customer.cus_name', 'za_course.course_name', 'za_course.course_duration', 'za_course.course_days', 'za_course_type.course_type_name')
            ->where('za_batch.sno', $batchDetails->sno)
            ->join('za_batch', 'za_batch.sno', '=', 'za_training.batch_id')
            ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')

            // Filter batches where the end date is after or within the current month
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }

        $batch = $batch->orderBy('sno', 'desc')->get();
        $batch = $batch->unique('customer_id');

        // return $batch;

        // Check if attendance exists for the specific batch and customer
        $attendanceRecords = AttendanceModel::where('batch_id', $batchDetails->sno)
            ->get();

        // Initialize course progress percentage
        $courseProgress = 0;
        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $batchDetails->course_id)->count();

        // If attendance exists, check for syllabus update percentage for each attendance record
        if ($attendanceRecords->isNotEmpty()) {
            foreach ($attendanceRecords as $attendance) {
                // Check for all syllabus updates that match the batch_id and attendance date
                $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchDetails->sno)
                    ->whereDate('date', $attendance->att_date) // Check the attendance date
                    ->get(); // Get all syllabus updates for that date

                // If syllabus updates exist, sum the percentages
                if ($syllabusUpdates->isNotEmpty()) {
                    foreach ($syllabusUpdates as $syllabusUpdate) {
                        if ($syllabusUpdate->percentage == 100) {
                            $topicCount++;
                        }
                    }
                }
            }
            if ($course_topic_count > 0) {
                $courseProgress = ($topicCount / $course_topic_count) * 100;
            }

            // Limit the course progress to a maximum of 100%
            if ($courseProgress > 100) {
                $courseProgress = 100; // Cap the maximum value at 100%
            }

            // Format the course progress to 2 decimal places
            $courseProgress = number_format($courseProgress, 2);
        }

        $batchDetails->total_amount = 0;
        // return $courseProgress;

        $cos = TrainingModel::where('branch_id', $branch_id)
            ->where('batch_id', $batchDetails->sno)
            ->get();

        // Initialize total amount
        // Iterate over each costing item in the collection
        foreach ($cos as $costing) {
            // Calculate total payment for the current course in the current month
            $batchDetails->total_amount += PaymentModel::where('branch_id', $costing->branch_id)->where('customer_id', $costing->customer_id)
                ->where('course_id', $costing->course_id)
                ->whereMonth('initialPayDate', $currentMonth)
                ->whereYear('initialPayDate', $currentYear)
                ->sum('paidAmount');
        }
        // return $batch;

        $lists = TrainingModel::where('za_training.batch_id', $batchDetails->sno)
            ->where('za_training.staff_id', $batchDetails->staff_id)
            ->where('za_training.course_id', $batchDetails->course_id)
            ->where('za_training.status', 0)
            ->select(
                'za_training.overall_fees',
                'za_customer.sno',
                'za_customer.cus_name',
                'za_customer.cus_mobile',
                'za_customer.customer_id',
                'za_customer.cus_pic',
                'za_customer.customer_id',
                'za_customer.cus_gender',
                'za_course.course_days',
                'za_course.course_duration',
                //  'za_attendance.att_date', 'za_attendance.attendance'
            )
            ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')

            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->get();


        $dates = [];
        $startDate = strtotime($batchDetails->start_date);
        $endDate = strtotime($batchDetails->end_date);

        while ($startDate <= $endDate) {
            $dates[] = date('Y-m-d', $startDate);
            $startDate = strtotime('+1 day', $startDate);
        }
        $customer_ids = [];

        foreach ($lists as $student) {
            $customer_ids[] = $student->sno;
        }

        $attendanceData = AttendanceModel::select('za_attendance.att_date', 'za_attendance.attendance', 'za_attendance.customer_id')
            ->where('za_attendance.batch_id', $batchDetails->sno)
            ->whereIn('za_attendance.customer_id', $customer_ids)
            ->get()
            ->groupBy('customer_id');
        // $attendance = [];
        // return $attendanceData;

        foreach ($lists as $student) {
            // Get the hourly cost for the student
            $attendance_per_hour_cost = AttendanceModel::where('customer_id', $student->sno)->value('per_hr_cost');
            $student->per_hr_cost = $attendance_per_hour_cost;

            // Initialize an array for attendance data for this student
            $attendanceResults = [];

            foreach ($dates as $date) {
                $dateAttendance = "";

                // Get attendance for the specific customer ID
                if (isset($attendanceData[$student->sno])) {
                    $attendances = $attendanceData[$student->sno];
                    $attendanceForDate = $attendances->firstWhere('att_date', $date); // Get attendance for the specific date

                    if ($attendanceForDate) {
                        $dateAttendance = $attendanceForDate->attendance;
                    }
                }

                $attendanceResults[] = [
                    "date" => $date,
                    "attendance" => $dateAttendance,
                ];
            }

            // Assign the attendance results to the student
            $student->attendanceResults = $attendanceResults;
        }

        // return $lists;
        // return $batchDetails;
        return view('content.production.manage_costing.batch_costing_view', [
            'batch' => $batch,
            'courseProgress' => $courseProgress,
            'batchDetails' => $batchDetails,
            'student_list' => $lists,
            'dates' => $dates,
        ]);
    }

    public function staffcost_view($id, Request $request)
    {
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        $branch_id = $request->user()->branch_id;

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $branch_id = $request->query('branch_id', $request->user()->branch_id);
        $staffdetails = StaffModel::where('sno', $id)->first();

        $staff = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_batch.end_date',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_shift_time.shift_end_time',
            'za_batch.batch_name',
            'za_batch.sno as batch_ids', // Using za_batch.sno as batch_ids for matching
            'za_staff.nick_name',
            'za_job_position.job_position_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_staff.status AS staff_status',
        )
            ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->leftJoin('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->where(function ($query) use ($currentMonth, $currentYear) {
                // Only include batches that end in the current month or future
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            })
            ->leftJoin('za_training', function ($join) {
                // Ensure za_training is joined on za_batch.sno (as batch_ids)
                $join->on('za_training.batch_id', '=', 'za_batch.sno');
            })
            ->where('za_staff.status', '!=', 2)
            ->where('za_staff.sno', $id)
            ->where('za_staff.branch_id', $branch_id)
            ->groupBy(
                'za_staff.sno',
                'za_staff.staff_id',
                'za_staff.staff_name',
                'za_batch.end_date',
                'za_shift_time.shift_start_time',
                'za_shift_time.shift_end_time',
                'za_shift_time.shift_lunch_start',
                'za_shift_time.shift_lunch_end',
                'za_staff.gender',
                'za_staff.staff_image',
                'za_batch.batch_name',
                'za_batch.sno', // za_batch.sno as batch_ids for groupBy
                'za_staff.nick_name',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_job_position.job_position_name',
                'za_staff.knowledge_tag',
                'za_staff.per_hour_cost',
                'za_staff.basic_salary',
                'za_staff.status'
            )
            ->orderBy('za_staff.sno', 'desc')
            ->first();


        if ($staff) {
            // Parse the start and end times using Carbon
            $shiftStartTime = Carbon::createFromFormat('H:i:s', $staff->shift_start_time);
            $shiftEndTime = Carbon::createFromFormat('H:i:s', $staff->shift_end_time);

            // Calculate total working hours
            $totalHours = $shiftEndTime->diffInHours($shiftStartTime);

            // Parse the lunch times
            $lunchStartTime = Carbon::createFromFormat('H:i:s', $staff->shift_lunch_start);
            $lunchEndTime = Carbon::createFromFormat('H:i:s', $staff->shift_lunch_end);

            // Calculate total lunch hours
            $lunchHours = $lunchEndTime->diffInHours($lunchStartTime);

            // Optionally, you can also calculate minutes for more precision
            $totalHoursMinutes = $shiftEndTime->diffInMinutes($shiftStartTime);
            $lunchHoursMinutes = $lunchEndTime->diffInMinutes($lunchStartTime);

            $totalWorkingminutes = $totalHoursMinutes - $lunchHoursMinutes;
            $totalHours = floor($totalWorkingminutes / 60); // Get whole hours
            $totalMinutes = $totalWorkingminutes % 60; // Get remaining minutes

            $totalWorkingHours = $totalHours + ($totalMinutes / 60);
            // Return or assign the results
            $staff->totalWorkingHours = $totalWorkingHours; // Total working hours

            $course_count = BatchModel::where('za_batch.status', 0)->where('za_batch.staff_id', $staff->sno)->distinct('course_id')->count();

            $staff->course_count = $course_count;

            $staff->customer_count = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $staff->sno)
            ->distinct('customer_id') // Ensure unique students
            ->count('customer_id');

            $staff->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                    ->where('staff_id', $staff->sno)
                    ->pluck('batch_id')) // Fetch batch_ids for this staff
                ->where('za_batch.status', 0)
                ->get();
        }

        $batches = BatchModel::select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_staff.staff_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_slot.start_time as slot_start_time',
            'za_slot.end_time as slot_end_time',

        )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->where('za_batch.staff_id', $id)->where('za_batch.status', 0)
            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_staff.staff_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time'
            )
            ->get();

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        $total_batch_costing = 0;
        foreach ($batches as $slotType) {

            $dayIndices = json_decode($slotType->slot_type_days);
            $dayNames = [];
            $overall_fees = 0;
            $allocatedStudents = DB::table('za_training')
                ->where('za_training.status', 0)
                ->where('za_training.batch_id', $slotType->sno)
                ->count('customer_id');
                
            // $overall_fees = DB::table('za_training')
            //     ->where('course_id', $slotType->course_id)
            //     ->where('batch_id', $slotType->sno)
            //     ->where('status', 0)
            //     ->value('overall_fees');
            // $overall_fees = $overall_fees ?? 0;

        $present_data = AttendanceModel::select('*')->where('branch_id', $branch_id)
            ->where('batch_id', $slotType->sno)
            ->where('attendance', 'P')
            ->whereBetween('att_date', [$slotType->start_date, $slotType->end_date])
            ->get();
        
            $slotType->present_count = $present_data->count();
            
            // Ensure the per_hr_cost exists for the model and calculate the batch costing
            if ($present_data->isNotEmpty()) {
                // Assuming all records have the same per_hr_cost, you can use the first record to get the per_hr_cost
                $per_hr_cost = $present_data->first()->per_hr_cost; // Get the per_hr_cost from the first record
                
                $batch_costing = $per_hr_cost * $slotType->present_count;
            } else {
                $batch_costing = 0; // If no data is present, set the batch costing to 0
            }
        
            $total_batch_costing += $batch_costing;
            $slotType->batch_costing = $batch_costing;
            $slotType->allocated_students = $allocatedStudents;

            if (is_array($dayIndices)) {
                // Convert start_time and end_time to 12-hour format with AM/PM
                $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->start_time)->format('h:i A');
                $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->end_time)->format('h:i A');
                foreach ($dayIndices as $index) {
                    // Ensure the index is within the valid range
                    $dayIndex = (int) $index;

                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-'; // Handle invalid indices
                    }
                }
            }

            // Assign the day names to each slot instance
            $slotType->dayNames = implode(', ', $dayNames);


        }

        // return $batches;
        return view('content.production.manage_costing.staff_costing_view', [
            'staff' => $staff,
            'batches' => $batches,
            'total_batch_costing' => $total_batch_costing,

        ]);
    }

    public function coursecost_view($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $branch_id = $request->query('branch_id', $request->user()->branch_id);
        $course = ManageCoursesModel::where('za_course.sno', $id)->where('za_course.status', 0)->first();

        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;

        $batch = BatchModel::select(
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_slot.slot_name',
            'za_slot.sno as slot_sno',
            'za_slot.slot_type_id',
            'za_slot_type.slot_type_name',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.status',
            'za_slot.end_time',
            'za_course.course_name',
            'za_batch.sno as batch_sno',
            'za_batch.batch_name',
            'za_batch.batch_id',
            'za_course.sno as course_sno',
            'za_course_type.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.start_date',
            'za_batch.branch_id',
            'za_batch.status',
            DB::raw('COUNT(DISTINCT za_batch.sno) as batch_count'), // Count distinct batches for each course
            DB::raw('COUNT(DISTINCT za_training.sno) as student_count') // Count distinct students in each batch
        )
            // ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
            ->where('za_batch.course_id', $course->sno)
            ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }

        // Use distinct to avoid duplicate entries
        $batch = $batch->distinct()
            ->groupBy(
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                'za_course.course_name',
                'za_batch.sno',
                'za_batch.batch_name',
                'za_batch.batch_id',
                'za_course.sno',
                'za_course_type.course_days',
                'za_course.course_duration',
                'za_course_type.course_type_name',
                'za_batch.end_date',
                'za_batch.start_date',
                'za_batch.branch_id',
                'za_batch.status',
            )
            ->orderBy('za_batch.sno', 'desc')
            ->get();

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

        // return $batch;

        $totalAmount = 0; // Initialize the total amount

        foreach ($batch as $slotType) {
            $dayIndices = json_decode($slotType->slot_type_days);
            $dayNames = [];
            $slotType->actual_amount = 0;

            if (is_array($dayIndices)) {
                // Convert start_time and end_time to 12-hour format with AM/PM
                $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->start_time)->format('h:i A');
                $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->end_time)->format('h:i A');
                
                foreach ($dayIndices as $index) {
                    // Ensure the index is within the valid range
                    $dayIndex = (int) $index;

                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-'; // Handle invalid indices
                    }
                }
            }

            // Assign the day names to each slot instance
            $slotType->dayNames = implode(', ', $dayNames);

            // Fetch the customer fees for the current course, batch, and branch
            $trainingRecords = TrainingModel::where('branch_id', $slotType->branch_id)
                ->where('batch_id', $slotType->batch_sno)
                ->where('course_id', $id)
                ->get();

            // Calculate the total fees for each customer in the training records
            foreach ($trainingRecords as $training) {
                $slotType->actual_amount += $training->overall_fees;
            }

            // Add the actual amount of the current batch to the total amount
            $totalAmount += $slotType->actual_amount;
        }

        // Save the total amount to the course
        $course->total_amount = $totalAmount;

              
        //  return $course;
        return view('content.production.manage_costing.course_costing_view', compact('batch', 'course'));
    }

    public function slotcost_view($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $branch_id = $request->query('branch_id', $request->user()->branch_id);
        $slot = SlotModel::where('za_slot.sno', $id)->where('za_slot.status', 0)->first();

        $branch_id = $request->query('branch_id', $request->user()->branch_id); // Use branch_id from query or user session
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        // Fetch only batches where the end_date is >= the first day of the current month
        $batch = BatchModel::select(
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_slot.slot_name',
            'za_slot.sno as slot_sno',
            'za_slot.slot_type_id',
            'za_slot_type.slot_type_name',
            'za_slot.slot_type_days',
            'za_slot.start_time',
            'za_slot.status',
            'za_slot.end_time',
            'za_course.course_name',
            'za_batch.sno as batch_sno',
            'za_batch.batch_name',
            'za_batch.batch_id',
            'za_course.sno as course_sno',
            'za_course_type.course_days',
            'za_course.course_duration',
            'za_course_type.course_type_name',
            'za_batch.end_date',
            'za_batch.start_date',
            'za_batch.branch_id',
            'za_batch.status',
            DB::raw('COUNT(DISTINCT za_batch.sno) as batch_count'), // Count distinct batches for each course
            DB::raw('COUNT(DISTINCT za_training.sno) as student_count') // Count distinct students in each batch
        )
            // ->join('za_batch', 'za_batch.course_id', '=', 'za_course.sno')
            ->where('za_batch.slot_id', $slot->sno)
            ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')

            // Filter batches where the end date is after or within the current month
            ->where(function ($query) use ($currentMonth, $currentYear) {
                $query->whereYear('za_batch.end_date', '>', $currentYear)
                    ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                        $query->whereYear('za_batch.end_date', '=', $currentYear)
                            ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                    });
            });

        if ($branch_id != 0) {
            $batch->where('za_batch.branch_id', $branch_id);
        }
        $totalAmount =0;
        // Use distinct to avoid duplicate entries
        $batch = $batch->distinct()
            ->groupBy(
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_slot.slot_name',
                'za_slot.sno',
                'za_slot.slot_type_id',
                'za_slot_type.slot_type_name',
                'za_slot.slot_type_days',
                'za_slot.start_time',
                'za_slot.status',
                'za_slot.end_time',
                'za_course.course_name',
                'za_batch.sno',
                'za_batch.batch_name',
                'za_batch.batch_id',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_course.sno',
                'za_course_type.course_days',
                'za_course.course_duration',
                'za_course_type.course_type_name',
                'za_batch.branch_id',
                'za_batch.status',
            )
            ->orderBy('za_batch.sno', 'desc')
            ->get();

        $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        

        foreach ($batch as $slotType) {
            $dayIndices = json_decode($slotType->slot_type_days);
            $dayNames = [];
            $batch_amount = 0;
        
            if (is_array($dayIndices)) {
                $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->start_time)->format('h:i A');
                $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->end_time)->format('h:i A');
                
                foreach ($dayIndices as $index) {
                    $dayIndex = (int) $index;
                    if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                        $dayNames[] = $shortDays[$dayIndex];
                    } else {
                        $dayNames[] = '-';
                    }
                }
            }
        
            $slotType->dayNames = implode(', ', $dayNames);

            $batch_amount = AttendanceModel::select('*')
                ->where('batch_id', $slotType->batch_sno)
                ->where('attendance', '=', 'P')
                ->whereYear('att_date', '=', $currentYear)
                ->whereMonth('att_date', '>=', $currentMonth)->sum('total_cost');

            // return $batch_amount;
        
            $slotType->batch_amount = $batch_amount;
            $totalAmount += $slotType->batch_amount;
        }

        // return $totalAmount;
        
        return view('content.production.manage_costing.slot_costing_view', compact('batch', 'totalAmount'));
    }
}