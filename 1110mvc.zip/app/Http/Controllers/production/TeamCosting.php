<?php

namespace App\Http\Controllers\production;

use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchHistoryModel;
use App\Models\BatchModel;
use App\Models\CourseTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchExtensionModel;
use App\Models\PaymentModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\StaffModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\LeadModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;


class TeamCosting extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $year  = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek;

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        $datesInMonth = collect();

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        // return $year;

        $staff = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_staff.staff_image',
            // 'za_batch.end_date',
            // 'za_batch.slot_id',
            // 'za_slot.start_time',
            // 'za_slot.end_time',
            // 'za_batch.sno as batch_ids',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status AS staff_status'
        )
        // ->leftJoin('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        // ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        // ->where(function ($query) use ($month, $year) {
        //     $query->whereYear('za_batch.end_date', '>', $year)
        //         ->orWhere(function ($query) use ($month, $year) {
        //             $query->whereYear('za_batch.end_date', '=', $year)
        //                 ->whereMonth('za_batch.end_date', '>=', $month);
        //         });
        // })
        // ->leftJoin('za_training', function ($join) {
        //     $join->on('za_training.batch_id', '=', 'za_batch.sno');
        // })
        ->where('za_staff.status', '=', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            // 'za_batch.end_date',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.sno', // za_batch.sno as batch_ids for groupBy
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc')
        ->paginate(25);
        // ->get();
        // return  $staff;

        $staff = $staff->unique('staff_id'); 

        $total_batch = 0;
        $total_student = 0;
        $total_free_batch = 0;
        $total_staff = 0;
        $total_course = 0;
        $overall_earned = 0;
        $overall_earned_per = 0;
        $success_staff_count = 0;

        $total_staff = StaffModel::select('*')->where('za_staff.status', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)->count();

        // return $total_staff;

        $total_batch = BatchModel::select('za_batch.*', 'za_training.batch_id')
            ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->where('za_batch.status', '!=', [2, 3])
            ->where(function ($query) use ($month, $year) {
                $query->whereMonth('za_training.start_date', '<=', $month)
                      ->whereYear('za_training.start_date', '<=', $year)
                      ->whereMonth('za_training.end_date', '>=', $month)
                      ->whereYear('za_training.end_date', '>=', $year);
            })
            ->where('za_batch.branch_id', $branch_id)->distinct('za_batch.sno')->count();
            
        $total_course = TrainingModel::where('branch_id', $branch_id)
                ->whereIn('staff_id', $staff->pluck('sno'))
                ->where('branch_id', $branch_id)
                // ->where(function ($query) use ($month, $year) {
                //     $query->whereMonth('za_training.start_date', '<=', $month)
                //           ->whereYear('za_training.start_date', '<=', $year)
                //           ->whereMonth('za_training.end_date', '>=', $month)
                //           ->whereYear('za_training.end_date', '>=', $year);
                // })
                ->where('status', 0)
                ->distinct('course_id')  // Ensure we're counting distinct course_id
                ->count('course_id'); 

     

            $perTraining = TrainingModel::select(
                    'za_training.training_id',
                    DB::raw('COUNT(za_training.customer_id) AS total_students')
                )
                ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
                ->where('za_customer.status', 0)
                ->where('za_training.status', '!=', 2)
                ->where('za_training.branch_id', $branch_id)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('za_training.start_date', '<=', $month)
                          ->whereYear('za_training.start_date', '<=', $year)
                          ->whereMonth('za_training.end_date', '>=', $month)
                          ->whereYear('za_training.end_date', '>=', $year);
                })
                ->groupBy('za_training.training_id')
                ->get();

            $total_student = $perTraining->sum('total_students');
        // return $total_batch;  

        foreach ($staff as $slotType) {
            
            $slotType->earned_amount = 0;
            $slotType->batch_count = 0;
            $slotType->student_count = 0;
            $slotType->present_count = 0;
            $slotType->course_count = 0;
            $slotType->slotDetails = [];
            $slotType->avg_amnt = 0;
            $slotType->salary = 0;
        
            $batchIds = TrainingModel::where('branch_id', $branch_id)
            ->where('staff_id', $slotType->sno)
            ->distinct()
            ->pluck('batch_id')
            ->toArray(); 

            $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array
        
            $slotType->batch_ids = $batchIds; // Save batch IDs

            // return $slotType;
      
            foreach ($slotType->batch_ids as $batchId) {
                // Fetch the slot details for the slot type
                $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                        ->where('staff_id', $slotType->sno)
                        ->where(function ($query) use ($month, $year) {
                            $query->whereMonth('start_date', '<=', $month)
                                ->whereYear('start_date', '<=', $year)
                                ->whereMonth('end_date', '>=', $month)
                                ->whereYear('end_date', '>=', $year);
                        })
                    ->pluck('batch_id'))
                    ->where('za_batch.status', '!=', 2)
                    ->get();
            
                // Fetch the batch details
                $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->where('za_batch.status', '!=', 2)
                    ->find($batchId);
            
                if ($batch) {
                    // Calculate the duration between start_time and end_time for the specific batch
                    $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
                    $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance
            
                    $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
                    $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
            
                    // Get attendance records for the current batch
                    $attendanceRecords = AttendanceModel::select('*')
                        ->where('batch_id', $batch->sno)
                        ->where('staff_id', $slotType->sno)
                        ->where('branch_id', $branch_id)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->get();

            
                    // Loop through the attendance records and calculate the earned amount
                    foreach ($attendanceRecords as $attendance) {
                        // Multiply the per_hr_cost by the batch duration (instead of slotType duration)
                        $earnedAmountForAttendance = $attendance->per_hr_cost * $batchDurationInHours; // Use batch duration here
                        $slotType->earned_amount += $earnedAmountForAttendance;  // Add to the total earned amount
                    }
                }
            }  
        
            
            // return $slotType;
            
            $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('customer_id') 
                ->count('customer_id');
        
            $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('course_id') 
                ->count('course_id');
        
            $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('batch_id')
                ->count('batch_id');
            

            $slotType->salary = $slotType->basic_salary * 10;
          
            if ($slotType->salary != 0) {
                $slotType->avg_amnt = round(($slotType->earned_amount / $slotType->salary) * 100);
            } else {
                $slotType->avg_amnt = 0;  // or any other value you want in case of division by zero
            }
            

            $total_free_batch += 8 -$slotType->batch_count;
            $overall_earned += $slotType->earned_amount;
            
            $overall_earned_per += min($slotType->avg_amnt, 100);

            if ($slotType->salary < $slotType->earned_amount) {
                $success_staff_count++;  // Increment staff count who meet the condition
            }
            // return $slotType;    
        }
        // return $success_staff_count;
     
        // return $staff;
        $staffNames = [];
        $earnedAmount = [];
        $actualAmount = [];

        foreach ($staff as $category) {
            $staffNames[] = $category->staff_name;
            $earnedAmount[] = $category->earned_amount;
            $actualAmount[] = ($category->basic_salary) * 10;
        }
       

        // return $staff;   

        $staff_list = StaffModel::select('za_staff.sno', 'za_staff.staff_name', 'za_staff.nick_name')
            ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where(function ($query) use ($month, $year) {
                // Only include batches that end in the current month or future
                $query->whereYear('za_batch.end_date', '>', $year)
                    ->orWhere(function ($query) use ($month, $year) {
                        $query->whereYear('za_batch.end_date', '=', $year)
                            ->whereMonth('za_batch.end_date', '>=', $month);
                    });
            })
            ->where('za_staff.status', 0)
            ->orderBy('za_staff.sno', 'desc')
            ->distinct('za_staff.staff_id') 
            ->get();

        // $staff_list = $staff_list->unique('staff_id');
        // dd($staff);


        $paginatedStaff = new LengthAwarePaginator(
            $staff->slice($offset, $perpage)->values(),
            $staff->count(), 
            $perpage, 
            $page, 
            ['path' => request()->url(), 'query' => request()->query()] 
        );

        // return $staff;
        
        return view(
            'content.production.team_costing.costing_staff_list',
            [
                'staff' => $paginatedStaff, 
                'perpage' => $perpage,
                'staff_list' => $staff_list,
                'staffNames' => $staffNames,
                'actualAmount' => $actualAmount,
                'earnedAmount' => $earnedAmount,
                'total_batch' => $total_batch,
                'total_course' => $total_course,
                'total_student' => $total_student,
                'total_free_batch' => $total_free_batch,
                'total_staff' => $total_staff,
                'overall_earned' => $overall_earned,
                'overall_earned_per' => $overall_earned_per,
                'success_staff_count' => $success_staff_count,        
                'staff_name_fill' => "",
                'per_hr_cost_fill' => "",
                'fin_yr_fill' => '',
                'date_filter' => '',
                'month_chk' => $month_chk,
                'previousMonth' => $previousMonth,
                'previousYear' => $previousYear,
                'nextMonth' => $nextMonth,
                'nextYear' => $nextYear,
                'startDayOfWeek' => $startDayOfWeek,
            ]
        )->with('filter_on', false);
        
    }

    public function StaffFilter(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        // Get current year and month from the request, defaulting to the current date if not provided
        $year  = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        // Calculate the previous and next month/year
        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        // Get the first day of the selected month
        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek;

        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

        $datesInMonth = collect();

        $staff_name_fill = $request->staff_name_fill ?? '';
        $per_hr_cost_fill = $request->per_hr_cost_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter = $request->to_date_fillter_textbox;
        $fin_yr_fill = $request->fin_yr_fill ?? '';

        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;

        // return $perpage;

        $query = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_staff.staff_image',
            // 'za_batch.end_date',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.sno as batch_ids', // Using za_batch.sno as batch_ids for matching
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status AS staff_status',
        )
        // ->leftJoin('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        // ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        // ->where(function ($query) use ($month, $year) {
        //     // Only include batches that end in the current month or future
        //     $query->whereYear('za_batch.end_date', '>', $year)
        //         ->orWhere(function ($query) use ($month, $year) {
        //             $query->whereYear('za_batch.end_date', '=', $year)
        //                 ->whereMonth('za_batch.end_date', '>=', $month);
        //         });
        // })
        // ->leftJoin('za_training', function ($join) {
        //     // Ensure za_training is joined on za_batch.sno (as batch_ids)
        //     $join->on('za_training.batch_id', '=', 'za_batch.sno');
        // })
        ->where('za_staff.status', '=', 0)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.dob',
            'za_staff.mobile_no',
            'za_staff.email_id',
            // 'za_slot.start_time',
            // 'za_batch.slot_id',
            // 'za_slot.end_time',
            // 'za_batch.end_date',
            // 'za_batch.sno', // za_batch.sno as batch_ids for groupBy
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc');


        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $query->whereDate('za_staff.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('za_staff.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('za_staff.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->whereBetween('za_staff.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $query->where('za_staff.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $query->where('za_staff.created_at', '<=', $toDate);
            }
        }
        if ($fin_yr_fill) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year' => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }
                    if (!empty($monthConditions)) {
                        $query->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('za_staff.created_at', $condition['year'])
                                        ->whereMonth('za_staff.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }

        if ($staff_name_fill) {
            $query->where('za_staff.sno', $staff_name_fill);
        }
        if ($per_hr_cost_fill) {
            $query->where('per_hour_cost', $per_hr_cost_fill);
        }
        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }

        $staff = $query->paginate(25);

        $staff = $staff->unique('staff_id'); // Ensure uniqueness on staff_id
        
        $total_batch = 0;
        $total_student = 0;
        $total_course = 0;
        $total_free_batch = 0;
        $total_staff = 0;
        $overall_earned = 0;
        $overall_earned_per = 0;
        $success_staff_count = 0;

        $total_staff = StaffModel::select('*')->where('za_staff.status', '!=', 2)
        ->where('za_staff.role_id', '=', 22)
        ->where('za_staff.branch_id', $branch_id)->count();

        // return $total_staff;

        $total_batch = BatchModel::select('za_batch.*', 'za_training.batch_id')
            ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->where('za_batch.status', '!=', [2, 3])
            ->where(function ($query) use ($month, $year) {
                $query->whereMonth('za_training.start_date', '<=', $month)
                      ->whereYear('za_training.start_date', '<=', $year)
                      ->whereMonth('za_training.end_date', '>=', $month)
                      ->whereYear('za_training.end_date', '>=', $year);
            })
            ->where('za_batch.branch_id', $branch_id)->distinct('za_batch.sno')->count();
            
         $total_course = TrainingModel::where('branch_id', $branch_id)
                ->whereIn('staff_id', $staff->pluck('sno'))
                ->where('branch_id', $branch_id)
                // ->where(function ($query) use ($month, $year) {
                //     $query->whereMonth('za_training.start_date', '<=', $month)
                //           ->whereYear('za_training.start_date', '<=', $year)
                //           ->whereMonth('za_training.end_date', '>=', $month)
                //           ->whereYear('za_training.end_date', '>=', $year);
                // })
                ->where('status', 0)
                ->distinct('course_id')  // Ensure we're counting distinct course_id
                ->count('course_id');   

        $total_student = TrainingModel::where('za_training.branch_id', $branch_id)
            ->leftjoin('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->where('za_customer.status', '!=', 2)
            ->where('za_training.status', '!=', 2)
            ->where(function ($query) use ($month, $year) {
                $query->whereMonth('za_training.start_date', '<=', $month)
                      ->whereYear('za_training.start_date', '<=', $year)
                      ->whereMonth('za_training.end_date', '>=', $month)
                      ->whereYear('za_training.end_date', '>=', $year);
            })
            ->distinct('za_training.customer_id') 
            ->count('za_training.customer_id');


        foreach ($staff as $slotType) {
            
            $slotType->earned_amount = 0;
            $slotType->batch_count = 0;
            $slotType->student_count = 0;
            $slotType->present_count = 0;
            $slotType->course_count = 0;
            $slotType->salary = 0;
            $slotType->avg_amnt = 0;
            $slotType->slotDetails = [];
        
            $batchIds = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct()
                ->pluck('batch_id')
                ->toArray(); // Ensure it's an array
        
            $slotType->batch_ids = $batchIds; // Save batch IDs

            // return $slotType;
      
            foreach ($slotType->batch_ids as $batchId) {
                // Fetch the slot details for the slot type
                $slotType->slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branch_id)
                        ->where('staff_id', $slotType->sno)
                        ->where(function ($query) use ($month, $year) {
                            $query->whereMonth('start_date', '<=', $month)
                                ->whereYear('start_date', '<=', $year)
                                ->whereMonth('end_date', '>=', $month)
                                ->whereYear('end_date', '>=', $year);
                        })
                    ->pluck('batch_id'))
                    ->where('za_batch.status', 0)
                    ->get();
            
                // Fetch the batch details
                $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                    ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                    ->find($batchId);
            
                if ($batch) {
                    // Calculate the duration between start_time and end_time for the specific batch
                    $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
                    $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance
            
                    $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
                    $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
            
                    // Get attendance records for the current batch
                    $attendanceRecords = \DB::table('za_attendance')
                        ->select('*')
                        ->where('batch_id', $batch->sno)
                        ->where('attendance', 'P')
                        ->whereMonth('att_date', '=', $month)
                        ->whereYear('att_date', '=', $year)
                        ->get();
            
                    // Loop through the attendance records and calculate the earned amount
                    foreach ($attendanceRecords as $attendance) {
                        // Multiply the per_hr_cost by the batch duration (instead of slotType duration)
                        $earnedAmountForAttendance = $attendance->per_hr_cost * $batchDurationInHours; // Use batch duration here
                        $slotType->earned_amount += $earnedAmountForAttendance;  // Add to the total earned amount
                    }
                }
            }

                // return $slotType;
            $slotType->student_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('customer_id') 
                ->count('customer_id');
        
            $slotType->course_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('course_id') 
                ->count('course_id');
        
            $slotType->batch_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $slotType->sno)
                ->where(function ($query) use ($month, $year) {
                    $query->whereMonth('start_date', '<=', $month)
                          ->whereYear('start_date', '<=', $year)
                          ->whereMonth('end_date', '>=', $month)
                          ->whereYear('end_date', '>=', $year);
                })
                ->distinct('batch_id')
                ->count('batch_id');

            $slotType->salary = $slotType->basic_salary * 10;
            if ($slotType->salary != 0) {
                $slotType->avg_amnt = ($slotType->earned_amount / $slotType->salary) * 100;
            } else {
                $slotType->avg_amnt = 0;  // or any other value you want in case of division by zero
            }

            $total_free_batch += 8 -$slotType->batch_count;
            $overall_earned += $slotType->earned_amount;
            $overall_earned_per += $slotType->avg_amnt;

            if ($slotType->salary < $slotType->earned_amount) {
                $success_staff_count++;  // Increment staff count who meet the condition
            }
        }
        
        $staffNames = [];
        $earnedAmount = [];
        $actualAmount = [];

        foreach ($staff as $category) {
            $staffNames[] = $category->staff_name;
            $earnedAmount[] = $category->earned_amount;
            $actualAmount[] = ($category->basic_salary) * 10;
        }
       

        // return $staff; 

        $staff_list = StaffModel::select('za_staff.sno', 'za_staff.staff_name', 'za_staff.nick_name')
            ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->where(function ($query) use ($month, $year) {
                // Only include batches that end in the current month or future
                $query->whereYear('za_batch.end_date', '>', $year)
                    ->orWhere(function ($query) use ($month, $year) {
                        $query->whereYear('za_batch.end_date', '=', $year)
                            ->whereMonth('za_batch.end_date', '>=', $month);
                    });
            })
            ->where('za_staff.status', 0)
            ->orderBy('za_staff.sno', 'desc')
            ->distinct('za_staff.staff_id') // Ensure distinct staff_id
            ->get();

        // $staff_list = $staff_list->unique('staff_id');
        // dd($staff);

        $paginatedStaff = new LengthAwarePaginator(
            $staff->slice($offset, $perpage)->values(), // Paginate manually
            $staff->count(), // Total records count
            $perpage, // Items per page
            $page, // Current page
            ['path' => request()->url(), 'query' => request()->query()] // Preserve filters
        );
        
        return view(
            'content.production.team_costing.costing_staff_list',
            [
                'staff' => $paginatedStaff, // ✅ Now pagination works
                'perpage' => $perpage,
                'staff_list' => $staff_list,
                'staffNames' => $staffNames,
                'actualAmount' => $actualAmount,
                'earnedAmount' => $earnedAmount, 
                'staff_name_fill' => $staff_name_fill,
                'per_hr_cost_fill' => $per_hr_cost_fill,
                'fin_yr_fill' => $fin_yr_fill,
                'date_filter' => $date_filter,
                'month_chk' => $month_chk,
                'previousMonth' => $previousMonth,
                'previousYear' => $previousYear,
                'nextMonth' => $nextMonth,
                'nextYear' => $nextYear,
                'startDayOfWeek' => $startDayOfWeek,
                'total_batch' => $total_batch,
                'total_student' => $total_student,
                'total_course' => $total_course,
                'total_free_batch' => $total_free_batch,
                'total_staff' => $total_staff,
                'overall_earned' => $overall_earned,
                'overall_earned_per' => $overall_earned_per,
                'success_staff_count' => $success_staff_count, 
            ]
        )->with('filter_on', true);
        
    }

    public function staffcost_view($id, Request $request)
    {
        $currentMonth = Carbon::now()->month;
        $currentYear = Carbon::now()->year;
        $branch_id = $request->user()->branch_id;
    
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }
        $id = $decryptedValue;
        $branch_id = $request->query('branch_id', $request->user()->branch_id);
        $staffdetails = StaffModel::where('sno', $id)->first();
    
        $staff = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_batch.end_date',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_shift_time.shift_end_time',
            'za_batch.batch_name',
            'za_batch.sno as batch_ids',
            'za_staff.nick_name',
            'za_job_position.job_position_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_staff.status AS staff_status',
        )
        ->join('za_batch', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->leftJoin('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
        ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where(function ($query) use ($currentMonth, $currentYear) {
            // Only include batches that end in the current month or future
            $query->whereYear('za_batch.end_date', '>', $currentYear)
                ->orWhere(function ($query) use ($currentMonth, $currentYear) {
                    $query->whereYear('za_batch.end_date', '=', $currentYear)
                        ->whereMonth('za_batch.end_date', '>=', $currentMonth);
                });
        })
        ->leftJoin('za_training', function ($join) {
            // Ensure za_training is joined on za_batch.sno (as batch_ids)
            $join->on('za_training.batch_id', '=', 'za_batch.sno');
        })
        ->where('za_staff.status', '!=', 2)
        ->where('za_staff.sno', $id)
        ->where('za_staff.branch_id', $branch_id)
        ->groupBy(
            'za_staff.sno',
            'za_staff.staff_id',
            'za_staff.staff_name',
            'za_batch.end_date',
            'za_shift_time.shift_start_time',
            'za_shift_time.shift_end_time',
            'za_shift_time.shift_lunch_start',
            'za_shift_time.shift_lunch_end',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_batch.batch_name',
            'za_batch.sno',
            'za_staff.nick_name',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name',
            'za_job_position.job_position_name',
            'za_staff.knowledge_tag',
            'za_staff.per_hour_cost',
            'za_staff.basic_salary',
            'za_staff.status'
        )
        ->orderBy('za_staff.sno', 'desc')
        ->first();
    
        if ($staff) {
            // Parse the start and end times using Carbon
            $shiftStartTime = Carbon::createFromFormat('H:i:s', $staff->shift_start_time);
            $shiftEndTime = Carbon::createFromFormat('H:i:s', $staff->shift_end_time);
    
            // Calculate total working hours
            $totalHours = $shiftEndTime->diffInHours($shiftStartTime);
    
            // Parse the lunch times
            $lunchStartTime = Carbon::createFromFormat('H:i:s', $staff->shift_lunch_start);
            $lunchEndTime = Carbon::createFromFormat('H:i:s', $staff->shift_lunch_end);
    
            // Calculate total lunch hours
            $lunchHours = $lunchEndTime->diffInHours($lunchStartTime);
    
            // Optionally, you can also calculate minutes for more precision
            $totalHoursMinutes = $shiftEndTime->diffInMinutes($shiftStartTime);
            $lunchHoursMinutes = $lunchEndTime->diffInMinutes($lunchStartTime);
    
            $totalWorkingminutes = $totalHoursMinutes - $lunchHoursMinutes;
            $totalHours = floor($totalWorkingminutes / 60); // Get whole hours
            $totalMinutes = $totalWorkingminutes % 60; // Get remaining minutes
    
            $totalWorkingHours = $totalHours + ($totalMinutes / 60);
            // Return or assign the results
            $staff->totalWorkingHours = $totalWorkingHours; // Total working hours
    
            $course_count = BatchModel::where('za_batch.status', 0)->where('za_batch.staff_id', $staff->sno)->distinct('course_id')->count();
    
            $staff->course_count = $course_count;
    
            $staff->customer_count = TrainingModel::where('branch_id', $branch_id)
                ->where('staff_id', $staff->sno)
                ->distinct('customer_id')
                ->count('customer_id');

            // return $staff;
    
            // Get the batches
            $batches = BatchModel::select(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_staff.staff_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time as slot_start_time',
                'za_slot.end_time as slot_end_time'
            )
            ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
            ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_batch.status', '!=', 2)
            ->where('za_slot_type.status', '!=', 2)
            ->where('za_slot.status', '!=', 2)
            ->where('za_batch.staff_id', $id)->whereIn('za_batch.status', [0,3])
            ->groupBy(
                'za_batch.sno',
                'za_batch.batch_id',
                'za_batch.batch_name',
                'za_staff.staff_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_batch.max_students',
                'za_batch.classroom_id',
                'za_class_room.class_room_name',
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_version',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_batch.slot_id',
                'za_slot.slot_name',
                'za_slot_type.slot_type_name',
                'za_slot.start_time',
                'za_slot.end_time'
            )
            ->get();
    
            $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            $total_per_hour_cost = 0;
            $total_batch_costing = 0;

    
            foreach ($batches as $slotType) {
                // Calculate duration_in_minutes for each slot
                $startTime = Carbon::createFromFormat('H:i:s', $slotType->slot_start_time);
                $endTime = Carbon::createFromFormat('H:i:s', $slotType->slot_end_time);
                $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
                $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch
                $slotType->duration_in_minutes = $batchDurationInHours;
            
                $dayIndices = json_decode($slotType->slot_type_days);
                $dayNames = [];
                $overall_fees = 0;
                $allocatedStudents = DB::table('za_training')
                    ->where('za_training.status', 0)
                    ->where('za_training.batch_id', $slotType->sno)
                    ->count('customer_id');
            
                $batchCount = TrainingModel::where('branch_id', $branch_id)
                    ->where('za_training.status', 0)
                    ->distinct('batch_id')
                    ->count('batch_id');
                    
                // Get the present data for each batch
                $present_data = AttendanceModel::select('*')
                    ->where('branch_id', $branch_id)
                    ->where('batch_id', $slotType->sno)
                    ->where('staff_id', $staff->sno)
                    ->where('attendance', 'P')
                    ->whereBetween('att_date', [$slotType->start_date, $slotType->end_date])
                    ->get();
            
                // Initialize the total per hour cost and batch costing variables for each batch
                $total_per_hour_cost = 0;
                $batch_costing = 0;
            
                // Sum the per_hr_cost for each attendance record
                foreach ($present_data as $attendance) {
                    $total_per_hour_cost += $attendance->per_hr_cost;
                }
            
                // Calculate the batch cost using the total duration and per_hr_cost
                if ($total_per_hour_cost > 0) {
                    $batch_costing = $slotType->duration_in_minutes * $total_per_hour_cost;  // Duration in hours * per hour cost
                }
            
                $total_batch_costing += $batch_costing;
                $slotType->batch_costing = $batch_costing;
                $slotType->allocated_students = $allocatedStudents;
            
                // Process days and other details as needed
                if (is_array($dayIndices)) {
                    // Convert start_time and end_time to 12-hour format with AM/PM
                    $slotType->start_time = Carbon::createFromFormat('H:i:s', $slotType->slot_start_time)->format('h:i A');
                    $slotType->end_time = Carbon::createFromFormat('H:i:s', $slotType->slot_end_time)->format('h:i A');
                    foreach ($dayIndices as $index) {
                        // Ensure the index is within the valid range
                        $dayIndex = (int) $index;
            
                        if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
                            $dayNames[] = $shortDays[$dayIndex];
                        } else {
                            $dayNames[] = '-'; // Handle invalid indices
                        }
                    }
                }
            
                // Assign the day names to each slot instance
                $slotType->dayNames = implode(', ', $dayNames);
            }            
    
            // return $batches;
            return view('content.production.manage_costing.staff_costing_view', [
                'staff' => $staff,
                'batches' => $batches,
                'batchCount' => $batchCount,
                'total_batch_costing' => $total_batch_costing,
            ]);
        }
    
        // If no staff found
        return redirect()->back()->with('error', 'Staff not found.');
    }
     
    
}