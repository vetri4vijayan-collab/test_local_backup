<?php

namespace App\Http\Controllers\source_summary;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\DepartmentModel;
use App\Models\PointsModel;
use App\Models\StaffModel;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class SourceSummary extends Controller
{
  public function index(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 10);
      $offset = ($page - 1) * $perpage;
      // Get the current date
      $currentDate = now()->toDateString();
      
    //   $points = PointsModel::select('*')
    //   ->where('status', '!=', 2)
    //   ->orderBy('comments', 'asc')
    //   ->paginate(10);

    $staff= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [20])
    ->where('za_staff.branch_id', $branch_id)
    ->get();

    $staff_pc= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [15])
    ->where('za_staff.branch_id', $branch_id)
    ->get();
    
    $staff_faculty= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [22])
    ->where('za_staff.branch_id', $branch_id)
    ->get();

    $staff_cre= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [16])
    ->where('za_staff.branch_id', $branch_id)
    ->get();

    $staff_sales_lead= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [12])
    ->where('za_staff.branch_id', $branch_id)
    ->get();

    $staff_sale= StaffModel::select('za_staff.sno as staff_sno', 'za_staff.staff_name', 'za_staff.gender','za_staff.staff_image', 'za_user_role.role_name', 'za_staff.role_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.nick_name','za_staff.avaiable_points','za_sub_department.sub_department_name', 'za_staff.sub_department_id', 'za_staff.department_id', 'za_staff.position_role', 'za_job_position.department_id', 'za_job_position.job_position_name', 'za_department.department_name')
    ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
    ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    ->where('za_staff.status', 0)
    ->whereIn('za_staff.role_id', [11,13])
    ->where('za_staff.branch_id', $branch_id)
    ->get();

    // return $staff_pc;   
    $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

      return view('content.source_summary.source_summary', [
          'perpage' => $perpage,
          'staff' => $staff,
          'staff_pc' => $staff_pc,
          'staff_faculty' => $staff_faculty,
          'staff_cre' => $staff_cre,
          'staff_sales' => $staff_sales_lead,
          'staff_sale' => $staff_sale,
          'department' => $department,
      ]);
  }

//   public function update(Request $request)
//   {
//       $points_id = $request->input('points_id');
//       $comments = $request->input('comments');
      
//       $score = PointsModel::where('sno', $points_id)
//                           ->where('comments', $comments)
//                           ->first();

//       if (!$score) {
//           return response()->json([
//               'status' => 404,
//               'message' => 'Score not found',
//               'data' => null,
//           ], 404);
//       }

//       $score->points_name = $request->input('score_name', '');
//       $score->points = $request->input('score_points', '');
//       $score->updated_by = $request->user()->user_id;
      
//       $score->save();

//       if ($score) {
//           session()->flash('toastr', [
//               'type' => 'success',
//               'message' => 'Score updated Successfully!'
//           ]);
//       } else {
//           session()->flash('toastr', [
//               'type' => 'error',
//               'message' => 'Could not update the Score!'
//           ]);
//       }

//       return redirect('/score_summary');
//   }

}