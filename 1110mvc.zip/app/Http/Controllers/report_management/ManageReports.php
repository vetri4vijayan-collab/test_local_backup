<?php

namespace App\Http\Controllers\report_management;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\LedgerModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\StaffModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\UserRolePermissionModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ManageReports extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;

    // Filters
    $lead_type_fill = $request->input('lead_type_fill', '');
    $lead_source_fill = $request->input('lead_source_fill', '');
    $course_fill = $request->input('course_fill', '');
    $potential_type_fill = $request->input('potential_type_fill', '');
    $lead_status_fill = $request->input('lead_status_fill', '');
    $staff_fill = $request->input('staff_fill', '');
    $date_filter = $request->input('dt_fill_issue_rpt');
    $from_date_filter = $request->input('from_date_fillter_textbox');
    $to_date_filter = $request->input('to_date_fillter_textbox');
    $lead_fill = $request->input('lead_fill', '');
    $fin_yr_fill = $request->input('fin_yr_fill', '');

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.course_id',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'latest_appointment.status as appointment_status',
      'latest_appointment.appointment_date',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date, SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
                          FROM za_appointment
                          WHERE (lead_id, appointment_date) IN (
                              SELECT lead_id, MAX(appointment_date) AS appointment_date
                              FROM za_appointment
                              GROUP BY lead_id
                          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(
        DB::raw('(SELECT lead_id, COUNT(*) as total_appointments FROM za_appointment GROUP BY lead_id) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->whereNotIn('za_lead.status', [3, 2, 6]);

    if ($branch_id != 0) {
      $leads->where('za_lead.branch_id', $branch_id);
    }

    // Date Filtering
    if ($date_filter === "today") {
      $leads->whereDate('za_lead.created_at', now()->toDateString());
    } elseif ($date_filter === "week") {
      $leads->whereBetween('za_lead.created_at', [now()->startOfWeek(), now()->endOfWeek()]);
    } elseif ($date_filter === "monthly") {
      $leads->whereMonth('za_lead.created_at', now()->month)
        ->whereYear('za_lead.created_at', now()->year);
    } elseif ($date_filter === "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $leads->whereBetween('za_lead.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
      } elseif ($from_date_filter) {
        $leads->where('za_lead.created_at', '>=', Carbon::parse($from_date_filter));
      } elseif ($to_date_filter) {
        $leads->where('za_lead.created_at', '<=', Carbon::parse($to_date_filter));
      }
    }

    // Financial Year Filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);
        if (is_array($monthsArray)) {
          $leads->where(function ($query) use ($monthsArray) {
            foreach ($monthsArray as $month) {
              $query->orWhereMonth('za_lead.created_at', $month)
                ->whereYear('za_lead.created_at', now()->year);
            }
          });
        }
      }
    }

    // Other Filters
    if ($lead_type_fill) $leads->where('za_lead.lead_type_id', $lead_type_fill);
    if ($staff_fill) $leads->where('za_lead.created_by', $staff_fill);
    if ($lead_source_fill) $leads->where('za_lead.lead_source_id', $lead_source_fill);
    if ($course_fill) {
      $leads->whereJsonContains('za_lead.course_id', $course_fill)
        ->whereRaw('JSON_LENGTH(za_lead.course_id) = 1'); // Ensures only single-item arrays match
    }

    if ($potential_type_fill) $leads->where('za_lead.lead_score', $potential_type_fill);
    if ($lead_status_fill != '') $leads->where('za_lead.status', $lead_status_fill);
    if ($lead_fill) {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    // Fetch Paginated Results
    $leads = $leads->orderBy('za_lead.sno', 'desc')->paginate($perpage);

    // Load Filters
    $staff_filter_list = StaffModel::where('status', 0)
      ->when($branch_id != 0, fn($q) => $q->where('branch_id', $branch_id))
      ->orderBy('nick_name', 'ASC')->get();

    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $course_type = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead_sourse_list = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Lead_status_list = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();

    $Sourse_names = [];
    $sl_count = []; // To store counts of leads for each source

    foreach ($lead_sourse_list as $source) {
      $id = $source->sno;
      // Retrieve the count of leads for the given lead_source_id
      $lead_count = LeadModel::where('lead_source_id', $id)
        ->whereMonth('created_at', now()->month)
        ->whereYear('created_at', now()->year)
        ->count();

      $Sl_count[] = $lead_count; // Add the count to the sl_count array
      $Sourse_names[] = $source->lead_source_name; // Add the lead source name
    }

    $Lead_status_list = [
      (object) ['sno' => 0, 'lead_status_name' => 'Active'],
      (object) ['sno' => 1, 'lead_status_name' => 'Inactive'],
      (object) ['sno' => 4, 'lead_status_name' => 'Customer'],
      (object) ['sno' => 5, 'lead_status_name' => 'Drop'],
      (object) ['sno' => 2, 'lead_status_name' => 'Unlist'],
      (object) ['sno' => 3, 'lead_status_name' => 'Spam']
    ];

    $Status_names = [];
    $Status_count = []; // To store counts of leads for each status

    foreach ($Lead_status_list as $status) {
      $lead_count = LeadModel::where('status', $status->sno)->whereMonth('created_at', now()->month)
        ->whereYear('created_at', now()->year)->count();
      $Status_count[] = $lead_count; // Add the count to the Status_count array
      $Status_names[] = $status->lead_status_name; // Add the lead status name
    }


    $Sales_names = [];
    $Sales_count = []; // To store counts of leads for each source

    foreach ($staff_filter_list as $staff) {
      $id = $staff->sno;
      // Retrieve the count of leads for the given lead_staff_id
      $lead_count = LeadModel::where('created_by', $id)->whereMonth('created_at', now()->month)
        ->whereYear('created_at', now()->year)->count();
      $Sales_count[] = $lead_count; // Add the count to the sl_count array
      $Sales_names[] = $staff->staff_name; // Add the lead source name
    }

    $viewData = compact(
      'leads',
      'course_type',
      'Status_names',
      'Status_count',
      'Sales_names',
      'Sales_count',
      'Sourse_names',
      'Sl_count',
      'lead_sourse_list',
      'lead_type_fill',
      'lead_source_fill',
      'course_fill',
      'Course_list',
      'perpage',
      'date_filter',
      'lead_fill',
      'Lead_status_list',
      'staff_filter_list',
      'staff_fill',
      'potential_type_fill',
      'lead_status_fill',
      'login_branch_data',
      'fin_yr_fill',
      'from_date_filter',
      'to_date_filter'
    );

    $filterOn = $request->filter_on ?? 0;

    if ($filterOn) {
      return view('content.report_management.lead.list', $viewData)->with('filter_on', true);
    }
    return view('content.report_management.lead.list', $viewData)->with('filter_on', false);
  }


  function source_graph(Request $request)
  {
    // Get the inputs from the request
    $fin_yr_fill = $request->input('fin_yr', '');
    $date_filter = $request->input('date');
    $from_date_filter = $request->input('from_date'); // Assuming you pass these
    $to_date_filter = $request->input('to_date'); // Assuming you pass these

    // Initialize arrays to store source names and lead counts
    $Sourse_names = [];
    $Sl_count = [];

    // Get the list of lead sources where status is 0
    $lead_sourse_list = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();

    foreach ($lead_sourse_list as $source) {
      $id = $source->sno;

      // Start with the basic query to get the leads based on the source
      $leads = LeadModel::where('lead_source_id', $id);

      // Apply date filters
      if ($date_filter === "today") {
        $leads->whereDate('za_lead.created_at', now()->toDateString()); // Today's leads
      } elseif ($date_filter === "week") {
        $leads->whereBetween('za_lead.created_at', [now()->startOfWeek(), now()->endOfWeek()]); // This week's leads
      } elseif ($date_filter === "monthly") {
        $leads->whereMonth('za_lead.created_at', now()->month)
          ->whereYear('za_lead.created_at', now()->year); // This month's leads
      } elseif ($date_filter === "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $leads->whereBetween('za_lead.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]); // Custom date range
        } elseif ($from_date_filter) {
          $leads->where('za_lead.created_at', '>=', Carbon::parse($from_date_filter)); // From date only
        } elseif ($to_date_filter) {
          $leads->where('za_lead.created_at', '<=', Carbon::parse($to_date_filter)); // To date only
        }
      }

      // Apply financial year filter if specified
      if ($fin_yr_fill) {
        $helper = new Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

        if ($selected_fin_year) {
          $monthsArray = json_decode($selected_fin_year->financial_month, true);
          if (is_array($monthsArray)) {
            $leads->where(function ($query) use ($monthsArray) {
              foreach ($monthsArray as $month) {
                $query->orWhereMonth('za_lead.created_at', $month)
                  ->whereYear('za_lead.created_at', now()->year); // Apply the financial months filter
              }
            });
          }
        }
      }

      // Get the count of leads for the current lead source after applying filters
      $lead_count = $leads->count();

      // Add the lead count and source name to their respective arrays
      $Sl_count[] = $lead_count;
      $Sourse_names[] = $source->lead_source_name;
    }

    // Return the data (or further process as needed)
    return response()->json([
      'Sourseames' => $Sourse_names,
      'SourceTotals' => $Sl_count
    ]);
  }

  function status_graph(Request $request)
  {
    // Get the inputs from the request
    $fin_yr_fill = $request->input('fin_yr', '');
    $date_filter = $request->input('date');
    $from_date_filter = $request->input('from_date'); // Assuming you pass these
    $to_date_filter = $request->input('to_date'); // Assuming you pass these

    // Initialize arrays to store source names and lead counts
    $Status_names = [];
    $Status_count = [];

    $Lead_status_list = [
      (object) ['sno' => 0, 'lead_status_name' => 'Active'],
      (object) ['sno' => 1, 'lead_status_name' => 'Inactive'],
      (object) ['sno' => 4, 'lead_status_name' => 'Customer'],
      (object) ['sno' => 5, 'lead_status_name' => 'Drop'],
      (object) ['sno' => 2, 'lead_status_name' => 'Unlist'],
      (object) ['sno' => 3, 'lead_status_name' => 'Spam']
    ];

    // $Lead_status_list = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();

    foreach ($Lead_status_list as $source) {
      $id = $source->sno;

      // Start with the basic query to get the leads based on the source
      $leads = LeadModel::where('status', $id);

      // Apply date filters
      if ($date_filter === "today") {
        $leads->whereDate('za_lead.created_at', now()->toDateString()); // Today's leads
      } elseif ($date_filter === "week") {
        $leads->whereBetween('za_lead.created_at', [now()->startOfWeek(), now()->endOfWeek()]); // This week's leads
      } elseif ($date_filter === "monthly") {
        $leads->whereMonth('za_lead.created_at', now()->month)
          ->whereYear('za_lead.created_at', now()->year); // This month's leads
      } elseif ($date_filter === "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $leads->whereBetween('za_lead.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]); // Custom date range
        } elseif ($from_date_filter) {
          $leads->where('za_lead.created_at', '>=', Carbon::parse($from_date_filter)); // From date only
        } elseif ($to_date_filter) {
          $leads->where('za_lead.created_at', '<=', Carbon::parse($to_date_filter)); // To date only
        }
      }

      // Apply financial year filter if specified
      if ($fin_yr_fill) {
        $helper = new Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

        if ($selected_fin_year) {
          $monthsArray = json_decode($selected_fin_year->financial_month, true);
          if (is_array($monthsArray)) {
            $leads->where(function ($query) use ($monthsArray) {
              foreach ($monthsArray as $month) {
                $query->orWhereMonth('za_lead.created_at', $month)
                  ->whereYear('za_lead.created_at', now()->year); // Apply the financial months filter
              }
            });
          }
        }
      }

      // Get the count of leads for the current lead source after applying filters
      $lead_count = $leads->count();

      // Add the lead count and source name to their respective arrays
      $Status_count[] = $lead_count;
      $Status_names[] = $source->lead_status_name;
    }

    // Return the data (or further process as needed)
    return response()->json([
      'Status_names' => $Status_names,
      'Status_count' => $Status_count
    ]);
  }

  function sales_graph(Request $request)
  {
    // Get the inputs from the request
    $branch_id = $request->user()->branch_id;

    $fin_yr_fill = $request->input('fin_yr', '');
    $date_filter = $request->input('date');
    $from_date_filter = $request->input('from_date'); // Assuming you pass these
    $to_date_filter = $request->input('to_date'); // Assuming you pass these

    $Sales_names = [];
    $Sales_count = [];


    $staff_filter_list = StaffModel::where('status', 0)
      ->when($branch_id != 0, fn($q) => $q->where('branch_id', $branch_id))
      ->orderBy('nick_name', 'ASC')->get();


    foreach ($staff_filter_list as $source) {
      $id = $source->sno;

      // Start with the basic query to get the leads based on the source
      $leads = LeadModel::where('created_by', $id);

      // Apply date filters
      if ($date_filter === "today") {
        $leads->whereDate('za_lead.created_at', now()->toDateString()); // Today's leads
      } elseif ($date_filter === "week") {
        $leads->whereBetween('za_lead.created_at', [now()->startOfWeek(), now()->endOfWeek()]); // This week's leads
      } elseif ($date_filter === "monthly") {
        $leads->whereMonth('za_lead.created_at', now()->month)
          ->whereYear('za_lead.created_at', now()->year); // This month's leads
      } elseif ($date_filter === "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $leads->whereBetween('za_lead.created_at', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]); // Custom date range
        } elseif ($from_date_filter) {
          $leads->where('za_lead.created_at', '>=', Carbon::parse($from_date_filter)); // From date only
        } elseif ($to_date_filter) {
          $leads->where('za_lead.created_at', '<=', Carbon::parse($to_date_filter)); // To date only
        }
      }

      // Apply financial year filter if specified
      if ($fin_yr_fill) {
        $helper = new Helpers();
        $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

        if ($selected_fin_year) {
          $monthsArray = json_decode($selected_fin_year->financial_month, true);
          if (is_array($monthsArray)) {
            $leads->where(function ($query) use ($monthsArray) {
              foreach ($monthsArray as $month) {
                $query->orWhereMonth('za_lead.created_at', $month)
                  ->whereYear('za_lead.created_at', now()->year); // Apply the financial months filter
              }
            });
          }
        }
      }

      // Get the count of leads for the current lead source after applying filters
      $lead_count = $leads->count();

      // Add the lead count and source name to their respective arrays
      $Sales_count[] = $lead_count;
      $Sales_names[] = $source->staff_name;
    }

    // Return the data (or further process as needed)
    return response()->json([
      'Sales_names' => $Sales_names,
      'Sales_count' => $Sales_count
    ]);
  }


  // customer Report
  public function customer_report(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int)$request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;

    $helper = new \App\Helpers\Helpers();
    $get_branch_type = $branch_id ? $helper->get_branch_id($branch_id)->branch_type ?? 0 : 0;

    $customer_fill = $request->customer_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // return $request;
    $query = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_training.course_mode_id',
      'za_staff.staff_name',
      'za_branch.min_prd_cost',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count')

    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.status', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_training.course_mode_id',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_branch.min_prd_cost'

      )
      ->orderBy('za_customer.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_customer.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_customer.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_customer.created_at', '<=', $toDate);
      }
    }
    // Financial year filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
        foreach ($monthsArray as $month) {
          if (is_numeric($month) && $month >= 1 && $month <= 12) {
            $query->orWhere(function ($q) use ($month) {
              $q->whereYear('za_customer.created_at', now()->year)
                ->whereMonth('za_customer.created_at', (int)$month);
            });
          }
        }
      }
    }

    if ($branch_id > 0) {
      $query->where('za_customer.branch_id', $branch_id);
    }

    if ($customer_fill) {
      $query->where(function ($customer) use ($customer_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$customer_fill}%");
      });
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }
    if ($batch_name_fill) {
      $query->where('za_batch.sno', $batch_name_fill);
    }
    if ($slot_name_fill) {
      $query->where('za_slot.sno', $slot_name_fill);
    }

    // Fetch Branch list ordered by sno in descending order
    $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate($perpage);

    // $customers = $customers->unique('payment_id');

    $customers->transform(function ($item, $key) {
      // Initialize an array to hold course and batch details
      $carouselDetails = [];
      $paymentget = DB::table('za_training')
        ->where('customer_id', $item->sno)
        ->whereIn('status', [0, 2]) // Use an array for the values
        ->get();

      // Decode the JSON arrays for course_id and batch_id
      $courseIds = $paymentget;
      $batchIds = json_decode($item->batch_id);

      // Check if both arrays are the same length
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      foreach ($courseIds as $index => $courseId) {
        // $batchId = $batchIds[$index];
        $batchId = $batchIds[$index] ?? [];

        // Retrieve course details
        $course = DB::table('za_course')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
          ->where('za_course.sno', $courseId->course_id)
          ->first();

        // Get date format from general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

        // Retrieve batch details
        $batch = DB::table('za_batch')
          ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
          ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
          ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
          ->where('za_batch.sno', $batchId)
          ->first();

        // Format start_date and end_date
        $startDate = !empty($batch->start_date) ? \Carbon\Carbon::parse($batch->start_date)->format($dateFormat) : null;
        $endDate = !empty($batch->end_date) ? \Carbon\Carbon::parse($batch->end_date)->format($dateFormat) : null;

        // Retrieve summed paidAmount and total_amount for the specific course and batch
        $paymentDetails = DB::table('za_training')
          ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
          ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
          ->where('za_training.customer_id', $item->sno)
          ->where('za_training.course_id', $courseId->course_id)
          ->where('za_training.status', '!=', 3)
          ->where('za_payment.status', '!=', 3)
          //   ->where('za_training.batch_id', $batchId)
          ->groupBy('za_payment.total_amount') // Since total_amount remains constant, group by it
          ->first();

        // Calculate payment percentage for the specific course and batch
        $paymentPercentage = 0;
        if ($paymentDetails && $paymentDetails->total_amount > 0) {
          $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
        }

        // Check if attendance exists for the specific batch and customer
        $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
          ->where('batch_id', $batchId)
          ->where('attendance', 'P')
          ->get();

        // Initialize course progress percentage
        $courseProgress = 0;

        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
          ->count();


        // If attendance exists, check for syllabus update percentage for each attendance record
        if ($attendanceRecords->isNotEmpty()) {
          foreach ($attendanceRecords as $attendance) {
            // Check for all syllabus updates that match the batch_id and attendance date
            $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchId)
              ->whereDate('date', $attendance->att_date) // Check the attendance date
              ->get(); // Get all syllabus updates for that date

            // If syllabus updates exist, sum the percentages
            if ($syllabusUpdates->isNotEmpty()) {
              foreach ($syllabusUpdates as $syllabusUpdate) {
                if ($syllabusUpdate->percentage == 100) {
                  $topicCount++;
                }
              }
            }
          }
          if ($course_topic_count > 0) {
            $courseProgress = ($topicCount / $course_topic_count) * 100;
          }
          // Limit the course progress to a maximum of 100%
          if ($courseProgress > 100) {
            $courseProgress = 100; // Cap the maximum value at 100%
          }

          // Format the course progress to 2 decimal places
          $courseProgress = number_format($courseProgress, 2);
        }

        // batch count by course id
        $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
        // Add the course and batch details to the array
        $carouselDetails[] = [
          'course_sno' => $courseId->course_id ?? null,
          'course_mode_id' => $courseId->course_mode_id ?? null,
          'online_course_fee' => $course->online_fee ?? null,
          'batch_sno' => $batchId ?? null,
          'batch_count' => $batch_count ?? 0,
          'traning_status' => $courseId->status ?? null,
          'traning_sno' => $courseId->sno ?? null,
          'course_name' => $course->course_name ?? null,
          'course_type_name' => $course->course_type_name ?? null,
          'batch_name' => $batch->batch_name ?? null,
          'start_date' => $startDate, // Use formatted start date
          'end_date' => $endDate, // Use formatted end date
          'slot_name' => $batch->slot_name ?? null,
          'staff_name' => $batch->staff_name ?? null,
          'payment_percentage' => $paymentPercentage, // Include calculated payment percentage here
          'course_progress' => $courseProgress, // Include course progress percentage here
        ];
      }
      // }

      // Attach the carousel details to the customer item
      $item->carousel_details = $carouselDetails;

      // Calculate initial letter
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));

      // Calculate overall payment percentage if total amount is not zero
      if ($item->total_amount > 0) {
        $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
      } else {
        $item->payment_percentage = number_format(0, 1);
      }

      return $item;
    });

    // Fetch other data lists
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('course_type_name', 'ASC')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('course_name', 'ASC')->get();
    $batch_list = BatchModel::where('branch_id', $branch_id)->orderBy('batch_name', 'ASC')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('slot_name', 'ASC')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'ASC')->get();

    $gender_name = ['Male', 'Female', 'Others'];
    $gender_count = []; // To store counts of leads for each source

    foreach ($customers as $customer) {
      $id = $customer->cus_gender;

      $lead_count = CustomerModel::where('cus_gender', $id)->count();

      switch ($id) {
        case 1:
          $gender_name = 'Male';
          break;
        case 2:
          $gender_name = 'Female';
          break;
        case 3:
          $gender_name = 'Others';
          break;
        default:
          $gender_name = '-';
      }

      // Store the gender name and lead count in their respective arrays
      $gender_count[] = $lead_count; // Add the count to the gender_count array
      $gender_names[] = $gender_name; // Add the gender name to the gender_names array
    }

    // If you need to return or use the $gender_names array outside the loop:
    // return $gender_count;


    $filterOn = $request->filter_on ?? 0;

    if ($filterOn) {
      return view('content.report_management.customer.list', [
        'customers' => $customers,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'customer_fill' => $customer_fill,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'perpage' => $perpage,
        'gender_name' => $gender_name,
        'gender_count' => $gender_count,
      ])->with('filter_on', true);
    }
    return view('content.report_management.customer.list', [
      'customers' => $customers,
      'course_type_list' => $course_type_list,
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'slot_list' => $slot_list,
      'slot_type_list' => $slot_type_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'customer_fill' => $customer_fill,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'batch_name_fill' => $batch_name_fill,
      'slot_name_fill' => $slot_name_fill,
      'slot_type_name_fill' => $slot_type_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,
      'perpage' => $perpage,
      'gender_name' => $gender_name,
      'gender_count' => $gender_count,
    ])->with('filter_on', false);
  }


  // Payment Report
  public function customer_consolidate_report(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int)$request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;
    $helper = new \App\Helpers\Helpers();
    $get_branch_type = $branch_id ? $helper->get_branch_id($branch_id)->branch_type ?? 0 : 0;

    $customer_fill = $request->customer_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // return $request;
    $query = TrainingModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_training.course_mode_id',
      'za_training.course_id',
      'za_training.batch_id',
      'za_customer.placement_status',
      'za_training.certificate_status'
    )
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_training.status', 0)
      ->where('za_training.branch_id', $branch_id);
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_training.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_training.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_training.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_training.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_training.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_training.created_at', '<=', $toDate);
      }
    }
    // Financial year filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
        foreach ($monthsArray as $month) {
          if (is_numeric($month) && $month >= 1 && $month <= 12) {
            $query->orWhere(function ($q) use ($month) {
              $q->whereYear('za_training.created_at', now()->year)
                ->whereMonth('za_training.created_at', (int)$month);
            });
          }
        }
      }
    }

    if ($branch_id > 0) {
      $query->where('za_customer.branch_id', $branch_id);
    }

    if ($customer_fill) {
      $query->where(function ($customer) use ($customer_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$customer_fill}%");
      });
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }
    if ($batch_name_fill) {
      $query->where('za_batch.sno', $batch_name_fill);
    }

    // Fetch Branch list ordered by sno in descending order
    $customers = $query->orderBy('za_training.customer_id', 'desc')->distinct()->paginate($perpage);

    // Fetch other data lists
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('course_type_name', 'ASC')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('course_name', 'ASC')->get();
    $batch_list = BatchModel::where('branch_id', $branch_id)->orderBy('batch_name', 'ASC')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('slot_name', 'ASC')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'ASC')->get();


    // If you need to return or use the $gender_names array outside the loop:
    // return $gender_count;


    $filterOn = $request->filter_on ?? 0;

    if ($filterOn) {
      return view('content.report_management.consolidate.list', [
        'customers' => $customers,
        'course_type_list' => $course_type_list,
        'course_list' => $course_list,
        'batch_list' => $batch_list,
        'slot_list' => $slot_list,
        'slot_type_list' => $slot_type_list,
        'login_branch_id' => $branch_id,
        'login_branch_type' => $get_branch_type,
        'customer_fill' => $customer_fill,
        'customer_name_fill' => $customer_name_fill,
        'mobile_fill' => $mobile_fill,
        'gender_fill' => $gender_fill,
        'course_type_fill' => $course_type_fill,
        'course_name_fill' => $course_name_fill,
        'batch_name_fill' => $batch_name_fill,
        'slot_name_fill' => $slot_name_fill,
        'slot_type_name_fill' => $slot_type_name_fill,
        'date_filter' => $date_filter,
        'from_date_filter' => $from_date_filter,
        'to_date_filter' => $to_date_filter,
        'fin_yr_fill' => $fin_yr_fill,
        'perpage' => $perpage,
      ])->with('filter_on', true);
    }
    return view('content.report_management.consolidate.list', [
      'customers' => $customers,
      'course_type_list' => $course_type_list,
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'slot_list' => $slot_list,
      'slot_type_list' => $slot_type_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'customer_fill' => $customer_fill,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'batch_name_fill' => $batch_name_fill,
      'slot_name_fill' => $slot_name_fill,
      'slot_type_name_fill' => $slot_type_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,
      'perpage' => $perpage,
    ])->with('filter_on', false);
  }


  public function accounts_report(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int)$request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;

    $ledger_fill = $request->ledger_fill ?? '';
    $sub_ledger_fill = $request->sub_ledger_fill ?? '';
    $ledger_acc_fill = $request->ledger_acc_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;

    $trans_list = TransactionModel::select('za_transaction.*', 'za_ledger.ledger_name', 'za_subledger.subledger_name')
      ->leftJoin('za_ledger', 'za_ledger.sno', '=', 'za_transaction.ledger_id')
      ->leftJoin('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id');

    // Branch Filter
    if ($branch_id != 0) {
      $trans_list->where('za_transaction.branch_id', $branch_id);
    }

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $trans_list->whereDate('za_transaction.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      $weekFromDate = ($today == "Sunday") ? date('Y-m-d', strtotime("sunday 0 week")) : date('Y-m-d', strtotime("sunday -1 week"));
      $weekToDate = ($today == "Sunday") ? date('Y-m-d', strtotime("saturday 1 week")) : date('Y-m-d', strtotime("saturday 0 week"));
      $trans_list->whereBetween('za_transaction.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $trans_list->whereBetween('za_transaction.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date" && $from_date_filter && $to_date_filter) {
      $fromDate = date('Y-m-d', strtotime($from_date_filter));
      $toDate = date('Y-m-d', strtotime($to_date_filter));
      $trans_list->whereBetween('za_transaction.created_at', [$fromDate, $toDate]);
    } elseif ($date_filter == "custom_date" && $from_date_filter) {
      $fromDate = date('Y-m-d', strtotime($from_date_filter));
      $trans_list->where('za_transaction.created_at', '>=', $fromDate);
    } elseif ($date_filter == "custom_date" && $to_date_filter) {
      $toDate = date('Y-m-d', strtotime($to_date_filter));
      $trans_list->where('za_transaction.created_at', '<=', $toDate);
    }

    // Other Filters
    if ($ledger_fill) {
      $trans_list->where('za_transaction.ledger_id', $ledger_fill);
    }
    if ($sub_ledger_fill) {
      $trans_list->where('za_transaction.subledger_id', $sub_ledger_fill);
    }
    if ($ledger_acc_fill) {
      $trans_list->where('za_transaction.transaction_name', $ledger_acc_fill);
    }

    // Pagination
    $trans_list = $trans_list->orderBy('za_transaction.sno', 'desc')->paginate($perpage);

    // return $trans_list;  // Return paginated results

    // Additional Data
    $ledger_list = LedgerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $sum_credit = TransactionModel::selectRaw('SUM(credit) AS total_credit')
      ->where('branch_id', $branch_id)
      ->where('status', 1)
      ->first();
    $sum_debit = TransactionModel::selectRaw('SUM(debit) AS total_debit')
      ->where('branch_id', $branch_id)
      ->where('status', 1)
      ->first();

    $viewData = [
      'trans_list' => $trans_list,
      'ledger_list' => $ledger_list,
      'sum_debit' => $sum_debit,
      'sum_credit' => $sum_credit,
      'ledger_fill' => $ledger_fill,
      'sub_ledger_fill' => $sub_ledger_fill,
      'ledger_acc_fill' => $ledger_acc_fill,
      'date_filter' => $date_filter,
      'perpage' => $perpage
    ];

    $filterOn = $request->filter_on ?? 0;

    if ($filterOn) {
      return view('content.report_management.accounts.list', $viewData)->with('filter_on', true);
    }
    return view('content.report_management.accounts.list', $viewData)->with('filter_on', false);
  }



  public function batch_report(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;

    $branch_id = $request->user()->branch_id;
    // return $request;
    // Retrieve request parameters with default values
    $course_type_fill = $request->course_type_fill ?? '';
    $course_fill = $request->course_fill ?? '';
    $batch_name_fill = $request->batch_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // Initialize query with base conditions
    $query = BatchModel::where('za_batch.status', '!=', 2);

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_batch.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_batch.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_batch.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_batch.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_batch.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_batch.created_at', '<=', $toDate);
      }
    }
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && !empty($monthsArray)) {
          $monthConditions = [];

          foreach ($monthsArray as $month) {
            if (is_numeric($month) && $month >= 1 && $month <= 12) {
              $monthConditions[] = [
                'year' => date('Y'),
                'month' => (int) $month,
              ];
            }
          }
          if (!empty($monthConditions)) {
            $query->where(function ($query) use ($monthConditions) {
              foreach ($monthConditions as $condition) {
                $query->orWhere(function ($q) use ($condition) {
                  $q->whereYear('za_batch.created_at', $condition['year'])
                    ->whereMonth('za_batch.created_at', $condition['month']);
                });
              }
            });
          }
        }
      }
    }

    if ($course_type_fill) {
      $query->where('za_batch.course_type_id', $course_type_fill);
    }
    if ($course_fill) {
      $query->where('za_batch.course_id', $course_fill);
    }
    if ($batch_name_fill) {
      $query->where('batch_name', 'like', "%{$batch_name_fill}%");
    }
    if ($branch_id != 0) {
      $query->where('za_batch.branch_id', $branch_id);
    }

    // Fetch Branch list ordered by sno in descending order

    $query->select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->orderBy('za_batch.sno', 'desc');

    if ($branch_id != 0) {
      $query->where('za_batch.branch_id', $branch_id);
    }

    $batch_list = $query->paginate($perpage);

    // Get the student count for each batch
    foreach ($batch_list as $singleBatch) {
      $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
        // Uncomment the next line if you want to filter by course_id
        // ->where('course_id', $singleBatch->course_id)
        ->count('customer_id');
    }
    // return $batch;
    // return $batch_list;
    $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    // Return the view with filter variables and session flash for filter_on
    $viewData = [
      'batch' => $batch_list,
      'course_Type_list' => $course_type,
      'course_type_fill' => $course_type_fill,
      'course_fill' => $course_fill,
      'batch_name_fill' => $batch_name_fill,
      'date_filter' => $date_filter,
      'fin_yr_fill' => $fin_yr_fill,
      'perpage' => $perpage
    ];

    $filterOn = $request->filter_on ?? 0;

    if ($filterOn) {
      return view('content.report_management.batch.list', $viewData)->with('filter_on', true);
    }
    return view('content.report_management.batch.list', $viewData)->with('filter_on', false);
  }
}
