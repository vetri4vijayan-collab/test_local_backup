<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BranchModel;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class FeedbackReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function feedback_event_yearly()
    {
        $feedbacknavHtml = $this->generateNavHtml();
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.feedback_report.event_feedback_yr_list', compact(
            'months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function feedbackEventYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $days = range(1, 31); // Daily

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $yearly_avg_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            $result = $this->GetFeedbacEventDetails($branch_id);
            
            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $paymentMonthSums = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];
            $att_years = !empty($paymentMonthSums) ? collect(array_keys($paymentMonthSums)) : collect();
            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
            
            // Step 2: deduplicate, sort
            $allYears = $att_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            // return $years;
            
            foreach ($finalYears as $year_index => $year) {

                $pre_year  = (int)$year - 1;

                $Trend_data_list = [];
                
                foreach ($months as $monthNum => $monthName) {

                    $amount = isset($paymentSums[$year][$monthNum]['count']) ? round($paymentSums[$year][$monthNum]['count']) : 0;
                    $yearly_average = isset($paymentMonthSums[$year]['average']) && !empty($paymentMonthSums[$year]['average']) ? round(($paymentMonthSums[$year]['average']),2) : 0;
                    $monthly_average = isset($paymentSums[$year][$monthNum]['average']) && !empty($paymentSums[$year][$monthNum]['average']) ? round(($paymentSums[$year][$monthNum]['average']),2) : 0;

                    // Save raw daily data
                    $data[$year][$monthNum] = $amount;

                    if($year_index != 0){
                        
                        $Trend_data_list[$monthNum] = $amount;
                        $Trend_percentages[$monthNum] = $monthly_average ?? 0;

                        // Month grand total
                        $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                        $yearly_avg_data[$year] = $yearly_average ?? 0;

                        // Day totals across months
                        $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;
                    }
                }

                if($year_index != 0){
                    $Trend_data[$year] = $Trend_data_list;
                    $percentages[$year] = $Trend_percentages;
                }
            }

            foreach ($years as $year) {
                $monthTotal = $grandMonthTotals[$year] ?? 0;
                $grandAllTotal += $monthTotal;
            }

            $year_colors = $this->generateAttractiveColors($years);
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'yearly_avg_data' => $yearly_avg_data,
                'present_data' => $present_data,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function feedback_event_monthly()
    {
        // Days (1–31 max)
        $days = range(1, 31);
        $feedbacknavHtml = $this->generateNavHtml();

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.feedback_report.event_feedback_monthly_list', compact(
            'months',
            'days','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function feedbackEventMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFeedbacEventDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];
            $paymentMonthSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

            // return $paymentSums;
            $days = range(1, 31);

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                $Trend_avg_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums[$year][$monthNum][$day]['count']) ? round($paymentSums[$year][$monthNum][$day]['count']) : 0;

                    $monthly_average = isset($paymentMonthSums[$year][$monthNum]['average']) && !empty($paymentMonthSums[$year][$monthNum]['average']) ? round(($paymentMonthSums[$year][$monthNum]['average']),2) : 0;
                    $daily_average = isset($paymentSums[$year][$monthNum][$day]['average']) && !empty($paymentSums[$year][$monthNum][$day]['average']) ? round(($paymentSums[$year][$monthNum][$day]['average']),2) : 0;
                    
                    $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth]['count']) ? round($paymentSums[$pre_year][12][$pre_daysInMonth]['count']) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;
                    $percentages[$monthNum][$day] = $daily_average;

                    $Trend_data_list[$day] = $amount;
                    $Trend_avg_data_list[$day] = $daily_average;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;
                    $total_students_data[$monthNum] = ($monthly_average ?? 0);

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
                $Trend_percentages[$monthName] = $Trend_avg_data_list;
            }

            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function feedback_intern_yearly()
    {
        $feedbacknavHtml = $this->generateNavHtml();
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.feedback_report.intern_feedback_yr_list', compact(
            'months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function feedbackInternYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $days = range(1, 31); // Daily

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $yearly_avg_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            $result = $this->GetFeedbacInternDetails($branch_id);
            
            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $paymentMonthSums = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];
            $att_years = !empty($paymentMonthSums) ? collect(array_keys($paymentMonthSums)) : collect();
            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
            
            // Step 2: deduplicate, sort
            $allYears = $att_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            // return $years;
            
            foreach ($finalYears as $year_index => $year) {

                $pre_year  = (int)$year - 1;

                $Trend_data_list = [];
                
                foreach ($months as $monthNum => $monthName) {

                    $amount = isset($paymentSums[$year][$monthNum]['count']) ? round($paymentSums[$year][$monthNum]['count']) : 0;
                    $yearly_average = isset($paymentMonthSums[$year]['average']) && !empty($paymentMonthSums[$year]['average']) ? round(($paymentMonthSums[$year]['average']),2) : 0;
                    $monthly_average = isset($paymentSums[$year][$monthNum]['average']) && !empty($paymentSums[$year][$monthNum]['average']) ? round(($paymentSums[$year][$monthNum]['average']),2) : 0;

                    // Save raw daily data
                    $data[$year][$monthNum] = $amount;

                    if($year_index != 0){
                        
                        $Trend_data_list[$monthNum] = $amount;
                        $Trend_percentages[$monthNum] = $monthly_average ?? 0;

                        // Month grand total
                        $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                        $yearly_avg_data[$year] = $yearly_average ?? 0;

                        // Day totals across months
                        $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;
                    }
                }

                if($year_index != 0){
                    $Trend_data[$year] = $Trend_data_list;
                    $percentages[$year] = $Trend_percentages;
                }
            }

            foreach ($years as $year) {
                $monthTotal = $grandMonthTotals[$year] ?? 0;
                $grandAllTotal += $monthTotal;
            }

            $year_colors = $this->generateAttractiveColors($years);
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'yearly_avg_data' => $yearly_avg_data,
                'present_data' => $present_data,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function feedback_intern_monthly()
    {
        // Days (1–31 max)
        $days = range(1, 31);

        $feedbacknavHtml = $this->generateNavHtml();

        // Months
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.feedback_report.intern_feedback_monthly_list', compact(
            'months',
            'days','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function feedbackInternMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetFeedbacInternDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];
            $paymentMonthSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

            // return $paymentSums;
            $days = range(1, 31);

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                $Trend_avg_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums[$year][$monthNum][$day]['count']) ? round($paymentSums[$year][$monthNum][$day]['count']) : 0;

                    $monthly_average = isset($paymentMonthSums[$year][$monthNum]['average']) && !empty($paymentMonthSums[$year][$monthNum]['average']) ? round(($paymentMonthSums[$year][$monthNum]['average']),2) : 0;
                    $daily_average = isset($paymentSums[$year][$monthNum][$day]['average']) && !empty($paymentSums[$year][$monthNum][$day]['average']) ? round(($paymentSums[$year][$monthNum][$day]['average']),2) : 0;
                    
                    $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth]['count']) ? round($paymentSums[$pre_year][12][$pre_daysInMonth]['count']) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;
                    $percentages[$monthNum][$day] = $daily_average;

                    $Trend_data_list[$day] = $amount;
                    $Trend_avg_data_list[$day] = $daily_average;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;
                    $total_students_data[$monthNum] = ($monthly_average ?? 0);

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
                $Trend_percentages[$monthName] = $Trend_avg_data_list;
            }

            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function feedback_avg_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $feedbacknavHtml = $this->generateNavHtml();

        return view('content.report_management.feedback_report.avg_feedback_yearly_list', compact(
            'months','feedbacknavHtml'
        ))->with('report_heading', self::$report_heading);
    }

    public function feedbackAvgYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getFeedbackAvgDetails($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'event_average' => 'Event',
                'intern_average' => 'Intern'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $month_percentages = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$year][$monthNum][$type_key]) ? $monthlyData[$year][$monthNum][$type_key] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                // $percentages[$year] = ($monthly_data[$year]['drop_percentage'] ?? 0);
                                // $month_percentages[$year][$monthNum] = isset($monthlyData[$year][$monthNum]['drop_percentage']) ? $monthlyData[$year][$monthNum]['drop_percentage'] : 0;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'month_percentages' => $month_percentages,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function GetFeedbacEventDetails(int $branch_id)
    {
        try {
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $feedbacks = DB::table('za_event_feedback_answer')
                ->select('feedback_json')
                ->where('branch_id', $branch_id)
                // ->where('status', 1)
                ->get();

            if ($feedbacks->isEmpty()) {
                return [
                    'yearly'  => [],
                    'monthly' => [],
                    'daily'   => [],
                    'years'   => []
                ];
            }

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            foreach ($feedbacks as $row) {

                $json = json_decode($row->feedback_json, true);
                if (!$json || empty($json['submitted_at'])) {
                    continue;
                }

                $date = date('Y-m-d', strtotime($json['submitted_at']));
                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));

                // ---- Calculate average score per feedback ----
                $scores = array_column($json['answers'] ?? [], 'answer_score');

                $avgScore = count($scores) ? array_sum($scores) / count($scores) : 0;

                // ---- Daily ----
                $dailyData[$y][$m][$d]['count'] =
                    ($dailyData[$y][$m][$d]['count'] ?? 0) + 1;

                $dailyData[$y][$m][$d]['total'] =
                    ($dailyData[$y][$m][$d]['total'] ?? 0) + $avgScore;

                // ---- Monthly ----
                $monthlyData[$y][$m]['count'] =
                    ($monthlyData[$y][$m]['count'] ?? 0) + 1;

                $monthlyData[$y][$m]['total'] =
                    ($monthlyData[$y][$m]['total'] ?? 0) + $avgScore;

                // ---- Yearly ----
                $yearlyData[$y]['count'] =
                    ($yearlyData[$y]['count'] ?? 0) + 1;

                $yearlyData[$y]['total'] =
                    ($yearlyData[$y]['total'] ?? 0) + $avgScore;

                $years[$y] = true;
            }

            // ---- Finalize averages ----
            foreach ($dailyData as $y => $months) {
                foreach ($months as $m => $days) {
                    foreach ($days as $d => $val) {
                        $dailyData[$y][$m][$d]['average'] =
                            round($val['total'] / $val['count'], 2);
                        unset($dailyData[$y][$m][$d]['total']);
                    }
                }
            }

            foreach ($monthlyData as $y => $months) {
                foreach ($months as $m => $val) {
                    $monthlyData[$y][$m]['average'] =
                        round($val['total'] / $val['count'], 2);
                    unset($monthlyData[$y][$m]['total']);
                }
            }

            foreach ($yearlyData as $y => $val) {
                $yearlyData[$y]['average'] =
                    round($val['total'] / $val['count'], 2);
                unset($yearlyData[$y]['total']);
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_keys($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFeedbackDetails: " . $e->getMessage());
            return null;
        }
    }

    private function GetFeedbacInternDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $feedbacks = DB::table('za_intern_feedback_answer')
                ->select('feedback_json')
                ->where('branch_id', $branch_id)
                // ->where('status', 1)
                ->get();

            if ($feedbacks->isEmpty()) {
                return [
                    'yearly'  => [],
                    'monthly' => [],
                    'daily'   => [],
                    'years'   => []
                ];
            }

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            foreach ($feedbacks as $row) {

                $json = json_decode($row->feedback_json, true);
                if (!$json || empty($json['submitted_at'])) {
                    continue;
                }

                $date = date('Y-m-d', strtotime($json['submitted_at']));
                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));

                // ---- Calculate average score per feedback ----
                $scores = array_column($json['answers'] ?? [], 'answer_score');
                $avgScore = count($scores) ? array_sum($scores) / count($scores) : 0;

                // ---- Daily ----
                $dailyData[$y][$m][$d]['count'] =
                    ($dailyData[$y][$m][$d]['count'] ?? 0) + 1;

                $dailyData[$y][$m][$d]['total'] =
                    ($dailyData[$y][$m][$d]['total'] ?? 0) + $avgScore;

                // ---- Monthly ----
                $monthlyData[$y][$m]['count'] =
                    ($monthlyData[$y][$m]['count'] ?? 0) + 1;

                $monthlyData[$y][$m]['total'] =
                    ($monthlyData[$y][$m]['total'] ?? 0) + $avgScore;

                // ---- Yearly ----
                $yearlyData[$y]['count'] =
                    ($yearlyData[$y]['count'] ?? 0) + 1;

                $yearlyData[$y]['total'] =
                    ($yearlyData[$y]['total'] ?? 0) + $avgScore;

                $years[$y] = true;
            }

            // ---- Finalize averages ----
            foreach ($dailyData as $y => $months) {
                foreach ($months as $m => $days) {
                    foreach ($days as $d => $val) {
                        $dailyData[$y][$m][$d]['average'] =
                            round($val['total'] / $val['count'], 2);
                        unset($dailyData[$y][$m][$d]['total']);
                    }
                }
            }

            foreach ($monthlyData as $y => $months) {
                foreach ($months as $m => $val) {
                    $monthlyData[$y][$m]['average'] =
                        round($val['total'] / $val['count'], 2);
                    unset($monthlyData[$y][$m]['total']);
                }
            }

            foreach ($yearlyData as $y => $val) {
                $yearlyData[$y]['average'] =
                    round($val['total'] / $val['count'], 2);
                unset($yearlyData[$y]['total']);
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_keys($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFeedbackDetails: " . $e->getMessage());
            return null;
        }
    }

    private function getFeedbackAvgDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            /* ============================================================
            1. FETCH DATA
            ============================================================ */

            $event_list = DB::table('za_event_feedback_answer')
                ->select('feedback_json')
                ->where('branch_id', $branch_id)
                ->get();

            $intern_list = DB::table('za_intern_feedback_answer')
                ->select('feedback_json')
                ->where('branch_id', $branch_id)
                ->get();


            /* ============================================================
            2. PROCESS BOTH TABLES
            ============================================================ */

            foreach ([
                ['rows' => $event_list,  'count' => 'event_count',  'total' => 'event_total'],
                ['rows' => $intern_list, 'count' => 'intern_count', 'total' => 'intern_total'],
            ] as $set) {

                foreach ($set['rows'] as $row) {

                    $json = !empty($row->feedback_json)
                        ? json_decode($row->feedback_json, true)
                        : null;

                    if (!$json || empty($json['submitted_at'])) continue;

                    $date = date('Y-m-d', strtotime($json['submitted_at']));

                    $y = (int) date('Y', strtotime($date));
                    $m = (int) date('n', strtotime($date));
                    $d = (int) date('j', strtotime($date));

                    $scores   = array_column($json['answers'] ?? [], 'answer_score');
                    $avgScore = count($scores) ? array_sum($scores) / count($scores) : 0;

                    $years[$y] = $y;

                    // YEARLY
                    $yearlyData[$y][$set['count']] =
                        ($yearlyData[$y][$set['count']] ?? 0) + 1;

                    $yearlyData[$y][$set['total']] =
                        ($yearlyData[$y][$set['total']] ?? 0) + $avgScore;

                    // MONTHLY
                    $monthlyData[$y][$m][$set['count']] =
                        ($monthlyData[$y][$m][$set['count']] ?? 0) + 1;

                    $monthlyData[$y][$m][$set['total']] =
                        ($monthlyData[$y][$m][$set['total']] ?? 0) + $avgScore;

                    // DAILY
                    $dailyData[$y][$m][$d][$set['count']] =
                        ($dailyData[$y][$m][$d][$set['count']] ?? 0) + 1;

                    $dailyData[$y][$m][$d][$set['total']] =
                        ($dailyData[$y][$m][$d][$set['total']] ?? 0) + $avgScore;
                }
            }


            /* ============================================================
            3. CALCULATE AVERAGES
            ============================================================ */

            // YEARLY
            ksort($yearlyData);

            foreach ($yearlyData as $y => &$yData) {

                if (isset($yData['event_count'])) {
                    $yData['event_average'] =
                        round($yData['event_total'] / $yData['event_count'], 2);
                }

                if (isset($yData['intern_count'])) {
                    $yData['intern_average'] =
                        round($yData['intern_total'] / $yData['intern_count'], 2);
                }
            }

            // MONTHLY
            foreach ($monthlyData as $y => &$months) {

                ksort($months);

                foreach ($months as $m => &$mData) {

                    if (isset($mData['event_count'])) {
                        $mData['event_average'] =
                            round($mData['event_total'] / $mData['event_count'], 2);
                    }

                    if (isset($mData['intern_count'])) {
                        $mData['intern_average'] =
                            round($mData['intern_total'] / $mData['intern_count'], 2);
                    }
                }
            }

            // DAILY
            foreach ($dailyData as $y => &$months) {

                foreach ($months as $m => &$days) {

                    ksort($days);

                    foreach ($days as $d => &$dData) {

                        if (isset($dData['event_count'])) {
                            $dData['event_average'] =
                                round($dData['event_total'] / $dData['event_count'], 2);
                        }

                        if (isset($dData['intern_count'])) {
                            $dData['intern_average'] =
                                round($dData['intern_total'] / $dData['intern_count'], 2);
                        }
                    }
                }
            }


            /* ============================================================
            4. FINAL RETURN
            ============================================================ */

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in getFeedbackAvgDetails: " . $e->getMessage());
            return null;
        }
    }

    // private function GetAllBatchCountAndAverage(int $branch_id)
    // {
    //     try {

    //         if (!$branch_id) {
    //             throw new \InvalidArgumentException("Branch ID is required");
    //         }

    //         // get all batches first
    //         $batches = DB::table('za_batch')
    //             ->where('branch_id', $branch_id)
    //             ->where('status', 3)
    //             ->select('sno','batch_name')
    //             ->get();

    //         if ($batches->isEmpty()) {
    //             return [];
    //         }

    //         // get all feedbacks
    //         $feedbacks = DB::table('za_intern_feedback_answer')
    //             ->select('batch_id','feedback_json')
    //             ->where('branch_id', $branch_id)
    //             ->whereNotNull('feedback_json') // submitted only
    //             ->get();

    //         $batchStats = [];

    //         // initialize all batches with 0
    //         foreach ($batches as $b) {
    //             $batchStats[$b->sno] = [
    //                 'batch_id'   => $b->sno,
    //                 'batch_name' => $b->batch_name,
    //                 'count'      => 0,
    //                 'total'      => 0,
    //                 'average'    => 0
    //             ];
    //         }

    //         foreach ($feedbacks as $row) {

    //             $batch = $row->batch_id;
    //             if (!isset($batchStats[$batch])) {
    //                 continue;
    //             }

    //             $json = json_decode($row->feedback_json, true);
    //             if (!$json) continue;

    //             $scores = array_column($json['answers'] ?? [], 'answer_score');
    //             $avgScore = count($scores) ? array_sum($scores)/count($scores) : 0;

    //             $batchStats[$batch]['count']++;
    //             $batchStats[$batch]['total'] += $avgScore;
    //         }

    //         // finalize avg
    //         foreach ($batchStats as $id => $row) {

    //             if ($row['count'] > 0) {
    //                 $batchStats[$id]['average'] =
    //                     round($row['total'] / $row['count'], 2);
    //             }

    //             unset($batchStats[$id]['total']);
    //         }

    //         return array_values($batchStats);

    //     } catch (\Exception $e) {
    //         \Log::error("Batch avg error: ".$e->getMessage());
    //         return null;
    //     }
    // }



    private function getYearBasedMonths($year, $type = 1)
    {

        $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December'
        ];

        if ($type == 2) {
            $months = [
                1 => 'Jan',
                2 => 'Feb',
                3 => 'Mar',
                4 => 'Apr',
                5 => 'May',
                6 => 'Jun',
                7 => 'Jul',
                8 => 'Aug',
                9 => 'Sep',
                10 => 'Oct',
                11 => 'Nov',
                12 => 'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function ($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl(' . $hue . ', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if ($count > 0) {
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl(' . $hue . ', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text)
    {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getDepartmentName($id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['department_name'])) {
            self::$temp['department_name'] = [];
        }
        // Check if the id is already cached
        if (!isset(self::$temp['department_name'][$id])) {
            $state = DB::table('za_department')->select('department_name')->where('sno', $id)->first();
            self::$temp['department_name'][$id] = $state ? $state->department_name : null;
        }
        return self::$temp['department_name'][$id];
    }

    public function get_all_department_wise_staff(Request $request)
    {
        try {
            $user = $request->user();
            $branch_id = $user->branch_id;
            $is_existing_val = $request->filled('checked_val') ? (int) $request->checked_val : 2;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            // ✅ Sorted department list
            $departments = DB::table('za_department')
                ->where('status', '!=', 2)
                ->orderBy('department_name', 'asc')
                ->get();

            if ($departments->isEmpty()) {
                return response([
                    'status' => 200,
                    'message' => 'list retrieved successfully.',
                    'error_msg' => null,
                    'data' => [
                        [
                            'option_group_name' => 'Unknown Group Name',
                            'option_group_id' => null,
                            'options' => []
                        ]
                    ]
                ], 200);
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            $staff_query = DB::table('za_staff')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->where('za_staff.branch_id', $branch_id)
                ->whereIn('za_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 5)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 6)
                                ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 7)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('za_staff.status', 0);
                });
            } else {
                $staff_query->where('za_staff.status', '!=', 2);
            }

            $staff_list = $staff_query
                ->orderBy('za_staff.staff_name', 'asc')
                ->get([
                    'za_staff.sno',
                    'za_staff.staff_name',
                    'za_staff.department_id',
                    'za_staff.date_of_joining',
                    'za_user_role.role_name'
                ]);

            // ✅ Group staff by department
            $data = [];
            foreach ($departments as $dept) {

                $dept_staff = $staff_list->where('department_id', $dept->sno)->map(function ($s) {
                    return [
                        'value' => $s->sno,
                        'label' => $s->staff_name . ' (' . $s->role_name . ')',
                        'date_of_joining' => $s->date_of_joining
                    ];
                })->values();

                if (!$dept_staff->isEmpty()) {
                    $data[] = [
                        'option_group_name' => $dept->department_name,
                        'option_group_id' => $dept->sno,
                        'options' => $dept_staff
                    ];
                }
            }

            return response([
                'status' => 200,
                'message' => 'list retrieved successfully.',
                'error_msg' => null,
                'data' => $data
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Failed to fetch list.',
                'error_msg' => $e->getMessage(),
                'data' => []
            ], 500);
        }
    }

    private function getDaysWithoutSundays($month, $year)
    {

        $totalDays = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Total days in the month
        $daysWithoutSundays = 0;

        for ($day = 1; $day <= $totalDays; $day++) {
            $date = "$year-$month-$day";
            if (date('w', strtotime($date)) != 0) { // Check if the day is not Sunday (0 represents Sunday)
                $daysWithoutSundays++;
            }
        }

        return $daysWithoutSundays;
    }

    private function generateNavHtml()
    {
        $menus =  [
            [
                'title' => 'Event Feedback',
                'url' => url('/manage_reports/feedback_event_yearly'),
                'is_active' => request()->is([
                    'manage_reports/feedback_event_yearly*',
                    'manage_reports/feedback_event_monthly*',
                ]),
            ],
            [
                'title' => 'Intern Feedback',
                'url' => url('/manage_reports/feedback_intern_yearly'),
                'is_active' => request()->is([
                    'manage_reports/feedback_intern_yearly*',
                    'manage_reports/feedback_intern_monthly*',
                ]),
            ],
            [
                'title' => 'Avarage Vs Feedback',
                'url' => url('/manage_reports/feedback_avg_yearly'),
                'is_active' => request()->is([
                    'manage_reports/feedback_avg_yearly*'
                ]),
            ],
        ];

        $html = '<div class="nav-align-top mb-2">';
        $html .= '<ul class="nav nav-pills" role="tablist">';

        foreach ($menus as $menu) {

            $active = $menu['is_active'] ? 'active' : '';

            $html .= "
                <li class='nav-item'>
                    <a href='{$menu['url']}' class='nav-link text-capitalize {$active}'>
                        {$menu['title']}
                    </a>
                </li>
            ";
        }

        $html .= '</ul></div>';

        return $html;
    }

}
