<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\SlotModel;
use App\Models\BranchModel;
use App\Models\ManageInternModel;
use App\Models\TransactionModel;
use App\Models\ManageTargetModel;
use DateTime;

class AccountsReport extends Controller
{

    public static $report_heading = 'Analysis';
    public static $branch_wise = 1;
    public static $franchise_wise = 2;
    protected static $temp = [];

    public function index()
    {
        $currentYear  = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.accounts_report.branch_income_yr_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function BranchIncomeYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $days = range(1,31);
            $year = date('Y', strtotime($filterDate));
            $prevYear  = (int)$year - 1;
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getAccountsData(self::$branch_wise);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = BranchModel::where('status', 0)
                ->where('branch_type', self::$branch_wise)
                ->whereNotIn('sno', [1,11,18]); //1 -> Developer Branch
                // ->select('sno', 'branch_name');

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'branch_name')->orderBy('branch_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->branch_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result[$lead_type_id]['collection_sale']['monthly']) && !empty($result[$lead_type_id]['collection_sale']['monthly']) ? $result[$lead_type_id]['collection_sale']['monthly'] : [];

                    $count = isset($paymentSums[$year][$monthNum]) ? (int) $paymentSums[$year][$monthNum] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    
                    $leadData[$monthNum][$lead_type_id] = $count;

                    $dayTotals[$monthNum] = ($dayTotals[$monthNum] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = (int)$monthNum - 1;

                    $day_query = false;

                    if ((int)$monthNum === 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $day_query = true;
                    }else if((int)$monthNum !== 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]) ? (int)$paymentSums[$prevYear][$prevMonth] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise months trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function branch_income_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.accounts_report.branch_income_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function BranchIncomeMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getAccountsData(self::$branch_wise);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = BranchModel::where('status', 0)
                ->where('branch_type', self::$branch_wise)
                ->whereNotIn('sno', [1,11,18]); //1 -> Developer Branch
                // ->select('sno', 'branch_name');

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'branch_name')->orderBy('branch_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->branch_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result[$lead_type_id]['collection_sale']['daily']) && !empty($result[$lead_type_id]['collection_sale']['daily']) ? $result[$lead_type_id]['collection_sale']['daily'] : [];

                    $count = isset($paymentSums[$year][$Month][$day]) ? (int) $paymentSums[$year][$Month][$day] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function franchise_income_yearly()
    {
        $currentYear  = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.accounts_report.franchise_income_yr_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function FranchiseIncomeYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $days = range(1,31);
            $year = date('Y', strtotime($filterDate));
            $prevYear  = (int)$year - 1;
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getAccountsData(self::$franchise_wise);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = BranchModel::where('status', 0)->where('branch_type', self::$franchise_wise);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'franchise_name')->orderBy('franchise_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->franchise_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result[$lead_type_id]['collection_sale']['monthly']) && !empty($result[$lead_type_id]['collection_sale']['monthly']) ? $result[$lead_type_id]['collection_sale']['monthly'] : [];

                    $count = isset($paymentSums[$year][$monthNum]) ? (int) $paymentSums[$year][$monthNum] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    
                    $leadData[$monthNum][$lead_type_id] = $count;

                    $dayTotals[$monthNum] = ($dayTotals[$monthNum] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = (int)$monthNum - 1;

                    $day_query = false;

                    if ((int)$monthNum === 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $day_query = true;
                    }else if((int)$monthNum !== 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]) ? (int)$paymentSums[$prevYear][$prevMonth] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise months trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function franchise_income_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.accounts_report.franchise_income_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function FranchiseIncomeMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getAccountsData(self::$franchise_wise);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = BranchModel::where('status', 0)->where('branch_type', self::$franchise_wise);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'franchise_name')->orderBy('franchise_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->franchise_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result[$lead_type_id]['collection_sale']['daily']) && !empty($result[$lead_type_id]['collection_sale']['daily']) ? $result[$lead_type_id]['collection_sale']['daily'] : [];

                    $count = isset($paymentSums[$year][$Month][$day]) ? (int) $paymentSums[$year][$Month][$day] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function incomevsexp_yr_list()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.accounts_report.Incomevsexp_yr_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function IncomevsExpYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $types_list = [
                'collection_sale' => 'Income', 
                'exp_sale' => 'Expenditure'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            $result = $this->getCollectionExpData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // Step 1: Extract years from result safely
            $presale_years = isset($result['pre_sale']['years']) && !empty($result['pre_sale']['years']) ? collect($result['pre_sale']['years']) : collect();
            
            $postsale_years = isset($result['post_sale']['years']) && !empty($result['post_sale']['years']) ? collect($result['post_sale']['years']) : collect();
                        
            // Step 2: Merge, deduplicate, sort
            $allYears = $presale_years->merge($postsale_years)->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            // return $finalYears;
            $days = range(1, 31);

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    foreach ($months as $monthNum => $monthName) {

                        $Trend_data_list = [];

                        foreach ($types_list as $type_key => $type_name) {
                            
                            $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];
                            
                            if((int)$monthNum > $currentMonth){
                                $amount = 0;
                            }else{
                                $amount = isset($paymentSums['monthly'][$year][$monthNum]) ? round($paymentSums['monthly'][$year][$monthNum]) : 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                                $grandTotalAll += $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }

                }
            }
            
            // 🔹 Percentages
            foreach ($finalYears as $year_index => $year) {
                if((int)$year <= $currentYear){
                    foreach ($months as $monthNum => $monthName) {

                        if($year_index != 0){

                            $monthTotal = (int)$data[$year][$monthNum]['collection_sale'] ?? 0;
                            $amount     = ((int)$data[$year][$monthNum]['collection_sale'] ?? 0) - ((int)$data[$year][$monthNum]['exp_sale'] ?? 0);

                            $percentages[$year][$monthNum]['collection_sale'] = $monthTotal > 0
                                ? round(($amount / $monthTotal) * 100, 2)
                                : 0;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function incomevsexp_month_list()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.accounts_report.Incomevsexp_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function IncomevsExpMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getCollectionExpData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $types_list = [
                'collection_sale' => 'Income', 
                'exp_sale' => 'Expenditure'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    foreach ($types_list as $type_key => $type_name) {
                        
                        $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                        $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day]) : 0;
                        
                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                        $grandTotalAll += $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    // foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = (int)$data[$monthNum][$day]['collection_sale'] ?? 0;
                        $amount     = ((int)$data[$monthNum][$day]['collection_sale'] ?? 0) - ((int)$data[$monthNum][$day]['exp_sale'] ?? 0);

                        $percentages[$monthNum][$day]['collection_sale'] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    // }
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function get_type_wise_branch_list(Request $request)
    {
        $branch_type = (int)$request->input('branch_type',self::$branch_wise);

        $LeadTypeModelList = null;
        if($branch_type === self::$franchise_wise){
            $LeadTypeModelList = BranchModel::where('status', 0)
                                ->where('branch_type', self::$franchise_wise)
                                // ->select('sno', 'franchise_name') // optional for clarity
                                ->orderBy('franchise_name', 'asc')
                                ->get();
        }else{
            $LeadTypeModelList = BranchModel::where('status', 0)
                                ->where('branch_type', self::$branch_wise)
                                ->whereNotIn('sno', [1,11,18])
                                // ->select('sno', 'branch_name') // optional for clarity
                                ->orderBy('branch_name', 'asc')
                                ->get();
        }
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    private function getAccountsData(int $branch_type = 1)
    {
        try {

            // 🔹 Step 1: Fetch all active branches of type 1

            $branches =[];

            if($branch_type === self::$franchise_wise){
                $branches = BranchModel::where('status', 0)
                    ->where('branch_type', self::$franchise_wise)
                    ->select('sno', 'franchise_name') // optional for clarity
                    ->get();
            }else{
                $branches = BranchModel::where('status', 0)
                    ->where('branch_type', self::$branch_wise)
                    ->whereNotIn('sno', [1,11,18]) //1 -> Developer Branch
                    ->select('sno', 'branch_name') // optional for clarity
                    ->get();
            }

            if ($branches->isEmpty()) {
                throw new \Exception("No active branches found.");
            }

            // 🔹 Step 2: Prepare results container
            $finalResults = [];

            // 🔹 Step 3: Loop each branch
            foreach ($branches as $branch) {

                $branch_id = $branch->sno;

                // Fetch all customers in this branch
                $currentMonthCustomerPre = CustomerModel::select(
                    'za_customer.course_id',
                    'za_customer.sno',
                    'za_customer.branch_id',
                    DB::raw("
                        GROUP_CONCAT(
                            CASE 
                                WHEN za_training.post_sale_check = 1 AND za_customer.post_sale_check = 1 
                                THEN za_customer.customer_id 
                            END 
                            ORDER BY za_customer.customer_id SEPARATOR ','
                        ) AS post_training_ids
                    "),
                    DB::raw("
                        GROUP_CONCAT(
                            CASE 
                                WHEN za_training.post_sale_check != 1 AND za_customer.post_sale_check != 1 
                                THEN za_customer.customer_id 
                            END 
                            ORDER BY za_customer.customer_id SEPARATOR ','
                        ) AS pre_training_ids
                    ")
                )
                ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branch_id)
                ->whereIn('za_customer.status', [0, 6])
                ->groupBy('za_customer.course_id', 'za_customer.sno', 'za_customer.branch_id')
                ->get();

                // Separate pre/post IDs
                $allPreIds = [];
                $allPostIds = [];

                foreach ($currentMonthCustomerPre as $customer) {
                    if (!empty($customer->pre_training_ids)) {
                        $allPreIds = array_merge($allPreIds, explode(',', $customer->pre_training_ids));
                    }
                    if (!empty($customer->post_training_ids)) {
                        $allPostIds = array_merge($allPostIds, explode(',', $customer->post_training_ids));
                    }
                }

                $allPreIds = array_unique($allPreIds);
                $allPostIds = array_unique($allPostIds);

                // Helper: get transaction sums by date
                $getTransactionSums = function(array $transSourceIds, int $branch_id) {
                    if (empty($transSourceIds)) {
                        return collect();
                    }

                    return TransactionModel::select(
                        DB::raw('YEAR(transaction_date) as train_year'),
                        DB::raw('MONTH(transaction_date) as train_month'),
                        DB::raw('DAY(transaction_date) as train_day'),
                        DB::raw('SUM(credit) as total_credit')
                    )
                    ->where('branch_id', $branch_id)
                    ->whereIn('trans_source_id', $transSourceIds)
                    ->groupBy('train_year', 'train_month', 'train_day')
                    ->get();
                };

                // Fetch transactions for pre/post/total
                $preTransactions = $getTransactionSums($allPreIds, $branch_id);
                $postTransactions = $getTransactionSums($allPostIds, $branch_id);

                $totalTransactions = TransactionModel::select(
                    DB::raw('YEAR(transaction_date) as train_year'),
                    DB::raw('MONTH(transaction_date) as train_month'),
                    DB::raw('DAY(transaction_date) as train_day'),
                    DB::raw('SUM(credit) as total_credit')
                )
                ->where('branch_id', $branch_id)
                ->where('customer_type', '!=', 2)
                ->groupBy('train_year', 'train_month', 'train_day')
                ->get();

                // Branch Targets
                $totalTargets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->select(
                        DB::raw('YEAR(branch_target.date) as train_year'),
                        DB::raw('MONTH(branch_target.date) as train_month'),
                        DB::raw('DAY(branch_target.date) as train_day'),
                        'branch_target.monthly_target as total_credit'
                    )
                    ->get();

                // Distribute monthly target across days
                $dailyTargets = collect();
                foreach ($totalTargets as $target) {
                    $year = $target->train_year;
                    $month = $target->train_month;
                    $monthlyTarget = $target->total_credit;
                    $daysInMonth = Carbon::create($year, $month, 1)->daysInMonth;
                    $dailyValue = $monthlyTarget / $daysInMonth;

                    for ($day = 1; $day <= $daysInMonth; $day++) {
                        $dailyTargets->push((object)[
                            'train_year' => $year,
                            'train_month' => $month,
                            'train_day' => $day,
                            'total_credit' => round($dailyValue, 2),
                        ]);
                    }
                }

                // Accumulate helper
                $accumulate = function($collection) {
                    $result = ['yearly'=>[], 'monthly'=>[], 'daily'=>[], 'years'=>[]];
                    foreach ($collection as $item) {
                        $y = $item->train_year;
                        $m = $item->train_month;
                        $d = $item->train_day;
                        $c = $item->total_credit;
                        $result['daily'][$y][$m][$d] = ($result['daily'][$y][$m][$d] ?? 0) + $c;
                        $result['monthly'][$y][$m] = ($result['monthly'][$y][$m] ?? 0) + $c;
                        $result['yearly'][$y] = ($result['yearly'][$y] ?? 0) + $c;
                        $result['years'][$y] = $y;
                    }
                    return $result;
                };

                // Compute structured results
                $pre_result = $accumulate($preTransactions);
                $post_result = $accumulate($postTransactions);
                $post_total = $accumulate($totalTransactions);
                $target_sale = $accumulate($totalTargets);
                $target_sale['daily'] = $accumulate($dailyTargets)['daily'];

                // Subtract Helper
                $subtractResults = function($totalArr, $preArr, $postArr) {
                    $result = [];
                    foreach ($totalArr as $year => $months) {
                        if (is_array($months)) {
                            foreach ($months as $month => $daysOrVal) {
                                if (is_array($daysOrVal)) {
                                    foreach ($daysOrVal as $day => $value) {
                                        $preVal = $preArr[$year][$month][$day] ?? 0;
                                        $postVal = $postArr[$year][$month][$day] ?? 0;
                                        $result[$year][$month][$day] = max(0, $value - ($preVal + $postVal));
                                    }
                                } else {
                                    $preVal = $preArr[$year][$month] ?? 0;
                                    $postVal = $postArr[$year][$month] ?? 0;
                                    $result[$year][$month] = max(0, $daysOrVal - ($preVal + $postVal));
                                }
                            }
                        } else {
                            $preVal = $preArr[$year] ?? 0;
                            $postVal = $postArr[$year] ?? 0;
                            $result[$year] = max(0, $months - ($preVal + $postVal));
                        }
                    }
                    return $result;
                };

                $post_closed_result = [
                    'daily' => $subtractResults($post_total['daily'], $pre_result['daily'], $post_result['daily']),
                    'monthly' => $subtractResults($post_total['monthly'], $pre_result['monthly'], $post_result['monthly']),
                    'yearly' => $subtractResults($post_total['yearly'], $pre_result['yearly'], $post_result['yearly']),
                ];

                // Sum helper (pre + post + closed)
                $sumResults = function($arr1, $arr2, $arr3) {
                    $result = [];
                    $allYears = array_unique(array_merge(array_keys($arr1 ?? []), array_keys($arr2 ?? []), array_keys($arr3 ?? [])));
                    foreach ($allYears as $year) {
                        $val1 = $arr1[$year] ?? [];
                        $val2 = $arr2[$year] ?? [];
                        $val3 = $arr3[$year] ?? [];
                        if (is_array($val1) || is_array($val2) || is_array($val3)) {
                            $allMonths = array_unique(array_merge(
                                is_array($val1) ? array_keys($val1) : [],
                                is_array($val2) ? array_keys($val2) : [],
                                is_array($val3) ? array_keys($val3) : []
                            ));
                            foreach ($allMonths as $month) {
                                $m1 = $val1[$month] ?? 0;
                                $m2 = $val2[$month] ?? 0;
                                $m3 = $val3[$month] ?? 0;
                                if (is_array($m1) || is_array($m2) || is_array($m3)) {
                                    $allDays = array_unique(array_merge(
                                        is_array($m1) ? array_keys($m1) : [],
                                        is_array($m2) ? array_keys($m2) : [],
                                        is_array($m3) ? array_keys($m3) : []
                                    ));
                                    foreach ($allDays as $day) {
                                        $d1 = is_array($m1) ? ($m1[$day] ?? 0) : 0;
                                        $d2 = is_array($m2) ? ($m2[$day] ?? 0) : 0;
                                        $d3 = is_array($m3) ? ($m3[$day] ?? 0) : 0;
                                        $result[$year][$month][$day] = $d1 + $d2 + $d3;
                                    }
                                } else {
                                    $result[$year][$month] = $m1 + $m2 + $m3;
                                }
                            }
                        } else {
                            $result[$year] = $val1 + $val2 + $val3;
                        }
                    }
                    return $result;
                };

                $collection_sale = [
                    'yearly' => $sumResults($pre_result['yearly'], $post_result['yearly'], $post_closed_result['yearly']),
                    'monthly' => $sumResults($pre_result['monthly'], $post_result['monthly'], $post_closed_result['monthly']),
                    'daily' => $sumResults($pre_result['daily'], $post_result['daily'], $post_closed_result['daily']),
                ];

                // Save this branch's complete data
                $finalResults[$branch_id] = [
                    // 'pre_sale' => $pre_result,
                    // 'post_sale' => $post_result,
                    // 'total_sale' => $post_total,
                    // 'closed_sale' => $post_closed_result,
                    'collection_sale' => $collection_sale,
                    // 'target_sale' => $target_sale,
                ];
            }

            // 🔹 Step 4: Return all branches data
            return $finalResults;

        } catch (\Exception $e) {
            \Log::error("Error in getAccountsData: " . $e->getMessage());
            return null;
        }
    }

    private function getCollectionExpData(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            // Get all customer data with pre/post training IDs concatenated
            $currentMonthCustomerPre = CustomerModel::select(
                'za_customer.course_id', 
                'za_customer.sno',
                DB::raw("
                    GROUP_CONCAT(
                        CASE 
                            WHEN za_training.post_sale_check = 1 AND za_customer.post_sale_check = 1 
                            THEN za_customer.customer_id 
                        END 
                        ORDER BY za_customer.customer_id SEPARATOR ','
                    ) AS post_training_ids
                "),
                DB::raw("
                    GROUP_CONCAT(
                        CASE 
                            WHEN za_training.post_sale_check != 1 AND za_customer.post_sale_check != 1 
                            THEN za_customer.customer_id 
                        END 
                        ORDER BY za_customer.customer_id SEPARATOR ','
                    ) AS pre_training_ids
                ")
            )
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->whereIn('za_customer.status', [0, 6])
            ->groupBy('za_customer.course_id', 'za_customer.sno')
            ->get();

            // Flatten all pre_training_ids and post_training_ids into single arrays to minimize queries
            $allPreIds = [];
            $allPostIds = [];

            foreach ($currentMonthCustomerPre as $customer) {
                if (!empty($customer->pre_training_ids)) {
                    $allPreIds = array_merge($allPreIds, explode(',', $customer->pre_training_ids));
                }
                if (!empty($customer->post_training_ids)) {
                    $allPostIds = array_merge($allPostIds, explode(',', $customer->post_training_ids));
                }
            }

            // Remove duplicates just in case
            $allPreIds = array_unique($allPreIds);
            $allPostIds = array_unique($allPostIds);

            // Function to get sum grouped by year, month, day for given IDs
            $getTransactionSums = function(array $transSourceIds) use ($branch_id) {
                if (empty($transSourceIds)) {
                    return collect();
                }

                return TransactionModel::select(
                    DB::raw('YEAR(transaction_date) as train_year'),
                    DB::raw('MONTH(transaction_date) as train_month'),
                    DB::raw('DAY(transaction_date) as train_day'),
                    DB::raw('SUM(credit) as total_credit')
                )
                ->where('branch_id', $branch_id)
                ->whereIn('trans_source_id', $transSourceIds)
                ->groupBy('train_year', 'train_month', 'train_day')
                ->get();
            };

            // Get all transaction sums
            $preTransactions = $getTransactionSums($allPreIds);
            $postTransactions = $getTransactionSums($allPostIds);

            // Get total transactions (all)
            $totalTransactions = TransactionModel::select(
                DB::raw('YEAR(transaction_date) as train_year'),
                DB::raw('MONTH(transaction_date) as train_month'),
                DB::raw('DAY(transaction_date) as train_day'),
                DB::raw('SUM(credit) as total_credit')
            )
            ->where('branch_id', $branch_id)
            ->where('customer_type', '!=', 2)
            ->groupBy('train_year', 'train_month', 'train_day')
            ->get();

            $totalTargets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                        ->select(
                            DB::raw('YEAR(branch_target.date) as train_year'),
                            DB::raw('MONTH(branch_target.date) as train_month'),
                            DB::raw('DAY(branch_target.date) as train_day'),
                            'branch_target.monthly_target as total_credit'
                            )
                        ->get();

            
            // Distribute monthly target evenly across all days of the month for daily targets
            $dailyTargets = collect();

            foreach ($totalTargets as $target) {

                $year = $target->train_year;
                $month = $target->train_month;
                $monthlyTarget = $target->total_credit;

                // Calculate days in the month
                $daysInMonth = Carbon::create($year, $month, 1)->daysInMonth;

                // Daily target value
                $dailyValue = $monthlyTarget / $daysInMonth;

                // Add daily entries for each day of the month
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $dailyTargets->push((object)[
                        'train_year' => $year,
                        'train_month' => $month,
                        'train_day' => $day,
                        'total_credit' => round($dailyValue,2),
                    ]);
                }
            }

            // Helper to accumulate results into the structure
            $accumulate = function($collection) {
                $result = [
                    'yearly' => [],
                    'monthly' => [],
                    'daily' => [],
                    'years' => [],
                ];

                foreach ($collection as $item) {
                    $y = $item->train_year;
                    $m = $item->train_month;
                    $d = $item->train_day;
                    $c = $item->total_credit;

                    $result['daily'][$y][$m][$d] = ($result['daily'][$y][$m][$d] ?? 0) + $c;
                    $result['monthly'][$y][$m] = ($result['monthly'][$y][$m] ?? 0) + $c;
                    $result['yearly'][$y] = ($result['yearly'][$y] ?? 0) + $c;
                    $result['years'][$y] = $y;
                }

                return $result;
            };

            $pre_result = $accumulate($preTransactions);
            $post_result = $accumulate($postTransactions);
            $post_total = $accumulate($totalTransactions);
            $target_sale = $accumulate($totalTargets); // yearly & monthly only from original monthly targets

            // Replace daily with distributed daily targets:
            $target_sale['daily'] = $accumulate($dailyTargets)['daily'];

            // Calculate post_closed_result = post_total - (pre_result + post_result)
            $post_closed_result = [
                'yearly' => [],
                'monthly' => [],
                'daily' => [],
            ];

            // Helper function to subtract arrays recursively
            $subtractResults = function($totalArr, $preArr, $postArr) {
                $result = [];

                foreach ($totalArr as $year => $months) {
                    if (is_array($months)) {
                        foreach ($months as $month => $daysOrVal) {
                            if (is_array($daysOrVal)) {
                                foreach ($daysOrVal as $day => $value) {
                                    $preVal = $preArr[$year][$month][$day] ?? 0;
                                    $postVal = $postArr[$year][$month][$day] ?? 0;
                                    $result[$year][$month][$day] = max(0, $value - ($preVal + $postVal));
                                }
                            } else {
                                // Monthly or yearly value
                                $preVal = $preArr[$year][$month] ?? 0;
                                $postVal = $postArr[$year][$month] ?? 0;
                                $result[$year][$month] = max(0, $daysOrVal - ($preVal + $postVal));
                            }
                        }
                    } else {
                        // Yearly level
                        $preVal = $preArr[$year] ?? 0;
                        $postVal = $postArr[$year] ?? 0;
                        $result[$year] = max(0, $months - ($preVal + $postVal));
                    }
                }

                return $result;
            };

            // Calculate post_closed_result for daily, monthly, yearly
            $post_closed_result['daily'] = $subtractResults($post_total['daily'], $pre_result['daily'], $post_result['daily']);
            $post_closed_result['monthly'] = $subtractResults($post_total['monthly'], $pre_result['monthly'], $post_result['monthly']);
            $post_closed_result['yearly'] = $subtractResults($post_total['yearly'], $pre_result['yearly'], $post_result['yearly']);

            $sumResults = function($arr1, $arr2, $arr3) {

                $result = [];

                // Get all unique keys from all arrays
                $allYears = array_unique(array_merge(array_keys($arr1 ?? []), array_keys($arr2 ?? []), array_keys($arr3 ?? [])));

                foreach ($allYears as $year) {
                    $val1 = $arr1[$year] ?? [];
                    $val2 = $arr2[$year] ?? [];
                    $val3 = $arr3[$year] ?? [];

                    if (is_array($val1) || is_array($val2) || is_array($val3)) {
                        // Merge months or days level
                        $allMonths = array_unique(array_merge(
                            is_array($val1) ? array_keys($val1) : [],
                            is_array($val2) ? array_keys($val2) : [],
                            is_array($val3) ? array_keys($val3) : []
                        ));

                        foreach ($allMonths as $month) {
                            $m1 = is_array($val1) && isset($val1[$month]) ? $val1[$month] : 0;
                            $m2 = is_array($val2) && isset($val2[$month]) ? $val2[$month] : 0;
                            $m3 = is_array($val3) && isset($val3[$month]) ? $val3[$month] : 0;

                            if (is_array($m1) || is_array($m2) || is_array($m3)) {
                                // Day level
                                $allDays = array_unique(array_merge(
                                    is_array($m1) ? array_keys($m1) : [],
                                    is_array($m2) ? array_keys($m2) : [],
                                    is_array($m3) ? array_keys($m3) : []
                                ));

                                foreach ($allDays as $day) {
                                    $d1 = is_array($m1) && isset($m1[$day]) ? $m1[$day] : 0;
                                    $d2 = is_array($m2) && isset($m2[$day]) ? $m2[$day] : 0;
                                    $d3 = is_array($m3) && isset($m3[$day]) ? $m3[$day] : 0;

                                    $result[$year][$month][$day] = $d1 + $d2 + $d3;
                                }
                            } else {
                                // Month level
                                $result[$year][$month] = $m1 + $m2 + $m3;
                            }
                        }
                    } else {
                        // Year level only
                        $result[$year] = $val1 + $val2 + $val3;
                    }
                }

                return $result;
            };

            // Create collection_sale by summing pre_sale + post_sale + closed_sale
            $collection_sale = [
                'yearly' => $sumResults($pre_result['yearly'], $post_result['yearly'], $post_closed_result['yearly']),
                'monthly' => $sumResults($pre_result['monthly'], $post_result['monthly'], $post_closed_result['monthly']),
                'daily' => $sumResults($pre_result['daily'], $post_result['daily'], $post_closed_result['daily']),
            ];

            // Return results - can return more if needed
            return [
                'pre_sale' => $pre_result,
                'post_sale' => $post_result,
                'total_sale' => $post_total,
                'closed_sale' => $post_closed_result,
                'collection_sale' => $collection_sale,
                'target_sale' => $target_sale,
            ];

        } catch (\Exception $e) {
            \Log::error("Error in getOutstandingMonthlyData: " . $e->getMessage());
            return null; // or handle as you prefer
        }
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }
}
