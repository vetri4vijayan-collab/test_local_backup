<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\StaffAttendanceModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;

class PerformanceReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.performance_report.production_yr_list', compact(
            'months',
            'short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function ProductionYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) $request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetProductionPerDetails($branch_id, $search_lead_src_fill, $is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function ($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate = strtotime($staff['doj']);
                    $dojYear = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int) $year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate = strtotime($staff['exist_date']);
                    $exitYear = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int) $year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                $exist_status = isset($leadType['exist_status']) ? $leadType['exist_status'] : false;
                $exist_date = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : '';
                $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                // ---------- Exit Staff Tracking ----------
                if ($exist_status) {
                    $exist_y = (int) date('Y', strtotime($exist_date));
                    $exist_m = (int) date('n', strtotime($exist_date));

                    while ($exist_m <= (int) $currentMonth) {
                        $exit_staff_details[$exist_y][$exist_m][$lead_type_id] = [
                            'exist_status' => true,
                            'exist_date' => null
                        ];
                        $exist_m++;
                    }

                    $exit_status_staffs[$lead_type_id] = $exist_status;
                }

                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {

                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['earned_amount']) ? $paymentSums[$year][$monthNum]['earned_amount'] : 0;
                    $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$lead_type_id] = $count;
                    $percentages[$lead_type_id][$monthNum] = $earned_per;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int) $monthNum == 1) {
                        $prevYear = (int) $year - 1;
                        $prevMonth = 12;
                    } else if ((int) $monthNum != 1) {
                        $prevYear = (int) $year;
                        $prevMonth = (int) $monthNum - 1;
                    }

                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['earned_amount']) ? $paymentSums[$prevYear][$prevMonth]['earned_amount'] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int) $year) {
                            if ((int) $monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        } else if ($doj_y < (int) $year) {
                            $doj_status = true;
                        } else if ($doj_y > (int) $year) {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$year][$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $monthTotals[$day] = $dayTotal;
                }


                $grandTotalAll += $dayTotal;

                // Calculate percentages
            }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int) $currentMonth,
                'currentYear' => (int) $currentYear,
                'currentDay' => (int) $currentDay,
                'Month' => (int) $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int) $year,
                'yearShort' => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function leave_percent_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.performance_report.leave_percent_yr_list', compact(
            'months',
            'short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function LeavePerYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) ($request->is_existing_val ?? 2);

            // --- Validate and determine year ---
            $filterDate = ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year))
                ? $selected_year . '-01-01'
                : now()->format('Y-01-01');

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            // --- Fetch Faculty Attendance Data ---
            $result = $this->GetFacultyAttendanceDetails($branch_id, $search_lead_src_fill, $is_existing_val);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get faculty data'], 500);
            }

            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            $deptSummary = $result['dept_summary'] ?? [];

            // --- Initialize output containers ---
            $leadData = [];       // monthly count per staff
            $preleadData = [];    // previous month data
            $percentages = [];    // placeholder for percentages (attendance ratio)
            $sourceTotals = [];   // total per staff
            $deptTotals = [];   // total per staff
            $monthTotals = [];    // total per month
            $sourceTrends = [];   // line chart data
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            // --- Flatten Department + Staff Structure ---
            $staffDetails = [];
            foreach ($deptSummary as $dept_id => $deptInfo) {
                foreach ($deptInfo['staff_list'] as $staff) {

                    $exist_status = isset($staff['exist_status']) ? $staff['exist_status'] : false;
                    $exist_date = !empty($staff['exist_date']) ? date('Y-m-d', strtotime($staff['exist_date'])) : '';

                    // ---------- Exit Staff Tracking ----------
                    if ($exist_status) {
                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));

                        while ($exist_m <= (int) $today_month) {
                            $exit_staff_details[$exist_y][$exist_m][$staff['staff_id']] = [
                                'exist_status' => true,
                                'exist_date' => null
                            ];
                            $exist_m++;
                        }

                        $exit_status_staffs[$staff['staff_id']] = $exist_status;
                    }

                    $staffDetails[$staff['staff_id']] = [
                        'staff_name' => $staff['staff_name'],
                        'department_id' => $deptInfo['department_id'],
                        'doj' => $staff['doj']
                    ];
                }
            }

            // --- Sort staff alphabetically ---
            uasort($staffDetails, fn($a, $b) => strcmp($a['staff_name'], $b['staff_name']));
            $staffIds = array_keys($staffDetails);

            // --- Build Monthly Dataset ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];
                $doj = !empty($staff_info['doj']) ? date('Y-m-d', strtotime($staff_info['doj'])) : null;

                foreach ($months as $monthNum => $monthName) {

                    $monthVal = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['total_attendance'] ?? 0;

                    $leadData[$dept_id][$staff_id][$monthNum] = $monthVal;

                    $sourceTotals[$dept_id][$staff_id] = ($sourceTotals[$dept_id][$staff_id] ?? 0) + $monthVal;

                    $deptTotals[$dept_id] = ($deptTotals[$dept_id] ?? 0) + $monthVal;

                    $monthTotals[$dept_id][$monthNum] = ($monthTotals[$dept_id][$monthNum] ?? 0) + $monthVal;

                    // --- Previous month data ---
                    $prevMonth = ($monthNum == 1) ? 12 : $monthNum - 1;
                    $prevYear = ($monthNum == 1) ? $year - 1 : $year;
                    $preVal = $monthlyData[$dept_id][$staff_id][$prevYear][$prevMonth]['total_attendance'] ?? 0;
                    $preleadData[$dept_id][$staff_id][$prevMonth] = $preVal;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int) $year) {
                            if ((int) $monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        } else if ($doj_y < (int) $year) {
                            $doj_status = true;
                        } else if ($doj_y > (int) $year) {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$year][$monthNum][$staff_id] = [
                        'doj_status' => $doj_status,
                    ];
                }
            }

            // --- Source Trends for Graphs (month-wise) ---
            foreach ($staffIds as $staff_id) {

                $staff_info = $staffDetails[$staff_id];
                $dept_id = $staff_info['department_id'];

                $trend = [];
                foreach ($months as $monthNum => $monthName) {

                    $daysInMonth = $this->getDaysWithoutSundays($monthNum, $year);

                    $percentage_value = ($daysInMonth > 0)
                        ? round((($leadData[$dept_id][$staff_id][$monthNum] ?? 0) / $daysInMonth) * 100, 2)
                        : 0;

                    $percentages[$dept_id][$staff_id][$monthNum] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['present_percent'] ?? 0;

                    $trend[] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['total_attendance'] ?? 0;
                }

                $sourceTrends[$staff_id] = $trend;
            }

            $line_MonthColors = $this->generateAttractiveColors($staffIds);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            $chartDetails = [];

            foreach ($deptSummary as $deptInfo) {

                $dept_id = $deptInfo['department_id'] ?? 0;
                $department_name = $deptInfo['department_name'] ?? 'Unknown';

                // Initialize department array if not set
                if (!isset($chartDetails[$dept_id])) {
                    $chartDetails[$dept_id] = [
                        'department_name' => $department_name,
                        'staff_ids' => [],
                        'staff_names' => [],
                        'staff_shot_names' => [],
                        'staff_colors' => [],
                        'staff_pre_per' => [],
                    ];
                }

                foreach ($deptInfo['staff_list'] as $staff) {
                    $staff_id = $staff['staff_id'];
                    $staff_name = $staff['staff_name'] ?? 'Unknown';
                    $staff_position = $staff['staff_position'] ?? 'Unknown';

                    $chartDetails[$dept_id]['staff_ids'][] = $staff_id;
                    $chartDetails[$dept_id]['staff_names'][] = $staff_name . ' (' . $staff_position . ')';
                    $chartDetails[$dept_id]['staff_shot_names'][] = $staff_name;
                    $chartDetails[$dept_id]['staff_colors'][] = $line_MonthColors[$staff_id] ?? '#1e90ff';
                    $chartDetails[$dept_id]['staff_pre_per'][] = $yearlyData[$dept_id][$staff_id][$year]['present_percent'] ?? 0;
                }
            }

            // --- Final Response ---
            return response()->json([
                'months' => $months,
                'short_months' => $short_months,
                'leadTypes' => $staffIds,
                'staff_details' => $staffDetails,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'deptTotals' => $deptTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int) date('n'),
                'currentYear' => (int) date('Y'),
                'currentDay' => (int) date('j'),
                'Month' => (int) $Month,
                'sourceTrends' => $sourceTrends,
                'year' => (int) $year,
                'yearShort' => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                'dept_summary' => $deptSummary,
                'chartDetails' => $chartDetails,
                'total_departments' => count($deptSummary)
            ]);

        } catch (\Exception $e) {
            \Log::error("Error in FacultyYearlyData: " . $e->getMessage());
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function stud_count_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.performance_report.stud_count_yr_list', compact(
            'months',
            'short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function ProductionStudentsYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int) $request->is_existing_val ?? 2;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStudentsDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function ($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate = strtotime($staff['doj']);
                    $dojYear = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int) $year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate = strtotime($staff['exist_date']);
                    $exitYear = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int) $year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                $exist_status = isset($leadType['exist_status']) ? $leadType['exist_status'] : false;
                $exist_date = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : '';
                $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                // ---------- Exit Staff Tracking ----------
                if ($exist_status) {
                    $exist_y = (int) date('Y', strtotime($exist_date));
                    $exist_m = (int) date('n', strtotime($exist_date));

                    while ($exist_m <= (int) $currentMonth) {
                        $exit_staff_details[$exist_y][$exist_m][$lead_type_id] = [
                            'exist_status' => true,
                            'exist_date' => null
                        ];
                        $exist_m++;
                    }

                    $exit_status_staffs[$lead_type_id] = $exist_status;
                }

                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {

                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]['student_count']) ? $paymentSums[$year][$monthNum]['student_count'] : 0;
                    // $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$monthNum][$lead_type_id] = $count;
                    // $percentages[$lead_type_id][$monthNum] = $earned_per;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int) $monthNum == 1) {
                        $prevYear = (int) $year - 1;
                        $prevMonth = 12;
                    } else if ((int) $monthNum != 1) {
                        $prevYear = (int) $year;
                        $prevMonth = (int) $monthNum - 1;
                    }

                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]['student_count']) ? $paymentSums[$prevYear][$prevMonth]['student_count'] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int) $year) {
                            if ((int) $monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        } else if ($doj_y < (int) $year) {
                            $doj_status = true;
                        } else if ($doj_y > (int) $year) {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$year][$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $monthTotals[$day] = $dayTotal;
                }


                $grandTotalAll += $dayTotal;

                // Calculate percentages
            }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int) $currentMonth,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'currentYear' => (int) $currentYear,
                'currentDay' => (int) $currentDay,
                'Month' => (int) $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int) $year,
                'yearShort' => (int) $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    // public function goalset_yearly()
    // {
    //     $currentMonth = date('n'); // 1-12
    //     $currentYear = date('Y');

    //     $months = $this->getYearBasedMonths($currentYear);
    //     $short_months = $this->getYearBasedMonths($currentYear,2);

    //     return view('content.report_management.performance_report.goalset_yr_list', compact(
    //         'months','short_months'
    //     ))->with('report_heading', self::$report_heading);
    // }

    // public function GoalsetYearlyData(Request $request)
    // {
    //     try {

    //         $selected_year = $request->year;
    //         $search_lead_src_fill = $request->search_lead_src_fill ?? null;
    //         $is_existing_val = (int) ($request->is_existing_val ?? 2);

    //         // --- Validate and determine year ---
    //         $filterDate = ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year))
    //             ? $selected_year . '-01-01'
    //             : now()->format('Y-01-01');

    //         $year = date('Y', strtotime($filterDate));
    //         $yearShort = date('y', strtotime($filterDate));
    //         $Month = date('n', strtotime($filterDate));

    //         $months = $this->getYearBasedMonths($year);
    //         $short_months = $this->getYearBasedMonths($year, 2);

    //         $today = date('d');
    //         $today_month = date('n');
    //         $today_year = date('Y');

    //         $user = $request->user();
    //         $branch_id = $user->branch_id;

    //         // --- Fetch Faculty Attendance Data ---
    //         $result = $this->getMyIncentiveMetrics($branch_id, $search_lead_src_fill, $is_existing_val, $year);

    //         if ($result === null) {
    //             return response()->json(['error' => 'Failed to get faculty data'], 500);
    //         }

    //         // return $result;

    //         // $dailyData = $result['daily'] ?? [];
    //         $monthlyData = $result['monthly'] ?? [];
    //         $yearlyData = $result['yearly'] ?? [];
    //         $deptSummary = $result['department_summary'] ?? [];

    //         // --- Initialize output containers ---
    //         $leadData = [];       // monthly count per staff
    //         $preleadData = [];    // previous month data
    //         $percentages = [];    // placeholder for percentages (attendance ratio)
    //         $sourceTotals = [];   // total per staff
    //         $deptTotals = [];   // total per staff
    //         $monthTotals = [];    // total per month
    //         $sourceTrends = [];   // line chart data
    //         $grandTotalAll = 0;

    //         // --- Flatten Department + Staff Structure ---
    //         $staffDetails = [];
    //         foreach ($deptSummary as $dept_id => $deptInfo) {
    //             foreach ($deptInfo['staff_list'] as $staff) {
    //                 $staffDetails[$staff['staff_id']] = [
    //                     'staff_name' => $staff['staff_name'],
    //                     'department_id' => $deptInfo['department_id']
    //                 ];
    //             }
    //         }

    //         // --- Sort staff alphabetically ---
    //         uasort($staffDetails, fn($a, $b) => strcmp($a['staff_name'], $b['staff_name']));
    //         $staffIds = array_keys($staffDetails);

    //         // --- Build Monthly Dataset ---
    //         foreach ($staffIds as $staff_id) {

    //             $staff_info = $staffDetails[$staff_id];
    //             $dept_id = $staff_info['department_id'];

    //             foreach ($months as $monthNum => $monthName) {

    //                 $monthVal = $monthlyData[$dept_id][$staff_id][$monthNum]['10x_status'] ?? 0;
    //                 $goal_status = $monthlyData[$dept_id][$staff_id][$monthNum]['goal_status'] ?? 0;

    //                 $leadData[$dept_id][$staff_id][$monthNum] = [
    //                     '10x_status'=>$monthVal,
    //                     'goal_status'=>$goal_status
    //                 ];

    //                 $sourceTotals[$dept_id][$staff_id] = ($sourceTotals[$dept_id][$staff_id] ?? 0) + $monthVal;

    //                 $deptTotals[$dept_id] = ($deptTotals[$dept_id] ?? 0) + $monthVal;
    //                 $monthTotals[$dept_id][$monthNum] = ($monthTotals[$dept_id][$monthNum] ?? 0) + $monthVal;

    //                 // --- Previous month data ---
    //                 // $prevMonth = ($monthNum == 1) ? 12 : $monthNum - 1;
    //                 // $prevYear = ($monthNum == 1) ? $year - 1 : $year;
    //                 // $preVal = $monthlyData[$dept_id][$staff_id][$prevYear][$prevMonth]['total_attendance'] ?? 0;
    //                 // $preleadData[$dept_id][$staff_id][$prevMonth] = $preVal;
    //             }
    //         }

    //         // --- Source Trends for Graphs (month-wise) ---
    //         foreach ($staffIds as $staff_id) {

    //             $staff_info = $staffDetails[$staff_id];
    //             $dept_id = $staff_info['department_id'];

    //             $trend = [];
    //             foreach ($months as $monthNum => $monthName) {

    //                 // $daysInMonth = $this->getDaysWithoutSundays($monthNum, $year);

    //                 // $percentage_value = ($daysInMonth > 0)
    //                 // ? round((($leadData[$dept_id][$staff_id][$monthNum] ?? 0) / $daysInMonth) * 100, 2)
    //                 // : 0;

    //                 // $percentages[$dept_id][$staff_id][$monthNum] = $monthlyData[$dept_id][$staff_id][$year][$monthNum]['present_percent'] ?? 0;

    //                 $trend[] = $monthlyData[$dept_id][$staff_id][$monthNum]['10x_status'] ?? 0;
    //             }

    //             $sourceTrends[$staff_id] = $trend;
    //         }

    //         // --- Compute Grand Total ---
    //         // $grandTotalAll = array_sum($sourceTotals);

    //         // --- Generate colors for charts ---
    //         $line_MonthColors = $this->generateAttractiveColors($staffIds);
    //         $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
    //             ? array_values($line_MonthColors)
    //             : [];


    //         $chartDetails = [];

    //         foreach ($deptSummary as $deptInfo) {

    //             $dept_id = $deptInfo['department_id'] ?? 0;
    //             $department_name = $deptInfo['department_name'] ?? 'Unknown';

    //             // Initialize department array if not set
    //             if (!isset($chartDetails[$dept_id])) {
    //                 $chartDetails[$dept_id] = [
    //                     'department_name' => $department_name,
    //                     'staff_ids'     => [],
    //                     'staff_names'     => [],
    //                     'staff_shot_names' => [],
    //                     'staff_colors'    => [],
    //                     'staff_pre_per'   => [],
    //                 ];
    //             }

    //             foreach ($deptInfo['staff_list'] as $staff) {

    //                 $staff_id   = $staff['staff_id'];
    //                 $staff_name = $staff['staff_name'] ?? 'Unknown';
    //                 $staff_position = $staff['staff_position'] ?? 'Unknown';

    //                 $chartDetails[$dept_id]['staff_ids'][]   = $staff_id;
    //                 $chartDetails[$dept_id]['staff_names'][]   = $staff_name.' ('.$staff_position.')';
    //                 $chartDetails[$dept_id]['staff_shot_names'][]   = $staff_name;
    //                 $chartDetails[$dept_id]['staff_colors'][]  = $line_MonthColors[$staff_id] ?? '#1e90ff';
    //                 $chartDetails[$dept_id]['staff_pre_per'][] = $sourceTotals[$dept_id][$staff_id] ?? 0;
    //             }
    //         }

    //         // --- Final Response ---
    //         return response()->json([
    //             'months'         => $months,
    //             'short_months'   => $short_months,
    //             'leadTypes'      => $staffIds,
    //             'staff_details'  => $staffDetails,
    //             'leadData'       => $leadData,
    //             'preleadData'    => $preleadData,
    //             'percentages'    => $percentages,
    //             'sourceTotals'   => $sourceTotals,
    //             'deptTotals'   => $deptTotals,
    //             'monthTotals'    => $monthTotals,
    //             'grandTotalAll'  => $grandTotalAll,
    //             'currentMonth'   => (int) date('n'),
    //             'currentYear'    => (int) date('Y'),
    //             'currentDay'     => (int) date('j'),
    //             'Month'          => (int) $Month,
    //             'sourceTrends'   => $sourceTrends,
    //             'year'           => (int) $year,
    //             'yearShort'      => (int) $yearShort,
    //             'line_MonthColors' => $line_MonthColors,
    //             'pie_MonthColors'  => $pie_MonthColors,
    //             'dept_summary'   => $deptSummary,
    //             'chartDetails'   => $chartDetails,
    //             'total_departments' => count($deptSummary)
    //         ]);

    //     } catch (\Exception $e) {
    //         \Log::error("Error in FacultyYearlyData: " . $e->getMessage());
    //         return response()->json([
    //             'message' => 'Failed to load Faculty data.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    // private function getMyIncentiveMetrics(int $branchId, $search_lead_src_fill = null, int $is_existing_val = 2, int $year)
    // {
    //     try {

    //         if (!$branchId) {
    //             throw new \InvalidArgumentException("Branch ID is required");
    //         }

    //         $currentDate  = date('Y-m-d');
    //         $current_date  = date('Y-m-d');
    //         $currentYear  = (int) date('Y');
    //         $currentMonth = (int) date('n');

    //         $months = $this->getYearBasedMonths($year);

    //         $staffListQuery = DB::table('za_staff')
    //         ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
    //         ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
    //         ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    //         ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
    //         ->where('za_staff.branch_id', $branchId);

    //         if ($is_existing_val == 2) {

    //             $staffListQuery->where(function ($query) use ($currentYear, $currentMonth) {
    //                 $query->where(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where('za_staff.status', 4)
    //                         ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
    //                         ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
    //                 })
    //                 ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where('za_staff.status', 5)
    //                         ->whereYear('za_staff.updated_at', '>=', $currentYear)
    //                         ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
    //                 })
    //                 ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where('za_staff.status', 6)
    //                         ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
    //                         ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
    //                 })
    //                 ->orWhere(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where('za_staff.status', 7)
    //                         ->whereYear('za_staff.updated_at', '>=', $currentYear)
    //                         ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
    //                 })
    //                 ->orWhere('za_staff.status', 0);
    //             });
    //         } else {
    //             $staffListQuery->where('za_staff.status', '!=', 2);
    //         }

    //         if (!empty($search_lead_src_fill)) {
    //             $staffListQuery->whereIn('za_staff.sno', $search_lead_src_fill);
    //         }

    //         $staffList = $staffListQuery
    //         ->orderBy('za_staff.department_id')
    //         ->orderBy('za_staff.staff_name')
    //         ->get([
    //             'za_staff.*',
    //             'za_staff.sno as staff_id',
    //             'za_user_role.role_name',
    //             'za_job_position.job_position_name'
    //         ]);

    //         if ($staffList->isEmpty()) {
    //             return [
    //                 'year' => $year,
    //                 'total_departments' => 0,
    //                 'department_summary' => [],
    //                 'monthly' => [],
    //                 'yearly' => [],
    //                 'data' => []
    //             ];
    //         }

    //         $result = [];
    //         $departmentSummary = [];
    //         $department_Summary = [];
    //         $monthlySummary = [];
    //         $yearlySummary = [];

    //         $deptSummary = [];

    //         $departmentSummary = $staffList->groupBy('department_id')->map(function ($group, $deptId) {

    //             return [
    //                 'department_id'   => $deptId,
    //                 'department_name' => $this->getDepartmentName($deptId),
    //                 'staff_count'     => $group->count(),
    //                 'staff_list'      => $group->map(fn($s) => [
    //                     'staff_id'       => $s->staff_id ?? $s->sno,
    //                     'staff_name'     => $s->staff_name ?? 'Unknown',
    //                     'staff_position' => (
    //                         !empty($s->job_position_name ?? null)
    //                             ? $s->job_position_name
    //                             : (!empty($s->role_name ?? null)
    //                                 ? $s->role_name
    //                                 : 'None')
    //                     ),
    //                 ])->values(),
    //             ];
    //         })->values()->toArray();

    //         foreach ($staffList->groupBy('department_id') as $departmentId => $departmentStaff) {

    //             $departmentTotal = 0;

    //             $tenxStatus = false;

    //             foreach ($departmentStaff as $staff) {

    //                 $role_id = $staff->role_id;

    //                 $isProduction  = $role_id == 22;
    //                 $isSalesEx     = $role_id == 11;
    //                 $isTeamLead    = $role_id == 12;
    //                 $isCollection  = $role_id == 14;
    //                 $isCRE         = $role_id == 16;
    //                 $isPC          = $role_id == 15;

    //                 $monthlyData = [];
    //                 $staffYearlyTotal = 0;

    //                 foreach ($months as $month => $month_name) {

    //                     $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    //                     $endDate   = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    //                     $prevMonth = $startDate->copy()->subMonth()->month;
    //                     $prevYear  = $startDate->copy()->subMonth()->year;

    //                     $current = Carbon::create($year, $month, 1);
    //                     // 20 years ago from now startDateOld
    //                     $startDateold = $current->copy()->subYears(20)->startOfMonth();
    //                     $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month

    //                     $goalsetteam = GoalSetTeamModel::where('department_id', $departmentId)
    //                         ->where('branch_id', $branchId)
    //                         ->where('team_goal_month', $month)
    //                         ->where('team_goal_year', $year)
    //                         ->first();

    //                     $goalStaff = GoalSetStaffModel::where('department_id', $departmentId)
    //                         ->where('branch_id', $branchId)
    //                         ->where('staff_id', $staff->staff_id)
    //                         ->where('goal_month', $month)
    //                         ->whereYear('goal_date', $year)
    //                         ->first();

    //                     // âœ… Example total variable â€” you can adjust if you track other metrics
    //                     $tenxStatus = false;
    //                     $customerConvertCount = 0;

    //                     // // ==============================================
    //                     // // ðŸŸ¦ SALES EXECUTIVE (role_id = 11)
    //                     // // ==============================================
    //                     if ($isSalesEx) {

    //                         // --- Current Month Conversion Count ---
    //                         $customerConvertCountthismonth = DB::table('za_customer as c')
    //                             ->join('za_lead as l', 'l.sno', '=', 'c.lead_id')
    //                             ->whereIn('c.status', [0, 6])
    //                             ->where('c.branch_id', $branchId)
    //                             ->where('l.created_by', $staff->staff_id)
    //                             ->whereYear('c.created_at', $year)
    //                             ->whereMonth('c.created_at', $month)
    //                             ->count();

    //                         // --- Prev Month Converted Customers ---
    //                         $prevMonthConvertedCustomers = DB::table('za_customer as c')
    //                             ->join('za_lead as l', 'l.sno', '=', 'c.lead_id')
    //                             ->whereIn('c.status', [0, 6])
    //                             ->where('c.branch_id', $branchId)
    //                             ->where('l.created_by', $staff->staff_id)
    //                             ->whereYear('c.created_at', $prevYear)
    //                             ->whereMonth('c.created_at', $prevMonth)
    //                             ->pluck('c.sno')
    //                             ->toArray();

    //                         if (empty($prevMonthConvertedCustomers)) {
    //                             $customerConvertCount = $customerConvertCountthismonth;
    //                             $tenxStatus = false;
    //                         }

    //                         // --- Dropouts ---
    //                         $dropoutCustomers = DB::table('za_training')
    //                             ->whereIn('customer_id', $prevMonthConvertedCustomers)
    //                             ->where('status', 2)
    //                             ->pluck('customer_id')
    //                             ->toArray();

    //                         // --- Fully Paid Customers ---
    //                         $fullPaidCustomerIds = DB::table('za_payment')
    //                             ->select('customer_id')
    //                             ->whereIn('customer_id', $prevMonthConvertedCustomers)
    //                             ->where('status', 1)
    //                             ->groupBy('customer_id')
    //                             ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
    //                             ->pluck('customer_id')
    //                             ->toArray();

    //                         // --- Second Payment Customers ---
    //                         $secondPaymentCustomers = DB::table('za_payment')
    //                             ->whereIn('customer_id', $prevMonthConvertedCustomers)
    //                             ->where('status', 1)
    //                             ->whereYear('nextPayDate', $year)
    //                             ->whereMonth('nextPayDate', $month)
    //                             ->pluck('customer_id')
    //                             ->merge($fullPaidCustomerIds)
    //                             ->unique()
    //                             ->values()
    //                             ->toArray();

    //                         // --- Branch Info ---
    //                         $branch = BranchModel::select('min_prd_cost')
    //                             ->where('sno', $branchId)
    //                             ->where('status', 0)
    //                             ->first();

    //                         // --- Dropped Refund Customers ---
    //                         $drop_ids = DB::table('za_drop_refund as dr')
    //                             ->join('za_training as t', 'dr.training_id', '=', 't.sno')
    //                             ->where('dr.bh_status', 1)
    //                             ->pluck('t.customer_id')
    //                             ->toArray();

    //                         // --- Payment Summary ---
    //                         $PaidUnderPayment = DB::table('za_training as t')
    //                             ->join('za_customer as c', 't.customer_id', '=', 'c.sno')
    //                             ->join('za_payment as p', 'p.payment_id', '=', 't.payment_id')
    //                             ->where('p.branch_id', $branchId)
    //                             ->whereIn('t.customer_id', $prevMonthConvertedCustomers)
    //                             ->whereNotIn('c.sno', $drop_ids)
    //                             ->where('t.status', '!=', 2)
    //                             ->where('t.balance_amount', '!=', 0)
    //                             ->select(
    //                                 'c.customer_id',
    //                                 'c.sno as customer_sno',
    //                                 'c.cus_name',
    //                                 't.paid_amount as total_paid_amount',
    //                                 DB::raw('SUM(p.gst_amount) as total_gst_amount')
    //                             )
    //                             ->groupBy('c.customer_id', 'c.sno', 'c.cus_name', 't.paid_amount')
    //                             ->get()
    //                             ->unique('customer_sno');

    //                         // --- Filter Underpaid Customers ---
    //                         $lowPaymentResult = $PaidUnderPayment->filter(fn($p) =>
    //                             $p->total_paid_amount < ($branch->min_prd_cost ?? 0)
    //                         );

    //                         $lowMbcCustomerIds = $lowPaymentResult->pluck('customer_sno')->toArray();

    //                         // --- Merge Bad Customers ---
    //                         $badCustomerIds = array_unique(array_merge(
    //                             $dropoutCustomers,
    //                             $lowMbcCustomerIds,
    //                             array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    //                         ));

    //                         // --- TenX Status ---
    //                         $customerConvertCount = max(0, $customerConvertCountthismonth);
    //                         $targetConversion = optional($goalStaff)->conversion ?? 0;
    //                         $targetABV = optional($goalStaff)->ABV ?? 0;
    //                         $targetACV = optional($goalStaff)->ACV ?? 0;

    //                         $tenxStatus = (
    //                             $targetConversion > 0 &&
    //                             $targetABV > 0 &&
    //                             $targetACV > 0 &&
    //                             $customerConvertCount >= $targetConversion
    //                         );
    //                     }

    //                     // // ==============================================
    //                     // // ðŸŸ¦ COLLECTION TEAM (role_id = 14)
    //                     // // ==============================================
    //                     if ($isCollection) {

    //                         $refferal_count = DB::table('za_referral_persons')
    //                             ->where('branch_id', $branchId)
    //                             ->where('referral_id', $staff->staff_id)
    //                             ->where('status', 0)
    //                             ->where('referral_type', 2)
    //                             ->whereYear('created_at', $year)
    //                             ->whereMonth('created_at', $month)
    //                             ->count();

    //                         $dropoutCustomers = DB::table('za_training')
    //                             ->where('status', 2)
    //                             ->pluck('customer_id')
    //                             ->toArray();

    //                         $prevMonthConvertedCustomers = DB::table('za_customer')
    //                             ->whereIn('za_customer.status', [0, 6])
    //                             ->where('za_customer.branch_id', $branchId)
    //                             ->whereNotIn('za_customer.sno', $dropoutCustomers)
    //                             ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
    //                             ->pluck('za_customer.sno')
    //                             ->toArray();

    //                         $hacAmount = DB::table('za_payment')
    //                             ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    //                             ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
    //                             ->where('za_payment.status', 1)
    //                             ->whereYear('za_payment.initialPayDate', $year)
    //                             ->whereMonth('za_payment.initialPayDate', $month)
    //                             ->where('za_payment.branch_id', $branchId)
    //                             ->sum('za_payment.paidAmount');

    //                         $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);

    //                         $isHacCostingRequired = isset($ten_x['hac_10x']) ? $ten_x['hac_10x'] == "1" : false;
    //                         $isoutstandingRequired        = isset($ten_x['no_of_outstanding_10x']) ? $ten_x['no_of_outstanding_10x'] == "1" : false;
    //                         $isPostsaleRequired        = isset($ten_x['no_of_post_sale_10x']) ? $ten_x['no_of_post_sale_10x'] == "1" : false;

    //                         $targetTenx = 0;
    //                         $actaulTenx = 0;
    //                         $tenxStatus = false;

    //                         if ($isHacCostingRequired) {
    //                             $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
    //                             $actaulTenx  = $hacAmount ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
    //                         } elseif ($isoutstandingRequired) {
    //                             $targetTenx  = $goalStaff->student_count ?? 0;
    //                             $actaulTenx  = $actual_student_count ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
    //                         } 
    //                     }

    //                     // // ==============================================
    //                     // // ðŸŸ¦ CRE TEAM (role_id = 16)
    //                     // // ==============================================
    //                     if ($isCRE) {

    //                         $review_count = DB::table('za_review')
    //                             ->where('branch_id', $branchId)
    //                             ->where('created_by', $staff->staff_id)
    //                             ->where('status', 0)
    //                             ->whereYear('created_at', $year)
    //                             ->whereMonth('created_at', $month)
    //                             ->count();

    //                         $refferal_count = DB::table('za_referral_persons')
    //                             ->where('branch_id', $branchId)
    //                             ->where('referral_id', $staff->staff_id)
    //                             ->where('status', 0)
    //                             ->where('referral_type', 2)
    //                             ->whereYear('created_at', $year)
    //                             ->whereMonth('created_at', $month)
    //                             ->count();

    //                         $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    //                         $isReview10x = $ten_x['no_of_reviews_10x'] ?? false;
    //                         $isReferral10x = $ten_x['reference_sales_10x'] ?? false;

    //                         $targetTenx = 0;
    //                         $actaulTenx = 0;
    //                         $tenxStatus = false;

    //                         if ($isReview10x) {
    //                             $targetTenx = optional($goalStaff)->no_of_reviews ?? 0;
    //                             $actaulTenx = $review_count;
    //                             $tenxStatus = $targetTenx > 0 && $actaulTenx >= $targetTenx;
    //                         } elseif ($isReferral10x) {
    //                             $targetTenx = optional($goalStaff)->reference_sales ?? 0;
    //                             $actaulTenx = $refferal_count;
    //                             $tenxStatus = $targetTenx > 0 && $actaulTenx >= $targetTenx;
    //                         }
    //                     }

    //                     // ==============================================
    //                     // ðŸŸ¦ Production TEAM (role_id = 22)
    //                     // ==============================================
    //                     if ($isProduction) {

    //                         // Initialize
    //                         $slotType = $staff;
    //                         $slotType->earned_amount = 0;
    //                         $slotType->avg_amnt = 0;
    //                         $slotType->salary = 0;

    //                         // ⚡ Fast batch fetch
    //                         $batchIds = TrainingModel::where('branch_id', $branchId)
    //                             ->where('staff_id', $slotType->staff_id)
    //                             ->distinct()
    //                             ->pluck('batch_id')
    //                             ->toArray();

    //                         $slotType->batch_ids = (array) $batchIds;

    //                         // ⚡ Preload all batches with slot timings
    //                         $batches = BatchModel::select('za_batch.sno', 'za_slot.start_time', 'za_slot.end_time')
    //                             ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
    //                             ->whereIn('za_batch.sno', $slotType->batch_ids)
    //                             ->get()
    //                             ->keyBy('sno');

    //                         // ⚡ Preload all attendance for this staff in one go
    //                         $attendanceData = AttendanceModel::select('batch_id', 'per_hr_cost')
    //                             ->where('staff_id', $slotType->staff_id)
    //                             ->where('attendance', 'P')
    //                             ->whereMonth('att_date', $month)
    //                             ->whereYear('att_date', $year)
    //                             ->get()
    //                             ->groupBy('batch_id');

    //                         // ⚙️ Loop only necessary batches (no logic change)
    //                         foreach ($slotType->batch_ids as $batchId) {

    //                             $batch = $batches->get($batchId);

    //                             if (!$batch) continue;

    //                             $startTime = Carbon::parse($batch->start_time);
    //                             $endTime   = Carbon::parse($batch->end_time);
    //                             $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

    //                             $attendanceRecords = $attendanceData->get($batchId, collect());
    //                             foreach ($attendanceRecords as $attendance) {
    //                                 $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
    //                             }
    //                         }

    //                         // Salary & Average
    //                         $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;

    //                         $slotType->avg_amnt = ($slotType->salary > 0)
    //                             ? (($slotType->earned_amount / $slotType->salary) * 100)
    //                             : 0;

    //                         // Copy for use
    //                         $staffproduction = $slotType;
    //                         $costing_amount = $staffproduction->earned_amount ?? 0;

    //                         // ⚡ Fast referral count
    //                         $refferal_count = DB::table('za_referral_persons')
    //                             ->where('branch_id', $branchId)
    //                             ->where('referral_id', $staff->staff_id)
    //                             ->where('status', 0)
    //                             ->where('referral_type', 2)
    //                             ->whereYear('created_at', $year)
    //                             ->whereMonth('created_at', $month)
    //                             ->count();

    //                         // Salary & Costing Amount
    //                         $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    //                         $costing_amount_asign = $goalStaff->production_costing ?? 0;

    //                         $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0)
    //                             ? ($costing_amount / $basic_pay) * $costing_amount_asign
    //                             : 0;

    //                         $costing_amount = $costing_amount2;

    //                         // TenX logic (unchanged)
    //                         $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    //                         $isProductionCostingRequired = isset($ten_x['production_costing_10x']) ? $ten_x['production_costing_10x'] == "1" : false;
    //                         $isStudentMinRequired = isset($ten_x['min_no_of_students_10x']) ? $ten_x['min_no_of_students_10x'] == "1" : false;
    //                         $isReferenceSalesRequired = isset($ten_x['reference_sales_10x']) ? $ten_x['reference_sales_10x'] == "1": false;

    //                         $tenxStatus = false;
    //                         $targetTenx = 0;
    //                         $actaulTenx = 0;

    //                         if ($isProductionCostingRequired) {
    //                             $targetTenx = $costing_amount_asign ?? 0;
    //                             $actaulTenx = $costing_amount ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    //                         } elseif ($isStudentMinRequired) {
    //                             $targetTenx = $goalStaff->student_count ?? 0;
    //                             $actaulTenx = $actual_student_count ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    //                         } elseif ($isReferenceSalesRequired) {
    //                             $targetTenx = $goalStaff->reference_sales ?? 0;
    //                             $actaulTenx = $refferal_count ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    //                         }
    //                     }

    //                     // // ==============================================
    //                     // // ðŸŸ¦ PC TEAM (role_id = 15)
    //                     // // ==============================================
    //                     if ($isPC) {

    //                         // --- Initialize ---
    //                         $slotType = $staff;
    //                         $slotType->earned_amount = 0;
    //                         $slotType->salary = 0;

    //                         // --- Fetch all batch IDs for staff ---
    //                         $batchIds = TrainingModel::where('branch_id', $branchId)
    //                             ->where('staff_id', $slotType->staff_id)
    //                             ->distinct()
    //                             ->pluck('batch_id')
    //                             ->toArray();

    //                         $slotType->batch_ids = (array) $batchIds;

    //                         // --- Preload all related batches + slots in one go ---
    //                         $batches = BatchModel::select('za_batch.sno', 'za_slot.start_time', 'za_slot.end_time')
    //                             ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
    //                             ->whereIn('za_batch.sno', $slotType->batch_ids)
    //                             ->get()
    //                             ->keyBy('sno');

    //                         // --- Preload all attendance for this staff in one query ---
    //                         $attendanceRecords = AttendanceModel::select('batch_id', 'per_hr_cost')
    //                             ->where('staff_id', $slotType->staff_id)
    //                             ->where('attendance', 'P')
    //                             ->whereMonth('att_date', $month)
    //                             ->whereYear('att_date', $year)
    //                             ->get()
    //                             ->groupBy('batch_id');

    //                         // --- Calculate earned amount ---
    //                         foreach ($slotType->batch_ids as $batchId) {
    //                             $batch = $batches->get($batchId);
    //                             if (!$batch) continue;

    //                             $startTime = Carbon::parse($batch->start_time);
    //                             $endTime   = Carbon::parse($batch->end_time);
    //                             $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

    //                             $batchAttendance = $attendanceRecords->get($batchId, collect());
    //                             foreach ($batchAttendance as $attendance) {
    //                                 $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
    //                             }
    //                         }

    //                         // --- Salary Calculation ---
    //                         $slotType->salary = isset($slotType->basic_salary)
    //                             ? ($slotType->basic_salary * 10)
    //                             : 0;

    //                         // --- Copy for further use ---
    //                         $staffproduction = $slotType;
    //                         $costing_amount  = $staffproduction->earned_amount ?? 0;

    //                         // --- ⚡ Fast referral count ---
    //                         $refferal_count = DB::table('za_referral_persons')
    //                             ->where('branch_id', $branchId)
    //                             ->where('referral_id', $staff->staff_id)
    //                             ->where('status', 0)
    //                             ->where('referral_type', 2)
    //                             ->whereYear('created_at', $year)
    //                             ->whereMonth('created_at', $month)
    //                             ->count();

    //                         // --- Costing Calculation ---
    //                         $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    //                         $costing_amount_asign = $goalStaff->production_costing ?? 0;

    //                         $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0)
    //                             ? ($costing_amount / $basic_pay) * $costing_amount_asign
    //                             : 0;

    //                         $costing_amount = $costing_amount2;

    //                         // --- TenX Logic (unchanged) ---
    //                         $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);

    //                         $isProductionCostingRequired = isset($ten_x['productions_10x']) ? $ten_x['productions_10x'] == "1" : false;
    //                         $isReferenceSalesRequired = isset($ten_x['reference_sales_10x']) ? $ten_x['reference_sales_10x'] == "1": false;

    //                         $tenxStatus = false;
    //                         $targetTenx = 0;
    //                         $actaulTenx = 0;

    //                         if ($isProductionCostingRequired) {
    //                             $targetTenx = $costing_amount_asign ?? 0;
    //                             $actaulTenx = $costing_amount ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;

    //                         } elseif ($isReferenceSalesRequired) {
    //                             $targetTenx = $goalStaff->reference_sales ?? 0;
    //                             $actaulTenx = $refferal_count ?? 0;
    //                             $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    //                         }
    //                     }

    //                     $monthlyData[$month] = [
    //                         'month' => $month,
    //                         'month_name' => Carbon::create()->month($month)->format('F'),
    //                         'goal_team' => $goalsetteam ? $goalsetteam->toArray() : null,
    //                         'goal_staff' => $goalStaff ? $goalStaff->toArray() : null,
    //                         'tenx_status' => $tenxStatus,
    //                         'customerConvertCount' => $customerConvertCount,
    //                     ];
    //                 }

    //                 $result[$departmentId][$staff->staff_id] = $monthlyData;

    //                 // Initialize summary arrays
    //                 $monthlySummary = [];

    //                 $yearlySummary = [];

    //                 // Loop through all data
    //                 foreach ($result as $departmentId => $staffs) {

    //                     foreach ($staffs as $staffId => $months) {

    //                         $yearlyCount = 0;

    //                         foreach ($months as $monthNum => $monthData) {

    //                             $monthlyCount = 0;

    //                             // âœ… If TenX achieved, increment counters
    //                             if (isset($monthData['tenx_status']) && $monthData['tenx_status']) {
    //                                 $monthlyCount++;
    //                                 $yearlyCount++;
    //                             }

    //                             if (!isset($monthlySummary[$departmentId][$staffId][$monthNum])) {
    //                                 $monthlySummary[$departmentId][$staffId][$monthNum] = [
    //                                     '10x_status' => 0,
    //                                     'goal_status' => 0
    //                                 ];
    //                             }

    //                             $monthlySummary[$departmentId][$staffId][$monthNum] = [
    //                                 '10x_status' => $monthlyCount,
    //                                 'goal_status' => isset($monthData['goal_staff']) && !empty($monthData['goal_staff']) ? 1 : 0
    //                             ];
    //                         }
    //                         // âœ… Store per-staff yearly total
    //                     }

    //                     if (!isset($yearlySummary[$departmentId])) {
    //                         $yearlySummary[$departmentId] = ['10x_status' => 0];
    //                     }

    //                     $yearlySummary[$departmentId]['10x_status'] = $yearlyCount;
    //                 }
    //             }

    //             $department_Summary[$departmentId] = $departmentTotal;
    //         }

    //         // count of total departments
    //         $totalDepartments = count($department_Summary);

    //         return [
    //             'year' => $year,
    //             'total_departments' => $totalDepartments,
    //             'department_summary' => $departmentSummary,
    //             'monthly' => $monthlySummary,
    //             'yearly' => $yearlySummary,
    //             'data' => $result
    //         ];

    //     } catch (\Exception $e) {
    //         \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
    //         return null;
    //     }
    // }

    private function GetProductionPerDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details = [];
            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];

            // --- Fetch job positions ---
            $job_positions = DB::table('za_job_position')
                ->where('sub_department_id', 4)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Staff list ---
            $staff_query = DB::table('za_staff')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
                ->where('za_staff.branch_id', $branch_id)
                ->whereIn('za_staff.position_role', $job_positionsIds);

            // Active/existing staff logic
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 5)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 6)
                                ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 7)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('za_staff.status', 0);
                });
            } else {
                $staff_query->where('za_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('za_staff.sno', $search_lead_src_fill);
            }

            // Fetch staff
            $staff_list = $staff_query->orderBy('staff_name', 'asc')->get([
                'za_staff.*',
                'za_user_role.role_name',
                'za_job_position.job_position_name'
            ]);


            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $batchIds = DB::table('za_training')->where('branch_id', $branch_id)
                    ->where('staff_id', $staff->sno)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();

                $batchIds = (array) $batchIds; // Convert to an array if it's a string or non-array

                foreach ($batchIds as $batchId) {

                    // Fetch the batch details
                    $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
                        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                        ->where('za_batch.status', '!=', 2)
                        ->find($batchId);

                    if ($batch) {

                        // Calculate the duration between start_time and end_time for the specific batch
                        $startTime = Carbon::parse($batch->start_time);  // Convert start time to a Carbon instance
                        $endTime = Carbon::parse($batch->end_time);      // Convert end time to a Carbon instance

                        $durationInMinutes = $startTime->diffInMinutes($endTime);  // Calculate duration in minutes
                        $batchDurationInHours = $durationInMinutes / 60;  // Convert minutes to hours for this batch

                        // --- Fetch all attendance for all staff in one query ---
                        $attendances = DB::table('za_attendance')
                            ->where('batch_id', $batch->sno)
                            ->where('branch_id', $branch_id)
                            ->where('staff_id', $staff->sno)
                            ->whereDate('att_date', '<=', $currentDate)
                            ->where('attendance', 'P')
                            ->get();

                        // Attendance for this staff
                        if (!empty($attendances)) {

                            foreach ($attendances as $att) {

                                $attDate = date('Y-m-d', strtotime($att->att_date));

                                $y = (int) date('Y', strtotime($attDate));
                                $m = (int) date('n', strtotime($attDate));
                                $d = (int) date('j', strtotime($attDate));

                                // if ($attDate == $loopDate) {
                                if (!isset($dailyData[$staff->sno][$y][$m][$d])) {
                                    $dailyData[$staff->sno][$y][$m][$d] = [
                                        'earned_amount' => 0,
                                        'earned_per' => 0
                                    ];
                                }
                                if (!isset($monthlyData[$staff->sno][$y][$m])) {
                                    $monthlyData[$staff->sno][$y][$m] = [
                                        'earned_amount' => 0,
                                        'earned_per' => 0
                                    ];
                                }
                                if (!isset($yearlyData[$staff->sno][$y])) {
                                    $yearlyData[$staff->sno][$y] = [
                                        'earned_amount' => 0,
                                        'earned_per' => 0
                                    ];
                                }

                                $earnedAmountForAttendance = $att->per_hr_cost * $batchDurationInHours; // Use batch duration here

                                $slary_amount = ($staff->basic_salary ?? 0) * 10;

                                $earnedAmountForPer = 0;

                                if ($slary_amount != 0) {
                                    $earnedAmountForPer = ($earnedAmountForAttendance / $slary_amount) * 100;
                                }


                                $dailyData[$staff->sno][$y][$m][$d]['earned_amount'] += $earnedAmountForAttendance;
                                $monthlyData[$staff->sno][$y][$m]['earned_amount'] += $earnedAmountForAttendance;
                                $yearlyData[$staff->sno][$y]['earned_amount'] += $earnedAmountForAttendance;
                                $dailyData[$staff->sno][$y][$m][$d]['earned_per'] += $earnedAmountForPer;
                                $monthlyData[$staff->sno][$y][$m]['earned_per'] += $earnedAmountForPer;
                                $yearlyData[$staff->sno][$y]['earned_per'] += $earnedAmountForPer;

                            }
                        }
                    }
                }

                $doj = !empty($staff->date_of_joining) ? $staff->date_of_joining : null;
                $exist_date = match ($staff->status) {
                    4 => $staff->notice_end_date,
                    5 => $staff->updated_at,
                    6 => $staff->staff_last_date,
                    7 => $staff->updated_at,
                    default => null,
                };

                $staff_details[$staff->sno] = [
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $staff->job_position_name ?: ($staff->role_name ?: 'None'),
                    'staff_full_name' => $staff->staff_name . ' (' . $staff->job_position_name ?: ($staff->role_name ?: 'None') . ')' ?? 'None',
                    'doj' => $doj,
                    'exist_status' => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date' => $exist_date,
                ];
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly' => $yearlyData,
                'monthly' => $monthlyData,
                'daily' => $dailyData,
                'staff_details' => $staff_details,
                'years' => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
            return null;
        }
    }

    private function GetStudentsDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2, int $year)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $staff_details = [];
            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];

            $months = $this->getYearBasedMonths($year);

            // --- Fetch job positions ---
            $job_positions = DB::table('za_job_position')
                ->where('sub_department_id', 4)
                ->where('status', '!=', 2)
                ->get();

            $job_positionsIds = $job_positions->pluck('sno')->toArray();

            // --- Staff list ---
            $staff_query = DB::table('za_staff')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
                ->where('za_staff.branch_id', $branch_id)
                ->whereIn('za_staff.position_role', $job_positionsIds);

            // Active/existing staff logic
            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 5)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 6)
                                ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 7)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('za_staff.status', 0);
                });
            } else {
                $staff_query->where('za_staff.status', '!=', 2);
            }

            // Search filter
            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('za_staff.sno', $search_lead_src_fill);
            }

            // Fetch staff
            $staff_list = $staff_query->orderBy('staff_name', 'asc')->get([
                'za_staff.*',
                'za_user_role.role_name',
                'za_job_position.job_position_name'
            ]);

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                foreach ($months as $monthNum => $monthName) {

                    $student_count = TrainingModel::where('branch_id', $branch_id)
                        ->where('staff_id', $staff->sno)
                        ->where(function ($query) use ($monthNum, $year) {
                            $query->whereMonth('start_date', '<=', $monthNum)
                                ->whereYear('start_date', '<=', $year)
                                ->whereMonth('end_date', '>=', $monthNum)
                                ->whereYear('end_date', '>=', $year);
                        })
                        ->distinct('customer_id')
                        ->count('customer_id');

                    // $dailyData[$staff->sno][$y][$m][$d]['student_count'] = ($dailyData[$staff->sno][$y][$m][$d]['student_count'] ?? 0) + 1;
                    $monthlyData[$staff->sno][$year][$monthNum]['student_count'] = ($monthlyData[$staff->sno][$year][$monthNum]['student_count'] ?? 0) + $student_count;
                    $yearlyData[$staff->sno][$year]['student_count'] = ($yearlyData[$staff->sno][$year]['student_count'] ?? 0) + $student_count;
                }

                $doj = !empty($staff->date_of_joining) ? $staff->date_of_joining : null;
                $exist_date = match ($staff->status) {
                    4 => $staff->notice_end_date,
                    5 => $staff->updated_at,
                    6 => $staff->staff_last_date,
                    7 => $staff->updated_at,
                    default => null,
                };

                $staff_details[$staff->sno] = [
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $staff->job_position_name ?: ($staff->role_name ?: 'None'),
                    'staff_full_name' => $staff->staff_name . ' (' . $staff->job_position_name ?: ($staff->role_name ?: 'None') . ')' ?? 'None',
                    'doj' => $doj,
                    'exist_status' => in_array($staff->status, [4, 5, 6, 7]),
                    'exist_date' => $exist_date,
                ];
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly' => $yearlyData,
                'monthly' => $monthlyData,
                'daily' => $dailyData,
                'staff_details' => $staff_details,
                'years' => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyRevenueDetails: " . $e->getMessage());
            return null;
        }
    }

    public function getStaffPerformList(Request $request)
    {
        $currentDate = date('Y-m-d');
        $currentYear = (int) date('Y');
        $currentMonth = (int) date('n');

        $is_existing_val = (int) $request->checked_val ?? 2;

        $user = $request->user();
        $user_id = $user->user_id;
        $branch_id = $user->branch_id;

        $staff_details = [];

        $job_positions = DB::table('za_job_position')
            ->where('sub_department_id', 4)
            ->where('status', '!=', 2)
            ->get();

        foreach ($job_positions as $position) {

            // --- Fetch staff under this position ---
            $staff_list = DB::table('za_staff')
                ->where('branch_id', $branch_id)
                ->where('position_role', $position->sno)
                // ->where('role_id', 22)
                // ->where('za_staff.status', 0)
                ->where(function ($query) use ($currentYear, $currentMonth, $is_existing_val) {
                    if ($is_existing_val == 2) {
                        $query->where(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('status', 4)
                                ->whereYear('notice_end_date', '>=', $currentYear)
                                ->whereMonth('notice_end_date', '>=', $currentMonth);
                        })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 5)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 6)
                                    ->whereYear('staff_last_date', '>=', $currentYear)
                                    ->whereMonth('staff_last_date', '>=', $currentMonth);
                            })
                            ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                                $q->where('status', 7)
                                    ->whereYear('updated_at', '>=', $currentYear)
                                    ->whereMonth('updated_at', '>=', $currentMonth);
                            })
                            ->orWhere('status', 0);
                    } else {
                        $query->where('status', '!=', 2);
                    }
                })
                ->orderBy('staff_name', 'asc')
                ->get();

            $staff_list = $staff_list->unique('staff_id');

            // --- Loop staff for daily counts ---
            foreach ($staff_list as $staff) {

                if (!isset($staff_details[$staff->sno])) {
                    $staff_details[$staff->sno] = [];
                }

                $staff_details[$staff->sno] = [
                    'sno' => $staff->sno ?? 0,
                    'staff_name' => $staff->staff_name ?? 'None',
                    'staff_position' => $position->job_position_name ?? 'None',
                    'staff_full_name' => $staff->staff_name . ' (' . $position->job_position_name . ')' ?? 'None',
                ];
            }
        }

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => array_values($staff_details)
        ], 200);
    }

    public function GetFacultyAttendanceDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];
            $deptSummary = [];

            $attendanceTypes = StaffAttendanceModel::distinct()->pluck('attendance')->toArray();
            ;

            // --- Fetch job positions (departments) ---
            $departments = DB::table('za_department')
                ->where('status', '!=', 2)
                ->orderBy('department_name', 'asc')
                ->get();

            if ($departments->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            // --- Fetch staff list ---
            $staff_query = DB::table('za_staff')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
                ->where('za_staff.branch_id', $branch_id)
                ->whereIn('za_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 5)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 6)
                                ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 7)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('za_staff.status', 0);
                });
            } else {
                $staff_query->where('za_staff.status', '!=', 2);
            }

            if (!empty($search_lead_src_fill)) {
                $staff_query->whereIn('za_staff.sno', $search_lead_src_fill);
            }

            $staff_list = $staff_query->orderBy('za_staff.staff_name', 'asc')->get([
                'za_staff.*',
                'za_user_role.role_name',
                'za_job_position.job_position_name'
            ]);

            if ($staff_list->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => [],
                    'total_departments' => 0
                ];
            }

            $staffIds = $staff_list->pluck('sno')->toArray();

            // ✅ Department summary
            $deptSummary = $staff_list->groupBy('department_id')->map(function ($group, $deptId) {
                return [
                    'department_id' => $deptId,
                    'department_name' => $this->getDepartmentName($deptId),
                    'staff_count' => $group->count(),
                    'staff_list' => $group->map(fn($s) => [
                        'staff_id' => $s->sno,
                        'staff_name' => $s->staff_name,
                        'staff_position' => (isset($s->job_position_name) && !empty($s->job_position_name) ? $s->job_position_name : (isset($s->role_name) && !empty($s->role_name) ? $s->role_name : 'None')),
                        'doj' => !empty($s->date_of_joining) ? $s->date_of_joining : null,
                        'exist_status' => in_array($s->status, [4, 5, 6, 7]),
                        'exist_date' => match ($s->status) {
                            4 => $s->notice_end_date,
                            5 => $s->updated_at,
                            6 => $s->staff_last_date,
                            7 => $s->updated_at,
                            default => null,
                        },
                    ])->values(),
                ];
            })->values()->toArray();

            // --- Fetch attendance data in bulk ---
            $attendances = DB::table('za_staff_attendance')
                ->where('branch_id', $branch_id)
                ->whereIn('staff_id', $staffIds)
                ->whereDate('date', '<=', $currentDate)
                ->select('staff_id', 'date', 'attendance')
                ->get();

            if ($attendances->isEmpty()) {
                return [
                    'daily' => [],
                    'monthly' => [],
                    'yearly' => [],
                    'years' => [],
                    'dept_summary' => $deptSummary,
                    'total_departments' => count($deptSummary)
                ];
            }

            // --- Group attendance by staff ---
            $attGroup = $attendances->groupBy('staff_id');

            // --- Build daily, monthly, yearly data ---
            foreach ($staff_list as $staff) {
                $sid = $staff->sno;
                $dept = $staff->department_id;
                $records = $attGroup[$sid] ?? collect();

                foreach ($records as $att) {
                    $y = (int) date('Y', strtotime($att->date));
                    $m = (int) date('n', strtotime($att->date));
                    $d = (int) date('j', strtotime($att->date));
                    $years[$y] = $y;

                    // ✅ Daily data
                    $dailyRef = &$dailyData[$dept][$sid][$y][$m][$d];
                    if (!isset($dailyRef)) {
                        $dailyRef = array_fill_keys($attendanceTypes, 0);
                        $dailyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $dailyRef[$att->attendance]++;
                    }

                    $dailyRef['total_attendance'] = ((int) $dailyRef['P'] ?? 0) + ((int) $dailyRef['HD'] ?? 0);

                    // ✅ Monthly data
                    $monthlyRef = &$monthlyData[$dept][$sid][$y][$m];
                    if (!isset($monthlyRef)) {
                        $monthlyRef = array_fill_keys($attendanceTypes, 0);
                        $monthlyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $monthlyRef[$att->attendance]++;
                    }
                    $monthlyRef['total_attendance'] = ((int) $monthlyRef['P'] ?? 0) + ((int) $monthlyRef['HD'] ?? 0);

                    // ✅ Yearly data
                    $yearlyRef = &$yearlyData[$dept][$sid][$y];
                    if (!isset($yearlyRef)) {
                        $yearlyRef = array_fill_keys($attendanceTypes, 0);
                        $yearlyRef['total_attendance'] = 0;
                    }
                    if (in_array($att->attendance, $attendanceTypes)) {
                        $yearlyRef[$att->attendance]++;
                    }
                    $yearlyRef['total_attendance'] = ((int) $yearlyRef['P'] ?? 0) + ((int) $yearlyRef['HD'] ?? 0);
                }
            }

            // --- Monthly ---
            foreach ($monthlyData as $deptId => &$deptStaffs) {
                foreach ($deptStaffs as $staffId => &$yearsData) {
                    foreach ($yearsData as $year => &$monthsData) {
                        foreach ($monthsData as $month => &$mdata) {
                            // totalDays includes P
                            $totalDays = array_sum(array_intersect_key($mdata, array_flip($attendanceTypes)));
                            $P = ((int) $mdata['P'] ?? 0) + ((int) $mdata['HD'] ?? 0);

                            $mdata['present_percent'] = $totalDays > 0
                                ? round(($P / $totalDays) * 100, 2)
                                : 0;
                        }
                    }
                }
            }

            // --- Yearly ---
            foreach ($yearlyData as $deptId => &$deptStaffs) {
                foreach ($deptStaffs as $staffId => &$yearsData) {
                    foreach ($yearsData as $year => &$ydata) {
                        $totalDays = array_sum(array_intersect_key($ydata, array_flip($attendanceTypes)));
                        $P = ((int) $ydata['P'] ?? 0) + ((int) $ydata['HD'] ?? 0);

                        $ydata['present_percent'] = $totalDays > 0
                            ? round(($P / $totalDays) * 100, 2)
                            : 0;
                    }
                }
            }

            // --- Sort for consistent output ---
            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'daily' => $dailyData,
                'monthly' => $monthlyData,
                'yearly' => $yearlyData,
                'years' => array_values($years),
                'dept_summary' => $deptSummary,
                'total_departments' => count($deptSummary)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyAttendanceDetails: " . $e->getMessage());
            return null;
        }
    }

    private function getYearBasedMonths($year, $type = 1)
    {

        $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December'
        ];

        if ($type == 2) {
            $months = [
                1 => 'Jan',
                2 => 'Feb',
                3 => 'Mar',
                4 => 'Apr',
                5 => 'May',
                6 => 'Jun',
                7 => 'Jul',
                8 => 'Aug',
                9 => 'Sep',
                10 => 'Oct',
                11 => 'Nov',
                12 => 'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function ($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl(' . $hue . ', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if ($count > 0) {
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl(' . $hue . ', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text)
    {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getDepartmentName($id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['department_name'])) {
            self::$temp['department_name'] = [];
        }
        // Check if the id is already cached
        if (!isset(self::$temp['department_name'][$id])) {
            $state = DB::table('za_department')->select('department_name')->where('sno', $id)->first();
            self::$temp['department_name'][$id] = $state ? $state->department_name : null;
        }
        return self::$temp['department_name'][$id];
    }

    public function get_all_department_wise_staff(Request $request)
    {
        try {
            $user = $request->user();
            $branch_id = $user->branch_id;
            $is_existing_val = $request->filled('checked_val') ? (int) $request->checked_val : 2;

            $currentDate = date('Y-m-d');
            $currentYear = (int) date('Y');
            $currentMonth = (int) date('n');

            // ✅ Sorted department list
            $departments = DB::table('za_department')
                ->where('status', '!=', 2)
                ->orderBy('department_name', 'asc')
                ->get();

            if ($departments->isEmpty()) {
                return response([
                    'status' => 200,
                    'message' => 'list retrieved successfully.',
                    'error_msg' => null,
                    'data' => [
                        [
                            'option_group_name' => 'Unknown Group Name',
                            'option_group_id' => null,
                            'options' => []
                        ]
                    ]
                ], 200);
            }

            $departmentIds = $departments->pluck('sno')->toArray();

            $staff_query = DB::table('za_staff')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->where('za_staff.branch_id', $branch_id)
                ->whereIn('za_staff.department_id', $departmentIds);

            if ($is_existing_val == 2) {
                $staff_query->where(function ($query) use ($currentYear, $currentMonth) {
                    $query->where(function ($q) use ($currentYear, $currentMonth) {
                        $q->where('za_staff.status', 4)
                            ->whereYear('za_staff.notice_end_date', '>=', $currentYear)
                            ->whereMonth('za_staff.notice_end_date', '>=', $currentMonth);
                    })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 5)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 6)
                                ->whereYear('za_staff.staff_last_date', '>=', $currentYear)
                                ->whereMonth('za_staff.staff_last_date', '>=', $currentMonth);
                        })
                        ->orWhere(function ($q) use ($currentYear, $currentMonth) {
                            $q->where('za_staff.status', 7)
                                ->whereYear('za_staff.updated_at', '>=', $currentYear)
                                ->whereMonth('za_staff.updated_at', '>=', $currentMonth);
                        })
                        ->orWhere('za_staff.status', 0);
                });
            } else {
                $staff_query->where('za_staff.status', '!=', 2);
            }

            $staff_list = $staff_query
                ->orderBy('za_staff.staff_name', 'asc')
                ->get([
                    'za_staff.sno',
                    'za_staff.staff_name',
                    'za_staff.department_id',
                    'za_staff.date_of_joining',
                    'za_user_role.role_name'
                ]);

            // ✅ Group staff by department
            $data = [];
            foreach ($departments as $dept) {

                $dept_staff = $staff_list->where('department_id', $dept->sno)->map(function ($s) {
                    return [
                        'value' => $s->sno,
                        'label' => $s->staff_name . ' (' . $s->role_name . ')',
                        'date_of_joining' => $s->date_of_joining
                    ];
                })->values();

                if (!$dept_staff->isEmpty()) {
                    $data[] = [
                        'option_group_name' => $dept->department_name,
                        'option_group_id' => $dept->sno,
                        'options' => $dept_staff
                    ];
                }
            }

            return response([
                'status' => 200,
                'message' => 'list retrieved successfully.',
                'error_msg' => null,
                'data' => $data
            ], 200);

        } catch (\Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Failed to fetch list.',
                'error_msg' => $e->getMessage(),
                'data' => []
            ], 500);
        }
    }

    private function getDaysWithoutSundays($month, $year)
    {

        $totalDays = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Total days in the month
        $daysWithoutSundays = 0;

        for ($day = 1; $day <= $totalDays; $day++) {
            $date = "$year-$month-$day";
            if (date('w', strtotime($date)) != 0) { // Check if the day is not Sunday (0 represents Sunday)
                $daysWithoutSundays++;
            }
        }

        return $daysWithoutSundays;
    }
}
