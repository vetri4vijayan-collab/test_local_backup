<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\DropReasonModel;
use App\Models\LeadTypeModel;
use App\Models\LeadSourceModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;

class CustomerReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.course_package_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);

    }

    public function CusYearlyData(Request $request)
    {
        try {

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            // $years = range(2022, date('Y'));

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $currentMonth = date('n');
            $currentYear = date('Y');

            // Get lead years
            $leadYears = DB::table('za_training')
                    ->where('za_training.branch_id', $branch_id)
                    // ->where('za_training.customer_id', $cust_data->sno)
                    ->select(DB::raw('YEAR(za_training.created_at) as year'))
                    ->where('za_training.status', 0)
                    ->distinct()
                    ->pluck('year');

            $allYears = $leadYears->unique()->sort()->values();
            
            $out_Years = $allYears->sort()->values()->toArray();
            
            $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
            $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)
            
            $year_string = $firstYear.$lastYear;
            
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }
            
            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];
            
            $years = $allYears->toArray();

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $cust = DB::table('za_customer')
                ->select('za_customer.*')
                ->whereIn('za_customer.status', [0, 6])
                ->where('za_customer.branch_id', $branch_id)
                ->get();
            

            $customerData_count_details = [];
            $customerData_course_type_list = [];

            $pre_customerData_count_details = [];

            if (!$cust->isEmpty()) {

                foreach ($finalYears as $year_num) {

                    $tesbo_count = 0;

                    foreach ($cust as $cust_data) {
                        
                        $training_data = DB::table('za_training')
                                        ->select(
                                            'za_training.tesbo_check',
                                            DB::raw("GROUP_CONCAT(za_training.course_id ORDER BY za_training.course_id SEPARATOR ',') AS course_id"),
                                            DB::raw('MONTH(za_training.created_at) as train_month')
                                        )
                                        ->where('za_training.branch_id', $branch_id)
                                        ->where('za_training.status', 0)
                                        ->whereYear('za_training.created_at', $year_num)
                                        ->where('za_training.customer_id', $cust_data->sno)
                                        ->groupBy('za_training.tesbo_check','za_training.training_id', DB::raw('MONTH(za_training.created_at)'))
                                        ->get();

                        foreach ($training_data as $training) {

                            $train_month = $training->train_month ?? date('n');
                            
                            $train_tesbo_check = isset($training->tesbo_check) && !empty($training->tesbo_check) && ($training->tesbo_check == '2') ? 2 : 0;

                            $train_course_type_name = $this->getCouseTypeName($training->course_id) ?? 'Others';

                            $crs_type_key = ($train_tesbo_check == 2) ? 'tesbo_courses' : $this->slugify($train_course_type_name);
                            
                            $customerData_course_type_list[$crs_type_key] = $train_course_type_name;

                            $customerData_count_details[$year_num][$train_month][$crs_type_key]['cust_count'] =
                            ($customerData_count_details[$year_num][$train_month][$crs_type_key]['cust_count'] ?? 0) + 1;
                        }
                    }
                }
            }

            $query = CourseTypeModel::where('status', 0);
            
            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }
            
            // Use select instead of pluck
            $leadSources = $query->select('sno', 'course_type_name')->get(); // 10 per page
            
            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                $crs_type_key = $this->slugify($item->course_type_name);
                return [$crs_type_key => $item->course_type_name];
            })->toArray();
            
            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];
            
            if (!empty($leadSourcesMapped) && isset($leadSourcesMapped["add_on"])) {
                unset($leadSourcesMapped["add_on"]);
            }
            
            $packages_count = !empty($leadSourcesMapped) ? count($leadSourcesMapped) : 0;
            
            $packages = $leadSourcesMapped;

            $package_keys = !empty($leadSourcesMapped) ? array_keys($leadSourcesMapped) : [];

            $packageData   = [];
            $percentages   = [];
            $packageTotals = [];
            $monthwiseTotals = [];
            $monthTotals   = [];
            $yearTotals    = [];

            foreach ($finalYears as $year_num) {

                $yearTotals[$year_num] = 0;

                foreach ($months as $monthNum => $monthLabel) {

                    $monthTotal = 0;
                    $monthlyCounts = [];

                    foreach ($packages as $package_key => $package) {

                        // $count = rand(5, 50); // replace with DB query
                        $count = isset($customerData_count_details[$year_num][$monthNum][$package_key]['cust_count']) && !empty($customerData_count_details[$year_num][$monthNum][$package_key]['cust_count']) ? $customerData_count_details[$year_num][$monthNum][$package_key]['cust_count']: 0;

                        $monthlyCounts[$package_key] = $count;
                        $monthTotal += $count;

                        if (!isset($packageTotals[$year_num][$package_key])) {
                            $packageTotals[$year_num][$package_key] = 0;
                        }
                        $packageTotals[$year_num][$package_key] += $count;
                    }

                    $monthTotals[$year_num][$monthNum] = $monthTotal;
                    $yearTotals[$year_num] += $monthTotal;

                    foreach ($packages as $package_key => $package) {
                        
                        $packageData[$year_num][$monthNum][$package_key] = $monthlyCounts[$package_key] ?? 0;

                        $percentages[$year_num][$monthNum][$package_key] =
                        ($monthTotal > 0) ? round(($monthlyCounts[$package_key] / $monthTotal) * 100, 1) : 0;
                    }

                }
            }

            $grandTotals = []; // [monthNum] => total across all years
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {
                $grandTotals[$monthNum] = 0;
                foreach ($finalYears as $year_num) {
                    $grandTotals[$monthNum] += $monthTotals[$year_num][$monthNum] ?? 0;
                }
            }

            // Grand totals per package across all years
            $grandPackageTotals = []; // [package] => total across all years
            foreach ($packages as $package_key => $package) {
                $grandPackageTotals[$package_key] = 0;
                foreach ($finalYears as $year_num) {
                    $grandPackageTotals[$package_key] += $packageTotals[$year_num][$package_key] ?? 0;
                }
            }

            // ✅ Grand overall total (sum of either grandTotals or grandPackageTotals)
            $grandTotalAll = !empty($grandTotals) && is_array($grandTotals) ? array_sum($grandTotals) : 0; // or array_sum($grandPackageTotals)

            // Total per package for all years per month
            $packageMonthTotals = []; // [package][month] => total across all years
            $packageYearMonthTotals = []; // [package][month] => total across all years

            foreach ($packages as $package_key => $package) {
                foreach ($months as $monthNum => $monthName) {
                    $packageMonthTotals[$package_key][$monthNum] = 0;
                    foreach ($finalYears as $year_num) {
                        $packageYearMonthTotals[$year_num][$package_key][$monthNum] = 0;
                        $packageMonthTotals[$package_key][$monthNum] += $packageData[$year_num][$monthNum][$package_key] ?? 0;
                        $packageYearMonthTotals[$year_num][$package_key][$monthNum] += $packageData[$year_num][$monthNum][$package_key] ?? 0;
                    }
                }
            }
            
            $chartData = [];
            foreach ($packages as $package_key => $package) {
                $chartData[$package_key] = [];
                foreach ($finalYears as $year_num) {
                    $chartData[$package_key][] = $packageTotals[$year_num][$package_key] ?? 0;
                }
            }

            $package_colors = $this->generateAttractiveColors($package_keys);

            return response()->json([
                'months' => $months,
                'years' => $years,
                'packages' => $packages,
                'packageData' => $packageData,
                'percentages' => $percentages,
                'packageTotals' => $packageTotals,
                'monthTotals' => $monthTotals,
                'yearTotals' => $yearTotals,
                'grandTotals' => $grandTotals,
                'grandPackageTotals' => $grandPackageTotals,
                'grandTotalAll' => $grandTotalAll,
                'chartData' => $chartData,
                'packageMonthTotals' => $packageMonthTotals,
                'packageYearMonthTotals' => $packageYearMonthTotals,
                'package_colors' => $package_colors,
                'package_keys' => $package_keys,
                'year_string' => $year_string,
                'packages_count' => $packages_count
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function month_customer(Request $request)
    {
        $days = range(1, 31); // 01 to 31
        $currentMonth = date('n');
        $currentYear = date('Y');
        $months = $this->getYearBasedMonths($currentYear);

        return view('content.report_management.customer_report.course_package_list', compact(
            'days','months','currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusMonthlyData(Request $request)
    {
        try {

            $days = range(1,31);

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $currentMonth = date('n');
            $currentYear = date('Y');

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $months = $this->getYearBasedMonths($year);

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $cust = DB::table('za_customer')
                ->select('za_customer.*')
                ->whereIn('za_customer.status', [0, 6])
                ->where('za_customer.branch_id', $branch_id)
                ->get();

            $customerData_count_details = [];
            $customerData_course_type_list = [];

            $customerData_count_details[$currentMonth][$currentDay]['Others'] = [
                'cust_count' => 0,
                'drop_cust_count' => 0
            ];

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);
            $pre_customerData_count_details = [];

            $pre_customerData_count_details[12][$pre_daysInMonth] = [
                'cust_count' => 0,
                'drop_cust_count' => 0
            ];


            if (!$cust->isEmpty()) {

                foreach ($cust as $cust_data) {
                    
                    $training_data = DB::table('za_training')
                        ->select(
                            'za_training.tesbo_check',
                            DB::raw("GROUP_CONCAT(za_training.course_id ORDER BY za_training.course_id SEPARATOR ',') AS course_id"),
                            DB::raw('MONTH(za_training.created_at) as train_month'),
                            DB::raw('DAY(za_training.created_at) as train_day')
                        )
                        ->where('za_training.branch_id', $branch_id)
                        ->where('za_training.status', 0)
                        ->whereYear('za_training.created_at', $year)
                        ->where('za_training.customer_id', $cust_data->sno)
                        ->groupBy('za_training.tesbo_check','za_training.training_id', DB::raw('MONTH(za_training.created_at)'), DB::raw('DAY(za_training.created_at)'))
                        ->get();

                    foreach ($training_data as $training) {

                        $train_month = $training->train_month ?? date('n');
                        $train_day = $training->train_day ?? date('j');

                        $train_course_type_name = $this->getCouseTypeName($training->course_id) ?? 'Others';

                        $train_tesbo_check = isset($training->tesbo_check) && !empty($training->tesbo_check) && ($training->tesbo_check == '2') ? 2 : 0;

                        $crs_type_key = ($train_tesbo_check == 2) ? 'tesbo_courses' : $this->slugify($train_course_type_name);

                        $customerData_course_type_list[$crs_type_key] = $train_course_type_name;

                        // ✅ Count customers (or training sessions) per day
                        $customerData_count_details[$train_month][$train_day][$crs_type_key]['cust_count'] = 
                            ($customerData_count_details[$train_month][$train_day][$crs_type_key]['cust_count'] ?? 0) + 1;

                    }

                    $pre_training_data = DB::table('za_training')
                        ->select(
                            'za_training.tesbo_check',
                            DB::raw("GROUP_CONCAT(za_training.course_id ORDER BY za_training.course_id SEPARATOR ',') AS course_id"),
                            DB::raw('MONTH(za_training.created_at) as train_month'),  DB::raw('DAY(za_training.created_at) as train_day')
                        )
                        ->where('za_training.branch_id', $branch_id)
                        ->where('za_training.status', 0)
                        ->whereYear('za_training.created_at', $pre_year)
                        ->whereMonth('za_training.created_at', 12)
                        ->whereDay('za_training.created_at', $pre_daysInMonth)
                        ->where('za_training.customer_id', $cust_data->sno)
                        ->groupBy('za_training.tesbo_check','za_training.training_id', DB::raw('MONTH(za_training.created_at)'), DB::raw('DAY(za_training.created_at)'))
                        ->get();

                    foreach ($pre_training_data as $pre_training) {

                        $pre_train_month = $pre_training->train_month ?? date('n');
                        $pre_train_day = $pre_training->train_day ?? date('j');
                        $pre_train_course_type_name = $this->getCouseTypeName($pre_training->course_id) ?? 'Others';

                        $pre_train_tesbo_check = isset($pre_training->tesbo_check) && !empty($pre_training->tesbo_check) && ($pre_training->tesbo_check == '2') ? 2 : 0;

                        $pre_crs_type_key = ($pre_train_tesbo_check == 2) ? 'tesbo_courses' : $this->slugify($pre_train_course_type_name);

                        // ✅ Count customers (or training sessions) per day
                        $pre_customerData_count_details[$pre_train_month][$pre_train_day][$pre_crs_type_key]['cust_count'] = 
                            ($pre_customerData_count_details[$pre_train_month][$pre_train_day][$pre_crs_type_key]['cust_count'] ?? 0) + 1;
                    }
                }
            }

            $query = CourseTypeModel::where('status', 0);
            
            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }
            
            // Use select instead of pluck
            $leadSources = $query->select('sno', 'course_type_name')->get(); // 10 per page
            
            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                $crs_type_key = $this->slugify($item->course_type_name);
                return [$crs_type_key => $item->course_type_name];
            })->toArray();
            
            if (!empty($leadSourcesMapped) && isset($leadSourcesMapped["add_on"])) {
                unset($leadSourcesMapped["add_on"]);
            }

            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];
            $packages_count = !empty($leadSourcesMapped) ? count($leadSourcesMapped) : 0;

            $packages = $leadSourcesMapped;

            $packageData   = [];
            $pre_packageData   = [];
            $percentages   = [];
            $packageTotals = [];
            $dayTotals     = [];
            $daywiseTotals = [];
            $monthTotals   = [];

            foreach ($months as $monthNum => $monthLabel) {

                $monthTotals[$monthNum] = 0;

                foreach ($days as $day) {

                    $dayTotal = 0;
                    $dailyCounts = [];
                    $pre_dailyCounts = [];

                    foreach ($packages as $package_key => $package) {

                        // $count = rand(5, 50); // replace with DB query
                        $count = isset($customerData_count_details[$monthNum][$day][$package_key]['cust_count']) && !empty($customerData_count_details[$monthNum][$day][$package_key]['cust_count']) ? $customerData_count_details[$monthNum][$day][$package_key]['cust_count']: 0;

                        $pre_count = isset($pre_customerData_count_details[12][$pre_daysInMonth][$package_key]['cust_count']) && !empty($pre_customerData_count_details[12][$pre_daysInMonth][$package_key]['cust_count']) ? $pre_customerData_count_details[12][$pre_daysInMonth][$package_key]['cust_count']: 0;

                        $dailyCounts[$package_key] = $count;

                        $pre_dailyCounts[$package_key] = $pre_count;

                        $dayTotal += $count;

                        if (!isset($packageTotals[$monthNum][$package_key])) {
                            $packageTotals[$monthNum][$package_key] = 0;
                        }

                        $packageTotals[$monthNum][$package_key] += $count;
                    }

                    $dayTotals[$monthNum][$day] = $dayTotal;
                    $monthTotals[$monthNum] += $dayTotal;

                    if (!isset($daywiseTotals[$day])) {
                        $daywiseTotals[$day] = 0;
                    }

                    $daywiseTotals[$day] += $dayTotal;

                    foreach ($packages as $package_key => $package) {
                        
                        $packageData[$monthNum][$day][$package_key] = $dailyCounts[$package_key] ?? 0;

                        $pre_packageData[12][$pre_daysInMonth][$package_key] = $pre_dailyCounts[$package_key] ?? 0;

                        $percentages[$monthNum][$day][$package_key] = ($packageData[$monthNum][$day][$package_key] > 0) ? round(($packageData[$monthNum][$day][$package_key] / $packageTotals[$monthNum][$package_key]) * 100, 1) : 0;
                    }
                }
            }

            // return $percentages;
            // Grand totals per package across all months
            $grandPackageTotals = [];
            $chartSeries = [];
            $grandTotalAll = 0;
            foreach ($packages as $package_key => $package) {
                $grandPackageTotals[$package_key] = 0;
                $data = [];
                foreach ($months as $monthNum => $monthLabel) {
                    $grandPackageTotals[$package_key] += $packageTotals[$monthNum][$package_key] ?? 0;
                    $data[] = $packageTotals[$monthNum][$package_key] ?? 0;
                }
                $chartSeries[] = [
                    'name' => $package,
                    'data' => $data
                ];
                $grandTotalAll += $grandPackageTotals[$package_key] ?? 0;
            }

            // Prepare chart data
            $monthsShort = [
                1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr',
                5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug',
                9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
            ];

            $xLabels = [];
            foreach ($months as $monthNum => $monthLabel) {
                $xLabels[] = $monthsShort[$monthNum] ?? date('M');
            }

            return response()->json([
                'days' => $days,
                'months' => $months,
                'packages' => $packages,
                'packageData' => $packageData,
                'percentages' => $percentages,
                'packageTotals' => $packageTotals,
                'dayTotals' => $dayTotals,
                'daywiseTotals' => $daywiseTotals,
                'monthTotals' => $monthTotals,
                'grandPackageTotals' => $grandPackageTotals,
                'grandTotalAll' => $grandTotalAll,
                'chartSeries' => $chartSeries,
                'xLabels' => $xLabels,
                'pre_packageData' => $pre_packageData,
                'packages_count' => $packages_count
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function customer_drop()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_drop_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusDropYearlyData(Request $request)
    {
        try {

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            // $years = range(2022, date('Y'));

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $currentMonth = date('n');
            $currentYear = date('Y');

            // Get lead years
            $leadYears = DB::table('za_training')
                    ->where('za_training.branch_id', $branch_id)
                    // ->where('za_training.customer_id', $cust_data->sno)
                    ->select(DB::raw('YEAR(za_training.created_at) as year'))
                    ->where('za_training.status', 0)
                    ->distinct()
                    ->pluck('year');

            // Get conversion years
            $conversionYears = DB::table('za_drop_refund')
                            ->select(
                                DB::raw('YEAR(za_drop_refund.created_at) as year')
                            )
                            ->where([
                                ['za_drop_refund.type', '=', 0],
                                ['za_drop_refund.bh_status', '=', 1],
                                ['za_drop_refund.status', '=', 0],
                                ['za_drop_refund.branch_id', '=', $branch_id],
                                // ['za_drop_refund.training_id', '=', $pre_training->sno],
                                // ['za_drop_refund.customer_id', '=', $pre_training->customer_id],
                                // ['za_drop_refund.course_id', '=', $pre_training->course_id],
                            ])->distinct()->pluck('year');
            
                            
                            // Combine and get unique years
            $allYears = $leadYears->merge($conversionYears)->unique()->sort()->values();
            
            $out_Years = $allYears->sort()->values()->toArray();
            
            $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
            $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)
            
            $year_string = $firstYear.$lastYear;
            
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }
            
            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];

            
            $years = $allYears->toArray();
            
            $cust = DB::table('za_customer')
                ->select('za_customer.*')
                ->whereIn('za_customer.status', [0, 6])
                ->where('za_customer.branch_id', $branch_id)
                ->get();

            $customerData_count_details = [];

            $customerData = [];   // [year][month] => customer count
            $dropData     = [];   // [year][month] => drop count
            $yearlyCustomers = []; // [year] => total customers
            $yearlyDrops     = []; // [year] => total drops

            // Drop reasons
            $dropReasons = ['Price', 'Service', 'Competitor', 'Product Issue', 'Other'];
            $dropReasonData = []; // [reason][year][month] => count

            // 1️⃣ Populate per-year, per-month data

            if (!$cust->isEmpty()) {
                    
                foreach ($finalYears as $year_num) {

                    foreach ($cust as $cust_data) {

                            $training_data = DB::table('za_training')
                                            ->select(
                                                'za_training.tesbo_check',
                                                'za_training.customer_id',
                                                DB::raw("
                                                    GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
                                                        ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
                                                "),
                                                DB::raw("
                                                    GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
                                                        ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
                                                "),
                                                DB::raw("
                                                    GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
                                                        ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
                                                "),
                                                DB::raw("
                                                    GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
                                                        ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
                                                "),
                                                DB::raw('MONTH(za_training.created_at) as train_month')
                                            )
                                            ->where('za_training.branch_id', $branch_id)
                                            ->where('za_training.tesbo_check','!=',1)
                                            ->whereYear('za_training.created_at', $year_num)
                                            ->where('za_training.customer_id', $cust_data->sno)
                                            ->groupBy('za_training.tesbo_check','za_training.customer_id','za_training.training_id', DB::raw('MONTH(za_training.created_at)'))
                                            ->get();


                        foreach ($training_data as $training) {

                            $train_month = $training->train_month ?? date('n');

                            $active_training_ids = isset($training->active_training_ids) && !empty($training->active_training_ids) && is_string($training->active_training_ids) ? explode(',',$training->active_training_ids) : [];
                            $drop_training_ids = isset($training->drop_training_ids) && !empty($training->drop_training_ids) && is_string($training->drop_training_ids) ? explode(',',$training->drop_training_ids) : [];

                            $active_course_ids = isset($training->active_course_ids) && !empty($training->active_course_ids) && is_string($training->active_course_ids) ? explode(',',$training->active_course_ids) : [];
                            $drop_course_ids = isset($training->drop_course_ids) && !empty($training->drop_course_ids) && is_string($training->drop_course_ids) ? explode(',',$training->drop_course_ids) : [];

                            if(!empty($active_training_ids)){
                                $customerData_count_details[$year_num][$train_month]['cust_count'] = ($customerData_count_details[$year_num][$train_month]['cust_count'] ?? 0) + 1;
                                
                            }

                            // ✅ Fetch drop data
                            $drop_data = DB::table('za_drop_refund')
                                ->select(
                                    DB::raw('MONTH(za_drop_refund.created_at) as drop_month')
                                )
                                ->where([
                                    ['za_drop_refund.type', '=', 0],
                                    ['za_drop_refund.bh_status', '=', 1],
                                    ['za_drop_refund.status', '=', 0],
                                    ['za_drop_refund.branch_id', '=', $branch_id],
                                    ['za_drop_refund.customer_id', '=',$cust_data->sno],
                                ])
                                ->whereYear('za_drop_refund.created_at', $year_num)
                                ->whereIn('za_drop_refund.training_id', $drop_training_ids)
                                ->whereIn('za_drop_refund.course_id', $drop_course_ids)
                                ->get();

                            foreach ($drop_data as $drop) {
                                
                                $drop_month = $drop->drop_month ?? $train_month;

                                $customerData_count_details[$year_num][$drop_month]['drop_cust_count'] =
                                    ($customerData_count_details[$year_num][$drop_month]['drop_cust_count'] ?? 0) + 1;
                            }
                        }
                    }
                }
            }

            foreach ($finalYears as $year_index => $year) {

                if($year_index != 0){
                    $yearlyCustomers[$year] = 0;
                    $yearlyDrops[$year] = 0;
                }

                foreach ($months as $monthNum => $monthName) {

                    $customers = isset($customerData_count_details[$year][$monthNum]['cust_count']) && !empty($customerData_count_details[$year][$monthNum]['cust_count']) ? $customerData_count_details[$year][$monthNum]['cust_count']: 0;
                    $drops = isset($customerData_count_details[$year][$monthNum]['drop_cust_count']) && !empty($customerData_count_details[$year][$monthNum]['drop_cust_count']) ? $customerData_count_details[$year][$monthNum]['drop_cust_count']: 0;
                    // $drops = min($drops, $customers);

                    $customerData[$year][$monthNum] = $customers;
                    $dropData[$year][$monthNum]     = $drops;

                    if($year_index != 0){
                        $yearlyCustomers[$year] += $customers;
                        $yearlyDrops[$year]     += $drops;
                    }
                    
                    // Generate reason-wise drop counts (sum ≤ total drops)
                    // $remainingDrops = $drops;
                    // foreach ($dropReasons as $reason) {
                    //     if ($reason === end($dropReasons)) {
                    //         $dropReasonData[$reason][$year][$monthNum] = $remainingDrops;
                    //     } else {
                    //         $val = rand(0, $remainingDrops);
                    //         $dropReasonData[$reason][$year][$monthNum] = $val;
                    //         $remainingDrops -= $val;
                    //     }
                    // }
                }
            }

            // 2️⃣ Calculate month totals across all years
            $monthTotals = []; // [month] => ['customers'=>0,'drops'=>0]
            foreach ($months as $monthNum => $monthName) {

                $monthTotals[$monthNum]['customers'] = 0;
                $monthTotals[$monthNum]['drops']     = 0;

                foreach ($finalYears as $year_index => $year) {
                    if($year_index != 0){
                        $monthTotals[$monthNum]['customers'] += $customerData[$year][$monthNum] ?? 0;
                        $monthTotals[$monthNum]['drops']     += $dropData[$year][$monthNum] ?? 0;
                    }
                }
            }

            // 3️⃣ Calculate drop percentages per year per month
            $dropPercent = [];
            foreach ($finalYears as $year_index => $year) {

                foreach ($months as $monthNum => $monthName) {

                    $customers = $customerData[$year][$monthNum] ?? 0;
                    $drops     = $dropData[$year][$monthNum] ?? 0;

                    if($year_index != 0){

                        $drop_percent = ($customers > 0) ? round(($drops / $customers) * 100, 1) : 0;
                        $dropPercent[$year][$monthNum] = ((int)$drop_percent > 100) ? 100 : (int)$drop_percent;
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'months' => $months ?? null,
                'currentYear' => $currentYear ?? null,
                'currentMonth' => $currentMonth ?? null,
                'months' => $months ?? null,
                'years' => $years ?? null,
                'customerData' => $customerData ?? null,
                'dropData' => $dropData ?? null,
                'dropPercent' => $dropPercent ?? null,
                'yearlyCustomers' => $yearlyCustomers ?? null,
                'yearlyDrops' => $yearlyDrops ?? null,
                'dropReasons' => $dropReasons ?? null,
                'dropReasonData' => $dropReasonData ?? null,
                'year_string' => !empty($year_string) ? $year_string : null,
                'year_colors' => !empty($year_colors) ? $year_colors : null,
                'monthTotals' => $monthTotals ?? null
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_drop_monthly(Request $request)
    {
        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');

        return view('content.report_management.customer_report.customer_drop_list', compact('days','year','yearShort'))->with('report_heading', self::$report_heading);
    }

    public function CusDropMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $months = $this->getYearBasedMonths($year);

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $cust = DB::table('za_customer')
                ->select('za_customer.*')
                ->whereIn('za_customer.status', [0, 6])
                ->where('za_customer.branch_id', $branch_id)
                ->get();

            $customerData_count_details = [];

            $customerData_drop_count_details = [];

            $customerData_count_details[$currentMonth][$currentDay] = [
                'cust_count' => 0,
                'drop_cust_count' => 0
            ];
            
            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);
            $pre_customerData_count_details = [];

            $pre_customerData_count_details[12][$pre_daysInMonth] = [
                'cust_count' => 0,
                'drop_cust_count' => 0
            ];


            $customerData = [];
            $customerTrendData = [];
            $dropTrendData = [];
            $pre_customerData = [];
            $dropData = [];
            $pre_dropData = [];
            $dropPercent = [];
            $monthTotals = [];
            $grandTotals = [
                'customers' => [],
                'drops'     => [],
            ];

            $dropReasonData = [];
            $dropReasons = [];

            if (!$cust->isEmpty()) {
                
                foreach ($cust as $cust_data) {
                    
                    $training_data = DB::table('za_training')
                                        ->select(
                                            'za_training.tesbo_check',
                                            'za_training.customer_id',
                                            DB::raw("
                                                GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
                                                    ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
                                            "),
                                            DB::raw("
                                                GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
                                                    ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
                                            "),
                                            DB::raw("
                                                GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
                                                    ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
                                            "),
                                            DB::raw("
                                                GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
                                                    ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
                                            "),
                                            DB::raw('MONTH(za_training.created_at) as train_month'),
                                            DB::raw('DAY(za_training.created_at) as train_day')
                                        )
                                        ->where('za_training.branch_id', $branch_id)
                                        ->whereYear('za_training.created_at', $year)
                                        ->where('za_training.customer_id', $cust_data->sno)
                                        ->where('za_training.tesbo_check','!=',1)
                                        ->groupBy(
                                            'za_training.tesbo_check',
                                            'za_training.customer_id',
                                            'za_training.training_id',
                                            DB::raw('MONTH(za_training.created_at)'),
                                            DB::raw('DAY(za_training.created_at)')
                                        )
                                        ->get();

                    foreach ($training_data as $training) {

                        $train_month = $training->train_month ?? date('n');
                        $train_day = $training->train_day ?? date('j');
                        
                        $active_training_ids = isset($training->active_training_ids) && !empty($training->active_training_ids) && is_string($training->active_training_ids) ? explode(',',$training->active_training_ids) : [];
                        $drop_training_ids = isset($training->drop_training_ids) && !empty($training->drop_training_ids) && is_string($training->drop_training_ids) ? explode(',',$training->drop_training_ids) : [];

                        $active_course_ids = isset($training->active_course_ids) && !empty($training->active_course_ids) && is_string($training->active_course_ids) ? explode(',',$training->active_course_ids) : [];
                        $drop_course_ids = isset($training->drop_course_ids) && !empty($training->drop_course_ids) && is_string($training->drop_course_ids) ? explode(',',$training->drop_course_ids) : [];

                        if(!empty($active_training_ids)){
                            // ✅ Count customers (or training sessions) per day
                            $customerData_count_details[$train_month][$train_day]['cust_count'] = 
                                ($customerData_count_details[$train_month][$train_day]['cust_count'] ?? 0) + 1;
                        }

                        // $customerData_drop_count_details[$cust_data->sno] = $training;

                        // $customerData_count_details[$train_month][$train_day][] = $training;

                        // ✅ Fetch drop data
                        $drop_data = DB::table('za_drop_refund')
                            ->select(
                                'za_drop_refund.*',
                                DB::raw('MONTH(za_drop_refund.created_at) as drop_month'),
                                DB::raw('DAY(za_drop_refund.created_at) as drop_day')
                            )
                            ->where([
                                ['za_drop_refund.type', '=', 0],
                                ['za_drop_refund.bh_status', '=', 1],
                                ['za_drop_refund.status', '=', 0],
                                ['za_drop_refund.branch_id', '=', $branch_id],
                                ['za_drop_refund.customer_id', '=', $cust_data->sno],
                            ])
                            ->whereYear('za_drop_refund.created_at', $year)
                            ->whereIn('za_drop_refund.training_id', $drop_training_ids)
                            ->whereIn('za_drop_refund.course_id', $drop_course_ids)
                            ->get();
                        

                        foreach ($drop_data as $drop) {
                            
                            $drop_month = $drop->drop_month ?? 0;
                            $drop_day = $drop->drop_day ?? 0;

                            // $drop_refund_reason = $drop->drop_refund_reason ?? 'others';
                            
                            // $key = $this->slugify($drop_refund_reason);

                            // $dropReasonData[$key][$drop_month][$drop_day] = ($dropReasonData[$key][$drop_month][$drop_day] ?? 0) + 1;

                            // $dropReasons[$key] = $drop_refund_reason;

                            
                            $customerData_count_details[$drop_month][$drop_day]['drop_cust_count'] =
                                ($customerData_count_details[$drop_month][$drop_day]['drop_cust_count'] ?? 0) + 1;
                        }
                    }

                    $pre_training_data = DB::table('za_training')
                        ->select(
                            'za_training.tesbo_check',
                            'za_training.customer_id',
                            DB::raw("
                                GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.sno END 
                                    ORDER BY za_training.sno SEPARATOR ',') AS active_training_ids
                            "),
                            DB::raw("
                                GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.sno END 
                                    ORDER BY za_training.sno SEPARATOR ',') AS drop_training_ids
                            "),
                            DB::raw("
                                GROUP_CONCAT(CASE WHEN za_training.status = 0 THEN za_training.course_id END 
                                    ORDER BY za_training.course_id SEPARATOR ',') AS active_course_ids
                            "),
                            DB::raw("
                                GROUP_CONCAT(CASE WHEN za_training.status = 2 THEN za_training.course_id END 
                                    ORDER BY za_training.course_id SEPARATOR ',') AS drop_course_ids
                            "),
                            DB::raw('MONTH(za_training.created_at) as train_month'),
                            DB::raw('DAY(za_training.created_at) as train_day')
                        )
                        ->where('za_training.branch_id', $branch_id)
                        // ->where('za_training.status', 0)
                        ->whereYear('za_training.created_at', $pre_year)
                        ->whereMonth('za_training.created_at', 12)
                        ->whereDay('za_training.created_at', $pre_daysInMonth)
                        ->where('za_training.customer_id', $cust_data->sno)
                        ->where('za_training.tesbo_check','!=',1)
                        ->groupBy(
                            'za_training.tesbo_check','za_training.customer_id','za_training.training_id', DB::raw('MONTH(za_training.created_at)'),DB::raw('DAY(za_training.created_at)')
                        )
                        ->get();

                    foreach ($pre_training_data as $pre_training) {

                        $pre_train_month = $pre_training->train_month ?? date('n');
                        $pre_train_day = $pre_training->train_day ?? date('j');

                        $pre_active_training_ids = isset($pre_training->active_training_ids) && !empty($pre_training->active_training_ids) && is_string($pre_training->active_training_ids) ? explode(',',$pre_training->active_training_ids) : [];
                        $pre_drop_training_ids = isset($pre_training->drop_training_ids) && !empty($pre_training->drop_training_ids) && is_string($pre_training->drop_training_ids) ? explode(',',$pre_training->drop_training_ids) : [];

                        $pre_active_course_ids = isset($pre_training->active_course_ids) && !empty($pre_training->active_course_ids) && is_string($pre_training->active_course_ids) ? explode(',',$pre_training->active_course_ids) : [];
                        $pre_drop_course_ids = isset($pre_training->drop_course_ids) && !empty($pre_training->drop_course_ids) && is_string($pre_training->drop_course_ids) ? explode(',',$pre_training->drop_course_ids) : [];

                        if(!empty($pre_active_training_ids)){
                            // ✅ Count customers (or training sessions) per day
                            $pre_customerData_count_details[$pre_train_month][$pre_train_day]['cust_count'] = 
                                ($pre_customerData_count_details[$pre_train_month][$pre_train_day]['cust_count'] ?? 0) + 1;
                        }

                        // ✅ Fetch drop data
                        $pre_drop_data = DB::table('za_drop_refund')
                            ->select(
                                DB::raw('MONTH(za_drop_refund.created_at) as drop_month'),
                                DB::raw('DAY(za_drop_refund.created_at) as drop_day')
                            )
                            ->where([
                                ['za_drop_refund.type', '=', 0],
                                ['za_drop_refund.bh_status', '=', 1],
                                ['za_drop_refund.status', '=', 0],
                                ['za_drop_refund.branch_id', '=', $branch_id],
                                ['za_drop_refund.customer_id', '=', $pre_training->customer_id]
                            ])
                            ->whereYear('za_drop_refund.created_at', $pre_year)
                            ->whereMonth('za_drop_refund.created_at', 12)
                            ->whereDay('za_drop_refund.created_at', $pre_daysInMonth)
                            ->whereIn('za_drop_refund.training_id', $pre_drop_training_ids)
                            ->whereIn('za_drop_refund.course_id', $pre_drop_course_ids)
                            ->get();

                        foreach ($pre_drop_data as $pre_drop) {
                            
                            $pre_drop_month = $pre_drop->drop_month ?? $train_month;
                            $pre_drop_day = $pre_drop->drop_day ?? $train_day;

                            $pre_customerData_count_details[$pre_drop_month][$pre_drop_day]['drop_cust_count'] =
                                ($pre_customerData_count_details[$pre_drop_month][$pre_drop_day]['drop_cust_count'] ?? 0) + 1;
                        }
                    }
                }

                // return $customerData_drop_count_details;
            }
            
            foreach ($months as $monthNum => $monthName) {

                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);
                
                for ($day = 1; $day <= 31; $day++) {
                    
                    $date_format = date('d-m-Y',strtotime($day.'-'.$monthNum.'-'.$year));

                    if (($monthNum == $currentMonth && $day > $currentDay) || $day > $daysInMonth) {
                        $customers = 0;
                        $drops = 0;
                    } else {
                        $customers = isset($customerData_count_details[$monthNum][$day]['cust_count']) && !empty($customerData_count_details[$monthNum][$day]['cust_count']) ? $customerData_count_details[$monthNum][$day]['cust_count']: 0;
                        $drops = isset($customerData_count_details[$monthNum][$day]['drop_cust_count']) && !empty($customerData_count_details[$monthNum][$day]['drop_cust_count']) ? $customerData_count_details[$monthNum][$day]['drop_cust_count']: 0;
                        // $drops = min($drops, $customers);
                    }
                    
                    $customerData[$monthNum][$day] = $customers;
                    $customerTrendData[$monthName][] = ['date'=>$date_format,'customer'=>$customers];
                    
                    $pre_customerData[12][$pre_daysInMonth] = isset($pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']) && !empty($pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']) ? $pre_customerData_count_details[12][$pre_daysInMonth]['cust_count']: 0;

                    $dropData[$monthNum][$day] = $drops;
                    $dropTrendData[$monthName][] = ['date'=>$date_format,'drop'=>$drops];
                    
                    $pre_dropData[12][$pre_daysInMonth] = isset($pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']) && !empty($pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']) ? $pre_customerData_count_details[$monthNum][$pre_daysInMonth]['cust_count']: 0;
                    
                    $drop_percent = ($customers > 0) ? round(($drops / $customers) * 100, 1) : 0;
                    $dropPercent[$monthNum][$day] = ((int)$drop_percent > 100) ? 100 : (int)$drop_percent;
                    
                    $monthTotals[$monthNum]['customers'] = ($monthTotals[$monthNum]['customers'] ?? 0) + $customers;
                    $monthTotals[$monthNum]['drops'] = ($monthTotals[$monthNum]['drops'] ?? 0) + $drops;

                    $grandTotals['customers'][$day] = ($grandTotals['customers'][$day] ?? 0) + $customers;
                    $grandTotals['drops'][$day] = ($grandTotals['drops'][$day] ?? 0) + $drops;
                }
            }
            
            $reasonColors = $this->generateLeadSourceAttractiveColors($dropReasons);
            
            // foreach ($months as $monthNum => $monthName) {
            //     $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);
            //     foreach ($dropReasons as $reason) {
            //         for ($day = 1; $day <= $daysInMonth; $day++) {
            //             $dropCount = DB::table('za_drop_refund')
            //                         ->select('za_drop_refund.sno')
            //                         ->where([
            //                             ['za_drop_refund.type', '=', 0],
            //                             ['za_drop_refund.bh_status', '=', 1],
            //                             ['za_drop_refund.status', '=', 0],
            //                             ['za_drop_refund.branch_id', '=', $branch_id]
            //                             // ['za_drop_refund.training_id', '=', $training->sno],
            //                             // ['za_drop_refund.customer_id', '=', $training->customer_id],
            //                             // ['za_drop_refund.course_id', '=', $training->course_id],
            //                         ])
            //                         ->whereYear('za_drop_refund.created_at', $year)
            //                         ->where('za_drop_refund.drop_refund_reason', 'LIKE', "%{$reason}%")
            //                         ->whereMonth('za_drop_refund.created_at', $monthNum)
            //                         ->whereDay('za_drop_refund.created_at', $day)
            //                         ->count();
            //             $dropReasonData[$reason][$monthNum][$day] = $dropCount ?? 0;
            //         }
            //     }
            // }

            return response()->json([
                'months' => $months ?? null,
                'year' => $year ?? null,
                'currentYear' => $currentYear ?? null,
                'currentMonth' => $currentMonth ?? null,
                'currentDay' => $currentDay ?? null,
                'customerData' => $customerData ?? null,
                'dropData' => $dropData ?? null,
                'pre_customerData' => $pre_customerData ?? null,
                'pre_dropData' => $pre_dropData ?? null,
                'dropPercent' => $dropPercent ?? null,
                'monthTotals' => $monthTotals ?? null,
                'customerTrendData' => $customerTrendData ?? null,
                'dropTrendData' => $dropTrendData ?? null,
                'grandTotals' => $grandTotals ?? null,
                'dropReasons' => $dropReasons ?? null,
                'dropReasonData' => $dropReasonData ?? null,
                'reasonColors' => $reasonColors ?? null
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_src_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_src_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusSrcYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                $filterDate = $selected_year . '-' .'01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadSourceModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'lead_source_name')->orderBy('lead_source_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_source_name];
            })->toArray();
            
            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $MonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $MonthTotal = 0;

                foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {

                    //Fetch conversions count
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                    })->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', (int)$monthNum)
                    ->where('za_customer.status', 0)
                    ->count();

                    $count = (int) $conversions_detail_modal;

                    // $count = rand(5, 50); // Replace with DB query

                    $leadData[$monthName][$leadSource] = $count;
                    $MonthTotal += $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    $day_query = false;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $day_query = true;
                    }
                    
                    $pre_count = 0;

                    if($day_query){

                        $pre_months = $this->getYearBasedMonths($prevYear);
                        
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                            $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                        })->whereYear('za_customer.created_at', $prevYear)
                        ->whereMonth('za_customer.created_at', (int)$prevMonth)
                        ->where('za_customer.status', 0)
                        ->count();

                        // $pre_count = rand(5, 50);

                        $pre_count = (int)$prev_conversion_detail ?? 0;

                        $preleadData[$pre_months[12]][$leadSource] = $pre_count;
                    }
                    
                    if (!isset($sourceTotals[$leadSource])) $sourceTotals[$leadSource] = 0;
                    $sourceTotals[$leadSource] += $count;
                }

                $MonthTotals[$monthName] = $MonthTotal;
                $grandTotalAll += $MonthTotal;

                // Calculate percentages
            }

            $sourceTrends = [];
            foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {
                $source_totals = $sourceTotals[$leadSource] ?? 0;
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $percentages[$monthName][$leadSource] = ($source_totals > 0)
                    ? round(($leadData[$monthName][$leadSource] / $source_totals) * 100, 1)
                    : 0;
                    $trend[] = $leadData[$monthName][$leadSource] ?? 0;
                }
                $sourceTrends[$leadSource] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadSources_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'months' => $months,
                'leadSources' => $leadSources_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'MonthTotals' => $MonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_src_monthly()
    {
        $currentMonth = date('n');
        $currentYear = date('Y');
        $currentDay = date('j');

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_src_list', [
            'currentMonth' => $currentMonth,
            'currentYear' => $currentYear,
            'currentDay' => $currentDay,
            'months' => $months
        ])->with('report_heading', self::$report_heading);
    }

    public function CusSrcMonthlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadSourceModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'lead_source_name')->orderBy('lead_source_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_source_name];
            })->toArray();
            
            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $grandTotalAll = 0;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($days as $day) {

                $dayTotal = 0;

                foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {

                    //Fetch conversions count
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                    })->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', (int)$querycurrentMonth)
                    ->whereDay('za_customer.created_at', $day)
                    ->where('za_customer.status', 0)
                    ->count();

                    $count = (int) $conversions_detail_modal;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$leadSource] = $count;
                    $dayTotal += $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = 0;

                    if($day_query){
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::select('za_customer.sno')
                        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.status', 4)->where('za_lead.spam_verified',0)
                        ->where('za_lead.branch_id', $branch_id)->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.created_by', '>', 0)
                        ->whereRaw('YEAR(za_customer.created_at) = ?', [$prevYear])
                        ->whereRaw('MONTH(za_customer.created_at) = ?', [$prevMonth])
                        ->whereRaw('DAY(za_customer.created_at) = ?', [$prevDay])
                        ->where('za_customer.status', 0)
                        ->count();
                        $pre_count = (int)$prev_conversion_detail ?? 0;
                    }

                    $preleadData[$prevDay][$leadSource] = $pre_count;
                    
                    if (!isset($sourceTotals[$leadSource])) $sourceTotals[$leadSource] = 0;
                    $sourceTotals[$leadSource] += $count;
                }

                $dayTotals[$day] = $dayTotal;
                $grandTotalAll += $dayTotal;

                // Calculate percentages
            }

            foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {
                $source_totals = $sourceTotals[$leadSource] ?? 0;
                foreach ($days as $day) {
                    $percentages[$day][$leadSource] = ($source_totals > 0)
                    ? round(($leadData[$day][$leadSource] / $source_totals) * 100, 1)
                    : 0;
                }
            }

            // Prepare day labels with day names
            $dayLabels = [];
            $dayNames = [];
            foreach ($days as $day) {
                $dateObj = Carbon::createFromDate($year, $Month, $day);
                $dayLabels[$day] = str_pad($day,2,'0',STR_PAD_LEFT) . ' ' . $dateObj->format('D');
                $dayNames[$day] = $dateObj->format('D'); // "Mon", "Tue", etc.
            }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$leadSource] ?? 0;
                }
                $sourceTrends[$leadSource] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadSources_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadSources' => $leadSources_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.cus_age_gen_yearly_list', compact(
            'months',
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeYearlyData(Request $request)
    {
        try {

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $user = $request->user();
            $branch_id = $user->branch_id;
            
            // Get lead years
            $leadYears = CustomerModel::join('za_lead', function ($join) use ($branch_id) {
                $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                    ->where('za_lead.status', 4)
                    ->where('za_lead.branch_id', $branch_id)
                    ->where('za_lead.spam_verified', 0)
                    ->where('za_lead.created_by', '>', 0);
                })
                ->where('za_customer.status', 0)
                ->select(DB::raw('YEAR(za_customer.created_at) as year'))
                ->distinct()
                ->pluck('year');

            $allYears = $leadYears->unique()->sort()->values();
            
            $out_Years = $allYears->sort()->values()->toArray();
            
            $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
            $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)
            
            $year_string = $firstYear.$lastYear;
            
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }
            
            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];
            
            $years = $allYears->toArray();


            $customerData_count_details = [];

            $genderMap = [
                1 => 'male',
                2 => 'female',
                3 => 'others',
            ];

            $genders = [
                'male'=>'Male',
                'female'=>'Female',
                'others'=>'Others'
            ];

            $customerData = [];
            $customerTrendData = [];
            $yearTotals = [];
            $monthOverallTotals = [];
            $grandYearsTotalAll = 0;
            $grandgenderTotalAll = [
                'male' => 0,
                'female' => 0,
                'others' => 0,
            ];

            $grandTotals = [
                'male' => [],
                'female' => [],
                'others' => [],
            ];

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            if(!empty(array_filter($finalYears))){

                foreach ($finalYears as $year) {
                    
                    // Query customers joined with lead, filtered by your criteria
                    $cust = CustomerModel::join('za_lead', function ($join) use ($branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.status', 4)
                            ->where('za_lead.branch_id', $branch_id)
                            ->where('za_lead.spam_verified', 0)
                            ->where('za_lead.created_by', '>', 0);
                    })
                    ->select('za_customer.*', 'za_lead.lead_gender')
                    ->whereYear('za_customer.created_at', $year)
                    ->where('za_customer.status', 0)
                    ->get();

                    // Initialize empty counts array
                    
                    if (!$cust->isEmpty()) {

                        foreach ($cust as $cust_data) {

                            if (!empty($cust_data->created_at)) {
                                $train_month = (int)date('m', strtotime($cust_data->created_at)); // month as int 1..12
                            } else {
                                $train_month = $currentMonth;
                            }

                            $cust_gener = isset($cust_data->lead_gender) && !empty($cust_data->lead_gender) ? (int)$cust_data->lead_gender : 0;

                            if (isset($genderMap[$cust_gener])) {
                                $genderKey = $genderMap[$cust_gener];
                                $customerData_count_details[$year][$train_month][$genderKey] =
                                    ($customerData_count_details[$year][$train_month][$genderKey] ?? 0) + 1;
                            }
                        }
                    }
                }

                $year_index = 1;

                foreach ($finalYears as $year) {

                    // Initialize yearTotals keys if not set
                    if($year_index != 1){
                        if (!isset($yearTotals[$year])) {
                            $yearTotals[$year] = [
                                'male' => 0,
                                'female' => 0,
                                'others' => 0,
                                'total' => 0,
                            ];
                        }
                    }
                    
                    if (!isset($monthOverallTotals[$year])) {
                        $monthOverallTotals[$year] = 0;
                    }

                    foreach ($months as $monthNum => $monthName) {

                        if ($year == $currentYear && $monthNum > $currentMonth) {
                            $maleCount = 0;
                            $femaleCount = 0;
                            $othersCount = 0;
                        } else {
                            $maleCount = $customerData_count_details[$year][$monthNum]['male'] ?? 0;
                            $femaleCount = $customerData_count_details[$year][$monthNum]['female'] ?? 0;
                            $othersCount = $customerData_count_details[$year][$monthNum]['others'] ?? 0;
                        }

                        $customerData[$year][$monthNum] = [
                            'male' => $maleCount,
                            'female' => $femaleCount,
                            'others' => $othersCount,
                        ];

                        if($year_index != 1){
                            
                            $customerTrendData[$year][] = [
                                'month' => $monthName,
                                'male' => $maleCount,
                                'female' => $femaleCount,
                                'others' => $othersCount,
                            ];
    
                            // Add to month totals for each gender
                            $yearTotals[$year]['male'] += $maleCount;
                            $yearTotals[$year]['female'] += $femaleCount;
                            $yearTotals[$year]['others'] += $othersCount;
                            $yearTotals[$year]['total'] = $yearTotals[$year]['male'] + $yearTotals[$year]['female'] + $yearTotals[$year]['others'];
                            
                            $grandgenderTotalAll['male'] += $maleCount;
                            $grandgenderTotalAll['female'] += $femaleCount;
                            $grandgenderTotalAll['others'] += $othersCount;
                            
                            // Add to grand totals for each gender by day
                            $grandTotals['male'][$monthNum] = ($grandTotals['male'][$monthNum] ?? 0) + $maleCount;
                            $grandTotals['female'][$monthNum] = ($grandTotals['female'][$monthNum] ?? 0) + $femaleCount;
                            $grandTotals['others'][$monthNum] = ($grandTotals['others'][$monthNum] ?? 0) + $othersCount;
                        }
                    }

                    if($year_index != 1){
                        $grandYearsTotalAll += $yearTotals[$year]['total'];
                    }

                    $year_index++;
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'years' => $years,
                'months' => $months,
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'currentDay' => $currentDay,
                'customerData' => $customerData,
                'customerTrendData' => $customerTrendData,
                'yearTotals' => $yearTotals,
                'grandYearsTotalAll' => $grandYearsTotalAll,
                'grandTotals' => $grandTotals,
                'genderMap' => $genderMap,
                'grandgenderTotalAll' => $grandgenderTotalAll,
                'gender_count' => !empty($genderMap) && is_array($genderMap) ? count($genderMap) : 0,
                'genders' => $genders,
                'year_colors' => $year_colors,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_age_monthly()
    {
        $days = range(1,31);
        return view('content.report_management.customer_report.cus_age_gen_list', compact(
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusAgeMonthlyData(Request $request)
    {
        try {
            
            $days = range(1,31);

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            // Helper to get months (assumed you have this method)
            $months = $this->getYearBasedMonths($year);

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // Query customers joined with lead, filtered by your criteria
            $cust = CustomerModel::join('za_lead', function ($join) use ($branch_id) {
                $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                    ->where('za_lead.status', 4)
                    ->where('za_lead.branch_id', $branch_id)
                    ->where('za_lead.spam_verified', 0)
                    ->where('za_lead.created_by', '>', 0);
            })
            ->select('za_customer.*', 'za_lead.lead_gender')
            ->whereYear('za_customer.created_at', $year)
            ->where('za_customer.status', 0)
            ->get();

            $pre_cust = CustomerModel::join('za_lead', function ($join) use ($branch_id) {
                $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                    ->where('za_lead.status', 4)
                    ->where('za_lead.branch_id', $branch_id)
                    ->where('za_lead.spam_verified', 0)
                    ->where('za_lead.created_by', '>', 0);
            })
            ->select('za_customer.*', 'za_lead.lead_gender')
            ->whereYear('za_customer.created_at', $pre_year)
            ->whereMonth('za_customer.created_at', 12)
            ->whereDay('za_customer.created_at', $pre_daysInMonth)
            ->where('za_customer.status', 0)
            ->get();

            // Initialize empty counts array
            $customerData_count_details = [];
            $pre_customerData_count_details = [];

            $genderMap = [
                1 => 'male',
                2 => 'female',
                3 => 'others',
            ];

            $genders = [
                'male'=>'Male',
                'female'=>'Female',
                'others'=>'Others'
            ];

            if (!$cust->isEmpty()) {
                foreach ($cust as $cust_data) {
                    if (!empty($cust_data->created_at)) {
                        $train_month = (int)date('m', strtotime($cust_data->created_at)); // month as int 1..12
                        $train_day = (int)date('j', strtotime($cust_data->created_at));   // day as int 1..31
                    } else {
                        $train_month = $currentMonth;
                        $train_day = $currentDay;
                    }

                    $cust_gener = isset($cust_data->lead_gender) && !empty($cust_data->lead_gender) ? (int)$cust_data->lead_gender : 0;

                    if (isset($genderMap[$cust_gener])) {
                        $genderKey = $genderMap[$cust_gener];
                        $customerData_count_details[$train_month][$train_day][$genderKey] =
                            ($customerData_count_details[$train_month][$train_day][$genderKey] ?? 0) + 1;
                    }
                }
            }

            if (!$pre_cust->isEmpty()) {
                foreach ($pre_cust as $pre_cust_data) {
                    if (!empty($pre_cust_data->created_at)) {
                        $pretrain_month = (int)date('m', strtotime($pre_cust_data->created_at)); // month as int 1..12
                        $pretrain_day = (int)date('j', strtotime($pre_cust_data->created_at));   // day as int 1..31
                    } else {
                        $pretrain_month = $currentMonth;
                        $pretrain_day = $currentDay;
                    }

                    $pre_cust_gender = isset($pre_cust_data->lead_gender) && !empty($pre_cust_data->lead_gender) ? (int)$pre_cust_data->lead_gender : 0;

                    if (isset($genderMap[$pre_cust_gender])) {
                        $pre_genderKey = $genderMap[$pre_cust_gender];
                        $pre_customerData_count_details[$pretrain_month][$pretrain_day][$pre_genderKey] =
                            ($pre_customerData_count_details[$pretrain_month][$pretrain_day][$pre_genderKey] ?? 0) + 1;
                    }
                }
            }

            // Prepare data arrays for response
            $pre_customerData = [];
            $customerData = [];
            $customerTrendData = [];
            $monthTotals = [];
            $monthOverallTotals = [];
            $grandTotalAll = 0;
            $grandgenderTotalAll = [
                'male' => 0,
                'female' => 0,
                'others' => 0,
            ];
            $grandTotals = [
                'male' => [],
                'female' => [],
                'others' => [],
            ];

            foreach ($months as $monthNum => $monthName) {

                // Initialize monthTotals keys if not set
                if (!isset($monthTotals[$monthNum])) {
                    $monthTotals[$monthNum] = [
                        'male' => 0,
                        'female' => 0,
                        'others' => 0,
                        'total' => 0,
                    ];
                }
                
                if (!isset($monthOverallTotals[$monthNum])) {
                    $monthOverallTotals[$monthNum] = 0;
                }

                foreach($days as $day) {

                    $date_format = date('d-m-Y', strtotime("$day-$monthNum-$year"));

                    if ($year == $currentYear && $monthNum == $currentMonth && $day > $currentDay) {

                        $maleCount = 0;
                        $femaleCount = 0;
                        $othersCount = 0;
                        $pre_maleCount = 0;
                        $pre_femaleCount = 0;
                        $pre_othersCount = 0;

                    } else {

                        $maleCount = $customerData_count_details[$monthNum][$day]['male'] ?? 0;
                        $femaleCount = $customerData_count_details[$monthNum][$day]['female'] ?? 0;
                        $othersCount = $customerData_count_details[$monthNum][$day]['others'] ?? 0;
                        
                        $pre_maleCount = $pre_customerData_count_details[12][$pre_daysInMonth]['male'] ?? 0;
                        $pre_femaleCount = $pre_customerData_count_details[12][$pre_daysInMonth]['female'] ?? 0;
                        $pre_othersCount = $pre_customerData_count_details[12][$pre_daysInMonth]['others'] ?? 0;
                    }

                    $customerData[$monthNum][$day] = [
                        'male' => $maleCount,
                        'female' => $femaleCount,
                        'others' => $othersCount,
                    ];

                    $pre_customerData[12][$pre_daysInMonth] = [
                        'male' => $pre_maleCount,
                        'female' => $pre_femaleCount,
                        'others' => $pre_othersCount,
                    ];

                    $customerTrendData[$monthName][] = [
                        'date' => $date_format,
                        'male' => $maleCount,
                        'female' => $femaleCount,
                        'others' => $othersCount,
                    ];

                    // Add to month totals for each gender
                    $monthTotals[$monthNum]['male'] += $maleCount;
                    $monthTotals[$monthNum]['female'] += $femaleCount;
                    $monthTotals[$monthNum]['others'] += $othersCount;
                    $monthTotals[$monthNum]['total'] = $monthTotals[$monthNum]['male'] + $monthTotals[$monthNum]['female'] + $monthTotals[$monthNum]['others'];
                    
                    $grandgenderTotalAll['male'] += $maleCount;
                    $grandgenderTotalAll['female'] += $femaleCount;
                    $grandgenderTotalAll['others'] += $othersCount;
                    
                    // Add to grand totals for each gender by day
                    $grandTotals['male'][$day] = ($grandTotals['male'][$day] ?? 0) + $maleCount;
                    $grandTotals['female'][$day] = ($grandTotals['female'][$day] ?? 0) + $femaleCount;
                    $grandTotals['others'][$day] = ($grandTotals['others'][$day] ?? 0) + $othersCount;
                }
                $grandTotalAll += $monthTotals[$monthNum]['total'];
            }

            return response()->json([
                'days' => $days,
                'months' => $months,
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'currentDay' => $currentDay,
                'customerData' => $customerData,
                'pre_customerData' => $pre_customerData,
                'customerTrendData' => $customerTrendData,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'grandTotals' => $grandTotals,
                'genderMap' => $genderMap,
                'grandgenderTotalAll' => $grandgenderTotalAll,
                'gender_count' => !empty($genderMap) && is_array($genderMap) ? count($genderMap) : 0,
                'genders' => $genders,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_yearly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_type_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                $filterDate = $selected_year . '-' .'01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadTypeModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadTypes = $query->select('sno', 'lead_type_name')->orderBy('lead_type_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadTypes->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_type_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $MonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $MonthTotal = 0;

                foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                    //Fetch conversions count
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_type_id,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.lead_type_id', $lead_type_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                    })->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', (int)$monthNum)
                    ->where('za_customer.status', 0)
                    ->count();

                    $count = (int) $conversions_detail_modal;

                    // $count = rand(5, 50); // Replace with DB query

                    $leadData[$monthName][$leadType] = $count;
                    $MonthTotal += $count;

                    $prevMonth = 0;
                    $prevYear = 0;

                    $day_query = false;

                    if ((int)$monthNum == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $day_query = true;
                    }
                    
                    $pre_count = 0;

                    if($day_query){

                        $pre_months = $this->getYearBasedMonths($prevYear);
                        
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::join('za_lead', function ($join) use ($lead_type_id,$branch_id) {
                            $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.lead_type_id', $lead_type_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                        })->whereYear('za_customer.created_at', $prevYear)
                        ->whereMonth('za_customer.created_at', (int)$prevMonth)
                        ->where('za_customer.status', 0)
                        ->count();

                        // $pre_count = rand(5, 50);

                        $pre_count = (int)$prev_conversion_detail ?? 0;

                        $preleadData[$pre_months[12]][$leadType] = $pre_count;
                    }
                    
                    if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                    $sourceTotals[$leadType] += $count;
                }

                $MonthTotals[$monthName] = $MonthTotal;
                $grandTotalAll += $MonthTotal;

                // Calculate percentages
            }

            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $source_totals = $sourceTotals[$leadType] ?? 0;
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $percentages[$monthName][$leadType] = ($source_totals > 0)
                    ? round(($leadData[$monthName][$leadType] / $source_totals) * 100, 1)
                    : 0;
                    $trend[] = $leadData[$monthName][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'months' => $months,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'MonthTotals' => $MonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_employee_type_monthly()
    {
        $currentMonth = date('n');
        $currentYear = date('Y');
        $currentDay = date('j');

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.customer_report.customer_type_list', compact(
            'currentMonth',
            'currentYear',
            'currentDay',
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusTypeMonthlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadTypeModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'lead_type_name')->orderBy('lead_type_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_type_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $grandTotalAll = 0;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($days as $day) {

                $dayTotal = 0;

                foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                    //Fetch conversions count
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_type_id,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.lead_type_id', $lead_type_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                    })->whereYear('za_customer.created_at', $year)
                    ->whereMonth('za_customer.created_at', (int)$querycurrentMonth)
                    ->whereDay('za_customer.created_at', $day)
                    ->where('za_customer.status', 0)
                    ->count();

                    $count = (int) $conversions_detail_modal;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$leadType] = $count;
                    $dayTotal += $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = 0;

                    if($day_query){
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::select('za_customer.sno')
                        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.status', 4)->where('za_lead.spam_verified',0)
                        ->where('za_lead.branch_id', $branch_id)->where('za_lead.lead_type_id', $lead_type_id)->where('za_lead.created_by', '>', 0)
                        ->whereRaw('YEAR(za_customer.created_at) = ?', [$prevYear])
                        ->whereRaw('MONTH(za_customer.created_at) = ?', [$prevMonth])
                        ->whereRaw('DAY(za_customer.created_at) = ?', [$prevDay])
                        ->where('za_customer.status', 0)
                        ->count();
                        $pre_count = (int)$prev_conversion_detail ?? 0;
                    }

                    $preleadData[$prevDay][$leadType] = $pre_count;
                    
                    if (!isset($sourceTotals[$leadType])) $sourceTotals[$leadType] = 0;
                    $sourceTotals[$leadType] += $count;
                }

                $dayTotals[$day] = $dayTotal;
                $grandTotalAll += $dayTotal;

                // Calculate percentages
            }

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $source_totals = $sourceTotals[$leadType] ?? 0;
                foreach ($days as $day) {
                    $percentages[$day][$leadType] = ($source_totals > 0)
                    ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
                    : 0;
                }
            }

            // Prepare day labels with day names
            $dayLabels = [];
            $dayNames = [];
            foreach ($days as $day) {
                $dateObj = Carbon::createFromDate($year, $Month, $day);
                $dayLabels[$day] = str_pad($day,2,'0',STR_PAD_LEFT) . ' ' . $dateObj->format('D');
                $dayNames[$day] = $dateObj->format('D'); // "Mon", "Tue", etc.
            }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$leadType] ?? 0;
                }
                $sourceTrends[$leadType] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_batch_yearly()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.customer_report.customer_batch_yearly_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusBatchYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            // $selected_month = $request->month;

            // Accept multiple slugs (array or comma-separated string)
            $slugs = collect($request->slugs)
                ->when(is_string($request->slugs), fn($c) => collect(explode(',', $request->slugs)))
                ->map(fn($s) => strtolower(trim($s)))
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $search_lead_src_fill = $request->search_lead_src_fill ?? [];
            // $is_existing_val = (int)($request->is_existing_val ?? 2);

            // Validate year/month
            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                // $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = "{$selected_year}-01-01";
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = date('Y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            $result = $this->GetBatchTimeWiseCustDetails($branch_id, $year);

            $slots_type_list = isset($result['slots']) && !empty($result['slots']) ? $result['slots'] : [];

            $leadTypesMapped = [];
            
            // $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);
            // if ($today_year == $year && $today_month == $Month) $daysInMonth = (int)$today;
            $days = range(1, 31);

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year,2);

            // Initialize data containers
            $leadData = [];
            $slot_type_details = [];
            $preleadData = [];
            $sourceTotals = [];
            $dayTotals = [];
            $sourceTrends = [];
            $SlottypeTotals = [];
            $grandTotalAll = 0;

            foreach ($slots_type_list as $slots_type => $slots_type_details) {
                
                if(!isset($leadTypesMapped[$slots_type])){
                    $leadTypesMapped[$slots_type] = [];
                }

                $slot_type_details[$slots_type] = [
                    'slot_type_name' => $this->getSlotTypeName($slots_type),
                    'slot_count' => !empty($slots_type_details) && is_array($slots_type_details) ? count($slots_type_details) : 0
                ];

                $color_sno = 0;
                
                foreach ($slots_type_details as $slots_details) {

                    $slots_slug = isset($slots_details['time_slug']) && !empty($slots_details['time_slug']) ? $slots_details['time_slug'] : null;
                    $start_time = isset($slots_details['start_time']) && !empty($slots_details['start_time']) ? date('h:i A',strtotime($slots_details['start_time'])) : null;
                    $end_time = isset($slots_details['end_time']) && !empty($slots_details['end_time']) ? date('h:i A',strtotime($slots_details['end_time'])) : null;

                    $dailyData = isset($slots_details['monthly']) && !empty($slots_details['monthly']) ? $slots_details['monthly'] : [];

                    $leadTypesMapped[$slots_type][$slots_slug] = $start_time.' - '.$end_time;

                    foreach ($months as $monthNum => $monthName) {

                        if(!isset($leadData[$slots_type][$slots_slug])){
                            $leadData[$slots_type][$slots_slug] = [];
                        }

                        $count = isset($dailyData[$year][$monthNum]['customer_count']) && !empty($dailyData[$year][$monthNum]['customer_count']) ? $dailyData[$year][$monthNum]['customer_count'] : 0;

                        $leadData[$slots_type][$slots_slug][$monthNum] = $count;

                        $SlottypeTotals[$slots_type] = ($SlottypeTotals[$slots_type] ?? 0) + $count;

                        $sourceTotals[$slots_type][$slots_slug] = ($sourceTotals[$slots_type][$slots_slug] ?? 0) + $count;

                        $dayTotals[$slots_type][$monthNum] = ($dayTotals[$slots_type][$monthNum] ?? 0) + $count;

                        $sourceTrends[$slots_type][$slots_slug][$monthNum] = $count;

                        $prevMonth = 0;
                        $prevYear = 0;
                        // $prevDay = 0;

                        if ((int)$monthNum == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            // $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if((int)$monthNum != 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$monthNum - 1;
                            // $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }
                        
                        $pre_count = isset($dailyData[$prevYear][$prevMonth]['customer_count']) && !empty($dailyData[$prevYear][$prevMonth]['customer_count']) ? $dailyData[$prevYear][$prevMonth]['customer_count'] : 0;

                        $preleadData[$slots_type][$slots_slug][$prevMonth] = $pre_count;
                    }

                }
            }

            $line_slot_MonthColors = $this->generateLeadSourceAttractiveColorsNew($leadTypesMapped);

            $chartDetails = [];

            foreach ($slots_type_list as $slots_type => $slots_type_details) {
                
                // Initialize department array if not set
                if (!isset($chartDetails[$slots_type])) {
                    $chartDetails[$slots_type] = [
                        'slot_type_name' => $this->getSlotTypeName($slots_type),
                        'time_slugs'     => [],
                        'slot_timings'     => [],
                        'slot_timing_colors'    => [],
                        'slot_cus_count'   => [],
                    ];
                }

                foreach ($slots_type_details as $slots_details) {

                    $slots_slug = isset($slots_details['time_slug']) && !empty($slots_details['time_slug']) ? $slots_details['time_slug'] : null;
                    $start_time = isset($slots_details['start_time']) && !empty($slots_details['start_time']) ? date('h:i A',strtotime($slots_details['start_time'])) : null;
                    $end_time = isset($slots_details['end_time']) && !empty($slots_details['end_time']) ? date('h:i A',strtotime($slots_details['end_time'])) : null;

                    $chartDetails[$slots_type]['time_slugs'][]   = $slots_slug;
                    $chartDetails[$slots_type]['slot_timings'][]   = $start_time.' - '.$end_time;
                    $chartDetails[$slots_type]['slot_timing_colors'][]  = $line_slot_MonthColors[$slots_type][$slots_slug] ?? '#1e90ff';
                    $chartDetails[$slots_type]['slot_cus_count'][] = $sourceTotals[$slots_type][$slots_slug] ?? 0;
                }
            }
            
            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'leadTypes' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'sourceTrends' => $sourceTrends,
                'slottypeTotals' => $SlottypeTotals,
                'slot_type_details' => $slot_type_details,
                'chartDetails' => $chartDetails,
                'line_MonthColors' => $line_slot_MonthColors,
                'currentMonth' => (int)date('n'),
                'currentYear' => (int)date('Y'),
                'currentDay' => (int)date('j'),
                'year' => $year,
                'daysInMonth' => !empty($months) ? count($months) : 0,
                'month' => $Month,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load exam completion data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function cus_batch_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $currentMonth = date('n');
        $currentYear = date('Y');
        $currentDay = date('j');

        return view('content.report_management.customer_report.customer_batch_list', compact(
            'days','currentMonth','months','currentYear','currentDay'
        ))->with('report_heading', self::$report_heading);
    }

    public function CusBatchMonthlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;

            // Accept multiple slugs (array or comma-separated string)
            $slugs = collect($request->slugs)
                ->when(is_string($request->slugs), fn($c) => collect(explode(',', $request->slugs)))
                ->map(fn($s) => strtolower(trim($s)))
                ->filter()
                ->unique()
                ->values()
                ->toArray();

            $search_lead_src_fill = $request->search_lead_src_fill ?? [];
            // $is_existing_val = (int)($request->is_existing_val ?? 2);

            // Validate year/month
            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = "{$selected_year}-{$monthFormatted}-01";
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $branch_id = $user->branch_id;

            $result = $this->GetBatchTimeWiseCustDetails($branch_id, $year);

            $slots_type_list = isset($result['slots']) && !empty($result['slots']) ? $result['slots'] : [];

            $leadTypesMapped = [];
            
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);
            if ($today_year == $year && $today_month == $Month) $daysInMonth = (int)$today;
            $days = range(1, $daysInMonth);

            // Initialize data containers
            $leadData = [];
            $slot_type_details = [];
            $preleadData = [];
            $sourceTotals = [];
            $dayTotals = [];
            $sourceTrends = [];
            $SlottypeTotals = [];
            $grandTotalAll = 0;

            foreach ($slots_type_list as $slots_type => $slots_type_details) {
                
                if(!isset($leadTypesMapped[$slots_type])){
                    $leadTypesMapped[$slots_type] = [];
                }

                $slot_type_details[$slots_type] = [
                    'slot_type_name' => $this->getSlotTypeName($slots_type),
                    'slot_count' => !empty($slots_type_details) && is_array($slots_type_details) ? count($slots_type_details) : 0
                ];

                $color_sno = 0;
                
                foreach ($slots_type_details as $slots_details) {

                    $slots_slug = isset($slots_details['time_slug']) && !empty($slots_details['time_slug']) ? $slots_details['time_slug'] : null;
                    $start_time = isset($slots_details['start_time']) && !empty($slots_details['start_time']) ? date('h:i A',strtotime($slots_details['start_time'])) : null;
                    $end_time = isset($slots_details['end_time']) && !empty($slots_details['end_time']) ? date('h:i A',strtotime($slots_details['end_time'])) : null;

                    $dailyData = isset($slots_details['daily']) && !empty($slots_details['daily']) ? $slots_details['daily'] : [];

                    $leadTypesMapped[$slots_type][$slots_slug] = $start_time.' - '.$end_time;

                    foreach ($days as $day) {

                        if(!isset($leadData[$slots_type][$slots_slug])){
                            $leadData[$slots_type][$slots_slug] = [];
                        }

                        $count = isset($dailyData[$year][$Month][$day]['customer_count']) && !empty($dailyData[$year][$Month][$day]['customer_count']) ? $dailyData[$year][$Month][$day]['customer_count'] : 0;

                        $leadData[$slots_type][$slots_slug][$day] = $count;

                        $SlottypeTotals[$slots_type] = ($SlottypeTotals[$slots_type] ?? 0) + $count;

                        $sourceTotals[$slots_type][$slots_slug] = ($sourceTotals[$slots_type][$slots_slug] ?? 0) + $count;

                        $dayTotals[$slots_type][$day] = ($dayTotals[$slots_type][$day] ?? 0) + $count;

                        $sourceTrends[$slots_type][$slots_slug][$day] = $count;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }
                        
                        $pre_count = isset($dailyData[$prevYear][$prevMonth][$prevDay]['customer_count']) && !empty($dailyData[$prevYear][$prevMonth][$prevDay]['customer_count']) ? $dailyData[$prevYear][$prevMonth][$prevDay]['customer_count'] : 0;

                        $preleadData[$slots_type][$slots_slug][$prevDay] = $pre_count;
                    }

                }
            }

            $line_slot_MonthColors = $this->generateLeadSourceAttractiveColorsNew($leadTypesMapped);

            $chartDetails = [];

            foreach ($slots_type_list as $slots_type => $slots_type_details) {
                
                // Initialize department array if not set
                if (!isset($chartDetails[$slots_type])) {
                    $chartDetails[$slots_type] = [
                        'slot_type_name' => $this->getSlotTypeName($slots_type),
                        'time_slugs'     => [],
                        'slot_timings'     => [],
                        'slot_timing_colors'    => [],
                        'slot_cus_count'   => [],
                    ];
                }

                foreach ($slots_type_details as $slots_details) {

                    $slots_slug = isset($slots_details['time_slug']) && !empty($slots_details['time_slug']) ? $slots_details['time_slug'] : null;
                    $start_time = isset($slots_details['start_time']) && !empty($slots_details['start_time']) ? date('h:i A',strtotime($slots_details['start_time'])) : null;
                    $end_time = isset($slots_details['end_time']) && !empty($slots_details['end_time']) ? date('h:i A',strtotime($slots_details['end_time'])) : null;

                    $chartDetails[$slots_type]['time_slugs'][]   = $slots_slug;
                    $chartDetails[$slots_type]['slot_timings'][]   = $start_time.' - '.$end_time;
                    $chartDetails[$slots_type]['slot_timing_colors'][]  = $line_slot_MonthColors[$slots_type][$slots_slug] ?? '#1e90ff';
                    $chartDetails[$slots_type]['slot_cus_count'][] = $sourceTotals[$slots_type][$slots_slug] ?? 0;
                }
            }
            
            return response()->json([
                'days' => $days,
                'leadTypes' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'sourceTrends' => $sourceTrends,
                'slottypeTotals' => $SlottypeTotals,
                'slot_type_details' => $slot_type_details,
                'chartDetails' => $chartDetails,
                'line_MonthColors' => $line_slot_MonthColors,
                'currentMonth' => (int)date('n'),
                'currentYear' => (int)date('Y'),
                'currentDay' => (int)date('j'),
                'year' => $year,
                'daysInMonth' => $daysInMonth,
                'month' => $Month,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load exam completion data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getCouseTypeName($course_id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['CouseTypeName'])) {
            self::$temp['CouseTypeName'] = [];
        }
        // Check if the id is already cached
        if (!isset(self::$temp['CouseTypeName'][$course_id])) {
            $state = DB::table('za_course')->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')->select('za_course_type.course_type_name')->where('za_course.sno', $course_id)->first();
            self::$temp['CouseTypeName'][$course_id] = $state ? $state->course_type_name : null;
        }
        return self::$temp['CouseTypeName'][$course_id];
    }

    private function getSlotTypeName($slot_type_id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['getSlotTypeName'])) {
            self::$temp['getSlotTypeName'] = [];
        }
        // Check if the id is already cached
        if (!isset(self::$temp['getSlotTypeName'][$slot_type_id])) {
            $state = DB::table('za_slot_type')->select('za_slot_type.slot_type_name')->where('za_slot_type.sno', $slot_type_id)->first();
            self::$temp['getSlotTypeName'][$slot_type_id] = $state ? $state->slot_type_name : null;
        }
        return self::$temp['getSlotTypeName'][$slot_type_id];
    }

    public function get_lead_type_list()
    {
        $LeadTypeModelList = LeadTypeModel::where('status', 0)->orderBy('lead_type_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    public function get_slot_type_list(Request $request)
    {
        $user = $request->user();
        $user_id = $user->user_id;
        $branch_id = $user->branch_id;

        $LeadTypeModelList = SlotModel::join('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')->select('za_slot.*','za_slot_type.slot_type_name')->where('za_slot.status', 0)->where('za_slot.branch_id', $branch_id)->orderBy('za_slot.start_time','asc')->orderBy('za_slot.end_time','asc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LeadTypeModelList
        ], 200);
    }

    private function GetBatchTimeWiseCustDetails(int $branch_id, int $year)
    {
        try {
            
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $slots = [];

            // 🔹 Step 1: Get slot types
            $slot_types = DB::table('za_slot_type')
                ->where('status', '!=', 2)
                ->orderBy('sno', 'asc')
                ->get();

            $slot_typeIds = $slot_types->pluck('sno')->toArray();

            // 🔹 Step 2: Get slots
            $slotsRaw = DB::table('za_slot')
                ->where('branch_id', $branch_id)
                ->where('status', '!=', 2)
                ->whereIn('slot_type_id', $slot_typeIds)
                ->orderBy('slot_type_id', 'asc')
                ->orderBy('start_time', 'asc')
                ->get();

            // 🔹 Step 3: Generate 2-hour split slots per slot type
            foreach ($slot_typeIds as $slotTypeId) {
                $slotGroup = $slotsRaw->where('slot_type_id', $slotTypeId);

                if ($slotGroup->isNotEmpty()) {
                    $overallStart = $slotGroup->first()->start_time;
                    $overallEnd   = $slotGroup->last()->end_time;

                    $startTime = strtotime($overallStart);
                    $endTime   = strtotime($overallEnd);
                    $interval  = 2 * 60 * 60; // 2 hours

                    $splitSlots = [];

                    while ($startTime < $endTime) {
                        $splitStart = date('H:i:s', $startTime);
                        $splitEnd   = date('H:i:s', min($startTime + $interval, $endTime));

                        $slotIds = $slotGroup->filter(function ($slot) use ($splitStart, $splitEnd) {
                            return ($slot->start_time < $splitEnd && $slot->end_time > $splitStart);
                        })->pluck('sno')->values()->toArray();

                        $splitSlots[] = [
                            'time_slug' => str_replace([':', '-'], '_', $splitStart . '_' . $splitEnd),
                            'start_time' => $splitStart,
                            'end_time'   => $splitEnd,
                            'slot_ids'   => $slotIds,
                            'monthly'    => [],
                            'daily'      => []
                        ];

                        $startTime += $interval;
                    }

                    $slots[$slotTypeId] = $splitSlots;
                }
            }

            // 🔹 Step 4: Get training data counts (for all slots)
            $trainingData = DB::table('za_training')
                ->select(
                    DB::raw('slot_id'),
                    DB::raw('YEAR(created_at) as year'),
                    DB::raw('MONTH(created_at) as month'),
                    DB::raw('DAY(created_at) as day'),
                    DB::raw('COUNT(customer_id) as customer_count')
                )
                ->where('branch_id', $branch_id)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereNotNull('slot_id')
                ->groupBy('slot_id', 'year', 'month', 'day')
                ->get();

            // 🔹 Step 5: Map counts into slot structure
            foreach ($slots as $slotTypeId => &$slotList) {
                foreach ($slotList as &$slotBlock) {
                    $slotIds = $slotBlock['slot_ids'];

                    // Get all matching training rows for these slot IDs
                    $matching = $trainingData->whereIn('slot_id', $slotIds);

                    // Monthly
                    foreach ($matching->groupBy('month') as $month => $monthGroup) {
                        $monthlyCount = $monthGroup->sum('customer_count');
                        $slotBlock['monthly'][$year][$month] = ['customer_count' => $monthlyCount];
                    }

                    // Daily
                    foreach ($matching->groupBy(['month', 'day']) as $month => $days) {
                        foreach ($days as $day => $dayGroup) {
                            $dailyCount = $dayGroup->sum('customer_count');
                            $slotBlock['daily'][$year][$month][$day] = ['customer_count' => $dailyCount];
                        }
                    }
                }
            }

            return [
                'year'  => $year,
                'slots' => $slots
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetBatchTimeWiseCustDetails: " . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    private function generateLeadSourceAttractiveColorsNew($leadTypesMapped, $baseHue = 200)
    {
        $colors = [];
        if (!empty($leadTypesMapped)) {
            foreach ($leadTypesMapped as $slotType => $slots) {
                // Ensure valid data
                if (!is_array($slots) || empty($slots)) {
                    continue;
                }
                $count = count($slots);
                $i = 0;
                foreach ($slots as $slug => $label) {
                    $hue = ($baseHue + $i * (360 / $count)) % 360;
                    // Assign color to slug within its slotType
                    $colors[$slotType][$slug] = "hsl({$hue}, 65%, 55%)";

                    $i++;
                }
            }
        }
        return $colors;
    }
}