<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\JobCategoryModel;
use DateTime;

class PlacementReport extends Controller
{

    public static $report_heading = 'Analysis';

    public function index()
    {
        $currentYear  = date('Y');
        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear, 2);

        return view('content.report_management.placement_report.job_posting_yearly_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function JobPostingPlaceYearData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year)
            ) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $days = range(1,31);
            $year = date('Y', strtotime($filterDate));
            $prevYear  = (int)$year - 1;
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPlacementCountDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = JobCategoryModel::where('status','!=',2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->orderBy('job_category_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_category_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($months as $monthNum => $monthName) {
                    
                    $paymentSums = isset($result['monthly'][$lead_type_id]) && !empty($result['monthly'][$lead_type_id]) ? $result['monthly'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$monthNum]) ? (int) $paymentSums[$year][$monthNum] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    
                    $leadData[$monthNum][$lead_type_id] = $count;

                    $dayTotals[$monthNum] = ($dayTotals[$monthNum] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = (int)$monthNum - 1;

                    $day_query = false;

                    if ((int)$monthNum === 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $day_query = true;
                    }else if((int)$monthNum !== 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth]) ? (int)$paymentSums[$prevYear][$prevMonth] : 0;

                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise months trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function job_posting_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.placement_report.job_posting_monthly_list', compact(
           'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function JobPostingPlaceMonthData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPlacementCountDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $query = JobCategoryModel::where('status','!=',2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->orderBy('job_category_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadTypesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->job_category_name];
            })->toArray();
            
            $leadTypes_list = !empty($leadTypesMapped) ? array_values($leadTypesMapped) : [];
            $leadTypes_keys = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $dayTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;
            

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]) ? (int) $paymentSums[$year][$Month][$day] : 0;

                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    $day_query = false;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        $day_query = true;
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]) ? (int) $paymentSums[$prevYear][$prevMonth][$prevDay] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // $dayTotals[$day] = $dayTotal;
                    
                    // $sourceTotals[$lead_type_id] = $sourceTotals[$lead_type_id];
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // foreach ($leadTypesMapped as $lead_type_id => $leadType) {
            //     $source_totals = $sourceTotals[$leadType] ?? 0;
            //     foreach ($days as $day) {
            //         $percentages[$day][$leadType] = ($source_totals > 0)
            //         ? round(($leadData[$day][$leadType] / $source_totals) * 100, 1)
            //         : 0;
            //     }
            // }

            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadTypes_keys' => $leadTypes_keys,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function placed_unplaced_stud_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.placement_report.placed_unplaced_stud_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function PlacedUnplacedYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPlacedUnplacedStuDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'placed_cust_count' => 'Placed',
                'unplaced_cust_count' => 'Unplaced',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years'])
                ? collect($result['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];

                        foreach ($types_list as $type_key => $type_name) {

                            // if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    ? $paymentSums['monthly'][$year][$monthNum][$type_key]
                                    : 0;
                            // } else {
                            //     $amount = 0;
                            // }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($monthly_data[$year]['total_count'] ?? 0);

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function placed_unplaced_stud_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.placement_report.placed_unplaced_stud_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function PlacedUnplacedMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPlacedUnplacedStuDetails($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $types_list = [
                'placed_cust_count' => 'Placed',
                'unplaced_cust_count' => 'Unplaced',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                ? round($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                : 0;
                        } else {
                            $amount = 0;
                        }

                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + ($totals[$monthNum][$type_key] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function ReportjobCategoryList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $jobCategory = DB::table('za_job_category')->select('za_job_category.*')
        ->where('za_job_category.status', '!=', 2)
        ->orderBy('za_job_category.job_category_name', 'asc')
        ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $jobCategory,
        ], 200);
    }

    public function GetPlacementCountDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];

            // --- Fetch job positions ---
            $job_category = DB::table('za_job_category')->where('status', '!=', 2)->get();

            foreach ($job_category as $category) {

                // --- Fetch staff under this position ---
                $job_list = DB::table('za_placement_interview')
                            ->select('za_placement_interview.*')
                            ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                            ->join('za_jobs','za_placement_interview.job_id', '=', 'za_jobs.sno')
                            ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
                            ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
                            ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
                            ->where('za_customer.status', '!=', 2)
                            ->where('za_placement_interview.status', 4)
                            ->where('za_jobs.job_category_id', $category->sno)
                            ->where('za_placement_interview.branch_id',$branch_id)
                            ->get();

                // $dailyData[$category->sno] = $job_list;

                // --- Loop staff for daily counts ---
                foreach ($job_list as $job) {
                    
                    if (empty($job->selected_date)) continue;

                    $loopDate = date('Y-m-d', strtotime($job->selected_date));

                    $y = (int) date('Y', strtotime($loopDate));
                    $m = (int) date('n', strtotime($loopDate));
                    $d = (int) date('j', strtotime($loopDate));

                    if (!isset($dailyData[$category->sno][$y][$m][$d])) {

                        $dailyData[$category->sno][$y][$m][$d] = [
                            'staff_count' => 0
                        ];
                    }

                    // --- Staff count ---
                    $dailyData[$category->sno][$y][$m][$d]['staff_count']++;
                    $years[$y] = $y;
                }
            }

            // return $dailyData;

            // --- Monthly aggregation including attendance ---
            foreach ($dailyData as $positionId => $yearsData) {
                foreach ($yearsData as $year => $months) {
                    foreach ($months as $month => $days) {
                        $monthlyData[$positionId][$year][$month] = [
                            'staff_count' => array_sum(array_column($days, 'staff_count')) ?? 0
                        ];
                    }
                }
            }

            // --- Yearly aggregation including attendance ---
            foreach ($monthlyData as $positionId => $yearsData) {
                foreach ($yearsData as $year => $months) {
                    $yearlyData[$positionId][$year] = [
                        'staff_count'          => array_sum(array_column($months, 'staff_count')) ?? 0
                    ];
                }
            }

            ksort($dailyData);
            ksort($monthlyData);
            ksort($yearlyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetFacultyDetails: " . $e->getMessage());
            return null;
        }
    }

    private function GetPlacedUnplacedStuDetails(int $branch_id)
    {
        try {

            // 🧩 Validate input
            if (!$branch_id || $branch_id <= 0) {
                throw new \InvalidArgumentException("Valid Branch ID is required");
            }

            $currentDate = date('Y-m-d');

            /** ------------------ FETCH CUSTOMERS ------------------ */
            $customers = DB::table('za_customer')
                ->whereIn('status', [0, 6])
                ->where('branch_id', $branch_id)
                ->pluck('sno')
                ->toArray();

            if (empty($customers)) {
                return [
                    'yearly'  => [],
                    'monthly' => [],
                    'daily'   => [],
                    'years'   => [],
                    'message' => 'No active or training customers found for this branch.'
                ];
            }

            /** ------------------ INITIALIZE STRUCTURES ------------------ */
            $yearlyData = [];
            $monthlyData = [];
            $dailyData = [];

            /** ------------------ PLACEMENT DATA ------------------ */
            try {

                $placements = DB::table('za_placement_interview')
                    ->select('customer_id', 'selected_date')
                    ->where('branch_id', $branch_id)
                    ->whereIn('customer_id', $customers)
                    ->where('status', 4)
                    ->whereNotNull('selected_date')
                    ->get();

                foreach ($placements as $placement) {
                    $date = date('Y-m-d', strtotime($placement->selected_date));
                    $y = (int) date('Y', strtotime($date));
                    $m = (int) date('n', strtotime($date));
                    $d = (int) date('j', strtotime($date));

                    $yearlyData[$y]['placed_cust_count'] = ($yearlyData[$y]['placed_cust_count'] ?? 0) + 1;
                    $monthlyData[$y][$m]['placed_cust_count'] = ($monthlyData[$y][$m]['placed_cust_count'] ?? 0) + 1;
                    $dailyData[$y][$m][$d]['placed_cust_count'] = ($dailyData[$y][$m][$d]['placed_cust_count'] ?? 0) + 1;
                }

            } catch (\Throwable $e) {
                \Log::error("Error fetching placement data: " . $e->getMessage());
            }

            /** ------------------ TRAINING DATA ------------------ */
            try {

                $trainings = DB::table('za_training')
                    ->select('customer_id', 'start_date', 'end_date')
                    ->where('branch_id', $branch_id)
                    ->whereIn('customer_id', $customers)
                    ->where('tesbo_check', '!=', 1)
                    ->where('batch_id', '!=', 0)
                    ->whereNotNull('end_date')
                    ->get();

                foreach ($trainings as $training) {

                    $endDate = date('Y-m-d', strtotime($training->end_date));

                    if ($endDate < $currentDate) {

                        $y = (int) date('Y', strtotime($endDate));
                        $m = (int) date('n', strtotime($endDate));
                        $d = (int) date('j', strtotime($endDate));

                        $yearlyData[$y]['unplaced_cust_count'] = ($yearlyData[$y]['unplaced_cust_count'] ?? 0) + 1;
                        $monthlyData[$y][$m]['unplaced_cust_count'] = ($monthlyData[$y][$m]['unplaced_cust_count'] ?? 0) + 1;
                        $dailyData[$y][$m][$d]['unplaced_cust_count'] = ($dailyData[$y][$m][$d]['unplaced_cust_count'] ?? 0) + 1;
                    }
                }
            } catch (\Throwable $e) {
                \Log::error("Error fetching training data: " . $e->getMessage());
            }

            /** ------------------ NORMALIZE STRUCTURE ------------------ */
            foreach ($yearlyData as $y => &$yd) {
                $yd = array_merge(['unplaced_cust_count' => 0, 'placed_cust_count' => 0], $yd);
            }

            ksort($yearlyData);
            ksort($monthlyData);
            ksort($dailyData);

            /** ------------------ SUCCESS RESPONSE ------------------ */
            return [
                'status'  => true,
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_keys($yearlyData),
                'message' => 'Student status details fetched successfully.'
            ];

        } catch (\InvalidArgumentException $e) {
            \Log::warning("Invalid input: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'Invalid Branch ID provided.',
                'details' => $e->getMessage()
            ];

        } catch (\Throwable $e) {
            \Log::error("Unexpected error in GetStudentStatusDetails: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'An unexpected error occurred while fetching student details.',
                'details' => $e->getMessage()
            ];
        }
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }
}   
