<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;

class BatchReport extends Controller
{

    public static $report_heading = 'Analysis';

    public function index()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.active_upcoming_yr_list', compact('months'))->with('report_heading', self::$report_heading);
    }

    public function ActiveUpcomingYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Active',
                'upcoming_count' => 'Upcoming',
                'completed_count' => 'Completed'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years'])
                ? collect($result['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    ? $paymentSums['monthly'][$year][$monthNum][$type_key]
                                    : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($monthly_data[$year]['total_count'] ?? 0);

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function active_upcoming_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.active_upcoming_month_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function ActiveUpcomingMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Active',
                'upcoming_count' => 'Upcoming',
                'completed_count' => 'Completed'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];

                    $monthly_data = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

                    foreach ($types_list as $type_key => $type_name) {

                        // if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                ? $paymentSums['daily'][$year][$monthNum][$day][$type_key]
                                : 0;
                        // } else {
                        //     $amount = 0;
                        // }

                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;
                        

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);

                        // Month grand total
                        $grandTotals[$monthNum] = ($monthly_data[$year][$monthNum]['total_count'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function batch_student_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.batch_student_yr_list', compact('months'))->with('report_heading', self::$report_heading);
    }
    
    public function ActiveBatchStudentYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Total Batches',
                'active_student_count' => 'Total Students'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years'])
                ? collect($result['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];

                        foreach ($types_list as $type_key => $type_name) {

                            // if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    ? $paymentSums['monthly'][$year][$monthNum][$type_key]
                                    : 0;
                            // } else {
                            //     $amount = 0;
                            // }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($monthly_data[$year]['total_count'] ?? 0);

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function batch_student_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.batch_student_month_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function ActiveBatchStudentMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Total Batches',
                'active_student_count' => 'Total Students'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];

                    $monthly_data = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

                    foreach ($types_list as $type_key => $type_name) {

                        // if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                ? $paymentSums['daily'][$year][$monthNum][$day][$type_key]
                                : 0;
                        // } else {
                        //     $amount = 0;
                        // }

                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;
                        

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);

                        // Month grand total
                        $grandTotals[$monthNum] = ($monthly_data[$year][$monthNum]['total_count'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function extend_batch_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.extend_batch_yr_list', compact('months'))->with('report_heading', self::$report_heading);
    }

    public function ExtentBatchYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Active',
                'extended_batch_count' => 'Extended'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years'])
                ? collect($result['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];

                        foreach ($types_list as $type_key => $type_name) {

                            // if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    ? $paymentSums['monthly'][$year][$monthNum][$type_key]
                                    : 0;
                            // } else {
                            //     $amount = 0;
                            // }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($monthly_data[$year]['total_count'] ?? 0);

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function extend_batch_monthly()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.batch_report.extend_batch_month_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function ExtentBatchMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetBatchStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'active_count' => 'Active',
                'extended_batch_count' => 'Extended'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];

                    $monthly_data = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

                    foreach ($types_list as $type_key => $type_name) {

                        // if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                ? $paymentSums['daily'][$year][$monthNum][$day][$type_key]
                                : 0;
                        // } else {
                        //     $amount = 0;
                        // }

                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;
                        

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);

                        // Month grand total
                        $grandTotals[$monthNum] = ($monthly_data[$year][$monthNum]['total_count'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($monthly_data[$year][$monthNum][$type_key] ?? 0);
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function GetBatchStatusDetails(int $branch_id)
    {
        try {
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            // Fetch batches for this branch (exclude inactive)
            $batches = DB::table('za_batch')
                ->select('za_batch.*')
                ->where('za_batch.branch_id', $branch_id)
                ->whereNotIn('za_batch.status', [2, 4])
                ->get();

            $dailyData = [];
            $monthlyData = [];
            $yearlyData = [];
            $years = [];

            if ($batches->isEmpty()) {
                return [
                    'yearly'  => [],
                    'monthly' => [],
                    'daily'   => [],
                    'years'   => []
                ];
            }

            foreach ($batches as $batch) {

                $startDate = date('Y-m-d', strtotime($batch->start_date));
                $endDate   = date('Y-m-d', strtotime($batch->end_date));

                // ✅ Active student count
                $activeStudentCount = DB::table('za_training')
                    ->where('za_training.branch_id', $branch_id)
                    ->where('za_training.batch_id', $batch->sno)
                    ->count('za_training.customer_id');

                // ✅ Fetch extensions for this active batch (status = 1)
                $extensions = DB::table('za_batch_extension')
                    ->select('change_date')
                    ->where('branch_id', $branch_id)
                    ->where('batch_id', $batch->sno)
                    ->where('status', 1)
                    ->get();

                    // --- ACTIVE ---
                if ($startDate && $endDate) {

                    // Daily active logic
                    $loopDate = $startDate;
                    
                    while ($loopDate <= $endDate) {

                        $y = (int) date('Y', strtotime($loopDate));
                        $m = (int) date('n', strtotime($loopDate));
                        $d = (int) date('j', strtotime($loopDate));

                        if (!isset($dailyData[$y][$m][$d])) {
                            $dailyData[$y][$m][$d] = [
                                'active_count'          => 0,
                                'active_student_count'  => 0,
                                'completed_count'       => 0,
                                'upcoming_count'        => 0,
                                'extended_batch_count'  => 0,
                                'total_count'           => 0,
                                'overall_total_count'   => 0
                            ];
                        }

                        $dailyData[$y][$m][$d]['active_count']++;
                        $dailyData[$y][$m][$d]['active_student_count'] += $activeStudentCount;

                        $years[$y] = $y;
                        $loopDate = date('Y-m-d', strtotime($loopDate . ' +1 day'));
                    }
                }

                // --- COMPLETED ---
                if ($endDate && $endDate < $currentDate) {

                    $y = (int) date('Y', strtotime($endDate));
                    $m = (int) date('n', strtotime($endDate));
                    $d = (int) date('j', strtotime($endDate));

                    if (!isset($dailyData[$y][$m][$d])) {
                        $dailyData[$y][$m][$d] = [
                            'active_count'          => 0,
                            'active_student_count'  => 0,
                            'completed_count'       => 0,
                            'upcoming_count'        => 0,
                            'extended_batch_count'  => 0,
                            'total_count'           => 0,
                            'overall_total_count'   => 0
                        ];
                    }

                    $dailyData[$y][$m][$d]['completed_count']++;
                    $years[$y] = $y;
                }

                // --- UPCOMING ---
                if ($startDate) {

                    // One day before the start date
                    $prevDate = date('Y-m-d', strtotime($startDate . ' -1 day'));

                    $y = (int) date('Y', strtotime($prevDate));
                    $m = (int) date('n', strtotime($prevDate));
                    $d = (int) date('j', strtotime($prevDate));

                    if (!isset($dailyData[$y][$m][$d])) {
                        $dailyData[$y][$m][$d] = [
                            'active_count'          => 0,
                            'active_student_count'  => 0,
                            'completed_count'       => 0,
                            'upcoming_count'        => 0,
                            'extended_batch_count'  => 0,
                            'total_count'           => 0,
                            'overall_total_count'   => 0
                        ];
                    }

                    $dailyData[$y][$m][$d]['upcoming_count']++;
                    $years[$y] = $y;
                }

                if (!empty($extensions)) {

                    // ✅ Add extension count based on change_date
                    foreach ($extensions as $ext) {

                        $changeDate = date('Y-m-d', strtotime($ext->change_date));

                        // only if change_date <= currentDate
                        if ($changeDate <= $currentDate) {

                            $y = (int) date('Y', strtotime($changeDate));
                            $m = (int) date('n', strtotime($changeDate));
                            $d = (int) date('j', strtotime($changeDate));

                            if (!isset($dailyData[$y][$m][$d])) {

                                $dailyData[$y][$m][$d] = [
                                    'active_count'          => 0,
                                    'active_student_count'  => 0,
                                    'completed_count'       => 0,
                                    'upcoming_count'        => 0,
                                    'extended_batch_count'  => 0,
                                    'total_count'           => 0,
                                    'overall_total_count'   => 0
                                ];
                            }

                            $dailyData[$y][$m][$d]['extended_batch_count']++;
                            $years[$y] = $y;
                        }
                    }
                }
            }

            // === MONTHLY ===
            foreach ($dailyData as $year => $months) {
                foreach ($months as $month => $days) {
                    $lastDay = (int) date('t', strtotime("$year-$month-01"));
                    if ($year == $currentYear && $month == $currentMonth) {
                        $lastDay = (int) date('j', strtotime($currentDate));
                    }

                    $lastDayActive         = $days[$lastDay]['active_count'] ?? 0;
                    $lastDayActiveStudents = $days[$lastDay]['active_student_count'] ?? 0;
                    $completedSum          = array_sum(array_column($days, 'completed_count'));
                    $upcomingSum           = array_sum(array_column($days, 'upcoming_count'));
                    $extendedSum           = array_sum(array_column($days, 'extended_batch_count'));

                    $monthlyData[$year][$month] = [
                        'active_count'          => $lastDayActive,
                        'active_student_count'  => $lastDayActiveStudents,
                        'completed_count'       => $completedSum,
                        'upcoming_count'        => $upcomingSum,
                        'extended_batch_count'  => $extendedSum,
                        'total_count'           => $lastDayActive + $completedSum + $upcomingSum,
                        'overall_total_count'   => $lastDayActive + $completedSum + $upcomingSum + $extendedSum
                    ];
                }
            }

            // === YEARLY ===
            foreach ($monthlyData as $year => $months) {
                $lastMonth = ($year == $currentYear)
                    ? $currentMonth
                    : max(array_keys($months));

                $lastMonthActive         = $months[$lastMonth]['active_count'] ?? 0;
                $lastMonthActiveStudents = $months[$lastMonth]['active_student_count'] ?? 0;
                $completedSum            = array_sum(array_column($months, 'completed_count'));
                $upcomingSum             = array_sum(array_column($months, 'upcoming_count'));
                $extendedSum             = array_sum(array_column($months, 'extended_batch_count'));

                $yearlyData[$year] = [
                    'active_count'          => $lastMonthActive,
                    'active_student_count'  => $lastMonthActiveStudents,
                    'completed_count'       => $completedSum,
                    'upcoming_count'        => $upcomingSum,
                    'extended_batch_count'  => $extendedSum,
                    'total_count'           => $lastMonthActive + $completedSum + $upcomingSum,
                    'overall_total_count'   => $lastMonthActive + $completedSum + $upcomingSum + $extendedSum
                ];
            }

            // === DAILY TOTALS ===
            foreach ($dailyData as $year => &$months) {
                foreach ($months as $month => &$days) {
                    foreach ($days as $day => &$values) {
                        $values['total_count'] =
                            $values['active_count'] +
                            $values['completed_count'] +
                            $values['upcoming_count'];
                        $values['overall_total_count'] =
                            $values['active_count'] +
                            $values['completed_count'] +
                            $values['upcoming_count'] +
                            $values['extended_batch_count'];
                    }
                }
            }

            ksort($yearlyData);
            ksort($monthlyData);
            ksort($dailyData);

            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => $years
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetBatchStatusDetails: " . $e->getMessage());
            return null;
        }
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }
}   
