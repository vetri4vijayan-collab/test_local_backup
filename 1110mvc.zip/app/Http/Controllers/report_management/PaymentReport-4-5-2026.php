<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\ManageInternModel;
use App\Models\CustomerModel;
use App\Models\BranchModel;
use App\Models\TransactionModel;
use App\Models\ManageTargetModel;

class PaymentReport extends Controller
{
    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.payment_report.payment_collection_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function PaymentCollectionYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];
           
            $types_list = [
                'collection_sale' => 'Collection',
                'target_sale' => 'Target'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $monthly_target_data   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            $result = $this->getPostPreSalesData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // Step 1: Extract years from result safely
            $presale_years = isset($result['pre_sale']['years']) && !empty($result['pre_sale']['years']) ? collect($result['pre_sale']['years']) : collect();
            
            $postsale_years = isset($result['post_sale']['years']) && !empty($result['post_sale']['years']) ? collect($result['post_sale']['years']) : collect();

            $targetsale_years = isset($result['target_sale']['years']) && !empty($result['target_sale']['years']) ? collect($result['target_sale']['years']) : collect();
                        
            // Step 2: Merge, deduplicate, sort
            $collectionYears = $presale_years->merge($postsale_years)->unique()->sort()->values();

            $allYears = $collectionYears->merge($targetsale_years)->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            // return $result;

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        foreach ($types_list as $type_key => $type_name) {

                            $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                            $yearhly_target_data = isset($paymentSums['yearly']) ? $paymentSums['yearly'] : [];

                            if ($type_key == 'target_sale') {

                                $monthly_target_data = isset($paymentSums['monthly']) ? $paymentSums['monthly'] : [];

                                $amount = isset($monthly_target_data[$year][$monthNum]) ? round($monthly_target_data[$year][$monthNum], 2) : 0;

                            } else {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum]) ? round($paymentSums['monthly'][$year][$monthNum]) : 0;
                            }

                            // Save raw daily data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){
                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;

                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                                $grandTotalAll += $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'monthly_target_data' => $yearhly_target_data,
                'year' => $year,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function payment_collection_monthly()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.payment_collection_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);

    }

    public function PaymentCollectionMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getPostPreSalesData($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $types_list = [
                'collection_sale' => 'Collection',
                'target_sale' => 'Target'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $monthly_target_data   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $day_format = str_pad($day, 2, '0', STR_PAD_LEFT);
                    $month_format = str_pad($monthNum, 2, '0', STR_PAD_LEFT);

                    $date_format = $day_format . '-' . $month_format . '-' . $year;

                    foreach ($types_list as $type_key => $type_name) {

                        $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                        if ($type_key == 'target_sale') {

                            $monthly_target_data = isset($paymentSums['monthly']) ? $paymentSums['monthly'] : [];

                            // if($day != 1){
                            //     $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day], 2) : 0;
                            //     $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth], 2) : 0;
                            // }else{
                                $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? $paymentSums['daily'][$year][$monthNum][$day] : 0;
                                $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? $paymentSums['daily'][$pre_year][12][$pre_daysInMonth] : 0;
                            // }

                        } else {

                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day]) : 0;

                            $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) : 0;

                        }

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;

                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                        $grandTotalAll += $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'monthly_target_data' => $monthly_target_data,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function pre_post_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.payment_report.pre_post_collection_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function PrePostYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $types_list = [
                'pre_sale' => 'Pre Sale Collection', 
                'post_sale' => 'Post Sale Collection',
                'closed_sale' => 'Closing'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            $result = $this->getPostPreSalesDataNew($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            // Step 1: Extract years from result safely
            $presale_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();
            
            // $postsale_years = isset($result['post_sale']['years']) && !empty($result['post_sale']['years']) ? collect($result['post_sale']['years']) : collect();
                        
            // Step 2: Merge, deduplicate, sort
            $allYears = $presale_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            // return $finalYears;
            $days = range(1, 31);

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    foreach ($months as $monthNum => $monthName) {

                        $Trend_data_list = [];

                        foreach ($types_list as $type_key => $type_name) {
                            
                            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
                            
                            if((int)$monthNum > $currentMonth){
                                $amount = 0;
                            }else{
                                $amount = isset($paymentSums[$year][$monthNum][$type_key]) ? round($paymentSums[$year][$monthNum][$type_key]) : 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                                $grandTotalAll += $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }

                }
            }
            
            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function pre_post_monthly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.pre_post_collection_month_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function PrePostMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getPostPreSalesDataNew($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $types_list = [
                'pre_sale' => 'Pre Sale Collection', 
                'post_sale' => 'Post Sale Collection',
                'closed_sale' => 'Closing'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $grandTotalAll = 0;

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    foreach ($types_list as $type_key => $type_name) {
                        
                        $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];

                        $amount = isset($paymentSums[$year][$monthNum][$day][$type_key]) ? round($paymentSums[$year][$monthNum][$day][$type_key]) : 0;
                        
                        $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums[$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;

                        $grandTotalAll += $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = $totals[$monthNum][$type_key] ?? 0;
                        $amount     = $data[$monthNum][$day][$type_key] ?? 0;

                        $percentages[$monthNum][$day][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    }
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTotalAll' => $grandTotalAll,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function drop_payment_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];
        return view('content.report_management.payment_report.drop_payment_yr_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function DropPaymentYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // Step 1: Extract years from result safely
            $collection_years = isset($result['out_rejected']['years']) && !empty($result['out_rejected']['years'])
                ? collect($result['out_rejected']['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data             = [];
            $Trend_data       = [];
            $pre_data         = [];
            $percentages      = [];
            $grandMonthTotals = []; // per month (all types)
            $grandDayTotals   = [];
            $grandAllTotal    = 0;

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;

                    $paymentSums = isset($result['out_rejected']) && !empty($result['out_rejected']) ? $result['out_rejected'] : [];

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {
                        
                        if((int)$monthNum > $currentMonth){
                            $amount = 0;
                        }else{
                            $amount = isset($paymentSums['monthTotals'][$year][$monthNum]) ? round($paymentSums['monthTotals'][$year][$monthNum]) : 0;
                        }
                            

                        // Save raw daily data
                        $data[$year][$monthNum] = $amount;

                        if($year_index != 0){

                            $Trend_data_list[$monthNum] = $amount;

                            // Month grand total
                            $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                            // Day totals across months
                            $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;

                            $grandAllTotal += $grandDayTotals[$monthNum] ?? 0;
                        }
                        
                    }

                    if($year_index != 0){
                        $Trend_data[$year] = $Trend_data_list;
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'year_colors' => $year_colors,
                'years' => $years
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function drop_payment_monthly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.drop_payment_monthly_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function DropPaymentMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $paymentSums = isset($result['out_rejected']) && !empty($result['out_rejected']) ? $result['out_rejected'] : [];

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $percentages     = [];
            $grandMonthTotals     = []; // per month (all types)
            $grandDayTotals = [];
            $grandAllTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums['dayTotals'][$year][$monthNum][$day]) ? round($paymentSums['dayTotals'][$year][$monthNum][$day]) : 0;
                    
                    $pre_amount = isset($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;

                    $Trend_data_list[$day] = $amount;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
                foreach ($days as $day) {
                    $amount     = $data[$monthNum][$day] ?? 0;
                    $percentage_val = $monthTotal > 0 ? round(($amount / $monthTotal) * 100) : 0;
                    $percentages[$monthNum][$day] = $percentage_val > 100 ? 100 : $percentage_val;
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function outstanding_yearly()
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        return view('content.report_management.payment_report.outstanding_yr_list', compact(
            'months',
        ))->with('report_heading', self::$report_heading);
    }

    public function OutstandingYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // Step 1: Extract years from result safely
            $collection_years = isset($result['collection']['years']) && !empty($result['collection']['years'])
                ? collect($result['collection']['years'])
                : collect();

            $payment_years = isset($result['payment']['years']) && !empty($result['payment']['years'])
                ? collect($result['payment']['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->merge($payment_years)->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $types = ['Payment', 'Collection'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    foreach ($months as $monthNum => $monthName) {
    
                        $Trend_data_list = [];
                                        
                        foreach ($types_list as $type_key => $type_name) {
                            
                            $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];
    
                            if((int)$monthNum > $currentMonth){
                                $amount = 0;
                            }else{
                                $amount = isset($paymentSums['monthTotals'][$year][$monthNum]) ? round($paymentSums['monthTotals'][$year][$monthNum]) : 0;
                            }
                            
                            // Save raw daily data
                            $data[$year][$monthNum][$type_key] = $amount;
    
                            if($year_index != 0){
    
                                $Trend_data_list[$type_key] = $amount;
    
                                // Month totals per type
                                $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;
    
                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;
    
                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;
    
                                $typeMonthTotals[$type_key][$year] = ($typeMonthTotals[$type_key][$year] ?? 0) + $amount;
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }
    
                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            // 🔹 Percentages
            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){
                    foreach ($months as $monthNum => $monthName) {

                        foreach ($types_list as $type_key => $type_name) {

                            if($year_index != 0){

                                $monthTotal = $totals[$year][$type_key] ?? 0;
                                $amount     = $data[$year][$monthNum][$type_key] ?? 0;

                                $percentages[$year][$monthNum][$type_key] = $monthTotal > 0
                                    ? round(($amount / $monthTotal) * 100, 2)
                                    : 0;
                            }
                        }
                    }
                }
            }
            
            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function outstanding_monthly(Request $request)
    {
        $months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.payment_report.outstanding_monthly_list', compact(
            'months',
            'days'
        ))->with('report_heading', self::$report_heading);
    }

    public function OutstandingMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->getOutstandingMonthlyData($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $types = ['Payment', 'Collection'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    foreach ($types_list as $type_key => $type_name) {
                        
                        $paymentSums = isset($result[$type_key]) && !empty($result[$type_key]) ? $result[$type_key] : [];

                        $amount = isset($paymentSums['dayTotals'][$year][$monthNum][$day]) ? round($paymentSums['dayTotals'][$year][$monthNum][$day]) : 0;
                        
                        $pre_amount = isset($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['dayTotals'][$pre_year][12][$pre_daysInMonth]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = $totals[$monthNum][$type_key] ?? 0;
                        $amount     = $data[$monthNum][$day][$type_key] ?? 0;

                        $percentages[$monthNum][$day][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    }
                }
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function intern_payment_yearly()
    {
        $currentYear = date('Y');
        $currentMonth = date('n');

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.payment_report.intern_payment_yr_list', compact(
           'currentYear','currentMonth','months'
        ))->with('report_heading', self::$report_heading);

    }

    public function InternPaymentYearlyData(Request $request)
    {
        try {

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            
            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $intern_details = ManageInternModel::where('branch_id', $branch_id)
                                ->where('status', 0)
                                ->get();

            $intern_amount_details = [];
            $intern_payment_years = [];

            $types = ['Total Interns', 'Revenue'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeYearTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = []; 

            $paymentSums = [
                'yearly' => [],
                'monthly' => []
            ];

            $totalInterns = [
                'yearly' => [],
                'monthly' => []
            ];

            foreach ($intern_details as $intern_data) {
                $inter_sno = $intern_data->sno ?? ''; 
                $inter_paid = (float)$intern_data->paid ?? 0;
                if($inter_paid > 0){
                    $inter_transaction_all = !empty($intern_data->transaction_all) ? json_decode($intern_data->transaction_all, true) : [];
                    $intern_amount_details[$inter_sno] = $inter_transaction_all;
                }
            }

            foreach ($intern_amount_details as $transactions) {
                
                foreach ($transactions as $transaction) {

                    $timestamp = $transaction['timestamp'] ?? null;
                    $paymentAmount = isset($transaction['payment_amount']) ? round($transaction['payment_amount']) : 0;

                    if (!$timestamp || $paymentAmount <= 0) {
                        continue;  // skip invalid data
                    }

                    $trans_date = Carbon::parse($timestamp);

                    $trans_year = $trans_date->year;
                    $trans_month = $trans_date->format('n');
                    $trans_day = $trans_date->format('j');

                    $intern_payment_years[trim($trans_year)] = trim($trans_year);
                    
                    // Add to monthly total
                    $paymentSums['monthly'][$trans_year][$trans_month] = ($paymentSums['monthly'][$trans_year][$trans_month] ?? 0) + $paymentAmount;

                    // Add to yearly total
                    $paymentSums['yearly'][$trans_year] = ($paymentSums['yearly'][$trans_year] ?? 0) + $paymentAmount;
                }
            }

            $yearList = !empty($intern_payment_years) ? collect(array_values($intern_payment_years)) : null; // Your starting list
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
            $lastYear = !empty($intern_payment_years) && (count($intern_payment_years) > 1) ? ' - '.$yearList->get(count($intern_payment_years) - 1) : ''; // Get year at index 0 (2024)
            
            $year_string = $firstYear.$lastYear;
            
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }
            
            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];

            $years = !empty($intern_payment_years) ? array_values($intern_payment_years) : [];

            foreach ($finalYears as $year_index => $year) {

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = 0;

                        // 🔹 Demo values
                        if ($type_key == 'total_interns') {
                            $amount = ManageInternModel::where('branch_id', $branch_id)
                                        ->where('status', 0)
                                        ->whereYear('created_at', $year)
                                        ->whereMonth('created_at', $monthNum)
                                        ->count();  // interns count
                            // $amount = rand(5, 20);  // interns count
                        } else if ($type_key == 'revenue') {
                            $amount = isset($paymentSums['monthly'][$year][$monthNum]) ? round($paymentSums['monthly'][$year][$monthNum]) : 0;
                        }

                        // Save raw daily data
                        $data[$year][$monthNum][$type_key] = $amount;

                        if($year_index != 0){
            
                            $Trend_data_list[$type_key] = $amount;

                            // Month totals per type
                            $totals[$year][$type_key] = ($totals[$year][$type_key] ?? 0) + $amount;

                            // Month grand total
                            $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                            // Day totals across months
                            $typeYearTotals[$type_key][$year] = ($typeYearTotals[$type_key][$year] ?? 0) + $amount;

                            $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                            
                            $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                        }
                    }

                    if($year_index != 0){
                        $Trend_data[$year][] = $Trend_data_list;
                    }
                }
            }

            // 🔹 Percentages
            foreach ($finalYears as $year_index => $year) {
                foreach ($months as $monthNum => $monthName) {
                    foreach ($types_list as $type_key => $type_name) {
                        if($year_index != 0){
                            $monthTotal = $totals[$year][$type_key] ?? 0;
                            $amount     = $data[$year][$monthNum][$type_key] ?? 0;

                            $percentages[$year][$monthNum][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeYearTotals' => $typeYearTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function intern_payment_monthly()
    {

        $currentYear = date('Y');
        $currentMonth = date('n');

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1, 31);
        
        return view('content.report_management.payment_report.intern_payment_month_list', compact(
            'currentYear','currentMonth','months','days'
        ))->with('report_heading', self::$report_heading);
    }

    public function InternPaymentMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y',strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year,2);

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $types = ['Total Interns', 'Revenue'];

            $type_keys = array_map(fn($type) => $this->slugify($type), $types);

            $types_list = array_combine($type_keys, $types);

            $type_count = !empty($types) && is_array($types) ? count($types) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = []; 

            $intern_details = ManageInternModel::where('branch_id', $branch_id)
                                ->where('status', 0)
                                ->get();

            $intern_amount_details = [];

            foreach ($intern_details as $intern_data) {
                $inter_sno = $intern_data->sno ?? ''; 
                $inter_paid = (float)$intern_data->paid ?? 0;
                if($inter_paid > 0){
                    $inter_transaction_all = !empty($intern_data->transaction_all) ? json_decode($intern_data->transaction_all, true) : [];
                    $intern_amount_details[$inter_sno] = $inter_transaction_all;
                }
            }

            $paymentSums = [
                'yearly' => [],
                'monthly' => [],
                'daily' => [],
            ];

            $totalInterns = [
                'yearly' => [],
                'monthly' => [],
                'daily' => [],
            ];

            foreach ($intern_amount_details as $transactions) {
                
                foreach ($transactions as $transaction) {

                    $timestamp = $transaction['timestamp'] ?? null;
                    $paymentAmount = isset($transaction['payment_amount']) ? round($transaction['payment_amount']) : 0;

                    if (!$timestamp || $paymentAmount <= 0) {
                        continue;  // skip invalid data
                    }

                    $trans_date = Carbon::parse($timestamp);

                    $trans_year = $trans_date->year;
                    $trans_month = $trans_date->format('n');
                    $trans_day = $trans_date->format('j');

                    // Add to daily total
                    $paymentSums['daily'][$trans_year][$trans_month][$trans_day] = ($paymentSums['daily'][$trans_year][$trans_month][$trans_day] ?? 0) + $paymentAmount;

                    // Add to monthly total
                    $paymentSums['monthly'][$trans_year][$trans_month] = ($paymentSums['monthly'][$trans_year][$trans_month] ?? 0) + $paymentAmount;

                    // Add to yearly total
                    $paymentSums['yearly'][$trans_year] = ($paymentSums['yearly'][$trans_year] ?? 0) + $paymentAmount;
                }
            }

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                    $Trend_data_list['date'] = $date_format;

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = 0;
                        $pre_amount = 0;

                        // 🔹 Demo values
                        if ($type_key == 'total_interns') {
                            $amount = ManageInternModel::where('branch_id', $branch_id)
                                        ->where('status', 0)
                                        ->whereYear('created_at', $year)
                                        ->whereMonth('created_at', $monthNum)
                                        ->whereDay('created_at', $day)
                                        ->count();  // interns count
                            $pre_amount = ManageInternModel::where('branch_id', $branch_id)
                                        ->where('status', 0)
                                        ->whereYear('created_at', $pre_year)
                                        ->whereMonth('created_at', 12)
                                        ->whereDay('created_at', $pre_daysInMonth)
                                        ->count();  // interns count
                            // $amount = rand(5, 20);  // interns count
                        } else if ($type_key == 'revenue') {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day]) ? round($paymentSums['daily'][$year][$monthNum][$day]) : 0;
                            $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth]) : 0;
                        }

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $Trend_data_list[$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = ($totals[$monthNum][$type_key] ?? 0) + $amount;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + $amount;

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = ($typeMonthTotals[$type_key][$monthNum] ?? 0) + $amount;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }

            }

            // 🔹 Percentages
            foreach ($months as $monthNum => $monthName) {
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {

                        $monthTotal = $totals[$monthNum][$type_key] ?? 0;
                        $amount     = $data[$monthNum][$day][$type_key] ?? 0;

                        $percentages[$monthNum][$day][$type_key] = $monthTotal > 0
                            ? round(($amount / $monthTotal) * 100, 2)
                            : 0;
                    }
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => $types,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }
    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }
    
    private function getOutstandingMonthlyData(int $branch_id)
    {
        try {
            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            // Get dropped customer IDs
            $drop_customer_ids = DB::table('za_drop_refund')
                ->where('za_drop_refund.branch_id', $branch_id)
                ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
                ->where('za_drop_refund.bh_status', 1)
                ->pluck('za_training.payment_id')
                ->toArray();

            $customers = CustomerModel::where('branch_id', $branch_id)
                ->where('status', 0)
                ->with(['payments' => function ($q) {
                    $q->orderBy('sno', 'asc');
                }])
                ->get();

            $branchCost = BranchModel::where('sno', $branch_id)
                ->where('status', 0)
                ->pluck('min_prd_cost')
                ->first() ?? 0;

            $overallStandings = [];

            foreach ($customers as $customer) {
                $customerCumulative = 0.0;
                $reachedThreshold = false;

                foreach ($customer->payments as $payment) {
                    if (!isset($payment->status, $payment->amount, $payment->paidAmount, $payment->payment_id)) {
                        continue;
                    }

                    if ((int)$payment->status === 2 || $payment->amount < 0 || $payment->paidAmount < 0) {
                        continue;
                    }

                    $isDropped = in_array($payment->payment_id, $drop_customer_ids, true);

                    if ((int)$payment->status === 1) {
                        $customerCumulative += (float)$payment->paidAmount;

                        if (!$reachedThreshold && $customerCumulative <= $branchCost) {
                            continue;
                        }

                        if (!$reachedThreshold && $customerCumulative > $branchCost) {
                            $reachedThreshold = true;
                        }
                    }

                    if ((int)$payment->status === 0) {
                        if (empty($payment->nextPayDate)) continue;
                        $month = \Carbon\Carbon::parse($payment->nextPayDate)->format('Y-n-j');
                        $amount = (float)$payment->amount;
                        $bg = 'payment';
                    } elseif ((int)$payment->status === 1) {
                        if (empty($payment->initialPayDate)) continue;
                        $month = \Carbon\Carbon::parse($payment->initialPayDate)->format('Y-n-j');
                        $amount = (float)$payment->paidAmount;
                        $bg = 'collection';
                    } else {
                        continue;
                    }

                    if ($isDropped) {
                        $bg = 'out_rejected';
                    }

                    $courseTypeName = $payment->course?->courseType?->course_type_name ?? null;

                    if (!isset($overallStandings[$month])) {
                        $overallStandings[$month] = ['rows' => []];
                    }

                    $overallStandings[$month]['rows'][] = [
                        'month' => $month,
                        'name' => $customer->cus_name,
                        'customerId' => $customer->customer_id,
                        'courseType' => $courseTypeName,
                        'amount' => $amount,
                        'bg' => $bg,
                        'payment_id' => $payment->payment_id,
                        'status' => $payment->status,
                        'cumulative' => $customerCumulative,
                        'reachedThreshold' => $reachedThreshold,
                    ];
                }
            }

            $result = [];

            foreach ($overallStandings as $date => $info) {
                $parts = explode('-', $date);
                if (count($parts) !== 3) continue;
                [$year, $month, $day] = $parts;

                foreach ($info['rows'] as $row) {
                    $bg = $row['bg'];
                    $amount = $row['amount'];

                    if (!isset($result[$bg])) {
                        $result[$bg] = [
                            'yearTotals' => [],
                            'monthTotals' => [],
                            'dayTotals' => [],
                            'years' => [],
                        ];
                    }

                    $result[$bg]['yearTotals'][$year] = ($result[$bg]['yearTotals'][$year] ?? 0) + $amount;

                    $result[$bg]['years'][trim($year)] = trim($year);

                    if (!isset($result[$bg]['monthTotals'][$year])) {
                        $result[$bg]['monthTotals'][$year] = [];
                    }
                    $result[$bg]['monthTotals'][$year][$month] = ($result[$bg]['monthTotals'][$year][$month] ?? 0) + $amount;

                    if (!isset($result[$bg]['dayTotals'][$year])) {
                        $result[$bg]['dayTotals'][$year] = [];
                    }
                    if (!isset($result[$bg]['dayTotals'][$year][$month])) {
                        $result[$bg]['dayTotals'][$year][$month] = [];
                    }
                    $result[$bg]['dayTotals'][$year][$month][$day] = ($result[$bg]['dayTotals'][$year][$month][$day] ?? 0) + $amount;
                }
            }

            // Round totals
            foreach ($result as $bg => &$groups) {
                foreach ($groups['yearTotals'] as $year => &$yearTotal) {
                    $yearTotal = round($yearTotal, 2);
                }
                foreach ($groups['monthTotals'] as $year => &$months) {
                    foreach ($months as $month => &$monthTotal) {
                        $monthTotal = round($monthTotal, 2);
                    }
                }
                foreach ($groups['dayTotals'] as $year => &$months) {
                    foreach ($months as $month => &$days) {
                        foreach ($days as $day => &$dayTotal) {
                            $dayTotal = round($dayTotal, 2);
                        }
                    }
                }
            }
            unset($groups, $months, $days, $yearTotal, $monthTotal, $dayTotal);

            return $result;

        } catch (\Exception $e) {
            \Log::error("Error in getOutstandingMonthlyData: " . $e->getMessage());
            return null; // or handle as you prefer
        }
    }

    private function getPostPreSalesData(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            // Get all customer data with pre/post training IDs concatenated
            $currentMonthCustomerPre = CustomerModel::select(
                'za_customer.course_id', 
                'za_customer.sno',
                DB::raw("
                    GROUP_CONCAT(
                        CASE 
                            WHEN za_training.post_sale_check = 1 AND za_customer.post_sale_check = 1 
                            THEN za_customer.customer_id 
                        END 
                        ORDER BY za_customer.customer_id SEPARATOR ','
                    ) AS post_training_ids
                "),
                DB::raw("
                    GROUP_CONCAT(
                        CASE 
                            WHEN za_training.post_sale_check != 1 AND za_customer.post_sale_check != 1 
                            THEN za_customer.customer_id 
                        END 
                        ORDER BY za_customer.customer_id SEPARATOR ','
                    ) AS pre_training_ids
                ")
            )
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->where('za_customer.branch_id', $branch_id)
            ->whereIn('za_customer.status', [0, 6])
            ->groupBy('za_customer.course_id', 'za_customer.sno')
            ->get();

            // Flatten all pre_training_ids and post_training_ids into single arrays to minimize queries
            $allPreIds = [];
            $allPostIds = [];

            foreach ($currentMonthCustomerPre as $customer) {
                if (!empty($customer->pre_training_ids)) {
                    $allPreIds = array_merge($allPreIds, explode(',', $customer->pre_training_ids));
                }
                if (!empty($customer->post_training_ids)) {
                    $allPostIds = array_merge($allPostIds, explode(',', $customer->post_training_ids));
                }
            }

            // Remove duplicates just in case
            $allPreIds = array_unique($allPreIds);
            $allPostIds = array_unique($allPostIds);

            // Function to get sum grouped by year, month, day for given IDs
            $getTransactionSums = function(array $transSourceIds) use ($branch_id) {
                if (empty($transSourceIds)) {
                    return collect();
                }

                return TransactionModel::select(
                    DB::raw('YEAR(transaction_date) as train_year'),
                    DB::raw('MONTH(transaction_date) as train_month'),
                    DB::raw('DAY(transaction_date) as train_day'),
                    DB::raw('SUM(credit) as total_credit')
                )
                ->where('branch_id', $branch_id)
                ->whereIn('trans_source_id', $transSourceIds)
                ->groupBy('train_year', 'train_month', 'train_day')
                ->get();
            };

            // Get all transaction sums
            $preTransactions = $getTransactionSums($allPreIds);
            $postTransactions = $getTransactionSums($allPostIds);

            // Get total transactions (all)
            $totalTransactions = TransactionModel::select(
                DB::raw('YEAR(transaction_date) as train_year'),
                DB::raw('MONTH(transaction_date) as train_month'),
                DB::raw('DAY(transaction_date) as train_day'),
                DB::raw('SUM(credit) as total_credit')
            )
            ->where('branch_id', $branch_id)
            ->where('customer_type', '!=', 2)
            ->groupBy('train_year', 'train_month', 'train_day')
            ->get();

            $totalTargets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                        ->select(
                            DB::raw('YEAR(branch_target.date) as train_year'),
                            DB::raw('MONTH(branch_target.date) as train_month'),
                            DB::raw('DAY(branch_target.date) as train_day'),
                            'branch_target.monthly_target as total_credit'
                            )
                        ->get();

            
            // Distribute monthly target evenly across all days of the month for daily targets
            $dailyTargets = collect();

            foreach ($totalTargets as $target) {

                $year = $target->train_year;
                $month = $target->train_month;
                $monthlyTarget = $target->total_credit;

                // Calculate days in the month
                $daysInMonth = Carbon::create($year, $month, 1)->daysInMonth;

                // Daily target value
                $dailyValue = $monthlyTarget / $daysInMonth;

                // Add daily entries for each day of the month
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $dailyTargets->push((object)[
                        'train_year' => $year,
                        'train_month' => $month,
                        'train_day' => $day,
                        'total_credit' => round($dailyValue,2),
                    ]);
                }
            }

            // Helper to accumulate results into the structure
            $accumulate = function($collection) {
                $result = [
                    'yearly' => [],
                    'monthly' => [],
                    'daily' => [],
                    'years' => [],
                ];

                foreach ($collection as $item) {
                    $y = $item->train_year;
                    $m = $item->train_month;
                    $d = $item->train_day;
                    $c = $item->total_credit;

                    $result['daily'][$y][$m][$d] = ($result['daily'][$y][$m][$d] ?? 0) + $c;
                    $result['monthly'][$y][$m] = ($result['monthly'][$y][$m] ?? 0) + $c;
                    $result['yearly'][$y] = ($result['yearly'][$y] ?? 0) + $c;
                    $result['years'][$y] = $y;
                }

                return $result;
            };

            $pre_result = $accumulate($preTransactions);
            $post_result = $accumulate($postTransactions);
            $post_total = $accumulate($totalTransactions);
            $target_sale = $accumulate($totalTargets); // yearly & monthly only from original monthly targets

            // Replace daily with distributed daily targets:
            $target_sale['daily'] = $accumulate($dailyTargets)['daily'];

            // Calculate post_closed_result = post_total - (pre_result + post_result)
            $post_closed_result = [
                'yearly' => [],
                'monthly' => [],
                'daily' => [],
            ];

            // Helper function to subtract arrays recursively
            $subtractResults = function($totalArr, $preArr, $postArr) {
                $result = [];

                foreach ($totalArr as $year => $months) {
                    if (is_array($months)) {
                        foreach ($months as $month => $daysOrVal) {
                            if (is_array($daysOrVal)) {
                                foreach ($daysOrVal as $day => $value) {
                                    $preVal = $preArr[$year][$month][$day] ?? 0;
                                    $postVal = $postArr[$year][$month][$day] ?? 0;
                                    $result[$year][$month][$day] = max(0, ($value - ($preVal + $postVal)));
                                }
                            } else {
                                // Monthly or yearly value
                                $preVal = $preArr[$year][$month] ?? 0;
                                $postVal = $postArr[$year][$month] ?? 0;
                                $result[$year][$month] = max(0, $daysOrVal - ($preVal + $postVal));
                            }
                        }
                    } else {
                        // Yearly level
                        $preVal = $preArr[$year] ?? 0;
                        $postVal = $postArr[$year] ?? 0;
                        $result[$year] = max(0, $months - ($preVal + $postVal));
                    }
                }

                return $result;
            };

            // Calculate post_closed_result for daily, monthly, yearly
            $post_closed_result['daily'] = $subtractResults($post_total['daily'], $pre_result['daily'], $post_result['daily']);
            $post_closed_result['monthly'] = $subtractResults($post_total['monthly'], $pre_result['monthly'], $post_result['monthly']);
            $post_closed_result['yearly'] = $subtractResults($post_total['yearly'], $pre_result['yearly'], $post_result['yearly']);

            $sumResults = function($arr1, $arr2, $arr3) {

                $result = [];

                // Get all unique keys from all arrays
                $allYears = array_unique(array_merge(array_keys($arr1 ?? []), array_keys($arr2 ?? []), array_keys($arr3 ?? [])));

                foreach ($allYears as $year) {
                    $val1 = $arr1[$year] ?? [];
                    $val2 = $arr2[$year] ?? [];
                    $val3 = $arr3[$year] ?? [];

                    if (is_array($val1) || is_array($val2) || is_array($val3)) {
                        // Merge months or days level
                        $allMonths = array_unique(array_merge(
                            is_array($val1) ? array_keys($val1) : [],
                            is_array($val2) ? array_keys($val2) : [],
                            is_array($val3) ? array_keys($val3) : []
                        ));

                        foreach ($allMonths as $month) {
                            $m1 = is_array($val1) && isset($val1[$month]) ? $val1[$month] : 0;
                            $m2 = is_array($val2) && isset($val2[$month]) ? $val2[$month] : 0;
                            $m3 = is_array($val3) && isset($val3[$month]) ? $val3[$month] : 0;

                            if (is_array($m1) || is_array($m2) || is_array($m3)) {
                                // Day level
                                $allDays = array_unique(array_merge(
                                    is_array($m1) ? array_keys($m1) : [],
                                    is_array($m2) ? array_keys($m2) : [],
                                    is_array($m3) ? array_keys($m3) : []
                                ));

                                foreach ($allDays as $day) {
                                    $d1 = is_array($m1) && isset($m1[$day]) ? $m1[$day] : 0;
                                    $d2 = is_array($m2) && isset($m2[$day]) ? $m2[$day] : 0;
                                    $d3 = is_array($m3) && isset($m3[$day]) ? $m3[$day] : 0;

                                    $result[$year][$month][$day] = $d1 + $d2 + $d3;
                                }
                            } else {
                                // Month level
                                $result[$year][$month] = $m1 + $m2 + $m3;
                            }
                        }
                    } else {
                        // Year level only
                        $result[$year] = $val1 + $val2 + $val3;
                    }
                }

                return $result;
            };

            // Create collection_sale by summing pre_sale + post_sale + closed_sale
            $collection_sale = [
                'yearly' => $sumResults($pre_result['yearly'], $post_result['yearly'], $post_closed_result['yearly']),
                'monthly' => $sumResults($pre_result['monthly'], $post_result['monthly'], $post_closed_result['monthly']),
                'daily' => $sumResults($pre_result['daily'], $post_result['daily'], $post_closed_result['daily']),
            ];

            // Return results - can return more if needed
            return [
                'pre_sale' => $pre_result,
                'post_sale' => $post_result,
                'total_sale' => $post_total,
                'closed_sale' => $post_closed_result,
                'collection_sale' => $collection_sale,
                'target_sale' => $target_sale,
            ];

        } catch (\Exception $e) {
            \Log::error("Error in getOutstandingMonthlyData: " . $e->getMessage());
            return null; // or handle as you prefer
        }
    }

    public function getPostPreSalesDataNew(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            // Get all unique years and months from transactions
            $years = TransactionModel::where('branch_id', $branch_id)
                ->selectRaw('DISTINCT YEAR(transaction_date) as year')
                ->orderBy('year', 'ASC')
                ->pluck('year')
                ->toArray();

            $finalData = [
                'yearly'  => [],
                'monthly' => [],
                'daily'   => [],
                'years'   => [],
            ];

            foreach ($years as $year) {

                // ---- YEARLY ----
                $totalSumAll = TransactionModel::where('branch_id', $branch_id)
                    ->whereYear('transaction_date', $year)
                    ->sum('credit');

                $currentYearCustomerPre = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                    ->whereIn('za_customer.status', [0, 6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->whereIn('za_customer.status', [0, 6])
                    ->whereYear('za_customer.created_at', $year)
                    ->get();

                $customerIds = $currentYearCustomerPre->pluck('training_id');

                $totalSumPre = TransactionModel::where('branch_id', $branch_id)
                    ->whereIn('training_id', $customerIds)
                    ->whereYear('transaction_date', $year)
                    ->sum('credit');

                $currentYearCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                    ->whereIn('za_customer.status', [0, 6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_customer.post_sale_check', 1)
                    ->where('za_training.post_sale_check', 1)
                    ->whereIn('za_customer.status', [0, 6])
                    ->whereYear('za_training.created_at', $year)
                    ->get();

                $customerIdsPost = $currentYearCustomerPost->pluck('training_id');

                $totalSumPost = TransactionModel::where('branch_id', $branch_id)
                    ->whereIn('training_id', $customerIdsPost)
                    ->whereYear('transaction_date', $year)
                    ->sum('credit');

                $totalSumClosing = $totalSumAll - ($totalSumPre + $totalSumPost);

                $finalData['yearly'][$year] = [
                    'total_sum_all'  => $totalSumAll,
                    'pre_sale'  => $totalSumPre,
                    'post_sale' => $totalSumPost,
                    'closed_sale' => $totalSumClosing,
                ];


                $finalData['years'][$year] = $year;

                $months = $this->getYearBasedMonths($year);

                // ---- MONTHLY ----
                foreach ($months as $month => $monthName) {

                    $totalSumAll_m = TransactionModel::where('branch_id', $branch_id)
                        ->whereYear('transaction_date', $year)
                        ->whereMonth('transaction_date', $month)
                        ->sum('credit');

                    $currentMonthCustomerPre = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                        ->whereIn('za_customer.status', [0, 6])
                        ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                        ->where('za_customer.branch_id', $branch_id)
                        ->whereIn('za_customer.status', [0, 6])
                        ->whereYear('za_customer.created_at', $year)
                        ->whereMonth('za_customer.created_at', $month)
                        ->get();

                    $customerIds_m = $currentMonthCustomerPre->pluck('training_id');

                    $totalSumPre_m = TransactionModel::where('branch_id', $branch_id)
                        ->whereIn('training_id', $customerIds_m)
                        ->whereYear('transaction_date', $year)
                        ->whereMonth('transaction_date', $month)
                        ->sum('credit');

                    $currentMonthCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                        ->whereIn('za_customer.status', [0, 6])
                        ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                        ->where('za_customer.branch_id', $branch_id)
                        ->where('za_customer.post_sale_check', 1)
                        ->where('za_training.post_sale_check', 1)
                        ->whereIn('za_customer.status', [0, 6])
                        ->whereYear('za_training.created_at', $year)
                        ->whereMonth('za_training.created_at', $month)
                        ->get();

                    $customerIdsPost_m = $currentMonthCustomerPost->pluck('training_id');

                    $totalSumPost_m = TransactionModel::where('branch_id', $branch_id)
                        ->whereIn('training_id', $customerIdsPost_m)
                        ->whereYear('transaction_date', $year)
                        ->whereMonth('transaction_date', $month)
                        ->sum('credit');

                    $totalSumClosing_m = $totalSumAll_m - ($totalSumPre_m + $totalSumPost_m);

                    $finalData['monthly'][$year][$month] = [
                        'total_sum_all'  => $totalSumAll_m,
                        'pre_sale'  => $totalSumPre_m,
                        'post_sale' => $totalSumPost_m,
                        'closed_sale' => $totalSumClosing_m,
                    ];

                    $finalData['years'][$year] = $year;

                    // ---- DAILY ----
                    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                    
                    for ($day = 1; $day <= $daysInMonth; $day++) {

                        $totalSumAll_d = TransactionModel::where('branch_id', $branch_id)
                            ->whereYear('transaction_date', $year)
                            ->whereMonth('transaction_date', $month)
                            ->whereDay('transaction_date', $day)
                            ->sum('credit');

                        $currentDayCustomerPre = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                            ->whereIn('za_customer.status', [0, 6])
                            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                            ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                            ->where('za_customer.branch_id', $branch_id)
                            ->whereIn('za_customer.status', [0, 6])
                            ->whereYear('za_customer.created_at', $year)
                            ->whereMonth('za_customer.created_at', $month)
                            ->whereDay('za_customer.created_at', $day)
                            ->get();

                        $customerIds_d = $currentDayCustomerPre->pluck('training_id');

                        $totalSumPre_d = TransactionModel::where('branch_id', $branch_id)
                            ->whereIn('training_id', $customerIds_d)
                            ->whereYear('transaction_date', $year)
                            ->whereMonth('transaction_date', $month)
                            ->whereDay('transaction_date', $day)
                            ->sum('credit');

                        $currentDayCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno AS training_id')
                            ->whereIn('za_customer.status', [0, 6])
                            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                            ->where('za_customer.branch_id', $branch_id)
                            ->where('za_customer.post_sale_check', 1)
                            ->where('za_training.post_sale_check', 1)
                            ->whereIn('za_customer.status', [0, 6])
                            ->whereYear('za_training.created_at', $year)
                            ->whereMonth('za_training.created_at', $month)
                            ->whereDay('za_training.created_at', $day)
                            ->get();

                        $customerIdsPost_d = $currentDayCustomerPost->pluck('training_id');

                        $totalSumPost_d = TransactionModel::where('branch_id', $branch_id)
                            ->whereIn('training_id', $customerIdsPost_d)
                            ->whereYear('transaction_date', $year)
                            ->whereMonth('transaction_date', $month)
                            ->whereDay('transaction_date', $day)
                            ->sum('credit');

                        $totalSumClosing_d = $totalSumAll_d - ($totalSumPre_d + $totalSumPost_d);

                        $finalData['daily'][$year][$month][$day] = [
                            'total_sum_all'  => $totalSumAll_d,
                            'pre_sale'  => $totalSumPre_d,
                            'post_sale' => $totalSumPost_d,
                            'closed_sale' => $totalSumClosing_d,
                        ];

                        $finalData['years'][$year] = $year;
                    }
                }
            }

           // Return results - can return more if needed
            return $finalData;

        } catch (\Exception $e) {
            \Log::error("Error in getOutstandingMonthlyData: " . $e->getMessage());
            return null; // or handle as you prefer
        }
    }
}
