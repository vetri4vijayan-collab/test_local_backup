<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;

class LeadReports extends Controller
{
    public static $report_heading = 'Analysis';
    public function index()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');

        return view('content.report_management.lead_report.total_lead_list', compact(
            'months',
            'days',
            'yearShort'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsData(Request $request)
    {
        try {
            
            $inputYear = $request->year;
    
            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            
            $days = range(1,31);
            $year = date('Y',strtotime($filter_year));
            $yearShort = date('y',strtotime($filter_year));

            $months = $this->getYearBasedMonths($year);

            $months_colors = [
                1=>'hsl(220,65%,55%)',
                2=>'hsl(250,65%,55%)',
                3=>'hsl(280,65%,55%)',
                4=>'hsl(310,65%,55%)',
                5=>'hsl(340,65%,55%)',
                6=>'hsl(10,65%,55%)',
                7=>'hsl(40,65%,55%)',
                8=>'hsl(70,65%,55%)',
                9=>'hsl(100,65%,55%)',
                10=>'hsl(130,65%,55%)',
                11=>'hsl(160,65%,55%)',
                12=>'hsl(190,65%,55%)'
            ];

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $leadsData = [];

            // Generate daily data
            foreach ($months as $monthNum => $monthName) {

                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);

                for ($d = 1; $d <= $daysInMonth; $d++) {

                    // Current day queries (as before)
                    $lead_detail_modal = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                        ->select('za_lead.sno')
                        // ->where('za_staff.status',0)
                        // ->where('za_staff.department_id', 1)
                        ->where('za_lead.branch_id', $branch_id)
                        ->whereNotIn('za_lead.status',[2,6])
                        ->where('za_lead.spam_verified',0)
                        ->where('za_lead.drop_verified', 0)
                        ->where('za_lead.internal_status',0)
                        ->whereRaw('YEAR(za_lead.registered_date) = ?', [$year])
                        ->whereRaw('MONTH(za_lead.registered_date) = ?', [$monthNum])
                        ->whereRaw('DAY(za_lead.registered_date) = ?', [$d])
                        ->count();
                    $leads = (int)$lead_detail_modal ?? 0;

                    $conversion_detail_modal = CustomerModel::select('za_customer.sno')
                        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.status', 4)
                        ->where('za_lead.branch_id', $branch_id)
                        ->where('za_lead.spam_verified',0)
                        ->where('za_customer.status', 0)
                        ->whereRaw('YEAR(za_customer.created_at) = ?', [$year])
                        ->whereRaw('MONTH(za_customer.created_at) = ?', [$monthNum])
                        ->whereRaw('DAY(za_customer.created_at) = ?', [$d])
                        ->count();
                    $conversion = (int)$conversion_detail_modal ?? 0;
                    
                    // Calculate previous day date components

                    $prevLeads = 0;
                    $prevConversion = 0;

                    if ((int)$monthNum == 1 && $d == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }else if($d == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$monthNum - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }

                    $prev_lead_detail = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                        // ->where('za_staff.status',0)
                        // ->where('za_staff.department_id', 1)
                        ->select('za_lead.sno')
                        ->where('za_lead.branch_id', $branch_id)
                        ->whereNotIn('za_lead.status',[2,6])
                        ->where('za_lead.spam_verified',0)
                        ->where('za_lead.drop_verified', 0)
                        ->where('za_lead.internal_status',0)
                        ->whereRaw('YEAR(za_lead.registered_date) = ?', [$prevYear])
                        ->whereRaw('MONTH(za_lead.registered_date) = ?', [$prevMonth])
                        ->whereRaw('DAY(za_lead.registered_date) = ?', [$prevDay])
                        ->count();
                    $prevLeads = (int)$prev_lead_detail ?? 0;

                    // Query previous day's conversion count
                    $prev_conversion_detail = CustomerModel::select('za_customer.sno')
                        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                        ->where('za_lead.status', 4)
                        ->where('za_lead.branch_id', $branch_id)
                        ->where('za_lead.spam_verified',0)
                        ->where('za_customer.status', 0)
                        ->whereRaw('YEAR(za_customer.created_at) = ?', [$prevYear])
                        ->whereRaw('MONTH(za_customer.created_at) = ?', [$prevMonth])
                        ->whereRaw('DAY(za_customer.created_at) = ?', [$prevDay])
                        ->count();
                    $prevConversion = (int)$prev_conversion_detail ?? 0;

                    // Store data including previous day counts
                    $leadsData[$monthNum][$d] = [
                        'leads' => $leads,
                        'conversion' => $conversion,
                        'prev_leads' => $prevLeads,
                        'prev_conversion' => $prevConversion,
                    ];
                }
            }

            $monthlyLeads = [];
            $monthlyConversions = [];
            $weeklyLeads = [];
            $weeklyConversions = [];

            // Calculate monthly & weekly totals
            foreach($months as $monthNum => $monthName){
                $monthLeads = 0;
                $monthConversions = 0;
                $weeksLeads = [];
                $weeksConversions = [];
                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $year);

                for($d=1;$d<=$daysInMonth;$d++){
                    if(isset($leadsData[$monthNum][$d])){

                        $leads = $leadsData[$monthNum][$d]['leads'];
                        $conversion = $leadsData[$monthNum][$d]['conversion'];

                        $monthLeads += $leads;
                        $monthConversions += $conversion;

                        // Week calculation: 1-7 => Week1, 8-14 => Week2, etc.
                        $weekNum = ceil($d / 7);
                        if(!isset($weeksLeads[$weekNum])) $weeksLeads[$weekNum] = 0;
                        if(!isset($weeksConversions[$weekNum])) $weeksConversions[$weekNum] = 0;

                        $weeksLeads[$weekNum] += $leads;
                        $weeksConversions[$weekNum] += $conversion;
                    }
                }

                $monthlyLeads[$monthNum] = $monthLeads;
                $monthlyConversions[$monthNum] = $monthConversions;
                $weeklyLeads[$monthNum] = array_values($weeksLeads);          // week1..week5
                $weeklyConversions[$monthNum] = array_values($weeksConversions);
            }

            return response()->json([
                'months' => $months,
                'days' => $days,
                'year' => $year,
                'yearShort' => $yearShort,
                'leadsData' => $leadsData,
                'monthlyLeads' => $monthlyLeads,
                'monthlyConversions' => $monthlyConversions,
                'weeklyLeads' => $weeklyLeads,
                'weeklyConversions' => $weeklyConversions,
                'currentMonth' => now()->month,
                'MonthColors' => $months_colors
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function yearly_lead()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.lead_report.total_lead_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsYearlyData(Request $request)
    {
        try {
            
            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            // Get lead years
            $leadYears = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                // ->where('za_staff.status',0)
                // ->where('za_staff.department_id', 1)
                ->where('za_lead.branch_id', $branch_id)
                ->whereNotIn('za_lead.status',[2,6])
                ->where('za_lead.spam_verified',0)
                ->where('za_lead.drop_verified', 0)
                ->where('za_lead.internal_status',0)
                ->whereNotNull('za_lead.registered_date')
                ->select(DB::raw('YEAR(za_lead.registered_date) as year'))
                ->distinct()
                ->pluck('year');

            // Get conversion years
            $conversionYears = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
            ->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->whereNotNull('za_lead.registered_date')->where('za_customer.status', 0)
            ->select(DB::raw('YEAR(za_customer.created_at) as year'))
            ->distinct()
            ->pluck('year');
            
            
            // Combine and get unique years
            $allYears = $leadYears->merge($conversionYears)->unique()->sort()->values();
            
            $out_Years = $allYears->sort()->values()->toArray();
            
            $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)
            
            $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)
            
            $year_string = $firstYear.$lastYear;

            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)
            
            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }
            
            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];

            $years = $out_Years;

            $months = [
                1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
                7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
            ];

            $leadsData = [];

            
            // Loop through each year and each month
            foreach ($finalYears as $yr) {
                foreach ($months as $monthNum => $monthName) {
                    $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $monthNum, $yr);
                    for ($d = 1; $d <= $daysInMonth; $d++) {
                        // $dayOfWeek = date('w', strtotime("$yr-$monthNum-$d"));
                        // if ($dayOfWeek != 0) { // skip Sundays
                            //Fetch leads count
                            $lead_detail_modal = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                                // ->where('za_staff.status',0)
                                // ->where('za_staff.department_id', 1)
                                ->where('za_lead.branch_id', $branch_id)
                                ->whereNotIn('za_lead.status',[2,6])
                                ->where('za_lead.spam_verified',0)
                                ->where('za_lead.drop_verified', 0)
                                ->where('za_lead.internal_status',0)
                                ->whereYear('za_lead.registered_date', $yr)
                                ->whereMonth('za_lead.registered_date', $monthNum)
                                ->whereDay('za_lead.registered_date', $d)
                                ->count();
                            $leads = (int)$lead_detail_modal ?? 0;

                            //Fetch conversions count
                            $conversions_detail_modal = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                                ->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)
                                ->where('za_customer.status', 0)
                                ->whereYear('za_customer.created_at', $yr)
                                ->whereMonth('za_customer.created_at', $monthNum)
                                ->whereDay('za_customer.created_at', $d)
                                ->count();
                            $conversions = (int)$conversions_detail_modal ?? 0;

                            $leadsData[$yr][$monthNum][$d] = [
                                'leads' => $leads,
                                'conversion' => $conversions
                            ];
                        // }
                    }
                }
            }

            // Initialize aggregators
            $yearlyLeads = [];
            $yearlyConversions = [];
            $monthlyLeads = [];
            $monthlyConversions = [];

            foreach ($years as $yr) {
                $yearLeadsTotal = 0;
                $yearConversionsTotal = 0;

                $monthlyLeads[$yr] = [];
                $monthlyConversions[$yr] = [];

                foreach ($months as $monthNum => $monthName) {
                    $monthlyLead = 0;
                    $monthlyConversion = 0;

                    if (isset($leadsData[$yr][$monthNum])) {
                        foreach ($leadsData[$yr][$monthNum] as $dayData) {
                            $monthlyLead += (int)$dayData['leads'];
                            $monthlyConversion += (int)$dayData['conversion'];
                        }
                    }

                    $monthlyLeads[$yr][] = $monthlyLead;
                    $monthlyConversions[$yr][] = $monthlyConversion;

                    $yearLeadsTotal += $monthlyLead;
                    $yearConversionsTotal += $monthlyConversion;
                }

                $yearlyLeads[] = $yearLeadsTotal;
                $yearlyConversions[] = $yearConversionsTotal;
            }

            $line_MonthColors = $this->generateAttractiveColors($years);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'months' => $months,
                'years' => $years,
                'leadsData' => $leadsData,
                'yearlyLeads' => $yearlyLeads,
                'yearlyConversions' => $yearlyConversions,
                'monthlyLeads' => $monthlyLeads,
                'monthlyConversions' => $monthlyConversions,
                'currentMonth' => now()->month,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function lead_src_month()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        $currentMonth = date('n'); // numeric month (1–12)

        return view('content.report_management.lead_report.total_lead_src_list', compact(
            'months','yearShort','days','year','currentMonth'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsSourceData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $perPage = $request->input('per_page', 10); // Default to 25 per page

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadSourceModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'lead_source_name')->orderBy('lead_source_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_source_name];
            })->toArray();
            
            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $currentMonth = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');
    
            $leadsData       = [];
            $pieData         = []; // daily pie for leads
            $convPieData     = []; // daily pie for conversions
            $totalLine       = []; // total leads
            $sourceTrends    = []; // daily leads per source
            $convSourceTrends = []; // daily conversions per source
            
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $year);

            if($today_year == $year && $today_month == $currentMonth){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            for ($d=1; $d <= $daysInMonth; $d++) {
                // $dayOfWeek = date('w', strtotime("$year-$currentMonth-$d"));
                // if ($dayOfWeek != 0) { // skip Sunday
                    $dateLabel = sprintf('%02d-%02d-%s', $d, $currentMonth, $yearShort);
                    $dailyPie = [];
                    $dailyConvPie = [];
                    $dailyTotal = 0;

                    foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {
       
                        $lead_detail_modal = LeadModel::where('status', '!=',2)->where('branch_id', $branch_id)
                                    ->where('lead_source_id', $lead_src_id)->where('spam_verified',0)
                                    ->whereYear('registered_date', $year)
                                    ->where('internal_status', '!=', 1)
                                    ->where('created_by', '>', 0)
                                    ->whereMonth('registered_date', $querycurrentMonth)
                                    ->whereDay('registered_date', $d)
                                    ->count();
                        $leads = (int)$lead_detail_modal ?? 0;

                        //Fetch conversions count
                        $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                            $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                        })->whereYear('za_customer.created_at', $year)
                        ->whereMonth('za_customer.created_at', (int)$querycurrentMonth)
                        ->whereDay('za_customer.created_at', $d)
                        ->where('za_customer.status', 0)
                        ->count();

                        $conversion = (int) $conversions_detail_modal;

                        $prevLeads = 0;
                        $prevConversion = 0;
                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        $day_query = false;

                        if ((int)$currentMonth == 1 && $d == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                            $day_query = true;
                        }else if($d == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$currentMonth - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                            $day_query = true;
                        }
                        
                        
                        if($day_query){
                            $prev_lead_detail = LeadModel::select('sno')
                            ->where('status', '!=', 2)
                            ->where('branch_id', $branch_id)->where('spam_verified',0)
                            ->where('lead_source_id', $lead_src_id)
                            ->where('internal_status', '!=', 1)
                            ->where('created_by', '>', 0)
                            ->whereRaw('YEAR(registered_date) = ?', [$prevYear])
                            ->whereRaw('MONTH(registered_date) = ?', [$prevMonth])
                            ->whereRaw('DAY(registered_date) = ?', [$prevDay])
                            ->count();
                            $prevLeads = (int)$prev_lead_detail ?? 0;
                            
                            // Query previous day's conversion count
                            $prev_conversion_detail = CustomerModel::select('za_customer.sno')
                            ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.status', 4)->where('za_lead.spam_verified',0)
                            ->where('za_lead.branch_id', $branch_id)->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.created_by', '>', 0)
                            ->whereRaw('YEAR(za_customer.created_at) = ?', [$prevYear])
                            ->whereRaw('MONTH(za_customer.created_at) = ?', [$prevMonth])
                            ->whereRaw('DAY(za_customer.created_at) = ?', [$prevDay])
                            ->where('za_customer.status', 0)
                            ->count();
                            $prevConversion = (int)$prev_conversion_detail ?? 0;

                        }

                        $leadsData[$currentMonth][$d][$leadSource] = [
                            'leads' => $leads,
                            'conversion' => $conversion,
                            'prevLeads' => $prevLeads,
                            'prevConversion' => $prevConversion,
                        ];

                        // store leads pie
                        $dailyPie[] = [
                            'source' => $leadSource,
                            'leads'  => $leads
                        ];

                        // store conversions pie
                        $dailyConvPie[] = [
                            'source' => $leadSource,
                            'conversion' => $conversion
                        ];

                        $dailyTotal += $leads;

                        // store trends
                        $sourceTrends[$leadSource][] = [
                            'date'  => $dateLabel,
                            'leads' => $leads
                        ];

                        $convSourceTrends[$leadSource][] = [
                            'date'       => $dateLabel,
                            'conversion' => $conversion
                        ];
                    }

                    $pieData[$dateLabel]     = $dailyPie;
                    $convPieData[$dateLabel] = $dailyConvPie;

                    $totalLine[] = [
                        'date'  => $dateLabel,
                        'leads' => $dailyTotal
                    ];
                // }
            }


            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadSources_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentMonth' => $currentMonth,
                'year' => $year,
                'yearShort' => $yearShort,
                'leadsData' => $leadsData,
                'leadSources' => $leadSources_list,
                'pieData' => $pieData,
                'convPieData' => $convPieData,
                'totalLine' => $totalLine,
                'days' => $days,
                'sourceTrends' => $sourceTrends,
                'convSourceTrends' => $convSourceTrends,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                // 'pagination' => [
                //     'total' => $leadSources->total(),
                //     'per_page' => $leadSources->perPage(),
                //     'current_page' => $leadSources->currentPage(),
                //     'last_page' => $leadSources->lastPage(),
                //     'next_page_url' => $leadSources->nextPageUrl(),
                //     'prev_page_url' => $leadSources->previousPageUrl(),
                //     'from' => $leadSources->firstItem(),
                //     'to' => $leadSources->lastItem(),
                // ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }

    }

    public function yearly_lead_src()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        $currentMonth = date('n'); // numeric month (1–12)
        
        return view('content.report_management.lead_report.total_lead_src_yearly_list', compact(
            'months',
            'days',
            'year',
            'yearShort',
            'currentMonth',
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsSourceYearData(Request $request)
    {
        try {

            $year = $request->year ?? date('Y');
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            // $perPage = $request->input('per_page', 10); // Default to 25 per page

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = LeadSourceModel::where('status', '!=', 2);

            if (!empty($search_lead_src_fill) && is_array($search_lead_src_fill)) {
                $query->whereIn('sno', $search_lead_src_fill);
            }

            // Use select instead of pluck
            $leadSources = $query->select('sno', 'lead_source_name')->orderBy('lead_source_name', 'asc')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $leadSourcesMapped = $leadSources->mapWithKeys(function ($item) {
                return [$item->sno => $item->lead_source_name];
            })->toArray();
            
            $leadSources_list = !empty($leadSourcesMapped) ? array_values($leadSourcesMapped) : [];

            $yearShort = date('y', strtotime($year));

            $months = $this->getYearBasedMonths($year);
            $currentMonth = date('n'); // current month number

            $leadsData = [];
            $pieData = []; // monthly pie for leads
            $convPieData = []; // monthly pie for conversions
            $totalLine = []; // total leads per month
            $sourceTrends = []; // monthly leads per source
            $convSourceTrends = []; // monthly conversions per source

            // Loop over months up to current month
            foreach($months as $monthNum => $monthName){

                $monthlyTotal = 0;
                $monthlyPie = [];
                $monthlyConvPie = [];

                foreach ($leadSourcesMapped as $lead_src_id => $leadSource) {
       
                    // No need to pad month; whereMonth expects integer
                    $query_month = (int)$monthNum; 

                    // Count leads
                    $lead_detail_modal = LeadModel::where('status', '!=',2)->where('branch_id', $branch_id)
                        ->where('lead_source_id', $lead_src_id)->where('spam_verified',0)
                        ->where('internal_status', '!=', 1)
                        ->where('created_by', '>', 0)
                        ->whereYear('registered_date', $year)
                        ->whereMonth('registered_date', $query_month)
                        ->count();

                    $leads = (int)$lead_detail_modal;

                    // Count conversions
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                        })
                    ->whereYear('za_customer.created_at', $year)   // make sure you specify the table here explicitly
                    ->whereMonth('za_customer.created_at', $query_month)
                    ->where('za_customer.status', 0)
                    ->count();

                    $conversion = (int)$conversions_detail_modal;

                    $prevLeads = 0;
                    $prevConversion = 0;

                    if ((int)$monthNum == 1) {

                        $prevMonth = 12;
                        $prevYear = $year - 1;

                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);

                        $prev_lead_detail = LeadModel::where('status', '!=',2)->where('branch_id', $branch_id)
                            ->where('lead_source_id', $lead_src_id)->where('spam_verified',0)
                            ->where('internal_status', '!=', 1)->where('created_by', '>', 0)
                            ->whereYear('registered_date', $prevYear)
                            ->whereMonth('registered_date', $prevMonth)
                            ->count();
                        $prevLeads = (int)$prev_lead_detail ?? 0;
    
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::join('za_lead', function ($join) use ($lead_src_id,$branch_id) {
                                $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                                    ->where('za_lead.lead_source_id', $lead_src_id)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->where('za_lead.created_by', '>', 0);
                                })
                            ->whereYear('za_customer.created_at', $prevYear)   // make sure you specify the table here explicitly
                            ->whereMonth('za_customer.created_at', $prevMonth)
                            ->where('za_customer.status', 0)
                            ->count();
                        $prevConversion = (int)$prev_conversion_detail ?? 0;
                    }

                    $leadsData[$monthNum][$leadSource] = [
                        'leads' => $leads,
                        'conversion' => $conversion,
                        'prevLeads' => $prevLeads,
                        'prevConversion' => $prevConversion,
                    ];

                    $monthlyPie[] = [
                        'source' => $leadSource,
                        'leads' => $leads
                    ];

                    $monthlyConvPie[] = [
                        'source' => $leadSource,
                        'conversion' => $conversion
                    ];

                    $monthlyTotal += $leads;

                    // monthly trends
                    $sourceTrends[$leadSource][] = [
                        'month' => $monthName,
                        'leads' => $leads
                    ];

                    $convSourceTrends[$leadSource][] = [
                        'month' => $monthName,
                        'conversion' => $conversion
                    ];
                }

                $pieData[$monthName] = $monthlyPie;
                $convPieData[$monthName] = $monthlyConvPie;

                $totalLine[] = [
                    'month' => $monthName,
                    'leads' => $monthlyTotal
                ];
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadSources_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            // Return successful JSON response
            return response()->json([
                'status' => 'success',
                'months' => $months,
                'yearShort' => $yearShort,
                'year' => $year,
                'leadSources' => $leadSources_list,
                'leadsData' => $leadsData,
                'pieData' => $pieData,
                'convPieData' => $convPieData,
                'totalLine' => $totalLine,
                'sourceTrends' => $sourceTrends,
                'convSourceTrends' => $convSourceTrends,
                'line_MonthColors' =>$line_MonthColors,
                'pie_MonthColors' =>$pie_MonthColors,
                // 'pagination' => [
                //     'total' => $leadSources->total(),
                //     'per_page' => $leadSources->perPage(),
                //     'current_page' => $leadSources->currentPage(),
                //     'last_page' => $leadSources->lastPage(),
                //     'next_page_url' => $leadSources->nextPageUrl(),
                //     'prev_page_url' => $leadSources->previousPageUrl(),
                //     'from' => $leadSources->firstItem(),
                //     'to' => $leadSources->lastItem(),
                // ]
            ]);

        } catch (Exception $e) {
            // Return error JSON response
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate lead data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function sales_lead_month()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        $currentMonth = date('n'); // numeric month (1–12)

        return view('content.report_management.lead_report.sales_lead_list', compact(
            'months',
            'year',
            'yearShort',
            'days',
            'currentMonth'
            )
        )->with('report_heading', self::$report_heading);
    }

    public function getSalesMonthlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;
            $perPage = $request->input('per_page', 10); // Default to 25 per page

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = StaffModel::where('role_id', 11)->where('branch_id', $branch_id);

            if (!empty($search_lead_src_fill)) {
                $filterArray = is_array($search_lead_src_fill) ? $search_lead_src_fill : explode(',', $search_lead_src_fill);
                $query->whereIn('sno', $filterArray);
            }

            if ($is_existing_val == 2) {
                $query->where('status', 0);
            }

            // Use select instead of pluck
            $salesExecutives = $query->select('sno', 'staff_name')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            
            $salesExecutivesMapped = $salesExecutives->mapWithKeys(function ($item) {
                return [$item->sno => $item->staff_name];
            })->toArray();
            
            $salesRolesMapped = $salesExecutives->mapWithKeys(function ($item) {
                $helper = new \App\Helpers\Helpers();
                $staff_details = isset($item->sno) && !empty($item->sno) ? self::staff_details($item->sno) : '';
                return [$item->sno => isset($staff_details->role_name) && !empty($staff_details->role_name) ? $staff_details->role_name : ''];
            })->toArray();

            $salesExecutives_list = !empty($salesExecutivesMapped) ? array_values($salesExecutivesMapped) : [];
            
            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];
            
            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $currentMonth = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $year);

            if($today_year == $year && $today_month == $currentMonth){
                $daysInMonth = (int)$today;
            }

            $days = range(1, $daysInMonth);
        
            $leadsData       = [];
            $pieData         = []; // daily pie for leads
            $convPieData     = []; // daily pie for conversions
            $sourceTrends    = []; // daily leads per executive
            $convSourceTrends = []; // daily conversions per executive


            for ($d=1; $d <= $daysInMonth; $d++) {

                // $dayOfWeek = date('w', strtotime("$year-$currentMonth-$d"));

                // if ($dayOfWeek != 0) { // skip Sunday

                    $dateLabel = sprintf('%02d-%02d-%s', $d, $currentMonth, $yearShort);
                    $dailyPie = [];
                    $dailyConvPie = [];
                    $dailyTotal = 0;

                    foreach ($salesExecutivesMapped as $executive => $executive_name) {

                        $lead_detail_modal = LeadModel::where('branch_id', $branch_id)
                                            ->where('created_by', $executive)
                                            ->whereYear('registered_date', $year)
                                            ->whereMonth('registered_date', $querycurrentMonth)
                                            ->whereDay('registered_date', $d)
                                            ->whereNotIn('status',[2,6])
                                            ->where('spam_verified',0)
                                            ->where('drop_verified', 0)
                                            ->where('internal_status',0)
                                            ->count();

                        $leads = (int)$lead_detail_modal ?? 0;

                        //Fetch conversions count
                        $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($executive,$branch_id) {
                            $join->on('za_customer.lead_id', '=', 'za_lead.sno')->where('za_lead.created_by', $executive)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0);
                        })->whereYear('za_customer.created_at', $year)
                        ->whereMonth('za_customer.created_at', (int)$querycurrentMonth)
                        ->whereDay('za_customer.created_at', $d)
                        ->where('za_customer.status', 0)
                        ->count();

                        $conversion = (int) $conversions_detail_modal;

                        $prevLeads = 0;
                        $prevConversion = 0;
                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        $day_query = false;

                        if ((int)$currentMonth == 1 && $d == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                            $day_query = true;
                        }else if($d == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$currentMonth - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                            $day_query = true;
                        }

                        if($day_query){
                            $prev_lead_detail = LeadModel::select('sno')
                            ->where('branch_id', $branch_id)
                            ->where('created_by', $executive)
                            ->whereYear('registered_date', $prevYear)
                            ->whereMonth('registered_date', $prevMonth)
                            ->whereDay('registered_date', $prevDay)
                            ->whereNotIn('status',[2,6])
                            ->where('spam_verified',0)
                            ->where('drop_verified', 0)
                            ->where('internal_status',0)
                            ->count();
                            $prevLeads = (int)$prev_lead_detail ?? 0;
                            
                            // Query previous day's conversion count
                            $prev_conversion_detail = CustomerModel::select('za_customer.sno')
                            ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                            ->where('za_lead.status', 4)->where('za_lead.spam_verified',0)
                            ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', $executive)
                            ->where('za_customer.status', 0)
                            ->whereRaw('YEAR(za_customer.created_at) = ?', [$prevYear])
                            ->whereRaw('MONTH(za_customer.created_at) = ?', [$prevMonth])
                            ->whereRaw('DAY(za_customer.created_at) = ?', [$prevDay])
                            ->count();
                            $prevConversion = (int)$prev_conversion_detail ?? 0;

                        }

                        $leadsData[$currentMonth][$d][$executive] = [
                            'leads' => $leads,
                            'conversion' => $conversion,
                            'prevLeads' => $prevLeads,
                            'prevConversion' => $prevConversion
                        ];

                        $dailyPie[] = [
                            'source_id' => $executive,
                            'leads'  => $leads
                        ];

                        $dailyConvPie[] = [
                            'source_id' => $executive,
                            'conversion' => $conversion
                        ];

                        $dailyTotal += $leads;

                        $sourceTrends[$executive][] = [
                            'date'  => $dateLabel,
                            'leads' => $leads
                        ];

                        $convSourceTrends[$executive][] = [
                            'date'       => $dateLabel,
                            'conversion' => $conversion
                        ];
                    }

                    $pieData[$dateLabel]     = $dailyPie;
                    $convPieData[$dateLabel] = $dailyConvPie;

                // }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($salesExecutives_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? $line_MonthColors : [];

            return response()->json([
                'months' => $months,
                'yearShort' => $yearShort,
                'leadsData' => $leadsData,
                'leadSources' => $salesExecutivesMapped,
                'leadRoles' => $salesRolesMapped,
                'pieData' => $pieData,
                'convPieData' => $convPieData,
                // 'totalLine' => $totalLine,
                'days' => $days,
                'sourceTrends' => $sourceTrends,
                'convSourceTrends' => $convSourceTrends,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
                'year' => $year,
                'currentMonth' => $currentMonth,
                // 'pagination' => [
                //     'total' => $salesExecutives->total(),
                //     'per_page' => $salesExecutives->perPage(),
                //     'current_page' => $salesExecutives->currentPage(),
                //     'last_page' => $salesExecutives->lastPage(),
                //     'next_page_url' => $salesExecutives->nextPageUrl(),
                //     'prev_page_url' => $salesExecutives->previousPageUrl(),
                //     'from' => $salesExecutives->firstItem(),
                //     'to' => $salesExecutives->lastItem(),
                // ]
            ]);

        } catch (Exception $e) {
            // Return error JSON response
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate lead data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function yearly_lead_sales()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');
        $currentMonth = date('n'); // current month number

        return view('content.report_management.lead_report.sales_lead_yearly_list', compact(
            'months',
            'days',
            'year',
            'yearShort',
            'currentMonth',
        ))->with('report_heading', self::$report_heading);
    }

    public function getSalesYearlyData(Request $request)
    {
        try {

            $year = $request->year ?? date('Y');
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';
            $is_existing_val = (int)$request->is_existing_val ?? 2;
            $perPage = $request->input('per_page', 10); // Default to 25 per page

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $query = StaffModel::where('department_id', 1)->where('branch_id', $branch_id);

            if (!empty($search_lead_src_fill)) {
                $filterArray = is_array($search_lead_src_fill) ? $search_lead_src_fill : explode(',', $search_lead_src_fill);
                $query->whereIn('sno', $filterArray);
            }

            if ($is_existing_val == 2) {
                $query->where('status', 0);
            }

            // Use select instead of pluck
            $salesExecutives = $query->select('sno', 'staff_name')->get(); // 10 per page

            // Optional: transform to just values (not recommended if you want to keep pagination metadata)
            $salesExecutivesMapped = $salesExecutives->mapWithKeys(function ($item) {
                return [$item->sno => $item->staff_name];
            })->toArray();
            
            $salesRolesMapped = $salesExecutives->mapWithKeys(function ($item) {

                $helper = new \App\Helpers\Helpers();

                $staff_details = isset($item->sno) && !empty($item->sno) ? self::staff_details($item->sno) : '';

                return [$item->sno => isset($staff_details->role_name) && !empty($staff_details->role_name) ? $staff_details->role_name : ''];
                
            })->toArray();

            $salesExecutives_list = !empty($salesExecutivesMapped) ? array_values($salesExecutivesMapped) : [];

            $yearShort = date('y', strtotime($year));

            $months = $this->getYearBasedMonths($year);
            // return $months;
            $currentMonth = date('n'); // current month number

            $leadsData = [];
            $pieData = []; // monthly pie for leads
            $convPieData = []; // monthly pie for conversions
            $totalLine = []; // total leads per month
            $sourceTrends = []; // monthly leads per source
            $convSourceTrends = []; // monthly conversions per source

            $days = range(1,31);

            // Loop over months up to current month
            foreach($months as $monthNum => $monthName){

                $monthlyTotal = 0;
                $monthlyPie = [];
                $monthlyConvPie = [];

                foreach ($salesExecutivesMapped as $executive => $executive_name) {

                    $query_month = (int)$monthNum; 
                    
                    $lead_detail_modal = LeadModel::where('branch_id', $branch_id)
                                        ->where('created_by', $executive)
                                        ->whereYear('registered_date', $year)
                                        ->whereMonth('registered_date', $query_month)
                                        ->whereNotIn('status',[2,6])
                                        ->where('spam_verified',0)
                                        ->where('drop_verified', 0)
                                        ->where('internal_status',0)
                                        ->count();

                    $leads = (int)$lead_detail_modal ?? 0;

                    //Fetch conversions count
                    $conversions_detail_modal = CustomerModel::join('za_lead', function ($join) use ($executive,$branch_id) {
                        $join->on('za_customer.lead_id', '=', 'za_lead.sno')->where('za_lead.created_by', $executive)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0);
                    })->whereYear('za_customer.created_at', $year)->where('za_customer.status', 0)
                    ->whereMonth('za_customer.created_at', $query_month)
                    ->count();

                    $conversion = (int) $conversions_detail_modal;

                    $prevLeads = 0;
                    $prevConversion = 0;
                    $prevMonth = 0;
                    $prevYear = 0;

                    if ((int)$monthNum == 1) {

                        $prevMonth = 12;
                        $prevYear = $year - 1;

                        $prev_lead_detail = LeadModel::where('branch_id', $branch_id)
                            ->where('created_by', $executive)
                            ->whereYear('registered_date', $prevYear)
                            ->whereMonth('registered_date', $prevYear)
                            ->whereNotIn('status',[2,6])
                            ->where('spam_verified',0)
                            ->where('drop_verified', 0)
                            ->where('internal_status',0)
                            ->count();
                        $prevLeads = (int)$prev_lead_detail ?? 0;
    
                        // Query previous day's conversion count
                        $prev_conversion_detail = CustomerModel::join('za_lead', function ($join) use ($executive,$branch_id) {
                                $join->on('za_customer.lead_id', '=', 'za_lead.sno')
                                    ->where('za_lead.created_by', $executive)->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0);
                                })
                            ->whereYear('za_customer.created_at', $prevYear)   // make sure you specify the table here explicitly
                            ->whereMonth('za_customer.created_at', $prevMonth)
                            ->where('za_customer.status', 0)
                            ->count();
                        $prevConversion = (int)$prev_conversion_detail ?? 0;
                    }
                    
                    $leadsData[$monthNum][$executive] = [
                        'leads' => $leads,
                        'conversion' => $conversion,
                        'prevLeads' => $prevLeads,
                        'prevConversion' => $prevConversion
                    ];

                    $monthlyPie[] = [
                        'source_id' => $executive,
                        'leads' => $leads
                    ];

                    $monthlyConvPie[] = [
                        'source_id' => $executive,
                        'conversion' => $conversion
                    ];

                    $monthlyTotal += $leads;

                    // monthly trends
                    $sourceTrends[$executive][] = [
                        'month' => $monthName,
                        'leads' => $leads
                    ];

                    $convSourceTrends[$executive][] = [
                        'month' => $monthName,
                        'conversion' => $conversion
                    ];
                }

                $pieData[$monthName]     = $monthlyPie;
                $convPieData[$monthName] = $monthlyConvPie;

                $totalLine[] = [
                    'month' => $monthName,
                    'leads' => $monthlyTotal
                ];
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($salesExecutives_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? $line_MonthColors : [];

            // Return successful JSON response
            return response()->json([
                'status' => 'success',
                'months' => $months,
                'yearShort' => $yearShort,
                'year' => $year,
                'leadSources' => $salesExecutivesMapped,
                'leadRoles' => $salesRolesMapped,
                'leadsData' => $leadsData,
                'pieData' => $pieData,
                'convPieData' => $convPieData,
                'totalLine' => $totalLine,
                'sourceTrends' => $sourceTrends,
                'convSourceTrends' => $convSourceTrends,
                'line_MonthColors' =>$line_MonthColors,
                'pie_MonthColors' =>$pie_MonthColors,
                // 'pagination' => [
                //     'total' => $salesExecutives->total(),
                //     'per_page' => $salesExecutives->perPage(),
                //     'current_page' => $salesExecutives->currentPage(),
                //     'last_page' => $salesExecutives->lastPage(),
                //     'next_page_url' => $salesExecutives->nextPageUrl(),
                //     'prev_page_url' => $salesExecutives->previousPageUrl(),
                //     'from' => $salesExecutives->firstItem(),
                //     'to' => $salesExecutives->lastItem(),
                // ]
            ]);

        } catch (Exception $e) {
            // Return error JSON response
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate lead data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function week_lead_month()
    {
        $weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        return view('content.report_management.lead_report.weekly_lead_list', compact(
            'weekdays'
        ))->with('report_heading', self::$report_heading);
    }

    public function getWeeklyMonthData(Request $request)
    {
        // Validate year input or fallback to current year
        $year = $request->input('year');
        if (!$year || !preg_match('/^\d{4}$/', $year)) {
            $year = date('Y');
        }

        $months = $this->getYearBasedMonths($year);

        $weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

        // Initialize result arrays with zero counts
        $monthlyLeads = array_fill_keys(array_keys($months), 0);
        $monthlyConversions = array_fill_keys(array_keys($months), 0);

        $dailyLeads = [];
        $dailyConversions = [];
        $Trend_dailyLeads = [];
        $Trend_dailyConversions = [];

        foreach ($months as $monthNum => $monthName) {
            $dailyLeads[$monthNum] = array_fill_keys($weekdays, 0);
            $dailyConversions[$monthNum] = array_fill_keys($weekdays, 0);
            $Trend_dailyLeads[$monthNum] = array_fill_keys($weekdays, 0);
            $Trend_dailyConversions[$monthNum] = array_fill_keys($weekdays, 0);
        }

        try {

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            // Fetch all leads for the year with status != 2
            $leads = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                    ->select('za_lead.registered_date')
                    ->where('za_lead.branch_id', $branch_id)
                    // ->where('za_staff.status', 0)
                    // ->where('za_staff.department_id', 1)
                    ->whereNotIn('za_lead.status', [2, 6])
                    ->where('za_lead.spam_verified', 0)
                    ->where('za_lead.drop_verified', 0)
                    ->where('za_lead.internal_status', 0)
                    ->whereNotNull('za_lead.registered_date')
                    ->whereYear('za_lead.registered_date', $year)
                    ->get();

            // return $leads;
            // Process lead counts grouped by month and weekday
            foreach ($leads as $lead) {

                $date = Carbon::parse($lead->registered_date);
                $monthNum = $date->format('n'); // 1-12
                $dayShort = $date->format('D'); // Mon, Tue, etc.

                if (isset($monthlyLeads[$monthNum])) {
                    $monthlyLeads[$monthNum]++;
                }

                if (isset($dailyLeads[$monthNum][$dayShort])) {

                    $dailyLeads[$monthNum][$dayShort]++;
                    $Trend_dailyLeads[$monthNum][$dayShort]++;
                    
                    $dailyLeads[$monthNum]['preSunday'] = 0;
                    
                    if((int)$monthNum == 1){

                        $prevMonth = 12;
                        $prevYear = $year - 1;

                        $prevLeads_modal = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                                            ->where('za_lead.branch_id', $branch_id)
                                            // ->where('za_staff.status',0)
                                            // ->where('za_staff.department_id', 1)
                                            ->whereNotIn('za_lead.status',[2,6])
                                            ->where('za_lead.spam_verified',0)
                                            ->where('za_lead.drop_verified', 0)
                                            ->where('za_lead.internal_status',0)
                                            ->whereYear('za_lead.registered_date', $prevYear)
                                            ->whereMonth('za_lead.registered_date', $prevMonth)
                                            ->where(DB::raw('DAYNAME(za_lead.registered_date)'), 'Sunday')
                                            ->count();

                        $prevLeads = (int)$prevLeads_modal ?? 0;

                        $dailyLeads[$monthNum]['preSunday'] = $prevLeads;
                    }
                }
            }

            // Fetch conversions grouped by month and weekday with join
            $conversions = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                ->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0) // conversion status
                ->whereYear('za_customer.created_at', $year)->where('za_customer.status', 0)
                ->select(
                    DB::raw('MONTH(za_customer.created_at) as month'),
                    DB::raw('DAYNAME(za_customer.created_at) as dayname'),
                    DB::raw('COUNT(*) as count')
                )
                ->groupBy('month', 'dayname')
                ->get();

            foreach ($conversions as $conv) {
                $monthNum = (int) $conv->month;
                $dayShort = date('D', strtotime($conv->dayname));

                if (isset($monthlyConversions[$monthNum])) {
                    $monthlyConversions[$monthNum] += $conv->count;
                }
                if (isset($dailyConversions[$monthNum][$dayShort])) {
                    $dailyConversions[$monthNum][$dayShort] += $conv->count;
                    $Trend_dailyConversions[$monthNum][$dayShort] += $conv->count;
                }
                $dailyConversions[$monthNum]['preSunday'] = 0;
                if((int)$monthNum == 1){

                    $prevMonth = 12;
                    $prevYear = $year - 1;

                    $prevConversion_modal = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                                        ->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0) // conversion status
                                        ->whereYear('za_customer.created_at', $prevYear)
                                        ->whereMonth('za_customer.created_at', $prevMonth)
                                        ->where(DB::raw('DAYNAME(za_customer.created_at)'), 'Sunday')
                                        ->where('za_customer.status', 0)
                                        ->select('za_customer.sno')
                                        ->count();

                    $prevConversion = (int)$prevConversion_modal ?? 0;

                    $dailyConversions[$monthNum]['preSunday'] = $prevConversion;
                }
            }

            // Return JSON with proper keys and values
            return response()->json([
                'months' => $months,
                'year' => $year,
                'monthlyLeads' => $monthlyLeads,
                'monthlyConversions' => $monthlyConversions,
                'dailyLeads' => $dailyLeads,
                'dailyConversions' => $dailyConversions,
                'Trend_dailyLeads' => $Trend_dailyLeads,
                'Trend_dailyConversions' => $Trend_dailyConversions,
                'weekdays' => $weekdays,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate Weekly data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function yearly_lead_weekly()
    {
        $weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        return view('content.report_management.lead_report.week_lead_yearly_list', compact(
            'weekdays'
        ))->with('report_heading', self::$report_heading);
    }

    public function getWeeklyYearlyData(Request $request)
    {
        try {


            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            // === Configuration ===
            // Get lead years
            $leadYears = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                ->where('za_lead.branch_id', $branch_id)
                // ->where('za_staff.status', 0)
                // ->where('za_staff.department_id', 1)
                ->whereNotIn('za_lead.status', [2, 6])
                ->where('za_lead.spam_verified', 0)
                ->where('za_lead.drop_verified', 0)
                ->where('za_lead.internal_status', 0)
                ->whereNotNull('za_lead.registered_date')
                ->select(DB::raw('YEAR(za_lead.registered_date) as year'))
                ->distinct()
                ->pluck('year');

            // Get conversion years
            $conversionYears = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                ->where('za_lead.status', 4)->where('za_lead.branch_id', $branch_id)->where('za_lead.spam_verified',0)->whereNotNull('za_lead.registered_date')->where('za_customer.status', 0)
                ->select(DB::raw('YEAR(za_customer.created_at) as year'))
                ->distinct()
                ->pluck('year');

            // Combine and get unique years
            $allYears = $leadYears->merge($conversionYears)->unique()->sort()->values();

            $out_Years = $allYears->sort()->values()->toArray();

            $yearList = !empty($out_Years) ? collect($out_Years) : null; // Your starting list
            
            $firstYear = !empty($yearList) ? $yearList->get(0) : ''; // Get year at index 0 (2024)

            $lastYear = !empty($out_Years) && (count($out_Years) > 1) ? ' - '.$yearList->get(count($out_Years) - 1) : ''; // Get year at index 0 (2024)

            $year_string = $firstYear.$lastYear;

            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null; // Previous year (2023)

            // Push previousYear if not already in the list
            if (!empty($yearList) && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Sort and reset keys
            $finalYears = !empty($yearList) ? $yearList->sort()->values()->toArray() : [];

            $weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            $currentYear = (int) date('Y');
            $today = new DateTime();

            $dailyLeads = [];
            $dailyConversions = [];

            $YearWiseLeads = array_fill_keys($out_Years, 0);
            $YearWiseConversions = array_fill_keys($out_Years, 0);

            $allYearsDaywiseLeads = array_fill_keys($weekdays, 0);
            $allYearsDaywiseConversions = array_fill_keys($weekdays, 0);

            // === Process valid requested years ===
            foreach ($finalYears as $year_index => $year) {

                $dailyLeads[$year] = array_fill_keys($weekdays, 0);
                $dailyConversions[$year] = array_fill_keys($weekdays, 0);

                $leadsByDate = LeadModel::join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                    ->where('za_lead.branch_id', $branch_id)
                    // ->where('za_staff.status', 0)
                    // ->where('za_staff.department_id', 1)
                    ->whereNotIn('za_lead.status', [2, 6])
                    ->where('za_lead.spam_verified', 0)
                    ->where('za_lead.drop_verified', 0)
                    ->where('za_lead.internal_status', 0)
                    ->whereNotNull('za_lead.registered_date')
                    ->whereYear('za_lead.registered_date', $year)
                    ->select(
                        DB::raw('DAYNAME(za_lead.registered_date) as dayname'),
                        DB::raw('COUNT(za_lead.sno) as lead_count')
                    )
                    ->groupBy('dayname')
                    ->pluck('lead_count', 'dayname');  // keys: dayname, values: lead_count

                $conversionsByDate = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                    ->where('za_lead.status', 4)
                    ->where('za_lead.branch_id', $branch_id)
                    ->where('za_lead.spam_verified', 0)
                    ->whereYear('za_customer.created_at', $year)
                    ->where('za_customer.status', 0)
                    ->select(
                        DB::raw('DAYNAME(za_customer.created_at) as dayname'),
                        DB::raw('COUNT(za_customer.sno) as conversion_count')
                    )
                    ->groupBy('dayname')
                    ->pluck('conversion_count', 'dayname');  // keys: dayname, values: conversion_count

                foreach($weekdays as $dayName){

                    $leadCount = isset($leadsByDate[$dayName]) && !empty($leadsByDate[$dayName]) ? $leadsByDate[$dayName] : 0;
                    $conversionCount = isset($conversionsByDate[$dayName]) && !empty($conversionsByDate[$dayName]) ? $conversionsByDate[$dayName] : 0;

                    // Per-year totals
                    $dailyLeads[$year][$dayName] += $leadCount;
                    $dailyConversions[$year][$dayName] += $conversionCount;

                    // All-years daywise
                    if($year_index != 0){
                        
                        $allYearsDaywiseLeads[$dayName] += $leadCount;
                        $allYearsDaywiseConversions[$dayName] += $conversionCount;

                        $YearWiseLeads[$year] += $leadCount;
                        $YearWiseConversions[$year] += $conversionCount;
                    }
                }
            }

            $line_Colors = $this->generateAttractiveColors($out_Years);
            $pie_Colors = !empty($line_Colors) && is_array($line_Colors) ? array_values($line_Colors) : null;

            // === Return JSON ===
            return response()->json([
                'years' => !empty($out_Years) ? $out_Years : null,
                'dailyData' => !empty($dailyData) ? $dailyData : null,
                'dailyLeads' => !empty($dailyLeads) ? $dailyLeads : null,
                'dailyConversions' => !empty($dailyConversions) ? $dailyConversions : null,
                'weekdays' => !empty($weekdays) ? $weekdays : null,
                'year_string' => !empty($year_string) ? $year_string : null,
                'allYearsDaywiseLeads' => !empty($allYearsDaywiseLeads) ? $allYearsDaywiseLeads : null,
                'allYearsDaywiseConversions' => !empty($allYearsDaywiseConversions) ? $allYearsDaywiseConversions : null,
                'YearWiseLeads' => !empty($YearWiseLeads) ? $YearWiseLeads : null,
                'YearWiseConversions' => !empty($YearWiseConversions) ? $YearWiseConversions : null,
                'line_Colors' => !empty($line_Colors) ? $line_Colors : null,
                'pie_Colors' => !empty($pie_Colors) ? $pie_Colors : null,
            ]);

        } catch (Exception $e) {
            return response()->json([
                'error' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getYearBasedMonths($year) {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    public function get_lead_source_list()
    {
        $CourseCategory = LeadSourceModel::where('status', 0)->orderBy('lead_source_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function SalesExcutiveStaffList(Request $request)
    {
        $user      = $request->user(); // Fetch user details only once
        $user_id   = $user->user_id;
        $branch_id = $user->branch_id;
        $is_existing = ($request->checked_val == 1) ? 1 : 2;

        $query = StaffModel::where('role_id', 11)->where('branch_id', $branch_id);

        if ($is_existing == 2) {
            $query = $query->where('status', 0);
        }

        $staff = $query->orderBy('staff_name', 'asc')->distinct()->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff ?? null,
        ], 200);
    }

    public function staff_details($sno)
    {
        $result = StaffModel::select('za_staff.sno', 'za_staff.branch_id', 'za_staff.staff_image', 'za_staff.status', 'za_staff.staff_name',  'za_staff.nick_name', 'za_job_position.job_position_name', 'za_user_role.role_name')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
            // ->where('za_staff.status', 0)
            ->where('za_staff.sno', $sno)
            ->orderBy('za_staff.staff_name', "ASC")->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
}
