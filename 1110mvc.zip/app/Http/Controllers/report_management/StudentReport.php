<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\SlotModel;
use DateTime;

class StudentReport extends Controller
{

    public static $report_heading = 'Analysis';
    protected static $temp = [];

    public function index()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.student_report.student_attendance_yr_list', compact('months'))->with('report_heading', self::$report_heading);
    }

    public function StudentAttYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $days = range(1, 31); // Daily

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            $result = $this->GetStudentAttDetails($branch_id);
            
            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;
            
            $paymentMonthSums = isset($result['yearly']) && !empty($result['yearly']) ? $result['yearly'] : [];
            $att_years = !empty($paymentMonthSums) ? collect(array_keys($paymentMonthSums)) : collect();
            $paymentSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];
            
            // Step 2: deduplicate, sort
            $allYears = $att_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            // return $years;
            
            foreach ($finalYears as $year_index => $year) {

                $pre_year  = (int)$year - 1;

                $Trend_data_list = [];
                
                foreach ($months as $monthNum => $monthName) {

                    $amount = isset($paymentSums[$year][$monthNum]['total_attendance']) ? round($paymentSums[$year][$monthNum]['total_attendance']) : 0;
                    $present_count = isset($paymentSums[$year][$monthNum]['P']) ? round($paymentSums[$year][$monthNum]['P']) : 0;

                    // Save raw daily data
                    $data[$year][$monthNum] = $amount;

                    if($year_index != 0){
                        
                        $present_data[$year][$monthNum] = $present_count;

                        $Trend_data_list[$monthNum] = $amount;
                        $Trend_data_percentage[$monthNum] = $present_count;

                        // Month grand total
                        $grandMonthTotals[$year] = ($grandMonthTotals[$year] ?? 0) + $amount;

                        // Day totals across months
                        $grandDayTotals[$monthNum] = ($grandDayTotals[$monthNum] ?? 0) + $amount;
                    }
                }

                if($year_index != 0){
                    $Trend_data[$year] = $Trend_data_list;
                }
            }

            foreach ($years as $year) {

                $monthTotal = $grandMonthTotals[$year] ?? 0;
                $grandAllTotal += $monthTotal;
                
                $total_students = isset($paymentMonthSums[$year]['total_students']) ? $paymentMonthSums[$year]['total_students'] : 0;
                
                $total_students_data[$year] = $total_students ?? 0;
                
                $grandAllStudentsTotal += $total_students_data[$year] ?? 0;

                foreach ($months as $monthNum => $monthName) {
                    $percentage_val = isset($paymentSums[$year][$monthNum]['total_percent_percentage']) ? $paymentSums[$year][$monthNum]['total_percent_percentage'] : 0;
                    $percentages[$year][$monthNum] = $percentage_val > 100 ? 100 : $percentage_val;
                    $Trend_percentages[$year][$monthNum] = $percentage_val > 100 ? 100 : $percentage_val;
                }
            }

            $year_colors = $this->generateAttractiveColors($years);
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function stud_att_monthly()
    {        
        $days = range(1, 31); // Daily
        return view('content.report_management.student_report.student_attendance_month_list', compact('days'))->with('report_heading', self::$report_heading);
    }

    public function StudentAttMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStudentAttDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            $paymentSums = isset($result['daily']) && !empty($result['daily']) ? $result['daily'] : [];
            $paymentMonthSums = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

            // return $paymentSums;
            $days = range(1, 31);

            $data                = [];
            $present_data        = [];
            $Trend_data          = [];
            $pre_data            = [];
            $percentages         = [];
            $Trend_percentages   = [];
            $total_students_data = [];
            $grandMonthTotals    = []; // per month (all types)
            $grandDayTotals      = [];
            $grandAllTotal       = 0; 
            $grandAllStudentsTotal = 0; 

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];
                
                foreach ($days as $day) {
                    
                    $day_format = str_pad($day,2,'0',STR_PAD_LEFT);
                    $month_format = str_pad($monthNum,2,'0',STR_PAD_LEFT);

                    $date_format = $day_format.'-'.$month_format.'-'.$year;
                    
                        
                    $amount = isset($paymentSums[$year][$monthNum][$day]['total_attendance']) ? round($paymentSums[$year][$monthNum][$day]['total_attendance']) : 0;
                    $present_count = isset($paymentSums[$year][$monthNum][$day]['P']) ? round($paymentSums[$year][$monthNum][$day]['P']) : 0;
                    
                    $pre_amount = isset($paymentSums[$pre_year][12][$pre_daysInMonth]['total_attendance']) ? round($paymentSums[$pre_year][12][$pre_daysInMonth]['total_attendance']) : 0;

                    // Save raw daily data
                    $data[$monthNum][$day] = $amount;
                    $present_data[$monthNum][$day] = $present_count;

                    $Trend_data_list[$day] = $amount;
                    $Trend_data_percentage[$day] = $present_count;

                    $pre_data[12][$pre_daysInMonth] = $pre_amount;

                    // Month grand total
                    $grandMonthTotals[$monthNum] = ($grandMonthTotals[$monthNum] ?? 0) + $amount;

                    // Day totals across months
                    $grandDayTotals[$day] = ($grandDayTotals[$day] ?? 0) + $amount;
                }

                $Trend_data[$monthName] = $Trend_data_list;
            }

            foreach ($months as $monthNum => $monthName) {
                $monthTotal = $grandMonthTotals[$monthNum] ?? 0;
                $grandAllTotal += $monthTotal;
                foreach ($days as $day) {
                    $percentage_val = isset($paymentSums[$year][$monthNum][$day]['total_percent_percentage']) ? $paymentSums[$year][$monthNum][$day]['total_percent_percentage'] : 0;
                    $total_students = isset($paymentMonthSums[$year][$monthNum]['total_students']) ? $paymentMonthSums[$year][$monthNum]['total_students'] : 0;
                    $percentages[$monthNum][$day] = $percentage_val > 100 ? 100 : $percentage_val;
                    $Trend_percentages[$monthName][$day] = $percentage_val > 100 ? 100 : $percentage_val;
                    $total_students_data[$monthNum] = $total_students ?? 0;
                }
                $grandAllStudentsTotal += $total_students_data[$monthNum] ?? 0;
            }
            
            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'inern_per_trend_data' => $Trend_percentages,
                'pre_inern_cal_data' => $pre_data,
                'grandMonthTotals' => $grandMonthTotals,
                'grandDayTotals' => $grandDayTotals,
                'percentages' => $percentages,
                'grandAllTotal' => $grandAllTotal,
                'grandAllStudentsTotal' => $grandAllStudentsTotal,
                'total_students_data' => $total_students_data,
                'present_data' => $present_data,
                'year' => $year
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function stud_details_yearly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.student_report.student_details_yr_list', compact('months'))->with('report_heading', self::$report_heading);
    }

    public function StudentDetailsYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('d-m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStudentStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'cust_count' => 'Active',
                'finished_cust_count' => 'Finished',
                'placed_cust_count' => 'Placed'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years'])
                ? collect($result['years'])
                : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= $currentYear){

                    $pre_year  = (int)$year - 1;
                    
                    foreach ($months as $monthNum => $monthName) {

                        $Trend_data_list = [];

                        $paymentSums = isset($result) && !empty($result) ? $result : [];
                        $year_data = isset($paymentSums['yearly']) ? $paymentSums['yearly'] : [];

                        foreach ($types_list as $type_key => $type_name) {

                            // if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    ? round($paymentSums['monthly'][$year][$monthNum][$type_key])
                                    : 0;
                            // } else {
                            //     $amount = 0;
                            // }

                            // Save raw daily data
                            $data[$year][$monthNum][$type_key] = ($data[$year][$monthNum][$type_key] ?? 0) + $amount;                                

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = ($Trend_data_list[$type_key] ?? 0) + $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($year_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = ($grandTotals[$year] ?? 0) + $amount;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $typeMonthTotals[$type_key][$year] = ($year_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][$monthNum] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function stud_details_monthly()
    {
        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        $days = range(1, 31);

        return view('content.report_management.student_report.student_details_month_list', compact('months','days'))->with('report_heading', self::$report_heading);
    }

    public function StudentDetailsMonthlyData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetStudentStatusDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $types_list = [
                'cust_count' => 'Active',
                'finished_cust_count' => 'Finished',
                'placed_cust_count' => 'Placed'
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($result['monthly']) && !empty($result['monthly']) ? $result['monthly'] : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                ? round($paymentSums['daily'][$year][$monthNum][$day][$type_key])
                                : 0;
                        } else {
                            $amount = 0;
                        }

                        $pre_amount = isset($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) ? round($paymentSums['daily'][$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + ($totals[$monthNum][$type_key] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $text)));
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    public function GetStudentStatusDetails(int $branch_id)
    {
        try {

            // 🧩 Validate input
            if (!$branch_id || $branch_id <= 0) {
                throw new \InvalidArgumentException("Valid Branch ID is required");
            }

            $currentDate = date('Y-m-d');

            /** ------------------ FETCH CUSTOMERS ------------------ */
            $customers = DB::table('za_customer')
                ->whereIn('status', [0, 6])
                ->where('branch_id', $branch_id)
                ->pluck('sno')
                ->toArray();

            if (empty($customers)) {
                return [
                    'yearly'  => [],
                    'monthly' => [],
                    'daily'   => [],
                    'years'   => [],
                    'message' => 'No active or training customers found for this branch.'
                ];
            }

            /** ------------------ INITIALIZE STRUCTURES ------------------ */
            $yearlyData = [];
            $monthlyData = [];
            $dailyData = [];

            /** ------------------ PLACEMENT DATA ------------------ */
            try {

                $placements = DB::table('za_placement_interview')
                    ->select('customer_id', 'selected_date')
                    ->where('branch_id', $branch_id)
                    ->whereIn('customer_id', $customers)
                    ->where('status', 4)
                    ->whereNotNull('selected_date')
                    ->get();

                foreach ($placements as $placement) {
                    $date = date('Y-m-d', strtotime($placement->selected_date));
                    $y = (int) date('Y', strtotime($date));
                    $m = (int) date('n', strtotime($date));
                    $d = (int) date('j', strtotime($date));

                    $yearlyData[$y]['placed_cust_count'] = ($yearlyData[$y]['placed_cust_count'] ?? 0) + 1;
                    $monthlyData[$y][$m]['placed_cust_count'] = ($monthlyData[$y][$m]['placed_cust_count'] ?? 0) + 1;
                    $dailyData[$y][$m][$d]['placed_cust_count'] = ($dailyData[$y][$m][$d]['placed_cust_count'] ?? 0) + 1;
                }

            } catch (\Throwable $e) {
                \Log::error("Error fetching placement data: " . $e->getMessage());
            }

            /** ------------------ ATTENDANCE DATA ------------------ */
            try {

                $attendances = DB::table('za_attendance')
                    ->select('customer_id', 'att_date')
                    ->whereIn('customer_id', $customers)
                    ->where('attendance', '=', 'P')
                    ->orderBy('att_date', 'asc')
                    ->get();

                // Deduplicate attendance per student per day
                // $uniqueAttendance = $attendances->groupBy(fn($r) => $r->customer_id . '|' . $r->att_date);

                foreach ($attendances as $records) {

                    $attDate = date('Y-m-d', strtotime($records->att_date));
                    $y = (int) date('Y', strtotime($attDate));
                    $m = (int) date('n', strtotime($attDate));
                    $d = (int) date('j', strtotime($attDate));

                    $yearlyData[$y]['cust_count'] = ($yearlyData[$y]['cust_count'] ?? 0) + 1;
                    $monthlyData[$y][$m]['cust_count'] = ($monthlyData[$y][$m]['cust_count'] ?? 0) + 1;
                    $dailyData[$y][$m][$d]['cust_count'] = ($dailyData[$y][$m][$d]['cust_count'] ?? 0) + 1;
                }

            } catch (\Throwable $e) {
                \Log::error("Error fetching attendance data: " . $e->getMessage());
            }

            /** ------------------ TRAINING DATA ------------------ */
            try {

                $trainings = DB::table('za_training')
                    ->select('customer_id', 'start_date', 'end_date')
                    ->where('branch_id', $branch_id)
                    ->whereIn('customer_id', $customers)
                    ->where('tesbo_check', '!=', 1)
                    ->where('batch_id', '!=', 0)
                    ->whereNotNull('end_date')
                    ->get();

                foreach ($trainings as $training) {

                    $endDate = date('Y-m-d', strtotime($training->end_date));

                    if ($endDate < $currentDate) {

                        $y = (int) date('Y', strtotime($endDate));
                        $m = (int) date('n', strtotime($endDate));
                        $d = (int) date('j', strtotime($endDate));

                        $yearlyData[$y]['finished_cust_count'] = ($yearlyData[$y]['finished_cust_count'] ?? 0) + 1;
                        $monthlyData[$y][$m]['finished_cust_count'] = ($monthlyData[$y][$m]['finished_cust_count'] ?? 0) + 1;
                        $dailyData[$y][$m][$d]['finished_cust_count'] = ($dailyData[$y][$m][$d]['finished_cust_count'] ?? 0) + 1;
                    }
                }
            } catch (\Throwable $e) {
                \Log::error("Error fetching training data: " . $e->getMessage());
            }

            /** ------------------ NORMALIZE STRUCTURE ------------------ */
            foreach ($yearlyData as $y => &$yd) {
                $yd = array_merge(['cust_count' => 0, 'finished_cust_count' => 0, 'placed_cust_count' => 0], $yd);
            }

            ksort($yearlyData);
            ksort($monthlyData);
            ksort($dailyData);

            /** ------------------ SUCCESS RESPONSE ------------------ */
            return [
                'status'  => true,
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_keys($yearlyData),
                'message' => 'Student status details fetched successfully.'
            ];

        } catch (\InvalidArgumentException $e) {
            \Log::warning("Invalid input: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'Invalid Branch ID provided.',
                'details' => $e->getMessage()
            ];

        } catch (\Throwable $e) {
            \Log::error("Unexpected error in GetStudentStatusDetails: " . $e->getMessage());
            return [
                'status' => false,
                'error'  => 'An unexpected error occurred while fetching student details.',
                'details' => $e->getMessage()
            ];
        }
    }

    public function GetStudentAttDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            // ✅ Get customers in this branch
            $customer_list = CustomerModel::where('branch_id', $branch_id)->pluck('sno');

            // ✅ Get all attendance records for these students
            $attendanceRecords = AttendanceModel::whereIn('za_attendance.customer_id', $customer_list)
                ->orderBy('att_date', 'asc')
                ->get(['customer_id', 'att_date', 'attendance']);

            // ✅ Get all unique attendance statuses dynamically
            $validStatuses = AttendanceModel::distinct()
                ->pluck('attendance')
                ->filter() // remove nulls
                ->unique()
                ->values()
                ->toArray();

            // ✅ Add fallback 'NA' if not in DB
            if (!in_array('NA', $validStatuses)) {
                $validStatuses[] = 'NA';
            }

            // Helper function to generate default structure
            $defaultStats = function () use ($validStatuses) {
                $structure = [];
                foreach ($validStatuses as $status) {
                    $structure[$status] = 0;
                }
                $structure += [
                    "total_students" => 0,
                    "total_attendance" => 0,
                    "total_all_attendance" => 0,
                    "total_percent_percentage" => 0,
                    "unique_customers" => 0,
                ];
                return $structure;
            };

            // Initialize arrays
            $yearly = [];
            $monthly = [];
            $daily = [];

            $uniquePYearly = [];
            $uniquePMonthly = [];
            $uniquePDaily = [];

            foreach ($attendanceRecords as $record) {

                $date  = \Carbon\Carbon::parse($record->att_date);
                $year  = $date->year;
                $month = $date->month;
                $day   = $date->day;
                $cust  = $record->customer_id;

                // ✅ Validate or assign default status
                $status = in_array($record->attendance, $validStatuses)
                    ? $record->attendance
                    : 'NA';

                // ---------- YEARLY ----------
                if (!isset($yearly[$year])) {
                    $yearly[$year] = $defaultStats();
                    $uniquePYearly[$year] = [];
                }
                $yearly[$year][$status]++;
                if ($status === 'P') {
                    $uniquePYearly[$year][$cust] = true;
                }

                // ---------- MONTHLY ----------
                if (!isset($monthly[$year][$month])) {
                    $monthly[$year][$month] = $defaultStats();
                    $uniquePMonthly[$year][$month] = [];
                }
                $monthly[$year][$month][$status]++;
                if ($status === 'P') {
                    $uniquePMonthly[$year][$month][$cust] = true;
                }

                // ---------- DAILY ----------
                if (!isset($daily[$year][$month][$day])) {
                    $daily[$year][$month][$day] = $defaultStats();
                    $uniquePDaily[$year][$month][$day] = [];
                }
                $daily[$year][$month][$day][$status]++;
                if ($status === 'P') {
                    $uniquePDaily[$year][$month][$day][$cust] = true;
                }
            }

            // ✅ Compute final totals dynamically
            foreach ($yearly as $year => &$data) {
                $uniquePCount = count($uniquePYearly[$year]);
                $data['unique_customers'] = $uniquePCount;

                // Calculate totals dynamically
                $data['total_students'] = array_sum(array_intersect_key($data, array_flip($validStatuses)));
                $data['total_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0);
                $data['total_all_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0) + ($data['P'] ?? 0);
                $data['total_percent_percentage'] = ($data['total_all_attendance'] > 0)
                    ? round(($data['P'] / $data['total_all_attendance']) * 100, 2)
                    : 0;
            }

            foreach ($monthly as $year => &$months) {
                foreach ($months as $month => &$data) {
                    $uniquePCount = count($uniquePMonthly[$year][$month]);
                    $data['unique_customers'] = $uniquePCount;

                    $data['total_students'] = array_sum(array_intersect_key($data, array_flip($validStatuses)));
                    $data['total_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0);
                    $data['total_all_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0) + ($data['P'] ?? 0);
                    $data['total_percent_percentage'] = ($data['total_all_attendance'] > 0)
                        ? round(($data['P'] / $data['total_all_attendance']) * 100, 2)
                        : 0;
                }
            }

            foreach ($daily as $year => &$months) {
                foreach ($months as $month => &$days) {
                    foreach ($days as $day => &$data) {
                        $uniquePCount = count($uniquePDaily[$year][$month][$day]);
                        $data['unique_customers'] = $uniquePCount;

                        $data['total_students'] = array_sum(array_intersect_key($data, array_flip($validStatuses)));
                        $data['total_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0);
                        $data['total_all_attendance'] = ($data['L'] ?? 0) + ($data['A'] ?? 0) + ($data['P'] ?? 0);
                        $data['total_percent_percentage'] = ($data['total_all_attendance'] > 0)
                            ? round(($data['P'] / $data['total_all_attendance']) * 100, 2)
                            : 0;
                    }
                }
            }

            // ✅ Return structured data
            return [
                "valid_statuses" => $validStatuses,
                "yearly" => $yearly,
                "monthly" => $monthly,
                "daily" => $daily
            ];

        } catch (\Exception $e) {
            \Log::error("Error in GetStudentAttDetails: " . $e->getMessage());
            return null;
        }
    }
}
