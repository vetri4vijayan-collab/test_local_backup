<?php

namespace App\Http\Controllers\WebHookHandler;

use Illuminate\Http\Request;
use App\Models\ManageInternModel;
use App\Helpers\Helpers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;


class WebhookController extends Controller
{
  /**
   * Provide certificate data to central server
   */
  public function getCertificateData(Request $request)
  {
    // Validate API key for security
    Log::info('Webhook called on EAPL server', $request->all());
    $apiKey = $request->header('X-API-Key');
    $validKey = env('WEBHOOK_API_KEY');

    if (!$apiKey || $apiKey !== $validKey) {
      Log::warning('Invalid API key', ['received' => $apiKey]);
      return response()->json([
        'success' => false,
        'message' => 'Unauthorized'
      ], 401);
    }


    // Validate request
    $validated = $request->validate([
      'certificate_id' => 'required|string'
    ]);

    $certificateId = $validated['certificate_id'];

    // Fetch certificate data from your database
    $interns = ManageInternModel::where('za_intern.sno', $certificateId)
      ->join('za_intern_college', 'za_intern.college_id', '=', 'za_intern_college.sno')
      ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
      ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
      ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
      ->join('za_education', 'za_intern.degree_id', '=', 'za_education.sno')
      ->join('za_branch', 'za_intern.branch_id', '=', 'et_branch.sno')
      ->select(
        'za_intern.sno',
        'za_intern.intern_name',
        'za_intern.intern_id',
        'za_intern.intern_email',
        'za_intern.intern_mobile',
        'za_intern.start_date',
        'za_intern.end_date',
        'za_intern.year',
        'za_intern.transaction_all',
        'za_topic.title as topic',
        'za_intern_college.college_name',
        'za_letter_pad.company',
        'za_education.education'
      )
      ->first();

    if (!$interns) {
      return response()->json([
        'success' => false,
        'message' => 'Certificate not found'
      ], 404);
    }

    // Get transactions
    $transactions = json_decode($interns->transaction_all ?? '[]', true);

    // Return formatted data
    return response()->json([
      'success' => true,
      'data' => [
        'intern_name' => $interns->intern_name,
        'intern_id' => $interns->intern_id,
        'intern_email' => $interns->intern_email,
        'intern_mobile' => $interns->intern_mobile,
        'college_name' => $interns->college_name,
        'company' => $interns->company,
        'topic' => $interns->topic,
        'start_date' => $interns->start_date,
        'end_date' => $interns->end_date,
        'year' => $interns->year,
        'education' => $interns->education,
        'transactions' => $transactions
      ]
    ]);
  }
}
