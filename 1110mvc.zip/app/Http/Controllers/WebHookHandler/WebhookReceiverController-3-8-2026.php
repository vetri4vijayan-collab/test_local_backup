<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel;
use App\Models\SubDepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\JobpositionModel;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\UserRolePermissionModel;
use App\Events\StaffExistUpdated;
use App\Models\TransactionModel;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\GoalSetStaffModel;
use App\Models\IncentiveModel;
use App\Models\BranchModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\BatchModel;
use App\Models\ManageTargetModel;
use App\Models\AttendanceModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;



class WebhookReceiverController extends Controller
{

   public function broadcastMessage(Request $request)
        {
           
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }
 
                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);
 
                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
               
            $updateBroadcast = NewsBroadcastModel::updateOrCreate(
                ['external_uuid' => $payload['sno']],
                [
 
                    'template_name' => $payload['template_name'] ?? NULL,
                    'broadcast_message' => $payload['broadcast_message'] ?? NULL,
                    'branch_id' => $payload['branch_id'] ?? NULL,
                    'role_ids' => $payload['role_ids'] ?? NULL,
                    'start_date' => $payload['start_date'] ?? NULL,
                    'end_date' => $payload['end_date'] ?? NULL,
                    'information' => $payload['information'] ?? NULL,
                    'theme_id' => $payload['theme_id'] ?? 0,
                    'theme_style' => $payload['theme_style'] ?? NULL,
                    'created_by' => $request->user()->user_id ?? 0,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]
            );
 
           
 
            return response()->json([
                'ok' => true,
                'sno' => $updateBroadcast->sno,
            ], 200);
        }



    // Deparment Webhook Start
    public function DepartmentList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
       $departmentList=DB::table('za_department')
       ->select('za_department.*')
       ->where('za_department.status',0)
       ->get();
       $lastId = DB::table('za_department')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function DepartmentHook(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $department = DepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],
            [
                'department_id'    => $payload['department_id'] ?? null,
                'entity_id'        => 1,
                'branch_id'        =>  1,
                'department_name'  => $payload['department_name'],
                'department_desc'  => $payload['department_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'uuid' => $uuid,
        ], 200);
    }

    public function UpdateDepartmentUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_department_id'];
        if($erpId){
            $department = DepartmentModel::where('sno', $erpId)->first();

            if ($department) {
                $department->external_uuid = $uuid;
                $department->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'department Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'department id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }
    // Deparment Webhook End



     // Division Webhook Start
    public function DivisionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $depart_id = $request->department_id;
        // return $depart_id;
       $departmentList=DB::table('za_sub_department')
       ->select('za_sub_department.*','za_sub_department.sub_department_name as division_name');
       if($depart_id){
         $departmentList->where('za_sub_department.department_id',$depart_id);
       }
      
       $departmentList=$departmentList->where('za_sub_department.status',0)
       ->get();

       $lastId = DB::table('za_sub_department')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

     public function DivisionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

        $department = SubDepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'department_id'    => $payload['erp_department_id'],
                'branch_id'        => 1,
                'sub_department_name'  => $payload['division_name'],
                'sub_department_desc'  => $payload['division_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

     public function UpdateDivisionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_division_id'];
        if($erpId){
            $division = SubDepartmentModel::where('sno', $erpId)->first();

            if ($division) {
                $division->external_uuid = $uuid;
                $division->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Division Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Division id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $division->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

     // Division Webhook End

    // Job Position Webhook Start
    public function JobPostionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $division_id = $request->division_id;
        // return $depart_id;
       $departmentList=DB::table('za_job_position')
       ->select('za_job_position.*','za_job_position.sub_department_id as division_id');
       if($division_id){
         $departmentList->where('za_job_position.sub_department_id',$division_id);
       }
       $departmentList=$departmentList->where('za_job_position.status',0)
       ->get();
       $lastId = DB::table('za_job_position')
        ->orderBy('sno', 'desc')
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function JobPositionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

         $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {

              $year = substr(date("y"), -2);
              $job_position_id = "JP-0001/" . $year;
            } else {

              $data = $category_check->job_position_id;
              $slice = explode("/", $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);

              $next_number = (int) $result + 1;
              $request = sprintf("JP-%04d", $next_number);

              $year = substr(date("y"), -2);
              $job_position_id = $request . '/' . $year;
            }

        $department = JobpositionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'job_position_id'    => $job_position_id,
                'department_id'    => $payload['erp_department_id'],
                'division_id'    => $payload['erp_division_id'],
                'branch_id'        => 1,
                'job_position_name'  => $payload['job_position_name'],
                'job_position_desc'  => $payload['job_position_desc'] ?? null,
                'per_hour_cost'  => $payload['per_hour_cost'] ?? 0,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }
    public function UpdateJobPositionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_job_role_id'];
        if($erpId){
            $jobPosition = JobpositionModel::where('sno', $erpId)->first();

            if ($jobPosition) {
                $jobPosition->external_uuid = $uuid;
                $jobPosition->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $jobPosition->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Job Position Webhook End



    // UserRole Webhook Start
    public function userRoleList(Request $request)
    {
        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $departmentList = DB::table('za_user_role')
            ->select('za_user_role.*')
            ->where('za_user_role.status', 0)
            ->get();

        $lastId = DB::table('za_user_role')
            ->orderBy('sno', 'desc')
            ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;

        return response()->json([
            'status' => 200,
            'data' => $departmentList,
            'nextId' => $nextId
        ], 200);
    }

    public function UpdateUserRoleUUID(Request $request)
    {
        // Get UUID (idempotency key or generate a new UUID if not provided)
        $uuid = $request->header('X-IDEMPOTENCY-KEY')
            ?? $request->input('uuid')
            ?? (string) Str::uuid();

        $payload = $request->all();

        // Get the erp_role_id from the payload
        $erpId = $payload['erp_role_id'] ?? null;

        if ($erpId) {
            // Find the user role by erp_role_id
            $userRole = DB::table('za_user_role')->where('sno', $erpId)->first();

            if ($userRole) {
                // Update the external_uuid for the found user role
                DB::table('za_user_role')
                    ->where('sno', $erpId)
                    ->update(['external_uuid' => $uuid]);

                return response()->json([
                    'ok' => true,
                    'sno' => $userRole->sno,
                    'message' => 'External UUID updated successfully',
                    'uuid' => $uuid,
                ], 200);
            } else {
                // If user role is not found
                return response()->json([
                    'ok' => false,
                    'message' => 'User Role not found',
                    'uuid' => $uuid,
                ], 200); // Use 404 for not found error
            }
        } else {
            // If erp_role_id is not provided
            return response()->json([
                'ok' => false,
                'message' => 'User Role ID not provided',
                'uuid' => $uuid,
            ], 200); // Use 400 for bad request error
        }
    }
    // UserRole Webhook End

    // Staff Webhook Start

        public function StaffData(Request $request){

            $auth_key = $request->auth_key;
            $verify_key = 'egcsecret2030datagetapierp';

            if ($auth_key !== $verify_key) {
                return response()->json([
                    'status' => 410,
                    'data' => null,
                    'message' => 'Unauthorized Entry'
                ], 410);
            }

            $staffdata=DB::table('za_staff')
                ->select('za_staff.*','za_department.department_name','za_sub_department.sub_department_name as division_name','za_user_role.role_name')
                ->where('za_staff.branch_id',6)
                // ->where('za_staff.branch_id',11)
                ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
                ->join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
                ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
                ->where('za_staff.status',0)
                ->where('za_staff.sno','>',1)
                // ->whereIN('za_staff.sno',[162,164,188])
                // ->where('za_staff.department_id','!=',10)
                ->get();

            foreach($staffdata as $staff){
                if($staff->staff_image){
                    $staff->staff_image= url('staff_images/' . $staff->staff_image);
                }else{
                    $staff->staff_image='';
                }
                $staff->staff_work_info=[];
                if($staff->exp_type == 2){
                    $WorkDetails = StaffWorkInfoModel::where('staff_id', $staff->sno)->where('status',0)
                            ->get();
                    $staff->staff_work_info = $WorkDetails ?? [];

                }
                 $staff->staff_education_info=[];

                  $existingQualification = StaffEducationInfoModel::where('staff_id', $staff->sno)
                                    ->get();
                  $staff->staff_education_info = $existingQualification ?? [];


            }

            return response()->json(['status' => 200, 'data' => $staffdata], 200);
        }

        public function StaffAddHook(Request $request)
        {

            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }
                
                $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff already exists'
                    ], 200);
                }
                
                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }

                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
              $add_staff = StaffModel::updateOrCreate(
                  ['external_uuid' => $uuid],
                  [
                      'staff_id' => $payload['staff_id'],
                      'branch_id' => 6,
                      'branch_franchise' => 1,
                      'entity_id' => 1,
                      'shift_time_id' => 1,
                      'multi_branch_access' => null,
                      'sub_department_id' => $payload['sub_department_id'] ?? 0,
                      'department_id' => $payload['department_id'] ?? 0,
                      'role_id' => $payload['role_id'],
                      'exp_type' => $payload['exp_type'],
                      'staff_name' => $payload['staff_name'],
                      'mobile_no' => $payload['mobile_no'],
                      'alternative_no' => $payload['alternative_no'] ?? null,
                      'email_id' => $payload['email_id'],
                      'gender' => $payload['gender'],
                      'dob' => $payload['dob'],
                      'date_of_joining' => $payload['date_of_joining'],
                      'contact_person_name' => $payload['contact_person_name'] ?? null,
                      'contact_person_no' => $payload['contact_person_no'] ?? null,
                      'martial_status' => $payload['martial_status'],
                      'address' => $payload['address'] ?? null,
                      'staff_image' => $staff_image ?? null,
                      'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): json_encode([]),
                      'nick_name' => $payload['nick_name'] ?? null,
                      'position_role' => $payload['position_role'] ?? null,
                      'description' => $payload['description'] ?? null,
                      'basic_salary' => $payload['basic_salary'] ?? null,
                      'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                      'login_access' => $payload['login_access'] ?? 0,
                      'user_name' => $payload['user_name'],
                      'password' => $payload['password'],
                      'created_by' => $request->user()->user_id ?? 1,
                      'updated_by' => $request->user()->user_id ?? 1,
                  ]
              );
            if ($add_staff) {
                    // Create user credentials if not exists
                    $existingUser = User::where('user_id', $add_staff->sno)->first();
                    if (!$existingUser) {
                        if($payload['login_access'] == 1){
                        User::create([
                            'user_id' => $add_staff->sno,
                            'role_id' => $add_staff->role_id ?? 0,
                            'branch_id' => $add_staff->branch_id,
                            'entity_id' => $add_staff->entity_id,
                            'name' => $add_staff->user_name,
                            'password' => Hash::make($add_staff->password),
                            'email' => $add_staff->email_id,
                            'created_by' => $request->user()->user_id ?? 1,
                            'updated_by' => $request->user()->user_id ?? 1,
                        ]);
                        }
                    }


                        // if (!empty($payload['qualification_type'])) {
                        //     foreach ($payload['qualification_type'] as $key => $qualification_type) {
                        //         // Avoid duplicate work entries for same staff
                        //         $existingQualification = StaffEducationInfoModel::where('staff_id', $add_staff->sno)
                        //             ->where('qualification_type', $qualification_type)
                        //             ->where('degree_name', $payload['degree_name'][$key] ?? '')
                        //             ->first();

                        //         if (!$existingQualification) {
                        //             StaffEducationInfoModel::create([
                        //                 'staff_id' => $add_staff->sno,
                        //                 'qualification_type' => $qualificationType,
                        //                 'degree_name' => $payload['degree_name'][$key] ?? null,
                        //                 'major' => $payload['major'][$key] ?? null,
                        //                 'university_name' => $payload['university_name'][$key] ?? null,
                        //                 'created_by' => 1,
                        //                 'updated_by' => 1,
                        //             ]);
                        //         }
                        //     }
                        // }

                    // Handle work experience (if applicable)
                    if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                        foreach ($payload['work_company_name'] as $key => $company) {
                            // Avoid duplicate work entries for same staff
                            $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                                ->where('company_name', $company)
                                ->where('position', $payload['work_position'][$key] ?? '')
                                ->first();

                            if (!$existingWork) {
                                StaffWorkInfoModel::create([
                                    'staff_id' => $add_staff->sno,
                                    'staff_type' => $payload['exp_type'],
                                    'position' => $payload['work_position'][$key] ?? null,
                                    'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                    'company_name' => $company,
                                    // 'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                    // 'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                    'created_by' => $request->user()->user_id ?? 1,
                                    'updated_by' => $request->user()->user_id ?? 1,
                                ]);
                            }
                        }
                    }
                }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }

        public function UpdateStaffUUID(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) Str::uuid();

            $payload = $request->all();

            $erpId = $payload['erp_staff_id'];
            if($erpId){
                $staff = StaffModel::where('sno', $erpId)->first();

                if ($staff) {
                    $staff->external_uuid = $uuid;
                    $staff->save();
                }else{
                    return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff Not Found',
                    'uuid' => $uuid,
                ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
            return response()->json([
                'ok'  => true,
                'sno' => $staff->sno,
                'meassage'=>'external uuid updated',
                'uuid' => $uuid,
            ], 200);
        }

    // Staff Webhook End

    // Staff Attendance Webhook Start
        public function StaffAddAttendanceHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }


                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                $staffData = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
                
                 $alreadyExists = StaffAttendanceModel::where([
                    ['staff_id', '=', $staffData->sno],
                    ['date', '=', $payload['date']],
                    ['status', '!=', 2], 
                ])->first();
            $year = date("Y");
            $month = date("m");
            $addStaff = null;
            if (in_array($payload['attendance'], ['OD', 'PR','P'])) {
                
            if ($alreadyExists) {
                $alreadyExists->attendance = $payload['attendance'];
                $alreadyExists->time_start = $payload['time_start'] ?? null;
                $alreadyExists->time_end = $payload['time_end'] ?? null;
                $alreadyExists->reason = $payload['reason'] ?? null;
                $alreadyExists->external_uuid = $uuid ;
                $alreadyExists->update();
                $addStaff=$alreadyExists;
            }else{
                // Generate a new staff attendance ID
                    $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                    $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

                    // Save new attendance record
                $addStaff= StaffAttendanceModel::updateOrCreate(
                        ['external_uuid' => $uuid],
                        [
                        'staff_attendance_id' => $staff_attendance_id,
                        'branch_id'           => $staffData->branch_id ?? 6,
                        'staff_id'            => $staffData->sno,
                        'date'                => $payload['date'],
                        'attendance'          => $payload['attendance'],
                        'type'                => $payload['type'] ?? null,
                        'time_start'          => $payload['time_start'] ?? null,
                        'time_end'            => $payload['time_end'] ?? null,
                        'reason'              => $payload['reason'] ?? null,
                        'created_by'          => 0,
                        'updated_by'          => 0,
                        ]
                );
            }  
            
                
            }

            return response()->json([
                'ok' => true,
                'sno' => $addStaff ? $addStaff->sno : 0,
            ], 200);
        }

    
         public function StaffAddAttendanceHookEssl(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('batch_uuid')
                ?? (string) Str::uuid();
 
           $rawContent = $request->getContent();

                $payload = json_decode($rawContent, true);

                // If double encoded JSON string
                if (is_string($payload)) {
                    $payload = json_decode($payload, true);
                }

                // Final fallback
                if (!$payload || !is_array($payload)) {
                    $payload = $request->all();
                }

            if (empty($payload['records']) || !is_array($payload['records'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Attendance records required',
                    "data" => $payload ?? "-"
                ], 400);
            }


 
            DB::beginTransaction();
 
            try {
 
                foreach ($payload['records'] as $record) {
 
                    $staffData = StaffModel::where('external_uuid', $record['staff_id'])->first();
 
                    if (!$staffData) {
                        continue; // skip if staff not found
                    }
 
                    $alreadyExists = StaffAttendanceModel::where([
                        ['staff_id', '=', $staffData->sno],
                        ['date', '=', $record['date']],
                        ['status', '!=', 2],
                    ])->first();
 
                    if ($alreadyExists) {
 
                        if (in_array($alreadyExists, ['OD', 'PR', 'L','P'])) {
                                $alreadyExists->update([
                                    'in_time'    => $record['in_time'] ?? null,
                                    'out_time'   => $record['out_time'] ?? null,
                                ]);
                        }else{
                            $alreadyExists->update([
                                'attendance' => $record['attendance'],
                                'in_time'    => $record['in_time'] ?? null,
                                'out_time'   => $record['out_time'] ?? null,
                                'reason'     => $record['reason'] ?? null,
                                'external_uuid' => $record['sno'],
                            ]);
                        }
 
                    } else {
 
                        $category_check = StaffAttendanceModel::where('status','!=',2)
                            ->orderBy('sno','desc')
                            ->first();
 
                        $staff_attendance_id = $this->generateStaffAttendanceId(
                            $category_check,
                            date("m"),
                            date("Y")
                        );
                        
                        if($record['attendance'] != 'A'){
 
                        StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'branch_id'           => $staffData->branch_id ?? 6,
                            'staff_id'            => $staffData->sno,
                            'date'                => $record['date'],
                            'attendance'          => $record['attendance'],
                            'in_time'             => $record['in_time'] ?? null,
                            'out_time'            => $record['out_time'] ?? null,
                            'reason'              => $record['reason'] ?? null,
                            'external_uuid'       => $record['sno'],
                            'created_by'          => 0,
                            'updated_by'          => 0,
                        ]);
                    }
                    }
                }
 
                DB::commit();
 
                return response()->json([
                    'ok' => true,
                    'message' => 'Attendance processed successfully'
                ], 200);
 
            } catch (\Throwable $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'ok' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
        }
        private function generateStaffAttendanceId($category_check, $month, $year)
        {
            if (!$category_check) {
                return 'ATT0001/' . $month . '/' . $year;
            }

            // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
            $data = $category_check->staff_attendance_id;
            $slice = explode("/", $data);

            // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
            $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$resultcus + 1;

            // Return the formatted ID (e.g., "ATT0002/11/2025")
            return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
        }
    // Staff Attendance Webhook End


// user Credential Check Api
    public function userCrendentialCheck(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        $user = User::select('users.*', 'za_staff.status as staff_status')
        ->where('users.name', $request->name)
        ->leftJoin('za_staff', 'users.user_id', '=', 'za_staff.sno')
        ->leftJoin('za_branch', 'users.branch_id', '=', 'za_branch.sno')
        // ->where('za_staff.status', 0)
        ->where('za_branch.status', 0)
        ->first();
        
        if (!$user) {
            return response()->json([
                'type' => 'error',
                'message' => 'User not found.'
            ]);
        }

        if ($user->staff_status == 1) {

            return response()->json([
                'type' => 'error',
                'message' => 'This user is inactive. Please contact the administrator.'
            ], 200);

        } elseif ($user->staff_status == 2) {
            return response()->json([
                'type' => 'error',
                'message' => 'This user is deactivated. Please contact the administrator.'
            ], 200);
        }
        if ($user->name !== $request->name) {
            return response()->json([
                'type' => 'error',
                'message' => 'Username is case-sensitive. Please enter the correct case.'
            ], 200);
        }

        // if (!Hash::check($request->password, $user->password)) {
        //     return response()->json([
        //         'type' => 'error',
        //         'message' => 'Invalid credentials'
        //     ], 200);
        // }

        $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();
    
        if (!$permissions) {
            return response()->json([
                'type' => 'error',
                'message' => 'Role Permission Not Set in EAPL ERP'
            ], 200);
        }

        return response()->json([
        'type' => 'Success',
        'message' => 'User Found'
        ], 200);
        
    }


public function updateTargets(Request $request)
    {
        DB::beginTransaction();
 
        try {
 
            //  Idempotency
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) \Str::uuid();
 
            $payload = $request->all();
 
            // Handle string payload
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);
            }
 
            \Log::info('Decoded Payload:', $payload);
 
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
 
            $targets = $payload['targets'] ?? [];
 
            foreach ($targets as $target) {
 
                DB::table('branch_target')->updateOrInsert(
                    [
                        'branch_id' => $target['branch_id'],
                        'date'      => $target['date'],
                    ],
                    [
                        'quarter' => $target['quarter'],
                        'no_of_registrations' => $target['pre_sale'],
                        'post_sale' => $target['post_sale'],
                        'monthly_target' => $target['monthly_target'],
                        'updated_by' => 1,
                        'created_by' => 1,
                        'updated_at' => now(),
                    ]
                );
 
                $targetId = DB::table('branch_target')
                    ->where('branch_id', $target['branch_id'])
                    ->where('date', $target['date'])
                    ->value('sno');
 
                foreach ($target['weeks'] as $week) {
 
                    // [$startDay, $endDay] = $this->getWeekRange($week['week'], $target['date']);
 
                    DB::table('za_weekly_metrics')->updateOrInsert(
                        [
                            'target_id' => $targetId,
                            'week_name' => 'Week ' . $week['week'],
                        ],
                        [
                            'start_day' => \Carbon\Carbon::parse($week['start_day'])->format('d'),
                            'end_day'   => \Carbon\Carbon::parse($week['end_day'])->format('d'),
                            'percentage' => $week['percentage'],
                            'target_amount' => $week['target_amount'],
                            'pre_sale' => $week['pre_sale'],
                            'post_sale' => $week['post_sale'],
                            'updated_by' => 1,
                            'created_by' => 1,
                            'updated_at' => now(),
                        ]
                    );
                }
            }
            DB::commit();
 
            return response()->json([
                'ok' => true,
                'message' => 'Target synced successfully'
            ], 200);
 
        } catch (\Exception $e) {
 
            DB::rollBack();
 
            \Log::error('Target Sync Failed: ' . $e->getMessage());
 
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
 
  public function UpdateExistStaff(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('uuid')
                ?? (string) Str::uuid();
 
            $payload = $request->all();
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }
 
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
            try{
 
            if($payload['staff_id']){
                // $staff = StaffModel::where('sno', $erpId)->first();
                $staff = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
 
                if ($staff) {
                    $staff->status = 1;
                    $staff->is_exist_egc = $payload['status'] ?? 1;;
                    $staff->dep_reason = $payload['dep_reason'] ?? null;
                    $staff->notice_start_date = $payload['notice_start_date'] ?? null;
                    $staff->notice_end_date = $payload['notice_end_date'] ?? null;
                    $staff->staff_last_date = $payload['staff_last_date'] ?? null;
                    $staff->save();
 
                    event(new StaffExistUpdated($staff));
 
                     return response()->json([
                        'ok'  => true,
                        'sno' => $staff->sno,
                        'meassage'=>'Exit Staff Updated',
                        'uuid' => $uuid,
                    ], 200);
                   
 
                }else{
                    return response()->json([
                        'ok'  => true,
                        'meassage'=>'Staff Not Found',
                        'uuid' => $uuid,
                    ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
 
            }catch(\Throwable $e){
                    return response()->json([
                        'ok'  => false,
                        'message' => $e->getMessage(),
                    ], 500);
            }
            // $erpId = $payload['erp_staff_id'];
           
 
           
        }
 
        public function existStaffCount()
    {
        $count = StaffModel::where('is_exist_egc', '!=',0)
            ->where('status', 1)
            ->count();
 
        return response()->json([
            'count' => $count
        ]);
    }
 
       public function existStaffList()
    {
        $staff = StaffModel::where('za_staff.is_exist_egc','!=',0)
            ->where('za_staff.status', 1)
            ->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->select(
                'za_staff.staff_name',
                'za_staff.sno as id',
                'za_staff.staff_image',
                'za_staff.external_uuid',
                'za_staff.is_exist_egc',
                'za_staff.staff_last_date',
                'za_staff.notice_start_date',
                'za_staff.notice_end_date',
                'za_staff.dep_reason',
                'za_department.department_name',
                'za_job_position.job_position_name'
            )
            ->get();
 
        return response()->json($staff);
    }

public function getAchieveData(Request $request)
    {
        try {
 
            $verify_key = 'egcsecret2030datagetapierp';
 
            if ($request->verify_key !== $verify_key) {
 
                return response()->json([
                    'status' => false,
                    'message' => 'Unauthorized'
                ], 401);
            }
 
            $branchId = $request->branch_id;
 
            $fromDate = Carbon::parse($request->from_date)->format('Y-m-d');
            $toDate   = Carbon::parse($request->to_date)->format('Y-m-d');
 
            $dates = [];
 
            $period = CarbonPeriod::create($fromDate, $toDate);
            $helper = new \App\Helpers\Helpers();
 
            $branch_common = DB::table('za_branch')->select('za_branch.*')
            ->where('za_branch.sno', $branchId)
            ->first();
 
            foreach ($period as $dateObj) {
 
                $date = $dateObj->format('Y-m-d');
 
                $dailyCredit = TransactionModel::where('branch_id', $branchId)
                    ->whereDate('transaction_date', $date)
                    ->sum('credit');
               
                $total_collection_value = round($dailyCredit);
 
                // PRE SALE
                $preSale = DB::table('za_customer')->whereIn('status', [0, 6])
                    ->where('post_sale_check', '!=', 1)
                    ->where('branch_id', $branchId)
                    ->whereDate('created_at', $date)
                    ->count();
 
                // POST SALE
                // $postSale = DB::table('za_customer')->whereIn('status', [0, 6])
                //     ->where('post_sale_check', 1)
                //     ->where('branch_id', $branchId)
                //     ->whereDate('created_at', $date)
                //     ->count();
 
                $postSale =DB::table('za_customer')->whereIn('za_customer.status',[0,6])
                    ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
                    ->where('za_customer.branch_id', $branchId)
                    ->where('za_customer.post_sale_check', 1)
                    ->where('za_training.post_sale_check', 1)
                    ->whereIn('za_customer.status',[0,6])
                    ->whereDate('za_training.created_at', $date)
                    ->count();
 
                $dates[] = [
                    'date' => $date,
                    'amount' => $total_collection_value,
                    'pre_sale' => (int)$preSale,
                    'post_sale' => (int)$postSale
                ];
            }
 
            return response()->json([
                'status' => true,
                'data' => $dates
            ]);
 
        } catch (\Exception $e) {
 
            \Log::error('Achieve API Error : ' . $e->getMessage());
 
            return response()->json([
                'status' => false,
                'message' => 'Server Error'
            ]);
        }
    }

   public function GetIncentive(Request $request)
{
    try {

        if ($request->verify_key !== 'egcsecret2030datagetapierp') {

            return response()->json([
                'status'  => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $request->validate([
            'branch_id' => 'required|integer',
            'role_id'   => 'required',
            'month_year'=> 'nullable|string'
        ]);

        $branchId = (int) $request->branch_id;
        $roleId   = trim($request->role_id);

        $monthFilter = $request->get('month_year', date('M-Y'));
        try {

            $parsedDate = Carbon::createFromFormat('M-Y', $monthFilter);

        } catch (\Exception $e) {

            $parsedDate = now();
        }

        $month = (int) $parsedDate->month;
        $year  = (int) $parsedDate->year;

        $cacheVersion = 'v3';

        $cacheKey = implode('_', [
            'incentive',
            $cacheVersion,
            'branch', $branchId,
            'role', $roleId,
            'year', $year,
            'month', $month
        ]);

        // $responseData = Cache::remember(
        //     $cacheKey,
        //     now()->addMinutes(5),
        //     function () use (
        //         $branchId,
        //         $roleId,
        //         $year,
        //         $month
        //     ) {
                $staffs = DB::table('za_staff')
                    ->select([
                        'sno',
                        'staff_name',
                        'external_uuid',
                        'role_id'
                    ])
                    ->where('role_id', $roleId)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    // ->where('sno', 77)
                    ->orderBy('staff_name')
                    ->get();

                if ($staffs->isEmpty()) {

                    return [
                        'generated_at' => now()->format('Y-m-d H:i:s'),
                        'next_refresh' => now()->addMinutes(30)->format('Y-m-d H:i:s'),
                        'count'        => 0,
                        'data'         => []
                    ];
                }

                $incentiveData = [];

                foreach ($staffs as $staff) {
                    try {
                        $result = self::calculateIncentiveValue(
                            $staff->sno,
                            $branchId,
                            $roleId,
                            $year,
                            $month
                        );
                        // return $result;
                        $totalAward = (float) ($result['total_award'] ?? 0);
                        $breakdown = $result['breakdown'] ?? [];
                        $metrics = $result['metrics'] ?? [];

                        foreach ($breakdown as $key => $value) {
                            $breakdown[$key] = (float) $value;
                        }

                        $incentiveData[] = [
                            'staff_id' => (int) $staff->sno,
                            'external_uuid' => (int) $staff->external_uuid,
                            'staff_name' => $result['staff_name']
                                ?? $staff->staff_name,
                            'role_id' => $result['role_id']
                                ?? $staff->role_id,
                            'total_award' => round($totalAward, 2),
                            'currency' => 'INR',
                            'breakdown' => $breakdown,
                            'metrics' => $metrics,
                            'last_updated' => now()
                                ->format('Y-m-d H:i:s'),
                            'next_update' => now()
                                ->addMinutes(5)
                                ->format('Y-m-d H:i:s'),
                        ];

                    } catch (\Throwable $e) {
                        Log::error('Incentive Staff Error', [
                            'staff_id' => $staff->sno,
                            'message'  => $e->getMessage()
                        ]);

                        $incentiveData[] = [
                            'staff_id'      => (int) $staff->sno,
                            'external_uuid'      => (int) $staff->external_uuid,
                            'staff_name'    => $staff->staff_name,
                            'external_uuid'    => $staff->external_uuid,
                            'role_id'       => $staff->role_id,
                            'total_award'   => 0,
                            'currency'      => 'INR',
                            'breakdown'     => [],
                            'metrics'     => [],
                            'last_updated'  => now()->format('Y-m-d H:i:s'),
                            'next_update'   => now()->addMinutes(5)
                                ->format('Y-m-d H:i:s'),
                            'err_mssg'   => $e->getMessage(),
                        ];
                    }
                }
                usort($incentiveData, function ($a, $b) {
                    return $b['total_award'] <=> $a['total_award'];
                });
                return [
                    'generated_at' => now()
                        ->format('Y-m-d H:i:s'),
                    'next_refresh' => now()
                        ->addMinutes(5)
                        ->format('Y-m-d H:i:s'),
                    'count' => count($incentiveData),
                    'data' => $incentiveData
                ];
        //     }
        // );
        return response()->json([
            'status'  => true,
            'message' => 'Incentive data fetched successfully',
            'cached' => true,
            'cache_expires_in_minutes' => 30,
            'generated_at' => $responseData['generated_at'] ?? null,
            'next_refresh' => $responseData['next_refresh'] ?? null,
            'total_staff' => $responseData['count'] ?? 0,
            'data' => $responseData['data'] ?? []
        ]);

    } catch (\Throwable $e) {
        Log::error('Get Incentive API Error', [
            'message' => $e->getMessage(),
            'line'    => $e->getLine(),
            'file'    => $e->getFile(),
        ]);
        return response()->json([

            'status'  => false,
            'message' => 'Server Error'
        ], 500);
    }
}

 private static function calculateIncentiveValue($userId, $branchId, $roleId, $year, $month)
  {
    $staff = StaffModel::find($userId);
    if (!$staff) {
      return self::getEmptyResponse();
    }

    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');

    $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
    $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;

    $current = Carbon::create($year, $month, 1);
    $startDateold = $current->copy()->subYears(20)->startOfMonth();
    $endDateold = $current->copy()->subMonth()->endOfMonth();

    // Get incentive settings
    $incentive = IncentiveModel::where('role_id', $roleId)
      ->where('branch_id', $branchId)
      ->whereMonth('incentive_month', $month)
      ->whereYear('incentive_month', $year)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      // Try fallback date
      $fallbackDate = '2025-06-01';
      $incentive = IncentiveModel::where('role_id', $roleId)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', date('m', strtotime($fallbackDate)))
        ->whereYear('incentive_month', date('Y', strtotime($fallbackDate)))
        ->where('status', 0)
        ->first();
    }

    if (!$incentive) {
      return self::getEmptyResponse();
    }


    $checkRole = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $month)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->where('staff_id', 123)
      ->first();

    $query = StaffModel::join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
      ->where('za_staff.branch_id', $branchId);

    if ($checkRole && $checkRole->sales_lead_check == 1 && $roleId == 11) {
      $query->whereIn('za_staff.role_id', [11, 12]);
    } else {
      $query->where('za_staff.role_id', $roleId);
    }

    $staffList = $query->where('za_staff.status', 0)
      ->select(
        'za_staff.sno as staff_id',
        'za_staff.staff_name',
        'za_staff.role_id',
        'za_staff.department_id',
        'za_staff.staff_image',
        'za_staff.nick_name',
        'za_staff.branch_id',
        'za_branch.branch_name',
        'za_branch.franchise_name',
        'za_branch.cert_auth_sign',
        'za_staff.avaiable_points',
        'za_staff.per_hour_cost',
        'za_staff.basic_salary',
        'za_sub_department.sub_department_id',
        'za_sub_department.sub_department_name',
        'za_department.department_name'
      )
      ->get();

    $departmentIds = $staffList->pluck('department_id')->unique()->toArray();

    // Get goal data
    $goalData = GoalSetStaffModel::where('staff_id', $userId)
      ->where('goal_month', $month)
      ->whereYear('goal_date', $year)
      ->first();

    $goalsetteam = GoalSetTeamModel::whereIn('za_goal_set_team.department_id', $departmentIds)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

     $goalsetRecords = GoalSetStaffModel::whereIn('za_goal_set_staff.department_id', $departmentIds)
      ->where('za_goal_set_staff.branch_id', $branchId)
      ->where('za_goal_set_staff.goal_month', $month)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->get();
    // return  $goalData ;
    $goalsetDataArray = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetDataArray[$goal->staff_id] = $goal;
    }

    $current_date = date('Y-m-d');

    // Calculate based on role
    $totalReward = 0;
    $breakdown = [];
    $metrics = [];

    switch ($roleId) {
      case 11: // Sales Executive
        $result = self::processSalesExecutive($staff, $incentive, $goalData, $branchId, $month, $year,  $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates);
        // $totalReward = $result;
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 12: // Team Lead
        $result = self::processTeamLead($staff, $incentive,$goalsetteam,$goalsetRecords, $branchId,$month, $year, $startDate,$endDate, $startOfMonth, $endOfMonth,$prevMonth,$prevYear,$dates,$goalData,$goalsetDataArray);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 14: // Collection
        $result = self::processCollection($staff,$incentive,$goalsetteam, $goalData, $branchId,$month, $year, $startDateold, $endDateold, $startDate,$endDate);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 15: // PC
        $result = self::processPC($staff, $incentive, $goalsetteam,  $goalData, $branchId,$month,$year,$current_date);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 16: // CRE
        $result = self::processCRE($staff, $incentive, $goalsetteam, $goalData, $branchId, $month, $year);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 22: // Production
        $result = self::processProduction($staff, $incentive, $goalsetteam, $goalsetDataArray, $branchId,  $month, $year, $current_date);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 17: // Placement Executive
        $result = self::processPlacementEx( $staff, $incentive, $goalsetteam, $goalData, $branchId, $month, $year);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 19: // Placement Lead
        $result = self::processPlacementLead($staff, $incentive,$goalsetteam, $goalData,$branchId, $month,$year);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      case 36: // BDM
        $result = self::processBDM($staff, $incentive, $goalsetteam, $goalData, $branchId,$month, $year, $startDate, $endDate, $startDateold, $endDateold, $prevMonth,$prevYear, $dates,$startOfMonth, $endOfMonth);
        $totalReward = $result['total'];
        $breakdown = $result['breakdown'];
        $metrics = $result['metrics'];
        break;
      default:
        return self::getEmptyResponse();
    }
        // return $totalReward;
    return [
      'total_award' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => $metrics,
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'staff_name' => $staff->staff_name,
      'staff_id' => $staff->sno,
      'egc_staff_id' => $staff->external_uuid,
      'role_id' => $roleId
    ];
  }

  private static function processSalesExecutive($staff, $incentive, $goalsetData, $branchId, $month ,$year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates)
  {

    $totalReward = 0;
    $breakdown = [];
    $staffId = $staff->sno;
   

    // All Lead Count
    $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Month Lead Count
    $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staffId)
      ->where('za_lead.branch_id', $branchId)
      ->whereYear('za_lead.registered_date', $year)
      ->whereMonth('za_lead.registered_date', $month)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    // Customer Convert Count This Month
    $customerConvertCountthismonth = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Branch
    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    // Drop Refund
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    // Paid Under Payment
    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $totalItems = $finalResult->count();
    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));

    // Month Call Out
    $monthcall_out = DB::table('za_call_tracker')
      ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('za_call_tracker.branch_id', $branchId)
      ->where('za_call_tracker.branch_staff_id', $staffId)
      ->first();
    $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;

    // Conversion Rate
    $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
    $convertion_rate = number_format($convertion_rate, 2);

    // Average Conversion Rate
    $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
    $averager_convertion_rate = number_format($averager_convertion_rate, 2);

    $luxury = json_decode($incentive->luxury_incentive, true);
    $pi_slabs = json_decode($incentive->pi_slab_json, true);

    $targetConversion = $goalsetData->conversion ?? 0;
    $targetABV = $goalsetData->ABV ?? 0;
    $targetACV = $goalsetData->ACV ?? 0;
    // return $targetConversion;
    // Initialize variables
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;
    $total_payment = 0;
    $total_paid_payment = 0;
    $eciCustomerConvertCount = 0;

    // Get Current Month Customers
    $currentMonthCustomer = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->get();

    // ECI Count
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->count();

    // Calculate Training Counts
    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $hasTesbo = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('branch_id', $branchId)
          ->whereMonth('created_at', $month)
          ->whereYear('created_at', $year)
          ->where('tesbo_check', 2)
          ->where('post_sale_check', '!=', 1)
          ->exists();

        if ($hasTesbo) {
          $tesboCount++;
          continue;
        }

        $nonTesboTrainings = DB::table('za_training')
          ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
          ->where('za_training.customer_id', $customer->sno)
          ->where('za_training.branch_id', $branchId)
          ->whereMonth('za_training.created_at', $month)
          ->whereYear('za_training.created_at', $year)
          ->where('za_training.post_sale_check', '!=', 1)
          ->where('za_training.tesbo_check', '!=', 2)
          ->whereIn('za_course.course_type_id', [3, 4])
          ->select('za_course.course_type_id')
          ->get();

        $hasCrash = false;
        $hasProfession = false;

        foreach ($nonTesboTrainings as $training) {
          if ($training->course_type_id == 3) {
            $hasProfession = true;
          } elseif ($training->course_type_id == 4) {
            $hasCrash = true;
          }
        }

        if ($hasCrash) $crashCount++;
        if ($hasProfession) $professionCount++;
      }
    }

    // Calculate Payments
    if ($currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 0)
          ->sum('overall_fees');
        $total_payment += $payment;

        $latestTraining = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->where('tesbo_check', 2)
          ->orderByDesc('sno')
          ->first();

        if ($latestTraining) {
          $total_payment += $latestTraining->overall_fees;
        }

        $paid_payment = DB::table('za_training')
          ->where('customer_id', $customer->sno)
          ->sum('paid_amount');
        $total_paid_payment += $paid_payment;
      }
    }

    // SP Calculation
    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereBetween('za_customer.created_at', [$startDate, $endDate])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at',
        'za_lead.lead_mobile as lead_mobile'
      )
      ->get();

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $lastCall = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->orderByDesc('call_start_date')
        ->first();

      $totalCallCount = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->count();

      $row->call_created_at = $lastCall->call_start_date ?? null;
      $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
      $row->call_count = $totalCallCount;
    }

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $mobile = $row->lead_mobile;
      $totalCalldata = DB::table('za_call_tracker')
        ->where('branch_id', $branchId)
        ->where('branch_staff_id', $staffId)
        ->where('customer_phone_no', 'like', "%{$mobile}")
        ->select('call_start_date')
        ->get();

      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
      $call_count = $row->call_count;

      if ($customerDate === $leadDate && $call_count === 1) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        $leadDate >= $startOfMonth && $leadDate <= $endOfMonth &&
        $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
          $callDate = Carbon::parse($call->call_start_date);
          return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
        })
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $endOfMonth &&
        ($leadDate < $startOfMonth || $leadDate > $endOfMonth)
      ) {
        $convertedOldMonth++;
      }
    }

    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    // PI Calculation
    $originalAmount = 0;
    $piPercentage = 0;
    $slabPercentage = 0;
    $matchedSlab = null;
    $piReward = 0;

    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
      foreach ($currentMonthCustomer as $customer) {
        $trainings = DB::table('za_training as t1')
          ->join(DB::raw('(SELECT MIN(sno) as min_sno FROM za_training WHERE post_sale_check = 0 GROUP BY customer_id) as t2'), 't1.sno', '=', 't2.min_sno')
          ->where('t1.customer_id', $customer->sno)
          ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
          ->get();

        foreach ($trainings as $training) {
          $course_id = null;

          if ($training->tesbo_check > 0) {
            $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
            if ($payment && $payment->course_id) {
              $course_id = $payment->course_id;
            }
          } else {
            $course_id = $training->course_id;
          }

          if (!$course_id) continue;

          $course = ManageCoursesModel::where('sno', $course_id)
            ->whereIn('course_type_id', [2, 3])
            ->first();

          if (!$course) continue;

          $basePrice = $course->course_min_price;
          $soldPrice = $training->overall_fees;
          $profitAmount = $soldPrice - $basePrice;
          $originalAmount += $profitAmount;

          $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;

          foreach ($pi_slabs as $slab) {
            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
              $slabPercentage = $slab['percentage'];
              $piReward = ($originalAmount * $slabPercentage) / 100;
              $piPercentage = $profitPercent;
              $matchedSlab = "{$slab['min']} < {$slab['max']}%";
              break;
            }
          }
        }
      }
    }

    // SI Calculation
    $crashTarget = $incentive->si_crash_course ?? 0;
    $professionTarget = $incentive->si_profession_course ?? 0;
    $tesboTarget = $incentive->si_tesbo_course ?? 0;

    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / max(1, $customerConvertCountthismonth)) * 100 : 0;
    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / max(1, $customerConvertCountthismonth)) * 100 : 0;

    $siStatus = false;
    if ($customerConvertCountthismonth >= 20) {
      $siStatus = true;
      if ($incentive->si_crash_course > 0) {
        $siStatus = $siStatus && ($crashPercent >= $crashTarget || $crashPercent <= $crashTarget);
      }
      if ($incentive->si_profession_course > 0) {
        $siStatus = $siStatus && ($professionPercent >= $professionTarget);
      }
      if ($incentive->si_tesbo_course > 0) {
        $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
      }
    }

    // ECI Logic
    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
    $eciActualPercentage = number_format($eciActualPercentage, 2);
    $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

    // Averages
    $averageBusinessValue = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
    $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : 0;

    // 10X Status
    $tenxStatus = $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 && $customerConvertCount >= $targetConversion;

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $customerConvertCount - $targetConversion);
    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $biAchievedCount > 0;


        $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
        $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

        $breakdown['ECI Award'] = ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0;
        $totalReward += ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0;

        $breakdown['BI Award'] = ($tenxStatus && $biStatus) ? $biReward : 0;
        $totalReward += ($tenxStatus && $biStatus) ? $biReward : 0;

        $breakdown['SI Award'] = ($tenxStatus && $siStatus) ? ($incentive->si_reward ?? 0) : 0;
        $totalReward += ($tenxStatus && $siStatus) ? ($incentive->si_reward ?? 0) : 0;

        $breakdown['PRF Award'] = ($tenxStatus && $piReward > 0) ? round($piReward) : 0;
        $totalReward += ($tenxStatus && $piReward > 0) ? round($piReward) : 0;

        $breakdown['SP Award'] = ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0;
        $totalReward += ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0;

        $breakdown['LI Award'] = ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? ($luxury['reward'] ?? 0) : 0;
        $totalReward += ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) ? ($luxury['reward'] ?? 0) : 0;
       
        
        


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetConversion,
        'actual' => $customerConvertCount,
        'actual_original' => $customerConvertCountthismonth,
        'target_abv' => $targetABV,
        'actual_abv' => round($averageBusinessValue),
        'target_acv' => $targetACV,
        'actual_acv' => round($averageCollectionValue),
        'eci_target' => $eciTargetPercentage,
        'eci_actual' => round($eciActualPercentage, 1),
        'bi_actual' => round($biAchievedCount),
        'on_day_count' => $convertedToday,
        'on_month_count' => $convertedMonth,
      ]
    ];

  }

   private static function processTeamLead($staff, $incentive, $goalsetteam, $goalsetRecords, $branchId, $month, $year, $startDate, $endDate, $startOfMonth, $endOfMonth, $prevMonth, $prevYear, $dates, $goalsetData,$goalsetDataArray)
  {

    $totalReward = 0;
    $breakdown = [];

    $checkRecord = GoalSetStaffModel::where('branch_id', $branchId)
      ->where('goal_month', $month)
      ->whereMonth('goal_date', $month)
      ->whereYear('goal_date', $year)
      ->where('staff_id', $staff->sno)
      ->first();

    if ($checkRecord && $checkRecord->sales_lead_check == 0) {
      $executives = StaffModel::where('branch_id', $staff->branch_id)
        ->where('department_id', $staff->department_id)
        ->where('role_id', 11)
        ->where('status', 0)
        ->get();

      $executiveIds = $executives->pluck('sno')->toArray();
      $executiveGoalSet = $goalsetRecords
        ->whereIn('staff_id', $executiveIds)
        ->where('conversion', '>', 0)
        ->pluck('staff_id')
        ->unique()
        ->toArray();

      $incentive = IncentiveModel::where('role_id', 11)
        ->where('branch_id', $branchId)
        ->where('status', 0)
        ->first();

      if (!$incentive) {
        return [];
      }

      $filteredExecutives = $executives->whereIn('sno', $executiveGoalSet);
      $allExecutiveIncentives = [];
      foreach ($filteredExecutives as $executive) {
        $allExecutiveIncentives['staff_' . $executive->sno] = self::calculateIncentivesForStaff(
          $executive,
          $branchId,
          $month,
          $year,
          $goalsetDataArray
        );
      }

      $finalStatus = self::getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives);
      $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
        ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->whereMonth('branch_target.date', $month)
        ->whereYear('branch_target.date', $year)
        ->select('branch_target.*')
        ->first();

      $preSaleActual = CustomerModel::whereIn('status', [0, 6])
        ->where('branch_id', $branchId)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;

      
        $breakdown['10X Award'] = $individual10x ? ($incentive->tenx_award ?? 0) : 0;
        $totalReward += $individual10x ? ($incentive->tenx_award ?? 0) : 0;

        $breakdown['ECI Award'] = $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0;
        $totalReward += $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0;

        $breakdown['BI Award'] = $finalStatus['bi'] ? ($incentive->bi_amount ?? 0) : 0;
        $totalReward += $finalStatus['bi'] ? ($incentive->bi_amount ?? 0) : 0;

        $breakdown['SI Award'] = $finalStatus['si'] ? 3000 : 0;
        $totalReward += $finalStatus['si'] ? 3000 : 0;

        $breakdown['PRF Award'] = $finalStatus['pi'] ? ($incentive->pi_reward ?? 0) : 0;
        $totalReward += $finalStatus['pi'] ? ($incentive->pi_reward ?? 0) : 0;

        $breakdown['SP Award'] = $finalStatus['sp'] ? ($incentive->spot_total_reward ?? 0) : 0;
        $totalReward += $finalStatus['sp'] ? ($incentive->spot_total_reward ?? 0) : 0;

        $breakdown['LI Award'] = ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']) ? ($incentive->luxury_reward ?? 0) : 0;
        $totalReward += ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']) ? ($incentive->luxury_reward ?? 0) : 0;
       
        
        


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
       
      ]
    ];
      
    } else {
      return self::processSalesExecutive(
        $staff,
        $incentive,
        $goalsetData,
        $branchId,
        $month,
        $year,
        $startDate,
        $endDate,
        $startOfMonth,
        $endOfMonth,
        $prevMonth,
        $prevYear,
        $dates
      );
    }
  }


  private static function processCollection($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDateold, $endDateold, $startDate, $endDate)
  {

    $totalReward = 0;
    $breakdown = [];
    $staffId = $staff->sno;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $dropoutCustomers)
      ->whereBetween('za_customer.created_at', [$startDateold, $endDateold])
      ->pluck('za_customer.sno')
      ->toArray();

    // HAC Amount
    $hacAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereIn('za_payment.customer_id', $prevMonthConvertedCustomers)
      ->where('za_payment.status', 1)
      ->whereYear('za_payment.initialPayDate', $year)
      ->whereMonth('za_payment.initialPayDate', $month)
      ->where('za_payment.branch_id', $branchId)
      ->sum('za_payment.paidAmount');

    // Actual Month Customer Post
    $actualMonthCustomerPost = CustomerModel::select('za_customer.course_id', 'za_customer.sno', 'za_training.sno As training_id')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_customer.branch_id', $branchId)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->whereIn('za_customer.status', [0, 6, 4])
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
    $isoutstandingRequired = $ten_x['no_of_outstanding_10x'] == "1";
    $isPostsaleRequired = $ten_x['no_of_post_sale_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Harvesting Amount";
    } elseif ($isoutstandingRequired) {
      $targetTenx = $goalsetData->student_count ?? 0;
      $actaulTenx = $goalsetData->student_count_actual ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Outstanding Count";
    } elseif ($isPostsaleRequired) {
      $targetTenx = $goalsetData->no_of_post_sale ?? 0;
      $actaulTenx = $actualMonthCustomerPost ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Post Sale Count";
    }

    // REI Calculation
    $targetREI = $goalsetData->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // EI Calculation
    $EIaward = 0;
    $EIStatus = false;
    $targetEI = 0;
    $actaulEI = 0;

    if ($isHacCostingRequired) {
      $targetTenx = optional($goalsetteam)->hac_over_all ?? 0;
      $actaulTenx = $hacAmount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;

      if ($tenxStatus && ($incentive->excess_incentive ?? 0) > 0) {
        $excessAmount = $actaulTenx - $targetTenx;
        if ($excessAmount > 0) {
          $targetEI = $incentive->excess_incentive . '%';
          $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
          $EIaward = $actaulEI;
          $EIStatus = true;
        }
      }
    }


        $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
        $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

        $breakdown['EI Award'] = ($tenxStatus && $EIStatus) ? ($EIaward ?? 0) : 0;
        $totalReward += ($tenxStatus && $EIStatus) ? ($EIaward ?? 0) : 0;

        $breakdown['RI Award'] =  $REIaward ?? 0;
        $totalReward += $REIaward ?? 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => round($actaulTenx,2),
        'target_ei' => $targetEI,
        'actual_ei' => round($actaulEI,1),
        'referrals' => $actaulREI,
      ]
    ];

    
  }


  private static function processCRE($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {

    $totalReward = 0;
    $breakdown = [];
    $staffId = $staff->sno;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Review Count
    $review_count = DB::table('za_review')
      ->where('branch_id', $branchId)
      ->where('created_by', $staffId)
      ->where('status', 0)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isNoOfReviewsRequired = $ten_x['no_of_reviews_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isNoOfReviewsRequired) {
      $targetTenx = $goalsetData->no_of_reviews ?? 0;
      $actaulTenx = $review_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
    $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

    $breakdown['RI Award'] =  $REIaward ?? 0;
    $totalReward += $REIaward ?? 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'referrals' => $actaulREI,
      ]
    ];
    
  }
  

   private static function processProduction($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {

        $totalReward = 0;
        $breakdown = [];
        $staffId = $staff->sno;

   

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;
    

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->sno],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();
          // return $batch;

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

      ;

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

   

    // PDI Slabs
    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
    $studentCount = $staffproduction->student_count ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;
        
    foreach ($slabs as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->where('branch_id', $branchId)
      ->where('referral_id', $staffId)
      ->where('status', 0)
      ->where('referral_type', 2)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->count();

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    
    $costing_amount_asign = $goalsetData[$staffId]->production_costing ?? 0;
   
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
     
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
    $isStudentMinRequired = $ten_x['min_no_of_students_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;
    $tenxTolltip = "10X Target";

    if ($isProductionCostingRequired) {
      $targetTenx = $goalsetData[$staffId]->production_costing ?? 0;
      $actaulTenx = round($costing_amount);
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Production Costing";
    } elseif ($isStudentMinRequired) {
      $targetTenx = $goalsetData[$staffId]->min_no_of_students ?? 0;
      $actaulTenx = $goalsetData[$staffId]->min_no_of_students_actual ?? $staffproduction->student_count;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Min No. of Students Handling";
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData[$staffId]->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
      $tenxTolltip = "Reference Sales Count";
    }

    // PDI
    $pdiReward = $slabPercentage;
    $pdiStatus = $tenxStatus && $pdiReward > 0;


    $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
        $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

        $breakdown['PDI Award'] =  $tenxStatus && $pdiReward ? round($pdiReward) : 0;
        $totalReward += $tenxStatus && $pdiReward ? round($pdiReward) : 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'slap_percentage' =>  round($slabPercentage, 1),
        'isProductionCostingRequired' => $isProductionCostingRequired,
        'isReferenceSalesRequired' => $isReferenceSalesRequired,
        'costing_amount' => $costing_amount ,
      ]
    ];
    
  }
 
  private static function processPC($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year, $current_date)
  {
        $totalReward = 0;
        $breakdown = [];
        $staffId = $staff->sno;

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Student Count
    $std_count = TrainingModel::where('za_training.status', 0)
      ->where('za_batch.status', 0)
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.staff_id', $staffId)
      ->where('za_batch.start_date', '<=', $current_date)
      ->where('za_batch.end_date', '>=', $current_date)
      ->count();

    // Initialize variables
    $slotType = $staff;
    $slotType->earned_amount = 0;
    $slotType->batch_count = 0;
    $slotType->student_count = 0;
    $slotType->present_count = 0;
    $slotType->course_count = 0;
    $slotType->slotDetails = [];
    $slotType->avg_amnt = 0;
    $slotType->salary = 0;

    // Fetch batch IDs
    $batchIds = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->distinct()
      ->pluck('batch_id')
      ->toArray();

    $slotType->batch_ids = (array) $batchIds;

    foreach ($slotType->batch_ids as $batchId) {
      $slotDetails = BatchModel::select('za_batch.slot_id', 'za_slot.start_time', 'za_slot.end_time', 'za_slot.slot_name')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->whereIn('za_batch.sno', TrainingModel::where('branch_id', $branchId)
          ->where('staff_id', $slotType->sno)
          ->where(function ($query) use ($month, $year) {
            $query->whereMonth('start_date', '<=', $month)
              ->whereYear('start_date', '<=', $year)
              ->whereMonth('end_date', '>=', $month)
              ->whereYear('end_date', '>=', $year);
          })
          ->pluck('batch_id'))
        ->where('za_batch.status', 0)
        ->get();

      $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());

      $batch = BatchModel::select('za_batch.*', 'za_slot.start_time', 'za_slot.end_time')
        ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->find($batchId);

      if ($batch) {
        $startTime = Carbon::parse($batch->start_time);
        $endTime = Carbon::parse($batch->end_time);
        $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;

        $attendanceRecords = AttendanceModel::select('per_hr_cost')
          ->where([
            ['batch_id', $batch->sno],
            ['staff_id', $slotType->sno],
            ['attendance', 'P']
          ])
          ->whereMonth('att_date', $month)
          ->whereYear('att_date', $year)
          ->get();

        foreach ($attendanceRecords as $attendance) {
          $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
        }
      }
    }

    // Student count
    $slotType->student_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('customer_id')
      ->count('customer_id');

    // Course count
    $slotType->course_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('course_id')
      ->count('course_id');

    // Batch count
    $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
      ->where('staff_id', $slotType->sno)
      ->where(function ($query) use ($month, $year) {
        $query->whereMonth('start_date', '<=', $month)
          ->whereYear('start_date', '<=', $year)
          ->whereMonth('end_date', '>=', $month)
          ->whereYear('end_date', '>=', $year);
      })
      ->distinct('batch_id')
      ->count('batch_id');

    // Salary
    $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
    $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;

    $staffproduction = $slotType;
    $costing_amount = $staffproduction->earned_amount ?? 0;

    // Costing Calculation
    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
    $costing_amount_asign = $goalsetData->production_costing ?? 0;
    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
    $costing_amount = $costing_amount2;

    // Ten X Settings
    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
    $isReferenceSalesRequired = $ten_x['reference_sales_10x'] == "1";

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isProductionCostingRequired) {
      $targetTenx = $costing_amount_asign ?? 0;
      $actaulTenx = $costing_amount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    } elseif ($isReferenceSalesRequired) {
      $targetTenx = $goalsetData->reference_sales ?? 0;
      $actaulTenx = $refferal_count ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

        $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
        $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

        $breakdown['RI Award'] =  $REIStatus ? ($REIaward) : 0;
        $totalReward += $REIStatus ? ($REIaward) : 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'referrals' => $actaulREI,
      ]
    ];
  }

  private static function processPlacementEx($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
        $totalReward = 0;
        $breakdown = [];
        $staffId = $staff->sno;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIE Slab
    $pie_slab_json = json_decode($incentive->pie_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pie_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // OIE Slab
    $oie_slab_json = json_decode($incentive->oie_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oie_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
    $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

    $breakdown['PDI Award'] = $tenxStatus && $pdiReward ? round($pdiReward) : 0;
    $totalReward += $tenxStatus && $pdiReward ? round($pdiReward) : 0;

    $breakdown['RI Award'] =  $REIaward ?? 0;
    $totalReward += $REIaward ?? 0;

    $breakdown['Other Award'] =  $tenxStatus && $OthersReward ? round($OthersReward) : 0;
    $totalReward += $tenxStatus && $OthersReward ? round($OthersReward) : 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'pdi_percentage' => round($piPercentage, 1),
        'other_percentage' => round($piPercentageOi, 1),
        'referrals' => $actaulREI,
      ]
    ];
  }
 
  private static function processPlacementLead($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year)
  {
        $totalReward = 0;
        $breakdown = [];
        $staffId = $staff->sno;

    // Tesbo Count
    $tesboCount = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Others Slab
    $othersSlab = DB::table('za_placement_interview')
      ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
      ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_placement_interview.branch_id', $branchId)
      ->where('za_placement_interview.created_by', $staffId)
      ->where('za_placement_interview.status', 4)
      ->whereYear('za_placement_interview.selected_date', $year)
      ->whereMonth('za_placement_interview.selected_date', $month)
      ->distinct()
      ->count('za_placement_interview.customer_id');

    // Referral Count
    $refferal_count = DB::table('za_referral_persons')
      ->join('za_customer', 'za_customer.sno', '=', 'za_referral_persons.customer_id')
      ->where('za_referral_persons.branch_id', $branchId)
      ->where('za_referral_persons.referral_id', $staffId)
      ->where('za_referral_persons.status', 0)
      ->where('za_referral_persons.referral_type', 2)
      ->where('za_customer.post_sale_check', 1)
      ->whereYear('za_referral_persons.created_at', $year)
      ->whereMonth('za_referral_persons.created_at', $month)
      ->count();

    // Ten X Settings
    $isnoOfplacementsCheckRequired = $goalsetteam->no_of_placements_check == 1;

    $tenxStatus = false;
    $targetTenx = 0;
    $actaulTenx = 0;

    if ($isnoOfplacementsCheckRequired) {
      $targetTenx = $goalsetData->no_of_placements ?? 0;
      $actaulTenx = $tesboCount ?? 0;
      $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
    }

    // REI Calculation
    $targetREI = $goalsetData->reference_sales ?? 0;
    $actaulREI = $refferal_count ?? 0;
    $REIStatus = $targetREI != 0 ? $actaulREI >= $targetREI : false;
    $REIaward = $actaulREI * ($incentive->reference_incentive ?? 0);

    // PIL Slab
    $pil_slab_json = json_decode($incentive->pil_slab_json ?? '[]', true);
    $studentCount = $tesboCount ?? 0;

    $matchedSlab = null;
    $slabPercentage = 0;

    foreach ($pil_slab_json as $slab) {
      if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
        $matchedSlab = $slab['min'] . '-' . $slab['max'];
        $slabPercentage = $slab['percentage'];
        break;
      }
    }

    // Double X Slab
    $double_x_slab_json = json_decode($incentive->double_x_slab_json ?? '[]', true);
    $matchedX = null;
    $slabPercentageX = 0;
    $DoubleReward = 0;

    $multiplier = $targetTenx > 0 ? floor($tesboCount / $targetTenx) : 0;

    foreach ($double_x_slab_json as $slab) {
      if ($multiplier >= $slab['min'] && $multiplier <= $slab['max']) {
        if ($multiplier == 2) {
          $matchedX = 'Double X';
        } elseif ($multiplier == 3) {
          $matchedX = 'Triple X';
        } else {
          $matchedX = $multiplier . 'X';
        }
        $slabPercentageX = $slab['percentage'];
        $DoubleReward = $slabPercentageX;
        break;
      }
    }

    // OIL Slab
    $oil_slab_json = json_decode($incentive->oil_slab_json ?? '[]', true);
    $studentCountothers = $othersSlab ?? 0;

    $matchedSlabOi = null;
    $slabPercentageOi = 0;

    foreach ($oil_slab_json as $slab) {
      if ($studentCountothers >= $slab['min'] && $studentCountothers <= $slab['max']) {
        $matchedSlabOi = $slab['min'] . '-' . $slab['max'];
        $slabPercentageOi = $slab['percentage'];
        break;
      }
    }

    $piPercentage = $slabPercentage;
    $piPercentageOi = $slabPercentageOi;

    $pdiReward = $piPercentage;
    $OthersReward = $piPercentageOi;

    $pdiStatus = $tenxStatus && $pdiReward > 0;
    $DoubleStatus = $tenxStatus && $DoubleReward > 0;
    $otherStatus = $tenxStatus && $OthersReward > 0;

    $breakdown['10X Award'] = $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;
    $totalReward += $tenxStatus ? ($incentive->tenx_award ?? 0) : 0;

    $breakdown['PDI Award'] = $tenxStatus && $pdiReward ? round($pdiReward) : 0;
    $totalReward += $tenxStatus && $pdiReward ? round($pdiReward) : 0;

    $breakdown['RI Award'] =  $REIaward ?? 0;
    $totalReward += $REIaward ?? 0;

    $breakdown['2X Award'] =  $tenxStatus && $DoubleReward ? round($DoubleReward) : 0;
    $totalReward += $tenxStatus && $DoubleReward ? round($DoubleReward) : 0;

    $breakdown['Other Award'] =  $tenxStatus && $OthersReward ? round($OthersReward) : 0;
    $totalReward += $tenxStatus && $OthersReward ? round($OthersReward) : 0;


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target' => $targetTenx,
        'actual' => $actaulTenx,
        'pdi_percentage' => round($piPercentage, 1),
        '2x_percentage' => round($slabPercentageX, 1),
        'other_percentage' => round($piPercentageOi, 1),
        'referrals' => $actaulREI,
      ]
    ];
  }


  private static function processBDM($staff, $incentive, $goalsetteam, $goalsetData, $branchId, $month, $year, $startDate, $endDate, $startDateold, $endDateold, $prevMonth, $prevYear, $dates, $startOfMonth, $endOfMonth)
  {

    $totalReward = 0;
    $breakdown = [];
    $staffId = $staff->sno;

    // Targets
    $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
      ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
      ->whereMonth('branch_target.date', $month)
      ->whereYear('branch_target.date', $year)
      ->select('branch_target.*')
      ->first();

    $pregoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $postgoalsetteam = GoalSetTeamModel::where('za_goal_set_team.department_id', 1)
      ->where('za_goal_set_team.branch_id', $branchId)
      ->where('za_goal_set_team.team_goal_month', $month)
      ->where('za_goal_set_team.team_goal_year', $year)
      ->first();

    $financialYear = (int)$year;
    if ($month >= 1 && $month <= 3) {
      $financialYear = $financialYear - 1;
    }

    $fyStart = Carbon::create($financialYear, 4, 1)->startOfDay();
    $fyEnd = Carbon::create($financialYear + 1, 3, 31)->endOfDay();

    $yearlyTargets = ManageTargetModel::query()
      ->where('branch_target.branch_id', $branchId)
      ->whereBetween('branch_target.date', [$fyStart, $fyEnd])
      ->selectRaw("
            SUM(no_of_registrations) as total_pre_target,
            SUM(post_sale) as total_post_target
        ")
      ->first();

    $yearlyPreTarget = (int) ($yearlyTargets->total_pre_target ?? 0);
    $yearlyPostTarget = (int) ($yearlyTargets->total_post_target ?? 0);

    $target_collection = $targets->monthly_target ?? 0;
    $target_pre = $targets->no_of_registrations ?? 0;
    $target_post = $targets->post_sale ?? 0;
    $targetPreABV = $pregoalsetteam ? $pregoalsetteam->abv_over_all : 0;
    $targetPreACV = $pregoalsetteam ? $pregoalsetteam->acv_over_all : 0;
    $targetPostABV = $postgoalsetteam ? $postgoalsetteam->abv_over_all : 0;
    $targetPostACV = $postgoalsetteam ? $postgoalsetteam->acv_over_all : 0;

    // Total Credit
    $totalCredit = TransactionModel::where('branch_id', $branchId)
      ->whereBetween('transaction_date', [$startDate, $endDate])
      ->sum('credit');

    // Previous Month Converted Customers
    $prevMonthConvertedCustomers = CustomerModel::select('za_customer.sno')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staffId)
      ->whereYear('za_customer.created_at', $prevYear)
      ->whereMonth('za_customer.created_at', $prevMonth)
      ->pluck('za_customer.sno')
      ->toArray();

    // Dropout Customers
    $dropoutCustomers = DB::table('za_training')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 2)
      ->pluck('customer_id')
      ->toArray();

    // Fully Paid Customers
    $fullPaidCustomerIds = DB::table('za_payment')
      ->select('customer_id')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->groupBy('customer_id')
      ->havingRaw('SUM(paidAmount) = MAX(total_amount)')
      ->pluck('customer_id')
      ->toArray();

    // Second Payment Customers
    $secondPaymentCustomersmulti = DB::table('za_payment')
      ->whereIn('customer_id', $prevMonthConvertedCustomers)
      ->where('status', 1)
      ->whereMonth('nextPayDate', $month)
      ->whereYear('nextPayDate', $year)
      ->pluck('customer_id')
      ->unique()
      ->values()
      ->toArray();

    $secondPaymentCustomers = array_values(array_unique(array_merge(
      $secondPaymentCustomersmulti,
      $fullPaidCustomerIds
    )));

    // Branch
    $branch = BranchModel::where('sno', $branchId)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    // Drop Refund
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');

    // Paid Under Payment
    $PaidUnderPayment = DB::table('za_training')
      ->whereIn('za_training.customer_id', $prevMonthConvertedCustomers)
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->select(
        'za_customer.customer_id',
        'za_payment.course_id',
        'za_customer.sno as customer_sno',
        'za_course.sno as course_sno',
        'za_customer.cus_name',
        'za_customer.cus_gender',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_staff.staff_name',
        'za_training.training_id',
        'za_training.batch_id',
        'za_training.payment_id',
        'za_payment.initialPayDate',
        'za_training.paid_amount as total_paid_amount',
        'za_training.balance_amount as total_balance_fee',
        'za_training.overall_fees as total_amount',
        DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate'
      )
      ->where('za_payment.branch_id', $branchId)
      ->whereNotIn('za_customer.sno', $drop_ids)
      ->where('za_training.status', '!=', 2)
      ->where('za_training.balance_amount', '!=', 0)
      ->groupBy(
        'za_customer.customer_id',
        'za_customer.sno',
        'za_course.sno',
        'za_customer.cus_name',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.cus_email_id',
        'za_course.course_name',
        'za_training.training_id',
        'za_training.payment_id',
        'za_staff.staff_name',
        'za_training.batch_id',
        'za_training.paid_amount',
        'za_training.balance_amount',
        'za_training.overall_fees',
        'za_payment.payment_mode_label',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.course_id'
      )
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get()
      ->unique('payment_id');

    $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
      return $payment->total_paid_amount < $branch->min_prd_cost;
    });

    $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
      $filteredPayments = $payments->filter(function ($payment) {
        return $payment->total_paid_amount > 0;
      });

      if ($filteredPayments->isEmpty()) {
        return null;
      }

      $payment = $payments->first();
      return [
        'customer_name' => $payment->cus_name,
        'customer_sno' => $payment->customer_sno,
        'total_paid' => $payment->total_paid_amount,
        'min_required' => $branch->min_prd_cost,
        'status' => 'Pending',
        'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
          return [
            'course_name' => $payment->course_name,
            'cus_gender' => $payment->cus_gender,
            'cus_pic' => $payment->cus_pic,
            'staff_name' => $payment->staff_name,
            'batch_id' => $payment->batch_id,
            'training_id' => $payment->training_id,
            'payment_id' => $payment->payment_id,
            'cus_name' => $payment->cus_name,
            'cus_mobile' => $payment->cus_mobile,
            'amount' => $payment->total_amount,
            'paidAmount' => $payment->total_paid_amount,
            'balanceFee' => $payment->total_balance_fee,
            'gst_amount' => $payment->total_gst_amount,
            'nextPayDate' => $payment->nextPayDate,
            'initialPayDate' => $payment->initialPayDate,
            'payment_mode_label' => $payment->payment_mode_label,
          ];
        })->values(),
      ];
    })->filter();

    $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();

    $badCustomerIds = array_unique(array_merge(
      $dropoutCustomers,
      $lowMbcCustomerIds,
      array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
    ));

    // Presale Count
    $presaleCount = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->count();

    // Post Sale Count
    $postSaleCount = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->count('za_training.sno');

    // Presale Customers
    $presaleCustomers = CustomerModel::whereIn('status', [0, 6])
      ->where('post_sale_check', '!=', 1)
      ->where('branch_id', $branchId)
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->pluck('customer_id')
      ->toArray();

    // Postsale Customers
    $postsaleCustomers = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_training.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->distinct('za_training.customer_id')
      ->pluck('za_training.sno')
      ->toArray();

    // ECI Counts
    $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.post_sale_check', '!=', 1)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->whereDay('za_customer.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->count();

    $eciCustomerConvertCountPost = DB::table('za_customer')
      ->select('za_customer.sno', 'za_customer.proposal_ids', 'za_customer.cus_name')
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.status', 0)
      ->where('za_customer.post_sale_check', 1)
      ->where('za_training.post_sale_check', 1)
      ->where('za_customer.branch_id', $branchId)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->whereNotIn('za_training.status', [0, 1, 2])
      ->where('za_training.status', 0)
      ->orderBy('za_training.sno', 'asc')
      ->whereDay('za_training.created_at', '<=', 15)
      ->whereNotIn('za_customer.sno', $badCustomerIds)
      ->distinct('za_customer.sno')
      ->count();

    // Team Targets
    $teamTargets = GoalSetStaffModel::where('za_goal_set_staff.branch_id', $branchId)
      ->join('za_staff', 'za_staff.sno', '=', 'za_goal_set_staff.staff_id')
      ->whereIn('za_staff.role_id', [11])
      ->where('za_staff.status', 0)
      ->whereMonth('za_goal_set_staff.goal_date', $month)
      ->whereYear('za_goal_set_staff.goal_date', $year)
      ->select(
        'za_goal_set_staff.staff_id',
        'za_goal_set_staff.conversion',
        'za_staff.role_id',
        'za_staff.staff_name'
      )
      ->distinct('za_staff.sno')
      ->get();

    // Pre and Post Actuals
    $preActuals = CustomerModel::where('branch_id', $branchId)
      ->whereIn('status', [0, 6])
      ->whereYear('created_at', $year)
      ->whereMonth('created_at', $month)
      ->whereNotIn('sno', $badCustomerIds)
      ->groupBy('lead_id')
      ->select('lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    $postActuals = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereYear('za_training.created_at', $year)
      ->whereMonth('za_training.created_at', $month)
      ->groupBy('za_customer.lead_id')
      ->select('za_customer.lead_id', DB::raw('count(*) as total'))
      ->pluck('total', 'lead_id')
      ->toArray();

    // Yearly Pre Actual
    $yearlyPreActualOriginal = CustomerModel::select('za_customer.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->join('za_transaction', 'za_transaction.trans_source_id', '=', 'za_customer.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereBetween('za_transaction.transaction_date', [$fyStart, $fyEnd])
      ->orderBy('za_customer.sno', 'asc')
      ->count();

    $lowMbcCustomerIdsYear = $badCustomerIds;
    $badCustomerIdsYear = array_unique($lowMbcCustomerIdsYear);
    $yearlyPreActual = max(0, $yearlyPreActualOriginal - count($badCustomerIdsYear));

    // Yearly Post Actual
    $yearlyPostActualOriginal = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.branch_id', $branchId)
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_training.post_sale_check', 1)
      ->whereBetween('za_training.created_at', [$fyStart, $fyEnd])
      ->count();

    $yearlyPostActual = max(0, $yearlyPostActualOriginal - count($badCustomerIdsYear));

    // Yearly Achievements
    $yearlyPreAchievement = 0;
    if ($yearlyPreTarget > 0) {
      $yearlyPreAchievement = round(($yearlyPreActual / $yearlyPreTarget) * 100, 1);
    }

    $yearlyPostAchievement = 0;
    if ($yearlyPostTarget > 0) {
      $yearlyPostAchievement = round(($yearlyPostActual / $yearlyPostTarget) * 100, 1);
    }

    // Team Breakdown
    $teamTotalMembers = 0;
    $teamAchievedMembers = 0;
    $teamBreakdown = [];
    $preTotal = 0;
    $preAchieved = 0;

    foreach ($teamTargets as $target) {
      $teamTotalMembers++;
      $actual = 0;

      if ($target->role_id == 11) {
        $actual = $preActuals[$target->staff_id] ?? 0;
      }

      if ($target->role_id == 35) {
        $actual = $postActuals[$target->staff_id] ?? 0;
      }

      $achieved = $target->conversion > 0 && $actual >= $target->conversion;

      if ($achieved) {
        $teamAchievedMembers++;
        if ($target->role_id == 11) {
          $preAchieved++;
        }
      }

      if ($target->role_id == 11) {
        $preTotal++;
      }

      $teamBreakdown[] = [
        'staff_name' => $target->staff_name,
        'role_id' => $target->role_id,
        'target' => $target->conversion,
        'actual' => $actual,
        'status' => $achieved,
      ];
    }

    $teamAchievementStatus = $teamTotalMembers > 0 && $teamAchievedMembers === $teamTotalMembers;
    $teamAchievementReward = $teamAchievementStatus ? ($incentive->team_target ?? 0) : 0;

    // TenX Monthly Status
    $fyStartYear = $financialYear;
    $currentMonth = now()->month;
    $currentYear = now()->year;
    $achievedMonths = 0;
    $monthIcons = '';

    for ($i = 0; $i < 12; $i++) {
      $date = Carbon::create($fyStartYear, 4, 1)->addMonths($i);
      $m = $date->month;
      $y = $date->year;
      $label = $date->format('M');

      if ($y > $currentYear || ($y == $currentYear && $m > $currentMonth)) {
        $status = 'upcoming';
      } elseif ($y == $currentYear && $m == $currentMonth) {
        $status = 'progress';
      } else {
        $actualPre = CustomerModel::whereIn('status', [0, 6])
          ->where('post_sale_check', '!=', 1)
          ->where('branch_id', $branchId)
          ->whereYear('created_at', $y)
          ->whereMonth('created_at', $m)
          ->whereNotIn('sno', $badCustomerIds)
          ->count();

        if ($target_pre > 0 && $target_post > 0 && $actualPre >= $target_pre) {
          $status = 'achieved';
          $achievedMonths++;
        } else {
          $status = 'failed';
        }
      }

      $icon = '';
      switch ($status) {
        case 'achieved':
          $icon = '<div class="text-center"><span class="badge bg-label-success rounded"><i class="mdi mdi-check-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'failed':
          $icon = '<div class="text-center"><span class="badge bg-label-danger rounded"><i class="mdi mdi-close-circle fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        case 'progress':
          $icon = '<div class="text-center"><span class="badge bg-label-info rounded"><i class="mdi mdi-timer-sand fs-7"></i></span><div>' . $label . '</div></div>';
          break;
        default:
          $icon = '<div class="text-center"><span class="badge bg-label-secondary rounded"><i class="mdi mdi-clock-outline fs-7"></i></span><div>' . $label . '</div></div>';
      }
      $monthIcons .= $icon;
    }

    $nineMonthStatus = $achievedMonths >= 9;
    $nineMonthReward = $incentive->nine_monthadd ?? '-';

    // Actual ABV and ACV Calculations
    $actualABV = 0;
    $actualACV = 0;
    $actualABVPost = 0;
    $actualACVPost = 0;

    if (!empty($presaleCustomers)) {
      $presaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_customer.customer_id', $presaleCustomers)
        ->whereNotIn('za_customer.sno', $badCustomerIds)
        ->sum('za_training.overall_fees');

      $presaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('trans_source_id', $presaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABV = ($presaleCount > 0) ? $presaleTotalOverallFees / $presaleCount : 0;
      $actualACV = ($presaleCount > 0) ? $presaleTotalCredit / $presaleCount : 0;
    }

    if (!empty($postsaleCustomers)) {
      $postsaleTotalOverallFees = CustomerModel::join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
        ->whereIn('za_training.sno', $postsaleCustomers)
        ->sum('za_training.overall_fees');

      $postsaleTotalCredit = TransactionModel::where('branch_id', $branchId)
        ->whereIn('training_id', $postsaleCustomers)
        ->whereBetween('transaction_date', [$startDate, $endDate])
        ->sum('credit');

      $actualABVPost = ($postSaleCount > 0) ? $postsaleTotalOverallFees / $postSaleCount : 0;
      $actualACVPost = ($postSaleCount > 0) ? $postsaleTotalCredit / $postSaleCount : 0;
    }

    // TenX Status
    $tenxStatus = (
      $target_collection > 0 && $target_pre > 0 && $target_post > 0 &&
      $targetPreABV > 0 && $targetPreACV > 0 && $targetPostABV > 0 && $targetPostACV > 0 &&
      $totalCredit >= $target_collection &&
      $presaleCount >= $target_pre &&
      $postSaleCount >= $target_post &&
      $actualABV >= $targetPreABV &&
      $actualACV >= $targetPreACV &&
      $actualABVPost >= $targetPostABV &&
      $actualACVPost >= $targetPostACV
    );

    // ECI Logic
    $totalTarget = ($target_pre ?? 0) + ($target_post ?? 0);
    $totalConversion15 = ($eciCustomerConvertCount ?? 0) + ($eciCustomerConvertCountPost ?? 0);
    $eciAchievement15 = 0;
    if ($totalTarget > 0) {
      $eciAchievement15 = round(($totalConversion15 / $totalTarget) * 100, 1);
    }

    $slabs = json_decode($incentive->closing_slab_json ?? '[]', true);
    $eciStatus = false;
    $eciReward = 0;
    $eciRewardType = '';

    if (!empty($slabs)) {
      usort($slabs, function ($a, $b) {
        return $b['max'] <=> $a['max'];
      });

      foreach ($slabs as $slab) {
        if ($eciAchievement15 >= $slab['min'] && $eciAchievement15 <= $slab['max']) {
          $eciStatus = true;
          $eciReward = $slab['percentage'];
          $eciRewardType = $slab['max'] . 'th Achievement';
          break;
        }
      }
    }

    // BI
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCountPre = max(0, $presaleCount - $target_pre);
    $biRewardPre = $biAchievedCountPre * $biPerConversion;
    $biAchievedCountPost = max(0, $postSaleCount - $target_post);
    $biRewardPost = $biAchievedCountPost * $biPerConversion;
    $biReward = $biRewardPre + $biRewardPost;
    $biStatus = ($biAchievedCountPre > 0 || $biAchievedCountPost > 0);

    // Double X
    $doublexTargetPre = ($target_pre * 2);
    $doublexTargetPost = ($target_post * 2);
    $doubleXStatus = (
      $doublexTargetPre > 0 && $doublexTargetPost > 0 &&
      $presaleCount >= $doublexTargetPre &&
      $postSaleCount >= $doublexTargetPost
    );
    $doubleXReward = $incentive->double_x_reward ?? 0;

    // ABV 150%
    $preABVAchievement = 0;
    if (($targetPreABV ?? 0) > 0) {
      $preABVAchievement = round((($actualABV ?? 0) / $targetPreABV) * 100, 1);
    }

    $postABVAchievement = 0;
    if (($targetPostABV ?? 0) > 0) {
      $postABVAchievement = round((($actualABVPost ?? 0) / $targetPostABV) * 100, 1);
    }

    $abvStatus = $preABVAchievement >= 150 && $postABVAchievement >= 150;
    $abvReward = ($tenxStatus && $abvStatus) ? ($incentive->abv_incentive ?? 0) : 0;

    // Yearly 150%
    $yearly150Status = $yearlyPreAchievement >= 150 && $yearlyPostAchievement >= 150;
    $yearly150Reward = $yearly150Status ? ($incentive->yearly_count ?? 0) : 0;


            // 10x Reward
            if ($tenxStatus) {
                $tenxReward = $incentive->tenx_award ?? 0;
                $totalReward += $tenxReward;
                $breakdown['10X Award'] = $tenxReward;
            }else{
                $tenxReward =  0;
                $totalReward += $tenxReward;
                $breakdown['10X Award'] = $tenxReward;
            }

            // ABV Incentive Reward
            if ($tenxStatus && $abvAchivedStatus) {
                $abvAchivedReward = $abvAchivedReward ?? 0;
                $totalReward += $abvAchivedReward;
                $breakdown['ABV Award'] = $abvAchivedReward;
            }else{
                $abvAchivedReward =  0;
                $totalReward += $abvAchivedReward;
                $breakdown['ABV Award'] = $abvAchivedReward;
            }

            // Team 10x Incentive Reward
            if ($tenxStatus && $teamAchievementStatus) {
                $teamAchievementReward = $teamAchievementReward ?? 0;
                $totalReward += $teamAchievementReward;
                $breakdown['Team 10X Award'] = $teamAchievementReward;
            }else{
                $teamAchievementReward =  0;
                $totalReward += $teamAchievementReward;
                $breakdown['Team 10X Award'] = $teamAchievementReward;
            }

            // ECI Incentive Reward
            if ($tenxStatus && $eciStatus) {
                $eciReward = $eciReward ?? 0;
                $totalReward += $eciReward;
                $breakdown['ECI Award'] = $eciReward;
            }else{
                $eciReward =  0;
                $totalReward += $eciReward;
                $breakdown['ECI Award'] = $eciReward;
            }

            // BI Incentive Reward
            if ($tenxStatus && $biStatus) {
                $biReward = $biReward ?? 0;
                $totalReward += $biReward;
                $breakdown['BI Award'] = $biReward;
            }else{
                $biReward =  0;
                $totalReward += $biReward;
                $breakdown['BI Award'] = $biReward;
            }
            // 2x Incentive Reward
            if ($tenxStatus && $doubleXStatus) {
                $doubleXReward = $doubleXReward ?? 0;
                $totalReward += $doubleXReward;
                $breakdown['2X Award'] = $doubleXReward;
            }else{
                $doubleXReward =  0;
                $totalReward += $doubleXReward;
                $breakdown['2X Award'] = $doubleXReward;
            }

            // ABV 150% Incentive Reward
            if ($tenxStatus && $abvStatus) {
                $abvReward = $abvReward ?? 0;
                $totalReward += $abvReward;
                $breakdown['ABV 150% Award'] = $abvReward;
            }else{
                $abvReward =  0;
                $totalReward += $abvReward;
                $breakdown['ABV 150% Award'] = $abvReward;
            }

            // Yearly 150% Incentive Reward
            if ($tenxStatus && $yearly150Reward) {
                $yearly150Reward = $yearly150Reward ?? 0;
                $totalReward += $yearly150Reward;
                $breakdown['Yearly 150% Award'] = $yearly150Reward;
            }else{
                $yearly150Reward =  0;
                $totalReward += $yearly150Reward;
                $breakdown['Yearly 150% Award'] = $yearly150Reward;
            }
            // Yearly 150% Incentive Reward
            if ($tenxStatus && $nineMonthStatus) {
                $nineMonthReward = $nineMonthReward ?? '-';
                $totalReward += $nineMonthReward;
                $breakdown['9 Month Award'] = $nineMonthReward;
            }else{
                $nineMonthReward =  0;
                $totalReward += $nineMonthReward;
                $breakdown['9 Month Award'] = $nineMonthReward;
            }

    


    return [
      'total' => $totalReward,
      'breakdown' => $breakdown,
      'metrics' => [
        'target_pre' => $target_pre,
        'actual_pre' => $actualConversion,
        'target_post' => $target_post,
        'actual_post' => $actualConversionPost,
        
        'target_pre_abv' => $targetPreABV,
        'actual_pre_abv' => $actualABV,

        'target_pre_acv' => $targetPreACV,
        'actual_pre_acv' => $actualACV,

        'target_post_abv' => $targetPostABV,
        'actual_post_abv' => $actualABVPost,

        'target_post_acv' => $targetPostACV,
        'actual_post_acv' => $actualACVPost,

        'team_pre_target' => $preTotal,
        'team_pre_actual' => $preAchieved,

        'team_post_target' => $postTotal,
        'team_post_actual' => $postAchieved,
        'abv_150_pre' => $preABVAchievement,
        'abv_150_post' => $postABVAchievement,
        'yearly_150_acheived_pre' => $yearlyPreAchievement,
        'yearly_150_acheived_pre' => $yearlyPreAchievement,
        'yearly_150_acheived_post' => $yearlyPostAchievement,
        'nine_month_acheived' => $achievedMonths,
      ]
    ];

   
  }

  private static function getEmptyResponse()
  {
    return [
      'total_award' => 0,
      'breakdown' => [],
      'metrics' => [],
      'currency' => 'INR',
      'last_updated' => now()->toDateTimeString(),
      'next_update' => now()->addHours(2)->toDateTimeString(),
      'error' => 'No incentive configuration found'
    ];
  }
  
   public function AddTransferStaff(Request $request)
    {
 
        // Generate or get UUID
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                // Retrieve the payload and decode it
            $payload = $request->all();
                    // Check if the payload contains a JSON-encoded string (as your logs suggest)
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }
 
            // Log the decoded payload
            \Log::info('Decoded Payload:', $payload);
 
            // Validate payload
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
 
       
            // Check if mobile number exists
            if (empty($payload['mobile_no'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Mobile number is missing'
                ], 400);
            }
            $existingExternalStaff = StaffModel::where('external_uuid', $uuid)->first();
 
                if ($existingExternalStaff) {
                    $existingExternalStaff->status = 0;
                    $existingExternalStaff->update();
                    return response()->json([
                        'ok' => true,
                        'message' => 'Staff Rejoin Successfully'
                    ], 200);
                }
 
            // Check if mobile number already exists
            $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
            if ($existingStaff) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Mobile Number already exists'
                ], 200);
            }
 
            // Handle staff image upload (if any)
            $staff_image_url = $payload['staff_image'] ?? null;
            $staff_image = null;
 
            if ($staff_image_url) {
                $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                $folderPath = public_path("staff_images");
 
                // Create directory if it doesn't exist
                if (!File::exists($folderPath)) {
                    File::makeDirectory($folderPath, 0777, true, true);
                }
 
                // Find the next available image number
                $existingFiles = File::files($folderPath);
                $maxNumber = 0;
                foreach ($existingFiles as $file) {
                    if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                        $num = (int) $matches[1];
                        if ($num > $maxNumber) $maxNumber = $num;
                    }
                }
                $nextNumber = $maxNumber + 1;
                $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                $savePath = $folderPath . '/' . $staff_image_name;
 
                // Save image
                try {
                    $imageData = @file_get_contents($staff_image_url);
                    if ($imageData !== false) {
                        file_put_contents($savePath, $imageData);
                        $staff_image = $staff_image_name;
                    }
                } catch (\Exception $e) {
                    $staff_image = null;
                }
            }
 
        // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 6,
                    'branch_franchise' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => is_array($payload['contact_person_name'] ?? null)
                                    ? json_encode($payload['contact_person_name'])
                                    : ($payload['contact_person_name'] ?? null),
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])
                                ? json_encode($payload['attachment'])
                                : '[]',
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );
        if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }
            }
 
        return response()->json([
            'ok' => true,
            'sno' => $add_staff->sno,
        ], 200);
    }
    
     private static function getTeamIncentiveStatus(array $executiveIds, array $allExecutiveIncentives): array
  {
    $finalStatus = [
      'tenx_award' => true,
      'eci' => true,
      'bi' => true,
      'si' => true,
      'pi' => true,
      'sp' => true,
    ];

    foreach ($executiveIds as $execId) {
      $key = 'staff_' . $execId;

      if (!isset($allExecutiveIncentives[$key])) {
        // If data missing, fail all
        foreach ($finalStatus as $type => $_) {
          $finalStatus[$type] = false;
        }
        continue;
      }

      $incentiveSet = $allExecutiveIncentives[$key]['incentives'] ?? [];

      foreach ($finalStatus as $type => $_) {
        // If not true, then mark team as not fully achieved
        if (!isset($incentiveSet[$type]['status']) || $incentiveSet[$type]['status'] !== true) {
          $finalStatus[$type] = false;
        }
      }
    }

    return $finalStatus;
  }

   private static function calculateIncentivesForStaff($staff, $branchId, $month, $year, $goalsetData)
  {
    $finalStatus = [
      'tenx_award' => true,
      'eci' => true,
      'bi' => true,
      'si' => true,
      'pi' => true,
      'sp' => true,
    ];

    // Get the first and last date of the requested month
    $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

    // Generate all dates in the month
    $dates = [];
    $currentDate = $startDate->copy();
    while ($currentDate->lte($endDate)) {
      $dates[] = $currentDate->toDateString();
      $currentDate->addDay();
    }

    // Directly use startDate and endDate for formatting
    $startOfMonth = $startDate->format('Y-m-d');
    $endOfMonth = $endDate->format('Y-m-d');
    // $finalStatus  = [];

    // foreach ($staff as $staff) {

    $current_date = date('Y-m-d'); // Define the current date
    //Sales Team

    $allLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staff->sno)
      ->where('za_lead.branch_id', $branchId)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
      ->where('za_lead.created_by', $staff->sno)
      ->where('za_lead.branch_id', $branchId)
      ->whereYear('za_lead.registered_date', $year)
      ->whereMonth('za_lead.registered_date', $month)
      ->whereNotIn('za_lead.status', [2, 6])
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->where('za_lead.internal_status', 0)
      ->count();

    $customerConvertCount = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])
      ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereYear('za_customer.created_at', $year)
      ->whereMonth('za_customer.created_at', $month)
      ->count();

    $monthcall_out = DB::table('za_call_tracker')
      ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
      ->whereYear('call_start_date', $year)
      ->whereMonth('call_start_date', $month)
      ->where('za_call_tracker.branch_id', $branchId)
      ->where('za_call_tracker.branch_staff_id', $staff->staff_id)
      ->first();
    $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;


    // customer ratio
    $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
    $convertion_rate = number_format($convertion_rate, 2);

    //acr
    $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
    $averager_convertion_rate = number_format($averager_convertion_rate, 2);

    $incentive = IncentiveModel::where('role_id', 11)
      ->where('branch_id', $branchId)
      ->where('status', 0)
      ->first();

    if (!$incentive) {
      return []; // or return null or false based on your method return type
    }

    $luxury = json_decode($incentive->luxury_incentive, true);
    $pi_slabs = json_decode($incentive->pi_slab_json, true);

    $currentMonthCustomerCount = 0;
    $total_business_amount     = 0;
    $total_payment             = 0;
    $total_paid_payment        = 0;
    $averageBusinessValue      = 0;
    $averageCollectionValue    = 0;
    $crashCount = 0;
    $professionCount = 0;
    $tesboCount = 0;
    $courseTypeTotal = 0;
    $eciCustomerConvertCount = 0;
    $eciActualPercentage = 0;
    $eciTargetPercentage = $incentive->eci_count ?? 0;
    $eciStatus = false;

    $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
    $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
    $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;
    $crashTarget = 0;
    $professionTarget = 0;
    $tesboTarget = 0;
    $crashPercent = 0;
    $professionPercent = 0;
    $tesboPercent = 0;
    $piPercentage = 0;
    $originalAmount = 0;
    $piReward = 0;
    $matchedSlab = null;
    $slabPercentage = 0;

    // Total Professional and Crash courses
    $groupedData = DB::table('za_training')
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->select(
        'za_course.course_type_id',
        DB::raw('COUNT(DISTINCT za_training.payment_id) AS total_trainings')
      )
      ->where('za_training.branch_id', $branchId)
      ->whereMonth('za_training.created_at', $month)
      ->whereYear('za_training.created_at', $year)
      ->whereIn('za_course.course_type_id', [3, 4])
      ->where('za_training.tesbo_check', '!=', 2)
      ->where('za_training.post_sale_check', '!=', 1)
      ->groupBy('za_course.course_type_id')
      ->get();

    // Get valid TESBO count separately
    $teshobo_coures_total = DB::table('za_training')
      ->where('branch_id', $branchId)
      ->whereMonth('created_at', $month)
      ->whereYear('created_at', $year)
      ->where('tesbo_check', 2)
      ->where('post_sale_check', '!=', 1)
      ->distinct('payment_id')
      ->count('payment_id');

    // Prepare tree output
    $crash_coures_total = 0;
    $professinal_coures_total = 0;

    foreach ($groupedData as $row) {
      if ($row->course_type_id == 3) {
        $professinal_coures_total = (int) $row->total_trainings;
      } elseif ($row->course_type_id == 4) {
        $crash_coures_total = (int) $row->total_trainings;
      }
    }

    $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;

    if ($customerConvertCount > 0) {
      $currentMonthCustomer = CustomerModel::select('za_customer.sno')->whereIn('za_customer.status', [0, 6])
        ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->whereIn('za_customer.status', [0, 6])
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->get();


      // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total
      // ECI early conversion before 15th
      $eciCustomerConvertCount = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
        ->where('za_customer.branch_id', $branchId)
        ->whereIn('za_customer.status', [0, 6])
        ->where('za_lead.created_by', $staff->sno)
        ->whereYear('za_customer.created_at', $year)
        ->whereMonth('za_customer.created_at', $month)
        ->whereDay('za_customer.created_at', '<=', 15)
        ->count();
      //   return $currentMonthCustomer;
      if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {

          // First: check if this customer has TESBO training
          $hasTesbo = DB::table('za_training')
            ->where('customer_id', $customer->sno)
            ->where('branch_id', $branchId)
            ->whereMonth('created_at', $month)
            ->whereYear('created_at', $year)
            ->where('tesbo_check', 2)
            ->where('post_sale_check', '!=', 1)
            ->exists();

          if ($hasTesbo) {
            $tesboCount++;
            continue; // skip crash/professional check if TESBO already counted
          }

          // Then: check if customer has valid Professional or Crash training (not tesbo)
          $nonTesboTrainings = DB::table('za_training')
            ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
            ->where('za_training.customer_id', $customer->sno)
            ->where('za_training.branch_id', $branchId)
            ->whereMonth('za_training.created_at', $month)
            ->whereYear('za_training.created_at', $year)
            ->where('za_training.post_sale_check', '!=', 1)
            ->where('za_training.tesbo_check', '!=', 2)
            ->whereIn('za_course.course_type_id', [3, 4])
            ->select('za_course.course_type_id')
            ->get();

          $hasCrash = false;
          $hasProfession = false;

          foreach ($nonTesboTrainings as $training) {
            if ($training->course_type_id == 3) {
              $hasProfession = true;
            } elseif ($training->course_type_id == 4) {
              $hasCrash = true;
            }
          }

          if ($hasCrash) $crashCount++;
          if ($hasProfession) $professionCount++;
        }

        $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
      }
      // return $crashCount;
      // spot incentive
      $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalcours) * 100 : 0;
      $professionPercent = $incentive->si_profession_course > 0 ? ($totalcours / $professinal_coures_total) * 100 : 0;
      $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalcours) * 100 : 0;

      $crashTarget = $incentive->si_crash_course ?? 0;
      $professionTarget = $incentive->si_profession_course ?? 0;
      $tesboTarget = $incentive->si_tesbo_course ?? 0;

      // only condition: Crash must be ≤ target
      $siStatus = $crashPercent <= $crashTarget;



      if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {
          // $trainings = DB::table('za_training')
          //     ->where('customer_id', $customer->sno)
          //       ->where('post_sale_check', 0)
          //     ->get();
          $trainings = DB::table('za_training as t1')
            ->join(DB::raw('(
                                        SELECT MIN(sno) as min_sno
                                        FROM za_training
                                        WHERE post_sale_check = 0
                                        GROUP BY customer_id
                                    ) as t2'), 't1.sno', '=', 't2.min_sno')
            ->where('t1.customer_id', $customer->sno)
            ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
            ->get();

          foreach ($trainings as $training) {
            // Determine course_id based on tesbo_check
            $course_id = null;

            if ($training->tesbo_check > 0) {
              $payment = PaymentModel::where('payment_id', $training->payment_id)->first();
              if ($payment && $payment->course_id) {
                $course_id = $payment->course_id;
              }
            } else {
              $course_id = $training->course_id;
            }

            if (!$course_id) continue; // Skip if no course_id

            $course = ManageCoursesModel::where('sno', $course_id)
              ->whereIn('course_type_id', [2, 3])
              ->first();

            if (!$course) continue;

            $basePrice = $course->course_min_price;
            $soldPrice = $training->overall_fees;


            $profitAmount = $soldPrice - $basePrice;
            $originalAmount += $profitAmount; // always include both + and -

            $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;

            // Match against PI slabs
            foreach ($pi_slabs as $slab) {
              if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                $slabPercentage = $slab['percentage'];
                $rewardFromThis = ($profitAmount * $slabPercentage) / 100;

                $piReward += $rewardFromThis;
                $piPercentage = $profitPercent;
                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                break; // first matching slab
              }
            }
          }
        }
      }

      if ($currentMonthCustomer->isNotEmpty()) {
        foreach ($currentMonthCustomer as $customer) {

          $payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
            ->where('za_training.customer_id', $customer->sno)
            ->where('za_training.tesbo_check', 0)
            ->sum('za_training.overall_fees');

          $total_payment += $payment;


          $latestTraining = DB::table('za_training')
            ->where('customer_id', $customer->sno)
            ->where('tesbo_check', 2)
            ->orderByDesc('sno')
            ->first();

          if ($latestTraining) {
            $total_payment += $latestTraining->overall_fees;
          }

          $paid_payment = DB::table('za_training')->select('za_training.course_id', 'za_training.sno', 'za_training.customer_id')
            ->where('za_training.customer_id', $customer->sno)
            ->sum('za_training.paid_amount');

          $total_paid_payment += $paid_payment;
        }
      }
      // ECI Logic
      $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
      $eciActualPercentage = number_format($eciActualPercentage, 2);
      $eciStatus = $eciActualPercentage >= $eciTargetPercentage;

      // average
      $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
      $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

      // $totalAllPayment += $total_payment;
      // $totalAllPaidPayment += $total_paid_payment;
    }

    $allConverted = CustomerModel::join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->whereIn('za_customer.status', [0, 6])
      ->where('za_customer.branch_id', $branchId)
      ->where('za_lead.created_by', $staff->sno)
      ->whereRaw('DATE(za_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
      ->select(
        'za_customer.created_at as customer_created_at',
        'za_lead.created_at as lead_created_at'
      )
      ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
      $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
      $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');

      if ($customerDate ===  $leadDate) {
        $convertedToday++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $dates &&
        $leadDate >= $startOfMonth && $leadDate <= $dates
      ) {
        $convertedMonth++;
      } elseif (
        $customerDate >= $startOfMonth && $customerDate <= $dates &&
        ($leadDate < $startOfMonth || $leadDate > $dates)
      ) {
        $convertedOldMonth++;
      }
    }

    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
    // Old month = always 0
    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;

    // 10x award calculation
    $actualConversion      = $customerConvertCount;
    $actualABV             = $averageBusinessValue ?? 0;
    $actualACV             = $averageCollectionValue ?? 0;


    $tenxStatus = (
      $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
      $actualConversion >= $targetConversion
    );
    // bi award calculation
    $biPerConversion = $incentive->bi_amount ?? 0;
    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus

    $biReward = $biAchievedCount * $biPerConversion;
    $biStatus = $biAchievedCount > 0;


    return [

      'incentives' => [
        'tenx_award' => [
          'target' => "{$targetConversion}, {$targetABV}, {$targetACV}",
          'actual' => " {$actualConversion}, " . round($actualABV) . ", " . round($actualACV) .
            ' <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                    <i class="mdi mdi-help-circle text-dark"></i>
                                </label>',
          'status' => $tenxStatus,
          'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
        ],

        'eci' => [
          'target' => $eciTargetPercentage . '%',
          'actual' => round($eciActualPercentage, 1) . '%' . ' <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
          'status' => $eciStatus,
          'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
        ],

        'bi' => [
          'target' => "{$targetConversion} - {$actualConversion} = ({$biAchievedCount})",
          'actual' => "{$biAchievedCount} × {$biPerConversion}",
          'status' =>  $biStatus,
          'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
        ],

        'si' => [
          'target' => "{$crashTarget}:{$professionTarget}:{$tesboTarget}",
          'actual' => round($crashPercent) . '%' . ':' . round($professionPercent) . '%' . ':' . round($tesboPercent) . '%',
          'status' => $tenxStatus && $siStatus,
          'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
        ],

        'pi' => [
          'target' => $matchedSlab . round($slabPercentage, 2) . '%' ?? 'No Matching Slab',
          'actual' => round($piPercentage, 2) . '%' . '₹' . $originalAmount,
          'status' => $piReward > 0,
          'reward' => ($tenxStatus && $piReward > 0)
            ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
            : 0,
        ],

        'sp' => [
          'target' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>' . $convertedOldMonth . '</td></tr>
                                </table>
                            ',
          'actual' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>₹0</td></tr>
                                </table>
                            ',
          'status' => $tenxStatus && $spotTotalReward > 0,
          'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
        ],


        'li' => [
          'target' => 'All Incentives Achieved',
          'actual' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
            ? 'Achieved'
            : 'Not Achieved',
          'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus),
          'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
            ? ($luxury['reward'] ?? 0)
            : 0,
        ]
      ]
    ];
  }   
    
}
