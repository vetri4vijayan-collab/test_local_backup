<?php

namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel;
use App\Models\SubDepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\JobpositionModel;
use App\Models\StaffModel;
use App\Models\UserRolePermissionModel;
use App\Models\User;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class WebhookReceiverEPROController extends Controller
{
  // Deparment Webhook Start
  public function DepartmentList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_college_department')
      ->select('et_college_department.*')
      ->where('et_college_department.status', 0)
      ->get();
    $lastId = DB::table('et_college_department')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function DepartmentHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_college_department')->upsert(
      [
        [
          'external_uuid'   => $uuid,
          'dept_name'       => $payload['dept_name'],
          'dept_desc'        => $payload['dept_desc'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'dept_name',
        'dept_desc',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $department = DB::table('et_college_department')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $department->sno,
      'uuid' => $uuid,
    ], 200);
  }

  // college Webhook Start
  public function CollegeList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_college')
      ->select('et_college.*')
      ->where('et_college.status', 0)
      ->get();
    $lastId = DB::table('et_college')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function CollegeHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_college')->upsert(
      [
        [
          'external_uuid'   => $uuid,
          'college_name'       => $payload['college_name'],
          'college_desc'        => $payload['college_desc'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'college_name',
        'college_desc',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $college = DB::table('et_college')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $college->sno,
      'uuid' => $uuid,
    ], 200);
  }

  // language Webhook Start
  public function languageList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_language')
      ->select('et_language.*')
      ->where('et_language.status', 0)
      ->get();
    $lastId = DB::table('et_language')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function languageHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_language')->upsert(
      [
        [
          'external_uuid'   => $uuid,
          'language_name'   => $payload['language_name'],
          'language_desc'   => $payload['language_desc'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'language_name',
        'language_desc',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $college = DB::table('et_language')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $college->sno,
      'uuid' => $uuid,
    ], 200);
  }

  // project_domain Webhook Start
  public function projectdomainList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_project_domain')
      ->select('et_project_domain.*')
      ->where('et_project_domain.status', 0)
      ->get();
    $lastId = DB::table('et_project_domain')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function projectdomainHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_project_domain')->upsert(
      [
        [
          'external_uuid'   => $uuid,
          'domain_name'   => $payload['domain_name'],
          'domain_desc'   => $payload['domain_desc'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'domain_name',
        'domain_desc',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $college = DB::table('et_project_domain')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $college->sno,
      'uuid' => $uuid,
    ], 200);
  }

  // database Webhook Start
  public function databaseList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_database')
      ->select('et_database.*')
      ->where('et_database.status', 0)
      ->get();
    $lastId = DB::table('et_database')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function databaseHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_database')->upsert(
      [
        [
          'external_uuid'   => $uuid,
          'db_name'   => $payload['db_name'],
          'db_desc'   => $payload['db_desc'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'db_name',
        'db_desc',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $college = DB::table('et_database')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $college->sno,
      'uuid' => $uuid,
    ], 200);
  }

  //  manageproject Webhook Start
  public function  manageprojectList(Request $request)
  {

    $auth_key = $request->auth_key;
    $verify_key = 'eprosecret2030datagetapierp';

    if ($auth_key !== $verify_key) {
      return response()->json([
        'status' => 410,
        'data' => null,
        'message' => 'Unauthorized Entry'
      ], 410);
    }
    $departmentList = DB::table('et_manage_project')
      ->select('et_manage_project.*')
      ->where('et_manage_project.status', 0)
      ->get();
    $lastId = DB::table('et_manage_project')
      ->orderBy('sno', 'desc')
      ->value('sno');

    $nextId = $lastId ? $lastId + 1 : 1;
    return response()->json(['status' => 200, 'data' => $departmentList, 'nextId' => $nextId], 200);
  }

  public function  manageprojectHook(Request $request)
  {
    $uuid = $request->header('X-IDEMPOTENCY-KEY')
      ?? $request->input('uuid')
      ?? (string) Str::uuid();

    $payload = $request->all();

    DB::table('et_manage_project')->upsert(
      [
        [
          'external_uuid'    => $uuid,
          'branch_id'        => $payload['branch_id'],
          'project_id'       => $payload['project_id'] ?? null,
          'project_title'    => $payload['project_title'] ?? null,
          'domain_id'        => $payload['domain_id'] ?? null,
          'language_id'      => $payload['language_id'] ?? 0,
          'database_id'      => $payload['database_id'] ?? 0,
          'journal_id'       => $payload['journal_id'] ?? 0,
          'min_amt'          => $payload['min_amt'] ?? 0,
          'max_amt'          => $payload['max_amt'] ?? 0,
          'production_check' => $payload['production_check'] ?? 0,
          'project_desc'     => $payload['project_desc'] ?? null,
          'project_type_id'  => $payload['project_type_id'] ?? null,
          'created_by'      => 1,
          'updated_by'      => 1,
          'created_at'      => now(),
          'updated_at'      => now(),
        ]
      ],
      ['external_uuid'], // unique key
      [
        'external_uuid',
        'branch_id',
        'project_id',
        'project_title',
        'domain_id',
        'language_id',
        'database_id',
        'journal_id',
        'min_amt',
        'max_amt',
        'production_check',
        'project_desc',
        'project_type_id',
        'updated_by',
        'updated_at'
      ]
    );

    // 🔹 Fetch record after upsert
    $college = DB::table('et_manage_project')
      ->where('external_uuid', $uuid)
      ->first();

    return response()->json([
      'ok'   => true,
      'sno'  => $college->sno,
      'uuid' => $uuid,
    ], 200);
  }
}
