<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateSettingsModel;
use Illuminate\Support\Facades\Validator;

class CorporateSettings extends Controller
{
    public function index()
    {
        $CorporateList = CorporateSettingsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];

        
        return view('content.settings.corporate_settings.corporate_list',[
            'CorporateList' => $CorporateList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add(Request $request)
    {
        
        // Validation rules for each contact in cust_contact_info array
        $rules = [
            'cmpy_name' => 'required',
            'cmpy_mob_no' => 'required',
            'cmpy_mail_id' => 'required',
            'cmpy_website' => 'required',
            'cmpy_address' => 'required',
            'hr_details' => 'required|array',
            'hr_details.*.hr_name' => 'required',
            'hr_details.*.hr_mob_no' => 'required',
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $cmpy_name = $request->input('cmpy_name');
        $cmpy_mob_no = $request->input('cmpy_mob_no');
        $cmpy_mail_id = $request->input('cmpy_mail_id');
        $cmpy_website = $request->input('cmpy_website');
        $cmpy_address = $request->input('cmpy_address');

        $user_details = $request->input('hr_details');
        $user_id = $request->user()->user_id;
        
        // If deliverables is an array, JSON encode it; if not, leave as is
        $deliverablesJson = null;
        
        if (is_array($user_details)) {
            $indexed_options = [];
            foreach ($user_details as $index => $value) {
                if ($value !== '') {
                    // Indexing options starting at 1, as in your second example
                    $indexed_options[] = [(string)((int)$index + 1) => $value];
                }
            }
            $deliverablesJson = json_encode($indexed_options);
        }
        
        // echo"<pre>"; return $deliverablesJson;
        // Check if module already exists (status != 2 means active/not deleted)
        $existingModule = CorporateSettingsModel::where('corporate_name', ucwords($cmpy_name))
        ->where('mail_id', '=', $cmpy_mail_id)
        ->where('mobile_no', '=', $cmpy_mob_no)
        ->where('status', '!=', 2)
        ->first();

        if ($existingModule) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Corporate already exists!'
            ]);
            return redirect()->back();
        }

        // Create new record
        $newModule = new CorporateSettingsModel();
        $newModule->corporate_name = ucfirst($cmpy_name);
        $newModule->mail_id = $cmpy_mail_id;
        $newModule->mobile_no = $cmpy_mob_no;
        $newModule->address = $cmpy_address;
        $newModule->website_url = $cmpy_website;
        $newModule->hr_details = $deliverablesJson;
        $newModule->created_by = $user_id;
        $newModule->status = 0; 

        if ($newModule->save()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Corporate added successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Corporate!'
            ]);
        }
        return redirect()->back();
    }

    public function Edit($id)
    {
        $CorporateSettings = CorporateSettingsModel::where('sno', $id)
            ->where('status', '!=', 2)
            ->first();

        if ($CorporateSettings) {
            // Decode 'hr_details' if available
            $CorporateListOptions = isset($CorporateSettings->hr_details) && !empty($CorporateSettings->hr_details)
                ? json_decode($CorporateSettings->hr_details, true)
                : [];

            $options_list = $this->flattenHRData($CorporateListOptions);

            return response()->json([
                'status' => 200,
                'data' => [
                    'id' => $CorporateSettings->sno,
                    'corporate_name' => $CorporateSettings->corporate_name,
                    'mail_id' => $CorporateSettings->mail_id ?? null,       // Assuming mail_id is a field in the model
                    'mobile_no' => $CorporateSettings->mobile_no ?? null,   // Assuming mobile_no is a field
                    'address' => $CorporateSettings->address ?? null,       // Assuming address is a field
                    'website_url' => $CorporateSettings->website_url ?? null, // Assuming website_url is a field
                    'hr_details' => $options_list,
                ],
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Corporate Settings not found',
            ]);
        }
    }

    public function Update(Request $request)
    {

        // return $request;

        // Validation rules for each contact in cust_contact_info array
        $rules = [
            'corporate_sno' => 'required',
            'cmpy_name' => 'required',
            'cmpy_mob_no' => 'required',
            'cmpy_mail_id' => 'required',
            'cmpy_website' => 'required',
            'cmpy_address' => 'required',
            'hr_details' => 'required|array',
            'hr_details.*.hr_name' => 'required',
            'hr_details.*.hr_mob_no' => 'required',
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $corporate_sno = $request->input('corporate_sno');
        $cmpy_name = $request->input('cmpy_name');
        $cmpy_mob_no = $request->input('cmpy_mob_no');
        $cmpy_mail_id = $request->input('cmpy_mail_id');
        $cmpy_website = $request->input('cmpy_website');
        $cmpy_address = $request->input('cmpy_address');

        $user_details = $request->input('hr_details');
        $user_id = $request->user()->user_id;
        
        // If deliverables is an array, JSON encode it; if not, leave as is
        $deliverablesJson = null;
        
        if (is_array($user_details)) {
            $indexed_options = [];
            foreach ($user_details as $index => $value) {
                if ($value !== '') {
                    // Indexing options starting at 1, as in your second example
                    $indexed_options[] = [(string)$index => $value];
                }
            }
            $deliverablesJson = json_encode($indexed_options);
        }
        
        // echo"<pre>"; return $deliverablesJson;
        // Check if module already exists (status != 2 means active/not deleted)
        $existingModule = CorporateSettingsModel::where('corporate_name', ucwords($cmpy_name))
        ->where('mail_id', '=', $cmpy_mail_id)
        ->where('mobile_no', '=', $cmpy_mob_no)
        ->where('status', '!=', 2)
        ->where('sno', '!=', $corporate_sno)
        ->first();

        $updateModule = CorporateSettingsModel::where('sno', $corporate_sno)
        ->where('status', '!=', 2)
        ->first();

        if ($existingModule) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Corporate already exists!'
            ]);
            return redirect()->back();
        }

        // Create new record
        $updateModule->corporate_name = ucfirst($cmpy_name);
        $updateModule->mail_id = $cmpy_mail_id;
        $updateModule->mobile_no = $cmpy_mob_no;
        $updateModule->address = $cmpy_address;
        $updateModule->website_url = $cmpy_website;
        $updateModule->hr_details = $deliverablesJson;
        $updateModule->created_by = $user_id;
        $updateModule->status = 0; 

        if ($updateModule->update()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Corporate Update successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Corporate!'
            ]);
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CorporateSettingsModel         = CorporateSettingsModel::where('sno', $id)->first();
        $upd_CorporateSettingsModel->status = 2;
        $upd_CorporateSettingsModel->Update();

        return response([
        'status'    => 200,
        'message'   => 'Corporate Setting Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $upd_CorporateSettingsModel         = CorporateSettingsModel::where('sno', $id)->first();
        $upd_CorporateSettingsModel->status = $request->input('status', 0);
        $upd_CorporateSettingsModel->update();

        return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }

    private function flattenHRData($input)
    {
        $result = [];
        foreach ($input as $item) {
            foreach ($item as $key => $details) {
                $result[$key] = $details;  // append inner arrays
            }
        }
        return $result;
    }
}