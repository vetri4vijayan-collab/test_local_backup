<?php

namespace App\Http\Controllers\settings\default_goal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DefaultGoalSetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class DefaultGoal extends Controller
{


  public function index()
    {
        return view('content.settings.default.goal');
    }

   public function getDefaultGoals(Request $request)
    {
        $goal = DefaultGoalSetModel::where('branch_id',$request->branch_id)->where('department_id',$request->department_id)->first();
        return response()->json(['status' => 200, 'data' => $goal]);
    }

    public function updateDefaultGoals(Request $request)
    {
        $validatedData = $request->validate([
            'branch_id' => 'required|integer',
            'department_id' => 'required|integer',
            'conversion' => 'nullable|numeric',
            'conversion_check' => 'nullable|boolean',
            'CR' => 'nullable|numeric',
            'CR_check' => 'nullable|boolean',
            'ABV' => 'nullable|numeric',
            'ABV_check' => 'nullable|boolean',
            'ACV' => 'nullable|numeric',
            'ACV_check' => 'nullable|boolean',
            'avg_call_out' => 'nullable|numeric',
            'avg_call_out_check' => 'nullable|boolean',
            'no_of_walk' => 'nullable|numeric',
            'no_of_walk_check' => 'nullable|boolean',
            'no_of_followup' => 'nullable|numeric',
            'no_of_followup_check' => 'nullable|boolean',
            'hac' => 'nullable|numeric',
            'hac_check' => 'nullable|boolean',
            'min_no_of_students' => 'nullable|numeric',
            'min_no_of_students_check' => 'nullable|boolean',
            'no_of_post_sale' => 'nullable|numeric',
            'no_of_post_sale_check' => 'nullable|boolean',
            'no_of_outstanding' => 'nullable|numeric',
            'no_of_outstanding_check' => 'nullable|boolean',
            'production_costing' => 'nullable|numeric',
            'production_costing_check' => 'nullable|boolean',
            'productions' => 'nullable|numeric',
            'productions_check' => 'nullable|boolean',
            'no_of_reviews' => 'nullable|numeric',
            'no_of_reviews_check' => 'nullable|boolean',
            'given_links' => 'nullable|string',
            'given_links_check' => 'nullable|boolean',
            'no_of_placements' => 'nullable|numeric',
            'no_of_placements_check' => 'nullable|boolean',
            'mou' => 'nullable|string',
            'mou_check' => 'nullable|boolean',
            'reference_sales' => 'nullable|numeric',
            'reference_sales_check' => 'nullable|boolean',
        ]);

        // Ensure unchecked checkboxes are set to 0
        foreach ($validatedData as $key => $value) {
            if (strpos($key, '_check') !== false && $value === null) {
                $validatedData[$key] = 0;
            }
        }

        $goal = DefaultGoalSetModel::updateOrCreate(
            ['branch_id' => $validatedData['branch_id'], 'department_id' => $validatedData['department_id']], // Search condition
            array_merge(
                $validatedData,
                [
                    'updated_by' => auth()->id(),
                    'created_by' => DefaultGoalSetModel::where('branch_id', $validatedData['branch_id'])
                        ->where('department_id', $validatedData['department_id'])
                        ->exists()
                        ? DefaultGoalSetModel::where('branch_id', $validatedData['branch_id'])
                            ->where('department_id', $validatedData['department_id'])
                            ->value('created_by')
                        : auth()->id(), // Keep existing created_by if record exists
                ]
            )
        );

        return response()->json(['status' => 200, 'message' => 'Default goals updated successfully', 'data' => $goal]);
    }


}
