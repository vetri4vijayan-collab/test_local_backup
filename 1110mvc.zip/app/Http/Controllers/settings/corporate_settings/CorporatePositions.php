<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporatePositionsModel;
use Illuminate\Support\Facades\Validator;

class CorporatePositions extends Controller
{
    public function index()
    {
        $CorporatePositionsList = CorporatePositionsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];

        return view('content.settings.corporate_settings.corporate_positions.corporate_positions_list',[
            'CorporatePositionsList' => $CorporatePositionsList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'position_name' => 'required|max:60'
        ]);

        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

        $position_name       = $request->position_name;
        $position_desc       = $request->position_desc;
        $user_id                  = $request->user()->user_id;
        $check_validation = CorporatePositionsModel::where('position_name', ucwords( $position_name ) )->where( 'status', '!=', 2 )->first();
        if ($check_validation) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Corporate Positions is Already Exist!'
            ] );
            return redirect()->back();

        } else {

            $add_corporate_venue = new CorporatePositionsModel();
            $add_corporate_venue->position_name = Ucfirst( $position_name );
            $add_corporate_venue->position_desc = $position_desc;
            $add_corporate_venue->created_by = $user_id;
            $add_corporate_venue->created_at = now();
            $add_corporate_venue->save();

            if ( $add_corporate_venue ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Corporate Positions Added Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Failed to add Corporate Positions.'
                ] );
            }
        }
        return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editCorporateVenue = CorporatePositionsModel::where('sno', $id)->first();
        return view('content.settings.corporate_venue.corporate_venue_list', [
            'editCorporateVenue' => $editCorporateVenue,
            'id'             => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'edit_position_id' => 'required',
            'position_name' => 'required|max:60',
        ]);

        if ($validator->fails()) {
            return   response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
            ], 200);
        } else {

        $position_name = $request->position_name;
        $position_desc = $request->position_desc;
        $edit_position_id   = $request->edit_position_id;
        $user_id            = $request->user()->user_id;

        $upd_corporate_venue = CorporatePositionsModel::where('sno', $edit_position_id)->first();

        $check_validation = CorporatePositionsModel::where('position_name', ucwords($position_name))->where('sno', '!=', $edit_position_id)->where('status', '!=', 2)->first();

        if ($check_validation) {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Corporate Positions is Already Exist!'
            ]);
            return redirect()->back();
        }

        $upd_corporate_venue->position_name = Ucfirst($position_name);
        $upd_corporate_venue->position_desc = $position_desc;
        $upd_corporate_venue->updated_by         = $user_id;
        $upd_corporate_venue->updated_at         = now();
        $upd_corporate_venue->update();

        if ($upd_corporate_venue) {
            // If category added successfully, return success response and display Toastr message
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Corporate Positions Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to update Corporate Positions.'
            ]);
        }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_BranchTypeModel         = CorporatePositionsModel::where('sno', $id)->first();
        $upd_BranchTypeModel->status = 2;
        $upd_BranchTypeModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Corporate Position Deleted Successfully!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $upd_BranchTypeModel         = CorporatePositionsModel::where('sno', $id)->first();
        $upd_BranchTypeModel->status = $request->input('status', 0);
        $upd_BranchTypeModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
    public function List() {
        $CorporatePositionsModel_list = CorporatePositionsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $CorporatePositionsModel_list
        ], 200 );
    }
}