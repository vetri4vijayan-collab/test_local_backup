<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateVenueModel;
use Illuminate\Support\Facades\Validator;

class CorporateVenue extends Controller
{
  public function index()
  {

    $CorporateVenue = CorporateVenueModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
    $pageConfigs = [ 'myLayout' => 'default' ];
    return view( 'content.settings.corporate_settings.corporate_venue.corporate_venue_list', [
        'DeliveryTypes' => $CorporateVenue,
        'pageConfigs' => $pageConfigs
    ] );
  }

  public function Add( Request $request ) {

    $validator = Validator::make( $request->all(), [
        'corporate_venue_name' => 'required|max:60'
    ]);

    if ( $validator->fails() ) {
        return  response( [
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => $validator->messages()->get( '*' ),
            'data'      => null,
        ], 200 );
    } else {

      $corporate_venue_name       = $request->corporate_venue_name;
      $corporate_venue_desc       = $request->corporate_venue_desc;
      $user_id                  = $request->user()->user_id;
      $check_validation = CorporateVenueModel::where('corporate_venue_name', ucwords( $corporate_venue_name ) )->where( 'status', '!=', 2 )->first();
      if ($check_validation) {
          session()->flash( 'toastr', [
              'type' => 'error',
              'message' => 'Corporate Venue is Already Exist!'
          ] );
          return redirect()->back();

      } else {

        $add_corporate_venue = new CorporateVenueModel();
        $add_corporate_venue->corporate_venue_name = Ucfirst( $corporate_venue_name );
        $add_corporate_venue->corporate_venue_desc = $corporate_venue_desc;
        $add_corporate_venue->created_by = $user_id;
        $add_corporate_venue->save();

        if ( $add_corporate_venue ) {
            // If category added successfully, return success response and display Toastr message
            session()->flash( 'toastr', [
                'type' => 'success',
                'message' => 'Corporate Venue Added Successfully!'
            ] );
        } else {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Failed to add Corporate Venue.'
            ] );
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editCorporateVenue = CorporateVenueModel::where('sno', $id)->first();
    return view('content.settings.corporate_settings.corporate_venue.corporate_venue_list', [
        'editCorporateVenue' => $editCorporateVenue,
        'id'             => $id,
    ]);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'corporate_venue_name' => 'required|max:60',
    ]);

    if ($validator->fails()) {
        return   response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
    } else {

      $corporate_venue_name = $request->corporate_venue_name;
      $corporate_venue_desc = $request->corporate_venue_desc;
      $corporate_venue_id   = $request->corporate_venue_id;
      $user_id            = $request->user()->user_id;

      $upd_corporate_venue = CorporateVenueModel::where('sno', $corporate_venue_id)->first();

      $check_validation = CorporateVenueModel::where('corporate_venue_name', ucwords($corporate_venue_name))->where('sno', '!=', $corporate_venue_id)->where('status', '!=', 2)->first();

      if ($check_validation) {
          session()->flash('toastr', [
              'type'    => 'error',
              'message' => 'Corporate Venue is Already Exist!'
          ]);
          return redirect()->back();
      }

      $upd_corporate_venue->corporate_venue_name = Ucfirst($corporate_venue_name);
      $upd_corporate_venue->corporate_venue_desc = $corporate_venue_desc;
      $upd_corporate_venue->updated_by         = $user_id;
      $upd_corporate_venue->update();

      if ($upd_corporate_venue) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
            'type'    => 'success',
            'message' => 'Corporate Venue Updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Failed to update Corporate Venue.'
        ]);
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_BranchTypeModel         = CorporateVenueModel::where('sno', $id)->first();
    $upd_BranchTypeModel->status = 2;
    $upd_BranchTypeModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Corporate Venue Deleted Successfully!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {
    $upd_BranchTypeModel         = CorporateVenueModel::where('sno', $id)->first();
    $upd_BranchTypeModel->status = $request->input('status', 0);
    $upd_BranchTypeModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  
  public function List() {
      $CorporateVenueModel_list = CorporateVenueModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
      return response( [
          'status' => 200,
          'message' => null,
          'error_msg' => null,
          'data' => $CorporateVenueModel_list
      ], 200 );
  }

}
