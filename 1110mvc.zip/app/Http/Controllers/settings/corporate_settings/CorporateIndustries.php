<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateIndustriesModel;
use Illuminate\Support\Facades\Validator;

class CorporateIndustries extends Controller
{
    public static $CORP_INDUSTRY_TYPE_LIST = [
        1 => 'IT',
        2 => 'Non-IT'
    ];

    public function index()
    {
        $CorporateIndustriesList = CorporateIndustriesModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->get()
        ->map(function ($row) {
            $row->industry_type_name = $this->getIndustryTypeName($row->industry_type);
            return $row;
        });

        $pageConfigs = [ 'myLayout' => 'default' ];

        return view('content.settings.corporate_settings.corporate_industries.corporate_industries_list',[
            'CorporateIndustriesList' => $CorporateIndustriesList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'industry_name' => 'required|max:60',
            'industry_type' => 'required'
        ]);

        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $industry_name = $request->industry_name;
            $industry_type = $request->industry_type ?? 2;
            $industry_desc = $request->industry_desc ?? null;
            $user_id       = $request->user()->user_id;

            $check_validation = CorporateIndustriesModel::where('industry_name', ucwords( $industry_name ) )->where( 'status', '!=', 2 )->first();

            if ($check_validation) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Corporate Industries is Already Exist!'
                ] );
                return redirect()->back();
            } else {

                $add_corporate_industry = new CorporateIndustriesModel();
                $add_corporate_industry->industry_name = Ucfirst($industry_name);
                $add_corporate_industry->industry_type = $industry_type ?? 2;
                $add_corporate_industry->industry_desc = $industry_desc ?? NULL;
                $add_corporate_industry->created_by = $user_id;
                $add_corporate_industry->created_at = now();
                $add_corporate_industry->save();

                if ($add_corporate_industry) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Corporate Industries Added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Failed to add Corporate Industries.'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        
        if ($decryptedValue === false) {
            return response()->json([
                'status'  => 422,
                'type'     => 'error',
                'message' => 'Invalid Entry',
                'data' => null
            ], 422);
        }

        $editCorporateVenue = CorporateIndustriesModel::where('sno', $decryptedValue)->first();
        return response()->json([
            'status'  => 200,
            'type'     => 'success',
            'message' => 'Fetched Successfully',
            'data' => $editCorporateVenue,
            'encrypt_id' => $id
        ], 200);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_industry_id' => 'required',
            'industry_name' => 'required|max:60',
            'edit_industry_type' => 'required'
        ]);

        if ($validator->fails()) {
            return   response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
            ], 200);
        } else {
            
            $edit_industry_id   = $request->edit_industry_id;

            $helper = new \App\Helpers\Helpers();
            $decryptedValue = $helper->encrypt_decrypt($edit_industry_id, 'decrypt');

            $industry_name = $request->industry_name;
            $industry_type = $request->edit_industry_type;
            $industry_desc = $request->industry_desc;
            $user_id            = $request->user()->user_id;

            $upd_corporate_industry = CorporateIndustriesModel::where('sno', $decryptedValue)->first();

            $check_validation = CorporateIndustriesModel::where('industry_name', ucwords($industry_name))->where('sno', '!=', $decryptedValue)->where('status', '!=', 2)->first();

            if ($check_validation) {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Corporate Industries is Already Exist!'
                ]);
                return redirect()->back();
            }

            $upd_corporate_industry->industry_name = Ucfirst($industry_name);
            $upd_corporate_industry->industry_type = Ucfirst($industry_type);
            $upd_corporate_industry->industry_desc = $industry_desc;
            $upd_corporate_industry->updated_by         = $user_id;
            $upd_corporate_industry->updated_at         = now();
            $upd_corporate_industry->update();

            if ($upd_corporate_industry) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type'    => 'success',
                    'message' => 'Corporate Industries Updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Failed to update Corporate Industries.'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return response()->json([
                'status'  => 422,
                'type'     => 'error',
                'message' => 'Invalid Entry',
                'data' => null
            ], 422);
        }

        $upd_BranchTypeModel         = CorporateIndustriesModel::where('sno', $decryptedValue)->first();
        $upd_BranchTypeModel->status = 2;
        $upd_BranchTypeModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Corporate Position Deleted Successfully!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return response()->json([
                'status'  => 422,
                'type'     => 'error',
                'message' => 'Invalid Entry',
                'data' => null
            ], 422);
        }

        $upd_BranchTypeModel         = CorporateIndustriesModel::where('sno', $decryptedValue)->first();
        $upd_BranchTypeModel->status = $request->input('status', 0);
        $upd_BranchTypeModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
    // public function List() {
    //     $CorporateIndustriesModel_list = CorporateIndustriesModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
    //     return response( [
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $CorporateIndustriesModel_list
    //     ], 200 );
    // }

    protected function getIndustryTypeName($type = 2)
    {
        $types = self::$CORP_INDUSTRY_TYPE_LIST;

        return isset($types[$type]) && !empty($types[$type])
            ? $types[$type]
            : 'Non-IT';
    }
}