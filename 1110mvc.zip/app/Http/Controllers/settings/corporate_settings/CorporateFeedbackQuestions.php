<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateFeedbackQuestionsModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class CorporateFeedbackQuestions extends Controller
{
    private static $ENGLISH_LANG_ID = 15;
    private static $TAMIL_LANG_ID = 79;

    public function index()
    {
        $CorporateFeedbackQuestionsList = CorporateFeedbackQuestionsModel::where( 'status', '!=', 2 )->orderBy( 'created_at', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];

        return view('content.settings.corporate_settings.corporate_feedback_questions.questions_list',[
            'cat_question' => $CorporateFeedbackQuestionsList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function FeedbackAdd()
    {
        $CorporateFeedbackQuestionsList = new CorporateFeedbackQuestionsModel();
        return view('content.settings.corporate_settings.corporate_feedback_questions.questions_add',[
            'cat_question' => $CorporateFeedbackQuestionsList
        ]);
    }

    public function Add(Request $request)
    {
        
        /* ---------------------------------
        BASIC VALIDATION
        --------------------------------- */
        $validator = Validator::make($request->all(), [
            'question.*'      => 'required|max:255',
            'question_type.*' => 'required',
            'language.*'      => 'required',
            'section.*'       => 'nullable',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'type'    => 'error',
                'message' => 'Please fill all required fields!'
            ], 422);
        }

        $user_id = $request->user()->user_id;

        /* ---------------------------------
        LOOP QUESTIONS
        --------------------------------- */
        foreach ($request->question as $key => $questionName) {

            $qType       = $request->question_type[$key];
            $language_id = $request->language[$key] ?? null;
            
            $section_id  = null;
            if($language_id == self::$TAMIL_LANG_ID){
                $section_id = 2;
            }else if($language_id == self::$ENGLISH_LANG_ID){
                $section_id = 1;
            }

            $optionsJson = null;

            /* ---------------------------------
            DYNAMIC OPTION HANDLING
            --------------------------------- */
            $optionTypes = ['radio_button', 'checkbox', 'list_box'];

            if (in_array($qType, $optionTypes)) {

                $valueKey = "option_value_{$key}";
                $scoreKey = "option_score_{$key}";

                $values = $request->input($valueKey, []);
                $scores = $request->input($scoreKey, []);

                $options = [];

                foreach ($values as $i => $value) {

                    if (trim($value) === '') {
                        continue;
                    }

                    $score = $scores[$i] ?? null;
                    if ($score === null || $score <= 0) {
                        continue;
                    }

                    $options[] = [
                        'value' => trim($value),
                        'score' => (int) $score
                    ];
                }

                if (count($options) === 0) {
                    return response()->json([
                        'status'  => false,
                        'type'    => 'error',
                        'message' => 'At least one valid option is required!'
                    ], 422);
                }

                $optionsJson = json_encode($options);
            }

            /* ---------------------------------
            DUPLICATE CHECK
            --------------------------------- */
            $exists = CorporateFeedbackQuestionsModel::whereRaw(
                            'LOWER(category_question_name) = ?',
                            [strtolower(trim($questionName))]
                        )
                        ->where('status', '!=', 2)
                        ->exists();

            if ($exists) {
                return response()->json([
                    'status'  => false,
                    'type'    => 'warning',
                    'message' => "Question already exists: {$questionName}"
                ], 409);
            }

            /* ---------------------------------
            SAVE QUESTION
            --------------------------------- */

            $newModule = new CorporateFeedbackQuestionsModel();
            $newModule->category_question_name = ucfirst(trim($questionName));
            $newModule->category_question_type = $qType;
            $newModule->category_question_option = $optionsJson ?? NULL;
            $newModule->language_id = $language_id ?? NULL;
            $newModule->section_id = $section_id ?? NULL;
            $newModule->created_by = $user_id;
            $newModule->created_at = now();
            $newModule->save();
        }

        /* ---------------------------------
        SUCCESS RESPONSE
        --------------------------------- */
        return response()->json([
            'status'   => true,
            'type'     => 'success',
            'message'  => 'Feedback Questions Saved Successfully!',
            'redirect' => url('/settings/corporate/feedback_questions_list')
        ]);
    }

    public function Edit($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Fetch the single question
        $question = CorporateFeedbackQuestionsModel::where('sno', $decryptedValue)
                        ->where('status', '!=', 2)
                        ->first();

        if (!$question) {
            return redirect()->route('feedback_question_list')
            ->with('toastr', [
                'type' => 'error',
                'message' => 'Question not found!'
            ]);
        }

        // Fetch all sections for the selected language (optional)
        $sections = [];
        $languages = DB::table('za_languages')->get(); // raw query
    
        return view('content.settings.corporate_settings.corporate_feedback_questions.questions_edit', [
            'question' => $question,
            'sections' => $sections,
            'languages' => $languages, // all languages for dropdown
        ]);
    }

    public function update(Request $request, $id)
    {
        /* ---------------------------------
        BASIC VALIDATION
        --------------------------------- */
        $validator = Validator::make($request->all(), [
            'question'       => 'required|string',
            'question_type'  => 'required|string',
            'language'    => 'required|integer',
            'section'     => 'nullable|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Please fill all required fields'
            ], 422);
        }

        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        
        // return $decryptedValue;
        // Check if decryption failed

        if ($decryptedValue === false) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Invalid Entry'
            ], 422);
        }

        /* ---------------------------------
        FETCH QUESTION
        --------------------------------- */
        $question = CorporateFeedbackQuestionsModel::find($decryptedValue);

        if (!$question) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Question not found'
            ], 404);
        }

        $user_id = $request->user()->user_id;
        $qType   = $request->question_type;

        /* ---------------------------------
        DYNAMIC OPTION HANDLING
        --------------------------------- */
        $optionTypes = ['radio_button', 'checkbox', 'list_box'];
        $optionsJson = null;

        if (in_array($qType, $optionTypes)) {

            $values = $request->input('option_value', []);
            $scores = $request->input('option_score', []);

            $options = [];

            foreach ($values as $key => $val) {

                if (trim($val) !== '') {

                    if (!isset($scores[$key]) || $scores[$key] <= 0) {
                        return response()->json([
                            'status'  => false,
                            'message' => 'Each option must have a score greater than 0'
                        ], 422);
                    }

                    $options[] = [
                        'value' => trim($val),
                        'score' => (int) $scores[$key],
                    ];
                }
            }

            if (empty($options)) {
                return response()->json([
                    'status'  => false,
                    'type'     => 'error',
                    'message' => 'At least one option is required'
                ], 422);
            }

            $optionsJson = json_encode($options);
        }

        /* ---------------------------------
        DUPLICATE QUESTION CHECK
        --------------------------------- */
        $exists = CorporateFeedbackQuestionsModel::where(
                        'category_question_name',
                        ucfirst(trim($request->question))
                )
                ->where('sno', '!=', $decryptedValue)
                ->where('status', '!=', 2)
                ->exists();

        if ($exists) {
            return response()->json([
                'status'  => false,
                'type'     => 'warning',
                'message' => 'Question already exists'
            ], 409);
        }

        /* ---------------------------------
        UPDATE QUESTION
        --------------------------------- */
        $question->category_question_name   = ucfirst(trim($request->question));
        $question->category_question_type   = $qType;
        $question->category_question_option = $optionsJson ?? NULL;
        $question->language_id              = $request->language ?? NULL;
        $question->section_id               = $request->section ?? NULL;
        $question->updated_by               = $user_id;
        $question->updated_at               = now();

        $question->save();

        /* ---------------------------------
        SUCCESS RESPONSE
        --------------------------------- */
        return response()->json([
            'status'   => true,
            'type'     => 'success',
            'message'  => 'Feedback Questions Updated Successfully!',
            'redirect' => url('/settings/corporate/feedback_questions_list')
        ]);
    }

    public function Delete($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        
        // return $decryptedValue;
        // Check if decryption failed

        if ($decryptedValue === false) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Invalid Entry'
            ], 422);
        }

        $upd_BranchTypeModel         = CorporateFeedbackQuestionsModel::where('sno', $decryptedValue)->first();
        $upd_BranchTypeModel->status = 2;
        $upd_BranchTypeModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Deleted Successfully!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        
        // return $decryptedValue;
        // Check if decryption failed

        if ($decryptedValue === false) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Invalid Entry'
            ], 422);
        }
        
        $upd_BranchTypeModel         = CorporateFeedbackQuestionsModel::where('sno', $decryptedValue)->first();
        $upd_BranchTypeModel->status = $request->input('status', 0);
        $upd_BranchTypeModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
    public function List() {
        $CorporateFeedbackQuestionsModel_list = CorporateFeedbackQuestionsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $CorporateFeedbackQuestionsModel_list
        ], 200 );
    }

    public function get_feedback_question_details($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // return $decryptedValue;
        // Check if decryption failed
        if ($decryptedValue === false) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Invalid Entry'
            ], 422);
        }

        // Fetch the single question
        $question = CorporateFeedbackQuestionsModel::where('sno', $decryptedValue)
                        ->where('status', '!=', 2)
                        ->first();

        if (!$question) {
            return response()->json([
                'status'  => false,
                'type'     => 'error',
                'message' => 'Question not found!'
            ], 422);
        }

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => $question,
        ], 200);
    }
}