<?php

namespace App\Http\Controllers\settings\corporate_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CorporateSettingsModel;
use App\Models\CorporatePositionsModel;
use Illuminate\Support\Facades\Validator;

class CorporateSettings extends Controller
{
    protected static $temp = [];

    public function index()
    {
        $CorporateList = CorporateSettingsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];

        // Process each college
        foreach ($CorporateList as $corporate) {

            $spoc_details = isset($corporate->hr_details) && !empty($corporate->hr_details) ? json_decode($corporate->hr_details, true) : [];

            $options_list = $this->flattenHRData($spoc_details);

            $spoc_list = [];

            foreach ($options_list as $item) {
                $spoc_list[] = [
                    'spoc_name'           => $item['spoc_name'] ?? '',
                    'spoc_mob_no'         => $item['spoc_mob_no'] ?? '',
                    'spoc_position'       => $item['spoc_position'] ?? '',
                    'spoc_position_name'  => isset($item['spoc_position']) ? self::getCorporatePositionName($item['spoc_position']) : ''
                ];
            }

            $corporate->hr_details = !empty($spoc_list) ? json_encode($spoc_list) : null;
        }
        
        return view('content.settings.corporate_settings.corporate.corporate_list',[
            'CorporateList' => $CorporateList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add(Request $request)
    {    
        // Validation rules for each contact in cust_contact_info array
        $rules = [
            'cmpy_name' => 'required',
            'cmpy_mob_no' => 'required',
            'cmpy_mail_id' => 'required',
            'cmpy_address' => 'required'
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $cmpy_name = $request->input('cmpy_name');
        $cmpy_mob_no = $request->input('cmpy_mob_no');
        $cmpy_mail_id = $request->input('cmpy_mail_id');
        $cmpy_address = $request->input('cmpy_address');
        $logo_width = $request->input('logo_width',100);
        $logo_height = $request->input('logo_height',100);

        $user_id = $request->user()->user_id;
        
        $user_details   = $request->input('spoc_details');
        $deliverablesJson = null;
        if (is_array($user_details)) {
          $indexed_options = [];
          foreach ($user_details as $index => $value) {
            if ($value !== '') {
                $indexed_options[] = [
                    (string)((int)$index + 1) => $value
                ];
            }
          }
          $deliverablesJson = json_encode($indexed_options);
        }

        $timestamp = time();

        $logo_sizes = [
            'width' => $logo_width ?? 100,
            'height' => $logo_height ?? 100
        ];

        $LogoPath = '';
        if ($request->hasFile('logo_file')) {
            $LogoPath = 'corporate_logo_' . $timestamp . '.' . $request->file('logo_file')->extension();
            $request->file('logo_file')->move(public_path('college_corp_logos'), $LogoPath);
        }
        
        // Check if module already exists (status != 2 means active/not deleted)
        $existingModule = CorporateSettingsModel::where('corporate_name', ucwords($cmpy_name))
        ->where('mail_id', '=', $cmpy_mail_id)
        ->where('mobile_no', '=', $cmpy_mob_no)
        ->where('status', '!=', 2)
        ->first();

        if ($existingModule) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Corporate already exists!'
            ]);
            return redirect()->back();
        }

        // Create new record
        $newModule = new CorporateSettingsModel();
        $newModule->corporate_name = ucfirst($cmpy_name);
        $newModule->mail_id = $cmpy_mail_id;
        $newModule->mobile_no = $cmpy_mob_no;
        $newModule->address = $cmpy_address;
        $newModule->authority_name = NULL;
        if(!empty($LogoPath)){
            $newModule->logo_file = $LogoPath;
        }
        $newModule->logo_size = json_encode($logo_sizes) ?? NULL;
        $newModule->authority_mobile = NULL;
        $newModule->website_url = NULL;
        $newModule->hr_details = $deliverablesJson;
        $newModule->created_by = $user_id;
        $newModule->created_at = now();
        $newModule->status = 0; 

        if ($newModule->save()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Corporate added successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Corporate!'
            ]);
        }
        return redirect()->back();
    }

    public function Edit($id)
    {
        $CorporateSettings = CorporateSettingsModel::where('sno', $id)
            ->where('status', '!=', 2)
            ->first();

        if ($CorporateSettings) {

            $CorporateListOptions = isset($CorporateSettings->hr_details) && !empty($CorporateSettings->hr_details)
                ? json_decode($CorporateSettings->hr_details, true)
                : [];
            
            $CorporateListlogo_size = isset($CorporateSettings->logo_size) && !empty($CorporateSettings->logo_size)
                ? json_decode($CorporateSettings->logo_size, true)
                : [];

            $options_list = $this->flattenHRData($CorporateListOptions);

            return response()->json([
                'status' => 200,
                'data' => [
                    'id' => $CorporateSettings->sno,
                    'corporate_name' => $CorporateSettings->corporate_name,
                    'mail_id' => $CorporateSettings->mail_id ?? null,       // Assuming mail_id is a field in the model
                    'mobile_no' => $CorporateSettings->mobile_no ?? null,   // Assuming mobile_no is a field
                    'address' => $CorporateSettings->address ?? null,       // Assuming address is a field
                    'authority_name' => null,       // Assuming authority_name is a field
                    'authority_mobile' => null,       // Assuming authority_mobile is a field
                    'website_url' => null, // Assuming website_url is a field
                    'hr_details' => $options_list,
                    'logo_file' => $CorporateSettings->logo_file ?? null,
                    'logo_size' => $CorporateListlogo_size,
                ],
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Corporate Settings not found',
            ]);
        }
    }

    public function Update(Request $request)
    {
        // Validation rules for each contact in cust_contact_info array
        $rules = [
            'corporate_sno' => 'required',
            'cmpy_name' => 'required',
            'cmpy_mob_no' => 'required',
            'cmpy_mail_id' => 'required',
            'cmpy_address' => 'required'
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $timestamp = time();

        $LogoPath = '';
        if ($request->hasFile('logo_file')) {
            $LogoPath = 'corporate_logo_' . $timestamp . '.' . $request->file('logo_file')->extension();
            $request->file('logo_file')->move(public_path('college_corp_logos'), $LogoPath);
        }
        

        $corporate_sno = $request->input('corporate_sno');
        $cmpy_name = $request->input('cmpy_name');
        $cmpy_mob_no = $request->input('cmpy_mob_no');
        $cmpy_mail_id = $request->input('cmpy_mail_id');
        $cmpy_address = $request->input('cmpy_address');
        $logo_width = $request->input('logo_width',100);
        $logo_height = $request->input('logo_height',100);

        $user_id = $request->user()->user_id;
        
        // If deliverables is an array, JSON encode it; if not, leave as is
        $user_details   = $request->input('spoc_details');

        // Process HR details
        $deliverablesJson = null;
        $logo_sizes = [
            'width' => $logo_width ?? 100,
            'height' => $logo_height ?? 100
        ];

        if (is_array($user_details)) {
            $indexed_options = [];
            foreach ($user_details as $index => $value) {
            if ($value !== '') {
                $indexed_options[] = [
                    (string)((int)$index) => $value
                ];
            }
            }
            $deliverablesJson = json_encode($indexed_options);
        }
        
        // Check if module already exists (status != 2 means active/not deleted)
        $existingModule = CorporateSettingsModel::where('corporate_name', ucwords($cmpy_name))
        ->where('mail_id', '=', $cmpy_mail_id)
        ->where('mobile_no', '=', $cmpy_mob_no)
        ->where('status', '!=', 2)
        ->where('sno', '!=', $corporate_sno)
        ->first();

        $updateModule = CorporateSettingsModel::where('sno', $corporate_sno)
        ->where('status', '!=', 2)
        ->first();

        if ($existingModule) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Corporate already exists!'
            ]);
            return redirect()->back();
        }

        // Create new record
        $updateModule->corporate_name = ucfirst($cmpy_name);
        $updateModule->mail_id = $cmpy_mail_id;
        $updateModule->mobile_no = $cmpy_mob_no;
        $updateModule->address = $cmpy_address;
        $updateModule->authority_name = NULL;
        if(!empty($LogoPath)){
            $updateModule->logo_file = $LogoPath;
        }
        $updateModule->logo_size = json_encode($logo_sizes) ?? NULL;
        $updateModule->authority_mobile = NULL;
        $updateModule->website_url = NULL;
        $updateModule->hr_details = $deliverablesJson;
        $updateModule->created_by = $user_id;
        $updateModule->status = 0; 


        if ($updateModule->update()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Corporate Update successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Corporate!'
            ]);
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CorporateSettingsModel         = CorporateSettingsModel::where('sno', $id)->first();
        $upd_CorporateSettingsModel->status = 2;
        $upd_CorporateSettingsModel->Update();

        return response([
        'status'    => 200,
        'message'   => 'Corporate Setting Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $upd_CorporateSettingsModel         = CorporateSettingsModel::where('sno', $id)->first();
        $upd_CorporateSettingsModel->status = $request->input('status', 0);
        $upd_CorporateSettingsModel->update();

        return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }

    private function flattenHRData($input)
    {
        $result = [];
        foreach ($input as $item) {
            foreach ($item as $key => $details) {
                $result[$key] = $details;  // append inner arrays
            }
        }
        return $result;
    }

    private static function getCorporatePositionName($id)
    {
        // Initialize 'details' if not already
        if (!isset(self::$temp['CorporatePositionName'])) {
            self::$temp['CorporatePositionName'] = [];
        }

        // Check if the id is already cached
        if (!isset(self::$temp['CorporatePositionName'][$id])) {
            $state = CorporatePositionsModel::select(['position_name'])->where('sno', $id)->first();
            self::$temp['CorporatePositionName'][$id] = $state ? $state->position_name : null;
        }
        return self::$temp['CorporatePositionName'][$id];
    }
}