<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobTimeModel;
use Illuminate\Support\Facades\Validator;

class JobTime extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    // return view('content.settings.hrm.job_time.job_time_list');

    $job = JobTimeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.hrm.job_time.job_time_list', compact('job', 'pageConfigs'));
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_time_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $job_time_name       = $request->job_time_name;
      $start_time          = $request->start_time;
      $end_time            = $request->end_time;
      $job_time_desc       = $request->job_time_desc;

      $user_id                    = $request->user()->user_id;
      $chk = JobTimeModel::where('job_time_name', ucwords($job_time_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobTimeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_time_id = "JOB-0001/" . $year;
        } else {

          $data = $category_check->job_time_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("JOB-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_time_id = $request . '/' . $year;
        }


        $add_job = new JobTimeModel();
        $add_job->job_time_id         = $job_time_id;
        $add_job->job_time_name       = Ucfirst($job_time_name);
        $add_job->start_time          = $start_time;
        $add_job->end_time            = $end_time;
        $add_job->job_time_desc       = $job_time_desc;
        $add_job->branch_id           = self::$branch_id;
        $add_job->created_by          = $user_id;
        $add_job->updated_by          = $user_id;

        $add_job->save();

        if ($add_job) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Job Time added Successfully!',
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Job Time!',
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'job time Created successfully!');
    }
  }

  public function Edit($id)
  {
    $jobtime = JobTimeModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $jobtime
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_time_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $job_time_name       = $request->job_time_name;
      $start_time          = $request->start_time;
      $end_time            = $request->end_time;
      $job_time_desc       = $request->job_time_desc;

      $upd_job =  JobTimeModel::where('sno', $id)->first();

      $chk = JobTimeModel::where('job_time_name', ucwords($job_time_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_job->job_time_name  = Ucfirst($job_time_name);
        $upd_job->start_time     = $start_time;
        $upd_job->end_time       = $end_time;
        $upd_job->job_time_desc  = $job_time_desc;
        $upd_job->update();
      }



      if ($upd_job) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  JobTimeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  JobTimeModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}