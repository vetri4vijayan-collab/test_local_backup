<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\LevelModel;

class Level extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $Level = LevelModel::where('za_level.status', '!=', 2)
      ->where('za_level.branch_id', self::$branch_id)
      ->orderBy('za_level.sno', 'desc')->get();

    // $selectedjob_positionId = $Level->isEmpty() ? null : $Level[0]->job_position_id;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.hrm.level.level_list', [
      'Level' => $Level,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $Level = LevelModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Level
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'level_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $level_name = $request->level_name;
      $level_desc = $request->level_desc;
      $user_id = $request->user()->user_id;
      $chk = LevelModel::where('level_name', ucwords($level_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Level is exist!'
        ]);
        return redirect()->back();
      } else {
        $job_position_check = LevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$job_position_check) {

          $year = substr(date("y"), -2);
          $level_id = "LV-0001/" . $year;
        } else {

          $data = $job_position_check->level_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("LV-%04d", $next_number);

          $year = substr(date("y"), -2);
          $level_id = $request . '/' . $year;
        }


        $add_job_position = new LevelModel();
        $add_job_position->level_id = $level_id;
        $add_job_position->level_name = Ucfirst($level_name);
        $add_job_position->level_desc = $level_desc;
        $add_job_position->branch_id = self::$branch_id;
        $add_job_position->created_by = $user_id;
        $add_job_position->updated_by = $user_id;

        $add_job_position->save();

        if ($add_job_position) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Level added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Level!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function edit($id)
  {
    $editjob_position = LevelModel::where('za_level.sno', $id)
      ->first();

    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $editjob_position
    ], 200);
  }
  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'level_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $level_name = $request->level_name;
      $level_desc = $request->level_desc;
      $level_id = $request->level_id;

      $upd_LevelModel = LevelModel::where('sno', $level_id)->first();

      $chk = LevelModel::where('level_name', ucwords($level_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $level_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Level is exist!'
        ]);
        return redirect()->back();
      } else {

        $upd_LevelModel->level_name = Ucfirst($level_name);
        $upd_LevelModel->level_desc = $level_desc;
        $upd_LevelModel->update();
        if ($upd_LevelModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Level Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Level!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_LevelModel = LevelModel::where('sno', $id)->first();
    $upd_LevelModel->status = 2;
    $upd_LevelModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_LevelModel = LevelModel::where('sno', $id)->first();
    $upd_LevelModel->status = $request->input('status', 0);
    $upd_LevelModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
