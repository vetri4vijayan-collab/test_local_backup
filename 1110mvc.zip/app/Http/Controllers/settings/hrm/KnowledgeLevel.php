<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\KnowledgeLevelModel;
use Illuminate\Support\Facades\Validator;

class KnowledgeLevel extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    // return view('content.settings.course.knowledge_type.knowledge_type_list');
    $level = KnowledgeLevelModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.course.knowledge_type.knowledge_type_list', compact('level', 'pageConfigs'));
  }

  public function List()
  {
    $knowledge_level = KnowledgeLevelModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $knowledge_level
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'knowledge_level_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $knowledge_level_name       = $request->knowledge_level_name;
      $bg_color                   = $request->bg_color;
      $knowledge_level_desc       = $request->knowledge_level_desc;

      $user_id                    = $request->user()->user_id;
      $chk = KnowledgeLevelModel::where('knowledge_level_name', ucwords($knowledge_level_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = KnowledgeLevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $knowledge_level_id = "KL-0001/" . $year;
        } else {

          $data = $category_check->knowledge_level_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("KL-%04d", $next_number);

          $year = substr(date("y"), -2);
          $knowledge_level_id = $request . '/' . $year;
        }


        $add_category = new KnowledgeLevelModel();
        $add_category->knowledge_level_id           = $knowledge_level_id;
        $add_category->knowledge_level_name       = Ucfirst($knowledge_level_name);
        $add_category->bg_color                   = $bg_color;
        $add_category->knowledge_level_desc       = $knowledge_level_desc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'knowledge level added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the knowledge level!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $knowledge = KnowledgeLevelModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $knowledge
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'knowledge_level_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $knowledge_level_name       = $request->knowledge_level_name;
      $bg_color                   = $request->bg_color;
      $knowledge_level_desc       = $request->knowledge_level_desc;

      $upd_CourseCategoryModel =  KnowledgeLevelModel::where('sno', $id)->first();

      $chk = KnowledgeLevelModel::where('knowledge_level_name', ucwords($knowledge_level_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->knowledge_level_name  = Ucfirst($knowledge_level_name);
        $upd_CourseCategoryModel->bg_color              = $bg_color;
        $upd_CourseCategoryModel->knowledge_level_desc  = $knowledge_level_desc;
        $upd_CourseCategoryModel->update();
      }

      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  KnowledgeLevelModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  KnowledgeLevelModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}