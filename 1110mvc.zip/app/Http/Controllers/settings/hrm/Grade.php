<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\GradeModel;

class Grade extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $Grade = GradeModel::where('za_grade.status', '!=', 2)
      ->where('za_grade.branch_id', self::$branch_id)
      ->orderBy('za_grade.sno', 'desc')->get();

    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.hrm.grade.grade_list', [
      'Grade' => $Grade,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $Grade = GradeModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Grade
    ], 200);
  }
  
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'grade_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $grade_name = $request->grade_name;
      $grade_desc = $request->grade_desc;
      $user_id = $request->user()->user_id;
      $chk = GradeModel::where('grade_name', ucwords($grade_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Grade is exist!'
        ]);
        return redirect()->back();
      } else {
        $job_position_check = GradeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$job_position_check) {

          $year = substr(date("y"), -2);
          $grade_id = "GR-0001/" . $year;
        } else {

          $data = $job_position_check->grade_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("GR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $grade_id = $request . '/' . $year;
        }


        $add_job_position = new GradeModel();
        $add_job_position->grade_id = $grade_id;
        $add_job_position->grade_name = Ucfirst($grade_name);
        $add_job_position->grade_desc = $grade_desc;
        $add_job_position->branch_id = self::$branch_id;
        $add_job_position->created_by = $user_id;
        $add_job_position->updated_by = $user_id;

        $add_job_position->save();

        if ($add_job_position) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Grade added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Grade!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function edit($id)
  {
    $editjob_position = GradeModel::where('za_grade.sno', $id)
      ->first();

    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $editjob_position
    ], 200);
  }
  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'grade_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $grade_name = $request->grade_name;
      $grade_desc = $request->grade_desc;
      $grade_id = $request->grade_id;

      $upd_GradeModel = GradeModel::where('sno', $grade_id)->first();

      $chk = GradeModel::where('grade_name', ucwords($grade_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $grade_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Grade is exist!'
        ]);
        return redirect()->back();
      } else {


        $upd_GradeModel->grade_name = Ucfirst($grade_name);
        $upd_GradeModel->grade_desc = $grade_desc;
        $upd_GradeModel->update();
        if ($upd_GradeModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Grade Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Grade!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_GradeModel = GradeModel::where('sno', $id)->first();
    $upd_GradeModel->status = 2;
    $upd_GradeModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_GradeModel = GradeModel::where('sno', $id)->first();
    $upd_GradeModel->status = $request->input('status', 0);
    $upd_GradeModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
