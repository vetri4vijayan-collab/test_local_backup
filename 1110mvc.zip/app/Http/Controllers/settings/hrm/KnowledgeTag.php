<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\KnowledgeTagModel;
use Illuminate\Support\Facades\Validator;

class KnowledgeTag extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    // return view('content.settings.hrm.knowledge_tag.knowledge_tag_list');

    $tag = KnowledgeTagModel::select('za_knowledge_tag.*', 'za_knowledge_level.knowledge_level_name', 'za_knowledge_level.sno as level_id', 'za_knowledge_level.bg_color')
      ->join('za_knowledge_level', 'za_knowledge_tag.knowledge_level_id', '=', 'za_knowledge_level.sno')
      ->where('za_knowledge_tag.status', '!=', 2)
      ->where('za_knowledge_tag.branch_id', self::$branch_id)
      ->orderBy('za_knowledge_tag.sno', 'desc')
      ->get();

    // dd($tag);
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.hrm.knowledge_tag.knowledge_tag_list', compact('tag', 'pageConfigs'));
  }
  public function List()
  {
    $tags = KnowledgeTagModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $tags
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'knowledge_tag_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'knowledge Tag Name is required'
      ]);
    } else {


      $knowledge_tag_name       = $request->knowledge_tag_name;
      $knowledge_level_id       = $request->knowledge_level_id;
      $knowledge_tag_desc       = $request->knowledge_tag_desc;

      $user_id                    = $request->user()->user_id;
      $chk = KnowledgeTagModel::where('knowledge_tag_name', ucwords($knowledge_tag_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = KnowledgeTagModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $knowledge_tag_id = "KTAG-0001/" . $year;
        } else {

          $data = $category_check->knowledge_tag_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("KTAG-%04d", $next_number);

          $year = substr(date("y"), -2);
          $knowledge_tag_id = $request . '/' . $year;
        }


        $add_category = new KnowledgeTagModel();
        $add_category->knowledge_tag_id         = $knowledge_tag_id;
        $add_category->knowledge_tag_name       = Ucfirst($knowledge_tag_name);
        $add_category->knowledge_level_id       = $knowledge_level_id;
        $add_category->knowledge_tag_desc       = $knowledge_tag_desc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'knowledge Tag added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the knowledge Tag!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $knowledge = KnowledgeTagModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $knowledge
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'knowledge_tag_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $knowledge_tag_name       = $request->knowledge_tag_name;
      $knowledge_level_id       = $request->knowledge_level_id;
      $knowledge_tag_desc       = $request->knowledge_tag_desc;

      $upd_CourseCategoryModel =  KnowledgeTagModel::where('sno', $id)->first();

      $chk = KnowledgeTagModel::where('knowledge_tag_name', ucwords($knowledge_tag_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->knowledge_tag_name  = Ucfirst($knowledge_tag_name);
        $upd_CourseCategoryModel->knowledge_level_id  = $knowledge_level_id;
        $upd_CourseCategoryModel->knowledge_tag_desc  = $knowledge_tag_desc;
        $upd_CourseCategoryModel->update();
      }



      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  KnowledgeTagModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  KnowledgeTagModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}