<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\SpecialRequirementModel;
use Carbon\Carbon;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\ManageEntityModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Support\Facades\Http;

class SpecialRequirement extends Controller
{

  //  SpecialRequirement
  public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = SpecialRequirementModel::where('za_special_requirements.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('za_special_requirements.*');
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('za_special_requirements.requirement_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('za_special_requirements.requirement_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('za_special_requirements.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'requirement_name' => $item->requirement_name,
                    'requirement_desc' => $item->requirement_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.hrm.special_requirement.special_requirement_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }


  public function List(Request $request)
  {
    
    $Department = SpecialRequirementModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

 

  public function Status($id, Request $request)
  {

    $staff =  SpecialRequirementModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Special Requirement Updated Successfully!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Special Requirement!',
        'error_msg' => 'Could not, update  Special Requirement!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_SpecialRequirementModel = SpecialRequirementModel::where('sno', $id)->first();
    $upd_SpecialRequirementModel->status = 2;
    $upd_SpecialRequirementModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'requirement_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $requirement_name = $request->requirement_name;
      $requirement_desc = $request->requirement_desc;
      $user_id = $request->user()->user_id;
      $chk = SpecialRequirementModel::where('requirement_name', $requirement_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Special Requirement Name Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = SpecialRequirementModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        $add_department = new SpecialRequirementModel();
        $add_department->requirement_name = $requirement_name;
        $add_department->requirement_desc = $requirement_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Special Requirement added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function AddNew(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'requirement_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $requirement_name = $request->requirement_name;

      $user_id = $request->user()->user_id;
      $chk = SpecialRequirementModel::where('requirement_name', $requirement_name)->where('status', '!=', 2)->first();

      if ($chk) {
        return response([
            'status' => 401,
            'message' => 'Special Requirement Name Already Exists!',
            'error_msg' => 'Special Requirement Name Already Exists!',
            'data' => null,
        ], 401);

      } else {
        $add_department = new SpecialRequirementModel();
        $add_department->requirement_name = $requirement_name;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {


            $payload=[
                'sno' => $add_department->sno,
                'company_id' => 2,
                'entity_id' => 2,
                'requirement_name' => $add_department->requirement_name ?? null,
                'requirement_desc' => $add_department->requirement_desc ?? null,
            ];
          // If category added successfully, return success response and display Toastr message
            $response = $this->dispatchWebhooks($payload, $user_id,'Add_SpecialRequirement');
            if($response){
                    $data = json_decode($response['data'], true);
                    $sno = $data['sno'] ?? null;
                    if($sno){
                        $updateData= SpecialRequirementModel::where('sno', $sno)->first();
                        $updateData->external_uuid = $sno;
                        $updateData->update();
                    }
            }
            return response([
                'status' => 200,
                'message' => 'Special Requirement added Successfully!',
                'error_msg' => null,
                'data' => null,
            ], 200);
          
        } else {
                return response([
                    'status' => 401,
                    'message' => 'Could not add the Special Requirement!',
                    'error_msg' => 'Could not add the Special Requirement!',
                    'data' => null,
                ], 401);
        }
      }

    }
  }

  public function Edit($id)
  {
    $editdepartment = SpecialRequirementModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Special Requirement not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Special Requirement fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'requirement_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $requirement_name = $request->requirement_name;
      $requirement_desc = $request->requirement_desc;
      $user_id = $request->user()->user_id;
      $chk = SpecialRequirementModel::where('requirement_name', $requirement_name)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Special Requirement Name Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = SpecialRequirementModel::where('sno', $sno)->first();
        $up_department->requirement_name = $requirement_name;
        $up_department->requirement_desc = $requirement_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Special Requirement updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

    protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
          if($webhook){
              $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => 'App\Models\SpecialRequirementModel',
                'dispatchable_id' => $broadcast['sno'],
                'message_uuid' => $broadcast['sno'],
                'payload' => json_encode($broadcast),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

           
           
            // enqueue the job
            try {
                $result = $this->sendWebhookNow($dispatch, $webhook);
              
                return $result;
                // if (!$result['success']) {
                //     // If fails, dispatch to queue
                //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                // }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
            
          }
          
  }
    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                
                return ['success' => true,'data'=>$response->body()];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            
            return ['success' => false];
        }
    }
}