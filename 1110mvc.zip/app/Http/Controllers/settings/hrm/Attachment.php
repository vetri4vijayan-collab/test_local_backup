<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AttachmentModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class Attachment extends Controller
{

    protected static $branch_id = 1;
    public function index()
    {

        $level = AttachmentModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.hrm.attachment.attachment', compact('level', 'pageConfigs'));
    }

    // public function index(Request $request)
    // {
    //     $query = AttachmentModel::where('branch_id', self::$branch_id)->where('status', '!=', 2);

    //     // Get total records before filtering
    //     $totalRecords = $query->count();

    //     // Apply filtering if necessary
    //     if ($request->has('search') && $request->input('search')['value'] != '') {
    //         $searchValue = $request->input('search')['value'];
    //         $query->where('column_name', 'LIKE', "%{$searchValue}%"); // Adjust 'column_name' as needed
    //     }

    //     // Get total records after filtering
    //     $totalFilteredRecords = $query->count();

    //     // Pagination
    //     $limit = $request->input('length'); // Number of records per page
    //     $offset = $request->input('start'); // Offset for pagination
    //     $data = $query->orderBy('sno', 'desc')->skip($offset)->take($limit)->get();

    //     // Prepare the response
    //     return response()->json([
    //         "draw" => intval($request->input('draw')),
    //         "recordsTotal" => $totalRecords,
    //         "recordsFiltered" => $totalFilteredRecords,
    //         "data" => $data // This should be an array of your records
    //     ]);
    // }
    // public function index(Request $request)
    // {
    //     if ($request->ajax()) {
    //         $query = AttachmentModel::where('branch_id', self::$branch_id)
    //             ->where('status', '!=', 2)
    //             ->orderBy('sno', 'desc');

    //         // Get total records without filtering
    //         $totalRecords = $query->count();

    //         // Apply pagination
    //         $length = $request->input('length'); // Number of records per page
    //         $start = $request->input('start'); // Offset
    //         $attachments = $query->skip($start)->take($length)->get();

    //         // Prepare data for DataTable
    //         $data = [];
    //         foreach ($attachments as $category) {
    //             $data[] = [
    //                 'iteration' => $loop->iteration,
    //                 'attachment_name' => $category->attachment_name,
    //                 'status' => $category->status,
    //                 'sno' => $category->sno,
    //                 'attachment_id' => $category->attachment_id,
    //                 'attachment_desc' => $category->attachment_desc,
    //             ];
    //         }

    //         return response()->json([
    //             "draw" => intval($request->input('draw')),
    //             "recordsTotal" => $totalRecords,
    //             "recordsFiltered" => $totalRecords, // You can adjust this if you implement filtering
    //             "data" => $data
    //         ]);
    //     }

    //     $pageConfigs = ['myLayout' => 'default'];
    //     return view('content.settings.hrm.attachment.attachment', compact('pageConfigs'));
    // }


    public function List()
    {
        $knowledge_level = AttachmentModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge_level
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'attachment_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $attachment_name       = $request->attachment_name;
            $attachment_desc       = $request->attachment_desc;

            // $user_id            = $request->user()->id;
            $user_id            = $request->user()->user_id;
            $chk = AttachmentModel::where('attachment_name', ucwords($attachment_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = AttachmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $attachment_id = "AT-0001/" . $year;
                } else {

                    $data = $category_check->attachment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf("AT-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $attachment_id = $request . '/' . $year;
                }


                $add_category = new AttachmentModel();
                $add_category->attachment_id           = $attachment_id;
                $add_category->attachment_name         = Ucfirst($attachment_name);
                $add_category->attachment_desc         = $attachment_desc;
                $add_category->branch_id              = self::$branch_id;
                $add_category->created_by              = $user_id;
                $add_category->updated_by              = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'knowledge level added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the knowledge level!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'knowledge Created successfully!');
        }
    }

    public function Edit($id)
    {
        $attachment = AttachmentModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $attachment
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'attachment_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $attachment_name       = $request->attachment_name;
            // dd($request->attachment_name);
            $attachment_desc       = $request->attachment_desc;

            $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();

            $chk = AttachmentModel::where('attachment_name', ucwords($attachment_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $upd_CourseCategoryModel->attachment_name  = Ucfirst($attachment_name);
                $upd_CourseCategoryModel->attachment_desc  = $attachment_desc;

                $upd_CourseCategoryModel->update();
                if ($upd_CourseCategoryModel) {
                    $result = response([
                        'status'    => 200,
                        'message'   => 'Successfully Updated!',
                        'error_msg' => null,
                        'data'      => null,
                    ], 200);
                } else {
                    $result = response([
                        'status'    => 401,
                        'message'   => 'Incorrect format input feilds',
                        'error_msg' => 'Incorrect format input feilds',
                        'data'      => null,
                    ], 401);
                }
            }



            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}