<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use App\Models\JobpositionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JobPosition extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $startTime = microtime(true);
    $job_position = JobpositionModel::select(
      'za_job_position.*',
      'za_department.department_name',
      'za_department.department_desc',
      'za_sub_department.sub_department_name', 
      'za_sub_department.sub_department_desc', 
      'za_sub_department.department_id', 
      'za_grade.grade_name', 
      'za_level.level_name', 
  )
  ->leftjoin('za_level', 'za_level.sno', '=', 'za_job_position.level_id')
  ->leftjoin('za_grade', 'za_grade.sno', '=',  'za_job_position.grade_id')
  ->leftjoin('za_department', 'za_department.sno', '=' , 'za_job_position.department_id',)
  ->leftjoin('za_sub_department', 'za_sub_department.sno', '=', 'za_job_position.sub_department_id')
  ->where('za_job_position.status', '!=', 2)
  ->where('za_job_position.branch_id', self::$branch_id)
  ->orderBy('za_job_position.sno', 'desc')
  ->get();

    $pageConfigs = ['myLayout' => 'default'];
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return view('content.settings.hrm.job_position.job_position',[
      'job_position' => $job_position
    ]);
  }

  public function list()
  {

    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobpositionModel::where('branch_id', self::$branch_id) ->where('sub_department_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_position_name' => 'required|max:255',

    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $job_position_name = $request->job_position_name;
      $department_id = $request->department_id;
      $sub_department_id = $request->sub_department_id;
      $grade_id = $request->grade_id;
      $level_id = $request->level_id;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;
      $productivity_score = $request->productivity_score;

      // dd($request);

      $user_id = $request->user()->user_id;
      $chk = JobpositionModel::where('job_position_name', ucwords($job_position_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Job Position has been  already created!',
        ]);
      } else {
        $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_position_id = "JP-0001/" . $year;
        } else {

          $data = $category_check->job_position_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("JP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_position_id = $request . '/' . $year;
        }

        $add_category = new JobpositionModel();
        $add_category->job_position_id = $job_position_id;
        $add_category->job_position_name = Ucfirst($job_position_name);
        $add_category->grade_id = $grade_id;
        $add_category->department_id = $department_id;
        $add_category->sub_department_id = $sub_department_id;
        $add_category->level_id = $level_id;
        $add_category->per_hour_cost = $per_hour_cost;
        $add_category->job_position_desc = $job_position_desc;
        $add_category->productivity_score = $productivity_score;
        $add_category->branch_id = self::$branch_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job position added Successfully!',
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job position!',
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $job_position = JobpositionModel::where('sno', $id)->first();

    // return $job_position;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
    ], 200);
  }


  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_position_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $job_position_name = $request->job_position_name;
      $grade_id = $request->grade_id;
      $level_id = $request->level_id;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;
      $productivity_score = $request->productivity_score;
      $department_id = $request->department_id;
      $sub_department_id = $request->sub_department_id;

      $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();

      $chk = JobpositionModel::where('job_position_name', ucwords($job_position_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_position_name = Ucfirst($job_position_name);
        $upd_CourseCategoryModel->grade_id = $grade_id;
        $upd_CourseCategoryModel->level_id = $level_id;
        $upd_CourseCategoryModel->per_hour_cost = $per_hour_cost;
        $upd_CourseCategoryModel->job_position_desc = $job_position_desc;
        $upd_CourseCategoryModel->productivity_score = $productivity_score;
        $upd_CourseCategoryModel->department_id = $department_id;
        $upd_CourseCategoryModel->sub_department_id = $sub_department_id;
        $upd_CourseCategoryModel->update();
      }


      if ($upd_CourseCategoryModel) {
        $result = response([
          'status' => 200,
          'message' => 'Successfully Updated!',
          'error_msg' => null,
          'data' => null,
        ], 200);
      } else {
        $result = response([
          'status' => 401,
          'message' => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data' => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
