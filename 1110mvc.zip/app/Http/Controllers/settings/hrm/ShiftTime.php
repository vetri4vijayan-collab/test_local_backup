<?php


namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\ShiftTimeModel;
use App\Models\BranchModel;


class ShiftTime extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    $shift_time = ShiftTimeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    return view('content.settings.hrm.shift_time.shift_time_list', [
      'shift_time' => $shift_time
    ]);;
  }
  
public function branch_list()
  {
      $branch = BranchModel::where('status',0)->get();

      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $branch
      ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_shift_time =  ShiftTimeModel::where('sno', $id)->first();
    $upd_shift_time->status = $request->input('status', 0);
    $upd_shift_time->update();
    if ($upd_shift_time) {
      return response([
        'status'    => 200,
        'message'   => 'Shift Time  Status Successfully Updated!',
        'error_msg' => 'Could not ,update  Shift Time  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Shift Time  Status!',
        'error_msg' => 'Could not ,update  Shift Time  Status!',
        'data'      => null,
      ], 200);
    }
  }


  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'shift_time_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      // If validation fails, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }

    // If validation passes
    $shift_time_name = $request->shift_time_name;
    $shift_start_time = date('H:i:s', strtotime($request->staff_st_time));
    $shift_end_time = date('H:i:s', strtotime($request->staff_ed_time));
    // dd($shift_start_time);
    $shift_lunch_start = date('H:i:s', strtotime($request->staff_lunch_st_time));
    $shift_sunday = $request->sunday_incd_chk ?? null;
    $shift_lunch_end = date('H:i:s', strtotime($request->staff_lunch_ed_time));
    // $shift_weekoff_day = $request->wk_off_day_add;
    // $shift_weekoff = $request->no_week_off_day;
    $shift_time_desc = $request->shift_time_desc;
    $user_id = $request->user()->user_id;
    $branch_assign_id = $request->branch_id;
    // return $shift_lunch_end;


    // Check if the category already exists
    $chk = ShiftTimeModel::where('shift_time_name', ucwords($shift_time_name))
      ->where('branch_id', self::$branch_id)
      ->first();

    if ($chk) {
      // If category already exists, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Shift Time has already been created!'
      ]);
    } else {
      // Generate a unique category ID
      $category_check = ShiftTimeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$category_check) {
        $year = substr(date('y'), -2);
        $shift_time_id = 'ST-0001/' . $year;
      } else {
        $data = $category_check->shift_time_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $requestId = sprintf('MC-%04d', $next_number);
        $year = substr(date('y'), -2);
        $shift_time_id = $requestId . '/' . $year;
      }

      // Add the category to the database
      $add = new ShiftTimeModel();
      $add->shift_time_id = $shift_time_id;
      $add->shift_time_name = ucfirst($shift_time_name);
      $add->shift_start_time = $shift_start_time;
      $add->shift_end_time = $shift_end_time;
      $add->shift_lunch_start = $shift_lunch_start;
      $add->shift_lunch_end = $shift_lunch_end;
      $add->shift_sunday = $shift_sunday;
       $add->branch_assign_id = json_encode($branch_assign_id);
      // $add->shift_weekoff_day = $shift_weekoff_day;
      // $add->shift_weekoff = $shift_weekoff;
      $add->shift_time_desc = $shift_time_desc;
      $add->branch_id = self::$branch_id;
      $add->created_by = $user_id;
      $add->updated_by = $user_id;
      // return $add;  
      $add->save();

      if ($add) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Shift Time added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Shift Time!'
        ]);
      }
    }

    return redirect()->back();
  }

  public function Edit($id)
  {
    $ShiftTime = ShiftTimeModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $ShiftTime
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'shift_time_name_edit' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      // If validation passes
      $id = $request->edit_sno;
      $shift_time_name = $request->shift_time_name_edit;
      $shift_start_time = date('H:i:s', strtotime($request->staff_st_time_edit));
      $shift_end_time = date('H:i:s', strtotime($request->staff_ed_time_edit));
      $shift_lunch_start = date('H:i:s', strtotime($request->staff_lunch_st_time_edit));
      $shift_sunday = $request->sunday_incd_chk_edit ?? null;
      $shift_lunch_end = date('H:i:s', strtotime($request->staff_lunch_ed_time_edit));
      // $shift_weekoff_day = $request->wk_off_day_edit;
      // $shift_weekoff = $request->no_week_off_day_edit;
      $shift_time_desc = $request->shift_time_desc_edit;
      $user_id = $request->user()->user_id;
      $branch_assign_id = $request->branch_id_edit;

      $upd_ShiftTimeModel =  ShiftTimeModel::where('sno', $id)->first();

      $chk = ShiftTimeModel::where('shift_time_name', ucwords($shift_time_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_ShiftTimeModel->shift_time_name  = Ucfirst($shift_time_name);
        $upd_ShiftTimeModel->shift_start_time = $shift_start_time;
        $upd_ShiftTimeModel->shift_end_time = $shift_end_time;
        $upd_ShiftTimeModel->shift_lunch_start = $shift_lunch_start;
        $upd_ShiftTimeModel->shift_lunch_end = $shift_lunch_end;
        $upd_ShiftTimeModel->shift_sunday = $shift_sunday;
        // $upd_ShiftTimeModel->shift_weekoff_day = $shift_weekoff_day;
        // $upd_ShiftTimeModel->shift_weekoff = $shift_weekoff;
        $upd_ShiftTimeModel->shift_time_desc = $shift_time_desc;
        $upd_ShiftTimeModel->branch_id = self::$branch_id;
        $upd_ShiftTimeModel->created_by =  $request->user()->user_id;
        $upd_ShiftTimeModel->updated_by = $request->user()->user_id;
         $upd_ShiftTimeModel->branch_assign_id = json_encode($branch_assign_id);

        $upd_ShiftTimeModel->update();
        if ($upd_ShiftTimeModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Shift Time updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Shift Time!'
          ]);
        }
      }

      return redirect()->back();
    }
  }


  public function Delete($id)
  {
    $upd_shift_time =  ShiftTimeModel::where('sno', $id)->first();
    $upd_shift_time->status  = 2;
    $upd_shift_time->Update();
    if ($upd_shift_time) {
      return response([
        'status'    => 200,
        'message'   => 'Shift Time Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Shift Time!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
}
