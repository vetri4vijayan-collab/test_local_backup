<?php

namespace App\Http\Controllers\settings\business_goal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessGoalSetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class BusinessGoal extends Controller
{


  public function index()
    {
        return view('content.settings.business.goal');
    }

   public function getBusinessGoals(Request $request)
    {
        $goal = BusinessGoalSetModel::where('branch_id',$request->branch_id)->first();
        return response()->json(['status' => 200, 'data' => $goal]);
    }

    public function updateBusinessGoals(Request $request)
    {
        $validatedData = $request->validate([
            'branch_id' => 'required|integer',
            'conversion' => 'nullable|numeric',
            'conversion_check' => 'nullable|boolean',
            'target' => 'nullable|numeric',
            'target_check' => 'nullable|boolean',
        ]);

        // Ensure unchecked checkboxes are set to 0
        foreach ($validatedData as $key => $value) {
            if (strpos($key, '_check') !== false && $value === null) {
                $validatedData[$key] = 0;
            }
        }

        $goal = BusinessGoalSetModel::updateOrCreate(
            ['branch_id' => $validatedData['branch_id']], // Search condition
            array_merge(
                $validatedData,
                [
                    'updated_by' => auth()->id(),
                    'created_by' => BusinessGoalSetModel::where('branch_id', $validatedData['branch_id'])
                        ->exists()
                        ? BusinessGoalSetModel::where('branch_id', $validatedData['branch_id'])
                            ->value('created_by')
                        : auth()->id(), // Keep existing created_by if record exists
                ]
            )
        );

        return response()->json(['status' => 200, 'message' => 'Business goals updated successfully', 'data' => $goal]);
    }

}