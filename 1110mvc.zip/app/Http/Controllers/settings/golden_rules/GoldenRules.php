<?php

namespace App\Http\Controllers\settings\golden_rules;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoldenRuleModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class GoldenRules extends Controller
{


  public function index()
  {

    return view('content.settings.golden_rules_setting.golden_rules');

  }
    // Fetch Rules
   public function FetchGoldenRules()
  {
      // fetch the first record (sno = 1)
      $rule = GoldenRuleModel::first();
      return response()->json($rule);
  }

    // Update Rules
  public function goldenrulescreateupdate (Request $request, $id)
{
    $rule = GoldenRuleModel::updateOrCreate(
        ['sno' => $id], // match by primary key
        array_merge(
            $request->all(),
            [
                'updated_by' => $request->user()->user_id ?? 1,
                'created_by' =>     $user_id = $request->user()->user_id  ?? 1 // set if new
            ]
        )
    );

    return response()->json([
        'success' => true,
        'message' => $rule->wasRecentlyCreated
            ? 'Golden Rules created successfully'
            : 'Golden Rules updated successfully',
        'data' => $rule
    ]);
}










}
