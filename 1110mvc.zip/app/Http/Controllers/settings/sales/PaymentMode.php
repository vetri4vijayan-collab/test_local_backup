<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentModeModel;
use Illuminate\Support\Facades\Validator;

class PaymentMode extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {

        $Paymentmode = PaymentModeModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.sales.payment_mode.payment_mode_list', [
            'Paymentmode' => $Paymentmode,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $Paymentmode = PaymentModeModel::where('status', 0)->where('branch_id', self::$branch_id)
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Paymentmode
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'paymentmode_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $paymentmode_name = $request->paymentmode_name;
            $paymentmode_desc = $request->paymentmode_desc;
            $user_id = $request->user()->user_id;
            $chk = PaymentModeModel::where('paymentmode_name', ucwords($paymentmode_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Payment Mode is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = PaymentModeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $paymentmode_id = 'PM-0001/' . $year;
                } else {

                    $data = $category_check->paymentmode_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('PM-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $paymentmode_id = $request . '/' . $year;
                }

                $add_paymentmode = new PaymentModeModel();
                $add_paymentmode->paymentmode_id = $paymentmode_id;
                $add_paymentmode->paymentmode_name = Ucfirst($paymentmode_name);
                $add_paymentmode->paymentmode_desc = $paymentmode_desc;
                $add_paymentmode->branch_id = self::$branch_id;
                $add_paymentmode->created_by = $user_id;
                $add_paymentmode->updated_by = $user_id;

                $add_paymentmode->save();

                if ($add_paymentmode) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Payment Mode added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payment Mode!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editpaymentmode = PaymentModeModel::where('sno', $id)->first();

        return view('content.settings.sales.payment_mode.payment_mode_list', [
            'editpaymentmode' => $editpaymentmode,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'paymentmode_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $paymentmode_name = $request->paymentmode_name;
            $paymentmode_desc = $request->paymentmode_desc;
            $paymentmode_id = $request->paymentmode_id;

            $upd_PaymentModeModel = PaymentModeModel::where('sno', $paymentmode_id)->first();

            $chk = PaymentModeModel::where('paymentmode_name', ucwords($paymentmode_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $paymentmode_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Payment Mode is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_PaymentModeModel->paymentmode_name = Ucfirst($paymentmode_name);
                $upd_PaymentModeModel->paymentmode_desc = $paymentmode_desc;
                $upd_PaymentModeModel->update();

                if ($upd_PaymentModeModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Payment Mode Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Payment Mode!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_PaymentModeModel = PaymentModeModel::where('sno', $id)->first();
        $upd_PaymentModeModel->status = 2;
        $upd_PaymentModeModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_PaymentModeModel = PaymentModeModel::where('sno', $id)->first();
        $upd_PaymentModeModel->status = $request->input('status', 0);
        $upd_PaymentModeModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
