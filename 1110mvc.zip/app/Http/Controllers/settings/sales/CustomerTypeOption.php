<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CourseTypeOptionModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class CustomerTypeOption extends Controller
{
    public function index()
    {

        $option = CourseTypeOptionModel::select(
            'za_customer_type.customer_type_name',
            'za_customer_type.sno as customer_type_id',
            'za_customer_type_option.sno as customer_type_option_id',
            'za_customer_type_option.cus_type_opt_id',
            'za_customer_type_option.field_name',
            'za_customer_type_option.field_value',
            'za_customer_type_option.field_option',
            'za_customer_type_option.is_depends',
            'za_customer_type_option.depends_on',
            'za_customer_type_option.is_mandatory',
            'za_customer_type_option.created_by',
            'za_customer_type_option.created_at',
            'za_customer_type_option.updated_by',
            'za_customer_type_option.updated_at',
            'za_customer_type_option.status'
        )
            ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
            ->where('za_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('za_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name . '-' . $item->status;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            return [
                'customer_type_id' => $firstItem->customer_type_id,
                'cus_type_opt_id' => $firstItem->cus_type_opt_id,
                'customer_type_name' => $firstItem->customer_type_name,
                'status' => $firstItem->status,
                'customer_type_option_id' => $items->pluck('customer_type_option_id')->implode(','),
                'field_name' => $items->pluck('field_name')->implode(','),
                'field_value' => $items->pluck('field_value')->implode(','),
                'field_option' => $items->pluck('field_option')->map(function ($option) {
                    return json_decode($option);
                })->toArray(),
                'is_depends' => $items->pluck('is_depends')->implode(','),
                'depends_on' => $items->pluck('depends_on')->implode(','),
                'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
            ];
        })->values();





        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.sales.customer_option.customer_option', compact('result', 'pageConfigs'));


        // return view('content.settings.sales.customer_option.customer_option');
    }
    public function AddIndex()
    {

        // $level = CourseTypeOptionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // $pageConfigs = ['myLayout' => 'default'];
        // return view('content.settings.sales.customer_option.customer_option', compact('level', 'pageConfigs'));
        return view('content.settings.sales.customer_option.customer_option_add');
    }
    public function EditIndex()
    {

        // $level = CourseTypeOptionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // $pageConfigs = ['myLayout' => 'default'];
        // return view('content.settings.sales.customer_option.customer_option', compact('level', 'pageConfigs'));
        return view('content.settings.sales.customer_option.customer_option_edit');
    }

    // public function List()
    // {

    //     $option = CourseTypeOptionModel::select(
    //         'za_customer_type.customer_type_name',
    //         'za_customer_type.sno as customer_type_id',
    //         'za_customer_type_option.cus_type_opt_id',
    //         'za_customer_type_option.field_name',
    //         'za_customer_type_option.field_value',
    //         'za_customer_type_option.field_option',
    //         'za_customer_type_option.is_depends',
    //         'za_customer_type_option.depends_on',
    //         'za_customer_type_option.is_mandatory',
    //         'za_customer_type_option.created_by',
    //         'za_customer_type_option.created_at',
    //         'za_customer_type_option.updated_by',
    //         'za_customer_type_option.updated_at',
    //         'za_customer_type_option.status'
    //     )
    //         ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
    //         ->where('za_customer_type_option.status', 0) // Assuming status check for active records
    //         ->orderBy('za_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
    //         ->get();

    //     $grouped = $option->groupBy(['customer_type_id', 'cus_type_opt_id', 'customer_type_name']);

    //     $result = $grouped->map(function ($items, $key) {
    //         $firstItem = $items->first();

    //         return [
    //             'customer_type_id' => $firstItem->customer_type_id,
    //             'cus_type_opt_id' => $firstItem->cus_type_opt_id,
    //             'customer_type_name' => $firstItem->customer_type_name,
    //             'field_name' => $items->pluck('field_name')->implode(','),
    //             'field_value' => $items->pluck('field_value')->implode(','),
    //             'field_option' => $items->pluck('field_option')->map(function ($option) {
    //                 return json_decode($option);
    //             }),
    //             'is_depends' => $items->pluck('is_depends')->implode(','),
    //             'depends_on' => $items->pluck('depends_on')->implode(','),
    //             'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
    //         ];
    //     })->values();

    //     // return response()->json($result);


    //     return  response([
    //         'status'    => 200,
    //         'message'   => null,
    //         'error_msg' => null,
    //         'data'      => $result
    //     ], 200);
    // }
    // public function ListDisplay(Request $request)
    // {
    //     $customer_type_id = $request->customer_type_id;
    //     $option = CourseTypeOptionModel::select(
    //         'za_customer_type.customer_type_name',
    //         'za_customer_type_option.sno as customer_type_option_id',
    //         'za_customer_type.sno as customer_type_id',
    //         'za_customer_type_option.cus_type_opt_id',
    //         'za_customer_type_option.field_name',
    //         'za_customer_type_option.field_value',
    //         'za_customer_type_option.field_option',
    //         'za_customer_type_option.is_depends',
    //         'za_customer_type_option.depends_on',
    //         'za_customer_type_option.is_mandatory',
    //         'za_customer_type_option.created_by',
    //         'za_customer_type_option.created_at',
    //         'za_customer_type_option.updated_by',
    //         'za_customer_type_option.updated_at',
    //         'za_customer_type_option.status'
    //     )
    //         ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
    //         ->where('za_customer_type_option.customer_type_id', $customer_type_id)
    //         ->where('za_customer_type_option.status', 0)
    //         // Assuming status check for active records
    //         // ->orderBy('za_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
    //         ->get();

    //     $grouped = $option->groupBy(function ($item) {
    //         return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
    //     });

    //     $result = $grouped->map(function ($items) {
    //         $firstItem = $items->first();

    //         return [
    //             'customer_type_id' => $firstItem->customer_type_id,
    //             'cus_type_opt_id' => $firstItem->cus_type_opt_id,
    //             'customer_type_name' => $firstItem->customer_type_name,
    //             'customer_type_option_id' => $items->pluck('customer_type_option_id')->implode(','),
    //             'field_name' => $items->pluck('field_name')->implode(','),
    //             'field_value' => $items->pluck('field_value')->implode(','),
    //             'field_option' => $items->pluck('field_option')->map(function ($option) {
    //                 return json_decode($option);
    //             })->toArray(),
    //             'is_depends' => $items->pluck('is_depends')->implode(','),
    //             'depends_on' => $items->pluck('depends_on')->implode(','),
    //             'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
    //         ];
    //     })->values();

    //     return response()->json([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $result
    //     ], 200);
    // }
    public function ListDisplay($id, Request $request)
    {
        $customer_type_id = $id;

        $options = CourseTypeOptionModel::select(
            'za_customer_type.customer_type_name',
            'za_customer_type_option.sno as customer_type_option_id',
            'za_customer_type.sno as customer_type_id',
            'za_customer_type_option.cus_type_opt_id',
            'za_customer_type_option.field_name',
            'za_customer_type_option.field_value',
            'za_customer_type_option.field_option',
            'za_customer_type_option.is_depends',
            'za_customer_type_option.depends_on',
            'za_customer_type_option.is_mandatory',
            'za_customer_type_option.created_by',
            'za_customer_type_option.created_at',
            'za_customer_type_option.updated_by',
            'za_customer_type_option.updated_at',
            'za_customer_type_option.status'
        )
            ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
            ->where('za_customer_type_option.customer_type_id', $customer_type_id)
            ->where('za_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('za_customer_type_option.sno', 'asc') // Order by sno ascending to maintain order
            ->get();

        $result = $options->map(function ($item) {
            // Process dependencies
            $dependsOnArray = $item->depends_on ? json_decode($item->depends_on, true) : [];

            return [
                'customer_type_id' => $item->customer_type_id,
                'cus_type_opt_id' => $item->cus_type_opt_id,
                'customer_type_name' => $item->customer_type_name,
                'customer_type_option_id' => $item->customer_type_option_id,
                'field_name' => $item->field_name,
                'field_value' => $item->field_value,
                'field_option' => $item->field_option ? json_decode($item->field_option, true) : [],
                'is_depends' => $item->is_depends,
                'depends_on' => $dependsOnArray,
                'is_mandatory' => $item->is_mandatory,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }


    public function List()
    {
        $option = CourseTypeOptionModel::select(
            'za_customer_type.customer_type_name',
            'za_customer_type_option.sno as customer_type_option_id',
            'za_customer_type.sno as customer_type_id',
            'za_customer_type_option.cus_type_opt_id',
            'za_customer_type_option.field_name',
            'za_customer_type_option.field_value',
            'za_customer_type_option.field_option',
            'za_customer_type_option.is_depends',
            'za_customer_type_option.depends_on',
            'za_customer_type_option.is_mandatory',
            'za_customer_type_option.created_by',
            'za_customer_type_option.created_at',
            'za_customer_type_option.updated_by',
            'za_customer_type_option.updated_at',
            'za_customer_type_option.status'
        )
            ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
            ->where('za_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('za_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            return [
                'customer_type_id' => $firstItem->customer_type_id,
                'cus_type_opt_id' => $firstItem->cus_type_opt_id,
                'customer_type_name' => $firstItem->customer_type_name,
                'customer_type_option_id' => $items->pluck('customer_type_option_id')->implode(','),
                'field_name' => $items->pluck('field_name')->implode(','),
                'field_value' => $items->pluck('field_value')->implode(','),
                'field_option' => $items->pluck('field_option')->map(function ($option) {
                    return json_decode($option);
                })->toArray(),
                'is_depends' => $items->pluck('is_depends')->implode(','),
                'depends_on' => $items->pluck('depends_on')->implode(','),
                'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }
    // public function View($id)
    // {

    //     $cus_ids = explode(',', $id);

    //     // Get the first value from the array
    //     $cus_type_opt_id = $cus_ids[0];

    //     $editcategory = CourseTypeOptionModel::where('sno', $cus_type_opt_id)->first();
    //     $option = CourseTypeOptionModel::select(
    //         'za_customer_type.customer_type_name',
    //         'za_customer_type.sno as customer_type_id',
    //         'za_customer_type_option.cus_type_opt_id',
    //         'za_customer_type_option.field_name',
    //         'za_customer_type_option.field_value',
    //         'za_customer_type_option.field_option',
    //         'za_customer_type_option.is_depends',
    //         'za_customer_type_option.depends_on',
    //         'za_customer_type_option.is_mandatory',
    //         'za_customer_type_option.created_by',
    //         'za_customer_type_option.created_at',
    //         'za_customer_type_option.updated_by',
    //         'za_customer_type_option.updated_at',
    //         'za_customer_type_option.status'
    //     )
    //         ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
    //         ->where('za_customer_type_option.cus_type_opt_id', $editcategory->cus_type_opt_id)
    //         ->where('za_customer_type_option.status', 0) // Assuming status check for active records
    //         ->orderBy('za_customer_type_option.sno', 'asc') // Order by sno descending to get the latest rows
    //         ->get();

    //     $grouped = $option->groupBy(function ($item) {
    //         return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
    //     });

    //     $result = $grouped->map(function ($items) {
    //         $firstItem = $items->first();

    //         return [
    //             'customer_type_id' => $firstItem->customer_type_id,
    //             'cus_type_opt_id' => $firstItem->cus_type_opt_id,
    //             'customer_type_name' => $firstItem->customer_type_name,
    //             'field_name' => $items->pluck('field_name')->implode(','),
    //             'field_value' => $items->pluck('field_value')->implode(','),
    //             'field_option' => $items->pluck('field_option')->map(function ($option) {
    //                 return json_decode($option);
    //             })->toArray(),
    //             'is_depends' => $items->pluck('is_depends')->implode(','),
    //             'depends_on' => $items->pluck('depends_on')->implode(','),
    //             'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
    //         ];
    //     })->values();

    //     return response()->json([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $result
    //     ], 200);
    // }
    public function View($id)
    {
        $cus_ids = explode(',', $id);

        // Get the first value from the array
        $cus_type_opt_id = $cus_ids[0];

        $editcategory = CourseTypeOptionModel::where('sno', $cus_type_opt_id)->first();
        $option = CourseTypeOptionModel::select(
            'za_customer_type.customer_type_name',
            'za_customer_type.sno as customer_type_id',
            'za_customer_type_option.cus_type_opt_id',
            'za_customer_type_option.field_name',
            'za_customer_type_option.field_value',
            'za_customer_type_option.field_option',
            'za_customer_type_option.is_depends',
            'za_customer_type_option.depends_on',
            'za_customer_type_option.is_mandatory',
            'za_customer_type_option.created_by',
            'za_customer_type_option.created_at',
            'za_customer_type_option.updated_by',
            'za_customer_type_option.updated_at',
            'za_customer_type_option.status'
        )
            ->join('za_customer_type', 'za_customer_type_option.customer_type_id', '=', 'za_customer_type.sno')
            ->where('za_customer_type_option.cus_type_opt_id', $editcategory->cus_type_opt_id)
            ->where('za_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('za_customer_type_option.sno', 'asc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            $fieldOptions = $items->pluck('field_option')->map(function ($option) {
                return json_decode($option);
            })->toArray();

            return [
                'customer_type_name' => $firstItem->customer_type_name,
                'fields' => $items->map(function ($item) {
                    return [
                        'field_name' => $item->field_name,
                        'field_value' => $item->field_value,
                        'field_option' => json_decode($item->field_option, true),
                        'is_depends' => $item->is_depends,
                        'depends_on' => $item->depends_on,
                        'is_mandatory' => $item->is_mandatory,
                    ];
                })->toArray()
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }



    // public function Add(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'customer_type_id' => 'required|max:255',
    //         'label_names' => 'required|array',
    //         'label_values' => 'required|array',
    //         'options' => 'required|array',
    //         'options.*.*.label' => 'nullable', // Allow label to be nullable
    //     ]);

    //     if ($validator->fails()) {
    //         session()->flash('toastr', [
    //             'type' => 'error',
    //             'message' => 'Incorrect format input fields!'
    //         ]);
    //         return redirect()->back()->withErrors($validator)->withInput();
    //     } else {
    //         $customer_type_id = $request->customer_type_id;
    //         $user_id = 1; // Assuming user ID is 1 for simplicity
    //         $cus_type_opt_id = $this->generateCustomerTypeOptionId();

    //         $allOptions = [];
    //         // Iterate through label names and values
    //         foreach ($request->label_names as $index => $label_name) {
    //             $field_name = ucfirst($label_name);
    //             $field_value = $request->label_values[$index];
    //             // $field_option = json_encode($request->options[$index]);
    //             $field_options = [];


    //             foreach ($request->options[$index] as $optionIndex => $option) {
    //                 if (!empty($option['label'])) {
    //                     $option_label = $option['label'];
    //                     $option_value = $optionIndex;
    //                     $allOptions[] = $option_value;

    //                     $field_options[] = [
    //                         'value' => $option_value,
    //                         'label' => $option_label,
    //                     ];
    //                 }
    //                 // else {
    //                 //     $field_options[] = null;
    //                 // }
    //             }
    //             // print_r($field_options);
    //             // exit;
    //             $is_depends = isset($request->depends[$index]) ? 1 : 0;
    //             $is_mandatory = isset($request->mandatory[$index]) ? 1 : 0;

    //             $add_category = new CourseTypeOptionModel();
    //             $add_category->cus_type_opt_id = $cus_type_opt_id;
    //             $add_category->customer_type_id = $customer_type_id;
    //             $add_category->field_name = $field_name;
    //             $add_category->field_value = $field_value;
    //             $add_category->field_option =  empty($field_options) ? null : json_encode($field_options);
    //             $add_category->is_depends = $is_depends;
    //             $add_category->is_mandatory = $is_mandatory;
    //             $add_category->created_by = $user_id;
    //             $add_category->updated_by = $user_id;


    //             // if ($is_depends) {
    //             //     $add_category->depends_on = $request->depends_checkbox[$index];

    //             // }
    //             if ($is_depends) {
    //                 $dependency_value = $request->depends_checkbox[$index];
    //                 $add_category->depends_on = json_encode([['value' => '', 'label' => $dependency_value]]);
    //             }
    //             // return $add_category;
    //             print_r($add_category->depends_on);
    //             exit;
    //             // $add_category->save();
    //         }

    //         session()->flash('toastr', [
    //             'type' => 'success',
    //             'message' => 'Customer Type Option added Successfully!'
    //         ]);

    //         return redirect()->view('content.settings.sales.customer_option.customer_option');
    //     }
    // }
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_type_id' => 'required|max:255',
            'label_names' => 'required|array',
            'label_values' => 'required|array',
            'options' => 'required|array',
            'options.*.*.label' => 'nullable', // Allow label to be nullable
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields!'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            $customer_type_id = $request->customer_type_id;
            $user_id = $request->user()->user_id; // Assuming user ID is 1 for simplicity
            $cus_type_opt_id = $this->generateCustomerTypeOptionId();

            $allOptions = [];
            // Iterate through label names and values
            foreach ($request->label_names as $index => $label_name) {
                $field_name = ucfirst($label_name);
                $field_value = $request->label_values[$index];
                $field_options = [];

                foreach ($request->options[$index] as $optionIndex => $option) {
                    if (!empty($option['label'])) {
                        $option_label = $option['label'];
                        $option_value = $optionIndex;
                        $allOptions[] = $option_value;

                        $field_options[] = [
                            'value' => $option_value,
                            'label' => $option_label,
                        ];
                    }
                }

                $is_depends = isset($request->depends[$index]) ? 1 : 0;
                $is_mandatory = isset($request->mandatory[$index]) ? 1 : 0;

                $add_category = new CourseTypeOptionModel();
                $add_category->cus_type_opt_id = $cus_type_opt_id;
                $add_category->customer_type_id = $customer_type_id;
                $add_category->field_name = $field_name;
                $add_category->field_value = $field_value;
                $add_category->field_option = empty($field_options) ? null : json_encode($field_options);
                $add_category->is_depends = $is_depends;
                $add_category->is_mandatory = $is_mandatory;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                // if ($is_depends && isset($request->depends_checkbox[$index])) {
                //     $dependency_label = $request->depends_checkbox[$index];
                //     $dependency_value = '';

                //     // Debug print
                //     // print_r($request->options[$index]);
                //     // exit;

                //     // Find the option value that matches the dependency label
                //     foreach ($request->options as $optIndex => $optionGroup) {
                //         foreach ($optionGroup as $option) {
                //             if ($option['label'] == $dependency_label) {
                //                 $dependency_value = $optIndex;
                //                 break;
                //             }
                //         }
                //         if ($dependency_value !== '') {
                //             break;
                //         }
                //     }

                //     $add_category->depends_on = json_encode([['value' => $dependency_value, 'label' => $dependency_label]]);
                // }
                if ($is_depends && isset($request->depends_checkbox[$index])) {
                    $dependency_label = $request->depends_checkbox[$index];
                    $dependency_value = '';

                    // Iterate through label names and values to find the matching option
                    foreach ($request->label_names as $optIndex => $label_name) {
                        foreach ($request->options[$optIndex] as $optionIndex => $option) {
                            if ($option['label'] == $dependency_label) {
                                $dependency_value = $optionIndex;
                                break 2; // Exit both foreach loops once match is found
                            }
                        }
                    }

                    // Construct depends_on as JSON array
                    $depends_on = [];
                    if ($dependency_value !== '') {
                        $depends_on[] = [
                            'value' => $dependency_value,
                            'label' => $dependency_label,
                        ];
                    }

                    $add_category->depends_on = json_encode($depends_on);
                }


                $add_category->save();
            }

            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Customer Type Option added Successfully!'
            ]);

            return redirect()->route('settings-sales-customerlist');
        }
    }

    private function generateCustomerTypeOptionId()
    {
        $latestRecord = CourseTypeOptionModel::orderBy('sno', 'desc')->first();

        if (!$latestRecord) {
            $year = substr(date("y"), -2);
            $cus_type_opt_id = "CTO-0001/" . $year;
        } else {
            $latestId = $latestRecord->cus_type_opt_id;
            $year = substr(date("y"), -2);

            // Extract numeric part from the latest ID
            preg_match('/CTO-(\d{4})\/\d{2}/', $latestId, $matches);
            $nextNumber = intval($matches[1]) + 1;

            // Format the new ID
            $newId = sprintf("CTO-%04d", $nextNumber);
            $cus_type_opt_id = $newId . '/' . $year;
        }

        return $cus_type_opt_id;
    }


    public function Edit($id)
    {
        $customer_type = CourseTypeOptionModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $customer_type
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {

            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input feilds!'
            ]);
        } else {


            $customer_type_name       = $request->customer_type_name;
            $customer_type_desc       = $request->customer_type_desc;

            $upd_CourseCategoryModel =  CourseTypeOptionModel::where('sno', $id)->first();

            $chk = CourseTypeOptionModel::where('customer_type_name', ucwords($customer_type_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already created!'
                    ]);
                } else {
                }
            }
            $upd_CourseCategoryModel->customer_type_name  = Ucfirst($customer_type_name);
            $upd_CourseCategoryModel->customer_type_desc  = $customer_type_desc;
            $upd_CourseCategoryModel->update();


            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  CourseTypeOptionModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  CourseTypeOptionModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}