<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadQuestionModel;
use Illuminate\Support\Facades\Validator;

class LeadQuestion extends Controller
{
  public function Index()
  {

    $quest = LeadQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // dd($quest);
    // dd($quest);
    return view('content.settings.sales.lead_question.lead_question_list', compact('quest', 'pageConfigs'));

    // return view('content.settings.sales.lead_question.lead_question_list');
  }
  public function LeadQuestionAdd()
  {
    return view('content.settings.sales.lead_question.lead_question_add');
  }
  public function LeadQuestionEdit()
  {
    return view('content.settings.sales.lead_question.lead_question_edit');
  }

  // public function lead_question_list()
  // {
  //   return view('content.settings.sales.lead_question.lead_question_list');
  // }

  // public function Add(Request $request)
  // {

  //   $validator = Validator::make($request->all(), [
  //     'lead_question_name' => 'required|max:255'
  //   ]);
  //   if ($validator->fails()) {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Lead Question Name is required!'
  //     ]);
  //   } else {




  //     // $lead_question_name       = $request->question;
  //     // $lead_question_type       = $request->question_type;
  //     // $lead_question_option     = json_encode($request->option_value_checkbox);
  //     $lead_question_name = $request->question[0];
  //     $lead_question_type = $request->question_type[0];

  //     // Handle different types of questions and their options and scores
  //     $lead_question_option = [];
  //     switch ($lead_question_type) {
  //       case 'text_field':
  //         // Handle text field type
  //         $lead_question_option = [
  //           'value' => $request->option_value_text_field[0],
  //           'score' => $request->option_score_text_field[0]
  //         ];
  //         break;
  //       case 'checkbox':
  //         // Handle checkbox type
  //         $lead_question_option = [
  //           'value' => $request->option_value_checkbox[0],
  //           'score' => $request->option_score_checkbox[0]
  //         ];
  //         break;
  //         // Add cases for other question types as needed
  //       default:
  //         break;
  //     }

  //     // Convert option to JSON
  //     $lead_question_option = json_encode($lead_question_option);
  //     $user_id                    = 1;
  //     $chk = LeadQuestionModel::where('lead_question_name', ucwords($lead_question_name))->where('status', '!=', 2)->first();

  //     if ($chk) {

  //       session()->flash('toastr', [
  //         'type' => 'error',
  //         'message' => 'Name has been  already created!'
  //       ]);
  //     } else {

  //       $add_category = new LeadQuestionModel();
  //       $add_category->lead_question_name       = Ucfirst($lead_question_name);
  //       $add_category->lead_question_type       = $lead_question_type;
  //       $add_category->lead_question_option       = $lead_question_option;
  //       $add_category->created_by           = $user_id;
  //       $add_category->updated_by           = $user_id;

  //       $add_category->save();
  //     }
  //     return redirect()->back();
  //     // return redirect('content.settings.sales.lead_question.lead_question_list')->back()->with('success', 'Lead Type Created successfully!');
  //   }
  // }

  public function List()
  {
    $leadquestion = LeadQuestionModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $leadquestion
    ], 200);
  }

  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'question.*' => 'required|max:255', // '*' indicates an array of questions
      'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
      // Add validation rules for option fields if needed
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Lead Question Name is required!'
      ]);
      return redirect()->back();
    }

    $user_id = $request->user()->user_id; // You should set this to the currently authenticated user ID

    foreach ($request->input('question') as $key => $lead_question_name) {
      $lead_question_type = $request->input('question_type.' . $key);
      // return $lead_question_type;
      // Initialize options array
      $lead_question_option = [];

      switch ($lead_question_type) {
        case 'checkbox':
        case 'radio_button':
        case 'list_box':
          // Get options and scores for the current question
          $options_key = 'option_value_' . $lead_question_type . '_' . $key;
          $scores_key = 'option_score_' . $lead_question_type . '_' . $key;

          $options = $request->input($options_key, []);
          $scores = $request->input($scores_key, []);

          $options_array = [];
          foreach ($options as $option_key => $value) {
            if ($value !== '') {
              $options_array[] = [
                'value' => $value,
                'score' => $scores[$option_key] ?? null,
              ];
            }
          }

          $lead_question_option = json_encode($options_array); // Convert options to JSON
          break;
        case 'text_field':
          // No options needed for text_field questions
          $lead_question_option = null;
          break;
        default:
          break;
      }

      $chk = LeadQuestionModel::where('lead_question_name', ucwords($lead_question_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
        continue; // Skip processing this question and move to the next one
      }

      $add_category = new LeadQuestionModel();
      $add_category->lead_question_name = ucfirst($lead_question_name);
      $add_category->lead_question_type = $lead_question_type;
      $add_category->lead_question_option = $lead_question_option;
      $add_category->created_by = $user_id;
      $add_category->updated_by = $user_id;
      // return $add_category;
      $add_category->save();

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Lead Question added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Lead Question!'
        ]);
      }
    }

    return redirect()->route('settings-sales-lead_question_list');
  }

  public function Edit($id)
  {
    $editcategory = LeadQuestionModel::where('sno', $id)->first();

    return view('content.settings.sales.lead_type.lead_type_list', [
      'editcategory' => $editcategory,
      'id' => $id,
    ]);
  }
  public function LeadQuestion_edit($id)
  {

    // return $id;
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $lead_question = LeadQuestionModel::where('status', '!=', 2)
      ->where('sno', $decryptedValue)
      // ->orderBy('sno', 'desc')
      ->first();



    $json_string = $lead_question->lead_question_option;
    // dd($json_string);
    // Decode the JSON string into a PHP associative array
    $options_array = json_decode($json_string, true);
    // dd($options_array);
    // Initialize arrays to hold values and scores
    $values = [];
    $scores = [];

    // Process each item in the array
    foreach ($options_array as $item) {
      // Extract 'value'
      if (isset($item['value'])) {
        $values[] = $item['value'];
      }

      // Extract 'score'
      if (isset($item['score'])) {
        $scores[] = $item['score'];
      }
    }

    // Map values and scores into the desired format
    $mapped_array = [];
    $maxCount = max(count($values), count($scores));

    for ($i = 0; $i < $maxCount; $i++) {
      $mapped_array[] = [
        'value' => isset($values[$i]) ? $values[$i] : '',
        'score' => isset($scores[$i]) ? $scores[$i] : ''
      ];
    }

    // Output or use $mapped_array as needed
    // For debugging D:\Xampp_8.2.4\htdocs\eapl_full\resources\views\content\settings\sales\lead_question\lead_question_edit.blade.php
    // dd($mapped_array);



    return view('content.settings.sales.lead_question.lead_question_edit', [
      'lead_question' => $lead_question,
      'mapped_array' => $mapped_array,
    ]);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'lead_question_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $lead_question_name       = $request->lead_question_name;
      $lead_question       = $request->lead_question;
      $lead_option_name         = $request->lead_option_name;
      $lead_score         = $request->lead_score;
      $user_id = $request->user()->user_id;
      $sno = $request->sno_edit;
      // dd($lead_option_name);
      // dd($lead_score);

      $chk = LeadQuestionModel::where('lead_question_name', ucfirst($lead_question_name))
        ->where('status', '!=', 2)
        ->where('sno', '!=', $sno)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
        return redirect()->back();
      }

      // Initialize an array to hold options and scores
      $optionsArray = [];
      foreach ($lead_option_name as $index => $option) {
        $score = $lead_score[$index] ?? null; // Get the score for this option
        if ($option !== '') {
          $optionsArray[] = [
            'value' => $option,
            'score' => $score,
          ];
        }
      }
      // dd($optionsArray);
      $lead_question_option = json_encode($optionsArray);


      // Find and update the CategoryQuestionModel
      $upd_CourseModel = LeadQuestionModel::find($sno);
      if (!$upd_CourseModel) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Lead Question not found!'
        ]);
        return redirect()->back();
      }

      $upd_CourseModel->lead_question_name = ucfirst($lead_question_name);
      $upd_CourseModel->lead_question_type = $lead_question;
      $upd_CourseModel->lead_question_option = $lead_question_option;

      $upd_CourseModel->created_by = $user_id;
      $upd_CourseModel->updated_by = $user_id;

      $upd_CourseModel->save();
      // Flash success or error message based on the result D:\Xampp_8.2.4\htdocs\eapl_full\resources\views\content\settings\sales\lead_question\lead_question_list.blade.php
      if ($upd_CourseModel) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Lead Question updated successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Lead Question!'
        ]);
      }
    }
    return redirect()->route('settings-sales-lead_question_list');
  }



  public function Delete($id)
  {
    $upd_CourseCategoryModel =  LeadQuestionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  LeadQuestionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
