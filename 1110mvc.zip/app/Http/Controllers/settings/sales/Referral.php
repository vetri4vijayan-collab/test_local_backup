<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ReferralModel;
use Illuminate\Support\Facades\Validator;
//  D:\Xampp_8.2.4\htdocs\eapl_7_10_2024\app\Http\Controllers\settings\sales\Referral.php

class Referral extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {

        $referral = ReferralModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];

        return view(
            'content.settings.sales.referral.referral_list',
            [
                'referral' => $referral,
                'pageConfigs' => $pageConfigs
            ]
        );
    }

    public function List()
    {
        $Department = ReferralModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Department
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'referral_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $referral_name = $request->referral_name;
            $referral_desc = $request->referral_desc;
            // $branch_id = $request->user()->branch_id;
            $user_id            = $request->user()->user_id;
            $chk = ReferralModel::where('referral_name', ucwords($referral_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Department is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = ReferralModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $referral_id = 'RF-0001/' . $year;
                } else {

                    $data = $category_check->referral_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('RF-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $referral_id = $request . '/' . $year;
                }

                $add_department = new ReferralModel();
                $add_department->referral_id = $referral_id;
                $add_department->referral_name = Ucfirst($referral_name);
                $add_department->referral_desc = $referral_desc;
                $add_department->branch_id = self::$branch_id;
                $add_department->created_by                 = $user_id;
                $add_department->updated_by                 = $user_id;

                $add_department->save();

                if ($add_department) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Referral added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Referral!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editdepartment = ReferralModel::where('sno', $id)->first();

        return view('content.settings.branch.department.department_list', [
            'editdepartment' => $editdepartment,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'referral_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $referral_name = $request->referral_name;
            $referral_desc = $request->referral_desc;
            $referral_sno = $request->referral_sno;
            $user_id            = $request->user()->user_id;

            $upd_ReferralModel = ReferralModel::where('sno', $referral_sno)->first();

            $chk = ReferralModel::where('referral_name', ucwords($referral_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $referral_sno)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Referral is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_ReferralModel->referral_name = Ucfirst($referral_name);
                $upd_ReferralModel->referral_desc = $referral_desc;
                $upd_ReferralModel->branch_id = self::$branch_id;
                $upd_ReferralModel->updated_by                 = $user_id;
                $upd_ReferralModel->update();
                // dd($upd_ReferralModel);

                if ($upd_ReferralModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Referral Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Referral!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_DepartmentModel = ReferralModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        // return $id;
        $upd_DepartmentModel = ReferralModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}