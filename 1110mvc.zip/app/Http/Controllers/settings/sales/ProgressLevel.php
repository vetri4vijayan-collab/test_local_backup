<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProgressLevelModel;
use Illuminate\Support\Facades\Validator;

class ProgressLevel extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    // return view( 'content.settings.sales.lead_potential_type.lead_potential_type_list' );
    $progressLevel = ProgressLevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.sales.progress_level.progress_level_list', [
      'progressLevel' => $progressLevel,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $progressLevel = ProgressLevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $progressLevel
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progress_level_start' => 'required|max:255',
      'progress_level_end' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input feilds!'
      ]);
    } else {

      $progress_level_start     = $request->progress_level_start;
      $progress_level_end       = $request->progress_level_end;
      $background_color         = $request->background_color;
      $progress_level_description       = $request->progress_level_description;

      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;

      $category_check = ProgressLevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$category_check) {

        $year = substr(date('y'), -2);
        $progress_level_id = 'CT-0001/' . $year;
      } else {

        $data = $category_check->progress_level_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf('CT-%04d', $next_number);

        $year = substr(date('y'), -2);
        $progress_level_id = $request . '/' . $year;
      }

      $add_category = new ProgressLevelModel();
      $add_category->progress_level_id           = $progress_level_id;
      $add_category->progress_level_start         = $progress_level_start;
      $add_category->progress_level_end         = $progress_level_end;
      $add_category->progress_level_end         = $progress_level_end;
      $add_category->background_color         = $background_color;
      $add_category->progress_level_description         = $progress_level_description;
      $add_category->branch_id = self::$branch_id;

      $add_category->created_by                 = $user_id;
      $add_category->updated_by                 = $user_id;

      $add_category->save();

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Progress Level added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Progress Level !'
        ]);
      }

      // return $result;
      return redirect()->back()->with('success', 'Progress Level  Created successfully!');
    }
  }


  public function Edit($id)
  {
    $editcategory = ProgressLevelModel::where('sno', $id)->first();

    return view('content.settings.sales.progress_level.progress_level_list', [
      'editcategory' => $editcategory,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progress_level_start' => 'required|max:255',
      'progress_level_end' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $progress_level_start       = $request->progress_level_start;
      $progress_level_end       = $request->progress_level_end;
      $background_color               = $request->background_color;
      $progress_level_description     = $request->progress_level_description;
      $progress_level_id         = $request->progress_level_id;

      $upd_CourseCategoryModel =  ProgressLevelModel::where('sno', $progress_level_id)->first();


      $upd_CourseCategoryModel->progress_level_start  = $progress_level_start;
      $upd_CourseCategoryModel->progress_level_end  = $progress_level_end;
      $upd_CourseCategoryModel->progress_level_description  = $progress_level_description;
      $upd_CourseCategoryModel->background_color  = $background_color;

      $upd_CourseCategoryModel->update();

      if ($upd_CourseCategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Progress Level Update Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Update the Progress Level!'
        ]);
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  ProgressLevelModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  ProgressLevelModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
