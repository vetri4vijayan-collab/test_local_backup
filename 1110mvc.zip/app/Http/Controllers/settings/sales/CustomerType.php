<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerTypeModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class CustomerType extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {

        $level = CustomerTypeModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.sales.customer_type.customer_type', compact('level', 'pageConfigs'));
    }

    public function List()
    {
        $knowledge_level = CustomerTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge_level
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_type_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input feilds!'
            ]);
        } else {

            $customer_type_name       = $request->customer_type_name;
            $customer_type_desc       = $request->customer_type_desc;

            // $user_id            = $request->user()->id;
            $user_id            = $request->user()->user_id;
            $chk = CustomerTypeModel::where('customer_type_name', ucwords($customer_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = CustomerTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $customer_type_id = 'CT-0001/' . $year;
                } else {

                    $data = $category_check->customer_type_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('CT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $customer_type_id = $request . '/' . $year;
                }

                $add_category = new CustomerTypeModel();
                $add_category->customer_type_id           = $customer_type_id;
                $add_category->customer_type_name         = Ucfirst($customer_type_name);
                $add_category->customer_type_desc         = $customer_type_desc;
                $add_category->branch_id = self::$branch_id;

                $add_category->created_by                 = $user_id;
                $add_category->updated_by                 = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Customer Type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Customer Type!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'Customer Type Created successfully!');
        }
    }

    public function Edit($id)
    {
        $customer_type = CustomerTypeModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $customer_type
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {

            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => 'Incorrect format input feilds',
                'data'      => null,
            ], 401);
        } else {

            $customer_type_name       = $request->customer_type_name;
            $customer_type_desc       = $request->customer_type_desc;

            $upd_CourseCategoryModel =  CustomerTypeModel::where('sno', $id)->first();

            $chk = CustomerTypeModel::where('customer_type_name', ucwords($customer_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    return response([
                        'status'    => 403,
                        'message'   => 'Name has been  already created!',
                        'error_msg' => 'Incorrect format input feilds',
                        'data'      => null,
                    ], 403);
                }
            } else {
                $upd_CourseCategoryModel->customer_type_name  = Ucfirst($customer_type_name);
                $upd_CourseCategoryModel->customer_type_desc  = $customer_type_desc;
                $upd_CourseCategoryModel->update();

                if ($upd_CourseCategoryModel) {
                    return response([
                        'status'    => 200,
                        'message'   => 'Successfully Updated!',
                        'error_msg' => null,
                        'data'      => null,
                    ], 200);
                } else {
                    return response([
                        'status'    => 401,
                        'message'   => 'Incorrect format input feilds',
                        'error_msg' => 'Incorrect format input feilds',
                        'data'      => null,
                    ], 401);
                }
            }
        }

        // return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  CustomerTypeModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  CustomerTypeModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}