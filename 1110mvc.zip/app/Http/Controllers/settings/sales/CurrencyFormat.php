<?php

namespace App\Http\Controllers\settings\sales;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CurrencyFormatModel;
use Illuminate\Support\Facades\Validator;

class CurrencyFormat extends Controller
{
  public function index()
  {

    $CurrencyFormat = CurrencyFormatModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.sales.currency_format.currency_format', [
      'CurrencyFormat' => $CurrencyFormat,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $CurrencyFormat = CurrencyFormatModel::where('status', 0)->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $CurrencyFormat
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
      $user_id = 1;
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      }

      $add_currencyformat = new CurrencyFormatModel();
      $add_currencyformat->country_name = Ucfirst($country_name);
      $add_currencyformat->currency_code = Ucfirst($currency_code);
      $add_currencyformat->currency_name = Ucfirst($currency_name);
      $add_currencyformat->currency_symbol = Ucfirst($currency_symbol);

      $add_currencyformat->save();

      if ($add_currencyformat) {

        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Currency Format added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Currency Format!'
        ]);
      }
      return redirect()->back();
    }
  }


  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
      $edit_id = $request->edit_id;
      $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $edit_id)->first();
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      } else {
        $upd_CurrencyFormatModel->country_name = Ucfirst($country_name);
        $upd_CurrencyFormatModel->currency_code = Ucfirst($currency_code);
        $upd_CurrencyFormatModel->currency_name = Ucfirst($currency_name);
        $upd_CurrencyFormatModel->currency_symbol = Ucfirst($currency_symbol);

        $upd_CurrencyFormatModel->update();

        if ($upd_CurrencyFormatModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Currency Format Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Currency Format!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = 2;
    $upd_CurrencyFormatModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = $request->input('status', 0);
    $upd_CurrencyFormatModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
