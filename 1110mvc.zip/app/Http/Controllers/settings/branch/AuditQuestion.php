<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use App\Models\AuditQuestionModel;
use App\Models\CourseSubCategoryModel;
use Illuminate\Http\Request;
use App\Models\LeadQuestionModel;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
// use Carbon\Carbon;


class AuditQuestion extends Controller
{
    public function Index()
    {

        // $starttime = Carbon::createFromFormat('H:i', '12:30');
        // $endtime = Carbon::createFromFormat('H:i', '14:30');

        // // Calculate the difference in minutes
        // $diffInMinutes = $starttime->diffInMinutes($endtime);
        // $hours = intdiv($diffInMinutes, 60);  // Get hours
        // $minutes = $diffInMinutes % 60;

        $course_question = AuditQuestionModel::select('za_audit_question.*','za_audit_category.audit_category_name')->join('za_audit_category','za_audit_category.sno','=','za_audit_question.audit_category_id')->where('za_audit_question.status', '!=', 2)->orderBy('za_audit_question.sno', 'desc')->get();
        // $pageConfigs = ['myLayout' => 'default'];
        // // dd($quest);
        // return view('content.settings.sales.lead_question.lead_question_list', compact('quest', 'pageConfigs'));

        return view('content.settings.branch.audit_category_question.audit_category_question_list', [
            'course_question' => $course_question
        ]);
    }
    public function AuditQuestionAdd()
    {
        return view('content.settings.branch.audit_category_question.audit_category_question_add');
    }
    public function AuditQuestionEdit()
    {
        return view('content.settings.branch.audit_category_question.audit_category_question_edit');
    }
    public function SubCategoryList()
    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = CourseSubCategoryModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }
    public function SubCatCourseList($id, Request $request)

    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = ManageCoursesModel::where('status', 0)
            ->where('course_subcategory_id', $id)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }

    public function SubCatCourseListAll()

    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = ManageCoursesModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }

    public function List()
    {
        $leadquestion = LeadQuestionModel::where('status', 0)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $leadquestion
        ], 200);
    }


    public function Add(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'audit_category_id.*' => 'required|max:255',
            'question.*' => 'required|max:255',
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            'option_value_checkbox_*.*' => 'nullable|string',
            'option_course_checkbox_*.*' => 'nullable|array',
            'option_value_radio_button_*.*' => 'nullable|string',
            'option_course_radio_button_*.*' => 'nullable|array',
            'option_value_list_box_*.*' => 'nullable|string',
        ]);

        $audit_category_id=$request->assg_dept_add;

    

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed. Please check your inputs.'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // $chk_cat = AuditQuestionModel::where('audit_category_id', $audit_category_id)
        // ->where('status',0)
        // ->first();

        
        // if ($chk_cat) {
        //     session()->flash('toastr', [
        //         'type' => 'error',
        //         'message' => 'Audit Category is Already Exist.'
        //     ]);
        //     return redirect()->back()->withErrors($validator)->withInput();
        // }

        $user_id = $request->user()->user_id;
        

        foreach ($request->input('question') as $key => $course_question_name) {
            $audit_question_type = $request->input('question_type.' . $key);
            // dd($audit_question_type);
            $audit_question_option = [];

            switch ($audit_question_type) {
                case 'checkbox':
                case 'radio_button':
                case 'list_box':
                    $options_key = 'option_value_' . $audit_question_type . '_' . $key;
                    // $category_key = 'option_category_' . $audit_question_type . '_' . $key;
                    $scores_key = 'option_score_' . $audit_question_type . '_' . $key;

                    $options = $request->input($options_key, []);
                    // $categories = $request->input($category_key, []);
                    $scores = $request->input($scores_key, []);
                 
                    // Ensure all inputs are arrays
                    $options = (array) $options;
                    // $categories = (array) $categories;
                    $scores = (array) $scores;

                    $options_array = [];

                    foreach ($options as $option_key => $value) {
                        if ($value !== '') {
                            $score_array = isset($scores[$option_key]) ? (array) $scores[$option_key] : [];
                            $options_array[] = [
                                'value' => $value,
                                // 'category' => $categories[$option_key] ?? null,
                                'score' => $score_array,
                            ];
                        }
                    }
                    // dd($options_array);
                    $audit_question_option = json_encode($options_array);
                    break;
                case 'text_field':
                    $audit_question_option = null;
                    break;
                default:
                    break;
            }

            // Check if question already exists
            $chk = AuditQuestionModel::where('audit_question_name', $course_question_name)
                ->where('status',0)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has already been created!'
                ]);
                continue;
            }

            // Create and save new Course Question
            $add_category = new AuditQuestionModel();
            $add_category->audit_category_id = $audit_category_id;
            $add_category->audit_question_name = $course_question_name;
            $add_category->audit_question_type = $audit_question_type;
            $add_category->audit_question_option = $audit_question_option;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
            $add_category->save();
            if ($add_category->save()) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Audit Question added successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Course Question!'
                ]);
            }
        }

        return redirect('/settings/branch/audit_question_list');
    }



    public function Edit($id)
    {
            $helper = new \App\Helpers\Helpers();
            $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
            // Check if decryption failed
            if ($decryptedValue === false) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }

            $audit_question = AuditQuestionModel::where('status', '!=', 2)
                ->where('sno', $decryptedValue)
                ->first();

            $json_string = $audit_question->audit_question_option;

            $options_array =  $json_string ? json_decode($json_string, true) :[];

            $values = [];
            $scores = [];

            // return  $json_string;

            foreach ($options_array as $item) {
                // Extract 'value'
                if (isset($item['value'])) {
                    $values[] = $item['value'];
                }

                // Extract 'score'
                if (isset($item['score'])) {
                    $scores[] = $item['score'];
                }
            }

            // Map values and scores into the desired format
            $mapped_array = [];
            $maxCount = max(count($values), count($scores));

            for ($i = 0; $i < $maxCount; $i++) {
                $mapped_array[] = [
                    'value' => isset($values[$i]) ? $values[$i] : '',
                    'score' => isset($scores[$i]) ? $scores[$i] : ''
                ];
            }


        return view('content.settings.branch.audit_category_question.audit_category_question_edit', [
            'audit_question' => $audit_question,
            'mapped_array' => $mapped_array,
        ]);
    }


    public function Update(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'audit_question_name' => 'required|max:255',
            // 'option_name' => 'array',
            // 'category_score' => 'array'
        ]);
        // return $request;


        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed. Please ensure all required fields are filled out.'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        }
        // return $request;
        $audit_question_name = $request->audit_question_name;
        $audit_cat = $request->audit_cat;
        $audit_question = $request->audit_question;
        $option_name = $request->option_name;
        $category_score = $request->category_score;
        $sno = $request->sno_edit;
        $user_id = $request->user()->user_id;
        // dd($category_score);
        // Check if the question already exists
        $chk = AuditQuestionModel::where('audit_question_name', $audit_question_name)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();
        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name has been already created!'
            ]);
            return redirect()->back();
        }

        // Initialize an array to hold options and scores
        $optionsArray = [];
        foreach ($option_name as $index => $option) {
            $score = $category_score[$index] ?? null; // Get the score for this option
            if ($option !== '') {
                $optionsArray[] = [
                    'value' => $option,
                    'score' => $score,
                ];
            }
        }
        // dd($optionsArray);

        $audit_question_option = json_encode($optionsArray); // Convert options and scores to JSON

        // Find and update the CategoryQuestionModel
        $upd_AuditQuestModel = AuditQuestionModel::find($sno);
        if (!$upd_AuditQuestModel) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Audit Question not found!'
            ]);
            return redirect()->back();
        }

        $upd_AuditQuestModel->audit_question_name =$audit_question_name;
        $upd_AuditQuestModel->audit_category_id = $audit_cat;
        $upd_AuditQuestModel->audit_question_type = $audit_question;
        $upd_AuditQuestModel->audit_question_option = $audit_question_option;

        $upd_AuditQuestModel->created_by = $user_id;
        $upd_AuditQuestModel->updated_by = $user_id;
        $upd_AuditQuestModel->save();

        // Flash success or error message based on the result
        if ($upd_AuditQuestModel) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Audit Question updated successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Audit Question!'
            ]);
        }

        return redirect('/settings/branch/audit_question_list');
    }

    public function Delete($id)
    {
        $upd_CourseAnalysisModel =  AuditQuestionModel::where('sno', $id)->first();
        $upd_CourseAnalysisModel->status  = 2;
        $upd_CourseAnalysisModel->Update();
        if ($upd_CourseAnalysisModel) {
            return response([
                'status'    => 200,
                'message'   => ' Audit Category Questions Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Audit Category Questions!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Status($id, Request $request)
    {

        $upd_CourseAnalysisModel =  AuditQuestionModel::where('sno', $id)->first();
        $upd_CourseAnalysisModel->status = $request->input('status', 0);
        $upd_CourseAnalysisModel->update();
        if ($upd_CourseAnalysisModel) {
            return response([
                'status'    => 200,
                'message'   => 'Audit Questions Successfully Updated!',
                'error_msg' => 'Could not ,update  Audit Questions!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Audit Questions!',
                'error_msg' => 'Could not ,update  Audit Questions!',
                'data'      => null,
            ], 200);
        }
    }
    
       public function PreviewQuestions(Request $request)
        {   
            
             $depart_list = DB::table('za_audit_category')
                ->select('za_audit_category.audit_category_name','za_audit_category.sno as id')
                ->where('za_audit_category.status',  0)
                ->get();
         
            $department_ids = $depart_list->pluck('id')->toArray();
            
              $questions = DB::table('za_audit_question')
                ->select('za_audit_question.audit_question_name as question_name',
                        'za_audit_question.audit_question_type',
                        'za_audit_question.audit_category_id as department_id',
                        'za_audit_question.audit_question_option')
                ->where('za_audit_question.status', 0)
                ->whereIn('za_audit_question.audit_category_id', $department_ids)
                ->get();
                     
                foreach ($questions as $singleQuestion) {
            $options = $singleQuestion->audit_question_option;
            
            // Check if the field contains a valid JSON string
            if ($options && $decodedOptions = json_decode($options)) {
                $optionValues = [];
                $scores = [];
        
                foreach ($decodedOptions as $option) {
                    $optionValues[] = $option->value;
                    $scores[] = isset($option->score[0]) ? (string) $option->score[0] : "0";
                }
        
                // Add as decoded arrays
                $singleQuestion->options = $optionValues;
                $singleQuestion->scores = $scores;
                
                // Optionally remove original
                unset($singleQuestion->audit_question_option);
            } else {
                // Handle the case where JSON is invalid or empty
                $singleQuestion->options = [];
                $singleQuestion->scores = [];
            }
        }
           $audit_data = new \stdClass();
            $depart_names = $depart_list->pluck('audit_category_name')->toArray(); 
            $audit_data->department_name = implode(', ', $depart_names);
            $audit_data->department_list = $depart_list;
            $audit_data->questions = $questions;
       
       return response()->json([
           'status' => 200,
           'success' => true,
           'message' => null,
           'error_msg' => null,
           'data' => $audit_data ,
       ], 200);
   }
}