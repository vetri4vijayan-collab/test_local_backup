<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FranchiseReasonModel;
use Illuminate\Support\Facades\Validator;

class FranchiseReason extends Controller {

    public function index() {

        $Department = FranchiseReasonModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.branch.franchise.franchise_reason', [
            'Department' => $Department,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $Department = FranchiseReasonModel::where( 'status', 0)->orderBy( 'sno', 'desc' )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Department
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'reason_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $reason_name = $request->reason_name;
            $reas_desc = $request->department_desc;
            $user_id = 1;
            $chk = FranchiseReasonModel::where( 'reason_name', ucwords( $reason_name ) )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Reason is exist!'
                ] );
                return redirect()->back();
            } else {


                $add_department = new FranchiseReasonModel();
                $add_department->reason_name = Ucfirst( $reason_name );
                $add_department->reas_desc = $reas_desc;
                $add_department->created_by = $user_id;
                $add_department->updated_by = $user_id;

                $add_department->save();

                if ( $add_department ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Reason added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Reason!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'reason_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $reason_name = $request->reason_name;
            $reas_desc = $request->department_desc;
            $department_id = $request->department_id;

            $upd_FranchiseReasonModel = FranchiseReasonModel::where( 'sno', $department_id )->first();

            $chk = FranchiseReasonModel::where( 'department_name', ucwords( $department_name ) )->where( 'sno', '!=', $department_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Reason is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_FranchiseReasonModel->reason_name = Ucfirst( $reason_name );
                $upd_FranchiseReasonModel->reas_desc = $reas_desc;
                $upd_FranchiseReasonModel->update();

                if ( $upd_FranchiseReasonModel ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Reason Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Reason!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_FranchiseReasonModel = FranchiseReasonModel::where( 'sno', $id )->first();
        $upd_FranchiseReasonModel->status = 2;
        $upd_FranchiseReasonModel->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_FranchiseReasonModel = FranchiseReasonModel::where( 'sno', $id )->first();
        $upd_FranchiseReasonModel->status = $request->input( 'status', 0 );
        $upd_FranchiseReasonModel->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}
