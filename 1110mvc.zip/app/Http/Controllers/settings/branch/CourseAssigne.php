<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CourseAssigne_model;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Facades\Validator;

class CourseAssigne extends Controller {
    public function index() {

        $CourseAssigne = CourseAssigne_model::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.branch.course_assigne.course_assigne_list', [
            'CourseAssigne_list' => $CourseAssigne,
            'pageConfigs' => $pageConfigs
        ] );
        // return view( 'content.settings.branch.course_assigne.course_assigne_list' );
    }

    public function List() {
        $Branchtype = CourseAssigne_model::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'assign_course_branch_sno' => 'required|max:255',
            'course_assign_date' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {
            // return $request;
            $branch_id       = $request->assign_course_branch_sno;
            $assign_date     = date( 'Y-m-d', strtotime( $request->course_assign_date ) );
            $course_type_id  = json_encode( $request->course_type_id );
            $course_id       = json_encode( $request->course_sno_add );
            $user_id         = 1;

            $add_branch_course = new CourseAssigne_model();
            $add_branch_course->branch_id      = $branch_id;
            $add_branch_course->assign_date    = $assign_date;
            $add_branch_course->course_type_id = $course_type_id;
            $add_branch_course->course_id      = $course_id;
            $add_branch_course->created_by     = $user_id;
            $add_branch_course->updated_by     = $user_id;

            $add_branch_course->save();

            if ( $add_branch_course ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Branch Course Assigned  Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not assign the Branch Course!'
                ] );
            }
            // return $request;
            return redirect()->back();
        }
    }

    public function Edit( $id ) {

        $course = CourseAssigne_model::where( 'za_branch_course.branch_id', $id )
        ->select( 'za_branch_course.*', 'za_course.sno as course_id_original' )
        ->where( 'za_branch_course.status', 0 )
        ->leftJoin( 'za_course', 'za_branch_course.course_id', '=', 'za_course.sno' )
        ->get();
        $course_all = ManageCoursesModel::where( 'za_course.status', 0 )->get();
        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $course,
            'course_all' => $course_all
        ], 200 );

    }

    public function Update( Request $request ) {
        $validator = Validator::make( $request->all(), [
            'course_type_id_edit_hidden' => 'required|max:255',
        ] );

        if ( $validator->fails() ) {
            return redirect()->back()
            ->withErrors( $validator )
            ->withInput()
            ->with( [
                'toastr' => [
                    'type' => 'error',
                    'message' => 'Incorrect format input fields'
                ]
            ] );
        }

        $branch_course_id = $request->course_type_id_edit_hidden;

        $add_branch_course = CourseAssigne_model::where('branch_id',$branch_course_id)->first();

        if ( !$add_branch_course ) {
            return redirect()->back()->with( [
                'toastr' => [
                    'type' => 'error',
                    'message' => 'Branch Course Assign not found!'
                ]
            ] );
        }

        // Update the model attributes
        $add_branch_course->branch_id = $request->assign_course_branch_sno_edit;
        $add_branch_course->assign_date = date( 'Y-m-d', strtotime( $request->course_assign_date_edit ) );
        $add_branch_course->course_type_id = json_encode( $request->course_type_id_edit );
        $add_branch_course->course_id = json_encode( $request->course_sno_edit );
        $add_branch_course->updated_by = 1;
        // Assuming user ID should be dynamic

        // Attempt to save the updated model
        if ( $add_branch_course->save() ) {
            session()->flash( 'toastr', [
                'type' => 'success',
                'message' => 'Branch Course Assigned updated Successfully!'
            ] );
        } else {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Could not update the Branch Course Assign!'
            ] );
        }

        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_CourseAssigne_model = CourseAssigne_model::where( 'sno', $id )->first();
        $upd_CourseAssigne_model->status  = 2;
        $upd_CourseAssigne_model->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_CourseAssigne_model =  CourseAssigne_model::where( 'sno', $id )->first();
        $upd_CourseAssigne_model->status = $request->input( 'status', 0 );
        $upd_CourseAssigne_model->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}