<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AuditCategoryModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AuditCategory extends Controller {
    protected static $branch_id = 1;

    public function index() {

        $Department = AuditCategoryModel::where('status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.branch.audit_category.audit_category_list', [
            'Department' => $Department,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $Department = AuditCategoryModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Department
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'audit_category_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $audit_category_name = $request->audit_category_name;
            $audit_category_desc = $request->audit_category_desc;
             $user_id   = $request->user()->user_id ?? 1;
            $chk = AuditCategoryModel::where( 'audit_category_name', ucwords( $audit_category_name ) )->where( 'branch_id', self::$branch_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Audit Category is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = AuditCategoryModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $audit_category_id = 'AC-0001/' . $year;
                } else {

                    $data = $category_check->audit_category_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int ) $result + 1;
                    $request = sprintf( 'AC-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $audit_category_id = $request . '/' . $year;
                }

                $add_department = new AuditCategoryModel();
                $add_department->audit_category_id = $audit_category_id;
                $add_department->audit_category_name = Ucfirst( $audit_category_name );
                $add_department->audit_category_desc = $audit_category_desc;
                $add_department->branch_id = self::$branch_id;
                $add_department->created_by = $user_id;
                $add_department->updated_by = $user_id;

                $add_department->save();

                if ( $add_department ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Audit Category added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Audit Category!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit( $id ) {
        $editdepartment = AuditCategoryModel::where( 'sno', $id )->first();

        return view( 'content.settings.branch.department.department_list', [
            'editdepartment' => $editdepartment,
            'id' => $id,
        ] );
    }

    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'audit_category_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $audit_category_name = $request->audit_category_name;
            $audit_category_desc = $request->audit_category_desc;
            $audit_category_id = $request->audit_category_id;
             $user_id   = $request->user()->user_id ?? 1;

            $upd_AuditCategory = AuditCategoryModel::where( 'sno', $audit_category_id )->first();

            $chk = AuditCategoryModel::where( 'audit_category_name', ucwords( $audit_category_name ) )->where( 'branch_id', self::$branch_id )->where( 'sno', '!=', $audit_category_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Audit Category is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_AuditCategory->audit_category_name = Ucfirst( $audit_category_name );
                $upd_AuditCategory->audit_category_desc = $audit_category_desc;
                $upd_AuditCategory->updated_by = $user_id;
                $upd_AuditCategory->branch_id = self::$branch_id;
                $upd_AuditCategory->update();

                if ( $upd_AuditCategory ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Audit Category Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Audit Category!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_AuditCategory = AuditCategoryModel::where( 'sno', $id )->first();
        $upd_AuditCategory->status = 2;
        $upd_AuditCategory->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_AuditCategory = AuditCategoryModel::where( 'sno', $id )->first();
        $upd_AuditCategory->status = $request->input( 'status', 0 );
        $upd_AuditCategory->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
    
    public function AuditCategoryQuestions($id,Request $request)
    {  

        $audit_data = AuditCategoryModel::where('sno', $id)
        ->first();
        
      
 
        $questions = DB::table('za_audit_question')
        ->select('za_audit_question.audit_question_name as question_name',
                'za_audit_question.audit_question_type',
                'za_audit_question.audit_question_option')
        ->where('za_audit_question.status', 0)
        ->where('za_audit_question.audit_category_id', $id)
        ->get();
             
        foreach ($questions as $singleQuestion) {
    $options = $singleQuestion->audit_question_option;
    
    // Check if the field contains a valid JSON string
    if ($options && $decodedOptions = json_decode($options)) {
        $optionValues = [];
        $scores = [];

        foreach ($decodedOptions as $option) {
            $optionValues[] = $option->value;
            $scores[] = isset($option->score[0]) ? (string) $option->score[0] : "0";
        }

        // Add as decoded arrays
        $singleQuestion->options = $optionValues;
        $singleQuestion->scores = $scores;
        
        // Optionally remove original
        unset($singleQuestion->audit_question_option);
    } else {
        // Handle the case where JSON is invalid or empty
        $singleQuestion->options = [];
        $singleQuestion->scores = [];
    }
}
 
        $audit_data->questions = $questions;
        
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $audit_data ,
        ], 200);
    }
}
