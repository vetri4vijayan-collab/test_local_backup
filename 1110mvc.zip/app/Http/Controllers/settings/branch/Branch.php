<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CourseAssigne_model;
use App\Models\CugManagementModel;
use App\Models\FranchiseDocumentModel;
use App\Models\ManageCoursesModel;
use App\Models\JobpositionModel;
use Illuminate\Support\Facades\DB;
use App\Models\StaffModel;
use App\Models\ManageTargetModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\AttendanceModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\SyllabusUpdateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Models\TransactionModel;
use Illuminate\Support\Facades\Session;
use Laravel\Sanctum\PersonalAccessToken;
class Branch extends Controller
{

 public function index()
{
    $user_id = auth()->user()->user_id;

    $helper = new \App\Helpers\Helpers();
    $branchControlList = $helper->get_branch_control_list($user_id);

    $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
    $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');

    // Merge allowed branch IDs (company + franchise)
    $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
   
    // Fetch only branches the user has access to
    $Branch_list = BranchModel::whereIn('sno', $allowedBranchIds)
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->get();
        
    $other_db = DB::connection('mysql_secondary');
    $cal_tracker_company =    $other_db->table('company')->where('status',0)->get();

    return view('content.settings.branch.branch.branch_list', [
        'Branch_list'       => $Branch_list,
        'country_fill'      => '',
        'state_fill'        => '',
        'city_fill'         => '',
        'branch_type_fill'  => '',
        'branch_cate_fill'  => '',
        'date_filter'       => '',
        'cal_tracker_company'       => $cal_tracker_company,
    ])->with('filter_on', false);
}

public function Franchiseterminate(Request $request)
  {
    $request->validate([
      'franchise_id' => 'required', // adjust table/column
      'reason_id'    => 'required',
      'checklist' => 'required|array',
    ]);
 
    // Build checklist JSON (id + status)
    $checklistData = [];
    foreach ($request->checklist as $checklistId => $status) {
      $checklistData[] = [
        'check_id'      => $checklistId,
        'check_status'  => (int) $status, // 1 or 0
      ];
    }
 
    // Save in BranchModel
    $branch = BranchModel::findOrFail($request->franchise_id);
 
 
    if ((int)$branch->status === 0) {
      $userIds = \App\Models\User::where('branch_id', $branch->sno)->pluck('id');
 
      $sessionFiles = glob(storage_path('framework/sessions/*'));
 
      foreach ($sessionFiles as $file) {
        $contents = @file_get_contents($file);
 
        if (!$contents) continue;
 
        foreach ($userIds as $userId) {
          if (strpos($contents, 'user_id|i:' . $userId) !== false) {
            @unlink($file); // Logout this user by deleting session file
            break;
          }
        }
      }
 
      // Also remove their Sanctum tokens:
      \Laravel\Sanctum\PersonalAccessToken::whereIn('tokenable_id', $userIds)->delete();
    }
    $branch->check_list_data = json_encode($checklistData);
    $branch->franchise_reason_id = $request->reason_id;
    $branch->status = 2;
    $branch->save();
 
    return response()->json([
      'success' => true,
      'message' => 'Franchise terminated successfully',
    ]);
  }
  
  public function terminalList()
  {
    $user_id = auth()->user()->user_id;
 
    // Fetch only branches the user has access to
    $Branch_list = BranchModel::where('status', 2)
      ->orderBy('sno', 'desc')
      ->get();
 
    $cal_tracker_company =    [];
 
    return view('content.settings.branch.branch.branch_terminated_list', [
      'Branch_list'       => $Branch_list,
      'country_fill'      => '',
      'state_fill'        => '',
      'city_fill'         => '',
      'branch_type_fill'  => '',
      'branch_cate_fill'  => '',
      'date_filter'       => '',
      'cal_tracker_company'       => $cal_tracker_company,
    ])->with('filter_on', false);
  }
 
   public function terminalBranchCustomer($branch_id)
  {
    $helper      = new \App\Helpers\Helpers();
    $currentDate = now();
 
    // ------------------------------------------------------------------
    // 1) Customers of this branch that have AT LEAST ONE
    //    currently-active training (start_date <= today <= end_date)
    // ------------------------------------------------------------------
    $customers = CustomerModel::where('branch_id', $branch_id)
      ->whereIn('status', [0, 6])
      ->whereExists(function ($q) use ($branch_id, $currentDate) {
        $q->select(\DB::raw(1))
          ->from('za_training')
          ->whereColumn('za_training.customer_id', 'za_customer.sno')
          ->where('za_training.branch_id', $branch_id)
          ->where('za_training.status', 0)
          ->where('za_training.start_date', '<=', $currentDate)
          ->where('za_training.end_date',   '>=', $currentDate);
      })
      ->orderBy('sno', 'desc')
      ->get();
 
    if ($customers->isEmpty()) {
      return response()->json([
        'status'    => true,
        'count'     => 0,
        'customers' => [],
      ]);
    }
 
    $customerIds = $customers->pluck('sno')->toArray();
 
    // ------------------------------------------------------------------
    // 2) Currently-active trainings for those customers (same date filter)
    // ------------------------------------------------------------------
    $trainings = TrainingModel::whereIn('customer_id', $customerIds)
      ->where('branch_id', $branch_id)
      ->where('status', 0)
      ->where('start_date', '<=', $currentDate)
      ->where('end_date',   '>=', $currentDate)
      ->orderBy('sno', 'desc')
      ->get();
 
    $trainingsByCustomer = $trainings->groupBy('customer_id');
 
    // ------------------------------------------------------------------
    // 3) Lookup maps
    // ------------------------------------------------------------------
    $batchIds  = $trainings->pluck('batch_id')->filter()->unique()->values()->toArray();
    $staffIds  = $trainings->pluck('staff_id')->filter()->unique()->values()->toArray();
    $courseIds = $trainings->pluck('course_id')->filter()->unique()->values()->toArray();
    $slotIds   = $trainings->pluck('slot_id')->filter()->unique()->values()->toArray();
 
    $batches  = \App\Models\BatchModel::whereIn('sno', $batchIds)->pluck('batch_name', 'sno');
    $staffs   = \App\Models\StaffModel::whereIn('sno', $staffIds)->get()->keyBy('sno');
    $courses  = \App\Models\ManageCoursesModel::whereIn('sno', $courseIds)->get()->keyBy('sno');
    $slots    = \App\Models\SlotModel::whereIn('sno', $slotIds)->pluck('slot_name', 'sno');
 
    $canManage = auth()->user()->hasPermission('Customer Management', 'Action', 'Manage Customer');
 
    // ------------------------------------------------------------------
    // 4) Build response
    // ------------------------------------------------------------------
    $result = [];
 
    foreach ($customers as $customer) {
 
      $custTrainings    = $trainingsByCustomer->get($customer->sno, collect());
      $mainTrainings    = $custTrainings->where('tesbo_check', 0)->values();
      $presaleTrainings = $custTrainings->where('tesbo_check', 1)->values();
 
      // ---- Customer-level carousel details (mirrors customer list page) ----
      $carouselDetails = [];
      $totalPaid = 0;
 
      foreach ($mainTrainings as $t) {
        $course   = $courses[$t->course_id] ?? null;
        $total    = (float) $t->total_amount;
        $paid     = (float) $t->paid_amount;
        $payPct   = $total > 0 ? round(($paid / $total) * 100, 2) : 0;
 
        $totalPaid += $paid;
 
        // 🚨 course_progress — plug in YOUR existing logic.
        // If it's a helper call, replace this line:
        // $courseProgress = $helper->get_course_progress($t->sno);
        $courseProgress = 0;
 
        $carouselDetails[] = [
          'training_sno'             => $t->sno,
          'course_id'                => $t->course_id,
          'course_name'              => $course->course_name ?? '-',
          'course_type_name'         => $course->courseType->course_type_name ?? '-',
          'course_mode_id'           => $t->course_mode_id ?? 0,
          'batch_name'               => $batches[$t->batch_id]  ?? '-',
          'slot_name'                => $slots[$t->slot_id]    ?? '-',
          'staff_name'               => optional($staffs[$t->staff_id] ?? null)->name ?? '-',
          'start_date'               => $t->start_date,
          'end_date'                 => $t->end_date,
          'course_progress'          => $courseProgress,
          'payment_percentage'       => $payPct,
          'traning_status'           => $t->status,
          'certificate_status_name'  => null,   // 🔌 plug in your certificate helper
          'certificate_status_bg'    => null,
          'certificate_status_color' => null,
        ];
      }
 
      // ---- Status aggregation for the badge ----
      $allActive   = $mainTrainings->where('status', 0)->count() === $mainTrainings->count() && $mainTrainings->count() > 0;
      $allDropped  = $mainTrainings->where('status', 2)->count() === $mainTrainings->count() && $mainTrainings->count() > 0;
      $allSchedule = $mainTrainings->where('status', 1)->count() === $mainTrainings->count() && $mainTrainings->count() > 0;
 
      // ---- Payment due check (call the same notify logic if desired) ----
      $notify = false; // 🔌 optional: replicate your existing notify check
 
      $result[] = [
        // ---- identity ----
        'customer_id'       => $customer->sno,
        'encrypted_id'      => $helper->encrypt_decrypt($customer->sno, 'encrypt'),
        'customer_code'     => $customer->customer_id ?? '-',
        'customer_name'     => $customer->cus_name ?? '-',
        'mobile'            => $customer->cus_mobile ?? '-',
        'alternate_mobile'  => $customer->cus_alternate_mobile ?? '-',
        'email'             => $customer->cus_email_id ?? '-',
        'gender'            => (int) ($customer->cus_gender ?? 0),
        'cus_pic'           => $customer->cus_pic ?? '',
        'doj'               => $customer->doj ?? '-',
        'status'            => $customer->status,
 
        // ---- badges / colours ----
        'app_installed'     => (int) ($customer->app_installed ?? 0),
        'daily_points'      => (int) ($customer->daily_points  ?? 0),
        'is_placement'      => (int) ($customer->is_placement  ?? 0),
        'lead_id'           => $customer->lead_id ?? null,
        'lead_staff_name'   => $customer->lead_staff_name ?? null,
        'all_active'        => $allActive,
        'all_schedule'      => $allSchedule,
        'all_cus_drop'      => $allDropped,
        'min_prd_cost'      => (float) ($customer->min_prd_cost ?? 0),
        'total_paid_amount' => $totalPaid,
 
        // ---- permission ----
        'can_manage'        => $canManage,
 
        // ---- carousel (this is what the JS loops over) ----
        'main_trainings'    => $carouselDetails,
 
        // ---- optional: pre/post sale list ----
        'presale_trainings' => $presaleTrainings->map(function ($t) use ($batches, $staffs, $courses) {
          return [
            'training_id'     => $t->sno,
            'course_name'     => $courses[$t->course_id]->course_name ?? '-',
            'batch_name'      => $batches[$t->batch_id] ?? '-',
            'staff_name'      => optional($staffs[$t->staff_id] ?? null)->name ?? '-',
            'start_date'      => $t->start_date,
            'end_date'        => $t->end_date,
            'total_amount'    => $t->total_amount,
            'post_sale_check' => $t->post_sale_check,
          ];
        }),
      ];
    }
 
    return response()->json([
      'status'    => true,
      'count'     => count($result),
      'customers' => $result,
    ]);
  }
  
  /**
   * Get franchise statistics (active students and outstanding amount)
   */
  public function getFranchiseStats(Request $request, $id)
  {
 
 
    $franchiseId = $id;
 
    // Get active students count
    $activeStudentsCount = CustomerModel::where('branch_id', $franchiseId)
      ->whereIn('status', [0, 6]) // Assuming status 0 means active
      ->count();
 
    // Alternative: Get active students based on training dates
    $activeStudentsFromTraining = TrainingModel::where('branch_id', $franchiseId)
      ->where('end_date', '>=', now())
      ->where('start_date', '<=', now())
      ->where('status', 0)
      ->distinct('training_id')
      ->count('customer_id');
 
    // Get outstanding amount (unpaid payments)
    $outstandingAmount = PaymentModel::where('branch_id', $franchiseId)
      ->where('status', 0) // status 0 means not paid
      ->sum('amount'); // Assuming there's an 'amount' column
 
    // Get total customers
    $totalCustomers = CustomerModel::where('branch_id', $franchiseId)->count();
 
    // Get total revenue (paid amount)
    $totalRevenue = PaymentModel::where('branch_id', $franchiseId)
      ->where('status', 1) // status 1 means paid
      ->sum('paidAmount');
 
    return response()->json([
      'success' => true,
      'data' => [
        'active_students' => $activeStudentsFromTraining,
        'active_students_from_training' => $activeStudentsFromTraining,
        'outstanding_amount' => (float) $outstandingAmount,
        'total_customers' => $totalCustomers,
        'total_revenue' => (float) $totalRevenue,
        'franchise_id' => $franchiseId
      ]
    ]);
  }
  
  public function list_filter(Request $request)
  {
      
    $user_id = auth()->user()->user_id;

    $helper = new \App\Helpers\Helpers();
    $branchControlList = $helper->get_branch_control_list($user_id);

    $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
    $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');

    // Merge allowed branch IDs (company + franchise)
    $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
    
    $country_fill = $request->country_fill ?? '';
    $state_fill = $request->state_fill ?? '';
    $city_fill = $request->city_fill ?? '';
    $branch_type_fill = $request->branch_type_fill ?? '';
    // $branch_cate_fill = $request->branch_cate_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;

    // Initialize query with base conditions
    $query = BranchModel::whereIn('sno', $allowedBranchIds)->where('status', '!=', 2);

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_branch.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_branch.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_branch.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_branch.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_branch.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_branch.created_at', '<=', $toDate);
      }
    }

    if ($country_fill) {
      $query->where('country_id', $country_fill);
    }
    if ($state_fill) {
      $query->where('state_id', $state_fill);
    }
    if ($city_fill) {
      $query->where('city_id', $city_fill);
    }
    if ($branch_type_fill) {
      $query->where('branch_type', $branch_type_fill);
    }

    // Fetch Branch list ordered by sno in descending order
    $Branch_list = $query->orderBy('sno', 'desc')->paginate(10);
    
    $other_db = DB::connection('mysql_secondary');
    $cal_tracker_company =    $other_db->table('company')->where('status',0)->get();

    // Return the view with filter variables and session flash for filter_on
    return view('content.settings.branch.branch.branch_list', [
      'Branch_list' => $Branch_list,
      'country_fill' => $country_fill,
      'state_fill' => $state_fill,
      'city_fill' => $city_fill,
      'branch_type_fill' => $branch_type_fill,
      'cal_tracker_company'       => $cal_tracker_company,
      'date_filter' => $date_filter,
    ])->with('filter_on', true);
    // Flashing 'filter_on' session variable
  }
  public function list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $branch_data = BranchModel::where('status', 0);
     $branch_data = $branch_data->orderBy('sno', 'desc')->whereNotIn('sno', [1, 11, 18])->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $branch_data,
    ], 200);
  }
//   public function Status($id, Request $request)
//   {

//     $staff =  BranchModel::where('sno', $id)->first();
//     // return $staff;
//     $staff->status = $request->input('status', 0);
//     $staff->update();

//     if ($staff) {
//       return response([
//         'status'    => 200,
//         'message'   => 'Branch / Franchise  Status Successfully Updated!',
//         'error_msg' => 'Could not, update  Branch / Franchise  Status!',
//         'data'      => null,
//       ], 200);
//     } else {
//       return response([
//         'status'    => 200,
//         'message'   => 'Could not update Branch / Franchise  Status!',
//         'error_msg' => 'Could not, update  Branch / Franchise  Status!',
//         'data'      => null,
//       ], 200);
//     }
//   }


public function Status($id, Request $request)
{
    $branch = BranchModel::where('sno', $id)->first();

    if (!$branch) {
        return response([
            'status'    => 404,
            'message'   => 'Branch not found!',
            'error_msg' => 'Invalid branch ID.',
            'data'      => null,
        ]);
    }

    $branch->status = $request->input('status', 0);
    $branch->update();

    // If status is deactivated (e.g. 0), log out users from that branch
    // if ((int)$branch->status === 0) {
    //     // Assuming `branch_id` or `branch_sno` exists in your `users` table
    //     $users = \App\Models\User::where('branch_id', $id)->get();

    //     foreach ($users as $user) {
    //         // If using Sanctum:
    //         PersonalAccessToken::where('tokenable_id', $user->id)->delete();

    //         // If using Laravel sessions instead:
    //         DB::table('sessions')->where('user_id', $user->id)->delete();
    //     }
    // }
    if ((int)$branch->status === 0) {
        $userIds = \App\Models\User::where('branch_id', $id)->pluck('id');
    
        $sessionFiles = glob(storage_path('framework/sessions/*'));
    
        foreach ($sessionFiles as $file) {
            $contents = @file_get_contents($file);
    
            if (!$contents) continue;
    
            foreach ($userIds as $userId) {
                if (strpos($contents, 'user_id|i:' . $userId) !== false) {
                    @unlink($file); // Logout this user by deleting session file
                    break;
                }
            }
        }
    
        // Also remove their Sanctum tokens:
        \Laravel\Sanctum\PersonalAccessToken::whereIn('tokenable_id', $userIds)->delete();
    }


    return response([
        'status'    => 200,
        'message'   => 'Branch / Franchise Status Successfully Updated!',
        'error_msg' => null,
        'data'      => null,
    ]);
}

  public function Delete($id)
  {
    $upd_StaffModel = BranchModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Branch / Franchise Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function View($id)
  {
    $data = BranchModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    if ($data) {
      // Initialize variables
      $html = '';
      $type = '';
      $address_final = '';
      $attach = '';

      if ($data->branch_type == 1) {
        // Branch type
        $type = 'Branch';
        $name = $data->branch_name;
        $business_name = '';
        $height_set = '225px';
      } else {
        $type = 'Franchise';
        $height_set = '320px';
        $name = $data->franchise_name;
        $business_name =    '<div class="col-lg-12 mb-2 d-flex align-items-center">
                                <label class="fw-semibold fs-6 me-1">
                                    <i class="mdi mdi-account-tie-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Name"></i>
                                    <label class="fw-semibold fs-6">' . htmlspecialchars($data->business_name) . '</label>
                                </label>
                            </div>
                            <div class="col-lg-12 mb-2 d-flex align-items-center">
                                <label class="fw-semibold fs-6 me-1">
                                    <i class="mdi mdi-badge-account-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Person Name"></i>
                                    <label class="fw-semibold fs-6">' . htmlspecialchars($data->business_person_name) . '</label>
                                </label>
                            </div>';
      }

      $cat_name = $helper->get_branch_category_id($data->branch_category)->branchtype_name ?? '';
      $time_zone_country = $helper->get_time_zone_id($data->time_zone_id)->country  ?? '';
      $time_zone_utc_offset = $helper->get_time_zone_id($data->time_zone_id)->utc_offset  ?? '';
      $time_zone =  $time_zone_country . '( UTC ' . $time_zone_utc_offset . ' )';
      $currency_format = $helper->get_currency_format_id($data->currency_id)->currency_code ?? '';

      // Branch course assign
      $branch_course = CourseAssigne_model::where('branch_id', $data->sno)->first();
      if ($branch_course) {
        $course_date = date('d-M-Y', strtotime($branch_course->assign_date));

        $course_type_id = $branch_course->course_type_id ?? '[]';
        $course_type = [];
        if (!empty($course_type_id)) {
          foreach (json_decode($course_type_id) as $value) {
            $course_type_name =
              $helper->get_course_type_data($value)->course_type_name ??
              '';
            $course_type[] = ltrim($course_type_name, ',');
          }
        }
        $course_type_set_data = implode(', ', $course_type);

        $branch_course_id = $branch_course->course_id ?? '[]';
        $branch_course = [];
        if (!empty($branch_course_id)) {
          foreach (json_decode($branch_course_id) as $value) {
            $name2 = $helper->get_course_data($value)->course_name ?? '';
            $branch_course[] = ltrim($name2, ',');
          }
        }
        $branch_course_set_data = implode(', ', $branch_course);
        $branch_course_set_data = '';
        foreach ($branch_course as $index => $course) {
          $branch_course_set_data .= ($index + 1) . ". " . $course . "\n";
        }
      } else {
        $course_date = '-';
        $course_type_set_data = '-';
        $branch_course_set_data = '-';
      }

      // Construct address string
      $address = [];
      $address[] = $data->door_no;
      $address[] = $data->area_street;
      $address[] = $helper->get_city_data($data->city_id)->name ?? '-';
      $address[] = $helper->get_state_data($data->state_id)->name ?? '-';
      $address[] = $helper->get_country_data($data->country_id)->name ?? '-';
      $address[] = $data->pincode;
      $address = array_filter($address);
      $address_final = implode(', ', $address);
      // Trim leading/trailing spaces and commas
      $address_final = trim($address_final, ', ');

      // Fetch franchise document attachments
      $frattachment_data = FranchiseDocumentModel::where('franchise_id', $data->sno)
        ->where('status', '!=', 2)
        ->get();

      $row = '';
      // Initialize the row variable for attachments
      foreach ($frattachment_data as $key => $fdata) {
        $files = [];
        if (!empty($fdata->document)) {
          $decodedFiles = json_decode($fdata->document, true);
          if (is_array($decodedFiles)) {
            $files[$key] = $decodedFiles;
          }
        }

        // Generate attachment HTML
        foreach ($files[$key] as $fkey => $file) {
          $link = asset('branch_attachments/branch_' . $data->sno . '/' . $fdata->documenttype_id . '_' . $key . '/' . $file);
          $dc_name = $helper->get_document_id($fdata->documenttype_id)->documenttype_name ?? '';
          if (file_exists(public_path('branch_attachments/branch_' . $data->sno . '/' . $fdata->documenttype_id . '_' . $key . '/' . $file))) {
            $row .= '
                        <div class="col-lg-6">
                           <label class="fs-6 text-secondary fw-bold text-center">' . $dc_name . '
                            <div class="d-block overlay text-center me-3 mb-3 ms-3 mt-3 card border border-gray-600 border-dashed" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($file) . '">
                              <div class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" style="background-image:url(' . htmlspecialchars($link) . ')"></div>
                              <div class="overlay-layer card-rounded bg-dark bg-opacity-75 shadow w-100px h-100px">
                                  <a class="justify-content-end align-items-center" href="' . htmlspecialchars($link) . '" download>
                                      <i class="mdi mdi-download-circle-outline text-white fs-3 text-hover-success ms-7"></i>
                                  </a>
                              </div>
                            </div>
                          </label>
                        </div>';
          }
        }
      }
      $head = $data->authority_id ?? '';
      $person_div = '';
      if ($head > 0) {
        $staff = $helper->get_staff_data($head);
        $position = $helper->get_position_id($staff->position_role)->job_position_name;
        $person_div = '
                  <div class="col-lg-12 mb-3">
                      <div class="card">
                          <div class="card-body px-2 py-2">
                              <div class="row mb-2">
                                  <div class="col-lg-12 mb-2">
                                      <div class="mb-2">
                                          <h4 class="fs-5 fw-bold">Center Head Details</h4>
                                      </div>
                                  </div>
                                  <div class="col-lg-6">
                                      <div class="d-flex align-items-center justify-content-start">
                                          <div class="align-items-center me-2">
                                              <img src="' . asset('staff_images/' . $staff->staff_image) . '" alt="user" class="w-50px h-50px rounded-circle">
                                          </div>
                                          <div class="d-block">
                                              <div>
                                                  <label class="fs-6 me-2 fw-semibold text-black">' . htmlspecialchars($staff->staff_name) . '</label>
                                              </div>
                                              <label class="text-primary fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Position">' . $position . '</label>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-lg-6 mb-2">
                                      <label class="fw-semibold fs-6">
                                          <i class="mdi mdi-cellphone fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile Number"></i>
                                          ' . htmlspecialchars($staff->mobile_no) . '
                                      </label>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }
      // Main HTML content for Branch type
      $html = '
            <div class="mb-4">
                <h3 class="mb-4 text-black text-center">View Franchise</h3>
            </div>
            <div class="container-xxl">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="mt-4 mb-2">' . htmlspecialchars($name) . '</h3>
                    </div>
                    <div class="col-lg-4 border-right mb-4 rounded">
                        <div class="card">
                            <div class="card-body min-h-500px">
                                <div class="row">
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-alpha-c-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch Category"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($cat_name) . '</label>
                                    </div>
                                    ' . $business_name . '
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-calendar-lock-open fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Opening Date"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars(date('d-M-Y', strtotime($data->opening_date))) . '</label>
                                    </div>
                                    <div class="col-lg-12">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-handshake-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Share for Brand in Percentage"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->share_percentage) . '%</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-calendar-clock fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Share Date"></i>
                                        </label>
                                        <label class="fw-semibold fs-6"><span class="badge bg-success text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Agreement Start Date">' . htmlspecialchars(date('d-M-Y', strtotime($data->share_start_date))) . '</span> | <span class="badge bg-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Agreement End Date">' . htmlspecialchars(date('d-M-Y', strtotime($data->share_end_date))) . '</span></label>
                                    </div>

                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-web-check fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->website) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-file-percent-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Percentage"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->gst_percentage) . ' %</label>
                                    </div>
                                    
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-file-table-box-multiple-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->gst_no) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-card-account-details-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="PAN No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->pan_no) . '</label>
                                    </div>
                                    <div class="col-lg-12">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-cash fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Royal Fee"></i>
                                        </label>
                                            <label><i class="mdi mdi-currency-rupee fs-5"></i></label>
                                            <label class="fw-semibold fs-6">' . htmlspecialchars(number_format($data->royal_fee  ?? 0, 2, '.', ',')) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class=" mdi mdi-cellphone-lock fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Mobile No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->mobile) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class=" mdi mdi-email-lock-outline fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Business Email Id"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->mail) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class="mdi mdi-email-fast-outline fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Communication Email Id"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->comm_email_id) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class="mdi mdi-cellphone-sound fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="CRE Mobile No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->cre_mobile) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class="mdi mdi-cellphone fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sales Mobile No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->sales_mobile) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-facebook fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facebook"></i>
                                        </label>
                                          <a href="' .  htmlspecialchars($data->fb_link) . '" target="_blank" class="fw-semibold fs-6 text-truncate max-w-200px text-dark">' .  htmlspecialchars($data->fb_link) . '</a>                                      
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-instagram fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Instagram "></i>
                                        </label>
                                         <a href="' .   htmlspecialchars($data->insta_link) . '" target="_blank" class="fw-semibold fs-6 text-truncate max-w-200px text-dark">' .   htmlspecialchars($data->insta_link) . '</a>  
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-google-maps fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($address_final) . '</label>
                                    </div>

                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                          <label class="fw-semibold fs-6 me-2">
                                              <i class=" mdi mdi-order-numeric-ascending fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Latitude & Longitude"></i>
                                          </label>
                                          <label class="fw-semibold fs-6">' . htmlspecialchars($data->latitude) . ' | ' . htmlspecialchars($data->longitude) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class=" mdi mdi-map-marker-radius-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Location URL"></i>
                                        </label>
                                        <a href="' . htmlspecialchars($data->location) . '" target="_blank" class="fw-semibold fs-6 text-truncate max-w-200px text-dark">' . htmlspecialchars($data->location) . '</a>
                                    </div>

                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-2">
                                            <i class=" mdi mdi-order-numeric-ascending fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="CIN No"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->tax_no) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class=" mdi mdi-map-clock fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Time Zone"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($time_zone) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class=" mdi mdi-cash-multiple fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Currency Format"></i>
                                        </label>
                                        <label class="fw-semibold fs-6">' . htmlspecialchars($currency_format) . '</label>
                                    </div>
                                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                                        <label class="fw-semibold fs-6 me-1">
                                            <i class="mdi mdi-format-list-text fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                                        </label>
                                        <label class="fw-semibold fs-6 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($data->branch_desc) . '">' . htmlspecialchars($data->branch_desc) . '</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <!-- Add other HTML content here -->
                        <div class="row">
                            ' . $person_div . '

                            <div class="col-lg-12 mb-3">
                                <div class="card">
                                    <div class="card-body px-2 py-2">
                                        <div class="row mb-2">
                                            <div class="col-lg-12 mb-2">
                                                <div class="mb-2">
                                                    <h4 class="fs-5 fw-bold">Account Details</h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-account-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Account Holder Name"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_holder) . '</label>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-counter fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Account Number"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_account_no) . '</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-bank fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bank Name"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_name) . '</label>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-office-building-marker fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch Name"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_account_no) . '</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-application-array-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IFSC Code"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_ifsc) . '</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-format-list-text fs-4 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars($data->bank_desc) . '</label>
                                                    </div>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                    <div class="card">
                                        <div class="card-body px-2 py-2">
                                            <div class="row mb-2">
                                                <div class="col-lg-12 mb-2">
                                                    <div class="mb-2">
                                                        <h4 class="fs-5 fw-bold">Collection Info</h4>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="d-flex align-items-center">
                                                        <label class="fw-semibold fs-6 me-1">
                                                            <i class="mdi mdi-close-network-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registration Closing Date"></i>
                                                        </label>
                                                        <label class="fw-semibold fs-6">' . htmlspecialchars(date('d-M-Y', strtotime($data->registeration_close))) . '</label>
                                                    </div>
                                                      <div class="d-flex align-items-center">
                                                          <label class="fw-semibold fs-6 me-1">
                                                              <i class="mdi mdi-close-circle-multiple-outline fs-3 text-black" data-bs-toggle="tooltip"
                                                                  data-bs-placement="bottom" title="Closing Collection Date"></i>
                                                          </label>
                                                          <label class="fw-semibold fs-6">' . htmlspecialchars(date('d-M-Y', strtotime($data->registeration_close))) . '</label>
                                                      </div>
                                                      <div class="d-flex align-items-center">
                                                          <label class="fw-semibold fs-6 me-1">
                                                              <i class="mdi mdi-cash-lock fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                  title="Minimum Amount Receive"></i>
                                                          </label>
                                                          <div class="fw-semibold fs-6">
                                                              <label><i class="mdi mdi-currency-rupee fs-5"></i></label>
                                                              <label class="mt-1 fs-6 fw-semibold">' . htmlspecialchars(number_format($data->min_amnt_receive  ?? 0, 2, '.', ',')) . '</label>
                                                          </div>
                                                      </div>   
                                                </div>                                                    
                                                      <div class="col-lg-6">
                                                          <div class="d-flex align-items-center">
                                                              <label class="fw-semibold fs-6 me-1">
                                                                  <i class="mdi mdi-archive-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                      title="MPC (Minimum Product Cost) Value"></i>
                                                              </label>
                                                              <div class="fw-semibold fs-6">
                                                                  <label><i class="mdi mdi-currency-rupee fs-5"></i></label>
                                                                  <label class="mt-1 fs-6 fw-semibold">' . htmlspecialchars(number_format($data->min_prd_cost ?? 0, 2, '.', ',')) . '</label>
                                                              </div>
                                                          </div>
                                                          <div class="d-flex align-items-center">
                                                              <label class="fw-semibold fs-6 me-1">
                                                                  <i class="mdi mdi-calendar-range fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                      title="MPC Validity"></i>
                                                              </label>
                                                              <label class="fw-semibold fs-6">' . htmlspecialchars($data->min_prd_days) . ' Days</label>
                                                          </div>
                                                          <div class="d-flex align-items-center">
                                                              <label class="fw-semibold fs-6 me-1">
                                                                  <i class="mdi mdi-cash-multiple fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                      title="Last Payment (In %)"></i>
                                                              </label>
                                                              <div class="fw-semibold fs-6">
                                                                 <label class="fw-semibold fs-6">' . htmlspecialchars($data->last_payment) . ' %</label>
                                                              </div>
                                                          </div>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            <div class="col-lg-12 ">
                                                <div class="row">
                                                    <div class="card-body px-2 py-2">
                                                        <h4 class="fs-5 fw-bold">Location</h4>
                                                        <iframe class="w-100 border border-solid rounded" 
                                                            src="' . htmlspecialchars($data->location) . '" 
                                                            style="border: 0px; height: ' . $height_set . ' !important;" 
                                                            allowfullscreen="" 
                                                            loading="lazy" 
                                                            referrerpolicy="no-referrer-when-downgrade">
                                                        </iframe>
                                                    </div>
                                                </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div class="col-lg-4 mb-4">
                                      <h4 class="fs-5 fw-bold">Attachment</h4>
                                      <div class="border border-gray-600 border-dashed rounded py-1 px-1">
                                          <div class="row d-flex mb-1">
                                              ' . $row . '
                                          </div>
                                      </div>
                                    </div>
                                    <div class="col-lg-8 mb-3">
                                <div class="card">
                                  <div class="card-body px-4 py-2">
                                    <div class="row mb-2">
                                      <div class="col-lg-12">
                                          <h4 class="fs-5 fw-bold">Course Assign Info</h4>
                                      </div>
                                      <div class="col-lg-12">
                                        <div class="d-flex align-items-center">
                                          <label class="fw-semibold fs-6 me-1">
                                              <i class="mdi mdi-calendar fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Course Assigning Date"></i>
                                          </label>
                                          <div class="fw-semibold fs-6">' . htmlspecialchars($course_date) . '</div>
                                        </div>
                                      </div>
                                      <div class="col-lg-12">
                                          <div class="d-flex align-items-top">
                                              <label class="fw-semibold fs-6 me-1">
                                                  <i class="mdi mdi-book-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                      title="Course Type"></i>
                                              </label>
                                              <label class="fw-semibold fs-6">' . htmlspecialchars($course_type_set_data) . '</label>
                                          </div>
                                      </div>
                                      <div class="col-lg-12">
                                          <div class="d-flex align-items-top">
                                              <label class="fw-semibold fs-6 me-1">
                                                  <i class="mdi mdi-book-check-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                      title="Course"></i>
                                              </label>
                                              <label class="fw-semibold fs-6">' . nl2br($branch_course_set_data) . '</label>
                                          </div>
                                      </div>
                                    </div>
                                    </div>
                                    </div>
                                  </div>
                                </div>';

      // Return the HTML string as JSON response
      return response()->json([
        'html' => $html,
        'status' => 'success'
      ]);
    } else {
      // Handle case where data is not found
      return response()->json([
        'error_msg' => 'Branch not found'
      ], 404);
    }
  }
  public function create_branch_franchise()
  {
    return view('content.settings.branch.branch.add');
  }

  public function get_course_by_type(Request $request)
  {
    $course_type_ids = $request->input('course_type_ids', []);

    $coursesByType = [];

    foreach ($course_type_ids as $course_type_id) {
      $courses = ManageCoursesModel::where('course_type_id', $course_type_id)->where('status', 0)->get();
      $coursesByType = array_merge($coursesByType, $courses->toArray());
    }

    return response()->json([
      'status' => 200,
      'data' => $coursesByType
    ]);
  }


  public function Add(Request $request)
  {
    // Validate input data
    $validator = Validator::make($request->all(), [
      'branch_franc' => 'required|max:255',
      'branch_category' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }
    $old_chk = BranchModel::where('status', 0)
      ->where('city_short_code', 'like', $request->input('city_short_code', '') . '%')
      ->orderBy('sno', 'desc')
      ->first();

    if ($old_chk) {
      $last_code_number = intval(substr($old_chk->city_short_code, -2));
      $city_short_code = $request->input('city_short_code', '') . str_pad($last_code_number + 1, 2, '0', STR_PAD_LEFT);
    } else {
      $city_short_code = $request->input('city_short_code', '') . '01';
    }

    // Determine branch type and set relevant fields
    $branch = new BranchModel();
    $user_id = 1;
    $branch->branch_type = $request->input('branch_franc');
    if ($request->input('branch_franc') == 2) {
      $branch->branch_name = '';
      $branch->business_name = $request->input('business_name', '');
      $branch->franchise_name = $request->input('franchise_name', '');
      $type_name = 'Franchise';
    } else {
      // Default values if not a franchise
      $branch->branch_name = $request->input('branch_name', '');
      $type_name = 'Branch';
      $branch->business_name = '';
      $branch->franchise_name = '';
    }
    
    $thumbnail_image = $request->file('branch_head_image');
    $thumbnail = '';
    if ($thumbnail_image) {
      $imageName = idate('B') . rand(1, 50) . '.' . $thumbnail_image->extension();
      $destinationPath = public_path('branch_auth_attachments');
      $thumbnail_image->move($destinationPath, $imageName);
      $thumbnail = $imageName;
    }
    // return $thumbnail;

    $thumbnail_image_cert = $request->file('cert_auth_image');
    $thumbnail_cert = '';
    if ($thumbnail_image_cert) {
        // Correct the variable name to $thumbnail_image_cert
        $imageName = idate('B') . rand(1, 70) . '.' . $thumbnail_image_cert->extension();
        $destinationPath = public_path('branch_cert_auth_attachments');
        
        // Make sure the directory exists before moving
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }
    
        // Check if the file exists and move it
        if ($thumbnail_image_cert->isValid()) {
            $thumbnail_image_cert->move($destinationPath, $imageName);
            $thumbnail_cert = $imageName;
        } else {
            // Log error or handle file upload failure
            // For example, you can log this:
            \Log::error('Invalid file or failed upload: ' . $thumbnail_image_cert->getErrorMessage());
        }
    }

    // Generate branch ID
    $branch_check = BranchModel::where('status', ' != ', 2)->orderBy('sno', 'desc')->first();
    $sno = $branch_check ? $branch_check->sno + 1 : 1;
    $year = date('y');
    $branch_code = sprintf('BR-%04d/%s', $sno, $year);
    $branch->branch_id = $branch_code;
    $branch->business_person_name = $request->input('business_person_name', '');
    // Set other fields
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->time_zone_id = $request->input('time_zone', '');
    $branch->currency_id = $request->input('currency_format', '');
    $branch->gst_check = $request->input('gst_check', 0);
    $branch->gst_percentage = $request->input('gst_percentage', 0);
    $branch->call_tracker_branch_id = $request->input('call_tracker_id', 0);
    
    $branch->goalset_last_date    = $request->input('goalset_last_date', 0);
    $branch->goalset_monthend_chk = $request->input('goalset_monthend_chk', 0);

    $branch->gst_no = $request->input('gst_no', '');
    $branch->royal_fee = $request->input('royal_fee', '');
    $branch->pan_no = $request->input('pan_no', '');
    $branch->tax_no = $request->input('tax_no', '');
    $branch->fb_link = $request->input('fb_link', '');
    $branch->insta_link = $request->input('insta_link', '');
    $branch->just_dial_id = $request->input('just_dial_id', '');
    $branch->cloud_call_api_key = $request->input('cloud_call_api_key', '');
    $branch->other_src_staff_id = $request->input('other_src_staff_id', 0);

    $branch->share_percentage = $request->input('share_percentage', '');
    $branch->share_start_date = date('Y-m-d', strtotime($request->input('share_start_date')));
    $branch->share_end_date = date('Y-m-d', strtotime($request->input('share_end_date')));
    // $branch->cre_mobile = $request->input('cre_mobile_no', '');
    // $branch->sales_mobile = $request->input('sales_mobile_no', '');
    $branch->comm_email_id = $request->input('comm_email_id', '');
    $branch->min_amnt_receive = $request->input('min_amnt_receive', '');
    $branch->collection_close = date('Y-m-d', strtotime($request->input('collection_close')));
    $branch->registeration_close = date('Y-m-d', strtotime($request->input('registeration_close')));
    $branch->min_prd_cost = $request->input('min_prd_cost', '');
    $branch->min_prd_days = $request->input('min_prd_days', '');
    $branch->last_payment = $request->input('last_payment', '');
    $branch->branch_category = $request->input('branch_category', '');
    $branch->branch_department = json_encode($request->input('branch_dept'));
    $branch->country_id = $request->input('country', '');
    $branch->state_id = $request->input('state', '');
    $branch->city_id = $request->input('city', '');
    $branch->area_street = $request->input('area_street', '');
    $branch->door_no = $request->input('door_flat_no', '');
    $branch->pincode = $request->input('pincode', '');
    $branch->city_short_code = $city_short_code;
    $branch->mobile = $request->input('business_mobile_no', '');
    $branch->mail = $request->input('business_email_id', '');
    $branch->location = $request->input('location_url', '');
    $branch->website = $request->input('website_url', '');
    $branch->latitude = $request->input('latitude', '');
    $branch->longitude = $request->input('longitude', '');
    $branch->bank_name = $request->input('bank_name', '');
    $branch->bank_branch = $request->input('bank_branch', '');
    $branch->bank_holder = $request->input('bank_holder', '');
    $branch->bank_account_no = $request->input('bank_account_no', '');
    $branch->bank_ifsc = $request->input('bank_ifsc', '');
    $branch->bank_desc = $request->input('bank_desc', '');
    $branch->branch_desc = $request->input('branch_desc', '');
    $branch->cert_auth_name = $request->input('cert_auth_name');
    $branch->branch_head_name = $request->input('branch_head_name');
    $branch->cert_auth_sign = $thumbnail_cert;
    $branch->branch_head_sign = $thumbnail;
    $branch->urban_pro_id = $request->input('urbanpro_id');
    $branch->sulekha_id = $request->input('sulekha_id');
    $branch->created_by = $request->user()->user_id;
    $branch->updated_by = $request->user()->user_id;
    $branch->catalogue_offers = $request->input('catalogue');
    // Handle file uploads
    // $attachments = [];
    // if ( $request->hasFile( 'branch_file' ) ) {
    // foreach ( $request->file( 'branch_file' ) as $file ) {
    // $attachmentName = 'branch_' . $sno . '_' . $file->getClientOriginalName();
    // $file->move( public_path( 'branch_attachments/branch_' . $sno ), $attachmentName );
    // $attachments[] = $attachmentName;
    // }
    // }
    // $branch->branch_attachments = json_encode( $attachments );

    // Save the branch to the database
    $branch->save();

    $document_ids = $request->input('document_type_id') ?? [];
    $i = 0;
    foreach ($document_ids as $key => $did) {
      $frattachments = [];
      if ($request->file('fran_attach_')[$i]) {
        foreach ($request->file('fran_attach_')[$i] as $file2) {
          $frattachmentName = $type_name . $branch->sno . '_' . $did . '_' . $i . '_' . $file2->getClientOriginalName();
          $file2->move(public_path('branch_attachments/branch_' . $branch->sno . '/' . $did . '_' . $i), $frattachmentName);
          $frattachments[] = $frattachmentName;
        }
      }
      // Example of creating a model instance, adjust as per your model structure
      FranchiseDocumentModel::create([
        'franchise_id' => $branch->sno,
        'documenttype_id' => $did,
        'document' => json_encode($frattachments),
        'created_by' => $user_id,
        'updated_by' => $user_id,
      ]);

      $i++;
    }
    // Flash message based on save result
    if ($branch->sno) {
      // session()->flash( 'toastr', [
      // 'type' => 'success',
      // 'message' => 'Branch added Successfully!'
      // ] );
      session()->flash('toastr', [
        'type' => 'info',
        'message' => 'Create Branch Head..!'
      ]);
      session(['branch_type_ses' => $branch->branch_type]);
      session(['branch_id_ses' => $branch->sno]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Branch!'
      ]);
    }
    // return $branch;
    return redirect('hr_management/staff/staff_add');
  }
  public function Edit($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $edit = BranchModel::where('sno', $decryptedValue)->first();
    $frattachment_data = FranchiseDocumentModel::where('franchise_id', $decryptedValue)
      ->where('status', ' != ', 2)
      ->get();
    return view('content.settings.branch.branch.edit', [
      'edit' => $edit,
      'fra_attach_data' => $frattachment_data,
      'id' => $decryptedValue,
    ]);
    // return view( 'content.settings.branch.branch.edit' );
  }
  public function update(Request $request)
  {
    //
    //   return $request;
    // Validate input data
    $validator = Validator::make($request->all(), [
      'branch_franc' => 'required|numeric', // Assuming branch_franc is numeric
      'branch_category' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    // Retrieve branch by sno ( assuming sno is the primary key )
    $edit_sno = $request->input('edit_sno');
    $branch = BranchModel::find($edit_sno);
    if (!$branch) {
      return response()->json([
        'status' => 404,
        'message' => 'Branch not found',
        'data' => null,
      ], 404);
    }

    // Update branch fields based on branch_franc value
    $branch->branch_type = $request->input('branch_franc');
    if ($request->input('branch_franc') == 2) {
      $branch->branch_name = '';
      $branch->business_name = $request->input('business_name', '');
      $branch->franchise_name = $request->input('franchise_name', '');
      $type_name = 'Franchise';
    } else {
      // Default values if not a franchise
      $branch->branch_name = $request->input('branch_name', '');
      $type_name = 'Branch';
      $branch->business_name = '';
      $branch->franchise_name = '';
    }
    
    $thumbnail_image = $request->file('branch_head_image');
    $thumbnail = '';
    if ($thumbnail_image) {
      $imageName = idate('B') . rand(1, 50) . '.' . $thumbnail_image->extension();
      $destinationPath = public_path('branch_auth_attachments');
      $thumbnail_image->move($destinationPath, $imageName);
      $thumbnail = $imageName;
    }
    // return $thumbnail;

    $thumbnail_image_cert = $request->file('cert_auth_image');
    $thumbnail_cert = '';
    if ($thumbnail_image_cert) {
        // Correct the variable name to $thumbnail_image_cert
        $imageName = idate('B') . rand(1, 70) . '.' . $thumbnail_image_cert->extension();
        $destinationPath = public_path('branch_cert_auth_attachments');
        
        // Make sure the directory exists before moving
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0755, true);
        }
    
        // Check if the file exists and move it
        if ($thumbnail_image_cert->isValid()) {
            $thumbnail_image_cert->move($destinationPath, $imageName);
            $thumbnail_cert = $imageName;
        } else {
            // Log error or handle file upload failure
            // For example, you can log this:
            \Log::error('Invalid file or failed upload: ' . $thumbnail_image_cert->getErrorMessage());
        }
    }

    // Set common fields
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->time_zone_id = $request->input('time_zone', '');
    $branch->currency_id = $request->input('currency_format', '');
    $branch->gst_check = $request->input('gst_check', 0);
    $branch->business_person_name = $request->input('business_person_name', '');
    $branch->gst_percentage = $request->input('gst_percentage', 0);
    $branch->call_tracker_branch_id = $request->input('call_tracker_id', 0);
    
    $branch->goalset_last_date    = $request->input('goalset_last_date', 0);
    $branch->goalset_monthend_chk = $request->input('goalset_monthend_chk', 0);
    
    $branch->gst_no = $request->input('gst_no', '');
    $branch->pan_no = $request->input('pan_no', '');
    $branch->royal_fee = $request->input('royal_fee', '');
    $branch->tax_no = $request->input('tax_no', '');
    $branch->fb_link = $request->input('fb_link', '');
    $branch->insta_link = $request->input('insta_link', '');
    $branch->just_dial_id = $request->input('just_dial_id', '');
    $branch->other_src_staff_id = $request->input('other_src_staff_id', 0);
    $branch->share_percentage = $request->input('share_percentage', '');
    $branch->share_start_date = date('Y-m-d', strtotime($request->input('share_start_date')));
    $branch->share_end_date = date('Y-m-d', strtotime($request->input('share_end_date')));
    // $branch->cre_mobile = $request->input('cre_mobile_no', '');
    // $branch->sales_mobile = $request->input('sales_mobile_no', '');
    $branch->comm_email_id = $request->input('comm_email_id', '');
    $branch->min_amnt_receive = $request->input('min_amnt_receive', '');
    $branch->collection_close = date('Y-m-d', strtotime($request->input('collection_close')));
    $branch->registeration_close = date('Y-m-d', strtotime($request->input('registeration_close')));
    $branch->min_prd_cost = $request->input('min_prd_cost', '');
    $branch->min_prd_days = $request->input('min_prd_days', '');
    $branch->last_payment = $request->input('last_payment', '');
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->cloud_call_api_key = $request->input('cloud_call_api_key', '');
    $branch->branch_category = $request->input('branch_category', '');
    $branch->branch_department = json_encode($request->input('branch_dept'));
    $branch->country_id = $request->input('country', '');
    $branch->state_id = $request->input('state', '');
    $branch->city_id = $request->input('city', '');
    $branch->area_street = $request->input('area_street', '');
    $branch->door_no = $request->input('door_flat_no', '');
    $branch->pincode = $request->input('pincode', '');
    // $branch->city_short_code = $request->input( 'city_short_code', '' ) . str_pad( $edit_sno, 2, '0', STR_PAD_LEFT );
    $branch->mobile = $request->input('business_mobile_no', '');
    $branch->mail = $request->input('business_email_id', '');
    $branch->location = $request->input('location_url', '');
    $branch->website = $request->input('website_url', '');
    $branch->latitude = $request->input('latitude', '');
    $branch->longitude = $request->input('longitude', '');
    $branch->bank_name = $request->input('bank_name', '');
    $branch->bank_branch = $request->input('bank_branch', '');
    $branch->bank_holder = $request->input('bank_holder', '');
    $branch->bank_account_no = $request->input('bank_account_no', '');
    $branch->bank_ifsc = $request->input('bank_ifsc', '');
    $branch->bank_desc = $request->input('bank_desc', '');
    $branch->branch_desc = $request->input('branch_desc', '');
    $branch->cert_auth_name = $request->input('cert_auth_name');
    $branch->branch_head_name = $request->input('branch_head_name');
    $branch->cert_auth_sign = $thumbnail_cert;
    $branch->branch_head_sign = $thumbnail;
    $branch->urban_pro_id = $request->input('urbanpro_id');
    $branch->sulekha_id = $request->input('sulekha_id');
    $branch->catalogue_offers = $request->input('catalogue');
    // Set audit fields
    $user_id = 1;
    // Replace with actual authenticated user ID
    $branch->updated_by = $request->user()->user_id;

    // Handle file uploads

    // Save updated branch details
    $branch->save();
    // return $request;

    // Handle franchise documents if branch_franc is 2
    $document_ids = $request->input('document_type_id', []);
    $edit_atch = $request->input('edit_atch', []);
    $i = 0;

    foreach ($document_ids as $key => $did) {
      $atta_sno = $edit_atch[$key] ?? '';

      // Handle franchise document updates or creation
      if ($atta_sno != '') {
        $frattachments = [];

        // Check if new files are uploaded
        if (isset($request->file('fran_attach_')[$i])) {
          foreach ($request->file('fran_attach_')[$i] as $file2) {
            $frattachmentName = $type_name . $edit_sno . '_' . $did . '_' . $i . '_' . $file2->getClientOriginalName();
            $file2->move(public_path('branch_attachments/branch_' . $edit_sno . '/' . $did . '_' . $i), $frattachmentName);
            $frattachments[] = $frattachmentName;
          }
        } else {
          // If no new files, retain existing attachments
          $oldfile = $request->fran_attach_hidden[$i] ?? [];
          $decodedFiles = json_decode($oldfile, true);
          foreach ($decodedFiles as $file) {
            $frattachments[] = $file;
          }
        }

        // Update existing franchise document
        $fra_attach = FranchiseDocumentModel::find($atta_sno);
        if ($fra_attach) {
          $fra_attach->update([
            'franchise_id' => $edit_sno,
            'documenttype_id' => $did,
            'document' => json_encode($frattachments),
            'updated_by' => $user_id,
          ]);
        }
      } else {
        // Create new franchise document
        $frattachments = [];
        if ($request->file('fran_attach_')[$i]) {
          foreach ($request->file('fran_attach_')[$i] as $file2) {
            $frattachmentName = $type_name . $edit_sno . '_' . $did . '_' . $i . '_' . $file2->getClientOriginalName();
            $file2->move(public_path('branch_attachments/branch_' . $edit_sno . '/' . $did . '_' . $i), $frattachmentName);
            $frattachments[] = $frattachmentName;
          }
        } else {
          // If no new files, retain existing attachments
          $oldfile = $request->fran_attach_hidden[$i] ?? [];
          $decodedFiles = json_decode($oldfile, true);
          foreach ($decodedFiles as $file) {
            $frattachments[] = $file;
          }
        }

        // Create new franchise document record
        FranchiseDocumentModel::create([
          'franchise_id' => $edit_sno,
          'documenttype_id' => $did,
          'document' => json_encode($frattachments),
          'created_by' => $user_id,
          'updated_by' => $user_id,
        ]);
      }
      $i++;
    }

    // Flash message based on save result
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Branch updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Branch!'
      ]);
    }
    // return $request;
    // Redirect to branch list page
    return redirect('/branch');
  }
  public function Add_staff_assignee(Request $request)
  {

    $edit_sno = $request->input('update_sno');
    $branch = BranchModel::find($edit_sno);
    $branch->authority_id = $request->input('staff_assignee_add', '');
    $branch->save();
    // Flash message based on save result
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff Assigned Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Staff Assignee!'
      ]);
    }

    // return $request;
    return redirect('/branch');
  }
  public function Add_staff_branch(Request $request)
  {
    $id = $request->input('id');
    $type = $request->input('type');
    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');

    session(['branch_type_ses' => $type]);
    session(['branch_id_ses' => $id]);
    return response()->json(['id' => $id, 'type' => $type]);
    // return redirect( '/hr_management/staff/staff_add' );
  }

  public function Edit_staff_Cug_modal(Request $request)
  {
    // return $request;
    $edit_sno = $request->input('edit_sno_cug');
    $job_position_ids = $request->input('job_position_cug_edit');
    $staff_ids = $request->input('staff_cug_edit');
    $mobile_no = $request->input('mobile_no_cug_edit');

    // return $job_position_id;
    $cug_array = [];
    foreach ($job_position_ids as $index => $value) {
      if (isset($staff_ids[$index]) && isset($mobile_no[$index]) && $value !== '') {
        $cug_array[] = [
          'job_position' => $value,
          'staff_id' => $staff_ids[$index],
          'mobile_no' => $mobile_no[$index],
        ];
      }
    }
    // return $cug_array;
    $cug_datas = json_encode($cug_array);
    $branch = BranchModel::find($edit_sno);

    $branch->staff_cug = $cug_datas;
    $branch->update();
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the CUG to Staff Assignee!'
      ]);
    }
    return redirect('/branch');
  }

  public function Add_staff_Cug_modal(Request $request)
  {

    $edit_sno = $request->input('add_sno_cug');
    $cre_cug_add = $request->input('cre_cug_add');
    $cre_mobile_no_cug_add = $request->input('cre_mobile_no_cug_add');
    $job_position_ids = $request->input('job_position_cug_add');
    $staff_ids = $request->input('staff_cug_add');
    $mobile_no = $request->input('mobile_no_cug_add');


    foreach ($job_position_ids as $index => $value) {
      $cug_manage_add = new CugManagementModel();
      $cug_manage_add->branch_id = $edit_sno;
      $cug_manage_add->job_position_id = $value;
      $cug_manage_add->cre_id = $cre_cug_add;
      $cug_manage_add->cre_mobile = $cre_mobile_no_cug_add;
      $cug_manage_add->staff_id = $staff_ids[$index];
      $cug_manage_add->staff_mobile = $mobile_no[$index];
      $cug_manage_add->created_by = $request->user()->user_id;
      $cug_manage_add->updated_by = $request->user()->user_id;
      // dd($cug_manage_add);
      $cug_manage_add->save();
    }
    // dd($cug_manage_add);


    $branch = BranchModel::find($edit_sno);
    if ($branch) {
      $branch->cre_id = $cre_cug_add;
      $branch->cre_mobile = $cre_mobile_no_cug_add;
      $branch->save();
    }

    // Return success or error message
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Add Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the CUG to Staff Assignee!'
      ]);
    }

    return redirect('/branch');
  }

  public function Job_postion_to_Cug(Request $request)
  {

    $branch_id = $request->user()->branch_id;


    $job_position = JobpositionModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // dd($job_position);
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,

    ], 200);
  }

  public function Staff_based_on_role($id, Request $request)
  {

    $branchId = $request->query('branchId');
    $roleId = $id;


    $staff_data = StaffModel::where('branch_id', $branchId)->where('position_role', $roleId)->where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff_data,

    ], 200);
  }

  public function Update_staff_Cug_modal(Request $request)
  {
    // return $request;
    $branch_id = $request->input('edit_sno_cug');
    $cre_cug_edit = $request->input('cre_cug_edit');
    $cre_mobile_no_cug_edit = $request->input('cre_mobile_no_cug_edit');
    $edit_sno = $request->input('edit_sno_cug_management');
    $job_position_ids = $request->input('job_position_cug_edit');
    $staff_ids = $request->input('staff_cug_edit');
    $mobile_no = $request->input('mobile_no_cug_edit');
    foreach ($job_position_ids as $index => $value) {

      if (isset($edit_sno[$index])) {
        $edit = CugManagementModel::find($edit_sno[$index]);
        if ($edit) {
          $edit->branch_id = $branch_id;
          $edit->job_position_id = $value;
          $edit->cre_id = $cre_cug_edit;
          $edit->cre_mobile = $cre_mobile_no_cug_edit;
          $edit->staff_id = $staff_ids[$index];
          $edit->staff_mobile = $mobile_no[$index];
          $edit->updated_by = $request->user()->user_id;  // For update user              
          $edit->update();
        }
      } else {
        $update = new CugManagementModel();
        $update->branch_id = $branch_id;
        $update->job_position_id = $value;
        $update->cre_id = $cre_cug_edit;
        $update->cre_mobile = $cre_mobile_no_cug_edit;
        $update->staff_id = $staff_ids[$index];
        $update->staff_mobile = $mobile_no[$index];
        $update->created_by = $request->user()->user_id;  // For create user
        $update->updated_by = $request->user()->user_id;  // For update user
        $update->save();
      }
    }

    $branch = BranchModel::find($branch_id);
    if ($branch) {
      $branch->cre_id = $cre_cug_edit;
      $branch->cre_mobile = $cre_mobile_no_cug_edit;
      $branch->update();
    }


    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the CUG to Staff Assignee!'
      ]);
    }

    // Redirect back to the branch page
    return redirect('/branch');
  }

  public function Cre_Dropdown(Request $request)
  {

    $branchId = $request->query('branchId');

    $cre_role = StaffModel::select('za_staff.*', 'za_user_role.role_name')
      ->leftJoin('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
    //   ->where('za_staff.role_id', 16)
      ->where('za_staff.branch_id', $branchId)
      ->where('za_staff.status', 0)
      ->get();
    // return  $cre_role;

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $cre_role,

    ], 200);
  }
  public function Cug_Edit_Fetch(Request $request)
  {
    $branchId = $request->query('branchId');

    $edit = CugManagementModel::where('za_cug_management.branch_id', $branchId)
      ->where('za_cug_management.status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $edit,

    ], 200);
  }
  
  

  public function Cug_delete(Request $request)
  {
    $sno = $request->input('sno');

    $delete =  CugManagementModel::where('sno', $sno)->first();
    $delete->status  = 2;
    $delete->Update();
    if ($delete) {
      return response([
        'status'    => 200,
        'message'   => 'CUG Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete CUG!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function checkUniqueMobileNumber(Request $request)
  {
    $mobile = $request->query('mobile');

    $exists = CugManagementModel::where('staff_mobile', $mobile)->exists();

    if ($exists) {
      return response()->json(1);  // Mobile number is already taken
    } else {
      return response()->json(0);  // Mobile number is unique
    }
  }
  
    // Staff Mobile access Panel   
   public function StaffAccessApp($id,Request $request)
  {
      
    //   $id = $request->id;
      $branch_data = DB::table('za_branch')
      ->select(
      'za_branch.branch_name',
      'za_branch.franchise_name',
      'za_branch.branch_type' ,
      'za_branch.door_no',
      'za_branch.area_street',
      'za_branch.pincode',
      'za_cities.name as city_name',
      'za_states.name as state_name')
      ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
      ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
      ->where('za_branch.status', '!=', 2)
      ->where('za_branch.sno', $id)
      ->first(); 

      $branch_name = " ";
      if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
      } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
      }
      $branch_data->branch_name =$branch_name ;
      $branch_data->branch_type_name = $branch_data->branch_type == 1 ? 'Branch' : 'Franchise' ;

      $address = ($branch_data->door_no ? $branch_data->door_no . ", " : "")
      . ($branch_data->area_street ? $branch_data->area_street . ", " : "")
      . ($branch_data->city_name ? $branch_data->city_name . ", " : "")
      . ($branch_data->state_name ? $branch_data->state_name : "")
      . ($branch_data->pincode ? " - " . $branch_data->pincode : "");

      $branch_data->address = $address;

        $staff_data = DB::table('za_staff')
                ->select('za_staff.*','za_cug_management.staff_mobile as cug_mobile_no','za_job_position.job_position_name as position_name')
                ->leftJoin('za_cug_management', 'za_staff.sno', '=', 'za_cug_management.staff_id')
                ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
                ->where('za_staff.status', 0)
                ->where('za_staff.branch_id', $id)
                ->orderBy('za_staff.department_id', 'asc')
                ->get();
              
          foreach( $staff_data as $single){

            $app_data = DB::table('za_mobile_app')
              ->select('za_mobile_app.*')
              ->where('za_mobile_app.status', 0)
              ->orderBy('za_mobile_app.sno', 'asc')
              ->get();
              $staff_access = [];
              $access_app_ids = json_decode($single->access_app_ids, true); 
              foreach( $app_data as $app){

                if (is_array($access_app_ids) && in_array($app->sno, $access_app_ids)) {
                    $access = 1; // The staff has access to this app
                } else {
                    $access = 0; // The staff does not have access to this app
                }
                  $staff_access[] = [
                      'access_name' => $app->mobile_app_name,
                      'access_desc' => $app->mobile_app_desc,
                      'access' => $access,
                      'id' =>$app->sno,
                  ];
               
              }
              $single->staff_access = $staff_access;
            
          }
       
         
          $branch_data->staff_list = $staff_data;
     
     
      return response()->json([
          'status' => 200,
          'success' => true,
          'message' => null,
          'error_msg' => null,
          'data' => $branch_data ,
      ], 200);
  }

  public function updateStaffAccess(Request $request)
  {

    // return $request;
      
      $staff_access_ids =$request->staff_access_ids;
      foreach ($staff_access_ids as $staff_sno) {
          // Retrieve the specific staff member by their sno
          $staff = StaffModel::find($staff_sno);
          if ($staff) {
              $updated_access = [];
              $access_key = 'access_chk_' . $staff_sno;
              if ($request->has($access_key)) {
                  $access_values = $request->input($access_key);
                  $access_values = array_filter($access_values, function ($value) {
                      return $value !== null;
                  });
                  $updated_access = array_values($access_values); // Re-indexed array
              }
              // Encode the updated access_app_ids into JSON format
              $staff->access_app_ids = json_encode($updated_access);
              $staff->save();
          }
      }

      // Flash success message
      session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Access updated successfully!'
      ]);

      // Redirect back to the interview management page
      return redirect('/branch');
  }
  
    public function Cug_Mail_Edit_Fetch(Request $request)
  {
    $branchId = $request->query('branchId');

    $edit = CugManagementModel::where('za_cug_management.branch_id', $branchId)
      ->where('za_cug_management.status', 0)
      ->get();

    // return $edit;

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $edit,

    ], 200);
  }
  
    public function checkUniqueMailId(Request $request)
  {
    $mail_id = $request->query('mail_id');

    $exists = CugManagementModel::where('staff_mail_id', $mail_id)->exists();

    if ($exists) {
      return response()->json(1);  // Mobile number is already taken
    } else {
      return response()->json(0);  // Mobile number is unique
    }
  }

  public function Update_staff_Cug_mail(Request $request)
  {
    // return $request;
    $branch_id = $request->input('edit_sno_mcug');
    $cre_cug_edit = $request->input('cre_mcug_edit');
    $cre_mail_id_cug_edit = $request->input('cre_mail_id_cug_edit');
    $edit_sno = $request->input('edit_sno_mcug_management');
    $job_position_ids = $request->input('job_position_mcug_edit');
    $staff_ids = $request->input('staff_mcug_edit');
    $mail_id = $request->input('mail_id_cug_edit');
    foreach ($job_position_ids as $index => $value) {

      if (isset($edit_sno[$index])) {
        $edit = CugManagementModel::find($edit_sno[$index]);
        if ($edit) {
          $edit->branch_id = $branch_id;
          $edit->job_position_id = $value;
          $edit->cre_id = $cre_cug_edit;
          $edit->cre_mail_id = $cre_mail_id_cug_edit;
          $edit->staff_id = $staff_ids[$index];
          $edit->staff_mail_id = $mail_id[$index];
          $edit->updated_by = $request->user()->user_id;  // For update user     
          // return $edit;         
          $edit->update();
        }
      } else {
        $update = new CugManagementModel();
        $update->branch_id = $branch_id;
        $update->job_position_id = $value;
        $update->cre_id = $cre_cug_edit;
        $update->cre_mail_id = $cre_mail_id_cug_edit;
        $update->staff_id = $staff_ids[$index];
        $update->staff_mail_id = $mail_id[$index];
        $update->created_by = $request->user()->user_id;  // For create user
        $update->updated_by = $request->user()->user_id;  // For update user
        return $update;
        $update->save();
      }
    }

    $branch = BranchModel::find($branch_id);
    if ($branch) {
      $branch->cre_id = $cre_cug_edit;
      $branch->cre_mail_id = $cre_mail_id_cug_edit;
      $branch->update();
    }


    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the CUG to Staff Assignee!'
      ]);
    }

    // Redirect back to the branch page
    return redirect('/branch');
  }

  public function Add_staff_Cug_mail(Request $request)
  {
    return $request;
    $edit_sno = $request->input('add_sno_cug');
    $cre_cug_add = $request->input('cre_cug_add');
    $cre_mobile_no_cug_add = $request->input('cre_mobile_no_cug_add');
    $job_position_ids = $request->input('job_position_cug_add');
    $staff_ids = $request->input('staff_cug_add');
    $mobile_no = $request->input('mobile_no_cug_add');


    foreach ($job_position_ids as $index => $value) {
      $cug_manage_add = new CugManagementModel();
      $cug_manage_add->branch_id = $edit_sno;
      $cug_manage_add->job_position_id = $value;
      $cug_manage_add->cre_id = $cre_cug_add;
      $cug_manage_add->cre_mobile = $cre_mobile_no_cug_add;
      $cug_manage_add->staff_id = $staff_ids[$index];
      $cug_manage_add->staff_mobile = $mobile_no[$index];
      $cug_manage_add->created_by = $request->user()->user_id;
      $cug_manage_add->updated_by = $request->user()->user_id;
      // dd($cug_manage_add);
      $cug_manage_add->save();
    }
    // dd($cug_manage_add);


    $branch = BranchModel::find($edit_sno);
    if ($branch) {
      $branch->cre_id = $cre_cug_add;
      $branch->cre_mobile = $cre_mobile_no_cug_add;
      $branch->save();
    }

    // Return success or error message
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Add Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the CUG to Staff Assignee!'
      ]);
    }

    return redirect('/branch');
  }

  public function Cug_delete_mail(Request $request)
  {
    $sno = $request->input('sno');

    $delete =  CugManagementModel::where('sno', $sno)->first();
    $delete->status  = 2;
    $delete->Update();
    if ($delete) {
      return response([
        'status'    => 200,
        'message'   => 'CUG Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete CUG!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  
   public function getBranchTargets($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    // if ($decryptedValue === false) {
    //   return redirect()->back()->with('error', 'Invalid Entry');
    // }
    $id = 1;
    
    
      return view('content.settings.branch.branch.branch_target',['branch_id' => $decryptedValue]);
  }
 
   public function getBranchTargetsMetrics(Request $request)
    {   
        $user_id = auth()->user()->user_id;
        $id = $request->branch_id;
         $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id);
    
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
    
        // Merge allowed branch IDs (company + franchise)
        $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
    
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
    
        // Fetch all targets for the month
        $targets = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                      ->whereIn('branch_target.branch_id', $allowedBranchIds) // <- only this branch
                    ->select('branch_target.*', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_type')
                    ->get();
                    
                    // return $targets;
    
        $results = [];
        
        // return $branchControlList;
        foreach ($targets as $target) {
            $branchId = $target->branch_id;
            
               
            
           $lastLogin = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id') // table alias must match
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User') // ensure it's filtering correct model
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->limit(1)
            ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));
            
            if ($lastLogin) {
                $lastLoginCarbon = Carbon::parse($lastLogin);
                
                $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
                $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true); // more accurate format
            } else {
                $lastLoginFormatted = 'N/A';
                $lastLoginDiff = 'N/A';
            }
             $totalLeads = DB::table('za_lead')
                ->where('branch_id', $branchId)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
            // Actual payments (old)
            $totalPaidAmountOld = DB::table('za_old_payments')
                ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
                ->where('za_old_payments.status', '!=', 2)
                ->where('za_old_customer.branch_id', $branchId)
                ->whereIn('za_old_customer.status', [1, 4])
                ->where('za_old_payments.amount', '>', 0)
                ->whereYear('za_old_payments.created_at', $year)
                ->whereMonth('za_old_payments.created_at', $month)
                ->sum('za_old_payments.paidAmount');
    
            // Actual payments (new)
            $totalPaidAmountNew = DB::table('za_payment')
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->where('za_customer.branch_id', $branchId)
                ->where('za_payment.status', 1)
                ->where('za_customer.status', 0)
                ->where('za_payment.amount', '>', 0)
                ->whereYear('za_payment.initialPayDate', $year)
                ->whereMonth('za_payment.initialPayDate', $month)
                ->sum('za_payment.paidAmount');
    
          
             $transaction = DB::table('za_transaction')
                     ->where('za_transaction.branch_id', $branchId)
                      ->whereYear('za_transaction.transaction_date', $year)
                    ->whereMonth('za_transaction.transaction_date', $month)
                     ->sum('za_transaction.credit');
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $transaction;
    
            // Post-sale & pre-sale actuals
            $postSaleActual = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', 1)
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
    
            $preSaleActual = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', 0)
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
                
               
    
            $results[] = [
                'branch_name' => $target->branch_type == 1 ? $target->branch_name : $target->franchise_name,
                 'branch_type' => $target->branch_type,
                  'branch_id' => $target->branch_id,
                'date' => $target->date,
                'target'             => '₹' . number_format($target->monthly_target),
                'post_sale_target' => $target->post_sale,
                'pre_sale_target' => $target->no_of_registrations,
                 'target_actual'      => '₹' . number_format($targetActual),
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                 'lead_total'         => $totalLeads,
                 'last_login' => $lastLogin ? date('d-M-Y h:i A', strtotime($lastLogin)) : 'N/A',
                 'last_login_ago' => $lastLoginDiff,
                 
            ];
        }
    
        return response()->json([
            'status' => 200,
            'data' => $results
        ]);
    }
    public function getBranchChecklist($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    
    $id = $decryptedValue;
     $branch_data = DB::table('za_branch')
      ->select(
      'za_branch.branch_name',
      'za_branch.franchise_name',
      'za_branch.branch_type' ,
       'za_branch.sno',
      'za_branch.door_no',
      'za_branch.area_street',
      'za_branch.pincode',
      'za_cities.name as city_name',
      'za_states.name as state_name')
      ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
      ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
      ->where('za_branch.status', '!=', 2)
      ->where('za_branch.sno', $id)
      ->first(); 

    
      return view('content.settings.branch.branch.branch_checklist',['id' => $decryptedValue,'branch_data'=> $branch_data]);
  }
    
    public function getCheckList(Request $request)
     {
        $branchId = $request->branch_id;
        $result = [];
    
           function formatRange($datetime) {
                if (!$datetime) return null;
            
                $diff = Carbon::parse($datetime)->diff(Carbon::now());
            
                $parts = [];
                if ($diff->y > 0) $parts[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
                if ($diff->m > 0) $parts[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
                if ($diff->d > 0) $parts[] = $diff->d . ' day' . ($diff->d > 1 ? 's' : '');
                if ($diff->h > 0) $parts[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
                if ($diff->i > 0) $parts[] = $diff->i . ' min' . ($diff->i > 1 ? 's' : '');
                if ($diff->s > 0) $parts[] = $diff->s . ' sec' . ($diff->s > 1 ? 's' : '');
            
                return $parts ? implode(' ', $parts) : 'just now';
            }
    
        // 1. Last Login
        $login = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id')
            ->join('za_staff', 'user.user_id', '=', 'za_staff.sno')
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User')
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->select(DB::raw('COALESCE(pat.last_used_at, za_staff.updated_at) as datetime'), 'za_staff.staff_name as who','za_department.department_name')
            ->first();
            
            // Determine verification status
            $verifiedStatus = 'Not Verified';
            if (!empty($login->datetime)) {
                $loginTime = \Carbon\Carbon::parse($login->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatus = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Login',
            'datetime' => $login->datetime ?? null,
            'range' => formatRange($login->datetime ?? null),
            'who' => $login->who ?? null,
              'department' => $login->department_name ?? null,
             'payment' => '',
             'attendance' => '',
             'Status' => 'Staff',
             'Verified'    => $verifiedStatus,
        ];
    
        // 2. Last Lead
        $lead = DB::table('za_lead as l')
            ->join('users as u', 'u.id', '=', 'l.created_by')
            ->where('l.branch_id', $branchId)
            ->orderByDesc('l.created_at')
            ->select('l.created_at as datetime', 'l.lead_name as who')
            ->first();
            
             // Determine verification status
            $verifiedStatusLead = 'Not Verified';
            if (!empty($lead->datetime)) {
                $loginTime = \Carbon\Carbon::parse($lead->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusLead = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Lead',
            'datetime' => $lead->datetime ?? null,
            'range' => formatRange($lead->datetime ?? null),
            'who' => $lead->who ?? null,
              'department' => '',
             'payment' => '',
             'attendance' => '',
             'Status' => 'Lead',
             'Verified'    => $verifiedStatusLead,
        ];
    
        // 3. Last Customer
        $customer = DB::table('za_customer as c')
            ->join('users as u', 'u.id', '=', 'c.created_by')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'c.cus_name as who') 
            ->first();
            
             $verifiedStatusCustomer = 'Not Verified';
            if (!empty($customer->datetime)) {
                $loginTime = \Carbon\Carbon::parse($customer->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusCustomer = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Customer',
            'datetime' => $customer->datetime ?? null,
            'range' => formatRange($customer->datetime ?? null),
            'who' => $customer->who ?? null,
             'department' => '',
             'payment' => '',
             'attendance' => '',
             'Status' => 'Customer',
             'Verified'    => $verifiedStatusCustomer,
        ];
    
        // 4. Last Payment
        $payment = DB::table('za_transaction as c')
            ->join('za_customer', 'c.trans_source_id', '=', 'za_customer.customer_id')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'za_customer.cus_name as who', 'c.credit')
            ->first();
             $verifiedStatusPayment = 'Not Verified';
            if (!empty($payment->datetime)) {
                $loginTime = \Carbon\Carbon::parse($payment->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusPayment = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Payment',
            'datetime' => $payment->datetime ?? null,
            'range' => formatRange($payment->datetime ?? null),
            'who' => $payment->who ?? null,
             'department' => '',
             'payment' => $payment->credit ?? null,
             'attendance' => '',
             'Status' => 'Customer',
             'Verified'    => $verifiedStatusPayment,
        ];
    
        // 5. Last Staff Attendance
        $staffAtt = DB::table('za_staff_attendance as c')
            ->join('za_staff', 'c.staff_id', '=', 'za_staff.sno')
             ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'za_staff.staff_name as who','c.attendance','za_department.department_name')
            ->first();
            
             $verifiedStatusstaffAtt = 'Not Verified';
            if (!empty($staffAtt->datetime)) {
                $loginTime = \Carbon\Carbon::parse($staffAtt->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusstaffAtt = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Staff Attendance',
            'datetime' => $staffAtt->datetime ?? null,
            'range' => formatRange($staffAtt->datetime ?? null),
            'who' => $staffAtt->who ?? null,
             'department' => $staffAtt->department_name ?? null,
            'payment' => '',
             'attendance' => $staffAtt->attendance ?? null,
             'Status' => 'Staff',
             'Verified'    => $verifiedStatusstaffAtt,
        ];
    
        // 6. Last Student Attendance
        $studAtt = DB::table('za_attendance as c')
            ->join('za_customer', 'c.customer_id', '=', 'za_customer.sno')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'za_customer.cus_name as who','c.attendance')
            ->first();
            
            
             $verifiedStatusstudAtt = 'Not Verified';
            if (!empty($studAtt->datetime)) {
                $loginTime = \Carbon\Carbon::parse($studAtt->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusstudAtt = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Student Attendance',
            'datetime' => $studAtt->datetime ?? null,
            'range' => formatRange($studAtt->datetime ?? null),
            'who' => $studAtt->who ?? null,
            'department' => '',
             'payment' => '',
             'attendance' => $studAtt->attendance ?? null,
             'Status' => 'Customer',
             'Verified'    => $verifiedStatusstudAtt,
        ];
    
        // 7. Last Appointment
        $appointment = DB::table('za_lead_appointment as c')
            ->join('za_lead', 'c.lead_id', '=', 'za_lead.sno')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'za_lead.lead_name as who')
            ->first();
           $verifiedStatusappo = 'Not Verified';
            if (!empty($appointment->datetime)) {
                $loginTime = \Carbon\Carbon::parse($appointment->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusappo = 'Verified';
                }
            }
        $result[] = [
            'checklist' => 'Last Appointment',
            'datetime' => $appointment->datetime ?? null,
            'range' => formatRange($appointment->datetime ?? null),
            'who' => $appointment->who ?? null,
            'department' => '',
            'payment' => '',
             'attendance' => '',
             'Status' => 'Lead',
             'Verified'    => $verifiedStatusappo,
        ];
    
        // 8. Last Followup
        $followup = DB::table('za_appointment as c')
            ->join('za_lead', 'c.lead_id', '=', 'za_lead.sno')
            ->where('c.branch_id', $branchId)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'za_lead.lead_name as who')
            ->first();
          $verifiedStatusfollo = 'Not Verified';
            if (!empty($followup->datetime)) {
                $loginTime = \Carbon\Carbon::parse($followup->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusfollo = 'Verified';
                }
            }
        $result[] = [
            'checklist' => 'Last Followup',
            'datetime' => $followup->datetime ?? null,
            'range' => formatRange($followup->datetime ?? null),
            'who' => $followup->who ?? null,
            'department' => '',
            'payment' => '',
             'attendance' => '',
             'Status' => 'Lead',
             'Verified'    => $verifiedStatusfollo,
        ];
        $Branch_list = BranchModel::where('status', 0)->where('sno', $branchId)->first();
        // 9. Last Justdial
        $justdial = DB::table('za_justdial_lead as c')
            ->where('c.parentid', $Branch_list->just_dial_id)
            ->orderByDesc('c.created_at')
            ->select('c.created_at as datetime', 'c.lead_name as who')
            ->first();
            
            $verifiedStatusjust = 'Not Verified';
            if (!empty($justdial->datetime)) {
                $loginTime = \Carbon\Carbon::parse($justdial->datetime);
                if ($loginTime->diffInHours(now()) < 24) {
                    $verifiedStatusjust = 'Verified';
                }
            }
    
        $result[] = [
            'checklist' => 'Last Justdial',
            'datetime' => $justdial->datetime ?? null,
            'range' => formatRange($justdial->datetime ?? null),
            'who' => $justdial->who ?? null,
            'department' => '',
            'payment' => '',
            'attendance' => '',
            'Status' => 'Lead',
            'Verified'    => $verifiedStatusjust,
        ];
    
        return response()->json([
            'status' => 200,
            'data' => $result,
        ]);
    }

    
    
   public function getBranchMetrics($id,Request $request){
      
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
        // return $decryptedValue;
        // Check if decryption failed
       
        $id = 1;
        
    
        
          return view('content.settings.branch.branch.branch_metrics',['id' => $decryptedValue,]);
    }
    
    public function get_branch_dashboard_metrics(Request $request)
    {
          $user_id = auth()->user()->user_id;
      
         $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id);
    
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
    
        // Merge allowed branch IDs (company + franchise)
        $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
        
    $month_id = $request->month_id;
    $year = $request->year ?? date('Y');
    
    // Convert month name to number if necessary
    $month = is_numeric($month_id) ? (int) $month_id : date('n', strtotime($month_id . ' 1'));
    $targetDate = $request->year . '-' . $month . '-01';
    // Fetch all active branches
   $branches = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->whereIn('branch_target.branch_id', $allowedBranchIds)
                    ->select('branch_target.*', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_type')
                    ->get();

    $allBranchMetrics = [];

    foreach ($branches as $branch) {
        $branchId = $branch->branch_id;
        
        
        $lastLogin = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id') // table alias must match
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User') // ensure it's filtering correct model
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->limit(1)
            ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));
            
            if ($lastLogin) {
                $lastLoginCarbon = Carbon::parse($lastLogin);
                
                $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
                $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true); // more accurate format
            } else {
                $lastLoginFormatted = 'N/A';
                $lastLoginDiff = 'N/A';
            }

        $totalAllLead = DB::table('za_lead')
            ->where('branch_id', $branchId)
            ->whereNotIn('status', [2, 6])
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->count();

        $monthtotalLeadCount = DB::table('za_lead')
            ->where('branch_id', $branchId)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->where('internal_status', 0)
            ->count();

        $totalMonthLead = DB::table('za_lead')
            ->where('branch_id', $branchId)
            ->whereYear('registered_date', $year)
            ->whereMonth('registered_date', $month)
            ->whereNotIn('status', [2, 6])
            ->where('spam_verified', 0)
            ->where('drop_verified', 0)
            ->where('internal_status', 0)
            ->count();

        $totalConvertCustomer = CustomerModel::join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
            ->whereIn('za_customer.status', [0, 6])
            ->where('za_customer.branch_id', $branchId)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->count();

        // Payments Calculation
        $totalPayment = 0;
        $totalPaidPayment = 0;

        if ($totalConvertCustomer > 0) {
            $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')
                ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                ->where('za_customer.branch_id', $branchId)
                ->whereYear('za_customer.created_at', $year)
                ->whereMonth('za_customer.created_at', $month)
                ->get();

            foreach ($currentMonthCustomer as $customer) {
                $payment = DB::table('za_training')
                    ->where('customer_id', $customer->sno)
                    ->where('tesbo_check', 0)
                    ->sum('overall_fees');

                $totalPayment += $payment;

                $latestTraining = DB::table('za_training')
                    ->where('customer_id', $customer->sno)
                    ->where('tesbo_check', 2)
                    ->orderByDesc('sno')
                    ->first();

                if ($latestTraining) {
                    $totalPayment += $latestTraining->overall_fees;
                }

                $paid_payment = DB::table('za_training')
                    ->where('customer_id', $customer->sno)
                    ->sum('paid_amount');

                $totalPaidPayment += $paid_payment;
            }
        }

        $totalBusinessValue = $totalConvertCustomer > 0 ? round($totalPayment / $totalConvertCustomer, 2) : 0;
        $totalCollectionValue = $totalConvertCustomer > 0 ? round($totalPaidPayment / $totalConvertCustomer, 2) : 0;
        $conversion_rate = $totalMonthLead > 0 ? ($totalConvertCustomer / $totalMonthLead) * 100 : 0;
        $totalConvertRatio = number_format($conversion_rate, 2);

        $incomingCall = DB::table('za_call_tracker')
            ->where('branch_id', $branchId)
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('call_status', 1)
            ->count();

        $outgoingCall = DB::table('za_call_tracker')
            ->where('branch_id', $branchId)
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('call_status', 0)
            ->count();

        $goalteam = GoalSetTeamModel::where('branch_id', $branchId)
            ->where('team_goal_month', $month)
            ->first();

        $notpaidamount = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branchId)
            ->where('za_payment.status', 0)
            ->where('za_customer.status', 0)
            ->where('za_payment.amount', '>', 0)
            ->whereYear('za_payment.nextPayDate', $year)
            ->whereMonth('za_payment.nextPayDate', $month)
            ->where('za_payment.branch_id', $branchId)
            ->sum('za_payment.amount');

        $outstandingAmount = $notpaidamount;

        $allBranchMetrics[] = [
            'branch_id' => $branchId,
            'branch_name' => $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name,
            'city' => $branch->city_name,
             'branch_type' => $branch->branch_type,
            'state' => $branch->state_name,

            'total_lead' => $totalAllLead,
            'total_month_lead' => $monthtotalLeadCount,
            'active_lead' => $totalMonthLead,

            'conversion_over_all' => $goalteam->conversion_over_all ?? 0,
            'conversion_check' => 1,
            'conversion_type' => $goalteam->conversion_type ?? 0,
            'conversion_actual' => $totalConvertCustomer,

            'cr_over_all' => $goalteam->cr_over_all ?? 0,
            'cr_check' => 1,
            'cr_type' => $goalteam->cr_type ?? 0,
            'cr_actual' => $totalConvertRatio,

            'abv_over_all' => $goalteam->abv_over_all ?? 0,
            'abv_check' => 1,
            'abv_type' => $goalteam->abv_type ?? 0,
            'abv_actual' => $totalBusinessValue,

            'acv_over_all' => $goalteam->acv_over_all ?? 0,
            'acv_check' => 1,
            'acv_type' => $goalteam->acv_type ?? 0,
            'acv_actual' => $totalCollectionValue,

            'incoming_call' => $incomingCall,
            'outgoing_call' => $outgoingCall,
            'outstanding' => $outstandingAmount,
            'month' => $month_id,
            'last_login' => $lastLogin ? date('d-M-Y h:i A', strtotime($lastLogin)) : 'N/A',
                 'last_login_ago' => $lastLoginDiff,
        ];
    }

    return response()->json([
        'status' => 200,
        'data' => $allBranchMetrics
    ]);
}


  
   public function getBranchAlert($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
   
    $id = 1;
     $branch_data = DB::table('za_branch')
      ->select(
      'za_branch.branch_name',
      'za_branch.franchise_name',
      'za_branch.branch_type' ,
      'za_branch.door_no',
      'za_branch.area_street',
      'za_branch.pincode',
      'za_cities.name as city_name',
      'za_states.name as state_name')
      ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
      ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
      ->where('za_branch.status', '!=', 2)
      ->where('za_branch.sno', $id)
      ->first(); 

    
      return view('content.settings.branch.branch.branch_alert',['id' => $decryptedValue,'branch_data'=> $branch_data]);
  }
  
  public function getBranchAlertList(Request $request)
  {
      
       $user_id = auth()->user()->user_id;
      
         $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id);
    
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
    
        // Merge allowed branch IDs (company + franchise)
        $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
    $month_id = $request->month_id;
    $year = $request->year ?? date('Y');

    // Convert month name to number if necessary
    $month = is_numeric($month_id) ? (int)$month_id : date('n', strtotime($month_id . ' 1'));
    $targetDate = $year . '-' . $month . '-01';

    // Fetch all active branches with target for the selected month
    $branches = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->where('branch_target.date', $targetDate)
         ->whereIn('branch_target.branch_id', $allowedBranchIds)
        ->select('branch_target.*', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_type')
        ->get();
        
    // Get today's date
    //Attendance Pending
    $today    = today();
    
     $alertData = [];// Initialize as array

     foreach ($branches as $branch) {   
         $branchId = $branch->branch_id;
    
            // Get last login for any user in this branch
            $lastLogin = DB::table('personal_access_tokens as pat')
                ->join('users as user', 'pat.tokenable_id', '=', 'user.id')
                ->where('user.branch_id', $branchId)
                ->where('pat.tokenable_type', 'App\\Models\\User')
                ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
                ->limit(1)
                ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));
    
            if ($lastLogin) {
                $lastLoginCarbon = \Carbon\Carbon::parse($lastLogin);
                $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
                $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true);
            } else {
                $lastLoginFormatted = 'N/A';
                $lastLoginDiff = 'N/A';
            }
    
            $staffCount = DB::table('za_staff')
              ->where('status', 0)
              ->where('branch_id', $branchId)
              ->where('za_staff.position_role', '!=', 49)
              ->count();
            // Query to find staff who are not present today
            $staffNotAttendedCount = DB::table('za_staff')
              ->where('status', 0)
              ->where('branch_id', $branchId)
              ->where('za_staff.position_role', '!=', 49)
              ->whereNotIn('sno', function ($query) use ($today) {
                $query->select('staff_id')
                  ->from('za_staff_attendance')
                  ->where('date', $today);
              })
              ->count();
            $staffAttendedCount = $staffCount - $staffNotAttendedCount;
        
              // outstanding
                $drop_ids = DB::table('za_drop_refund')
                ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
                ->where('za_drop_refund.bh_status', 1)
                ->where('za_drop_refund.branch_id', $branchId)
                ->pluck('za_training.customer_id');
        
                // Get the current date
                $currentDate = now()->subDay()->toDateString();
        
                
                    
                 $OutstandingPaymentss = DB::table('za_payment')
                    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                    ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                    ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_payment.branch_id', $branchId)
                    ->whereNotIn('za_payment.customer_id', $drop_ids)
                    ->where('za_payment.status', 0)
                    ->where('za_payment.amount', '>', 0)
                    ->where('za_customer.status', 0)
                    ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
                    ->select('za_training.training_id')
                    ->groupBy('za_training.training_id')
                    ->orderBy('za_payment.nextPayDate', 'DESC')
                    ->get();
               $OutstandingPayment = $OutstandingPaymentss->count();
        
            //Low Paid
            // Get branch details
            $branch = BranchModel::where('sno', $branchId)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();
        
             $drop_ids = DB::table('za_drop_refund')
                  ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
                  ->where('za_drop_refund.bh_status', 1)
                  ->pluck('za_training.customer_id');
              
                // Sum of the amounts
                $sumScheduleAmount = DB::table('za_payment')
                    ->where('za_payment.branch_id', $branchId)
                    ->sum('za_payment.amount');
        
                $sumBalanceFee = DB::table('za_payment')
                    ->where('za_payment.branch_id', $branchId)
                    ->sum('za_payment.balanceFee');
        
                // Retrieve payments for the given branch and group by customer and course with aggregation
              $PaidUnderPayment = DB::table('za_training')
                  ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
                  ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
                  ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
                  ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
                  ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                  ->select(
                      'za_customer.customer_id',
                      'za_payment.course_id',
                      'za_customer.sno as customer_sno',
                      'za_course.sno as course_sno',
                      'za_customer.cus_name',
                      'za_customer.cus_gender',
                      'za_customer.cus_pic',
                      'za_customer.cus_mobile',
                      'za_customer.cus_email_id',
                      'za_course.course_name',
                      'za_staff.staff_name',
                      'za_training.training_id',
                      'za_training.batch_id',
                      'za_training.payment_id',
                      'za_payment.initialPayDate',
                      'za_training.paid_amount as total_paid_amount',
                     'za_training.balance_amount as total_balance_fee',
                     'za_training.overall_fees as total_amount',
                      DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
                      'za_payment.payment_mode_label',
                      'za_payment.nextPayDate'
                  )
                  ->where('za_payment.branch_id', $branchId)
                   ->whereNotIn('za_customer.sno', $drop_ids)
                  ->where('za_training.status', '!=',2)
                  ->where('za_training.balance_amount', '!=',0)
                  ->groupBy(
                      'za_customer.customer_id',
                      'za_customer.sno',
                      'za_course.sno',
                      'za_customer.cus_name',
                      'za_customer.cus_mobile',
                      'za_customer.cus_pic',
                      'za_customer.cus_gender',
                      'za_customer.cus_email_id',
                      'za_course.course_name',
                      'za_training.training_id',
                      'za_training.payment_id',
                       'za_staff.staff_name',
                        'za_training.batch_id',
                       'za_training.paid_amount',
                     'za_training.balance_amount',
                     'za_training.overall_fees',
                      'za_payment.payment_mode_label',
                      'za_payment.nextPayDate',
                      'za_payment.initialPayDate',
                      'za_payment.course_id'
                  )
                //   ->orderByDesc('za_payment.sno')
                ->orderBy('za_payment.nextPayDate', 'asc')
                  ->get()
                  ->unique('payment_id'); // Keep only unique customer records;
              //   return $PaidUnderPayment;
              // Filter the results for customers with unpaid or insufficient amounts (below min_required)
              $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                  return $payment->total_paid_amount < $branch->min_prd_cost ?? 8000;
              });
           
            
              // Group by customer_id
              $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
                  // Filter payments where paidAmount is greater than 0
                  $filteredPayments = $payments->filter(function ($payment) {
                      return $payment->total_paid_amount > 0;
                  });
            
                  // If no valid payments exist after filtering, exclude this customer
                  if ($filteredPayments->isEmpty()) {
                      return null;
                  }
            
                  $payment = $payments->first();
                  // Return structured data for each customer
                  return [
                      'customer_name' => $payment->cus_name,
                      'customer_sno' => $payment->customer_sno,
                      'total_paid' => $payment->total_paid_amount,
                      'min_required' => $branch->min_prd_cost,
                      'status' => 'Pending',
                      'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                          return [
                              'course_name' => $payment->course_name,
                              'cus_gender' => $payment->cus_gender,
                              'cus_pic' => $payment->cus_pic,
                              'staff_name' => $payment->staff_name,
                              'batch_id' => $payment->batch_id,
                              'training_id' => $payment->training_id,
                              'payment_id' => $payment->payment_id,
                              'cus_name' => $payment->cus_name,
                              'cus_mobile' => $payment->cus_mobile,
                              'amount' => $payment->total_amount,
                              'paidAmount' => $payment->total_paid_amount,
                              'balanceFee' => $payment->total_balance_fee,
                              'gst_amount' => $payment->total_gst_amount,
                              'nextPayDate' => $payment->nextPayDate,
                              'initialPayDate' => $payment->initialPayDate,
                              'payment_mode_label' => $payment->payment_mode_label,
                          ];
                      })->values(), // Reset array keys
                  ];
              })->filter();
          
              // Calculate the total number of pages
              $totalItems = $finalResult->count();
        
            // not Yet Started Count
            $batch_Data = DB::table('za_training')
              ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
              ->where('za_training.branch_id', $branchId)
              ->where('za_customer.status',0)
              ->get();
        
        
            $dropCount = 0;
            $activeCount = 0;
            $notYetStartedCount = 0;
            $scheduleCount = 0;
        
            $processed_drop_customers = [];
            $processed_active_customers = [];
            $processed_schedule_customers = [];
            $processed_not_started_customers = [];
        
            foreach ($batch_Data as $singledata) {
              if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
              }
              if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
              }
            }
        
            $batch_active_Data = DB::table('za_training')
              ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
              ->whereNotNull('za_training.start_date')
              ->where('za_training.branch_id', $branchId)
              ->where('za_customer.status',0)
              ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->get();
        
        
            foreach ($batch_active_Data as $singledata) {
              if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                  continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                  $activeCount++;
                  $processed_active_customers[] = $singledata->customer_id;
                }
              }
            }
        
        
            $batch_Data_old = DB::table('za_training')
              ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
              ->where('za_training.branch_id', $branchId)
              ->where('za_customer.status',0)
              ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->get();
        
        
            // return  $processed_active_customers;
            foreach ($batch_Data_old as $singledata) {
        
              if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (!in_array($singledata->customer_id, $processed_active_customers)) {
                  if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                    continue;
                  }
                  if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
                    $scheduleCount++;
                    $processed_schedule_customers[] = $singledata->customer_id;
                  }
                }
              }
            }
            
            $batch_notyetStated = DB::table('za_training')
              ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
              ->where('za_training.branch_id', $branchId)
              ->where('za_customer.status',0)
              ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
              ->get();
        
            foreach ($batch_notyetStated as $singledata) {
        
              if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (!in_array($singledata->customer_id, $processed_active_customers)) {
                  if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
                    if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                      continue;
                    }
                    if ($singledata->start_date === null) {
                      $notYetStartedCount++;
                      $processed_not_started_customers[] = $singledata->customer_id;
                    }
                  }
                }
              }
            }
                
            $dropcourseapproval = DB::table('za_drop_refund')
              ->where('type', 0)
              ->where('branch_id', $branchId)
              ->where('bh_status', 1)
              ->where('bh_status', 0)->count();
        
            $refundapproval = DB::table('za_drop_refund')
              ->where('za_drop_refund.type', 1)
              ->where('branch_id', $branchId)
              ->where('bh_status', 0)->count();
        
        
        
            $payment_count = TransactionModel::where('branch_id', $branchId)
              ->whereIn('payment_status', [0, 2])
              ->count();
        
        
            $certificate_count = DB::table('za_manage_certificate')
              ->where('branch_id', $branchId)
              ->where('status', 0)
              ->select(DB::raw('SUM(COALESCE(req_stud_count, 0) - COALESCE(confirm_stud_count, 0)) as total_count'))
              ->value('total_count') ?? 0;
            $currentDate = now()->toDateString();
            $drop_ids = DB::table('za_drop_refund')
              ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
              ->where('za_drop_refund.bh_status', 1)
              ->where('za_drop_refund.branch_id', $branchId)
              ->pluck('za_training.payment_id');
              
            $OutstandingPayment_cri = PaymentModel::where('za_payment.branch_id', $branchId)
              ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
              ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
              ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
              ->select(
                'za_training.training_id',
                DB::raw('MAX(za_payment.payment_id) AS payment_id'),
                DB::raw('MAX(za_training.sno) AS tran_sno'),
                DB::raw('MAX(za_training.batch_id) AS batch_id'),
                DB::raw('MAX(za_payment.sno) AS payment_sno'),
                DB::raw('MAX(za_payment.branch_id) AS branch_id'),
                DB::raw('MAX(za_customer.customer_id) AS customer_id'),
                DB::raw('MAX(za_customer.sno) AS customer_sno'),
                DB::raw('MAX(za_course.course_id) AS course_id'),
                DB::raw('MAX(za_payment.initialPayDate) AS initialPayDate'),
                DB::raw('MAX(za_payment.nextPayDate) AS nextPayDate'),
                DB::raw('MAX(za_payment.amount) AS amount'),
                DB::raw('MAX(za_payment.paidAmount) AS paidAmount'),
                DB::raw('MAX(za_payment.gst_amount) AS gst_amount'),
                DB::raw('MAX(za_payment.balanceFee) AS balanceFee'),
                DB::raw('MAX(za_payment.total_amount) AS total_amount'),
                DB::raw('MAX(za_payment.payment_mode_label) AS payment_mode_label'),
                DB::raw('MAX(za_payment.status) AS payment_status'),
                DB::raw('MIN(za_customer.cus_name) AS cus_name'),
                DB::raw('MAX(za_customer.cus_pic) AS cus_pic'),
                DB::raw('MAX(za_customer.cus_gender) AS cus_gender'),
                DB::raw('MAX(za_customer.jumper_skiper) AS jumper_skiper'),
                DB::raw('MAX(za_customer.cus_mobile) AS cus_mobile'),
                DB::raw('MAX(za_customer.cus_email_id) AS cus_email_id'),
                DB::raw('MAX(za_course.course_name) AS course_name'),
                DB::raw('MAX(za_course.sno) AS course_sno')
              )
              ->whereNotIn('za_payment.payment_id', $drop_ids)
              ->where('za_payment.status', 0)
              ->where('za_payment.amount', '>', 0)
              ->whereIn('za_customer.status',[0,6])
              ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
              ->groupBy('za_training.training_id')
              ->orderBy('za_payment.nextPayDate', 'DESC')
              ->get();
        
            $critical_cus = 0;
            $long_abs_cus = 0;
        
            foreach ($OutstandingPayment_cri as $list) {
              $tran_sno = $list->tran_sno;
              $cus_sno  = $list->customer_sno;
        
              $training = TrainingModel::find($tran_sno);
              if (!$training) {
                continue;
              }
        
              $batch_id = $training->batch_id;
              $course_id = $training->course_id;
        
              // 1. Check course progress
              $presentDates = AttendanceModel::where('customer_id', $cus_sno)
                ->where('batch_id', $batch_id)
                ->where('attendance', 'P')
                ->pluck('att_date');
        
              if ($presentDates->isEmpty()) {
                continue;
              }
        
              $course_topic_count = ManageCoursesSyllabusModel::where('course_id', $course_id)
                ->where('status', 0)
                ->count();
        
              if ($course_topic_count == 0) {
                continue;
              }
        
              $topicCount = SyllabusUpdateModel::where('batch_id', $batch_id)
                ->where('percentage', '100')
                ->distinct()
                ->count('sno');
        
              $courseProgress = ($topicCount / $course_topic_count) * 100;
        
              if ($courseProgress >= 75) {
                $critical_cus++;
              }
        
              // 2. Check long absenteeism (e.g., 3+ consecutive absents)
              $absentDates = AttendanceModel::where('customer_id', $cus_sno)
                ->where('attendance', 'A')
                ->orderBy('att_date', 'desc')
                ->pluck('att_date')
                ->toArray();
        
              $consecutiveCount = 1;
              for ($i = 1; $i < count($absentDates); $i++) {
                $prev = strtotime($absentDates[$i - 1]);
                $curr = strtotime($absentDates[$i]);
        
                if ($prev === strtotime('+1 day', $curr)) {
                  $consecutiveCount++;
                } else {
                  // break; // Stop when not continuous
                }
              }
        
              if ($consecutiveCount >= 3) {
                $long_abs_cus++;
                // $long_abs_cus =$cus_sno;
              }
            }
        
        
        
             $alertData[] = [
                  'branch_id' => $branchId,
                  'branch_name' => $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name,
                  'branch_type' => $branch->branch_type,
                  'total_staff' => $staffCount,
                  'total_present_staff' => $staffAttendedCount,
                  'total_outstanding' => $OutstandingPayment,
                  'total_low_mpc' => $totalItems,
                  'total_not_yet_count' => $notYetStartedCount,
                  'drop_count' => $dropcourseapproval,
                  'refund_count' => $refundapproval,
                  'payment_count' => $payment_count,
                   'critical_cus_count' => $critical_cus,
                   'long_abs_count' => $long_abs_cus,
                  'certificate_count' => $certificate_count,
                  'last_login' => $lastLoginFormatted,
                  'month' => $month_id,
                 'last_login_ago' => $lastLoginDiff,
            ];
        }

    return response()->json([
      'status' => 200,
      'data' => $alertData
    ]);
  }
  
   public function getBranchManPower($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

   
    $id = 1;
    
    
      return view('content.settings.branch.branch.branch_man_power',['id' => $decryptedValue]);
  }
  
  public function getmanpowerlist(Request $request)
  {
      
      $user_id = auth()->user()->user_id;
      
         $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id);
    
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
    
        // Merge allowed branch IDs (company + franchise)
        $allowedBranchIds = $branches->merge($franchises)->unique()->toArray();
    $month_id = $request->month_id;
    $year = $request->year ?? date('Y');

    // Convert month name to number if necessary
    $month = is_numeric($month_id) ? (int)$month_id : date('n', strtotime($month_id . ' 1'));
    $targetDate = $year . '-' . $month . '-01';

    // Fetch all active branches with target for the selected month
    $branches = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
        ->where('branch_target.date', $targetDate)
        ->whereIn('branch_target.branch_id', $allowedBranchIds)
        ->select('branch_target.*', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_type')
        ->get();

    $datamanpower = []; // Initialize as array

    foreach ($branches as $branch) {
        $branchId = $branch->branch_id;

        // Get last login for any user in this branch
        $lastLogin = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id')
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User')
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->limit(1)
            ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));

        if ($lastLogin) {
            $lastLoginCarbon = \Carbon\Carbon::parse($lastLogin);
            $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
            $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true);
        } else {
            $lastLoginFormatted = 'N/A';
            $lastLoginDiff = 'N/A';
        }

        // Count staff by department and conditions
        $sales_staff = StaffModel::where('status', 0)
            ->where('department_id', 1)
            ->where('branch_id', $branchId)
            ->count();

        $production_staff = StaffModel::where('status', 0)
            ->where('department_id', 2)
            ->where('position_role', '!=', 38)
            ->where('branch_id', $branchId)
            ->count();

        $production_staff_freelance = StaffModel::where('status', 0)
            ->where('department_id', 2)
            ->where('position_role', 38)
            ->where('branch_id', $branchId)
            ->count();

        $placement_staff = StaffModel::where('status', 0)
            ->where('department_id', 8)
            ->where('branch_id', $branchId)
            ->count();

        // Append data to array
        $datamanpower[] = [
            'branch_id' => $branchId,
            'branch_name' => $branch->branch_type == 1 ? $branch->branch_name : $branch->franchise_name,
            'branch_type' => $branch->branch_type,
            'sales_staff' => $sales_staff,
            'production_staff' => $production_staff,
            'production_staff_freelance' => $production_staff_freelance,
            'placement_staff' => $placement_staff,
            'last_login' => $lastLoginFormatted,
             'month' => $month_id,
            'last_login_ago' => $lastLoginDiff,
        ];
    }

    return response()->json([
        'status' => 200,
        'data' => $datamanpower
    ]);
}

}