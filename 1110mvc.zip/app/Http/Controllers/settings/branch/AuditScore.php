<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\AuditScoreModel;

class AuditScore extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $score_template = AuditScoreModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.branch.audit_score.audit_score_list', [
            'score_template' => $score_template,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_AuditScoreModel =  AuditScoreModel::where('sno', $id)->first();
        $upd_AuditScoreModel->status = $request->input('status', 0);
        $upd_AuditScoreModel->update();
        if ($upd_AuditScoreModel) {
            return response([
                'status'    => 200,
                'message'   => 'Grade Template  Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Grade Template  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Grade Template  Status!',
                'error_msg' => 'Could not ,update  Grade Template  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {  
       
        $upd_AuditScoreModel =  AuditScoreModel::where('sno', $id)->first();
        $upd_AuditScoreModel->status  = 2;
        $upd_AuditScoreModel->Update();
        if ($upd_AuditScoreModel) {
            return response([
                'status'    => 200,
                'message'   => 'Score Template  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Score Template !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
            'score_name' => 'required|max:255',
            'score_min_value' => 'required|max:255',
            'score_max_value' => 'required|max:255',
            
            'score_color' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
       
        $score_name = $request->score_name;
        $score_min_value = $request->score_min_value;
        $score_max_value = $request->score_max_value;
        $score_color = $request->score_color;
        $score_desc = $request->score_desc;
        $user_id = 1;

        // Check if the category already exists
        $chk = AuditScoreModel::where('score_name', ucwords($score_name))
            ->where('branch_id', self::$branch_id)
            ->where('score_name', ucwords($score_name))->where('status', '!=', 2)
            ->first();

        $chk2 = AuditScoreModel::where('score_color', ucwords($score_color))->where('status', '!=', 2)
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'audit score has already been created!'
            ]);
        } else if ($chk2) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'score Color has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = AuditScoreModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = date('y');
                $audit_score_id = 'GT-0001/' . $year;
            } else {
                $data = $category_check->audit_score_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('GT-%04d', $next_number);
                $year = date('y');
                $audit_score_id = $requestId . '/' . $year;
            }

            

            // Add the category to the database
            $add = new AuditScoreModel();
            $add->audit_score_id = $audit_score_id;
            $add->score_name = ucfirst($score_name);
            $add->score_min_value = $score_min_value;
            $add->score_max_value = $score_max_value;
           
            // Assign the uploaded filename here
            $add->score_color = $score_color;
            $add->score_desc = $score_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by = $request->user()->user_id;
            $add->updated_by = $request->user()->user_id;
            // return $add;
            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Audit score  added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Audit Score!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'score_name_edit' => 'required|max:255',
            
            'score_min_value_edit' => 'required|max:255',
            'score_max_value_edit' => 'required|max:255',
            'score_color_edit' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
      
        $score_name = $request->score_name_edit;
        $score_min_value = $request->score_min_value_edit;
        $score_max_value = $request->score_max_value_edit;
        
        $audit_score_id = $request->audit_score_id;
        // $grade_logo = $request->grade_logo;
        $score_color = $request->score_color_edit;
        $score_desc = $request->score_desc_edit;
        $user_id = $request->user()->user_id;
        
        $upd_score_template = AuditScoreModel::find($audit_score_id);
        // return $upd_score_template;
        if (!$upd_score_template) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Score Template  not found!'
            ]);
            return redirect()->back();
        }

        $chk = AuditScoreModel::where('score_name', ucwords($score_name))
            ->where('branch_id', self::$branch_id)
            
            ->where('status', '!=', 2)
            ->where('sno', '!=', $audit_score_id)
            ->first();

        $chk2 = AuditScoreModel::where('score_color', ucwords($score_color))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $audit_score_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Score Template has already been created!'
            ]);
        } else if ($chk2) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'score Color has already been created!'
            ]);
        } else {

           
            // return $logo;

            // Add the category to the database
            $upd_score_template->score_name = ucfirst($score_name);
            
            $upd_score_template->score_min_value = $score_min_value;
            $upd_score_template->score_max_value = $score_max_value;
           
            $upd_score_template->score_color = $score_color;
            $upd_score_template->score_desc = $score_desc;
            $upd_score_template->updated_by = $user_id;
            $upd_score_template->save();

            if ($upd_score_template) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Score Template updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Score Template!'
                ]);
            }

            return redirect()->back();
        }
    }
}