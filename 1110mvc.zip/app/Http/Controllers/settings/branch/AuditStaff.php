<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AuditStaffModel;
use Illuminate\Support\Facades\Validator;

class AuditStaff extends Controller {
    protected static $branch_id = 1;

    public function index() {

        $Department = AuditStaffModel::where('status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.branch.audit_staff.audit_staff_list', [
            'Department' => $Department,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $Department = AuditStaffModel::where( 'status', 0 )->orderBy( 'sno', 'desc' )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Department
        ], 200 );
    }

    public function Add( Request $request ) {

        // return $request;

        $branch_id = $request->user()->branch_id;
        $validator = Validator::make( $request->all(), [
            'audit_staff_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $audit_staff_name = $request->audit_staff_name;
            $audit_staff_mobile = $request->audit_staff_mobile;
            $alternative_no = $request->alternative_mobile ?? null;
            $email_id = $request->email_id ?? null;
            $gender = $request->gender;
            $audit_staff_desc = $request->audit_staff_desc ?? null;
            $user_id   = $request->user()->user_id ?? 1;
            $chk = AuditStaffModel::where( 'audit_staff_mobile',  $audit_staff_mobile  )->where( 'status', '!=', 2 )->first();

            $staff_check = AuditStaffModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $sno         = $staff_check ? $staff_check->sno + 1 : 1;

            // Handle staff image upload
            $staff_image = '';
            if ($request->hasFile('staff_add_icon')) {
                $staff_imageName = 'staff_' . $sno . '.' . $request->file('staff_add_icon')->extension();
                $request->file('staff_add_icon')->move(public_path('audit_images'), $staff_imageName);
                $staff_image = $staff_imageName;
            }

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Audit Staff is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = AuditStaffModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $audit_staff_id = 'AS-0001/' . $year;
                } else {

                    $data = $category_check->audit_staff_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int ) $result + 1;
                    $request = sprintf( 'AS-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $audit_staff_id = $request . '/' . $year;
                }

                $add_department = new AuditStaffModel();
                $add_department->audit_staff_id = $audit_staff_id;
                $add_department->audit_staff_name = $audit_staff_name;
                $add_department->audit_staff_mobile = $audit_staff_mobile;
                $add_department->alternative_no = $alternative_no;
                $add_department->email_id = $email_id;
                $add_department->gender = $gender;
                $add_department->staff_image = $staff_image;
                $add_department->audit_staff_desc = $audit_staff_desc;
                $add_department->branch_id = $branch_id;
                $add_department->created_by = $user_id;
                $add_department->updated_by = $user_id;

                $add_department->save();

                if ( $add_department ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Audit Staff added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Audit Staff!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Update( Request $request ) {

        // return $request;
        $validator = Validator::make( $request->all(), [
            'audit_staff_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {
            $user_id   = $request->user()->user_id ?? 1;
            $audit_staff_name = $request->audit_staff_name;
            $audit_staff_mobile = $request->audit_staff_mobile;
            $alternative_no = $request->alternative_mobile ?? null;
            $email_id = $request->email_id ?? null;
            $gender = $request->gender;
            $audit_staff_desc = $request->audit_staff_desc;
            $audit_staff_id = $request->audit_staff_id;
            $staff_image = '';
            if ($request->hasFile('staff_image_icon')) {
                $staff_imageName = 'staff_' . $audit_staff_id . '.' . $request->file('staff_image_icon')->extension();
                $request->file('staff_image_icon')->move(public_path('audit_images'), $staff_imageName);
                $staff_image = $staff_imageName;
            } else {
                $staff_image = $request->old_staff_image;
            }

            $upd_Auditstaff = AuditStaffModel::where( 'sno', $audit_staff_id )->first();

            $chk = AuditStaffModel::where( 'audit_staff_mobile', $audit_staff_mobile )->where( 'sno', '!=', $audit_staff_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Staff Mobile is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_Auditstaff->audit_staff_name =$audit_staff_name;
                $upd_Auditstaff->audit_staff_mobile = $audit_staff_mobile;
                $upd_Auditstaff->alternative_no = $alternative_no;
                $upd_Auditstaff->email_id = $email_id;
                $upd_Auditstaff->staff_image = $staff_image;
                $upd_Auditstaff->gender = $gender;
                $upd_Auditstaff->audit_staff_desc = $audit_staff_desc;
                $upd_Auditstaff->updated_by = $user_id;
                $upd_Auditstaff->update();

                if ( $upd_Auditstaff ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Audit Staff Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Audit Staff!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_AuditCategory = AuditStaffModel::where( 'sno', $id )->first();
        $upd_AuditCategory->status = 2;
        $upd_AuditCategory->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_AuditCategory = AuditStaffModel::where( 'sno', $id )->first();
        $upd_AuditCategory->status = $request->input( 'status', 0 );
        $upd_AuditCategory->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}
