<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchTypeModel;
use Illuminate\Support\Facades\Validator;

class BranchType extends Controller {
    protected static $branch_id = 1;

    public function index() {

        $Branchtype = BranchTypeModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.branch.branch_type.branch_type_list', [
            'Branchtype' => $Branchtype,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $Branchtype = BranchTypeModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'branchtype_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $branchtype_name       = $request->branchtype_name;
            $branchtype_desc          = $request->branchtype_desc;
            $user_id                    = 1;
            $chk = BranchTypeModel::where( 'branchtype_name', ucwords( $branchtype_name ) )->where( 'branch_id', self::$branch_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Branch Category is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = BranchTypeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $branchtype_id = 'BC-0001/' . $year;
                } else {

                    $data = $category_check->branchtype_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int )$result + 1;
                    $request = sprintf( 'BC-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $branchtype_id = $request . '/' . $year;
                }

                $add_branchtype = new BranchTypeModel();
                $add_branchtype->branchtype_id         = $branchtype_id;
                $add_branchtype->branchtype_name       = Ucfirst( $branchtype_name );
                $add_branchtype->branchtype_desc       = $branchtype_desc;
                $add_branchtype->branch_id = self::$branch_id;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Branch Category added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Branch Category!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit( $id ) {
        $editbranchtype = BranchTypeModel::where( 'sno', $id )->first();

        return view( 'content.settings.branch.branch_type.branch_type_list', [
            'editbranchtype' => $editbranchtype,
            'id' => $id,
        ] );
    }

    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'branchtype_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $branchtype_name       = $request->branchtype_name;
            $branchtype_desc       = $request->branchtype_desc;
            $branchtype_id       = $request->branchtype_id;

            $upd_BranchTypeModel =  BranchTypeModel::where( 'sno', $branchtype_id )->first();

            $chk = BranchTypeModel::where( 'branchtype_name', ucwords( $branchtype_name ) )->where( 'sno', '!=', $branchtype_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Branch Category is exist!'
                ] );
                return redirect()->back();
            }

            $upd_BranchTypeModel->branchtype_name  = Ucfirst( $branchtype_name );
            $upd_BranchTypeModel->branchtype_desc  = $branchtype_desc;
            $upd_BranchTypeModel->branch_id = self::$branch_id;
            $upd_BranchTypeModel->update();

            if ( $upd_BranchTypeModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Branch Category Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Branch Category!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_BranchTypeModel = BranchTypeModel::where( 'sno', $id )->first();
        $upd_BranchTypeModel->status  = 2;
        $upd_BranchTypeModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Branch Category Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_BranchTypeModel =  BranchTypeModel::where( 'sno', $id )->first();
        $upd_BranchTypeModel->status = $request->input( 'status', 0 );
        $upd_BranchTypeModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}