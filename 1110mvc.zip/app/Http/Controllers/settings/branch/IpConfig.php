<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\IpConfigModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;

class IpConfig extends Controller {
    protected static $branch_id = 1;
    // $branch_id->branch_id = self::$branch_id;

    public function index() {
        // Fetch IP configuration data with associated branch and franchise names
        $ip_lists = IpConfigModel::select( 'za_ip_config.*', 'za_branch.branch_name', 'za_branch.franchise_name' )
        ->where( 'za_ip_config.status', '!=', 2 )
        ->leftJoin( 'za_branch', 'za_branch.sno', '=', 'za_ip_config.branch_id' )
        ->orderBy( 'za_ip_config.sno', 'desc' )
        ->get();
        // Return view with IP configuration data and page configuration settings
        return view( 'content.settings.branch.ipconfig.ipconfig_list', [
            'ip_list' => $ip_lists,
        ] );
    }

    public function List() {
        $list = IpConfigModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $list
        ], 200 );
    }

    public function branch_List() {
        $branch_list = BranchModel::where( 'status', '!=', 2 )->where( 'branch_type', 1 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $branch_list
        ], 200 );
    }

    public function franchise_List() {
        $franchise_List = BranchModel::where( 'status', '!=', 2 )->where( 'branch_type', 2 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $franchise_List
        ], 200 );
    }

    public function Add( Request $request ) {
        // Validate the incoming request data
        $validator = Validator::make( $request->all(), [
            'branch_type' => 'required|integer',
        ] );

        // Check if validation fails
        if ( $validator->fails() ) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check the form fields.'
            ] );
            return redirect()->back()->withErrors( $validator )->withInput();
        }
        $branch_type = $request->branch_type;
        $branch_id = $branch_type == 1 ? $request->branch_id : $request->franchise_id;
        $ip_desc = $request->ip_desc ?? '';
        $ip_number = json_encode( $request->ip_number );
        $user_id = 1;

        $add_ip_config = new IpConfigModel();
        $add_ip_config->branch_type = $branch_type;
        $add_ip_config->branch_id = $branch_id;
        $add_ip_config->ip_desc = $ip_desc;
        $add_ip_config->ip_ids = $ip_number;
        $add_ip_config->created_by = $user_id;
        $add_ip_config->updated_by = $user_id;

        // Attempt to save the record
        if ( $add_ip_config->save() ) {
            // Success: Set success message
            session()->flash( 'toastr', [
                'type' => 'success',
                'message' => 'IP Configuration added successfully!'
            ] );
        } else {
            // Error: Set error message
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Failed to add IP Configuration. Please try again.'
            ] );
        }

        return redirect()->back();
    }

    public function Update( Request $request ) {
        // return $request;
        // Validate the incoming request data
        $validator = Validator::make( $request->all(), [
            'branch_type_edit' => 'required|integer',
        ] );

        // Check if validation fails
        if ( $validator->fails() ) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check the form fields.'
            ] );
            return redirect()->back()->withErrors( $validator )->withInput();
        }
        $edit_sno = $request->edit_sno;
        $branch_type = $request->branch_type_edit;
        $branch_id = $branch_type == 1 ? $request->branch_id_edit : $request->franchise_id_edit;
        $ip_desc = $request->ip_desc_edit ?? '';
        $ip_number = json_encode( $request->ip_number_edit );
        $user_id = 1;

        $add_ip_config = IpConfigModel::where( 'sno', $edit_sno )->first();
        $add_ip_config->branch_type = $branch_type;
        $add_ip_config->branch_id = $branch_id;
        $add_ip_config->ip_desc = $ip_desc;
        $add_ip_config->ip_ids = $ip_number;
        $add_ip_config->created_by = $user_id;
        $add_ip_config->updated_by = $user_id;

        // Attempt to save the record
        if ( $add_ip_config->save() ) {
            // Success: Set success message
            session()->flash( 'toastr', [
                'type' => 'success',
                'message' => 'IP Configuration Updatedsuccessfully!'
            ] );
        } else {
            // Error: Set error message
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Failed to update IP Configuration. Please try again.'
            ] );
        }

        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_IpConfigModel = IpConfigModel::where( 'sno', $id )->first();
        $upd_IpConfigModel->status = 2;
        $upd_IpConfigModel->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_IpConfigModel = IpConfigModel::where( 'sno', $id )->first();
        $upd_IpConfigModel->status = $request->input( 'status', 0 );
        $upd_IpConfigModel->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}