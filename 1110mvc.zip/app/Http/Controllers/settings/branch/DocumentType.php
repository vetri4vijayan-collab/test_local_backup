<?php

namespace App\Http\Controllers\settings\branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DocumentTypeModel;
use Illuminate\Support\Facades\Validator;

class Documenttype extends Controller {
    protected static $branch_id = 1;
    // $branch_id->branch_id = self::$branch_id;

    public function index() {
        $Documenttype = DocumentTypeModel::where( 'status', '!=', 2 )
        ->where( 'branch_id', self::$branch_id )
        ->orderBy( 'sno', 'desc' )
        ->get();

        $pageConfigs = [ 'myLayout' => 'default' ];

        return view( 'content.settings.branch.document_type.document_type_list', [
            'Documenttype' => $Documenttype,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $Documenttype = DocumentTypeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->where( 'branch_id', self::$branch_id )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Documenttype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'documenttype_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Already Document type is exist!'
            ] );
            return redirect()->back();
        } else {

            $documenttype_name = $request->documenttype_name;
            $documenttype_desc = $request->documenttype_desc;
            $user_id = 1;
            $chk = DocumentTypeModel::where( 'documenttype_name', ucwords( $documenttype_name ) )->where( 'branch_id', self::$branch_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                $result = response( [
                    'status' => 401,
                    'message' => 'Error',
                    'error_msg' => 'Name has been  already created!',
                    'data' => null,
                ], 200 );
            } else {
                $category_check = DocumentTypeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $documenttype_id = 'DT-0001/' . $year;
                } else {

                    $data = $category_check->documenttype_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int ) $result + 1;
                    $request = sprintf( 'DT-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $documenttype_id = $request . '/' . $year;
                }

                $add_documenttype = new DocumentTypeModel();
                $add_documenttype->documenttype_id = $documenttype_id;
                $add_documenttype->documenttype_name = Ucfirst( $documenttype_name );
                $add_documenttype->documenttype_desc = $documenttype_desc;
                $add_documenttype->branch_id = self::$branch_id;
                $add_documenttype->created_by = $user_id;
                $add_documenttype->updated_by = $user_id;

                $add_documenttype->save();

                if ( $add_documenttype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Document type added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Document type!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit( $id ) {
        $editdocumenttype = DocumentTypeModel::where( 'sno', $id )->first();

        return view( 'content.settings.branch.document_type.document_type_list', [
            'editdocumenttype' => $editdocumenttype,
            'id' => $id,
        ] );
    }

    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'documenttype_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $documenttype_name = $request->documenttype_name;
            $documenttype_desc = $request->documenttype_desc;
            $documenttype_id = $request->documenttype_id;

            $upd_DocumentTypeModel = DocumentTypeModel::where( 'sno', $documenttype_id )->first();

            $chk = DocumentTypeModel::where( 'documenttype_name', ucwords( $documenttype_name ) )->where( 'branch_id', self::$branch_id )->where( 'sno', '!=', $documenttype_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Document Type is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_DocumentTypeModel->documenttype_name = Ucfirst( $documenttype_name );
                $upd_DocumentTypeModel->documenttype_desc = $documenttype_desc;
                $upd_DocumentTypeModel->branch_id = self::$branch_id;
                $upd_DocumentTypeModel->update();

                if ( $upd_DocumentTypeModel ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Document Type Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Document Type!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_DocumentTypeModel = DocumentTypeModel::where( 'sno', $id )->first();
        $upd_DocumentTypeModel->status = 2;
        $upd_DocumentTypeModel->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_DocumentTypeModel = DocumentTypeModel::where( 'sno', $id )->first();
        $upd_DocumentTypeModel->status = $request->input( 'status', 0 );
        $upd_DocumentTypeModel->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}
