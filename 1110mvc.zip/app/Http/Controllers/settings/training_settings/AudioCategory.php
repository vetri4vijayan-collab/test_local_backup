<?php

namespace App\Http\Controllers\settings\training_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\AudioCategoryModel;
use App\Models\User;

class AudioCategory extends Controller
{
 
  public function index()
  {
    $Audio = AudioCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return $Gift;
    return view('content.settings.training_settings.audio_category_list', [
      'Audio' => $Audio,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $Audio = AudioCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // return $ReviewLink;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Audio
    ], 200);
  }
    public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'audio_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $audio_name       = $request->audio_name;
      $audio_desc       = $request->audio_desc;
      $user_id                    = $request->user()->user_id;
      $chk = AudioCategoryModel::where('audio_category', ucwords($audio_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        // $category_check = AudioCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        // if (!$category_check) {

        //   $year = substr(date("y"), -2);
        //   $job_category_id = "CC-0001/" . $year;
        // } else {

        //   $data = $category_check->job_category_id;
        //   $slice = explode("/", $data);
        //   $result = preg_replace('/[^0-9]/', '', $slice[0]);

        //   $next_number = (int)$result + 1;
        //   $request = sprintf("CC-%04d", $next_number);

        //   $year = substr(date("y"), -2);
        //   $job_category_id = $request . '/' . $year;
        // }


        $add_category = new AudioCategoryModel();
        // $add_category->job_category_id         = $job_category_id;
        $add_category->audio_category       = Ucfirst($audio_name);
        $add_category->audio_desc       = $audio_desc;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();
        
        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Audio Category Added Successfully !'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Audio Category!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {
    
    $editcategory = AudioCategoryModel::where('sno', $id)->first();
    
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update(Request $request)
  {

    $id=$request->id;
    // return $request;
    $validator = Validator::make($request->all(), [
      'audio_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 401);
    }

      $audio_name = $request->audio_name;
      $audio_desc = $request->audio_desc;
      $id = $request->id;

      $upd_ReviewLinkModel =  AudioCategoryModel::where('sno', $id)->first();
      // return $upd_ReviewLinkMoel;

      if (!$upd_ReviewLinkModel) {
        return response([
          'status'    => 404,
          'message'   => 'Audio category not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

       else {

        $upd_ReviewLinkModel->audio_category = ucfirst($audio_name);
        $upd_ReviewLinkModel->audio_desc = $audio_desc;
        $upd_ReviewLinkModel->save();
        return response([
          'status'    => 200,
          'message'   => 'Audio Category Updated Successfully !',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }
  }

  public function Delete($id)
  {
    $upd_ReviewLinkModel =  AudioCategoryModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status  = 2;
    $upd_ReviewLinkModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Audio Category Deleted Successfully !',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_ReviewLinkModel =  AudioCategoryModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status = $request->input('status', 0);
    $upd_ReviewLinkModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Status Updated Successfully!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
 
}
