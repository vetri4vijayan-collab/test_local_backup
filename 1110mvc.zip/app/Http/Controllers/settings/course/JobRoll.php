<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\JobRollModel;

class JobRoll extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {

    $job_roll = JobRollModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.course.job_roll.job_roll', compact('job_roll', 'pageConfigs'));
  }

  public function List()
  {
    $jobroll = JobRollModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $jobroll
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_roll_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $job_roll_name       = $request->job_roll_name;
      $fresher_ctc       = $request->fresher_ctc;
      $experience_ctc       = $request->experience_ctc;
      $job_roll_desc       = $request->job_roll_desc;

      $user_id                    = $request->user()->user_id;
      $chk = JobRollModel::where('job_roll_name', ucwords($job_roll_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobRollModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_roll_id = "JR-0001/" . $year;
        } else {

          $data = $category_check->job_roll_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("JR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_roll_id = $request . '/' . $year;
        }


        $add_category = new JobRollModel();
        $add_category->job_roll_id         = $job_roll_id;
        $add_category->job_roll_name       = Ucfirst($job_roll_name);
        $add_category->job_roll_desc       = $job_roll_desc;
        $add_category->fresher_ctc       = $fresher_ctc;
        $add_category->experience_ctc       = $experience_ctc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Job Role added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Job Role!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Job Role Created successfully!');
    }
  }

  public function Edit($id)
  {
    $job_roll = JobRollModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $job_roll
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_roll_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $job_roll_name       = $request->job_roll_name;
      $experience_ctc       = $request->experience_ctc;
      $fresher_ctc       = $request->fresher_ctc;
      $job_roll_desc       = $request->job_roll_desc;

      $upd_CourseCategoryModel =  JobRollModel::where('sno', $id)->first();

      $chk = JobRollModel::where('job_roll_name', ucwords($job_roll_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_roll_name  = Ucfirst($job_roll_name);
        $upd_CourseCategoryModel->job_roll_desc  = $job_roll_desc;
        $upd_CourseCategoryModel->fresher_ctc  = $fresher_ctc;
        $upd_CourseCategoryModel->experience_ctc  = $experience_ctc;
        $upd_CourseCategoryModel->update();
      }

      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  JobRollModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  JobRollModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}