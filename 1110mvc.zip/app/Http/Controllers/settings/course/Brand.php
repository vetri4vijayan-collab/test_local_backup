<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\BrandModel;

class Brand extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    // return view('content.settings.course.brand.brand');
    $brand = BrandModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.course.brand.brand', compact('brand', 'pageConfigs'));
  }

  public function List()
  {
    $facility = BrandModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'brand_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $brand_name       = $request->brand_name;
      $brand_desc       = $request->brand_desc;

      $user_id                      = $request->user()->user_id;
      $chk = BrandModel::where('brand_name', ucwords($brand_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = BrandModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $brand_id = "B-0001/" . $year;
        } else {

          $data = $category_check->brand_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("B-%04d", $next_number);

          $year = substr(date("y"), -2);
          $brand_id = $request . '/' . $year;
        }


        $add_category = new BrandModel();
        $add_category->brand_id         = $brand_id;
        $add_category->brand_name       = Ucfirst($brand_name);
        $add_category->brand_desc       = $brand_desc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Brand added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the brand!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'brand Created successfully!');
    }
  }

  public function Edit($id)
  {
    $brand = BrandModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $brand
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'brand_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $brand_name       = $request->brand_name;
      $brand_desc       = $request->brand_desc;

      $upd_CourseCategoryModel =  BrandModel::where('sno', $id)->first();

      $chk = BrandModel::where('brand_name', ucwords($brand_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        $upd_CourseCategoryModel->brand_name  = Ucfirst($brand_name);
        $upd_CourseCategoryModel->brand_desc  = $brand_desc;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  BrandModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  BrandModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}