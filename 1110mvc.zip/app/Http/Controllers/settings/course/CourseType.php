<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CourseTypeModel;

class CourseType extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $CourseCategory = CourseTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return $CourseCategory;
    return view('content.settings.course.course_type.course_type_list', [
      'CourseCategory' => $CourseCategory,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $Coursetype = CourseTypeModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }
  function get_course_type_data($sno = '')
  {
    $result = CourseTypeModel::where('sno', $sno)->first();


    if ($result) {
      return response([
        'status'    => 200,
        'data'      => $result,
      ], 200);
    } else {
      return response([
        'status'    => 404,
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Add(Request $request)
  {
      // Validation
      $validator = Validator::make($request->all(), [
          'course_type_name' => 'required|max:255',
      ]);
  
      if ($validator->fails()) {
          return response([
              'status' => 401,
              'message' => 'Incorrect format input fields',
              'error_msg' => $validator->messages()->get('*'),
              'data' => null,
          ], 200);
      } else {
          $course_type_name = $request->course_type_name;
          $course_type_desc = $request->course_type_desc;
          $course_days = $request->course_days;
          $course_duration = $request->course_duration;
          $last_fees_duration_days = $request->last_fees_duration_days;
          $fees_schedule = $request->fees_schedule;
          $combined_course = $request->comb_course ?? 0;
  
          $ratio = [];
          foreach ($request->all() as $key => $value) {
              // Check if the key starts with 'sch_per_'
              if (strpos($key, 'sch_per_') === 0) {
                  $ratio[] = $value;
              }
          }
  
          // Encode the array as JSON
          // $ratio = json_encode($ratio);
  
          $user_id = $request->user()->user_id;
          // return $ratio;
          $chk = CourseTypeModel::where('course_type_name', ucwords($course_type_name))
              ->where('branch_id', self::$branch_id)
              ->where('status', '!=', 2)
              ->first();
  
          if ($chk) {
              session()->flash('toastr', [
                  'status' => 401,
                  'type' => 'error',
                  'message' => 'Name has already been created!'
              ]);
          } else {
              $category_check = CourseTypeModel::where('status', '!=', 2)
                  ->orderBy('sno', 'desc')
                  ->first();
  
              if (!$category_check) {
                  $year = substr(date("y"), -2);
                  $course_type_id = "CT-0001/" . $year;
              } else {
                  $data = $category_check->course_type_id;
                  $slice = explode("/", $data);
                  $result = preg_replace('/[^0-9]/', '', $slice[0]);
  
                  $next_number = (int)$result + 1;
                  $request = sprintf("CT-%04d", $next_number);
  
                  $year = substr(date("y"), -2);
                  $course_type_id = $request . '/' . $year;
              }
  
              $add_category = new CourseTypeModel();
              $add_category->course_type_id = $course_type_id;
              $add_category->course_type_name = ucfirst($course_type_name);
              $add_category->course_type_desc = $course_type_desc;
              $add_category->course_days = $course_days;
              $add_category->course_duration = $course_duration;
              $add_category->last_fees_duration_days = $last_fees_duration_days;
              $add_category->fees_schedule = $fees_schedule;
              $add_category->combined_course = $combined_course;
              $add_category->ratio = $ratio;  // Store the JSON-encoded array
              $add_category->branch_id = self::$branch_id;
              $add_category->created_by = $user_id;
              $add_category->updated_by = $user_id;
              // return $add_category;
              $add_category->save();
  
              if ($add_category) {
                  session()->flash('toastr', [
                      'type' => 'success',
                      'message' => 'Course Type Successfully Added!'
                  ]);
              } else {
                  session()->flash('toastr', [
                      'type' => 'error',
                      'message' => 'Could not add the Course Type!'
                  ]);
              }
          }
  
          return redirect()->back();
      }
  }
  

  // public function Edit($id)
  // {
  //   $editcategory = CourseTypeModel::where('sno', $id)->first();

  //   return view('content.settings.course.course_category.course_category_list', [
  //     'editcategory' => $editcategory,
  //     'id' => $id,
  //   ]);
  // }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'course_type_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $course_type_name       = $request->course_type_name;
      $course_type_desc       = $request->course_type_desc;
      $course_days          = $request->course_days;
      $course_duration          = $request->course_duration;
      $course_type_id       = $request->course_type_id;
      $last_fees_duration_days          = $request->last_fees_duration_days_edit;
      $combined_course          = $request->comb_course_edit ?? 0;
      $fees_schedule          = $request->fees_schedule_edit;
      $ratio = [];
          foreach ($request->all() as $key => $value) {
              // Check if the key starts with 'sch_per_'
              if (strpos($key, 'sch_per_edit') === 0) {
                  $ratio[] = $value;
              }
          }
  
          // Encode the array as JSON
          // $ratio = json_encode($ratio);

      // return $ratio;
      $upd_CourseCategoryModel =  CourseTypeModel::where('sno', $course_type_id)->first();

      $chk = CourseTypeModel::where('course_type_name', ucwords($course_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $course_type_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->course_type_name  = Ucfirst($course_type_name);
        $upd_CourseCategoryModel->course_type_desc  = $course_type_desc;
        $upd_CourseCategoryModel->course_days             = $course_days;
        $upd_CourseCategoryModel->course_duration         = $course_duration;
        $upd_CourseCategoryModel->last_fees_duration_days = $last_fees_duration_days;
        $upd_CourseCategoryModel->fees_schedule         = $fees_schedule;
        $upd_CourseCategoryModel->ratio                 = $ratio;  // Store the JSON-encoded array
        $upd_CourseCategoryModel->combined_course         = $combined_course;

        // return $upd_CourseCategoryModel;
        $upd_CourseCategoryModel->update();
      }
    }
    // return $upd_CourseCategoryModel;
    if ($upd_CourseCategoryModel) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Course Type Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Course Type!'
      ]);
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CourseTypeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CourseTypeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}