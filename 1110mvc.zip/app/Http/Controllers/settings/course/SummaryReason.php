<?php

namespace App\Http\Controllers\settings\course;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\SummaryReasonModel;




class SummaryReason extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {
      $summaryReason = SummaryReasonModel::select('*')
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')->get();

        // return $summaryReason;

      return view('content.settings.course.summary_reason.summary_reason', [
        'summaryReason' => $summaryReason
      ]);
    }

    public function List()
    {  
      $CourseSubCategory = SummaryReasonModel::where('branch_id', self::$branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $CourseSubCategory
      ], 200);
    }
  
    public function Add(Request $request)
    {
  
      $validator = Validator::make($request->all(), [
        'summary_reason_add' => 'required|max:255'
      ]);
      if ($validator->fails()) {
        return  response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {
  
  
        $reason_name       = $request->summary_reason_add;
        $summary_reason_id       = $request->summary_reason_id;
        $user_id                    = $request->user()->user_id;
        $chk = SummaryReasonModel::where('reason_name', ucwords($reason_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();
  
        if ($chk) {
  
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Name has been  already created!'
          ]);
        } else {
          $category_check = SummaryReasonModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
  
  
          if (!$category_check) {
  
            $year = substr(date("y"), -2);
            $summary_reason_id = "SR-0001/" . $year;
          } else {
  
            $data = $category_check->summary_reason_id;
            $slice = explode("/", $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
  
            $next_number = (int)$result + 1;
            $request = sprintf("SR-%04d", $next_number);
  
            $year = substr(date("y"), -2);
            $summary_reason_id = $request . '/' . $year;
          }
  
  
          $add_category = new SummaryReasonModel();
          $add_category->summary_reason_id         = $summary_reason_id;
          $add_category->reason_name       = Ucfirst($reason_name);
          $add_category->branch_id                 = self::$branch_id;
          $add_category->created_by                 = $user_id;
          $add_category->updated_by                 = $user_id;
  
          $add_category->save();
  
          if ($add_category) {

            session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Summary Reason added Successfully!'
            ]);
          } else {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not add the Summary Reason!'
            ]);
          }
        }
        return redirect()->back();
      }
    }
  
  
    public function edit($id)
    {
      $CourseSubCategory = SummaryReasonModel::where('sno', $id)->where('branch_id', self::$branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
  
        return view('content.settings.course.summary_reason.summary_reason', [
          'edit' => $CourseSubCategory,
      ]);
    }
  
    public function Update(Request $request)
    {
  
      // return $request;
      $validator = Validator::make($request->all(), [
        'summary_reason_edit' => 'required|max:255',
      ]);
  
      if ($validator->fails()) {
        return   response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg'     => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {

        $reason_name             = $request->summary_reason_edit;
        $summary_reason_id       = $request->summary_reason_id;
      // return $request;
  
        $upd_CourseCategoryModel =  SummaryReasonModel::where('sno', $summary_reason_id)->first();
  
        $chk = SummaryReasonModel::where('reason_name', ucwords($reason_name))->where('status', '!=', 2)->where('sno', '!=', $summary_reason_id)->first();
  
        if ($chk) {
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Name has been  already created!'
          ]);
        } else {
          $upd_CourseCategoryModel->sno    = $summary_reason_id;
          $upd_CourseCategoryModel->reason_name  = Ucfirst($reason_name);
          $upd_CourseCategoryModel->update();
        }
        if ($upd_CourseCategoryModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Summary Reason updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Summary Reason!'
          ]);
        }
      }
      return redirect()->back();
    }


    public function Delete($id)
    {
      $upd_CourseCategoryModel =  SummaryReasonModel::where('sno', $id)->first();
      $upd_CourseCategoryModel->status  = 2;
      $upd_CourseCategoryModel->Update();
  
  
      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  
    public function Status($id, Request $request)
    {
  
      $summary_reason =  SummaryReasonModel::where('sno', $id)->first();
      $summary_reason->status = $request->input('status', 0);
      $summary_reason->update();
  
      return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
