<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CourseActionModel;
use App\Helpers\Helpers;

class CourseAction extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    $CourseCategory = CourseActionModel::select(
      'za_course_action.*',
      'za_course_action_type.course_action_type_name',
      'za_course_action_type.category_file_upload',
      'za_course_action_type.category_text_field',
      'za_course_action_type.category_text_area',
      'za_course_action_type.category_text_link',
      'za_course_action_type.category',
      'za_course_action_type.sno as course_action_type_id'
    )
      ->join('za_course_action_type', 'za_course_action_type.sno', '=', 'za_course_action.course_action_type_id')
      ->where('za_course_action_type.status', '!=', 2)
      ->where('za_course_action.status', '!=', 2)
      ->where('za_course_action.branch_id', self::$branch_id)
      ->orderBy('za_course_action.sno', 'desc')
      ->get();

    $pageConfigs = ['myLayout' => 'default'];
    // dd($CourseCategory);

    return view('content.settings.course.course_action.course_action_list', [
      'CourseCategory' => $CourseCategory,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'course_action_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $course_action_name            = $request->course_action_name;
      $course_action_type_id         = $request->course_action_type_id;
      $course_action_desc            = $request->course_action_desc;
      $user_id                       = $request->user()->user_id;


      $chk = CourseActionModel::where('course_action_name', ucwords($course_action_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!!'
        ]);
      } else {

        if ($request->hasFile('course_action_icon')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->file('course_action_icon')->extension();
          $destinationPath = public_path('course_action_icon');
          $request->file('course_action_icon')->move($destinationPath, $imageName);
          $course_action_icon = $imageName;
        } else {
          $course_action_icon = '';
        }

        $add_category = new CourseActionModel();
        $add_category->course_action_name       = Ucfirst($course_action_name);
        $add_category->course_action_type_id    = $course_action_type_id;
        $add_category->course_action_icon       = $course_action_icon;
        $add_category->course_action_desc       = $course_action_desc;
        $add_category->branch_id                = self::$branch_id;
        $add_category->created_by               = $user_id;
        $add_category->updated_by               = $user_id;

        // return $add_category;
        $add_category->save();


        if ($add_category) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Course Action added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Course Action!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editcategory = CourseActionModel::select(
      'za_course_action.*',
      'za_course_action_type.course_action_type_name',
      'za_course_action_type.category_file_upload',
      'za_course_action_type.category_text_field',
      'za_course_action_type.category_text_area',
      'za_course_action_type.category_text_link',
      'za_course_action_type.category',
      'za_course_action_type.sno as course_action_type_id'
    )
      ->join('za_course_action_type', 'za_course_action_type.sno', '=', 'za_course_action.course_action_type_id')
      ->where('za_course_action_type.status', '!=', 2)
      ->where('za_course_action.status', '!=', 2)
      ->orderBy('za_course_action.sno', 'desc')
      ->where('za_course_action.sno', $id)->first();
    // return $editcategory;
    return response()->json([
      'status' => 200,
      'data' => $editcategory,
    ]);
  }


  public function Update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'course_action_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $course_action_name            = $request->course_action_name;
      $course_action_type_id         = $request->course_action_type_id;
      $course_action_desc            = $request->course_action_desc;

      // $upd_CourseCategoryModel = CourseActionTypeModel::find($id);
      $upd_CourseCategoryModel =  CourseActionModel::where('sno', $id)->first();
      $chk = CourseActionModel::where('course_action_name', ucwords($course_action_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        if ($request->hasFile('course_action_icon')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->file('course_action_icon')->extension();
          $destinationPath = public_path('course_action_icon');
          $request->file('course_action_icon')->move($destinationPath, $imageName);
          $course_action_icon = $imageName;
        } else {
          $course_action_icon = $request->icon_old;
        }


        $upd_CourseCategoryModel->course_action_name       = Ucfirst($course_action_name);
        $upd_CourseCategoryModel->course_action_type_id    = $course_action_type_id;
        $upd_CourseCategoryModel->course_action_icon       = $course_action_icon;
        $upd_CourseCategoryModel->course_action_desc       = $course_action_desc;
        // return  $upd_CourseCategoryModel;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Succcessfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }


  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CourseActionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CourseActionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}