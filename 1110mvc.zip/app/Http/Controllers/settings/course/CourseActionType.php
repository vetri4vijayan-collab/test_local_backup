<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CourseActionTypeModel;

class CourseActionType extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    $CourseCategory = CourseActionTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];

    // return $CourseCategory;
    // return view('content.settings.course.course_action_type.course_action_type_list');
    return view('content.settings.course.course_action_type.course_action_type_list', [
      'CourseCategory' => $CourseCategory,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $Courseaction = CourseActionTypeModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Courseaction
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'course_action_type_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {




      $course_action_type_name       = $request->course_action_type_name;
      $category                      = $request->ca_category;
      $category_text_field           = $request->category_text_field;
      $category_text_area            = $request->category_text_area;
      $user_id                       = $request->user()->user_id;

      $chk = CourseActionTypeModel::where('course_action_type_name', ucwords($course_action_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        $result = response([
          'status'    => 401,
          'message'   => 'Error',
          'error_msg' => 'Name has been  already created!',
          'data'      => null,
        ], 200);
      } else {

        if ($request->hasFile('category_file_upload')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->file('category_file_upload')->extension();
          $destinationPath = public_path('category_file_upload');
          $request->file('category_file_upload')->move($destinationPath, $imageName);
          $category_file_upload = $imageName;
        } else {
          $category_file_upload = '';
        }

        $add_category = new CourseActionTypeModel();
        $add_category->course_action_type_name    = Ucfirst($course_action_type_name);
        $add_category->category                   = $category;
        $add_category->category_file_upload       = $category_file_upload;
        $add_category->category_text_field        = $category_text_field;
        $add_category->category_text_area         = $category_text_area;
        $add_category->branch_id                 = self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        // return $add_category;
        $add_category->save();

        if ($add_category) {

          $result = response([
            'status'    => 200,
            'message'   => 'Successfully Course Category Created',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        } else {
          $result = response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
          ], 401);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editcategory = CourseActionTypeModel::where('sno', $id)->first();
    // return $editcategory;
    return response()->json([
      'status' => 200,
      'data' => $editcategory,
    ]);
  }


  public function Update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'course_action_type_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $course_action_type_name       = $request->course_action_type_name;
      $category                      = $request->category;
      $category_file_upload          = $request->category_file_upload;
      $category_text_field           = $request->category_text_field;
      $category_text_area            = $request->category_text_area;


      $upd_CourseCategoryModel =  CourseActionTypeModel::where('sno', $id)->first();
      $chk = CourseActionTypeModel::where('course_action_type_name', ucwords($course_action_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->course_action_type_name = ucfirst($course_action_type_name);
        $upd_CourseCategoryModel->category = $category;
        $upd_CourseCategoryModel->category_file_upload = $category_file_upload;
        $upd_CourseCategoryModel->category_text_field = $category_text_field;
        $upd_CourseCategoryModel->category_text_area = $category_text_area;
        // return  $upd_CourseCategoryModel;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }


  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CourseActionTypeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CourseActionTypeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}