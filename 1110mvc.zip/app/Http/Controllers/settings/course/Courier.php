<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CourierModel;
use Illuminate\Support\Facades\Validator;

class Courier extends Controller {
    protected static $branch_id = 1;

    public function index() {

        $courier = CourierModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];
        return view( 'content.settings.course.courier.courier_list', [
            'courier' => $courier,
            'pageConfigs' => $pageConfigs
        ] );
    }

    public function List() {
        $courier = CourierModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $courier
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'courier_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $courier_name = $request->courier_name;
            $courier_desc = $request->courier_desc;
            $user_id = 1;
            $chk = CourierModel::where( 'courier_name', ucwords( $courier_name ) )->where( 'branch_id', self::$branch_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already courier is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = CourierModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $courier_id = 'CR-0001/' . $year;
                } else {

                    $data = $category_check->courier_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int ) $result + 1;
                    $request = sprintf( 'CR-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $courier_id = $request . '/' . $year;
                }

                $add_courier = new CourierModel();
                $add_courier->courier_id = $courier_id;
                $add_courier->courier_name = Ucfirst( $courier_name );
                $add_courier->courier_desc = $courier_desc;
                $add_courier->branch_id = self::$branch_id;
                $add_courier->created_by = $user_id;
                $add_courier->updated_by = $user_id;

                $add_courier->save();

                if ( $add_courier ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'courier added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the courier!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit( $id ) {
        $editcourier = CourierModel::where( 'sno', $id )->first();

        return view( 'content.settings.course.courier.courier_list', [
            'editcourier' => $editcourier,
            'id' => $id,
        ] );
    }

    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'courier_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $courier_name = $request->courier_name;
            $courier_desc = $request->courier_desc;
            $courier_id = $request->courier_id;

            $upd_CourierModel = CourierModel::where( 'sno', $courier_id )->first();

            $chk = CourierModel::where( 'courier_name', ucwords( $courier_name ) )->where( 'branch_id', self::$branch_id )->where( 'sno', '!=', $courier_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already courier is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_CourierModel->courier_name = Ucfirst( $courier_name );
                $upd_CourierModel->courier_desc = $courier_desc;
                $upd_CourierModel->branch_id = self::$branch_id;
                $upd_CourierModel->update();

                if ( $upd_CourierModel ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'courier Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the courier!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_CourierModel = CourierModel::where( 'sno', $id )->first();
        $upd_CourierModel->status = 2;
        $upd_CourierModel->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_CourierModel = CourierModel::where( 'sno', $id )->first();
        $upd_CourierModel->status = $request->input( 'status', 0 );
        $upd_CourierModel->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}