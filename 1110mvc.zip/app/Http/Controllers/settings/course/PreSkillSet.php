<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\PreSkillSetModel;

class PreSkillSet extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {

        // return view('content.settings.course.brand.brand');
        $pre_skill_set = PreSkillSetModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.course.pre_skill_set.pre_skill_set', compact('pre_skill_set', 'pageConfigs'));
    }

    public function List()
    {
        $pre_skill_set = PreSkillSetModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $pre_skill_set
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'pre_skill_set_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $pre_skill_set_name       = $request->pre_skill_set_name;
            $pre_skill_set_desc       = $request->pre_skill_set_desc;

            $user_id                    = $request->user()->user_id;
            $chk = PreSkillSetModel::where('pre_skill_set_name', ucwords($pre_skill_set_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = PreSkillSetModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $pre_skill_set_id = "PSS-0001/" . $year;
                } else {

                    $data = $category_check->pre_skill_set_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf("PSS-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $pre_skill_set_id = $request . '/' . $year;
                }


                $add_category = new PreSkillSetModel();
                $add_category->pre_skill_set_id         = $pre_skill_set_id;
                $add_category->pre_skill_set_name       = Ucfirst($pre_skill_set_name);
                $add_category->pre_skill_set_desc       = $pre_skill_set_desc;
                $add_category->branch_id           = self::$branch_id;
                $add_category->created_by           = $user_id;
                $add_category->updated_by           = $user_id;

                $add_category->save();

                if ($add_category) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Pre Skill set added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the pre skill set!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'Job Roll Created successfully!');
        }
    }

    public function Edit($id)
    {
        $pre_skill_set = PreSkillSetModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $pre_skill_set
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'pre_skill_set_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $pre_skill_set_name       = $request->pre_skill_set_name;
            $pre_skill_set_desc       = $request->pre_skill_set_desc;

            $upd_CourseCategoryModel =  PreSkillSetModel::where('sno', $id)->first();

            $chk = PreSkillSetModel::where('pre_skill_set_name', ucwords($pre_skill_set_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'status'    => 401,
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $upd_CourseCategoryModel->pre_skill_set_name  = Ucfirst($pre_skill_set_name);
                $upd_CourseCategoryModel->pre_skill_set_desc  = $pre_skill_set_desc;
                $upd_CourseCategoryModel->update();
            }

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  PreSkillSetModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  PreSkillSetModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}