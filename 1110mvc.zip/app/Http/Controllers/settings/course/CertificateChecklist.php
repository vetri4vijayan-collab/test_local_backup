<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CertificateChecklistModel;
use Illuminate\Support\Facades\Validator;

class CertificateChecklist extends Controller
{
    public function index()
    {

        $CertificateChecklist = CertificateChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.course.certificate_checklist.certificate_checklist', [
            'CertificateChecklist' => $CertificateChecklist,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $CertificateChecklist = CertificateChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $CertificateChecklist
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'certificate_checklist_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $certificate_checklist_name = $request->certificate_checklist_name;
            $certificate_checklist_desc = $request->certificate_checklist_desc;
            $user_id = 1;
            $chk = CertificateChecklistModel::where('certificate_checklist_name', ucwords($certificate_checklist_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Certificate Checklist is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = CertificateChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $certificate_checklist_id = "CC-0001/" . $year;
                } else {

                    $data = $category_check->certificate_checklist_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("CC-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $certificate_checklist_id = $request . '/' . $year;
                }


                $add_certificate_checklist = new CertificateChecklistModel();
                $add_certificate_checklist->certificate_checklist_id = $certificate_checklist_id;
                $add_certificate_checklist->certificate_checklist_name = Ucfirst($certificate_checklist_name);
                $add_certificate_checklist->certificate_checklist_desc = $certificate_checklist_desc;
                $add_certificate_checklist->created_by = $user_id;
                $add_certificate_checklist->updated_by = $user_id;

                $add_certificate_checklist->save();

                if ($add_certificate_checklist) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Certificate Checklist added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Certificate Checklist!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editcertificate_checklist = CertificateChecklistModel::where('sno', $id)->first();

        return view('content.settings.course.certificate_checklist.certificate_checklist', [
            'editcertificate_checklist' => $editcertificate_checklist,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'certificate_checklist_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $certificate_checklist_name = $request->certificate_checklist_name;
            $certificate_checklist_desc = $request->certificate_checklist_desc;
            $certificate_checklist_id = $request->certificate_checklist_id;

            $upd_CertificateChecklistModel = CertificateChecklistModel::where('sno', $certificate_checklist_id)->first();

            $chk = CertificateChecklistModel::where('certificate_checklist_name', ucwords($certificate_checklist_name))->where('sno', '!=', $certificate_checklist_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Certificate Checklist is exist!'
                ]);
                return redirect()->back();
            } else {


                $upd_CertificateChecklistModel->certificate_checklist_name = Ucfirst($certificate_checklist_name);
                $upd_CertificateChecklistModel->certificate_checklist_desc = $certificate_checklist_desc;
                $upd_CertificateChecklistModel->update();


                if ($upd_CertificateChecklistModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Certificate Checklist  Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Certificate Checklist!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CertificateChecklistModel = CertificateChecklistModel::where('sno', $id)->first();
        $upd_CertificateChecklistModel->status = 2;
        $upd_CertificateChecklistModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_CertificateChecklistModel = CertificateChecklistModel::where('sno', $id)->first();
        $upd_CertificateChecklistModel->status = $request->input('status', 0);
        $upd_CertificateChecklistModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}