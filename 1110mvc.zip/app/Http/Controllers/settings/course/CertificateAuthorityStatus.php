<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CertificateAuthorityStatusModel;
use Illuminate\Support\Facades\Validator;

class CertificateAuthorityStatus extends Controller
{
  public function index()
  {
    $CertificateAuthorityStatus = CertificateAuthorityStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.course.certificate_authority_status.certificate_authority_status', [
      'CertificateAuthorityStatus' => $CertificateAuthorityStatus,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $CertificateAuthorityStatus = CertificateAuthorityStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CertificateAuthorityStatus
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'certificate_authority_status_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $certificate_authority_status_name       = $request->certificate_authority_status_name;
      $bg_color                      = $request->bg_color;
      $text_color                    = $request->text_color;
      $certificate_authority_status_desc       = $request->certificate_authority_status_desc;
      $user_id                       = 1;
      $chk = CertificateAuthorityStatusModel::where('certificate_authority_status_name', ucwords($certificate_authority_status_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = CertificateAuthorityStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $certificate_authority_status_id = "CA-0001/" . $year;
        } else {

          $data = $category_check->certificate_authority_status_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CA-%04d", $next_number);

          $year = substr(date("y"), -2);
          $certificate_authority_status_id = $request . '/' . $year;
        }


        $add_category = new CertificateAuthorityStatusModel();
        $add_category->certificate_authority_status_id           = $certificate_authority_status_id;
        $add_category->certificate_authority_status_name         = Ucfirst($certificate_authority_status_name);
        $add_category->bg_color                        = $bg_color;
        $add_category->text_color                      = $text_color;
        $add_category->certificate_authority_status_desc         = $certificate_authority_status_desc;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Certificate Authority Status added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Certificate Authority Status!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editcertificate_authority_status = CertificateAuthorityStatusModel::where('sno', $id)->first();

    return view('content.settings.course.certificate_authority_status.certificate_authority_status', [
      'editcertificate_authority_status' => $editcertificate_authority_status,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'certificate_authority_status_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $certificate_authority_status_name       = $request->certificate_authority_status_name;
      $bg_color                      = $request->bg_color;
      $text_color                    = $request->text_color;
      $certificate_authority_status_desc       = $request->certificate_authority_status_desc;
      $certificate_authority_status_id         = $request->certificate_authority_status_id;

      $upd_CertificateAuthorityStatusModel =  CertificateAuthorityStatusModel::where('sno', $certificate_authority_status_id)->first();

      $chk = CertificateAuthorityStatusModel::where('certificate_authority_status_name', ucwords($certificate_authority_status_name))->where('sno', '!=', $certificate_authority_status_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Certificate Authority Status is exist!'
        ]);
        return redirect()->back();
      } else {

        $upd_CertificateAuthorityStatusModel->certificate_authority_status_name  = Ucfirst($certificate_authority_status_name);
        $upd_CertificateAuthorityStatusModel->bg_color                 = $bg_color;
        $upd_CertificateAuthorityStatusModel->text_color               = $text_color;
        $upd_CertificateAuthorityStatusModel->certificate_authority_status_desc  = $certificate_authority_status_desc;
        $upd_CertificateAuthorityStatusModel->update();


        if ($upd_CertificateAuthorityStatusModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Certificate Authority Status Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Certificate Authority Status!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CertificateAuthorityStatusModel =  CertificateAuthorityStatusModel::where('sno', $id)->first();
    $upd_CertificateAuthorityStatusModel->status  = 2;
    $upd_CertificateAuthorityStatusModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CertificateAuthorityStatusModel =  CertificateAuthorityStatusModel::where('sno', $id)->first();

    $upd_CertificateAuthorityStatusModel->status = $request->input('status', 0);
    $upd_CertificateAuthorityStatusModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
