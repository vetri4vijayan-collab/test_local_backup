<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CourseCategoryModel;
use App\Models\User;

class CourseCategory extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $CourseCategory = CourseCategoryModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return view('content.settings.course.course_category.course_category_list');
    return view('content.settings.course.course_category.course_category_list', [
      'CourseCategory' => $CourseCategory,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $CourseCategory = CourseCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseCategory
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'course_category_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $course_category_name       = $request->course_category_name;
      $course_category_desc       = $request->course_category_desc;
      $user_id                    = $request->user()->user_id;
      $chk = CourseCategoryModel::where('course_category_name', ucwords($course_category_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = CourseCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $course_category_id = "CC-0001/" . $year;
        } else {

          $data = $category_check->course_category_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $course_category_id = $request . '/' . $year;
        }


        $add_category = new CourseCategoryModel();
        $add_category->course_category_id         = $course_category_id;
        $add_category->course_category_name       = Ucfirst($course_category_name);
        $add_category->course_category_desc       = $course_category_desc;
        $add_category->branch_id                 =  self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Course Category Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Course Category!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {
    $editcategory = CourseCategoryModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'course_category_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $course_category_name = $request->course_category_name;
      $course_category_desc = $request->course_category_desc;
      $course_category_id   = $request->course_category_id;

      $upd_CourseCategoryModel =  CourseCategoryModel::where('sno', $id)->first();

      if (!$upd_CourseCategoryModel) {
        return response([
          'status'    => 404,
          'message'   => 'Course category not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

      $chk = CourseCategoryModel::where('course_category_name', ucwords($course_category_name))
        ->where('status', '!=', 2)
        ->where('sno', '!=', $id)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {

        $upd_CourseCategoryModel->course_category_name = ucfirst($course_category_name);
        $upd_CourseCategoryModel->course_category_desc = $course_category_desc;
        $upd_CourseCategoryModel->update();
      }

      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CourseCategoryModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CourseCategoryModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
