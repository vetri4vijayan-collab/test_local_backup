<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CourseSubCategoryModel;

class CourseSubCategory extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $CourseSubCategory = CourseSubCategoryModel::select('za_course_subcategory.*', 'za_course_category.course_category_name', 'za_course_category.sno as category_id')
      ->join('za_course_category', 'za_course_subcategory.course_category_id', '=', 'za_course_category.sno')
      ->where('za_course_subcategory.status', '!=', 2)
      ->where('za_course_subcategory.branch_id', self::$branch_id)
      ->orderBy('za_course_subcategory.sno', 'desc')->get();

    $selectedCategoryId = $CourseSubCategory->isEmpty() ? null : $CourseSubCategory[0]->course_category_id;
    $pageConfigs = ['myLayout' => 'default'];
    // echo  $selectedCategoryId;
    // exit;
    return view('content.settings.course.course_subcategory.course_subcategory_list', [
      'CourseSubCategory' => $CourseSubCategory,
      'selectedCategoryId' => $selectedCategoryId,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List(Request $request)
  {
    // Retrieve the category ID from the POST request
    $cat_id = $_GET['id'] ?? '';

    $CourseSubCategory = CourseSubCategoryModel::where('branch_id', self::$branch_id)->where('status', 0)
      ->where('course_category_id', $cat_id)
      ->orderBy('sno', 'desc')
      ->get();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseSubCategory
    ], 200);
  }
  
   public function ListCustomer(Request $request)
  {
    // return $id;
    // Retrieve the category ID from the POST request
     $categoryId = $request->get('course_category_id');

    $CourseSubCategory = CourseSubCategoryModel::where('branch_id', self::$branch_id)->where('status', 0)
      ->where('course_category_id', $categoryId)
      ->orderBy('sno', 'desc')
      ->get();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseSubCategory
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'course_subcategory_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $course_subcategory_name       = $request->course_subcategory_name;
      $course_subcategory_desc          = $request->course_subcategory_desc;
      $course_category_id           = $request->course_category_id;
      $user_id                    = $request->user()->user_id;
      $chk = CourseSubCategoryModel::where('course_subcategory_name', ucwords($course_subcategory_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = CourseSubCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $course_subcategory_id = "CS-0001/" . $year;
        } else {

          $data = $category_check->course_subcategory_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CS-%04d", $next_number);

          $year = substr(date("y"), -2);
          $course_subcategory_id = $request . '/' . $year;
        }


        $add_category = new CourseSubCategoryModel();
        $add_category->course_category_id         = $course_category_id;
        $add_category->course_subcategory_id         = $course_subcategory_id;
        $add_category->course_subcategory_name       = Ucfirst($course_subcategory_name);
        $add_category->course_subcategory_desc       = $course_subcategory_desc;
        $add_category->branch_id                 = self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Course SubCategory added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Course SubCategory!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function edit($id)
  {
    $editCategory = CourseSubCategoryModel::select(
      'za_course_subcategory.*',
      'za_course_category.course_category_name',
      'za_course_category.sno as category_id'
    )
      ->join('za_course_category', 'za_course_subcategory.course_category_id', '=', 'za_course_category.sno')
      ->where('za_course_subcategory.sno', $id)
      ->first();

    return response()->json([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editCategory
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'course_subcategory_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $course_category_id            = $request->course_category_id_edit;
      $course_subcategory_name       = $request->course_subcategory_name;
      $course_subcategory_desc       = $request->course_subcategory_desc;
      $course_subcategory_id         = $request->course_subcategory_id;

      $upd_CourseCategoryModel =  CourseSubCategoryModel::where('sno', $course_subcategory_id)->first();

      $chk = CourseSubCategoryModel::where('course_subcategory_name', ucwords($course_subcategory_name))->where('status', '!=', 2)->where('sno', '!=', $course_subcategory_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->course_category_id    = $course_category_id;
        $upd_CourseCategoryModel->course_subcategory_name  = Ucfirst($course_subcategory_name);
        $upd_CourseCategoryModel->course_subcategory_desc  = $course_subcategory_desc;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Course SubCategory Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Course SubCategory!'
        ]);
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CourseSubCategoryModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CourseSubCategoryModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}