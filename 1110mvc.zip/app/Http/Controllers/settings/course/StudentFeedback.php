<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\StudentFeedbackModel;

class StudentFeedback extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {
        $studentfeedback = StudentFeedbackModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.course.student_feedback.student_feedbacks_list', [
            'studentfeedback' => $studentfeedback,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $studentfeedback = StudentFeedbackModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $studentfeedback
        ], 200);
    }
    public function Add(Request $request)
    {

        // return $request;
        $validator = Validator::make($request->all(), [
            'studentfeedback_name' => 'required|max:255',
            // 'studentfeedback_logo' => 'required|max:255',

        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $studentfeedback_name = $request->studentfeedback_name;
            $studentfeedback_desc = $request->studentfeedback_desc;
            $user_id = $request->user()->user_id;
            $chk = StudentFeedbackModel::where('studentfeedback_name', ucwords($studentfeedback_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Student Feedback is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = StudentFeedbackModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $studentfeedback_id = "SF-0001/" . $year;
                } else {

                    $data = $category_check->studentfeedback_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $requests = sprintf("SF-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $studentfeedback_id = $requests . '/' . $year;
                }


                if ($request->hasFile('studentfeedback_logo')) {
                    $imageName = idate('B') . rand(1, 50) . '.' . $request->file('studentfeedback_logo')->extension();
                    $destinationPath = public_path('studentfeedback_logo');
                    // Path to the logos directory
                    $request->file('studentfeedback_logo')->move($destinationPath, $imageName);
                    $logo = $imageName;
                } else {
                    $logo = '';
                }

                $add_studentfeedback = new StudentFeedbackModel();
                $add_studentfeedback->studentfeedback_id = $studentfeedback_id;
                $add_studentfeedback->studentfeedback_name = Ucfirst($studentfeedback_name);
                $add_studentfeedback->studentfeedback_logo = $logo;
                $add_studentfeedback->studentfeedback_desc = $studentfeedback_desc;
                $add_studentfeedback->branch_id = self::$branch_id;
                $add_studentfeedback->created_by = $user_id;
                $add_studentfeedback->updated_by = $user_id;

                $add_studentfeedback->save();

                if ($add_studentfeedback) {

                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Student Feedback added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Student Feedback!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editstudentfeedback = StudentFeedbackModel::where('sno', $id)->first();

        return view('content.settings.sales.student_feedback.student_feedback_list', [
            'editstudentfeedback' => $editstudentfeedback,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'studentfeedback_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $studentfeedback_name = $request->studentfeedback_name;
        $studentfeedback_desc = $request->studentfeedback_desc;
        $studentfeedback_id = $request->studentfeedback_id;
        $old_studentfeedback_img = $request->old_studentfeedback_img;
        $upd_StudentFeedbackModel = StudentFeedbackModel::where('sno', $studentfeedback_id)->first();

        if (!$upd_StudentFeedbackModel) {
            return response([
                'status' => 404,
                'message' => 'Record not found',
                'error_msg' => null,
                'data' => null,
            ], 404);
        }

        $chk = StudentFeedbackModel::where('studentfeedback_name', ucwords($studentfeedback_name))
            ->where('branch_id', self::$branch_id)->where('status', '!=', 2)
            ->where('sno', '!=', $studentfeedback_id) // Exclude the current record from check
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Student Feedback is exist!'
            ]);
            return redirect()->back();
        } else {
            if ($request->hasFile('studentfeedback_logo_edit')) {
                $imageName = idate('B') . rand(1, 50) . '.' . $request->file('studentfeedback_logo_edit')->extension();
                $destinationPath = public_path('studentfeedback_logo');
                // Path to the logos directory
                $request->file('studentfeedback_logo_edit')->move($destinationPath, $imageName);
                $logo = $imageName;
            } else {
                $logo = $request->studentfeedback_logo_edit_hidden;
            }

            $upd_StudentFeedbackModel->studentfeedback_name = ucfirst($studentfeedback_name);
            $upd_StudentFeedbackModel->studentfeedback_logo = $logo;
            $upd_StudentFeedbackModel->studentfeedback_desc = $studentfeedback_desc;
            $upd_StudentFeedbackModel->updated_by = 1;

            $upd_StudentFeedbackModel->save();

            if ($upd_StudentFeedbackModel) {
                // If update successful, return success response
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Student Feedback updated successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the student Feedback!'
                ]);
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_StudentFeedbackModel = StudentFeedbackModel::where('sno', $id)->first();
        $upd_StudentFeedbackModel->status = 2;
        $upd_StudentFeedbackModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_StudentFeedbackModel = StudentFeedbackModel::where('sno', $id)->first();
        $upd_StudentFeedbackModel->status = $request->input('status', 0);
        $upd_StudentFeedbackModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}