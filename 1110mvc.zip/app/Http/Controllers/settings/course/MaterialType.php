<?php

namespace App\Http\Controllers\settings\course;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\MaterialTypeModel;




class MaterialType extends Controller
{

    public function index(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $material_type = MaterialTypeModel::select('*')
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')->get();

        // return $material_type;

      return view('content.settings.course.material_type.material_type', [
        'material_type' => $material_type
      ]);
    }

    public function List(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $material_list = MaterialTypeModel::where('status', 0)
        ->orderBy('sno', 'desc')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $material_list
      ], 200);
    }

    public function Add(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $validator = Validator::make($request->all(), [
        'material_type_name' => 'required|max:255'
      ]);
      if ($validator->fails()) {
        return  response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {


        $material_type_name       = $request->material_type_name;
        $material_type_id       = $request->material_type_id;
        $user_id                    = $request->user()->user_id;
        $chk = MaterialTypeModel::where('material_type_name', ucwords($material_type_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

        if ($chk) {

          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Name has been already created!'
          ]);
        } else {
          $category_check = MaterialTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


          if (!$category_check) {
            $year = substr(date("y"), -2);
            $material_type_id = "MT-0001/" . $year;
          } else {

            $data = $category_check->material_type_id;
            $slice = explode("/", $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);

            $next_number = (int)$result + 1;
            $request = sprintf("MT-%04d", $next_number);

            $year = substr(date("y"), -2);
            $material_type_id = $request . '/' . $year;
          }


          $add_category = new MaterialTypeModel();
          $add_category->material_type_id         = $material_type_id;
          $add_category->material_type_name       = Ucfirst($material_type_name);
          $add_category->branch_id                 = $branch_id;
          $add_category->created_by                 = $user_id;
          $add_category->updated_by                 = $user_id;

          $add_category->save();

          if ($add_category) {

            session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Material Type added Successfully!'
            ]);
          } else {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not add the Material Type!'
            ]);
          }
        }
        return redirect()->back();
      }
    }


    public function edit(Request $request,$id)
    {
      $branch_id = $request->user()->branch_id;
      $material = MaterialTypeModel::where('sno', $id)->where('branch_id', $branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();

        return view('content.settings.course.material_type.material_type', [
          'edit' => $material,
      ]);
    }

    public function Update(Request $request)
    {

      // return $request;
      $validator = Validator::make($request->all(), [
        'material_type_edit' => 'required|max:255',
      ]);

      if ($validator->fails()) {
        return   response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg'     => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      } else {

        $material_type_name             = $request->material_type_edit;
        $material_type_id       = $request->material_type_id;
      // return $request;

        $upd_CourseCategoryModel =  MaterialTypeModel::where('sno', $material_type_id)->first();

        $chk = MaterialTypeModel::where('material_type_name', ucwords($material_type_name))->where('status', '!=', 2)->where('sno', '!=', $material_type_id)->first();

        if ($chk) {
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => 'Name has been already created!'
          ]);
        } else {
          $upd_CourseCategoryModel->sno    = $material_type_id;
          $upd_CourseCategoryModel->material_type_name  = Ucfirst($material_type_name);
          $upd_CourseCategoryModel->update();
        }
        if ($upd_CourseCategoryModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Material Type updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Material Type!'
          ]);
        }
      }
      return redirect()->back();
    }


    public function Delete($id)
    {
      $upd_CourseCategoryModel =  MaterialTypeModel::where('sno', $id)->first();
      $upd_CourseCategoryModel->status  = 2;
      $upd_CourseCategoryModel->Update();


      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    public function Status($id, Request $request)
    {

      $material_type =  MaterialTypeModel::where('sno', $id)->first();
      $material_type->status = $request->input('status', 0);
      $material_type->update();

      return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

  }
