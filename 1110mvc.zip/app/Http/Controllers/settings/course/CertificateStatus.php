<?php

namespace App\Http\Controllers\settings\course;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CertificateStatusModel;
use Illuminate\Support\Facades\Validator;

class CertificateStatus extends Controller
{
  public function index()
  {
    $CertificateStatus = CertificateStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.course.certificate_status.certificate_status', [
      'CertificateStatus' => $CertificateStatus,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $CertificateStatus = CertificateStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CertificateStatus
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'certificate_status_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $certificate_status_name       = $request->certificate_status_name;
      $bg_color                      = $request->bg_color;
      $text_color                    = $request->text_color;
      $certificate_status_desc       = $request->certificate_status_desc;
      $user_id                       = 1;
      $chk = CertificateStatusModel::where('certificate_status_name', ucwords($certificate_status_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = CertificateStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $certificate_status_id = "CS-0001/" . $year;
        } else {

          $data = $category_check->certificate_status_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CS-%04d", $next_number);

          $year = substr(date("y"), -2);
          $certificate_status_id = $request . '/' . $year;
        }


        $add_category = new CertificateStatusModel();
        $add_category->certificate_status_id           = $certificate_status_id;
        $add_category->certificate_status_name         = Ucfirst($certificate_status_name);
        $add_category->bg_color                        = $bg_color;
        $add_category->text_color                      = $text_color;
        $add_category->certificate_status_desc         = $certificate_status_desc;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Certificate Status added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Certificate Status!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editcertificate_status = CertificateStatusModel::where('sno', $id)->first();

    return view('content.settings.course.certificate_status.certificate_status', [
      'editcertificate_status' => $editcertificate_status,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'certificate_status_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $certificate_status_name       = $request->certificate_status_name;
      $bg_color                      = $request->bg_color;
      $text_color                    = $request->text_color;
      $certificate_status_desc       = $request->certificate_status_desc;
      $certificate_status_id         = $request->certificate_status_id;

      $upd_CertificateStatusModel =  CertificateStatusModel::where('sno', $certificate_status_id)->first();

      $chk = CertificateStatusModel::where('certificate_status_name', ucwords($certificate_status_name))->where('sno', '!=', $certificate_status_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Certificate Status is exist!'
        ]);
        return redirect()->back();
      } else {

        $upd_CertificateStatusModel->certificate_status_name  = Ucfirst($certificate_status_name);
        $upd_CertificateStatusModel->bg_color                 = $bg_color;
        $upd_CertificateStatusModel->text_color               = $text_color;
        $upd_CertificateStatusModel->certificate_status_desc  = $certificate_status_desc;
        $upd_CertificateStatusModel->update();


        if ($upd_CertificateStatusModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Certificate Status Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Certificate Status!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CertificateStatusModel =  CertificateStatusModel::where('sno', $id)->first();
    $upd_CertificateStatusModel->status  = 2;
    $upd_CertificateStatusModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CertificateStatusModel =  CertificateStatusModel::where('sno', $id)->first();

    $upd_CertificateStatusModel->status = $request->input('status', 0);
    $upd_CertificateStatusModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
