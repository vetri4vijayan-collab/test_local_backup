<?php

namespace App\Http\Controllers\settings\counsellor;

use App\Http\Controllers\Controller;
use App\Models\CourseQuestionModel;
use App\Models\CourseSubCategoryModel;
use Illuminate\Http\Request;
use App\Models\LeadQuestionModel;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Facades\Validator;

class CourseQuestion extends Controller
{
    public function Index()
    {

        $course_question = CourseQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // $pageConfigs = ['myLayout' => 'default'];
        // // dd($quest);
        // return view('content.settings.sales.lead_question.lead_question_list', compact('quest', 'pageConfigs'));

        return view('content.settings.counsellor.course_question.course_question_list', [
            'course_question' => $course_question
        ]);
    }
    public function CourseQuestionAdd()
    {
        return view('content.settings.counsellor.course_question.course_questions_add');
    }
    public function CourseQuestionEdit()
    {
        return view('content.settings.counsellor.course_question.course_questions_edit');
    }
    public function SubCategoryList()
    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = CourseSubCategoryModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }
    public function SubCatCourseList($id, Request $request)

    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = ManageCoursesModel::where('status', 0)
            ->where('course_subcategory_id', $id)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }

    public function SubCatCourseListAll()

    {
        // Retrieve the category ID from the POST request

        $CourseSubCategory = ManageCoursesModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }

    public function List()
    {
        $leadquestion = LeadQuestionModel::where('status', 0)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $leadquestion
        ], 200);
    }


    // public function Add(Request $request)
    // {
    //     // Validate incoming request
    //     $validator = Validator::make($request->all(), [
    //         'question.*' => 'required|max:255',
    //         'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
    //     ]);

    //     if ($validator->fails()) {
    //         session()->flash('toastr', [
    //             'type' => 'error',
    //             'message' => 'Lead Question Name is required!'
    //         ]);
    //         return redirect()->back();
    //     }
    //     dd($request->all());
    //     // dd($data);
    //     $user_id = $request->user()->user_id;

    //     foreach ($request->input('question') as $key => $course_question_name) {
    //         $course_question_type = $request->input('question_type.' . $key);
    //         $course_question_option = [];

    //         switch ($course_question_type) {
    //             case 'checkbox':
    //             case 'radio_button':
    //             case 'list_box':
    //                 $options_key = 'option_value_' . $course_question_type . '_' . $key;
    //                 $category_key = 'option_category_' . $course_question_type . '_' . $key;
    //                 $course_key = 'option_course_' . $course_question_type . '_' . $key;

    //                 $options = $request->input($options_key, []);
    //                 $categories = $request->input($category_key, []);
    //                 $courses = $request->input($course_key, []);

    //                 // Ensure all inputs are arrays
    //                 $options = (array) $options;
    //                 $categories = (array) $categories;
    //                 $courses = (array) $courses;
    //                 // dd($courses);
    //                 $options_array = [];

    //                 foreach ($options as $option_key => $value) {
    //                     if ($value !== '') {
    //                         // Ensure courses is an array
    //                         $course_array = isset($courses[$option_key]) ? (array) $courses[$option_key] : [];
    //                         $options_array[] = [
    //                             'value' => $value,
    //                             'category' => $categories[$option_key] ?? null,
    //                             'courses' => json_encode($course_array),  // Ensure this is an array before encoding
    //                         ];
    //                     }
    //                 }
    //                 dd($options_array);
    //                 $course_question_option = json_encode($options_array);
    //                 break;
    //             case 'text_field':
    //                 $course_question_option = null;
    //                 break;
    //             default:
    //                 break;
    //         }

    //         $chk = CourseQuestionModel::where('course_question_name', ucwords($course_question_name))
    //             ->where('status', '!=', 2)
    //             ->first();

    //         if ($chk) {
    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Name has been already created!'
    //             ]);
    //             continue;
    //         }

    //         $add_category = new CourseQuestionModel();
    //         $add_category->course_question_name = ucfirst($course_question_name);
    //         $add_category->course_question_type = $course_question_type;
    //         $add_category->course_question_option = $course_question_option;
    //         $add_category->created_by = $user_id;
    //         $add_category->updated_by = $user_id;
    //         return $add_category;
    //         if ($add_category->save()) {
    //             session()->flash('toastr', [
    //                 'type' => 'success',
    //                 'message' => 'Course Question added Successfully!'
    //             ]);
    //         } else {
    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Could not add the Course Question!'
    //             ]);
    //         }
    //     }

    //     return redirect()->route('settings-counsellor-course_question_list');
    // }
    public function Add(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255',
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            'option_value_checkbox_*.*' => 'nullable|string',
            'option_course_checkbox_*.*' => 'nullable|array',
            'option_value_radio_button_*.*' => 'nullable|string',
            'option_course_radio_button_*.*' => 'nullable|array',
            'option_value_list_box_*.*' => 'nullable|string',
        ]);




        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed. Please check your inputs.'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $user_id = $request->user()->user_id;

        foreach ($request->input('question') as $key => $course_question_name) {
            $course_question_type = $request->input('question_type.' . $key);
            dd($course_question_type);
            $course_question_option = [];

            switch ($course_question_type) {
                case 'checkbox':
                case 'radio_button':
                case 'list_box':
                    $options_key = 'option_value_' . $course_question_type . '_' . $key;
                    // $category_key = 'option_category_' . $course_question_type . '_' . $key;
                    $course_key = 'option_course_' . $course_question_type . '_' . $key;

                    $options = $request->input($options_key, []);
                    // $categories = $request->input($category_key, []);
                    $courses = $request->input($course_key, []);
                    // dd($courses);
                    // Ensure all inputs are arrays
                    $options = (array) $options;
                    // $categories = (array) $categories;
                    $courses = (array) $courses;

                    $options_array = [];

                    foreach ($options as $option_key => $value) {
                        if ($value !== '') {
                            $course_array = isset($courses[$option_key]) ? (array) $courses[$option_key] : [];
                            $options_array[] = [
                                'value' => $value,
                                // 'category' => $categories[$option_key] ?? null,
                                'courses' => json_encode($course_array),
                            ];
                        }
                    }
                    // dd($options_array);
                    $course_question_option = json_encode($options_array);
                    break;
                case 'text_field':
                    $course_question_option = null;
                    break;
                default:
                    break;
            }

            // Check if question already exists
            $chk = CourseQuestionModel::where('course_question_name', ucfirst($course_question_name))
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has already been created!'
                ]);
                continue;
            }

            // Create and save new Course Question
            $add_category = new CourseQuestionModel();
            $add_category->course_question_name = ucfirst($course_question_name);
            $add_category->course_question_type = $course_question_type;
            $add_category->course_question_option = $course_question_option;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
            $add_category->save();
            if ($add_category->save()) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Course Question added successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Course Question!'
                ]);
            }
        }

        return redirect()->route('settings-counsellor-course_question_list');
    }



    public function Edit($id)
    {
        $editcategory = LeadQuestionModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_type.lead_type_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Course_edit($id)
    {

        // return $id;
        // Decrypt the ID
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $course_question = CourseQuestionModel::where('status', '!=', 2)
            ->where('sno', $decryptedValue)
            // ->orderBy('sno', 'desc')D:\Xampp_8.2.4\htdocs\eapl_full\resources\views\content\settings\counsellor\course_question\course_questions_edit.blade.php
            ->first();

        $json_string = $course_question->course_question_option;
        // dd($json_string);
        // Decode the JSON string into a PHP associative array
        $options_array = json_decode($json_string, true);
        // dd($options_array);

        // Initialize arrays to hold values and courses
        $values = [];
        $courses = [];

        // Process each item in the array
        foreach ($options_array as $item) {
            // Extract 'value'
            if (isset($item['value'])) {
                $values[] = $item['value'];
            }

            // Decode 'courses' from JSON string to PHP array
            if (isset($item['courses'])) {
                $courses[] = json_decode($item['courses'], true);
            }
        }

        // Map values and courses into the desired format
        $mapped_array = [];
        $maxCount = max(count($values), count($courses));

        for ($i = 0; $i < $maxCount; $i++) {
            $mapped_array[] = [
                'value' => isset($values[$i]) ? $values[$i] : '',
                'courses' => isset($courses[$i]) ? $courses[$i] : []
            ];
        }


        return view('content.settings.counsellor.course_question.course_questions_edit', [
            'course_question' => $course_question,
            'mapped_array' => $mapped_array,
        ]);
    }

    public function Update(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255',
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            'option_value_checkbox_*.*' => 'nullable|string',
            'option_course_checkbox_*.*' => 'nullable|array',
            'option_value_radio_button_*.*' => 'nullable|string',
            'option_course_radio_button_*.*' => 'nullable|array',
            'option_value_list_box_*.*' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed. Please check your inputs.'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $course_question_name = $request->course_question_name;
        $course_question_type       = $request->question_course;
        $course_question_option       = $request->options;
        $course_type_dropdown_select       = $request->course_type_dropdown_select;
        // dd($course_question_name);
        $sno    = $request->sno_edit;
        $user_id = $request->user()->user_id;
        

        // Get the options and course data from the request
        $options = $request->input('options', []);
        $courseData = $request->input('course_type_dropdown_select', []);
        // dd($options, $courseData);
        // Initialize an empty array to hold the result
        $result = [];

        // Iterate over each option and map it to the corresponding courses
        foreach ($options as $index => $value) {
            // dd($index, $value);
            // Generate the key for courses
            $courseKey = "{$index}[courses";
            // dd($courseKey);

            // Check if the courses exist for this index
            if (isset($courseData[$courseKey])) {
                // dd($courseData, $courseKey);
                // Create the formatted entry
                $result[] = [
                    'value' => $value,
                    'courses' => json_encode($courseData[$courseKey]) // Convert array to JSON string
                ];
            }
        }

        // return $result;
        // foreach ($request->input('question') as $key => $course_question_name) {
        //     $course_question_type = $request->input('course_question_type.' . $key);
        //     $course_question_option = [];

        //     switch ($course_question_type) {
        //         case 'checkbox':
        //         case 'radio_button':
        //         case 'list_box':
        //             $options_key = 'option_value_' . $course_question_type . '_' . $key;
        //             // $category_key = 'option_category_' . $course_question_type . '_' . $key;
        //             $course_key = 'option_course_' . $course_question_type . '_' . $key;

        //             $options = $request->input($options_key, []);
        //             // $categories = $request->input($category_key, []);
        //             $courses = $request->input($course_key, []);
        //             // dd($courses);
        //             // Ensure all inputs are arrays
        //             $options = (array) $options;
        //             // $categories = (array) $categories;
        //             $courses = (array) $courses;

        //             $options_array = [];

        //             foreach ($options as $option_key => $value) {
        //                 if ($value !== '') {
        //                     $course_array = isset($courses[$option_key]) ? (array) $courses[$option_key] : [];
        //                     $options_array[] = [
        //                         'value' => $value,
        //                         // 'category' => $categories[$option_key] ?? null,
        //                         'courses' => json_encode($course_array),
        //                     ];
        //                 }
        //             }
        //             // dd($options_array);
        //             $course_question_option = json_encode($options_array);
        //             break;
        //         case 'text_field':
        //             $course_question_option = null;
        //             break;
        //         default:
        //             break;
        //     }

        // Check if question already exists
        $chk = CourseQuestionModel::where('course_question_name', ucfirst($course_question_name))
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name has already been created!'
            ]);
            // continue;
        }

        // Create and save new Course Question
        $upd_CourseModel =  CourseQuestionModel::find($sno);
        $upd_CourseModel->course_question_name = ucfirst($course_question_name);
        $upd_CourseModel->course_question_type = $course_question_type;
        $upd_CourseModel->course_question_option = $result;
        // dd($upd_CourseModel->course_question_option);
        $upd_CourseModel->created_by = $user_id;
        $upd_CourseModel->updated_by = $user_id;

        $upd_CourseModel->save();
        if ($upd_CourseModel->save()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Course Question Updated successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Course Question!'
            ]);
        }
        // }

        return redirect()->route('settings-counsellor-course_question_list');
    }

    public function Delete($id)
    {
        $upd_CourseAnalysisModel =  CourseQuestionModel::where('sno', $id)->first();
        $upd_CourseAnalysisModel->status  = 2;
        $upd_CourseAnalysisModel->Update();
        if ($upd_CourseAnalysisModel) {
            return response([
                'status'    => 200,
                'message'   => ' Course Analysis Questions Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Course Analysis Questions!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Status($id, Request $request)
    {

        $upd_CourseAnalysisModel =  CourseQuestionModel::where('sno', $id)->first();
        $upd_CourseAnalysisModel->status = $request->input('status', 0);
        $upd_CourseAnalysisModel->update();
        if ($upd_CourseAnalysisModel) {
            return response([
                'status'    => 200,
                'message'   => 'Course Analysis Questions Successfully Updated!',
                'error_msg' => 'Could not ,update  Course Analysis Questions!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Course Analysis Questions!',
                'error_msg' => 'Could not ,update  Course Analysis Questions!',
                'data'      => null,
            ], 200);
        }
    }
}