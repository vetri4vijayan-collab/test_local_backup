<?php

namespace App\Http\Controllers\settings\counsellor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SelfAssessmentModel;
use App\Models\ManageCoursesModel;

use Illuminate\Support\Facades\Validator;

class SelfAssessment extends Controller
{
    public function Index()
    {

        $cat_question = SelfAssessmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // dd($cat_question);
        return view('content.settings.counsellor.category_assessment.assessment_ques_list', compact('cat_question', 'pageConfigs'));

        // return view('content.settings.counsellor.category_assessment.assessment_ques_list'); D:\Xampp_8.2.4\htdocs\eapl_full\resources\views\content\settings\counsellor\category_assessment\assessment_ques_edit.blade.php
    }
    public function ass_questions_add()
    {
        return view('content.settings.counsellor.category_assessment.assessment_ques_add');
    }


    public function assessment_edit($id)
    {
        // return $id;
        // Decrypt the ID
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $self_question = SelfAssessmentModel::where('status', '!=', 2)
            ->where('sno', $decryptedValue)
            // ->orderBy('sno', 'desc')
            ->first();

        return view('content.settings.counsellor.category_assessment.assessment_ques_edit', [
            'self_question' => $self_question
        ]);
        // return view('content.settings.counsellor.category_assessment.assessment_ques_edit');
    }


    public function List()
    {
        $leadquestion = SelfAssessmentModel::where('status', 0)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $leadquestion
        ], 200);
    }


    public function Add(Request $request)
    {
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255', // '*' indicates an array of questions
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            'category_type.*' => 'required|integer', // Validate category_id
            // Add validation rules for option fields if needed
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check your inputs.'
            ]);
            return redirect()->back()->withInput();
        }

        $user_id = $request->user()->user_id;

        foreach ($request->input('question') as $key => $category_question_name) {
            $category_question_type = $request->input('question_type.' . $key);
            $category_id = $request->input('category_type.' . $key); // Get category_id from request

            // Initialize options array
            $category_question_option = [];

            switch ($category_question_type) {
                case 'checkbox':
                case 'radio_button':
                case 'list_box':
                    // Get options for the current question
                    $options_key = 'option_value_' . $category_question_type . '_' . $key;

                    $options = $request->input($options_key, []);

                    $options_array = [];
                    foreach ($options as $option_key => $value) {
                        if ($value !== '') {
                            $options_array[] = [
                                'value' => $value,
                            ];
                        }
                    }

                    $category_question_option = json_encode($options_array); // Convert options to JSON
                    break;
                case 'text_field':
                    // No options needed for text_field questions
                    $category_question_option = null;
                    break;
                default:
                    break;
            }

            // Check if the question already exists
            $chk = SelfAssessmentModel::where('assessment_question_name', ucwords($category_question_name))
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been already created!'
                ]);
                continue;
            }

            // Add new category question
            $add_category = new SelfAssessmentModel();
            $add_category->assessment_question_name = ucfirst($category_question_name);
            $add_category->category_id = $category_id;
            $add_category->assessment_question_type = $category_question_type;
            $add_category->assessment_question_option = $category_question_option;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
            $add_category->save();

            // Flash success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Self Assessment Question added Successfully!'
            ]);
        }

        return redirect()->route('settings-counsellor-assessment_ques_list');
    }



    public function Edit($id)
    {
        $self_question = SelfAssessmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.counsellor.category_assessment.assessment_ques_edit', [
            'self_question' => $self_question
        ]);
    }

    public function Update(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255', // '*' indicates an array of questions
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            'category_type.*' => 'required|integer', // Validate category_id
            // Add validation rules for option fields if needed
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check your inputs.'
            ]);
            return redirect()->back()->withInput();
        } else {
            $user_id = $request->user()->user_id;

            $self_assessment_question_name = $request->self_assessment_question_name;
            $course_cat       = $request->course_cat;
            $question_cat       = $request->question_cat;
            $top_name       = $request->top_name;
            $sno    = $request->sno_edit;

            $upd_CourseCategoryModel =  SelfAssessmentModel::find($sno);

            $upd_CourseCategoryModel->assessment_question_name  = $self_assessment_question_name;
            $upd_CourseCategoryModel->category_id  = $course_cat;


            $options_array = [];
            foreach ($top_name as $option_key => $value) {
                if ($value !== '') {
                    $options_array[] = [
                        'value' => $value,
                    ];
                }
            }
            $upd_CourseCategoryModel->assessment_question_option  = json_encode($options_array);
            $upd_CourseCategoryModel->assessment_question_type  = $question_cat;
            $upd_CourseCategoryModel->created_by = $user_id;
            $upd_CourseCategoryModel->updated_by = $user_id;
            $upd_CourseCategoryModel->update();

            // Flash success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Self Assessment Question Update Successfully!'
            ]);
        }
        return redirect()->route('settings-counsellor-assessment_ques_list');
    }

    public function Delete($id)
    {
        $upd_SelfAssementModel =  SelfAssessmentModel::where('sno', $id)->first();
        $upd_SelfAssementModel->status  = 2;
        $upd_SelfAssementModel->Update();
        if ($upd_SelfAssementModel) {
            return response([
                'status'    => 200,
                'message'   => ' Self Assessment Questions Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Self Assessment Questions!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Status($id, Request $request)
    {


        $upd_SelfAssementModel =  SelfAssessmentModel::where('sno', $id)->first();
        $upd_SelfAssementModel->status = $request->input('status', 0);
        $upd_SelfAssementModel->update();
        if ($upd_SelfAssementModel) {
            return response([
                'status'    => 200,
                'message'   => 'Self Assessment Questions Successfully Updated!',
                'error_msg' => 'Could not ,update  Self Assessment Questions!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Self Assessment Questions!',
                'error_msg' => 'Could not ,update  Self Assessment Questions!',
                'data'      => null,
            ], 200);
        }
    }
}