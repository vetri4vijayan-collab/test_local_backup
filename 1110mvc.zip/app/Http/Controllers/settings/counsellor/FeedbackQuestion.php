<?php

namespace App\Http\Controllers\settings\counsellor;

use App\Http\Controllers\Controller;
use App\Models\FeedbackQuestionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FeedbackQuestion extends Controller
{
    public function Index()
    {

        $feed_question = FeedbackQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // $pageConfigs = ['myLayout' => 'default'];
        // dd($feed_question);
        return view('content.settings.counsellor.feedback_question.feedback_quest_list', [
            'feed_question' => $feed_question
        ]);
        // return view('content.settings.counsellor.feedback_question.feedback_quest_list');
    }
    public function feedback_question_add()
    {
        return view('content.settings.counsellor.feedback_question.feedback_quest_add');
    }

    public function Add(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255', // '*' indicates an array of questions
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            // 'category_type.*' => 'required|integer', // Validate feedback_id
            // Add validation rules for option fields if needed
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check your inputs.'
            ]);
            return redirect()->back()->withInput();
        }

        $user_id = $request->user()->user_id;

        foreach ($request->input('question') as $key => $category_question_name) {
            $category_question_type = $request->input('question_type.' . $key);
            // $feedback_id = $request->input('category_type.' . $key); // Get feedback_id from request 

            // Initialize options array
            $category_question_option = [];

            switch ($category_question_type) {
                case 'checkbox':
                case 'radio_button':
                case 'list_box':
                    // Get options for the current question
                    $options_key = 'option_value_' . $category_question_type . '_' . $key;

                    $options = $request->input($options_key, []);

                    $options_array = [];
                    foreach ($options as $option_key => $value) {
                        if ($value !== '') {
                            $options_array[] = [
                                'value' => $value,
                            ];
                        }
                    }

                    $category_question_option = json_encode($options_array); // Convert options to JSON
                    break;
                case 'text_field':
                    // No options needed for text_field questions
                    $category_question_option = null;
                    break;
                default:
                    break;
            }

            // Check if the question already exists
            $chk = FeedbackQuestionModel::where('feedback_question_name', ucwords($category_question_name))
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been already created!'
                ]);
                continue;
            }

            // Add new category question
            $add_category = new FeedbackQuestionModel();
            $add_category->feedback_question_name = ucfirst($category_question_name);
            // $add_category->feedback_id = $feedback_id;
            $add_category->feedback_question_type = $category_question_type;
            $add_category->feedback_question_option = $category_question_option;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
            $add_category->save();

            // Flash success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Self Feedback Question added Successfully!'
            ]);
        }

        return redirect()->route('settings-counsellor-feedback_question_list');
        // return redirect('settings-counsellor-feedback_quest_list');
    }

    public function FeedBack_edit($id)
    {

        // return $id;
        // Decrypt the ID
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;
        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $feedback_question = FeedbackQuestionModel::where('status', '!=', 2)
            ->where('sno', $decryptedValue)
            // ->orderBy('sno', 'desc')
            ->first();

        return view('content.settings.counsellor.feedback_question.feedback_quest_edit', [
            'feedback_question' => $feedback_question
        ]);
    }

    public function Update(Request $request)
    {
        // return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255', // '*' indicates an array of questions
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            // 'category_type.*' => 'required|integer', // Validate feedback_id
            // Add validation rules for option fields if needed
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Validation failed! Please check your inputs.'
            ]);
            return redirect()->back()->withInput();
        } else {

            $user_id = $request->user()->user_id;
            $feedback_ques_name = $request->feedback_ques_name;
            $question_cat       = $request->question_cat;
            $top_name       = $request->top_name;
            $sno    = $request->sno_edit;

            $upd_CourseCategoryModel =  FeedbackQuestionModel::find($sno);
            $upd_CourseCategoryModel->feedback_question_name  = $feedback_ques_name;
            $upd_CourseCategoryModel->feedback_question_type  = $question_cat;

            $options_array = [];
            foreach ($top_name as $option_key => $value) {
                if ($value !== '') {
                    $options_array[] = [
                        'value' => $value,
                    ];
                }
            }
            $upd_CourseCategoryModel->feedback_question_option  = json_encode($options_array);
            $upd_CourseCategoryModel->created_by = $user_id;
            $upd_CourseCategoryModel->updated_by = $user_id;
            $upd_CourseCategoryModel->update();

            // Flash success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Counsellor Feedback Questions Update Successfully!'
            ]);
        }





        return redirect()->route('settings-counsellor-feedback_question_list');
        // return redirect('settings-counsellor-feedback_quest_list');
    }


    // Status change 
    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  FeedbackQuestionModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Counsellor Feedback Question Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Counsellor Feedback Question Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update  Counsellor Feedback Question Status!',
                'error_msg' => 'Could not ,update   Counsellor Feedback Question Status!',
                'data'      => null,
            ], 200);
        }
    }


    public function Delete($id)
    {

        $upd_CourseTypeModel =  FeedbackQuestionModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => ' Counsellor Feedback Question Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Counsellor Feedback Question!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
