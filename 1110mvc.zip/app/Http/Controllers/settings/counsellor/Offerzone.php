<?php

namespace App\Http\Controllers\settings\counsellor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OfferzoneModel;
use Faker\Provider\Image;
use Illuminate\Support\Facades\Validator;


class Offerzone extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    $offerzone = OfferzoneModel::select('za_course_category.*', 'za_course.course_name', 'za_course_type.*', 'za_course_subcategory.*', 'za_course_type.sno as course_type_id', 'za_course_category.sno as course_category_id', 'za_course_subcategory.sno as course_subcategory_id', 'za_offerzone.*')
      ->leftJoin('za_course_category', 'za_offerzone.course_category', '=', 'za_course_category.sno')
      ->leftJoin('za_course_subcategory', 'za_offerzone.course_sub_category', '=', 'za_course_subcategory.sno')
      ->leftJoin('za_course_type', 'za_offerzone.course_type', '=', 'za_course_type.sno')
      ->leftJoin('za_course', 'za_offerzone.offered_courses', '=', 'za_course.sno')
      ->where('za_offerzone.status', '!=', 2)
      ->where('za_offerzone.branch_id', self::$branch_id)
      ->orderBy('za_offerzone.sno', 'desc')->get();

    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.counsellor.offerzone.offerzone_list', [
      'offerzone' => $offerzone,
      'pageConfigs' => $pageConfigs
    ]);
  }

  public function List()
  {
    $startTime = microtime(true);
    $offerzone = OfferzoneModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $offerzone,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }



  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'offerzone_category' => 'required|max:255',
    ]);
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input feilds!'
      ]);
    } else {

      $offerzone_category     = $request->offerzone_category;
      $offer_name_cmn   = $request->offer_name_cmn;
      $offer_name   = $request->offer_name;
      $coupon_code_cmn         = $request->coupon_code_cmn;
      $coupon_code         = $request->coupon_code;
      $starting_date_cmn       = $request->starting_date_cmn;
      $starting_date       = $request->starting_date;
      $end_date_cmn       = $request->end_date_cmn;
      $end_date       = $request->end_date;
      $offer_type_cmn       = $request->offer_type_cmn;
      $offer_type       = $request->offer_type;
      $offer_amount_cmn = $request->offer_amount_cmn;
      $offer_amount = $request->offer_amount;
      $offer_percent_cmn = $request->offer_percent_cmn;
      $offer_percent = $request->offer_percent;
      $offerzone_description_cmn       = $request->offerzone_description_cmn;
      $offerzone_description       = $request->offerzone_description;
      $display_on_dashboard_cmn       = $request->display_on_dashboard_cmn ? "on" : "off";
      $display_on_dashboard       = $request->display_on_dashboard ? "on" : "off";
      $related_course_name       = $request->related_course_name ? json_encode($request->related_course_name) : null;
      $course_category       = $request->course_category;
      $course_sub_category       = $request->course_sub_category;
      $course_type       = $request->course_type;
      $offered_courses       = $request->offered_courses;

      // dd($request);



      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;

      $category_check = OfferzoneModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$category_check) {

        $year = substr(date('y'), -2);
        $offerzone_id = 'CT-0001/' . $year;
      } else {

        $data = $category_check->offerzone_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request_id = sprintf('CT-%04d', $next_number);

        $year = substr(date('y'), -2);
        $offerzone_id = $request_id . '/' . $year;
      }



      if ($offerzone_category == "Common Offer") {

        if ($request->hasFile('coupon_image_cmn')) {
          $imageName = idate('B') . rand(1, 50) . '.' . $request->file('coupon_image_cmn')->extension();
          $destinationPath = public_path('coupon_images');
          // Path to the logos directory
          $request->file('coupon_image_cmn')->move($destinationPath, $imageName);
          $logo = $imageName;
        } else {
          $logo = '';
        }

        $add_category = new OfferzoneModel();
        $add_category->offerzone_id           = $offerzone_id;
        $add_category->offerzone_category         = $offerzone_category;
        $add_category->offer_name         = $offer_name_cmn;
        $add_category->coupon_code         = $coupon_code_cmn;
        $add_category->starting_date         = $starting_date_cmn;
        $add_category->end_date         = $end_date_cmn;
        $add_category->offer_type         = $offer_type_cmn;
        $add_category->offer_amount         = $offer_amount_cmn;
        $add_category->offer_percent         = $offer_percent_cmn;
        $add_category->coupon_image         = $logo;
        $add_category->offerzone_description   = $offerzone_description_cmn;
        $add_category->display_on_dashboard   = $display_on_dashboard_cmn;

        $add_category->branch_id = self::$branch_id;

        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;
        $add_category->save();
      } else {
        if ($request->hasFile('coupon_image')) {
          $imageName = idate('B') . rand(1, 50) . '.' . $request->file('coupon_image')->extension();
          $destinationPath = public_path('coupon_images');
          // Path to the logos directory
          $request->file('coupon_image')->move($destinationPath, $imageName);
          $logo = $imageName;
        } else {
          $logo = '';
        }

        $add_category = new OfferzoneModel();
        $add_category->offerzone_id           = $offerzone_id;
        $add_category->offerzone_category         = $offerzone_category;
        $add_category->offer_name         = $offer_name;
        $add_category->coupon_code         = $coupon_code;
        $add_category->starting_date         = $starting_date;
        $add_category->end_date         = $end_date;
        $add_category->offer_type         = $offer_type;
        $add_category->offer_amount         = $offer_amount;
        $add_category->offer_percent         = $offer_percent;
        $add_category->related_course_name  = $related_course_name;
        $add_category->coupon_image         = $logo;
        $add_category->offerzone_description   = $offerzone_description;
        $add_category->display_on_dashboard   = $display_on_dashboard;
        $add_category->course_category   = $course_category;
        $add_category->course_sub_category   = $course_sub_category;
        $add_category->course_type   = $course_type;
        $add_category->offered_courses   = $offered_courses;
        $add_category->branch_id = self::$branch_id;


        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;
        $add_category->save();
      }


      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Offerzone  added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Offerzone !'
        ]);
      }

      // return $result;
      return redirect()->back();
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'offerzone_category' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input feilds!'
      ]);
    } else {
      $offer_id = $request->sno;
      $offerzone_category     = $request->offerzone_category;
      $offer_name_cmn   = $request->offer_name_cmn;
      $offer_name   = $request->offer_name;
      $coupon_code_cmn         = $request->coupon_code_cmn;
      $coupon_code         = $request->coupon_code;
      $starting_date_cmn       = $request->starting_date_cmn;
      $starting_date       = $request->starting_date;
      $end_date_cmn       = $request->end_date_cmn;
      $end_date       = $request->end_date;
      $offer_type_cmn       = $request->offer_type_cmn;
      $offer_type       = $request->offer_type;
      $offer_amount_cmn = $request->offer_amount_cmn;
      $offer_amount = $request->offer_amount;
      $offer_percent_cmn = $request->offer_percent_cmn;
      $offer_percent = $request->offer_percent;
      $offerzone_description_cmn       = $request->offerzone_description_cmn;
      $offerzone_description       = $request->offerzone_description;
      $display_on_dashboard_cmn       = $request->display_on_dashboard_cmn;
      $display_on_dashboard       = $request->display_on_dashboard;
      $related_course_name       = $request->related_course_name ? json_encode($request->related_course_name) : null;
      $course_category       = $request->course_category;
      $course_sub_category       = $request->course_sub_category;
      $course_type       = $request->course_type;
      $offered_courses       = $request->offered_courses;
      $old_coupon_img_cmn       = $request->old_coupon_img_cmn;
      $old_coupon_img       = $request->old_coupon_img;





      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;



      $upd_offerzone = OfferzoneModel::find($offer_id);

      if (!$upd_offerzone) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'offerzone  not found!'
        ]);
        return redirect()->back();
      }


      if ($offerzone_category == "Common Offer") {

        if ($request->hasFile('coupon_image_cmn')) {
          $imageName = idate('B') . rand(1, 50) . '.' . $request->file('coupon_image_cmn')->extension();
          $destinationPath = public_path('coupon_images');
          // Path to the logos directory
          $request->file('coupon_image_cmn')->move($destinationPath, $imageName);
          $logo = $imageName;
        } else {
          $logo = $request->old_coupon_img_cmn;
        }
        if ($display_on_dashboard_cmn == null) {
          $displayStatus = "off";
        } else {
          $displayStatus = "on";
        }

        $update_category = OfferzoneModel::where('sno', $offer_id)->first();;
        $update_category->offerzone_category         = $offerzone_category;
        $update_category->offer_name         = $offer_name_cmn;
        $update_category->coupon_code         = $coupon_code_cmn;
        $update_category->starting_date         = $starting_date_cmn;
        $update_category->end_date         = $end_date_cmn;
        $update_category->offer_type         = $offer_type_cmn;
        $update_category->offer_amount         = $offer_amount_cmn;
        $update_category->offer_percent         = $offer_percent_cmn;
        $update_category->coupon_image         = $logo;
        $update_category->offerzone_description   = $offerzone_description_cmn;
        $update_category->display_on_dashboard   = $displayStatus;

        $update_category->branch_id = self::$branch_id;


        $update_category->updated_by                 = $user_id;
        $update_category->update();
      } else {
        if ($request->hasFile('coupon_image')) {
          $imageName = idate('B') . rand(1, 50) . '.' . $request->file('coupon_image')->extension();
          $destinationPath = public_path('coupon_images');
          // Path to the logos directory
          $request->file('coupon_image')->move($destinationPath, $imageName);
          $logo = $imageName;
        } else {
          $logo = $request->old_coupon_img;
        }

        if ($display_on_dashboard == null) {
          $displayStatus = "off";
        } else {
          $displayStatus = "on";
        }

        $update_category = OfferzoneModel::where('sno', $offer_id)->first();;
        $update_category->offerzone_category         = $offerzone_category;
        $update_category->offer_name         = $offer_name;
        $update_category->coupon_code         = $coupon_code;
        $update_category->starting_date         = $starting_date;
        $update_category->end_date         = $end_date;
        $update_category->offer_type         = $offer_type;
        $update_category->offer_amount         = $offer_amount;
        $update_category->offer_percent         = $offer_percent;
        $update_category->related_course_name  = $related_course_name;
        $update_category->coupon_image         = $logo;
        $update_category->offerzone_description   = $offerzone_description;
        $update_category->display_on_dashboard   = $displayStatus;
        $update_category->course_category   = $course_category;
        $update_category->course_sub_category   = $course_sub_category;
        $update_category->course_type   = $course_type;
        $update_category->offered_courses   = $offered_courses;
        $update_category->branch_id = self::$branch_id;



        $update_category->updated_by                 = $user_id;
        $update_category->update();
      }


      if ($update_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Offerzone upadted Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Offerzone !'
        ]);
      }

      // return $result;
      return redirect()->back();
    }
  }




  public function Delete($id)
  {
    $upd_CourseCategoryModel = OfferzoneModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel = OfferzoneModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
