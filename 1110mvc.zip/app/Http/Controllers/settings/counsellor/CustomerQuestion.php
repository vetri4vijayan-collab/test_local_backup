<?php

namespace App\Http\Controllers\settings\counsellor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadQuestionModel;
use Illuminate\Support\Facades\Validator;

class CustomerQuestion extends Controller
{
    public function Index()
    {

        $quest = LeadQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // dd($quest);
        return view('content.settings.sales.lead_question.lead_question_list', compact('quest', 'pageConfigs'));

        // return view('content.settings.sales.lead_question.lead_question_list');
    }
    public function LeadQuestionAdd()
    {
        return view('content.settings.sales.lead_question.lead_question_add');
    }
    public function LeadQuestionEdit()
    {
        return view('content.settings.sales.lead_question.lead_question_edit');
    }

    // public function lead_question_list()
    // {
    //   return view('content.settings.sales.lead_question.lead_question_list');
    // }

    // public function Add(Request $request)
    // {

    //   $validator = Validator::make($request->all(), [
    //     'lead_question_name' => 'required|max:255'
    //   ]);
    //   if ($validator->fails()) {
    //     session()->flash('toastr', [
    //       'type' => 'error',
    //       'message' => 'Lead Question Name is required!'
    //     ]);
    //   } else {




    //     // $lead_question_name       = $request->question;
    //     // $lead_question_type       = $request->question_type;
    //     // $lead_question_option     = json_encode($request->option_value_checkbox);
    //     $lead_question_name = $request->question[0];
    //     $lead_question_type = $request->question_type[0];

    //     // Handle different types of questions and their options and scores
    //     $lead_question_option = [];
    //     switch ($lead_question_type) {
    //       case 'text_field':
    //         // Handle text field type
    //         $lead_question_option = [
    //           'value' => $request->option_value_text_field[0],
    //           'score' => $request->option_score_text_field[0]
    //         ];
    //         break;
    //       case 'checkbox':
    //         // Handle checkbox type
    //         $lead_question_option = [
    //           'value' => $request->option_value_checkbox[0],
    //           'score' => $request->option_score_checkbox[0]
    //         ];
    //         break;
    //         // Add cases for other question types as needed
    //       default:
    //         break;
    //     }

    //     // Convert option to JSON
    //     $lead_question_option = json_encode($lead_question_option);
    //     $user_id                    = 1;
    //     $chk = LeadQuestionModel::where('lead_question_name', ucwords($lead_question_name))->where('status', '!=', 2)->first();

    //     if ($chk) {

    //       session()->flash('toastr', [
    //         'type' => 'error',
    //         'message' => 'Name has been  already created!'
    //       ]);
    //     } else {

    //       $add_category = new LeadQuestionModel();
    //       $add_category->lead_question_name       = Ucfirst($lead_question_name);
    //       $add_category->lead_question_type       = $lead_question_type;
    //       $add_category->lead_question_option       = $lead_question_option;
    //       $add_category->created_by           = $user_id;
    //       $add_category->updated_by           = $user_id;

    //       $add_category->save();
    //     }
    //     return redirect()->back();
    //     // return redirect('content.settings.sales.lead_question.lead_question_list')->back()->with('success', 'Lead Type Created successfully!');
    //   }
    // }

    public function List()
    {
        $leadquestion = LeadQuestionModel::where('status', 0)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $leadquestion
        ], 200);
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question.*' => 'required|max:255', // '*' indicates an array of questions
            'question_type.*' => 'required|in:checkbox,radio_button,list_box,text_field',
            // Add validation rules for option fields if needed
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Lead Question Name is required!'
            ]);
            return redirect()->back();
        }

        $user_id = 1; // You should set this to the currently authenticated user ID

        foreach ($request->input('question') as $key => $lead_question_name) {
            $lead_question_type = $request->input('question_type.' . $key);
            // return $lead_question_type;
            // Initialize options array
            $lead_question_option = [];

            switch ($lead_question_type) {
                case 'checkbox':
                case 'radio_button':
                case 'list_box':
                    // Get options and scores for the current question
                    $options_key = 'option_value_' . $lead_question_type . '_' . $key;
                    $scores_key = 'option_score_' . $lead_question_type . '_' . $key;

                    $options = $request->input($options_key, []);
                    $scores = $request->input($scores_key, []);

                    $options_array = [];
                    foreach ($options as $option_key => $value) {
                        if ($value !== '') {
                            $options_array[] = [
                                'value' => $value,
                                'score' => $scores[$option_key] ?? null,
                            ];
                        }
                    }

                    $lead_question_option = json_encode($options_array); // Convert options to JSON
                    break;
                case 'text_field':
                    // No options needed for text_field questions
                    $lead_question_option = null;
                    break;
                default:
                    break;
            }

            $chk = LeadQuestionModel::where('lead_question_name', ucwords($lead_question_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been already created!'
                ]);
                continue; // Skip processing this question and move to the next one
            }

            $add_category = new LeadQuestionModel();
            $add_category->lead_question_name = ucfirst($lead_question_name);
            $add_category->lead_question_type = $lead_question_type;
            $add_category->lead_question_option = $lead_question_option;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;
            // return $add_category;
            $add_category->save();

            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Lead Question added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Lead Question!'
                ]);
            }
        }

        return redirect()->route('settings-sales-lead_question_list');
    }


    public function Edit($id)
    {
        $editcategory = LeadQuestionModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_type.lead_type_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_type_name       = $request->lead_type_name;
            $lead_type_desc       = $request->lead_type_desc;
            $lead_type_id         = $request->lead_type_id;

            $upd_CourseCategoryModel =  LeadQuestionModel::where('sno', $lead_type_id)->first();

            $chk = LeadQuestionModel::where('lead_type_name', ucwords($lead_type_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_type_id) {
                    $result = response([
                        'status'    => 401,
                        'message'   => 'Error',
                        'error_msg' => 'Name has been  already assigned!',
                        'data'      => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->lead_type_name  = Ucfirst($lead_type_name);
            $upd_CourseCategoryModel->lead_type_desc  = $lead_type_desc;
            $upd_CourseCategoryModel->update();
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadQuestionModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadQuestionModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}