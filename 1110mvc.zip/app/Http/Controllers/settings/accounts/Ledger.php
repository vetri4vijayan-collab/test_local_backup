<?php

namespace App\Http\Controllers\settings\accounts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LedgerModel;
use Illuminate\Support\Facades\Validator;

class Ledger extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {

        $LedgerCategory = LedgerModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.accounts.ledger', [
            'LedgerCategory' => $LedgerCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $LedgerCategory = LedgerModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $LedgerCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'ledger_name' => 'required|max:255',
            'trans_type' => 'required'
        ]);

        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $ledger_name       = $request->ledger_name;
            $trans_type       = $request->trans_type ?? 1;
            $ledger_desc          = $request->ledger_desc;
            $user_id                    = $request->user()->user_id;
            $chk = LedgerModel::where('ledger_name', ucwords($ledger_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Ledger is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = LedgerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $ledger_id = 'LD-0001/' . $year;
                } else {

                    $data = $category_check->ledger_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('LD-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $ledger_id = $request . '/' . $year;
                }

                $add_ledger = new LedgerModel();
                $add_ledger->ledger_id         = $ledger_id;
                $add_ledger->ledger_name       = Ucfirst($ledger_name);
                $add_ledger->transection_type  = $trans_type;
                $add_ledger->ledger_desc       = $ledger_desc;
                $add_ledger->branch_id         = self::$branch_id;
                $add_ledger->created_by        = $user_id;
                $add_ledger->updated_by        = $user_id;

                $add_ledger->save();

                if ($add_ledger) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Ledger added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Ledger!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = LedgerModel::where('sno', $id)->first();

        return view('content.settings.accounts.ledger', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'ledger_name' => 'required|max:255',
            'edit_trans_type' => 'required'
        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $ledger_name       = $request->ledger_name;
            $trans_type       = $request->edit_trans_type ?? 1;
            $ledger_desc       = $request->ledger_desc;
            $ledger_id       = $request->ledger_id;

            $upd_LedgerCategoryModel =  LedgerModel::where('sno', $ledger_id)->first();

            $chk = LedgerModel::where('ledger_name', ucwords($ledger_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $ledger_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Ledger is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_LedgerCategoryModel->ledger_name  = Ucfirst($ledger_name);
                $upd_LedgerCategoryModel->transection_type  = $trans_type;
                $upd_LedgerCategoryModel->ledger_desc  = $ledger_desc;
                $upd_LedgerCategoryModel->update();

                if ($upd_LedgerCategoryModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Ledger Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Ledger!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_LedgerCategoryModel = LedgerModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status  = 2;
        $upd_LedgerCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_LedgerCategoryModel =  LedgerModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status = $request->input('status', 0);
        $upd_LedgerCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}