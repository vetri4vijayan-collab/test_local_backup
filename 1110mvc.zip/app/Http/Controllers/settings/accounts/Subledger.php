<?php

namespace App\Http\Controllers\settings\accounts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\SubLedgerModel;

class Subledger extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $Subledgers = SubLedgerModel::select('za_subledger.*', 'za_ledger.ledger_name', 'za_ledger.sno as ledger_id')
            ->join('za_ledger', 'za_subledger.ledger_id', '=', 'za_ledger.sno')
            ->where('za_subledger.status', '!=', 2)
            ->where('za_subledger.branch_id', self::$branch_id)
            ->orderBy('za_subledger.sno', 'desc')->get();

        $selectedledgerId = $Subledgers->isEmpty() ? null : $Subledgers[0]->ledger_id;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.accounts.subledger', [
            'Subledgers' => $Subledgers,
            'selectedledgerId' => $selectedledgerId,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'subledger_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $subledger_name = $request->subledger_name;
            $subledger_desc = $request->subledger_desc;
            $ledger_id = $request->ledger_id;
            $user_id = $request->user()->user_id;
            $chk = SubLedgerModel::where('subledger_name', ucwords($subledger_name))->where('branch_id', self::$branch_id)->where('ledger_id', $ledger_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already SubLedger is exist!'
                ]);
                return redirect()->back();
            } else {
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {

                    $year = substr(date('y'), -2);
                    $subledger_id = 'SL-0001/' . $year;
                } else {

                    $data = $ledger_check->subledger_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('SL-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $subledger_id = $request . '/' . $year;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = $ledger_id;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = Ucfirst($subledger_name);
                $add_subledger->subledger_desc = $subledger_desc;
                $add_subledger->branch_id      = self::$branch_id;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();

                if ($add_subledger) {

                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'SubLedger added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the SubLedger!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function edit($id)
    {
        $editledger = SubLedgerModel::select(
            'za_subledger.*',
            'za_ledger.ledger_name',
            'za_ledger.sno as ledger_id'
        )
            ->join('za_ledger', 'za_subledger.ledger_id', '=', 'za_ledger.sno')
            ->where('za_subledger.sno', $id)
            ->first();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $editledger
        ], 200);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'subledger_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $ledger_id = $request->ledger_id_edit;
            $subledger_name = $request->subledger_name;
            $subledger_desc = $request->subledger_desc;
            $subledger_id = $request->subledger_id;

            $upd_SubLedgerModel = SubLedgerModel::where('sno', $subledger_id)->first();

            $chk = SubLedgerModel::where('subledger_name', ucwords($subledger_name))->where('branch_id', self::$branch_id)->where('ledger_id', $ledger_id)->where('sno', '!=', $subledger_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already SubLedger is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_SubLedgerModel->ledger_id = $ledger_id;
                $upd_SubLedgerModel->subledger_name = Ucfirst($subledger_name);
                $upd_SubLedgerModel->subledger_desc = $subledger_desc;
                $upd_SubLedgerModel->update();
                if ($upd_SubLedgerModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'SubLedger Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the SubLedger!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_SubLedgerModel = SubLedgerModel::where('sno', $id)->first();
        $upd_SubLedgerModel->status = 2;
        $upd_SubLedgerModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_SubLedgerModel = SubLedgerModel::where('sno', $id)->first();
        $upd_SubLedgerModel->status = $request->input('status', 0);
        $upd_SubLedgerModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}