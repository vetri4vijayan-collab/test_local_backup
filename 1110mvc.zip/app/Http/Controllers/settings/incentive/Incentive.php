<?php

namespace App\Http\Controllers\settings\incentive;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\UserRoleModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use App\Models\IncentiveModel;
use App\Models\IncentiveCriteriaModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class Incentive extends Controller
{


  public function index()
  {

    return view('content.settings.incentive.incentive');
  }
  // Fetch role based on Branch
  public function getroleIncentive(Request $request)
  {

    $departments = UserRoleModel::where('status', 0)->get(['sno', 'role_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
  }

  public function getroleIncentivedata(Request $request)
  {
    $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

    $incentivedata = IncentiveModel::where('role_id', $request->role_id)
      ->whereDate('incentive_month', $incentiveMonthDate->format('Y-m-d'))
      ->where('branch_id', $request->branch_id)
      ->where('status', 0)
      ->first();
    // $incentivedata->previousMonth=0;
    if (!$incentivedata) {
      $incentivedata = IncentiveModel::where('role_id', $request->role_id)
        ->where('branch_id', $request->branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
      $incentivedata->previousMonth = 1;
    }

    return response()->json(['status' => 200, 'data' => $incentivedata]);
  }
  public function Incentivecreateupdate(Request $request)
  {
    try {
      // Convert to proper date
      $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

      // Validate input
      $validatedData = $request->validate([
        'branch_id' => 'required|integer',
        'role_id' => 'required|integer',
        'tenx_award' => 'nullable|integer',
        'target_day' => 'nullable|integer',
        'tenx_warrior' => 'nullable|integer',
        'eci_count' => 'nullable|integer',
        'eci_reward' => 'nullable|integer',
        'bi_amount' => 'nullable|integer',
        'si_crash_course' => 'nullable|integer',
        'si_profession_course' => 'nullable|integer',
        'si_tesbo_course' => 'nullable|integer',
        'si_reward' => 'nullable|integer',
        'pi_percentage' => 'nullable|integer',
        'spot_incentive_month' => 'nullable|integer',
        'spot_incentive_day' => 'nullable|integer',
        'luxury_incentive' => 'nullable',
        'pi_slab_json' => 'nullable',
        'pdi_slab_json' => 'nullable',
        'reference_incentive' => 'nullable',
        'excess_incentive' => 'nullable',
        'team_Individual' => 'nullable',


        // bh role
        'ceiling' => 'nullable',
        'quarterly' => 'nullable',
        'twenty_five_percentage' => 'nullable',
        'fifty_percentage' => 'nullable',
        'six_month' => 'nullable',
        'twelve_month' => 'nullable',
        'nine_monthadd' => 'nullable',
        'twelve_monthadd' => 'nullable',
        'overall_year' => 'nullable',
        'dynamic' => 'nullable',
        'presale' => 'nullable',
        'megabonus' => 'nullable',

        // placement
        'oil_slab_json' => 'nullable',
        'double_x_slab_json' => 'nullable',
        'pil_slab_json' => 'nullable',
        'oie_slab_json' => 'nullable',
        'pie_slab_json' => 'nullable',

        // bdm
        'acv_abv' => 'nullable',
        'closing_percentage' => 'nullable',
        'closing_slab_json' => 'nullable',
        'add_incentive' => 'nullable',
        'double_x_bdm' => 'nullable',
        'abv_percentage' => 'nullable',
        'team_target' => 'nullable',
        'abv' => 'nullable',
        'any_nine_month' => 'nullable',
        'yearly_count' => 'nullable',
        'luxury_reward_bdm' => 'nullable',


      ]);

      // return $validatedData;

      // Add date
      $validatedData['incentive_month'] = $incentiveMonthDate->format('Y-m-d');

      // Check by branch, role, and month
      $incentive = IncentiveModel::where('branch_id', $validatedData['branch_id'])
        ->where('role_id', $validatedData['role_id'])
        ->whereDate('incentive_month', $validatedData['incentive_month'])
        ->first();

      if ($incentive) {
        $validatedData['updated_by'] = auth()->id();
        $incentive->update($validatedData);
      } else {
        $validatedData['created_by'] = auth()->id();
        $validatedData['updated_by'] = auth()->id();
        IncentiveModel::create($validatedData);
      }

      return response()->json(['status' => 200, 'message' => 'Incentive saved successfully.']);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Something went wrong.',
        'error' => $e->getMessage()
      ]);
    }
  }



//   public function checkIncentive(Request $request)
//   {
//     $user = Auth::user(); // logged-in user

//     $today = Carbon::now();

//     $exists = IncentiveModel::where('branch_id', 6) //$user->branch_id
//       ->where('role_id', $user->role_id)
//       ->whereNot('role_id', 18)
//       ->whereYear('incentive_month', $today->year)
//       ->whereMonth('incentive_month', $today->month)
//       ->exists();

//     return response()->json([
//       'isIncentive' => $exists
//     ]);
//   }

    public function checkIncentive(Request $request)
    {
        $user = Auth::user(); // logged-in user
        $today = Carbon::now();
     
        $exists = IncentiveModel::where('za_incentive.branch_id', $user->branch_id)
            ->join('za_branch', 'za_incentive.branch_id', '=', 'za_branch.sno')
            ->where('za_branch.branch_type', 1)  // Only branch type 1
            ->where('za_incentive.role_id', $user->role_id)
            ->where('za_incentive.role_id', '!=', 18)  // Exclude role_id 18
            ->whereYear('za_incentive.incentive_month', $today->year)
            ->whereMonth('za_incentive.incentive_month', $today->month)
            ->exists();
     
        return response()->json([
            'isIncentive' => $exists
        ]);
    }

  public function getCriteria(Request $request)
  {
    $request->validate([
      'incentive_key' => 'required|string',
      'role_id' => 'required|integer',
      'branch_id' => 'required|integer',
      'month' => 'required|string',
      'year' => 'required|string',
    ]);

    $criteria = IncentiveCriteriaModel::where([
      'incentive_key' => $request->incentive_key,
      'role_id' => $request->role_id,
      'branch_id' => $request->branch_id,
    ])->first();

    if ($criteria) {
      return response()->json([
        'status' => 200,
        'data' => $criteria
      ]);
    }

    return response()->json([
      'status' => 404,
      'message' => 'No criteria found'
    ]);
  }

  public function saveCriteria(Request $request)
  {
    $request->validate([
      'incentive_key' => 'required|string',
      'role_id' => 'required|integer',
      'branch_id' => 'required|integer',
      'month' => 'required|string',
      'year' => 'required|string',
      'criteria_points' => 'required|json',
    ]);

    try {
      $criteria = IncentiveCriteriaModel::updateOrCreate(
        [
          'incentive_key' => $request->incentive_key,
          'role_id' => $request->role_id,
          'branch_id' => $request->branch_id,
        ],
        [
          'criteria_points' => $request->criteria_points,
        ]
      );

      return response()->json([
        'status' => 200,
        'message' => 'Criteria saved successfully',
        'data' => $criteria
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Failed to save criteria: ' . $e->getMessage()
      ], 500);
    }
  }
}

// ALTER TABLE `za_incentive` ADD `oil_slab_json` JSON NULL DEFAULT NULL AFTER `megabonus`, ADD `double_x_slab_json` JSON NULL DEFAULT NULL AFTER `oil_slab_json`, ADD `pil_slab_json` JSON NULL DEFAULT NULL AFTER `double_x_slab_json`, ADD `oie_slab_json` JSON NULL DEFAULT NULL AFTER `pil_slab_json`, ADD `pie_slab_json` JSON NULL DEFAULT NULL AFTER `oie_slab_json`;
// ALTER TABLE `za_incentive` ADD `acv_abv` BIGINT NULL DEFAULT NULL AFTER `pie_slab_json`, ADD `check_closing` BIGINT NULL DEFAULT NULL AFTER `acv_abv`, ADD `add_incentive` BIGINT NULL DEFAULT NULL AFTER `check_closing`, ADD `double_x_bdm` BIGINT NULL DEFAULT NULL AFTER `add_incentive`, ADD `abv_percentage` BIGINT NULL DEFAULT NULL AFTER `double_x_bdm`, ADD `luxury_reward_bdm` BIGINT NULL DEFAULT NULL AFTER `abv_percentage`;
// ALTER TABLE `za_incentive` CHANGE `luxury_reward_bdm` `luxury_reward_bdm` JSON NULL DEFAULT NULL;
// ALTER TABLE `za_incentive` CHANGE `check_closing` `closing_slab_json` JSON NULL DEFAULT NULL;

// ALTER TABLE `za_incentive` ADD `si_reward` BIGINT NOT NULL DEFAULT '0' AFTER `si_tesbo_course`;

// ALTER TABLE `za_incentive` ADD `closing_percentage` BIGINT NOT NULL DEFAULT '0' AFTER `acv_abv`;

// ALTER TABLE `za_incentive` ADD `team_target` BIGINT NULL DEFAULT NULL AFTER `abv_percentage`, ADD `abv` BIGINT NULL DEFAULT NULL AFTER `team_target`, ADD `any_nine_month` TINYTEXT NULL DEFAULT NULL AFTER `abv`, ADD `yearly_count` BIGINT NULL DEFAULT NULL AFTER `any_nine_month`;


// ALTER TABLE `za_incentive` ADD `target_day` INT NULL DEFAULT NULL AFTER `incentive_month`;
