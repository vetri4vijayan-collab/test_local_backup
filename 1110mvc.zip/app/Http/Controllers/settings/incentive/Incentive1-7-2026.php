<?php

namespace App\Http\Controllers\settings\incentive;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\UserRoleModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use App\Models\IncentiveModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class Incentive extends Controller
{


  public function index()
  {

    return view('content.settings.incentive.incentive');

  }
   // Fetch role based on Branch
   public function getroleIncentive(Request $request)
   {

    $departments = UserRoleModel::where('status', 0)->get(['sno', 'role_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
   }

   public function getroleIncentivedata(Request $request)
    {
        $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();
    
        $incentivedata = IncentiveModel::where('role_id', $request->role_id)
            ->whereDate('incentive_month', $incentiveMonthDate->format('Y-m-d'))
            ->where('branch_id', $request->branch_id)
            ->where('status', 0)
            ->first();
            // $incentivedata->previousMonth=0;
           if(!$incentivedata){
            $incentivedata = IncentiveModel::where('role_id', $request->role_id)
            ->where('branch_id', $request->branch_id)
            ->where('status', 0)
            ->orderBy('sno','desc')
            ->first();
            $incentivedata->previousMonth=1;
        }
    
        return response()->json(['status' => 200, 'data' => $incentivedata]);
    }
    
//  public function Incentivecreateupdate(Request $request)
//   {
//     try {
//       // Convert to proper date
//       $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

//       // Validate input
//       $validatedData = $request->validate([
//         'branch_id' => 'required|integer',
//         'role_id' => 'required|integer',
//         'tenx_award' => 'nullable|integer',
//         'tenx_warrior' => 'nullable|integer',
//         'eci_count' => 'nullable|integer',
//         'eci_reward' => 'nullable|integer',
//         'bi_amount' => 'nullable|integer',
//         'si_crash_course' => 'nullable|integer',
//         'si_profession_course' => 'nullable|integer',
//         'si_tesbo_course' => 'nullable|integer',
//         'pi_percentage' => 'nullable|integer',
//         'spot_incentive_month' => 'nullable|integer',
//         'spot_incentive_day' => 'nullable|integer',
//         'luxury_incentive' => 'nullable',
//         'pi_slab_json' => 'nullable',
//         'pdi_slab_json' => 'nullable',
//         'reference_incentive' => 'nullable',
//         'excess_incentive' => 'nullable',
//         'team_Individual' => 'nullable',


//         // bh role
//         'ceiling' => 'nullable',
//         'quarterly' => 'nullable',
//         'twenty_five_percentage' => 'nullable',
//         'fifty_percentage' => 'nullable',
//         'six_month' => 'nullable',
//         'twelve_month' => 'nullable',
//         'nine_monthadd' => 'nullable',
//         'twelve_monthadd' => 'nullable',
//         'overall_year' => 'nullable',
//         'dynamic' => 'nullable',
//         'presale' => 'nullable',
//         'megabonus' => 'nullable',

//       ]);

//       // return $validatedData;

//       // Add date
//       $validatedData['incentive_month'] = $incentiveMonthDate->format('Y-m-d');

//       // Check by branch, role, and month
//       $incentive = IncentiveModel::where('branch_id', $validatedData['branch_id'])
//         ->where('role_id', $validatedData['role_id'])
//         ->whereDate('incentive_month', $validatedData['incentive_month'])
//         ->first();

//       if ($incentive) {
//         $validatedData['updated_by'] = auth()->id();
//         $incentive->update($validatedData);
//       } else {
//         $validatedData['created_by'] = auth()->id();
//         $validatedData['updated_by'] = auth()->id();
//         IncentiveModel::create($validatedData);
//       }

//       return response()->json(['status' => 200, 'message' => 'Incentive saved successfully.']);
//     } catch (\Exception $e) {
//       return response()->json([
//         'status' => 500,
//         'message' => 'Something went wrong.',
//         'error' => $e->getMessage()
//       ]);
//     }
//   }


public function Incentivecreateupdate(Request $request)
  {
    try {
      // Convert to proper date
      $incentiveMonthDate = Carbon::createFromFormat('F Y', $request->month . ' ' . $request->year)->startOfMonth();

      // Validate input
      $validatedData = $request->validate([
        'branch_id' => 'required|integer',
        'role_id' => 'required|integer',
        'tenx_award' => 'nullable|integer',
        'tenx_warrior' => 'nullable|integer',
        'eci_count' => 'nullable|integer',
        'eci_reward' => 'nullable|integer',
        'bi_amount' => 'nullable|integer',
        'si_crash_course' => 'nullable|integer',
        'si_profession_course' => 'nullable|integer',
        'si_tesbo_course' => 'nullable|integer',
        'si_reward' => 'nullable|integer',
        'pi_percentage' => 'nullable|integer',
        'spot_incentive_month' => 'nullable|integer',
        'spot_incentive_day' => 'nullable|integer',
        'luxury_incentive' => 'nullable',
        'pi_slab_json' => 'nullable',
        'pdi_slab_json' => 'nullable',
        'reference_incentive' => 'nullable',
        'excess_incentive' => 'nullable',
        'team_Individual' => 'nullable',


        // bh role
        'ceiling' => 'nullable',
        'quarterly' => 'nullable',
        'twenty_five_percentage' => 'nullable',
        'fifty_percentage' => 'nullable',
        'six_month' => 'nullable',
        'twelve_month' => 'nullable',
        'nine_monthadd' => 'nullable',
        'twelve_monthadd' => 'nullable',
        'overall_year' => 'nullable',
        'dynamic' => 'nullable',
        'presale' => 'nullable',
        'megabonus' => 'nullable',

        // placement
        'oil_slab_json' => 'nullable',
        'double_x_slab_json' => 'nullable',
        'pil_slab_json' => 'nullable',
        'oie_slab_json' => 'nullable',
        'pie_slab_json' => 'nullable',

        // bdm
        'acv_abv' => 'nullable',
        'closing_slab_json' => 'nullable',
        'add_incentive' => 'nullable',
        'double_x_bdm' => 'nullable',
        'abv_percentage' => 'nullable',
        'luxury_reward_bdm' => 'nullable',


      ]);

      // return $validatedData;

      // Add date
      $validatedData['incentive_month'] = $incentiveMonthDate->format('Y-m-d');

      // Check by branch, role, and month
      $incentive = IncentiveModel::where('branch_id', $validatedData['branch_id'])
        ->where('role_id', $validatedData['role_id'])
        ->whereDate('incentive_month', $validatedData['incentive_month'])
        ->first();

      if ($incentive) {
        $validatedData['updated_by'] = auth()->id();
        $incentive->update($validatedData);
      } else {
        $validatedData['created_by'] = auth()->id();
        $validatedData['updated_by'] = auth()->id();
        IncentiveModel::create($validatedData);
      }

      return response()->json(['status' => 200, 'message' => 'Incentive saved successfully.']);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Something went wrong.',
        'error' => $e->getMessage()
      ]);
    }
  }


 public function checkIncentive(Request $request)
    {
        $user = Auth::user(); // logged-in user
 
      $today = Carbon::now();
 
        $exists = IncentiveModel::where('branch_id', $user->branch_id)
            ->where('role_id', $user->role_id)
            ->whereNot('role_id', 18)
            ->whereYear('incentive_month', $today->year)
            ->whereMonth('incentive_month', $today->month)
            ->exists();
 
        return response()->json([
            'isIncentive' => $exists
        ]);
    }

}
