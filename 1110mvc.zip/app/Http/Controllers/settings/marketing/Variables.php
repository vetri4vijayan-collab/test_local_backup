<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\VariablesModel;

class Variables extends Controller
{
  
  public function index()
  {
    $CourseSubCategory = VariablesModel::select('za_variables.*', 'za_variant.variant_name', 'za_variant.sno as variant_id')
      ->join('za_variant', 'za_variables.variant_id', '=', 'za_variant.sno')
      ->where('za_variables.status', '!=', 2)
      ->orderBy('za_variables.sno', 'desc')->get();

    $selectedCategoryId = $CourseSubCategory->isEmpty() ? null : $CourseSubCategory[0]->variant_id;
    $pageConfigs = ['myLayout' => 'default'];
    // echo  $selectedCategoryId;
    // exit;
    return view('content.settings.marketing.variables.variables_list', [
      'CourseSubCategory' => $CourseSubCategory,
      'selectedCategoryId' => $selectedCategoryId,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    // Retrieve the category ID from the POST request
    $cat_id = $_GET['id'] ?? '';

    $CourseSubCategory = VariablesModel::where('status', 0)
      ->where('variant_id', $cat_id)
      ->orderBy('sno', 'desc')
      ->get();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseSubCategory
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'variables_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $variables_name       = $request->variables_name;
      $variables_desc          = $request->variables_desc;
      $variant_id           = $request->variant_id;
      $user_id                    = $request->user()->user_id;
      $chk = VariablesModel::where('variables_name', ucwords($variables_name))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
       


        $add_category = new VariablesModel();
        $add_category->variant_id         = $variant_id;
        $add_category->variables_name       = Ucfirst($variables_name);
        $add_category->variables_desc       = $variables_desc;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'variables added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the variables!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function edit($id)
  {
    $editCategory = VariablesModel::select(
      'za_variables.*',
      'za_variant.variant_name',
      'za_variant.sno as variant_id'
    )
      ->join('za_variant', 'za_variables.variant_id', '=', 'za_variant.sno')
      ->where('za_variables.sno', $id)
      ->first();

    return response()->json([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editCategory
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'variables_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $variables_id            = $request->variables_id;
      $variant_id            = $request->variant_id;

      $variables_name       = $request->variables_name;
      $variables_desc       = $request->variables_desc;
    

      $upd_CourseCategoryModel =  VariablesModel::where('sno', $variables_id)->first();

      $chk = VariablesModel::where('variables_name', ucwords($variables_name))->where('status', '!=', 2)->where('sno', '!=', $variables_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->variant_id    = $variant_id;
        $upd_CourseCategoryModel->variables_name  = Ucfirst($variables_name);
        $upd_CourseCategoryModel->variables_desc  = $variables_desc;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Variables Successfully Upadted!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Update the variables!'
        ]);
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  VariablesModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  VariablesModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}