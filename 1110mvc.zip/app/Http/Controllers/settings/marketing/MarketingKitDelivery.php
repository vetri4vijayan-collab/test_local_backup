<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\MarketingKitDeliveryModel;
use App\Models\User;

class MarketingKitDelivery extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $MarketingKitCategory = MarketingKitDeliveryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return $MarketingKitcategory;
    return view('content.settings.marketing.MarketingKitDelivery.marketingkitdelivery_list', [
      'MarketingKitCategory' => $MarketingKitCategory,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $MarketingKitCategory = MarketingKitDeliveryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $MarketingKitCategory
    ], 200);
  }
  public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'range_from' => 'required|numeric|min:0',
        'range_to' => 'required|numeric|min:0',
        'delivery_cost' => 'required|numeric|min:0',
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $range_from = $request->range_from;
    $range_to = $request->range_to;
    $delivery_cost = $request->delivery_cost;
    $user_id = $request->user()->user_id;

    // Check if overlapping range already exists
    $exists = MarketingKitDeliveryModel::where('status', 0)
        ->where(function ($q) use ($range_from, $range_to) {
            $q->whereBetween('range_from', [$range_from, $range_to])
              ->orWhereBetween('range_to', [$range_from, $range_to])
              ->orWhere(function ($q2) use ($range_from, $range_to) {
                  $q2->where('range_from', '<=', $range_from)
                     ->where('range_to', '>=', $range_to);
              });
        })->first();

    if ($exists) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Overlapping range already exists: ' . $exists->range_from . ' to ' . $exists->range_to
        ]);
        return redirect()->back()->withInput();
    }

    // Save new record
    $add = new MarketingKitDeliveryModel();
    $add->range_from = $range_from;
    $add->range_to = $range_to;
    $add->delivery_cost = $delivery_cost;
    $add->created_by = $user_id;
    $add->updated_by = $user_id;

    if ($add->save()) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Marketing Kit Delivery Successfully added!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Marketing Kit Delivery!'
        ]);
    }

    return redirect()->back();
}



  public function Edit($id)
  {
    
    $editcategory = MarketingKitDeliveryModel::where('sno', $id)->first();
    
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

 public function Update(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        'range_from' => 'required|numeric',
        'range_to' => 'required|numeric',
        'delivery_cost' => 'required|numeric',
    ]);
// return $request->all();
    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Invalid input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $range_from = $request->range_from;
    $range_to = $request->range_to;
    $delivery_cost = $request->delivery_cost;
    $user_id = $request->user()->user_id;

    // Check for overlap excluding current record
    $exists = MarketingKitDeliveryModel::where('status', 0)
        ->where('sno', '!=', $id)
        ->where(function ($q) use ($range_from, $range_to) {
            $q->whereBetween('range_from', [$range_from, $range_to])
              ->orWhereBetween('range_to', [$range_from, $range_to])
              ->orWhere(function ($q2) use ($range_from, $range_to) {
                  $q2->where('range_from', '<=', $range_from)
                     ->where('range_to', '>=', $range_to);
              });
        })
        ->first();

    if ($exists) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Overlapping range already exists: ' . $exists->range_from . ' to ' . $exists->range_to
        ]);
        return redirect()->back()->withInput();
    }

    $record = MarketingKitDeliveryModel::findOrFail($id);
    $record->range_from = $range_from;
    $record->range_to = $range_to;
    $record->delivery_cost = $delivery_cost;
    $record->updated_by = $user_id;

    if ($record->save()) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Marketing Kit Delivery Successfully Updated!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Update failed!'
        ]);
    }

    return redirect()->back();
}


  public function Delete($id)
  {
    $upd_CategoryModel =  MarketingKitDeliveryModel::where('sno', $id)->first();
    $upd_CategoryModel->status  = 2;
    $upd_CategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_JobCategoryModel =  MarketingKitDeliveryModel::where('sno', $id)->first();
    $upd_JobCategoryModel->status = $request->input('status', 0);
    $upd_JobCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
