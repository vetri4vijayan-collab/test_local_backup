<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\VariantModel;
use App\Models\User;

class Variant extends Controller
{
  
  public function index()
  {
    $Variant = VariantModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return view('content.settings.course.course_category.course_category_list');
    return view('content.settings.marketing.variant.variant_list', [
      'Variant' => $Variant,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $Variant = VariantModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Variant
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'variant_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $variant_name       = $request->variant_name;
      $variant_desc       = $request->variant_desc;
      $user_id                    = $request->user()->user_id;
      $chk = VariantModel::where('variant_name', ucwords($variant_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
      

        

        $add_category = new VariantModel();
        // $add_category->course_category_id         = $course_category_id;
        $add_category->variant_name       = Ucfirst($variant_name);
        $add_category->variant_desc       = $variant_desc;
        // $add_category->branch_id                 =  self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Variant Successfully Added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Variant!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {
    $editcategory = VariantModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
      'variant_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $variant_name = $request->variant_name;
      $variant_desc = $request->variant_desc;
      $variant_id   = $request->variant_id;

      $upd_CourseCategoryModel =  VariantModel::where('sno', $id)->first();

      if (!$upd_CourseCategoryModel) {
        return response([
          'status'    => 404,
          'message'   => 'Variant not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

      $chk = VariantModel::where('variant_name', ucwords($variant_name))
        ->where('status', '!=', 2)
        ->where('sno', '!=', $id)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {

        $upd_CourseCategoryModel->variant_name = ucfirst($variant_name);
        $upd_CourseCategoryModel->variant_desc = $variant_desc;
        $upd_CourseCategoryModel->update();
      }

      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  VariantModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  VariantModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
