<?php

namespace App\Http\Controllers\settings\location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AttachmentModel;
use App\Models\CountryModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class Country extends Controller
{
    public function index()
    {

        $level = CountryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.hrm.attachment.attachment', compact('level', 'pageConfigs'));
    }

    public function List()
    {
        $city = CountryModel::get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $city
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'attachment_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $attachment_name       = $request->attachment_name;
            $attachment_desc       = $request->attachment_desc;

            // $user_id            = $request->user()->id;
            $user_id            = $request->user()->user_id;
            $chk = CountryModel::where('attachment_name', ucwords($attachment_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = CountryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $attachment_id = "AT-0001/" . $year;
                } else {

                    $data = $category_check->attachment_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf("AT-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $attachment_id = $request . '/' . $year;
                }


                $add_category = new AttachmentModel();
                $add_category->attachment_id           = $attachment_id;
                $add_category->attachment_name         = Ucfirst($attachment_name);
                $add_category->attachment_desc         = $attachment_desc;
                $add_category->created_by              = $user_id;
                $add_category->updated_by              = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'knowledge level added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the knowledge level!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'knowledge Created successfully!');
        }
    }

    public function Edit($id)
    {
        $attachment = AttachmentModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $attachment
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'attachment_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $attachment_name       = $request->attachment_name;
            $bg_color                   = $request->bg_color;
            $attachment_desc       = $request->attachment_desc;

            $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();

            $chk = AttachmentModel::where('attachment_name', ucwords($attachment_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $upd_CourseCategoryModel->attachment_name  = Ucfirst($attachment_name);
                $upd_CourseCategoryModel->attachment_desc  = $attachment_desc;
                $upd_CourseCategoryModel->update();
            }


            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  AttachmentModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}