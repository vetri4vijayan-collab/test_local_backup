<?php

namespace App\Http\Controllers\settings\location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AttachmentModel;
use App\Models\TimeZoneModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class TimeZone extends Controller
{
    public function index()
    {

        $level = TimeZoneModel::get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.hrm.attachment.attachment', compact('level', 'pageConfigs'));
    }

    public function List(Request $request)
    {

        // $countryId = $request->input('country_id');
        $timeZone = TimeZoneModel::get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $timeZone
        ], 200);
    }
}