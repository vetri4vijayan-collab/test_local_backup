<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Communication_config_Model;
use App\Models\EmailTemplateModel;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappTemplateModel;
use App\Models\za_schedule_message_model;
use Illuminate\Support\Facades\Validator;

class Communication_config extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    $list_data = Communication_config_Model::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    // return view( 'content.settings.course.course_type.course_type_list' );
    $sms_list     = SmsTemplateModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $email_list   = EmailTemplateModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $whatapp_list = WhatsappTemplateModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();

    return view('content.settings.common_setting.communication_config', [
      'list_data' => $list_data,
      'sms_list' => $sms_list,
      'email_list' => $email_list,
      'whatapp_list' => $whatapp_list
    ]);
  }

  public function List()
  {
    $sms_template = Communication_config_Model::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'work_flow_id' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $last_id = Communication_config_Model::orderBy('sno', 'desc')->first();

      if (!$last_id) {
        $year = substr(date('y'), -2);
        $config_id = 'CC-0001/' . $year;
      } else {
        $data = $last_id->config_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $request_num = sprintf('CC-%04d', $next_number);
        $year = substr(date('y'), -2);
        $config_id = $request_num . '/' . $year;
      }

      // return $config_id;
      $add_cc = new Communication_config_Model();
      $add_cc->config_id = $config_id;
      $add_cc->work_flow_id = $request->work_flow_id;
      $add_cc->mode_id = $request->mode_id;
      $add_cc->time = $request->time;
      $add_cc->duration = $request->duration;
      $add_cc->sms_check = $request->sms_check;
      $add_cc->sms_template_id = $request->sms_template_id;
      $add_cc->whatsapp_check = $request->whatsapp_check;
      $add_cc->whatsapp_template_id = $request->whatsapp_template_id;
      $add_cc->email_check = $request->email_check;
      $add_cc->email_template_id = $request->email_template_id;

      $add_cc->branch_id    = $request->user()->branch_id;
      $add_cc->created_by   = $request->user()->user_id;
      $add_cc->updated_by   = $request->user()->user_id;

      $add_cc->save();

      // Testind
      // $sourceTypeId = 1;
      // $sourceId = 1;
      // $configId = ($last_id->sno + 1);
      // $branchId = $request->user()->branch_id;
      // $userId   = $request->user()->user_id;
      // $helper = new \App\Helpers\Helpers();
      // $helper->scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId);

      if ($add_cc) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Communication Config Added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Communication Config!'
        ]);
      }
      // return $result;
      return redirect()->back()->with('success', 'template Created successfully!');
    }
  }

  public function Edit()
  {
    $id = request()->get('id', '');

    $editcategory = Communication_config_Model::where('sno', $id)->first();
    // Return the response with the role permissions data
    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $editcategory,
    ], 200);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'template_name_edit' => 'required|max:255',
    ]);
    $id = $request->edit_id;
    // return $config_id;
    $update_cc = Communication_config_Model::where('sno', $id)->first();
    $update_cc->work_flow_id = $request->work_flow_id;
    $update_cc->mode_id = $request->mode_id;
    $update_cc->time = $request->time;
    $update_cc->duration = $request->duration;
    $update_cc->sms_check = $request->sms_check;
    $update_cc->sms_template_id = $request->sms_template_id;
    $update_cc->whatsapp_check = $request->whatsapp_check;
    $update_cc->whatsapp_template_id = $request->whatsapp_template_id;
    $update_cc->email_check = $request->email_check;
    $update_cc->email_template_id = $request->email_template_id;
    $update_cc->updated_by   = $request->user()->user_id;
    $update_cc->update();

    if ($update_cc) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Communication Config updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Communication Config !'
      ]);
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  Communication_config_Model::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  Communication_config_Model::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => $upd_CourseCategoryModel,
    ], 200);
  }
}
