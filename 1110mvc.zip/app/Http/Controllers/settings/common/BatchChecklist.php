<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BatchChecklistModel;
use Illuminate\Support\Facades\Validator;

class BatchChecklist extends Controller
{


    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $batch_checklist = BatchChecklistModel::where('status', '!=', 2)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
        // return $highlightCategory;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.common_setting.batch_checklist.batch_checklist_list', [
            'batch_checklist' => $batch_checklist,
            'pageConfigs' => $pageConfigs
        ]);
        
    }
    public function Add(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'batch_checklist_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $batch_checklist_name = $request->batch_checklist_name;
        $user_id =  $request->user()->user_id;

        // Check if the category already exists
        $chk = BatchChecklistModel::where('batch_checklist_name', ucwords($batch_checklist_name))
            ->where('branch_id', $branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Batch Checklist  has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = BatchChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $batch_checklist_id = 'BC-0001/' . $year;
            } else {
                $data = $category_check->batch_checklist_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('BC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $batch_checklist_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new BatchChecklistModel();
            $add->batch_checklist_id = $batch_checklist_id;
            $add->batch_checklist_name = ucfirst($batch_checklist_name);
            $add->branch_id = $branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;
            // return $add;
            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Batch Checklist added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Batch Checklist!'
                ]);
            }
        }

        return redirect()->back();
    }
    public function Update(Request $request)
    {
        // return $request;

        $branch_id = $request->user()->branch_id;

        $validator = Validator::make($request->all(), [
            'batch_checklist_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $sno = $request->edit_batch_checklist_id;
        $batch_checklist_name = $request->batch_checklist_name_edit;
        $user_id =  $request->user()->user_id;

        $update = BatchChecklistModel::where('sno', $sno)->first();

        $chk = BatchChecklistModel::where('batch_checklist_name', ucwords($batch_checklist_name))
            ->where('branch_id', $branch_id)
            ->where('sno', '!=', $sno)
            ->where('status', '!=', 2)->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Batch Checklist is exist!'
            ]);
            return redirect()->back();
        } else {

            $update->batch_checklist_name = Ucfirst($batch_checklist_name);
            $update->updated_by = $user_id;
            $update->branch_id = $branch_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Batch Checklist Updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Updated the Batch Checklist!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Status($id, Request $request)
    {
        // return $id;
        $upd_DepartmentModel = BatchChecklistModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = BatchChecklistModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}