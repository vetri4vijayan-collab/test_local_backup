<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HighLightTemplateModel;
use Illuminate\Support\Facades\Validator;
// D:\Xampp_8.2.4\htdocs\elysium_erp_14-10-2024\app\Http\Controllers\settings\common\HighLightTemplate.php
// D:\Xampp_8.2.4\htdocs\elysium_erp_14-10-2024\resources\views\content\settings\common_setting\highlight\highlight_template_list.blade.php
class HighLightTemplate extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $highlightCategory = HighLightTemplateModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        // return  $highlightCategory;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.common_setting.highlight.highlight_template_list', [
            'highlightCategory' => $highlightCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function HighLightAdd()
    {
        return view('content.settings.common_setting.highlight.highlight_template_add');
    }

    public function Add(Request $request)
    {
        // return $request;


        $validator = Validator::make($request->all(), [
            'highlight_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $highlight_name       = $request->highlight_name;
            $highlight_subject          = $request->highlight_subject;
            $user_id                    = $request->user()->user_id;
            $chk = HighLightTemplateModel::where('highlight_name', ucwords($highlight_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already HighLight is exist!'
                ]);
                return redirect('settings/common/highlight/highlight_template_list');
            } else {
                $category_check = HighLightTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $highlight_template_id = 'HLT-0001/' . $year;
                } else {

                    $data = $category_check->highlight_template_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('HLT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $highlight_template_id = $request . '/' . $year;
                }

                $add_ledger = new HighLightTemplateModel();
                $add_ledger->highlight_template_id         = $highlight_template_id;
                $add_ledger->highlight_name       = Ucfirst($highlight_name);
                $add_ledger->highlight_subject       = $highlight_subject;
                $add_ledger->branch_id         = self::$branch_id;
                $add_ledger->created_by        = $user_id;
                $add_ledger->updated_by        = $user_id;


                $add_ledger->save();

                if ($add_ledger) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'HighLight added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the HighLight!'
                    ]);
                }
            }
            return redirect('settings/common/highlight/highlight_template_list');
        }
    }



    public function Edit($id)
    {
        // return $id;
        // Decrypt the ID D:\Xampp_8.2.4\htdocs\elysium_erp_14-10-2024\resources\views\content\settings\common_setting\highlight\highlight_template_edit.blade.php
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Check if decryption failed
        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $Edit = HighLightTemplateModel::where('sno', $decryptedValue)->first();
        return view('content.settings.common_setting.highlight.highlight_template_edit', [
            'edit' => $Edit
        ]);
    }


    public function Update(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            'hightlight_name_edit' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $highlight_name       = $request->hightlight_name_edit;
            $highlight_subject       = $request->hightlight_subject_edit;
            $edit_id       = $request->edit_id;

            $upd_LedgerCategoryModel =  HighLightTemplateModel::where('sno', $edit_id)->first();

            $chk = HighLightTemplateModel::where('highlight_name', ucwords($highlight_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already HighLight is exist!'
                ]);
                return redirect()->back();
            } else {


                $upd_LedgerCategoryModel->highlight_name  = Ucfirst($highlight_name);
                $upd_LedgerCategoryModel->highlight_subject  = $highlight_subject;
                $upd_LedgerCategoryModel->update();
                // return $upd_LedgerCategoryModel;

                if ($upd_LedgerCategoryModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'HighLight Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the HighLight!'
                    ]);
                }
            }
        }
        return redirect('settings/common/highlight/highlight_template_list');
    }



    public function Delete($id)
    {
        $upd_LedgerCategoryModel = HighLightTemplateModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status  = 2;
        $upd_LedgerCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_LedgerCategoryModel =  HighLightTemplateModel::where('sno', $id)->first();
        $upd_LedgerCategoryModel->status = $request->input('status', 0);
        $upd_LedgerCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
