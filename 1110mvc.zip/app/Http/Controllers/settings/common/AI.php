<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AIModel;
use Illuminate\Support\Facades\Validator;

class AI extends Controller
{
   

    public function index()
    {
        $AI = AIModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.common_setting.ai.ai_list', [
            'AI' => $AI,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $AI = AIModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $AI
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'ai' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $ai       = $request->ai;
            $ai_desc          = $request->ai_desc;
            $user_id                    = $request->user()->user_id;
            $chk = AIModel::where('ai', ucwords($ai))->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Name has been  already created!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = AIModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    // $topic_id = 'LS-0001/' . $year;
                } else {

                //     $data = $category_check->topic_id;
                //     $slice = explode('/', $data);
                //     $result = preg_replace('/[^0-9]/', '', $slice[0]);

                //     $next_number = (int)$result + 1;
                //     $request = sprintf('LS-%04d', $next_number);

                //     $year = substr(date('y'), -2);
                //     $topic_id = $request . '/' . $year;
                // }

                $add_ai = new AIModel();
                // $add_ai->topic_id         = $topic_id;
                $add_ai->ai       = Ucfirst($ai);
                $add_ai->ai_desc       = $ai_desc;
                // $add_ai->branch_id = self::$branch_id;
                $add_ai->created_by                 = $user_id;
                $add_ai->updated_by                 = $user_id;

                $add_ai->save();

                if ($add_ai) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'AI added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the AI!'
                    ]);
                }
            }
        }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = AIModel::where('sno', $id)->first();

        return view('content.settings.common_settings.ai.ai_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {
    //    return $request;
        $validator = Validator::make($request->all(), [
            'ai' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $ai       = $request->ai;
            $ai_desc       = $request->ai_desc;
            $ai_id        = $request->ai_id;

            $upd_CourseCategoryModel =  AIModel::where('sno', $ai_id)->first();

            $chk = AIModel::where('ai', ucwords($ai))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $ai_id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already assigned!'
                    ]);
                } else {
                }
            }

            $upd_CourseCategoryModel->ai  = Ucfirst($ai);
            $upd_CourseCategoryModel->ai_desc  = $ai_desc;

            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'AI Update Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the AI!'
                ]);
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  AIModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'AI Successfully Deleted!',
            'error_msg' => 'Could not Delete AI!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  AIModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
