<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ReviewLinkModel;
use App\Models\User;

class ReviewLinks extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $ReviewLinks = ReviewLinkModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return $ReviewLinks;
    return view('content.settings.common_setting.ReviewLinks.review_links_list', [
      'ReviewLinks' => $ReviewLinks,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $ReviewLinks = ReviewLinkModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    return $ReviewLink;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $ReviewLinks
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'review_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $review_name       = $request->review_name;
      $review_desc       = $request->review_desc;
      $user_id                    = $request->user()->user_id;
      $chk = ReviewLinkModel::where('review_name', ucwords($review_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = ReviewLinkModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_category_id = "CC-0001/" . $year;
        } else {

          $data = $category_check->job_category_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_category_id = $request . '/' . $year;
        }


        $add_category = new ReviewLinkModel();
        // $add_category->job_category_id         = $job_category_id;
        $add_category->review_name       = Ucfirst($review_name);
        $add_category->review_desc       = $review_desc;
        $add_category->branch_id                 =  self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();
        
        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Review Successfully added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job Category!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {
    
    $editcategory = ReviewLinkModel::where('sno', $id)->first();
    
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update(Request $request)
  {

    $id=$request->id;
    // return $request;
    $validator = Validator::make($request->all(), [
      'review_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 401);
    }

      $review_name = $request->review_name;
      $review_desc = $request->review_desc;
      $id = $request->id;

      $upd_ReviewLinkModel =  ReviewLinkModel::where('sno', $id)->first();
      // return $upd_ReviewLinkModel;

      if (!$upd_ReviewLinkModel) {
        return response([
          'status'    => 404,
          'message'   => 'Job category not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

      $chk = ReviewLinkModel::where('review_name', ucwords($review_name))
        ->where('status', '!=', 2)
        // ->where('sno', '!=', $id)
        ->first();

        // return $chk;

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {

        $upd_ReviewLinkModel->review_name = ucfirst($review_name);
        $upd_ReviewLinkModel->review_desc = $review_desc;
        $upd_ReviewLinkModel->save();
        return response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }
  }

  public function Delete($id)
  {
    $upd_ReviewLinkModel =  ReviewLinkModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status  = 2;
    $upd_ReviewLinkModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_ReviewLinkModel =  ReviewLinkModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status = $request->input('status', 0);
    $upd_ReviewLinkModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
