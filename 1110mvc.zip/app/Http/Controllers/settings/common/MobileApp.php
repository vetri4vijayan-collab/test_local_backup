<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\StaffAccessAppModel;
use Illuminate\Support\Facades\Validator;

class MobileApp extends Controller
{
    

    public function index()
    {
        $MobileApp = StaffAccessAppModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];

        return view(
            'content.settings.common_setting.MobileApp.MobileApp_list',
            [
                'MobileApp' => $MobileApp,
                'pageConfigs' => $pageConfigs
            ]
        );
    }



    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'MobileApp_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $MobileApp_name = $request->MobileApp_name;
            $MobileApp_desc = $request->MobileApp_desc;
            $user_id = auth()->user()->user_id;
            $chk = StaffAccessAppModel::where('mobile_app_name', ucwords($MobileApp_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already FMobileApp Name is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = StaffAccessAppModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $mobile_app_id = 'FY-0001/' . $year;
                } else {
                    $data = $category_check->mobile_app_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request = sprintf('FY-%04d', $next_number);
                    $year = substr(date('y'), -2);
                    $mobile_app_id = $request . '/' . $year;
                }

                $add_department = new StaffAccessAppModel();
                $add_department->mobile_app_id = $mobile_app_id;
                $add_department->mobile_app_name = Ucfirst($MobileApp_name);
                $add_department->mobile_app_desc = $MobileApp_desc;

                $add_department->updated_by = $user_id;
                // $add_department->branch_id = $branch_id;
               
                $add_department->created_by        = $user_id;
                $add_department->updated_by        = $user_id;
                // dd($add_department);
                $add_department->save();

                if ($add_department) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'MobileApp added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the MobileApp!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }



    public function Update($id, Request $request)
    {
    //   return $request;
      $validator = Validator::make($request->all(), [
        'MobileApp_name' => 'required|max:255',
      ]);
  
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 401);
      } else {
        $MobileApp_name = $request->MobileApp_name;
        $MobileApp_desc = $request->MobileApp_desc;
  
        $upd_CategoryModel =  StaffAccessAppModel::where('sno', $id)->first();
        
        if (!$upd_CategoryModel) {
          return response([
            'status'    => 404,
            'message'   => ' category not found',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        }
  
        $chk = StaffAccessAppModel::where('mobile_app_name', ucwords($MobileApp_name))
          ->where('status', '!=', 2)
          ->where('sno', '!=', $id)
          ->first();
  
        if ($chk) {
          session()->flash('toastr', [
            'status'    => 401,
            'type' => 'error',
            'message' => ' has been  already created!'
          ]);
        } else {
  
          $upd_CategoryModel->mobile_app_name = ucfirst($MobileApp_name);
          $upd_CategoryModel->mobile_app_desc = $MobileApp_desc;
          $upd_CategoryModel->update();
        }
  
        if ($upd_CategoryModel) {
          $result = response([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        } else {
          $result = response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => 'Incorrect format input feilds',
            'data'      => null,
          ], 401);
        }
        return $result;
      }
  
      // return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_DepartmentModel = StaffAccessAppModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        // return $id;
        $upd_DepartmentModel = StaffAccessAppModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
  {
    // return $id;
    $editcategory = StaffAccessAppModel::where('sno', $id)->first();
    
    if ($editcategory) {
        return response()->json([
            'status' => 200,
            'message' => 'Mobile App found',
            'data' => $editcategory
        ]);
    } else {
        return response()->json([
            'status' => 404,
            'message' => 'Mobile App not found',
            'data' => null
        ]);
    }
}
}