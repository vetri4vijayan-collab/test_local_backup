<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Rules_guidelinesModel;

class Rules_guidelines extends Controller
{

    public function index()
    {
        $exam_guidelines = Rules_guidelinesModel::select('za_rules_guidelines.*','za_department.department_name', 'za_sub_department.sub_department_name')
        ->leftJoin('za_department', 'za_rules_guidelines.department_id', '=', 'za_department.sno')
        ->leftJoin('za_sub_department', 'za_rules_guidelines.sub_dept_id', '=', 'za_sub_department.sno')
        ->where('za_rules_guidelines.status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->get();
    
        return view('content.settings.common_setting.rules.rules_list', compact('exam_guidelines'));
    }
    

    public function create_rules(Request $request)
    {
          // return $request;
          $validator = Validator::make($request->all(), [
            'department_id' => 'required|max:11',
            'sub_department_id' => 'required|max:11'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $department_id = $request->input('department_id');
            $sub_department_id = $request->input('sub_department_id');
            $multiExamIds = $request->input('multi_exam_id');
            $rulesStatus = $request->input('rules_status');
            $branch_id = $request->user()->branch_id;
            $chk = Rules_guidelinesModel::where('department_id', $department_id)->where('sub_dept_id', $sub_department_id)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Department and Sub Department is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = Rules_guidelinesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $rule_id = 'RG-0001/' . $year;
                } else {
                    $data = $category_check->rule_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request = sprintf('RG-%04d', $next_number);
                    $year = substr(date('y'), -2);
                    $rule_id = $request . '/' . $year;
                }
        
        $formattedRules = [];
        
        foreach ($multiExamIds as $index => $rule) {
            $formattedRules[] = [
                "Rule " . ($index + 1) => $rule,
                "rules_status" => isset($rulesStatus[$index]) ? $rulesStatus[$index] : "0" 
            ];
        }
        // return $request;


        $add_department = new Rules_guidelinesModel();
        $add_department->rule_id = $rule_id;
        $add_department->department_id = $department_id;
        $add_department->sub_dept_id = $sub_department_id;
        $add_department->rules_guidelines = json_encode($formattedRules);
        $add_department->branch_id         = $branch_id;
        $add_department->created_by        = auth()->user()->user_id;
        $add_department->updated_by        = auth()->user()->user_id;
        // return $add_department;
        $add_department->save();

        if ($add_department) {
            // If category added successfully, return success response and display Toastr message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Rules added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add Rules!'
            ]);
        }
        }
        return redirect()->back();
        }
    }

    public function editRules($id)
    {
       
        $edit = Rules_guidelinesModel::select(
            'za_rules_guidelines.*', 
        )
        ->where('za_rules_guidelines.status', '!=', 2)
        ->where('za_rules_guidelines.sno', $id)
        ->first(); 

    
        return response()->json($edit);
    }

    public function update_rules(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'department_id_edit' => 'required|max:11',
            'sub_department_id_edit' => 'required|max:11',
        ]);
    
        // Check if validation fails
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }
    
        // Extract inputs from the request
        $department_id = $request->input('department_id_edit');
        $rule_id = $request->input('rule_id');
        $sub_department_id = $request->input('sub_department_id_edit');
        $multiExamIds = $request->input('multi_exam_edit_id');
        $rulesStatus = $request->input('edit_rules_status');
        $branch_id = $request->user()->branch_id;
    
        // Prepare formatted rules for saving
        $formattedRules = [];
    
        // Format each rule with its status
        foreach ($multiExamIds as $index => $rule) {
            $formattedRules[] = [
                "Rule " . ($index + 1) => $rule,
                "rules_status" => isset($rulesStatus[$index]) ? $rulesStatus[$index] : "0"
            ];
        }
    
        // Fetch the existing rule model using the rule_id
        $add_department = Rules_guidelinesModel::where('sno', $rule_id)->first();
    
        // If the rule doesn't exist, return an error
        if (!$add_department) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Rule not found for the specified ID!'
            ]);
            return redirect()->back();
        }
    
        // Update the department record with new data
        $add_department->department_id = $department_id;
        $add_department->sub_dept_id = $sub_department_id;
        $add_department->rules_guidelines = json_encode($formattedRules); // Store rules as JSON
        $add_department->branch_id = $branch_id;
        $add_department->updated_by = auth()->user()->user_id;
    
        // return $add_department;
        $updateSuccess = $add_department->update();
    
        // Return the appropriate response based on the update result
        if ($updateSuccess) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Rules updated successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update rules!'
            ]);
        }
    
        // Redirect back to the previous page
        return redirect()->back();
    }

    public function view($id)
    {
        $rule_ids = explode(',', $id);
        // return $rule_ids;

        // Get the first value from the array
        $rule_id = $rule_ids[0];
       

        $editcategory = Rules_guidelinesModel::select('za_rules_guidelines.*','za_department.department_name', 'za_sub_department.sub_department_name')
        ->leftJoin('za_department', 'za_rules_guidelines.department_id', '=', 'za_department.sno')
        ->leftJoin('za_sub_department', 'za_rules_guidelines.sub_dept_id', '=', 'za_sub_department.sno')
        ->where('za_rules_guidelines.status', '!=', 2)->where('za_rules_guidelines.sno', $rule_id)->first();

        // return $editcategory;

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $editcategory
        ], 200);
    }
  
}