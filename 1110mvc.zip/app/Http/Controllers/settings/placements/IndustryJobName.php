<?php

namespace App\Http\Controllers\settings\placements;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\IndustryTypeModel;
use App\Models\IndustryJobNameModel;


class IndustryJobName extends Controller
{


    public function index()
    {
        $industry_job_name = IndustryJobNameModel::select('za_industry_job_name.*', 'za_industry_type.industry_type_name')
            ->join('za_industry_type', 'za_industry_job_name.industry_type_id', '=', 'za_industry_type.sno')
            ->where('za_industry_job_name.status', '!=', 2)
            ->orderBy('za_industry_job_name.sno', 'desc')->get();
        return view('content.settings.placements.industry_job_position_name.industry_job_name', [
            'industry_job_name' => $industry_job_name
        ]);
    }


    public function List(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $industrytype = IndustryTypeModel::where('branch_id', $branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $industrytype
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'industry_type_select' => 'required|max:255',
            'job_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $industry_type_id = $request->industry_type_select;
        $job_name = $request->job_name;
        $job_desc = $request->job_desc;
        $Know_tag = is_array($request->course_KnowledgeTag) ? json_encode($request->course_KnowledgeTag) : $request->course_KnowledgeTag;
        $branch_id = $request->user()->branch_id;
        $user_id   = $request->user()->user_id;

        // Check if the category already exists
        $chk = IndustryJobNameModel::where('job_name', ucwords($job_name))
            ->where('branch_id', $branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Job Name has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = IndustryJobNameModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $industry_job_name_id = 'ITJ-0001/' . $year;
            } else {
                $data = $category_check->industry_job_name_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('ITJ-%04d', $next_number);
                $year = substr(date('y'), -2);
                $industry_job_name_id = $requestId . '/' . $year;
            }



            // Add the category to the database
            $add = new IndustryJobNameModel();
            $add->industry_job_name_id = $industry_job_name_id;
            $add->industry_type_id = $industry_type_id;
            $add->job_name = ucfirst($job_name);
            $add->knowledge_tags = $Know_tag;
            $add->job_desc = $job_desc;
            $add->branch_id = $branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;
            // return $add;
            $add->save();
            if ($add) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Job Name added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Job Name!'
                ]);
            }
        }


        return redirect()->back();
    }


    public function Edit($id)
    {

        $job_name = IndustryJobNameModel::select(
            'za_industry_job_name.*',
            'za_industry_type.industry_type_name',
            'za_industry_type.sno as industry_type_sno'
        )
            ->join('za_industry_type', 'za_industry_job_name.industry_type_id', '=', 'za_industry_type.sno')
            ->where('za_industry_job_name.sno', $id)
            ->first();


        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $job_name
        ], 200);
    }


    public function Update(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'industry_type_select_edit' => 'required|max:255',
            'job_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $sno = $request->edit_sno;
        $industry_type_select_edit = $request->industry_type_select_edit;
        $job_name_edit = $request->job_name_edit;
        $job_desc_edit = $request->job_desc_edit;
        $Know_tag = is_array($request->course_KnowledgeTag_edit) ? json_encode($request->course_KnowledgeTag_edit) : $request->course_KnowledgeTag_edit;
        $branch_id = $request->user()->branch_id;
        $user_id   = $request->user()->user_id;

        $upd_marketing_type = IndustryJobNameModel::find($sno);

        if (!$upd_marketing_type) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Industry Type not found!'
            ]);
            return redirect()->back();
        }

        $chk = IndustryJobNameModel::where('job_name', ucwords($job_name_edit))
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Industry Type has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_marketing_type->job_name = ucfirst($job_name_edit);
        $upd_marketing_type->job_desc = $job_desc_edit;
        $upd_marketing_type->industry_type_id = $industry_type_select_edit;
        $upd_marketing_type->knowledge_tags = $Know_tag;
        $upd_marketing_type->branch_id = $branch_id;
        $upd_marketing_type->created_by = $user_id;
        $upd_marketing_type->updated_by = $user_id;
        $upd_marketing_type->update();

        if ($upd_marketing_type) {
            // If category added successfully, return success response and display Toastr message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Job Name Update Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add Update Job Name!'
            ]);
        }

        // return $marketing_type_id;



        return redirect()->back();
    }
    public function Status($id, Request $request)
    {

        $upd_IndustryJobNameModel =  IndustryJobNameModel::where('sno', $id)->first();
        $upd_IndustryJobNameModel->status = $request->input('status', 0);
        $upd_IndustryJobNameModel->update();
        if ($upd_IndustryJobNameModel) {
            return response([
                'status'    => 200,
                'message'   => 'Job Name Status Successfully Updated!',
                'error_msg' => 'Could not update  Job Name  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Job Name  Status!',
                'error_msg' => 'Could not update  Job Name Typ Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $IndustryJobNameModel =  IndustryJobNameModel::where('sno', $id)->first();
        $IndustryJobNameModel->status  = 2;
        $IndustryJobNameModel->Update();
        if ($IndustryJobNameModel) {
            return response([
                'status'    => 200,
                'message'   => 'Job Name   Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Job Name  !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
