<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRoleTagModel;
use Illuminate\Support\Facades\Validator;

class JobRoleTag extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $tag = JobRoleTagModel::select('za_job_role_tag.*')
      ->where('za_job_role_tag.status', '!=', 2)
      ->orderBy('za_job_role_tag.sno', 'desc')
      ->get();

    // dd($tag);
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.placements.job_role_tag.job_role_tag', compact('tag', 'pageConfigs'));
  }
  public function List()
  {
    $tags = JobRoleTagModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $tags
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_role_tag_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'knowledge Tag Name is required'
      ]);
    } else {


      $job_role_tag_name       = $request->job_role_tag_name;
      $job_role_tag_desc       = $request->job_role_tag_desc;

      $user_id                    = $request->user()->user_id;
      $chk = JobRoleTagModel::where('job_role_tag_name', $job_role_tag_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobRoleTagModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_role_tag_id = "RTAG-0001/" . $year;
        } else {

          $data = $category_check->job_role_tag_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("RTAG-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_role_tag_id = $request . '/' . $year;
        }


        $add_category = new JobRoleTagModel();
        $add_category->job_role_tag_id         = $job_role_tag_id;
        $add_category->job_role_tag_name       = $job_role_tag_name;
        $add_category->job_role_tag_desc       = $job_role_tag_desc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Job Role Tag added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the knowledge Tag!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Job Role Created successfully!');
    }
  }

  public function Edit($id)
  {
    $knowledge = JobRoleTagModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $knowledge
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_role_tag_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $job_role_tag_name       = $request->job_role_tag_name;
      
      $job_role_tag_desc       = $request->job_role_tag_desc;

      $upd_CourseCategoryModel =  JobRoleTagModel::where('sno', $id)->first();

      $chk = JobRoleTagModel::where('job_role_tag_name', ucwords($job_role_tag_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_role_tag_name  = $job_role_tag_name;
        $upd_CourseCategoryModel->job_role_tag_desc  = $job_role_tag_desc;
        $upd_CourseCategoryModel->update();
      }



      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  JobRoleTagModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  JobRoleTagModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}