<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\JobSubCategoryModel;

class JobSubCategory extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    $JobSubCategory = JobSubCategoryModel::select('za_job_subcategory.*', 'za_job_category.job_category_name', 'za_job_category.sno as category_id')
      ->join('za_job_category', 'za_job_subcategory.job_category_id', '=', 'za_job_category.sno')
      ->where('za_job_subcategory.status', '!=', 2)
      ->where('za_job_subcategory.branch_id', self::$branch_id)
      ->orderBy('za_job_subcategory.sno', 'desc')->get();
      
    // $selectedCategoryId = $JobSubCategory->isEmpty() ? null : $JobSubCategory[0]->job_category_id;
    $pageConfigs = ['myLayout' => 'default'];
    // return  $JobSubCategory;
    // exit;
    return view('content.settings.placements.job_subcategory.job_subcategory_list', [
      'JobSubCategory' => $JobSubCategory,
      // 'selectedCategoryId' => $selectedCategoryId,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    // Retrieve the category ID from the POST request
    $cat_id = $_GET['id'] ?? '';

    $JobSubCategory = JobSubCategoryModel::where('branch_id', self::$branch_id)->where('status', 0)
      ->where('course_category_id', $cat_id)
      ->orderBy('sno', 'desc')
      ->get();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $JobSubCategory
    ], 200);
  }

  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'job_subcategory_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $job_subcategory_name       = $request->job_subcategory_name;
      $job_subcategory_descr        = $request->job_subcategory_descr;
      $course_category_id           = $request->course_category_id;
      $user_id                    = $request->user()->user_id;
      $chk = JobSubCategoryModel::where('job_subcategory_name', ucwords($job_subcategory_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobSubCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        // if (!$category_check) {

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = "CS-0001/" . $year;
        // } else {

        //   $data = $category_check->job_subcategory_id;
        //   $slice = explode("/", $data);
        //   $result = preg_replace('/[^0-9]/', '', $slice[0]);

        //   $next_number = (int)$result + 1;
        //   $request = sprintf("CS-%04d", $next_number);

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = $request . '/' . $year;
        // }


        $add_category = new JobSubCategoryModel();
        $add_category->job_category_id         = $course_category_id;
        // $add_category->job_subcategory_id         = $job_subcategory_id;
        $add_category->job_subcategory_name       = Ucfirst($job_subcategory_name);
        $add_category->job_subcategory_descr       = $job_subcategory_descr;
        $add_category->branch_id                 = self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job SubCategory added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job SubCategory!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function edit($id)
  {
    $editCategory = JobSubCategoryModel::select(
      'za_job_subcategory.*',
      'za_job_category.job_category_name',
      'za_job_category.sno as category_id'
    )
      ->join('za_job_category', 'za_job_subcategory.job_category_id', '=', 'za_job_category.sno')
      ->where('za_job_subcategory.sno', $id)
      ->first();

    return response()->json([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editCategory
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'job_subcategory_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $job_category_id            = $request->job_category_id_edit;
      $job_subcategory_name       = $request->job_subcategory_name;
      $job_subcategory_descr       = $request->job_subcategory_descr;
      $course_category_id         = $request->course_category_id;
      $job_subcategory_id         = $request->job_subcategory_id;

      $upd_JobCategoryModel =  JobSubCategoryModel::where('sno', $job_subcategory_id)->first();
      // return $upd_JobCategoryModel;

      $chk = JobSubCategoryModel::where('job_subcategory_name', ucwords($job_subcategory_name))->where('status', '!=', 2)->where('sno', '!=', $job_subcategory_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        // return $job_category_id;
        $upd_JobCategoryModel->job_category_id    = $job_category_id;
        $upd_JobCategoryModel->job_subcategory_name  = Ucfirst($job_subcategory_name);
        $upd_JobCategoryModel->job_subcategory_descr  = $job_subcategory_descr;
        $upd_JobCategoryModel->update();
      }
      if ($upd_JobCategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Job SubCategory Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Job SubCategory!'
        ]);
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_JobCategoryModel =  JobSubCategoryModel::where('sno', $id)->first();
    $upd_JobCategoryModel->status  = 2;
    $upd_JobCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_JobCategoryModel =  JobSubCategoryModel::where('sno', $id)->first();
    $upd_JobCategoryModel->status = $request->input('status', 0);
    $upd_JobCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}