<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobSkillTagModel;
use Illuminate\Support\Facades\Validator;

class JobSkillTag extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    // return view('content.settings.hrm.knowledge_tag.knowledge_tag_list');

    $tag = JobSkillTagModel::select('za_job_skill_tag.*')
      ->where('za_job_skill_tag.status', '!=', 2)
      ->orderBy('za_job_skill_tag.sno', 'desc')
      ->get();

    // dd($tag);
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.placements.job_skill_tag.job_skill_tag', compact('tag', 'pageConfigs'));
  }
  public function List()
  {
    $tags = JobSkillTagModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $tags
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_skill_tag_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'knowledge Tag Name is required'
      ]);
    } else {


      $job_skill_tag_name       = $request->job_skill_tag_name;
      $job_skill_tag_desc       = $request->job_skill_tag_desc;

      $user_id                    = $request->user()->user_id;
      $chk = JobSkillTagModel::where('job_skill_tag_name', $job_skill_tag_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobSkillTagModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_skill_tag_id = "STAG-0001/" . $year;
        } else {

          $data = $category_check->job_skill_tag_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("STAG-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_skill_tag_id = $request . '/' . $year;
        }


        $add_category = new JobSkillTagModel();
        $add_category->job_skill_tag_id         = $job_skill_tag_id;
        $add_category->job_skill_tag_name       = $job_skill_tag_name;
        $add_category->job_skill_tag_desc       = $job_skill_tag_desc;
        $add_category->branch_id           = self::$branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Job Skill Tag added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the knowledge Tag!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Job Skill Created successfully!');
    }
  }

  public function Edit($id)
  {
    $knowledge = JobSkillTagModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $knowledge
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_skill_tag_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $job_skill_tag_name       = $request->job_skill_tag_name;
      $job_skill_tag_desc       = $request->job_skill_tag_desc;

      $upd_CourseCategoryModel =  JobSkillTagModel::where('sno', $id)->first();

      $chk = JobSkillTagModel::where('job_skill_tag_name',$job_skill_tag_name)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_skill_tag_name  = $job_skill_tag_name;
        $upd_CourseCategoryModel->knowledge_level_id  = $knowledge_level_id;
        $upd_CourseCategoryModel->job_skill_tag_desc  = $job_skill_tag_desc;
        $upd_CourseCategoryModel->update();
      }



      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  JobSkillTagModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  JobSkillTagModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}