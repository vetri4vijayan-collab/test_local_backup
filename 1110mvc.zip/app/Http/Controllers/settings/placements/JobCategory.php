<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\JobCategoryModel;
use App\Models\User;

class JobCategory extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    $Job_category = JobCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return $Job_category;
    return view('content.settings.placements.job_category.job_category_list', [
      'Job_category' => $Job_category,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $Job_category = JobCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Job_category
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_category_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $job_category_name       = $request->job_category_name;
      $job_category_descr       = $request->job_category_descr;
      $user_id                    = $request->user()->user_id;
      $chk = JobCategoryModel::where('job_category_name', ucwords($job_category_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = JobCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_category_id = "CC-0001/" . $year;
        } else {

          $data = $category_check->job_category_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_category_id = $request . '/' . $year;
        }


        $add_category = new JobCategoryModel();
        // $add_category->job_category_id         = $job_category_id;
        $add_category->job_category_name       = Ucfirst($job_category_name);
        $add_category->job_category_descr       = $job_category_descr;
        $add_category->branch_id                 =  self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();
        
        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job Category Successfully added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job Category!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    
    $editcategory = JobCategoryModel::where('sno', $id)->first();
    
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_category_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 401);
    } else {
      $job_category_name = $request->job_category_name;
      $job_category_desc = $request->job_category_desc;

      $upd_JobCategoryModel =  JobCategoryModel::where('sno', $id)->first();

      if (!$upd_JobCategoryModel) {
        return response([
          'status'    => 404,
          'message'   => 'Job category not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

      $chk = JobCategoryModel::where('job_category_name', ucwords($job_category_name))
        ->where('status', '!=', 2)
        ->where('sno', '!=', $id)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {

        $upd_JobCategoryModel->job_category_name = ucfirst($job_category_name);
        $upd_JobCategoryModel->job_category_descr = $job_category_desc;
        $upd_JobCategoryModel->update();
      }

      if ($upd_JobCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_JobCategoryModel =  JobCategoryModel::where('sno', $id)->first();
    $upd_JobCategoryModel->status  = 2;
    $upd_JobCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_JobCategoryModel =  JobCategoryModel::where('sno', $id)->first();
    $upd_JobCategoryModel->status = $request->input('status', 0);
    $upd_JobCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
