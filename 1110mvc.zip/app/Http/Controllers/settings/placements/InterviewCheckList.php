<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InterviewCheckListModel;
use Illuminate\Support\Facades\Validator;

class InterviewCheckList extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    $InterviewCheckList = InterviewCheckListModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.placements.interview_checklist.interview_checklist', [
      'InterviewCheckList' => $InterviewCheckList,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function List()
  {
    $InterviewCheckList = InterviewCheckListModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $InterviewCheckList
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'interview_checklist_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $interview_checklist_name = $request->interview_checklist_name;
      $interview_checklist_desc = $request->interview_checklist_desc;
      $user_id = $request->user()->user_id;
      $chk = InterviewCheckListModel::where('interview_checklist_name', ucwords($interview_checklist_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Interview check List is exist!'
        ]);
        return redirect()->back();
      } else {
        $category_check = InterviewCheckListModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $interview_checklist_id = "IC-0001/" . $year;
        } else {

          $data = $category_check->interview_checklist_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("IC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $interview_checklist_id = $request . '/' . $year;
        }


        $add_interview_checklist = new InterviewCheckListModel();
        $add_interview_checklist->interview_checklist_id = $interview_checklist_id;
        $add_interview_checklist->interview_checklist_name = Ucfirst($interview_checklist_name);
        $add_interview_checklist->interview_checklist_desc = $interview_checklist_desc;
        $add_interview_checklist->branch_id = self::$branch_id;
        $add_interview_checklist->created_by = $user_id;
        $add_interview_checklist->updated_by = $user_id;

        $add_interview_checklist->save();

        if ($add_interview_checklist) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Interview Check List added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Interview Check List!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function Edit($id)
  {
    $editinterview_checklist = InterviewCheckListModel::where('sno', $id)->first();

    return view('content.settings.placements.interview_checklist.interview_checklist', [
      'editinterview_checklist' => $editinterview_checklist,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'interview_checklist_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $interview_checklist_name = $request->interview_checklist_name;
      $interview_checklist_desc = $request->interview_checklist_desc;
      $interview_checklist_id = $request->interview_checklist_id;

      $upd_InterviewCheckListModel = InterviewCheckListModel::where('sno', $interview_checklist_id)->first();

      $chk = InterviewCheckListModel::where('interview_checklist_name', ucwords($interview_checklist_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $interview_checklist_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Interview Check List is exist!'
        ]);
        return redirect()->back();
      } else {


        $upd_InterviewCheckListModel->interview_checklist_name = Ucfirst($interview_checklist_name);
        $upd_InterviewCheckListModel->interview_checklist_desc = $interview_checklist_desc;
        $upd_InterviewCheckListModel->update();


        if ($upd_InterviewCheckListModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Interview Check List Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Interview Check List!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_InterviewCheckListModel = InterviewCheckListModel::where('sno', $id)->first();
    $upd_InterviewCheckListModel->status = 2;
    $upd_InterviewCheckListModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $upd_InterviewCheckListModel = InterviewCheckListModel::where('sno', $id)->first();
    $upd_InterviewCheckListModel->status = $request->input('status', 0);
    $upd_InterviewCheckListModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}