<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\IndustryTypeModel;
use Illuminate\Support\Facades\Validator;

class IndustryType extends Controller
{


    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $industryType = IndustryTypeModel::where('branch_id', $branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.placements.industry_type.industry_type', [
            'industryType' => $industryType,
            'pageConfigs' => $pageConfigs
        ]);
    }
    // public function List()
    // {
    //     $InterviewType = IndustryTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    //     return response([
    //         'status' => 200,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $InterviewType
    //     ], 200);
    // }
    public function Add(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'industry_type_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $industry_type_name = $request->industry_type_name;
            $industry_type_desc = $request->industry_type_desc;
            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            $chk = IndustryTypeModel::where('industry_type_name', ucwords($industry_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Interview Type is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = IndustryTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $industry_type_id = "IT-0001/" . $year;
                } else {

                    $data = $category_check->industry_type_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("IT-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $industry_type_id = $request . '/' . $year;
                }


                $add = new IndustryTypeModel();
                $add->industry_type_id = $industry_type_id;
                $add->industry_type_name = Ucfirst($industry_type_name);
                $add->industry_type_desc = $industry_type_desc;
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                // return $add;
                $add->save();

                if ($add) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Industry Type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Industry Type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }


    public function Update(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [
            'edit_industry_type_Name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $edit_industry_type_Id = $request->edit_industry_type_Id;
            $edit_industry_type_Name = $request->edit_industry_type_Name;
            $edit_industry_type_Desc = $request->edit_industry_type_Desc;

            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            // return $user_id;
            $upd_IndustryTypeModel = IndustryTypeModel::where('sno', $edit_industry_type_Id)->first();
            $chk = IndustryTypeModel::where('industry_type_name', ucwords($edit_industry_type_Name))
                ->where('branch_id', $branch_id)
                ->where('sno', '!=', $edit_industry_type_Id)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Industry type is exist!'
                ]);
                return redirect()->back();
            } else {


                $upd_IndustryTypeModel->industry_type_name = Ucfirst($edit_industry_type_Name);
                $upd_IndustryTypeModel->industry_type_desc = $edit_industry_type_Desc;
                $upd_IndustryTypeModel->updated_by = $user_id;
                $upd_IndustryTypeModel->update();


                if ($upd_IndustryTypeModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Industry Type Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Industry Type!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_IndustryTypeModel = IndustryTypeModel::where('sno', $id)->first();
        $upd_IndustryTypeModel->status = 2;
        $upd_IndustryTypeModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_IndustryTypeModel = IndustryTypeModel::where('sno', $id)->first();
        $upd_IndustryTypeModel->status = $request->input('status', 0);
        $upd_IndustryTypeModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
