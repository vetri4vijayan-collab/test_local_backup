<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PlacementReasonsModel;
use Illuminate\Support\Facades\Validator;

class PlacementReasons extends Controller
{
  public function index()
  {
    $PlacementReasons = PlacementReasonsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
    $pageConfigs = [ 'myLayout' => 'default' ];
    return view('content.settings.placements.placement_reasons.placement_reasons_list', [
      'PlacementReasonsList' => $PlacementReasons,
      'pageConfigs' => $pageConfigs
    ] );
  }

  public function Add( Request $request ) {

    $validator = Validator::make( $request->all(), [
      'placement_reason_name' => 'required',
      'placement_reason_score' => 'required'
    ]);

    if ( $validator->fails() ) {
      return  response( [
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get( '*' ),
        'data'      => null,
      ], 200 );
    } else {

      $placement_reason_name  = $request->placement_reason_name;
      $placement_reason_score = $request->placement_reason_score ?? 0;
      $placement_reason_desc  = $request->placement_reason_desc ?? NULL;
      $user_id                = $request->user()->user_id;
      $check_validation = PlacementReasonsModel::where('placement_reason_name', ucwords( $placement_reason_name ) )->where( 'status', '!=', 2 )->first();
      if ($check_validation) {
        session()->flash( 'toastr', [
          'type' => 'error',
          'message' => 'Placement Reasons is Already Exist!'
        ] );
        return redirect()->back();

      } else {

        $add_placement_reason = new PlacementReasonsModel();
        $add_placement_reason->placement_reason_name  = Ucfirst( $placement_reason_name );
        $add_placement_reason->placement_reason_score = $placement_reason_score;
        $add_placement_reason->placement_reason_desc  = $placement_reason_desc;
        $add_placement_reason->created_by = $user_id;
        $add_placement_reason->save();

        if ( $add_placement_reason ) {
          // If category added successfully, return success response and display Toastr message
          session()->flash( 'toastr', [
            'type' => 'success',
            'message' => 'Placement Reasons Added Successfully!'
          ] );
        } else {
          session()->flash( 'toastr', [
            'type' => 'error',
            'message' => 'Failed to add Placement Reasons.'
          ] );
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $PlacementReasonsModel_list = PlacementReasonsModel::where( 'status', '!=', 2 )->where('sno',$id)->first();
    return response( [
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $PlacementReasonsModel_list
    ], 200 );
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'placement_reason_name' => 'required',
      'placement_reason_score' => 'required'
    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $placement_reason_name  = $request->placement_reason_name;
      $placement_reason_score = $request->placement_reason_score ?? 0;
      $placement_reason_desc  = $request->placement_reason_desc ?? NULL;
      $placement_reason_id    = $request->placement_reason_id;
      $user_id            = $request->user()->user_id;

      $upd_placement_reason = PlacementReasonsModel::where('sno', $placement_reason_id)->first();

      $check_validation = PlacementReasonsModel::where('placement_reason_name', ucwords($placement_reason_name))->where('sno', '!=', $placement_reason_id)->where('status', '!=', 2)->first();

      if ($check_validation) {
        session()->flash('toastr', [
          'type'    => 'error',
          'message' => 'Placement Reasons is Already Exist!'
        ]);
        return redirect()->back();
      }

      $upd_placement_reason->placement_reason_name  = Ucfirst($placement_reason_name);
      $upd_placement_reason->placement_reason_score = $placement_reason_score;
      $upd_placement_reason->placement_reason_desc  = $placement_reason_desc;
      $upd_placement_reason->updated_by             = $user_id;
      $upd_placement_reason->update();

      if ($upd_placement_reason) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type'    => 'success',
          'message' => 'Placement Reasons Updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type'    => 'error',
          'message' => 'Failed to update Placement Reasons.'
        ]);
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_PlacementReasonsModel         = PlacementReasonsModel::where('sno', $id)->first();
    $upd_PlacementReasonsModel->status = 2;
    $upd_PlacementReasonsModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Placement Reasons Deleted Successfully!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {
    $upd_PlacementReasonsModel         = PlacementReasonsModel::where('sno', $id)->first();
    $upd_PlacementReasonsModel->status = $request->input('status', 0);
    $upd_PlacementReasonsModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Placement Reasons Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function List() {
    $PlacementReasonsModel_list = PlacementReasonsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
    return response( [
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $PlacementReasonsModel_list
    ], 200 );
  }

}
