<?php

namespace App\Http\Controllers\settings\placements;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InterviewTypeModel;
use Illuminate\Support\Facades\Validator;

class InterviewType extends Controller
{

    protected static $branch_id = 1;
    public function index()
    {

        $InterviewType = InterviewTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.placements.interview_type.interview_type', [
            'InterviewType' => $InterviewType,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $InterviewType = InterviewTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $InterviewType
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'interview_type_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {


            $interview_type_name = $request->interview_type_name;
            $interview_type_desc = $request->interview_type_desc;
            $user_id = $request->user()->user_id;
            $chk = InterviewTypeModel::where('interview_type_name', ucwords($interview_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Interview Type is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = InterviewTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $interview_type_id = "IT-0001/" . $year;
                } else {

                    $data = $category_check->interview_type_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("IT-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $interview_type_id = $request . '/' . $year;
                }


                $add_interview_type = new InterviewTypeModel();
                $add_interview_type->interview_type_id = $interview_type_id;
                $add_interview_type->interview_type_name = Ucfirst($interview_type_name);
                $add_interview_type->interview_type_desc = $interview_type_desc;
                $add_interview_type->branch_id = self::$branch_id;
                $add_interview_type->created_by = $user_id;
                $add_interview_type->updated_by = $user_id;

                $add_interview_type->save();

                if ($add_interview_type) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Interview_type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Interview_type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editinterview_type = InterviewTypeModel::where('sno', $id)->first();

        return view('content.settings.placements.interview_type.interview_type', [
            'editinterview_type' => $editinterview_type,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'interview_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $interview_type_name = $request->interview_type_name;
            $interview_type_desc = $request->interview_type_desc;
            $interview_type_id = $request->interview_type_id;

            $upd_InterviewTypeModel = InterviewTypeModel::where('sno', $interview_type_id)->first();

            $chk = InterviewTypeModel::where('interview_type_name', ucwords($interview_type_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $interview_type_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Interview type is exist!'
                ]);
                return redirect()->back();
            } else {


                $upd_InterviewTypeModel->interview_type_name = Ucfirst($interview_type_name);
                $upd_InterviewTypeModel->interview_type_desc = $interview_type_desc;
                $upd_InterviewTypeModel->update();


                if ($upd_InterviewTypeModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'InterviewType Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the InterviewType!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_InterviewTypeModel = InterviewTypeModel::where('sno', $id)->first();
        $upd_InterviewTypeModel->status = 2;
        $upd_InterviewTypeModel->Update();


        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_InterviewTypeModel = InterviewTypeModel::where('sno', $id)->first();
        $upd_InterviewTypeModel->status = $request->input('status', 0);
        $upd_InterviewTypeModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}