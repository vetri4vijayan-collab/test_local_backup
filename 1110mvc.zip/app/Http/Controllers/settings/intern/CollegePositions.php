<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CollegePositionsModel;
use Illuminate\Support\Facades\Validator;

class CollegePositions extends Controller
{
    public function index()
    {
        $CollegePositionsList = CollegePositionsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        $pageConfigs = [ 'myLayout' => 'default' ];

        return view('content.settings.intern.College.college_positions_list',[
            'CollegePositionsList' => $CollegePositionsList,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'position_name' => 'required|max:60'
        ]);

        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

        $position_name       = $request->position_name;
        $position_desc       = $request->position_desc;
        $user_id                  = $request->user()->user_id;
        $check_validation = CollegePositionsModel::where('position_name', ucwords( $position_name ) )->where( 'status', '!=', 2 )->first();
        if ($check_validation) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'College Positions is Already Exist!'
            ] );
            return redirect()->back();

        } else {

            $add_college_venue = new CollegePositionsModel();
            $add_college_venue->position_name = Ucfirst( $position_name );
            $add_college_venue->position_desc = $position_desc;
            $add_college_venue->created_by = $user_id;
            $add_college_venue->created_at = now();
            $add_college_venue->save();

            if ( $add_college_venue ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'College Positions Added Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Failed to add College Positions.'
                ] );
            }
        }
        return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editCollegeVenue = CollegePositionsModel::where('sno', $id)->first();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $editCollegeVenue
        ], 200 );
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'edit_position_id' => 'required',
            'position_name' => 'required|max:60',
        ]);

        if ($validator->fails()) {
            return   response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
            ], 200);
        } else {

        $position_name = $request->position_name;
        $position_desc = $request->position_desc;
        $edit_position_id   = $request->edit_position_id;
        $user_id            = $request->user()->user_id;

        $upd_college_venue = CollegePositionsModel::where('sno', $edit_position_id)->first();

        $check_validation = CollegePositionsModel::where('position_name', ucwords($position_name))->where('sno', '!=', $edit_position_id)->where('status', '!=', 2)->first();

        if ($check_validation) {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'College Positions is Already Exist!'
            ]);
            return redirect()->back();
        }

        $upd_college_venue->position_name = Ucfirst($position_name);
        $upd_college_venue->position_desc = $position_desc;
        $upd_college_venue->updated_by         = $user_id;
        $upd_college_venue->updated_at         = now();
        $upd_college_venue->update();

        if ($upd_college_venue) {
            // If category added successfully, return success response and display Toastr message
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'College Positions Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to update College Positions.'
            ]);
        }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_BranchTypeModel         = CollegePositionsModel::where('sno', $id)->first();
        $upd_BranchTypeModel->status = 2;
        $upd_BranchTypeModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'College Position Deleted Successfully!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        $upd_BranchTypeModel         = CollegePositionsModel::where('sno', $id)->first();
        $upd_BranchTypeModel->status = $request->input('status', 0);
        $upd_BranchTypeModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    
    public function List() {
        $CollegePositionsModel_list = CollegePositionsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();
        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $CollegePositionsModel_list
        ], 200 );
    }
}