<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CollegeModel;
use App\Models\CollegePositionsModel;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class College extends Controller
{

  protected static $temp = [];

  public function index(Request $request)
  {
      // Get all branches once
      $branches = DB::table('za_branch')->pluck('branch_name', 'sno')->toArray();

      // Get colleges
      $College = CollegeModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->get();

      // Process each college
      foreach ($College as $college) {

          $branchIds = json_decode($college->branch_id, true);

          if (is_array($branchIds)) {
              $college->branch_id_raw = implode(', ', $branchIds); // for raw ID output
              $branchNames = array_map(fn($id) => $branches[$id] ?? '-', $branchIds);
              $college->branch_name = implode(', ', $branchNames);
          } else {
              $college->branch_id_raw = $college->branch_id;
              $college->branch_name = $branches[$college->branch_id] ?? '-';
          }

          $spoc_details = isset($college->spoc_details) && !empty($college->spoc_details) ? json_decode($college->spoc_details, true) : [];

          $options_list = $this->flattenHRData($spoc_details);

          $spoc_list = [];

          foreach ($options_list as $item) {
            $spoc_list[] = [
              'spoc_name'           => $item['spoc_name'] ?? '',
              'spoc_mob_no'         => $item['spoc_mob_no'] ?? '',
              'spoc_position'       => $item['spoc_position'] ?? '',
              'spoc_position_name'  => isset($item['spoc_position']) ? self::getCollegePositionName($item['spoc_position']) : ''
            ];
          }

        $college->spoc_details = !empty($spoc_list) ? json_encode($spoc_list) : null;
      }

      // return $College;

      $pageConfigs = ['myLayout' => 'default'];

      return view('content.settings.intern.College.college_list', [
          'College' => $College,
          'pageConfigs' => $pageConfigs
      ]);
  }

  public function List()
  {
    $College = CollegeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // return $College;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $College
    ], 200);
  }

  public function Add(Request $request)
  {
    //return $request;
    $validator = Validator::make($request->all(), [
      'college_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $college_name     = $request->college_name;
      // $college_mobile   = $request->college_mob_no;
      // $college_mail_id  = $request->college_mail_id;
      // $authority_name   = $request->auth_name;
      // $authority_mobile = $request->auth_mob_no;
      $branchId         = $request->branchId;
      $college_desc     = $request->college_desc;
      $user_id          = $request->user()->user_id;
      // return $branchId;
      // $chk = CollegeModel::where('college_name', ucwords($college_name))->where('branch_id', $branchId)->where('status', '!=', 2)->first();
       
      // if ($chk) {
      //   session()->flash('toastr', [
      //     'type' => 'error',
      //     'message' => 'Name has been  already created!'
      //   ]);
      // } else {
      $chk = CollegeModel::where('college_name', ucwords($college_name))
          ->where('status', '!=', 2)
          ->get()
          ->first(function ($item) use ($branchId) {
              $branchIds = json_decode($item->branch_id, true);
              return (is_array($branchIds) ? $branchIds : []);
          });


      if ($chk) {
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Name has already been created for this branch!'
          ]);
      }
      else {
        // Proceed with save/create
    
        $user_details   = $request->input('spoc_details');
        // Process HR details
        $deliverablesJson = null;

        if (is_array($user_details)) {
          $indexed_options = [];
          foreach ($user_details as $index => $value) {
            if ($value !== '') {
                $indexed_options[] = [
                    (string)((int)$index + 1) => $value
                ];
            }
          }
          $deliverablesJson = json_encode($indexed_options);
        }

        // $add_category->job_category_id         = $job_category_id;
        $add_category = new CollegeModel();
        $add_category->college_name     = Ucfirst($college_name);
        // $add_category->college_mobile   = $college_mobile;
        // $add_category->college_mail_id  = $college_mail_id;
        // $add_category->authority_name   = $authority_name;
        // $add_category->authority_mobile = $authority_mobile;
        $add_category->branch_id        = json_encode($branchId);
        $add_category->spoc_details          = $deliverablesJson;
        $add_category->college_desc     = $college_desc;
        $add_category->created_by       = $user_id;
        $add_category->updated_by       = $user_id;
        // return $add_category;
        $add_category->save();
        
        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'College Successfully added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the college!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editcategory = CollegeModel::where('sno', $id)->first();
    $spoc_details = isset($editcategory->spoc_details) && !empty($editcategory->spoc_details) ? json_decode($editcategory->spoc_details, true) : [];
    $options_list = $this->flattenHRData($spoc_details);
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory,
      'spoc_details'      => $options_list
    ], 200);
  }

  // public function Update(Request $request)
  // {
    
  //   // return $request;
  //   $id=$request->id;
  //   // return $request;
  //   $validator = Validator::make($request->all(), [
  //     'college_name' => 'required|max:255',
  //   ]);

  //   if ($validator->fails()) {
  //     return response([
  //       'status'    => 401,
  //       'message'   => 'Incorrect format input fields',
  //       'error_msg' => $validator->messages()->get('*'),
  //       'data'      => null,
  //     ], 401);
  //   }

  //     $college_name = $request->college_name;
  //     $college_desc = $request->college_desc;
  //     $branchId       = $request->branchId;
  //     $id = $request->id;

  //     $upd_ReviewLinkModel =  CollegeModel::where('sno', $id)->first();
  //     // return $upd_ReviewLinkModel;

  //     if (!$upd_ReviewLinkModel) {
  //       return response([
  //         'status'    => 404,
  //         'message'   => 'college not found',
  //         'error_msg' => null,
  //         'data'      => null,
  //       ], 200);
  //     }

  //      else {

  //       $upd_ReviewLinkModel->college_name = ucfirst($college_name);
  //       $upd_ReviewLinkModel->college_desc = $college_desc;
  //       $upd_ReviewLinkModel->branch_id = json_encode($branchId);

  //       $upd_ReviewLinkModel->save();
  //       return response([
  //         'status'    => 200,
  //         'message'   => 'Successfully Updated!',
  //         'error_msg' => null,
  //         'data'      => null,
  //       ], 200);
  //     }
  // }

  public function Update(Request $request)
  {
      // return $request;

      $validator = Validator::make($request->all(), [
        'college_name' => 'required|max:255',
        'college_mob_no' => 'required',
        'college_mail_id' => 'required',
        // 'auth_name' => 'required',
        // 'auth_mob_no' => 'required',
      ]);

      if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
          ], 401);
      }

      $id = $request->id;
      $college_name = $request->college_name;
      $college_mobile   = $request->college_mob_no;
      $college_mail_id  = $request->college_mail_id;
      // $authority_name   = $request->auth_name;
      // $authority_mobile = $request->auth_mob_no;
      $college_desc = $request->college_desc;
      $branchId = $request->branch_id; // 👈 Ensure this matches frontend

      $college = CollegeModel::where('sno', $id)->first();

      if (!$college) {
          return response([
              'status'    => 404,
              'message'   => 'College not found',
              'error_msg' => null,
              'data'      => null,
          ], 404);
      }

      $user_details   = $request->input('spoc_details');

      // Process HR details
      $deliverablesJson = null;

      if (is_array($user_details)) {
        $indexed_options = [];
        foreach ($user_details as $index => $value) {
          if ($value !== '') {
              $indexed_options[] = [
                  (string)((int)$index) => $value
              ];
          }
        }
        $deliverablesJson = json_encode($indexed_options);
      }

      $college->college_name = ucfirst($college_name); // Or Str::title($college_name)
      $college->college_mobile   = $college_mobile;
      $college->college_mail_id  = $college_mail_id;
      // $college->authority_name   = $authority_name;
      // $college->authority_mobile = $authority_mobile;
      $college->spoc_details     = $deliverablesJson;
      $college->college_desc = $college_desc;
      $college->branch_id = json_encode($branchId);
      $college->save();

      return response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
      ], 200);
  }

  public function Delete($id)
  {
    $upd_ReviewLinkModel =  CollegeModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status  = 2;
    $upd_ReviewLinkModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_ReviewLinkModel =  CollegeModel::where('sno', $id)->first();
    $upd_ReviewLinkModel->status = $request->input('status', 0);
    $upd_ReviewLinkModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  private function flattenHRData($input)
  {
    $result = [];
    foreach ($input as $item) {
      foreach ($item as $key => $details) {
        $result[$key] = $details;  // append inner arrays
      }
    }
    return $result;
  }

  private static function getCollegePositionName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['CollegePositionName'])) {
      self::$temp['CollegePositionName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['CollegePositionName'][$id])) {
      $state = CollegePositionsModel::select(['position_name'])->where('sno', $id)->first();
      self::$temp['CollegePositionName'][$id] = $state ? $state->position_name : null;
    }
    return self::$temp['CollegePositionName'][$id];
  }

}
