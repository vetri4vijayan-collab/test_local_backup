<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LetterPadModel;
use Illuminate\Support\Facades\Validator;

class LetterPad extends Controller
{
   

    public function index()
    {
        $letterPad = LetterPadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.intern.letter_pad.letter_pad_list', [
            'letterPad' => $letterPad,
            'pageConfigs' => $pageConfigs
        ]);
    }

    // public function List()
    // {
    //     $letterPad = LetterPadModel::where('status', 0)->orderBy('sno', 'desc')->get();

    //     return  response([
    //         'status'    => 200,
    //         'message'   => null,
    //         'error_msg' => null,
    //         'data'      => $letterPad
    //     ], 200);
    // }
   
    public function List(Request $request)
    {
        $branch_id = (string) $request->user()->branch_id;
    
        $allPads = LetterPadModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
    
        $filtered = $allPads->filter(function ($item) use ($branch_id) {
            $branchIds = json_decode($item->branch_id, true); // decode the string
            return in_array((string)$branch_id, $branchIds ?? []);
        });
    
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $filtered->values()
        ], 200);
    }


    // public function Add(Request $request)
    // {
    //     // return $request;
    //     $validator = Validator::make($request->all(), [
    //         'company' => 'required|max:255'
    //     ]);
    //     if ($validator->fails()) {
    //         return  response([
    //             'status'    => 401,
    //             'message'   => 'Incorrect format input feilds',
    //             'error_msg' => $validator->messages()->get('*'),
    //             'data'      => null,
    //         ], 200);
    //     } else {

    //         $company       = $request->company;
    //         $email         = $request->email;
    //         $logo_size     = $request->logo_size;
    //         $letter_desc   = $request->letter_desc;


    //         $user_id       = $request->user()->user_id;


    //         $staff_check = LetterPadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    //         $sno = $staff_check ? $staff_check->sno + 1 : 1;
    //         $header_image = '';
    //         $footer_image = '';
    //         $logo_image = '';
    //         $signature = '';


    //         // return $sno;
    //         // // Handle image upload
    //         if ($request->hasFile('header_image')) {       
    //         // Generate unique file name        
    //             $imageName = 'header_' . $sno . '.' . $request->file('header_image')->extension();
    //             // Move the file to public/potential_image folder
    //             // return $imageName;
    //             $request->file('header_image')->move(public_path('header_image'), $imageName);
    //             $header_image = $imageName;
    //         }

    //         if ($request->hasFile('footer_image')) {       
    //         // Generate unique file name        
    //             $imageName = 'footer_' . $sno . '.' . $request->file('footer_image')->extension();
    //             // Move the file to public/potential_image folder
    //             // return $imageName;
    //             $request->file('footer_image')->move(public_path('footer_image'), $imageName);
    //             $footer_image = $imageName;
    //         }

    //         if ($request->hasFile('logo_image')) {       
    //         // Generate unique file name        
    //             $imageName = 'logo_' . $sno . '.' . $request->file('logo_image')->extension();
    //             // Move the file to public/potential_image folder
    //             // return $imageName;
    //             $request->file('logo_image')->move(public_path('logo_image'), $imageName);
    //             $logo_image = $imageName;
    //         }

    //          if ($request->hasFile('signature')) {       
    //         // Generate unique file name        
    //             $imageName = 'signature_' . $sno . '.' . $request->file('signature')->extension();
    //             // Move the file to public/potential_image folder
    //             // return $imageName;
    //             $request->file('signature')->move(public_path('signature'), $imageName);
    //             $signature = $imageName;
    //         }
    //         $chk = LetterPadModel::where('company', ucwords($company))->where('status', '!=', 2)->first();

    //         if ($chk) {

    //             $result = response([
    //                 'status'    => 401,
    //                 'message'   => 'Error',
    //                 'error_msg' => 'Name has been  already created!',
    //                 'data'      => null,
    //             ], 200);
    //         } else {
    //             $category_check = LetterPadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

    //             if (!$category_check) {

    //                 $year = substr(date('y'), -2);
    //                 // $topic_id = 'LS-0001/' . $year;
    //             } else {

    //             //     $data = $category_check->topic_id;
    //             //     $slice = explode('/', $data);
    //             //     $result = preg_replace('/[^0-9]/', '', $slice[0]);

    //             //     $next_number = (int)$result + 1;
    //             //     $request = sprintf('LS-%04d', $next_number);

    //             //     $year = substr(date('y'), -2);
    //             //     $topic_id = $request . '/' . $year;
    //             // }

    //             $add_letter = new LetterPadModel();
    //             // $add_ai->topic_id         = $topic_id;
    //             $add_letter->company               = Ucfirst($company);
    //             $add_letter->letter_pad_desc       = $letter_desc;
    //             $add_letter->email                 = $email;
    //             $add_letter->letter_header                 = $header_image;
    //             $add_letter->letter_footer                 = $footer_image;
    //             $add_letter->letter_logo                 = $logo_image;
    //             $add_letter->signature                 = $signature;
    //             // $add_ai->branch_id = self::$branch_id;
    //             $add_letter->created_by                 = $user_id;
    //             $add_letter->updated_by                 = $user_id;

    //             $add_letter->save();

    //             if ($add_letter) {
    //                 // If category added successfully, return success response and display Toastr message
    //                 session()->flash('toastr', [
    //                     'type' => 'success',
    //                     'message' => 'Company added Successfully!'
    //                 ]);
    //             } else {
    //                 session()->flash('toastr', [
    //                     'type' => 'error',
    //                     'message' => 'Could not add the Company!'
    //                 ]);
    //             }
    //         }
    //     }
    //         return redirect()->back();
    //     }
    // }

    public function Add(Request $request)
{
    // Validate required inputs
    $validator = Validator::make($request->all(), [
        'company' => 'required|max:255',
        'email' => 'nullable|email',
        // You can add validation for images if needed like:
        // 'header_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // 'footer_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // 'logo_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // 'signature' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $company     = $request->company;
    $email       = $request->email;
     $phone       = $request->phone;
    $letter_desc = $request->letter_desc;
    $logo_width = $request->logo_width;
    $logo_height = $request->logo_height;

    $branchId = $request->branchId;
    $user_id     = $request->user()->user_id;

    // Check for the latest serial number
    $latestRecord = LetterPadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $sno = $latestRecord ? $latestRecord->sno + 1 : 1;

    // Check if company already exists
    $existingCompany = LetterPadModel::where('company', ucwords($company))
                        ->where('status', '!=', 2)
                        ->first();

    if ($existingCompany) {
        return response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been created!',
            'data'      => null,
        ], 200);
    }

    // Initialize image variables
    $header_image = null;
    $footer_image = null;
    $logo_image = null;
    $signature = null;

    // Handle image uploads
    if ($request->hasFile('header_image')) {
        $header_image = 'header_' . $sno . '.' . $request->file('header_image')->extension();
        $request->file('header_image')->move(public_path('header_image'), $header_image);
    }

    if ($request->hasFile('footer_image')) {
        $footer_image = 'footer_' . $sno . '.' . $request->file('footer_image')->extension();
        $request->file('footer_image')->move(public_path('footer_image'), $footer_image);
    }

    if ($request->hasFile('logo_image')) {
        $logo_image = 'logo_' . $sno . '.' . $request->file('logo_image')->extension();
        $request->file('logo_image')->move(public_path('logo_image'), $logo_image);
    }

    if ($request->hasFile('signature')) {
        $signature = 'signature_' . $sno . '.' . $request->file('signature')->extension();
        $request->file('signature')->move(public_path('signature'), $signature);
    }

    // Save new LetterPadModel record
    $add_letter = new LetterPadModel();
    $add_letter->company         = ucfirst($company);
    $add_letter->letter_pad_desc = $letter_desc;
     $add_letter->branch_id           = json_encode($branchId);
    $add_letter->logo_width = $logo_width;
    $add_letter->logo_height = $logo_height;
    $add_letter->email           = $email;
    $add_letter->phone           = $phone;
    $add_letter->letter_header   = $header_image;
    $add_letter->letter_footer   = $footer_image;
    $add_letter->letter_logo     = $logo_image;
    $add_letter->signature       = $signature;
    $add_letter->created_by      = $user_id;
    $add_letter->updated_by      = $user_id;

    if ($add_letter->save()) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Company added Successfully!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Company!'
        ]);
    }

    return redirect()->back();
}


    public function Edit($id)
    {
        $editcategory = LetterPadModel::where('sno', $id)->first();

        return view('content.settings.intern.letter_pad.letter_pad_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    // public function Update(Request $request)
    // {
    // //    return $request;
    //     $validator = Validator::make($request->all(), [
    //         'company' => 'required|max:255',

    //     ]);

    //     if ($validator->fails()) {
    //         return   response([
    //             'status'    => 401,
    //             'message'   => 'Incorrect format input feilds',
    //             'error_msg'     => $validator->messages()->get('*'),
    //             'data'      => null,
    //         ], 200);
    //     } else {

    //         $company       = $request->company;
    //         $letter_pad_desc       = $request->letter_pad_desc;
    //         $company_id        = $request->company_id;
    //         $email        = $request->email;
    //         $logo_width        = $request->logo_width;
    //         $logo_height        = $request->logo_height;

            
    //         $edit_id = $request->company_id;
    //         // Handle staff image upload
    //         $header_image = '';
    //         if ($request->hasFile('header_image')) {
    //         $staff_imageName = 'header_' . $edit_id . '.' . $request->file('header_image')->extension();
    //         $request->file('header_image')->move(public_path('header_image'), $staff_imageName);
    //         $header_image = $staff_imageName;
    //         } 


    //          // Handle staff image upload
    //         $footer_image = '';
    //         if ($request->hasFile('footer_image')) {
    //         $staff_imageName = 'footer_' . $edit_id . '.' . $request->file('footer_image')->extension();
    //         $request->file('footer_image')->move(public_path('footer_image'), $staff_imageName);
    //         $footer_image = $staff_imageName;
    //         } 

    //           // Handle staff image upload
    //         $logo_image = '';
    //         if ($request->hasFile('logo_image')) {
    //         $staff_imageName = 'logo_' . $edit_id . '.' . $request->file('logo_image')->extension();
    //         $request->file('logo_image')->move(public_path('logo_image'), $staff_imageName);
    //         $logo_image = $staff_imageName;
    //         } 

    //           // Handle staff image upload
    //         $signature = '';
    //         if ($request->hasFile('signature')) {
    //         $staff_imageName = 'signature_' . $edit_id . '.' . $request->file('signature')->extension();
    //         $request->file('signature')->move(public_path('signature'), $staff_imageName);
    //         $signature = $staff_imageName;
    //         } 

            
    //         $upd_CourseCategoryModel =  LetterPadModel::where('sno', $company_id)->first();

    //         $chk = LetterPadModel::where('company', ucwords($company))->where('status', '!=', 2)->first();

    //         if ($chk) {
    //             if ($chk->sno != $company_id) {
    //                 session()->flash('toastr', [
    //                     'type' => 'error',
    //                     'message' => 'Name has been  already assigned!'
    //                 ]);
    //             } else {
    //             }
    //         }

    //         $upd_CourseCategoryModel->company  = Ucfirst($company);
    //         $upd_CourseCategoryModel->letter_pad_desc  = $letter_pad_desc;
    //         $upd_CourseCategoryModel->email  = $email;
    //         $upd_CourseCategoryModel->letter_header  = $header_image;
    //         $upd_CourseCategoryModel->letter_footer  = $footer_image;
    //         $upd_CourseCategoryModel->letter_logo  = $logo_image;
    //         $upd_CourseCategoryModel->signature  = $signature;
    //         $upd_CourseCategoryModel->logo_height  = $logo_height;
    //         $upd_CourseCategoryModel->logo_width  = $logo_width;


           
    //     //    return $upd_CourseCategoryModel;

    //         $upd_CourseCategoryModel->update();

    //         if ($upd_CourseCategoryModel) {
    //             // If category added successfully, return success response and display Toastr message
    //             session()->flash('toastr', [
    //                 'type' => 'success',
    //                 'message' => 'Company Update Successfully!'
    //             ]);
    //         } else {
    //             session()->flash('toastr', [
    //                 'type' => 'error',
    //                 'message' => 'Could not Update the Company!'
    //             ]);
    //         }
    //     }
    //     return redirect()->back();
    // }


    public function Update(Request $request)
{
    // Validation rules including optional image validations
    $validator = Validator::make($request->all(), [
        'company'       => 'required|max:255',
        'email'         => 'nullable|email|max:255',
        'logo_width'    => 'nullable|integer|min:1',
        'logo_height'   => 'nullable|integer|min:1',
        'header_image'  => 'nullable|image|mimes:jpeg,png,jpg|max:800',  // max size in KB
        'footer_image'  => 'nullable|image|mimes:jpeg,png,jpg|max:800',
        'logo_image'    => 'nullable|image|mimes:jpeg,png,jpg|max:800',
        'signature_image'=> 'nullable|image|mimes:jpeg,png,jpg|max:800',
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    // Extract inputs
    $company = $request->company;
    $letter_pad_desc = $request->letter_pad_desc;
    $company_id = $request->company_id;
    $email = $request->email;
     $phone = $request->phone;
    $logo_width = $request->logo_width;
    $logo_height = $request->logo_height;
    $edit_id = $company_id;
    $branchId = $request->branchId;

    // Check duplicate company name except current record
    $chk = LetterPadModel::where('company', ucwords($company))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $company_id)
            ->first();

    if ($chk) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Name has already been assigned!'
        ]);
        return redirect()->back();
    }

    // Fetch existing model record
    $upd_CourseCategoryModel = LetterPadModel::where('sno', $company_id)->first();

    if (!$upd_CourseCategoryModel) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Company record not found!'
        ]);
        return redirect()->back();
    }

    // Update basic fields
    $upd_CourseCategoryModel->company = ucfirst($company);
    $upd_CourseCategoryModel->phone = $phone;
    $upd_CourseCategoryModel->letter_pad_desc = $letter_pad_desc;
    $upd_CourseCategoryModel->email = $email;
    $upd_CourseCategoryModel->branch_id           = json_encode($branchId);
    $upd_CourseCategoryModel->logo_height = $logo_height;
    $upd_CourseCategoryModel->logo_width = $logo_width;

    // Handle header image upload
    if ($request->hasFile('header_image')) {
        $fileName = 'header_' . $edit_id . '.' . $request->file('header_image')->extension();
        $request->file('header_image')->move(public_path('header_image'), $fileName);
        $upd_CourseCategoryModel->letter_header = $fileName;
    }

    // Handle footer image upload
    if ($request->hasFile('footer_image')) {
        $fileName = 'footer_' . $edit_id . '.' . $request->file('footer_image')->extension();
        $request->file('footer_image')->move(public_path('footer_image'), $fileName);
        $upd_CourseCategoryModel->letter_footer = $fileName;
    }

    // Handle logo image upload
    if ($request->hasFile('logo_image')) {
        $fileName = 'logo_' . $edit_id . '.' . $request->file('logo_image')->extension();
        $request->file('logo_image')->move(public_path('logo_image'), $fileName);
        $upd_CourseCategoryModel->letter_logo = $fileName;
    }

    // Handle signature image upload
    if ($request->hasFile('signature_image')) {
        $fileName = 'signature_' . $edit_id . '.' . $request->file('signature_image')->extension();
        $request->file('signature_image')->move(public_path('signature'), $fileName);
        $upd_CourseCategoryModel->signature = $fileName;
    }

    // Save the updated model
    $updated = $upd_CourseCategoryModel->update();

    if ($updated) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Company Updated Successfully!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Company!'
        ]);
    }

    return redirect()->back();
}


    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LetterPadModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Company Successfully Deleted!',
            'error_msg' => 'Could not Delete Company!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LetterPadModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
