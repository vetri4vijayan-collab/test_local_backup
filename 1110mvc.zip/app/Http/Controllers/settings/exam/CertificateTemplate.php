<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\CertificateTemplateModel;

class CertificateTemplate extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $certificate_template = CertificateTemplateModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.exam.certificate_template.certificate_template_list', [
            'certificate_template' => $certificate_template,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_CertificateTemplateModel =  CertificateTemplateModel::where('sno', $id)->first();
        $upd_CertificateTemplateModel->status = $request->input('status', 0);
        $upd_CertificateTemplateModel->update();
        if ($upd_CertificateTemplateModel) {
            return response([
                'status'    => 200,
                'message'   => 'Certificate Template  Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Certificate Template  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Certificate Template  Status!',
                'error_msg' => 'Could not ,update  Certificate Template  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_CertificateTemplateModel =  CertificateTemplateModel::where('sno', $id)->first();
        $upd_CertificateTemplateModel->status  = 2;
        $upd_CertificateTemplateModel->Update();
        if ($upd_CertificateTemplateModel) {
            return response([
                'status'    => 200,
                'message'   => 'Certificate Template  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Certificate Template !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'certificate_template_name' => 'required|max:255',
            'certificate_template_file' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $certificate_template_name = $request->certificate_template_name;
        $certificate_template_file = $request->certificate_template_file;
        $certificate_template_desc = $request->certificate_template_desc;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = CertificateTemplateModel::where('certificate_template_name', ucwords($certificate_template_name))
            ->where('branch_id', self::$branch_id)
            ->where('certificate_template_file', ucwords($certificate_template_file))->where('status', '!=', 2)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Certificate Template has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = CertificateTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $certificate_template_id = 'CT-0001/' . $year;
            } else {
                $data = $category_check->certificate_template_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('CT-%04d', $next_number);
                $year = substr(date('y'), -2);
                $certificate_template_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new CertificateTemplateModel();
            $add->certificate_template_id = $certificate_template_id;
            $add->certificate_template_name = ucfirst($certificate_template_name);
            $add->certificate_template_file = ucfirst($certificate_template_file);
            $add->certificate_template_desc = $certificate_template_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Certificate Template  added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Certificate Template !'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'certificate_template_id' => 'required|max:255',
            'certificate_template_name_edit' => 'required|max:255',
            'certificate_template_file_edit' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $certificate_template_name = $request->certificate_template_name_edit;
        $certificate_template_file = $request->certificate_template_file_edit;
        $certificate_template_desc = $request->certificate_template_desc_edit;
        $certificate_template_id   = $request->certificate_template_id;

        $upd_certificate_template = CertificateTemplateModel::find($certificate_template_id);

        if (!$upd_certificate_template) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Certificate Template  not found!'
            ]);
            return redirect()->back();
        }

        $chk = CertificateTemplateModel::where('certificate_template_name', ucwords($certificate_template_name))
            ->where('branch_id', self::$branch_id)
            ->where('certificate_template_file', ucwords($certificate_template_file))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $certificate_template_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Certificate Template has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_certificate_template->certificate_template_name = ucfirst($certificate_template_name);
        $upd_certificate_template->certificate_template_file = ucfirst($certificate_template_file);
        $upd_certificate_template->certificate_template_desc = $certificate_template_desc;
        $upd_certificate_template->save();

        if ($upd_certificate_template) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Certificate Template updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Certificate Template !'
            ]);
        }

        return redirect()->back();
    }
}