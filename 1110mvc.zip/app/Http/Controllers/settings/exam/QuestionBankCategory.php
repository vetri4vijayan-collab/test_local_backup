<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\QuestionBankCategoryModel;

class QuestionBankCategory extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $question_bank_category = QuestionBankCategoryModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.exam.question_bank_category.question_bank_category_list', [
            'question_bank_category' => $question_bank_category,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  QuestionBankCategoryModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Question Bank Category Status Successfully Updated!',
            'error_msg' => 'Could not ,update  Question Bank Category Status!',
            'data'      => null,
        ], 200);
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  QuestionBankCategoryModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();
        if ($upd_CourseCategoryModel) {
            return response([
                'status'    => 200,
                'message'   => 'Question Bank Category Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Question Bank Category!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question_bank_category_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $question_bank_category_name = $request->question_bank_category_name;
        $question_bank_category_desc = $request->question_bank_category_desc;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = QuestionBankCategoryModel::where('question_bank_category_name', ucwords($question_bank_category_name))
            ->where('status', '!=', 2)
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = QuestionBankCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $question_bank_category_id = 'QC-0001/' . $year;
            } else {
                $data = $category_check->question_bank_category_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('QC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $question_bank_category_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add_category = new QuestionBankCategoryModel();
            $add_category->question_bank_category_id = $question_bank_category_id;
            $add_category->question_bank_category_name = ucfirst($question_bank_category_name);
            $add_category->question_bank_category_desc = $question_bank_category_desc;
            $add_category->branch_id = self::$branch_id;
            $add_category->created_by = $user_id;
            $add_category->updated_by = $user_id;

            $add_category->save();

            if ($add_category) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Question Bank Category added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Question Bank Category!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'question_bank_category_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $question_bank_category_name = $request->question_bank_category_name;
        $question_bank_category_desc = $request->question_bank_category_desc;
        $question_bank_category_id = $request->editQuestionbankcategory_id;

        $upd_question_bank_category = QuestionBankCategoryModel::find($question_bank_category_id);

        if (!$upd_question_bank_category) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category not found!'
            ]);
            return redirect()->back();
        }

        $chk = QuestionBankCategoryModel::where('question_bank_category_name', ucwords($question_bank_category_name))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $question_bank_category_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Category has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_question_bank_category->question_bank_category_name = ucfirst($question_bank_category_name);
        $upd_question_bank_category->question_bank_category_desc = $question_bank_category_desc;
        $upd_question_bank_category->save();

        if ($upd_question_bank_category) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Category updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Question Bank Category!'
            ]);
        }

        return redirect()->back();
    }
}