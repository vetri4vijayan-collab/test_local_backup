<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\QuestionBankTypeModel;

class QuestionBankType extends Controller
{
    protected static $branch_id = 2;

    public function index()
    {
        $question_bank_type = QuestionBankTypeModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.exam.question_bank_type.question_bank_type_list', [
            'question_bank_type' => $question_bank_type,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  QuestionBankTypeModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Question Bank Type Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Question Bank Type Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Question Bank Type Status!',
                'error_msg' => 'Could not ,update  Question Bank Type Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_CourseTypeModel =  QuestionBankTypeModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Question Bank Type Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Question Bank Type!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question_bank_type_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $question_bank_type_name = $request->question_bank_type_name;
        $question_bank_type_desc = $request->question_bank_type_desc;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = QuestionBankTypeModel::where('question_bank_type_name', ucwords($question_bank_type_name))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = QuestionBankTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $question_bank_type_id = 'QT-0001/' . $year;
            } else {
                $data = $category_check->question_bank_type_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('QT-%04d', $next_number);
                $year = substr(date('y'), -2);
                $question_bank_type_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add_type = new QuestionBankTypeModel();
            $add_type->question_bank_type_id = $question_bank_type_id;
            $add_type->question_bank_type_name = ucfirst($question_bank_type_name);
            $add_type->question_bank_type_desc = $question_bank_type_desc;
            $add_type->created_by = $user_id;
            $add_type->updated_by = $user_id;
            $add_type->branch_id = self::$branch_id;

            $add_type->save();

            if ($add_type) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Question Bank Type added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Question Bank Type!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'editquestion_bank_type_id' => 'required|max:255',
            'question_bank_type_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $question_bank_type_name = $request->question_bank_type_name;
        $question_bank_type_desc = $request->question_bank_type_desc;
        $question_bank_type_id = $request->editquestion_bank_type_id;

        $upd_question_bank_type = QuestionBankTypeModel::find($question_bank_type_id);

        if (!$upd_question_bank_type) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type not found!'
            ]);
            return redirect()->back();
        }

        $chk = QuestionBankTypeModel::where('question_bank_type_name', ucwords($question_bank_type_name))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $question_bank_type_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question Bank Type has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_question_bank_type->question_bank_type_name = ucfirst($question_bank_type_name);
        $upd_question_bank_type->question_bank_type_desc = $question_bank_type_desc;
        $upd_question_bank_type->save();

        if ($upd_question_bank_type) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Question Bank Type updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Question Bank Type!'
            ]);
        }

        return redirect()->back();
    }
}