<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\TypeofExamModel;

class TypeofExam extends Controller
{
    public function index()
    {
        $type_of_exam = TypeofExamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.exam.type_of_exam.type_of_exam_list', [
            'type_of_exam' => $type_of_exam,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_TypeofExamModel =  TypeofExamModel::where('sno', $id)->first();
        $upd_TypeofExamModel->status = $request->input('status', 0);
        $upd_TypeofExamModel->update();
        if ($upd_TypeofExamModel) {
            return response([
                'status'    => 200,
                'message'   => 'Type  Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Type  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Type  Status!',
                'error_msg' => 'Could not ,update  Type  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_TypeofExamModel =  TypeofExamModel::where('sno', $id)->first();
        $upd_TypeofExamModel->status  = 2;
        $upd_TypeofExamModel->Update();
        if ($upd_TypeofExamModel) {
            return response([
                'status'    => 200,
                'message'   => 'Type  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Type !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type_of_exam_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $type_of_exam_name = $request->type_of_exam_name;
        $type_of_exam_desc = $request->type_of_exam_desc;
        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = TypeofExamModel::where('type_of_exam_name', ucwords($type_of_exam_name))
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type Of Exam has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = TypeofExamModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $type_of_exam_id = 'TE-0001/' . $year;
            } else {
                $data = $category_check->type_of_exam_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('TE-%04d', $next_number);
                $year = substr(date('y'), -2);
                $type_of_exam_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add_type = new TypeofExamModel();
            $add_type->type_of_exam_id = $type_of_exam_id;
            $add_type->type_of_exam_name = ucfirst($type_of_exam_name);
            $add_type->type_of_exam_desc = $type_of_exam_desc;
            $add_type->created_by = $user_id;
            $add_type->updated_by = $user_id;

            $add_type->save();

            if ($add_type) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Type  added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Type !'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'edittype_of_exam_id' => 'required|max:255',
            'type_of_exam_name' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        $type_of_exam_name = $request->type_of_exam_name;
        $type_of_exam_desc = $request->type_of_exam_desc;
        $type_of_exam_id = $request->edittype_of_exam_id;

        $upd_type_of_exam = TypeofExamModel::find($type_of_exam_id);

        if (!$upd_type_of_exam) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type  not found!'
            ]);
            return redirect()->back();
        }

        $chk = TypeofExamModel::where('type_of_exam_name', ucwords($type_of_exam_name))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $type_of_exam_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Type  has already been created!'
            ]);
            return redirect()->back();
        }

        $upd_type_of_exam->type_of_exam_name = ucfirst($type_of_exam_name);
        $upd_type_of_exam->type_of_exam_desc = $type_of_exam_desc;
        $upd_type_of_exam->save();

        if ($upd_type_of_exam) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Type of exam updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Type of exam !'
            ]);
        }

        return redirect()->back();
    }
}