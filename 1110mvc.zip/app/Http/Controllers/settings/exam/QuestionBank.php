<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QuestionBank extends Controller
{
  public function index()
  {
    return view('content.settings.exam.question_bank.question_bank_list');
  }
  public function question_bank_add()
  {
    return view('content.settings.exam.question_bank.question_bank_add');
  }
  public function question_bank_edit()
  {
    return view('content.settings.exam.question_bank.question_bank_edit');
  }
}
