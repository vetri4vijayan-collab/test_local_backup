<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Exam_guidelinesModel;

class Exam_guidelines extends Controller {
    public function index() {
        $exam_guidelines = Exam_guidelinesModel::where( 'status', '!=', 2 )->where( 'sno', 1 )->orderBy( 'sno', 'desc' )->first();
        return view( 'content.settings.exam.exam_guidelines.exam_guidelines_list', [
            'exam_guidelines' => $exam_guidelines
        ] );
    }

    public function Update( Request $request ) {

        // return $request;
        $validator = Validator::make( $request->all(), [
            'exam_guidelines_sno' => 'required|max:255',
        ] );

        if ( $validator->fails() ) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ] );
            return redirect()->back();
        }

        $exam_guidelines    = $request->exam_guidelines;
        $exam_guideline_sno = $request->exam_guidelines_sno;
        $user = $request->user()->user_id;

        $upd_exam_guidelines = Exam_guidelinesModel::find( $exam_guideline_sno );

        if ( !$upd_exam_guidelines ) {
            session()->flash( 'toastr', [
                'type' => 'error',
                'message' => 'Exam Guidelines  not found!'
            ] );
            return redirect()->back();
        }
        $upd_exam_guidelines->exam_guidelines =  $exam_guidelines;
        $upd_exam_guidelines->updated_by =  $user;
        $upd_exam_guidelines->save();

        if ( $upd_exam_guidelines ) {
            return response( [
                'status'    => 200,
                'message'   => 'Exam Guidelines updated Successfully!',
                'data'      => $upd_exam_guidelines,
            ], 200 );
        } else {
            return response( [
                'status'    => 200,
                'message'   => 'Could not update Batch!',
                'data'      => null,
            ], 200 );
        }

        return redirect()->back();
    }
}