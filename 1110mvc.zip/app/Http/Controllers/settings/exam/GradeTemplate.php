<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\GradeTemplateModel;

class GradeTemplate extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $grade_template = GradeTemplateModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.exam.grade_template.grade_template_list', [
            'grade_template' => $grade_template,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function Status($id, Request $request)
    {

        $upd_GradeTemplateModel =  GradeTemplateModel::where('sno', $id)->first();
        $upd_GradeTemplateModel->status = $request->input('status', 0);
        $upd_GradeTemplateModel->update();
        if ($upd_GradeTemplateModel) {
            return response([
                'status'    => 200,
                'message'   => 'Grade Template  Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Grade Template  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Grade Template  Status!',
                'error_msg' => 'Could not ,update  Grade Template  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $upd_GradeTemplateModel =  GradeTemplateModel::where('sno', $id)->first();
        $upd_GradeTemplateModel->status  = 2;
        $upd_GradeTemplateModel->Update();
        if ($upd_GradeTemplateModel) {
            return response([
                'status'    => 200,
                'message'   => 'Grade Template  Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Grade Template !',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'grade_template_name' => 'required|max:255',
            'grade_name' => 'required|max:255',
            'grade_min_value' => 'required|max:255',
            'grade_max_value' => 'required|max:255',
            'grade_logo' => 'required|max:255',
            'grade_color' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $grade_template_name = $request->grade_template_name;
        $grade_name = $request->grade_name;
        $grade_min_value = $request->grade_min_value;
        $grade_max_value = $request->grade_max_value;
        $grade_color = $request->grade_color;
        $grade_desc = $request->grade_desc;
        $user_id = 1;

        // Check if the category already exists
        $chk = GradeTemplateModel::where('grade_template_name', ucwords($grade_template_name))
            ->where('branch_id', self::$branch_id)
            ->where('grade_name', ucwords($grade_name))->where('status', '!=', 2)
            ->first();

        $chk2 = GradeTemplateModel::where('grade_color', ucwords($grade_color))->where('status', '!=', 2)
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Grade Template has already been created!'
            ]);
        } else if ($chk2) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Grade Color has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = GradeTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = date('y');
                $grade_template_id = 'GT-0001/' . $year;
            } else {
                $data = $category_check->grade_template_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('GT-%04d', $next_number);
                $year = date('y');
                $grade_template_id = $requestId . '/' . $year;
            }

            if ($request->hasFile('grade_logo')) {
                $imageName = idate('B') . rand(1, 50) . '.' . $request->file('grade_logo')->extension();
                $destinationPath = public_path('grade_logo');
                // Path to the logos directory
                $request->file('grade_logo')->move($destinationPath, $imageName);
                $logo = $imageName;
            } else {
                $logo = '';
            }
            // return $logo;

            // Add the category to the database
            $add = new GradeTemplateModel();
            $add->grade_template_id = $grade_template_id;
            $add->grade_template_name = ucfirst($grade_template_name);
            $add->grade_name = ucfirst($grade_name);
            $add->grade_min_value = $grade_min_value;
            $add->grade_max_value = $grade_max_value;
            $add->grade_logo = $logo;
            // Assign the uploaded filename here
            $add->grade_color = $grade_color;
            $add->grade_desc = $grade_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by = $request->user()->user_id;
            $add->updated_by = $request->user()->user_id;
            // return $add;
            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Grade Template  added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Grade Template !'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'grade_template_name_edit' => 'required|max:255',
            'grade_name_edit' => 'required|max:255',
            'grade_min_value_edit' => 'required|max:255',
            'grade_max_value_edit' => 'required|max:255',
            'grade_color_edit' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $grade_template_name = $request->grade_template_name_edit;
        $grade_name = $request->grade_name_edit;
        $grade_min_value = $request->grade_min_value_edit;
        $grade_max_value = $request->grade_max_value_edit;
        $old_grade_img = $request->old_grade_img;
        $grade_template_id = $request->grade_template_id;
        // $grade_logo = $request->grade_logo;
        $grade_color = $request->grade_color_edit;
        $grade_desc = $request->grade_desc_edit;
        $user_id = $request->user()->user_id;

        $upd_grade_template = GradeTemplateModel::find($grade_template_id);

        if (!$upd_grade_template) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Grade Template  not found!'
            ]);
            return redirect()->back();
        }

        $chk = GradeTemplateModel::where('grade_template_name', ucwords($grade_template_name))
            ->where('branch_id', self::$branch_id)
            ->where('grade_name', ucwords($grade_name))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $grade_template_id)
            ->first();

        $chk2 = GradeTemplateModel::where('grade_color', ucwords($grade_color))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $grade_template_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Grade Template has already been created!'
            ]);
        } else if ($chk2) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Grade Color has already been created!'
            ]);
        } else {

            if ($request->hasFile('grade_logo_edit')) {
                $imageName = idate('B') . rand(1, 50) . '.' . $request->file('grade_logo_edit')->extension();
                $destinationPath = public_path('grade_logo');
                // Path to the logos directory
                $request->file('grade_logo_edit')->move($destinationPath, $imageName);
                $logo = $imageName;
            } else {
                $logo = $request->old_grade_img;
            }
            // return $logo;

            // Add the category to the database
            $upd_grade_template->grade_template_name = ucfirst($grade_template_name);
            $upd_grade_template->grade_name = ucfirst($grade_name);
            $upd_grade_template->grade_min_value = $grade_min_value;
            $upd_grade_template->grade_max_value = $grade_max_value;
            $upd_grade_template->grade_logo = $logo;
            // Assign the uploaded filename here
            $upd_grade_template->grade_color = $grade_color;
            $upd_grade_template->grade_desc = $grade_desc;
            $upd_grade_template->updated_by = $user_id;
            $upd_grade_template->save();

            if ($upd_grade_template) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Grade Template updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Grade Template !'
                ]);
            }

            return redirect()->back();
        }
    }
}