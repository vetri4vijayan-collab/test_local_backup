<?php

namespace App\Http\Controllers\settings\exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AIPrompt extends Controller
{
  public function index()
  {
    return view('content.settings.exam.ai_prompt.ai_prompt_list');
  }
}
