<?php

namespace App\Http\Controllers\settings\batch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FeedBackStudentQuestionModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class FeedbackStudentQuestion extends Controller
{
  public function Index()
  {

    $cat_question = FeedBackStudentQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    // return $cat_question;
    return view('content.settings.batch.feedback.feedback_list', compact('cat_question'));
  }
  public function feedbackQuestionsAdd()
  {
    return view('content.settings.batch.feedback.feedback_questions_add');
  }

  public function feedbackQuestionsEdit()
  {
    return view('content.settings.batch.feedback.feedback_questions_edit');
  }


  public function List()
  {
    $leadquestion = FeedBackStudentQuestionModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $leadquestion
    ], 200);
  }


  // public function Add(Request $request)
  // {
  //   // return $request;
  //   // Validate incoming request
  //   $validator = Validator::make($request->all(), [
  //     'question.*' => 'required|max:255', // '*' indicates an array of questions
  //     'question_type.*' => 'required',
  //     // Add validation rules for option fields if needed
  //   ]);

  //   if ($validator->fails()) {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Feedback Question Name is required!'
  //     ]);
  //     return redirect()->back();
  //   }

  //   $user_id = $request->user()->user_id; // You should set this to the currently authenticated user ID

  //   foreach ($request->input('question') as $key => $category_question_name) {
  //     $category_question_type = $request->input('question_type.' . $key);
  //     // Initialize options array
  //     $category_question_option = [];

  //     switch ($category_question_type) {
  //       case 'checkbox':
  //       case 'radio_button':
  //       case 'list_box':
  //         // Get options and scores for the current question
  //         $options_key = 'option_value_' . $category_question_type . '_' . $key;
  //         $scores_key = 'option_score_' . $category_question_type . '_' . $key;

  //         $options = $request->input($options_key, []);
  //         $scores = $request->input($scores_key, []);

  //         $options_array = [];
  //         foreach ($options as $option_key => $value) {
  //           if ($value !== '') {
  //             $options_array[] = [
  //               'value' => $value,
  //               'score' => $scores[$option_key] ?? null,
  //             ];
  //           }
  //         }

  //         $category_question_option = json_encode($options_array); // Convert options to JSON
  //         break;
  //       case 'slider':
  //         // No options needed for text_field questions
  //         $category_question_option = null;
  //         break;
  //       default:
  //         break;
  //     }

  //     $chk = FeedBackStudentQuestionModel::where('category_question_name', ucwords($category_question_name))->where('status', '!=', 2)->first();

  //     if ($chk) {
  //       session()->flash('toastr', [
  //         'type' => 'error',
  //         'message' => 'Name has been already created!'
  //       ]);
  //       continue; // Skip processing this question and move to the next one
  //     }

  //     $add_category = new FeedBackStudentQuestionModel();
  //     $add_category->category_question_name = ucfirst($category_question_name);
  //     $add_category->category_question_type = $category_question_type;
  //     $add_category->category_question_option = $category_question_option;
  //     $add_category->created_by = $user_id;
  //     $add_category->updated_by = $user_id;
  //     $add_category->save();

  //     if ($add_category) {
  //       session()->flash('toastr', [
  //         'type' => 'success',
  //         'message' => 'Feedback Question added Successfully!'
  //       ]);
  //     } else {
  //       session()->flash('toastr', [
  //         'type' => 'error',
  //         'message' => 'Could not add the Feedback Question!'
  //       ]);
  //     }
  //   }

  //   return redirect()->route('settings-batch-feedback_question_list');
  // }
public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'question.*'      => 'required|max:255',
        'question_type.*' => 'required',
        'language.*'      => 'required',
        'section.*'       => 'nullable',
    ]);

    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'All fields are required!'
        ]);
        return redirect()->back();
    }

    $user_id = $request->user()->user_id;

    foreach ($request->input('question') as $key => $category_question_name) {

        // NEW → fetch language & section
        $language_id = $request->input("language.$key");
        $section_id  = $request->input("section.$key");

        $category_question_type = $request->input("question_type.$key");

        $category_question_option = null;

        switch ($category_question_type) {

            case 'checkbox':
            case 'radio_button':
            case 'list_box':

                $options_key = "option_value_{$category_question_type}_{$key}";
                $scores_key  = "option_score_{$category_question_type}_{$key}";

                $options = $request->input($options_key, []);
                $scores  = $request->input($scores_key, []);

                $options_array = [];
                foreach ($options as $option_key => $value) {
                    if ($value !== '') {
                        $options_array[] = [
                            'value' => $value,
                            'score' => $scores[$option_key] ?? null,
                        ];
                    }
                }

                $category_question_option = json_encode($options_array);
                break;
        }

        // Duplicate check
        $chk = FeedBackStudentQuestionModel::where('category_question_name', ucwords($category_question_name))
                    ->where('status', '!=', 2)->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Question already exists!'
            ]);
            continue;
        }

        // CREATE NEW ROW
        $add_category = new FeedBackStudentQuestionModel();
        $add_category->category_question_name   = ucfirst($category_question_name);
        $add_category->category_question_type   = $category_question_type;
        $add_category->category_question_option = $category_question_option;

        // NEW → save language + section
        $add_category->language_id = $language_id;
        $add_category->section_id  = $section_id;

        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;
        $add_category->save();
    }

    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Feedback Questions Saved Successfully!'
    ]);

    return redirect()->route('settings-batch-feedback_question_list');
}



  public function Edit($id)
  {
    $editcategory = FeedBackStudentQuestionModel::where('sno', $id)->first();

    return view('content.settings.counsellor.category_question_list', [
      'editcategory' => $editcategory,
      'id' => $id,
    ]);
  }

  public function Category_edit($id)
  {

    // return $id;
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $category_question = FeedBackStudentQuestionModel::where('status', '!=', 2)
      ->where('sno', $decryptedValue)
      // ->orderBy('sno', 'desc')D:\Xampp_8.2.4\htdocs\eapl_full\resources\views\content\settings\counsellor\category_question\cat_questions_edit.blade.php
      ->first();

    $json_string = $category_question->category_question_option;

    // Decode the JSON string into a PHP associative array
    $options_array = json_decode($json_string, true);

    // Initialize arrays to hold values and scores
    $values = [];
    $scores = [];

    // Process each item in the array
    foreach ($options_array as $item) {
      // Extract 'value'
      if (isset($item['value'])) {
        $values[] = $item['value'];
      }

      // Extract 'score'
      if (isset($item['score'])) {
        $scores[] = $item['score'];
      }
    }

    // Map values and scores into the desired format
    $mapped_array = [];
    $maxCount = max(count($values), count($scores));

    for ($i = 0; $i < $maxCount; $i++) {
      $mapped_array[] = [
        'value' => isset($values[$i]) ? $values[$i] : '',
        'score' => isset($scores[$i]) ? $scores[$i] : ''
      ];
    }

    // Output or use $mapped_array as needed
    // For debugging
    // dd($mapped_array);



    return view('content.settings.counsellor.category_question.cat_questions_edit', [
      'category_question' => $category_question,
      'mapped_array' => $mapped_array,
    ]);
  }
  public function Update(Request $request)
  {
    // return $request;
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'category_question_name' => 'required|max:255',
      // 'option_name' => 'array',
      // 'category_score' => 'array'
    ]);
    // return $request;


    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Validation failed. Please ensure all required fields are filled out.'
      ]);
      return redirect()->back()->withErrors($validator)->withInput();
    }
    // return $request;
    $category_question_name = $request->category_question_name;
    $course_cat = $request->course_cat;
    $category_question = $request->category_question;
    $option_name = $request->option_name;
    $category_score = $request->category_score;
    $sno = $request->sno_edit;
    $user_id = $request->user()->user_id;
    // dd($category_score);
    // Check if the question already exists
    $chk = FeedBackStudentQuestionModel::where('category_question_name', ucfirst($category_question_name))
      ->where('status', '!=', 2)
      ->where('sno', '!=', $sno)
      ->first();
    if ($chk) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Name has been already created!'
      ]);
      return redirect()->back();
    }

    // Initialize an array to hold options and scores
    $optionsArray = [];
    foreach ($option_name as $index => $option) {
      $score = $category_score[$index] ?? null; // Get the score for this option
      if ($option !== '') {
        $optionsArray[] = [
          'value' => $option,
          'score' => $score,
        ];
      }
    }
    // dd($optionsArray);

    $category_question_option = json_encode($optionsArray); // Convert options and scores to JSON

    // Find and update the FeedBackStudentQuestionModel
    $upd_CourseModel = FeedBackStudentQuestionModel::find($sno);
    if (!$upd_CourseModel) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Category Question not found!'
      ]);
      return redirect()->back();
    }

    $upd_CourseModel->category_question_name = ucfirst($category_question_name);
    $upd_CourseModel->category_id = $course_cat;
    $upd_CourseModel->category_question_type = $category_question;
    $upd_CourseModel->category_question_option = $category_question_option;

    $upd_CourseModel->created_by = $user_id;
    $upd_CourseModel->updated_by = $user_id;
    $upd_CourseModel->save();

    // Flash success or error message based on the result
    if ($upd_CourseModel) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Category Question updated successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Category Question!'
      ]);
    }

    return redirect()->route('settings-counsellor-category_question_list');
  }


  public function Delete($id)
  {
    $upd_FeedBackStudentQuestionModel =  FeedBackStudentQuestionModel::where('sno', $id)->first();
    $upd_FeedBackStudentQuestionModel->status  = 2;
    $upd_FeedBackStudentQuestionModel->Update();
    if ($upd_FeedBackStudentQuestionModel) {
      return response([
        'status'    => 200,
        'message'   => 'Category Analysis Questions Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Category Analysis Questions!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Status($id, Request $request)
  {

    $upd_FeedBackStudentQuestionModel =  FeedBackStudentQuestionModel::where('sno', $id)->first();
    $upd_FeedBackStudentQuestionModel->status = $request->input('status', 0);
    $upd_FeedBackStudentQuestionModel->update();
    if ($upd_FeedBackStudentQuestionModel) {
      return response([
        'status'    => 200,
        'message'   => ' Category Analysis Questions Successfully Updated!',
        'error_msg' => 'Could not ,update   Category Analysis Questions!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update  Category Analysis Questions!',
        'error_msg' => 'Could not ,update   Category Analysis Questions!',
        'data'      => null,
      ], 200);
    }
  }

  public function getSections($language_id)
{
    $sections = DB::table('za_section')
        ->where('language_id', $language_id)
        ->select('sno', 'section')
        ->get();

    return response()->json($sections);
}

}
