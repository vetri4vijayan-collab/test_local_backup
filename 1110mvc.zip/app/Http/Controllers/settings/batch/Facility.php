<?php

namespace App\Http\Controllers\settings\batch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FacilityModel;
use Illuminate\Support\Facades\Validator;

class Facility extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    $slotTypes = FacilityModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    // return view('content.settings.batch.facility.facility_list');
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.batch.facility.facility_list', compact('slotTypes', 'pageConfigs'));
  }

  public function List()
  {
    $facility = FacilityModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'facility_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $facility_name       = $request->facility_name;
      $facility_desc       = $request->facility_desc;
      $branch_id                    = $request->user()->branch_id;
      $user_id                    = $request->user()->user_id;
      $chk = FacilityModel::where('facility_name', ucwords($facility_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = FacilityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $facility_id = "FAC-0001/" . $year;
        } else {

          $data = $category_check->facility_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("FAC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $facility_id = $request . '/' . $year;
        }


        $add_category = new FacilityModel();
        $add_category->facility_id         = $facility_id;
        $add_category->facility_name       = Ucfirst($facility_name);
        $add_category->facility_desc       = $facility_desc;
        $add_category->branch_id           = $branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Facility added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Facility!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Facility Created successfully!');
    }
  }

  public function Edit($id)
  {
    $facility = FacilityModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'facility_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Name has been  already created!'
      ]);
    } else {

      $facility_name       = $request->facility_name;
      $facility_desc       = $request->facility_desc;

      $upd_CourseCategoryModel =  FacilityModel::where('sno', $id)->first();

      $chk = FacilityModel::where('facility_name', ucwords($facility_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->facility_name  = Ucfirst($facility_name);
        $upd_CourseCategoryModel->facility_desc  = $facility_desc;
        $upd_CourseCategoryModel->update();
        if ($upd_CourseCategoryModel) {
          $result = response([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        } else {
          $result = response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => 'Incorrect format input feilds',
            'data'      => null,
          ], 401);
        }
        return $result;
      }
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  FacilityModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  FacilityModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}