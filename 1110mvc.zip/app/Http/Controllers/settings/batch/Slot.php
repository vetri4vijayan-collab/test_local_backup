<?php

namespace App\Http\Controllers\settings\batch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SlotModel;
use Illuminate\Support\Facades\Validator;

class Slot extends Controller
{

  // protected static $branch_id = 1;
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $slotTypes = SlotModel::select('za_slot.*', 'za_slot_type.slot_type_name', 'za_slot_type.sno as slot_type_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->orderBy('sno', 'desc');
      if ($branch_id != 0) {
        $slotTypes->where('za_slot.branch_id', $branch_id);
      }
      // ->paginate(20);
      $slotTypes=$slotTypes->get();
    // return  $slotTypes;

    if ($slotTypes->isEmpty()) {
      $message = "No data available";
      $pageConfigs = ['myLayout' => 'default'];
      return view('content.settings.batch.slot.slot_list', compact('message', 'pageConfigs'));
    }


    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    foreach ($slotTypes as $slotType) {
      $dayIndices = json_decode($slotType->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        // Ensure the index is within the valid range
        $dayIndex = (int)$index;

        if ($dayIndex >= 0 && $dayIndex < count($shortDays)) {
          $dayNames[] = $shortDays[$dayIndex];
        } else {
          $dayNames[] = '-';  // Handle invalid indices
        }
      }

      $slotType->dayNames = implode(', ', $dayNames);
    }
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.batch.slot.slot_list', compact('slotTypes', 'pageConfigs'));
  }

  public function List(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $CourseCategory = SlotModel::select('za_slot.*', 'za_slot_type.slot_type_name', 'za_slot_type.sno as slot_type_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
    //   ->where('za_slot.branch_id', self::$branch_id)
      ->where('za_slot_type.status', 0)
      ->where('za_slot.status', 0)
      ->orderBy('sno', 'asc');
      if ($branch_id != 0) {
        $CourseCategory->where('za_slot.branch_id', $branch_id);
      }
      $CourseCategory= $CourseCategory->get();

    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    foreach ($CourseCategory as $slotType) {
      $dayIndices = json_decode($slotType->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        $dayIndex = (int)$index - 1;
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      $slotType->dayNames = implode(', ', $dayNames);
    }

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseCategory
    ], 200);
  }

  public function Add(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'slot_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $slot_type_id    = $request->slot_type_id;
      $slot_type_days    = json_encode($request->slot_type_days);
      $slot_name       = $request->slot_name;
      $start_time      = $request->start_time;
      $end_time        = $request->end_time;
      $slot_desc       = $request->slot_desc;
      $user_id                    = $request->user()->user_id;
      $chk = SlotModel::where('slot_name', ucwords($slot_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name alredy have Slot!'
        ]);
      } else {
        $category_check = SlotModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $slot_id = "SLT-0001/" . $year;
        } else {

          $data = $category_check->slot_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("SLT-%04d", $next_number);

          $year = substr(date("y"), -2);
          $slot_id = $request . '/' . $year;
        }




        $add_category = new SlotModel();
        $add_category->slot_id              = $slot_id;
        $add_category->slot_type_id         = $slot_type_id;
        $add_category->slot_type_days         = $slot_type_days;
        $add_category->slot_name            = Ucfirst($slot_name);
        $add_category->start_time           = $start_time;
        $add_category->end_time             = $end_time;
        $add_category->slot_desc            = $slot_desc;
        $add_category->branch_id           = $branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;
        // return $add_category;
        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Slot added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Slot!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Slot Type Created successfully!');
    }
  }

  public function Edit($id)
  {
    // $slot = SlotModel::where('sno', $id)->first();

    // return view('content.settings.batch.slot_types.slot_type_list', [
    //   'slot' => $slot,
    //   'id' => $id,
    // ]);

    $slot = SlotModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $slot
    ], 200);
  }

  public function Update($id, Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'slot_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $slot_type_id    = $request->slot_type_id;
      $slot_type_days    = json_encode($request->slot_type_days);
      $slot_name       = $request->slot_name;
      $start_time      = $request->start_time;
      $end_time        = $request->end_time;
      $slot_desc       = $request->slot_desc;

      $upd_CourseCategoryModel =  SlotModel::where('sno', $id)->first();

      $chk = SlotModel::where('slot_name', ucwords($slot_name))->where('branch_id',$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $upd_CourseCategoryModel->slot_name  = Ucfirst($slot_name);
        $upd_CourseCategoryModel->slot_type_id  = $slot_type_id;
        $upd_CourseCategoryModel->slot_type_days  = $slot_type_days;
        $upd_CourseCategoryModel->start_time  = $start_time;
        $upd_CourseCategoryModel->end_time  = $end_time;
        $upd_CourseCategoryModel->slot_desc  = $slot_desc;

        // return $upd_CourseCategoryModel;
        $upd_CourseCategoryModel->update();
      }

      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  SlotModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  SlotModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
