<?php

namespace App\Http\Controllers\settings\batch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SlotTypeModel;
use Illuminate\Support\Facades\Validator;


class SlotTypes extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {

    $slotTypes = SlotTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();


    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.batch.slot_types.slot_type_list', compact('slotTypes', 'pageConfigs'));
  }


  public function List()
  {
    $CourseCategory = SlotTypeModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $CourseCategory
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'slot_type_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $slot_type_name       = $request->slot_type_name;
      // $slot_type_days       = json_encode($request->slot_type_days);
      $slot_type_desc       = $request->slot_type_desc;

      $user_id                    = $request->user()->user_id;
      $branch_id                    = $request->user()->branch_id;
      $chk = SlotTypeModel::where('slot_type_name', ucwords($slot_type_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = SlotTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $slot_type_id = "ST-0001/" . $year;
        } else {

          $data = $category_check->slot_type_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("ST-%04d", $next_number);

          $year = substr(date("y"), -2);
          $slot_type_id = $request . '/' . $year;
        }


        $add_category = new SlotTypeModel();
        $add_category->slot_type_id         = $slot_type_id;
        $add_category->slot_type_name       = Ucfirst($slot_type_name);
        $add_category->slot_type_desc       = $slot_type_desc;
        $add_category->branch_id            = $branch_id;
        $add_category->created_by           = $user_id;
        $add_category->updated_by           = $user_id;

        $add_category->save();

        if ($add_category) {
          $result = response([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        } else {
          $result = response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => 'Incorrect format input feilds',
            'data'      => null,
          ], 401);
        }
      }
      return $result;
      // return redirect()->back()->with('success', 'Slot Type Created successfully!');
    }
  }


  public function Edit($id)
  {
    $slottype = SlotTypeModel::where('sno', $id)->first();


    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $slottype
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'slot_type_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $slot_type_name       = $request->slot_type_name;
      // $slot_type_days       = json_encode($request->slot_type_days);
      $slot_type_desc       = $request->slot_type_desc;

      $upd_CourseCategoryModel =  SlotTypeModel::where('sno', $id)->first();

      $chk = SlotTypeModel::where('slot_type_name', ucwords($slot_type_name))->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $upd_CourseCategoryModel->slot_type_name  = Ucfirst($slot_type_name);
        $upd_CourseCategoryModel->slot_type_desc  = $slot_type_desc;
        $upd_CourseCategoryModel->update();
      }
      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  SlotTypeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  SlotTypeModel::where('sno', $id)->first();
    // toastr()->success('Success message', 'Success');
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();
    // if ($upd_CourseCategoryModel) {
    //   toastr()->success('Success message', 'Success');
    // } else {
    //   toastr()->error('Error message', 'Error');
    // }

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
