<?php

namespace App\Http\Controllers\settings\batch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ClassRoomModel;
use App\Models\FacilityModel;
use Illuminate\Support\Facades\Validator;

class ClassRoom extends Controller
{
  protected static $branch_id = 1;
  public function index()
  {
    // return view('content.settings.batch.classroom.classroom_list');
    $classrooms = ClassRoomModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)
      ->orderBy('sno', 'desc')
      ->get();

    // Step 2: Initialize a collection to store the combined data
    $combinedData = collect();

    // Step 3: Loop through each classroom
    foreach ($classrooms as $classroom) {
      // Deserialize the facility_id JSON field
      $facilityIds = json_decode($classroom->facility_id, true);

      // Fetch facilities based on the deserialized IDs
      $facilities = FacilityModel::whereIn('sno', $facilityIds)->get();

      // Combine the classroom data with the facilities data
      $classroomData = $classroom->toArray();
      $classroomData['facilities'] = $facilities;

      // Add the combined data to the collection
      $combinedData->push($classroomData);
    }
    // return $combinedData;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.batch.classroom.classroom_list', [
      'classroom' => $combinedData,
      'pageConfigs' => $pageConfigs
    ]);;
  }
  public function List()
  {
    $facility = ClassRoomModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $facility
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'class_room_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $class_room_name       = $request->class_room_name;
      $class_room_type       = $request->class_room_type;
      $maximum_capacity      = $request->maximum_capacity;
      $location              = $request->location;
      $facility_id           = json_encode($request->facility_id);
      $class_room_desc       = $request->class_room_desc;
      $branch_id                    = $request->user()->branch_id;
      $user_id                    = $request->user()->user_id;
      $chk = ClassRoomModel::where('class_room_name', ucwords($class_room_name))->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = ClassRoomModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $class_room_id = "CLS-0001/" . $year;
        } else {

          $data = $category_check->class_room_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CLS-%04d", $next_number);

          $year = substr(date("y"), -2);
          $class_room_id = $request . '/' . $year;
        }


        $add_category = new ClassRoomModel();
        $add_category->class_room_id         = $class_room_id;
        $add_category->class_room_name       = Ucfirst($class_room_name);
        $add_category->class_room_type       = $class_room_type;
        $add_category->maximum_capacity      = $maximum_capacity;
        $add_category->location              = $location;
        $add_category->facility_id           = $facility_id;
        $add_category->class_room_desc       = $class_room_desc;
        $add_category->branch_id             = $branch_id;
        $add_category->created_by            = $user_id;
        $add_category->updated_by            = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Class Room added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Class Room!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'ClassRoom Created successfully!');
    }
  }

  public function Edit($id)
  {
    $classroom = ClassRoomModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $classroom
    ], 200);
  }

  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'class_room_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $class_room_name       = $request->class_room_name;
      $class_room_type       = $request->class_room_type;
      $maximum_capacity      = $request->maximum_capacity;
      $location              = $request->location;
      $facility_id           = json_encode($request->facility_id);
      $class_room_desc       = $request->class_room_desc;

      $upd_CourseCategoryModel =  ClassRoomModel::where('sno', $id)->first();

      $chk = ClassRoomModel::where('class_room_name', ucwords($class_room_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $upd_CourseCategoryModel->class_room_name   = Ucfirst($class_room_name);
        $upd_CourseCategoryModel->class_room_type   = $class_room_type;
        $upd_CourseCategoryModel->maximum_capacity  = $maximum_capacity;
        $upd_CourseCategoryModel->location          = $location;
        $upd_CourseCategoryModel->facility_id       = $facility_id;
        $upd_CourseCategoryModel->class_room_desc   = $class_room_desc;
        $upd_CourseCategoryModel->update();
      }


      if ($upd_CourseCategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel =  ClassRoomModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  ClassRoomModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}