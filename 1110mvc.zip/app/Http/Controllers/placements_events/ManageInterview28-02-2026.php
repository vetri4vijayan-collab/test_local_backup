<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\HrDirectoryModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\JobModel;
use App\Models\InterviewModel;
use Illuminate\Support\Facades\DB;

class ManageInterview extends Controller
{

  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $search_fill = $request->input('search_fill', '');
    $filter_on = $request->input('filter_on', false);
    $search_company = $request->input('search_company', '');
    $search_job_category = $request->input('search_job_category', '');
    $search_status = $request->input('search_status', '');
    $search_job_sub_category = $request->input('search_job_sub_category', '');
    $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
    $dt_fill_date_type = $request->input('dt_fill_date_type', '');
    $search_start_date = $request->input('search_start_date', '');
    $search_end_date = $request->input('search_end_date', '');

    $job_list = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
    ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
    ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
    ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
    ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
    ->where('za_jobs.status', 0)
    ->where('za_jobs.branch_id', $branch_id);

    if (!empty($search_fill)) {
        $job_list->where(function ($query) use ($search_fill) {
            $query->Where('za_placement_company.company_name', 'LIKE', "%{$search_fill}%")
            // ->where('za_job_category.job_category_name', 'LIKE', "%{$search_fill}%")
            // ->orWhere('za_job_subcategory.job_subcategory_name', 'LIKE', "%{$search_fill}%")
            // ->orWhere('za_interview_type.interview_type_name', 'LIKE', "%{$search_fill}%")
            ->orWhere('za_placement_company.company_address', 'LIKE', "%{$search_fill}%");
        });
    }

    if(!empty($search_company)){
        $job_list->where('za_placement_company.sno',$search_company);
    }

    if(!empty($search_status)){
        $job_list->where('za_jobs.job_status',$search_status);
    }

    if(!empty($search_job_category)){
        $job_list->where('za_job_category.sno',$search_job_category);
    }

    if(!empty($search_job_sub_category)){
        $job_list->where('za_job_subcategory.sno',$search_job_sub_category);
    }


    if ($dt_fill_issue_rpt == "today") {
        $todayDate = date("Y-m-d");
        if($dt_fill_date_type == 'interview_date'){
            $job_list->whereDate('za_jobs.interview_date', $todayDate);
        }else if($dt_fill_date_type == 'last_pay_date'){
            $job_list->whereDate('za_jobs.last_apply_date', $todayDate);
        }
    } elseif ($dt_fill_issue_rpt == "week") {
        $today = date('l');
        if ($today == "Sunday") {
            $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
            $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
            $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
            $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
        }
        if($dt_fill_date_type == 'interview_date'){
            $job_list->whereBetween('za_jobs.interview_date', [$weekFromDate, $weekToDate]);
        }else if($dt_fill_date_type == 'last_pay_date'){
            $job_list->whereBetween('za_jobs.last_apply_date', [$weekFromDate, $weekToDate]);
        }
    } elseif ($dt_fill_issue_rpt == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth  = date('Y-m-t');
        if($dt_fill_date_type == 'interview_date'){
            $job_list->whereBetween('za_jobs.interview_date', [$firstDayOfMonth, $lastDayOfMonth]);
        }else if($dt_fill_date_type == 'last_pay_date'){
            $job_list->whereBetween('za_jobs.last_apply_date', [$firstDayOfMonth, $lastDayOfMonth]);
        }
    } elseif ($dt_fill_issue_rpt == "custom_date") {
        if ($search_start_date && $search_end_date) {
            $fromDate = date('Y-m-d', strtotime($search_start_date));
            $toDate   = date('Y-m-d', strtotime($search_end_date));
            if($dt_fill_date_type == 'interview_date'){
                $job_list->whereBetween('za_jobs.interview_date', [$fromDate, $toDate]);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->whereBetween('za_jobs.last_apply_date', [$fromDate, $toDate]);
            }
        } elseif ($search_start_date) {
            $fromDate = date('Y-m-d', strtotime($search_start_date));
            if($dt_fill_date_type == 'interview_date'){
                $job_list->where('za_jobs.interview_date', '>=', $fromDate);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->where('za_jobs.last_apply_date', '>=', $fromDate);
            }
        } elseif ($search_end_date) {
            $toDate = date('Y-m-d', strtotime($search_end_date));
            if($dt_fill_date_type == 'interview_date'){
                $job_list->where('za_jobs.interview_date', '<=', $toDate);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->where('za_jobs.last_apply_date', '<=', $toDate);
            }
        }
    }
         
    $job_list= $job_list->orderBy('za_jobs.sno', 'desc')->paginate($perpage);

    foreach( $job_list as $job){
        $selected_count=0;
        if (!empty($job->skill_description)) {
            $skills = json_decode($job->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job->skill_description = implode(', ', $skill_names); 
        }
        if (!empty($job->interest_student_ids)) {
            $customer_ids = json_decode($job->interest_student_ids, true);
            $students = DB::table('za_placement_interview')
                ->select('za_placement_interview.status','za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.selected_date')
                ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('za_placement_interview.customer_id', $customer_ids)
                ->where('za_placement_interview.job_id', $job->sno)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
            $job->customer_list = $students;
            $job->intrested_student_count = count($customer_ids); 

            $SelectedStudents = DB::table('za_placement_interview')
            ->select('za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position','za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.selected_date')
            ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
            ->where('za_customer.status', '!=', 2)
            ->whereIn('za_placement_interview.customer_id', $customer_ids)
            ->where('za_placement_interview.job_id', $job->sno)
            ->where('za_placement_interview.status', 4)
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();
            $job->selected_customer_list = $SelectedStudents;
            $job->selected_student_count = count($SelectedStudents); 
        }
    }

    return view('content.placements_events.manage_interview.manage_interview', [
        'job_list' => $job_list,
        'pageConfigs' => ['myLayout' => 'default'],
        'perpage'=> $perpage,
        'search_fill'=>$search_fill,
        'filter_on'=>$filter_on,
        'search_company' => $search_company,
        'search_job_category' => $search_job_category,
        'search_job_sub_category' => $search_job_sub_category,
        'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
        'dt_fill_date_type' => $dt_fill_date_type,
        'search_start_date' => $search_start_date,
        'search_end_date' => $search_end_date,
        'search_status' => $search_status,
    ]);
  }


  public function View($id,Request $request)
  {
      
    $branch_id = $request->user()->branch_id;

    $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email')
    ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
    ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
    ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
    ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
    ->where('za_jobs.status', '!=', 2)
    ->where('za_jobs.branch_id', $branch_id)
    ->where('za_jobs.sno', $id)
    ->first(); 

    if (!empty($job_data->skill_description)) {
        $skills = json_decode($job_data->skill_description, true);
        $skill_names = array_map(function ($skill) {
            return $skill['value'];
        }, $skills);
        $job_data->skill_description = implode(', ', $skill_names); 
    }
    $interview_checklist_id = json_decode($job_data->interview_checklist_id, true);

    $chk_list = DB::table('za_interview_checklist')
    ->select('za_interview_checklist.interview_checklist_name','za_interview_checklist.sno as checklist_id')
    ->where('za_interview_checklist.status', '!=', 2)
    ->whereIn('za_interview_checklist.sno', $interview_checklist_id)
    ->get();

    $job_data->interview_chk_list = $chk_list;
    if (!empty($job_data->interest_student_ids)) {
        $customer_ids = json_decode($job_data->interest_student_ids, true);
        $students = DB::table('za_placement_interview')
                ->select('za_placement_interview.sno as interview_id','za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position', 'za_customer.cus_name','za_placement_interview.ncs_reason','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.interview_checklist_status','za_placement_interview.selected_date')
                ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('za_placement_interview.customer_id', $customer_ids)
                ->where('za_placement_interview.job_id', $id)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
        $completed_count=0;
        $onprogress_count=0;
        $rejected_count=0;
        foreach($students as $singleStudent){
            if ($singleStudent->status == 1) {
                $onprogress_count +=1;
            } elseif ($singleStudent->status == 3) {
                $rejected_count +=1;
            } elseif ($singleStudent->status == 4) {
                $completed_count+=1;
            } elseif ($singleStudent->status == 5 || $singleStudent->status == 0) {
            }
            
            $interview_checklist_status = json_decode($singleStudent->interview_checklist_status, true);
            $singleStudent->interview_checklist_status=$interview_checklist_status;
        }

        $job_data->completed_count = $completed_count;
        $job_data->onprogress_count = $onprogress_count;
        $job_data->rejected_count = $rejected_count;
        $job_data->customer_list = $students;
        $job_data->intrested_student_count = count($customer_ids); 
    }

    $expiry_status = null;
    if(date('Y-m-d', strtotime($job_data->last_apply_date . ' -2 days')) <= date('Y-m-d') && $job_data->last_apply_date >= date('Y-m-d')){
        $expiry_status = '[ Expired Soon.. ]';
    }elseif($job_data->last_apply_date < date('Y-m-d')){
        $expiry_status = '[ Expired.. ]';
    }

    if($job_data->job_status == 0){
        $job_data->status_text = 'Not Yet Started';
        $job_data->status_class = 'badge bg-warning text-black fw-semibold rounded fw-7';
    }else if($job_data->job_status == 3){
        $job_data->status_text = 'Ongoing';
        $job_data->status_class = 'badge bg-info text-white fw-semibold rounded fw-7';
    }else if($job_data->job_status == 4){
        $job_data->status_text = 'Completed';
        $job_data->status_class = 'badge bg-success text-white fw-semibold rounded fw-7';
    }else if($job_data->job_status == 5){
        $job_data->status_text = 'Cancelled';
        $job_data->status_class = 'badge bg-danger text-white fw-semibold rounded fw-7';
    }

    $job_data->expiry_status = $expiry_status;
     
    return response()->json([
        'status' => 200,
        'success' => true,
        'message' => null,
        'error_msg' => null,
        'data' => $job_data ,
    ], 200);
  }

  public function JobDetails($id,Request $request)
  {
      
      $branch_id = $request->user()->branch_id;
      $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email')
      ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
      ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
      ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
      ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
      ->where('za_jobs.status', '!=', 2)
      ->where('za_jobs.branch_id', $branch_id)
      ->where('za_jobs.sno', $id)
      ->first(); 

      if (!empty($job_data->skill_description)) {
          $skills = json_decode($job_data->skill_description, true);
          $skill_names = array_map(function ($skill) {
              return $skill['value'];
          }, $skills);
          $job_data->skill_description = implode(', ', $skill_names); 
      }
      $interview_checklist_id = json_decode($job_data->interview_checklist_id, true);
        $chk_list = DB::table('za_interview_checklist')
                ->select('za_interview_checklist.interview_checklist_name','za_interview_checklist.sno as checklist_id')
                ->where('za_interview_checklist.status', '!=', 2)
                ->whereIn('za_interview_checklist.sno', $interview_checklist_id)
                ->get();
        $job_data->interview_chk_list = $chk_list;
      if (!empty($job_data->interest_student_ids)) {
          $customer_ids = json_decode($job_data->interest_student_ids, true);
          $students = DB::table('za_placement_interview')
                  ->select('za_placement_interview.sno as interview_id','za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position','za_placement_interview.ncs_reason', 'za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.interview_checklist_status','za_placement_interview.selected_date')
                  ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                  ->where('za_customer.status', '!=', 2)
                  ->whereIn('za_placement_interview.customer_id', $customer_ids)
                  ->where('za_placement_interview.job_id', $id)
                  ->orderBy('za_customer.cus_name', 'asc')
                  ->get();
            foreach( $students as $single){
                $interview_checklist_status = json_decode($single->interview_checklist_status, true);
                $single->interview_checklist_status=$interview_checklist_status;
            }
          $job_data->customer_list = $students;
          $job_data->intrested_student_count = count($customer_ids); 
      }
    
    $expiry_status = null;
    if(date('Y-m-d', strtotime($job_data->last_apply_date . ' -2 days')) <= date('Y-m-d') && $job_data->last_apply_date >= date('Y-m-d')){
        $expiry_status = '[ Expired Soon.. ]';
    }elseif($job_data->last_apply_date < date('Y-m-d')){
        $expiry_status = '[ Expired.. ]';
    }

    if($job_data->job_status == 0){
        $job_data->status_text = 'Not Yet Started';
        $job_data->status_class = 'badge bg-warning text-black fw-semibold rounded fw-7';
    }else if($job_data->job_status == 3){
        $job_data->status_text = 'Ongoing';
        $job_data->status_class = 'badge bg-info text-white fw-semibold rounded fw-7';
    }else if($job_data->job_status == 4){
        $job_data->status_text = 'Completed';
        $job_data->status_class = 'badge bg-success text-white fw-semibold rounded fw-7';
    }else if($job_data->job_status == 5){
        $job_data->status_text = 'Cancelled';
        $job_data->status_class = 'badge bg-danger text-white fw-semibold rounded fw-7';
    }

    $job_data->expiry_status = $expiry_status;     
     
    return response()->json([
        'status' => 200,
        'success' => true,
        'message' => null,
        'error_msg' => null,
        'data' => $job_data ,
    ], 200);
  }

  public function JobStatusChange($id,Request $request)
  {

    $upd_jobModel =  JobModel::where('sno', $id)->first();

    $job_status = $request->status;

    $upd_jobModel->job_status  =  $job_status;
    $upd_jobModel->Update();
    if ($upd_jobModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Status Update Successfully',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 200,
        'message'   => 'Could not Update Job Status!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }
  }



public function updateInterviewStatus(Request $request)
{
    // return $request;
    // Validate input
    $validatedData = $request->validate([
        'interview_job_id' => 'required|integer',
        'interview_student_id' => 'array',
        'student_intrv_status' => 'array',
    ]);

    $job_id = $request->interview_job_id;
    $studentIds = $validatedData['interview_student_id'] ?? [];
    $statuses = $validatedData['student_intrv_status'] ?? [];
    $job_salary = $request->intrv_salary_chk ?? [];
    $job_position = $request->intrv_postion_chk ?? [];
    $placed_date = $request->intrv_placed_chk ?? [];
    $ncs_reason = $request->intrv_ncs_reason ?? [];

    if(!empty($studentIds) && is_array($studentIds)){

        foreach ($studentIds as $index => $studentId) {
    
            $student = InterviewModel::where('sno', $studentId)->where('job_id', $job_id)->first();
    
            if ($student) {

                // Update student status
                $student->status = $statuses[$index] ?? 0;

                $student->job_salary = isset($job_salary[$index]) && !empty($job_salary[$index]) ? $job_salary[$index] : NULL;
                $student->job_position = isset($job_position[$index]) && !empty($job_position[$index]) ? $job_position[$index] : NULL;
                if (!empty($placed_date[$index])) {
                    try {
                        $convertedDate = \Carbon\Carbon::createFromFormat('d-m-Y', $placed_date[$index])->format('Y-m-d');
                        $student->selected_date = $convertedDate;
                    } catch (\Exception $e) {
                        $student->selected_date = null; // Invalid date fallback
                    }
                } else {
                    $student->selected_date = null;
                }
            
                $student->ncs_reason = isset($ncs_reason[$index]) && !empty($ncs_reason[$index]) ? $ncs_reason[$index] : NULL;
    
                // Fetch old checklist data (if any)
                $oldChecklistData = json_decode($student->interview_checklist_status, true) ?? [];
    
                // Fetch new checklist data dynamically
                $checklistKey = "inrv_chk_{$studentId}";
                $newChecklistData = $request->has($checklistKey) ? $request->input($checklistKey) : [];
    
                // If new checklist data is available, replace the old checklist for this student
                if (!empty($newChecklistData)) {
                    // Directly update the checklist for this student, removing old data
                    $oldChecklistData = $newChecklistData;
                }
    
                // Update the interview checklist status with new (or replaced) data
                $student->interview_checklist_status = json_encode($oldChecklistData);
    
                // Save the updated student record
                $student->save();
            }
        }
    }

    // Flash success message
    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Interview status updated successfully!'
    ]);

    // Redirect back to the interview management page
    return redirect('placements/manage_interview');
}



}