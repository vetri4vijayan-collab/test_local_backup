<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\HrDirectoryModel;
use App\Models\PlacementCompanyModel;
use App\Models\JobModel;
use App\Models\HrModel;
use App\Models\HrDirectoryBranchModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\Services\ChatGPTService;
use App\Models\StaffModel;
use App\Models\JobCategoryModel;
use App\Models\JobSubCategoryModel;



class ManageCompany extends Controller
{

    protected $chatGPTService;

    public function __construct(ChatGPTService $chatGPTService)
    {
      $this->chatGPTService = $chatGPTService;
    }
  //HR DIRECTORY index
  public function index(Request $request)
  {

    // $aiTags = $this->getAITagsFromAPI('Developer', 'Junior Python Developer');
    // return $aiTags;

    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;

    $search_fill = $request->input('lead_fill', '');

    $company_list = PlacementCompanyModel::select('za_placement_company.*','za_staff.staff_name','za_staff.nick_name')
      ->join('za_staff','za_placement_company.created_by', '=', 'za_staff.sno')
      ->where('za_placement_company.status', '!=', 2)
      ->where('za_placement_company.branch_id', $branch_id);
      if ($search_fill != '') {
        $company_list->where(function ($query) use ($search_fill) {
            $query->where('za_placement_company.company_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.company_email', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.hr_contact_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.hr_contact_phone', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.hr_contact_email', 'LIKE', "%{$search_fill}%");
        });
    }
    $company_list = $company_list->orderBy('za_placement_company.sno', 'desc')->paginate($perpage);

    foreach( $company_list as $company){
      $hrdetails = DB::table('za_company_hr')
      ->select('za_company_hr.hr_name', 'za_company_hr.hr_mobile_no', 'za_company_hr.hr_position', 'za_company_hr.hr_email_id')
      ->where('za_company_hr.branch_id', $branch_id)
      ->where('za_company_hr.company_id', $company->sno)
      ->orderBy('za_company_hr.sno', 'asc')
      ->get();

      $placement_reasons_his_details = DB::table('za_placement_reasons_history')
        ->select(
            'za_placement_reasons_history.customer_id',
            'za_placement_reasons_history.placement_reason_id',
            'za_placement_reasons_history.reason_score',
            'za_customer.cus_name as customer_name',
            'za_placement_reasons.placement_reason_name'
        )
        ->join('za_customer', 'za_customer.sno', '=', 'za_placement_reasons_history.customer_id')
        ->join('za_placement_reasons', 'za_placement_reasons.sno', '=', 'za_placement_reasons_history.placement_reason_id')
        ->where('za_placement_reasons_history.company_id', $company->sno)
        ->where('za_placement_reasons_history.status', 0)
        ->groupBy(
            'za_placement_reasons_history.customer_id',
            'za_placement_reasons_history.placement_reason_id',
            'za_placement_reasons_history.reason_score',
            'za_customer.cus_name',
            'za_placement_reasons.placement_reason_name'
        )
        ->orderBy('za_placement_reasons_history.sno', 'asc')
        ->get();

        $totalScore = DB::table('za_placement_reasons_history')
        ->where('company_id', $company->sno)
        ->where('status', 0)
        ->sum(DB::raw('reason_score'));

        if ($hrdetails) {
            $hrdetails = $hrdetails->slice(1); 
        }
        $company->hr_info = $hrdetails;
        $company->hr_count = count($hrdetails);
        $company->placement_reasons_his_details = $placement_reasons_his_details;
        $company->place_reasons_his_count = !empty($placement_reasons_his_details) ? count($placement_reasons_his_details) : 0;
        $company->totalScore = !empty($totalScore) ? (int)$totalScore : 0;
    }
    // return $company_list;
    return view('content.placements_events.manage_company.manage_company', [
      'company_list' => $company_list,
      'perpage'          => $perpage,
      'search_fill'        => $search_fill,
    ]);
  }


  public function AddCompany(Request $request)
  {
      // Validate the request data
      $validator = Validator::make($request->all(), [
          'company_name_add' => 'required|max:255',
          'company_email_add' => 'nullable',
      ]);

      if ($validator->fails()) {
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Incorrect format input fields'
          ]);
          return redirect()->back();
      }

      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;

      // Get request data
      $company_name = $request->company_name_add;
      $company_email = $request->company_email_add;
      $company_address = $request->address_add;
      $location_url = $request->location_url_add;
      $company_desc = $request->description;
      $website_url = $request->website_url_add ?? null;

      $job_role = is_array($request->company_job_role) ? json_encode($request->company_job_role) : $request->company_job_role;

      // Handle HR data safely
      $hr_names = $request->hr_name_add ?? [];
      $hr_mobiles = $request->hr_mobile_add ?? [];
      $hr_emails = $request->hr_email_add ?? [];
      $hr_positions = $request->hr_position_add ?? [];

      // Check if the company already exists
      $chk = PlacementCompanyModel::where('company_name', $company_name)
          ->where('branch_id', $branch_id)
          ->first();

      if ($chk) {
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Company already exists!'
          ]);
          return redirect('placements/manage_company');
      }

      // Generate a unique company ID
      $last_entry = PlacementCompanyModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

      if (!$last_entry) {
          $year = substr(date('y'), -2);
          $company_id = 'CMP-0001/' . $year;
      } else {
          $data = $last_entry->company_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);
          $next_number = (int)$result + 1;
          $company_id = sprintf('CMP-%04d', $next_number) . '/' . substr(date('y'), -2);
      }

      // Create a new company record
      $add = new PlacementCompanyModel();
      $add->company_id = $company_id;
      $add->company_name = $company_name;
      $add->company_email = $company_email;
      $add->company_address = $company_address;
      $add->location_url = $location_url;
      $add->company_desc = $company_desc;
      $add->website_url = $website_url;
      $add->job_role = $job_role;
      $add->hr_contact_name = $hr_names[0] ?? null;
      $add->hr_contact_phone = $hr_mobiles[0] ?? null;
      $add->hr_contact_email = $hr_emails[0] ?? null;
      $add->hr_position = $hr_positions[0] ?? null;
      $add->branch_id = $branch_id;
      $add->created_by = $user_id;
      $add->updated_by = $user_id;
      $add->save();

      // If the company is successfully created, add HR details
      if ($add) {
          $hr_company_id = $add->sno;
          $hr_count = count($hr_names);
        
          for ($i = 0; $i < $hr_count; $i++) {
              $hr_name_info = $hr_names[$i] ?? null;
              $hr_mobile_info = $hr_mobiles[$i] ?? null;
              $hr_email_info = $hr_emails[$i] ?? null;
              $hr_position_info = $hr_positions[$i] ?? null;

              if ($hr_name_info && $hr_mobile_info) {
                  // Check if HR already exists
                  $chk_hr = HrModel::where('hr_mobile_no', $hr_mobile_info)
                    ->where('branch_id', $branch_id)
                    ->first();

                  if (!$chk_hr) {
                      // Add new HR data
                      $add_hr = new HrModel();
                      $add_hr->company_id = $hr_company_id;
                      $add_hr->hr_name = $hr_name_info;
                      $add_hr->hr_mobile_no = $hr_mobile_info;
                      $add_hr->hr_email_id = $hr_email_info;
                      $add_hr->hr_position = $hr_position_info;
                      $add_hr->branch_id = $branch_id;
                      $add_hr->created_by = $user_id;
                      $add_hr->updated_by = $user_id;
                      $add_hr->save();
                  }
              }
          }
      }

      session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Company added successfully!'
      ]);

      return redirect('placements/manage_company');
  }


//   public function AddJob(Request $request)
//   {
//       // Validate the request data
//       $validator = Validator::make($request->all(), [
//           'job_category_add' => 'required|max:255',
//           'job_role_add' => 'required|max:255',
//       ]);

//       if ($validator->fails()) {
//           session()->flash('toastr', [
//               'type' => 'error',
//               'message' => 'Incorrect format input fields'
//           ]);
//           return redirect()->back();
//       }

//       $branch_id = $request->user()->branch_id;
//       $user_id = $request->user()->user_id;

//       // Get request data
//       $job_type = $request->job_type;
//       $company_id = $request->job_company_id;
//       $job_category_id = $request->job_category_add;
//       $job_subcategory_id = $request->job_role_add;
//       $interview_mode_id = $request->job_interview_mode_add;
//       $interview_date = $request->job_interview_date ? date('Y-m-d', strtotime($request->job_interview_date)) : null ;
//       $last_apply_date =$request->job_last_date_add ? date('Y-m-d', strtotime($request->job_last_date_add)) : null ;
//       $salary = $request->job_salary_add;
//       $vacancy_count = $request->job_vacancy_add ?? null;
//       $experience = $request->job_experience_add ?? null;
//       $auth_staff_id = $request->add_job_staff_id ?? null;
//       $skill_description = is_array($request->job_skill_desc) ? json_encode($request->job_skill_desc) : $request->job_skill_desc;

//       $job_interview_chk = $request->job_interview_chk_id ?? [];
//       $interview_checklist_id= json_encode($job_interview_chk);
     
    

//       // Generate a unique Job ID
//       $last_entry = JobModel::where('status', '!=', 2)
//           ->orderBy('sno', 'desc')
//           ->first();

//       if (!$last_entry) {
//           $year = substr(date('y'), -2);
//           $job_id = 'JOB-0001/' . $year;
//       } else {
//           $data = $last_entry->job_id;
//           $slice = explode('/', $data);
//           $result = preg_replace('/[^0-9]/', '', $slice[0]);
//           $next_number = (int)$result + 1;
//           $job_id = sprintf('JOB-%04d', $next_number) . '/' . substr(date('y'), -2);
//       }

//       // Create a new company record
//       $add = new JobModel();
//       $add->job_id = $job_id;
//       $add->job_type = $job_type;
//       $add->company_id = $company_id;
//       $add->job_category_id = $job_category_id;
//       $add->job_subcategory_id = $job_subcategory_id;
//       $add->interview_mode_id = $interview_mode_id;
//       $add->interview_date = $interview_date;
//       $add->last_apply_date = $last_apply_date;
//       $add->salary = $salary;
//       $add->vacancy_count = $vacancy_count;
//       $add->experience = $experience;
//       $add->skill_description = $skill_description;
//       $add->auth_staff_id = $auth_staff_id;
//       $add->interview_checklist_id = $interview_checklist_id;
//       $add->branch_id = $branch_id;
//       $add->created_by = $user_id;
//       $add->updated_by = $user_id;
//       $add->save();

//       if($add){
//         $company_data = PlacementCompanyModel::where('sno', $company_id)->first();
//         $company_data->total_job_counts  +=1;
//         $company_data->Update();
//       }

//       session()->flash('toastr', [
//           'type' => 'success',
//           'message' => 'Job added successfully!'
//       ]);

//       return redirect('placements/manage_jobs');
//   }

    public function AddJob(Request $request)
{
    // Validate the request data
    $validator = Validator::make($request->all(), [
        'job_category_add' => 'required|max:255',
        'job_role_add' => 'required|max:255',
        'branch_ids' => 'required|array|min:1', // Validate that at least one branch is selected
        'branch_ids.*' => 'integer|exists:za_branch,sno', // Validate each branch exists
    ]);
 
    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Incorrect format input fields'
        ]);
        return redirect()->back()->withErrors($validator)->withInput();
    }
 
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
 
    // Get request data
    $job_type = $request->job_type;
    $company_id = $request->job_company_id;
    $job_category_id = $request->job_category_add;
    $job_subcategory_id = $request->job_role_add;
    $interview_mode_id = $request->job_interview_mode_add;
    $interview_date = $request->job_interview_date ? date('Y-m-d', strtotime($request->job_interview_date)) : null;
    $last_apply_date = $request->job_last_date_add ? date('Y-m-d', strtotime($request->job_last_date_add)) : null;
    $salary = $request->job_salary_add;
    $vacancy_count = $request->job_vacancy_add ?? null;
    $experience = $request->job_experience_add ?? null;
    $auth_staff_id = $request->add_job_staff_id ?? null;
    $skill_description = is_array($request->job_skill_desc) ? json_encode($request->job_skill_desc) : $request->job_skill_desc;
    $job_interview_chk = $request->job_interview_chk_id ?? [];
    $interview_checklist_id = json_encode($job_interview_chk);
    $branch_ids = $request->branch_ids; // Get all selected branch IDs
 
    // Generate a unique Job ID
    $last_entry = JobModel::where('status', '!=', 2)
        ->orderBy('sno', 'desc')
        ->first();
 
    if (!$last_entry) {
        $year = substr(date('y'), -2);
        $job_id = 'JOB-0001/' . $year;
    } else {
        $data = $last_entry->job_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $job_id = sprintf('JOB-%04d', $next_number) . '/' . substr(date('y'), -2);
    }
 
    // Convert branch_ids array to JSON for storage
    $branch_ids_json = json_encode($branch_ids);
 
    // Create a new job record
    $add = new JobModel();
    $add->job_id = $job_id;
    $add->job_type = $job_type;
    $add->company_id = $company_id;
    $add->job_category_id = $job_category_id;
    $add->job_subcategory_id = $job_subcategory_id;
    $add->interview_mode_id = $interview_mode_id;
    $add->interview_date = $interview_date;
    $add->last_apply_date = $last_apply_date;
    $add->salary = $salary;
    $add->vacancy_count = $vacancy_count;
    $add->experience = $experience;
    $add->skill_description = $skill_description;
    $add->auth_staff_id = $auth_staff_id;
    $add->interview_checklist_id = $interview_checklist_id;
    $add->branch_id = $branch_id; // Save as JSON instead of single branch_id
    $add->branch_ids = $branch_ids_json; // Save as JSON instead of single branch_id
    $add->created_by = $user_id;
    $add->updated_by = $user_id;
    $add->save();
 
    if ($add) {
        $company_data = PlacementCompanyModel::where('sno', $company_id)->first();
        if ($company_data) {
            $company_data->total_job_counts += 1;
            $company_data->update();
        }
    }
 
    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Job added successfully!'
    ]);
 
    return redirect('placements/manage_jobs');
}

  public function View($id,Request $request)
{
    
    $branch_id = $request->user()->branch_id;
    $company_data = PlacementCompanyModel::select('za_placement_company.*')
        ->leftJoin('za_jobs','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->where('za_placement_company.status', '!=', 2)
        ->where('za_placement_company.branch_id', $branch_id)
        ->where('za_placement_company.sno', $id)
        ->first(); 
   
    if ($company_data) {
        $hrdetails = DB::table('za_company_hr')
            ->select('za_company_hr.hr_name', 'za_company_hr.hr_mobile_no', 'za_company_hr.hr_email_id')
            ->where('za_company_hr.branch_id', $branch_id)
            ->where('za_company_hr.company_id', $id)
            ->orderBy('za_company_hr.sno', 'asc')
            ->get();
        $company_data->mou_file = json_decode($company_data->mou_file);
        $company_data->hr_info = $hrdetails;
        $company_data->hr_count = $hrdetails->count();
        
         $job_list = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->whereNotIn('za_jobs.status', [1,2])
        ->where('za_jobs.company_id', $id)
        ->get();
        $students=[];
        foreach($job_list as $job ){
          if (!empty($job->interest_student_ids)) {
            $customer_ids = json_decode($job->interest_student_ids, true);
            $students = DB::table('za_placement_interview')
                ->select('za_placement_interview.status','za_jobs.salary', 'za_jobs.interview_date','za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_interview.interview_checklist_status')
                ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                ->join('za_jobs','za_jobs.sno', '=', 'za_placement_interview.job_id')
                ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
                ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
                ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('za_placement_interview.customer_id', $customer_ids)
                ->where('za_placement_interview.job_id', $job->sno)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
                foreach( $students as $single){
                  $interview_checklist_status = json_decode($single->interview_checklist_status, true);
                  $single->interview_checklist_status=$interview_checklist_status;
              }
            $job->customer_list = $students;
            $job->intrested_student_count = count($customer_ids); 
            $interview_checklist_id = json_decode($job->interview_checklist_id, true);
                $chk_list = DB::table('za_interview_checklist')
                        ->select('za_interview_checklist.interview_checklist_name','za_interview_checklist.sno as checklist_id')
                        ->where('za_interview_checklist.status', '!=', 2)
                        ->whereIn('za_interview_checklist.sno', $interview_checklist_id)
                        ->get();
            $job->interview_chk_list = $chk_list;
          }

        }

        $company_data->job_list=$students;

    } else {
        $company_data = (object) [
            'hr_info' => [],
            'hr_count' => 0,
            'job_list'=>[]
        ];
    }
   
    return response()->json([
        'status' => 200,
        'success' => true,
        'message' => null,
        'error_msg' => null,
        'data' => $company_data ,
    ], 200);
}


  // Status change
  public function Status($id, Request $request)
  {
    $upd_companyModel =  PlacementCompanyModel::where('sno', $id)->first();
    $upd_companyModel->status = $request->input('status', 0);
    $upd_companyModel->update();
    if ($upd_companyModel) {
      return response([
        'status'    => 200,
        'message'   => 'Company Status Successfully Updated !',
        'error_msg' => 'Could not ,update Company!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 204,
        'message'   => 'Could not update Company!',
        'error_msg' => 'Could not ,update  Company!',
        'data'      => null,
      ], 204);
    }
  }

  //delete function
  public function Delete($id)
  {

    $upd_companyModel =  PlacementCompanyModel::where('sno', $id)->first();
    $upd_companyModel->status  = 2;
    $upd_companyModel->Update();
    if ($upd_companyModel) {
      return response([
        'status'    => 200,
        'message'   => 'Company Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Company!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }


    public function AddInterestStudent(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'interested_student_ids' => 'required|array',  // Must be an array
            'interested_student_ids.*' => 'integer',  // Each ID must be an integer
        ]);
    
        // Check if validation fails
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format in input fields.'
            ]);
            return redirect()->back();
        }
    
        // Get the user information and request data
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $job_id = $request->intrst_job_id;
        $job_student = $request->interested_student_ids ?? [];
    
        // Convert student IDs array to JSON format
        $interested_student_id = json_encode($job_student);
        $company_data = JobModel::where('sno', $job_id)->first();
    
        if ($company_data) {
            // Update the job with the new list of interested student IDs
            $company_data->interest_student_ids = $interested_student_id;
            $company_data->update();
    
            // Step 1: Remove all existing interview data for the given job ID
            InterviewModel::where('job_id', $job_id)
                ->where('branch_id', $branch_id)
                ->delete();  // Delete all interview entries for this job ID and branch
    
            // Step 2: Add new students
            foreach ($job_student as $studentid) {
                // Check if the interview already exists (though this should not happen since we're deleting first)
                $chk = InterviewModel::where('job_id', $job_id)
                    ->where('customer_id', $studentid)
                    ->where('branch_id', $branch_id)
                    ->first();
    
                // Generate a unique placement interview ID
                $last_interv_entry = InterviewModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();
    
                if (!$last_interv_entry) {
                    $year = substr(date('y'), -2);
                    $placement_interview_id = 'SIV-0001/' . $year;
                } else {
                    $data = $last_interv_entry->placement_interview_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $placement_interview_id = sprintf('SIV-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                $job = JobModel::where('sno', $job_id)->first();
                $interview_checklist_id = json_decode($job->interview_checklist_id ?? '[]');  
                $interview_checklist_status = array_fill(0, count($interview_checklist_id), "0");
    
                // Create a new interview entry for the student
                $add = new InterviewModel();
                $add->placement_interview_id = $placement_interview_id;
                $add->customer_id = $studentid;
                $add->job_id = $job_id;
                $add->interview_checklist_status = json_encode($interview_checklist_status);
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                $add->save();
            }
    
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Interest students added successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Job not found!'
            ]);
        }
    
        return redirect('placements/manage_placement');
    }    


    public function jobCategoryList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $jobCategory     = DB::table('za_job_category')->select('za_job_category.*')
        ->where('za_job_category.status', '!=', 2)
        ->orderBy('za_job_category.job_category_name', 'asc')
        ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $jobCategory,
        ], 200);
    }

    public function List(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $jobCategory     = DB::table('za_placement_company')->select('za_placement_company.*')
        ->where('za_placement_company.status', '!=', 2)
        ->orderBy('za_placement_company.company_name', 'asc')
        ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $jobCategory,
        ], 200);
    }

    public function getJobRolelist(Request $request)
    {
        $job_category_id = $request->input('job_category_id');
        $jobRole = DB::table('za_job_subcategory')->select('za_job_subcategory.*')->where('za_job_subcategory.status', 0)
            ->where('za_job_subcategory.job_category_id', $job_category_id)
            ->get();

        return response()->json([
            'status' => 200,
            'data' => $jobRole,
        ]);
    }


    // Generate AI Skill Tags
    public function generateAITags(Request $request)
    {
        $jobCategory = $request->input('job_category');
        $jobRole = $request->input('job_role');

        // First try the fallback API
        $aiTags = $this->getAITagsFromAPIFallBack($jobCategory, $jobRole);

        // If fallback returns empty, use the main API
        if (empty($aiTags)) {
            $aiTags = $this->getAITagsFromAPI($jobCategory, $jobRole);
        }

        return response()->json([
            'status' => 200,
            'data' => $aiTags,
        ]);
    }

    private function getAITagsFromAPI($jobCategory, $jobRole)
    {
        $prompt = "Generate a comma-separated list of skill tags for job category '{$jobCategory}' and role '{$jobRole}'.";

        $aiResponse = $this->chatGPTService->getChatGPTResponse($prompt);

        if (!$aiResponse) {
            return [];
        }

        // Extract the tags string from the response
        if (is_array($aiResponse)) {
            // Try to find the text content in the expected structure
            if (isset($aiResponse['choices'][0]['message']['content'])) {
                $tagsString = $aiResponse['choices'][0]['message']['content'];
            } elseif (isset($aiResponse['raw']) && is_string($aiResponse['raw'])) {
                $tagsString = $aiResponse['raw'];
            } else {
                // Unable to get a string, return empty array
                return [];
            }
        } elseif (is_string($aiResponse)) {
            $tagsString = $aiResponse;
        } else {
            // Unexpected type
            return [];
        }

        // Now explode only if $tagsString is a string
        if (is_string($tagsString)) {
            $tagsArray = array_filter(array_map('trim', explode(',', $tagsString)));
            return $tagsArray;
        }

        return [];
    }


    private function getAITagsFromAPIFallBack($jobCategory, $jobRole)
    {
            $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; // DeepSeek API
            $fallbackApiUrl = 'https://api.together.xyz/v1/chat/completions'; // LLaMA API

            $primaryApiKey = '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';  // Replace with your OpenRouter API key
            $fallbackApiKey = '616a73d21c4d1749a3671db5c9c42668afc783ccc76d7d5eb51f7defa03010b3';   // Replace with your Together AI API key

            // Define prompt
            $prompt = "Generate a comma-separated list of skill tags for job category '$jobCategory' and role '$jobRole'.";

            // Primary API Request (DeepSeek)
            $response = Http::withHeaders([
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "HTTP-Referer" => "https://erp.elysium.academy",
                "X-Title" => "SkillTagGenerator",
            ])->post($primaryApiUrl, [
                'model' => "deepseek/deepseek-r1:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => 50,
            ]);

            // Check if primary API failed
            if ($response->failed()) {
                // Use fallback API (Llama)
                $response = Http::withHeaders([
                    'Authorization' => "Bearer $fallbackApiKey",
                    'Content-Type' => 'application/json',
                ])->post($fallbackApiUrl, [
                    'model' => "meta-llama/Llama-Vision-Free",
                    'messages' => [['role' => 'user', 'content' => $prompt]],
                    'max_tokens' => 50,
                ]);
            }

            // Parse Response
            $data = $response->json();

            if (isset($data['choices'][0]['message']['content'])) {
                $tags = array_map('trim', explode(',', $data['choices'][0]['message']['content']));
                array_shift($tags);
                return $tags;
            }

            return [];
        }
        
        
        public function uploadMOU(Request $request)
        {
        // Validate request input
        $validated = $request->validate([
            'file_upload' => 'required',
            'upload_company_id' => 'required|integer',
        ]);
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
    
        $companyId = $validated['upload_company_id'];
       
        $company_name = DB::table('za_placement_company')->where('sno', $companyId)->value('company_name');
    
        // Define base and material directories dynamically
        $baseDirectory = public_path("company_mou/{$companyId}");
    
        // Ensure directories exist
        if (!file_exists($baseDirectory)) {
            mkdir($baseDirectory, 0755, true);
        }
    
        $files = $request->file('file_upload');
        $storedFiles = [];
    
        $existingMouFile = DB::table('za_placement_company')->where('sno', $companyId)->value('mou_file');
        $existingMouFile = $existingMouFile ? json_decode($existingMouFile, true) : [];

        // Determine the starting index for the filenames
        $currentIndex = count($existingMouFile) + 1;
    
        foreach ($files as $file) {
            // Generate the new filename based on company ID and current index
            $newFilename = "mou_{$companyId}_{$currentIndex}." . $file->getClientOriginalExtension();
    
            // Move the file to the designated directory
            $file->move($baseDirectory, $newFilename);
            $storedFiles[$currentIndex] = $newFilename;
    
            $currentIndex++; // Increment for the next file
        }
    
        $updatedMouFile = array_merge($existingMouFile, $storedFiles);
    
        // Update the database with the updated materials
        $storedFilesJson = json_encode($updatedMouFile);
        $successUpload = DB::table('za_placement_company')->where('sno', $companyId)->first();
        if ($successUpload) {
            if ($successUpload->mou_status == '0') {
                $successUpload->mou_upload_date = date('Y-m-d');
            }
        
            $successUpload->mou_file = $storedFilesJson;
        
            DB::table('za_placement_company')->where('sno', $companyId)->update([
                'mou_upload_date' => $successUpload->mou_upload_date,
                'mou_status' => 1,
                'updated_by' => $user_id,
                'mou_file' => $storedFilesJson
            ]);
        
            return response()->json(['success' => true, 'message' => 'MOU file updated successfully.']);
       
        } else {
            return response()->json(['success' => false, 'message' => 'Files uploading failed.']);
        }
    }
    public function Authority_staff_list(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $staffs = StaffModel::where('status', 0)->where('branch_id', $branch_id)->get();

        if(!$staffs) {
        return response([
            'status' => 400,
            'message' => 'No Such Records !',
            'error_msg' => null,
            'data' => null
        ], 404);
        } else {
        return response([
            'status' => 200,
            'message' => 'Authority Staffs Fetched Successfully',
            'error_msg' => null,
            'data' => $staffs
        ], 200);
        }
    }

    public function Edit($id, Request $request)
    {
        $PlacementCompany = PlacementCompanyModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();
        $branch_id = $request->user()->branch_id;
        
        if ($PlacementCompany) {

            $HrModel = HrModel::where('company_id',$PlacementCompany->sno)->where('branch_id',$branch_id)->where('status',0)->get();

            return response()->json([
                'status' => 200,
                'data' => [
                    'sno' => $PlacementCompany->sno ?? 0,
                    'branch_id' => $PlacementCompany->branch_id,
                    'company_id' => $PlacementCompany->company_id,
                    'company_name' => $PlacementCompany->company_name,
                    'company_email' => $PlacementCompany->company_email,
                    'company_address' => $PlacementCompany->company_address,
                    'location_url' => $PlacementCompany->location_url,
                    'website_url' => $PlacementCompany->website_url,
                    'job_role' => $PlacementCompany->job_role,
                    'company_desc' => $PlacementCompany->company_desc,
                    'hr_contact_name' => $PlacementCompany->hr_contact_name,
                    'hr_contact_phone' => $PlacementCompany->hr_contact_phone,
                    'hr_contact_email' => $PlacementCompany->hr_contact_email,
                    'hired_student_counts' => $PlacementCompany->hired_student_counts,
                    'total_job_counts' => $PlacementCompany->total_job_counts,
                    'created_at' => $PlacementCompany->created_at,
                    'created_by' => $PlacementCompany->created_by,
                    'updated_at' => $PlacementCompany->updated_at,
                    'updated_by' => $PlacementCompany->updated_by,
                    'p_company_status' => $PlacementCompany->p_company_status,
                    'mou_file' => $PlacementCompany->mou_file,
                    'mou_upload_date' => $PlacementCompany->mou_upload_date,
                    'mou_statu' => $PlacementCompany->mou_status,
                    'hr_details' => $HrModel ?? null
                ],
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Placement Company not found',
            ]);
        }
    }

    public function UpdateCompany(Request $request){

        // return $request;

        $rules = [
            'place_comp_sno' => 'required',
            'company_name' => 'required',
            'company_email' => 'required',
            'address' => 'required',
            'location_url' => 'required',
            'website_url' => 'required',
            'company_job_role' => 'required',
            'hr_details' => 'required|array',
            'hr_details.*.hr_name' => 'required',
            'hr_details.*.hr_mobile' => 'required',
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }

        $place_comp_sno = $request->input('place_comp_sno');
        $company_name = $request->input('company_name');
        $company_email = $request->input('company_email');
        $address = $request->input('address');
        $location_url = $request->input('location_url');
        $website_url = $request->input('website_url');
        $company_job_role = $request->input('company_job_role');
        $description = $request->input('description', NULL);
        $hr_details = $request->input('hr_details', []);
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        // Check if the company already exists
        $chk = PlacementCompanyModel::where('company_name', $company_name)
        ->where('branch_id', $branch_id)
        ->where('sno', '!=', $place_comp_sno)
        ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Company is Already Exist!'
            ]);
            return redirect('placements/manage_company');
        }

        $save = false;
        if(!empty($place_comp_sno)){

            $update_comp = PlacementCompanyModel::where('sno', $place_comp_sno)->first();
            $update_comp->company_name = $company_name;
            $update_comp->company_email = $company_email;
            $update_comp->company_address = $address;
            $update_comp->location_url = $location_url;
            $update_comp->website_url = $website_url;
            $update_comp->job_role = $company_job_role;
            $update_comp->company_desc = $description;
            $update_comp->hr_contact_name = isset($hr_details[0]['hr_name']) && !empty($hr_details[0]['hr_name']) ? $hr_details[0]['hr_name'] : NULL;
            $update_comp->hr_position = isset($hr_details[0]['hr_position']) && !empty($hr_details[0]['hr_position']) ? $hr_details[0]['hr_position'] : NULL;
            $update_comp->hr_contact_phone = isset($hr_details[0]['hr_mobile']) && !empty($hr_details[0]['hr_mobile']) ? $hr_details[0]['hr_mobile'] : NULL;
            $update_comp->hr_contact_email = isset($hr_details[0]['hr_email']) && !empty($hr_details[0]['hr_email']) ? $hr_details[0]['hr_email'] : NULL;
            $update_comp->updated_by = $user_id;
            if($update_comp->update()){
                $save = true;
                if(!empty($hr_details)){

                    HrModel::where('company_id', $place_comp_sno)->where('branch_id',$branch_id)->update(['status' => 2]);

                    foreach ($hr_details as $index => $hr_data) {

                        $hr_sno = isset($hr_data['hr_sno']) && !empty($hr_data['hr_sno']) ? $hr_data['hr_sno'] : '';
                        $hr_name = isset($hr_data['hr_name']) && !empty($hr_data['hr_name']) ? $hr_data['hr_name'] : '';
                        $hr_mobile = isset($hr_data['hr_mobile']) && !empty($hr_data['hr_mobile']) ? $hr_data['hr_mobile'] : '';
                        $hr_email = isset($hr_data['hr_email']) && !empty($hr_data['hr_email']) ? $hr_data['hr_email'] : '';
                        $hr_position = isset($hr_data['hr_position']) && !empty($hr_data['hr_position']) ? $hr_data['hr_position'] : '';
                        // return $hr_sno;

                        if(empty($hr_sno)){

                            $validHrModel = HrModel::where('hr_name','=',$hr_name)->where('hr_mobile_no','=',$hr_mobile)->where('hr_email_id','=',$hr_email)->where('hr_position','=',$hr_position)->where('company_id',$place_comp_sno)->where('branch_id',$branch_id)->first();

                            if(!empty($validHrModel)){
                                $validHrModel->status = 0;
                                $validHrModel->updated_by = $user_id;
                                $validHrModel->update();
                                $save = true;
                            }else{
                                $addHrModel = new HrModel();
                                $addHrModel->branch_id = $branch_id;
                                $addHrModel->hr_name = $hr_name;
                                $addHrModel->hr_mobile_no = $hr_mobile;
                                $addHrModel->hr_email_id = $hr_email;
                                $addHrModel->hr_position = $hr_position;
                                $addHrModel->company_id = $place_comp_sno;
                                $addHrModel->created_by = $user_id;
                                $addHrModel->updated_by = $user_id;
                                $addHrModel->save();
                                $save = true;
                            }
                        }else{
                            $updateHrModel = HrModel::where('sno',$hr_sno)->where('branch_id',$branch_id)->first();
                            $updateHrModel->hr_name = isset($hr_data['hr_name']) && !empty($hr_data['hr_name']) ? $hr_data['hr_name'] : NULL;
                            $updateHrModel->hr_mobile_no = isset($hr_data['hr_mobile']) && !empty($hr_data['hr_mobile']) ? $hr_data['hr_mobile'] : NULL;
                            $updateHrModel->hr_email_id = isset($hr_data['hr_email']) && !empty($hr_data['hr_email']) ? $hr_data['hr_email'] : NULL;
                            $updateHrModel->hr_position = isset($hr_data['hr_position']) && !empty($hr_data['hr_position']) ? $hr_data['hr_position'] : NULL;
                            $updateHrModel->status = 0;
                            $updateHrModel->company_id = $place_comp_sno;
                            $updateHrModel->created_by = $user_id;
                            $updateHrModel->updated_by = $user_id;
                            $updateHrModel->update();
                            $save = true;
                        }
                    }
                }
            }
            if($save){
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Company Updated Successfully!'
                ]);
            }else{
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Company Not Updated!'
                ]);
            }
            return redirect('placements/manage_company');
        }else{
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Company Not Found!'
            ]);
            return redirect('placements/manage_company');
        }
    }

    public function Add_category_list(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'add_value' => 'required',
            'add_category_id' => 'required',
        ]);

        
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $type = (int)$request->input('type','1');
        $add_value = $request->input('add_value', null);
        $add_category_id = $request->input('add_category_id', null);
        $field_name = $type == 2 ? 'Job Role' : 'Job Category';
        
        if($type == 2){
            $chk = JobSubCategoryModel::where('job_subcategory_name', $add_value)->where('job_category_id', $add_category_id)->first();
        }else{
            $chk = JobCategoryModel::where('job_category_name', $add_value)->first();
        }

        if (!empty($chk)) {
            return response()->json([
                'status' => 400,
                'message' => $field_name.' Name is Already Exist!',
                'error_msg' => null,
                'data' => null
            ], 400);
        }

        $save = true;

        if($type == 2){
            $add_sub_category = new JobSubCategoryModel();
            $add_sub_category->job_category_id       = $add_category_id;
            $add_sub_category->job_subcategory_name  = Ucfirst($add_value);
            $add_sub_category->job_subcategory_descr = NULL;
            $add_sub_category->branch_id          = 1;
            $add_sub_category->created_by         = $user_id;
            $add_sub_category->updated_by         = $user_id;
            if($add_sub_category->save()){
                $save = true;
            }
        }else if($type == 1){
            $add_category = new JobCategoryModel();
            $add_category->job_category_name  = Ucfirst($add_value);
            $add_category->job_category_descr = NULL;
            $add_category->branch_id          = 1;
            $add_category->created_by         = $user_id;
            $add_category->updated_by         = $user_id;
            if($add_category->save()){
                $save = true;
            }
        }

        if($save) {
            return response()->json([
                'status' => 200,
                'message' => $field_name.' Added Successfully',
                'error_msg' => null,
                'data' => null
            ], 200);
        } else {
            return response()->json([
                'status' => 400,
                'message' => $field_name.' Added Unsuccessfully',
                'error_msg' => null,
                'data' => null
            ], 400);
        }
    }
}