<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\JobDirectoryModel;
use App\Models\JobDirectoryJobModel;
use App\Models\HrDirectoryModel;
use App\Models\InterviewTypeModel;
use App\Models\CourseTypeModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\InterviewCheckListModel;
use App\Models\IndustryJobNameModel;
use Illuminate\Support\Facades\DB;
use DateTime;

class JobDirectory extends Controller
{
  protected static $branch_id = 1;

  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $job_details = JobDirectoryJobModel::select(
      'za_job_directorys_job.sno',
      'za_job_directorys_job.salary',
      'za_job_directorys_job.job_name_id',
      'za_job_directorys_job.job_interview_date',
      'za_job_directorys_job.interview_type_id',
      'za_job_directorys_job.vacancy_count',
      'za_job_directorys_job.job_link',
      'za_job_directorys_job.job_description',
      'za_industry_job_name.job_name',
      'za_interview_type.interview_type_name',
      'za_job_directory.sno as job_dir_sno',  // Include job_dir_sno in the select
      'za_job_directory.status',  // Include job_dir_sno in the select
      'za_hr_directory.company_name',
      'za_hr_directory.hr_contact_name',
      'za_hr_directory.hr_contact_phone',
      'za_hr_directory.address'
    )
      ->join('za_job_directory', 'za_job_directory.sno', '=', 'za_job_directorys_job.job_dir_id')  // Join with job directory
      ->join('za_industry_job_name', 'za_job_directorys_job.job_name_id', '=', 'za_industry_job_name.sno')
      ->join('za_interview_type', 'za_job_directorys_job.interview_type_id', '=', 'za_interview_type.sno')
      ->join('za_hr_directory', 'za_hr_directory.sno', '=', 'za_job_directory.job_company_id')  // Join HR directory
      ->where('za_job_directory.status', '!=', 2)
      ->where('za_job_directory.branch_id', $branch_id)  // Uncomment if needed
      ->where('za_job_directory.status', '!=', 2)
      ->orderBy('za_job_directorys_job.sno', 'desc')
      ->get();


    // return  $job_details;


    // return $job_directory_list;

    // exit;

    return view('content.placements_events.job_directory.list', [
      // 'job_directory_list' => $job_directory_list,
      'job_details' => $job_details,

    ]);
  }
  public function create_job_directory()
  {
    return view('content.placements_events.job_directory.add');
  }
  public function update_job_directory()
  {
    return view('content.placements_events.job_directory.edit');
  }

  public function InterviewChecklist_list()
  {
    $interview_checklist = InterviewCheckListModel::select('*')
      ->where('za_interview_checklist.status', '=', 0)
      ->orderBy('za_interview_checklist.sno', 'desc')
      ->get();
    // return   $interview_checklist;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $interview_checklist
    ], 200);
  }

  public function hr_directory_details($id = '')
  {
    // return $id; D:\Xampp_8.2.4\htdocs\elysium_erp_18-10-2024\resources\views\content\placements_events\job_directory\add.blade.php
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $job_add   = HrDirectoryModel::where('sno', $decryptedValue)->first();
    //  return  $edit;


    return view('content.placements_events.job_directory.add', [
      'job_add' => $job_add,

    ]);
  }
  // public function Job_based_on_course_type($id = '')
  // {
  //   // Get course type information
  //   if ($id == 0) {
  //     $course_type_info = CourseTypeModel::select(
  //       'za_course_type.sno',
  //       'za_course_type.course_type_name',
  //       'za_course_type.premium',
  //       'za_course.sno as course_sno',
  //       'za_course.course_name',
  //       'za_course.knowledge_tags'
  //     )
  //       ->leftJoin('za_course', 'za_course_type.sno', '=', 'za_course.course_type_id')
  //       ->where('za_course_type.status', 0)
  //       ->get();
  //   } elseif ($id == 1) {
  //     $course_type_info = CourseTypeModel::select(
  //       'za_course_type.sno',
  //       'za_course_type.course_type_name',
  //       'za_course_type.premium',
  //       'za_course.sno as course_sno',
  //       'za_course.course_name',
  //       'za_course.knowledge_tags'
  //     )
  //       ->leftJoin('za_course', 'za_course_type.sno', '=', 'za_course.course_type_id')
  //       ->where('za_course_type.premium', '=', $id)
  //       ->where('za_course_type.status', '!=', 2)
  //       ->get();
  //   } elseif ($id == 1) {
  //     $course_type_info = CourseTypeModel::select(
  //       'za_course_type.sno',
  //       'za_course_type.course_type_name',
  //       'za_course_type.premium',
  //       'za_course.sno as course_sno',
  //       'za_course.course_name',
  //       'za_course.knowledge_tags'
  //     )
  //       ->leftJoin('za_course', 'za_course_type.sno', '=', 'za_course.course_type_id')
  //       ->where('za_course_type.status', 0)
  //       ->get();
  //   }




  //   return response([
  //     'status' => 200,
  //     'message' => null,
  //     'error_msg' => null,
  //     'data' => [  // Wrap the values in a 'data' key
  //       'course_type_info' => $course_type_info,

  //     ]
  //   ], 200);
  // }
  public function Job_List($id)
  {
    // Ensure the ID is valid and not empty

    // return $id;
    $job_name = IndustryJobNameModel::select('job.sno', 'job.industry_type_id', 'job.job_name')
      ->from('za_industry_job_name as job')
      ->join('za_hr_directory as hr', 'hr.industry_type_id', '=', 'job.industry_type_id')
      ->where('job.industry_type_id', $id)
      ->where('job.status', 0)
      ->distinct()
      ->get();

    // return $job_name;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $job_name
    ], 200);
  }




  //add D:\Xampp_8.2.4\htdocs\eapl_updated\app\Models\JobDirectoryModel.php
  // public function Add(Request $request)
  // {

  //   // return $request;
  //   // $validator = Validator::make($request->all(), [
  //   //   'company_name_dropdown' => 'required|max:255'
  //   // ]);

  //   // if ($validator->fails()) {
  //   //   // If validation fails, return error response
  //   //   session()->flash('toastr', [
  //   //     'type' => 'error',
  //   //     'message' => 'Incorrect format input fields'
  //   //   ]);
  //   //   return redirect()->back();
  //   // }

  //   // If validation passes

  //   $job_directory_id = $request->job_directory_id;
  //   // company info
  //   $company_name_dropdown = $request->company_name_dropdown_select;
  //   $company_branch_dropdown = $request->company_branch_dropdown_select;
  //   $comp_interview_date = $request->comp_interview_date;
  //   $notification_duration = $request->notification_duration;
  //   $course_type_dropdown_select = $request->course_type_dropdown_select;
  //   $company_descritpion = $request->company_descritpion;

  //   //vacancy info
  //   $job_position_name = $request->job_position_name;
  //   $job_salary = $request->job_salary;
  //   $interview_type_dropdown = $request->interview_type_dropdown;
  //   $vacancy_count = $request->vacancy_count;
  //   $job_postion_interv_date = $request->job_postion_interv_date;
  //   $job_description = $request->job_description;

  //   // return $job_postion_interv_date;

  //   $user_id = $request->user()->user_id;


  //   // Generate a unique category ID
  //   $jobdirectory_check = JobDirectoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

  //   if (!$jobdirectory_check) {
  //     $year = substr(date('y'), -2);
  //     $job_directory_id = 'JRD-0001/' . $year;
  //   } else {
  //     $data = $jobdirectory_check->job_directory_id;
  //     $slice = explode('/', $data);
  //     $result = preg_replace('/[^0-9]/', '', $slice[0]);
  //     $next_number = (int)$result + 1;
  //     $requestId = sprintf('JRD-%04d', $next_number);
  //     $year = substr(date('y'), -2);
  //     $job_directory_id = $requestId . '/' . $year;
  //   }

  //   // Add the category to the database

  //   $add = new JobDirectoryModel();

  //   //company info
  //   $add->job_directory_id = $job_directory_id;
  //   $add->job_company_id = $company_name_dropdown;
  //   $add->company_branch_id = $company_branch_dropdown;
  //   $add->interview_date = $comp_interview_date;
  //   $add->duration = $notification_duration;
  //   $add->course_type_id = $course_type_dropdown_select;
  //   $add->company_description = $company_descritpion;


  //   $add->job_postion_name = json_encode($job_position_name);
  //   $add->job_salary = json_encode($job_salary);
  //   $add->interview_type_id = json_encode($interview_type_dropdown);
  //   $add->vacancy_count = json_encode($vacancy_count);
  //   $add->job_interview_date = json_encode($job_postion_interv_date);
  //   $add->job_descritpion = json_encode($job_description);
  //   $add->branch_id = self::$branch_id;
  //   $add->created_by =  $request->user()->user_id;
  //   $add->updated_by = $request->user()->user_id;

  //   $add->save();

  //   if ($add) {
  //     session()->flash('toastr', [
  //       'type' => 'success',
  //       'message' => 'Job Directory added Successfully!'
  //     ]);
  //   } else {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Could not add the Job Directory!'
  //     ]);
  //   }
  //   // }

  //   return redirect()->back();
  // }
  public function Add(Request $request)
  {
    // return $request;
    // Validate request
    $validator = Validator::make($request->all(), [
      'comp_name_id' => 'required|max:255',
      // Add other validation rules as needed
    ]);

    if ($validator->fails()) {
      // If validation fails, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back()->withErrors($validator)->withInput();
    }

    // Retrieve and sanitize data from request
    $job_directory_id = $this->generateJobDirectoryId();
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    // Add the job directory to the database
    $add = new JobDirectoryModel();
    $add->job_directory_id = $job_directory_id;
    $add->job_company_id = $request->comp_name_id;
    // $add->interview_date = DateTime::createFromFormat('d-M-Y', $request->comp_interview_date)->format('Y-m-d');
    $add->duration = $request->notification_duration;
    $add->interview_to = $request->interview_to;
    $add->company_description = $request->company_description;
    $add->branch_id = $branch_id;
    $add->created_by = $user_id;
    $add->updated_by = $user_id;
    $add->save(); // Save the Job Directory first

    $job_position_names = $request->job_postion_dropdown;
    $job_salary = $request->job_salary;
    $interview_round_dropdown = $request->interivew_round_dropdown; // This is an array of arrays
    // return  $interview_round_dropdown;
    $interview_types = $request->interview_type_dropdown;
    $vacancy_counts = $request->vacancy_count;
    $job_links = $request->job_link;
    $job_interview_dates = $request->job_postion_interv_date;
    $job_descriptions = $request->job_description;

    // Save each job position as a separate record
    foreach ($job_position_names as $index => $position) {
      if ($add->exists) {
        $user_id = $request->user()->user_id;
        $record = new JobDirectoryJobModel(); // Replace with your model name
        $record->job_dir_id = $add->sno; // Link back to the directory
        $record->company_id = $add->job_company_id; // Link back to the directory
        $record->job_name_id = $position;

        // Handle nested interview rounds
        $rounds = $interview_round_dropdown[$index] ?? []; // Get the array for the current job
        $record->interivew_rounds = json_encode($rounds); // Store as JSON or handle as needed

        $record->salary = $job_salary[$index] ?? null; // Use null if no salary is provided
        $record->interview_type_id = $interview_types[$index] ?? null;
        $record->vacancy_count = $vacancy_counts[$index] ?? null;
        $record->job_link = $job_links[$index] ?? null;
        $record->job_description = $job_descriptions[$index] ?? null; // Corrected variable name
        $record->job_interview_date = DateTime::createFromFormat('d-M-Y', $job_interview_dates[$index])->format('Y-m-d') ?? null;

        $record->created_by = $request->user()->user_id;
        $record->updated_by = $request->user()->user_id;
        // return  $record;
        $record->save();
      }
    }

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Job Directory added successfully!'
    ]);

    return redirect('placements/job_directory');
  }


  private function generateJobDirectoryId()
  {
    $jobdirectory_check = JobDirectoryModel::where('status', '!=', 2)
      ->orderBy('sno', 'desc')
      ->first();

    if (!$jobdirectory_check) {
      $year = substr(date('y'), -2);
      return 'JRD-0001/' . $year;
    } else {
      $data = $jobdirectory_check->job_directory_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);
      $next_number = (int)$result + 1;
      $requestId = sprintf('JRD-%04d', $next_number);
      $year = substr(date('y'), -2);
      return $requestId . '/' . $year;
    }
  }




  public function job_edit($id = '', Request $request)
  {

    // return $id;

    $branch_id = $request->user()->branch_id;
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $edit = JobDirectoryModel::select(
      'za_job_directory.*',
      'za_job_directory.sno AS job_directory_sno',
      'za_job_directory.status AS job_directory_status',
      'za_hr_directory.*',
      'za_hr_directory.sno AS hr_dir_sno'
    )
      ->leftJoin('za_hr_directory', 'za_job_directory.job_company_id', '=', 'za_hr_directory.sno')
      ->where('za_job_directory.branch_id', $branch_id)
      ->where('za_job_directory.status', '!=', 2)
      ->where('za_job_directory.sno', $decryptedValue)  // Ensure $decryptedValue is set correctly
      ->orderBy('za_job_directory.sno', 'desc')
      ->first();


    $job_details = JobDirectoryJobModel::select(
      'za_job_directorys_job.sno',
      'za_job_directorys_job.salary',
      'za_job_directorys_job.job_name_id',
      'za_job_directorys_job.job_interview_date',
      'za_job_directorys_job.interview_type_id',
      'za_job_directorys_job.vacancy_count',
      'za_job_directorys_job.interivew_rounds',
      'za_job_directorys_job.job_link',
      'za_job_directorys_job.job_description',
      'za_industry_job_name.job_name',
      'za_interview_type.interview_type_name',
    )
      //->join('za_job_directorys_job', 'za_job_directory.sno', '=', 'za_job_directorys_job.job_dir_id')
      ->join('za_industry_job_name', 'za_job_directorys_job.job_name_id', '=', 'za_industry_job_name.sno')
      ->join('za_interview_type', 'za_job_directorys_job.interview_type_id', '=', 'za_interview_type.sno')
      ->where('za_job_directorys_job.job_dir_id', '=', $edit->job_directory_sno)
      ->where('za_job_directorys_job.status', 0)
      ->orderBy('sno', 'desc')
      ->get();
    // return   $job_details;

    // // Fetch Course related Information
    // $course_info = CourseTypeModel::select(
    //   'za_job_directory.sno',
    //   'za_course_type.course_type_name',
    //   'za_course_type.sno' // Select the interview_name from za_interview_type
    // )
    //   ->leftJoin('za_job_directory', 'za_course_type.sno', '=', 'za_job_directory.course_type_id') // Correct the join direction
    //   ->where('za_course_type.status', '!=', 2)
    //   ->get();
    // dd($course_info);







    return view('content.placements_events.job_directory.edit', [
      'edit' => $edit,
      'job_details' => $job_details,
      // 'course_info' => $course_info,
      // 'branch_info' => $branch_info,
      // 'staffknowledgeInfo' => $staffknowledgeInfo,
      // 'shiftTime' => $shiftTime,
      'id' => $decryptedValue, // Pass decrypted staff ID to the view
    ]);
  }

  // public function Update(Request $request)
  // {

  //   return $request;
  //   // Validate request
  //   $validator = Validator::make($request->all(), [
  //     'company_name_dropdown_select' => 'required|max:255',
  //     // Add other validation rules as needed
  //   ]);

  //   if ($validator->fails()) {
  //     // If validation fails, return error response
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Incorrect format input fields'
  //     ]);
  //     return redirect()->back();
  //   }

  //   // Retrieve and sanitize data from request
  //   $job_directory_id = $request->job_directory_id;
  //   $company_name_dropdown = $request->edit_comp_name;
  //   $company_branch_dropdown = $request->company_branch_dropdown_select;
  //   //   $lead_dob = DateTime::createFromFormat('d-M-Y', $request->lead_dob);

  //   // $comp_interview_date =  DateTime::createFromFormat('Y-m-d', $request->comp_interview_date);
  //   $comp_interview_date = DateTime::createFromFormat('d-M-Y', $request->comp_interview_date);
  //   // $comp_interview_date =  $request->comp_interview_date;
  //   // dd($comp_interview_date);
  //   $notification_duration = $request->notification_duration;
  //   $course_type_dropdown_select = $request->course_type_dropdown_select;
  //   $company_description = $request->company_description;  // Fix typo

  //   $job_position_name = $request->job_position_name;
  //   $job_salary = $request->job_salary;
  //   $interview_type_dropdown = $request->interview_type_dropdown;
  //   $vacancy_count = $request->vacancy_count;
  //   $job_postion_interv_date = $request->job_postion_interv_date;
  //   $job_link = $request->job_link;
  //   $job_description = $request->job_description;
  //   $sno    = $request->sno_edit;

  //   $user_id = $request->user()->user_id;

  //   // Generate a unique job directory ID
  //   $jobdirectory_check = JobDirectoryModel::where('status', '!=', 2)
  //     ->orderBy('sno', 'desc')
  //     ->first();

  //   if (!$jobdirectory_check) {
  //     $year = substr(date('y'), -2);
  //     $job_directory_id = 'JRD-0001/' . $year;
  //   } else {
  //     $data = $jobdirectory_check->job_directory_id;
  //     $slice = explode('/', $data);
  //     $result = preg_replace('/[^0-9]/', '', $slice[0]);
  //     $next_number = (int)$result + 1;
  //     $requestId = sprintf('JRD-%04d', $next_number);
  //     $year = substr(date('y'), -2);
  //     $job_directory_id = $requestId . '/' . $year;
  //   }

  //   // Add the job directory to the database
  //   $update_job_direct =  JobDirectoryModel::find($sno);



  //   // Fill attributes
  //   $update_job_direct->job_directory_id = $job_directory_id;
  //   $update_job_direct->job_company_id = $company_name_dropdown;
  //   $update_job_direct->company_branch_id = $company_branch_dropdown;
  //   // dd($comp_interview_date);
  //   $update_job_direct->interview_date    = $comp_interview_date;
  //   // dd($interview_date);
  //   // $update_job_direct->interview_date = $comp_interview_date;
  //   $update_job_direct->duration = $notification_duration;
  //   $update_job_direct->course_type_id = is_array($course_type_dropdown_select) ? json_encode($course_type_dropdown_select) : $course_type_dropdown_select;
  //   $update_job_direct->company_description = $company_description;

  //   // Convert arrays to JSON if needed
  //   $update_job_direct->job_postion_name =  json_encode($job_position_name);
  //   $update_job_direct->job_salary =  json_encode($job_salary);
  //   $update_job_direct->interview_type_id =  json_encode($interview_type_dropdown);
  //   $update_job_direct->vacancy_count =  json_encode($vacancy_count);
  //   $update_job_direct->job_interview_date =  json_encode($job_postion_interv_date);
  //   $update_job_direct->job_link =  json_encode($job_link);
  //   $update_job_direct->job_descritpion =  json_encode($job_description);

  //   $update_job_direct->branch_id = self::$branch_id;
  //   $update_job_direct->created_by = $user_id;
  //   $update_job_direct->updated_by = $user_id;
  //   // dd($update_job_direct);
  //   $update_job_direct->save();
  //   // return $update_job_direct;

  //   if ($update_job_direct) {
  //     session()->flash('toastr', [
  //       'type' => 'success',
  //       'message' => 'Job Directory Updated Successfully!'
  //     ]);
  //   } else {
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Could not add the Job Directory!'
  //     ]);
  //   }

  //   return redirect('placements/job_directory');
  // }
  public function Update(Request $request)
  {
    // return $request;
    // Validate request
    $validator = Validator::make($request->all(), [
      'comp_name_edit' => 'required|max:255',
      // Add other validation rules as needed
    ]);

    if ($validator->fails()) {
      // If validation fails, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back()->withErrors($validator)->withInput();
    }

    $id = $request->sno_edit;

    // Find the existing Job Directory record
    $jobDirectory = JobDirectoryModel::findOrFail($id);
    // return  $jobDirectory;
    // Update the job directory details
    $jobDirectory->job_company_id = $request->hr_dir_sno;
    // dd($jobDirectory->job_company_id);
    $jobDirectory->interview_date = DateTime::createFromFormat('d-M-Y', $request->comp_interview_date)->format('Y-m-d');
    // dd($jobDirectory->interview_date);
    $jobDirectory->duration = $request->notification_duration;
    $jobDirectory->interview_to = $request->interview_to;
    $jobDirectory->company_description = $request->company_description;
    $jobDirectory->updated_by = $request->user()->user_id;
    $jobDirectory->save(); // Save the updated Job Directory

    // Assuming you're passing arrays for position names, salaries, etc.
    $job_position_names = $request->job_position_dropdown;
    $job_salary = $request->job_salary;
    $interview_types = $request->interview_type_dropdown;
    $interivew_round_dropdown = $request->interivew_round_dropdown;
    $vacancy_counts = $request->vacancy_count;
    $job_links = $request->job_link;
    $job_interview_dates = $request->job_postion_interv_date;

    $job_descriptions = $request->job_description;
    // Update or create job positions
    if ($jobDirectory->sno) {
      foreach ($job_position_names as $index => $position) {
        $job_sno = $request->jobs_dir_id[$index];
        // $job_position_sno = $request->sno[$index];
        $record = JobDirectoryJobModel::where('sno', $job_sno)->first();

        if ($record) {
          // Update existing record
          $record->salary = $job_salary[$index] ?? null;
          $record->job_name_id = $position ?? null;
          $record->interview_type_id = $interview_types[$index] ?? null;
          // Handle nested interview rounds
          $rounds = $interivew_round_dropdown[$index] ?? []; // Get the array for the current job
          $record->interivew_rounds = json_encode($rounds);
          $record->vacancy_count = $vacancy_counts[$index] ?? null;
          $record->job_link = $job_links[$index] ?? null;
          $record->job_description = $job_descriptions[$index] ?? null;
          $record->job_interview_date = date('Y-m-d', strtotime($job_interview_dates[$index]));
          $record->updated_by = $request->user()->user_id;
          // return $record;
          $record->save();
        } else {
          // Create a new record if it doesn't exist

          $newRecord = new JobDirectoryJobModel();
          $newRecord->job_dir_id = $jobDirectory->sno;
          $newRecord->company_id = $jobDirectory->job_company_id;
          $newRecord->job_name_id = $position; // Use the job name ID
          $newRecord->salary = $job_salary[$index] ?? null;
          $newRecord->interview_type_id = $interview_types[$index] ?? null;
          // Handle nested interview rounds
          $rounds = $interview_round_dropdown[$index] ?? []; // Get the array for the current job
          $newRecord->interivew_rounds = json_encode($rounds);
          $newRecord->vacancy_count = $vacancy_counts[$index] ?? null;
          $newRecord->job_link = $job_links[$index] ?? null;
          $newRecord->job_description = $job_descriptions[$index] ?? null;
          $newRecord->job_interview_date = date('Y-m-d', strtotime($job_interview_dates[$index]));
          $newRecord->created_by = $request->user()->user_id;
          $newRecord->updated_by = $request->user()->user_id;
          $newRecord->save();
        }
      }
    }



    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Job Directory updated successfully!'
    ]);

    return redirect('placements/job_directory');
  }




  public function view(Request $request)
  {
    // return $request;
    $id = request()->get('id', '');
    $sno = request()->get('id', '');
    $sno = $request->id;
    $job_dir_sno = $request->sno;

    // Fetch the job details
    $job_view = JobDirectoryJobModel::select(
      'za_job_directorys_job.*',
      'za_hr_directory.company_name',
      'za_hr_directory.hr_contact_name',
      'za_hr_directory.hr_contact_phone',
      'za_hr_directory.address',
      'za_hr_directory.location_url',
      'za_hr_directory.company_desc',
      'za_interview_type.interview_type_name',
      'za_industry_job_name.job_name'
    )
      ->join('za_industry_job_name', 'za_job_directorys_job.job_name_id', '=', 'za_industry_job_name.sno')
      ->join('za_interview_type', 'za_job_directorys_job.interview_type_id', '=', 'za_interview_type.sno')
      ->join('za_hr_directory', 'za_hr_directory.sno', '=', 'za_job_directorys_job.company_id')
      ->where('za_job_directorys_job.job_dir_id', $job_dir_sno)
      ->where('za_job_directorys_job.sno', $sno)
      ->where('za_job_directorys_job.status', 0)
      ->first();


    $interviewRounds = json_decode($job_view->interivew_rounds); // Decode the JSON array

    // Fetch the interview checklist names based on the IDs in interview_rounds
    $checklistNames = [];
    if ($interviewRounds) {
      $checklistNames = DB::table('za_interview_checklist')
        ->whereIn('sno', $interviewRounds) // Use whereIn to get all matching checklist names
        ->pluck('interview_checklist_name')
        ->toArray(); // Convert the result to an array
    }


    return response()->json([
      'job_view' => $job_view,
      'checklist_names' => $checklistNames,
    ]);
  }




  // Status change
  public function Status($id, Request $request)
  {
    // return $id;
    $status = $request->status;
    $upd_JobDirectoryModel = JobDirectoryModel::where('sno', $id)->first();
    // return  $upd_JobDirectoryModel;

    $upd_JobDirectoryModel->status = $request->input('status', $status);
    // return  $upd_JobDirectoryModel;
    $upd_JobDirectoryModel->update();
    if ($upd_JobDirectoryModel) {
      return response([
        'status' => 200,
        'message' => 'Job Directory Status Successfully Updated!',
        'error_msg' => 'Could not ,update Job Directory Status!',
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 200,
        'message' => 'Could not update Job Directory Status!',
        'error_msg' => 'Could not ,update Job Directory Status!',
        'data' => null,
      ], 200);
    }
  }

  //delete function
  public function Delete($id)
  {

    $upd_JobDirectoryModel = JobDirectoryModel::where('sno', $id)->first();
    $upd_JobDirectoryModel->status = 2;
    $upd_JobDirectoryModel->Update();
    if ($upd_JobDirectoryModel) {
      return response([
        'status' => 200,
        'message' => ' Job Directory Successfully Deleted!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 200,
        'message' => 'Could not delete Job Directory!',
        'error_msg' => null,
        'data' => null,
      ], 200);
    }
  }
}
