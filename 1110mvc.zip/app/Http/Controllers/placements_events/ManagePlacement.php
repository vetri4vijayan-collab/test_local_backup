<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\PlacementStudentExports;
use Illuminate\Support\Facades\DB;
use App\Models\HrDirectoryModel;
use App\Models\CourseTypeModel;
use App\Models\InterviewCheckListModel;
use App\Models\PlacementFollowupModel;
use App\Models\JobDirectoryModel;
use App\Models\InterviewModel;
use Illuminate\Http\Request;
use App\Models\JobModel;
use App\Models\CustomerPlacementModel;
use App\Models\PlacementReasonsHistoryModel;
use Illuminate\Support\Facades\Validator;


use Maatwebsite\Excel\Facades\Excel;

class ManagePlacement extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;
    
        $search_fill = $request->input('search_fill', '');
        // $filter_on = $request->input('filter_on', false);
        $search_company = $request->input('search_company', '');
        $search_cust_name = $request->input('search_cust_name', '');
        $search_cust_mobile = $request->input('search_cust_mobile', '');
        $search_cust_id = $request->input('search_cust_id', '');
        $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
        $dt_fill_date_type = $request->input('dt_fill_date_type', '');
        $search_start_date = $request->input('search_start_date', '');
        $search_end_date = $request->input('search_end_date', '');

        $students = DB::table('za_placement_interview')
            ->select('za_placement_interview.sno as interview_id','za_jobs.interview_date','za_placement_company.company_name','za_placement_company.company_address','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position', 'za_customer.cus_name','za_customer.doj','za_customer.placement_status','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.interview_checklist_status','za_customer.sno as cus_id')
            ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
            ->join('za_jobs','za_jobs.sno','=','za_placement_interview.job_id')
            ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
            ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
            ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
            ->where('za_placement_interview.status', 4)
            ->where('za_customer.placement_status', '!=', 4)
            ->where('za_customer.branch_id', $branch_id)
            ->orderBy('za_jobs.interview_date', 'desc');

        if ($search_fill != '') {
            $students->where(function ($query) use ($search_fill) {
                $query->where('za_customer.cus_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_customer.customer_id', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.company_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.company_address', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_interview.job_position', 'LIKE', "%{$search_fill}%");
            });
        }

        if(!empty($search_company)){
            $students->where('za_placement_company.sno',$search_company);
        }

        if(!empty($search_cust_name)){
            $students->where('za_customer.cus_name', 'LIKE', "%{$search_cust_name}%");
        }

        if(!empty($search_cust_mobile)){
            $students->where('za_customer.cus_mobile', 'LIKE', "%{$search_cust_mobile}%");
        }

        if(!empty($search_cust_id)){
            $students->where('za_customer.customer_id', 'LIKE', "%{$search_cust_id}%");
        }

        if ($dt_fill_issue_rpt == "today") {
            $todayDate = date("Y-m-d");
            if($dt_fill_date_type == 'interview_date'){
                $students->whereDate('za_jobs.interview_date', $todayDate);
            }
        } elseif ($dt_fill_issue_rpt == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
            }
            if($dt_fill_date_type == 'interview_date'){
                $students->whereBetween('za_jobs.interview_date', [$weekFromDate, $weekToDate]);
            }
        } elseif ($dt_fill_issue_rpt == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth  = date('Y-m-t');
            if($dt_fill_date_type == 'interview_date'){
                $students->whereBetween('za_jobs.interview_date', [$firstDayOfMonth, $lastDayOfMonth]);
            }
        } elseif ($dt_fill_issue_rpt == "custom_date") {
            if ($search_start_date && $search_end_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                $toDate   = date('Y-m-d', strtotime($search_end_date));
                if($dt_fill_date_type == 'interview_date'){
                    $students->whereBetween('za_jobs.interview_date', [$fromDate, $toDate]);
                }else if($dt_fill_date_type == 'date_of_join'){
                    $students->whereBetween('za_customer.doj', [$fromDate, $toDate]);
                }
            } elseif ($search_start_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                if($dt_fill_date_type == 'interview_date'){
                    $students->where('za_jobs.interview_date', '>=', $fromDate);
                }else if($dt_fill_date_type == 'date_of_join'){
                    $students->where('za_customer.doj', '>=', $fromDate);
                }
            } elseif ($search_end_date) {
                $toDate = date('Y-m-d', strtotime($search_end_date));
                if($dt_fill_date_type == 'interview_date'){
                    $students->where('za_jobs.interview_date', '<=', $toDate);
                }else if($dt_fill_date_type == 'date_of_join'){
                    $students->where('za_customer.doj', '<=', $toDate);
                }
            }
        }
            
        $students = $students->paginate($perpage);

        if(!empty($search_company) || !empty($search_cust_name) || !empty($search_cust_mobile) || !empty($search_cust_id) || !empty($dt_fill_issue_rpt) && ($dt_fill_issue_rpt != 'all')){
            $filter_on = true;
        }else{
            $filter_on = false;
        }

        return view('content.placements_events.manage_placement.manage_placement', [
            'students' => $students,
            'pageConfigs' => ['myLayout' => 'default'],
            'perpage'=> $perpage,
            'search_fill'=>$search_fill,
            'filter_on'=>$filter_on,
            'search_company' => $search_company,
            'search_cust_name' => $search_cust_name,
            'search_cust_mobile' => $search_cust_mobile,
            'search_cust_id' => $search_cust_id,
            'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
            'dt_fill_date_type' => $dt_fill_date_type,
            'search_start_date' => $search_start_date,
            'search_end_date' => $search_end_date
        ]);
    }

    public function View($id,Request $request)
    {
        
        $branch_id = $request->user()->branch_id;

        $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->where('za_jobs.status', '!=', 2)
        ->where('za_jobs.branch_id', $branch_id)
        ->where('za_jobs.sno', $id)
        ->first(); 

        if (!empty($job_data->skill_description)) {
            $skills = json_decode($job_data->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job_data->skill_description = implode(', ', $skill_names); 
        }
        if (!empty($job_data->interest_student_ids)) {
            $customer_ids = json_decode($job_data->interest_student_ids, true);
            $students = DB::table('za_customer')
                ->select('za_customer.*')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('sno', $customer_ids)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
            $job_data->customer_list = $students;
            $job_data->intrested_student_count = count($customer_ids); 
        }
       
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $job_data ,
        ], 200);
    }

    public function JobDetails($id,Request $request)
    {
        
        $branch_id = $request->user()->branch_id;
        $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
                ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
                ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
                ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
                ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
                ->where('za_jobs.status', '!=', 2)
                ->where('za_jobs.branch_id', $branch_id)
                ->where('za_jobs.sno', $id)
                ->first(); 
    
        if (!empty($job_data->skill_description)) {
            $skills = json_decode($job_data->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job_data->skill_description = implode(', ', $skill_names); 
        }
        $job_data->intrested_student_count = 0;
        if (!empty($job_data->interest_student_ids)) {
            $customer_ids = json_decode($job_data->interest_student_ids, true);
            $job_data->student_ids = $customer_ids;
            $job_data->intrested_student_count = count($customer_ids); 
        }
       
       
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $job_data ,
        ], 200);
    }

    public function AllStudentList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $student     = DB::table('za_customer')->select('za_customer.*')
        ->where('za_customer.status', '!=', 2)
        ->where('branch_id', $branch_id)
        ->orderBy('za_customer.cus_name', 'asc')
        ->get();

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $student,
        ], 200);
    }
    
    public function AddInterestStudent(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'interested_student_ids' => 'required|array',  // Must be an array
            'interested_student_ids.*' => 'integer',  // Each ID must be an integer
        ]);
    
        // Check if validation fails
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format in input fields.'
            ]);
            return redirect()->back();
        }
    
        // Get the user information and request data
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $job_id = $request->intrst_job_id;
        $job_student = $request->interested_student_ids ?? [];
    
        // Convert student IDs array to JSON format
        $interested_student_id = json_encode($job_student);
        $company_data = JobModel::where('sno', $job_id)->first();
    
        if ($company_data) {
            // Update the job with the new list of interested student IDs
            $company_data->interest_student_ids = $interested_student_id;
            $company_data->update();
    
            // Step 1: Remove all existing interview data for the given job ID
            InterviewModel::where('job_id', $job_id)
                ->where('branch_id', $branch_id)
                ->delete();  // Delete all interview entries for this job ID and branch
    
            // Step 2: Add new students
            foreach ($job_student as $studentid) {
                // Check if the interview already exists (though this should not happen since we're deleting first)
                $chk = InterviewModel::where('job_id', $job_id)
                    ->where('customer_id', $studentid)
                    ->where('branch_id', $branch_id)
                    ->first();
    
                // Generate a unique placement interview ID
                $last_interv_entry = InterviewModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();
    
                if (!$last_interv_entry) {
                    $year = substr(date('y'), -2);
                    $placement_interview_id = 'SIV-0001/' . $year;
                } else {
                    $data = $last_interv_entry->placement_interview_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $placement_interview_id = sprintf('SIV-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                $job = JobModel::where('sno', $job_id)->first();
                $interview_checklist_id = json_decode($job->interview_checklist_id ?? '[]');  
                $interview_checklist_status = array_fill(0, count($interview_checklist_id), "0");
    
                // Create a new interview entry for the student
                $add = new InterviewModel();
                $add->placement_interview_id = $placement_interview_id;
                $add->customer_id = $studentid;
                $add->job_id = $job_id;
                $add->interview_checklist_status = json_encode($interview_checklist_status);
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                $add->save();
            }
    
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Interest students added successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Job not found!'
            ]);
        }
    
        return redirect('placements/manage_placement');
    }    
        
    
    // Status change
    public function Status($id, Request $request)
    {
    $upd_companyModel =  CustomerModel::where('sno', $id)->first();
    $upd_companyModel->placement_status = $request->input('status', 0);
    $upd_companyModel->update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Status Successfully Updated !',
        'error_msg' => 'Could not ,update Job!',
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 204,
        'message'   => 'Could not update Job!',
        'error_msg' => 'Could not ,update  Job!',
        'data'      => null,
        ], 204);
    }
    }

    //delete function
    public function Delete($id)
    {

    $upd_companyModel =  JobModel::where('sno', $id)->first();
    $upd_companyModel->status  = 2;
    $upd_companyModel->Update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 200,
        'message'   => 'Could not delete Company!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }
    }

    public function GetReassignDetails($id, Request $request)
    {
       $PlacementList = DB::table('za_placement_interview')
        ->select('za_placement_interview.sno as interview_id',
        'za_jobs.interview_date',
        'za_placement_company.sno as company_sno',
        'za_placement_company.company_name',
        'za_placement_company.company_email',
        'za_placement_company.company_address',
        'za_job_category.job_category_name',
        'za_job_subcategory.job_subcategory_name as job_role_name',
        'za_placement_interview.status',
        'za_placement_interview.job_salary',
        'za_placement_interview.job_position',
        'za_placement_interview.interview_checklist_status',
        'za_customer.cus_name',
        'za_customer.doj',
        'za_customer.placement_status',
        'za_customer.cus_gender',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.sno as cus_id')
        ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
        ->join('za_jobs','za_jobs.sno','=','za_placement_interview.job_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->where('za_placement_interview.status', 4)
        ->where('za_placement_interview.sno', $id)
        ->orderBy('za_jobs.interview_date', 'desc')->first();

        if ($PlacementList) {

            $cus_pic_url = $cus_gender_icon = '';
            if($PlacementList->cus_pic){
                $cus_pic_url = url('/cus_pics/'.$PlacementList->cus_pic);
            }else if($PlacementList->cus_gender == 1){
                $cus_pic_url = url('/assets/eapl_images/user_1.png');
            }else if($PlacementList->cus_gender == 2){
                $cus_pic_url = url('/assets/eapl_images/user_2.png');
            }

            if($PlacementList->cus_gender == 1){
                $cus_gender_icon = '<i class="mdi mdi-face-man text-danger" data-bs-toggle="tooltip" data-bs-placement="right" title="Male"></i>';
            }else if($PlacementList->cus_gender == 2){
                $cus_gender_icon = '<i class="mdi mdi-face-woman text-danger" data-bs-toggle="tooltip" data-bs-placement="right" title="Female"></i>';
            }

            return response()->json([
                'status' => 200,
                'data' => [
                    'sno' => $PlacementList->interview_id ?? 0,
                    'customer_sno' => $PlacementList->cus_id ?? '',
                    'company_sno' => $PlacementList->company_sno ?? '',
                    'customer_id' => $PlacementList->customer_id ?? '',
                    'cus_name' => $PlacementList->cus_name ?? '',
                    'cus_mobile' => $PlacementList->cus_mobile ?? '',
                    'cus_pic' => $PlacementList->cus_pic ?? '',
                    'cus_doj' => date('d-M-Y',strtotime($PlacementList->doj)) ?? '',
                    'cus_pic_url' => $cus_pic_url ?? '',
                    'cus_gender' => $PlacementList->cus_gender ?? '',
                    'cus_gender_icon' => $cus_gender_icon ?? '',
                    'company_name' => $PlacementList->company_name ?? '',
                    'company_email' => $PlacementList->company_email ?? '',
                    'company_address' => $PlacementList->company_address ?? '',
                    'interview_date' => date('d-M-Y',strtotime($PlacementList->interview_date)) ?? '',
                    'job_position' => $PlacementList->job_position ?? '',
                    'job_salary' => number_format($PlacementList->job_salary ?? 0 ,2,'.',',') ?? '',
                ],
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Placement not found',
            ]);
        }
    }

    public function Reassign_placements(Request $request){
        // return $request;
        $validator = Validator::make($request->all(), [
            'reassign_cust_id' => 'required',
            'reassign_comp_id' => 'required',
            'reassign_comp_id' => 'required',
            'place_reason_id' => 'required',
            'reassign_score' => 'required',
            'place_status_id' => 'required'
        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {
            $reassign_cust_id  = $request->reassign_cust_id;
            $reassign_comp_id  = $request->reassign_comp_id;
            $place_reason_id  = $request->place_reason_id;
            $reassign_score  = $request->reassign_score;
            $place_status_id  = $request->place_status_id ?? 3;
            $user_id            = $request->user()->user_id;

            $customer_modal = CustomerModel::where('status',0)->where('sno',$reassign_cust_id)->first();
            if(!empty($customer_modal)){
                $customer_modal->placement_status = ($place_status_id == 2) ? 4 : 3;
                $customer_modal->updated_at = date('Y-m-d H:i:s');
                $customer_modal->updated_by = $user_id;
                if($customer_modal->update()){
                    $add_place_reason_history = new PlacementReasonsHistoryModel();
                    $add_place_reason_history->company_id = $reassign_comp_id;
                    $add_place_reason_history->customer_id = $reassign_cust_id;
                    $add_place_reason_history->placement_reason_id = $place_reason_id;
                    $add_place_reason_history->reason_score = $reassign_score;
                    $add_place_reason_history->created_at = date('Y-m-d H:i:s');
                    $add_place_reason_history->created_by = $user_id;
                    $add_place_reason_history->save();
                    if ($add_place_reason_history) {
                        session()->flash('toastr', [
                        'type'    => 'success',
                        'message' => 'Placement Re-Assigned Successfully!'
                        ]);
                    } else {
                        session()->flash('toastr', [
                        'type'    => 'error',
                        'message' => 'Failed to Placement Re-Assigned.'
                        ]);
                    }
                    return redirect('/placements/manage_placement');
                }
            }else{
                return response([
                    'status'    => 404,
                    'message'   => 'Customer Not Found',
                    'error_msg' => $validator->messages()->get('*'),
                    'data'      => null,
                ], 404);
            }
        }
    }
}
