<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;

class PlacedStudents extends Controller
{
  public function index()
  {
    return view('content.placements_events.placed_students.placed_stud_list');
  }


  public function CourseTypeList()
  {
    $Coursetype = CourseTypeModel::whereIn('sno', [2, 3])->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }
  public function JobRoleList()
  {
    $Coursetype = DB::table('za_job_subcategory')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }

  private function formatLPA($value)
  {
    if (!$value) return '0 LPA';

    // Round up to nearest integer LPA
    $lpa = ceil($value / 100000);

    return $lpa . ' LPA';
  }

  public function placedReport(Request $request)
  {
    $branch_id   = $request->user()->branch_id;
    $search_fill = $request->input('search_fill', '');
    $course_id   = $request->input('course_id', '');
    $job_role_id = $request->input('job_role_id', '');
    $date        = $request->input('date', ''); // today, week, month, custom

    $query = DB::table('za_placement_interview as pi')
      ->select(
        'pi.sno as interview_id',
        'j.interview_date',
        'c.company_name',
        'c.company_address',
        'jc.job_category_name',
        'js.job_subcategory_name as job_role_name',
        'pi.status',
        'pi.job_salary',
        'pi.job_position',
        'cust.cus_name',
        'cust.placement_status',
        'cust.cus_gender',
        'cust.cus_mobile',
        'cust.cus_email_id',
        'cust.cus_pic',
        'cust.customer_id',
        'pi.interview_checklist_status',
        'cust.sno as cus_id',
        'br.branch_name',
        'br.franchise_name',
        DB::raw("CONCAT(CEIL(pi.job_salary / 100000), ' LPA') as job_salary"),
        DB::raw("CONCAT('" . asset('cus_pics') . "/', cust.cus_pic) as cus_pic"),
        DB::raw("
            MAX(
                CASE
                    WHEN tr.tesbo_check = 2 THEN 'TESBO Courses'
                    ELSE za_course_type.course_type_name
                END
            ) as course_type_name
        "),
        DB::raw("
            MAX(
              JSON_UNQUOTE(
                JSON_EXTRACT(ce.placed_datas, '$.qualification')
              )
            ) as qualification
          ")
      )

      ->join('za_customer as cust', 'cust.sno', '=', 'pi.customer_id')
      ->join('za_jobs as j', 'j.sno', '=', 'pi.job_id')
      ->leftJoin('za_customer_education as ce', 'ce.customer_id', '=', 'cust.sno')
      ->leftJoin('za_branch as br', 'br.sno', '=', 'cust.branch_id')
      ->leftJoin('za_job_category as jc', 'jc.sno', '=', 'j.job_category_id')
      ->leftJoin('za_job_subcategory as js', 'js.sno', '=', 'j.job_subcategory_id')
      ->join('za_placement_company as c', 'c.sno', '=', 'j.company_id')
      ->leftJoin('za_training as tr', 'tr.customer_id', '=', 'cust.sno')
      ->leftJoin('za_course', 'za_course.sno', '=', 'tr.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->where('pi.status', 4)
      ->where('br.status', 0)
      ->whereNotIn('br.sno', [1])
      // ->where('cust.branch_id', $branch_id)
      ->orderBy('j.interview_date', 'desc')
      ->groupBy(
        'pi.sno',
        'j.interview_date',
        'c.company_name',
        'c.company_address',
        'jc.job_category_name',
        'js.job_subcategory_name',
        'pi.status',
        'pi.job_salary',
        'pi.job_position',
        'cust.cus_name',
        'cust.placement_status',
        'cust.cus_gender',
        'cust.cus_mobile',
        'cust.cus_email_id',
        'cust.cus_pic',
        'cust.customer_id',
        'pi.interview_checklist_status',
        'cust.sno',
        'br.branch_name',
        'br.franchise_name',
      );

    $statsQuery = DB::table('za_placement_interview as pi')
      ->join('za_customer as cust', 'cust.sno', '=', 'pi.customer_id')
      ->join('za_jobs as j', 'j.sno', '=', 'pi.job_id')
      ->leftJoin('za_branch as br', 'br.sno', '=', 'cust.branch_id')
      ->join('za_training as tr', 'tr.customer_id', '=', 'cust.sno')
      ->join('za_course', 'za_course.sno', '=', 'tr.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->where('br.status', 0)
      ->whereNotIn('br.sno', [1])
      ->where('pi.status', 4);
      

    $maxPackage = DB::table('za_placement_interview as pi')
      ->join('za_customer as cust', 'cust.sno', '=', 'pi.customer_id')
      ->join('za_jobs as j', 'j.sno', '=', 'pi.job_id')
      ->join('za_training as tr', 'tr.customer_id', '=', 'cust.sno')
      ->join('za_course', 'za_course.sno', '=', 'tr.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->where('pi.status', 4)
      ->max('pi.job_salary'); // works at DB level

    $minPackage = DB::table('za_placement_interview as pi')
      ->join('za_customer as cust', 'cust.sno', '=', 'pi.customer_id')
      ->join('za_jobs as j', 'j.sno', '=', 'pi.job_id')
      ->join('za_training as tr', 'tr.customer_id', '=', 'cust.sno')
      ->join('za_course', 'za_course.sno', '=', 'tr.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->where('pi.status', 4)
      ->min('pi.job_salary'); // works at DB level

    // Apply same search filter
    if ($search_fill != '') {
      $statsQuery->where(function ($q) use ($search_fill) {
        $q->where('cust.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.cus_email_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('j.company_id', 'LIKE', "%{$search_fill}%");
      });
    }

    // Course filter
    if ($course_id != '') {
      $statsQuery->where(function ($q) use ($course_id) {
        $q->where(function ($q2) {
          $q2->where('tr.tesbo_check', 2)
            ->whereRaw('2 = ?', [request('course_id')]);
        })->orWhere(function ($q2) use ($course_id) {
          $q2->where('tr.tesbo_check', '!=', 2)
            ->where('za_course.course_type_id', $course_id);
        });
      });
    }

    // Job role filter
    if ($job_role_id != '') {
      $statsQuery->where('j.job_subcategory_id', $job_role_id);
    }

    // Date filter
    if ($date != '' && $date != 'all') {
      if ($date == 'today') {
        $statsQuery->whereDate('j.interview_date', today());
      } elseif ($date == 'week') {
        $statsQuery->whereBetween('j.interview_date', [now()->startOfWeek(), now()->endOfWeek()]);
      } elseif ($date == 'monthly') {
        $statsQuery->whereMonth('j.interview_date', now()->month)
          ->whereYear('j.interview_date', now()->year);
      } elseif ($date == 'custom') {
        $from = $request->input('from_date');
        $to   = $request->input('to_date');
        if ($from && $to) {
          $statsQuery->whereBetween('j.interview_date', [$from, $to]);
        }
      }
    }



    $students = $query->get()->unique('cus_id'); // remove duplicate cus_id

    // Now calculate stats directly
    $studentCount = $statsQuery->distinct('cust.sno')->count('cust.sno');
    // $maxPackage   = $statsQuery->max('pi.job_salary');
    // $minPackage   = $statsQuery->min('pi.job_salary'); // optional

    $companyCount = DB::table('za_placement_company')
      ->where('status', 0)  // filter by branch
      ->count('sno');                   // count distinct companies


    $stats = [
      'students' => $studentCount,
      'companies' => $companyCount,
      'avg_package' => $this->formatLPA($minPackage),
      'max_package' => $this->formatLPA($maxPackage),

    ];

    return response()->json([
      'status' => 200,
      'stats'  => $stats,
      'data'   => $students
    ]);
  }


  public function updateProfilePic(Request $request)
  {
    $request->validate([
      'student_id'  => 'required',
      'profile_pic' => 'required|image|mimes:jpg,jpeg,png,webp|max:2048'
    ]);

    $student = CustomerModel::where('sno', $request->student_id)->first();

    if (!$student) {
      return response()->json([
        'status' => 404,
        'message' => 'Student not found'
      ]);
    }

    /* ---------- DELETE OLD IMAGE (OPTIONAL) ---------- */
    if ($student->cus_pic && file_exists(public_path('cus_pics/' . $student->cus_pic))) {
      unlink(public_path('cus_pics/' . $student->cus_pic));
    }

    /* ---------- UPLOAD NEW IMAGE ---------- */
    $file = $request->file('profile_pic');

    $fileName = 'student_' . time() . '_' . rand(100, 999) . '.' . $file->extension();

    $destinationPath = public_path('cus_pics');
    $file->move($destinationPath, $fileName);

    /* ---------- SAVE PATH IN DB ---------- */
    $student->cus_pic = $fileName;
    $student->save();

    return response()->json([
      'status' => 200,
      'image'  => asset('cus_pics/' . $fileName)
    ]);
  }
}
