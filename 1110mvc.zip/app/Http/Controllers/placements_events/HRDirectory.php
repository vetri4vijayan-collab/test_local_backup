<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\HrDirectoryModel;
use App\Models\HrDirectoryBranchModel;
use Illuminate\Support\Facades\DB;

class HRDirectory extends Controller
{



  //HR DIRECTORY index
  public function index()
  {


    $hr_directory_list = HrDirectoryModel::select('*')
      ->where('status', '!=', 2)
      ->orderBy('sno', 'desc')
      ->get();


    // return $hr_directory_list;

    // $hr_directory_list = HrDirectoryModel::select(
    //   'za_hr_directory.hr_directory_id',
    //   'za_hr_directory.sno',
    //   'za_hr_directory.branch_id',
    //   'za_hr_directory.branch_check',
    //   'za_hr_directory.branch_name',
    //   'za_hr_directory.address',
    //   'za_hr_directory.location_url',
    //   'za_hr_directory.hr_contact_name',
    //   'za_hr_directory.hired_count',
    //   'za_hr_directory.total_vacancy_count',
    //   'za_hr_directory.status',
    //   'za_hr_directory_branch.company_id',
    //   'za_hr_directory_branch.sno as sub_branch_id',
    //   'za_hr_directory_branch.branch_name as sub_name',
    //   'za_hr_directory_branch.branch_location_url',
    //   'za_hr_directory_branch.branch_address',
    //   'za_hr_directory_branch.branch_hr_name',
    //   'za_hr_directory_branch.branch_hr_phone',
    // )
    //   ->leftJoin('za_hr_directory_branch', 'za_hr_directory.sno', '=', 'za_hr_directory_branch.company_id')
    //   ->where('za_hr_directory.status', '!=', 2)
    //   ->groupBy(
    //     'za_hr_directory.sno',
    //     'za_hr_directory.hr_directory_id',
    //     'za_hr_directory.branch_id',
    //     'za_hr_directory.branch_check',
    //     'za_hr_directory.branch_name',
    //     'za_hr_directory.address',
    //     'za_hr_directory.location_url',
    //     'za_hr_directory.hr_contact_name',
    //     'za_hr_directory.hired_count',
    //     'za_hr_directory.total_vacancy_count',
    //     'za_hr_directory.status',
    //     'za_hr_directory_branch.sno',
    //     'za_hr_directory_branch.company_id',
    //     'za_hr_directory_branch.branch_name',
    //     'za_hr_directory_branch.branch_location_url',
    //     'za_hr_directory_branch.branch_address',
    //     'za_hr_directory_branch.branch_hr_name',
    //     'za_hr_directory_branch.branch_hr_phone',
    //   )
    //   ->orderBy('za_hr_directory.sno', 'desc')
    //   ->get()
    //   ->unique('company_id'); // Remove duplicates based on hr_directory_id

    // return $hr_directory_list;



    // dd($hr_directory_list);


    return view('content.placements_events.hr_directory.list', [
      'hr_directory_list' => $hr_directory_list,

    ]);
  }

  //LIST FOR HR DIRECTORY
  public function List()
  {
    $Hrdirectory_data = HrDirectoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    // return $Hrdirectory_data;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Hrdirectory_data
    ], 200);
  }

  //LIST FOR HR DIRECTORY
  public function List_branch(Request $request)
  {

    // return $request;
    $sno = $request->id;


    $branch_data = HrDirectoryBranchModel::select(
      'hr_dir.sno as hr_dir_sno',
      'hr_dir.branch_check as hr_b_check',
      'branch.branch_name as b_name', // Select branch name
      'branch.sno as b_sno' // Select branch name
    )
      ->from('za_hr_directory as hr_dir') // Define the main table with an alias
      ->join('za_hr_directory_branch as branch', 'hr_dir.sno', '=', 'branch.company_id') // Join with the branch table
      ->where('hr_dir.sno', $sno) // Filter by sno
      ->where('hr_dir.status', '!=', 2) // Exclude status 2
      // ->orderBy('hr_dir.sno', 'desc') // Optional sorting
      ->get();


    // $branch_data = HrDirectoryBranchModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();



    // dd($branch_data);
    // return $Hrdirectory_data;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $branch_data
    ], 200);
  }

  public function get_company_branch_drop($sno)
  {
    // Retrieve the category ID from the POST request


    $MarType = HrDirectoryModel::where('sno', $sno)->where('status', 0)->orderBy('sno', 'desc')->first();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $MarType
    ], 200);
  }

  public function View()
  {
    $id = request()->get('id', '');
    // return $id;
    $main = HrDirectoryModel::where('sno', $id)
      ->where('status', 0)
      ->first();
    $sub = HrDirectoryBranchModel::where('company_id', $id)->where('status', 0)->get();

    // Return the response with the role permissions data
    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $main,
      'sub' => $sub,
    ], 200);
  }


  public function create_directory(Request $request)
  {
    // return redirect()->back();
    return view('content.placements_events.hr_directory.add');
  }

  // HR DIRECTORY ADD
  public function Add(Request $request)
  {

    // return $request;

    // Validate the request data
    $validator = Validator::make($request->all(), [
      'hr_company_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }

    // Get request data
    $hr_company_name_add = $request->hr_company_name;
    $industry_type = $request->industry_type;
    $branch_chk = $request->if_branch_add;

    // Check if the HR directory already exists
    $chk = HrDirectoryModel::where('company_name', ucwords($hr_company_name_add))
      ->where('branch_id', $request->user()->branch_id)
      ->first();

    if ($chk) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'HR Directory has already been created!'
      ]);
      return redirect('placements/hr_directory');
    }

    // Generate a unique HR directory ID
    $last_entry = HrDirectoryModel::where('status', '!=', 2)
      ->orderBy('sno', 'desc')
      ->first();

    if (!$last_entry) {
      $year = substr(date('y'), -2);
      $hr_directory_id = 'HRD-0001/' . $year;
    } else {
      $data = $last_entry->hr_directory_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);
      $next_number = (int)$result + 1;
      $requestId = sprintf('HRD-%04d', $next_number);
      $year = substr(date('y'), -2);
      $hr_directory_id = $requestId . '/' . $year;
    }
    // Create a new HR directory entry
    $add = new HrDirectoryModel();
    $add->hr_directory_id = $hr_directory_id;
    $add->company_name = $hr_company_name_add;
    $add->industry_type_id = $industry_type;
    $add->address = $request->main_branch_address;
    $add->company_desc = $request->main_desc;
    $add->address = $request->main_address;
    $add->country = $request->country;
    $add->state = $request->state;
    $add->city = $request->city;
    $add->hr_contact_name = json_encode($request->hr_person_name);
    // dd($add->hr_contact_name);
    $add->hr_contact_phone = json_encode($request->hr_person_mobile);
    // dd($add->hr_contact_phone);
    $add->location_url = $request->main_location_url;
    $add->branch_id = $request->user()->branch_id;
    $add->created_by = $request->user()->user_id;
    $add->updated_by = $request->user()->user_id;
    // return $add;
    $add->save();

    // If branch details were provided, save them


    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'HR Directory added successfully!'
    ]);
    // return $request;
    return redirect('placements/hr_directory');
    // return redirect()->back();
  }

  public function Add_old(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'hr_company_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      // If validation fails, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }

    // If validation passes
    //COMPANY NAME AND ID
    $hr_company_name_add = $request->hr_company_name;
    $hr_directory_id = $request->hr_directory_id;

    //DATA MAIN PAGE INFO
    $main_address_add = $request->main_address;
    $main_location_url_add = $request->main_location_url;
    $main_desc_add = $request->main_desc;
    $main_hr_person_name_add  = $request->main_hr_person_name;
    $main_hr_person_phone_add = $request->main_hr_person_phone;

    //DATA BRANCH PAGE INFO
    $branch_name_add = $request->branch_name;
    $branch_location_url_add = $request->branch_location_url;
    $branch_address_add = $request->branch_address;
    $branch_desc_add = $request->branch_description;
    $branch_hr_person_name_add  = $request->branch_hr_person_name;
    $branch_hr_person_phone_add = $request->branch_hr_person_phone;

    // to check branch checkbox is checked or not
    $branch_checked = $request->if_branch_add;
    $main_branch_checked = $request->main_checkbox;
    // $main_checked =$request->main_branch_check;
    // return $branch_checked;


    // Check if the category already exists
    $chk = HrDirectoryModel::where('company_name', ucwords($hr_company_name_add))
      ->where('branch_id', self::$branch_id)
      ->first();

    if ($chk) {
      // If category already exists, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Hr Directory has already been created!'
      ]);
    } else {
      // Generate a unique category ID
      $add_company = HrDirectoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$add_company) {
        $year = substr(date('y'), -2);
        $hr_directory_id = 'HRD-0001/' . $year;
      } else {
        $data = $add_company->hr_directory_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $requestId = sprintf('HRD-%04d', $next_number);
        $year = substr(date('y'), -2);
        $hr_directory_id = $requestId . '/' . $year;
      }
      // Add the hr diretory to the database
      // return $request;
      $add = new HrDirectoryModel();
      $add->hr_directory_id = $hr_directory_id;
      $add->company_name = $hr_company_name_add;
      $add->address = $main_address_add;
      $add->location_url = $main_location_url_add;
      $add->company_desc = $main_desc_add;

      // MAIN BRANCH HR DETAILS
      $add->hr_contact_name  = json_encode($main_hr_person_name_add);
      $add->hr_contact_phone = json_encode($main_hr_person_phone_add);
      $add->branch_id  = $request->user()->branch_id;
      $add->created_by = $request->user()->user_id;
      $add->updated_by = $request->user()->user_id;
      // return $add;
      $add->save();



      if ($add->sno) {

        if ($branch_checked == 1) {

          // if($main_branch_checked== 1){

          // }



          // return $request;
          $add_branch = new HrDirectoryBranchModel();
          // $add->hr_directory_id = $hr_directory_id_add;
          $add_branch->company_id = $add->sno;
          $add_branch->main_branch_status = $main_branch_checked;
          $add_branch->branch_status = $branch_checked;
          // $add_branch->company_name = $hr_company_name_add;  main_branch_status
          // return $add_branch;


          //HR  BRANCH DETAILS
          $add_branch->branch_name = json_encode($branch_name_add);
          $add_branch->branch_address = json_encode($branch_address_add);
          $add_branch->branch_location_url = json_encode($branch_location_url_add);
          $add_branch->branch_desc = json_encode($branch_desc_add);

          //  BRANCH HR DETAILS
          $add_branch->branch_hr_name  = json_encode($branch_hr_person_name_add);
          $add_branch->branch_hr_phone = json_encode($branch_hr_person_phone_add);
          $add_branch->branch_id  = $request->user()->branch_id;
          $add_branch->created_by = $request->user()->user_id;
          $add_branch->updated_by = $request->user()->user_id;

          // return $add_branch;
          $add_branch->save();
        }

        session()->flash('toastr', [
          'type' => 'success',
          'message' => ' Hr Directory  added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the  Hr Directory  !'
        ]);
      }
      // return $request;
    }


    return redirect('placements/hr_directory');
    // return redirect()->back();
    // return view('content.placements_events.hr_directory.list');
  }

  public function get_hr_directory($id = '')
  {

    $data =  HrDirectoryModel::where('sno', $id)->first();

    if ($data) {
      return response([
        'status'      => 200,
        'data'       => $data,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'data'      => '',
      ], 200);
    }
  }

  // Status change
  public function Status($id, Request $request)
  {
    // return $request;

    $upd_hrdirectoryModel =  HrDirectoryModel::where('sno', $id)->first();
    $upd_hrdirectoryModel->status = $request->input('status', 0);
    $upd_hrdirectoryModel->update();
    // return $upd_hrdirectoryModel;
    if ($upd_hrdirectoryModel) {
      return response([
        'status'    => 200,
        'message'   => 'Hr Directory Status Successfully Updated !',
        'error_msg' => 'Could not ,update Hr Directory!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 204,
        'message'   => 'Could not update Hr Directory!',
        'error_msg' => 'Could not ,update  Hr Directory!',
        'data'      => null,
      ], 204);
    }
  }



  //delete function
  public function Delete($id)
  {

    $upd_hrdirectoryModel =  HrDirectoryModel::where('sno', $id)->first();
    $upd_hrdirectoryModel->status  = 2;
    $upd_hrdirectoryModel->Update();
    if ($upd_hrdirectoryModel) {
      return response([
        'status'    => 200,
        'message'   => ' Hr Directory Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete  Hr Directory!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }


  public function Delete_all_branch($id)
  {

    // Fetch the specific record to get the session_id
    $data_get = HrDirectoryBranchModel::select('*')->where('company_id', $id)->first();

    // Check if the record exists
    if (!$data_get) {
      return response([
        'status'    => 200,
        'message'   => 'HR Branch not found!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    // Get the session_id from the fetched record
    $ses = $data_get->company_id;

    // Update the status of all records with the same session_id to 2
    $updatedRows = HrDirectoryBranchModel::where('company_id', $ses)->update(['status' => 2]);

    // Check if any rows were updated
    if ($updatedRows > 0) {
      return response([
        'status'    => 200,
        'message'   => 'All HR Branch have been successfully Deleted..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 404,
        'message'   => 'No HR Branch found!',
        'error_msg' => null,
        'data'      => null,
      ], 404);
    }
  }

  // HR DIRECTORY UPDATE
  public function update_directory($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $edit   = HrDirectoryModel::where('sno', $decryptedValue)->first();
    //  return  $edit;


    return view('content.placements_events.hr_directory.edit', [
      'edit' => $edit,
      // 'branch_list' => $branch,
    ]);
  }
  // HR DIRECTORY Update
  public function Update(Request $request)
  {

    // return $request;
    // Validate the request data
    $validator = Validator::make($request->all(), [
      'hr_company_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }
    $hr_company_name_add = $request->hr_company_name;
    $sno = $request->edit_id;
    $branch_chk = $request->if_branch_add;
    $add = HrDirectoryModel::find($sno);
    $add->company_name = $hr_company_name_add;
    $add->branch_check = $branch_chk ?? 0;
    $add->company_name = $hr_company_name_add;
    $add->address = $request->main_branch_address;
    $add->company_desc = $request->main_desc;
    $add->address = $request->main_address;
    $add->country = $request->country_edit;
    $add->state = $request->state_edit;
    $add->city = $request->city_edit;
    // dd($add->city);

    $add->hr_contact_name = json_encode($request->hr_person_name);
    // dd($add->hr_contact_name);
    $add->hr_contact_phone = json_encode($request->hr_person_mobile);
    // dd($add->hr_contact_phone);
    $add->location_url = $request->main_location_url;
    $add->branch_id = $request->user()->branch_id;
    $add->created_by = $request->user()->user_id;
    $add->updated_by = $request->user()->user_id;

    // dd($add);
    $add->update();
    // dd($add);




    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'HR Directory Update successfully!'
    ]);
    // return $request;
    return redirect('placements/hr_directory');
    // return redirect()->back();
  }



  //SubBranch  function
  public function hr_branch_delete($id)
  {

    $upd_hrdirectoryModel =  HrDirectoryBranchModel::where('sno', $id)->first();
    $upd_hrdirectoryModel->status  = 2;
    $upd_hrdirectoryModel->Update();
    if ($upd_hrdirectoryModel) {
      return response([
        'status'    => 200,
        'message'   => ' Hr Directory Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete  Hr Directory!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
}