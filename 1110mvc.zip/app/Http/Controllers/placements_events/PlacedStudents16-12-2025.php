<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\CourseTypeModel;

class PlacedStudents extends Controller
{
  public function index()
  {
    return view('content.placements_events.placed_students.placed_stud_list');
  }


  public function CourseTypeList()
  {
    $Coursetype = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }
  public function JobRoleList()
  {
    $Coursetype = DB::table('za_job_subcategory')->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }
  public function placedReport(Request $request)
  {
    $branch_id   = $request->user()->branch_id;
    $search_fill = $request->input('search_fill', '');
    $course_id   = $request->input('course_id', '');
    $job_role_id = $request->input('job_role_id', '');
    $date        = $request->input('date', ''); // today, week, month, custom

    $query = DB::table('za_placement_interview as pi')
      ->select(
        'pi.sno as interview_id',
        'j.interview_date',
        'c.company_name',
        'c.company_address',
        'jc.job_category_name',
        'js.job_subcategory_name as job_role_name',
        'pi.status',
        'pi.job_salary',
        'pi.job_position',
        'cust.cus_name',
        'cust.placement_status',
        'cust.cus_gender',
        'cust.cus_mobile',
        'cust.cus_email_id',
        'cust.cus_pic',
        'cust.customer_id',
        'pi.interview_checklist_status',
        'cust.sno as cus_id',
         DB::raw("FORMAT(pi.job_salary, 0) as job_salary"),
         DB::raw("CONCAT('" . asset('cus_pics') . "/', cust.cus_pic) as cus_pic"),
        DB::raw("
            MAX(
                CASE
                    WHEN tr.tesbo_check = 2 THEN 'TESBO Courses'
                    ELSE za_course_type.course_type_name
                END
            ) as course_type_name
        ")



      )

      ->join('za_customer as cust', 'cust.sno', '=', 'pi.customer_id')
      ->join('za_jobs as j', 'j.sno', '=', 'pi.job_id')
      ->leftJoin('za_job_category as jc', 'jc.sno', '=', 'j.job_category_id')
      ->leftJoin('za_job_subcategory as js', 'js.sno', '=', 'j.job_subcategory_id')
      ->join('za_placement_company as c', 'c.sno', '=', 'j.company_id')
      ->leftJoin('za_training as tr', 'tr.customer_id', '=', 'cust.sno')
      ->leftJoin('za_course', 'za_course.sno', '=', 'tr.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      // ->leftJoin('za_cities as city', function ($join) {
      //   $join->on(DB::raw("c.company_address"), 'LIKE', DB::raw("CONCAT('%', city.name, '%')"));
      // })
      // ->leftJoin('za_states as state', function ($join) {
      //   $join->on('state.id', '=', 'city.state_id');
      //   $join->where('state.country_id', 101);   // static country
      // })

      ->where('pi.status', 4)
      ->where('cust.branch_id', $branch_id)
      ->orderBy('j.interview_date', 'desc')
      ->groupBy(
        'pi.sno',
        'j.interview_date',
        'c.company_name',
        'c.company_address',
        'jc.job_category_name',
        'js.job_subcategory_name',
        'pi.status',
        'pi.job_salary',
        'pi.job_position',
        'cust.cus_name',
        'cust.placement_status',
        'cust.cus_gender',
        'cust.cus_mobile',
        'cust.cus_email_id',
        'cust.cus_pic',
        'cust.customer_id',
        'pi.interview_checklist_status',
        'cust.sno',
        // 'city.name',
      );




    // Search filter
    if ($search_fill != '') {
      $query->where(function ($q) use ($search_fill) {
        $q->where('cust.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.cus_email_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('cust.customer_id', 'LIKE', "%{$search_fill}%")
          ->orWhere('c.company_name', 'LIKE', "%{$search_fill}%");
      });
    }

    // Course filter
    if ($course_id != '') {
      $query->where(function ($q) use ($course_id) {
        $q->where(function ($q2) {
          $q2->where('tr.tesbo_check', 2)
            ->whereRaw('2 = ?', [request('course_id')]);
        })
          ->orWhere(function ($q2) use ($course_id) {
            $q2->where('tr.tesbo_check', '!=', 2)
              ->where('za_course.course_type_id', $course_id);
          });
      });
    }



    // Job role filter
    if ($job_role_id != '') {
      $query->where('j.job_subcategory_id', $job_role_id);
    }

    // Date filter
    if ($date != '' && $date != 'all') {
      if ($date == 'today') {
        $query->whereDate('j.interview_date', today());
      } elseif ($date == 'week') {
        $query->whereBetween('j.interview_date', [now()->startOfWeek(), now()->endOfWeek()]);
      } elseif ($date == 'monthly') {
        $query->whereMonth('j.interview_date', now()->month)
          ->whereYear('j.interview_date', now()->year);
      } elseif ($date == 'custom') {
        $from = $request->input('from_date');
        $to   = $request->input('to_date');
        if ($from && $to) {
          $query->whereBetween('j.interview_date', [$from, $to]);
        }
      }
    }

    $students = $query->get();

    return response()->json([
      'status' => 200,
      'data'   => $students
    ]);
  }
}
