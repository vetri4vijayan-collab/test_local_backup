<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\PlacementStudentExports;
use Illuminate\Support\Facades\DB;
use App\Models\HrDirectoryModel;
use App\Models\CourseTypeModel;
use App\Models\InterviewCheckListModel;
use App\Models\PlacementFollowupModel;
use App\Models\JobDirectoryModel;
use App\Models\InterviewModel;
use Illuminate\Http\Request;
use App\Models\JobModel;
use App\Models\CustomerPlacementModel;
use Illuminate\Support\Facades\Validator;


use Maatwebsite\Excel\Facades\Excel;

class ManageJobs extends Controller
{
    public function index(Request $request)
    {

        // return $request;
        
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
    
        $search_fill = $request->input('search_fill', '');
        $filter_on = $request->input('filter_on', false);
        $search_company = $request->input('search_company', '');
        $search_job_category = $request->input('search_job_category', '');
        $search_job_sub_category = $request->input('search_job_sub_category', '');
        $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
        $dt_fill_date_type = $request->input('dt_fill_date_type', '');
        $search_start_date = $request->input('search_start_date', '');
        $search_end_date = $request->input('search_end_date', '');
    
        $job_list = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_staff.staff_name','za_staff.nick_name','za_staff.staff_image')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_jobs.created_by')
        ->where('za_jobs.status', '!=', 2);
        // ->where('za_jobs.branch_id', $branch_id);
        
        $job_list->where(function ($query) use ($branch_id) {
            $query->where(function ($subQuery) use ($branch_id) {
                // When branch_ids is null or empty, use branch_id
                $subQuery->whereNull('za_jobs.branch_ids')
                        ->orWhere('za_jobs.branch_ids', '')
                        ->orWhere('za_jobs.branch_ids', '[]')
                        ->where('za_jobs.branch_id', $branch_id);
            })->orWhere(function ($subQuery) use ($branch_id) {
                // When branch_ids has value, check if branch_id exists in the JSON array
                $subQuery->whereNotNull('za_jobs.branch_ids')
                        ->where('za_jobs.branch_ids', '!=', '')
                        ->where('za_jobs.branch_ids', '!=', '[]')
                        ->whereJsonContains('za_jobs.branch_ids', (string)$branch_id);
            });
        });
        

        if (!empty($search_fill)) {
            $job_list->where(function ($query) use ($search_fill) {
                $query->Where('za_placement_company.company_name', 'LIKE', "%{$search_fill}%")
                // ->where('za_job_category.job_category_name', 'LIKE', "%{$search_fill}%")
                // ->orWhere('za_job_subcategory.job_subcategory_name', 'LIKE', "%{$search_fill}%")
                // ->orWhere('za_interview_type.interview_type_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('za_placement_company.company_address', 'LIKE', "%{$search_fill}%");
            });
        }

        if(!empty($search_company)){
            $job_list->where('za_placement_company.sno',$search_company);
        }

        if(!empty($search_job_category)){
            $job_list->where('za_job_category.sno',$search_job_category);
        }

        if(!empty($search_job_sub_category)){
            $job_list->where('za_job_subcategory.sno',$search_job_sub_category);
        }


        if ($dt_fill_issue_rpt == "today") {
            $todayDate = date("Y-m-d");
            if($dt_fill_date_type == 'interview_date'){
                $job_list->whereDate('za_jobs.interview_date', $todayDate);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->whereDate('za_jobs.last_apply_date', $todayDate);
            }
        } elseif ($dt_fill_issue_rpt == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
            }
            if($dt_fill_date_type == 'interview_date'){
                $job_list->whereBetween('za_jobs.interview_date', [$weekFromDate, $weekToDate]);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->whereBetween('za_jobs.last_apply_date', [$weekFromDate, $weekToDate]);
            }
        } elseif ($dt_fill_issue_rpt == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth  = date('Y-m-t');
            if($dt_fill_date_type == 'interview_date'){
                $job_list->whereBetween('za_jobs.interview_date', [$firstDayOfMonth, $lastDayOfMonth]);
            }else if($dt_fill_date_type == 'last_pay_date'){
                $job_list->whereBetween('za_jobs.last_apply_date', [$firstDayOfMonth, $lastDayOfMonth]);
            }
        } elseif ($dt_fill_issue_rpt == "custom_date") {
            if ($search_start_date && $search_end_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                $toDate   = date('Y-m-d', strtotime($search_end_date));
                if($dt_fill_date_type == 'interview_date'){
                    $job_list->whereBetween('za_jobs.interview_date', [$fromDate, $toDate]);
                }else if($dt_fill_date_type == 'last_pay_date'){
                    $job_list->whereBetween('za_jobs.last_apply_date', [$fromDate, $toDate]);
                }
            } elseif ($search_start_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                if($dt_fill_date_type == 'interview_date'){
                    $job_list->where('za_jobs.interview_date', '>=', $fromDate);
                }else if($dt_fill_date_type == 'last_pay_date'){
                    $job_list->where('za_jobs.last_apply_date', '>=', $fromDate);
                }
            } elseif ($search_end_date) {
                $toDate = date('Y-m-d', strtotime($search_end_date));
                if($dt_fill_date_type == 'interview_date'){
                    $job_list->where('za_jobs.interview_date', '<=', $toDate);
                }else if($dt_fill_date_type == 'last_pay_date'){
                    $job_list->where('za_jobs.last_apply_date', '<=', $toDate);
                }
            }
        }
            
        $job_list = $job_list->orderBy('za_jobs.sno', 'desc')->paginate($perpage);

        foreach( $job_list as $job){
            if (!empty($job->skill_description)) {
                $skills = json_decode($job->skill_description, true);
                $skill_names = array_map(function ($skill) {
                    return $skill['value'];
                }, $skills);
                $job->skill_description = implode(', ', $skill_names); 
            }
            if (!empty($job->interest_student_ids)) {
                $customer_ids = json_decode($job->interest_student_ids, true);
                $students = DB::table('za_customer')
                    ->select('za_customer.*')
                    ->where('za_customer.status', '!=', 2)
                    ->whereIn('sno', $customer_ids)
                    ->orderBy('za_customer.cus_name', 'asc')
                    ->get();
                $job->customer_list = $students;
                $job->intrested_student_count = count($customer_ids); 
            }
        }

        // return   $job_list;
        return view('content.placements_events.manage_jobs.manage_jobs', [
            'job_list' => $job_list,
            'pageConfigs' => ['myLayout' => 'default'],
            'perpage'=> $perpage,
            'search_fill'=>$search_fill,
            'filter_on'=>$filter_on,
            'search_company' => $search_company,
            'search_job_category' => $search_job_category,
            'search_job_sub_category' => $search_job_sub_category,
            'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
            'dt_fill_date_type' => $dt_fill_date_type,
            'search_start_date' => $search_start_date,
            'search_end_date' => $search_end_date,
        ]);
    }

    public function View($id,Request $request)
    {
        
        $branch_id = $request->user()->branch_id;

        $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->where('za_jobs.status', '!=', 2)
        ->where('za_jobs.branch_id', $branch_id)
        ->where('za_jobs.sno', $id)
        ->first(); 

        if (!empty($job_data->skill_description)) {
            $skills = json_decode($job_data->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job_data->skill_description = implode(', ', $skill_names); 
        }
        if (!empty($job_data->interest_student_ids)) {
            $customer_ids = json_decode($job_data->interest_student_ids, true);
            $students = DB::table('za_customer')
                ->select('za_customer.*')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('sno', $customer_ids)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
            $job_data->customer_list = $students;
            $job_data->intrested_student_count = count($customer_ids); 
        }
       
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $job_data ,
        ], 200);
    }

    // public function JobDetails($id,Request $request)
    // {
        
    //     $branch_id = $request->user()->branch_id;
    //     $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
    //             ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
    //             ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
    //             ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
    //             ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
    //             ->where('za_jobs.status', '!=', 2)
    //             ->where('za_jobs.branch_id', $branch_id)
    //             ->where('za_jobs.sno', $id)
    //             ->first(); 
    
    //     if (!empty($job_data->skill_description)) {
    //         $skills = json_decode($job_data->skill_description, true);
    //         $skill_names = array_map(function ($skill) {
    //             return $skill['value'];
    //         }, $skills);
    //         $job_data->skill_description = implode(', ', $skill_names); 
    //     }
    //     $job_data->intrested_student_count = 0;
    //     if (!empty($job_data->interest_student_ids)) {
    //         $customer_ids = json_decode($job_data->interest_student_ids, true);
    //         $job_data->student_ids = $customer_ids;
    //         $job_data->intrested_student_count = count($customer_ids); 
    //     }
       
       
    //     return response()->json([
    //         'status' => 200,
    //         'success' => true,
    //         'message' => null,
    //         'error_msg' => null,
    //         'data' => $job_data ,
    //     ], 200);
    // }
    public function JobDetails($id, Request $request)
     {
    $branch_id = $request->user()->branch_id;

    $job_data = JobModel::select(
            'za_jobs.*',
            'za_placement_company.company_name',
            'za_job_category.job_category_name',
            'za_job_subcategory.job_subcategory_name as job_role_name',
            'za_interview_type.interview_type_name',
            'za_placement_company.company_address'
        )
        ->join('za_placement_company', 'za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category', 'za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory', 'za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type', 'za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->where('za_jobs.status', '!=', 2)
        ->where('za_jobs.branch_id', $branch_id)
        ->where('za_jobs.sno', $id)
        ->first();

    if (!$job_data) {
        return response()->json([
            'status' => 404,
            'success' => false,
            'message' => 'Job not found',
            'error_msg' => 'Invalid job id or branch mismatch',
            'data' => null,
        ], 404);
    }

    if (!empty($job_data->skill_description)) {
        $skills = json_decode($job_data->skill_description, true);
        $skill_names = array_map(fn($skill) => $skill['value'], $skills);
        $job_data->skill_description = implode(', ', $skill_names);
    }

    $job_data->intrested_student_count = 0;
    if (!empty($job_data->interest_student_ids)) {
        $customer_ids = json_decode($job_data->interest_student_ids, true);
        $job_data->student_ids = $customer_ids;
        $job_data->intrested_student_count = count($customer_ids);
    }

    return response()->json([
        'status' => 200,
        'success' => true,
        'message' => null,
        'error_msg' => null,
        'data' => $job_data,
    ], 200);
}


    public function AllStudentList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $course_type_ids = $request->course_type_id;  // This will now be an array
        $job_id = $request->job_id;  // This will now be an array
        $merged_students = [];
        if(in_array(2,$course_type_ids )){
            $tesbo_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno','za_course.course_type_id')
            ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', 2)
            ->whereNotIn('za_customer.sno', function ($query) use ($job_id) {
                $query->select('customer_id')
                    ->from('za_placement_interview')
                    ->where('job_id', $job_id);
            })
            // ->where('za_course.course_type_id', 2) 
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();
        }else{
            $tesbo_students=[];
        }
        // Merge TESBO results
        foreach ($tesbo_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => []
                ];
            }
        
            // Set course type name for TESBO
            $student->course_type_name = 'TESBO Course';
        
            // Add to merged array
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
        }
        
        // Second: Query for other course types (excluding TESBO)
        $other_course_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_mobile', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno')
           ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', '!=', 2) // Exclude TESBO courses
            ->whereIn('za_course.course_type_id', $course_type_ids) // Other course types
            ->whereNot('za_course.course_type_id', 2)
             ->whereNotIn('za_customer.sno', function ($query) use ($job_id) {
                $query->select('customer_id')
                    ->from('za_placement_interview')
                    ->where('job_id', $job_id);
            }) // Other course types
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();
        
        // Merge other course type results
        foreach ($other_course_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => []
                ];
            }
        
            // Add the course type name
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
        }
        
        // Final formatting: Combine course types and remove duplicates
        $final_students = [];
        foreach ($merged_students as $student) {
            // Remove duplicates in course types and merge
            $student['course_type_name'] = implode(', ', array_unique($student['course_type_name'])); // Remove duplicates
            $final_students[] = $student;
        }
    
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $final_students,
        ], 200);
    }
    

    
    public function AddInterestStudent(Request $request)
{
    // Validate the incoming request data
    $validator = Validator::make($request->all(), [
        'interested_student_ids' => 'required|array',
        'interested_student_ids.*' => 'integer',
    ]);

    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Incorrect format in input fields.'
        ]);
        return redirect()->back();
    }

    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $job_id = $request->intrst_job_id;
    $new_students = $request->interested_student_ids ?? [];

    $company_data = JobModel::where('sno', $job_id)->first();

    if ($company_data) {
        // Decode existing interested student IDs
        $existing_ids = json_decode($company_data->interest_student_ids ?? '[]', true);

        // Merge and remove duplicates
        $merged_ids = array_unique(array_merge($existing_ids, $new_students));

        // Save merged IDs back to the job record
        $company_data->interest_student_ids = json_encode($merged_ids);
        $company_data->update();

        // Add new interview entries for students who don't already have one
        foreach ($new_students as $studentid) {
            $exists = InterviewModel::where('job_id', $job_id)
                ->where('customer_id', $studentid)
                ->where('branch_id', $branch_id)
                ->exists();

            if (!$exists) {
                $last_interv_entry = InterviewModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();

                if (!$last_interv_entry) {
                    $year = substr(date('y'), -2);
                    $placement_interview_id = 'SIV-0001/' . $year;
                } else {
                    $data = $last_interv_entry->placement_interview_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $placement_interview_id = sprintf('SIV-%04d', $next_number) . '/' . substr(date('y'), -2);
                }

                $interview_checklist_id = json_decode($company_data->interview_checklist_id ?? '[]', true);
                $interview_checklist_status = array_fill(0, count($interview_checklist_id), "0");

                $add = new InterviewModel();
                $add->placement_interview_id = $placement_interview_id;
                $add->customer_id = $studentid;
                $add->job_id = $job_id;
                $add->interview_checklist_status = json_encode($interview_checklist_status);
                $add->branch_id = $branch_id;
                $add->created_by = $user_id;
                $add->updated_by = $user_id;
                $add->save();
            }
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Interested students updated successfully!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Job not found!'
        ]);
    }

    return redirect('placements/manage_jobs');
}
   
        
    
    // Status change
    public function Status($id, Request $request)
    {
    $upd_companyModel =  JobModel::where('sno', $id)->first();
    $upd_companyModel->status = $request->input('status', 0);
    $upd_companyModel->update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Status Successfully Updated !',
        'error_msg' => 'Could not ,update Job!',
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 204,
        'message'   => 'Could not update Job!',
        'error_msg' => 'Could not ,update  Job!',
        'data'      => null,
        ], 204);
    }
    }

    //delete function
    public function Delete($id)
    {

    $upd_companyModel =  JobModel::where('sno', $id)->first();
    $upd_companyModel->status  = 2;
    $upd_companyModel->Update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 200,
        'message'   => 'Could not delete Job!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }
    }

    public function UpdateLastPayDate($id, Request $request)
    {
        $upd_companyModel = JobModel::where('sno', $id)->first();
        $last_pay_date = date('Y-m-d',strtotime($request->last_pay_date));
        $upd_companyModel->last_apply_date = $last_pay_date;
        $upd_companyModel->update();

        $expiry_msg = "";
        if(date('Y-m-d', strtotime($upd_companyModel->last_apply_date . ' -2 days')) <= date('Y-m-d') && $upd_companyModel->last_apply_date >= date('Y-m-d')){
            $expiry_msg = "[ Expired Soon.. ]";
        }else if($upd_companyModel->last_apply_date < date('Y-m-d')){
            $expiry_msg = "[ Expired.. ]";
        }
        
        if ($upd_companyModel) {
            return response([
            'status'    => 200,
            'message'   => 'Job Last Pay Date Updated Successfully !',
            'error_msg' => null,
            'data'      => null,
            'update_date' => date('d-M-Y',strtotime($last_pay_date)),
            'expiry_msg' => $expiry_msg,
            ], 200);
        } else {
            return response([
            'status'    => 204,
            'message'   => 'Could not update Job!',
            'error_msg' => 'Could not ,update  Job!',
            'data'      => null,
            ], 204);
        }
    }

   
}
