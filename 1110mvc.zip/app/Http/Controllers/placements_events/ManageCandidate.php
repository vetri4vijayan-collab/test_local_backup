<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\PlacementStudentExports;
use Illuminate\Support\Facades\DB;
use App\Models\HrDirectoryModel;
use App\Models\CourseTypeModel;
use App\Models\InterviewCheckListModel;
use App\Models\PlacementFollowupModel;
use App\Models\JobDirectoryModel;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\InterviewModel;
use Illuminate\Http\Request;
use App\Models\JobModel;
use App\Models\BranchModel;
use App\Models\CustomerPlacementModel;
use App\Models\CustomerEducationModel;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Pagination\LengthAwarePaginator;


use Maatwebsite\Excel\Facades\Excel;

class ManageCandidate extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;
    
        $search_fill = $request->input('search_fill', '');
        $filter_on = $request->input('filter_on', false);
        $search_cust_name = $request->input('search_cust_name', '');
        $search_cust_mobile = $request->input('search_cust_mobile', '');
        $search_cust_id = $request->input('search_cust_id', '');
        $search_course = $request->input('search_course', '');
        $search_course_type = $request->input('search_course_type', '');
        $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
        $dt_fill_date_type = $request->input('dt_fill_date_type', '');
        $search_start_date = $request->input('search_start_date', '');
        $search_end_date = $request->input('search_end_date', '');
    
        $branch_id = $request->user()->branch_id;
        $course_type_ids = $request->course_type_id;  // This will now be an array
        $merged_students = [];
    
        $tesbo_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.customer_id','za_customer.cus_name','za_course.course_name','za_customer.cus_pic', 'za_customer.cus_gender','za_customer.doj', 'za_customer.cus_mobile', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno','za_course.course_type_id','za_training.batch_id','za_training.course_id','za_training.payment_id','za_customer.branch_id')
            ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', 2)
            // ->where('za_course.course_type_id', 2) 
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();
        
        // Merge TESBO results
        foreach ($tesbo_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'customer_id' => $student->customer_id,
                    'branch_id' => $student->branch_id,
                    'cus_doj' => $student->doj,
                    'cus_gender' => $student->cus_gender,
                    'cus_pic' => $student->cus_pic??'',
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => [],
                    'course_name' => [],
                    'batch_id' => [],
                    'payment_id' => [],
                    'course_id' => [],
                    'training_sno' => []
                ];
            }
        
            // Add to merged array
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
            $merged_students[$student->sno]['course_name'][] = $student->course_name;
            $merged_students[$student->sno]['batch_id'][] = $student->batch_id;
            if (!in_array($student->payment_id, $merged_students[$student->sno]['payment_id'])) {
                $merged_students[$student->sno]['payment_id'][] = $student->payment_id;
            }
            $merged_students[$student->sno]['training_sno'][] = $student->training_sno;
            $merged_students[$student->sno]['course_id'][] = $student->course_id;
        }
        
        // Second: Query for other course types (excluding TESBO)
        $other_course_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.cus_name','za_course.course_name','za_customer.customer_id', 'za_customer.cus_pic', 'za_customer.cus_gender', 'za_customer.cus_mobile','za_customer.doj', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno','za_training.batch_id','za_training.payment_id','za_training.course_id','za_customer.branch_id')
            ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', '!=', 2) // Exclude TESBO courses
            ->where('za_customer.is_placement', 1) // Other course types
            ->whereNot('za_course.course_type_id', 2) // Other course types
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();

        // Merge other course type results
        foreach ($other_course_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'customer_id' => $student->customer_id,
                    'branch_id' => $student->branch_id,
                    'cus_pic' => $student->cus_pic??'',
                    'cus_doj' => $student->doj,
                    'cus_gender' => $student->cus_gender,
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => [],
                    'course_name' => [],
                    'batch_id' => [],
                    'payment_id' => [],
                    'course_id' => [],
                    'training_sno' => [],
                ];
            }
        
            // Add the course type name
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
            $merged_students[$student->sno]['course_name'][] = $student->course_name;
            $merged_students[$student->sno]['batch_id'][] = $student->batch_id;
            if (!in_array($student->payment_id, $merged_students[$student->sno]['payment_id'])) {
                $merged_students[$student->sno]['payment_id'][] = $student->payment_id;
            }
            
            $merged_students[$student->sno]['training_sno'][] = $student->training_sno;
            $merged_students[$student->sno]['course_id'][] = $student->course_id;
        }
        
        // Final formatting: Combine course types and remove duplicates
        $final_students = [];
        foreach ($merged_students as $student) {
            $student['course_type_name'] = implode(', ', array_unique($student['course_type_name']));
            $student['course_name'] = implode(', ', array_unique($student['course_name']));
            $final_students[] = (object) $student; // Cast each student array to object
        }
       
        // $grouped_candidates = $candidate_list->getCollection()->groupBy('payment_id');

        foreach($final_students as $student){
            $interview=DB::table('za_placement_interview')
                    ->select('za_jobs.*','za_placement_interview.sno as interview_id','za_placement_company.company_name','za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position', 'za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.doj','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.interview_checklist_status')
                    ->join('za_jobs','za_jobs.sno','=','za_placement_interview.job_id')
                    ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
                    ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                    ->where('za_customer.status', '!=', 2)
                    ->where('za_placement_interview.customer_id', $student->sno)
                    ->orderBy('za_jobs.interview_date', 'desc')
                    ->get();

                    $trainingIds = DB::table('za_training')
                    ->where('za_training.status', '!=', 2)
                    ->where('za_training.customer_id', $student->sno)
                    ->pluck('payment_id')
                    ->toArray();
            
            
            
            $student->inteview_count= $interview ? count($interview) :0;
            if (!$interview->isEmpty()) {
                // Filter for pending interviews (status == 0)
                $next_interview = $interview->first(function ($int) {
                    return $int->status == 0;
                });
        
                if ($next_interview) {
                    $student->next_interview_date = $next_interview->interview_date;
                    $student->next_interview_company_name = $next_interview->company_name;
                } else {
                    $student->next_interview_date = null;
                    $student->next_interview_company_name = null;
                }
            } else {
                $student->next_interview_date = null;
                $student->next_interview_company_name = null;
            }

      
           $student->paid_status = 0;
            $courseProgress=0;
            $paymentPercentage =0;
            foreach ($student->payment_id as $index => $payId) {
                
                $paymentAmount = DB::table('za_payment')
                    ->where('za_payment.payment_id', $payId)
                    ->sum('za_payment.paidAmount');
                
                $paymentDetails = DB::table('za_training')
                    ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
                    ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_training.payment_id', $payId) 
                    ->where('za_training.status', '!=', 2)
                    ->where('za_payment.status', '!=', 3)
                    ->groupBy('za_payment.total_amount')
                    ->first();
          
            
                if ($paymentDetails && $paymentDetails->total_amount > 0) {
                    $paymentPercentage = ($paymentAmount / $paymentDetails->total_amount) * 100;
                    
                    if ($paymentPercentage >= 100) {
                        $student->paid_status = 1; // Mark as fully paid
                        break; // No need to check other payment IDs
                    }
                }
            }
            
      
            
        
               foreach ($student->batch_id as $index => $batch_id) {
             
                // Initialize course progress percentage
                $courseProgress = 0;
                    $helper = new \App\Helpers\Helpers();
                $courseProgress    = $helper->get_course_percentage($batch_id, $student->sno);
    
            }
            $student->coursePrecentage=$courseProgress;
            $student->paymentPercentage=$paymentPercentage;

        }

        $final_students = array_filter($final_students, function ($student) {
            return $student->paid_status == 1;
        });
        
        // Collect input filters
        $filters = $request->only([
            'search_cust_name',
            'search_cust_mobile',
            'search_cust_id',
            'search_course',
            'search_course_type',
            'start_date',
            'end_date'
        ]);

        // Apply filters
        $filtered = array_filter($final_students, function ($final_student) use ($filters) {
            
            $final_student = !empty($final_student) && !is_array($final_student) ? json_encode($final_student) : "";
            $final_student = !empty($final_student) && !is_array($final_student) ? json_decode($final_student,true) : [];

            $final_student['course_type_name'] = isset($final_student['course_type_name']) && !empty($final_student['course_type_name']) ? (is_array($final_student['course_type_name']) ? $final_student['course_type_name'] : array_map('trim', explode(',', $final_student['course_type_name']))) : [];

            $final_student['course_name'] = isset($final_student['course_name']) && !empty($final_student['course_name']) ? (is_array($final_student['course_name']) ? $final_student['course_name'] : array_map('trim', explode(',', $final_student['course_name']))) : [];

            if (!empty($filters['search_cust_name']) && stripos($final_student['cus_name'], $filters['search_cust_name']) === false) {
                return false;
            }

            if (!empty($filters['search_cust_mobile']) &&
                stripos($final_student['cus_mobile'], $filters['search_cust_mobile']) === false) {
                return false;
            }

            if (!empty($filters['search_cust_id']) &&
                stripos($final_student['customer_id'], $filters['search_cust_id']) === false) {
                return false;
            }

            if (!isset($final_student['course_type_name']) || (!empty($filters['search_course_type']) && !in_array($filters['search_course_type'], (array) $final_student['course_type_name']))) {
                return false;
            }

            if (!isset($final_student['course_name']) || (!empty($filters['search_course']) && !in_array($filters['search_course'], (array) $final_student['course_name']))) {
                return false;
            }

            return $final_student;
        });
        
        // return $filtered;
        // Re-index filtered array
        $final_students = array_values($filtered);

        
        foreach ($final_students as $key => $item) {

                $carouselDetails = [];
        
            // Get payment details and course info
            $paymentDetailss = DB::table('za_payment')
                ->select('za_payment.status', 'za_payment.nextPayDate')
                ->where('za_payment.customer_id', $item->sno)
                ->where('za_payment.status', 0)
                ->get();
        
            $paymentget = DB::table('za_training')
                ->where('customer_id', $item->sno)
                ->whereIn('status', [0, 2])
                ->get();
        
            $courseIds = $paymentget;

            $education_details_count = DB::table('za_customer_education')->select('sno')->where('branch_id', $item->branch_id)
            ->where('customer_id', '=', $item->sno)
            ->where('status', '=', 0)
            ->count();
        
            foreach ($courseIds as $index => $courseId) {
        
                // Retrieve course details
                $course = DB::table('za_course')
                    ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                    ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                    ->where('za_course.sno', $courseId->course_id)
                    ->first();
        
                // Retrieve batch details
                $batch = DB::table('za_batch')
                    ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                    ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                    ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                    ->where('za_batch.sno', $courseId->batch_id)
                    ->first();
        
                // Retrieve payment details
                $paymentDetails = DB::table('za_training')
                    ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                    ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_training.customer_id', $item->sno)
                    ->where('za_training.course_id', $courseId->course_id)
                    ->where('za_training.status', '!=', 3)
                    ->where('za_payment.status', '!=', 3)
                    ->groupBy('za_payment.total_amount')
                    ->first();
        
                $paymentPercentage = 0;
                if ($paymentDetails && $paymentDetails->total_amount > 0) {
                    $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                    if($paymentPercentage>=100){
                        
                        $paymentPercentage = 100;
                        
                    }
                }
        
                // Check if attendance exists for the specific batch and customer
                $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                    ->where('batch_id', $courseId->batch_id)
                    ->where('attendance', 'P')
                    ->get();
        
                // Initialize course progress percentage
                $courseProgress = 0;
                $topicCount = 0;
                $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                    ->count();
                    
                    $helper = new \App\Helpers\Helpers();
                    $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);   
                // batch count by course id
                $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
                
                
                //*************************************************************************************
                
                $currentDate = date('Y-m-d');
        
                
                $start_date = $batch->start_date ?? null;
                $end_date  = $batch->end_date ?? null;
        
                // Add course and batch details to the array
                $carouselDetails[] = [
                    'course_sno' => $courseId->course_id ?? null,
                    'course_mode_id' => $courseId->course_mode_id ?? null,
                    'online_course_fee' => $course->online_fee ?? null,
                    'batch_sno' => $courseId->batch_id ?? 0,
                    'batch_count' => $batch_count ?? 0,
                    'traning_sno' => $courseId->sno ?? null,
                    'traning_status' => $courseId->status ?? null,
                    'course_name' => $course->course_name ?? null,
                    'course_type_name' => $course->course_type_name ?? null,
                    'batch_name' => $batch->batch_name ?? null,
                    'start_date' => $batch->start_date ?? null,
                    'end_date' => $batch->end_date ?? null,
                    'slot_name' => $batch->slot_name ?? null,
                    'staff_name' => $batch->staff_name ?? null,
                    'payment_percentage' => $paymentPercentage,
                    'course_progress' => $courseProgress,
                ];
            }
                    $item->carousel_details = $carouselDetails;
                    $item->education_details_count = $education_details_count ?? 0;
            }     
       
        return view('content.placements_events.manage_candidate.manage_candidate', [
            'candidate_list' => $final_students,
            'pageConfigs' => ['myLayout' => 'default'],
            'perpage'=> $perpage,
            'search_fill'=>$search_fill,
            'filter_on'=>$filter_on,
            'search_cust_name' => $search_cust_name,
            'search_cust_mobile' => $search_cust_mobile,
            'search_cust_id' => $search_cust_id,
            'search_course' => $search_course,
            'search_course_type' => $search_course_type,
            'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
            'dt_fill_date_type' => $dt_fill_date_type,
            'search_start_date' => $search_start_date,
            'search_end_date' => $search_end_date,
        ]);
    }

    public function Applicants(Request $request){

        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        
        $search_fill = $request->input('search_fill', '');
        $filter_on = $request->input('filter_on', false);
        $search_company = $request->input('search_company', '');
        $search_cust_name = $request->input('search_cust_name', '');
        $search_cust_mobile = $request->input('search_cust_mobile', '');
        $search_status = $request->input('search_status', '');
        $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
        $dt_fill_date_type = $request->input('dt_fill_date_type', '');
        $search_start_date = $request->input('search_start_date', '');
        $search_end_date = $request->input('search_end_date', '');
        $search_course = $request->input('search_course', '');
        $search_course_type = $request->input('search_course_type', '');

        $students = DB::table('za_placement_interview')
            ->select('za_placement_interview.sno as interview_id','za_placement_interview.status','za_placement_interview.customer_id','za_placement_interview.job_salary','za_placement_interview.job_position', 'za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.cus_email_id','za_customer.cus_pic','za_placement_interview.interview_checklist_status','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email','za_jobs.interview_date')
            ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
            ->join('za_jobs','za_placement_interview.job_id', '=', 'za_jobs.sno')
            ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
            ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
            ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
            ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
            ->where('za_customer.status', '!=', 2)
            ->where('za_placement_interview.branch_id',$branch_id );

        if(!empty($search_company)){
            $students->where('za_placement_company.sno',$search_company);
        }

        if(!empty($search_status)){
            $students->where('za_placement_interview.status',$search_status);
        }

        if(!empty($search_cust_name)){
            $students->where('za_customer.cus_name',$search_cust_name);
        }

        if(!empty($search_cust_mobile)){
            $students->where('za_customer.cus_mobile',$search_cust_mobile);
        }

        if ($dt_fill_issue_rpt == "today") {
            $todayDate = date("Y-m-d");
            $students->whereDate('za_jobs.interview_date', $todayDate);
        } elseif ($dt_fill_issue_rpt == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
            }     
            $students->whereBetween('za_jobs.interview_date', [$weekFromDate, $weekToDate]);
            
        } elseif ($dt_fill_issue_rpt == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth  = date('Y-m-t');
            $students->whereBetween('za_jobs.interview_date', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($dt_fill_issue_rpt == "custom_date") {
            if ($search_start_date && $search_end_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                $toDate   = date('Y-m-d', strtotime($search_end_date));
                $students->whereBetween('za_jobs.interview_date', [$fromDate, $toDate]);
            } elseif ($search_start_date) {
                $fromDate = date('Y-m-d', strtotime($search_start_date));
                $students->where('za_jobs.interview_date', '>=', $fromDate);
            } elseif ($search_end_date) {
                $toDate = date('Y-m-d', strtotime($search_end_date));
                $students->where('za_jobs.interview_date', '<=', $toDate);
            }
        }

        $students = $students->orderBy('za_customer.cus_name', 'asc')->paginate($perpage);

        foreach ($students as $key => $item) {

            $carouselDetails = [];
    
            // Get payment details and course info
            $paymentDetailss = DB::table('za_payment')
                ->select('za_payment.status', 'za_payment.nextPayDate')
                ->where('za_payment.customer_id', $item->customer_id)
                ->where('za_payment.status', 0)
                ->get();
    
            $paymentget = DB::table('za_training')
                ->where('customer_id', $item->customer_id)
                ->whereIn('status', [0, 2])
                ->get();
    
            $courseIds = $paymentget;
    
            foreach ($courseIds as $index => $courseId) {
    
                // Retrieve course details
                $course = DB::table('za_course')
                    ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                    ->select('za_course.course_name', 'za_course.course_type_id', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                    ->where('za_course.sno', $courseId->course_id)
                    ->first();
    
                // Retrieve batch details
                $batch = DB::table('za_batch')
                    ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                    ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                    ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                    ->where('za_batch.sno', $courseId->batch_id)
                    ->first();
    
                // Retrieve payment details
                $paymentDetails = DB::table('za_training')
                    ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                    ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_training.customer_id', $item->customer_id)
                    ->where('za_training.course_id', $courseId->course_id)
                    ->where('za_training.status', '!=', 3)
                    ->where('za_payment.status', '!=', 3)
                    ->groupBy('za_payment.total_amount')
                    ->first();
    
                $paymentPercentage = 0;

                if ($paymentDetails && $paymentDetails->total_amount > 0) {
                    $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                    if($paymentPercentage >= 100){
                        $paymentPercentage = 100;
                    }
                }
    
                // Check if attendance exists for the specific batch and customer
                $attendanceRecords = AttendanceModel::where('customer_id', $item->customer_id)
                    ->where('batch_id', $courseId->batch_id)
                    ->where('attendance', 'P')
                    ->get();
    
                // Initialize course progress percentage
                $courseProgress = 0;
                $topicCount = 0;
                $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)->count();
                
                $helper = new \App\Helpers\Helpers();
                $courseProgress = $helper->get_course_percentage($courseId->sno, $item->customer_id);

                // batch count by course id
                $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
            
                //*************************************************************************************
                $currentDate = date('Y-m-d');

                $start_date = $batch->start_date ?? null;
                $end_date  = $batch->end_date ?? null;
    
                // Add course and batch details to the array
                $carouselDetails[] = [
                    'course_sno' => $courseId->course_id ?? null,
                    'course_mode_id' => $courseId->course_mode_id ?? null,
                    'online_course_fee' => $course->online_fee ?? null,
                    'batch_sno' => $courseId->batch_id ?? 0,
                    'batch_count' => $batch_count ?? 0,
                    'traning_sno' => $courseId->sno ?? null,
                    'traning_status' => $courseId->status ?? null,
                    'course_name' => $course->course_name ?? null,
                    'course_type_name' => $course->course_type_name ?? null,
                    'course_type_id' => $course->course_type_id ?? null,
                    'batch_name' => $batch->batch_name ?? null,
                    'start_date' => $batch->start_date ?? null,
                    'end_date' => $batch->end_date ?? null,
                    'slot_name' => $batch->slot_name ?? null,
                    'staff_name' => $batch->staff_name ?? null,
                    'payment_percentage' => $paymentPercentage,
                    'course_progress' => $courseProgress,
                ];
            }

            $item->carousel_details = $carouselDetails;
            $item->course_ids = !empty($carouselDetails) ? array_column($carouselDetails,'course_sno') : [];
            $item->course_type_ids = !empty($carouselDetails) ? array_column($carouselDetails,'course_type_id') : [];
        }

        // Collect input filters
        $filters = $request->only([
            'search_course',
            'search_course_type',
        ]);

        $enable_search = false;

        if(isset($search_course) && !empty($search_course)){
            $enable_search = true;
        }

        if(isset($search_course_type) && !empty($search_course_type)){
            $enable_search = true;
        }

        if($enable_search){
            $filteredCollection = $students->getCollection()->filter(function ($entry) use ($filters) {
                if (!isset($entry->course_ids) || (!empty($filters['search_course']) && !in_array($filters['search_course'], $entry->course_ids))) {
                    return false;
                }

                if (!isset($entry->course_type_ids) || (!empty($filters['search_course_type']) && !in_array($filters['search_course_type'], $entry->course_type_ids))) {
                    return false;
                }
                return true;
            });

            $students = $filteredCollection;
        }

        // $students = $filteredCollection->orderBy('za_customer.cus_name', 'asc')->paginate($perpage);
        
        // return $filteredCollection;

        return view('content.placements_events.manage_candidate.manage_applicants', [
            'students' => $students,
            'pageConfigs' => ['myLayout' => 'default'],
            'perpage'=> $perpage,
            'search_fill'=>$search_fill,
            'filter_on'=>$filter_on,
            'search_company' => $search_company,
            'search_course' => $search_course,
            'search_course_type' => $search_course_type,
            'search_cust_name' => $search_cust_name,
            'search_cust_mobile' => $search_cust_mobile,
            'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
            'dt_fill_date_type' => $dt_fill_date_type,
            'search_start_date' => $search_start_date,
            'search_end_date' => $search_end_date,
            'search_status' => $search_status,
        ]);
    }

    public function View($id,Request $request)
    {
        
        $branch_id = $request->user()->branch_id;

        $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address','za_placement_company.company_email')
        ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->where('za_jobs.status', '!=', 2)
        ->where('za_jobs.branch_id', $branch_id)
        ->where('za_jobs.sno', $id)
        ->first(); 

        if (!empty($job_data->skill_description)) {
            $skills = json_decode($job_data->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job_data->skill_description = implode(', ', $skill_names); 
        }
        if (!empty($job_data->interest_student_ids)) {
            $customer_ids = json_decode($job_data->interest_student_ids, true);
            $students = DB::table('za_customer')
                ->select('za_customer.*')
                ->where('za_customer.status', '!=', 2)
                ->whereIn('sno', $customer_ids)
                ->orderBy('za_customer.cus_name', 'asc')
                ->get();
            $job_data->customer_list = $students;
            $job_data->intrested_student_count = count($customer_ids); 
        }
       
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $job_data ,
        ], 200);
    }

    public function JobDetails($id,Request $request)
    {
        
        $branch_id = $request->user()->branch_id;
        $job_data = JobModel::select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
                ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
                ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
                ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
                ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
                ->where('za_jobs.status', '!=', 2)
                ->where('za_jobs.branch_id', $branch_id)
                ->where('za_jobs.sno', $id)
                ->first(); 
    
        if (!empty($job_data->skill_description)) {
            $skills = json_decode($job_data->skill_description, true);
            $skill_names = array_map(function ($skill) {
                return $skill['value'];
            }, $skills);
            $job_data->skill_description = implode(', ', $skill_names); 
        }
        $job_data->intrested_student_count = 0;
        if (!empty($job_data->interest_student_ids)) {
            $customer_ids = json_decode($job_data->interest_student_ids, true);
            $job_data->student_ids = $customer_ids;
            $job_data->intrested_student_count = count($customer_ids); 
        }
       
       
        return response()->json([
            'status' => 200,
            'success' => true,
            'message' => null,
            'error_msg' => null,
            'data' => $job_data ,
        ], 200);
    }
          
 
    // Status change
    public function Status($id, Request $request)
    {
    $upd_companyModel =  JobModel::where('sno', $id)->first();
    $upd_companyModel->status = $request->input('status', 0);
    $upd_companyModel->update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Status Successfully Updated !',
        'error_msg' => 'Could not ,update Job!',
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 204,
        'message'   => 'Could not update Job!',
        'error_msg' => 'Could not ,update  Job!',
        'data'      => null,
        ], 204);
    }
    }

    //delete function
    public function Delete($id)
    {

    $upd_companyModel =  JobModel::where('sno', $id)->first();
    $upd_companyModel->status  = 2;
    $upd_companyModel->Update();
    if ($upd_companyModel) {
        return response([
        'status'    => 200,
        'message'   => 'Job Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    } else {
        return response([
        'status'    => 200,
        'message'   => 'Could not delete Company!',
        'error_msg' => null,
        'data'      => null,
        ], 200);
    }
    }
    
     public function applyJobList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $customer_id      = $request->customer_id;


        $job_list = DB::table('za_jobs')->select('za_jobs.*','za_placement_company.company_name','za_job_category.job_category_name','za_job_subcategory.job_subcategory_name as job_role_name','za_interview_type.interview_type_name','za_placement_company.company_address')
          ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
          ->leftJoin('za_job_category','za_job_category.sno', '=', 'za_jobs.job_category_id')
          ->leftJoin('za_job_subcategory','za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
          ->leftJoin('za_interview_type','za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
          ->where('za_jobs.status',0)
          ->where('za_jobs.last_apply_date','>=',date('Y-m-d'))
          ->where('za_jobs.job_status',0)
          ->whereRaw("JSON_CONTAINS(za_jobs.interest_student_ids, '\"$customer_id\"') = 0")
          ->where('za_jobs.branch_id', $branch_id)
          ->orderBy('za_jobs.sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $job_list,
        ], 200);
    }

    public function GetEducateDetails($id)
    {
        $candidate_details = DB::table('za_customer')
        ->select('za_customer.*')
        ->where('za_customer.status', 0)
        ->where('za_customer.sno', $id)
        ->first();

        
        if ($candidate_details) {

            $CustomerEducationModel = CustomerEducationModel::where('customer_id',$candidate_details->sno)->where('branch_id',$candidate_details->branch_id)->where('status', 0)->first();
            
            $cus_pic_url = $cus_gender_icon = '';
            if($candidate_details->cus_pic){
                $cus_pic_url = url('/cus_pics/'.$candidate_details->cus_pic);
            }else if($candidate_details->cus_gender == 1){
                $cus_pic_url = url('/assets/eapl_images/user_1.png');
            }else if($candidate_details->cus_gender == 2){
                $cus_pic_url = url('/assets/eapl_images/user_2.png');
            }

            if($candidate_details->cus_gender == 1){
                $cus_gender_icon = '<i class="mdi mdi-face-man text-danger"></i>';
            }else if($candidate_details->cus_gender == 2){
                $cus_gender_icon = '<i class="mdi mdi-face-woman text-danger"></i>';
            }

            $candidate_details->candidate_edu_details = $CustomerEducationModel ?? null;

            $CustomerEducationModel_datas = isset($CustomerEducationModel->placed_datas) && !empty($CustomerEducationModel->placed_datas) ? json_decode($CustomerEducationModel->placed_datas) : NULL;

            // Decode 'hr_details' if available
            $CorporateListOptions = isset($CustomerEducationModel->exp_details) && !empty($CustomerEducationModel->exp_details)
                ? json_decode($CustomerEducationModel->exp_details, true)
                : [];

            $options_list = [];;
            foreach ($CorporateListOptions as $item) {
                foreach ($item as $key => $details) {
                    $options_list[$key] = $details;  // append inner arrays
                }
            }

            return response()->json([
                'status' => 200,
                'data' => [
                    'sno' => $candidate_details->sno ?? 0,
                    'customer_id' => $candidate_details->customer_id ?? '',
                    'branch_id' => $candidate_details->branch_id ?? '',
                    'cus_name' => $candidate_details->cus_name ?? '',
                    'cus_mobile' => $candidate_details->cus_mobile ?? '',
                    'cus_pic' => $candidate_details->cus_pic ?? '',
                    'cus_doj' => date('d-M-Y',strtotime($candidate_details->doj)) ?? '',
                    'cus_pic_url' => $cus_pic_url ?? '',
                    'cus_gender' => $candidate_details->cus_gender ?? '',
                    'cus_gender_icon' => $cus_gender_icon ?? '',
                    'candidate_edu_details' => $CustomerEducationModel ?? null,
                    'candidate_edu_datas' => $CustomerEducationModel_datas ?? null,
                    'candidate_exp_details' => $options_list ?? null
                ],
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Candidate not found',
            ]);
        }
    }
    public function UpdateEducateDetails(Request $request){

        // return $request;

        $rules = [
            'edu_inst_name' => 'required',
            'edu_inst_qualification' => 'required',
            'edu_inst_passout' => 'required',
            'edu_cand_cust_id' => 'required',
        ];
        
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors(),
            ], 422);
        }

        $edu_cand_edu_sno = $request->input('edu_cand_edu_sno');
        $edu_cand_cust_id = $request->input('edu_cand_cust_id');
        $edu_cand_cust_branch_id = $request->input('edu_cand_cust_branch_id');
        $edu_inst_name = $request->input('edu_inst_name');
        $edu_inst_qualification = $request->input('edu_inst_qualification');
        $edu_inst_passout = $request->input('edu_inst_passout');
        $is_add_exp_btn_visible = $request->input('is_add_exp_btn_visible',2);
       
        $inter_exp_details = $request->input('inter_exp_details', []);

        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        // Check if the company already exists
        
        if(!empty($edu_cand_edu_sno)){
            
            $chk = CustomerEducationModel::where('branch_id', $edu_cand_cust_branch_id)
            ->where('customer_id', '=', $edu_cand_cust_id)
            ->where('sno', '=', $edu_cand_edu_sno)
            ->first();

            $chk->placed_datas = json_encode([
                'industry_name' => $edu_inst_name,
                'qualification' => $edu_inst_qualification,
                'passout' => $edu_inst_passout
            ]);

            $chk->is_experience = ($is_add_exp_btn_visible == 1) ? 1 : 2;

            $deliverablesJson = null;

            if($chk->is_experience == 1){
                // If deliverables is an array, JSON encode it; if not, leave as is
                if (is_array($inter_exp_details)) {
                    $indexed_options = [];
                    foreach ($inter_exp_details as $index => $value) {
                        if ($value !== '') {
                            // Indexing options starting at 1, as in your second example
                            $indexed_options[] = [(string)((int)$index + 1) => $value];
                        }
                    }
                    $deliverablesJson = json_encode($indexed_options);
                }
            }

            $chk->exp_details = $deliverablesJson;
            $chk->updated_by = $user_id;
            $chk->update();
            $save = true;

        }else{

            $branch_check = BranchModel::where('sno', $edu_cand_cust_branch_id)->orderBy('sno', 'desc')->first();
            $branch_code = $branch_check->city_short_code;

            $ed_check = CustomerEducationModel::orderBy('sno', 'desc')->first();
            if (!$ed_check) {
                $year = date("Y");
                $education_id = $year . '/' . $branch_code . '/' . "EDU2005";
            } else {
                $data = $ed_check->education_id;
                $slice = explode("/", $data);
                $result_cus = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int)$result_cus + 1;
                $request_cos = sprintf("EDU%04d", $next_number_cos);
                $year = date("Y");
                $education_id = $year . '/' . $branch_code . '/' . $request_cos;
            }

            $add_edu_mopdal = new CustomerEducationModel();
            $add_edu_mopdal->education_id= $education_id;
            $add_edu_mopdal->branch_id = $edu_cand_cust_branch_id;
            $add_edu_mopdal->customer_id = $edu_cand_cust_id;
            $add_edu_mopdal->placed_datas = json_encode([
                'industry_name' => $edu_inst_name,
                'qualification' => $edu_inst_qualification,
                'passout' => $edu_inst_passout
            ]);

            $add_edu_mopdal->is_experience = ($is_add_exp_btn_visible == 1) ? 1 : 2;

            $deliverablesJson = null;

            if($add_edu_mopdal->is_experience == 1){
                // If deliverables is an array, JSON encode it; if not, leave as is
                if (is_array($inter_exp_details)) {
                    $indexed_options = [];
                    foreach ($inter_exp_details as $index => $value) {
                        if ($value !== '') {
                            // Indexing options starting at 1, as in your second example
                            $indexed_options[] = [(string)((int)$index + 1) => $value];
                        }
                    }
                    $deliverablesJson = json_encode($indexed_options);
                }
            }

            $add_edu_mopdal->exp_details = $deliverablesJson;
            $add_edu_mopdal->created_by = $user_id;
            $add_edu_mopdal->updated_by = 0;
            $add_edu_mopdal->save();
            $save = true;
        }

        if($save){
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Company Updated Successfully!'
            ]);
        }else{
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Company Not Updated!'
            ]);
        }
        return redirect('placements/manage_candidate');
    }
    public function CourseTypeList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $Coursetype = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

        if(!$Coursetype) {
            return response([
                'status' => 400,
                'message' => 'No Such Records !',
                'error_msg' => null,
                'data' => null
            ], 404);
        } else {
            return response([
                'status' => 200,
                'message' => 'Course Type Fetched Successfully',
                'error_msg' => null,
                'data' => $Coursetype
            ], 200);
        }
    }
    public function CourseList(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $course_type_id = $request->id ?? 0;
        $CourseList = ManageCoursesModel::where('status', 0)->where('course_type_id', $course_type_id)->orderBy('sno', 'desc')->get();

        if(!$CourseList) {
            return response([
                'status' => 400,
                'message' => 'No Such Records !',
                'error_msg' => null,
                'data' => null
            ], 404);
        } else {
            return response([
                'status' => 200,
                'message' => 'Course Fetched Successfully',
                'error_msg' => null,
                'data' => $CourseList
            ], 200);
        }
    }
    public function Upcoming_candidate(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;
    
        $search_fill = $request->input('search_fill', '');
        $filter_on = $request->input('filter_on', false);
        $search_cust_name = $request->input('search_cust_name', '');
        $search_cust_mobile = $request->input('search_cust_mobile', '');
        $search_cust_id = $request->input('search_cust_id', '');
        $search_course = $request->input('search_course', '');
        $search_course_type = $request->input('search_course_type', '');
        $dt_fill_issue_rpt = $request->input('dt_fill_issue_rpt', '');
        $dt_fill_date_type = $request->input('dt_fill_date_type', '');
        $search_start_date = $request->input('search_start_date', '');
        $search_end_date = $request->input('search_end_date', '');
    
        $branch_id = $request->user()->branch_id;
        $course_type_ids = $request->course_type_id;  // This will now be an array
        $merged_students = [];
    
        $tesbo_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.customer_id','za_customer.cus_name','za_course.course_name','za_customer.cus_pic', 'za_customer.cus_gender','za_customer.doj', 'za_customer.cus_mobile', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno','za_course.course_type_id','za_training.batch_id','za_training.course_id','za_training.payment_id','za_customer.branch_id')
            ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', 2)
            // ->where('za_course.course_type_id', 2) 
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();
        
        // Merge TESBO results
        foreach ($tesbo_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'customer_id' => $student->customer_id,
                    'branch_id' => $student->branch_id,
                    'cus_doj' => $student->doj,
                    'cus_gender' => $student->cus_gender,
                    'cus_pic' => $student->cus_pic??'',
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => [],
                    'course_name' => [],
                    'batch_id' => [],
                    'payment_id' => [],
                    'course_id' => [],
                    'training_sno' => []
                ];
            }
        
            // Add to merged array
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
            $merged_students[$student->sno]['course_name'][] = $student->course_name;
            $merged_students[$student->sno]['batch_id'][] = $student->batch_id;
            if (!in_array($student->payment_id, $merged_students[$student->sno]['payment_id'])) {
                $merged_students[$student->sno]['payment_id'][] = $student->payment_id;
            }
            $merged_students[$student->sno]['training_sno'][] = $student->training_sno;
            $merged_students[$student->sno]['course_id'][] = $student->course_id;
        }
        
        // Second: Query for other course types (excluding TESBO)
        $other_course_students = DB::table('za_customer')
            ->select('za_customer.sno', 'za_customer.cus_name','za_course.course_name','za_customer.customer_id', 'za_customer.cus_pic', 'za_customer.cus_gender', 'za_customer.cus_mobile','za_customer.doj', 'za_training.payment_id', 'za_training.tesbo_check', 'za_course_type.course_type_name', 'za_training.sno as training_sno','za_training.batch_id','za_training.payment_id','za_training.course_id','za_customer.branch_id')
            ->where('za_customer.status', 0)
            ->join('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
            ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->where('za_training.status', '!=', 2)
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_training.tesbo_check', '!=', 2) // Exclude TESBO courses
            ->where('za_customer.is_placement', 1) // Other course types
            ->whereNot('za_course.course_type_id', 2) // Other course types
            ->orderBy('za_customer.cus_name', 'asc')
            ->get();

        // Merge other course type results
        foreach ($other_course_students as $student) {
            // Ensure merging by sno (unique student ID)
            if (!isset($merged_students[$student->sno])) {
                $merged_students[$student->sno] = [
                    'sno' => $student->sno,
                    'cus_name' => $student->cus_name,
                    'customer_id' => $student->customer_id,
                    'branch_id' => $student->branch_id,
                    'cus_pic' => $student->cus_pic??'',
                    'cus_doj' => $student->doj,
                    'cus_gender' => $student->cus_gender,
                    'cus_mobile' => $student->cus_mobile,
                    'payment_id' => $student->payment_id,
                    'tesbo_check' => $student->tesbo_check,
                    'course_type_name' => [],
                    'course_name' => [],
                    'batch_id' => [],
                    'payment_id' => [],
                    'course_id' => [],
                    'training_sno' => [],
                ];
            }
        
            // Add the course type name
            $merged_students[$student->sno]['course_type_name'][] = $student->course_type_name;
            $merged_students[$student->sno]['course_name'][] = $student->course_name;
            $merged_students[$student->sno]['batch_id'][] = $student->batch_id;
            if (!in_array($student->payment_id, $merged_students[$student->sno]['payment_id'])) {
                $merged_students[$student->sno]['payment_id'][] = $student->payment_id;
            }
            
            $merged_students[$student->sno]['training_sno'][] = $student->training_sno;
            $merged_students[$student->sno]['course_id'][] = $student->course_id;
        }
        
        // Final formatting: Combine course types and remove duplicates
        $final_students = [];
        foreach ($merged_students as $student) {
            $student['course_type_name'] = implode(', ', array_unique($student['course_type_name']));
            $student['course_name'] = implode(', ', array_unique($student['course_name']));
            $final_students[] = (object) $student; // Cast each student array to object
        }
       
        // $grouped_candidates = $candidate_list->getCollection()->groupBy('payment_id');

        foreach($final_students as $student){
            $interview=DB::table('za_placement_interview')
                ->select('za_jobs.*','za_placement_interview.sno as interview_id','za_placement_company.company_name','za_placement_interview.status','za_placement_interview.job_salary','za_placement_interview.job_position', 'za_customer.cus_name','za_customer.cus_gender','za_customer.cus_mobile','za_customer.doj','za_customer.cus_email_id','za_customer.cus_pic','za_customer.customer_id','za_placement_interview.interview_checklist_status')
                ->join('za_jobs','za_jobs.sno','=','za_placement_interview.job_id')
                ->join('za_placement_company','za_placement_company.sno', '=', 'za_jobs.company_id')
                ->join('za_customer','za_customer.sno','=','za_placement_interview.customer_id')
                ->where('za_customer.status', '!=', 2)
                ->where('za_placement_interview.customer_id', $student->sno)
                ->orderBy('za_jobs.interview_date', 'desc')
                ->get();

                $trainingIds = DB::table('za_training')
                ->where('za_training.status', '!=', 2)
                ->where('za_training.customer_id', $student->sno)
                ->pluck('payment_id')
                ->toArray();
            
            $student->inteview_count= $interview ? count($interview) :0;
            if (!$interview->isEmpty()) {
                // Filter for pending interviews (status == 0)
                $next_interview = $interview->first(function ($int) {
                    return $int->status == 0;
                });
        
                if ($next_interview) {
                    $student->next_interview_date = $next_interview->interview_date;
                    $student->next_interview_company_name = $next_interview->company_name;
                } else {
                    $student->next_interview_date = null;
                    $student->next_interview_company_name = null;
                }
            } else {
                $student->next_interview_date = null;
                $student->next_interview_company_name = null;
            }

      
           $student->paid_status = 0;
            $courseProgress=0;
            $paymentPercentage =0;
            foreach ($student->payment_id as $index => $payId) {
                
                $paymentAmount = DB::table('za_payment')
                    ->where('za_payment.payment_id', $payId)
                    ->sum('za_payment.paidAmount');
                
                $paymentDetails = DB::table('za_training')
                    ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
                    ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_training.payment_id', $payId) 
                    ->where('za_training.status', '!=', 2)
                    ->where('za_payment.status', '!=', 3)
                    ->groupBy('za_payment.total_amount')
                    ->first();
          
            
                if ($paymentDetails && $paymentDetails->total_amount > 0) {
                    $paymentPercentage = ($paymentAmount / $paymentDetails->total_amount) * 100;
                    
                    if ($paymentPercentage >= 100) {
                        $student->paid_status = 1; // Mark as fully paid
                        break; // No need to check other payment IDs
                    }
                }
            }

            foreach ($student->batch_id as $index => $batch_id) {
                // Initialize course progress percentage
                $courseProgress = 0;
                $helper = new \App\Helpers\Helpers();
                $courseProgress    = $helper->get_course_percentage($batch_id, $student->sno);
            }

            $student->coursePrecentage=$courseProgress;
            $student->paymentPercentage=$paymentPercentage;
        }

        $final_students = array_filter($final_students, function ($student) {
            return $student->paid_status == 0;
        });
        
        // Collect input filters
        $filters = $request->only([
            'search_cust_name',
            'search_cust_mobile',
            'search_cust_id',
            'search_course',
            'search_course_type',
            'start_date',
            'end_date'
        ]);

        // Apply filters
        $filtered = array_filter($final_students, function ($final_student) use ($filters) {
            
            $final_student = !empty($final_student) && !is_array($final_student) ? json_encode($final_student) : "";
            $final_student = !empty($final_student) && !is_array($final_student) ? json_decode($final_student,true) : [];

            $final_student['course_type_name'] = isset($final_student['course_type_name']) && !empty($final_student['course_type_name']) ? (is_array($final_student['course_type_name']) ? $final_student['course_type_name'] : array_map('trim', explode(',', $final_student['course_type_name']))) : [];

            $final_student['course_name'] = isset($final_student['course_name']) && !empty($final_student['course_name']) ? (is_array($final_student['course_name']) ? $final_student['course_name'] : array_map('trim', explode(',', $final_student['course_name']))) : [];

            if (!empty($filters['search_cust_name']) && stripos($final_student['cus_name'], $filters['search_cust_name']) === false) {
                return false;
            }

            if (!empty($filters['search_cust_mobile']) &&
                stripos($final_student['cus_mobile'], $filters['search_cust_mobile']) === false) {
                return false;
            }

            if (!empty($filters['search_cust_id']) &&
                stripos($final_student['customer_id'], $filters['search_cust_id']) === false) {
                return false;
            }

            if (!isset($final_student['course_type_name']) || (!empty($filters['search_course_type']) && !in_array($filters['search_course_type'], (array) $final_student['course_type_name']))) {
                return false;
            }

            if (!isset($final_student['course_name']) || (!empty($filters['search_course']) && !in_array($filters['search_course'], (array) $final_student['course_name']))) {
                return false;
            }

            return $final_student;
        });
        
        // return $filtered;
        // Re-index filtered array
        $final_students = array_values($filtered);

        
        foreach ($final_students as $key => $item) {

                $carouselDetails = [];
        
            // Get payment details and course info
            $paymentDetailss = DB::table('za_payment')
                ->select('za_payment.status', 'za_payment.nextPayDate')
                ->where('za_payment.customer_id', $item->sno)
                ->where('za_payment.status', 0)
                ->get();
        
            $paymentget = DB::table('za_training')
                ->where('customer_id', $item->sno)
                ->whereIn('status', [0, 2])
                ->get();
        
            $courseIds = $paymentget;

            $education_details_count = DB::table('za_customer_education')->select('sno')->where('branch_id', $item->branch_id)
            ->where('customer_id', '=', $item->sno)
            ->where('status', '=', 0)
            ->count();
        
            foreach ($courseIds as $index => $courseId) {
        
                // Retrieve course details
                $course = DB::table('za_course')
                    ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                    ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
                    ->where('za_course.sno', $courseId->course_id)
                    ->first();
        
                // Retrieve batch details
                $batch = DB::table('za_batch')
                    ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                    ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                    ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
                    ->where('za_batch.sno', $courseId->batch_id)
                    ->first();
        
                // Retrieve payment details
                $paymentDetails = DB::table('za_training')
                    ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount, MAX(za_training.sno) as sno')
                    ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
                    ->where('za_training.customer_id', $item->sno)
                    ->where('za_training.course_id', $courseId->course_id)
                    ->where('za_training.status', '!=', 3)
                    ->where('za_payment.status', '!=', 3)
                    ->groupBy('za_payment.total_amount')
                    ->first();
        
                $paymentPercentage = 0;
                if ($paymentDetails && $paymentDetails->total_amount > 0) {
                    $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
                    if($paymentPercentage>=100){
                        
                        $paymentPercentage = 100;
                        
                    }
                }
        
                // Check if attendance exists for the specific batch and customer
                $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
                    ->where('batch_id', $courseId->batch_id)
                    ->where('attendance', 'P')
                    ->get();
        
                // Initialize course progress percentage
                $courseProgress = 0;
                $topicCount = 0;
                $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
                    ->count();
                    
                    $helper = new \App\Helpers\Helpers();
                    $courseProgress    = $helper->get_course_percentage($courseId->sno, $item->sno);   
                // batch count by course id
                $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
                
                
                //*************************************************************************************
                
                $currentDate = date('Y-m-d');
        
                
                $start_date = $batch->start_date ?? null;
                $end_date  = $batch->end_date ?? null;
        
                // Add course and batch details to the array
                $carouselDetails[] = [
                    'course_sno' => $courseId->course_id ?? null,
                    'course_mode_id' => $courseId->course_mode_id ?? null,
                    'online_course_fee' => $course->online_fee ?? null,
                    'batch_sno' => $courseId->batch_id ?? 0,
                    'batch_count' => $batch_count ?? 0,
                    'traning_sno' => $courseId->sno ?? null,
                    'traning_status' => $courseId->status ?? null,
                    'course_name' => $course->course_name ?? null,
                    'course_type_name' => $course->course_type_name ?? null,
                    'batch_name' => $batch->batch_name ?? null,
                    'start_date' => $batch->start_date ?? null,
                    'end_date' => $batch->end_date ?? null,
                    'slot_name' => $batch->slot_name ?? null,
                    'staff_name' => $batch->staff_name ?? null,
                    'payment_percentage' => $paymentPercentage,
                    'course_progress' => $courseProgress,
                ];
            }
            $item->carousel_details = $carouselDetails;
            $item->education_details_count = $education_details_count ?? 0;
        }     
       
        return view('content.placements_events.manage_candidate.upcoming_candidate', [
            'candidate_list' => $final_students,
            'pageConfigs' => ['myLayout' => 'default'],
            'perpage'=> $perpage,
            'search_fill'=>$search_fill,
            'filter_on'=>$filter_on,
            'search_cust_name' => $search_cust_name,
            'search_cust_mobile' => $search_cust_mobile,
            'search_cust_id' => $search_cust_id,
            'search_course' => $search_course,
            'search_course_type' => $search_course_type,
            'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
            'dt_fill_date_type' => $dt_fill_date_type,
            'search_start_date' => $search_start_date,
            'search_end_date' => $search_end_date,
        ]);
    }
}
