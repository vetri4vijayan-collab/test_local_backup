<?php

namespace App\Http\Controllers\placements_events;

use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\PlacementStudentExports;
use Illuminate\Support\Facades\DB;
use App\Models\HrDirectoryModel;
use App\Models\CourseTypeModel;
use App\Models\InterviewCheckListModel;
use App\Models\PlacementFollowupModel;
use App\Models\JobDirectoryModel;
use Illuminate\Http\Request;
use App\Models\JobDirectoryJobModel;
use App\Models\CustomerPlacementModel;

use Maatwebsite\Excel\Facades\Excel;

class PlacementsTraining extends Controller
{
    public function index()
    {
        $placement_list = JobDirectoryModel::select(
            'za_job_directory.sno as job_dir_sno',
            'za_job_directory.job_directory_id',
            'za_job_directory.interview_to',
            'za_job_directory.job_company_id',
            'za_job_directory.duration',
            'za_job_directory.interview_date',
            'za_hr_directory.company_name',
            'za_hr_directory.industry_type_id',
            'za_hr_directory.address',
            'za_hr_directory.location_url',
            'za_hr_directory.hr_contact_name',
            'za_hr_directory.hr_contact_phone',
            'za_hr_directory.country',
            'za_hr_directory.state',
            'za_hr_directory.city',
            'za_countries.name as country_name', // Alias for country name
            'za_states.name as state_name',      // Alias for state name
            'za_cities.name as city_name',       // Alias for city name
            'za_industry_type.industry_type_name',
            'za_job_directorys_job.sno AS job_sno',
            'za_job_directorys_job.company_id',
            'za_job_directorys_job.job_name_id',
            'za_job_directorys_job.salary',
            'za_job_directorys_job.interview_type_id',
            'za_job_directorys_job.vacancy_count',
            'za_job_directorys_job.job_interview_date',
            'za_job_directorys_job.job_link',
            'za_job_directorys_job.job_description',
            'za_industry_job_name.job_name'
        )
            ->join('za_hr_directory', 'za_job_directory.job_company_id', '=', 'za_hr_directory.sno')
            ->join('za_industry_type', 'za_hr_directory.industry_type_id', '=', 'za_industry_type.sno')
            ->join('za_job_directorys_job', 'za_job_directory.sno', '=', 'za_job_directorys_job.job_dir_id')
            ->join('za_industry_job_name', 'za_job_directorys_job.job_name_id', '=', 'za_industry_job_name.sno')
            ->join('za_countries', 'za_hr_directory.country', '=', 'za_countries.id')
            ->join('za_states', 'za_hr_directory.state', '=', 'za_states.id')
            ->join('za_cities', 'za_hr_directory.city', '=', 'za_cities.id')
            ->where('za_job_directory.status', '!=', 2)
            ->groupBy(
                'za_job_directory.sno',
                'za_job_directory.job_directory_id',
                'za_job_directory.interview_to',
                'za_job_directory.job_company_id',
                'za_job_directory.duration',
                'za_job_directory.interview_date',
                'za_hr_directory.company_name',
                'za_hr_directory.industry_type_id',
                'za_hr_directory.address',
                'za_hr_directory.location_url',
                'za_hr_directory.hr_contact_name',
                'za_hr_directory.hr_contact_phone',
                'za_hr_directory.country',
                'za_hr_directory.state',
                'za_hr_directory.city',
                'za_countries.name',  // Grouping by country name
                'za_states.name',     // Grouping by state name
                'za_cities.name',
                'za_industry_type.industry_type_name',
                'za_job_directorys_job.sno',
                'za_job_directorys_job.company_id',
                'za_job_directorys_job.job_name_id',
                'za_job_directorys_job.salary',
                'za_job_directorys_job.interview_type_id',
                'za_job_directorys_job.vacancy_count',
                'za_job_directorys_job.job_interview_date',
                'za_job_directorys_job.job_link',
                'za_job_directorys_job.job_description',
                'za_industry_job_name.job_name'
            )
            ->get();
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        // return $lastDayOfMonth;
        $current_month_job_interested_count = CustomerPlacementModel::whereBetween('za_customer_placement.created_at', [$firstDayOfMonth, $lastDayOfMonth])
            ->count();
        $total_job_interested_count = CustomerPlacementModel::count();

        // return $current_month_job_interested_count;


        // return   $placement_list;
        return view('content.placements_events.placements_training.list', [
            'placement_list' => $placement_list,
            'current_month_count' => $current_month_job_interested_count,
            'total_job_interested_count' => $total_job_interested_count,
            // 'country_fill' => '',
            // 'state_fill' => '',
            // 'city_fill' => '',
            // 'pincode' => '',

        ])->with('filter_on', false);
    }


    public function Placement_checklist(Request $request)
    {

        $id = $request->id;
        // return $id;
        // First query to fetch customer placements
        $placement = CustomerPlacementModel::select(
            'za_customer_placement.*',
            'za_hr_directory.company_name',
            'za_hr_directory.address',
            'za_hr_directory.location_url',
            'za_industry_job_name.job_name',
            'za_job_directorys_job.job_interview_date',
            'za_job_directorys_job.job_description',
            'za_job_directorys_job.interivew_rounds as requirement'
        )
            ->join('za_industry_job_name', 'za_customer_placement.job_name_id', '=', 'za_industry_job_name.sno')
            ->join('za_job_directorys_job', 'za_customer_placement.job_name_id', '=', 'za_job_directorys_job.job_name_id')
            ->join('za_hr_directory', 'za_customer_placement.company_id', '=', 'za_hr_directory.sno')
            ->where('za_customer_placement.job_name_id',  $id)
            ->get();
        // return  $placement;


        $interviewRounds = $placement->pluck('requirement')->flatMap(function ($round) {

            $round = str_replace("'", '"', $round);
            $decoded = json_decode($round, true);

            // Check if decoding was successful
            return is_array($decoded) ? $decoded : [];
        })->toArray();

        // return $interviewRounds;


        $checklistNames = [];
        if (!empty($interviewRounds)) {
            $checklistNames = DB::table('za_interview_checklist')
                ->whereIn('sno', $interviewRounds) // Filter by the provided `sno` values
                ->orderBy('za_interview_checklist.sno', 'desc') // Order results by `sno` in descending order
                ->select('interview_checklist_name AS name', 'za_interview_checklist.sno as sno') // Select specific columns
                ->get() // Execute the query and get the results
                ->toArray(); // Convert the result to an array
        }



        $customer_ids = $placement->pluck('customer_id')->toArray();
        // return $customer_ids;
        $customers = [];

        if (!empty($customer_ids)) {
            // Use whereIn to fetch all customers at once
            $customers = CustomerModel::select(
                'za_customer.sno',
                'za_customer.customer_id',
                'za_customer.cus_pic',
                'za_customer.cus_name',
                'za_customer.cus_mobile',
                'za_customer.cus_email_id',
                'za_customer.cus_gender'
            )
                ->whereIn('za_customer.sno', $customer_ids) // Use whereIn for multiple IDs
                ->get(); // Use get() to retrieve all matching records

            // Convert the result to an array if needed
            $customers = $customers->toArray();
        }





        // return   $customers;
        // return  $checklistNames;
        // return   $customer_list;
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $placement,
            'checklist' => $checklistNames,
            'customer_list' => $customers,
        ], 200);
    }

    public function JobtableGet(Request $request)
    {
        $id = $request->id;

        // Get placement data from the database
        $placement = CustomerPlacementModel::select(
            'za_customer_placement.*',
            'za_hr_directory.company_name',
            'za_hr_directory.address',
            'za_hr_directory.location_url',
            'za_industry_job_name.job_name',
            'za_job_directorys_job.job_interview_date',
            'za_job_directorys_job.job_description',
            'za_job_directorys_job.interivew_rounds as requirement'
        )
            ->join('za_industry_job_name', 'za_customer_placement.job_name_id', '=', 'za_industry_job_name.sno')
            ->join('za_job_directorys_job', 'za_customer_placement.job_name_id', '=', 'za_job_directorys_job.job_name_id')
            ->join('za_hr_directory', 'za_customer_placement.company_id', '=', 'za_hr_directory.sno')
            ->where('za_customer_placement.job_name_id',  $id)
            ->get();
        // dd($placement);

        // Decode interview_round (requirement) into an array
        $interviewRounds = $placement->pluck('requirement')->flatMap(function ($round) {
            $round = str_replace("'", '"', $round); // Fix any quotes if needed
            $decoded = json_decode($round, true);

            return is_array($decoded) ? $decoded : [];
        })->toArray();
        // return $interviewRounds;

        // Get checklist names
        $checklistNames = [];
        if (!empty($interviewRounds)) {
            $checklistNames = DB::table('za_interview_checklist')
                ->whereIn('sno', $interviewRounds) // Filter by the provided `sno` values
                ->orderBy('za_interview_checklist.sno', 'desc') // Order results by `sno` in descending order
                ->select('interview_checklist_name AS name', 'za_interview_checklist.sno as sno') // Select specific columns
                ->get() // Execute the query and get the results
                ->toArray(); // Convert the result to an array
        }
        // return $checklistNames;

        // Get customer IDs
        $customer_ids = $placement->pluck('customer_id')->toArray();
        // dd($customer_ids);
        $customers = [];

        if (!empty($customer_ids)) {
            // Fetch customers using whereIn
            $customers = CustomerModel::select(
                'za_customer.sno',
                'za_customer.customer_id as cus_id',
                'za_customer.cus_pic',
                'za_customer.cus_name',
                'za_customer.cus_mobile',
                'za_customer.cus_email_id',
                'za_customer.cus_gender',
                'za_customer_placement.*'
            )
                ->join('za_customer_placement', 'za_customer.sno', '=', 'za_customer_placement.customer_id')
                ->whereIn('za_customer.sno', $customer_ids)
                ->get()
                ->toArray(); // Convert the result to an array
        }
        // return $customers;

        // Table Header
        $tableHeader = '
        <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                <th class="min-w-100px">Students</th>
                <th class="min-w-100px">Mobile/Gmail</th>';

        foreach ($checklistNames as $checklist) {
            $tableHeader .= '
                <th class="min-w-50px text-center">
                    <label>' . htmlspecialchars($checklist->name) . '</label>
                </th>';
        }

        $tableHeader .= '
            <th class="min-w-50px text-center">
                <label>Selected</label>
            </th>
            <th class="min-w-150px"><label>Salary LPA</label></th>
            <th class="min-w-150px"><label>DOJ</label></th>
        </tr>
        </thead>';
        $tableBody = '<tbody>';

        foreach ($customers as $s_list) {
            $tableBody .= '<tr>';
            $tableBody .= '
                            <td>
                                <input type="hidden" name="customer_id[]" value="' . $s_list['customer_id'] . '">
                                <div class="d-flex align-items-center justify-center">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="avatar">
                                            <!-- Image is dynamic here -->
                                            <img src="' . ($s_list['cus_pic'] ? asset('staff_images/' . $s_list['cus_pic']) : asset('assets/eapl_images/user_1.png')) . '" alt="user image" class="w-px-40 h-auto rounded-circle">
                                        </div>
                                    </div>
                                    <div class="ms-2 d-block">
                                        <label class="d-flex align-items-center">
                                            <span class="fs-7 fw-semibold text-truncate max-w-80px me-2">' . $s_list['cus_name'] . ' 
                                                ' . ($s_list['cus_gender'] == 2 ? '<i class="mdi mdi-face-woman text-danger"></i>' : '<i class="mdi mdi-face-man text-danger"></i>') . '
                                            </span>
                                        </label>
                                        <span class="fs-8">' . $s_list['cus_id'] . '</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-center justify-center">
                                    <div class="ms-2 d-block">
                                        <label class="d-flex align-items-center">
                                            <span class="fs-7 fw-semibold text-truncate max-w-80px me-2">' . $s_list['cus_mobile'] . '</span>
                                        </label>
                                        <span class="fs-8">' . $s_list['cus_email_id'] . '</span>
                                    </div>
                                </div>
                            </td>';


            // Decode the interview_round JSON string into an array if it's a string
            if (is_string($s_list['interview_round'])) {
                $s_list['interview_round'] = json_decode($s_list['interview_round'], true);
            }

            foreach ($checklistNames as $checklist) {
                // Initialize the checkbox as unchecked
                $checked = '';

                // Loop through interview_round to check if the checklist sno exists and if it's selected
                foreach ($s_list['interview_round'] as $round) {
                    // Ensure the array keys and values match as expected
                    if ($checklist->sno == $round['sno'] && $round['selected'] == '1') {
                        $checked = 'checked';
                        break; // Exit the loop early if a match is found
                    }
                }

                // Append the table row with the checkbox
                $tableBody .= '
                <td>
                    
                    <label>
                        <input class="form-check-input fs-6 eligible row_chk" id="checklist' . $checklist->sno . '_' . $s_list['customer_id'] . '" 
                        name="checklist[' . $s_list['customer_id'] . '][' . $checklist->sno . ']" type="checkbox" value="1" ' . $checked . ' />
                    </label>
                </td>';
            }




            // Additional fields
            $tableBody .= '
                <td class="text-center">
                    <label>
                        <input class="form-check-input fs-6 eligible" id="selected' . $s_list['customer_id'] . '" name="selected[' . $s_list['customer_id'] . ']" type="checkbox" value="1" ' . ($s_list['selected'] == 1 ? 'checked' : '') . ' />
                    </label>
                </td>
                <td>
                    <label>
                    <input type="text" class="form-control" name="salary[' . $s_list['customer_id'] . ']" id="salary' . $s_list['customer_id'] . '" placeholder="Enter Salary" value="' . htmlspecialchars($s_list['salary']) . '"  maxlength="3" oninput="this.value = this.value.replace(/[^0-9]/g, "").replace(/(\\..*)\\./g, "$1");"  />
                </label>
                </td>
                <td>
                    <label>
                        <input type="date" class="form-control" name="doj[' . $s_list['customer_id'] . ']" id="doj' . $s_list['customer_id'] . '" placeholder="Select Date" value="' . htmlspecialchars($s_list['doj']) . '"  />
                    </label>
                </td>';

            $tableBody .= '</tr>';
        }
        $tableBody .= '</tbody>';



        // Return the full table
        $tableHtml = $tableHeader . $tableBody;

        // Return the HTML table as JSON response
        return response()->json(['data' => $tableHtml]);
    }

    public function Placement_update(Request $request)
    {
        // return $request;
        // Fetch customer IDs from the request
        $customer_ids = $request->customer_id;
        // return $customer_ids;

        if ($customer_ids) {

            $updated = false;  // Flag to track if any placement is updated

            foreach ($customer_ids as $i => $id) {
                // return $id;

                $interview_round = $request->checklist[$id] ?? null;
                $salary = $request->salary[$id] ?? null;
                $selected = $request->selected[$id] ?? null; // Use null instead of empty string
                $doj = $request->doj[$id] ?? null;

                // Prepare interview rounds in the desired format
                $result = [];
                // dd($interview_round);
                if ($interview_round) {
                    foreach ($interview_round as $key => $value) {
                        $result[] = [
                            'sno' => $key,
                            'selected' => $value
                        ];
                    }
                }

                $interview_round = json_encode($result);
                // dd($interview_round);

                // Find the existing placement record for the customer
                $placement = CustomerPlacementModel::where('customer_id', $id)->first();
                // return $placement;

                if ($placement) {
                    // Update the placement details
                    $placement->salary = $salary;
                    $placement->doj = $doj ? date('Y-m-d', strtotime($doj)) : null;
                    $placement->interview_round = $interview_round;

                    // Ensure selected is not an empty string before saving

                    $placement->selected = !is_null($selected) ? $selected : null; // Avoid empty string
                    if ($selected) {
                        $status_change = CustomerModel::where('sno', $customer_ids)->first();
                        $status_change->placement_status = 1;

                        $status_change->save();
                        // dd($status_change);
                    }

                    $placement->save();

                    $updated = true;  // Mark as updated
                }
            }

            // Flash message based on whether any placement was updated
            if ($updated) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Placement updated successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update any placements!'
                ]);
            }
        } else {
            // Flash message if no customer IDs were provided
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'No customer IDs provided!'
            ]);
        }

        // Redirect back to placements_training
        return redirect('placements/placements_training');
    }
}
