<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class MenuController extends Controller
{
    public function users_add()
    {
        // Path to the JSON file
        $path = resource_path('menu/verticalMenu.json');

        // Read the file content
        $json = File::get($path);

        // Decode JSON to array
        $menu = json_decode($json, true);

        // Pass the menu data to the view
        return view('content.user_management.manage_users.add', compact('menu'));
    }
}