<?php

namespace App\Http\Controllers\hr_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TrainingDatabaseModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\CorporateIndustriesModel;


class TrainingDatabase extends Controller
{
  protected static $temp = [];

  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $cus_fill = $request->input('cus_fill', '');
    // $state_fill = $request->input('state_fill', []);
    // $city_fill = $request->input('city_fill', []);
    $pageConfigs = ['myLayout' => 'default'];

    $filter_on = $request->input('filter_on', '0');
    $search_work_type = $request->input('search_work_type', '');
    $area_fill = $request->input('area_fill', '');
    $cost_order_fill = $request->input('cost_order_fill', '');
    $perferred_time_fill = $request->input('perferred_time_fill', []);

    $query = TrainingDatabaseModel::where('status', 0)
        ->where('branch_id', $branch_id);

    if (!empty($cus_fill)) {
        $query->where(function ($q) use ($cus_fill) {
            $q->where('trainer_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('qualification', 'LIKE', "%{$cus_fill}%");
        });
    }

    if (!empty($area_fill)) {
      $query->where(function ($q) use ($area_fill) {
        $q->where('area', 'LIKE', "%{$area_fill}%");
      });
    }

    if (!empty($perferred_time_fill)) {
      $query->whereJsonContains('prefer_time', $perferred_time_fill);
    }
    
    
    $state_fill = $request->input('state_fill', null);
    $city_fill  = $request->input('city_fill', null);

    if ($state_fill !== null) {
      $query->whereJsonContains('state_id', (string) $state_fill);
    }

    if ($city_fill !== null) {
      $query->whereJsonContains('city_id', (string) $city_fill);
    }

    $domain_excellence_fill = $request->input('domain_excellence_fill', '[]');
    $domain_excellence_fill = json_decode($domain_excellence_fill, true) ?? [];
    $domain_values = array_column($domain_excellence_fill, 'value');

    if (!empty($domain_values)) {
      foreach ($domain_values as $val) {
        $query->where('domain_excellence', 'LIKE', "%{$val}%");
      }
    }
    
    if (!empty($cost_order_fill)) {
      if($cost_order_fill == 1){
        $query->orderBy('cost', 'asc');
      }else{
        $query->orderBy('cost', 'desc');
      }
    }else{
      $query->orderByDesc('sno');
    }

    // Clone query to avoid pagination conflict
    $statsQuery = clone $query;

    // Total trainers count
    $total_training_count = $statsQuery->count();

    // Total cost
    $total_cost = (clone $query)->sum('cost');

    // Min & Max experience (JSON based)
    $min_experience = null;
    $max_experience = null;

    $experienceRecords = (clone $query)->get(['experience_details']);

    foreach ($experienceRecords as $record) {
        if (empty($record->experience_details)) continue;

        $experienceDetails = json_decode($record->experience_details, true);
        if (!is_array($experienceDetails)) continue;

        foreach ($experienceDetails as $expBlock) {
            if (!is_array($expBlock)) continue;

            foreach ($expBlock as $exp) {
                if (!isset($exp['experience_yrs'])) continue;

                $yrs = (float) $exp['experience_yrs'];

                if ($min_experience === null || $yrs < $min_experience) {
                    $min_experience = $yrs;
                }

                if ($max_experience === null || $yrs > $max_experience) {
                    $max_experience = $yrs;
                }
            }
        }
    }
    
    $trainingdatabase = $query->paginate($perpage);

    foreach ($trainingdatabase as $record) {
        $decoded = json_decode($record->domain_excellence, true);
        $experience_details = isset($record->experience_details) && !empty($record->experience_details) ? json_decode($record->experience_details) : [];
        $prefer_time_details = isset($record->prefer_time) && !empty($record->prefer_time) ? json_decode($record->prefer_time,true) : [];
        $experience_count = is_array($experience_details) ? count($experience_details) : 0;
        $record->domain_excellence = is_array($decoded) ? $decoded : [];
        $record->prefer_time = $prefer_time_details ?? [];
        $record->experience_count = $experience_count;

        $state_ids = isset($record->state_id) && !empty($record->state_id) ? json_decode($record->state_id,true) : [];
        $city_ids = isset($record->city_id) && !empty($record->city_id) ? json_decode($record->city_id,true) : [];
        $industries = isset($record->industries) && !empty($record->industries) ? json_decode($record->industries,true) : [];

        $record->state_names = collect($state_ids)->map(fn ($state_id) => $this->getStateName($state_id) ?? null)->filter()->values()->toArray();
        $record->city_names = collect($city_ids)->map(fn ($city_id) => $this->getCityName($city_id) ?? null)->filter()->values()->toArray();
        $record->industries_names = collect($industries)->map(fn ($industry_id) => $this->getIndustriesName($industry_id) ?? null)->filter()->values()->toArray();
    }

    return view('content.hr_management.training_database.training_database_list', [
        'trainingdatabase' => $trainingdatabase,
        'pageConfigs' => $pageConfigs,
        'perpage' => $perpage,
        'filter_on' => $filter_on,
        'search_work_type' => $search_work_type,
        'area_fill' => $area_fill,
        'cost_order_fill' => $cost_order_fill,
        'perferred_time_fill' => $perferred_time_fill,
        'domain_excellence_fill' => $domain_excellence_fill,
        'state_fill' => $state_fill,
        'city_fill' => $city_fill,
        'cus_fill' =>$cus_fill,
        'total_training_count' => $total_training_count ?? 0,
        'min_experience' => $min_experience ?? 0,
        'max_experience' => $max_experience ?? 0,
        'total_cost' => $total_cost ?? 0
    ]);
  }

  public function store(Request $request)
  {
    $state_id = isset($request->state_id) && !empty($request->state_id) && !is_array($request->state_id) ? explode(',',$request->state_id) : ($request->state_id ?? []);
    $city_id = isset($request->city_id) && !empty($request->city_id) && !is_array($request->city_id) ? explode(',',$request->city_id) : ($request->city_id ?? []);
    $industries_ids = isset($request->industries_ids) && !empty($request->industries_ids) && !is_array($request->industries_ids) ? explode(',',$request->industries_ids) : ($request->industries_ids ?? []);

  
    $timestamp = time();

    $staffImagePath = '';
    if ($request->hasFile('staff_image')) {
        $staffImagePath = 'staff_' . $timestamp . '.' . $request->file('staff_image')->extension();
        $request->file('staff_image')->move(public_path('trainer_staff_images'), $staffImagePath);
    }

    $resumePath = '';
    if ($request->hasFile('resume')) {
        $resumePath = 'resume_' . $timestamp . '.' . $request->file('resume')->extension();
        $request->file('resume')->move(public_path('trainer_resume_uploads'), $resumePath);
    }

    $certificatePath = '';
    if ($request->hasFile('certificate')) {
        $certificatePath = 'certificate_' . $timestamp . '.' . $request->file('certificate')->extension();
        $request->file('certificate')->move(public_path('trainer_certificate_uploads'), $certificatePath);
    }
    $domainExcellence = json_decode($request->input('domain_excellence'), true);

    $user_details = $request->exp_details;
    $slot_type = !empty($request->slot_type) ? explode(',',$request->slot_type) : [1];

    // $domainExcellence2 = json_decode($domainExcellence, true);
    $training = new TrainingDatabaseModel();
    $training->trainer_name = $request->name;
    $training->mobile_no = $request->mobile_no;
    $training->email_id = $request->email_id;
    $training->qualification = $request->qualification;
    $training->industries = json_encode($industries_ids);
    // $training->work_type = (int)$request->work_type ?? 1;

    $indexed_options = [];
    foreach ($user_details as $index => $value) {
        if ($value !== '') {
            // Indexing options starting at 1, as in your second example
            $indexed_options[] = [(string)((int)$index + 1) => $value];
        }
    }
    $deliverablesJson = json_encode($indexed_options);

    $training->cost = $request->pay_cost ?? 0;
    $training->cost_session_type = $request->session_type ?? 1;
    $training->prefer_time = json_encode($slot_type);
    $training->is_interested_travel = $request->is_travel_interest ?? 2;
    // $training->area = $request->area_text ?? NULL;
    $training->state_id = json_encode($state_id);
    $training->city_id = json_encode($city_id);
    $training->experience_details = $deliverablesJson;
    $training->domain_excellence = $request->domain_excellence;
    $training->training_staff_image = $staffImagePath;
    $training->linkedin_url = $request->linkedin_url ?? NULL;
    $training->resume_upload = $resumePath;
    $training->certificate_upload = $certificatePath;
    $training->branch_id  = $request->user()->branch_id;
    $training->created_by = $request->user()->user_id;
    $training->updated_by = $request->user()->user_id;
    $training->save();

    return response()->json(['success' => true, 'message' => 'Trainer Database saved']);

  }

  public function Edit($id)
  {
    $TrainingDatabase = TrainingDatabaseModel::where('sno', $id)
    ->where('status', '!=', 2)
    ->first();

    if ($TrainingDatabase) {

      $CorporateListOptions = isset($TrainingDatabase->experience_details) && !empty($TrainingDatabase->experience_details) ? json_decode($TrainingDatabase->experience_details, true) : [];
      $prefer_time = isset($TrainingDatabase->prefer_time) && !empty($TrainingDatabase->prefer_time) ? json_decode($TrainingDatabase->prefer_time, true) : [];
      $industries_ids = isset($TrainingDatabase->industries) && !empty($TrainingDatabase->industries) ? json_decode($TrainingDatabase->industries, true) : [];
      // $exp_work_type = isset($TrainingDatabase->work_type) && !empty($TrainingDatabase->work_type) ? (int)$TrainingDatabase->work_type : 1;
        
        
      $options_list = [];
      if(!empty($CorporateListOptions)){
        foreach ($CorporateListOptions as $item) {
          foreach ($item as $key => $details) {
            $options_list[$key] = $details;  // append inner arrays
          }
        }
      }

      $TrainingDatabase->prefer_time = $prefer_time;

      return response()->json([
        'status' => 200,
        'data' => $TrainingDatabase,
        'exp_details' => $options_list,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Trainer Database not found',
      ]);
    }
  }

  public function Update(Request $request)
  {
     
    $state_id = isset($request->state_id) && !empty($request->state_id) && !is_array($request->state_id) ? explode(',',$request->state_id) : ($request->state_id ?? []);
    $city_id = isset($request->city_id) && !empty($request->city_id) && !is_array($request->city_id) ? explode(',',$request->city_id) : ($request->city_id ?? []);
    $industries_ids = isset($request->industries_ids) && !empty($request->industries_ids) && !is_array($request->industries_ids) ? explode(',',$request->industries_ids) : ($request->industries_ids ?? []);
    //  return $industries_ids;
    
    $timestamp = time();

    $domainExcellence = json_decode($request->input('domain_excellence'), true);

    $user_details = $request->update_exp_details;
    $training_sno = $request->sno;
    $slot_type = !empty($request->slot_type) ? explode(',',$request->slot_type) : [1];

    // $domainExcellence2 = json_decode($domainExcellence, true);
    $training = TrainingDatabaseModel::where('sno',$training_sno)->first();
    $training->trainer_name = $request->name;
    $training->mobile_no = $request->mobile_no;
    $training->email_id = $request->email_id;
    $training->qualification = $request->qualification;
    $training->industries = json_encode($industries_ids) ?? null;

    // return $training;
    // $training->work_type = (int)$request->work_type ?? 1;
    
    // If deliverables is an array, JSON encode it; if not, leave as is
    $deliverablesJson = null;
    
    if (is_array($user_details)) {
      $indexed_options = [];
      foreach ($user_details as $index => $value) {
          if ($value !== '') {
              // Indexing options starting at 1, as in your second example
              $indexed_options[] = [(string)$index => $value];
          }
      }
      $deliverablesJson = json_encode($indexed_options);
    }

    $training->cost = $request->pay_cost ?? 0;
    $training->cost_session_type = $request->session_type ?? 1;
    $training->prefer_time = json_encode($slot_type);
    $training->is_interested_travel = $request->is_travel_interest ?? 2;
    $training->state_id = json_encode($state_id);
    $training->city_id = json_encode($city_id);
    $training->experience_details = $deliverablesJson;
    $training->domain_excellence = $request->domain_excellence;
    $training->linkedin_url = $request->linkedin_url ?? NULL;
    // $training->area = $request->area_text ?? NULL;

    if ($request->hasFile('staff_image')) {
      $staffImagePath = 'staff_' . $timestamp . '.' . $request->file('staff_image')->extension();
      $request->file('staff_image')->move(public_path('trainer_staff_images'), $staffImagePath);
      $training->training_staff_image = $staffImagePath;
    }

    if ($request->hasFile('resume')) {
      $resumePath = 'resume_' . $timestamp . '.' . $request->file('resume')->extension();
      $request->file('resume')->move(public_path('trainer_resume_uploads'), $resumePath);
      $training->resume_upload = $resumePath;
    }

    if ($request->hasFile('certificate')) {
      $certificatePath = 'certificate_' . $timestamp . '.' . $request->file('certificate')->extension();
      $request->file('certificate')->move(public_path('trainer_certificate_uploads'), $certificatePath);
      $training->certificate_upload = $certificatePath;
    }

    $training->branch_id  = $request->user()->branch_id;
    $training->created_by = $request->user()->user_id;
    $training->updated_by = $request->user()->user_id;
    $training->save();

    return response()->json(['success' => true, 'message' => 'Trainer Database Updated']);

  }

  public function View_details($id)
  {
    $TrainingDatabase = TrainingDatabaseModel::where('sno', $id)
    ->where('status', '!=', 2)
    ->first();
    
    $helper = new \App\Helpers\Helpers();

    if (!empty($TrainingDatabase)) {

      $CorporateListOptions = isset($TrainingDatabase->experience_details) && !empty($TrainingDatabase->experience_details) ? json_decode($TrainingDatabase->experience_details, true) : [];
      // $exp_work_type = isset($TrainingDatabase->work_type) && !empty($TrainingDatabase->work_type) ? (int)$TrainingDatabase->work_type : 1;

      if(isset($TrainingDatabase->training_staff_image) && !empty($TrainingDatabase->training_staff_image)){
        if ($TrainingDatabase->training_staff_image != '' && file_exists(public_path('trainer_staff_images/' .$TrainingDatabase->training_staff_image))){
          $TrainingDatabase->training_staff_image = '<img src="'.asset('trainer_staff_images/' . $TrainingDatabase->training_staff_image).'" alt="avatar" class="rounded-circle border border-1 img-fluid" style="width: 150px; height: 150px; object-fit: cover;" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Trainer Profile" data-bs-original-title="Trainer Profile" />';
        }else{
          $initial = strtoupper(substr($TrainingDatabase->trainer_name, 0, 1));
          $TrainingDatabase->training_staff_image = '<div class="symbol symbol-35px me-2">'.$helper->name_image($initial,2).'</div>';
        }
      }

      $options_list = [];
      if(!empty($CorporateListOptions)){
        foreach ($CorporateListOptions as $item) {
          foreach ($item as $key => $details) {
            $options_list[$key] = $details;  // append inner arrays
          }
        }
      }
      
      $DomainListOptions = isset($TrainingDatabase->domain_excellence) && !empty($TrainingDatabase->domain_excellence) ? json_decode($TrainingDatabase->domain_excellence, true) : [];

      $domain_list = [];
      if(!empty($DomainListOptions)){
        foreach ($DomainListOptions as $key => $domain) {
          foreach ($domain as $domain_key => $domain_details) {
            $domain_list[(int)$key + 1] = $domain_details;  // append inner arrays
          }
        }
      }

      $TrainingDatabase->domain_list_str = !empty($domain_list) ? implode(', ',$domain_list) : null;
      $TrainingDatabase->cost_per_day = (!empty($TrainingDatabase->cost) ? number_format($TrainingDatabase->cost, 0) : 0).(isset($TrainingDatabase->cost_session_type) && !empty($TrainingDatabase->cost_session_type) ? ' Per '.ucfirst($helper->getCorpSessionType($TrainingDatabase->cost_session_type ?? 1)) : ' Per Day');

      $per_time_text = [];

      if(isset($TrainingDatabase->prefer_time) && !empty($TrainingDatabase->prefer_time)){
        $TrainingDatabase_prefer_time = !is_array($TrainingDatabase->prefer_time) ? json_decode($TrainingDatabase->prefer_time,true) : [];
        if(in_array(1, $TrainingDatabase_prefer_time)){
          $per_time_text[] ='Online';
        }
        if(in_array(2, $TrainingDatabase_prefer_time)){
          $per_time_text[] ='Offline';
        }
      }

      $state_ids = isset($TrainingDatabase->state_id) && !empty($TrainingDatabase->state_id) ? json_decode($TrainingDatabase->state_id,true) : [];
      $city_ids = isset($TrainingDatabase->city_id) && !empty($TrainingDatabase->city_id) ? json_decode($TrainingDatabase->city_id,true) : [];

      $states_list = collect($state_ids)->map(fn ($state_id) => $this->getStateName($state_id) ?? null)->filter()->values()->toArray();
      $city_list = collect($city_ids)->map(fn ($city_id) => $this->getCityName($city_id) ?? null)->filter()->values()->toArray();

      $TrainingDatabase->state_list = $states_list;
      $TrainingDatabase->state_names = !empty($states_list) && is_array($states_list) ? implode(', ',$states_list) : null;
      $TrainingDatabase->city_list = $city_list;
      $TrainingDatabase->city_names = !empty($city_list) && is_array($city_list) ? implode(', ',$city_list) : null;

      $TrainingDatabase->prefer_time_text = !empty($per_time_text) && is_array($per_time_text) ? implode(', ',$per_time_text) : '-';

      return response()->json([
        'status' => 200,
        'data' => $TrainingDatabase,
        'exp_details' => $options_list,
        'domain_list' => $domain_list,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Trainer Database not found',
      ]);
    }
  }

  public function Delete($id)
  {
    $upd_TrainingDatabaseModel         = TrainingDatabaseModel::where('sno', $id)->first();
    $upd_TrainingDatabaseModel->status = 2;
    $upd_TrainingDatabaseModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Trainer Database Deleted Successfully!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {
    $upd_TrainingDatabaseModel         = TrainingDatabaseModel::where('sno', $id)->first();
    $upd_TrainingDatabaseModel->status = $request->input('status', 0);
    $upd_TrainingDatabaseModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function getStates(Request $request)
  {
    try {
      $countryId = $request->country_id ?? 101;

      $states = DB::table('za_states')
          ->where('country_id', $countryId)
          ->select('id', 'name')
          ->orderBy('name')
          ->get();

      return response()->json([
        'status' => 200,
        'data' => $states
      ]);
    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Failed to fetch states',
        'error' => $e->getMessage()
      ]);
    }
  }

  public function getCitiesGroupedByState(Request $request)
  {
    try {

        $countryId = $request->country_id ?? 101;
        $stateIds  = $request->state_ids ?? [];

        if (!is_array($stateIds)) {
          $stateIds = [$stateIds];
        }

        // Fetch states
        $states = DB::table('za_states')
          ->where('country_id', $countryId)
          ->when(!empty($stateIds), function ($q) use ($stateIds) {
              $q->whereIn('id', $stateIds);
          })
          ->select('id', 'name')
          ->orderBy('name')
          ->get();

        // Fetch cities
        $cities = DB::table('za_cities')
          ->when(!empty($stateIds), function ($q) use ($stateIds) {
              $q->whereIn('state_id', $stateIds);
          })
          ->select('sid', 'name', 'state_id')
          ->orderBy('name')
          ->get()
          ->groupBy('state_id');

        // Group cities under states
        $result = $states->map(function ($state) use ($cities) {
          return [
            'state_id'   => $state->id,
            'state_name' => $state->name,
            'cities'     => isset($cities[$state->id]) ? $cities[$state->id]->map(function ($city) {
              return [
                'id'   => $city->sid,
                'name' => $city->name
              ];
            })->values() : []
          ];
        });

        return response()->json([
          'status' => 200,
          'data' => $result
        ]);

    } catch (\Exception $e) {
      return response()->json([
        'status' => 500,
        'message' => 'Failed to fetch cities',
        'error' => $e->getMessage()
      ]);
    }
  }

  private static function getStateName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['getStateName'])) {
        self::$temp['getStateName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['getStateName'][$id])) {
        $state = DB::table('za_states')->select('name')->where('id', $id)->first();
        self::$temp['getStateName'][$id] = $state ? $state->name : null;
    }
    return self::$temp['getStateName'][$id];
  }

  private static function getCityName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['getCityName'])) {
        self::$temp['getCityName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['getCityName'][$id])) {
        $state = DB::table('za_cities')->select('name')->where('sid', $id)->first();
        self::$temp['getCityName'][$id] = $state ? $state->name : null;
    }
    return self::$temp['getCityName'][$id];
  }

  public function get_resume_view_details($id, Request $request)
  {
    $TrainingDatabase = TrainingDatabaseModel::where('sno', $id)
    ->where('status', '!=', 2)
    ->first();
    
    $helper = new \App\Helpers\Helpers();

    if (!empty($TrainingDatabase)) {

      $CorporateListOptions = isset($TrainingDatabase->experience_details) && !empty($TrainingDatabase->experience_details) ? json_decode($TrainingDatabase->experience_details, true) : [];
      // $exp_work_type = isset($TrainingDatabase->work_type) && !empty($TrainingDatabase->work_type) ? (int)$TrainingDatabase->work_type : 1;

      if(isset($TrainingDatabase->training_staff_image) && !empty($TrainingDatabase->training_staff_image)){
        if ($TrainingDatabase->training_staff_image != '' && file_exists(public_path('trainer_staff_images/' .$TrainingDatabase->training_staff_image))){
          $TrainingDatabase->training_staff_image = '<img src="'.asset('trainer_staff_images/' . $TrainingDatabase->training_staff_image).'" alt="avatar" class="rounded-circle border border-1 img-fluid" style="width: 150px; height: 150px; object-fit: cover;" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Trainer Profile" data-bs-original-title="Trainer Profile" />';
        }else{
          $initial = strtoupper(substr($TrainingDatabase->trainer_name, 0, 1));
          $TrainingDatabase->training_staff_image = '<div class="symbol symbol-35px me-2">'.$helper->name_image($initial,2).'</div>';
        }
      }

      $options_list = [];
      if(!empty($CorporateListOptions)){
        foreach ($CorporateListOptions as $item) {
          foreach ($item as $key => $details) {
            $options_list[$key] = $details;  // append inner arrays
          }
        }
      }
      
      $DomainListOptions = isset($TrainingDatabase->domain_excellence) && !empty($TrainingDatabase->domain_excellence) ? json_decode($TrainingDatabase->domain_excellence, true) : [];

      $domain_list = [];
      if(!empty($DomainListOptions)){
        foreach ($DomainListOptions as $key => $domain) {
          foreach ($domain as $domain_key => $domain_details) {
            $domain_list[(int)$key + 1] = $domain_details;  // append inner arrays
          }
        }
      }

      $TrainingDatabase->domain_list_str = !empty($domain_list) ? implode(', ',$domain_list) : null;
      $TrainingDatabase->domain_list = !empty($domain_list) ? $domain_list : null;
      $TrainingDatabase->cost_per_day = (!empty($TrainingDatabase->cost) ? number_format($TrainingDatabase->cost, 0) : 0).(isset($TrainingDatabase->cost_session_type) && !empty($TrainingDatabase->cost_session_type) ? ' Per '.ucfirst($helper->getCorpSessionType($TrainingDatabase->cost_session_type ?? 1)) : ' Per Day');
      $TrainingDatabase->cost_value = (!empty($TrainingDatabase->cost) ? number_format($TrainingDatabase->cost, 0) : 0);
      $TrainingDatabase->per_day_text = (isset($TrainingDatabase->cost_session_type) && !empty($TrainingDatabase->cost_session_type) ? ' Per '.ucfirst($helper->getCorpSessionType($TrainingDatabase->cost_session_type ?? 1)) : ' Per Day');
      $industries_ids = isset($TrainingDatabase->industries) && !empty($TrainingDatabase->industries) ? json_decode($TrainingDatabase->industries,true) : [];
      
      
      $per_time_text = [];

      if(isset($TrainingDatabase->prefer_time) && !empty($TrainingDatabase->prefer_time)){
        $TrainingDatabase_prefer_time = !is_array($TrainingDatabase->prefer_time) ? json_decode($TrainingDatabase->prefer_time,true) : [];
        if(in_array(1, $TrainingDatabase_prefer_time)){
          $per_time_text[] ='Online';
        }
        if(in_array(2, $TrainingDatabase_prefer_time)){
          $per_time_text[] ='Offline';
        }
      }

      $state_ids = isset($TrainingDatabase->state_id) && !empty($TrainingDatabase->state_id) ? json_decode($TrainingDatabase->state_id,true) : [];
      $city_ids = isset($TrainingDatabase->city_id) && !empty($TrainingDatabase->city_id) ? json_decode($TrainingDatabase->city_id,true) : [];
      $experience_details = isset($TrainingDatabase->experience_details) && !empty($TrainingDatabase->experience_details) ? json_decode($TrainingDatabase->experience_details,true) : [];

      $states_list = collect($state_ids)->map(fn ($state_id) => $this->getStateName($state_id) ?? null)->filter()->values()->toArray();
      $city_list = collect($city_ids)->map(fn ($city_id) => $this->getCityName($city_id) ?? null)->filter()->values()->toArray();
      $industries_list = collect($industries_ids)->map(fn ($industry_id) => $this->getIndustriesName($industry_id) ?? null)->filter()->values()->toArray();

      $TrainingDatabase->state_list = $states_list;
      $TrainingDatabase->state_names = !empty($states_list) && is_array($states_list) ? implode(', ',$states_list) : null;
      $TrainingDatabase->city_list = $city_list;
      $TrainingDatabase->city_names = !empty($city_list) && is_array($city_list) ? implode(', ',$city_list) : null;

      $TrainingDatabase->prefer_time_list = !empty($per_time_text) && is_array($per_time_text) ? $per_time_text : null;
      $TrainingDatabase->prefer_time_text = !empty($per_time_text) && is_array($per_time_text) ? implode(', ',$per_time_text) : '-';
      $TrainingDatabase->resume_experience_details = !empty($experience_details) && is_array($experience_details) ? array_values($experience_details) : null;
      $TrainingDatabase->industries_list = $industries_list;
      $TrainingDatabase->industries_names = !empty($industries_list) && is_array($industries_list) ? implode(', ',$industries_list) : null;


      return response()->json([
        'status' => 200,
        'data' => $TrainingDatabase,
        'exp_details' => $options_list,
        'domain_list' => $domain_list,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Trainer Database not found',
      ]);
    }
  }
  public function get_corporate_industries_list()
  {
    $industries = CorporateIndustriesModel::where('status', '!=', 2)
      ->orderBy('industry_name')
      ->get()
      ->groupBy(function ($item) {
        return $item->industry_type == 1 ? 'IT' : 'Non-IT';
      })
      ->map(function ($group) {
          return $group->map(function ($item) {
              return [
                'id'   => $item->sno,
                'name' => $item->industry_name,
              ];
          })->values();
      });

    return response()->json([
      'status' => true,
      'data'   => $industries
    ]);
  }

  private static function getIndustriesName($id)
  {
    // Initialize 'details' if not already
    if (!isset(self::$temp['getIndustriesName'])) {
      self::$temp['getIndustriesName'] = [];
    }
    // Check if the id is already cached
    if (!isset(self::$temp['getIndustriesName'][$id])) {
      $state = CorporateIndustriesModel::select(['industry_name', 'industry_type'])->where('sno', $id)->first();
      self::$temp['getIndustriesName'][$id] = $state ? $state->industry_name." (".($state->industry_type == 1 ? 'IT' : 'Non-IT').")" : null;
    }
    return self::$temp['getIndustriesName'][$id];
  }
}
