<?php

namespace App\Http\Controllers\hr_management;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\ManageCoursesModel;
use App\Models\StaffKnowledgeModel;
use App\Models\StaffModel;
use App\Models\StaffRescheduleModel;
use App\Models\UserRolePermissionModel;
use App\Models\TrainingModel;
use App\Models\BatchModel;
use Illuminate\Support\Facades\Crypt;
use DateTime;
use App\Models\Batch_staff_swap_Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\View;

class Attendance extends Controller
{



    public function index(Request $request, $month = null)
    {
        // Get the current year and month if no month is provided
        $year = date('Y');
        $month = $request->get('month', $month ?? date('m')); // Get the month from request, or default to the current month

        // Generate start and end dates for the selected month
        $startDate = \Carbon\Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = \Carbon\Carbon::createFromDate($year, $month, 1)->endOfMonth();

        // Generate an array of dates for the selected month using CarbonPeriod
        $dates = \Carbon\CarbonPeriod::create($startDate, $endDate)->toArray();

        $branch_id = $request->user()->branch_id;

        // Fetch staff data including shift and weekoff details
        $query = StaffModel::select('za_staff.sno as staff_id', 'za_staff.staff_name', 'za_staff.nick_name', 'za_staff.gender', 'za_staff.staff_image', 'za_staff.mobile_no', 'za_staff.email_id', 'za_department.department_name', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_shift_time.shift_sunday', 'za_shift_time.shift_weekoff_day', 'za_shift_time.shift_weekoff', 'za_shift_time.shift_time_name')
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->where('za_staff.position_role','!=' ,49)
            ->where('za_staff.status', 0);
        // ->where('za_staff.department_id', 2);

        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }

        $staffs = $query->get();

        // Determine weekoff days
        foreach ($staffs as $staff) {
            if ($staff->shift_sunday == 0) {
                switch ($staff->shift_weekoff_day) {
                    case 1:
                        $staff->weekoff = 'Mon';
                        break;
                    case 2:
                        $staff->weekoff = 'Tue';
                        break;
                    case 3:
                        $staff->weekoff = 'Wed';
                        break;
                    case 4:
                        $staff->weekoff = 'Thu';
                        break;
                    case 5:
                        $staff->weekoff = 'Fri';
                        break;
                    case 6:
                        $staff->weekoff = 'Sat';
                        break;
                    default:
                        $staff->weekoff = 'Sun';
                        break;
                }
            } else {
                $staff->weekoff = 'Sun';
            }
        }

        // Fetch and group attendance records for the selected month
        $attendanceRecords = StaffAttendanceModel::select('staff_id', 'date', 'attendance')
            ->whereBetween('date', [$startDate, $endDate])
            ->get()
            ->groupBy('staff_id');

        // Initialize attendance summary
        $attendanceSummary = [];
        $attendanceSummaryMonth = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'other' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_days' => count($dates) * count($staffs), // Total days for all staff combined
        ];

        // Calculate attendance summary for each staff member
        foreach ($staffs as $staff) {
            $staffAttendance = $attendanceRecords->get($staff->staff_id, collect());

            // Initialize summary counts for the staff member
            $summary = [
                'present' => 0,
                'absent' => 0,
                'leave' => 0,
                'other' => 0,
                'permission' => 0,
                'onduty' => 0,
                'workoff' => 0,
                'total_days' => count($dates),
            ];

            foreach ($staffAttendance as $record) {
                switch ($record->attendance) {
                    case 'P':
                        $summary['present']++;
                        $attendanceSummaryMonth['present']++; // Add to the overall month summary
                        break;
                    case 'A':
                        $summary['absent']++;
                        $attendanceSummaryMonth['absent']++; // Add to the overall month summary
                        break;
                    case 'L':
                        $summary['leave']++;
                        $attendanceSummaryMonth['leave']++; // Add to the overall month summary
                        break;
                    case 'PR':
                        $summary['permission']++;
                        $attendanceSummaryMonth['permission']++; // Add to the overall month summary
                        break;
                    case 'OD':
                        $summary['onduty']++;
                        $attendanceSummaryMonth['onduty']++; // Add to the overall month summary
                        break;
                    case 'WO':
                            $summary['workoff']++;
                            $attendanceSummaryMonth['workoff']++; // Add to the overall month summary
                            break;
                    default:
                        $summary['other']++;
                        $attendanceSummaryMonth['other']++; // Add to the overall month summary
                        break;
                }
            }

            // Calculate and round percentages for the staff member
            $summary['present_percentage'] = $summary['total_days'] > 0 ? round(($summary['present'] / $summary['total_days']) * 100, 2) : 0;
            $summary['absent_percentage'] = $summary['total_days'] > 0 ? round(($summary['absent'] / $summary['total_days']) * 100, 2) : 0;
            $summary['leave_percentage'] = $summary['total_days'] > 0 ? round(($summary['leave'] / $summary['total_days']) * 100, 2) : 0;
            $summary['other_percentage'] = $summary['total_days'] > 0 ? round(($summary['other'] / $summary['total_days']) * 100, 2) : 0;
            $summary['permission_percentage'] = $summary['total_days'] > 0 ? round(($summary['permission'] / $summary['total_days']) * 100, 2) : 0;
            $summary['onduty_percentage'] = $summary['total_days'] > 0 ? round(($summary['onduty'] / $summary['total_days']) * 100, 2) : 0;
            $summary['workoff_percentage'] = $summary['total_days'] > 0 ? round(($summary['workoff'] / $summary['total_days']) * 100, 2) : 0;

            // Add the summary for the staff member
            $attendanceSummary[$staff->staff_id] = $summary;
        }

        // Optionally, calculate percentages for the overall monthly summary
        $attendanceSummaryMonth['present_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['present'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['absent_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['absent'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['leave_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['leave'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['other_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['other'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['permission_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['permission'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['onduty_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['onduty'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;
        $attendanceSummaryMonth['workoff_percentage'] = $attendanceSummaryMonth['total_days'] > 0 ? round(($attendanceSummaryMonth['workoff'] / $attendanceSummaryMonth['total_days']) * 100, 2) : 0;

        // return $staffs;
        // Fetch department data
        $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();
        // return $attendanceSummaryMonth['present_percentage'];
        // Pass data to the view
        return view('content.hr_management.attendance.attendance_list', [
            'branch_type_fill' => '',
            'branch_fill' => '',
            'franchise_fill' => '',
            'department_fill' => '',
            'staff_name_fill' => '',
            'staff_nick_name_fill' => '',
            'fdate' => '',
            'tdate' => '',
            'dt_fill' => '',
            'staffs' => $staffs,
            'attendanceRecords' => $attendanceRecords,
            'attendanceSummary' => $attendanceSummary,
            'attendanceSummaryMonth' => $attendanceSummaryMonth,
            'department_list_fill' => $department,
            'dates' => $dates,
            'month' => $month,
            'year' => $year,
        ]);
    }


    public function fetchIndividualStaffAttendance(Request $request)
    {
        $staffId = $request->input('staff_id');

        $response = StaffModel::select(
            'za_staff.sno as staff_id',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_department.department_name',
            'za_branch.branch_name',
            'za_branch.franchise_name',
            'za_shift_time.shift_sunday',
            'za_shift_time.shift_weekoff_day',
            'za_shift_time.shift_weekoff',
            'za_shift_time.shift_time_name'
        )
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->where('za_staff.status', 0)
            ->where('za_staff.sno', $staffId)
            ->first();


        return response()->json($response);
    }
    public function fetchStaffMonthlyAttendance(Request $request)
    {
        $staffId = $request->input('staff_id');
        $month = $request->input('month');
        $year = $request->input('year');

        // Fetch attendance data for the specified staff, month, and year
        $attendanceData = StaffAttendanceModel::select('staff_id', 'date', 'attendance')
            ->where('staff_id', $staffId)
            ->whereMonth('date', $month)
            ->whereYear('date', $year)
            ->get();

        // Initialize summary counts for the staff member
        $summary = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_days' => 0, // Total working days in the month
        ];

        // Initialize array to hold attendance for each day of the week
        $formattedAttendance = [
            'monday_status' => '',
            'tuesday_status' => '',
            'wednesday_status' => '',
            'thursday_status' => '',
            'friday_status' => '',
            'saturday_status' => '',
            'sunday_status' => ''
        ];

        // Check if attendance data is empty
        if ($attendanceData->isEmpty()) {
            return response()->json([
                'summary' => $summary,
                'formattedAttendance' => $formattedAttendance,
                'attendanceData' => $attendanceData,
            ]);
        }

        foreach ($attendanceData as $record) {
            $date = Carbon::parse($record->date);
            $dayOfWeek = $date->format('l'); // Day of the week

            // Count attendance status
            switch ($record->attendance) {
                case 'P':
                    $summary['present']++;
                    break;
                case 'A':
                    $summary['absent']++;
                    break;
                case 'L':
                    $summary['leave']++;
                    break;
                case 'PR':
                    $summary['permission']++;
                    break;
                case 'OD':
                    $summary['onduty']++;
                    break;
                case 'WO':
                    $summary['workoff']++;
                    break;
            }

            // Assign attendance to corresponding weekday
            switch ($dayOfWeek) {
                case 'Monday':
                    $formattedAttendance['monday_status'] = $record->attendance;
                    break;
                case 'Tuesday':
                    $formattedAttendance['tuesday_status'] = $record->attendance;
                    break;
                case 'Wednesday':
                    $formattedAttendance['wednesday_status'] = $record->attendance;
                    break;
                case 'Thursday':
                    $formattedAttendance['thursday_status'] = $record->attendance;
                    break;
                case 'Friday':
                    $formattedAttendance['friday_status'] = $record->attendance;
                    break;
                case 'Saturday':
                    $formattedAttendance['saturday_status'] = $record->attendance;
                    break;
                case 'Sunday':
                    $formattedAttendance['sunday_status'] = $record->attendance;
                    break;
            }

            // Increment total working days
            $summary['total_days']++;
        }

        // Calculate percentages
        $summary['present_percentage'] = $summary['total_days'] > 0 ? round(($summary['present'] / $summary['total_days']) * 100, 2) : 0;
        $summary['absent_percentage'] = $summary['total_days'] > 0 ? round(($summary['absent'] / $summary['total_days']) * 100, 2) : 0;
        $summary['leave_percentage'] = $summary['total_days'] > 0 ? round(($summary['leave'] / $summary['total_days']) * 100, 2) : 0;
        $summary['permission_percentage'] = $summary['total_days'] > 0 ? round(($summary['permission'] / $summary['total_days']) * 100, 2) : 0;
        $summary['onduty_percentage'] = $summary['total_days'] > 0 ? round(($summary['onduty'] / $summary['total_days']) * 100, 2) : 0;
        $summary['workoff_percentage'] = $summary['total_days'] > 0 ? round(($summary['workoff'] / $summary['total_days']) * 100, 2) : 0;

        // Format the final response
        $response = [
            'summary' => $summary,
            'formattedAttendance' => $formattedAttendance,
            'attendanceData' => $attendanceData,
        ];

        return response()->json($response);
    }
    protected function formatAttendanceData($attendanceData)
    {
        // Format the attendance data according to weekdays
        $formattedData = [];
        foreach ($attendanceData as $attendance) {
            $formattedData[] = [
                'monday_status' => $attendance->monday_status,
                'tuesday_status' => $attendance->tuesday_status,
                'wednesday_status' => $attendance->wednesday_status,
                'thursday_status' => $attendance->thursday_status,
                'friday_status' => $attendance->friday_status,
                'saturday_status' => $attendance->saturday_status,
                'sunday_status' => $attendance->sunday_status,
            ];
        }
        return $formattedData;
    }


    public function getYearlyAttendance(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        // Fetch all staff members in department 1 with active status
        $staffMembers = StaffModel::where('za_staff.status', 0)
            ->where('za_staff.branch_id', $branch_id)
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.department_id', 'za_department.department_name') // Assuming you want to select department name as well
            ->get();

        // Get the requested year or default to current year
        $year = $request->input('year', date('Y'));

        $attendanceData = [];

        foreach ($staffMembers as $staff) {
            $attendanceRecords = StaffAttendanceModel::where('staff_id', $staff->sno)
                ->whereYear('date', $year)  // Make sure this is the correct field name
                ->get();

             $monthlyAttendance = [];

              foreach ($attendanceRecords as $record) {
                  if (!empty($record->date)) {
                      $month = Carbon::parse($record->date)->format('m');  // Convert to Carbon and format
                      $monthlyAttendance[$month] = ($monthlyAttendance[$month] ?? 0) + 1;
                  }
              }
              // Convert monthly attendance count to percentage
              foreach ($monthlyAttendance as $month => $presentDays) {
                $totalDaysInMonth = Carbon::create($year, $month, 1)->daysInMonth; // Get total days in the month
                $monthlyAttendance[$month] = round(($presentDays / $totalDaysInMonth) * 100, 2); // Convert to percentage
              }

            $totalPresentDays = array_sum($monthlyAttendance);
            $attendancePercentage = ($totalPresentDays / (12 * 30)) * 100;

            // Prepare data for each staff
            $attendanceData[] = [
                'staff' => $staff,
                'monthlyAttendance' => $monthlyAttendance,
                'attendancePercentage' => round($attendancePercentage, 2),
            ];
        }

        return response()->json($attendanceData);
    }





    public function list_filter(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        $franchise_fill = $request->franchise_fill ?? '';
        $branch_fill = $request->branch_fill ?? '';
        $branch_type_fill = $request->branch_type_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $staff_name_fill = $request->staff_name_fill ?? '';
        $staff_nick_name_fill = $request->staff_nick_name_fill ?? '';
        // Date filtering
        $dt_fill = $request->month_select_value;
        // return $request;
        // Fetch staff data including shift and weekoff details
        $query = StaffModel::select('za_staff.sno as staff_id', 'za_staff.staff_name', 'za_staff.nick_name', 'za_staff.gender', 'za_staff.staff_image', 'za_staff.mobile_no', 'za_staff.email_id', 'za_department.department_name', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_shift_time.shift_sunday', 'za_shift_time.shift_weekoff_day', 'za_shift_time.shift_weekoff', 'za_shift_time.shift_time_name')
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id');
        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }


        if ($franchise_fill) {
            $query->where('za_staff.franchise_id', $franchise_fill);
        }
        if ($branch_fill) {
            $query->where('za_staff.branch_drop', $branch_fill);
        }
        if ($branch_type_fill) {
            $query->where('za_staff.branch_franchise', $branch_type_fill);
        }
        if ($department_fill) {
            $query->where('za_staff.department_id', $department_fill);
        }
        if ($staff_name_fill) {
            $query->where('za_staff.staff_name', 'LIKE', "%{$staff_name_fill}%");
        }
        if ($staff_nick_name_fill) {
            $query->where('za_staff.nick_name', 'LIKE', "%{$staff_nick_name_fill}%");
        }
        if ($dt_fill) {
            $year  = date('Y');
            $month = str_pad($dt_fill, 2, '0', STR_PAD_LEFT); // Ensure two-digit format

            $fdate = "$year-$month-01";
            $tdate = date('Y-m-t', strtotime($fdate));
            $dates = [];
            for ($i = 1; $i <= date('t'); $i++) {
                $dates[] =  $year . "-" . $month . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            }
        } else {
            $fdate = '';
            $tdate = '';
            $dates = [];
            for ($i = 1; $i <= date('t'); $i++) {
                $dates[] = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            }
        }

        // Fetch and group attendance records based on date range
        $attendanceRecords = StaffAttendanceModel::select('staff_id', 'date', 'status', 'attendance', 'type', 'time_start', 'time_end', 'reason')
            ->when($fdate && $tdate, function ($query) use ($fdate, $tdate) {
                return $query->whereBetween('date', [$fdate, $tdate]);
            })
            ->get()
            ->groupBy('staff_id');


        $staffs = $query->where('za_staff.status', 0)->get();

        // Determine weekoff days
        foreach ($staffs as $staff) {
            if ($staff->shift_sunday == 0) {
                switch ($staff->shift_weekoff_day) {
                    case 1:
                        $staff->weekoff = 'Mon';
                        break;
                    case 2:
                        $staff->weekoff = 'Tue';
                        break;
                    case 3:
                        $staff->weekoff = 'Wed';
                        break;
                    case 4:
                        $staff->weekoff = 'Thu';
                        break;
                    case 5:
                        $staff->weekoff = 'Fri';
                        break;
                    case 6:
                        $staff->weekoff = 'Sat';
                        break;
                    default:
                        $staff->weekoff = 'Sun';
                        break;
                }
            } else {
                $staff->weekoff = 'Sun';
            }
        }


        // Loop through each staff member's attendance records to calculate time differences
        foreach ($attendanceRecords as $staffId => $records) {
            foreach ($records as $record) {
                if ($record->attendance == 'OD' || $record->attendance == 'PR') {
                    $time_start = strtotime($record->time_start);
                    $time_end = strtotime($record->time_end);
                    $difference = $time_end - $time_start;
                    $hours = floor($difference / 3600);
                    $minutes = floor(($difference % 3600) / 60);
                    $record->time_difference = $hours . 'H ' . $minutes . 'M';
                }
            }
        }

        $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

        // Return the view with filter variables and session flash for filter_on
        return view('content.hr_management.attendance.attendance_list', [
            'attendanceRecords' => $attendanceRecords,
            'department_list_fill' => $department,
            'franchise_fill' => $franchise_fill,
            'branch_fill' => $branch_fill,
            'branch_type_fill' => $branch_type_fill,
            'department_fill' => $department_fill,
            'staff_name_fill' => $staff_name_fill,
            'staff_nick_name_fill' => $staff_nick_name_fill,
            'fdate' => $fdate,
            'tdate' => $tdate,
            'dt_fill' => $dt_fill,
            'staffs' => $staffs,
            'dates' => $dates,
        ])->with('filter_on', true);
        // Flashing 'filter_on' session variable
        // return $dt_fill;
    }



    public function getBranches()
    {
        $branches = BranchModel::where('status', 0)->get(['sno', 'branch_name']); // Adjust the fields as per your database
        return response()->json(['status' => 200, 'data' => $branches]);
    }

    // Fetch Departments based on Branch
    public function getDepartments(Request $request)
    {

        $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
        return response()->json(['status' => 200, 'data' => $departments]);
    }


    // public function getStaff(Request $request)
    // {
    //     $branchId = $request->user()->branch_id;
    //     $departmentId = $request->department_id;

    //     $staffQuery = StaffModel::query();
    //     $staff = $staffQuery->where('branch_id', $branchId)->where('department_id', $departmentId)->where('status', 0)->get(['sno', 'staff_name', 'nick_name']);

    //     return response()->json(['status' => 200, 'data' => $staff]);
    // }
    public function getStaff(Request $request)
    {
        $branchId = $request->user()->branch_id;
        $departmentId = $request->department_id;
        $currentDate = now()->format('Y-m-d'); // Get the current date in 'Y-m-d' format

        // Get staff members based on branch and department
        $staffQuery = StaffModel::query();
        $staff = $staffQuery->where('branch_id', $branchId)
            ->where('department_id', $departmentId)
            ->where('status', 0)
            ->get(['sno', 'staff_name', 'nick_name']);

        // Get staff IDs who have attendance records for the current date
        $attendanceRecords = StaffAttendanceModel::whereIn('staff_id', $staff->pluck('sno'))
            ->whereDate('date', $currentDate) // Filter by current date
            ->pluck('staff_id'); // Get only the staff IDs

        // Filter out staff members who have attendance records for today and reset keys
        $filteredStaff = $staff->whereNotIn('sno', $attendanceRecords)->values();

        return response()->json(['status' => 200, 'data' => $filteredStaff]);
    }


    // public function ViewAttendanceDate(Request $request)
    // {
    //     $date = $request->input('date');

    //     // Validate the incoming date
    //     if (!$date) {
    //         return response()->json([
    //             'status' => 400,
    //             'message' => 'Date is required.',
    //             'error_msg' => 'Invalid date provided.',
    //             'data' => [],
    //         ]);
    //     }

    //     // Get the selected date
    //     $selectedDate = Carbon::parse($date);

    //     // Fetch staff attendance data for the selected date
    //     $viewAttendance = StaffAttendanceModel::select('za_staff_attendance.*', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.nick_name', 'za_staff.mobile_no', 'za_staff.department_id', 'za_staff.sub_department_id', 'za_department.department_name', 'za_sub_department.sub_department_name', 'za_staff.position_role', 'za_job_roll.job_roll_name')
    //         ->join('za_staff', 'za_staff_attendance.staff_id', '=', 'za_staff.sno') // Assuming you have a relationship
    //         ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
    //         ->leftJoin('za_sub_department', 'za_staff.sub_department_id', '=', 'za_sub_department.sno')
    //         ->leftJoin('za_job_roll', 'za_staff.position_role', '=', 'za_job_roll.sno')
    //         ->where('za_staff_attendance.date', $selectedDate)
    //         ->get();

    //     if ($viewAttendance->isEmpty()) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'No attendance data found for the selected date.',
    //             'error_msg' => null,
    //             'data' => [],
    //         ]);
    //     }



    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Attendance data retrieved successfully.',
    //         'error_msg' => null,
    //         'data' => $viewAttendance,
    //     ]);
    // }
    public function ViewAttendanceDate(Request $request)
    {
        $date = $request->input('date');

        // Validate the incoming date
        if (!$date) {
            return response()->json([
                'status' => 400,
                'message' => 'Date is required.',
                'error_msg' => 'Invalid date provided.',
                'data' => [],
            ]);
        }

        // Get the selected date
        $selectedDate = Carbon::parse($date);

        // Fetch staff attendance data for the selected date
        $viewAttendance = StaffAttendanceModel::select(
            'za_staff_attendance.*',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.gender',
            'za_staff.nick_name',
            'za_staff.mobile_no',
            'za_staff.department_id',
            'za_staff.sub_department_id',
            'za_department.department_name',
            'za_sub_department.sub_department_name',
            'za_staff.position_role',
            'za_job_position.job_position_name as job_roll_name'
        )
            ->join('za_staff', 'za_staff_attendance.staff_id', '=', 'za_staff.sno')
            ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
            ->leftJoin('za_sub_department', 'za_staff.sub_department_id', '=', 'za_sub_department.sno')
            ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
            ->where('za_staff_attendance.date', $selectedDate)
            ->get();

        if ($viewAttendance->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No attendance data found for the selected date.',
                'error_msg' => null,
                'data' => [],
            ]);
        }

        // Calculate the attendance summary
        $attendanceSummaryMonth = [
            'present' => 0,
            'absent' => 0,
            'leave' => 0,
            'other' => 0,
            'permission' => 0,
            'onduty' => 0,
            'workoff' => 0,
            'total_staff' => count($viewAttendance),
        ];

        // Loop through staff attendance records to calculate summary
        foreach ($viewAttendance as $attendance) {
            switch ($attendance->attendance) {
                case 'P': // Present
                    $attendanceSummaryMonth['present']++;
                    break;
                case 'A': // Absent
                    $attendanceSummaryMonth['absent']++;
                    break;
                case 'L': // Leave
                    $attendanceSummaryMonth['leave']++;
                    break;
                case 'PR': // Permission
                    $attendanceSummaryMonth['permission']++;
                    break;
                case 'OD': // On Duty
                    $attendanceSummaryMonth['onduty']++;
                    break;
                case 'WO': // On Duty
                        $attendanceSummaryMonth['workoff']++;
                        break;
                default:
                    $attendanceSummaryMonth['other']++;
                    break;
            }
        }

        // Calculate percentages for each attendance category
        $totalStaff = $attendanceSummaryMonth['total_staff'];
        $attendanceSummaryMonth['present_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['present'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['absent_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['absent'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['leave_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['leave'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['permission_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['permission'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['onduty_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['onduty'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['workoff_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['workoff'] / $totalStaff) * 100, 2) : 0;
        $attendanceSummaryMonth['other_percentage'] = $totalStaff > 0 ? round(($attendanceSummaryMonth['other'] / $totalStaff) * 100, 2) : 0;

        return response()->json([
            'status' => 200,
            'message' => 'Attendance data retrieved successfully.',
            'error_msg' => null,
            'data' => $viewAttendance,
            'summary' => $attendanceSummaryMonth, // Return attendance summary as well
        ]);
    }
    public function Add(Request $request)
    {
        $request->validate([
            'staff_id' => 'required',
            'entry_select' => 'required',
        ]);
    
        $branch_id = $request->user()->branch_id;
        $staffIds = $request->input('staff_id', []);
        $attendanceType = $request->input('entry_select');
        $attendanceTypes = ['1' => 'P', '2' => 'A', '3' => 'OD', '4' => 'PR', '5' => 'L', '6' => 'WO'];
        $att = $attendanceTypes[$attendanceType] ?? 'NA';
    
        // if (in_array('all', $staffIds)) {
        //     $staffIds = StaffModel::where('branch_id', $branch_id)
        //         ->where('department_id', $request->department_id)
        //         ->pluck('sno')
        //         ->toArray();
        // }
        if (in_array('all', $staffIds)) {
            // Step 1: Get all staff for this branch and department
            $staffIds = StaffModel::where('branch_id', $branch_id)
                ->where('department_id', $request->department_id)->where('status', 0)
                ->pluck('sno') // Get only staff IDs
                ->toArray();

            // Step 2: Get attendance for today
            $attendanceRecords = StaffAttendanceModel::whereIn('staff_id', $staffIds)
                ->whereDate('date', Carbon::today()) // Use Carbon to get today's date
                ->pluck('staff_id') // Get already marked staff IDs
                ->toArray();

            // Step 3: Remove already attended staff
            $staffIds = array_diff($staffIds, $attendanceRecords); // These are the remaining staff to process
        }
    
        $attendanceDate = '';
        $startTime = null;
        $endTime = null;
        $reason = '';
    
        // OD or PR => With Time
        if (in_array($attendanceType, ['3', '4'])) {
            try {
                $startTime = (new DateTime($request->input('st_time')))->format('H:i:s');
                $endTime = (new DateTime($request->input('end_time')))->format('H:i:s');
                $reason = $request->reason;
            } catch (\Exception $e) {
                return response()->json(['status' => 400, 'message' => 'Invalid time format.']);
            }
            $attendanceDate = now()->format('Y-m-d'); // ← Set date!
        }
    
        // Tomorrow case
        elseif ($request->input('attendance_type_add') === 'tomorrow') {
            $attendanceDate = now()->modify('+1 day')->format('Y-m-d');
        }
    
        // Custom range
        elseif ($request->input('attendance_type_add') === 'custom') {
            $dates = $request->input('attendance_date_range_add', []);
            if (is_string($dates)) {
                $dates = explode(',', $dates);
            }
    
            foreach ($dates as $date) {
                $dateTime = DateTime::createFromFormat('Y-m-d', trim($date));
                if (!$dateTime) {
                    return response()->json(['status' => 400, 'message' => 'Invalid date format: ' . $date]);
                }
    
                $formattedDate = $dateTime->format('Y-m-d');
                $lastStaffAttendanceId = $this->processAttendanceForDate($request, $staffIds, $att, $formattedDate, $startTime, $endTime, $reason);
            }
    
            $staff_attendance_id = Crypt::encryptString($lastStaffAttendanceId);
            return response()->json([
                'status' => 200,
                'message' => 'Attendance marked successfully',
                'redirectUrl' => $request->department_id == 2
                    ? route('hr-management-staff-reschedule', ['staff_attendance_id' => $staff_attendance_id])
                    : null
            ]);
        }
    
        // P or A => Present or Absent
        elseif (in_array($attendanceType, ['1', '2', '6', '3', '4'])) {
            $attendanceDate = now()->format('Y-m-d');
        }
    
        // Fallback in case none of above sets date
        if (empty($attendanceDate)) {
            $attendanceDate = now()->format('Y-m-d');
        }
    
        $lastStaffAttendanceId = $this->processAttendanceForDate($request, $staffIds, $att, $attendanceDate, $startTime, $endTime, $reason);
        $staff_attendance_id = Crypt::encryptString($lastStaffAttendanceId);
    
        return response()->json([
            'status' => 200,
            'message' => 'Attendance marked successfully',
            'redirectUrl' => route('hr-management-staff-reschedule', ['staff_attendance_id' => $staff_attendance_id])
        ]);
    }
    
    private function processAttendanceForDate(Request $request, array $staffIds, string $attendanceType, string $attendanceDate , $startTime, $endTime, $reason)
    {
        $branchId = $request->user()->branch_id;
        $userId = auth()->user()->user_id;
        $branch_code = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first()->city_short_code;
        $lastStaffAttendanceId = null;
        $category_checks = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $years = date("Y");
        $reschedule_id = $this->generateStaffRescheduleId($category_checks, $years, $branch_code);

        foreach ($staffIds as $staffId) {
            // Generate unique staff attendance ID
            $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $year = date("Y");
            $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $branch_code);

            // Save attendance
            StaffAttendanceModel::create([
                'staff_attendance_id' => $staff_attendance_id,
                'branch_id'           => $branchId,
                'staff_id'            => $staffId,
                'date'                => $attendanceDate,
                'attendance'          => $attendanceType,
                'type'                => $request->type_select ?? null,
                'time_start'          => $startTime ?? null,
                'time_end'            => $endTime ?? null,
                'reason'              => $reason ?? null,
                'reschedule_id'       => $reschedule_id,
                'created_by'          => $userId,
                'updated_by'          => $userId,
            ]);

            // Create reschedule record if needed
            if (in_array($attendanceType, ['A', 'L'])) {
                StaffRescheduleModel::create([
                    'staff_id'            => $staffId,
                    'date'                => $attendanceDate,
                    'staff_attendance_id' => $reschedule_id,
                    'branch_id'           => $branchId,
                    'attendance_status'   => $attendanceType,
                    'date_range'          => $attendanceDate,
                    'created_by'          => $userId,
                    'updated_by'          => $userId, // Add this line
                ]);
            }

            $lastStaffAttendanceId = $reschedule_id;
        }

        return $lastStaffAttendanceId;
    }



    // Helper method to generate a unique staff attendance ID
    private function generateStaffAttendanceId($category_check, $year, $branch_code)
    {
        if (!$category_check) {
            return $year . '/' . $branch_code . '/' . "SAT0001";
        }

        $data = $category_check->staff_attendance_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        return $year . '/' . $branch_code . '/' . sprintf("SAT%04d", $next_number);
    }

    private function generateStaffRescheduleId($category_check, $year, $branch_code)
    {
        if (!$category_check) {
            return $year . '/' . $branch_code . '/' . "RES0001";
        }

        $data = $category_check->staff_attendance_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        return $year . '/' . $branch_code . '/' . sprintf("RES%04d", $next_number);
    }



    public function Update(Request $request)
    {
        // Validate request inputs
        $request->validate([
            'staff_id' => 'required', // Assuming 'staff' is your table name and 'id' is the primary key
            'attendance_date_edit' => 'required',
            'entry_select_edit' => 'required',
        ]);

        $staffId = $request->staff_id;
        $attendance = $request->entry_select_edit;
        $attendanceDate = $request->attendance_date_edit;
        $date = DateTime::createFromFormat('d-M-Y', $attendanceDate);

        // Determine attendance type
        $attendanceTypes = [
            '1' => 'P',  // Present
            '2' => 'A',  // Absent
            '3' => 'OD', // On Duty
            '4' => 'PR', // Permission
            '5' => 'L' ,  // Leave
            '6' => 'WO'  // Workoff
        ];
        $attendanceType = $attendanceTypes[$attendance] ?? 'NA'; // Default to 'NA' if not found
        // return $attendance;
        // Check if attendance record exists for the staff and date
        $staffAttendance = StaffAttendanceModel::where('branch_id', auth()->user()->branch_id)
            ->where('staff_id', $staffId)
            ->where('date', $date->format('Y-m-d'))
            ->first();

        if ($staffAttendance) {
            // Update the existing attendance record
            $staffAttendance->update([
                'attendance' => $attendanceType,
                'time_start' => $request->time_start ?? null,
                'time_end' => $request->time_end ?? null,
                'reason' => $request->reason ?? null,
                'updated_by' => auth()->user()->user_id, // Assuming 'updated_by' tracks who made the update
            ]);
        } else {
            // Get branch code
            $branch = BranchModel::where('sno', auth()->user()->branch_id)->firstOrFail();
            $branchCode = $branch->city_short_code;

            // Generate a new staff attendance ID
            $latestAttendance = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $year = date("Y");
            if (!$latestAttendance) {
                $staffAttendanceId = $year . '/' . $branchCode . '/' . "SAT0001";
            } else {
                $data = $latestAttendance->staff_attendance_id;
                $slice = explode("/", $data);
                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                $nextNumber = (int)$resultcus + 1;
                $staffAttendanceId = sprintf("%s/%s/SAT%04d", $year, $branchCode, $nextNumber);
            }

            // Create a new attendance record
            StaffAttendanceModel::create([
                'staff_attendance_id' => $staffAttendanceId,
                'branch_id' => auth()->user()->branch_id,
                'staff_id' => $staffId,
                'date' => $date,
                'attendance' => $attendanceType,
                'type' => $request->type_select ?? null,
                'time_start' => $request->time_start ?? null,
                'time_end' => $request->time_end ?? null,
                'reason' => $request->reason ?? null,
                'created_by' => auth()->user()->user_id,
            ]);
        }

        return response()->json(['status' => 200, 'message' => 'Attendance marked successfully']);
    }

    public function viewAttendance($id)
    {
        // Define the attendance types
        $attendanceTypes = ['A', 'OD', 'PR', 'L', 'WO'];

        // Get the current date and the start of the current month
        $currentDate = Carbon::now();
        $startOfMonth = $currentDate->copy()->startOfMonth();

        // Fetch data from the staff attendance table
        $viewAttendance = StaffAttendanceModel::select('za_staff_attendance.*')
            ->whereIn('attendance', $attendanceTypes)
            ->whereBetween('date', [$startOfMonth->toDateString(), $currentDate->toDateString()])
            ->where('staff_id', $id)
            ->get();

        // Process attendance records to calculate time differences
        $viewAttendance->transform(function ($record) {
            if ($record->attendance == 'OD' || $record->attendance == 'PR') {
                $timeStart = new Carbon($record->time_start);
                $timeEnd = new Carbon($record->time_end);
                $difference = $timeEnd->diffInSeconds($timeStart);

                $hours = floor($difference / 3600);
                $minutes = floor(($difference % 3600) / 60);
                $record->time_difference = "{$hours}H {$minutes}M";
            } else {
                $record->time_difference = null;
            }
            return $record;
        });


        return response()->json([
            'status' => 200,
            'message' => 'Attendance data retrieved successfully.',
            'error_msg' => null,
            'data' => $viewAttendance,
        ]);
    }

   
    public function staff_reschedule(Request $request)
    {
        // Decrypt the staff_attendance_id

        $decryptedStaffAttendanceId = Crypt::decryptString($request->staff_attendance_id);
        // return $decryptedStaffAttendanceId;
        $staffRescheduledate = StaffRescheduleModel::where('staff_attendance_id', $decryptedStaffAttendanceId)->first();
        $branchId = $request->user()->branch_id;
        // Get the list of staff IDs from the StaffRescheduleModel
        $staffRescheduleIds = StaffRescheduleModel::where('staff_attendance_id', $decryptedStaffAttendanceId)
            ->pluck('staff_id'); // Use pluck instead of get to directly get the staff IDs
        // return $staffRescheduleIds;
         if (!empty($staffRescheduleIds)) {
                $datesRange = StaffRescheduleModel::whereIn('staff_id', $staffRescheduleIds)
                    ->where('status', 0)
                    ->pluck('date_range');
            } else {
                $datesRange = collect(); // Return an empty collection to prevent errors
            }
        // Fetch staff details for each staff ID in `staffRescheduleIds`
        $staff_details = StaffModel::whereIn('za_staff.sno', $staffRescheduleIds)
            ->select('za_staff.sno as staff_id', 'za_staff.staff_name', 'za_staff.nick_name', 'za_staff.gender', 'za_staff.staff_image', 'za_staff.mobile_no', 'za_staff.email_id', 'za_department.department_name', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_shift_time.shift_sunday', 'za_shift_time.shift_weekoff_day', 'za_shift_time.shift_weekoff', 'za_shift_time.shift_time_name', 'za_staff.knowledge_tag')
            ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
            ->where('za_staff.status', 0)
            ->where('za_staff.branch_id', $branchId)
            ->get();
    


        // Retrieve batches associated with each `staff_id` in `staffReschedule`
     
       $today = now()->toDateString(); // Get today's date
    $todayNumeric = now()->dayOfWeek; // Get today's numeric day (0 = Sunday, 1 = Monday, etc.)
    
    $batches = BatchModel::whereIn('staff_id', $staffRescheduleIds)
        ->select(
            'za_batch.sno',
            'za_batch.batch_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_batch.max_students',
            'za_batch.classroom_id',
            'za_class_room.class_room_name',
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_version',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_batch.slot_id',
            'za_slot.slot_name',
            'za_slot_type.slot_type_name'
        )
        ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
        ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
        ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
        ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
        ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
        ->where('za_batch.status', '!=', 2)
        ->where('za_slot_type.status', '!=', 2)
        ->where('za_slot.status', '!=', 2)
        ->whereDate('za_batch.start_date', '<=', $today) // Ensure batch started today or earlier
        ->whereDate('za_batch.end_date', '>=', $today) // Ensure batch is ongoing today
        ->whereRaw("JSON_CONTAINS(za_slot.slot_type_days, ?)", [json_encode((string) $todayNumeric)]) // Fix for JSON data
        ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name'
    )
    ->get();

        // Extract unique branch and course IDs
        $branch_ids = $batches->pluck('classroom_id')->unique(); // Assuming class_room_id refers to branches
        $course_ids = $batches->pluck('course_id')->unique();

        // Retrieve courses and their knowledge tags
        $courses = ManageCoursesModel::whereIn('sno', $course_ids)
            ->where('status', 0)
            ->get(['sno', 'knowledge_tags']);

        // Decode JSON knowledge tags into a flat array
        $courseKnowledgeTags = $courses->pluck('knowledge_tags')
            ->filter() // Remove null or empty knowledge tags
            ->map(function ($tag) {
                return json_decode($tag, true); // Decode JSON
            })
            ->flatten() // Flatten nested arrays
            ->unique() // Ensure unique values
            ->values() // Reset array keys
            ->toArray();
            
        //  return $courseKnowledgeTags;
        // Assuming `knowledge_tag` in `StaffModel` is a JSON string, decode it
        $staff_dropdown = StaffModel::select(
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.knowledge_tag',
            'za_department.department_name',
            'za_branch.branch_name',
            'za_branch.franchise_name',
            'za_shift_time.shift_sunday',
            'za_shift_time.shift_weekoff_day',
            'za_shift_time.shift_weekoff',
            'za_shift_time.shift_time_name'
        )
        ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
        ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
        ->join('za_shift_time', 'za_shift_time.sno', '=', 'za_staff.shift_time_id')
        ->where('za_staff.branch_id', $branchId)
        ->where('za_staff.status', 0)
        ->where(function ($query) use ($courseKnowledgeTags) {
            foreach ($courseKnowledgeTags as $tag) {
                $query->orWhereRaw('JSON_CONTAINS(za_staff.knowledge_tag, ?)', [json_encode(['value' => $tag])]);
            }
        })
        ->get();




    //   return $staff_dropdown;
       $staff_pratical = StaffModel::where('za_staff.branch_id', $branchId)
            ->whereNotIn('za_staff.sno', $staffRescheduleIds) // Use whereNotIn to exclude IDs
            ->get(['sno', 'staff_name', 'nick_name']);

        // Initialize counts

        $student_count = 0;
        $course_count = 0;
        $batch_count = 0;

        // Loop through batches to calculate counts
        foreach ($batches as $batch) {
            $students = TrainingModel::where('za_training.batch_id', $batch->sno)
                ->whereIn('za_training.staff_id', $staffRescheduleIds)
                ->where('za_training.course_id', $batch->course_id)
                ->where('za_training.slot_id', $batch->slot_id)
                ->where('za_training.status', 0)
                ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
                ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
                ->count();

            $student_count += $students;

            $course_count += TrainingModel::whereIn('staff_id', $staffRescheduleIds)
                ->where('course_id', $batch->course_id)
                ->where('status', 0)
                ->count();

            $batch_count += TrainingModel::whereIn('staff_id', $staffRescheduleIds)
                ->where('batch_id', $batch->sno)
                ->where('status', 0)
                ->count();
        }
        $datesRange = collect($datesRange)->sort()->toArray();
    //   return $batches;
        // Return the view with the necessary data
        return view('content.hr_management.attendance.staff_reschedule', compact('batches', 'student_count', 'staff_details', 'staffRescheduleIds', 'course_count', 'batch_count', 'staff_dropdown', 'staffRescheduledate', 'staff_pratical', 'datesRange'));
    }

    // public function StaffBatchReshedule(Request $request)
    // {
    //     $branchId = $request->user()->branch_id; // Get the branch ID from the authenticated user
    //     $payload = $request->all(); // Retrieve the entire payload from the request

    //     // Validate the request payload
    //     $validator = Validator::make($payload, [
    //         '*.batch_id' => 'required',
    //         '*.staff_id' => 'required',
    //         '*.reschedule_date' => 'required',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Validation error',
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }

    //     // Iterate through each batch and update records
    //     // foreach ($payload as $data) {
    //     //     BatchModel::where('branch_id', $branchId)
    //     //         ->where('sno', $data['batch_id'])
    //     //         ->update([
    //     //             'staff_id' => $data['staff_id'],
    //     //             'batch_staff' => $data['staff_id_original'],
    //     //             'reschedule_start_date' => Carbon::createFromFormat('d-M-Y', $data['reschedule_date'])->format('Y-m-d'), // Convert date to DB format
    //     //             'reschedule_end_date' => Carbon::createFromFormat('d-M-Y', $data['reschedule_date'])->format('Y-m-d'), // Convert date to DB format
    //     //             'updated_by' => $request->user()->user_id // Log who made the update
    //     //         ]);
    //     // }
    //     foreach ($payload as $data) {
    //         // Split the reschedule_date into start and end dates
    //         $dateRange = explode('to', $data['reschedule_date']);
    //         $startDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[0]))->format('Y-m-d');
    //         $endDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[1]))->format('Y-m-d');

    //         // Update the BatchModel with start and end dates
    //         BatchModel::where('branch_id', $branchId)
    //             ->where('sno', $data['batch_id'])
    //             ->update([
    //                 'staff_id' => $data['staff_id'],
    //                 'batch_staff' => $data['staff_id_original'],
    //                 'reschedule_start_date' => $startDate, // Store the start date
    //                 'reschedule_end_date' => $endDate,     // Store the end date
    //                 'updated_by' => $request->user()->user_id // Log who made the update
    //             ]);
    //     }


    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Batch reschedule successfully updated'
    //     ], 200);
    // }
    // public function StaffBatchReshedule(Request $request)
    // {
    //     $branchId = $request->user()->branch_id; // Get the branch ID from the authenticated user
    //     $payload = $request->all(); // Retrieve the entire payload from the request
    
    //     // Validate the request payload
    //     $validator = Validator::make($payload, [
    //         '*.batch_id' => 'required',
    //         '*.staff_id' => 'required',
    //         '*.reschedule_date' => 'required',
    //     ]);
    
    //     if ($validator->fails()) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Validation error',
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }
    
    //     // Iterate through each batch and update records
    //     foreach ($payload as $data) {
    //         // Check if the reschedule_date contains 'to' to split the date range
    //         if (strpos($data['reschedule_date'], 'to') !== false) {
    //             $dateRange = explode('to', $data['reschedule_date']);
    //             if (count($dateRange) == 2) {
    //                 // Trim the date range parts and parse into start and end dates
    //                 $startDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[0]))->format('Y-m-d');
    //                 $endDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[1]))->format('Y-m-d');
    //             } else {
    //                 // Handle cases where the date range is not in expected format
    //                 return response()->json([
    //                     'success' => false,
    //                     'message' => 'Invalid reschedule date format.',
    //                 ], 422);
    //             }
    //         } else {
    //             // If 'to' is not found, assume it's a single date
    //             $startDate = $endDate = Carbon::createFromFormat('d-M-Y', $data['reschedule_date'])->format('Y-m-d');
    //         }
    
    //         // Update the BatchModel with start and end dates
    //         BatchModel::where('branch_id', $branchId)
    //             ->where('sno', $data['batch_id'])
    //             ->update([
    //                 'staff_id' => $data['staff_id'],
    //                 'batch_staff' => $data['staff_id_original'],
    //                 'reschedule_start_date' => $startDate, // Store the start date
    //                 'reschedule_end_date' => $endDate,     // Store the end date
    //                 'updated_by' => $request->user()->user_id // Log who made the update
    //             ]);
    //     }
    
    //     return response()->json([
    //         'success' => true,
    //         'message' => 'Batch reschedule successfully updated'
    //     ], 200);
    // }
    public function StaffBatchReshedule(Request $request)
    {
        $branchId = $request->user()->branch_id; // Get the branch ID from the authenticated user
        $payload = $request->all(); // Retrieve the entire payload from the request

        // Validate the request payload
        $validator = Validator::make($payload, [
            '*.batch_id' => 'required',
            '*.staff_id' => 'required',
            '*.reschedule_date' => 'required',
            '*.attendance_status' => 'required', // Validate attendance_status
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        // Initialize an array to keep track of processed batch_id and staff_id combinations
        $processedCombinations = [];

        // Iterate through each batch and update records
        foreach ($payload as $data) {
            // Parse the date range
            if (strpos($data['reschedule_date'], 'to') !== false) {
                $dateRange = explode('to', $data['reschedule_date']);
                if (count($dateRange) == 2) {
                    $startDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[0]))->format('Y-m-d');
                    $endDate = Carbon::createFromFormat('d-M-Y', trim($dateRange[1]))->format('Y-m-d');
                } else {
                    return response()->json([
                        'success' => false,
                        'message' => 'Invalid reschedule date format.',
                    ], 422);
                }
            } else {
                $startDate = $endDate = Carbon::createFromFormat('d-M-Y', $data['reschedule_date'])->format('Y-m-d');
            }

            // Update the BatchModel with start and end dates
            BatchModel::where('branch_id', $branchId)
                ->where('sno', $data['batch_id'])
                ->update([
                    'staff_id' => $data['staff_id'],
                    'batch_staff' => $data['staff_id_original'],
                    'reschedule_start_date' => $startDate,
                    'reschedule_end_date' => $endDate,
                    'updated_by' => $request->user()->user_id,
                ]);

            // Map attendance_status to reason
            $reasonMap = [
                'L'  => 'Leave',
                'A'  => 'Absent',
                'P'  => 'Present',
                'WO' => 'Workoff'
            ];
            $reason = $reasonMap[$data['attendance_status']] ?? 'Unknown';

            // Check if the combination of batch_id and staff_id is already processed
            $batchId = $data['batch_id'];
            $staffId = $data['staff_id'];

            if (in_array([$batchId, $staffId], $processedCombinations)) {
                // If the combination already exists in the processed list, skip creating the swap
                continue;
            }

            // Add the combination to the processed list to prevent duplicate entries
            $processedCombinations[] = [$batchId, $staffId];

            // Add to swap table if no existing record
            $batchDetails = BatchModel::where('staff_id', $data['staff_id_original'])->first();
            if ($batchDetails) {
                $current_staff_id = $batchDetails->staff_id;

                // Check if there's already a swap for the same batch and staff
                // $existingSwap = Batch_staff_swap_Model::where('batch_id', $data['batch_id'])
                //     ->where(function ($query) use ($current_staff_id, $data) {
                //         // Check if the same batch_id and staff_id already have a pending swap
                //         $query->where('staff_id_before', $current_staff_id)
                //             ->where('staff_id_after', $data['staff_id']);
                //     })
                //     ->where('status', 0) // Only consider swaps that are pending (status 0)
                //     ->first();

                // If no existing swap, create a new record
                // if (!$existingSwap) {
                Batch_staff_swap_Model::create([
                    'branch_id'       => $branchId,
                    'batch_id'        => $data['batch_id'],
                    'staff_id_before' => $current_staff_id,
                    'staff_id_after'  => $data['staff_id'],
                    'swap_start_date' => $startDate,
                    'swap_end_date'   => $endDate,
                    'reason'          => $reason, // Use mapped reason from attendance_status
                    'created_by'      => $request->user()->user_id,
                    'updated_by'      => $request->user()->user_id,
                    'status'          => 1, // Status 0 means pending or active swap
                ]);
                // }
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Batch reschedule successfully updated',
        ], 200);
    }
    // Rosini
    // For January Month
    public function staff_bulk_attendence(Request $request)
    {  
        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;
    
        $staff = StaffModel::where('za_staff.branch_id', $branch_id)
            ->where('za_staff.status', 0)
            ->select(
                'za_staff.sno', 
                'za_staff.staff_name', 
                'za_staff.nick_name', 
                'za_staff.staff_image', 
                'za_staff.position_role', 
                'za_staff.gender', 
                'za_job_position.sno as job_position_sno', 
                'za_job_position.job_position_name'
            )
            ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
            ->groupBy(
                'za_staff.sno',
                'za_staff.staff_name', 
                'za_staff.nick_name', 
                'za_staff.staff_image', 
                'za_staff.position_role', 
                'za_staff.gender', 
                'za_job_position.sno', 
                'za_job_position.job_position_name'
            ) 
            ->get();
    
        // Get the general settings (if applicable)
        $helper = new \App\Helpers\Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings->date_format ?? 'd-M-y';
    
        // Get the current year
        $currentYear = date('Y');
    
        // Generate dates for January of the current year
        $dates = [];
        for ($i = 1; $i <= 31; $i++) {
            $date = date('Y') . "-" . date('m') . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            // $date = $currentYear . "-01-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            // Format the date to d-M-Y
            $dates[] = date('d-M-Y', strtotime($date));
        }
    
        // Return the view with the generated dates and staff data
        return view('content.hr_management.attendance.staff_bulk_attendance', [
            'dates' => $dates,
            'staff' => $staff
        ]);
    }
     public function bulkAttendanceUpdate(Request $request)
    {
        // return $request;

        $attendence_data = $request->attendence;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $branch = BranchModel::find($branch_id);
        if (!$branch) {
        return response()->json(['status' => 'error', 'message' => 'Invalid branch ID'], 400);
        }
        $branch_code = $branch->city_short_code;

        foreach ($attendence_data as $date => $staffs) {
            foreach ($staffs as $staff_id => $attendance_status) {
                $attendance_status = $attendance_status[0]; // Extract "L" from the array
    
                if(isset($attendance_status)&& $attendance_status!=''){
                    // return $attendance_status;
                $last_attendance = StaffAttendanceModel::orderBy('sno', 'desc')->first();
                $attendance_id = $this->generateAttendanceId($last_attendance, $branch_code);

                $attendance_date = date('Y-m-d', strtotime($date));
                $attendance_record = StaffAttendanceModel::where('branch_id', $branch_id)
                ->where('date', $attendance_date)
                ->where('staff_id', $staff_id)
                ->first();


                if ($attendance_record) {
                // Update existing record
                $attendance_record->update([
                    'attendance' => $attendance_status,
                    'branch_id' => $branch_id,
                    'updated_by' => $user_id,
                    'time_start' => null,
                    'time_end' => null, 
                    'type' => null,
                    'reason' => null
                ]);
                } else {
                $attendance_record =  StaffAttendanceModel::create([
                    'staff_attendance_id' => $attendance_id,
                    'date' => $attendance_date,
                    'staff_id'=> $staff_id,
                    'attendance' => $attendance_status,
                    'branch_id' => $branch_id,
                    'time_start' => null,
                    'time_end' => null, 
                    'type' => null,
                    'reason' => null,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'status' => 1,
                ]);
                // return $attendance_record;

                }
                }
            }
        }

        if ($attendance_record) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff Attendance updated successfully!',
        ]);
        } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Batch!',
        ]);
        }

        return redirect()->back();
    }
    private function generateAttendanceId($last_attendance, $branch_code)
    {
      $year = date('Y');
      if (!$last_attendance) {
        return $year . '/' . $branch_code . '/SAT0001';
      }
  
      $last_id_parts = explode('/', $last_attendance->staff_attendance_id);
      $last_number = preg_replace('/[^0-9]/', '', $last_id_parts[2]);
      $next_number = (int)$last_number + 1;
  
      return sprintf('%s/%s/SAT%04d', $year, $branch_code, $next_number);
    }



}