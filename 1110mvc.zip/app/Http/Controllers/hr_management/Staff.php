<?php

namespace App\Http\Controllers\hr_management;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CredentialModel;
use App\Models\DepartmentModel;
use App\Models\JobpositionModel;
use App\Models\JobRollModel;
use App\Models\ShiftTimeModel;
use App\Models\StaffCredentialModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffKnowledgeModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\StaffSundayModel;
use App\Models\StaffWorkInfoModel;
use App\Models\User;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

// Staff controller

class Staff extends Controller
{

  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;
$helper = new \App\Helpers\Helpers();
$page = $request->input('page', 1);
$perpage = (int) $request->input('sorting_filter', 25);
$offset = ($page - 1) * $perpage;

$get_branch_type = 0;
if ($branch_id) {
    $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
}

$query = StaffModel::select(
    'za_staff.*',
    'za_staff.status AS staff_status',
    DB::raw('(
        SELECT degree_name
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_degree_name'),
    DB::raw('(
        SELECT major
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_major'),
    DB::raw('(
        SELECT university_name
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_university_name'),
     DB::raw('(
      SELECT COUNT(sno)
      FROM za_lead
      WHERE za_lead.created_by = za_staff.sno
      AND za_lead.status = 0
      AND za_lead.status NOT IN (2,4,6)
      AND za_lead.drop_verified = 0
      AND za_lead.spam_verified = 0
      AND za_lead.internal_status = 0
    ) AS leads_count'),
    'za_shift_time.shift_start_time',
    'za_shift_time.shift_end_time',
    'za_shift_time.shift_lunch_start',
    'za_shift_time.shift_lunch_end',
    'za_shift_time.shift_time_name',
    'za_department.department_name'
)
// ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.shift_time_id')
->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
// ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
->where('za_staff.status', '<', 2);

if ($branch_id > 0) {
    $query->where('za_staff.branch_id', $branch_id);
}

$staff = $query->orderBy('za_staff.sno', 'desc') ->paginate($perpage);


// return 

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    session()->forget('Add_staff_by_branch_id');

    $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Jobposition = JobpositionModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $JobRoll = JobRollModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // return $staff;
    return view('content.hr_management.staff.staff_list', [
      'staff' => $staff,
      'department_list_fill' => $department,
      'jop_position_list_fill' => $Jobposition,
      'job_roll_list_fill' => $JobRoll,
      'login_branch_id'   => $branch_id,
      'login_branch_type' => $get_branch_type,
      'perpage' => $perpage,
      'staff_name_fill' => '',
      'staff_nick_name_fill' => '',
      'department_fill' => '',
      'job_position_fill' => '',
      'job_roll_fill' => '',
      'date_filter' => '',

    ])->with('filter_on', false);
  }

  public function list_filter(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    $page = $request->input('page', 1);
$perpage = (int) $request->input('sorting_filter', 25);
$offset = ($page - 1) * $perpage;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }
    $staff_name_fill = $request->staff_name_fill ?? '';
    $staff_nick_name_fill = $request->staff_nick_name_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $job_position_fill = $request->job_position_fill_sno ?? '';
    $job_roll_fill = $request->job_roll_fill_sno ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $staff_ids = $request->input('staff_ids', []);

    $query = StaffModel::select(
    'za_staff.*',
    'za_staff.staff_id',
    'za_staff.staff_name',
    'za_staff.status AS staff_status',
    'za_staff.branch_id',
    'za_staff.department_id',
    'za_staff.position_role',
    'za_department.department_name',
    DB::raw('(
        SELECT degree_name
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_degree_name'),
    DB::raw('(
        SELECT major
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_major'),
    DB::raw('(
        SELECT university_name
        FROM za_staff_education_info
        WHERE staff_id = za_staff.sno
        ORDER BY qualification_type ASC
        LIMIT 1
    ) AS highest_university_name'),
    'za_shift_time.shift_start_time',
    'za_shift_time.shift_end_time',
    'za_shift_time.shift_lunch_start',
    'za_shift_time.shift_lunch_end',
    'za_shift_time.shift_time_name'
)
// ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.shift_time_id')
->leftJoin('za_department', 'za_staff.department_id', '=', 'za_department.sno')
->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
->where('za_staff.status', '<', 2);

if ($branch_id > 0) {
    $query->where('za_staff.branch_id', $branch_id);
}

if ($staff_name_fill) {
    $query->where('za_staff.staff_name', 'LIKE', "%{$staff_name_fill}%");
}


if (!empty($staff_ids)) {
        $query->whereIn('za_staff.sno', $staff_ids);
    }


// Date Filtering Logic
if ($date_filter == "today") {
    $todayDate = date("Y-m-d");
    $query->whereDate('za_staff.created_at', $todayDate);
} elseif ($date_filter == "week") {
    $today = date('l');
    if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
    } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
    }
    $query->whereBetween('za_staff.created_at', [$weekFromDate, $weekToDate]);
} elseif ($date_filter == "monthly") {
    $firstDayOfMonth = date('Y-m-01');
    $lastDayOfMonth = date('Y-m-t');
    $query->whereBetween('za_staff.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
} elseif ($date_filter == "custom_date") {
    if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_staff.created_at', [$fromDate, $toDate]);
    } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_staff.created_at', '>=', $fromDate);
    } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_staff.created_at', '<=', $toDate);
    }
}

if ($staff_nick_name_fill) {
    $query->where('za_staff.nick_name', 'LIKE', "%{$staff_nick_name_fill}%");
}

if ($department_fill) {
    $query->where('za_staff.department_id', $department_fill);
}

if ($job_position_fill) {
    $query->where('za_staff.position_role', $job_position_fill);
}

if ($job_roll_fill) {
    $query->where('za_staff.role_id', $job_roll_fill);
}

// Fetch Branch list ordered by sno in descending order
$staff = $query->orderBy('za_staff.sno', 'desc') ->paginate($perpage);;



    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    session()->forget('Add_staff_by_branch_id');




    $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Jobposition = JobpositionModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $JobRoll = JobRollModel::where('status', 0)->orderBy('sno', 'desc')->get();
    return view('content.hr_management.staff.staff_list', [
      'staff' => $staff,
      'department_list_fill' => $department,
      'jop_position_list_fill' => $Jobposition,
      'job_roll_list_fill' => $JobRoll,
      'login_branch_id'   => $branch_id,
      'login_branch_type' => $get_branch_type,
      'staff_name_fill' => $staff_name_fill,
      'staff_nick_name_fill' => $staff_nick_name_fill,
      'department_fill' => $department_fill,
      'job_position_fill' => $job_position_fill,
      'job_roll_fill' => $job_roll_fill,
       'perpage' => $perpage,
      'date_filter' => $date_filter,

    ])->with('filter_on', true);
  }

  public function get_branch_access_role()
  {
    // Retrieve the 'id' parameter from the request
    $id = request()->get('id', '');

    // Fetch the role permissions based on the role ID and status
    $role_per = UserRolePermissionModel::where('role_id', $id)
      ->where('status', 0)
      ->first();

    // Return the response with the role permissions data
    return response()->json([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $role_per,
    ], 200);
  }

  public function list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $staff = StaffModel::where('status', '!=', 2);
    // ->where('branch_id', $branch_id)
    if ($branch_id != 0) {
      $staff->where('branch_id', $branch_id);
    }
    $staff = $staff->orderBy('staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff,
    ], 200);
  }
    public function List_by_branch($id, Request $request)
  {
    $branch_id = $id;
    $staff = StaffModel::where('status', '!=', 2);
    // ->where('branch_id', $branch_id)
    if ($branch_id != 0) {
      $staff->where('branch_id', $branch_id);
    }
    $staff = $staff->orderBy('staff_name', 'asc')
      ->distinct() // Ensure unique rows
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff,
    ], 200);
  }
  public function credential_edit($id)
  {
    $results = CredentialModel::select(
      'za_credential.*',
      'za_staff_credential.status AS staff_status',
      'za_staff_credential.sno AS staff_cr_sno',
      'za_staff_credential.user_name',
      'za_staff_credential.password',
      'za_staff_credential.url_link',
      'za_staff_credential.description',
      'za_staff_credential.credential_id'
    )
      ->leftJoin('za_staff_credential', function ($join) use ($id) {
        $join->on('za_credential.sno', '=', 'za_staff_credential.credential_id')
          ->where('za_staff_credential.status', 0)
          ->where('za_staff_credential.staff_id', $id);
      })
      ->where('za_credential.status', 0)
      ->get();

    return response()->json([
      'status' => 200,
      'message' => 'Credentials fetched successfully',
      'data' => $results,
    ]);
  }

  public function Status($id, Request $request)
  {

    $staff =  StaffModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function staff_data_get($id)
  {

    $staff =  StaffModel::where('sno', $id)->first();

    if ($staff) {
      $helper = new \App\Helpers\Helpers();
      $position = $helper->get_position_id($staff->position_role)->job_position_name;
      return response([
        'status'      => 200,
        'mobile'      => $staff->mobile_no,
        'position'    => $position ?? '-',
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'mobile'      => '',
        'position'      => '',
      ], 200);
    }
  }

  public function staff_add(Request $request)
  {
      $branch_id = session('branch_id_ses') ?session('branch_id_ses') : $request->user()->branch_id;
        $shift_times = ShiftTimeModel::where('status', 0)->get();
        
        $shift_time = $shift_times->filter(function ($shift_time) use ($branch_id) {
            // Don't filter by branch_id if sno is 36
            if ($shift_time->sno == 36) {
                return true;
            }
        
            $branch_assign_ids = json_decode($shift_time->branch_assign_id, true);
        
            if (is_array($branch_assign_ids)) {
                return in_array($branch_id, $branch_assign_ids) || in_array(0, $branch_assign_ids);
            }
        
            return false;
        });
  
    return view('content.hr_management.staff.staff_add', compact('shift_time'));
  }

  public function Add(Request $request)
  {

    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'staff_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = $request->user()->user_id;
    // return $request;
    // Determine staff serial number
    $staff_check = StaffModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $sno = $staff_check ? $staff_check->sno + 1 : 1;

    // Handle staff image upload
    $staff_image = '';
    if ($request->hasFile('staff_add_icon')) {
      $staff_imageName = 'staff_' . $sno . '.' . $request->file('staff_add_icon')->extension();
      $request->file('staff_add_icon')->move(public_path('staff_images'), $staff_imageName);
      $staff_image = $staff_imageName;
    }

    // Handle attachments
    $attachments = [];
    if ($request->hasFile('attachment')) {
      foreach ($request->file('attachment') as $file) {
        $attachmentName = 'attachment_' . $sno . '_' . $file->getClientOriginalName();
        $file->move(public_path('staff_attachments/staff_' . $sno), $attachmentName);
        $attachments[] = $attachmentName;
      }
    }

    // Generate staff ID
    $year = substr(date("y"), -2);
    $staff_id = sprintf("SF-%04d/%s", $sno, $year);

    // return json_encode($request->KnowledgeTag);
    $access_bran = $request->acces_branch_id ?? [];
    $access_fra  = $request->acces_franchise_id ?? [];
    // Combine the two arrays
    $access_multi = array_merge($access_bran, $access_fra);
    $bran_multi   = json_encode($access_multi);

    // Create new staff record
    $add_staff = new StaffModel();
    $add_staff->staff_id = $staff_id;
    $add_staff->branch_franchise = $request->branch_franchise;
    if ($add_staff->branch_franchise == 1) {
      $staff_branch_id = $request->branch_id ?? session('branch_id_ses');
      $add_staff->branch_id = $request->branch_id ?? session('branch_id_ses');
    } else {
      $staff_branch_id      = $request->franchise_id ?? session('branch_id_ses');
      $add_staff->branch_id = $request->franchise_id ?? session('branch_id_ses');
    }

    // return $staff_branch_id;
    $add_staff->accessible_app         = $request->mobile_app ?? 0;
    $add_staff->multi_branch_access    = $bran_multi ?? '';

    $add_staff->sub_department_id = $request->sub_department_id ?? 0;
    $add_staff->branch_drop = $staff_branch_id;
    $add_staff->franchise_id = $staff_branch_id;
    $add_staff->department_id = $request->department_id ?? 0;
    $add_staff->role_id = $request->role_id;
    $add_staff->exp_type = $request->staff_type;
    $add_staff->staff_name = ucfirst($request->staff_name);
    $add_staff->mobile_no = $request->mobile_no;
    $add_staff->alternative_no = $request->alternative_no;
    $add_staff->email_id = $request->email_id;
    $add_staff->gender = $request->gender;
    $add_staff->dob = date('Y-m-d', strtotime($request->dob));
    $add_staff->date_of_joining = date('Y-m-d', strtotime($request->date_of_joinig));
    $add_staff->contact_person_name = $request->contact_person_name;
    $add_staff->contact_person_no = $request->contact_person_no;
    $add_staff->martial_status = $request->martial_status ?? null;
    $add_staff->address = $request->address ?? null;
    $add_staff->staff_image = $staff_image ?? null;
    $add_staff->attachment = json_encode($attachments) ?? null;
    $add_staff->knowledge_tag = is_array($request->KnowledgeTag) ? json_encode($request->KnowledgeTag) : $request->KnowledgeTag;
    $add_staff->nick_name = $request->nick_name ?? null;
    $add_staff->position_role = $request->position_role ?? null;
    $add_staff->description = $request->description ?? null;
    $add_staff->basic_salary = $request->salary ?? null;
    $add_staff->per_hour_cost = $request->hour_cost ?? null;
    $add_staff->discount = $request->dis_percent ?? null;
    $add_staff->coupon_code = $request->code_hidden;
    $add_staff->shift_time_id = $request->shift_time;
    $add_staff->login_access = $request->login_access ?? 0;
    $login_access = $request->login_access ?? 0;
    if ($login_access == 1) {
      $add_staff->user_name = $request->loginuser_name;
      $add_staff->password  = $request->loginpassword;
    } else {
      $add_staff->user_name = '';
      $add_staff->password  = '';
    }
    $add_staff->created_by = $request->user()->user_id;
    $add_staff->updated_by = $request->user()->user_id;

    $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {
      // Add User for login credentials
      $login_access = $request->login_access;
      if ($login_access == 1) {
        User::create([
          'user_id' => $add_staff->sno,
          'role_id' => $request->role_id ?? 0,
          'branch_id' => $staff_branch_id,
          'name' => $request->loginuser_name,
          'password' => Hash::make($request->loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id,
          'updated_by' => $request->user()->user_id,
        ]);
      }

      // Handle education information
      $qualificationTypes = $request->input('qualification_type_') ?? [];
      foreach ($qualificationTypes as $key => $qualificationType) {
        StaffEducationInfoModel::create([
          'staff_id' => $add_staff->sno,
          'qualification_type' => $qualificationType,
          'degree_name' => $request->input("degree_name_")[$key],
          'major' => $request->input("major_")[$key],
          'university_name' => $request->input("university_name_")[$key],
          'created_by' => $request->user()->user_id,
          'updated_by' => $request->user()->user_id,
        ]);
      }
      // Handle work information
      if ($request->staff_type == 2) {
        $positions = $request->input('position_') ?? [];
        foreach ($positions as $key => $position) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $request->staff_type,
            'position' => $position,
            'year_of_experience' => $request->input("year_of_experience_")[$key],
            'company_name' => $request->input("company_name_")[$key],
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }
      // Handle staff credentials

      $credentials = $request->input('credential_id') ?? [];

      foreach ($credentials as $key => $credential) {
        if ($request->input("username_" . $credential) != "") {
          StaffCredentialModel::create([
            'staff_id' => $add_staff->sno,
            'credential_id' => $credential,
            'user_name' => $request->input("username_" . $credential),
            'password' => $request->input("password_" . $credential),
            'url_link' => $request->input("url_" . $credential),
            'description' => $request->input("description_" . $credential),
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff added Successfully!'
      ]);

      if (session('Add_staff_by_branch_id')) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Staff added Successfully!'
        ]);
        session()->forget('branch_id_ses');
        session()->forget('branch_type_ses');
        session()->forget('Add_staff_by_branch_id');
        return redirect('hr_management/staff');
      } else {
        if (session('branch_type_ses')) {
          session()->flash('toastr', [
            'type' => 'info',
            'message' => 'Assign Branch Head..!'
          ]);
          session()->forget('branch_id_ses');
          session()->forget('branch_type_ses');
          return redirect('/branch');
        } else {
          return redirect('hr_management/staff');
        }
      }
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Staff !'
      ]);
    }
  }
  // unq Check add
  public function checkunique_user_name()
  {
    $username = request()->input('value');
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }
  // unq esit chk username
  public function checkunique_user_name_edit()
  {
    $username = request()->input('value');
    $id = request()->input('id');
    // return $id;
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => $staff,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }
  // unq esit chk username
    public function checkStaffMobileExists_edit()
    {
        $staff_mobile = request()->input('mobile');
        $id           = request()->input('id');
        // return $id;
        $staff = StaffModel::where('mobile_no', $staff_mobile)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $id)
            ->first();

        if ($staff) {
            return response()->json([
                'message' => 'Staff Mobile Number already assigned!',
                'data'    => $staff,
            ], 200);
        } else {
            return response()->json([
                'message' => 'Mobile Number available!',
                'data'    => 0,
            ], 200);
        }
    }



  public function Add_staff_branch_id(Request $request)
  {
    $id   = $request->input('id');
    $type = $request->input('type');
    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    session()->forget('Add_staff_by_branch_id');

    session(['branch_type_ses' => $type]);
    session(['branch_id_ses' => $id]);
    session(['Add_staff_by_branch_id' => 1]);

    return response()->json(['id' => $id, 'type' => $type, 'Add_staff_by_branch_id' => 1]);
    // return redirect( '/hr_management/staff/staff_add' );
  }


//   public function staff_view($id = '')
//   {
//     $helper = new \App\Helpers\Helpers();
//     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

//     // Check if decryption failed
//     if ($decryptedValue === false) {
//       return redirect()->back()->with('error', 'Invalid Entry');
//     }
//     // Fetch staff details for editing
//     $view = StaffModel::select(
//       'za_staff.*',
//       'za_staff.sno AS staff_sno',
//       'za_staff.user_name AS loginuser_name',
//       'za_staff.password AS loginpassword',
//       'za_staff.status AS staff_status',
//       'za_job_position.job_position_name',
//       'za_staff_work_info.staff_type',
//       'za_shift_time.shift_start_time',
//       'za_shift_time.shift_end_time',
//       'za_shift_time.shift_lunch_start',
//       'za_shift_time.shift_lunch_end',
//       'za_shift_time.shift_time_name'
//     )
//       ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
//       ->leftJoin('za_staff_education_info', 'za_staff_education_info.staff_id', '=', 'za_staff.sno')
//       ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
//       ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
//       ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
//       ->where('za_staff.status', '!=', 2)
//       ->where('za_staff.sno', '=', $decryptedValue)
//       ->first();

//     $educationInfo = StaffEducationInfoModel::where('staff_id', $decryptedValue)
//       ->where('status', '!=', 2)
//       ->get();

//     $workInfo = StaffWorkInfoModel::where('staff_id', $decryptedValue)
//       ->where('status', '!=', 2)
//       ->get();

//     $credentialInfo = StaffCredentialModel::join('za_credential', 'za_credential.sno', '=', 'za_staff_credential.credential_id')
//       ->where('za_staff_credential.status', '!=', 2)
//       ->where('za_staff_credential.staff_id', '=', $decryptedValue)
//       ->get();

//     $shiftTime = ShiftTimeModel::where('sno', $view->shift_time_id)
//       ->first();
//     // return $view->shift_time_id;

//     $staffknowledgeInfo = StaffKnowledgeModel::join('za_knowledge_tag', 'za_knowledge_tag.sno', '=', 'za_staff_knowledge_tag.knowledge_id')
//       ->where('za_staff_knowledge_tag.status', '!=', 2)
//       ->where('za_staff_knowledge_tag.staff_id', '=', $decryptedValue)
//       ->select('za_knowledge_tag.knowledge_tag_name') // Select columns you need
//       ->get();

//     return view('content.hr_management.staff.staff_view', [
//       'view' => $view,
//       'educationInfo' => $educationInfo,
//       'workInfo' => $workInfo,
//       'credentialInfo' => $credentialInfo,
//       'staffknowledgeInfo' => $staffknowledgeInfo,
//       'shiftTime' => $shiftTime,
//       'id' => $decryptedValue,
//     ]);
//   }
// popup
public function staff_view(Request $request)
  {
      if (!auth()->check()) {
          return redirect()->route('login');  // Redirect to login if the user is not authenticated
      }
      
    $id = $request->id;

    // Fetch staff details for editing
    $view = StaffModel::select(
      'za_staff.*',
      'za_staff.sno AS staff_sno',
      'za_staff.user_name AS loginuser_name',
      'za_staff.password AS loginpassword',
      'za_staff.status AS staff_status',
      'za_job_position.job_position_name',
      'za_staff_work_info.staff_type',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name'
    )
      ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_education_info', 'za_staff_education_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', '!=', 2)
      ->where('za_staff.sno', '=', $id)
      ->first();

    $educationInfo = StaffEducationInfoModel::where('staff_id', $id)
      ->where('status', '!=', 2)
      ->get();

    $workInfo = StaffWorkInfoModel::where('staff_id', $id)
      ->where('status', '!=', 2)
      ->get();

    $credentialInfo = StaffCredentialModel::join('za_credential', 'za_credential.sno', '=', 'za_staff_credential.credential_id')
      ->where('za_staff_credential.status', '!=', 2)
      ->where('za_staff_credential.staff_id', '=', $id)
      ->get();

    $shiftTime = ShiftTimeModel::where('sno', $view->shift_time_id)
      ->first();
    // return $view->shift_time_id;

    $staffknowledgeInfo = StaffKnowledgeModel::join('za_knowledge_tag', 'za_knowledge_tag.sno', '=', 'za_staff_knowledge_tag.knowledge_id')
      ->where('za_staff_knowledge_tag.status', '!=', 2)
      ->where('za_staff_knowledge_tag.staff_id', '=', $id)
      ->select('za_knowledge_tag.knowledge_tag_name') // Select columns you need
      ->get();

      // return $view;
      return view('content.hr_management.staff.staff_view', compact(
        'view', 'educationInfo', 'workInfo', 'credentialInfo', 'staffknowledgeInfo', 'shiftTime', 'id'
      ));    
  }
  public function staff_edit($id = '')
  {
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $branch_id = auth()->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }
    // Fetch staff details for editing
    $edit = StaffModel::select(
      'za_staff.*',
      'za_staff.sno AS staff_sno',
      'za_staff.user_name AS loginuser_name',
      'za_staff.password AS loginpassword',
      'za_staff.status AS staff_status',
      'za_job_position.job_position_name',
      'za_staff_work_info.staff_type',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name'
    )
      ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_education_info', 'za_staff_education_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', '!=', 2)
      ->where('za_staff.sno', '=', $decryptedValue)
      ->first();

    // Fetch related information
    $educationInfo = StaffEducationInfoModel::where('staff_id', $decryptedValue)
      ->where('status', '!=', 2)
      ->get();

    $workInfo = StaffWorkInfoModel::where('staff_id', $decryptedValue)
      ->where('status', '!=', 2)
      ->get();

    $credentialInfo = StaffCredentialModel::join('za_credential', 'za_credential.sno', '=', 'za_staff_credential.credential_id')
      ->where('za_staff_credential.status', '!=', 2)
      ->where('za_staff_credential.staff_id', '=', $decryptedValue)
      ->get();

    // $shift_times = ShiftTimeModel::where('status', '!=', 2)->get();

    // $shiftTime = $shift_times->filter(function ($shift_time) use ($branch_id) {
    //     $branch_assign_ids = json_decode($shift_time->branch_assign_id, true);

    //     if (is_array($branch_assign_ids)) {
    //         return in_array($branch_id, $branch_assign_ids);
    //     }

    //     return false;
    // });
    
    $shift_times = ShiftTimeModel::where('status', '!=', 2)->get();
        
    $shiftTime = $shift_times->filter(function ($shift_time) use ($branch_id) {
        // Don't filter by branch_id if sno is 36
        if ($shift_time->sno == 36) {
            return true;
        }
    
        $branch_assign_ids = json_decode($shift_time->branch_assign_id, true);
    
        if (is_array($branch_assign_ids)) {
            return in_array($branch_id, $branch_assign_ids) || in_array(0, $branch_assign_ids);
        }
    
        return false;
    });

    $staffknowledgeInfo = StaffKnowledgeModel::join('za_knowledge_tag', 'za_knowledge_tag.sno', '=', 'za_staff_knowledge_tag.knowledge_id')
      ->where('za_staff_knowledge_tag.status', '!=', 2)
      ->where('za_staff_knowledge_tag.staff_id', '=', $decryptedValue)
      ->select('za_knowledge_tag.knowledge_tag_name')
      ->get();
    // return $branch_id;
    return view('content.hr_management.staff.staff_edit', [
      'edit' => $edit,
      'educationInfo' => $educationInfo,
      'login_branch_id'   => $branch_id,
      'login_branch_type' => $get_branch_type,
      'workInfo' => $workInfo,
      'credentialInfo' => $credentialInfo,
      'staffknowledgeInfo' => $staffknowledgeInfo,
      'shiftTime' => $shiftTime,
      'id' => $decryptedValue, // Pass decrypted staff ID to the view
    ]);
  }

  public function Update(Request $request)
  {

    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'staff_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = 1;
    $edit_id = $request->edit_id;
    // Handle staff image upload
    $staff_image = '';
    if ($request->hasFile('staff_add_icon')) {
      $staff_imageName = 'staff_' . $edit_id . '.' . $request->file('staff_add_icon')->extension();
      $request->file('staff_add_icon')->move(public_path('staff_images'), $staff_imageName);
      $staff_image = $staff_imageName;
    } else {
      $staff_image = $request->old_staff_image;
    }

    // return $request->attachment;
    // Handle attachments
    $attachments = [];
    if ($request->hasFile('attachment') != '') {
      foreach ($request->file('attachment') as $file) {
        $attachmentName = 'attachment_' . $edit_id . '_' . $file->getClientOriginalName();
        $file->move(public_path('staff_attachments/staff_' . $edit_id), $attachmentName);
        $attachments[] = $attachmentName;
      }
    } else {
      $oldfile = $request->old_attachment ?? [''];
      $decodedFiles = json_decode($oldfile, true);
      // return $decodedFiles;
      foreach ($decodedFiles as $key => $file) {
        $attachments[] = $file;
      }
    }


    // Create new staff record
    $update_staff = StaffModel::where('sno', $edit_id)->first();

    // return json_encode($request->KnowledgeTag);
    $access_bran = $request->acces_branch_id ?? [];
    $access_fra  = $request->acces_franchise_id ?? [];
    // Combine the two arrays
    $access_multi = array_merge($access_bran, $access_fra);
    $bran_multi   = json_encode($access_multi);

    $update_staff->branch_franchise = $request->branch_franchise;
    if ($update_staff->branch_franchise == 1) {
      $staff_branch_id = $request->branch_id ?? 0;
      $update_staff->branch_id = $request->branch_id ?? 0;
    } else {
      $staff_branch_id      = $request->franchise_id ?? 0;
      $update_staff->branch_id = $request->franchise_id ?? 0;
    }
    $update_staff->accessible_app         = $request->mobile_app ?? 0;
    $update_staff->multi_branch_access    = $bran_multi ?? '';
    $update_staff->sub_department_id = $request->sub_department_id ?? 0;
    $update_staff->branch_drop = $staff_branch_id;
    $update_staff->franchise_id = $staff_branch_id;
    $update_staff->department_id = $request->department_id ?? 0;
    $update_staff->role_id = $request->role_id;
    $update_staff->exp_type = $request->staff_type;
    $update_staff->staff_name = ucfirst($request->staff_name);
    $update_staff->mobile_no = $request->mobile_no;
    $update_staff->alternative_no = $request->alternative_no;
    $update_staff->email_id = $request->email_id;
    $update_staff->gender = $request->gender;
    $update_staff->dob = date('Y-m-d', strtotime($request->dob));
    $update_staff->date_of_joining = date('Y-m-d', strtotime($request->date_of_joinig));
    $update_staff->contact_person_name = $request->contact_person_name;
    $update_staff->contact_person_no = $request->contact_person_no;
    $update_staff->martial_status = $request->martial_status ?? null;
    $update_staff->address = $request->address ?? null;
    $update_staff->staff_image = $staff_image ?? null;
    $update_staff->attachment = json_encode($attachments) ?? null;
    $update_staff->knowledge_tag = is_array($request->KnowledgeTag) ? json_encode($request->KnowledgeTag) : $request->KnowledgeTag;
    $update_staff->nick_name = $request->nick_name ?? null;
    $update_staff->position_role = $request->position_role ?? null;
    $update_staff->description = $request->description ?? null;
    $update_staff->basic_salary = $request->salary ?? null;
    $update_staff->per_hour_cost = $request->hour_cost ?? null;
    $update_staff->discount = $request->dis_percent ?? null;
    $update_staff->coupon_code = $request->code_hidden;
    $update_staff->shift_time_id =  $request->shift_time;
    $update_staff->login_access = $request->login_access ?? 0;
    $login_access = $request->login_access ?? 0;
    if ($login_access == 1) {
      $update_staff->user_name = $request->loginuser_name;
      $update_staff->password  = $request->loginpassword;
    } else {
      $update_staff->user_name = '';
      $update_staff->password  = '';
    }
    $update_staff->updated_by = $request->user()->user_id;
    $update_staff->save();
    if ($update_staff) {

      // Add User for login credentials
      $login_access = $request->login_access;

      if ($login_access == 1) {
        $user = User::where('user_id', $edit_id)->first();

        if ($user) {
          // Update the user
          $user->update([
            'role_id' => $request->role_id ?? 0,
            'branch_id' => $staff_branch_id,
            'name' => $request->loginuser_name,
            'password' => Hash::make($request->loginpassword),
            'email' => $request->email_id,
            'updated_by' => $request->user()->user_id,
          ]);
        } else {
          // Create a new user if it doesn't exist
          User::create([
            'user_id' => $edit_id,
            'role_id' => $request->role_id ?? 0,
            'branch_id' => $staff_branch_id,
            'name' => $request->loginuser_name,
            'password' => Hash::make($request->loginpassword),
            'email' => $request->email_id,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }


      $qualificationTypes = $request->input('qualification_type_') ?? [];
      foreach ($qualificationTypes as $key => $qualificationType) {
        $edu_sno = $request->input("edu_sno")[$key];

        if ($edu_sno != "") {
          // Update existing record
          $staffEducationInfo = StaffEducationInfoModel::find($edu_sno);
          if ($staffEducationInfo) {
            $staffEducationInfo->update([
              'qualification_type' => $qualificationType,
              'degree_name' => $request->input("degree_name_")[$key],
              'major' => $request->input("major_")[$key],
              'university_name' => $request->input("university_name_")[$key],
              'updated_by' => $request->user()->user_id,
            ]);
          }
        } else {
          // Insert new record
          StaffEducationInfoModel::create([
            'staff_id' => $edit_id,
            'qualification_type' => $qualificationType,
            'degree_name' => $request->input("degree_name_")[$key],
            'major' => $request->input("major_")[$key],
            'university_name' => $request->input("university_name_")[$key],
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }

      // Handle work information
      if ($request->staff_type == 2) {
        $positions = $request->input('position_') ?? [];
        foreach ($positions as $key => $position) {
          $work_sno = $request->input("work_sno")[$key] ?? null;

          if (!empty($work_sno)) {
            // Update existing record
            $staffWorkInfo = StaffWorkInfoModel::find($work_sno);
            if ($staffWorkInfo) {
              $staffWorkInfo->update([
                'staff_id' => $edit_id,
                'staff_type' => $request->staff_type,
                'position' => $position,
                'year_of_experience' => $request->input("year_of_experience_")[$key],
                'company_name' => $request->input("company_name_")[$key],
                'updated_by' => $request->user()->user_id,
              ]);
            }
          } else {
            // Insert new record
            StaffWorkInfoModel::create([
              'staff_id' => $edit_id,
              'staff_type' => $request->staff_type,
              'position' => $position,
              'year_of_experience' => $request->input("year_of_experience_")[$key],
              'company_name' => $request->input("company_name_")[$key],
              'created_by' => $request->user()->user_id,
              'updated_by' => $user_id
            ]);
          }
        }
      } elseif ($request->staff_type == 1) {
        // Update status for staff_type 2
        StaffWorkInfoModel::where('staff_id', $edit_id)
          ->update([
            'status' => 2,
          ]);
      }


      // Handle staff credentials
      $credentials = $request->input('credential_id') ?? [];

      foreach ($credentials as $key => $credential) {
        // Check if username for this credential is not empty
        $username = $request->input("username_" . $credential);
        if (!empty($username)) {
          // Retrieve the credential edit_sno if it exists
          $cre_sno = $request->input("credential_edit_sno")[$credential] ?? null;
          if (!empty($cre_sno)) {
            // Update existing StaffCredential
            $staffCredential = StaffCredentialModel::find($cre_sno);
            if ($staffCredential) {
              $staffCredential->update([
                'credential_id' => $credential,
                'user_name' => $username,
                'password' => $request->input("password_" . $credential),
                'url_link' => $request->input("url_" . $credential),
                'description' => $request->input("description_" . $credential),
                'updated_by' => $request->user()->user_id,
              ]);
            }
          } else {
            // Create new StaffCredential
            StaffCredentialModel::create([
              'staff_id' => $edit_id,
              'credential_id' => $credential,
              'user_name' => $username,
              'password' => $request->input("password_" . $credential),
              'url_link' => $request->input("url_" . $credential),
              'description' => $request->input("description_" . $credential),
              'created_by' => $request->user()->user_id,
              'updated_by' => $request->user()->user_id,
            ]);
          }
        }
      }

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Staff !'
      ]);
    }
    // return  $request;
    return redirect('hr_management/staff');
  }
  public function Delete($id)
  {
    $upd_StaffModel = StaffModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  // Sunday Staff By akilan
  public function sunday_staff_add(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'staff_ass_sno' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $starting_date = $request->sunday_start ? date('Y-m-d', strtotime($request->sunday_start)) : null;
    $ending_date = $request->sunday_end ? date('Y-m-d', strtotime($request->sunday_end)) : null;

    $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

    $branch_code = $branch_check->city_short_code;
    $user_id = $request->user()->user_id;

    $staff_check = StaffSundayModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

    $year = date("Y");

    if (!$staff_check) {
      // If no record is found, initialize the staff_sunday_id
      $staff_sunday_id = "{$year}/{$branch_code}/SFSUN0001";
    } else {
      // Extract the last staff_sunday_id
      $data = $staff_check->staff_sunday_id;
      $slice = explode("/", $data);

      // Check if the array has at least 3 elements
      if (count($slice) >= 3) {
        // Get the numeric part of the staff ID
        $result_coss = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number_cos = (int) $result_coss + 1;

        // Format the new staff ID
        $request_staff = sprintf("SFSUN%04d", $next_number_cos);
      } else {
        // Handle unexpected format: initialize with a default value
        $next_number_cos = 1; // Start numbering from 1
        $request_staff = sprintf("SFSUN%04d", $next_number_cos);
      }

      // Create the new staff_sunday_id
      $staff_sunday_id = "{$year}/{$branch_code}/{$request_staff}";
    }

    // Now you can use $staff_sunday_id as needed



    // Create new staff record
    $add_staff = new StaffSundayModel();
    $add_staff->staff_sunday_id = $staff_sunday_id;
    $add_staff->staff_id = $request->staff_ass_sno ?? 0;
    $add_staff->starting_date = $starting_date;
    $add_staff->ending_date = $ending_date;
    $add_staff->description = $request->sunday_desc ?? null;
    $add_staff->branch_id = $branch_id;
    $add_staff->created_by = $request->user()->user_id;
    $add_staff->updated_by = $request->user()->user_id;

    $add_staff->save();

    if ($add_staff) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Assign Sunday Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Assign Sunday!',
      ]);
    }
    return redirect('hr_management/staff');
  }

  public function sunday_staff_list(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $query = StaffSundayModel::select(
      'za_staff_sunday.sno as sunday_staff_sno',
      'za_staff_sunday.staff_id',
      'za_staff_sunday.status as sunday_status',
      'za_staff_sunday.starting_date',
      'za_staff_sunday.ending_date',
      'za_staff_sunday.description',
      'za_staff.*',
      'za_staff_education_info.degree_name AS highest_degree_name',
      'za_staff_education_info.major AS highest_major',
      'za_staff_education_info.university_name AS highest_university_name'

    )
      ->join('za_staff', 'za_staff.sno', '=', 'za_staff_sunday.staff_id')
      ->leftJoin('za_staff_education_info', function ($join) {
        $join->on('za_staff_education_info.staff_id', '=', 'za_staff.sno')
          ->whereRaw('za_staff_education_info.qualification_type = (
              SELECT MIN(qualification_type)
              FROM za_staff_education_info
              WHERE staff_id = za_staff.sno
          )');
      })
      ->where('za_staff_sunday.status', '!=', 2);
    if ($branch_id > 0) {
      $query->where('za_staff_sunday.branch_id', $branch_id);
    }
    $staff = $query->orderBy('za_staff_sunday.sno', 'desc')->paginate(10);
    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    session()->forget('Add_staff_by_branch_id');

    $department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Jobposition = JobpositionModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $JobRoll = JobRollModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // return $staff;
    return view('content.hr_management.staff.sunday_staff_list', [
      'staff' => $staff,
      'department_list_fill' => $department,
      'jop_position_list_fill' => $Jobposition,
      'job_roll_list_fill' => $JobRoll,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,

      'staff_name_fill' => '',
      'staff_nick_name_fill' => '',
      'department_fill' => '',
      'job_position_fill' => '',
      'job_roll_fill' => '',
      'date_filter' => '',

    ]);
  }

  public function SundayStatus($id, Request $request)
  {

    $staff = StaffSundayModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status' => 200,
        'message' => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data' => null,
      ], 200);
    } else {
      return response([
        'status' => 200,
        'message' => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data' => null,
      ], 200);
    }
  }

  // Exit staff
  public function Departure_staff(Request $request)
  {
    $id = $request->sts_change_sno;
    // Retrieve the staff record
    $staff = StaffModel::where('sno', $id)->first();

    if (!$staff) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid Staff!',
      ]);
    }

    // Update the staff status based on sts_change_id
    $staff->status = $request->sts_change_id;

    switch ($request->sts_change_id) {
      case 4:
        $staff->notice_start_date = date('Y-m-d', strtotime($request->notice_start_date));
        $staff->notice_end_date   = date('Y-m-d', strtotime($request->notice_end_date));
        $staff->dep_reason      = $request->dep_reason;
        break;

      case 5:
        $staff->dep_reason = $request->dep_reason;
        break;

      case 6:
        $staff->staff_last_date = date('Y-m-d', strtotime($request->staff_last_date));
        $staff->dep_reason = $request->dep_reason;
        break;

      case 7:
        $staff->dep_reason = $request->dep_reason;
        break;
      case 8:
        $staff->dep_reason = $request->dep_reason;
        break;

      default:
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Exit for the staff!',
        ]);
    }

    // Save the updated staff data
    if ($staff->save()) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff Exit Status Successfully Updated!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Exit for the staff!',
      ]);
    }
    return redirect('hr_management/staff/Exit_staff_list');
  }


  public function Exit_staff_list(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $query = StaffModel::select(
      'za_staff.*',
      'za_department.department_name'
    )
      ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->where('za_staff.branch_id', $branch_id)
      ->where('za_staff.status', '>', 3);
    
    $staff = $query->orderBy('za_staff.sno', 'desc')->get();

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    session()->forget('Add_staff_by_branch_id');
    // return $staff;
    return view('content.hr_management.staff.departure_staff_list', [
      'staff' => $staff,
    ]);
  }
  public function checkStaffMobileExists(Request $request)
    {
        $staff_mobile = $request->input('mobile');

        // Assuming you have a Lead model with a mobile field
        // $exists = StaffModel::where('mobile_no', $staff_mobile)->exists();
        $staff = StaffModel::where('mobile_no', $staff_mobile)
            ->where('status', '!=', 2)
            ->first();

        if ($staff) {
            return response()->json([
                'message' => 'Staff Mobile Number already assigned!',
                'data'    => 1,
            ], 200);
        } else {
            return response()->json([
                'message' => 'mobile no available!',
                'data'    => 0,
            ], 200);
        }

    }
    
     public function StaffFetchLeadBalance(Request $request){

    $branch_id = $request->user()->branch_id;
    $staffs = StaffModel::where('status', 0)->where('department_id', 1)->where('branch_id', $branch_id)->get();

    if(!$staffs) {
      return response([
        'status' => 400,
        'message' => 'No Such Records !',
        'error_msg' => null,
        'data' => null
      ], 404);
    } else {
      return response([
        'status' => 200,
        'message' => 'Staffs Fetched Successfully',
        'error_msg' => null,
        'data' => $staffs
      ], 200);
    }
  }
  public function bulkTransferExitStaff(Request $request)
  {

    $assign_staff_id = $request->staff_assgn_bulk;
    $user_id = $request->user()->user_id;
    $created_by = $request->created_by;

    // Fetch leads that match criteria
    $leads = LeadModel::where('created_by', $created_by)
    ->where('status', 0)
    ->whereNotIn('status', [2, 4, 6])
    ->where('spam_verified', 0)
    ->where('drop_verified', 0)
    ->where('internal_status', 0)
    ->select('sno', 'created_by', 'registered_date', 'status', 'branch_id', 'created_at')
    ->get();

    if ($leads->isNotEmpty()) {

      $success = true;

      foreach ($leads as $lead) {
        // Check current lead transfer log
        $lead_history = LeadTransferLogModel::where('lead_id', $lead->sno)
        ->where('end_date', null)
        ->where('current_staff_id', $created_by)
        ->first();

        if ($lead_history) {
          // Close the existing transfer
          $lead_history->end_date = date('Y-m-d');
          $lead_history->change_staff_id = $assign_staff_id;
          $lead_history->save();
        }

        // Add new transfer log
        $add_history = new LeadTransferLogModel();
        $add_history->lead_id = $lead->sno;
        $add_history->branch_id = $lead->branch_id;
        $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
        $add_history->end_date = null;
        $add_history->current_staff_id = $assign_staff_id;
        $add_history->change_staff_id = $created_by;
        $add_history->transferred_from = 1;
        $add_history->created_by = $user_id;
        $add_history->updated_by = $user_id;
        $add_history->save();

        // Update lead ownership
        $lead->created_by = $assign_staff_id;
        $lead->updated_by = $user_id;
        $lead->converted_by = $user_id;

        if (! $lead->update()) {
          $success = false;
        }
      }

      if($success) {
        return response([
          'status' => 200,
          'message' => 'Lead Converted Successfully',
          'error_msg' => null,
          'data' => null
        ], 200);
      } else {
        return response([
          'status' => 402,
          'message' => 'Lead Conversion Failed ',
          'error_msg' => null,
          'data' => null
        ], 402);
      }
    }
  }
      public function roleTransfer(Request $request)
    {
        $request->validate([
            'department_id' => 'required|integer',
            'sub_department_id' => 'required|integer',
            'position_role' => 'required|integer',
            'role_id' => 'required|integer',
            'dep_reason' => 'nullable|string|max:255',
        ]);
    
        try {
            DB::beginTransaction();
    
            $staff_id = $request->sts_change_sno ?? null; // ensure you pass this hidden input in modal
            if (!$staff_id) {
                return response()->json(['status' => 'error', 'message' => 'Staff ID missing.']);
            }
    
            // 1️⃣ Fetch existing staff
            $staff = StaffModel::where('sno', $staff_id)->first();
            if (!$staff) {
                return response()->json(['status' => 'error', 'message' => 'Staff not found.']);
            }
            // 2️⃣ Check if staff already has role history
                $lastHistory = DB::table('za_staff_role_history')
                    ->where('staff_id', $staff->sno)
                    ->orderByDesc('sno')
                    ->first();
        
                if ($lastHistory) {
                    // New role’s start date = previous record’s date_end (continuous)
                    $dateStart = $lastHistory->date_end ?? now();
                } else {
                    // First record — start today
                    $dateStart = $staff->date_of_joining;
                }
            // 2️⃣ Insert into history table before updating
            DB::table('za_staff_role_history')->insert([
                'staff_id' => $staff->sno,
                'branch_id' => $staff->branch_id,
                'old_department_id' => $staff->department_id,
                'old_sub_department_id' => $staff->sub_department_id,
                'old_position_role' => $staff->position_role,
                'old_role_id' => $staff->role_id,
                'reason' => $request->dep_reason,
                'date_start' =>  $dateStart,
                'date_end' => now(),
                'created_by' => $request->user()->user_id,
                'updated_by' => $request->user()->user_id,
            ]);
             // 3️⃣if goal have Update current staff record 
              DB::table('za_goal_set_staff')
                ->where('staff_id', $staff->sno)
                ->where('branch_id', $staff->branch_id)
                ->where('department_id', $staff->department_id) 
                ->update([
                    'status' => 2, // mark as inactive/deleted
                    'updated_at' => now(),
                ]);
    
            // 3️⃣ Update current staff record
            $staff->update([
                'department_id' => $request->department_id,
                'sub_department_id' => $request->sub_department_id,
                'position_role' => $request->position_role,
                'role_id' => $request->role_id,
            ]);
            DB::table('users')
                ->where('user_id', $staff->sno)
                ->update([
                    'role_id' => $request->role_id
                ]);
    
            DB::commit();
    
            return response()->json(['status' => 'success', 'message' => 'Role transferred successfully.']);
    
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}
