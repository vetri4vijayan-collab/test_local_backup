<?php
namespace App\Http\Controllers\sales\manage_followup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\FollowupReasonModel;
class ManageLeadFollowup extends Controller
{

    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $currentMonth=date('m');
        $currentYear=date('Y');
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('za_appointment')
            ->select(
                'za_appointment.sno', 'za_appointment.lead_id as ld_name_id', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status as appointment_status', 'za_appointment.reason as appointment_reason', 'za_appointment.created_by as staff_id', 'za_lead.lead_name', 'za_lead.lead_email_id', 'za_lead.lead_gender', 'za_lead.lead_id', 'za_lead.status as lead_status', 'za_staff.staff_name')
            ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
            ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
            ->where('za_appointment.status', 1)
            ->whereNotIn('za_lead.status', [2, 5, 6, 7])
            ->where('za_appointment.appointment_date', date('y-m-d'))
            ->where('za_appointment.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list      = $lead_flw_list->orderBy('za_appointment.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.progressed', null)->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();
        
        
        $completedCounts = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
            if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
                // User can only view their own data
                $completedCounts = $completedCounts->where('za_appointment.created_by', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
                // User can view all data
                $completedCounts = $completedCounts;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        $completedCounts=$completedCounts->count();
        $cancelledCounts = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        $pendingCounts   = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        // ->where('za_appointment.progressed', null)
        ->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();
    
    
        $TotalCounts   = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->whereIn('za_lead.status', [0, 4])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();
    
        
    
        $completedCountsMonth =  DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->whereMonth('za_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();
        $cancelledCountsMonth = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->whereMonth('za_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();
        $pendingCountsMonth   = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
        // ->where('za_appointment.progressed', null)
        ->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'))->where('za_appointment.appointment_time', '<=', now()->format('H:i'))->whereMonth('za_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();
        $TotalCountsMonth   = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->whereIn('za_lead.status', [0, 4])->where('za_appointment.branch_id', $branch_id)->whereMonth('za_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('za_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();
    
        $successAppointmentRate=$TotalCounts>0 ? ($completedCounts/$TotalCounts)*100 : 0;
        $failAppointmentRate=$TotalCounts>0 ? ($cancelledCounts/$TotalCounts)*100 : 0;
    
        // month
        $successAppointmentRateMonth=$TotalCountsMonth>0 ? ($completedCountsMonth/$TotalCountsMonth)*100 : 0;
        $failAppointmentRateMonth=$TotalCountsMonth>0 ? ($cancelledCountsMonth/$TotalCountsMonth)*100 : 0;

        // return $lead_flw_list;
        return view('content.sales.manage_followup.followup_list', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }

    public function closedFollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
         $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('za_appointment')
            ->select(
                'za_appointment.sno', 'za_appointment.convo_message', 'za_appointment.app_score', 'za_appointment.lead_id as ld_name_id', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status as appointment_status', 'za_appointment.reason as appointment_reason', 'za_appointment.created_by as staff_id', 'za_lead.lead_name', 'za_lead.lead_email_id', 'za_lead.lead_gender', 'za_lead.lead_id', 'za_lead.status as lead_status', 'za_staff.staff_name')
            ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
            ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
            ->where('za_appointment.status', 4)
            ->whereNotIn('za_lead.status', [2, 5, 6, 7])
            ->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list = $lead_flw_list->orderBy('za_appointment.sno', 'desc')->paginate($perpage);

        $todayFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.progressed', null)->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // return $lead_flw_list;
        return view('content.sales.manage_followup.closed_followup_list', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'staff_fill'              => $staff_fill,

        ]);
    }

    public function rescheduleFollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
         $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('za_appointment')
            ->select(
                'za_appointment.sno', 'za_appointment.reason', 'za_appointment.lead_id as ld_name_id', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status as appointment_status', 'za_appointment.reason as appointment_reason', 'za_appointment.created_by as staff_id', 'za_lead.lead_name', 'za_lead.lead_mobile', 'za_lead.lead_email_id', 'za_lead.lead_gender', 'za_lead.lead_id', 'za_lead.status as lead_status', 'za_staff.staff_name')
            ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
            ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
            ->where('za_appointment.status', 1)
            ->where('za_appointment.progressed', 2)
            ->whereNotIn('za_lead.status', [2, 5, 6, 7])
            ->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list = $lead_flw_list->orderBy('za_appointment.sno', 'desc')->paginate($perpage);

        $todayFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.progressed', null)->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // return $lead_flw_list;
        return view('content.sales.manage_followup.reschedule_followup', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'staff_fill'              => $staff_fill,

        ]);
    }
    public function unfollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
         $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('za_appointment')
            ->select(
                'za_appointment.sno', 'za_appointment.progressed', 'za_appointment.lead_id as ld_name_id', 'za_appointment.appointment_date', 'za_appointment.appointment_time', 'za_appointment.status as appointment_status', 'za_appointment.reason as appointment_reason', 'za_appointment.created_by as staff_id', 'za_lead.lead_name', 'za_lead.lead_email_id', 'za_lead.lead_mobile', 'za_lead.lead_gender', 'za_lead.lead_id', 'za_lead.status as lead_status', 'za_staff.staff_name')
            ->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')
            ->join('za_staff', 'za_appointment.created_by', '=', 'za_staff.sno')
            ->where('za_appointment.status', 1)
            // ->where('za_appointment.progressed', null)
            ->whereNotIn('za_lead.status', [2, 5, 6, 7])
            ->where('za_appointment.appointment_date', '<=', date('y-m-d'))
            ->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list      = $lead_flw_list->orderBy('za_appointment.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 4)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.status', 1)->where('za_appointment.progressed', 2)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('za_appointment')->join('za_lead', 'za_appointment.lead_id', '=', 'za_lead.sno')->where('za_appointment.progressed', null)->where('za_appointment.status', 1)->whereNotIn('za_lead.status', [2, 5, 6, 7])->where('za_appointment.branch_id', $branch_id)->where('za_appointment.appointment_date', '<=', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('za_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

       $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    // return $lead_flw_list;
      return view('content.sales.manage_followup.unfollowup', [
      'lead_flw_list'           => $lead_flw_list,
      'todayFollowupCount'      => $todayFollowupCount,
      'closedFollowupCount'     => $closedFollowupCount,
      'rescheduleFollowupCount' => $rescheduleFollowupCount,
      'unFollowupCount'         => $unFollowupCount,
      'perpage'                 => $perpage,
      'lead_fill'               => $lead_fill,
      'staff_fill'              => $staff_fill,
      'followupReasonList'             => $followupReasonList,
 
    ]);
    }

}
