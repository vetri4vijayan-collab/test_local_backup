<?php

namespace App\Http\Controllers\sales\lead;


use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\PotentialReasonModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\GeneralSettingsModel;
use App\Models\FollowupReasonModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use DateTime;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\AppointmentModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;

class DailyCallLead extends Controller
{

  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $pending_followUp_fill   = $request->pending_followUp_fill ?? '';
    $lead_fill   = $request->lead_fill ?? '';
    $branch_id = $request->user()->branch_id;
    $startTime = microtime(true);

    $leadall = DB::table('za_lead')
      ->select(
        'za_lead.created_at',
        'za_lead.sno',
        'latest_appointment.lead_id as followup_latest_id',
        'appointment_counts.lead_id as followup_id'
      )
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)
      ->where('za_lead.status', 0)->where('za_lead.internal_status', '!=', 1)
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                status,
                appointment_date,
                SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM za_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT
                    lead_id,
                    MAX(appointment_date) AS appointment_date
                FROM za_appointment
                GROUP BY lead_id
            )
        ) AS latest_appointment'),
        'za_lead.sno',
        '=',
        'latest_appointment.lead_id'
      )
      ->join('za_schedule_daily_call', 'za_lead.sno', '=', 'za_schedule_daily_call.lead_id')
      ->where('za_schedule_daily_call.status', 0)
      ->whereDate('za_schedule_daily_call.sch_date', '<=', now())
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                COUNT(*) as total_appointments
            FROM za_appointment
            GROUP BY lead_id
        ) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      );

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadall = $leadall->where('za_lead.created_by', $user_id);
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)
      // Do nothing as $leadall already includes all data
    }



    if ($lead_fill != '') {
      $leadall->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leadall       = $leadall->get();
    $follwup_count = 0;
    $not_follow_up_ids = [];
    // return $leadall;


    foreach ($leadall as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          // $lead_names[] = $singleLead->sno;
          $not_follow_up_ids[] = $singleLead->sno;
        }
      }
    }
    // Retrieve leads with joins and filters
    $leads = LeadModel::select(
      'za_schedule_daily_call.sno as sch_id',
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.dc_staff_id',
      'za_lead.inter_calls',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.dialed_count',
      'za_lead.document_send_count',
      'za_lead.incoming_count',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.sulekha_id',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',

      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'assgin.staff_name as assgin_staff',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_event_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM za_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM za_appointment

              GROUP BY lead_id
          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM za_appointment
          GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_schedule_daily_call', 'za_lead.sno', '=', 'za_schedule_daily_call.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->join('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->join('za_staff as assgin', 'za_schedule_daily_call.current_staff', '=', 'assgin.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_schedule_daily_call.status', 0)
      ->whereDate('za_schedule_daily_call.sch_date', '<=', now())
      ->where('za_lead.branch_id', $branch_id);
    if ($pending_followUp_fill == 1) {
      $leads->whereIn('za_lead.sno', $not_follow_up_ids);
    }
    // Add groupBy
    $leads = $leads->groupBy(
      'za_schedule_daily_call.sno',
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.incoming_count',
      'za_lead.dialed_count',
      'za_lead.created_by',
      'za_lead.dc_staff_id',
      'za_lead.sulekha_id',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.document_send_count',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.registered_date',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.inter_calls',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'assgin.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.lead_event_id',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_schedule_daily_call.current_staff', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data

      $leads = $leads;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }


    // Cursor Pagination for optimized results
    $leads = $leads->orderBy('za_lead.dc_date', 'asc')
      ->paginate($perpage);



    foreach ($leads as $singleLead) {
      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code
      $lead                 = DB::table('za_contact_book')
        ->where('phone_no', $singleLead->lead_mobile)
        ->orWhere('phone_no', $phoneWithCountryCode) // Check both formats
        ->orderBy('contact_book_id', 'desc')
        ->first();
      $singleLead->staff_id = $lead->staff_id ?? "0";
      $lead                 = DB::table('za_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $leadapp = DB::table('za_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      // Build the formatted difference string
      $parts = [];

      if ($years > 0) {
        $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      }
      if ($months > 0) {
        $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      }
      if ($days > 0 || empty($parts)) {
        // If all other parts are zero, still show "0 days"
        $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;

      $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('za_appointment')
        ->where('status', 1)
        ->where('appointment_date', '<=', $before48Hours)
        ->distinct()
        ->pluck('created_by')
        ->toArray();

      if (in_array($singleLead->created_by, $usersWithPendingAppointments)) {

        $singleLead->not_closed = 1;
      } else {
        $singleLead->not_closed = 0;
      }
    }


    // End timing
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;

    // Calculate the sum of app_score
    $sumAppScore = $leads->sum('total_app_score');



    // Transform the leads and add the sum of app_score to each lead
    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1)); // Only keeps and capitalizes the first letter
      $item->app_score = $sumAppScore; // Add sum of app_score to each lead
      return $item;
    });

    // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
    // Get the total count of leads
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])
      ->join('za_schedule_daily_call', 'za_lead.sno', '=', 'za_schedule_daily_call.lead_id')
      ->where('za_schedule_daily_call.status', 0)
      ->whereDate('za_schedule_daily_call.sch_date', '<=', now());
    if ($branch_id != 0) {
      $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalLeadCount = $totalLeadCounts->where('za_schedule_daily_call.current_staff', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();

    // return $totalLeadCount;
    // Get the count of leads for the current month
    $currentMonthLeadCounts = LeadModel::whereNotIn('za_lead.status', [2, 6])->where('za_lead.spam_verified', 0)->where('za_lead.is_dc', 1)
      ->whereDate('za_lead.dc_date', '<=', now())->where('za_lead.internal_status', 0);
    if ($branch_id != 0) {
      $currentMonthLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCounts = $currentMonthLeadCounts
      ->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'));
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $currentMonthLeadCount = $currentMonthLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $currentMonthLeadCount = $currentMonthLeadCounts->count();

    $totalCustomerCount = LeadModel::where('status', 4)->where('za_lead.is_dc', 1)
      ->whereDate('za_lead.dc_date', '<=', now())->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    // Get the count of leads for the current month
    $currentMonthCustomerCount = LeadModel::where('status', 4)->where('za_lead.is_dc', 1)
      ->whereDate('za_lead.dc_date', '<=', now())->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate the percentage
    $percentageover = 0;
    $percentagecurrentmonth = 0;
    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    // Format the percentage to 2 decimal places
    $percentageover = round($percentageover) . '%';
    $percentagecurrentmonth = round($percentagecurrentmonth) . '%';

    $rawLead = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'lead_mobile', 'za_lead_type.lead_type_name', 'za_lead_type.sno as lead_type_id', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
      ->where('za_raw_lead.status', 6)->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno')->orderBy('za_raw_lead.sno', 'desc');
    if ($branch_id != 0) {
      $rawLead->where('za_raw_lead.branch_id', $branch_id);
    }
    $pageConfigs = ['myLayout' => 'default'];

    $lead_type_fill = '';
    $lead_source_fill = '';
    $course_fill = '';
    $potential_type_fill = '';
    $lead_status_fill = '';
    $date_filter = '';
    $staff_fill = '';
    $lead_fill = '';
    $fin_yr_fill = '';


    $staff_filter_list = StaffModel::where('status', 0);
    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id);
    }
    $staff_filter_list = $staff_filter_list->where('department_id', 1)->orderBy('nick_name', 'ASC')->get();
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $course_type = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $PotentialType = LeadPotentialModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Lead_status_list = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();


    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_lead.is_dc', 1)
        ->whereDate('za_lead.dc_date', '<=', now())
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_lead.is_dc', 1)
        ->whereDate('za_lead.dc_date', '<=', now())
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();
    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();


    $leadall = DB::table('za_lead')
      ->select(
        'za_lead.created_at',
        'za_lead.sno',
        'latest_appointment.lead_id as followup_latest_id',
        'appointment_counts.lead_id as followup_id'
      )
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)
      ->where('za_lead.status', 0)->where('za_lead.internal_status', '!=', 1)
      ->where('za_lead.is_dc', 1)
      ->whereDate('za_lead.dc_date', '<=', now())
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                status,
                appointment_date,
                SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM za_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT
                    lead_id,
                    MAX(appointment_date) AS appointment_date
                FROM za_appointment
                GROUP BY lead_id
            )
        ) AS latest_appointment'),
        'za_lead.sno',
        '=',
        'latest_appointment.lead_id'
      )
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                COUNT(*) as total_appointments
            FROM za_appointment
            GROUP BY lead_id
        ) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      );

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadall = $leadall->where('za_lead.created_by', $user_id);
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)
      // Do nothing as $leadall already includes all data
    }

    // Execute the query
    $leadall = $leadall->get();

    // return $leadall;
    // vasanth

    $follwup_count = 0;
    $not_follow_up_ids = [];
    foreach ($leadall as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          // $lead_names[] = $singleLead->sno;
        }
      }
    }

    // return $lead_names;

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.is_dc', 1)
      ->whereDate('za_lead.dc_date', '<=', now())->where('za_lead.internal_status', '!=', 1)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    // return  $follwup_count;
    $monitor = DB::table('et_cronjob_monitor')
      ->where('sno', 18)
      ->first();

    // // Count latest open issues (status = 0) for customer category
    // $getDailyCount = DB::table('za_lead')
    //   ->where('za_lead.branch_id', $branch_id)
    //   ->where('za_lead.potential_verify', 1)
    //   ->where('za_lead.is_dc', 0)
    //   ->where('za_lead.status', 0);

    // if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
    //   // User can only view their own data
    //   $getDailyCount = $getDailyCount->where('za_lead.created_by', '=', $user_id);
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
    //   // User can view all data

    //   $getDailyCount = $getDailyCount;
    //   // return "global_lead";
    // } else {
    //   // No permission
    //   $getDailyCount = 0;
    // }
    // if (is_object($getDailyCount)) {
    //   $getDailyCount = $getDailyCount->get()->count();
    // }

    // $pb_counts = $getDailyCount;

    // Check Lead Basket Days Counts
    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $pb_counts = 0;
    $hot_lead_day = $genset->hotleadtoleadbasket;
    $now = Carbon::now();
    $today = Carbon::today();

    // Calculate additional hours for weekends/holidays
    $additional_days = 0;

    // Check weekends
    if ($today->isSunday() || $today->isMonday()) {
      $additional_days += 1;
    }

    // Check holidays - single optimized query
    $beforeHours = $now->copy()->subDays($hot_lead_day + $additional_days);
    $holiday_count = DB::table('za_holiday')
      ->whereBetween('hol_date', [$beforeHours->toDateString(), $today->toDateString()])
      ->count();

    $additional_days += $holiday_count;

    // Calculate final cutoff date
    $before_date = Carbon::now()->subDays($hot_lead_day + $additional_days)->toDateString();

    $pb_counts = DB::table('za_lead')
      ->leftJoin('za_branch', 'za_lead.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_appointment', function ($join) use ($before_date) {
        $join->on('za_lead.sno', '=', 'za_appointment.lead_id')
          ->whereBetween('za_appointment.appointment_date', [$before_date, Carbon::today()->toDateString()]);
      })
      ->where('za_branch.branch_type', 1)
      ->whereNotIn('za_lead.lead_status_id', [1, 3])
      ->where('za_lead.is_hot_lead', 0)
      ->where('za_lead.is_potential', 1)
      ->where('za_lead.potential_verify', 1)
      ->where(function ($query) {
        $query->whereNull('is_dc')->orWhere('is_dc', 0);
      })
      ->where('za_lead.spam_verified', 0)
      ->where('za_lead.drop_verified', 0)
      ->whereNotIn('za_lead.status', [10, 4])
      ->whereNull('za_appointment.lead_id')
      ->count();

    return view('content.sales.lead.daily_calls_list', compact(
      'leads',
      'totalLeadCount',
      'leadOriginalCount',
      'follwup_count',
      'totalFollowup',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'monitor',
      'pb_counts',

      'perpage',
      'currentMonthLeadCount',
      'percentageover',
      'percentagecurrentmonth',
      'pageConfigs',
      'course_type',
      'CourseCategory',
      'lead_type_fill',
      'lead_source_fill',
      'course_fill',
      'lead',
      'potential_type_fill',
      'PotentialType',
      'date_filter',
      'lead_status_fill',
      'staff_filter_list',
      'staff_fill',
      'login_branch_data',
      'Lead_status_list',
      'fin_yr_fill',
      'reasonList',
      'reasonList_internal',
      'leadbankCount',
      'followupReasonList',
      'reasonList_drop'

    ));
  }
  public function Appointment(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }

    $lead_id          = $request->lead_id;
    $appointment_time = $request->appointment_time;
    $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    // Generate appointment_id
    $last_appointment = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    if (!$last_appointment) {
      $year = substr(date("y"), -2);
      $appointment_id = "AP-0001/" . $year;
    } else {
      $data = $last_appointment->appointment_id;
      $slice = explode("/", $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);
      $next_number = (int)$result + 1;
      $year = substr(date("y"), -2);
      $appointment_id = sprintf("AP-%04d", $next_number) . '/' . $year;
    }
    $user_id            = $request->user()->user_id;
    $branch_id          = $request->user()->branch_id;
    // Save appointment
    $appointment = new AppointmentModel();
    $appointment->appointment_id   = $appointment_id;
    $appointment->lead_id          = $lead_id;
    $appointment->appointment_date = $appointment_date;
    $appointment->appointment_time = $appointment_time;
    $appointment->branch_id        = $branch_id;
    $appointment->status           = 1;
    $appointment->created_by           =  $user_id;
    $appointment->updated_by           = $user_id;
    $appointment->save();

    if ($appointment) {

      session()->flash('toastr', [
        'type'    => 'success',
        'message' => 'Appointment added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Could not add the Appointment!'
      ]);
    }

    return redirect('sales/daily_call_lead');
  }

  public function AppointmentUpdate($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      //   return $request;
      $progressed         = $request->progressed;
      $reason_appt        = $request->reason;
      $appointment_time   = $request->appointment_time;
      $app_score          = $request->app_score;
      $hot_lead           = $request->hot_lead;
      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  AppointmentModel::where('lead_id', $id)->orderBy('sno', 'desc')->first();

        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();

        if ($upd_lead) {
          // Update Lead
          $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();
          $LeadData->lead_status_id        = 2;
          $LeadData->drop_verified         = 0;
          $LeadData->drop_tl_verified      = 0;
          $LeadData->spam_verified         = 0;
          $LeadData->spam_tl_verified      = 0;
          $LeadData->internal_status       = 0;
          $LeadData->transfer_status       = 1;
          $LeadData->potential_verify      = 0;
          $LeadData->is_potential          = 0;
          $LeadData->is_dc                 = 0;
          $LeadData->update();

          DB::table('za_schedule_daily_call')
            ->where('lead_id', $upd_lead->lead_id)
            ->update([
              'status'      => 1,
              'updated_at'  => now()
            ]);


          // Create or Update Daily Call
          $dailyCall = DB::table('za_sales_dailly_call')
            ->where('branch_id', $LeadData->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user_id)
            ->whereDate('dc_date', $LeadData->dc_date)
            ->first();

          if ($dailyCall) {
            // Update existing record
            DB::table('za_sales_dailly_call')
              ->where('sno', $dailyCall->sno)
              ->update([
                'dc_count'    => $dailyCall->dc_count + 1,
                'updated_by'  => $user_id,
                'updated_at'  => now()
              ]);
          } else {
            // Create new record
            DB::table('za_sales_dailly_call')->insert([
              'branch_id'   => $LeadData->branch_id,
              'staff_id'    => $user_id,
              'dc_date'     => $LeadData->dc_date,
              'dc_count'    => 1,
              'status'      => 1,
              'created_by'  => $user_id,
              'updated_by'  => $user_id,
              'created_at'  => now(),
              'updated_at'  => now()
            ]);
          }

          session()->flash('toastr', [
            'type'    => 'success',
            'message' => 'Appointment added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Could not add the Appointment!'
          ]);
        }
        //****************** */ Update Staff Sales Person Points

      } else {
        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

        $upd_app = AppointmentModel::where('lead_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->whereNull('progressed')
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();

        if ($upd_app) {
          $upd_app->status = 5;
          $upd_app->update();
        }



        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();

        if ($upd_lead) {
          // Update Lead
          $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();
          $LeadData->lead_status_id        = 2;
          $LeadData->drop_verified         = 0;
          $LeadData->drop_tl_verified      = 0;
          $LeadData->spam_verified         = 0;
          $LeadData->spam_tl_verified      = 0;
          $LeadData->internal_status       = 0;
          $LeadData->transfer_status       = 1;
          $LeadData->potential_verify      = 0;
          $LeadData->is_potential          = 0;
          $LeadData->is_dc                 = 0;
          $LeadData->update();


          DB::table('za_schedule_daily_call')
            ->where('lead_id', $upd_lead->lead_id)
            ->update([
              'status'      => 2,
              'updated_at'  => now()
            ]);
          // Create or Update Daily Call
          $dailyCall = DB::table('za_sales_dailly_call')
            ->where('branch_id', $LeadData->branch_id)
            ->where('status', 1)
            ->where('staff_id', $user_id)
            ->whereDate('dc_date', $LeadData->dc_date)
            ->first();

          if ($dailyCall) {
            // Update existing record
            DB::table('za_sales_dailly_call')
              ->where('sno', $dailyCall->sno)
              ->update([
                'dc_count'    => $dailyCall->dc_count + 1,
                'updated_by'  => $user_id,
                'updated_at'  => now()
              ]);
          } else {
            // Create new record
            DB::table('za_sales_dailly_call')->insert([
              'branch_id'   => $LeadData->branch_id,
              'staff_id'    => $user_id,
              'dc_date'     => $LeadData->dc_date,
              'dc_count'    => 1,
              'status'      => 1,
              'created_by'  => $user_id,
              'updated_by'  => $user_id,
              'created_at'  => now(),
              'updated_at'  => now()
            ]);
          }

          session()->flash('toastr', [
            'type'    => 'success',
            'message' => 'Appointment added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Could not add the Appointment!'
          ]);
        }

        if ($upd_lead) {
          $result = response([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
          ], 200);
        } else {
          $result = response([
            'status'    => 401,
            'message'   => 'Incorrect format input feilds',
            'error_msg' => 'Incorrect format input feilds',
            'data'      => null,
          ], 401);
        }
        return $result;
      }
    }
  }
  public function SalesList(Request $request)
  {
    $SalesList = StaffModel::select(
      'za_staff.staff_name',
      'za_staff.staff_image',
      'za_staff.sno',
      'za_staff.date_of_joining',
      'za_staff.call_check',
      'za_staff.call_count',
      'za_job_position.job_position_name'
    )
      ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.department_id', 1)
      ->where('za_staff.status', 0)
      ->where('za_staff.branch_id', $request->user()->branch_id)
      ->get();

    return response()->json($SalesList);
  }
  public function SalesListUpdate(Request $request)
  {
    foreach ($request->staff_data as $staff) {

      $staffRecord = StaffModel::where('sno', $staff['staff_id'])->first();

      if ($staffRecord) {
        $staffRecord->call_check = $staff['checked'];
        $staffRecord->call_count = $staff['call_count'];
        $staffRecord->save();
      }
    }

    return response()->json([
      'status' => true,
      'message' => 'Daily Call Setup Updated Successfully!'
    ]);
  }
  public function updateSwitch(Request $request)
  {
    $newStatus = $request->status;

    // Example: update in settings table
    DB::table('et_cronjob_monitor')
      ->where('sno', 18)
      ->update(['status' => $newStatus]);

    return response()->json([
      'status' => true,
      'new_status' => $newStatus
    ]);
  }
  public function daily_call_history(Request $request)
  {
    // If only staff list is requested
    if ($request->has('staff_list_only') && $request->staff_list_only == 1) {
      $staffList = DB::table('za_staff')
        ->select('sno', 'staff_name')
        ->where('department_id', 1)
        ->where('branch_id', $request->user()->branch_id)
        ->where('status', 0)
        ->orderBy('staff_name')
        ->get();

      return response()->json([
        'status' => true,
        'staff_list' => $staffList
      ]);
    }

    $query = DB::table('za_schedule_daily_call')
      ->select(
        'za_schedule_daily_call.*',
        'za_staff.staff_name as sales_staff_name',
        'assgin.staff_name as assign_staff',
        'za_lead.lead_name',
        'za_lead.lead_mobile',
        'za_appointment.convo_message'
      )
      ->leftJoin('za_lead', 'za_schedule_daily_call.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_appointment', 'za_schedule_daily_call.app_id', '=', 'za_appointment.sno')
      ->leftJoin('za_staff', 'za_schedule_daily_call.previous_staff', '=', 'za_staff.sno')
      ->join('za_staff as assgin', 'za_schedule_daily_call.current_staff', '=', 'assgin.sno')
      ->whereDate('za_schedule_daily_call.sch_date', '<=', now());

    if ($request->has('LeadFilter') && !empty($request->LeadFilter)) {
      $query->where(function ($q) use ($request) {
        $q->where('za_lead.lead_name',  'LIKE', "%{$request->LeadFilter}%")
          ->orWhere('za_lead.lead_mobile',  'LIKE', "%{$request->LeadFilter}%")
          ->orWhere('za_lead.lead_id',  'LIKE', "%{$request->LeadFilter}%");
      });
    }
    // Apply staff filter if provided
    if ($request->has('staff_id') && !empty($request->staff_id)) {
      $query->where(function ($q) use ($request) {
        $q->where('za_schedule_daily_call.previous_staff', $request->staff_id)
          ->orWhere('za_schedule_daily_call.current_staff', $request->staff_id);
      });
    }

    // Paginate results
    $perPage = $request->get('per_page', 10);
    $data = $query->orderBy('za_schedule_daily_call.sch_date', 'desc')->paginate($perPage);

    return response()->json([
      'status' => true,
      'data' => $data->items(),
      'pagination' => [
        'current_page' => $data->currentPage(),
        'last_page' => $data->lastPage(),
        'per_page' => $data->perPage(),
        'total' => $data->total(),
        'from' => $data->firstItem(),
        'to' => $data->lastItem(),
      ],
      'message' => 'Daily Call History Fetch Successfully!'
    ]);
  }


  //   public function getDailyPerformance(Request $request)
  //   {
  //     $type = $request->type ?? 'day';
  //     $date = $request->date;
  //     $branchId = $request->user()->branch_id;

  //     $startDate = null;
  //     $endDate = null;
  //     $defaultTarget = 0; // Default for daily

  //     if ($type == 'day') {
  //       $date = $date
  //         ? Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d')
  //         : Carbon::today()->format('Y-m-d');
  //       $startDate = $date;
  //       $endDate = $date;
  //     } else {

  //       $date = $date
  //         ? Carbon::createFromFormat('F Y', $date)->format('Y-m')
  //         : Carbon::now()->format('Y-m');

  //       $monthDate = Carbon::createFromFormat('Y-m', $date);

  //       $startDate = $monthDate->copy()->startOfMonth()->format('Y-m-d');

  //       $endDate = $monthDate->isCurrentMonth()
  //         ? Carbon::today()->format('Y-m-d')
  //         : $monthDate->copy()->endOfMonth()->format('Y-m-d');

  //       $defaultTarget = 0;
  //     }

  //     // Get all staff members
  //     $staff = DB::table('za_staff as s')
  //       ->where('s.department_id', 1)
  //       ->where('s.status', 0)
  //       ->where('s.branch_id', $branchId)
  //       ->leftJoin('za_job_position as jp', 'jp.sno', '=', 's.position_role')
  //       ->select(
  //         's.sno as staff_id',
  //         's.staff_name',
  //         's.staff_image',
  //         'jp.job_position_name',
  //         's.call_check',
  //         's.call_count'
  //       )->get();

  //     // Get schedule targets (aggregated by staff)
  //     $scheduleTargets = DB::table('za_schedule_daily_call')
  //       ->whereIn('current_staff', $staff->pluck('staff_id'))
  //       ->whereBetween('sch_date', [$startDate, $endDate])
  //     //   ->where('status', '!=', 2)

  //       ->select('current_staff', DB::raw('COUNT(*) as schedule_count'))
  //       ->groupBy('current_staff')
  //       ->get()
  //       ->keyBy('current_staff');

  //     // Get actual call counts
  //     $callCounts = DB::table('za_sales_dailly_call')
  //       ->whereIn('staff_id', $staff->pluck('staff_id'))
  //       ->whereBetween('dc_date', [$startDate, $endDate])
  //       ->select(
  //         'staff_id',
  //         DB::raw('COUNT(DISTINCT failer_date_time) as failure_count'),
  //         DB::raw('MAX(reason) as reason'),
  //         DB::raw('SUM(dc_count) as total_calls')
  //       )
  //       ->groupBy('staff_id')
  //       ->get()
  //       ->keyBy('staff_id');

  //     // Calculate performance for each staff
  //     $data = $staff->map(function ($row) use ($scheduleTargets, $callCounts, $defaultTarget, $type) {

  //       // Get target from schedule or use fallback
  //       $target = $scheduleTargets->get($row->staff_id)?->schedule_count ?? 0;
  //       // Get actual calls made
  //       $row->total_calls = $callCounts->get($row->staff_id)?->total_calls ?? 0;
  //       $row->failure_count = $callCounts->get($row->staff_id)?->failure_count ?? 0;
  //       $row->reason = $callCounts->get($row->staff_id)?->reason ?? 0;

  //       // Calculate percentage (ensure it's not negative and cap at 100)
  //       $percentage = $target > 0
  //         ? round(min(($row->total_calls / $target) * 100, 100))
  //         : 0;

  //       // Determine performance level
  //      if ($percentage == 0) {
  //         $performance = "Waiting for Closing";
  //       } elseif ($percentage <= 60) {
  //         $performance = "Worst Closed";
  //       } elseif ($percentage <= 90) {
  //         $performance = "Moderate Closed";
  //       } else {
  //         $performance = "Perfect Closed";
  //       }

  //       if ($target == 0) {
  //         $performance = "Target Not Set";
  //       }

  //       // Add calculated fields
  //       $row->call_count = $target;
  //       $row->percentage = $percentage;
  //       $row->performance = $performance;

  //       return $row;
  //     });

  //     return response()->json($data);
  //   }

  public function getDailyPerformance(Request $request)
  {
    $type = $request->type ?? 'day';
    $date = $request->date;
    $branchId = $request->user()->branch_id;
    $startDate = null;
    $endDate = null;
    $currentDay = null;
    $totalDaysInMonth = null;
    $defaultTarget = 0; // Default for daily
    if ($type == 'day') {
      $date = $date
        ? Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d')
        : Carbon::today()->format('Y-m-d');
      $startDate = $date;
      $endDate = $date;
    } else {
      $date = $date
        ? Carbon::createFromFormat('F Y', $date)->format('Y-m')
        : Carbon::now()->format('Y-m');
      $monthDate = Carbon::createFromFormat('Y-m', $date);
      $startDate = $monthDate->copy()->startOfMonth()->format('Y-m-d');
      $endDate = $monthDate->isCurrentMonth()
        ? Carbon::yesterday()->format('Y-m-d')
        : $monthDate->copy()->endOfMonth()->format('Y-m-d');
      $defaultTarget = 0;


      $currentDay = $monthDate->isCurrentMonth()
        ? Carbon::today()->day
        : $monthDate->daysInMonth;

      $totalDaysInMonth = $monthDate->daysInMonth;
    }
    // Get all staff members
    $staff = DB::table('za_staff as s')
      ->where('s.department_id', 1)
      ->where('s.status', 0)
      ->where('s.branch_id', $branchId)
      ->leftJoin('za_job_position as jp', 'jp.sno', '=', 's.position_role')
      ->select(
        's.sno as staff_id',
        's.staff_name',
        's.staff_image',
        'jp.job_position_name',
        's.call_check',
        's.call_count'
      )->get();
    // Get schedule targets (aggregated by staff)
    $scheduleTargets = DB::table('za_schedule_daily_call')
      ->whereIn('current_staff', $staff->pluck('staff_id'))
      ->whereBetween('sch_date', [$startDate, $endDate])
      ->where('status', '!=', 4)
      ->select('current_staff', DB::raw('COUNT(*) as schedule_count'))
      ->groupBy('current_staff')
      ->get()
      ->keyBy('current_staff');
    // Get actual call counts
    $callCounts = DB::table('za_sales_dailly_call')
      ->whereIn('staff_id', $staff->pluck('staff_id'))
      ->whereBetween('dc_date', [$startDate, $endDate])
      ->select(
        'staff_id',
        DB::raw('COUNT(DISTINCT failer_date_time) as failure_count'),
        DB::raw('MAX(reason) as reason'),
        DB::raw('SUM(dc_count) as total_calls')
      )
      ->groupBy('staff_id')
      ->get()
      ->keyBy('staff_id');
    // Calculate performance for each staff
    $data = $staff->map(function ($row) use ($scheduleTargets, $callCounts, $defaultTarget, $type, $date, $totalDaysInMonth) {
      // Get target from schedule or use fallback
      $target = $scheduleTargets->get($row->staff_id)?->schedule_count ?? 0;
      // Get actual calls made
      $row->total_calls = $callCounts->get($row->staff_id)?->total_calls ?? 0;
      $row->failure_count = $callCounts->get($row->staff_id)?->failure_count ?? 0;
      $row->reason = $callCounts->get($row->staff_id)?->reason ?? 0;
      // Calculate percentage (ensure it's not negative and cap at 100)
      // if ($type == 'day') {
      //   $percentage = $target > 0
      //     ? round(min(($row->total_calls / $target) * 100, 100))
      //     : 0;
      // } else {
      //   $dailyTarget = $target / $totalDaysInMonth;
      //   $targetTillToday = $dailyTarget * $currentDay;

      //   $percentage = $targetTillToday > 0
      //     ? round(min(($row->total_calls / $targetTillToday) * 100, 100))
      //     : 0;
      // }
      $percentage = $target > 0
        ? round(min(($row->total_calls / $target) * 100, 100))
        : 0;



      // Determine performance level
      if ($percentage == 0) {
        $performance = "Waiting for Closing";
      } elseif ($percentage <= 60) {
        if ($date == Carbon::today()->format('Y-m-d')) {
          $performance = "On Progress";
        } else {
          $performance = "Worst Closed";
        }
      } elseif ($percentage <= 90) {
        $performance = "Moderate Closed";
      } else {
        $performance = "Perfect Closed";
      }
      if ($target == 0) {
        $performance = "Target Not Set";
      }
      // Add calculated fields
      $row->call_count = $target;
      $row->percentage = $percentage;
      $row->performance = $performance;
      return $row;
    });
    return response()->json($data);
  }



  public function daily_call_log(Request $request)
  {
    // If only staff list is requested
    if ($request->has('staff_list_only') && $request->staff_list_only == 1) {
      $staffList = DB::table('za_staff')
        ->select('sno', 'staff_name', 'nick_name')
        ->where('status', 0)
        ->where('department_id', 1)
        ->orderBy('staff_name')
        ->get();

      return response()->json([
        'status' => true,
        'staff_list' => $staffList
      ]);
    }


    $type = $request->type ?? 'day';
    $date = $request->date;

    $startDate = null;
    $endDate   = null;

    if ($type == 'day') {

      $date = $date
        ? Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d')
        : Carbon::today()->format('Y-m-d');
    } else {

      $date = $date
        ? Carbon::createFromFormat('M-Y', $date)->format('Y-m')
        : Carbon::now()->format('Y-m');

      $monthDate = Carbon::createFromFormat('Y-m', $date);

      $startDate = $monthDate->copy()->startOfMonth();

      $endDate = $monthDate->isCurrentMonth()
        ? Carbon::today()
        : $monthDate->copy()->endOfMonth();
    }

    $query = DB::table('za_schedule_daily_call')
      ->select(
        'za_schedule_daily_call.*',
        'za_staff.staff_name as sales_staff_name',
        'assgin.staff_name as assign_staff',
        'za_lead.lead_name',
        'za_lead.lead_mobile',
        'za_appointment.convo_message',
        'za_appointment.appointment_date',
        'za_appointment.appointment_time'
      )
      ->leftJoin('za_lead', 'za_schedule_daily_call.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_appointment', 'za_schedule_daily_call.app_id', '=', 'za_appointment.sno')
      ->leftJoin('za_staff', 'za_schedule_daily_call.previous_staff', '=', 'za_staff.sno')
      ->join('za_staff as assgin', 'za_schedule_daily_call.current_staff', '=', 'assgin.sno');

    // Apply staff filter if provided
    if ($request->has('staff_id') && !empty($request->staff_id)) {
      $staffId = $request->staff_id;
      $query->where(function ($q) use ($staffId) {
        $q->where('za_schedule_daily_call.current_staff', $staffId);
      });
    }

    if ($type == 'day') {

      $query->whereDate('za_schedule_daily_call.sch_date', $date);
    } else {

      $query->whereBetween('za_schedule_daily_call.sch_date', [
        $startDate->format('Y-m-d'),
        $endDate->format('Y-m-d')
      ]);
    }

    // Clone the query for counts
    $totalQuery = clone $query;
    $inprogressQuery = clone $query;
    $completedQuery = clone $query;
    $incompleteQuery = clone $query;
    $Reset_callQuery = clone $query;

    // Paginate results
    $perPage = $request->get('per_page', 10);
    $data = $query->orderBy('za_schedule_daily_call.sch_date', 'desc')->paginate($perPage);

    $data->getCollection()->transform(function ($item) use ($type, $date, $startDate, $endDate) {

      $item->sch_date = $item->sch_date
        ? date('d-M-Y', strtotime($item->sch_date))
        : 'N/A';

      $lead_mobile = $item->lead_mobile;
      $item->call_chk = false;
      if ($lead_mobile) {

        $normalizedPhoneNo    = ltrim($lead_mobile, '0');   // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $query = DB::table('za_call_tracker')
          ->where(function ($query) use ($lead_mobile, $phoneWithCountryCode) {
            $query->where('customer_phone_no', $lead_mobile)
              ->orWhere('customer_phone_no', $phoneWithCountryCode);
          })
          ->where('branch_staff_id', $item->current_staff);

        if ($type == 'day') {

          $query->whereDate('call_start_date', $date);
        } else {

          $query->whereBetween('call_start_date', [
            $startDate->format('Y-m-d'),
            $endDate->format('Y-m-d')
          ]);
        }

        $call_chk = $query->orderBy('sno', 'desc')->exists();

        $item->call_chk = $call_chk;
      }

      return $item;
    });
    // Get counts
    $Total_call     = $totalQuery->count();
    $Inprogress_call = $inprogressQuery->where('za_schedule_daily_call.status', 0)->count();
    $Completed_call = $completedQuery->where('za_schedule_daily_call.status', 1)->count();
    $Incomplete_call = $incompleteQuery->where('za_schedule_daily_call.status', 3)->count();
    $Reset_call      = $Reset_callQuery->where('za_schedule_daily_call.status', 4)->count();
    return response()->json([
      'status' => true,
      'data' => $data->items(),
      'Total_call' => $Total_call,
      'Completed_call' => $Completed_call,
      'Inprogress_call' => $Inprogress_call,
      'Reset_call' => $Reset_call,
      'pagination' => [
        'current_page' => $data->currentPage(),
        'last_page' => $data->lastPage(),
        'per_page' => $data->perPage(),
        'total' => $data->total(),
        'from' => $data->firstItem(),
        'to' => $data->lastItem(),
      ],
      'message' => 'Daily Call Log Fetch Successfully!'
    ]);
  }
  public function ResetDailyCall(Request $request, $id)
  {
    $date = Carbon::createFromFormat('d-F-Y', $request->date)->format('Y-m-d');

    $sch = DB::table('za_schedule_daily_call')
      ->where('current_staff', $id)
      ->where('status', 0)
      ->where('sch_date', $date)
      ->get();

    if ($sch->isEmpty()) {
      return response([
        'status' => 404,
        'message' => "Could not find the daily call schedule to reset.",
      ], 404);
    }

    DB::transaction(function () use ($sch) {

      foreach ($sch as $row) {

        DB::table('za_lead')
          ->where('sno', $row->lead_id)
          ->update([
            'is_dc' => 0,
            'updated_at' => now()
          ]);

        DB::table('za_schedule_daily_call')
          ->where('sno', $row->sno)
          ->update([
            'status' => 4,
            'updated_at' => now()
          ]);
      }
    });

    return response([
      'status' => 200,
      'message' => 'Successfully reset the daily call schedule!',
    ], 200);
  }
  // ALTER TABLE `za_staff` ADD `call_check` INT NULL DEFAULT NULL AFTER `status`, ADD `call_count` INT NULL DEFAULT NULL AFTER `call_check`;
  // ALTER TABLE `za_schedule_daily_call` ADD `app_id` INT NULL DEFAULT NULL AFTER `current_staff`;
}
