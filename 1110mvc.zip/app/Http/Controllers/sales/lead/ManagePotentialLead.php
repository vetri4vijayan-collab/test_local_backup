<?php

namespace App\Http\Controllers\sales\lead;


use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\PotentialReasonModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\FollowupReasonModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\StaffpointsModel;
use App\Models\AppointmentModel;
use Illuminate\Support\Facades\Validator;
use DateTime;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadTransferLogModel;
use Carbon\Carbon;

class ManagePotentialLead extends Controller
{

  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $lead_fill   = $request->lead_fill ?? '';
    $filter_on   = $request->filter_on ? true : false;
    $staff_fill   = $request->staff_fill ?? '';
    $startTime = microtime(true);
    // Retrieve leads with joins and filters
    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.created_at',
      'za_lead.created_by',
      'za_lead.inter_calls',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.dialed_count',
      'za_lead.document_send_count',
      'za_lead.incoming_count',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
      'za_lead.sulekha_id',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',

      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.potentail_reason',
      'za_lead.potential_comments',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_event_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM za_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM za_appointment

              GROUP BY lead_id
          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM za_appointment
          GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      //   ->leftJoin('za_lead_appointment', 'za_lead.sno', '=', 'za_lead_appointment.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
      ->where('za_lead.potential_verify', 1)
      ->where('za_lead.is_dc', 0)
      ->where('za_lead.branch_id', $branch_id)
      ->whereIn('za_lead.status', [0]);

    if ($staff_fill != '') {
      $leads->where('za_lead.created_by', $staff_fill);
    }

    if ($lead_fill != '') {
      // return 'ho';
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.incoming_count',
      'za_lead.dialed_count',
      'za_lead.created_by',
      'za_lead.sulekha_id',
      'za_lead.outgoing_count',
      'za_lead.missed_reject_count',
      'za_lead.spam_verified',
      'za_lead.drop_verified',
      'za_lead.spam_tl_verified',
      'za_lead.drop_tl_verified',
       'za_lead.potentail_reason',
      'za_lead.potential_comments',
      'za_lead.document_send_count',
      'za_lead.phone_verify_status',
      'za_lead.phone_verify_content',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.website_id',
      'za_lead.call_tracker_id',
      'za_lead.registered_date',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.inter_calls',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.lead_event_id',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leads = $leads->where('za_lead.created_by', $user_id)->where('za_lead.wallet_status', 0)
        ->where('za_lead.drop_verified', 0)
        ->where('za_lead.spam_verified', 0);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data

      $leads = $leads;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }


    // Cursor Pagination for optimized results
    $leads = $leads->orderBy('za_lead.registered_date', 'desc')
      ->paginate($perpage);

    foreach ($leads as $singleLead) {
      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code
      $lead                 = DB::table('za_contact_book')
        ->where('phone_no', $singleLead->lead_mobile)
        ->orWhere('phone_no', $phoneWithCountryCode) // Check both formats
        ->orderBy('contact_book_id', 'desc')
        ->first();
      $singleLead->staff_id = $lead->staff_id ?? "0";
      $lead                 = DB::table('za_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $leadapp = DB::table('za_lead_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->lead_appointment_status = $leadapp->appointment_status ?? "0";
      $singleLead->appointment_lead_id = $leadapp->lead_id ?? "0";
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day         = false;
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
      $registeredDate = Carbon::parse($singleLead->registered_date);
      $diff = $registeredDate->diff(Carbon::now());

      $years = $diff->y;
      $months = $diff->m;
      $days = $diff->d;

      // Build the formatted difference string
      $parts = [];

      if ($years > 0) {
        $parts[] = "{$years} year" . ($years > 1 ? 's' : '');
      }
      if ($months > 0) {
        $parts[] = "{$months} month" . ($months > 1 ? 's' : '');
      }
      if ($days > 0 || empty($parts)) {
        // If all other parts are zero, still show "0 days"
        $parts[] = "{$days} day" . ($days > 1 ? 's' : '');
      }

      $singleLead->formattedDifference = implode(' and ', $parts);
      $singleLead->formattedDayDifference = $days;

      $before48Hours   = Carbon::now()->subHours(48);
      $usersWithPendingAppointments = DB::table('za_appointment')
        ->where('status', 1)
        ->where('appointment_date', '<=', $before48Hours)
        ->distinct()
        ->pluck('created_by')
        ->toArray();

      if (in_array($singleLead->created_by, $usersWithPendingAppointments)) {

        $singleLead->not_closed = 1;
      } else {
        $singleLead->not_closed = 0;
      }
    }


    // End timing
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;

    // Calculate the sum of app_score
    $sumAppScore = $leads->sum('total_app_score');



    // Transform the leads and add the sum of app_score to each lead
    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1)); // Only keeps and capitalizes the first letter
      $item->app_score = $sumAppScore; // Add sum of app_score to each lead
      return $item;
    });

    // Continue with other operations and calculations for totalLeadCount, percentage calculations, etc.
    // Get the total count of leads
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.potential_verify', 1);
    if ($branch_id != 0) {
      $totalLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $totalLeadCount = $totalLeadCounts->count();
    // return $totalLeadCount;
    // Get the count of leads for the current month
    $currentMonthLeadCounts = LeadModel::whereNotIn('za_lead.status', [2, 6])->where('za_lead.spam_verified', 0)->where('za_lead.potential_verify', 1)->where('za_lead.internal_status', 0);
    if ($branch_id != 0) {
      $currentMonthLeadCounts->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCounts = $currentMonthLeadCounts
      ->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'));
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $currentMonthLeadCount = $currentMonthLeadCounts->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $currentMonthLeadCount = $currentMonthLeadCounts->count();

    $totalCustomerCount = LeadModel::where('status', 4)->where('za_lead.potential_verify', 1)->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    // Get the count of leads for the current month
    $currentMonthCustomerCount = LeadModel::where('status', 4)->where('za_lead.potential_verify', 1)->where('za_lead.registered_date', '!=', 0);
    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate the percentage
    $percentageover = 0;
    $percentagecurrentmonth = 0;
    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    // Format the percentage to 2 decimal places
    $percentageover = round($percentageover) . '%';
    $percentagecurrentmonth = round($percentagecurrentmonth) . '%';

    $rawLead = RawLeadModel::select('za_raw_lead.sno', 'za_raw_lead.lead_name', 'za_raw_lead.lead_gender', 'za_raw_lead.lead_dob', 'za_raw_lead.lead_email_id', 'lead_mobile', 'za_lead_type.lead_type_name', 'za_lead_type.sno as lead_type_id', 'za_lead_source.lead_source_name', 'za_lead_source.sno as lead_source_id')
      ->where('za_raw_lead.status', 6)->join('za_lead_type', 'za_raw_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->join('za_lead_source', 'za_raw_lead.lead_source_id', '=', 'za_lead_source.sno')->orderBy('za_raw_lead.sno', 'desc');
    if ($branch_id != 0) {
      $rawLead->where('za_raw_lead.branch_id', $branch_id);
    }
    $pageConfigs = ['myLayout' => 'default'];

    $lead_type_fill = '';
    $lead_source_fill = '';
    $course_fill = '';
    $potential_type_fill = '';
    $lead_status_fill = '';
    $date_filter = '';
    // $staff_fill = '';
    $fin_yr_fill = '';


    $staff_filter_list = StaffModel::where('status', 0);
    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id);
    }
    $staff_filter_list = $staff_filter_list->where('department_id', 1)->orderBy('nick_name', 'ASC')->get();
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $course_type = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $PotentialType = LeadPotentialModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $Lead_status_list = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();


    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();


    $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_lead.potential_verify', 1)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_lead.potential_verify', 1)
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.potential_verify', 1)
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();



    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();


    $leadall = DB::table('za_lead')
      ->select(
        'za_lead.created_at',
        'za_lead.sno',
        'latest_appointment.lead_id as followup_latest_id',
        'appointment_counts.lead_id as followup_id'
      )
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)
      ->where('za_lead.status', 0)->where('za_lead.internal_status', '!=', 1)
      ->where('za_lead.potential_verify', 1)
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                status,
                appointment_date,
                SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
            FROM za_appointment
            WHERE (lead_id, appointment_date) IN (
                SELECT
                    lead_id,
                    MAX(appointment_date) AS appointment_date
                FROM za_appointment
                GROUP BY lead_id
            )
        ) AS latest_appointment'),
        'za_lead.sno',
        '=',
        'latest_appointment.lead_id'
      )
      ->leftJoin(
        DB::raw('(
            SELECT
                lead_id,
                COUNT(*) as total_appointments
            FROM za_appointment
            GROUP BY lead_id
        ) AS appointment_counts'),
        'za_lead.sno',
        '=',
        'appointment_counts.lead_id'
      );

    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadall = $leadall->where('za_lead.created_by', $user_id);
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)
      // Do nothing as $leadall already includes all data
    }
    if ($lead_fill != '') {
      // return 'ho';
      $leadall->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    // Execute the query
    $leadall = $leadall->get();

    // return $leadall;
    // vasanth

    $follwup_count = 0;
    $not_follow_up_ids = [];
    foreach ($leadall as $singleLead) {
      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      if ($chk1day) {
        // Increment only if follow-up IDs do not exist
        if (!$singleLead->followup_latest_id && !$singleLead->followup_id) {
          $follwup_count++;
          // $lead_names[] = $singleLead->sno;
        }
      }
    }

    // return $lead_names;

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.potential_verify', 1)->where('za_lead.internal_status', '!=', 1)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    // return  $follwup_count;
    $walkIn = DB::table('za_lead_appointment')->select('za_lead_appointment.sno')->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_status', 1)->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $walkInCount = $walkIn->where('za_lead_appointment.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $walkInCount = $walkIn->count();
    $reasonList_potential = PotentialReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    return view('content.sales.lead.potential_lead_list', compact(
      'leads',
      'totalLeadCount',
      'leadOriginalCount',
      'walkInCount',
      'reasonList_potential',
      'follwup_count',
      'totalFollowup',
      'not_verified_spam_count',
      'not_verified_drop_count',

      'perpage',
      'currentMonthLeadCount',
      'percentageover',
      'walletCount',
      'percentagecurrentmonth',
      'pageConfigs',
      'course_type',
      'CourseCategory',
      'lead_type_fill',
      'lead_source_fill',
      'lead_fill',
      'lead',
      'potential_type_fill',
      'PotentialType',
      'date_filter',
      'lead_status_fill',
      'staff_filter_list',
      'staff_fill',
      'login_branch_data',
      'Lead_status_list',
      'fin_yr_fill',
      'reasonList',
      'reasonList_internal',
      'leadbankCount',
      'followupReasonList',
      'reasonList_drop'

    ))->with('filter_on', $filter_on);
  }

  public function trans_potential_to_lead(Request $request)
  {
    $id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    DB::beginTransaction();
    try {

      $lead = LeadModel::where('sno', $id)->first();

      if (!$lead) {
        return response([
          'status' => 400,
          'message' => 'Lead not found.',
          'error_msg' => 'Invalid lead ID.',
          'data' => null,
        ], 400);
      }

      $old_staff_id = $lead->created_by;

      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $old_staff_id)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
        // $lead_history->transferred_from = 15; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 17;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      // Update lead details
      $lead->status = 0;
      $lead->drop_verified = 0;
      $lead->drop_tl_verified = 0;
      $lead->spam_verified = 0;
      $lead->spam_tl_verified = 0;
      $lead->internal_status = 0;
      $lead->lead_status_id = 1;
      $lead->transfer_status = 1;
      $lead->potential_verify = 0;
      $lead->created_by = $request->convert_staff_id ?? $user_id;
      $lead->updated_by   = $user_id;
      $lead->converted_by = $user_id;
      $lead->save();

      DB::commit();

      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Successfully Lead Converted!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Convert the Lead!'
        ]);
      }
      // return $lead;

      return redirect('/lead_management/potential_lead');
    } catch (\Exception $e) {
      DB::rollBack();
      // return $e->getMessage();
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Convert the Lead!' . $e->getMessage()
      ]);
      return redirect('/lead_management/potential_lead');
    }
  }

  public function AppointmentPB(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'appointment_date' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      // return $request;
      $lead_id                  = $request->lead_id;
      $appointment_time         = $request->appointment_time;

      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);

      $user_id            = $request->user()->user_id;
      $branch_id          = $request->user()->branch_id;

      $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      if (!$category_check) {

        $year = substr(date("y"), -2);
        $appointment_id = "AP-0001/" . $year;
      } else {

        $data = $category_check->appointment_id;
        $slice = explode("/", $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);

        $next_number = (int)$result + 1;
        $request = sprintf("AP-%04d", $next_number);

        $year = substr(date("y"), -2);
        $appointment_id = $request . '/' . $year;
      }


      $add_category = new AppointmentModel();
      $add_category->appointment_id          = $appointment_id;
      $add_category->lead_id                 = $lead_id;
      $add_category->appointment_date        = $appointment_date;
      $add_category->appointment_time        = $appointment_time;
      $add_category->branch_id               = $branch_id;
      $add_category->status                  = 1;
      $add_category->created_by              = $user_id;
      $add_category->updated_by              = $user_id;


      $add_category->save();
      if ($add_category) {
        $lead =  LeadModel::where('sno', $lead_id)->first();
        $lead->lead_status_id          = 2; //followup lead
        $lead->update();
      }

      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Appointment added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Appointment!'
        ]);
      }
      // }
      // return $result;
      return redirect('lead_management/potential_lead');
    }
  }

  public function appointment_update_pb($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'progressed' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      //   return $request;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time     = $request->appointment_time;
      $app_score            = $request->app_score;
      $hot_lead             = $request->hot_lead;
      $pb                   = $request->pb ?? 0;
      $user_id              = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_lead =  AppointmentModel::where('lead_id', $id)->orderBy('sno', 'desc')->first();

        $upd_lead->progressed                 = $progressed;
        $upd_lead->app_score                  = $request->app_score;
        $upd_lead->convo_message              = $request->convo_message;
        $upd_lead->status                     = 4;
        // return $upd_lead;
        $upd_lead->update();

        if ($pb == 1) {
          $LeadData = LeadModel::where('sno', $upd_lead->lead_id)->first();

          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $LeadData->sno;
          $add_history->branch_id = $LeadData->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($LeadData->created_at));
          $add_history->current_staff_id = $LeadData->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 17; // from Bulk transfer
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();
        }
      } else {
        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

        $upd_app = AppointmentModel::where('lead_id', $id)
          ->where('status', 1)
          ->where(function ($query) {
            $query->where('progressed', null)
              ->orWhere('progressed', 2);
          })
          ->orderBy('sno', 'desc')
          ->first();

        if ($upd_app) {
          $upd_app->status = 5;
          $upd_app->update();
        }

        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->reason                   = $reason_appt;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();
      }

      if ($upd_lead) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }

  public function changeInterested(Request $request)
  {
    $lead = LeadModel::where('sno', $request->lead_id)->first();

    if (!$lead) {
      return response()->json(['success' => false]);
    }

    if ($lead) {
      // Update Lead
      $LeadData = LeadModel::where('sno', $request->lead_id)->first();
      $LeadData->lead_status_id        = 2;
      $LeadData->drop_verified         = 0;
      $LeadData->drop_tl_verified      = 0;
      $LeadData->spam_verified         = 0;
      $LeadData->spam_tl_verified      = 0;
      $LeadData->internal_status       = 0;
      $LeadData->transfer_status       = 1;
      $LeadData->potential_verify      = 0;
      $LeadData->is_potential          = 0;
      $LeadData->is_dc                 = 0;
      $LeadData->lead_interest         = $request->user()->user_id;
      $LeadData->update();


      return response()->json([
        'success' => true
      ]);
    } else {
      return response()->json([
        'success' => false
      ]);
    }
  }

  // ALTER TABLE `za_lead` ADD `lead_interest` INT NULL DEFAULT NULL COMMENT 'Staff_id' AFTER `lead_event_id`;
}
