<?php

namespace App\Http\Controllers\sales\lead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadExportExcel;
use App\Models\LeadExportModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use App\Models\StaffpointsModel;
// use App\Models\LeadBankReasonModel;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class ManagePotentialLead extends Controller
{
  public function index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_tl_verified',
      'za_lead.spam_tl_reason',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.is_hot_lead',
      'za_lead.potential_comments',
      'za_lead.potentail_reason',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.call_tracker_id',
      'za_lead.website_id',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.is_potential',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.sno as staff_id',
      'za_staff.nick_name as sales_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id'

    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_lead.potential_verify', 1);

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.is_potential',
      'za_lead.spam_tl_verified',
      'za_lead.potential_comments',
      'za_lead.potentail_reason',
      'za_lead.spam_tl_reason',
      'za_lead.is_hot_lead',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.call_tracker_id',
      'za_lead.website_id',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.sno',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno'
    );
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leads = $leads->where('za_lead.branch_id',$branch_id)->orderBy('za_lead.spam_verified', 'asc')->paginate($perpage);

    $verified_spam_count     = 0;
    $not_verified_spam_count = 0;

    $verified_drop_count     = 0;
    $not_verified_drop_count = 0;

    $verified_spam_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $verified_drop_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    // return $reasonList_internal;
    // if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
    //   // User can only view their own data
    //   $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->where('za_appointment.created_by', $user_id)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
    //   // User can view all data
    //   $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();
    //   // return "global_lead";
    // }
    // $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();

    // $leadbankCount = DB::table('za_lead_bank')
    //   ->where('za_lead_bank.branch_id', $branch_id)
    //   ->where('za_lead_bank.status', 0)
    //   ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [2, 6])->where('za_lead.drop_verified', 0)->where('za_lead.spam_verified', 0)->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    $totalLeadCount = RawLeadModel::where('status', 6)->where('za_raw_lead.branch_id', $branch_id)->count();
    $internal_calls_count = DB::table('za_lead')
      ->where('za_lead.internal_status', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.internal_verify', 0)
      ->count();

    // $reasonList_lead_bank = LeadBankReasonModel::select('*')
    //   ->where('status', 0)
    //   ->orderBy('sno', 'desc')->get();


    // return $leads;
    return view('content.sales.lead.potential_lead_list', compact(
      'leads',
      'leadOriginalCount',
      'internal_calls_count',
      'perpage',
      // 'totalFollowup',
      'walletCount',
      'verified_spam_count',
      'not_verified_spam_count',
      'verified_drop_count',
      // 'leadbankCount',
      'totalLeadCount',
      'not_verified_drop_count',
      'lead_fill',
      // 'reasonList_lead_bank'
    ));
  }
  public function trans_potential_to_lead(Request $request)
  {
    $id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    DB::beginTransaction();
    try {

      $lead = LeadModel::where('sno', $id)->first();

      if (!$lead) {
        return response([
          'status' => 400,
          'message' => 'Lead not found.',
          'error_msg' => 'Invalid lead ID.',
          'data' => null,
        ], 400);
      }

      $old_staff_id = $lead->created_by;

      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $old_staff_id)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
        // $lead_history->transferred_from = 15; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 17;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      // Update lead details
      $lead->status = 0;
      $lead->drop_verified = 0;
      $lead->drop_tl_verified = 0;
      $lead->spam_verified = 0;
      $lead->spam_tl_verified = 0;
      $lead->internal_status = 0;
      $lead->lead_status_id = 1;
      $lead->transfer_status = 1;
      $lead->potential_verify = 0;
      $lead->created_by = $request->convert_staff_id ?? $user_id;
      $lead->updated_by   = $user_id;
      $lead->converted_by = $user_id;
      $lead->save();

      DB::commit();

      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Successfully Lead Converted!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Convert the Lead!'
        ]);
      }
      // return $lead;

      return redirect('/lead_management/potential_lead');
    } catch (\Exception $e) {
      DB::rollBack();
      // return $e->getMessage();
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Convert the Lead!' . $e->getMessage()
      ]);
      return redirect('/lead_management/potential_lead');
    }
  }

  // convert spam to lead branch
  public function SpamLeadList(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $user_id   = $request->user()->user_id;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_reason',
      'za_lead.spam_tl_verified',
      'za_lead.spam_tl_reason',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.is_hot_lead',
      'za_lead.spam_comments',
      'za_lead.spam_verified',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.call_tracker_id',
      'za_lead.website_id',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.sno as staff_id',
      'za_staff.nick_name as sales_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id'


    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_lead.status', 7);

    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.spam_reason',
      'za_lead.spam_tl_verified',
      'za_lead.spam_comments',
      'za_lead.spam_verified',
      'za_lead.spam_tl_reason',
      'za_lead.is_hot_lead',
      'za_lead.spam_bh_reason',
      'za_lead.inter_calls',
      'za_lead.just_dial_id',
      'za_lead.cloud_call_id',
      'za_lead.call_tracker_id',
      'za_lead.website_id',
      'za_lead.raw_lead_check',
      'za_lead.raw_lead_group',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.sno',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno'
    );




    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    $leads = $leads->orderBy('za_lead.spam_verified', 'asc')->paginate($perpage);

    $verified_spam_count     = 0;
    $not_verified_spam_count = 0;

    $verified_drop_count     = 0;
    $not_verified_drop_count = 0;

    $verified_spam_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $verified_drop_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    // // return $reasonList_internal;
    // if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
    //   // User can only view their own data
    //   $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->where('za_appointment.created_by', $user_id)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
    //   // User can view all data
    //   $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();
    //   // return "global_lead";
    // }
    // $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();

    // $leadbankCount = DB::table('za_lead_bank')
    //   ->where('za_lead_bank.branch_id', $branch_id)
    //   ->where('za_lead_bank.status', 0)
    //   ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [2, 6])->where('za_lead.drop_verified', 0)->where('za_lead.spam_verified', 0)->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno');
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    $totalLeadCount = RawLeadModel::where('status', 6)->where('za_raw_lead.branch_id', $branch_id)->count();
    $internal_calls_count = DB::table('za_lead')
      ->where('za_lead.internal_status', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.internal_verify', 0)
      ->where('za_lead.potential_verify', 0)
      ->count();

    // $reasonList_lead_bank = LeadBankReasonModel::select('*')
    //   ->where('status', 0)
    //   ->orderBy('sno', 'desc')->get();


    // return $leads;
    return view('content.sales.lead.new_spam_lead_list', compact(
      'leads',
      'leadOriginalCount',
      'internal_calls_count',
      'perpage',
      // 'totalFollowup',
      'walletCount',
      'verified_spam_count',
      'not_verified_spam_count',
      'verified_drop_count',
      // 'leadbankCount',
      'totalLeadCount',
      'not_verified_drop_count',
      'lead_fill',
      // 'reasonList_lead_bank'
    ));
  }
  public function ConvertSpamToLead($id, Request $request)
  {
    // return $request;
    // Get user info from the request
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $old_staff_id = $request->old_staff_id;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    // Check if lead exists
    if ($lead) {
      // Get lead history and check if it exists
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->where('current_staff_id', $old_staff_id)
        ->first();

      // If there's a lead history, update it
      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id;
        $lead_history->transferred_from = 2; // from spam transfer
        $lead_history->update(); // Actually update the record
      }

      // Add a new history record for Spam conversion
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
      $add_history->current_staff_id = $old_staff_id;
      $add_history->change_staff_id = 0; // Indicating it's a spam transfer
      $add_history->transferred_from = 2; // Spam transfer
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save(); // Save the new history entry
      //   return response([
      //     'status' => 200,
      //     'message' => 'Successfully Lead Converted!',
      //     'error_msg' => null,
      //     'data' => $add_history,
      // ], 200);



      // Update lead details
      $lead->status = 0;
      $lead->spam_verified = 0;
      $lead->lead_status_id = 1;
      $lead->created_by = $request->convert_staff_id;
      $lead->updated_by = $user_id;
      $lead->converted_by = $user_id;
      // return $lead;
      // Update the lead in the database
      if ($lead->update()) {
        // Define point category and calculate points
        $pointsData = $helper->gza_points_by_id(11);
        $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string

        // Save new points for the staff
        $newPoints = new StaffpointsModel();
        $newPoints->branch_id = $branch_id;
        $newPoints->staff_id = $old_staff_id;
        $newPoints->points_by = $lead->sno;
        $newPoints->points_id = 1; // Assuming 1 represents the category for Lead Conversion
        $newPoints->points = $point;
        $newPoints->reason = $reason;
        $newPoints->save();

        // Update staff's available points
        $staff_points = StaffModel::where('sno', $old_staff_id)->first();
        if ($staff_points) {
          $staff_points->avaiable_points += $point; // Increment the available points
          $staff_points->save();
        }

        // Return success response
        return response([
          'status' => 200,
          'message' => 'Successfully Lead Converted!',
          'error_msg' => null,
          'data' => null,
        ], 200);
      }
    }

    // If no lead was found or the update failed, return an error
    return response([
      'status' => 400, // 400 Bad Request as the lead was not found or could not be updated
      'message' => 'Failed to convert lead. Lead not found or an error occurred.',
      'error_msg' => 'No lead found with the given ID.',
      'data' => null,
    ], 400);
  }
  public function trans_spam_to_lead(Request $request)
  {
    $id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    DB::beginTransaction();
    try {

      $lead = LeadModel::where('sno', $id)->first();

      if (!$lead) {
        return response([
          'status' => 400,
          'message' => 'Lead not found.',
          'error_msg' => 'Invalid lead ID.',
          'data' => null,
        ], 400);
      }

      $old_staff_id = $lead->created_by;

      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $old_staff_id)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
        // $lead_history->transferred_from = 14; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 14;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      // Update lead details
      $lead->status = 0;
      $lead->spam_verified = 0;
      $lead->lead_status_id = 1;
      $lead->transfer_status = 1;
      $lead->is_spam = 1;
      $lead->created_by = $request->convert_staff_id ?? $user_id;
      $lead->updated_by = $user_id;
      $lead->converted_by = $user_id;
      $lead->save();

      DB::commit();

      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Successfully Lead Converted!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Convert the Lead!'
        ]);
      }
      // return $result;
      return redirect('/lead_management/spam_lead');
    } catch (\Exception $e) {
      DB::rollBack();

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Convert the Lead!' . $e->getMessage()
      ]);
      return redirect('/lead_management/spam_lead');
    }
  }

  // convert drop to lead branch
  public function DropLeadList(Request $request)
  {
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $page      = $request->input('page', 1);
    $perpage   = (int) $request->input('sorting_filter', 25);
    $offset    = ($page - 1) * $perpage;
    $entity_id = $request->user()->entity_id;

    // Filters
    $lead_fill = $request->input('lead_fill', '');

    // return $lead_fill;

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.drop_verified',
      'za_lead.is_hot_lead',
      'za_lead.drop_tl_verified',
      'za_lead.drop_comments',
      'za_lead.drop_reason',
      'za_lead.inter_calls',
      'za_lead.drop_bh_reason',
      'za_lead.drop_tl_reason',
      'za_lead.registered_date',
      'za_lead.created_at',
      'za_lead.lead_mobile',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.sno as staff_id',
      'za_staff.nick_name as sales_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id'

    )
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->where('za_lead.status', 5)
      ->where('za_lead.branch_id', $branch_id);

    if (isset($lead_fill)) {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }
    // Add groupBy
    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.created_by',
      'za_lead.lead_id',
      'za_lead.is_hot_lead',
      'za_lead.drop_verified',
      'za_lead.drop_reason',
      'za_lead.drop_tl_verified',
      'za_lead.drop_comments',
      'za_lead.registered_date',
      'za_lead.inter_calls',
      'za_lead.drop_bh_reason',
      'za_lead.drop_tl_reason',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_staff.sno',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno'
    );


    $leads = $leads->orderBy('za_lead.drop_verified', 'asc')->paginate($perpage);

    $verified_spam_count     = 0;
    $not_verified_spam_count = 0;

    $verified_drop_count     = 0;
    $not_verified_drop_count = 0;

    $verified_spam_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 1)->count();
    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $verified_drop_count     = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 1)->count();
    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }
    // $totalFollowup = DB::table('za_appointment')
    //     ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
    //     ->where('za_appointment.branch_id', $branch_id)
    //     ->where('za_appointment.status', '!=', 4)
    //     ->where('za_lead.status', '=', 0)
    //     ->whereDate('za_appointment.appointment_date', '=', today())
    //     ->count();

    // $leadbankCount = DB::table('za_lead_bank')
    //   ->where('za_lead_bank.branch_id', $branch_id)
    //   ->where('za_lead_bank.status', 0)
    //   ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();

    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [2, 6])->where('za_lead.internal_status', '!=', 1)->where('za_lead.created_by', '!=', 0)
      ->distinct('za_lead.sno')->where('za_lead.drop_verified', 0)->where('za_lead.spam_verified', 0);
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    $totalLeadCount = RawLeadModel::where('status', 6)->where('za_raw_lead.branch_id', $branch_id)->count();
    $internal_calls_count = DB::table('za_lead')
      ->where('za_lead.internal_status', 1)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.internal_verify', 0)
      ->where('za_lead.wallet_status', '=', 1)
      ->where('za_lead.potential_verify', 0)
      // ->where('za_lead.lead_bank_status', 0)
      ->count();

    // $reasonList_lead_bank = LeadBankReasonModel::select('*')
    //   ->where('status', 0)
    //   ->orderBy('sno', 'desc')->get();


    // return $leads;
    return view('content.sales.lead.new_drop_lead_list', compact(
      'leads',
      'leadOriginalCount',
      'internal_calls_count',
      'perpage',
      // 'totalFollowup',
      'walletCount',
      'verified_spam_count',
      'not_verified_spam_count',
      'verified_drop_count',
      // 'leadbankCount',
      'totalLeadCount',
      'not_verified_drop_count',
      'lead_fill',
      // 'reasonList_lead_bank'
    ));
  }
  public function ConvertDropToLead($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $old_staff_id = $request->old_staff_id;
    $lead = LeadModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    if ($lead) {
      // Check for an existing lead transfer log entry
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->where('current_staff_id', $old_staff_id)
        ->first();
      //  return $lead_history;

      // If an existing entry is found, update it
      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id;
        $lead_history->transferred_from = 3; // from Dead Lead transfer
        $lead_history->update(); // Update the existing entry
      }

      // Create a new history entry (this will always be created)
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
      $add_history->current_staff_id = $old_staff_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 3; // from Dead Lead transfer
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save(); // Always save the new entry

      // Proceed with updating the lead status
      $lead->status = 0;
      $lead->drop_verified = 0;
      $lead->lead_status_id = 1;
      $lead->created_by = $request->convert_staff_id;
      $lead->updated_by = $user_id;
      $lead->converted_by = $user_id;
      // return $lead;
      // Save the updated lead
      $lead->update();

      // Define point category and assign points
      $pointsData = $helper->gza_points_by_id(12);
      $point = $pointsData ? $pointsData->points : 0;
      $reason = $pointsData ? $pointsData->points_name : '';

      // Save new points for the staff
      $newPoints = new StaffpointsModel();
      $newPoints->branch_id = $branch_id;
      $newPoints->staff_id = $old_staff_id;
      $newPoints->points_by = $lead->sno;
      $newPoints->points_id = 1;
      $newPoints->points = $point;
      $newPoints->reason = $reason;
      $newPoints->save();

      // Update staff's available points
      $staff_points = StaffModel::where('sno', $old_staff_id)->first();
      if ($staff_points) {
        $staff_points->avaiable_points += $point; // Increment the available points
        $staff_points->save();
      }

      // Return success response
      return response([
        'status'    => 200,
        'message'   => 'Successfully Lead Converted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    // Return response if lead doesn't exist
    return response([
      'status'    => 400,
      'message'   => 'Lead not found!',
      'error_msg' => 'The lead with the given ID does not exist.',
      'data'      => null,
    ], 400);
  }
  public function trans_drop_to_lead(Request $request)
  {
    $id = $request->lead_id;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    DB::beginTransaction();
    try {

      $lead = LeadModel::where('sno', $id)->first();

      if (!$lead) {
        return response([
          'status' => 400,
          'message' => 'Lead not found.',
          'error_msg' => 'Invalid lead ID.',
          'data' => null,
        ], 400);
      }

      $old_staff_id = $lead->created_by;

      // Close previous transfer history
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $old_staff_id)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
        // $lead_history->transferred_from = 15; // spam transfer
        $lead_history->save();
      }

      // New transfer history entry
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d'); // new start date = today
      $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 15;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      // Update lead details
      $lead->status = 0;
      $lead->drop_verified = 0;
      $lead->lead_status_id = 1;
      $lead->transfer_status = 1;
      $lead->is_dead = 1;
      $lead->created_by = $request->convert_staff_id ?? $user_id;
      $lead->updated_by   = $user_id;
      $lead->converted_by = $user_id;
      $lead->save();

      DB::commit();

      if ($lead) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Successfully Lead Converted!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Convert the Lead!'
        ]);
      }
      // return $lead;
      return redirect('/lead_management/drop_lead');
    } catch (\Exception $e) {
      DB::rollBack();
      //    return $e->getMessage();
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Convert the Lead!' . $e->getMessage()
      ]);
      return redirect('/lead_management/drop_lead');
    }
  }

  //lead
  public function potential_reason(Request $request)
  {
    // ❌ Remove this - it stops all code
    // return $request;

    DB::beginTransaction();
    try {

      $id = $request->lead_id_potential;
      $potential_reason_edit = $request->potential_reason_edit;

      $lead = LeadModel::where('sno', $id)->first();

      /* -----------------------------------
            Update Potential / Spam Reason
        -------------------------------------*/
      if ($potential_reason_edit == 1) {
        // When user enters custom reason
        $lead->potentail_reason = $request->potential_reason_text;
      } else {
        // Check if reason exists
        $Potential = PotentialReasonModel::where('reason_name', $potential_reason_edit)->first();

        if ($Potential) {
          if ($Potential->comments_check == 1) {
            $lead->potential_comments = $request->potential_comments_text;
          }
        }

        // Assign reason name
        $lead->potentail_reason = $potential_reason_edit;
      }

      $user_id = $request->user()->user_id;

      /* -----------------------------------
            Close Previous Transfer History
        -------------------------------------*/
      $lead_history = LeadTransferLogModel::where('lead_id', $id)
        ->whereNull('end_date')
        ->where('current_staff_id', $lead->created_by)
        ->first();

      if ($lead_history) {
        $lead_history->end_date = date('Y-m-d');
        $lead_history->change_staff_id = $lead->created_by;
        $lead_history->save();
      }

      /* -----------------------------------
            Add New Transfer History Entry
        -------------------------------------*/
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead->sno;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d');
      $add_history->current_staff_id = $lead->created_by ?? $user_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 16;
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      $add_history->save();

      /* -----------------------------------
            Update Lead Status
        -------------------------------------*/
      $lead->internal_status = 1;
      $lead->potential_verify = 1;
      $lead->is_potential = 1;
      $lead->save();

      DB::commit();

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);

      return redirect()->back();
    } catch (\Exception $e) {
      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }
}
