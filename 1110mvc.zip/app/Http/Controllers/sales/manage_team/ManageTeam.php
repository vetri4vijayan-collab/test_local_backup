<?php
namespace App\Http\Controllers\sales\manage_team;

use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\StaffModel;

use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadsExport;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\RawLeadModel;
use App\Models\LeadAppointmentModel;
use App\Models\SlotModel;
use App\Models\StaffpointsModel;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\Communication_config_Model;
use DateTime;
use App\Models\FollowupReasonModel;
use Carbon\Carbon;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\LeadMetricsModel;

class ManageTeam extends Controller
{

    public function index(Request $request, $month = null, $year = null)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));
        
        if($month.$year == date('mY') || $year > date('Y')){
          $month_chk = 0;
        }else{
          $month_chk = 1;
        }
     

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_lead')
                ->whereYear('za_lead.created_at', $year)
                ->whereMonth('za_lead.created_at', $month)
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->whereNotIn('za_lead.status', [3, 2, 6])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_lead')->select('za_lead.*')
                ->whereYear('za_lead.created_at', $year)
                ->whereMonth('za_lead.created_at', $month)
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_lead')->select('za_lead.*')
                ->whereYear('za_lead.created_at', $year)
                ->whereMonth('za_lead.created_at', $month)
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 7)->count();

            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_lead')->select('za_lead.*')
                ->whereYear('za_lead.created_at', $year)
                ->whereMonth('za_lead.created_at', $month)
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 5)->count();
            $dead_lead_ratio      = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_lead.created_by', $staff->sno)
                     ->whereYear('za_lead.created_at', $year)
                ->whereMonth('za_lead.created_at', $month)
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        
         $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.sales.manage_team.manage_team_month', [
            'salesStaff' => $salesStaff,
            'month_chk' =>$month_chk,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }
    
   public function staffLeadFilter($id, Request $request)
  {
        $page           = $request->input('page', 1);
        $perpage        = (int) $request->input('sorting_filter', 25);
        $offset         = ($page - 1) * $perpage;
        $branch_id      = $request->user()->branch_id;
        $user_id   = $request->user()->user_id;
        $helper         = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $staff_id       = $decryptedValue;
        $staff_data     = StaffModel::where('status', 0)->where('sno', $staff_id)->first();
        $staffName      = $staff_data->staff_name;

        $lead_type_fill      = $request->lead_type_fill ?? '';
        $lead_source_fill    = $request->lead_source_fill ?? '';
        $course_fill         = $request->course_fill ?? '';
        $potential_type_fill = $request->potential_type_fill ?? '';
        $lead_status_fill    = $request->lead_status_fill ?? '';
        $staff_fill          = $request->staff_fill ?? '';
        $date_filter         = $request->dt_fill_issue_rpt;
        $from_date_filter    = $request->from_date_fillter_textbox;
        $to_date_filter      = $request->to_date_fillter_textbox;
        $lead_fill           = $request->lead_fill ?? '';
        $fin_yr_fill         = $request->fin_yr_fill ?? '';

    $leads = LeadModel::select(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.created_at',
      'za_lead.registered_date',
      'za_lead.lead_mobile',
      'za_lead.inter_calls',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead_appointment.appointment_status as lead_appointment_status',
      'za_lead_appointment.lead_id as appointment_lead_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno as lead_type_id',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno as lead_source_id',
      'za_potential_type.potential_type_name as potential_type_name',
      'za_potential_type.emoji',
      'za_potential_type.emoji_color',
      'appointment_counts.lead_id as followup_id',
      'latest_appointment.lead_id as latest_lead_id',
      'latest_appointment.appointment_date',
      'latest_appointment.lead_id as followup_latest_id',
      DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
      DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
    )
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
        SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
        FROM za_appointment
        WHERE (lead_id, appointment_date) IN (
            SELECT lead_id, MAX(appointment_date) AS appointment_date
            FROM za_appointment
            GROUP BY lead_id
        )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
        FROM za_appointment
        GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_lead_appointment', 'za_lead.sno', '=', 'za_lead_appointment.lead_id')
      ->leftJoin('za_lead_status', 'za_lead.lead_status_id', '=', 'za_lead_status.sno')
      ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
      ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
      ->leftJoin('za_potential_type', function ($join) {
        $join->on('za_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
          ->on('za_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(za_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
      })
     ->where('internal_status', '!=', 1)
      ->where('drop_verified', 0)
      ->where('spam_verified', 0)
      ->whereIn('za_lead.status', [0, 1, 4, 5, 7]);

    // Branch-specific filter
    if ($branch_id != 0) {
      $leads->where('za_lead.branch_id', $branch_id);
    }

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $leads->whereDate('za_lead.registered_date', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $leads->whereBetween('za_lead.registered_date', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth  = date('Y-m-t');
      $leads->whereBetween('za_lead.registered_date', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate   = date('Y-m-d', strtotime($to_date_filter));
        $leads->whereBetween('za_lead.registered_date', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $leads->where('za_lead.registered_date', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $leads->where('za_lead.registered_date', '<=', $toDate);
      }
    }
   
    $selectedMonthsText = '';
    if ($fin_yr_fill != '') {
      $helper            = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && ! empty($monthsArray)) {
          // Map the months numbers to their names
          $months = [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4      => 'April',
            5    => 'May',
            6       => 'June',
            7 => 'July',
            8    => 'August',
            9   => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December',
          ];

          // Collect the selected month names
          $selectedMonths = [];
          foreach ($monthsArray as $month) {
            if (isset($months[$month])) {
              $selectedMonths[] = $months[$month];
            }
          }

          // Prepare the selected months text for the view
          $selectedMonthsText = implode(', ', $selectedMonths);
        }
      }
    }
    // Other Filters
    if ($lead_type_fill != '') {
      $leads->where('za_lead.lead_type_id', $lead_type_fill);
    }
    if ($staff_fill != '') {
      $leads->where('za_lead.created_by', $staff_fill);
    }
    if ($lead_source_fill != '') {
      $leads->where('za_lead.lead_source_id', $lead_source_fill);
    }
    if ($course_fill != '') {
      $leads->whereJsonContains('za_lead.course_id', $course_fill)->whereRaw('JSON_LENGTH(za_lead.course_id) = 1');
    }
    if ($potential_type_fill != '') {
      $leads->where('za_lead.lead_score', $potential_type_fill);
    }
    if ($lead_status_fill != '') {
      $leads->where('za_lead.status', $lead_status_fill);
    }
    if ($lead_fill != '') {
      $leads->where(function ($query) use ($lead_fill) {
        $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
          ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      });
    }

    $leads = $leads->groupBy(
      'za_lead.sno',
      'za_lead.lead_id',
      'za_lead.lead_mobile',
      'za_lead.created_at',
      'za_lead.registered_date',
      'za_lead.inter_calls',
      'za_lead_appointment.appointment_status',
      'za_lead_appointment.lead_id',
      'za_lead.lead_email_id',
      'za_lead.lead_gender',
      'za_lead.lead_dob',
      'za_lead.lead_answer',
      'za_lead.lead_marital_status',
      'za_lead_status.lead_bg_color',
      'za_staff.staff_name',
      'za_staff.nick_name',
      'za_lead.lead_score',
      'za_lead.status',
      'za_lead.lead_condition',
      'za_lead.lead_status_id',
      'za_lead.lead_name',
      'za_lead_type.lead_type_name',
      'za_lead_type.sno',
      'za_lead_source.lead_source_name',
      'za_lead_source.sno',
      'latest_appointment.appointment_date',
      'latest_appointment.total_app_score',
      'za_potential_type.potential_type_name',
      'za_potential_type.emoji',
      'appointment_counts.lead_id',
      'latest_appointment.lead_id',
      'za_potential_type.emoji_color',
      'appointment_counts.total_appointments'
    );

    // Ordering and Fetching
    $leads = $leads->orderBy('za_lead.registered_date', 'desc')->paginate($perpage);

    foreach ($leads as $singleLead) {
      $normalizedPhoneNo    = ltrim($singleLead->lead_mobile, '0'); // Remove leading zero if present
      $phoneWithCountryCode = '+91' . $normalizedPhoneNo;           // Add the country code
      $lead                 = DB::table('za_contact_book')
        ->where('phone_no', $singleLead->lead_mobile)
        ->orWhere('phone_no', $phoneWithCountryCode) // Check both formats
        ->orderBy('contact_book_id', 'desc')
        ->first();
      $singleLead->staff_id = $lead->staff_id ?? "0";

      $lead = DB::table('za_appointment')
        ->where('lead_id', $singleLead->sno)
        ->orderBy('sno', 'desc')
        ->first();
      $singleLead->appointment_status = $lead->status ?? "0";
      $chk1day                        = false;
      $createdAt                      = Carbon::parse($singleLead->created_at);
      $currentDateTime                = Carbon::now();
      if ($createdAt->diffInHours($currentDateTime) >= 24) {
        $chk1day = true;
      } else {
        $chk1day = false;
      }
      $alert_status = 0;
      if ($chk1day) {
        if ($singleLead->followup_latest_id) {
          $alert_status = 0;
        } else if ($singleLead->followup_id) {
          $alert_status = 0;
        } else {
          $alert_status = 1;
        }
      }

      $singleLead->alert_status = $alert_status;
    }

    // Calculate the sum of app_score
    $sumAppScore = $leads->sum('total_app_score');

    // Transform the leads and add the sum of app_score to each lead
    $leads->getCollection()->transform(function ($item, $key) use ($sumAppScore) {
      $item->lead_initial = strtoupper(substr($item->lead_name, 0, 1)); // Only keeps and capitalizes the first letter
      $item->app_score    = $sumAppScore;                               // Add sum of app_score to each lead
      return $item;
    });
    // Get the total count of leads
    $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1);
        if ($branch_id != 0) {
            $totalLeadCounts->where('za_lead.branch_id', $branch_id);
        }
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $totalLeadCount = $totalLeadCounts->where('za_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $totalLeadCount = $totalLeadCounts->count();

    // Get the count of leads for the current month
   $currentMonthLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7]);
        if ($branch_id != 0) {
            $currentMonthLeadCounts->where('za_lead.branch_id', $branch_id);
        }
        $currentMonthLeadCounts = $currentMonthLeadCounts->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'));
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $currentMonthLeadCount = $currentMonthLeadCounts->where('za_lead.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $currentMonthLeadCount = $currentMonthLeadCounts->count();

    $totalCustomerCount = LeadModel::where('status', 4);
    if ($branch_id != 0) {
      $totalCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $totalCustomerCount = $totalCustomerCount->count();

    // Get the count of leads for the current month
    $currentMonthCustomerCount = LeadModel::where('status', 4);
    if ($branch_id != 0) {
      $currentMonthCustomerCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthCustomerCount = $currentMonthCustomerCount->whereYear('registered_date', date('Y'))
      ->whereMonth('registered_date', date('m'))
      ->count();

    // Calculate the percentage
    $percentageover         = 0;
    $percentagecurrentmonth = 0;
    if ($totalLeadCount > 0) {
      $percentageover = ($totalCustomerCount / $totalLeadCount) * 100;
    }
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    // Format the percentage to 2 decimal places
    $percentageover         = round($percentageover) . '%';
    $percentagecurrentmonth = round($percentagecurrentmonth) . '%';

    $staff_filter_list = StaffModel::where('status', 0)->where('department_id', 1);

    if ($branch_id != 0) {
      $staff_filter_list = $staff_filter_list->where('branch_id', $branch_id);
    }

    $staff_filter_list = $staff_filter_list->orderBy('nick_name', 'ASC')->get();

    // Additional Data for View
    $course_type       = LeadTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $CourseCategory    = LeadSourceModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $lead              = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $PotentialType     = LeadPotentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
    $Lead_status_list  = LeadStatusModel::where('status', 0)->where('legend_status', 0)->orderBy('lead_status_name', 'ASC')->get();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();
    $followupReasonList = FollowupReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_internal = InternalReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $reasonList_internal;
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->where('za_appointment.created_by', $user_id)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data
      $totalFollowup = DB::table('za_appointment')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_appointment.lead_id')
        ->where('za_appointment.branch_id', $branch_id)
        ->where('za_appointment.status', '!=', 4)
        ->where('za_lead.status', '=', 0)
        ->whereDate('za_appointment.appointment_date', '=', today())
        ->count();
      // return "global_lead";
    }

    $leadbankCount = DB::table('za_raw_lead')
      ->where('za_raw_lead.branch_id', $branch_id)
      ->where('za_raw_lead.status', '=', 7)
      ->count();

    $walletCount = DB::table('za_lead')
      ->where('za_lead.created_by', $user_id)
      ->where('za_lead.branch_id', $branch_id)
      ->where('za_lead.wallet_status', '=', 1)
      ->count();



    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('za_lead')->where('branch_id', $branch_id)->where('status', 5)->where('drop_verified', 0)->count();

    $leadall = DB::table('za_lead')->select(
      'za_lead.created_at',
      'latest_appointment.lead_id as followup_latest_id',
      'appointment_counts.lead_id as followup_id'
    )
      ->where('za_lead.branch_id', $branch_id)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])
      ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM za_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM za_appointment
              GROUP BY lead_id
          )) AS latest_appointment'), 'za_lead.sno', '=', 'latest_appointment.lead_id')
      ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM za_appointment
          GROUP BY lead_id) AS appointment_counts'), 'za_lead.sno', '=', 'appointment_counts.lead_id');
    if ($staff_fill != '') {
      $leadall->where('created_by', $staff_fill);
    }
    $leadall       = $leadall->get();
    $follwup_count = 0;
    foreach ($leadall as $singleLead) {

      $createdAt       = Carbon::parse($singleLead->created_at);
      $currentDateTime = Carbon::now();
      $chk1day         = $createdAt->diffInHours($currentDateTime) >= 24;

      // Initialize follow-up count
      // $follwup_count = 0;

      if ($chk1day) {
        // Check if follow-up IDs exist
        if ($singleLead->followup_latest_id || $singleLead->followup_id) {
          $follwup_count = $follwup_count; // No follow-up count if either ID exists
        } else {
          $follwup_count++; // Increment follow-up count if no IDs exist
        }
      }

      $follwup_count;
    }
    $leadOriginal = DB::table('za_lead')
      ->where('za_lead.branch_id', $branch_id)->where('za_lead.created_by', '!=', 0)->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->where('za_lead.internal_status', '!=', 1)
      ->distinct('za_lead.sno');
    if ($staff_fill != '') {
      $leadOriginal->where('created_by', $staff_fill);
    }
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('za_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    
    $walkIn = DB::table('za_lead_appointment')->select('sno')->where('appointment_category', 'walk-in')->where('branch_id', $branch_id)->where('appointment_status', 2);
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $walkInCount = $walkIn->where('za_lead_appointment.created_by', $user_id)->count();
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
    $walkInCount = $walkIn->count();
    // Return view with data
    return view('content.sales.lead.lead_list', compact(
      'leads',
      'staffName',
      'leadOriginalCount',
      'walkInCount',
      'walletCount',
      'leadbankCount',
      'followupReasonList',
      'from_date_filter',
      'reasonList_internal',
      'to_date_filter',
      'selectedMonthsText',
      'follwup_count',
      'perpage',
      'page',
      'not_verified_spam_count',
      'not_verified_drop_count',
      'totalLeadCount',
      'totalFollowup',
      'fin_yr_fill',
      'currentMonthLeadCount',
      'percentageover',
      'percentagecurrentmonth',
      'course_type',
      'CourseCategory',
      'lead_type_fill',
      'lead_source_fill',
      'lead',
      'course_fill',
      'potential_type_fill',
      'PotentialType',
      'lead_status_fill',
      'date_filter',
      'staff_filter_list',
      'staff_fill',
      'login_branch_data',
      'Lead_status_list',
      'lead_fill',
      'reasonList',
      'reasonList_drop'
    ))->with('filter_on', true);
  }

    //manageteam functions
    public function manageTeamToday(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_lead')
                ->where('za_lead.created_at', now()->toDateString())
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_at', now()->toDateString())
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_at', now()->toDateString())
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_at', now()->toDateString())
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 5)->count();
            $dead_lead_ratio = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio = number_format($dead_lead_ratio, 2);

            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_lead.created_by', $staff->sno)
                    ->where('za_customer.created_at', now()->toDateString())
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();
                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.sales.manage_team.manage_team_today', [
            'salesStaff' => $salesStaff,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function manageTeamTotal(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 10);
        $offset    = ($page - 1) * $perpage;

        $lead_fill = $request->input('lead_fill', '');

        $salesStaff = DB::table('za_staff')
            ->select('za_staff.sno', 'za_staff.staff_name', 'za_staff.staff_image', 'za_staff.gender', 'za_staff.mobile_no', 'za_staff.lead_bank_count')
            ->where('za_staff.status', 0)
            ->where('za_staff.department_id', 1)
            ->where('za_staff.branch_id', $branch_id);

        if ($lead_fill != '') {
            $salesStaff->where(function ($query) use ($lead_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.nick_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.mobile_no', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_staff.email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        $salesStaff = $salesStaff->orderBy('za_staff.sno', 'desc')->paginate($perpage);

        foreach ($salesStaff as $staff) {
            $total_leads = DB::table('za_lead')
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->whereNotIn('za_lead.status', [3, 2, 6, 5, 7])->count();
            $total_lead_count = $total_leads;

            $total_convert = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 4)->count();
            $convertion_rate = $total_lead_count > 0 ? ($total_convert / $total_lead_count) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            $spam_lead = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 7)->count();
            $spam_lead_ratio = $total_lead_count > 0 ? ($spam_lead / $total_lead_count) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio, 2);

            $dead_lead = DB::table('za_lead')->select('za_lead.*')
                ->where('za_lead.created_by', $staff->sno)
                ->where('za_lead.branch_id', $branch_id)
                ->where('za_lead.status', 5)->count();
            $dead_lead_ratio      = $total_lead_count > 0 ? ($dead_lead / $total_lead_count) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
            $potential_lead_count = 0;
            if ($total_lead_count > 0) {
                $potential_lead_count = $total_lead_count - $dead_lead - $spam_lead;
            }

            $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;

            if ($total_convert > 0) {
                $currentMonthCustomer = CustomerModel::select('za_customer.course_id', 'za_customer.sno')->where('za_customer.status', 0)
                    ->join('za_lead', 'za_lead.sno', '=', 'za_customer.lead_id')
                    ->where('za_customer.branch_id', $branch_id)
                    ->where('za_lead.created_by', $staff->sno)
                    ->get();

                if ($currentMonthCustomer->isNotEmpty()) {
                    $currentMonthCustomerCount = $currentMonthCustomer->count();

                    foreach ($currentMonthCustomer as $customer) {
                        $courseIds = json_decode($customer->course_id, true);
                        foreach ($courseIds as $courseId) {
                            // Fetch the course's maximum price
                            $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                            $total_payment += $payment;
                            // Fetch the total paid amount for the course
                            $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                                ->where('course_id', $courseId)
                                ->where('status', 1)
                                ->sum('paidAmount');
                            $total_paid_payment += $paid_payment;
                        }
                    }
                }

                // Calculate averages
                $averageBusinessValue   = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
                $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;
            }

            $staff->total_lead           = $total_lead_count;
            $staff->potential_lead       = $potential_lead_count;
            $staff->total_convert        = $total_convert;
            $staff->convertion_rate      = $convertion_rate;
            $staff->spam_lead            = $spam_lead;
            $staff->spam_lead_ratio      = $spam_lead_ratio;
            $staff->dead_lead            = $dead_lead;
            $staff->dead_lead_ratio      = $dead_lead_ratio;
            $staff->avg_business_value   = $averageBusinessValue;
            $staff->avg_collection_value = $averageCollectionValue;
        }
        $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();
        // return $salesStaff;
        return view('content.sales.manage_team.manage_team_all', [
            'salesStaff' => $salesStaff,
            'Lead_metric_list' => $Lead_metric_list,
            'perpage'    => $perpage,
            'lead_fill'  => $lead_fill,

        ]);
    }

    public function leadLimitSet($id, Request $request)
    {
        $user_id = $request->user()->user_id;
        $staff   = StaffModel::where('sno', $id)->first();
        $helper  = new \App\Helpers\Helpers();

        if ($staff) {
            $staff->lead_bank_count = $request->lead_count;
            $staff->updated_by      = $user_id;
            $staff->update();
            if ($staff->update()) {
                return response([
                    'status'    => 200,
                    'message'   => 'Successfully Limit Set!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);

            }
        }
        return response([
            'status'    => 200,
            'message'   => 'Successfully Limit Set!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

}
