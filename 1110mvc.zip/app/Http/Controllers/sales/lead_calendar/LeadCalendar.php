<?php

namespace App\Http\Controllers\sales\lead_calendar;

use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\PaymentModel;
use App\Models\CustomerModel;
use App\Models\CloudCallModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class LeadCalendar extends Controller
{
    public function lead_calendar(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        // Get current year and month from the request, defaulting to the current date if not provided
        $year  = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        // Calculate the previous and next month/year
        $previousMonth = $month > 1 ? $month - 1 : 12;
        $previousYear = $month == 1 ? $year - 1 : $year;

        $nextMonth = $month < 12 ? $month + 1 : 1;
        $nextYear = $month == 12 ? $year + 1 : $year;

        // Get the first day of the selected month
        $firstDayOfMonth = Carbon::createFromDate($year, $month, 1);
        $daysInMonth = $firstDayOfMonth->daysInMonth;
        $startDayOfWeek = $firstDayOfMonth->dayOfWeek; // This will give you Sunday = 0, Monday = 1, ...
    
        $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
        // return $month_chk;

        // Initialize arrays to store lead counts
        $totalLeadCount = [];
        $LeadDetail = [];
        $datesInMonth = collect();
        // return $month;

        $monthLeadCount = DB::table('za_lead')->select('za_lead.sno')
            ->where('za_lead.created_by', '>', 0)
            ->where('za_lead.branch_id', $branch_id)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->whereNotIn('za_lead.status', [2, 6])
            ->where('za_lead.spam_verified', 0)
            ->count();

        $monthCustomerCount = CustomerModel::select('za_customer.sno')->where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', $year)
            ->whereMonth('za_customer.created_at', $month)
            ->count();
        
        $monthSpamCount = LeadModel::select('*')
            ->where('status', 7)
            ->whereYear('za_lead.registered_date', $year)
            ->whereMonth('za_lead.registered_date', $month)
            ->where('za_lead.spam_verified', 1)
            ->where('created_by', '>', 0)
            ->where('branch_id', $branch_id)
            ->count();

        $monthCallLog = CloudCallModel::select(
                'za_cloud_call.*',
                'za_lead.lead_name',
                'za_lead.drop_verified','za_lead.drop_tl_verified',
                'za_lead.spam_verified','za_lead.spam_tl_verified',
                'za_lead.status AS lead_status',
                'za_lead.lead_mobile',
                'za_lead.created_by AS lead_created_by',
                'za_staff.staff_name'
                )
            ->leftJoin('za_lead', function ($join) {
            $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_cloud_call.caller_number, 10)"));
            })
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->whereYear('start_time', $year)
            ->where('za_cloud_call.branch_id', $branch_id)
            ->whereMonth('start_time', $month)->orderBy('start_time', 'DESC')->count();

        // return $monthCallLog;


        // return $monthLeadCount;


        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();

            // Fetch total leads for the given day
            $totalLeadCounts = LeadModel::select('*')
                ->whereNotIn('status', [2, 6])
                ->whereDate('registered_date', $datesInMonth)
                ->where('created_by', '>', 0)
                ->where('branch_id', $branch_id)
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->get();

            $totalLeadCount[] = [
                'Date' => $datesInMonth,
                'TotalLeads' => $totalLeadCounts->count()
            ];

            $LeadDetails = LeadModel::select('za_lead.lead_name', 'za_lead.lead_mobile', 'za_staff.staff_name', 'za_staff.position_role', 'za_job_position.job_position_name', 'za_lead_source.lead_source_name')
                ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
                ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
                ->whereNotIn('za_lead.status', [2, 6])
                ->where('za_lead.created_by', '>', 0)
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->whereDate('za_lead.registered_date', $datesInMonth)
                ->where('za_lead.branch_id', $branch_id)
                ->get();

            $LeadDetail[] = [
                'Date' => $datesInMonth,
                'TotalLeads' => $totalLeadCounts->count(),
                'LeadDetails' => $LeadDetails
            ];

            // return $LeadDetail;
        }

        // Initialize array for lead conversions
        $leadConvert = [];
        $LeadConvertDetail = [];

        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();
            // return $datesInMonth;

            // Fetch lead conversions for the given day
            $leadConverts = CustomerModel::select('sno')
                ->where('status', 0)
                ->where('branch_id', $branch_id)
                ->whereDate('za_customer.created_at', $datesInMonth)
                ->get();

            $leadConvert[] = [
                'Date' => $datesInMonth,
                'LeadConvert' => $leadConverts->count()
            ];
            // return $leadConvert;

            $LeadConvertDetails = CustomerModel::select('za_customer.cus_name', 'za_customer.cus_mobile', 'za_staff.staff_name', 'za_staff.position_role', 'za_job_position.job_position_name', 'za_training.customer_id', 'za_training.course_id', 'za_training.overall_fees', 'za_training.paid_amount', 'za_training.balance_amount', 'za_training.created_at as training_created', 'za_course.course_name', 'za_course.course_type_id', 'za_course_type.course_type_name')
                ->leftJoin('za_staff', 'za_customer.created_by', '=', 'za_staff.sno')
                ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
                ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
                ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
                ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->where('za_customer.status', 0)
                ->where('za_customer.branch_id', $branch_id)
                ->whereDate('za_customer.created_at', $datesInMonth)
                ->get();

            $LeadConvertDetail[] = [
                'Date' => $datesInMonth,
                'LeadConvert' => $leadConverts->count(),
                'LeadConvertDetails' => $LeadConvertDetails
            ];
        }
        // return $leadConvert;

        // Initialize array for lead conversions
        $spamCount = [];
        $spamCountDetails = [];

        // Loop through all the days of the selected month
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();

            // Fetch lead conversions for the given day
            $spamCounts = LeadModel::select('*')
                ->where('status', 7)
                ->where('created_by', '>', 0)
                ->where('za_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('registered_date', $datesInMonth)
                ->where('branch_id', $branch_id)
                ->get();

            $spamCount[] = [
                'Date' => $datesInMonth,
                'spamCount' => $spamCounts->count()  // The count is stored here
            ];

            $spamCountDetail = LeadModel::select('za_lead.lead_name', 'za_lead.lead_mobile', 'za_staff.staff_name', 'za_staff.position_role', 'za_job_position.job_position_name', 'za_lead_source.lead_source_name')
                ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
                ->leftJoin('za_lead_source', 'za_lead.lead_source_id', '=', 'za_lead_source.sno')
                ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
                ->where('za_lead.status', 7)
                ->where('za_lead.created_by', '>', 0)
                ->where('za_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('za_lead.registered_date', $datesInMonth)
                ->where('za_lead.branch_id', $branch_id)
                ->get();

            $spamCountDetails[] = [
                'Date' => $datesInMonth,
                'spamCount' => $spamCounts->count(),
                'spamCountDetails' => $spamCountDetail
            ];
        }

        $callLog = [];
        $callLogDetail = [];
        // return $spamCountDetails;
        for ($i = 1; $i <= $daysInMonth; $i++) {

            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();


            $callLogs = CloudCallModel::select(
                'za_cloud_call.*',
                'za_lead.lead_name',
                'za_lead.drop_verified','za_lead.drop_tl_verified',
                'za_lead.spam_verified','za_lead.spam_tl_verified',
                'za_lead.status AS lead_status',
                'za_lead.lead_mobile',
                'za_lead.created_by AS lead_created_by',
                'za_staff.staff_name'
                )
            ->leftJoin('za_lead', function ($join) {
            $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_cloud_call.caller_number, 10)"));
            })
            
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_cloud_call.branch_id', $branch_id)
            ->whereDate('start_time', $datesInMonth)->get();

            $callLog[] = [
                'Date' => $datesInMonth,
                'callLog' => $callLogs->count()
            ];

            $callLogDetails = CloudCallModel::select(
                'za_cloud_call.*',
                'za_lead.lead_name',
                'za_lead.drop_verified','za_lead.drop_tl_verified',
                'za_lead.spam_verified','za_lead.spam_tl_verified',
                'za_lead.status AS lead_status',
                'za_lead.lead_mobile',
                'za_lead.created_by AS lead_created_by',
                'za_staff.staff_name'
                )
            ->leftJoin('za_lead', function ($join) {
            $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_cloud_call.caller_number, 10)"));
            })
            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
            ->where('za_cloud_call.branch_id', $branch_id)
            ->whereDate('start_time', $datesInMonth)->get();

            $callLogDetail[] = [
                'Date' => $datesInMonth,
                'callLog' => $callLogs->count(),
                'callLogDetail' => $callLogDetails
            ];
        }
        // return $callLogDetail;

        $dateData_garph = [];
        for ($i = 1; $i <= $daysInMonth; $i++) {
            $datesInMonth = Carbon::createFromDate($year, $month, $i)->toDateString();
            $spamCounts = LeadModel::select('*')
                ->where('status', 7)
                ->where('created_by', '>', 0)
                ->where('za_lead.spam_verified', 1)
                ->where('internal_status', 0)
                ->whereDate('registered_date', $datesInMonth)
                ->where('branch_id', $branch_id)
                ->get();

            $leadConverts = CustomerModel::select('*')
                ->where('status', 0)
                ->where('branch_id', $branch_id)
                ->whereDate('za_customer.created_at', $datesInMonth)
                ->get();

            $totalLeadCounts = LeadModel::select('*')
                ->whereNotIn('status', [2, 6])
                ->whereDate('registered_date', $datesInMonth)
                ->where('created_by', '>', 0)
                ->where('spam_verified', 0)
                ->where('internal_status', 0)
                ->where('branch_id', $branch_id)
                ->get();

            $totalCallLogs = CloudCallModel::select(
                    'za_cloud_call.*',
                    'za_lead.lead_name',
                    'za_lead.drop_verified','za_lead.drop_tl_verified',
                    'za_lead.spam_verified','za_lead.spam_tl_verified',
                    'za_lead.status AS lead_status',
                    'za_lead.lead_mobile',
                    'za_lead.created_by AS lead_created_by',
                    'za_staff.staff_name'
                    )
                ->leftJoin('za_lead', function ($join) {
                $join->on('za_lead.lead_mobile', '=', DB::raw("RIGHT(za_cloud_call.caller_number, 10)"));
                })
                ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_lead.created_by')
                ->where('za_cloud_call.branch_id', $branch_id)
                ->whereDate('start_time', $datesInMonth)->get();


            $dateData_garph[] =  [
                'Date' => $datesInMonth,
                'customer_count' => $leadConverts->count(),
                'lead_count' => $totalLeadCounts->count(),
                'spam_count' => $spamCounts->count(),
                'cloud_count' => $totalCallLogs->count()
            ];
        }

        // return $dateData_garph;

        // Return the view with the necessary data
        return view('content.sales.lead_calendar.calendar_list', [
            'month_chk' => $month_chk,
            'previousMonth' => $previousMonth,
            'previousYear' => $previousYear,
            'nextMonth' => $nextMonth,
            'nextYear' => $nextYear,
            'startDayOfWeek' => $startDayOfWeek,
            'totalLeadCount' => $totalLeadCount,
            'leadConvert' => $leadConvert,
            'callLog' => $callLog,
            'LeadDetail' => $LeadDetail,
            'LeadConvertDetail' => $LeadConvertDetail,
            'spamCountDetails' => $spamCountDetails,
            'callLogDetail' => $callLogDetail,
            'spamCount' => $spamCount,
            'monthSpamCount' => $monthSpamCount,
            'monthCustomerCount' => $monthCustomerCount,
            'monthLeadCount' => $monthLeadCount,
            'monthCallLog' => $monthCallLog,
            'dateData_garph' => $dateData_garph
        ]);
    }
}