<?php

namespace App\Http\Controllers\sales\manage_walkin;

use App\Http\Controllers\Controller;
use App\Models\LeadAppointmentModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class ManageWalkin extends Controller
{
    public function index(Request $request)
    {
        $page         = $request->input('page', 1);
        $perpage      = (int) $request->input('sorting_filter', 25);
        $offset       = ($page - 1) * $perpage;
        $branch_id    = $request->user()->branch_id;
         $currentMonth=date('m');
        $currentYear=date('Y');
         $user_id    = $request->user()->user_id;

        $lead_status_fill = $request->lead_status_fill ?? '';
        $staff_fill       = $request->staff_fill ?? '';
        $date_filter      = $request->dt_fill_issue_rpt;
        $from_date_filter = $request->from_date_fillter_textbox;
        $to_date_filter   = $request->to_date_fillter_textbox;
        $lead_fill        = $request->lead_fill ?? '';
        $fin_yr_fill      = $request->fin_yr_fill ?? '';

        $walkin_list = LeadAppointmentModel::select('za_lead_appointment.*', 'za_lead.lead_name', 'za_lead.lead_mobile', 'za_lead.registered_date', 'za_staff.staff_name', 'za_staff.position_role', 'za_job_position.job_position_name')
            ->leftJoin('za_lead', 'za_lead_appointment.lead_id', '=', 'za_lead.sno')
            ->leftJoin('za_staff', 'za_lead_appointment.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
            ->where('za_lead_appointment.appointment_category', 'walk-in');
            // ->where('za_lead_appointment.appointment_status', 2);

      
        $walkin_list->where('za_lead_appointment.branch_id', $branch_id);
        // Date Filtering Logic
        if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $walkin_list->whereDate('za_lead_appointment.created_at', $todayDate);
        } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate   = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $walkin_list->whereBetween('za_lead_appointment.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth  = date('Y-m-t');
            $walkin_list->whereBetween('za_lead_appointment.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate   = date('Y-m-d', strtotime($to_date_filter));
                $walkin_list->whereBetween('za_lead_appointment.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $walkin_list->where('za_lead_appointment.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $walkin_list->where('za_lead_appointment.created_at', '<=', $toDate);
            }
        }
        $selectedMonthsText = '';
        if ($fin_yr_fill != '') {
            $helper            = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && ! empty($monthsArray)) {
                    // Map the months numbers to their names
                    $months = [
                        1 => 'January',
                        2 => 'February',
                        3 => 'March',
                        4      => 'April',
                        5    => 'May',
                        6       => 'June',
                        7 => 'July',
                        8    => 'August',
                        9   => 'September',
                        10 => 'October',
                        11 => 'November',
                        12 => 'December',
                    ];

                    // Collect the selected month names
                    $selectedMonths = [];
                    foreach ($monthsArray as $month) {
                        if (isset($months[$month])) {
                            $selectedMonths[] = $months[$month];
                        }
                    }

                    // Prepare the selected months text for the view
                    $selectedMonthsText = implode(', ', $selectedMonths);
                }
            }
        }

        if ($staff_fill != '') {
            $walkin_list->where('za_lead_appointment.staff_id', $staff_fill);
        }

        if ($lead_status_fill != '') {
            $walkin_list->where('za_lead_appointment.appointment_status', $lead_status_fill);
        }
        if ($lead_fill != '') {
            $walkin_list->where(function ($query) use ($lead_fill) {
                $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
            });
        }

        // Ordering and Fetching
        $walkin_list = $walkin_list->orderBy('za_lead_appointment.sno', 'desc')->paginate($perpage);
        
        
         foreach ($walkin_list as $singleAppointment) {
            $end_status = 0;
            if ($singleAppointment->appointment_status == 1) {
                $appointmentDate = \Carbon\Carbon::parse($singleAppointment->appointment_date);
                $currentDateTime = \Carbon\Carbon::now();
                $end_status = $appointmentDate <= $currentDateTime ? 1 : 0;
            }
        
            $singleAppointment->end_status = $end_status;
        }

        $staff_filter_list = StaffModel::where('status', 0)->where('branch_id', $branch_id)->where('department_id', 1)->orderBy('nick_name', 'ASC')->get();

        // return $walkin_list;
        // Page layout configuration
        $pageConfigs = ['myLayout' => 'default'];
        
          $completedCounts = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "2")->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_category', 'walk-in');
            if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
                // User can only view their own data
                $completedCounts = $completedCounts->where('za_lead_appointment.staff_id', $user_id);
                // return "view_self_lead";
            } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
                // User can view all data
                $completedCounts = $completedCounts;
                // return "global_lead";
            } else {
                // No permission
                abort(403, 'Unauthorized');
            }
        $completedCounts=$completedCounts->count();
        $cancelledCounts = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "3")->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_category', 'walk-in');
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        $pendingCounts   = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "1")->where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();
        $TotalCounts   = LeadAppointmentModel::where('za_lead_appointment.branch_id', $branch_id)->where('za_lead_appointment.appointment_category', 'walk-in');
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();

        

        $completedCountsMonth = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "2")->where('za_lead_appointment.branch_id', $branch_id)->whereMonth('za_lead_appointment.appointment_date', $currentMonth)->where('za_lead_appointment.appointment_category', 'walk-in');
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();
        $cancelledCountsMonth = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "3")->where('za_lead_appointment.branch_id', $branch_id) ->whereMonth('za_lead_appointment.appointment_date', $currentMonth)->where('za_lead_appointment.appointment_category', 'walk-in');
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();
        $pendingCountsMonth   = LeadAppointmentModel::where('za_lead_appointment.appointment_status', "1")->where('za_lead_appointment.branch_id', $branch_id) ->whereMonth('za_lead_appointment.appointment_date', $currentMonth)->where('za_lead_appointment.appointment_category', 'walk-in')->where('za_lead_appointment.appointment_date', '<=', \Carbon\Carbon::now());
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();
        $TotalCountsMonth   = LeadAppointmentModel::where('za_lead_appointment.branch_id', $branch_id)->whereMonth('za_lead_appointment.appointment_date', $currentMonth)->where('za_lead_appointment.appointment_category', 'walk-in');
        if (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'view_self_lead')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('za_lead_appointment.staff_id', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Sales Management', 'Manage Lead', 'global_lead')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate=$TotalCounts>0 ? ($completedCounts/$TotalCounts)*100 : 0;
        $failAppointmentRate=$TotalCounts>0 ? ($cancelledCounts/$TotalCounts)*100 : 0;

        // month
        $successAppointmentRateMonth=$TotalCountsMonth>0 ? ($completedCountsMonth/$TotalCountsMonth)*100 : 0;
        $failAppointmentRateMonth=$TotalCountsMonth>0 ? ($cancelledCountsMonth/$TotalCountsMonth)*100 : 0;


        return view('content.sales.manage_walkin.manage_walkin_list', [
            'walkin_list'           => $walkin_list,
            'pageConfigs'           => $pageConfigs,
            'perpage'               => $perpage,
            'lead_status_fill'      => $lead_status_fill,
            'date_filter'           => $date_filter,
            'staff_fill'            => $staff_fill,
            'lead_fill'             => $lead_fill,
            'fin_yr_fill'           => $fin_yr_fill,
            'staff_filter_list'     => $staff_filter_list,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
        ])->with('filter_on', false);
    }
}
