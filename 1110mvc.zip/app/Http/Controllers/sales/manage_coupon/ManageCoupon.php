<?php

namespace App\Http\Controllers\sales\manage_coupon;

use App\Http\Controllers\Controller;
use App\Models\LeadModel;
use App\Models\ManageCouponModel;
use Illuminate\Support\Facades\DB;
use App\Models\ManageCouponHistoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ManageCoupon extends Controller
{
  public function index(Request $request)
  {
      $branch_id = $request->user()->branch_id;
    $coupon_list = ManageCouponModel::select('za_manage_coupon.*', 'za_manage_coupon.status as coupon_status')
        ->where('za_manage_coupon.status', '!=', "2")
        ->whereDate('za_manage_coupon.end_date', '>', date('Y-m-d')) // Only coupons that haven't expired yet
        ->orderBy('za_manage_coupon.sno', 'desc');
    
    if ($branch_id != 0) {
        $coupon_list->where('za_manage_coupon.branch_id', '=', $branch_id);
    }
    
    $coupon_list = $coupon_list->paginate(25);
  
      // Page layout configuration
      $pageConfigs = ['myLayout' => 'default'];
  
      // Return view with necessary data
      return view('content.sales.manage_coupon.coupon_list', [
          'coupon_list'           => $coupon_list,
          'date_filter'           => '',
          'from_date_filter'      => '',
          'to_date_filter'        => '',
          'coupon_fill'           => '',
          'coupon_type_fill'      => '',
          'max_usg_count_fill'    => '',
          'multiple_check_fill'   => '',
          'public_check_fill'     => '',
          'lead_fill'             => '',
          'pageConfigs'           => $pageConfigs,
      ])->with('filter_on', false);
  }
  
    public function autocomplete_coupon(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $search = $request->get('term');
      $coupon = ManageCouponModel::select(
        'za_manage_coupon.sno',
        'za_manage_coupon.coupon_name',
        'za_manage_coupon.coupon_value',
        'za_manage_coupon.coupon_code',
        'za_manage_coupon.coupon_type',
        'za_manage_coupon.end_date',
        'za_manage_coupon.branch_id',
        'za_manage_coupon.max_usage_count',
        'za_manage_coupon.used_count',
        'za_coupon_usage_history.coupon_id',
        'za_coupon_usage_history.used_by',
        'za_coupon_usage_history.amount',
        'za_coupon_usage_history.modal_id',
        'za_coupon_usage_history.used_date',
        DB::raw('CASE 
                    WHEN za_coupon_usage_history.modal_id = 1 THEN za_lead.lead_name 
                    WHEN za_coupon_usage_history.modal_id = 2 THEN za_customer.cus_name 
                    ELSE NULL 
                 END AS user_name')
        )
        ->leftJoin('za_coupon_usage_history', 'za_coupon_usage_history.coupon_id', '=', 'za_manage_coupon.sno')
        ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_coupon_usage_history.used_by')
        ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_coupon_usage_history.used_by')
        ->where(function ($query) use ($search) {
            $query->where('za_manage_coupon.coupon_name', 'LIKE', '%' . $search . '%')
                  ->orWhere('za_manage_coupon.coupon_value', 'LIKE', '%' . $search . '%')
                  ->orWhere('za_manage_coupon.coupon_code', 'LIKE', '%' . $search . '%');
        })
        ->where('za_manage_coupon.branch_id', $branch_id)
        ->get();

      // return $coupon;
      return response()->json($coupon);
    }

    public function list_filter(Request $request)
    {
  
      $branch_id = $request->user()->branch_id;
      $helper = new \App\Helpers\Helpers();
      if ($branch_id) {
        $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
      } else {
        $get_branch_type = 0;
      }
      $coupon_fill = $request->coupon_fill ?? '';
      $coupon_type_fill = $request->coupon_type_fill ?? '';
      $max_usg_count_fill = $request->max_usg_count_fill;
      $multiple_check_fill = $request->multiple_check_fill ?? '';
      $public_check_fill = $request->public_check_fill ?? '';
      // $lead_fill = $request->lead_fill ?? '';
      $date_filter = $request->dt_fill_issue_rpt;
      $from_date_filter = $request->from_date_fillter_textbox;
      $to_date_filter = $request->to_date_fillter_textbox;
      // return $request;

      // $lead = LeadModel::select('sno','lead_name', 'lead_mobile')->where('status', '!=', 2)->get();
      
      $query =  ManageCouponModel::select('za_manage_coupon.*',  'za_manage_coupon.status as coupon_status')
      // ->leftJoin('za_lead', 'za_lead.sno', '=', 'za_manage_coupon.assign_lead_id')
      // 'za_lead.lead_name','za_lead.lead_mobile',
      ->where('za_manage_coupon.status', '!=', "2");
     
      // date filter query
      // Date Filtering Logic
      if ($date_filter == "today") {
        $todayDate = date("Y-m-d");
        $query->whereDate('za_manage_coupon.created_at', $todayDate);
      } elseif ($date_filter == "week") {
        $today = date('l');
        if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $query->whereBetween('za_manage_coupon.created_at', [$weekFromDate, $weekToDate]);
      } elseif ($date_filter == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $query->whereBetween('za_manage_coupon.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
      } elseif ($date_filter == "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->whereBetween('za_manage_coupon.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $query->where('za_manage_coupon.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $query->where('za_manage_coupon.created_at', '<=', $toDate);
        }
      }
  
      if ($branch_id != 0) {
          $query->where('za_manage_coupon.branch_id', $branch_id);
      }
  
      if ($coupon_fill) {
        $query->where('za_manage_coupon.coupon_name', 'LIKE', "%{$coupon_fill}%");
      }
      if ($coupon_type_fill) {        
        $query->where('za_manage_coupon.coupon_type', 'LIKE', "%{$coupon_type_fill}%");
      }
      if ($max_usg_count_fill) {
        $query->where('za_manage_coupon.max_usage_count', 'LIKE', "%{$max_usg_count_fill}%");
      }    
      if ($multiple_check_fill) {
        $query->where('za_manage_coupon.multiple_check', $multiple_check_fill);
      }
      if ($public_check_fill) {
        $query->where('za_manage_coupon.public_check', $public_check_fill);
      }
      // // Lead filter logic (corrected)
      // if ($lead_fill != '') {
      //   $query->where(function ($query) use ($lead_fill) {
      //       $query->where('za_lead.lead_name', 'LIKE', "%{$lead_fill}%")
      //           ->orWhere('za_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
      //           ->orWhere('za_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
      //   });
      // }
        
      // Fetch Branch list ordered by sno in descending order
      $coupon_list = $query->orderBy('za_manage_coupon.sno', 'desc')->distinct()->paginate(25);
      // return $lead_fill;

      $pageConfigs = ['myLayout' => 'default'];
  
      return view('content.sales.manage_coupon.coupon_list', [
        'coupon_list' => $coupon_list,
        // 'lead' => $lead,
        'date_filter' => $date_filter,
        'coupon_fill' => $coupon_fill,
        'coupon_type_fill' => $coupon_type_fill,
        'max_usg_count_fill' => $max_usg_count_fill,
        'multiple_check_fill' => $multiple_check_fill,
        'public_check_fill' => $public_check_fill,
        // 'lead_fill' => $lead_fill,
        'pageConfigs' => $pageConfigs,
      ])->with('filter_on', true);
    }


    public function usage_history(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $coupon_name_fill ='';
        $coupon_type_fill = '';
        $public_check_fill ='';
        $multi_check_fill ='';
        $lead_fill = '';

        // $usage_history_list_fill = ManageCouponHistoryModel::select('*')
        // ->leftJoin('za_manage_coupon','za_manage_coupon.sno','za_coupon_usage_history.coupon_id')      
        //   ->where('za_coupon_usage_history.status',0)
        //   ->orderBy('za_coupon_usage_history.sno', 'desc')
        //   ->get();
         

       $usage_history_list = ManageCouponHistoryModel::select(
            'za_coupon_usage_history.*',
            'za_manage_coupon.coupon_name',
            'za_manage_coupon.coupon_code',
            'za_manage_coupon.public_check',
            'za_manage_coupon.multiple_check',
            'za_manage_coupon.branch_id',
            'za_branch.branch_type',
            'za_branch.branch_name',
            'za_branch.franchise_name'
        )
        ->leftJoin('za_manage_coupon', 'za_manage_coupon.sno', '=', 'za_coupon_usage_history.coupon_id')
        ->join('za_branch', 'za_branch.sno', '=', 'za_manage_coupon.branch_id')
        ->where('za_coupon_usage_history.status', 0);
        
        // Permission Checks
        if (auth()->user()->hasPermissionradio('Manage Coupon', 'Manage Coupon', 'view_self_lead')) {
            // User can only view their own branch's data
            $usage_history_list = $usage_history_list->where('za_manage_coupon.branch_id', $branch_id);
        } elseif (auth()->user()->hasPermissionradio('Marketing Management', 'Manage Coupon', 'global_lead')) {
            // Global access - no additional filters
        } else {
            // No permission
            return view('errors.unauthorized');
        }
        
        // Order and Fetch Results
        $usage_history_list = $usage_history_list->orderBy('za_coupon_usage_history.sno', 'desc');
      
                 

          
        $date_filter = '';
        if ($date_filter == "today") {
          $todayDate = date("Y-m-d");
          $usage_history_list->whereDate('za_coupon_usage_history.created_at', $todayDate);
        } elseif ($date_filter == "week") {
          $today = date('l');
          if ($today == "Sunday") {
            $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
          } else {
            $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
          }
          $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$weekFromDate, $weekToDate]);
        } elseif ($date_filter == "monthly") {
          $firstDayOfMonth = date('Y-m-01');
          $lastDayOfMonth = date('Y-m-t');
          $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif ($date_filter == "custom_date") {
          if ($from_date_filter && $to_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$fromDate, $toDate]);
          } elseif ($from_date_filter) {
            $fromDate = date('Y-m-d', strtotime($from_date_filter));
            $usage_history_list->where('za_coupon_usage_history.created_at', '>=', $fromDate);
          } elseif ($to_date_filter) {
            $toDate = date('Y-m-d', strtotime($to_date_filter));
            $usage_history_list->where('za_coupon_usage_history.created_at', '<=', $toDate);
          }
        }
        
        $usage_history_list = $usage_history_list->paginate($perpage);
        
       
        $pageConfigs = ['myLayout' => 'default'];

        //  return   $usage_history_list;
        return view('content.sales.manage_coupon.usage_history',
        compact(       
            'usage_history_list' ,
            // 'usage_history_list_fill',
            'coupon_name_fill',
            'coupon_type_fill', 
            'perpage',
            'public_check_fill', 
            'multi_check_fill', 
            'date_filter', 
            'lead_fill', 
            'pageConfigs',
        ));
    }

    public function UsageHistoryFilter(Request $request)
    {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      // $usage_history_list_fill = ManageCouponHistoryModel::select('*')
      // ->leftJoin('za_manage_coupon','za_manage_coupon.sno','za_coupon_usage_history.coupon_id')      
      //   ->where('za_coupon_usage_history.status',0)
      //   ->orderBy('za_coupon_usage_history.sno', 'desc')
      //   ->get();

      // return $request;
      $coupon_name_fill = $request->coupon_name_fill ??'';
      $coupon_type_fill = $request->coupon_type_fill??'';
      $multi_check_fill = $request->multi_check_fill??'';
      $public_check_fill = $request->public_check_fill??'';
      $lead_fill = $request->lead_fill ?? '';
      $date_filter = $request->dt_fill_issue_rpt;
      $from_date_filter = $request->from_date_fillter_textbox;
      $to_date_filter = $request->to_date_fillter_textbox;

      $usage_history_list = ManageCouponHistoryModel::select(
        'za_coupon_usage_history.*',
        'za_manage_coupon.coupon_name',
        'za_manage_coupon.coupon_code',
        'za_manage_coupon.public_check',
        'za_manage_coupon.multiple_check',
        'za_manage_coupon.branch_id',
        )          
        ->leftJoin('za_manage_coupon','za_manage_coupon.sno','=','za_coupon_usage_history.coupon_id')
          ->where('za_coupon_usage_history.status',0) 
           ->where('za_manage_coupon.branch_id', $branch_id)
          ->orderBy('za_coupon_usage_history.sno', 'desc');
       


       // Date Filtering Logic
      if ($date_filter == "today") {
        $todayDate = date("Y-m-d");
        $usage_history_list->whereDate('za_coupon_usage_history.created_at', $todayDate);
      } elseif ($date_filter == "week") {
        $today = date('l');
        if ($today == "Sunday") {
          $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
          $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
          $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$weekFromDate, $weekToDate]);
      } elseif ($date_filter == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
      } elseif ($date_filter == "custom_date") {
        if ($from_date_filter && $to_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $usage_history_list->whereBetween('za_coupon_usage_history.created_at', [$fromDate, $toDate]);
        } elseif ($from_date_filter) {
          $fromDate = date('Y-m-d', strtotime($from_date_filter));
          $usage_history_list->where('za_coupon_usage_history.created_at', '>=', $fromDate);
        } elseif ($to_date_filter) {
          $toDate = date('Y-m-d', strtotime($to_date_filter));
          $usage_history_list->where('za_coupon_usage_history.created_at', '<=', $toDate);
        }
      }
      if ($coupon_name_fill != '') {
      $usage_history_list->where('za_manage_coupon.coupon_name', $coupon_name_fill);
      }
      
      if ($multi_check_fill != '') {
        $usage_history_list->where('za_manage_coupon.multiple_check', $multi_check_fill);
      }
      if ($public_check_fill != '') {
        $usage_history_list->where('za_manage_coupon.public_check', $public_check_fill);
      }
    
        $usage_history_list = $usage_history_list->paginate($perpage);
     
      
       return view('content.sales.manage_coupon.usage_history',
       compact(
        'usage_history_list',
        'coupon_name_fill',
        'multi_check_fill',
        'public_check_fill',
        'perpage',
        'date_filter',
        ));
    }

    public function Status($id, Request $request)
    {
  
      $upd_CourseCategoryModel =  ManageCouponModel::where('sno', $id)->first();
  
      $upd_CourseCategoryModel->status = $request->input('status', 0);
      $upd_CourseCategoryModel->update();
  
  
      return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    public function Delete($id, Request $request)
    {
      // return $request;
  
      $user_id              = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $coupon =  ManageCouponModel::where('sno', $id)->first();
      $coupon->status  = 2;
      // return $coupon;

      $coupon->Update();

      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

    public function Add(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'coupon_name' => 'required|max:255'
          ]);
    
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        // return $request;
        // Extracting values from the request
        $coupon_name     = $request->coupon_name;
        $coupon_value    = $request->coupon_value;
        $coupon_type     = $request->coupon_type;
        $coup_code_val   = $request->coup_code_val;
        $coupon_code_cust = $request->coupon_code_cust;
        $max_usg_count   = $request->max_usg_count;
        $multiple_check  = $request->multiple_check ?? 0;
        $coupon_dur      = $request->coupon_dur;
        $coupon_dur_type = $request->coupon_dur_type;
        $public_check    = $request->public_check ?? 0;
        $unexpired_check = $request->unexpired_check ?? 0;
        $coupon_end_dt   = !empty($request->coupon_end_dt) ? date('Y-m-d', strtotime($request->coupon_end_dt)) : null;
        $branch_ids = $request->branch_id ?? [$request->branchid_coupon];
        $user_id         = $request->user()->user_id;
    
        // Ensure that if multiple_check is 1, max_usage_count should be 0
        if ($multiple_check == 1) {
            $max_usg_count = 0;
        }
    
        foreach ($branch_ids as $branch_id) {
            // Check if coupon already exists for this branch
            $chk = ManageCouponModel::where('coupon_name', ucwords($coupon_name))
                ->where('coupon_code', $coup_code_val)
                ->where('branch_id', $branch_id) // Now checking per branch
                ->where('status', '!=', 2)
                ->first();
    
            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => "Coupon for Branch ID $branch_id is already Created!"
                ]);
                continue; // Skip creating duplicate
            }
    
            // Generate coupon ID
            $category_check = ManageCouponModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')->first();
    
            if (!$category_check) {
                $year = substr(date("y"), -2);
                $coupon_id = "COU-0001/" . $year;
            } else {
                $data = $category_check->coupon_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
                $next_number = (int)$result + 1;
                $request_id = sprintf("COU-%04d", $next_number);
    
                $year = substr(date("y"), -2);
                $coupon_id = $request_id . '/' . $year;
            }
    
            // Create new Coupon record for each branch
            $add_category = new ManageCouponModel();
    
            $add_category->coupon_code      = $coup_code_val ?: $coupon_code_cust;
            $add_category->coupon_id        = $coupon_id;
            $add_category->coupon_name      = ucfirst($coupon_name);
            $add_category->coupon_value     = $coupon_value;
            $add_category->coupon_type      = $coupon_type;
            $add_category->max_usage_count  = $max_usg_count;
            $add_category->multiple_check   = $multiple_check;
            $add_category->duration         = $coupon_dur;
            $add_category->duration_type    = $coupon_dur_type;
            $add_category->public_check     = $public_check;
            $add_category->unexpired_check  = $unexpired_check;
            $add_category->end_date         = $coupon_end_dt;
            $add_category->branch_id        = $branch_id; // Save per branch entry
            $add_category->created_by       = $user_id;
            $add_category->updated_by       = $user_id;
            // return $add_category;
            // Save the coupon
            if ($add_category->save()) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => "Coupon added Successfully!"
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => "Could not add the Coupon!"
                ]);
            }
        }
    
        return redirect()->back();
    }
    

  }