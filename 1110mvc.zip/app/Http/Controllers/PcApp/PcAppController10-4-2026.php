<?php

namespace App\Http\Controllers\PcApp;


use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\StaffModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\AttendanceModel;
use App\Models\TrainingModel;
use App\Helpers\Helpers;
use App\Models\UserRoleModel;
use App\Models\OtpModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Auth;
use App\Models\SmsTemplateModel;
use App\Models\CugManagementModel;
use function PHPUnit\Framework\isEmpty;
use App\Models\GeneralSettingsModel;

class PcAppController extends Controller
{

  public function StaffLogin(Request $request)
  {

    $mobile_no = $request->mobile_no;
    $key      = $request->key ? $request->key : 'null';

    $validator = Validator::make($request->all(), [
      'mobile_no' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
    } else {

      // $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();
      $staffuser = CugManagementModel::where('staff_mobile', $mobile_no)->where('status', 0)->first();

      // return $staffuser;
      if ($staffuser) {
        $user = StaffModel::where('sno', $staffuser->staff_id)->where('status', 0)->first();

        if ($mobile_no == "9790464324") {
          $otp_value  = 123456; // Random 6-digit OTP
        } else {
          $otp_value  = rand(100000, 999999); // Random 6-digit OTP
        } // Random 6-digit OTP

        // Save OTP to Database

        $otp = new OtpModel();

        $otp->user_id                  = $user->sno;
        $otp->mobile_no                = $mobile_no;
        $otp->otp_number               = $otp_value;
        $otp->created_by               = $user->sno;
        $otp->updated_by               = $user->sno;
        $otp->save();
        // sms otp
        if ($mobile_no == "9790464324") {
          if ($otp_value) {

            $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
            $authkey         = $result_sms ? $result_sms->authkey : '';
            $sender_id       = $result_sms ? $result_sms->sender_id : '';
            $template_id     = $result_sms ? $result_sms->template_id : '';
            $country_code    = $result_sms ? $result_sms->country_code : '';
            $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
            $mobile_number   = $country_code . $mobile_no;

            $app_name = "Clari";
            // $app_link = 'https://elysiumacademy.org/';

            // Replace placeholders with actual values
            $replacement_values = [$user->cus_name, $app_name, $otp_value];
            $message_content    = preg_replace_callback(
              '/\{#var#\}/',
              function () use (&$replacement_values) {
                return array_shift($replacement_values);
              },
              $message_content
            );

            $route    = "default";
            $postData = [
              'authkey' => $authkey,
              'mobiles' => $mobile_number,
              'message' => $message_content,
              'sender'  => $sender_id,
              'route'   => $route,
            ];

            // API URL
            $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            // Initialize the resource
            $ch = curl_init();
            curl_setopt_array($ch, [
              CURLOPT_URL            => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_POST           => true,
              CURLOPT_POSTFIELDS     => $postData,
              CURLOPT_SSL_VERIFYHOST => 0,
              CURLOPT_SSL_VERIFYPEER => 0,
            ]);

            // Get response
            $response = curl_exec($ch);
            // return $response;
            $err = curl_error($ch);
            curl_close($ch);
          }
        }

        $usertable = User::where('user_id', $user->sno)->first();
        $token     = $usertable->createToken('authToken')->accessToken;

        $baseUrl = 'https://erp.elysium.academy/staff_images/';

        return response()->json([
          'status'       => 200,
          'otp'          => $otp_value,
          'mobile'       => $mobile_no,
          'message'      => 'Successfully',
          "error_msg"    => null,
          'data'         => null
        ], 200);
      } else {
        $response = [
          'status' => 404,
          'message' => 'User does not exist',
          "error_msg" => null,
          'data' => null
        ];
        return response($response, 200);
      }
    }
  }

  public function verifyOtp(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'mobile_no' => 'required',
      'otp'       => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status'  => 422,
        'message' => 'Validation Error',
        'errors'  => $validator->errors()
      ], 422);
    }

    $mobile_no = $request->mobile_no;
    $otpInput  = $request->otp;

    // Get latest OTP for this user
    $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
      // ->latest()
      ->first();
    // return $otpRecord;

    if (!$otpRecord) {
      return response()->json([
        'status'  => 404,
        'message' => 'No OTP found for this number.'
      ], 404);
    }
    // Ensure both times are in UTC and properly compare
    $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
    $expiryTime = $createdAt->copy()->addMinutes(2);
    $currentTime = Carbon::now('UTC');

    if ($currentTime->greaterThan($expiryTime)) {
      return response()->json([
        'status'  => 410,
        'message' => 'OTP expired. Please request a new one.'
      ], 410);
    }


    // Match OTP
    if ($otpRecord->otp_number != $otpInput) {
      return response()->json([
        'status'  => 401,
        'message' => 'Invalid OTP.'
      ], 401);
    }

    $user = StaffModel::where('sno', $otpRecord->user_id)->where('status', 0)->first();
    $baseUrl = 'https://erp.elysium.academy/staff_images/';
    return response()->json([
      'status'       => 200,
      'staff_id'     => $otpRecord->user_id,
      'Gender'       => $user->gender,
      'name'         => $user->staff_name,
      'auto_id'      => $user->staff_id,
      'staff_image'  => $baseUrl . $user->staff_image ?? null,
      'message'      => 'OTP verified successfully!',

    ], 200);
  }

  public function pcProfileDetails(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'staff_id' => 'required',
    ]);
 
    if ($validator->fails()) {
      return response()->json([
        'status'  => 422,
        'message' => 'Validation Error',
        'errors'  => $validator->errors()
      ], 422);
    }
 
    $staffuser = StaffModel::where('za_staff.sno', $request->staff_id)
      ->where('za_staff.status', 0)
      ->select('za_staff.staff_name', 'za_staff.staff_id', 'za_staff.mobile_no', 'za_staff.email_id', 'za_staff.address', 'za_staff.date_of_joining', 'za_staff.staff_image', 'za_user_role.role_name')
      ->join('za_user_role', 'za_user_role.sno', '=', 'za_staff.role_id')
      ->first();
 
    if (!$staffuser) {
      return response()->json([
        'status' => 404,
        'message' => 'Staff not found'
      ], 404);
    }
 
    // Format DOJ
    $dojFormatted = null;
    $experience = null;
 
    if (!empty($staffuser->date_of_joining)) {
      $doj = Carbon::parse($staffuser->date_of_joining);
 
      // Format: 06 Jun 2024
      $dojFormatted = $doj->format('d M Y');
 
      // Calculate experience
      $now = Carbon::now();
      $diff = $doj->diff($now);
 
      $experience = $diff->y . ' year' . ($diff->y != 1 ? 's ' : ' ')
        . $diff->m . ' month' . ($diff->m != 1 ? 's ' : ' ')
        . $diff->d . ' day' . ($diff->d != 1 ? 's' : '');
    }
 
    return response()->json([
      'status' => 200,
      "error_msg" => null,
      'message' => 'Profile details successfully',
      'data' => [
        'name'       => $staffuser->staff_name ?? '-',
        'role_name'  => "Project Coordinator ",
        'auto_id'    => $staffuser->staff_id ?? '-',
        'mobile'     => $staffuser->mobile_no ?? '-',
        'email'      => $staffuser->email_id ?? '-',
        'location'   => $staffuser->address ?? '-',
        'doj'        => $dojFormatted ?? '-',
        'experience' => $experience ?? '-',
        'staff_image' => $staffuser->staff_image ? url('staff_images/' . $staffuser->staff_image) : null
      ]
    ]);
  }

  public function pcProfileChange(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'staff_id' => 'required',
      'attachment' => 'nullable|string', // base64 image strin
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 422,
        'message' => 'Incorrect format input fields',
        'errors' => $validator->errors()
      ], 422);
    }

    // Fetch the customer record
    $staff_upd = StaffModel::where('sno', $request->staff_id)->where('status', 0)->first();

    if (!$staff_upd) {
      return response()->json([
        'status' => 404,
        'message' => 'Customer not found',
        'data' => []
      ], 404);
    }

    $attachment_image_base64 = $request->input('attachment');
    $attachment = '';

    //  Handle base64 image upload
    if ($attachment_image_base64) {
      // Remove base64 header if present
      if (strpos($attachment_image_base64, ',') !== false) {
        $base64_image = explode(',', $attachment_image_base64)[1];
      } else {
        $base64_image = $attachment_image_base64;
      }

      $decoded_image = base64_decode($base64_image);

      if ($decoded_image !== false) {
        $imageName = 'staff_' . time() . '_' . rand(1000, 9999) . '.png';

        $directory = public_path('staff_images');
        if (!file_exists($directory)) {
          mkdir($directory, 0777, true);
        }

        file_put_contents($directory . '/' . $imageName, $decoded_image);
        $attachment = $imageName;
      }
    }

    //  Update profile picture if uploaded
    if ($attachment !== '') {
      $staff_upd->staff_image = $attachment;
      $staff_upd->update();
    }
    return response()->json([
      'status' => 200,
      'message' => 'Profile picture updated successfully',
      "error_msg" => null,
      'data' => [
        'staff_id'    => $staff_upd->sno,
        'staff_image' => $staff_upd->staff_image ? url('staff_images/' . $staff_upd->staff_image) : null
      ]
    ], 200);
  }

 public function pcTaskList(Request $request)

  {

    $validator = Validator::make($request->all(), [

      'staff_id' => 'required',

      'type' => 'required',

    ]);

 

    if ($validator->fails()) {

      return response()->json([

        'status'  => 422,

        'message' => 'Validation Error',

        'errors'  => $validator->errors()

      ], 422);

    }

 

    $staffuser = StaffModel::where('sno', $request->staff_id)

      ->where('status', 0)

      ->first();

 

    if (!$staffuser) {

      return response()->json([

        'status' => 404,

        'message' => 'Staff not found'

      ], 404);

    }

 

    //  Base Query

    $query = DB::table('za_batch_daily_task')

      ->join('za_batch', 'za_batch.sno', '=', 'za_batch_daily_task.batch_id')

      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')

      ->join('za_slot', 'za_slot.sno', '=', 'za_batch_daily_task.slot_id')

      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')

      ->where('za_batch.status', 0)

      ->where('za_batch_daily_task.staff_id', $request->staff_id);

 

    $tasks = $query->select(

      'za_batch.sno',

      'za_batch.batch_name',

      'za_course.course_name',

      'za_batch.start_date',

      'za_batch.end_date',

      'za_slot.start_time',

      'za_slot.end_time',

      'za_slot_type.slot_type_name',

      'za_batch_daily_task.status'

    )->get();

 

    $today = Carbon::now();

    $nowTime = Carbon::now()->format('H:i:s');

 

    $result = [];

 

    //  Dashboard counters

    $total = 0;

    $completed = 0;

    $pending = 0;

    $issue = 0;

 

    foreach ($tasks as $task) {

 

      $total++;

 

      $startDate = Carbon::parse($task->start_date);

      $endDate = Carbon::parse($task->end_date);

 

      //  Progress %

      $totalDays = $startDate->diffInDays($endDate) ?: 1;

      $completedDays = $startDate->diffInDays($today, false);

      $progress = max(0, min(100, ($completedDays / $totalDays) * 100));

 

      //  Time Unlock

      $isUnlocked = false;

      if ($task->start_time && $task->end_time) {

        $isUnlocked = ($nowTime >= $task->start_time && $nowTime <= $task->end_time);

      }

 

      //  STATUS LOGIC (IMPORTANT)

      $statusLabel = 'Not Started';

 

      if ($task->status == 1) {

        $statusLabel = 'Completed';

        $completed++;

      } elseif ($task->status == 3) {

        $statusLabel = 'Issue';

        $issue++;

      } else {

        // Not completed → check time

        if ($nowTime > $task->end_time) {

          $statusLabel = 'Pending';

          $pending++;

        } else {

          $statusLabel = 'Not Started';

        }

      }

 

      //  FILTER TYPE (after status calculation)

      if (strtolower($request->type) == 'completed' && $statusLabel != 'Completed') continue;

      if (strtolower($request->type) == 'issue' && $statusLabel != 'Issue') continue;

      if (strtolower($request->type) == 'pending' && $statusLabel != 'Pending') continue;

      if (strtolower($request->type) == 'today' && $statusLabel != 'Not Started') continue;

 

      $result[] = [

        'batch_id'    => $task->sno ?? '-',

        'batch_name'  => $task->batch_name ?? '-',

        'course_name' => $task->course_name ?? '-',

        'start_date'  => $startDate->format('d M Y'),

        'end_date'    => $endDate->format('d M Y'),

        'start_time'  => date('gA', strtotime($task->start_time)),

        'end_time'    => date('gA', strtotime($task->end_time)),

        'slot_type'   => $task->slot_type_name ?? '-',

 

        'progress'    => number_format($progress, 2),

        'is_unlocked' => $isUnlocked,

 

        'status'      => $statusLabel

      ];

    }

 

    //  Completion %

    $completionPercentage = number_format(($completed / $total) * 100, 2, '.', '');

 

    return response()->json([

      'status' => 200,

      'message' => 'Daily Task successfully',

 

      'dashboard' => [

        'total_task_count' => $total,

        'completed_count'  => $completed,

        'pending_count'    => $pending,

        'issue_count'      => $issue,

        'completion_percentage' => $completionPercentage

      ],

 

      'data' => $result

    ]);

  }
 
  public function pcTaskView(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'staff_id' => 'required',
      'batch_id' => 'required',
    ]);
 
    if ($validator->fails()) {
      return response()->json([
        'status'  => 422,
        'message' => 'Validation Error',
        'errors'  => $validator->errors()
      ], 422);
    }
 
    $staffuser = StaffModel::where('sno', $request->staff_id)
      ->where('status', 0)
      ->first();
 
    if (!$staffuser) {
      return response()->json([
        'status' => 404,
        'message' => 'Staff not found'
      ], 404);
    }
 
    // SINGLE RECORD
    $task = DB::table('za_batch_daily_task')
      ->join('za_batch', 'za_batch.sno', '=', 'za_batch_daily_task.batch_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch_daily_task.slot_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->where('za_batch.status', 0)
      ->where('za_batch_daily_task.staff_id', $request->staff_id)
      ->where('za_batch_daily_task.batch_id', $request->batch_id)
      ->select(
        'za_batch.sno',
        'za_batch.batch_name',
        'za_course.course_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_slot_type.slot_type_name',
        'za_staff.staff_name',
        'za_batch_daily_task.status'
      )
      ->first();
 
    if (!$task) {
      return response()->json([
        'status' => 404,
        'message' => 'Task not found'
      ], 404);
    }
 
    $today = Carbon::now();
    $nowTime = Carbon::now()->format('H:i:s');
 
    //  Day Mapping
    $dayMap = [
      "0" => "Sun",
      "1" => "Mon",
      "2" => "Tue",
      "3" => "Wed",
      "4" => "Thu",
      "5" => "Fri",
      "6" => "Sat",
    ];
 
    //  Checklist
    $genset = GeneralSettingsModel::where('sno', 1)->first();
    $checklist = $genset && $genset->batch_check_list
      ? json_decode($genset->batch_check_list, true)
      : [];
 
    $startDate = Carbon::parse($task->start_date);
    $endDate = Carbon::parse($task->end_date);
 
    //  Progress
    $totalDays = max(1, $startDate->diffInDays($endDate));
    $completedDays = max(0, $startDate->diffInDays($today, false));
    $progress = ($completedDays / $totalDays) * 100;
 
    //  Time Unlock
    $isUnlocked = ($nowTime >= $task->start_time && $nowTime <= $task->end_time);
 
    // Status
    if ($task->status == 1) {
      $statusLabel = 'Completed';
    } elseif ($task->status == 3) {
      $statusLabel = 'Issue';
    } elseif ($nowTime > $task->end_time) {
      $statusLabel = 'Pending';
    } else {
      $statusLabel = 'Not Started';
    }
 
    //  Slot Days Mapping
    $slotDays = [];
    if (!empty($task->slot_type_days)) {
      $daysArray = json_decode($task->slot_type_days, true);
      foreach ($daysArray as $d) {
        $slotDays[] = $dayMap[$d] ?? '';
      }
    }
 
    // Student Count
    $studentCount = TrainingModel::where('batch_id', $task->sno)
      ->where('status', '!=', 2)
      ->distinct('customer_id')
      ->count('customer_id');
 
    // FINAL RESPONSE
    $result = [
      'batch_id'    => $task->sno,
      'batch_name'  => $task->batch_name,
      'course_name' => $task->course_name,
      'start_date'  => $startDate->format('d M Y'),
      'end_date'    => $endDate->format('d M Y'),
      'start_time'  => date('g A', strtotime($task->start_time)),
      'end_time'    => date('g A', strtotime($task->end_time)),
      'slot_type_days' => implode(', ', $slotDays),
      'slot_type'   => $task->slot_type_name,
      'assigne_staff' => $task->staff_name,
      'student_count' => $studentCount,
      'progress'    => number_format($progress, 2),
      'is_unlocked' => $isUnlocked,
      'status'      => $statusLabel,
      'checklist'   => $checklist
    ];
 
    return response()->json([
      'status' => 200,
      'message' => 'Daily Task Details successfully',
      'data' => $result
    ]);
  }
  
  public function pcTaskSave(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'staff_id'   => 'required',
      'batch_id'   => 'required',
      'task_desc'  => 'required|string',
      'type'       => 'required|in:completed,issue',
      'attachment' => 'nullable'
    ]);
 
    if ($validator->fails()) {
      return response()->json([
        'status'  => 422,
        'message' => 'Validation Error',
        'errors'  => $validator->errors()
      ], 422);
    }
 
    //  Staff Check
    $staffuser = StaffModel::where('sno', $request->staff_id)
      ->where('status', 0)
      ->first();
 
    if (!$staffuser) {
      return response()->json([
        'status' => 404,
        'message' => 'Staff not found'
      ], 404);
    }
 
    //  Task Check
    $task = DB::table('za_batch_daily_task')
      ->where('staff_id', $request->staff_id)
      ->where('batch_id', $request->batch_id)
      ->first();
 
    if (!$task) {
      return response()->json([
        'status' => 404,
        'message' => 'Task not found'
      ], 404);
    }
 
    DB::beginTransaction();
 
    try {
 
      $attachment = null;
 
      //  Handle Base64 Image
      if (!empty($request->attachment)) {
 
        if (preg_match('/^data:image\/(\w+);base64,/', $request->attachment, $type)) {
 
          $image = substr($request->attachment, strpos($request->attachment, ',') + 1);
          $image = base64_decode($image);
 
          if ($image === false) {
            throw new \Exception('Base64 decode failed');
          }
 
          $extension = strtolower($type[1]); // png, jpg, jpeg
 
          if (!in_array($extension, ['jpg', 'jpeg', 'png'])) {
            throw new \Exception('Invalid image type');
          }
 
          $imageName = 'task_' . time() . '_' . uniqid() . '.' . $extension;
 
          $directory = public_path('task_attachment');
          if (!file_exists($directory)) {
            mkdir($directory, 0755, true);
          }
 
          file_put_contents($directory . '/' . $imageName, $image);
 
          $attachment = $imageName;
        } else {
          throw new \Exception('Invalid base64 format');
        }
      }
 
      //  Correct Status Logic
      $status = $request->type === 'issue' ? 3 : 1;
 
      //  Update DB (SAFE)
      DB::table('za_batch_daily_task')
        ->where('staff_id', $request->staff_id)
        ->where('batch_id', $request->batch_id)
        ->update([
          'task_description' => $request->task_desc,
          'status' => $status,
          'task_attachment' => $attachment ?? $task->task_attachment,
          'updated_at' => now()
        ]);
 
      DB::commit();
 
      return response()->json([
        'status' => 200,
        'message' => 'Daily Task updated successfully',
      ]);
    } catch (\Exception $e) {
 
      DB::rollBack();
 
      return response()->json([
        'status' => 500,
        'message' => 'Something went wrong',
        'error' => $e->getMessage()
      ], 500);
    }
  }
  
  public function StaffLogout(Request $request)
  {
    try {
      $user = $request->user()->token()->revoke();
      if ($user) {
        $response = [
          'status' => 200,
          'message' => 'You have been successfully logged out!',
          'error_msg' => null,
          'data' => null
        ];
        return response($response, 200);
      } else {
        return response()->json([
          'status' => 500,
          'message' => 'User Not Found',
          'error_msg' => null,
          'data' => null
        ], 500);
      }
    } catch (\Throwable $th) {
      return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
    }
  }
}
