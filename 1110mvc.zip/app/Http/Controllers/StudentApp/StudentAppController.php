<?php

namespace App\Http\Controllers\StudentApp;


use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\CustomerModel;
use App\Models\JobDirectoryModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\PaymentModel;
use App\Models\JobDirectoryJobModel;
use App\Models\IssueNoteModel;
use App\Models\CustomerPlacementModel;
use App\Models\StudentpointsModel;
use App\Models\ContactDetailsModel;
use App\Models\TrainingModel;
use App\Models\LeadModel;
use App\Models\SubLedgerModel;
use App\Models\TransactionModel;
use App\Models\SyllabusUpdateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Passport\HasApiTokens;
use App\Models\OtpModel;
use App\Models\SmsTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\StudentRedeemModel;
use App\Models\ManageCouponModel;
use App\Models\JobModel;
use App\Models\StudentFeedbackModel;
use App\Models\BranchModel;
use App\Models\InterviewModel;
use App\Models\ReferralPersonModel;
use App\Models\RawLeadModel;
use App\Models\ParticipantModel;
use App\Models\StaffModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\NotificationMobileModel;
use App\Traits\NotifiableTrait;
use Illuminate\Support\Facades\Config;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Mail;

class StudentAppController extends Controller
{

  protected $client;
  protected $accessToken;
  protected $businessId;
  protected $baseUrl;
  protected $phoneNumberId;
  use NotifiableTrait;
  public function __construct()
  {
  
    $whatsappConfig = WhatsappApiConfigureModel::where('sno', 3)->first();
    $this->phoneNumberId = $whatsappConfig->phonenumber_id; // Set your access token in the environment file
    $this->accessToken = $whatsappConfig->access_tokken; // Set your access token in the environment file
    $this->baseUrl = 'https://graph.facebook.com/v17.0';
    $this->businessId = $whatsappConfig->waba_id;
  }
  public function StudentLogin(Request $request)
  {

    $mobile_no = $request->mobile_no;
    $key      = $request->key ? $request->key : 'null';

    $validator = Validator::make($request->all(), [
      'mobile_no' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
    } else {

      $user = CustomerModel::where('za_customer.cus_mobile', $mobile_no)
                 ->join('za_branch', 'za_branch.sno', '=', 'za_customer.branch_id')
                 ->join('za_countrytimezones', 'za_branch.time_zone_id', '=', 'za_countrytimezones.sno')
                ->select('za_customer.*', 'za_branch.branch_name', 'za_countrytimezones.time_zone')
                ->first();
                // if ($user && $user->time_zone) {
                //     Config::set('app.timezone', $user->time_zone);
                //     date_default_timezone_set($user->time_zone);
                // }
      // return $user;
      if ($user) {
          
                if( $mobile_no == "9790464324"){
                    $otp_value  = 123456; // Random 6-digit OTP
                }else{
                    $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                }

                // Save OTP to Database
                $otp = new OtpModel();

                $otp->user_id    = $user->sno;
                $otp->mobile_no =  $mobile_no;
                $otp->otp_number = $otp_value;
                $otp->created_by = $user->sno;
                $otp->updated_by = $user->sno;
                $otp->save();
                if( $mobile_no != "9790464324"){
                  if ($otp_value && preg_match('/^\d{10}$/', $mobile_no)) {

                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $mobile_no;

                    $app_name = "Classmate";
                    $app_code = "OJevne%2Bs68l";
                    //  $app_code = "OJevne%2Bs68l";
                    // $app_link = 'https://elysiumacademy.org/';

                    // Replace placeholders with actual values
                    $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);

                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
                }
            
                              // Email
 
          if ($otp_value) {
            $emailId = $user->cus_email_id;
            if ($user && $emailId) {
              try {
                // Get branch data
                $branch_data = BranchModel::where('sno', $user->branch_id)->first();
                $branch_name = "";
 
                if ($branch_data) {
                  if ($branch_data->branch_type == 1) {
                    $branch_name = $branch_data->branch_name;
                  } elseif ($branch_data->branch_type == 2) {
                    $branch_name = $branch_data->franchise_name;
                  }
                }
 
                // Get CRE data
                $cre = StaffModel::where('sno', $branch_data->cre_id ?? 0)->orderBy('sno', 'desc')->first();
 
                // Get email template
                $email_template_id = 28;
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
 
                if (!$emailTemplate) {
                  // \Log::error('Email template not found for ID: ' . $email_template_id);
                } else {
                  $dynamicSubject = str_replace('#entity_name', $branch_name, $emailTemplate->email_name);
                  $content = $emailTemplate->email_subject;
                  $content = str_replace('#user_name', $user->cus_name, $content);
                  $content = str_replace('#entity_name', $branch_name, $content);
                  $content = str_replace('#otp_code', $otp_value, $content);
 
                  // **CRITICAL FIX: Validate email addresses before using them**
                  $branchNo = $branch_data->sales_mobile ?? '';
 
                  // Validate branch email - ensure it's a valid email format
                  $branchemail = $branch_data->sales_email ?? '';
                  if (!empty($branchemail) && !filter_var($branchemail, FILTER_VALIDATE_EMAIL)) {
                    $branchemail = ''; // Reset if invalid
                    // \Log::warning('Invalid branch email found: ' . ($branch_data->sales_email ?? 'null'));
                  }
 
                  // If no valid branch email, use a default or empty
                  if (empty($branchemail)) {
                    $branchemail = 'elysiumacademy@elysium.community'; // Use a default email
                  }
 
                  $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                  $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/elysiumacademy/';
 
                  $content = str_replace('#sales_mobile', $branch_data->sales_mobile ?? $cre->cre_mobile ?? '', $content);
                  $content = str_replace('#cre_mobile', $cre->cre_mobile ?? '8220011465', $content);
 
                  $url = 'eapl.com';
                  $mailData = [
                    'url' => $url,
                    'subject' => $dynamicSubject,
                    'content' => $content,
                    'branchNo' => $branchNo,
                    'branchemail' => $branchemail, // Now contains valid email
                    'fbLink' => $fbLink,
                    'instaLink' => $instaLink,
                    'salesMobile' => $branch_data->sales_mobile ?? '9003400111',
                  ];
 
                  $to_address = $user->cus_email_id;
                  $from_address = 'elysiumacademy@elysium.community';
                  $from_name = 'Elysium Academy®';
 
                  try {
                    Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
                  } catch (\Exception $e) {
                    \Log::error('Email sending failed for user ' . $user->sno . ': ' . $e->getMessage());
                  }
                }
              } catch (\Exception $e) {
                \Log::error('Email processing error: ' . $e->getMessage());
              }
            }
          }
          
                }
             
          
                if ($user->sno) {
                    $today = date('Y-m-d');
                
                    $alreadyLoggedIn = DB::table('za_students_points')
                        ->where('student_id', $user->sno)
                        ->whereDate('created_at', $today)
                        ->where('reason', 'Student Login')
                        ->where('status', 0)
                        ->exists();
                
                    if (!$alreadyLoggedIn) {
                        DB::table('za_students_points')->insert([
                            'branch_id'   => $user->branch_id ?? 0,
                            'student_id'  => $user->sno,
                            'points_id'   => 0, // default 0
                            'points'      => 1,
                            'reason'      => 'Student Login',
                            'created_at'  => now(),
                            'updated_at'  => now(),
                            'status'      => 0,
                        ]);
                    }
                }
                $usertable = CustomerModel::where('sno', $user->sno)->first();
                // $token = $usertable->createToken('authToken')->accessToken;
        
                $baseUrl = 'https://erp.elysium.academy/cus_pics/' . $user->cus_pic;
                // return $roleId;
                return response()->json([
                  'status'             => "1",
                  'otp'                => $otp_value,
                  'cus_name'           => $user->cus_name,
                  'sno'                => $user->sno,
                  'student_id'         => $user->customer_id,
                  'baseUrl'            => $baseUrl,
                  'cus_gender'         => $user->cus_gender,
                  'cus_dob'            => $user->cus_dob,
                  'cus_mobile'         => $user->cus_mobile,
                  'doj'                => $user->doj,
                  'cus_marital_status' => $user->cus_marital_status,
                  'Active'             => $user->status,
                  'cus_email_id'       => $user->cus_email_id,
                  'message'            => 'Successfully Login',
                  "error_msg"          => null,
                  'data'               => null,
                  // 'api_token'          => $token,
                ], 200);
              } else {
                $response = [
                  'status' => "2",
                  'message' => 'Student does not exist',
                  "error_msg" => null,
                  'data' => null
                ];
                return response($response, 200);
              }
            }
  }
  public function verifyOtp(Request $request)
  {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    // ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        // $expiryTime = $createdAt->copy()->addMinutes(2);
        // $currentTime = Carbon::now('UTC');
    
        // if ($currentTime->greaterThan($expiryTime)) {
        //     return response()->json([
        //         'status'  => false,
        //         'message' => 'OTP expired. Please request a new one.'
        //     ], 410);
        // }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
        ], 200);
    }
  public function StudentDailyCheck(Request $request)
  {
    $studentId = $request->customer_id; // passed from app

    if (!$studentId) {
        return response()->json([
            'status' => 422,
            'message' => 'Student ID is required',
            'data' => null,
        ], 422);
    }

    $student = DB::table('za_customer')->where('sno', $studentId)->where('status', 0)->first();

    if (!$student) {
        return response()->json([
            'status' => 0,
            'message' => 'Student not found',
            'data' => null,
        ], 200);
    }

    $today = date('Y-m-d');

    $alreadyExists = DB::table('za_students_points')
        ->where('student_id', $studentId)
        ->whereDate('created_at', $today)
        ->where('reason', 'Student Login')
        ->where('status', 0)
        ->exists();

    if (!$alreadyExists) {
        // Insert daily points
        DB::table('za_students_points')->insert([
            'branch_id'   => $student->branch_id ?? 0,
            'student_id'  => $student->sno,
            'points_id'   => 0,
            'points'      => 1,
            'reason'      => 'Student Login',
            'created_at'  => now(),
            'updated_at'  => now(),
            'status'      => 0,
        ]);

        // ✅ Send notification only when points are added
        $this->sendNotification(
            $student->branch_id,
            $student->sno,
            "Your daily login coin reward added successfully",
            "Student App",
            $studentId
        );
    }

      $usertable = CustomerModel::where('sno', $studentId)->first();
 
    $baseUrl = 'https://erp.elysium.academy/cus_pics/' . $usertable->cus_pic;
    
    return response()->json([
        'status' => $alreadyExists ? 1 : 0,
        'message' => $alreadyExists ? 'Already rewarded today' : '1 Point added for today',
        'data' => [
            'student_id' => $studentId,
            'date' => $today,
            'imageURL' => $baseUrl,
        ],
    ], 200);
}
   public function redeemList(Request $request)
  {
    $studentId = $request->customer_id; // passed from app

    if (!$studentId) {
        return response()->json([
            'status' => 422,
            'message' => 'Student ID is required',
            'data' => null,
        ], 422);
    }

    $student = DB::table('za_customer')->where('sno', $studentId)->first();

    if (!$student) {
        return response()->json([
            'status' => 0,
            'message' => 'Student not found',
            'data' => null,
        ], 200);
    }

    $today = date('Y-m-d');

    $redeemlist = DB::table('za_students_redeem')
        ->where('student_id', $studentId)
        ->get();

   

    return response()->json([
        'status' => true,
        'data' => $redeemlist,
        'message' =>  'Redeem list',
    ], 200);
}

   public function redeemAdd(Request $request)
    {
    $studentId    = $request->customer_id; // passed from app
    $is_merge     = $request->is_merge;    // 1 or 0
    $redeem_value = $request->redeem_value; // passed from app
    $crown_count = $request->crown_count; // passed from app
    if (!$studentId) {
        return response()->json([
            'status'  => 422,
            'message' => 'Student ID is required',
            'data'    => null,
        ], 422);
    }

    $student = DB::table('za_customer')
        ->where('sno', $studentId)
        ->where('status', 0)
        ->first();

    if (!$student) {
        return response()->json([
            'status'  => 0,
            'message' => 'Student not found',
            'data'    => null,
        ], 200);
    }

    try {
        DB::beginTransaction(); // ✅ Start transaction


        // if($is_merge === 1){
            
        // }
        // Generate Coupon ID
        $category_check = ManageCouponModel::where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();

        if (!$category_check) {
            $year = substr(date("y"), -2);
            $coupon_id = "COU-0001/" . $year;
        } else {
            $data   = $category_check->coupon_id;
            $slice  = explode("/", $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);

            $next_number = (int)$result + 1;
            $request_id  = sprintf("COU-%04d", $next_number);

            $year = substr(date("y"), -2);
            $coupon_id = $request_id . '/' . $year;
        }

        // Generate random coupon code based on redeem_value
        $coupon_code = strtoupper(substr(md5($redeem_value . time()), 0, 10));

        // Set duration and end date (3 years)
        $duration_years = 3;
        $created_at     = now();
        $end_date       = $created_at->copy()->addYears($duration_years);

        // Create new Coupon record
        $coupon_add = new ManageCouponModel();
        $coupon_add->coupon_code      = $coupon_code;
        $coupon_add->coupon_id        = $coupon_id;
        $coupon_add->coupon_name      = ucfirst($student->cus_name) . ' - Student App';
        $coupon_add->coupon_value     = $redeem_value;
        $coupon_add->coupon_type      = 'rupee';
        $coupon_add->max_usage_count  = 1;
        $coupon_add->multiple_check   = 0;
        $coupon_add->duration         = $duration_years * 365; // 3 years in days
        $coupon_add->duration_type    = 1; // 1 = day
        $coupon_add->public_check     = 0;
        $coupon_add->unexpired_check  = 0;
        $coupon_add->end_date         = $end_date;
        $coupon_add->branch_id        = $student->branch_id;
        $coupon_add->created_by       = $student->sno;
        $coupon_add->updated_by       = $student->sno;
        $coupon_add->save();

        // Insert into student redeem table
        DB::table('za_students_redeem')->insert([
            'branch_id'   => $student->branch_id ?? 0,
            'student_id'  => $student->sno,
            'crown_count'  => $crown_count,
            'coupon_id'   => $coupon_add->sno,
            'redeem_value'=> $redeem_value,
            'end_date'    => $end_date,
            'coupon_code' => $coupon_code,
            'merge'       => $is_merge,
            'created_by'  => $student->sno,
            'updated_by'  => $student->sno,
            'created_at'  => now(),
            'updated_at'  => now(),
            'status'      => 0,
        ]);

        DB::commit(); // ✅ Commit transaction

        // Send notification (outside DB transaction)
        $this->sendNotification(
            $student->branch_id,
            $student->sno,
            "Redeem coupon generated successfully.",
            "Student App",
            $studentId
        );

        return response()->json([
            'status'  => true,
            'message' => 'Redeem successfully Created',
            'coupon_code' => $coupon_code,
        ], 200);

    } catch (\Exception $e) {
        DB::rollBack(); // ❌ Rollback on failure

        return response()->json([
            'status'  => false,
            'message' => 'Redeem failed: ' . $e->getMessage(),
        ], 500);
    }
}

   public function CustomerScore(Request $request)
    {
        $customerIdParam = $request->customer_id;
    
        // 1. Fetch total earned points
        $points = DB::table('za_students_points')
            ->select(
                DB::raw("SUM(CASE WHEN reason = 'Customer Online Feedback' OR reason = 'Student Login' OR reason = 'Customer Reference Mobile' THEN points ELSE 0 END) as coin"),
                DB::raw("SUM(CASE WHEN reason = 'Customer Ontime Payment' THEN points ELSE 0 END) as diamond"),
                DB::raw("SUM(CASE WHEN reason = 'Present' THEN points ELSE 0 END) as heart"),
                DB::raw("SUM(CASE WHEN reason = 'Customer Reference' THEN points ELSE 0 END) as crown")
            )
            ->where('student_id', $customerIdParam)
            ->where('status', 0)
            ->first();
    
        // 2. Get customer & rewards
        $customer_data = DB::table('za_customer')->where('sno', $customerIdParam)->first();
        $redeemed = [
            'coin' => 0,
            'diamond' => 0,
            'crown' => 0,
        ];
    
           if ($customer_data && !empty($customer_data->rewards)) {
                $rewardsHistory = json_decode($customer_data->rewards, true);
                if (is_array($rewardsHistory)) {
                    foreach ($rewardsHistory as $entry) {
                        $redeemed['coin']    += abs($entry['coin'] ?? 0);
                        $redeemed['diamond'] += $entry['diamond'] ?? 0;
                        $redeemed['crown']   += $entry['crown'] ?? 0;
                    }
                }
            }
      
        // return $redeemed['diamond'];
        if ($customer_data && $points) {
            
           $attendanceration = AttendanceModel::where('customer_id', $customerIdParam)
            ->whereIn('attendance', ['P', 'HD'])
            ->get();

                
            $availableCoin    = max(0, ($points->coin ?? 0)    - $redeemed['coin']);
           
          
            $availableHeart = min($attendanceration->count(), 100);
            $value = $redeemed['diamond'] ?? 0;
             $value2 = $redeemed['crown'] ?? 0;
            $availableDiamond = 0;
            $availableCrown =0;
            if ($value < 0) {
                // Negative: redemption stored as negative, so we treat it as 0 for deduction
                
                $availableDiamond = max(0, ($points->diamond ?? 0) - abs($value)); // 25 - 4 = 21
                // return $availableDiamond; // returns -4
            } elseif ($value > 0) {
                // Positive: redemption stored as positive, subtract it
                $availableDiamond = max(0, ($points->diamond ?? 0) + $value);
                // return $value;
            } else {
                // Zero or not set
                $availableDiamond = max(0, ($points->diamond ?? 0));
            }
            if ($value2 < 0) {
                // Negative: redemption stored as negative, so we treat it as 0 for deduction
                
                $availableCrown = max(0, ($points->crown ?? 0) + $value2);
            } elseif ($value2 > 0) {
                // Positive: redemption stored as positive, subtract it
                $availableCrown = max(0, ($points->crown ?? 0) - $value2);
            } else {
                // Zero or not set
                $availableCrown = max(0, ($points->crown ?? 0));
            }
            $notify_count = NotificationMobileModel::where('customer_id', $customer_data->sno)
            ->where('branch_id', $customer_data->branch_id)
            ->where('status', 0) // only unread
            ->count();
           $redeemCrownlist = DB::table('za_students_redeem')
                ->where('student_id', $customerIdParam)
                ->where('branch_id', $customer_data->branch_id) // ✅ fixed column
                ->where('status', 0)
                ->get();
                // return $redeemCrownlist;
             // ✅ Each redeem entry reduces 1 crown
            // $crownRedeemedFromList = $redeemCrownlist->count();
            $crownRedeemedFromList = $redeemCrownlist->sum('crown_count');
            if($availableCrown > 0){
                  $tempAvailableCrown    = max(0, $availableCrown - $crownRedeemedFromList);
                 
            }else{
                
                $tempAvailableCrown    = max(0, $redeemed['crown'] - $crownRedeemedFromList);
                //  return $crownRedeemedFromList;
                // return $crownRedeemedFromList;
            }
          
            // return $redeemed['crown'];
            // ✅ If result is 0, fallback to redeemed['crown']
            // $availableCrown = ($tempAvailableCrown == 0) ? $redeemed['crown'] : $tempAvailableCrown;
            
            // 4. Build result
            $result = [
                'cus_name'       => $customer_data->cus_name ?? '',
                'heart_score'    => $availableHeart,
                'coins_value'    => $availableCoin > 0 ? $availableCoin : 0,
                'diamond_value'  => $availableDiamond > 0 ? $availableDiamond : 0,
               'crown_value'     => $tempAvailableCrown,
               'notify_count'    => $notify_count,
            ];
    
            return response()->json([
                'status'  => "1",
                'message' => 'Successfully Retrieved Data',
                'error_msg' => null,
                'data' => $result,
            ], 200);
        } else {
            return response()->json([
                'status'  => "0",
                'message' => 'Data Not Found',
                'error_msg' => null,
                'data' => [],
            ], 200);
        }
    }
  
  //**********************************Rajkumar*******************************//
    public function CustomerPoints(Request $request)
    {
        $customerIdParam = $request->customer_id;
    
        $points = DB::table('za_students_points')
            ->select(
                DB::raw("SUM(CASE WHEN reason = 'Customer Online Feedback' OR reason = 'Student Login' THEN points ELSE 0 END) as coin"),
                DB::raw("SUM(CASE WHEN reason = 'Customer Ontime Payment' THEN points ELSE 0 END) as diamond"),
                DB::raw("SUM(CASE WHEN reason = 'Present' THEN points ELSE 0 END) as heart"),
                DB::raw("SUM(CASE WHEN reason = 'Customer Reference' THEN points ELSE 0 END) as crown")
            )
            ->where('student_id', $customerIdParam)
            ->where('status', 0)
            ->first();
    
        $customer_points_details = (array) $points;
    
        if (!empty(array_filter($customer_points_details))) {
            return response()->json([
                'status'  => "1",
                'message' => 'Successfully Retrieved Data',
                'error_msg' => null,
                'data' => $customer_points_details,
            ], 200);
        } else {
            return response()->json([
                'status'  => "0",
                'message' => 'Data Not Found',
                'error_msg' => null,
                'data' => [],
            ], 200);
        }
        
    }
    

  // Customer List
   public function customerList(Request $request)
    {
        $customerIdParam = $request->customer_id;
        $cus_course_id = CustomerModel::where('sno', $customerIdParam)
            ->pluck('course_id') // Use pluck to get an array of values
            ->first(); // Get the first value directly

        // Assume $customerIdParam is the customer ID and $courseIds is an array of course IDs
        $courseIds = json_decode($cus_course_id);
        // $courseIds = ["43", "41"]; // Assuming this is directly available

        $customer = CustomerModel::select(
            'za_customer.sno',
            'za_training.customer_id',
            'za_training.course_id',
            'za_training.batch_id',
            'za_training.status',
            'za_course.sno as course_sno',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_course.course_version',
            'za_course.course_name',
            'za_course.course_code',
            'za_course.course_id',
            'za_course.course_duration',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course_type.course_type_name',
            'za_course_category.course_category_name',
            'za_course_subcategory.course_subcategory_name'
        )
            ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_customer.sno', $customerIdParam) // Filter by customer ID
            ->whereIn('za_training.course_id', $courseIds) // Use whereIn on the correct column
            ->get();


        return response()->json([
            'status'                        => "1",
            'message'                       => 'Successfully Retrieved Data',
            'error_msg'                     => null,
            'data' => [
                'course' => $customer, // Place customer data in the 'customer' key
                // 'chapters' => $chapter_views // Place chapter data in the 'chapters' key
            ],

        ], 200);
    }
   
   public function customer_course_List(Request $request)
   {
    $customerIdParam = $request->customer_id;
    
    

    $customer_course_details = CustomerModel::select(
      'za_customer.sno',
      'za_training.customer_id',
      'za_training.course_id',
      'za_training.batch_id',
      'za_training.status',
      'za_course.sno as course_sno',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_slot.slot_type_id as slot_type',
      'za_course.course_version',
      'za_course.course_name',
      'za_course.course_code',
      'za_course.course_id',
      'za_course.attachment',
      'za_course.thumbnail',
      'za_course.course_duration',
      'za_course.course_partical_hours',
      'za_course.course_theory_hours',
      'za_course_type.course_type_name',
      'za_course_category.course_category_name',
      'za_course_subcategory.course_subcategory_name',
      DB::raw("IFNULL(za_student_course_feedback.rating, '') as rating"),
      DB::raw("IFNULL(za_student_course_feedback.description, '') as feedback_description")
    )
      ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->leftJoin('za_student_course_feedback', function ($join) {
            $join->on('za_training.customer_id', '=', 'za_student_course_feedback.customer_id')
                 ->on('za_training.course_id', '=', 'za_student_course_feedback.course_id');
        })
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
      ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->where('za_customer.sno', $customerIdParam)
      ->where('za_course.status', 0)
    //   ->whereIn('za_training.course_id', $courseIds)
      ->get();
    // return $customer;
    $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
    $thumbnailBaseUrl = 'https://erp.elysium.academy/course_thumbnail_image/';
    // Add base URLs to the attachments and thumbnails only if they are not empty
    $customer_course_details->transform(function ($customer) use ($attachmentBaseUrl, $thumbnailBaseUrl) {
      // Append base URL if the attachment is not null or empty
      if (!empty($customer->attachment)) {
        $customer->attachment = $attachmentBaseUrl . $customer->attachment;
      } else {
        $customer->attachment = null; // Don't send link if empty
      }

      // Append base URL if the thumbnail is not null or empty
      if (!empty($customer->thumbnail)) {
        $customer->thumbnail = $thumbnailBaseUrl . $customer->thumbnail;
      } else {
        $customer->thumbnail = null; // Don't send link if empty
      }
      // 🎯 Random rating logic (if no rating data)
            
            // Generate random float between 4.0 and 5.0
            $customer->rating = number_format(mt_rand(40, 50) / 10, 1);
            // $customer->total_rating = $customer->average_rating * rand(5, 30); // fake total rating count

      return $customer;
    });

    $customer_course_details = $customer_course_details->map(function ($item){

        $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
        ->where('batch_id', $item->batch_id)
        ->where('attendance', 'P')
        ->get();
        $courseProgress = 0;

        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $item->course_sno)
                              ->count();
        if ($attendanceRecords->isNotEmpty()) {
          foreach ($attendanceRecords as $attendance) {
            $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $item->batch_id)
              ->whereDate('date', $attendance->att_date) // Check the attendance date
              ->get();
            if ($syllabusUpdates->isNotEmpty()) {
              foreach ($syllabusUpdates as $syllabusUpdate) {
                    if ($syllabusUpdate->percentage == 100) {
                        $topicCount++;
                    }
              }
            }
          }
          if ($course_topic_count > 0) {
              $courseProgress = ($topicCount / $course_topic_count) * 100;
          }
          if ($courseProgress > 100) {
              $courseProgress = 100;
          }
        }
        $courseProgress = number_format($courseProgress, 2);
        $item->course_complete_percentage = $courseProgress;

        $attendanceDate = AttendanceModel::select('att_date')->where('customer_id', $item->sno)
        ->where('batch_id', $item->batch_id)
        ->where('attendance', 'P')
        ->orderBy('created_at', 'desc') // Adjust 'created_at' to the appropriate column for ordering
        ->first();
        $course_completedDays=0;
        if($attendanceDate){
          $startDate = Carbon::parse($item->start_date);
          $lastAttendanceDate = Carbon::parse($attendanceDate->att_date);
            if ($startDate->lte($lastAttendanceDate)) {
              // Check the slot_type and apply the appropriate logic
              switch ($item->slot_type) {
                  case 1: // Monday to Friday
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isWeekday()) { // Weekday (Monday to Friday)
                              $course_completedDays++;
                          }
                      }
                      break;

                  case 2: // Saturday only
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isSaturday()) { // Saturday
                              $course_completedDays++;
                          }
                      }
                      break;

                  case 3: // Sunday only
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isSunday()) { // Sunday
                              $course_completedDays++;
                          }
                      }
                      break;

                  default:
                      // Handle other slot types if needed
                      break;
              }
            }
        }
        $item->course_completedDays = $course_completedDays;
        // === Add this block ===
        $currentDate = Carbon::now();
      $startDate = Carbon::parse($item->start_date);
      $endDate = Carbon::parse($item->end_date);
 
      $remainingDays = 0;
 
      if ($currentDate->lt($endDate)) {
 
        $date = $currentDate->copy();
 
        while ($date->lte($endDate)) {
 
          if (
            ($item->slot_type == 1 && $date->isWeekday()) ||
            ($item->slot_type == 2 && $date->isSaturday()) ||
            ($item->slot_type == 3 && $date->isSunday())
          ) {
            $remainingDays++;
          }
 
          $date->addDay();
        }
      }
 
      $item->remaining_days = $remainingDays;
        // === End block ===
        
        return $item;
    });



    if ($customer_course_details) {
      return response()->json([
        'status'                        => "1",
        'message'                       => 'Successfully Retrieved Data',
        'error_msg'                     => null,
        'data' => [
          'course' => $customer_course_details,
          // 'chapters' => $chapter_views // Place chapter data in the 'chapters' key
        ],

      ], 200);
    } else {
      return response()->json([
        'status'                        => "1",
        'message'                       => 'Data Not Found',
        'error_msg'                     => null,
        'data' => [],

      ], 200);
    }
  }
  public function courseRating(Request $request)
  {
    // Validate request
    $request->validate([
        'customer_id' => 'required',
        'course_id'   => 'required',
        'rating'      => 'required',
        'description' => 'nullable',
    ]);

    // Extract inputs
    $customer_id = $request->customer_id;
    $course_id   = $request->course_id;
    $rating      = $request->rating;
    $description = $request->description;

    // Get customer to derive branch_id (if required)
    $customerData = CustomerModel::where('sno', $customer_id)->first();

    if (!$customerData) {
        return response()->json(['error' => 'Customer not found'], 404);
    }

    // Insert into za_student_course_feedback
    $feedbackId = DB::table('za_student_course_feedback')->insertGetId([
        'branch_id'   => $customerData->branch_id ?? 0, // if branch_id exists in customer model
        'customer_id' => $customer_id,
        'course_id'   => $course_id,
        'rating'      => $rating,
        'description' => $description,
        'created_by'  => $customer_id,
        'updated_by'  => $customer_id,
    ]);

    return response()->json([
        'success' => true,
        'message' => 'Feedback saved successfully',
        'feedback_id' => $feedbackId
    ], 201);
}

  // Placements List
  public function PlacementListOld(Request $request)
  {   
      // $branch_id = $request->user()->branch_id;

    $job_details = JobDirectoryJobModel::select(
      'za_job_directorys_job.sno',
      'za_job_directorys_job.salary',
      'za_job_directorys_job.job_name_id',
      'za_job_directorys_job.job_interview_date',
      'za_job_directorys_job.interview_type_id',
      'za_job_directorys_job.vacancy_count',
      'za_job_directorys_job.job_link',
      'za_job_directorys_job.job_description',
      'za_industry_job_name.job_name',
      'za_interview_type.interview_type_name',
      'za_job_directory.sno as job_dir_sno',
      'za_job_directory.status',
      'za_hr_directory.company_name',
      'za_hr_directory.hr_contact_name',
      'za_hr_directory.hr_contact_phone',
      'za_hr_directory.address'
    )
      ->join('za_job_directory', 'za_job_directory.sno', '=', 'za_job_directorys_job.job_dir_id')  // Join with job directory
      ->join('za_industry_job_name', 'za_job_directorys_job.job_name_id', '=', 'za_industry_job_name.sno')
      ->join('za_interview_type', 'za_job_directorys_job.interview_type_id', '=', 'za_interview_type.sno')
      ->join('za_hr_directory', 'za_hr_directory.sno', '=', 'za_job_directory.job_company_id')  // Join HR directory
      ->where('za_job_directory.status', '!=', 2)
      // ->where('za_job_directory.branch_id', $branch_id)
      ->orderBy('za_job_directorys_job.sno', 'desc')
      ->get();

    // Decode hr_contact_name and hr_contact_phone
    foreach ($job_details as $job) {
      $job->hr_contact_name = json_decode($job->hr_contact_name, true);
      $job->hr_contact_phone = json_decode($job->hr_contact_phone, true);
    }
if($job_details) {
    // Return the filtered placements
    return response()->json([
      'status' => '1',
      'message' => 'Successfully Retrieved Data',
      'error_msg' => null,
      'data' => $job_details
    ], 200);
  }else{
    return response()->json([
      'status' => '2',
      'message' => 'Successfully Retrieved Data',
      'error_msg' => null,
      'data' => null
    ], 200);
  }
  }
  // Syllabus student
//   public function StudentSyllabus(Request $request)
//   {
//       $customerIdParam = $request->customer_id;
//       $courseId = $request->course_id;
  
//       $stud_syllabus = CustomerModel::select(
//           'za_training.customer_id',
//           'za_training.course_id',
//           'za_training.batch_id',
//           'za_course.course_name',
//           'za_course.course_duration',
//           'za_course.course_partical_hours',
//           'za_course.course_theory_hours',
//           'za_course_subcategory.course_subcategory_name',
//           'za_syllabus_update.course_id AS syb_course_id',
//           'za_syllabus_update.batch_id AS syb_batch_id',
//           'za_syllabus_update.topic_id',
//           'za_syllabus_update.date AS syb_date',
//           'za_attendance.att_date',
//           'za_attendance.attendance',
//           'za_course_chapter.topic_name',
//           'za_course_chapter.course_chapter_duration',
//           'za_course_chapter.course_chapter_theory_hours',
//           'za_course_chapter.course_chapter_practical_hours'
//       )
//       ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
//       ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
//       ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
//       ->leftJoin('za_syllabus_update', function($join) {
//           $join->on('za_training.batch_id', '=', 'za_syllabus_update.batch_id')
//               ->on('za_training.course_id', '=', 'za_syllabus_update.course_id');
//       })
//       ->leftJoin('za_attendance', 'za_syllabus_update.batch_id', '=', 'za_attendance.batch_id')
//       ->leftJoin('za_course_chapter', 'za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
//       ->where('za_training.course_id', $courseId)
//       ->where('za_training.customer_id', $customerIdParam)
//       ->get();
  
//       // Initialize an array to store the final structured data
//       $allBatchesData = [];
  
//       foreach ($stud_syllabus as $item) {
//         // Create a unique key for each course and batch combination
//         $key = $item->course_id . '_' . $item->batch_id;
    
//         // If the course key doesn't exist, initialize it
//         if (!isset($allBatchesData[$key])) {
//             $allBatchesData[$key] = [
//                 'coursesDetails' => [
//                     'customer_id' => $item->customer_id,
//                     'course_id' => $item->course_id,
//                     'batch_id' => $item->batch_id,
//                     'course_name' => $item->course_name,
//                     'course_duration' => $item->course_duration,
//                     'course_partical_hours' => $item->course_partical_hours,
//                     'course_theory_hours' => $item->course_theory_hours,
//                     'course_subcategory_name' => $item->course_subcategory_name,
//                 ],
//                 'AttendanceSyllabus' => [] // Initialize AttendanceSyllabus as an empty array
//             ];
//         }
    
//         // Only process if att_date, attendance, and topic_name are not null
//         if ($item->att_date && $item->attendance && $item->topic_name) {
//             // Check if the date and attendance combination already exists in the AttendanceSyllabus
//             $attendanceIndex = null;
//             foreach ($allBatchesData[$key]['AttendanceSyllabus'] as $index => $attendanceItem) {
//                 if ($attendanceItem['date'] == $item->att_date && $attendanceItem['attendance'] == $item->attendance) {
//                     $attendanceIndex = $index;
//                     break;
//                 }
//             }
    
//             // If there's no match, create a new entry for the date and attendance
//             if ($attendanceIndex === null) {
//                 $allBatchesData[$key]['AttendanceSyllabus'][] = [
//                     'date' => $item->att_date,
//                     'attendance' => $item->attendance,
//                     'topics' => [] 
//                 ];
    
//                 // Find the index of the new entry
//                 $attendanceIndex = count($allBatchesData[$key]['AttendanceSyllabus']) - 1;
//             }
    
//             // Only append the topic name if syb_date matches att_date
//             // Also, prevent duplicates by checking if the topic already exists
//             if ($item->syb_date == $item->att_date) {
//                 $topicName = $item->topic_name;
//                 // Check if the topic is already in the topics array for this date/attendance
//                 if ($topicName && !in_array($topicName, $allBatchesData[$key]['AttendanceSyllabus'][$attendanceIndex]['topics'])) {
//                     $allBatchesData[$key]['AttendanceSyllabus'][$attendanceIndex]['topics'][] = $topicName;
//                 }
//             }
//         }
//       }
      
//       // Reindex the array for consistent keys
//       $data = array_values($allBatchesData);
      
//       // Prepare the response
//       $response = [
//           'status' => '1',
//           'message' => 'Successfully Retrieved Data',
//           'error_msg' => null,
//           'data' => $data
//       ];
      
//       // Return the response
//       return response()->json($response);
//   }


public function StudentSyllabus(Request $request)
  {
    $startTime = microtime(true);
 
    $customerId = $request->customer_id;
    $courseId   = $request->course_id;
    $getstartTime = microtime(true);
    /*
    |--------------------------------------------------------------------------
    | 1️⃣ Get Training + Course Details (Small Query)
    |--------------------------------------------------------------------------
    */
    $training = DB::table('za_training')
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->where('za_training.customer_id', $customerId)
      ->where('za_training.course_id', $courseId)
      ->select(
        'za_training.customer_id',
        'za_training.course_id',
        'za_training.batch_id',
        'za_course.course_name',
        'za_course.course_duration',
        'za_course.course_partical_hours',
        'za_course.course_theory_hours',
        'za_course_subcategory.course_subcategory_name'
      )
      ->first();
 
    if (!$training) {
      return response()->json([
        'status' => '0',
        'message' => 'No Training Found',
        'error_msg' => 'Invalid customer or course',
        'data' => []
      ]);
    }
 
    $batchId = $training->batch_id;
 
    /*
    |--------------------------------------------------------------------------
    | 2️⃣ Get Syllabus (Small Table – No Attendance Join)
    |--------------------------------------------------------------------------
    */
    $syllabus = DB::table('za_syllabus_update')
      ->join('za_course_chapter', 'za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
      ->where('za_syllabus_update.course_id', $courseId)
      ->where('za_syllabus_update.batch_id', $batchId)
      ->select(
        'za_syllabus_update.date',
        'za_course_chapter.topic_name'
      )
      ->get()
      ->groupBy('date');
 
    /*
    |--------------------------------------------------------------------------
    | 3️⃣ Get Attendance (Filtered Only)
    |--------------------------------------------------------------------------
    */
    $attendance = DB::table('za_attendance')
      ->where('customer_id', $customerId)
      ->where('course_id', $courseId)
      ->where('batch_id', $batchId)
      ->select('att_date', 'attendance')
      ->get()
      ->groupBy('att_date');
 
    $getendTime       = microtime(true);
    $getexecutionTime = $getendTime - $getstartTime;
 
    /*
    |--------------------------------------------------------------------------
    | 4️⃣ Build Final Response (Fast PHP Merge)
    |--------------------------------------------------------------------------
    */
    $allBatchesData = [
      'coursesDetails' => [
        'customer_id' => $training->customer_id,
        'course_id' => $training->course_id,
        'batch_id' => $training->batch_id,
        'course_name' => $training->course_name,
        'course_duration' => $training->course_duration,
        'course_partical_hours' => $training->course_partical_hours,
        'course_theory_hours' => $training->course_theory_hours,
        'course_subcategory_name' => $training->course_subcategory_name,
      ],
      'AttendanceSyllabus' => []
    ];
 
    $secondstartTime = microtime(true);
    foreach ($attendance as $date => $attRows) {
 
      $attendanceStatus = $attRows->first()->attendance;
 
      $topics = [];
 
      if (isset($syllabus[$date])) {
        $topics = $syllabus[$date]
          ->pluck('topic_name')
          ->unique()
          ->values()
          ->toArray();
      }
 
      $allBatchesData['AttendanceSyllabus'][] = [
        'date' => $date,
        'attendance' => $attendanceStatus,
        'topics' => $topics
      ];
    }
 
    $endTime = microtime(true);
 
 
    $secondendTime       = microtime(true);
    $secondexecutionTime = $secondendTime - $secondstartTime;
 
    return response()->json([
      'status' => '1',
      'message' => 'Successfully Retrieved Data',
      'error_msg' => null,
      'data' => [$allBatchesData],
      'timer' => $endTime - $startTime,
      'gettimer' => $getexecutionTime,
      'secondtimer' => $secondexecutionTime,
    ]);
  }
 
  
  // payment History
//   public function paymentHistory(Request $request)
//   {
//     // Retrieve the customer ID from the request
//     $customerIdParam = $request->customer_id;
//     // return  $customerIdParam;
    
//     $redeemlist = DB::table('za_students_redeem')
//         ->where('student_id', $customerIdParam)
//         ->where('status', 0)
//         ->get();
//     $redeemSum = DB::table('za_students_redeem')
//         ->where('student_id', $customerIdParam)
//         ->where('status', 0)
//         ->sum('redeem_value');
        
//     // Fetch training details for the customer
//     $customer_training = TrainingModel::select('za_training.*', 'za_course.course_name')
//       ->where('za_training.customer_id', $customerIdParam)
//       ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
//       ->where('za_training.status', 0)
//       ->get();
//     // return  $customer_training;

//     $formattedPaymentHistory = [];

//     // Iterate through each training record
//     foreach ($customer_training as $ct_list) {
//       // Fetch payment details for the current training record
//       $payments_details = PaymentModel::select('*')
//         ->where('payment_id', $ct_list->payment_id)
//         ->where('status', 1)
//         ->get();

//       foreach ($payments_details as $p => $payment) {
//         // Initialize the course entry in the formatted payment history if not already present
//         if (!isset($formattedPaymentHistory[$payment->course_id])) {
//           $formattedPaymentHistory[$payment->course_id] = [
//             'course_name' => $ct_list->course_name,
//             'course_id' => $ct_list->course_id,
//             'total_amount' => $ct_list->overall_fees,
//             'customer_id' => $ct_list->customer_id,
//             'paidAmount' => $ct_list->paid_amount,
//             'balanceFee' => $ct_list->balance_amount,
//             'payment_history' => []
//           ];
//         }

//         // Append the current payment details to the payment history
//         $formattedPaymentHistory[$payment->course_id]['payment_history'][] = [
//           'payment_date' => $payment->initialPayDate,
//           'payment_historycustomer_id' => $payment->customer_id,
//           'amount' => $payment->paidAmount,
//           'paymentmode_name' => $payment->payment_mode_label ?? 'Cash',
//           'payment_id' => $payment->payment_id
//         ];
//       }
//     }

//     // Return the formatted payment history
//     // return $formattedPaymentHistory;

//     $formattedPaymentHistory = array_values($formattedPaymentHistory);

//     // return $payments_details;

//     // return $formattedPaymentHistory;

//     if ($formattedPaymentHistory) {
//       return response()->json([
//         'status' => 200,
//         'message' => 'Successfully Retrieved Data',
//         'error_msg' => null,
//         'data' => $formattedPaymentHistory,
//         'redeemlist'    => $redeemlist,
//         'redeemValue'    => $redeemSum,
//       ], 200);
//     } else {
//       return response()->json([
//         'status' => 200,
//         'message' => 'Data not found',
//         'error_msg' => null,
//         'data' => [],
//         'redeemlist'    =>  [],
//         'redeemValue'    =>  [],
//       ], 200);
//     }
//   }

// payment History

   public function paymentHistory(Request $request)

  {

    // Retrieve the customer ID from the request

    $customerIdParam = $request->customer_id;

    // return  $customerIdParam;

 

    $redeemlist = DB::table('za_students_redeem')

      ->where('student_id', $customerIdParam)

      ->where('status', 0)

      ->get();

    $redeemSum = DB::table('za_students_redeem')

      ->where('student_id', $customerIdParam)

      ->where('status', 0)

      ->sum('redeem_value');

 

    // Fetch training details for the customer

    $customer_training = TrainingModel::select('za_training.*', 'za_course.course_name')

      ->where('za_training.customer_id', $customerIdParam)

      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')

      ->where('za_training.status', 0)

      ->get();

    // return  $customer_training;

 

    $formattedPaymentHistory = [];

 

    // Iterate through each training record

    foreach ($customer_training as $ct_list) {

 

      $branch = BranchModel::where('sno', $ct_list->branch_id)->first();

      $gstPercentage = $branch->gst_percentage ?? 0;

 

      $applyGst = function ($amount) use ($gstPercentage) {

        return round($amount + (($amount * $gstPercentage) / 100), 2);

      };

      // Fetch payment details for the current training record

      $payments_details = PaymentModel::select('*')

        ->where('payment_id', $ct_list->payment_id)

        ->where('status', 1)

        ->get();

 

      foreach ($payments_details as $p => $payment) {

        // Initialize the course entry in the formatted payment history if not already present

        if (!isset($formattedPaymentHistory[$payment->course_id])) {

          $formattedPaymentHistory[$payment->course_id] = [

            'course_name' => $ct_list->course_name,

            'course_id' => $ct_list->course_id,

            'total_amount' => round($applyGst($ct_list->overall_fees)),

            'customer_id'  => $ct_list->customer_id,

            'paidAmount'   => round($applyGst($ct_list->paid_amount)),

            'balanceFee'   => round($applyGst($ct_list->balance_amount)),

            'payment_history' => []

          ];

        }

 

        // Append the current payment details to the payment history

        $formattedPaymentHistory[$payment->course_id]['payment_history'][] = [

          'payment_date' => $payment->initialPayDate,

          'payment_historycustomer_id' => $payment->customer_id,

          'amount' => round($applyGst($payment->paidAmount)),

          'paymentmode_name' => $payment->payment_mode_label ?? 'Cash',

          'payment_id' => $payment->payment_id

        ];

      }

    }

 

    // Return the formatted payment history

    // return $formattedPaymentHistory;

 

    $formattedPaymentHistory = array_values($formattedPaymentHistory);

 

    // return $payments_details;

 

    // return $formattedPaymentHistory;

 

    if ($formattedPaymentHistory) {

      return response()->json([

        'status' => 200,

        'message' => 'Successfully Retrieved Data',

        'error_msg' => null,

        'data' => $formattedPaymentHistory,

        'redeemlist'    => $redeemlist,

        'redeemValue'    => $redeemSum,

      ], 200);

    } else {

      return response()->json([

        'status' => 200,

        'message' => 'Data not found',

        'error_msg' => null,

        'data' => [],

        'redeemlist'    =>  [],

        'redeemValue'    =>  [],

      ], 200);

    }

  }

 






//   public function IssueNoteAdd(Request $request)
//     {
//         $validator = Validator::make($request->all(), [
//             'customer_id' => 'required|max:255',
//             'issue' => 'required|max:255',
//             'category' => 'required|max:255',
//         ]);
    
//         if ($validator->fails()) {
//             return response()->json([
//                 'status' => 422,
//                 'message' => 'Incorrect format input fields',
//                 'errors' => $validator->errors()
//             ], 422);
//         }
    
//         $customer_id = $request->customer_id;
//         $issue = $request->issue;
//         $category = $request->category;
//         $priority_level = $request->priority_level;
    
//         $customer = DB::table('za_customer')->where('sno', $customer_id)->first();
//         if (!$customer) {
//             return response()->json([
//                 'status' => 0,
//                 'message' => 'Customer not found',
//                 'data' => []
//             ], 404);
//         }
    
//         $branch_id = $customer->branch_id;
//         $user_id = $customer_id;
    
//         // Handle base64 attachment
//         $attachment = '';
//         $attachment_image_base64 = $request->input('attachment');
    
//         if ($attachment_image_base64) {
//             // Remove base64 prefix if exists
//             if (strpos($attachment_image_base64, ',') !== false) {
//                 $base64_image = explode(',', $attachment_image_base64)[1];
//             } else {
//                 $base64_image = $attachment_image_base64;
//             }
    
//             $decoded_image = base64_decode($base64_image);
//             if ($decoded_image !== false) {
//                 // Generate a unique filename
//                 $imageName = 'audit_' . time() . '_' . rand(1000, 9999) . '.png';
    
//                 // Ensure directory exists
//                 $directory = public_path('issue_attachment');
//                 if (!file_exists($directory)) {
//                     mkdir($directory, 0777, true);
//                 }
    
//                 // Save the image
//                 file_put_contents($directory . '/' . $imageName, $decoded_image);
    
//                 $attachment = $imageName;
//             }
//         }
    
//         // Generate unique issue ID
//         $add_issue = IssueNoteModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
//         if (!$add_issue) {
//             $year = substr(date('y'), -2);
//             $issue_id = 'ISN-0001/' . $year;
//         } else {
//             $data = $add_issue->issue_id;
//             $slice = explode('/', $data);
//             $result = preg_replace('/[^0-9]/', '', $slice[0]);
//             $next_number = (int)$result + 1;
//             $requestId = sprintf('ISN-%04d', $next_number);
//             $year = substr(date('y'), -2);
//             $issue_id = $requestId . '/' . $year;
//         }
    
//         // Save issue note
//         $add = new IssueNoteModel();
//         $add->issue_id = $issue_id;
//         $add->customer_id = $customer_id;
//         $add->issue = $issue;
//         $add->category = $category;
//         $add->priority_level = $priority_level;
//         $add->attachment = $attachment;
//         $add->branch_id = $branch_id;
//         $add->created_by = $user_id;
//         $add->updated_by = $user_id;
//         $add->save();
    
//         if ($add) {
//             return response()->json([
//                 'status' => 200,
//                 'message' => 'Query submitted successfully',
//             ], 200);
//         } else {
//             return response()->json([
//                 'status' => 500,
//                 'message' => 'Query not found',
//             ], 500);
//         }
//     }


  public function IssueNoteList(Request $request)
{
    $customerIdParam = $request->customer_id;

    $issue_notes = IssueNoteModel::select(
        'za_issue_note.sno as issue_sno',
        'za_issue_note.issue_id',
        'za_issue_note.created_at',
        'za_issue_note.issue',
        'za_issue_note.category',
        'za_issue_note.priority_level',
        'za_issue_note.attachment',
        'za_issue_note.status as issue_status',
        'za_issue_note.description',
        'za_issue_note.authority_done',
        'za_staff.staff_name',
        'za_customer.cus_name',
        'za_customer.sno as cus_sno',
        'za_customer.branch_id as cus_branch_id',
        'za_customer.customer_id'
    )
    ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno')
    ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
    ->where('za_issue_note.customer_id', $customerIdParam)
    ->orderBy('za_issue_note.sno', 'desc')
    ->get();

    $baseUrl = 'https://erp.elysium.academy/issue_attachment/';

    $issue_notes->transform(function ($note) use ($baseUrl) {
        // Add attachment URL
        $note->attachment_url = $note->attachment ? $baseUrl . $note->attachment : null;

        // Apply description visibility rule
        if (empty($note->authority_done) || $note->authority_done != 1) {
            $note->description = null;
        }

        return $note;
    });

    if ($issue_notes->isNotEmpty()) {
        return response()->json([
            'status' => 200,
            'message' => 'Successfully Retrieved Data',
            'error_msg' => null,
            'data' => $issue_notes
        ], 200);
    } else {
        return response()->json([
            'status' => 200,
            'message' => 'Issue Note not found',
            'data' => []
        ], 200);
    }
}

//   public function IssueNoteConversation(Request $request)
// {
//     $customerId = $request->customer_id;

//     $issues = IssueNoteModel::select(
//         'za_issue_note.sno as issue_sno',
//         'za_issue_note.issue_id',
//         'za_issue_note.created_at',
//         'za_issue_note.issue as conversation', // customer message
//         'za_issue_note.description as reply',  // staff reply
//         'za_issue_note.attachment',
//         'za_issue_note.status',
//         'za_staff.staff_name',
//         'za_customer.cus_name',
//         'za_customer.sno as cus_sno',
//         'za_customer.branch_id as cus_branch_id'
//     )
//     ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno')
//     ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
//     ->where('za_issue_note.customer_id', $customerId)
//     ->orderBy('za_issue_note.created_at', 'asc') // chronological order
//     ->get();

//     $baseUrl = 'https://erp.elysium.academy/issue_attachment/';

//     // Transform data into conversation format
//     $conversation = [];

//     foreach ($issues as $issue) {
//         // $timestamp = Carbon\Carbon::parse($issue->created_at)->format('d M Y, h:i A');
//         $timestamp = Carbon::parse($issue->created_at)->format('d M Y, h:i A');
//         $timestampstaff = Carbon::parse($issue->closed_date)->format('d M Y, h:i A');
//         // Customer message
//         if (!empty($issue->conversation)) {
//             $conversation[] = [
//                 'sender'      => 'Student',
//                 'name'        => $issue->cus_name,
//                 'message'     => $issue->conversation,
//                 'attachment'  => $issue->attachment ? $baseUrl . $issue->attachment : null,
//                 'timestamp'   => $timestamp,
//                 'issue_id'    => $issue->sno,
//             ];
//         }

//         // Staff reply
//         if (!empty($issue->reply)) {
//             $conversation[] = [
//                 'sender'      => 'staff',
//                 'name'        => $issue->staff_name??'',
//                 'message'     => $issue->reply,
//                 'attachment'  => null, // can extend later if staff attachments are added
//                 'timestamp'   => $timestampstaff,
//                 'issue_id'    => $issue->sno,
//             ];
//         }
//     }

//     if (empty($conversation)) {
//         return response()->json([
//             'status'  => 200,
//             'message' => 'No conversations found for this customer.',
//             'data'    => [],
//         ], 200);
//     }

//     return response()->json([
//         'status'  => 200,
//         'message' => 'Conversation retrieved successfully.',
//         'data'    => $conversation,
//     ], 200);
// }
// public function IssueNoteConversation(Request $request)
// {
//     $customerId = $request->customer_id;

//     $issues = IssueNoteModel::select(
//         'za_issue_note.sno as issue_sno',
//         'za_issue_note.issue_id',
//         'za_issue_note.created_at',
//         'za_issue_note.closed_date',
//         'za_issue_note.issue as conversation', // student message
//         'za_issue_note.description as reply',  // staff reply
//         'za_issue_note.attachment',
//         'za_issue_note.status',
//         'za_staff.staff_name',
//         'za_customer.cus_name',
//         'za_customer.sno as cus_sno',
//         'za_customer.branch_id as cus_branch_id'
//     )
//     ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno')
//     ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
//     ->where('za_issue_note.customer_id', $customerId)
//     ->orderBy('za_issue_note.created_at', 'desc')
//     ->get();

//     $baseUrl = 'https://erp.elysium.academy/issue_attachment/';

//     $groupedConversations = [];

//     foreach ($issues as $issue) {
//         $issueId = $issue->issue_sno;

//         // Initialize if not already
//         if (!isset($groupedConversations[$issueId])) {
//             $groupedConversations[$issueId] = [
//                 'issue_id'   => $issueId,
//                 'conversation_list' => [],
//             ];
//         }

//         // Student message
//         if (!empty($issue->conversation)) {
//             $groupedConversations[$issueId]['conversation_list'][] = [
//                 'sender'     => 'Student',
//                 'name'       => $issue->cus_name,
//                 'message'    => $issue->conversation,
//                 'attachment' => $issue->attachment ? $baseUrl . $issue->attachment : null,
//                 'timestamp'  => Carbon::parse($issue->created_at)->format('d M Y, h:i A'),
//             ];
//         }

//         // Staff reply
//         if (!empty($issue->reply)) {
//             $groupedConversations[$issueId]['conversation_list'][] = [
//                 'sender'     => 'Staff',
//                 'name'       => $issue->staff_name ?? '',
//                 'message'    => $issue->reply,
//                 'attachment' => null, // Add later if staff uploads allowed
//                 'timestamp'  => $issue->closed_date
//                     ? Carbon::parse($issue->closed_date)->format('d M Y, h:i A')
//                     : Carbon::parse($issue->created_at)->format('d M Y, h:i A'),
//             ];
//         }
//     }

//     // Reindex grouped data
//     $groupedConversations = array_values($groupedConversations);

//     if (empty($groupedConversations)) {
//         return response()->json([
//             'status'  => 200,
//             'message' => 'No conversations found for this customer.',
//             'data'    => [],
//         ], 200);
//     }

//     return response()->json([
//         'status'  => 200,
//         'message' => 'Conversations retrieved successfully.',
//         'data'    => $groupedConversations,
//     ], 200);
// }


   public function profileChange(Request $request)
 {
    $validator = Validator::make($request->all(), [
        'customer_id' => 'required',
        'attachment' => 'nullable|string', // base64 image string
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Incorrect format input fields',
            'errors' => $validator->errors()
        ], 422);
    }

    $customer_id = $request->customer_id;

    // Fetch the customer record
    $customer_upd = CustomerModel::where('sno', $customer_id)->first();

    if (!$customer_upd) {
        return response()->json([
            'status' => 0,
            'message' => 'Customer not found',
            'data' => []
        ], 404);
    }

    $attachment_image_base64 = $request->input('attachment');
    $attachment = '';

    // ✅ Handle base64 image upload
    if ($attachment_image_base64) {
        // Remove base64 header if present
        if (strpos($attachment_image_base64, ',') !== false) {
            $base64_image = explode(',', $attachment_image_base64)[1];
        } else {
            $base64_image = $attachment_image_base64;
        }

        $decoded_image = base64_decode($base64_image);

        if ($decoded_image !== false) {
            $imageName = 'cus_' . time() . '_' . rand(1000, 9999) . '.png';

            $directory = public_path('cus_pics');
            if (!file_exists($directory)) {
                mkdir($directory, 0777, true);
            }

            file_put_contents($directory . '/' . $imageName, $decoded_image);
            $attachment = $imageName;
        }
    }

    // ✅ Update profile picture if uploaded
    if ($attachment !== '') {
        $customer_upd->cus_pic = $attachment;
        $customer_upd->update();
    }

    // Optional: send notification or log
    $this->sendNotification(
        $customer_upd->branch_id,
        $customer_upd->sno,
        "Profile picture updated successfully.",
        "Student App",
        $customer_upd->sno
    );

    return response()->json([
        'status' => 1,
        'message' => 'Profile picture updated successfully',
        'data' => [
            'customer_id' => $customer_upd->sno,
            'cus_pic' => $customer_upd->cus_pic ? url('cus_pics/' . $customer_upd->cus_pic) : null
        ]
    ], 200);
}

   public function AttendanceFeedback(Request $request)
   {
    $helper = new \App\Helpers\Helpers();
      // Validate input fields
      $validator = Validator::make($request->all(), [
          'attendance_id' => 'required|integer', // Assuming attendance_id is an integer
          'feedback_score' => 'required|integer|min:1|max:5',  // Assuming feedback score is between 1 and 5
          'feedback' => 'required|string|max:1000', // Feedback text can be longer
      ]);
  
      // Check if validation fails
      if ($validator->fails()) {
          return response()->json([
              'status' => 422,
              'message' => 'Incorrect format input fields',
              'errors' => $validator->errors()
          ], 422);
      }
  
      // Retrieve validated input values
      $attendance_id = $request->attendance_id;
      $feedback_score = $request->feedback_score;
      $feedback = $request->feedback;
  
      // Fetch the attendance record
      $attendanceRecord = AttendanceModel::where('sno', $attendance_id)->first();
      if ($attendanceRecord) {
          // Update the feedback for the attendance record
          $updResult = $attendanceRecord->update([
              'feedback_score' => $feedback_score,
              'feedback' => $feedback
          ]);

          // Return success or failure response based on update result
          if ($updResult) {
              $pointsDataFullAttendance = $helper->get_points_by_id(22); // Points for P
              $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
              $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
    
              // Save new points for the staff (full attendance)
              $newPointsFull = new StudentpointsModel();
              $newPointsFull->branch_id = $attendanceRecord->branch_id;
              $newPointsFull->student_id = $attendanceRecord->customer_id;
              $newPointsFull->points_id = 22;
              $newPointsFull->points = $pointFull;
              $newPointsFull->reason = $reasonFull;
              $newPointsFull->save();
    
              // Update staff's available points
              $student_points = CustomerModel::where('sno', $attendanceRecord->customer_id)->first();
              if ($student_points) {
                  $student_points->points_score += $pointFull;
                  $student_points->save();
              }
                    $this->sendNotification(
                        $attendanceRecord->branch_id,
                        $attendanceRecord->customer_id,
                        "You have been rewarded +2 coins for attendance feedback.",
                        "Student App",
                        $attendanceRecord->customer_id
                    );
              return response()->json([
                  'status' => 200,
                  'message' => 'Feedback submitted successfully',
              ], 200);
          } else {
              return response()->json([
                  'status' => 500,
                  'message' => 'Something went wrong while submitting the feedback!',
              ], 500);
          }
      } else {
          return response()->json([
              'status' => 404,
              'message' => 'Attendance not available for the given ID!',
          ], 404);
      }
    }
    
    public function CourseTopic(Request $request)
    {


    $batch_id = $request->batch_id;
    $date = $request->date;

    $customerIdParam = $request->customer_id;
    $courseId = $request->course_id;

    $stud_syllabus = CustomerModel::select(
      'za_training.customer_id',
      'za_training.course_id',
      'za_training.batch_id',
      'za_course.course_name',
      'za_course.course_duration',
      'za_course.course_partical_hours',
      'za_course.course_theory_hours',
      'za_course_subcategory.course_subcategory_name',
      'za_syllabus_update.course_id AS syb_course_id',
      'za_syllabus_update.batch_id AS syb_batch_id',
      'za_syllabus_update.topic_id',
      'za_syllabus_update.date AS syb_date',
      'za_attendance.att_date',
      'za_attendance.attendance',
      'za_course_chapter.topic_name',
      'za_course_chapter.course_chapter_duration',
      'za_course_chapter.course_chapter_theory_hours',
      'za_course_chapter.course_chapter_practical_hours'
    )
      ->join('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->leftJoin('za_syllabus_update', function ($join) {
        $join->on('za_training.batch_id', '=', 'za_syllabus_update.batch_id')
          ->on('za_training.course_id', '=', 'za_syllabus_update.course_id');
      })
      ->leftJoin('za_attendance', 'za_syllabus_update.batch_id', '=', 'za_attendance.batch_id')
      ->leftJoin('za_course_chapter', 'za_syllabus_update.topic_id', '=', 'za_course_chapter.topic_id')
      ->where('za_training.course_id', $courseId)
      ->where('za_training.customer_id', $customerIdParam)
      ->get();

    // Initialize an array to store the final structured data
    $allBatchesData = [];

    foreach ($stud_syllabus as $item) {
      // Create a unique key for each course and batch combination
      $key = $item->course_id . '_' . $item->batch_id;

      // If the course key doesn't exist, initialize it
      if (!isset($allBatchesData[$key])) {
        $allBatchesData[$key] = [
          'coursesDetails' => [
            'customer_id' => $item->customer_id,
            'course_id' => $item->course_id,
            'batch_id' => $item->batch_id,
            'course_name' => $item->course_name,
            'course_duration' => $item->course_duration,
            'course_partical_hours' => $item->course_partical_hours,
            'course_theory_hours' => $item->course_theory_hours,
            'course_subcategory_name' => $item->course_subcategory_name,
          ],
          'AttendanceSyllabus' => [] // Initialize AttendanceSyllabus as an empty array
        ];
      }

      // Check if the date and attendance combination already exists in the AttendanceSyllabus
      $attendanceIndex = null;
      foreach ($allBatchesData[$key]['AttendanceSyllabus'] as $index => $attendanceItem) {
        if ($attendanceItem['date'] == $item->att_date && $attendanceItem['attendance'] == $item->attendance) {
          $attendanceIndex = $index;
          break;
        }
      }

      // If there's no match, create a new entry for the date and attendance
      if ($attendanceIndex === null) {
        $allBatchesData[$key]['AttendanceSyllabus'][] = [
          'date' => $item->att_date,
          'attendance' => $item->attendance,
          'topics' => []
        ];

        // Find the index of the new entry
        $attendanceIndex = count($allBatchesData[$key]['AttendanceSyllabus']) - 1;
      }

      // Only append the topic name if syb_date matches att_date
      // Also, prevent duplicates by checking if the topic already exists
      if ($item->syb_date == $item->att_date) {
        $topicName = $item->topic_name;
        // Check if the topic is already in the topics array for this date/attendance
        if (!in_array($topicName, $allBatchesData[$key]['AttendanceSyllabus'][$attendanceIndex]['topics'])) {
          $allBatchesData[$key]['AttendanceSyllabus'][$attendanceIndex]['topics'][] = $topicName;
        }
      }
    }

    // Reindex the array for consistent keys
    $data = array_values($allBatchesData);
      if($data) {
        // Prepare the response
        $response = [
          'status' => '1',
          'message' => 'Successfully Retrieved Data',
          'error_msg' => null,
          'data' => $data
        ];
      }else{
        return response()->json([
          'status' => '2',
          'message' => 'Data not found',
          'error_msg' => null,
          'data' => null
        ], 200);
      }

    // Return the response
    return response()->json($response);
  }
   public function StudentJobInteresetAdd(Request $request)
   {
    // return $request;
    $user_id = 2;

    $validator = Validator::make($request->all(), [
      'customer_id' => 'required|max:255',
      'job_id' => 'required|max:255',
      'company_id' => 'required|max:255',
      // 'attachment' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      // If validation fails, return error response
      return response()->json([
        'status' => 422,
        'message' => 'Incorrect format input fields',
        'errors' => $validator->errors()
      ], 422);
    }

    // If validation passes
    $interested = $request->interested;
    $customer_id = $request->customer_id;
    $job_name_id = $request->job_id;
    $company_id = $request->company_id;

    if ($interested) {
      $add = CustomerPlacementModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


      // Add the category to the database
      $add = new CustomerPlacementModel();
      $add->job_name_id = $job_name_id;
      $add->customer_id = $customer_id;
      $add->company_id = $company_id;
      $add->created_by = $user_id;
      $add->updated_by = $user_id;

      // return $add;

      $add->save();
    }

        if($add){

            return response()->json([
              'status' => 200,
              'message' => 'Job Interest submitted successfully',
              // 'data' => $add
            ], 200);
        } else{
          return response()->json([
            'status' => '2',
            'message' => 'No Data found',
            'error_msg' => null,
            'data' => null
          ], 200);
    }
  }

  //**********************************Rosini***********************************//
   // batch details
   public function Batchdetails(Request $request)
   {
    $customer_id = $request->input('customer_id');
    $course_id = $request->input('course_id');

    $batch = BatchModel::select(
      'za_batch.sno as batch_sno',
      'za_batch.batch_id as auto_increment_id',
      'za_batch.batch_name',
      'za_batch.course_type_id',
      'za_batch.course_id',
      'za_batch.slot_id',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.classroom_id',
      'za_batch.staff_id',
      'za_batch.batch_desc',
      'za_batch.status',
      'za_slot.slot_name',
      'za_course.course_name',
      'za_training.customer_id',
      'za_training.course_id',
      'za_course_type.course_type_name',
      'za_course.course_duration',
      'za_course.course_version',
      'za_class_room.class_room_name',
      'za_class_room.class_room_type',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.staff_id'
    )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_training.course_id', '=', $course_id)
      ->where('za_training.customer_id', '=', $customer_id)
      ->whereNotIn('za_batch.status', [2, 3])
      ->first();

    if (!$batch) {
      return response()->json([
        'status' => 200,
        'message' => 'Batch Not Found',
        'error_msg' => null,
        'data' => []
      ], 200);
    }

    $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    $slotDays = json_decode($batch->slot_type_days);
    if ($slotDays) {
      $batch->slot_type_days = array_map(function ($day) use ($days) {
        return $days[$day - 1];
      }, $slotDays);
    } else {
      $batch->slot_type_days = [];
    }
    if($batch) {
        return response()->json([
          'status' => 200,
          'error_msg' => null,
          'data' => $batch
        ], 200);
    }else{
        return response()->json([
          'status' => 200,
          'error_msg' => null,
          'data' => null
        ], 200);
    }
  }
    public function AttendanceList(Request $request)
    {
      $customer_id = $request->input('customer_id');
      $course_id = $request->input('course_id');
  
      $batch = BatchModel::select(
          'za_batch.sno as batch_sno',
          'za_batch.batch_id as auto_increment_id',
          'za_batch.batch_name',
          'za_batch.course_type_id',
          'za_batch.course_id',
          'za_batch.slot_id',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_batch.classroom_id',
          'za_batch.staff_id',
          'za_batch.batch_desc',
          'za_batch.status',
          'za_slot.slot_name',
          'za_course.course_name',
          'za_training.customer_id',
          'za_training.course_id',
          'za_training.sno as training_sno',
          'za_customer.sno as customer_sno',
          'za_course_type.course_type_name',
          'za_course.course_duration',
          'za_course.course_version',
          'za_class_room.class_room_name',
          'za_class_room.class_room_type',
          'za_slot_type.slot_type_name',
          'za_slot.start_time',
          'za_slot.end_time',
          'za_slot.slot_type_days as slot_days',
          'za_staff.staff_name',
          'za_staff.staff_id'
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
      ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_training.course_id', '=', $course_id)
      ->where('za_training.customer_id', '=', $customer_id)
      ->whereNotIn('za_batch.status', [2, 3])
      ->first();
  
      // Ensure that batch is found
      if (!$batch) {
          return response()->json([
              'status' => 404,
              'message' => 'Batch not found',
              'error_msg' => null,
              'attendance' => []
          ], 404);
      }
  
      // Decode slot_type_days
      if (!empty($batch->slot_days)) {
          $decoded_days = json_decode($batch->slot_days, true);
          if (json_last_error() !== JSON_ERROR_NONE) {
              $decoded_days = []; 
          }
          $batch->slot_type_days = $decoded_days;
      }
  
      $attendanceRecords = AttendanceModel::where('customer_id', $customer_id)
          ->where('course_id', $course_id)
          ->whereBetween('att_date', [$batch->start_date, $batch->end_date]) // Use whereBetween for date range
          ->get();
  
      // Check if attendance records were found
      if ($attendanceRecords->isEmpty()) {
          return response()->json([
              'status' => 404,
              'message' => 'Attendance not found',
              'error_msg' => null,
              'attendance' => [],
              'batch' => $batch
          ], 404);
      }
      // Add day_count column
        $attendanceWithDayCount = $attendanceRecords->values()->map(function ($record, $index) {
            $record->day_count = $index + 1; // start from 1
            return $record;
        });
      if($attendanceRecords || $batch) {
          return response()->json([
              'status' => 200,
              'message' => 'Successfully Retrieved Attendance Details',
              'error_msg' => null,
              'attendance' => $attendanceRecords,
              'batch' => $batch
          ], 200);
      } else {
          return response()->json([
            'status' => 200,
            'message' => 'Attendance Details not Found',
            'error_msg' => null,
            'attendance' => null,
            'batch' => null
        ], 200);
        }
  }
  
    //  public function AttendanceChapter(Request $request)
    // {
    //     $batch_id = $request->input('batch_id');
    //     $course_id = $request->input('course_id');
    //     $att_date  = $request->input('att_date');
    //     $branch_id = $request->input('branch_id');
    
    //     // ✅ Fetch attendance record
    //     $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batch_id)
    //         ->where('course_id', $course_id)
    //         ->where('branch_id', $branch_id)
    //         ->whereDate('date', $att_date)
    //         ->get();
    
    //     if ($syllabusUpdates->isEmpty()) {
    //         return response()->json([
    //             'status' => 200,
    //             'message' => 'No attendance data found',
    //             'data' => [],
    //         ]);
    //     }
    
    //     $allBatchesData = [];
    
    //     // ✅ Loop through each attendance record
    //     foreach ($syllabusUpdates as $syllabusUpdate) {
    //         // Example: "chapter_id": "CCH-0060/25"
    //         $chapter_id = $syllabusUpdate->chapter_id;
    
    //         // ✅ Get chapter details by chapter_id
    //         $chapterDetails = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
    //             ->select(
    //                 'course_chapter_id',
    //                 'course_chapter_name',
    //                 'course_chapter_theory_hours',
    //                 'course_chapter_practical_hours',
    //                 'course_id',
    //                 'sno'
    //             )
    //             ->groupBy(
    //                 'course_chapter_id',
    //                 'course_chapter_name',
    //                 'course_chapter_theory_hours',
    //                 'course_chapter_practical_hours',
    //                 'course_id',
    //                 'sno'
    //             )
    //             ->get();
    
    //         $sections = [];
    
    //         foreach ($chapterDetails as $chapter) {
    //             // ✅ Fetch all sections
    //             $latest_sections = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter->course_chapter_id)
    //                 ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
    //                 ->groupBy('session_id', 'session_name')
    //                 ->get();
    
    //             foreach ($latest_sections as $sec) {
    //                 // ✅ Fetch all topics
    //                 $latest_topics = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter->course_chapter_id)
    //                     ->where('session_id', $sec->session_id)
    //                     ->select('topic_id', 'topic_name', 'course_chapter_description', DB::raw('MAX(sno) as max_sno'))
    //                     ->groupBy('topic_id', 'topic_name', 'course_chapter_description')
    //                     ->get();
    
    //                 $topics = [];
    //                 foreach ($latest_topics as $topic) {
    //                     $topics[] = [
    //                         'topic_id' => $topic->topic_id,
    //                         'topic_name' => $topic->topic_name,
    //                         'topic_description' => $topic->course_chapter_description,
    //                         'max_sno' => $topic->max_sno,
    //                     ];
    //                 }
    
    //                 $sections[] = [
    //                     'section_id' => $sec->session_id,
    //                     'section_name' => $sec->session_name,
    //                     'max_sno' => $sec->max_sno,
    //                     'topics' => $topics,
    //                 ];
    //             }
    //         }
    
    //         $allBatchesData[] = [
    //             'chapter_id' => $chapter_id,
    //             'chapterDetails' => $chapterDetails,
    //             'sections' => $sections,
    //         ];
    //     }
    
    //     return response()->json([
    //         'status' => 200,
    //         'message' => 'Attendance data retrieved successfully',
    //         'data' => $allBatchesData,
    //     ]);
    // }
    
    public function AttendanceChapter(Request $request)
    {
        $batch_id = $request->input('batch_id');
        $course_id = $request->input('course_id');
        $att_date  = $request->input('att_date');
        $branch_id = $request->input('branch_id');
    
        // ✅ Fetch attendance record
        $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batch_id)
            ->where('course_id', $course_id)
            ->where('branch_id', $branch_id)
            ->whereDate('date', $att_date)
            ->get();
    
        if ($syllabusUpdates->isEmpty()) {
            return response()->json([
                'status' => 200,
                'message' => 'No attendance data found',
                'data' => [],
            ]);
        }
    
        $allBatchesData = [];
    
        // ✅ Loop through each attendance record
        foreach ($syllabusUpdates as $syllabusUpdate) {
    
            $chapter_id = $syllabusUpdate->chapter_id;
            $section_id = $syllabusUpdate->section_id;
            $topic_id   = $syllabusUpdate->topic_id;
    
            // ✅ Get specific chapter details
            $chapterDetails = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
                ->select(
                    'course_chapter_id',
                    'course_chapter_name',
                    'course_chapter_theory_hours',
                    'course_chapter_practical_hours',
                    'course_id',
                    'sno'
                )
                ->first(); // only one chapter
    
            if (!$chapterDetails) continue;
    
            // ✅ Fetch only the matching section from syllabus
            $section = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
                ->where('session_id', $section_id)
                ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
                ->groupBy('session_id', 'session_name')
                ->first();
    
            $sections = [];
            $topics = [];
    
            if ($section) {
                // ✅ Fetch only the matching topic from syllabus
                $topic = ManageCoursesSyllabusModel::where('course_chapter_id', $chapter_id)
                    ->where('session_id', $section_id)
                    ->where('topic_id', $topic_id)
                    ->select('topic_id', 'topic_name', 'course_chapter_description', DB::raw('MAX(sno) as max_sno'))
                    ->groupBy('topic_id', 'topic_name', 'course_chapter_description')
                    ->first();
    
                if ($topic) {
                    $topics[] = [
                        'topic_id' => $topic->topic_id,
                        'topic_name' => $topic->topic_name,
                        'topic_description' => $topic->course_chapter_description,
                        'max_sno' => $topic->max_sno,
                    ];
                }
    
                $sections[] = [
                    'section_id' => $section->session_id,
                    'section_name' => $section->session_name,
                    'max_sno' => $section->max_sno,
                    'topics' => $topics,
                ];
            }
    
            // ✅ Final structured output
            $allBatchesData[] = [
                'chapter_id' => $chapter_id,
                'chapter_name' => $chapterDetails->course_chapter_name,
                'chapterDetails' => $chapterDetails,
                'sections' => $sections,
            ];
        }
    
        return response()->json([
            'status' => 200,
            'message' => 'Attendance data retrieved successfully',
            'data' => $allBatchesData,
        ]);
    }

   //**********************************Akilan***********************************//
   
// public function studentChapterDetails(Request $request)
//   {
//     $customer_id = $request->customer_id;
//     $course_id   = $request->course_id;
 
//     $helper = new \App\Helpers\Helpers();
//     $view = ManageCoursesModel::where('sno', $course_id)
//       ->where('status', 0)
//       ->first();
 
//     if (!$view) {
//       return response()->json([
//         'status' => 404,
//         'message' => 'Course not found',
//         'error_msg' => 'Course View not found',
//       ]);
//     }
 
//     // ✅ Decode materials JSON
//     $materials = [];
//     if (!empty($view->materials)) {
//       $materials = json_decode($view->materials, true);
//     }
 
//     // ✅ Get all chapters
//     $chapter_views = ManageCoursesSyllabusModel::where('course_id', $course_id)
//       ->where('status', 0)
//       ->select(
//         'course_chapter_id',
//         'course_chapter_name',
//         'course_chapter_practical_hours',
//         'course_chapter_theory_hours',
//         DB::raw('MAX(sno) as max_sno')
//       )
//       ->groupBy(
//         'course_chapter_id',
//         'course_chapter_name',
//         'course_chapter_theory_hours',
//         'course_chapter_practical_hours'
//       )
//       ->get();
 
//     $chapters = [];
 
//     foreach ($chapter_views as $chapter) {
//       $chapter_id = $chapter->course_chapter_id;
 
//       $customer = DB::table('za_training')
//         ->where('customer_id', $customer_id)
//         ->where('course_id', $course_id)
//         ->first();
 
//       // Filter materials for this chapter
//       $chapterMaterials = collect($materials)->filter(function ($m) use ($chapter_id) {
//         if (!isset($m['chapter_id'])) return false;
//         return trim(str_replace('\/', '/', $m['chapter_id'])) ===
//           trim(str_replace('\/', '/', $chapter_id));
//       });
 
//       // Counts
//       $study_doc_count = $chapterMaterials->where('document_type_id', 1)->count();
//       $ppt_count       = $chapterMaterials->where('document_type_id', 2)->count();
//       $lab_code_count  = $chapterMaterials->where('document_type_id', 3)->count();
//       $pdf_count       = $chapterMaterials->where('document_type_id', 4)->count();
//       $audio_count     = $chapterMaterials->where('document_type_id', 5)->count();
 
//       // Flags
//       $has_study_doc = $study_doc_count > 0;
//       $has_ppt       = $ppt_count > 0;
//       $has_lab_code  = $lab_code_count > 0;
//       $has_pdf       = $pdf_count > 0;
//       $has_audio     = $audio_count > 0;
 
//       // Calculate status
//       $chapter_status = $helper->get_chapter_status($chapter->max_sno, $customer->batch_id);
 
//       // Generate **links** for each type
//       $study_doc_link = $chapterMaterials
//         ->where('document_type_id', 1)
//         ->map(fn($m) => url("course_materials/{$m['course_id']}/1/{$m['material_name']}"))
//         ->values(); // ✅ IMPORTANT
 
//       $ppt_link = $chapterMaterials
//         ->where('document_type_id', 2)
//         ->map(fn($m) => url("course_materials/{$m['course_id']}/2/{$m['material_name']}"))
//         ->values(); // ✅ IMPORTANT
 
//       $pdf_link = $chapterMaterials
//         ->where('document_type_id', 4)
//         ->map(fn($m) => url("course_materials/{$m['course_id']}/4/{$m['material_name']}"))
//         ->values(); // ✅ already correct but keep consistent
 
 
//       $audio_link = $chapterMaterials->where('document_type_id', 5)
//         ->map(fn($m) => url("course_materials/{$m['course_id']}/5/{$m['material_name']}"))
//         ->toArray();
 
//       $lab_codes = $chapterMaterials
//         ->where('document_type_id', 3)
//         ->map(function ($m) {
//           return [
//             'code_title'    => $m['code_title'],
//             'code_language' => $m['code_language'],
//             'code_content'  => $m['code_content'],
//             'block_index'   => $m['block_index'] ?? null,
//           ];
//         })
//         ->values();
 
//       $chapters[] = [
//         'chapter_code'            => $chapter_id,
//         'chapter_name'            => $chapter->course_chapter_name,
//         'chapter_theory_hours'    => round($chapter->course_chapter_theory_hours, 2),
//         'chapter_practical_hours' => round($chapter->course_chapter_practical_hours, 2),
//         'chapter_id'              => $chapter->max_sno,
//         'chapter_status'          => $chapter_status,
 
//         // Flags
//         'has_study_doc' => $has_study_doc,
//         'has_ppt'       => $has_ppt,
//         'has_lab_code'  => $has_lab_code,
//         'has_pdf'       => $has_pdf,
//         // 'has_audio'     => $has_audio,
 
//         // Counts
//         'study_doc_count' => $study_doc_count,
//         'ppt_count'       => $ppt_count,
//         'lab_code_count'  => $lab_code_count,
//         'pdf_count'       => $pdf_count,
//         // 'audio_count'     => $audio_count,
 
//         // Links
//         'study_doc_link' => $study_doc_link,
//         'ppt_link'       => $ppt_link,
//         'pdf_link'       => $pdf_link,
//         // 'audio_link'     => $audio_link,
 
//         'lab_codes'       => $lab_codes,
//       ];
//     }
 
 
//     return response()->json([
//       'status' => 200,
//       'message' => 'Data Retrieved Successfully',
//       'error_msg' => null,
//       'chapters' => $chapters,
//     ], 200);
//   }

public function studentChapterDetails(Request $request)
  {
    $customer_id = $request->customer_id;
    $course_id   = $request->course_id;
 
    $helper = new \App\Helpers\Helpers();
    $view = ManageCoursesModel::where('sno', $course_id)
      ->where('status', 0)
      ->first();
 
    if (!$view) {
      return response()->json([
        'status' => 404,
        'message' => 'Course not found',
        'error_msg' => 'Course View not found',
      ]);
    }
 
    // ✅ Decode materials JSON
    $materials = [];
    if (!empty($view->materials)) {
      $materials = json_decode($view->materials, true);
    }
 
    // ✅ Get all chapters
    $chapter_views = ManageCoursesSyllabusModel::where('course_id', $course_id)
      ->where('status', 0)
      ->select(
        'course_chapter_id',
        'course_chapter_name',
        'course_chapter_practical_hours',
        'course_chapter_theory_hours',
        DB::raw('MAX(sno) as max_sno')
      )
      ->groupBy(
        'course_chapter_id',
        'course_chapter_name',
        'course_chapter_theory_hours',
        'course_chapter_practical_hours'
      )
      ->get();
 
    $chapters = [];
 
    foreach ($chapter_views as $chapter) {
      $chapter_id = $chapter->course_chapter_id;
 
      $customer = DB::table('za_training')
        ->where('customer_id', $customer_id)
        ->where('course_id', $course_id)
        ->first();
 
      // Filter materials for this chapter
      $chapterMaterials = collect($materials)->filter(function ($m) use ($chapter_id) {
        if (!isset($m['chapter_id'])) return false;
        return trim(str_replace('\/', '/', $m['chapter_id'])) ===
          trim(str_replace('\/', '/', $chapter_id));
      });
 
      // Counts
      $study_doc_count = $chapterMaterials->where('document_type_id', 1)->count();
      $ppt_count       = $chapterMaterials->where('document_type_id', 2)->count();
      $lab_code_count  = $chapterMaterials->where('document_type_id', 3)->count();
      $pdf_count       = $chapterMaterials->where('document_type_id', 4)->count();
      $audio_count     = $chapterMaterials->where('document_type_id', 5)->count();
 
      // Flags
      $has_study_doc = $study_doc_count > 0;
      $has_ppt       = $ppt_count > 0;
      $has_lab_code  = $lab_code_count > 0;
      $has_pdf       = $pdf_count > 0;
      $has_audio     = $audio_count > 0;
 
      // Calculate status
      $chapter_status = $helper->get_chapter_status($chapter->max_sno, $customer->batch_id);
 
      // Generate **links** for each type
      $study_doc_link = $chapterMaterials
        ->where('document_type_id', 1)
        ->map(fn($m) => url("course_materials/{$m['course_id']}/1/{$m['material_name']}"))
        ->values(); // ✅ IMPORTANT
 
      $ppt_link = $chapterMaterials
        ->where('document_type_id', 2)
        ->map(fn($m) => url("course_materials/{$m['course_id']}/2/{$m['material_name']}"))
        ->values(); // ✅ IMPORTANT
 
      $pdf_link = $chapterMaterials
        ->where('document_type_id', 4)
        ->map(fn($m) => url("course_materials/{$m['course_id']}/4/{$m['material_name']}"))
        ->values(); // ✅ already correct but keep consistent
 
 
      $audio_link = $chapterMaterials->where('document_type_id', 5)
        ->map(fn($m) => url("course_materials/{$m['course_id']}/5/{$m['material_name']}"))
        ->values();
 
      $lab_codes = $chapterMaterials
        ->where('document_type_id', 3)
        ->map(function ($m) {
          return [
            'code_title'    => $m['code_title'],
            'code_language' => $m['code_language'],
            'code_content'  => $m['code_content'],
            'block_index'   => $m['block_index'] ?? null,
          ];
        })
        ->values();
 
      $chapters[] = [
        'chapter_code'            => $chapter_id,
        'chapter_name'            => $chapter->course_chapter_name,
        'chapter_theory_hours'    => round($chapter->course_chapter_theory_hours, 2),
        'chapter_practical_hours' => round($chapter->course_chapter_practical_hours, 2),
        'chapter_id'              => $chapter->max_sno,
        'chapter_status'          => $chapter_status,
 
        // Flags
        'has_study_doc' => $has_study_doc,
        'has_ppt'       => $has_ppt,
        // 'has_lab_code'  => $has_lab_code,
        'has_pdf'       => $has_pdf,
        'has_audio'     => $has_audio,
 
        // Counts
        'study_doc_count' => $study_doc_count,
        'ppt_count'       => $ppt_count,
        // 'lab_code_count'  => $lab_code_count,
        'pdf_count'       => $pdf_count,
        'audio_count'     => $audio_count,
 
        // Links
        'study_doc_link' => $study_doc_link,
        'ppt_link'       => $ppt_link,
        'pdf_link'       => $pdf_link,
        'audio_link'     => $audio_link,
 
        // 'lab_codes'       => $lab_codes,
      ];
    }
 
 
    return response()->json([
      'status' => 200,
      'message' => 'Data Retrieved Successfully',
      'error_msg' => null,
      'chapters' => $chapters,
    ], 200);
  }
  

    //Section and topics List by chapter_id
    public function studentSectionList(Request $request)
    {
            // $id = $request->student_id;
            // $course_id = $request->course_id;
            $chapt_id = $request->chapter_id;
            
            $allBatchesData = []; // To store data for each batch
    
            $chapterDetails = ManageCoursesSyllabusModel::where('sno', $chapt_id)
                ->select('course_chapter_name', 'course_chapter_practical_hours', 'course_chapter_theory_hours', 'sno', 'course_id', 'course_chapter_id')
                ->groupBy('sno', 'course_chapter_name', 'course_chapter_theory_hours', 'course_chapter_practical_hours', 'course_id', 'course_chapter_id')
                ->get();
            // return $chapterDetails;
            // Fetch batch data with necessary joins
    
            foreach ($chapterDetails as $chapt) {
                $chapter_views = ManageCoursesSyllabusModel::where('course_chapter_id', $chapt->course_chapter_id)
                    ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
                    ->groupBy('course_chapter_id', 'course_chapter_name')
                    ->get();
    
                $chapters = [];
    
                foreach ($chapter_views as $chapter) {
                    // Fetch sections for each chapter
                    $latest_sections = ManageCoursesSyllabusModel::where('course_chapter_id', $chapt->course_chapter_id)
                        ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
                        ->groupBy('session_id', 'session_name')
                        ->get();
    
                    $sections = [];
    
                    foreach ($latest_sections as $sec) {
    
                        // Fetch topics for each section
                        $latest_topics = ManageCoursesSyllabusModel::where('course_chapter_id', $chapt->course_chapter_id)
                            ->where('course_chapter_id', $chapter->course_chapter_id)
                            ->where('session_id', $sec->session_id)
                            ->select('topic_id', 'topic_name','course_chapter_description', DB::raw('MAX(sno) as max_sno'))
                            ->groupBy('topic_id', 'topic_name','course_chapter_description')
                            ->get();
    
                        $topics = [];
    
                        foreach ($latest_topics as $topic) {
                            $topics[] = [
                                'topic_id' => $topic->topic_id,
                                'topic_name' => $topic->topic_name,
                                'topic_description' => $topic->course_chapter_description,
                                'max_sno' => $topic->max_sno,
                            ];
                        }
    
                        $sections[] = [
                            'section_id' => $sec->session_id,
                            'section_name' => $sec->session_name,
                            'max_sno' => $sec->max_sno,
                            'topics' => $topics,
                        ];
                    }
    
                }
    
                // Store batch-specific data
                $allBatchesData[] = [
                    'chapterDetails' => $chapterDetails,
                    'sections' => $sections,
                ];
            }
            if($allBatchesData) {
            return response()->json([
                'status' => 200,
                'message' => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data' => $allBatchesData,
            ], 200);
            }else{
                return response()->json([
                  'status' => 200,
                  'message' => 'Data Retrieved Successfully',
                  'error_msg' => null,
                  'data' => null,
              ], 200);
            }
        }
  
   //New Course List
    public function NewCourseList(Request $request)
    {
        $customer_id = $request->customer_id;
        $customer = DB::table('za_customer')->where('sno', $customer_id)->first();
        $intrestedcourse = json_decode($customer->add_course, true) ?? [];   
        $allCourseData = []; // To store data for each batch

        $Courses = ManageCoursesModel::select(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            DB::raw("DATE_FORMAT(za_course.created_at, '%d-%m-%Y') as created_date"),
            DB::raw('IFNULL(SUM(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE 0 END), "") as total_rating'),
            DB::raw('IFNULL(AVG(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE NULL END), "") as average_rating')
        )
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
        ->leftJoin('za_student_course_feedback', function ($join) {
            $join->on('za_course.sno', '=', 'za_student_course_feedback.course_id');
        })
        ->where('za_course.status', '!=', 2)
        ->groupBy(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            'created_date'
        )
        ->orderBy('za_course.sno', 'desc')
        ->limit(20)
        ->get();


          
        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';
        // return $Courses;
        // Add base URLs to the attachments and thumbnails
        $Courses->transform(function ($course) use ($attachmentBaseUrl, $thumbnailBaseUrl,$intrestedcourse) {
            $course->attachment = $attachmentBaseUrl . $course->attachment;
            $course->thumbnail  = $thumbnailBaseUrl . $course->thumbnail;
            $course->interested = in_array($course->sno, $intrestedcourse) ? 1 : 0;
            
            // 🎯 Random rating logic (if no rating data)
            
            // Generate random float between 4.0 and 5.0
            $course->average_rating = number_format(mt_rand(40, 50) / 10, 1);
            $course->total_rating = $course->average_rating * rand(5, 30); // fake total rating count
            
            return $course;
        });

        $allCourseData[] = [
            'coursesDetails' => $Courses,
        ];
        if ($allCourseData) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        }
    }

    // old course List
     public function ExistingCourseList(Request $request)
    {
     
        $customer_id = $request->customer_id;
        $customer = DB::table('za_customer')->where('sno', $customer_id)->first();
        $intrestedcourse = json_decode($customer->add_course, true) ?? []; 
        $allCourseData = []; // To store data for each batch

        $Courses = ManageCoursesModel::select('za_course.sno as course_sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_course.status', '!=', 2)
            ->orderBy('za_course.sno', 'desc')
            ->limit(20)
            ->get();
            $newCourseIds=$Courses->pluck('course_sno')->values();


        $oldCourses = ManageCoursesModel::select(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            DB::raw("DATE_FORMAT(za_course.created_at, '%d-%m-%Y') as created_date"),
            DB::raw('IFNULL(SUM(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE 0 END), "") as total_rating'),
            DB::raw('IFNULL(AVG(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE NULL END), "") as average_rating')
            // DB::raw('DATE(za_course.created_at) as created_date')

        )

        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
         ->leftJoin('za_student_course_feedback', function ($join) {
            $join->on('za_course.sno', '=', 'za_student_course_feedback.course_id');
        })
        ->where('za_course.status', '!=', 2)
        ->whereNotIn('za_course.sno', $newCourseIds)
        ->groupBy(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            'created_date'
        )
        ->orderBy('za_course.sno', 'desc')
        ->limit(40)
        ->get();

        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';
        // return $Courses;
        // Add base URLs to the attachments and thumbnails
        $oldCourses->transform(function ($course) use ($attachmentBaseUrl, $thumbnailBaseUrl,$intrestedcourse) {
            $course->attachment = $attachmentBaseUrl . $course->attachment;
            $course->thumbnail  = $thumbnailBaseUrl . $course->thumbnail;
            $course->interested = in_array($course->sno, $intrestedcourse) ? 1 : 0;
            // 🎯 Random rating logic (if no rating data)
            
            // Generate random float between 4.0 and 5.0
            $course->average_rating = number_format(mt_rand(40, 50) / 10, 1);
            $course->total_rating = $course->average_rating * rand(5, 30); // fake total rating count
            return $course;
        });

        $allCourseData[] = [
            'coursesDetails' => $oldCourses,
        ];
        if ($allCourseData) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        }
    }

  
    public function CourseMaterial(Request $request)
    {
        $customer_id = $request->input('customer_id');

        // Fetch batch data with necessary joins
        $batches = BatchModel::select(
            'za_batch.course_id',
            'za_course.course_name',
            'za_course.course_days',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_duration',
            'za_course.materials',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_batch.course_type_id',
            'za_course_type.course_type_name',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_training.customer_id',
            'za_training.course_id'
        )
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
            ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_training.customer_id', '=', $customer_id)
            ->where('za_batch.status', '!=', 2)
            ->groupBy(
                'za_batch.course_id',
                'za_course.course_name',
                'za_course.course_days',
                'za_course.course_version',
                'za_course.course_duration',
                'za_course.materials',
                'za_course.course_partical_hours',
                'za_course.course_theory_hours',
                'za_course.course_code',
                'za_course.course_duration',
                'za_course_subcategory.course_subcategory_name',
                'za_course.attachment',
                'za_course.thumbnail',
                'za_batch.course_type_id',
                'za_course_type.course_type_name',
                'za_staff.staff_name',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_staff.staff_image',
                'za_training.customer_id',
                'za_training.course_id'
            )
            ->get();

        // Decode materials and append URLs dynamically
        // $batches->transform(function ($batch) {
        //     $batch->course_materials = $batch->materials ? json_decode($batch->materials, true) : [];
        
        //     // Fetch material type names
        //     $material_types = DB::table('za_material_type')
        //         ->select('sno', 'material_type_name as folder_name')
        //         ->where('status', 0)
        //         ->get()
        //         ->toArray();
        
        //     $materialNamesWithCount = [];
        
        //     foreach ($material_types as $materialType) {
        //         $folderName = $materialType->folder_name;
        //         $materialTypeId = $materialType->sno;
        
        //         // Count files for this material type
        //         $count = 0;
        //         if (isset($batch->course_materials[$materialTypeId])) {
        //             $count = count($batch->course_materials[$materialTypeId]);
        //         }
        
        //         $materialNamesWithCount[] = [
        //             'sno' => $materialType->sno,
        //             'folder_name' => $folderName,
        //             'count' => $count
        //         ];
        //     }
        
        //     $batch->material_names = $materialNamesWithCount;
        
        //     // ✅ Optional: Build course_materials URLs as before
        //     $materialBaseUrl = 'https://erp.elysium.academy/course_materials';
        //     $materialUrls = [];
        //     foreach ($materialNamesWithCount as $mat) {
        //         $folderName = $mat['folder_name'];
        //         $materialTypeId = $mat['sno'];
        //         $materialUrls[$folderName] = [];
        
        //         if (isset($batch->course_materials[$materialTypeId])) {
        //             foreach ($batch->course_materials[$materialTypeId] as $file) {
        //                 $materialUrls[$folderName][] = [
        //                     'name' => $file,
        //                     'url' => "{$materialBaseUrl}/{$batch->course_id}/{$materialTypeId}/{$file}",
        //                 ];
        //             }
        //         }
        //     }
        
        //     // $materialUrls = [];
 
        //     // foreach ($materialNamesWithCount as $mat) {
        //     //     $folderName = $mat['folder_name'];
        //     //     $materialTypeId = $mat['sno'];
         
        //     //     $materialUrls[$folderName] = [];
         
        //     //     if (isset($batch->course_materials[$materialTypeId])) {
         
        //     //       foreach ($batch->course_materials[$materialTypeId] as $file) {
         
        //     //         $wasabiPath = "course_materials/{$batch->course_id}/{$materialTypeId}/{$file}";
         
        //     //         // Check file exists in Wasabi
        //     //         if (Storage::disk('wasabi')->exists($wasabiPath)) {
         
        //     //           // Temporary URL valid for 30 minutes
        //     //           $fileUrl = Storage::disk('wasabi')->temporaryUrl(
        //     //             $wasabiPath,
        //     //             now()->addMinutes(30)
        //     //           );
         
        //     //           $materialUrls[$folderName][] = [
        //     //             'name' => $file,
        //     //             'url' => $fileUrl,
        //     //           ];
        //     //         }
        //     //       }
        //     //     }
        //     //   }
              
              
        //     // Convert associative array to indexed array
        //     $batch->course_materials = array_map(function ($folderName) use ($materialUrls) {
        //         return [$folderName => $materialUrls[$folderName]];
        //     }, array_keys($materialUrls));
        
        //     // Attachments and thumbnail
        //     $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        //     $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';
        //     $batch->attachment = $batch->attachment ? $attachmentBaseUrl . $batch->attachment : null;
        //     $batch->thumbnail  = $batch->thumbnail ? $thumbnailBaseUrl . $batch->thumbnail : null;
        
        //     return $batch;
        // });

            // Decode materials and append URLs dynamically
    $batches->transform(function ($batch) {
 
      $batch->course_materials = $batch->materials
        ? json_decode($batch->materials, true)
        : [];
 
      if (!is_array($batch->course_materials)) {
        $batch->course_materials = [];
      }
 
      /*
        |--------------------------------------------------------------------------
        | Material Types
        |--------------------------------------------------------------------------
        */
      $material_types = DB::table('za_material_type')
        ->select(
          'sno',
          'material_type_name as folder_name'
        )
        ->where('status', 0)
        ->get();
 
      $materialNamesWithCount = [];
      $materialUrls = [];
 
      foreach ($material_types as $materialType) {
 
        $folderName = $materialType->folder_name;
        $materialTypeId = (string) $materialType->sno;
 
        $materialNamesWithCount[] = [
          'sno' => $materialType->sno,
          'folder_name' => $folderName,
          'count' => 0,
        ];
 
        $materialUrls[$folderName] = [];
 
        /*
            |--------------------------------------------------------------------------
            | Find materials by document_type_id
            |--------------------------------------------------------------------------
            */
        foreach ($batch->course_materials as $material) {
 
          if (
            !isset(
              $material['document_type_id'],
              $material['material_name']
            )
          ) {
            continue;
          }
 
          if (
            (string) $material['document_type_id'] !== $materialTypeId
          ) {
            continue;
          }
 
          $fileName = $material['material_name'];
 
          /*
                |--------------------------------------------------------------------------
                | Lab Code / Placeholder - no physical file
                |--------------------------------------------------------------------------
                */
          if (empty($fileName)) {
            continue;
          }
 
          /*
                |--------------------------------------------------------------------------
                | Wasabi Object Path
                |--------------------------------------------------------------------------
                */
          $wasabiPath =
            "course_materials/{$batch->course_id}/{$materialTypeId}/{$fileName}";
 
          /*
                |--------------------------------------------------------------------------
                | Check Wasabi
                |--------------------------------------------------------------------------
                */
          if (!Storage::disk('wasabi')->exists($wasabiPath)) {
            continue;
          }
 
          /*
                |--------------------------------------------------------------------------
                | Temporary URL
                |--------------------------------------------------------------------------
                */
          $fileUrl = Storage::disk('wasabi')->temporaryUrl(
            $wasabiPath,
            now()->addMinutes(30)
          );
 
          $materialUrls[$folderName][] = [
            'name' => $fileName,
            'url' => $fileUrl,
            'original_name' => $material['original_name'] ?? $fileName,
          ];
        }
 
        /*
            |--------------------------------------------------------------------------
            | Correct count based on actual Wasabi files
            |--------------------------------------------------------------------------
            */
        $materialNamesWithCount[count($materialNamesWithCount) - 1]['count'] = count($materialUrls[$folderName]);
      }
 
      /*
        |--------------------------------------------------------------------------
        | Convert to your existing mobile response structure
        |--------------------------------------------------------------------------
        */
      $batch->material_names = $materialNamesWithCount;
 
      $batch->course_materials = array_map(
        function ($folderName) use ($materialUrls) {
          return [
            $folderName => $materialUrls[$folderName] ?? []
          ];
        },
        array_keys($materialUrls)
      );
 
      /*
        |--------------------------------------------------------------------------
        | Attachments / Thumbnail
        |--------------------------------------------------------------------------
        */
      $attachmentBaseUrl =
        'https://erp.elysium.academy/course_attachments/';
 
      $thumbnailBaseUrl =
        'https://erp.elysium.academy/course_thumbnail_image/';
 
      $batch->attachment = $batch->attachment
        ? $attachmentBaseUrl . $batch->attachment
        : null;
 
      $batch->thumbnail = $batch->thumbnail
        ? $thumbnailBaseUrl . $batch->thumbnail
        : null;
 
      return $batch;
    });
 
 
        $batches = $batches->map(function ($item) {
            $attendanceRecords = AttendanceModel::where('customer_id', $item->customer_id) // note customer_id field
                ->where('batch_id', $item->sno)
                ->where('attendance', 'P')
                ->get();
        
            $courseProgress = 0;
            $topicCount = 0;
        
            $course_topic_count = DB::table('za_course_chapter')
                ->where('course_id', $item->course_id)
                ->count();
        
            if ($attendanceRecords->isNotEmpty()) {
                foreach ($attendanceRecords as $attendance) {
                    $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $item->sno)
                        ->whereDate('date', $attendance->att_date)
                        ->get();
                    foreach ($syllabusUpdates as $syllabusUpdate) {
                        if ($syllabusUpdate->percentage == 100) {
                            $topicCount++;
                        }
                    }
                }
        
                if ($course_topic_count > 0) {
                    $courseProgress = ($topicCount / $course_topic_count) * 100;
                    $courseProgress = min($courseProgress, 100); // Cap at 100
                }
            }
        
            $item->course_complete_percentage = number_format($courseProgress, 2);
        
            $lastAttendance = AttendanceModel::select('att_date')
                ->where('customer_id', $item->customer_id)
                ->where('batch_id', $item->sno)
                ->where('attendance', 'P')
                ->orderBy('created_at', 'desc')
                ->first();
        
            $course_completedDays = 0;
            if ($lastAttendance) {
                $startDate = Carbon::parse($item->start_date);
                $lastAttendanceDate = Carbon::parse($lastAttendance->att_date);
        
                if ($startDate->lte($lastAttendanceDate)) {
                    switch ($item->slot_type) {
                        case 1: // Mon-Fri
                            for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                                if ($date->isWeekday()) $course_completedDays++;
                            }
                            break;
                        case 2: // Sat
                            for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                                if ($date->isSaturday()) $course_completedDays++;
                            }
                            break;
                        case 3: // Sun
                            for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                                if ($date->isSunday()) $course_completedDays++;
                            }
                            break;
                    }
                }
            }
        
            $item->course_completedDays = $course_completedDays;
        
            return $item;
        });


        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data'      => $batches,
        ], 200);
    }
    
    public function CourseMaterialByTypeId(Request $request)
    {
        $course_id        = $request->input('course_id');
        $material_type_id = $request->input('material_type_id');

        // Fetch course data with necessary joins
        $course = DB::table('za_course')->select(
            'za_course.course_name',
            'za_course.course_days',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_duration',
            'za_course.course_code',
            'za_course.materials',
            'za_course_subcategory.course_subcategory_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course_type.course_type_name'
        )
            ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_course.sno', '=', $course_id)
            ->where('za_course.status', '!=', 2)
            ->first();

        if (! $course) {
            return response()->json([
                'status'    => 404,
                'message'   => 'Course not found',
                'error_msg' => 'Invalid course ID',
                'data'      => null,
            ], 404);
        }

        // Decode materials JSON and fetch base URL
        $materials         = $course->materials ? json_decode($course->materials, true) : [];
        $materialBaseUrl   = 'https://erp.elysium.academy/course_materials';
        $filteredMaterials = [];

        // Check for materials matching the material_type_id
        if (isset($materials[$material_type_id])) {
            foreach ($materials[$material_type_id] as $file) {
                $filteredMaterials[] = [
                    'url' => "{$materialBaseUrl}/{$course_id}/{$material_type_id}/{$file}",
                ];
            }
        }
        $material_types = DB::table('za_material_type')->select('material_type_name as folder_name')->where('status', 0)->where('sno', $material_type_id)->first();
        return response()->json([
            'status'    => 200,
            'message'   => 'Data Retrieved Successfully',
            'error_msg' => null,
            'data'      => [
                "folder_name"      => $material_types ? $material_types->folder_name : null,
                'course_materials' => $filteredMaterials, // Empty array if no materials are found
            ],
        ], 200);
    }

  
   public function AddContactDetails(Request $request) 
    {
    $helper = new \App\Helpers\Helpers();

      $request->validate([
          'name' => 'required|string|max:255',
          'mobile_no' => 'required|string|max:250', // Assuming mobile number is of 10 digits
          // 'referral_by' => 'required|integer|exists:za_lead,sno', // Assuming 'sno' is the identifier for leads
      ]);
  
      $name = ucfirst($request->name);
      $mobile_no = $request->mobile_no;
      $referral_by = $request->referral_by;
  
      // Check if the lead exists based on referral_by
      $lead_chk = LeadModel::select('lead_name', 'lead_mobile', 'branch_id')
          ->where('sno', $referral_by)
          ->first();
  
      if (!$lead_chk) {
          return response()->json([
              'status'    => 404,
              'message'   => 'No lead found for the given referral.',
              'error_msg' => null,
              'data'      => [],
          ], 404);
      }
  
      // Check if the contact already exists
      $chk = ContactDetailsModel::where('mobile_no', $mobile_no)
          ->first();
  
      if ($chk) {
          return response()->json([
              'status'    => 200,
              'message'   => 'Member has already been created!',
              'error_msg' => null,
              'data'      => $chk,
          ], 200);
      }
  
      // Generate a unique contact_detail_id
      $add_contact = ContactDetailsModel::where('status', '!=', 2)
          ->orderBy('id', 'desc')
          ->first();
  
      if (!$add_contact) {
          $year = substr(date('y'), -2);
          $contact_detail_id = 'SCD-0001/' . $year;
      } else {
          $data = $add_contact->contact_detail_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);
          $next_number = (int)$result + 1;
          $requestId = sprintf('SCD-%04d', $next_number);
          $year = substr(date('y'), -2);
          $contact_detail_id = $requestId . '/' . $year;
      }
  
      // Add the new contact to the database
      $add = new ContactDetailsModel();
      $add->contact_detail_id = $contact_detail_id;
      $add->name = $name;
      $add->branch_id = $lead_chk->branch_id;
      $add->mobile_no = $mobile_no;
      $add->referral_by = $referral_by;
      $add->save();
  
      if ($add) {
        
          $pointsDataFullAttendance = $helper->get_points_by_id(23); // Points for P
          $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
          $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

          // Save new points for the staff (full attendance)
          $newPointsFull = new StudentpointsModel();
          $newPointsFull->branch_id =  $lead_chk->branch_id;
          $newPointsFull->student_id = $add->referral_by;
          $newPointsFull->points_id = 23;
          $newPointsFull->points = $pointFull;
          $newPointsFull->reason = $reasonFull;
          $newPointsFull->save();

          // Update staff's available points
          $student_points = CustomerModel::where('sno', $add->referral_by)->first();
          if ($student_points) {
              $student_points->points_score += $pointFull;
              $student_points->save();
          }
          return response()->json([
              'status'    => 200,
              'message'   => 'Member has been created successfully!',
              'error_msg' => null,
              'data'      => $add
          ], 200);
      } else {
          return response()->json([
              'status'    => 500,
              'message'   => 'Unable to create contact.',
              'error_msg' => 'There was an error while saving the contact details.',
              'data'      => []
          ], 500);
      }
  }
   public function AddContactDetailsSelect(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
    
        $request->validate([
            'customer_id' => 'required|integer',
            'contacts'    => 'required|array|min:1',
            'contacts.*.name'      => 'required|string|max:255',
            'contacts.*.mobile_no' => 'required|string|max:15',
        ]);
    
        $customerId = $request->customer_id;
        $contacts = $request->contacts;
    
        $customer = CustomerModel::where('sno', $customerId)->first();
    
        if (!$customer) {
            return response()->json([
                'status'    => 404,
                'message'   => 'Referrer not found',
                'error_msg' => null,
                'data'      => [],
            ], 404);
        }
    
        $branchId = $customer->branch_id ?? 0;
        $savedContacts = [];
        $pointsEarned = 0;
        $branch_data = BranchModel::where('sno', $branchId)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }
        foreach ($contacts as $entry) {
                $name = ucfirst($entry['name']);
                $mobile_no = $entry['mobile_no'];
            
                // Skip if already exists
                $exists = ContactDetailsModel::where('mobile_no', $mobile_no)->first();
                if ($exists) continue;
            
                // Generate contact_detail_id
                $latestContact = ContactDetailsModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();
                if (!$latestContact) {
                    $year = substr(date('y'), -2);
                    $contact_detail_id = 'SCD-0001/' . $year;
                } else {
                    $lastId = $latestContact->contact_detail_id;
                    $split = explode('/', $lastId);
                    $number = preg_replace('/[^0-9]/', '', $split[0]);
                    $next = sprintf('SCD-%04d', ((int)$number + 1));
                    $year = substr(date('y'), -2);
                    $contact_detail_id = $next . '/' . $year;
                }
            
                // Save contact
                $add = new ContactDetailsModel();
                $add->contact_detail_id = $contact_detail_id;
                $add->name = $name;
                $add->mobile_no = $mobile_no;
                $add->branch_id = $branchId;
                $add->referral_by = $customerId;
                $add->save();
            
                $savedContacts[] = $add;
            
                // Award 2 points
                DB::table('za_students_points')->insert([
                    'branch_id'   => $branchId,
                    'student_id'  => $customerId,
                    'points_id'   => 0,
                    'points'      => 2,
                    'reason'      => 'Customer Reference Mobile',
                    'created_at'  => now(),
                    'updated_at'  => now(),
                    'status'      => 0,
                ]);
            
                $pointsEarned += 2;
            
                // --- SEND WHATSAPP MESSAGE TO THIS CONTACT ---
                $templateName = "elysium_academy_welcome_message";
                $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
                $website = $branch_data->website ?? 'https://elysiumacademy.org';
                $contact_no = $branch_data->cre_mobile ?? '9677781155';
                $email = $branch_data->mail ?? 'info@elysiumacademy.org';
            
                date_default_timezone_set('Asia/Kolkata');
                $currentHour = (int) date('H');
                if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                } else {
                    $greeting = 'Good Evening';
                }
            
                $bodyText = [
                    [ 'type' => 'text', 'text' => $greeting, 'parameter_name' => 'greet_msg' ],
                    [ 'type' => 'text', 'text' => $name, 'parameter_name' => 'customer_name' ],
                    [ 'type' => 'text', 'text' => $website, 'parameter_name' => 'web_link' ],
                    [ 'type' => 'text', 'text' => $branch_name, 'parameter_name' => 'branch_name' ],
                    [ 'type' => 'text', 'text' => $contact_no, 'parameter_name' => 'contact_no' ],
                    [ 'type' => 'text', 'text' => $email, 'parameter_name' => 'contact_email' ],
                ];
            
                $components = [
                    [
                        'type' => 'header',
                        'parameters' => [[ 'type' => 'image', 'image' => [ 'link' => $headerImage ] ]]
                    ],
                    [ 'type' => 'body', 'parameters' => $bodyText ],
                    [
                        'type' => 'button',
                        'sub_type' => 'copy_code',
                        'index' => 0,
                        'parameters' => [[ 'type' => 'coupon_code', 'coupon_code' => 'NOOFFER' ]]
                    ]
                ];
            
                $to = $mobile_no;
                if (strpos($to, '+91') !== 0) {
                    $to = '+91' . $to;
                }
            
                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to' => $to,
                    'type' => 'template',
                    'template' => [
                        'name' => $templateName,
                        'language' => [ 'code' => 'en_US' ],
                        'components' => $components
                    ]
                ];
            
                $apiUri = 'https://graph.facebook.com/v21.0/' . $this->phoneNumberId . '/messages';
                $this->sendRequestToWhatsApp($apiUri, $this->accessToken, $payload);
            }

        return response()->json([
            'status'  => 1,
            'message' => count($savedContacts) > 0 
                        ? 'Contacts saved & points rewarded.' 
                        : 'All contacts already exist. No points awarded.',
            'points_awarded' => $pointsEarned,
            'data'    => $savedContacts
        ]);
    }

   public function exchangeReward(Request $request) 
   {
    $customerId = $request->customer_id;
    $newCoin = (int) $request->coin;
    $newDiamond = (int) $request->diamond;
    $newCrown = (int) $request->crown;

    if (is_null($customerId) || ($newCoin === 0 && $newDiamond === 0 && $newCrown === 0)) {
        return response()->json([
            'status' => 0,
            'message' => 'Missing required fields or all values are zero',
            'data' => []
        ], 400);
    }

    $customer = DB::table('za_customer')->where('sno', $customerId)->first();
    if (!$customer) {
        return response()->json([
            'status' => 0,
            'message' => 'Customer not found',
            'data' => []
        ], 404);
    }

    // Get existing rewards
    $existingRewards = json_decode($customer->rewards ?? '[]', true);
    if (!is_array($existingRewards)) {
        $existingRewards = [];
    }

    // Apply negative only to the first non-zero field
    $coin = $newCoin;
    $diamond = $newDiamond;
    $crown = $newCrown;

    // if ($newCoin !== 0) {
    //     $coin = -$newCoin;
    // } elseif ($newDiamond !== 0) {
    //     $diamond = -$newDiamond;
    // } elseif ($newCrown !== 0) {
    //     $crown = -$newCrown;
    // }

    $newRewardEntry = [
        'date' => now()->toDateString(),
        'coin' => $coin,
        'diamond' => $diamond,
        'crown' => $crown,
    ];

    $existingRewards[] = $newRewardEntry;

    DB::table('za_customer')
        ->where('sno', $customerId)
        ->update([
            'rewards' => json_encode($existingRewards)
        ]);
             $this->sendNotification(
                $customer->branch_id,
                $customerId,
                "Exchange reward applied successfully",
                "Student App",
                $customerId
            );

    return response()->json([
        'status' => 1,
        'message' => 'Rewards exchanged successfully',
        'data' => $newRewardEntry
    ]);
}

   public function leaderShipBoard(Request $request) 
   {  
      $cus_id = $request->customer_id;
      $customer = CustomerModel::select('*')->where('sno', $cus_id)->where('status', 0)->first();

      if($customer){
        $customerData = CustomerModel::select('cus_name', 'cus_mobile', 'sno', 'customer_id', 'cus_pic', 'points_score')
            ->where('status', 0)
            ->where('branch_id', $customer->branch_id)
            ->orderBy('points_score', 'desc')
            ->limit(5)
            ->get();
      }
  
      $cusImageUrl = 'https://erp.elysium.academy/cus_pics/';
  
      // Add rank to each customer
      $customerData->transform(function ($customer, $key) use ($cusImageUrl) {
          $customer->cus_pic = $cusImageUrl . $customer->cus_pic;
          $customer->rank = $key + 1;  // Rank starts from 1
          return $customer;
      });
  
      if($customerData->isNotEmpty()) {
          return response()->json([
              'status' => 200,
              'message' => 'Data Retrieved Successfully',
              'error_msg' => null,
              'data' => $customerData,
          ], 200);
      } else {
          return response()->json([
              'status' => 404,
              'message' => 'Customer Not Found',
              'error_msg' => null,
              'data' => $customerData,
          ], 404);
      }
  }
  

    public function EventList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid input',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $customer_id = $request->customer_id;
        $customer = CustomerModel::select('*')->where('sno', $customer_id)->where('status', 0)->first();
    
        $event_list = DB::table('za_event')
            ->select(
                'za_event.sno as event_id',
                'za_event.event_name',
                'za_event.branch_id',
                'za_event.contact_person_name',
                'za_event.event_date',
                'za_event.start_time',
                'za_event.end_time',
                'za_event.event_address',
                'za_event.certificate_type',
                'za_event.certificate',
                'za_event.handle_type',
                'za_event.handle_staff_id',
                'za_event.handle_others_name',
                'za_event.event_type_id',
                'za_event.event_amount',
                'za_event.participants',
                'za_event.status',
                'za_event.no_of_participants',
                'za_event.event_description',
                'za_event.event_key_tag',
                DB::raw("CASE WHEN participants.sno IS NULL THEN 0 ELSE 1 END as booked"),
                'za_cities.name as city'
            )
            ->leftJoin('za_event_participant as participants', function ($join) use ($customer_id) {
                $join->on('za_event.sno', '=', 'participants.event_id')
                    ->where('participants.customer_id', '=', $customer_id)
                    ->where('participants.status', '!=', 2);
            })
            ->leftJoin('za_branch as branch', 'branch.sno', '=', 'za_event.branch_id')
            ->leftJoin('za_cities', 'za_cities.id', '=', 'branch.city_id')
            ->where('za_event.branch_id', $customer->branch_id)
            ->where('za_event.display_mobile_app', 1)
            ->whereNotIn('za_event.status', [3])
            ->orderBy('za_event.event_date', 'asc')
            ->get();
    
        // Map events to calculate remaining participants and remaining days
        $event_list = $event_list->map(function ($event) {
            // Remaining participants
            if ($event->participants == 'Limited') {
                $bookedCount = ParticipantModel::where('event_id', $event->event_id)
                    ->where('status', 0)
                    ->count();
                $remaining = max(0, $event->no_of_participants - $bookedCount);
                $event->remaining_participants = (string) $remaining;
            } else {
                $event->remaining_participants = 'Unlimited';
            }
            
            if ($event->event_description == null) {
 
                $tags = json_decode($event->event_key_tag, true);
         
                if (is_array($tags)) {
                  $values = array_column($tags, 'value');
                  $event->event_key_tag = implode(', ', $values);
                } else {
                  $event->event_key_tag = $event->event_description;
                }
         
                $event->event_description = $event->event_key_tag;
              } else {
                $event->event_description = null;
              }
              
    
            // Handle staff name
            if ($event->handle_type == 'Inhouse') {
                $staff = StaffModel::where('sno', $event->handle_staff_id)
                    ->where('status', 0)
                    ->first();
                $event->handle_others_name = $staff ? $staff->nick_name : null;
            }
    
            // Certificate type
            if ($event->certificate == 'yes') {
                $event->certificate_type = $event->certificate_type == 'Offline Certificate' ? 'Certificate' : 'E-Certificate';
            }
    
            // ✅ Calculate remaining days
            $today = Carbon::today();
            $event_date = Carbon::parse($event->event_date);
            $remaining_days = $today->diffInDays($event_date, false); // false to get negative if past
            $event->days_remaining = $remaining_days >= 0 ? $remaining_days : 0;
    
            return $event;
        });
    
        return response()->json([
            'status'     => 200,
            'message'    => 'Data Retrieved Successfully',
            'error_msg'  => null,
            'event_list' => $event_list,
        ]);
    }



    public function bookEvent(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'event_id'    => 'required',  
            'customer_id' => 'required',  
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid input',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $event_id    = $request->event_id;
        $customer_id = $request->customer_id;
    
        // Get customer details
        $customer = CustomerModel::where('sno', $customer_id)
            ->where('status', 0)
            ->first();
    
        if (!$customer) {
            return response()->json([
                'status'  => false,
                'message' => 'Customer not found or inactive.'
            ], 404);
        }
    
        // Check if already booked for this event
        $alreadyBooked = ParticipantModel::where('event_id', $event_id)
            ->where('customer_id', $customer_id) // ✅ safer check
            ->where('status', '!=', 2)
            ->first();
    
        if ($alreadyBooked) {
            return response()->json([
                'status'  => false,
                'message' => 'You have already booked this event.'
            ], 409);
        }
    
        // Generate participant_id
        $lastParticipant = ParticipantModel::where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();
    
        if (!$lastParticipant) {
            $year = substr(date('y'), -2);
            $participant_id = 'EPT-0001/' . $year;
        } else {
            $data = $lastParticipant->participant_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int) $result + 1;
            $participant_id = sprintf('EPT-%04d', $next_number) . '/' . substr(date('y'), -2);
        }
    
        // Save new booking
        $participant = new ParticipantModel();
        $participant->participant_id    = $participant_id;
        $participant->participant_name  = $customer->cus_name;
        $participant->event_id          = $event_id;
        $participant->customer_id       = $customer->sno; // ✅ add this column if missing
        $participant->mobile_no         = $customer->cus_mobile;
        $participant->alter_mobile_no   = $customer->cus_alternate_mobile;
        $participant->participant_email = $customer->cus_email_id;
        $participant->participant_type  = 'Student';
        $participant->branch_id         = $customer->branch_id;
        $participant->created_by        = $customer->sno;
        $participant->updated_by        = $customer->sno;
        $participant->save();
    
        return response()->json([
            'status'  => true,
            'message' => 'Event booked successfully!',
            'data'    => $participant
        ], 201);
    }

  
//   public function PlacementList(Request $request)
//     {
//         $customer_id = $request->customer_id;
 
//         $customer_data = DB::table('za_customer')
//             ->where('sno', $customer_id)
//             ->first();
 
//         if (!$customer_data) {
//             return response()->json([
//                 'status'    => '2',
//                 'message'   => 'Customer not found',
//                 'error_msg' => 'Invalid customer ID',
//                 'data'      => [],
//             ], 404);
//         }
 
//         // =========================================================
//         // CHECK PAYMENT PERCENTAGE FOR ANY ONE COURSE
//         // =========================================================
 
//         $trainingCourses = DB::table('za_training')
//             ->where('customer_id', $customer_id)
//             ->whereIn('status', [0, 2])
//             ->get();
 
//         $hasFullPayment = false;
 
//         foreach ($trainingCourses as $courseItem) {
 
//             $paymentDetails = DB::table('za_training')
//                 ->selectRaw('
//                     SUM(za_payment.paidAmount) as total_paid_amount,
//                     za_payment.total_amount
//                 ')
//                 ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
//                 ->where('za_training.customer_id', $customer_id)
//                 ->where('za_training.course_id', $courseItem->course_id)
//                 ->where('za_training.status', '!=', 3)
//                 ->where('za_payment.status', '!=', 3)
//                 ->groupBy('za_payment.total_amount')
//                 ->first();
 
//             $paymentPercentage = 0;
 
//             if (
//                 $paymentDetails &&
//                 !empty($paymentDetails->total_amount) &&
//                 $paymentDetails->total_amount > 0
//             ) {
 
//                 $paymentPercentage =
//                     ($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100;
 
//                 if ($paymentPercentage >= 100) {
 
//                     $hasFullPayment = true;
//                     break;
//                 }
//             }
//         }
 
//         // =========================================================
//         // BLOCK PLACEMENT ACCESS
//         // =========================================================
 
//         if (!$hasFullPayment) {
 
//             return response()->json([
//                 'status'    => '2',
//                 'message'   => 'Complete full payment for at least one course',
//                 'error_msg' => 'Placement access denied',
//                 'data'      => [],
//             ], 200);
//         }
 
//         // =========================================================
//         // TESBO / PLACEMENT CHECK
//         // =========================================================
 
//         $today = now()->format('Y-m-d');
 
//         $tesbo_chk = DB::table('za_training')
//             ->where('tesbo_check', '!=', '0')
//             ->where('customer_id', $customer_id)
//             ->exists();
 
//         $placement_chk = DB::table('za_customer')
//             ->where('is_placement', '1')
//             ->where('sno', $customer_id)
//             ->exists();
 
//         $job_details = [];
 
//         if ($tesbo_chk || $placement_chk) {
 
//             $saved_jobs = json_decode($customer_data->job_ids, true) ?? [];
 
//             $job_details = JobModel::select(
//                 'za_jobs.*',
//                 'za_placement_company.company_name',
//                 'za_job_category.job_category_name',
//                 'za_job_subcategory.job_subcategory_name as job_role_name',
//                 'za_interview_type.interview_type_name',
//                 'za_placement_company.company_address'
//             )
//                 ->join(
//                     'za_placement_company',
//                     'za_placement_company.sno',
//                     '=',
//                     'za_jobs.company_id'
//                 )
//                 ->leftJoin(
//                     'za_job_category',
//                     'za_job_category.sno',
//                     '=',
//                     'za_jobs.job_category_id'
//                 )
//                 ->leftJoin(
//                     'za_job_subcategory',
//                     'za_job_subcategory.sno',
//                     '=',
//                     'za_jobs.job_subcategory_id'
//                 )
//                 ->leftJoin(
//                     'za_interview_type',
//                     'za_interview_type.sno',
//                     '=',
//                     'za_jobs.interview_mode_id'
//                 )
//                 ->whereNotIn('za_jobs.status', [2])
//                 ->where('za_jobs.branch_id', $customer_data->branch_id)
//                 ->whereDate('za_jobs.interview_date', '>=', $today)
//                 ->orderByDesc('za_jobs.sno')
//                 ->get();
 
//             foreach ($job_details as $job) {
 
//                 $interested_students =
//                     json_decode($job->interest_student_ids, true) ?? [];
 
//                 $job->applied =
//                     in_array($customer_id, $interested_students) ? 1 : 0;
 
//                 $job->job_saved =
//                     in_array($job->sno, $saved_jobs) ? 1 : 0;
//             }
//         }
 
//         return response()->json([
//             'status'    => !empty($job_details) ? '1' : '2',
//             'message'   => 'Successfully Retrieved Data',
//             'error_msg' => null,
//             'data'      => !empty($job_details) ? $job_details : [],
//         ], 200);
//     }
    
    public function PlacementList(Request $request)

{

    $customer_id = $request->customer_id;
 
    $customer_data = DB::table('za_customer')

        ->where('sno', $customer_id)

        ->first();
 
    if (!$customer_data) {

        return response()->json([

            'status'    => '2',

            'message'   => 'Customer not found',

            'error_msg' => 'Invalid customer ID',

            'data'      => [],

        ], 404);

    }
 
    // =========================================================

    // CHECK PAYMENT PERCENTAGE FOR ANY ONE COURSE

    // =========================================================
 
    $trainingCourses = DB::table('za_training')

        ->where('customer_id', $customer_id)

        ->whereIn('status', [0, 2])

        ->get();
 
    $hasFullPayment = false;
 
    foreach ($trainingCourses as $courseItem) {
 
        $paymentDetails = DB::table('za_training')

            ->selectRaw('

                SUM(za_payment.paidAmount) as total_paid_amount,

                za_payment.total_amount

            ')

            ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')

            ->where('za_training.customer_id', $customer_id)

            ->where('za_training.course_id', $courseItem->course_id)

            ->where('za_training.status', '!=', 3)

            ->where('za_payment.status', '!=', 3)

            ->groupBy('za_payment.total_amount')

            ->first();
 
        $paymentPercentage = 0;
 
        if (

            $paymentDetails &&

            !empty($paymentDetails->total_amount) &&

            $paymentDetails->total_amount > 0

        ) {
 
            $paymentPercentage =

                ($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100;
 
            if ($paymentPercentage >= 100) {
 
                $hasFullPayment = true;

                break;

            }

        }

    }
 
    // =========================================================

    // BLOCK PLACEMENT ACCESS

    // =========================================================
 
    if (!$hasFullPayment) {
 
        return response()->json([

            'status'    => '2',

            'message'   => 'Complete full payment for at least one course',

            'error_msg' => 'Placement access denied',

            'data'      => [],

        ], 200);

    }
 
    // =========================================================

    // TESBO / PLACEMENT / PROFESSIONAL CHECK

    // =========================================================
 
    $today = now()->format('Y-m-d');
 
    // Check TESBO

    $tesbo_chk = DB::table('za_training')

        ->where('tesbo_check', '!=', '0')

        ->where('customer_id', $customer_id)

        ->exists();
 
    // Check PLACEMENT

    $placement_chk = DB::table('za_customer')

        ->where('is_placement', '1')

        ->where('sno', $customer_id)

        ->exists();
 
    // Check PROFESSIONAL (course_type_id = 3)

    $professional_chk = DB::table('za_training')

        ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')

        ->where('za_training.customer_id', $customer_id)

        ->where('za_course.course_type_id', 3)

        ->exists();
 
    $job_details = [];
 
    // If any of the three conditions is true

    if ($tesbo_chk || $placement_chk || $professional_chk) {
 
        $saved_jobs = json_decode($customer_data->job_ids, true) ?? [];
 
        $job_query = JobModel::select(

            'za_jobs.*',

            'za_placement_company.company_name',

            'za_job_category.job_category_name',

            'za_job_subcategory.job_subcategory_name as job_role_name',

            'za_interview_type.interview_type_name',

            'za_placement_company.company_address'

        )

            ->join(

                'za_placement_company',

                'za_placement_company.sno',

                '=',

                'za_jobs.company_id'

            )

            ->leftJoin(

                'za_job_category',

                'za_job_category.sno',

                '=',

                'za_jobs.job_category_id'

            )

            ->leftJoin(

                'za_job_subcategory',

                'za_job_subcategory.sno',

                '=',

                'za_jobs.job_subcategory_id'

            )

            ->leftJoin(

                'za_interview_type',

                'za_interview_type.sno',

                '=',

                'za_jobs.interview_mode_id'

            )

            ->whereNotIn('za_jobs.status', [2]);

            // ->where('za_jobs.branch_id', $customer_data->branch_id);
            
            // Branch filtering logic - supports both branch_id and branch_ids
              $job_query->where(function ($query) use ($customer_data) {
                $query->where(function ($subQuery) use ($customer_data) {
                  // Case 1: When branch_ids is null or empty, use branch_id
                  $subQuery->whereNull('za_jobs.branch_ids')
                    ->orWhere('za_jobs.branch_ids', '')
                    ->orWhere('za_jobs.branch_ids', '[]')
                    ->where('za_jobs.branch_id', $customer_data->branch_id);
                })->orWhere(function ($subQuery) use ($customer_data) {
                  // Case 2: When branch_ids has value, check if branch_id exists in the JSON array
                  $subQuery->whereNotNull('za_jobs.branch_ids')
                    ->where('za_jobs.branch_ids', '!=', '')
                    ->where('za_jobs.branch_ids', '!=', '[]')
                    ->whereJsonContains('za_jobs.branch_ids', (string)$customer_data->branch_id);
                });
              });
      
 
        // IMPORTANT: Use the correct date field from your table

        // Check if 'interview_date' or 'last_apply_date' exists in your za_jobs table

        // If 'interview_date' exists, use this:

        $job_query->whereDate('za_jobs.last_apply_date', '>=', $today);

        // OR if 'last_apply_date' exists, use this:

        // $job_query->whereDate('za_jobs.last_apply_date', '>=', $today);
 
        // Apply job_type filter based on professional check

        if ($professional_chk) {

            // Professional students see only PUBLIC jobs

            $job_query->where('za_jobs.job_type', 'Public');

        }

        // If TESBO or PLACEMENT, show all jobs (no filter)
 
        $job_details = $job_query->orderByDesc('za_jobs.sno')->get();
 
        foreach ($job_details as $job) {
 
            $interested_students =

                json_decode($job->interest_student_ids, true) ?? [];
 
            $job->applied =

                in_array($customer_id, $interested_students) ? 1 : 0;
 
            $job->job_saved =

                in_array($job->sno, $saved_jobs) ? 1 : 0;

        }

    }
 
    return response()->json([
      'status'    => !empty($job_details) ? '1' : '2',
      'message'   => 'Successfully Retrieved Data',
      'error_msg' => null,
    //   'log_data' => [
    //     'customer_id'          => $customer_id,
    //     'branch_id'            => $customer_data->branch_id,
    //     'today'                => $today,
    //     'tesbo_chk'            => $tesbo_chk,
    //     'placement_chk'        => $placement_chk,
    //     'professional_chk'     => $professional_chk,
    //     'job_count'            => count($job_details),
 
    //     'job_query_sql'        => $job_query->toSql(),
    //     'job_query_bindings'   => $job_query->getBindings(),
    //   ],
      'data'      => !empty($job_details) ? $job_details : [],
    ], 200);

}
 
    public function PlacementListStudent(Request $request)
{
    $customer_id = $request->customer_id;

    // Fetch customer details
    $customer = DB::table('za_customer')->where('sno', $customer_id)->first();

    if (!$customer) {
        return response()->json([
            'status'    => 404,
            'message'   => 'Customer not found',
            'error_msg' => 'Invalid customer ID',
            'data'      => [],
        ], 404);
    }

    $placements = DB::table('za_placement_interview as zpi')
    ->join('za_jobs as zj', 'zj.sno', '=', 'zpi.job_id')
    ->join('za_placement_company as zpc', 'zpc.sno', '=', 'zj.company_id')
    ->leftJoin('za_payment as zp', 'zp.customer_id', '=', 'zpi.customer_id')
    ->leftJoin('za_course as zc', 'zc.sno', '=', 'zp.course_id') // added join
    ->leftJoin('za_course_type as zct', 'zct.sno', '=', 'zc.course_type_id') // added join
    ->leftJoin('za_customer as zcst', 'zcst.sno', '=', 'zpi.customer_id') // to get pic
    ->where('zpi.branch_id', $customer->branch_id)
    ->where('zpi.status', 4)
    ->select([
        'zpi.customer_id',
        'zpc.company_name',
        DB::raw('MAX(zpi.selected_date) as selected_date'),
        DB::raw('MIN(zpi.job_position) as job_position'),
        DB::raw('MIN(zc.course_name) as course_name'), 
        DB::raw('MIN(zct.course_type_name) as course_type_name'),
        'zcst.cus_pic',
         'zcst.cus_name'
    ])
     ->groupBy('zpi.customer_id', 'zpc.company_name', 'zcst.cus_pic', 'zcst.cus_name')
    ->orderByDesc('selected_date')
    ->get();

    // Prepend base URL for customer_pic
    $placements->transform(function($item) {
        $item->customer_pic = $item->cus_pic 
            ? 'https://erp.elysium.academy/cus_pics/' . $item->cus_pic 
            : null;
        return $item;
    });




    // Check if placements found
    if ($placements->isEmpty()) {
        return response()->json([
            'status'    => 204,
            'message'   => 'No placement records found',
            'error_msg' => null,
            'data'      => [],
        ], 200);
    }

    return response()->json([
        'status'    => 200,
        'message'   => 'Successfully retrieved placement data',
        'error_msg' => null,
        'data'      => $placements,
    ], 200);
}


     public function PlacementHistoryList(Request $request)
    {
    $customer_id = $request->customer_id;

    // Check if customer exists
    $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
    if (!$customer_data) {
        return response()->json([
            'status'    => '2',
            'message'   => 'Customer not found',
            'error_msg' => 'Invalid customer ID',
            'data'      => [],
        ], 404);
    }

    // Check training and placement eligibility
    $tesbo_chk = DB::table('za_training')
        ->where('tesbo_check', '!=', '0')
        ->where('customer_id', $customer_id)
        ->exists();

    $placement_chk = DB::table('za_customer')
        ->where('is_placement', '1')
        ->where('sno', $customer_id)
        ->exists();

    $job_details = [];

    if ($tesbo_chk || $placement_chk) {
        // Decode saved jobs for this customer
        $saved_jobs = json_decode($customer_data->job_ids, true) ?? [];

        // Get today’s date
        $today = date('Y-m-d');

        // Fetch upcoming (non-expired) job details
        $job_details = JobModel::select(
                'za_jobs.*',
                'za_placement_company.company_name',
                'za_job_category.job_category_name',
                'za_job_subcategory.job_subcategory_name as job_role_name',
                'za_interview_type.interview_type_name',
                'za_placement_company.company_address'
            )
            ->join('za_placement_company', 'za_placement_company.sno', '=', 'za_jobs.company_id')
            ->leftJoin('za_job_category', 'za_job_category.sno', '=', 'za_jobs.job_category_id')
            ->leftJoin('za_job_subcategory', 'za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
            ->leftJoin('za_interview_type', 'za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
            ->where('za_jobs.branch_id', $customer_data->branch_id)
            ->whereDate('za_jobs.interview_date', '<', $today) // ✅ only non-expired jobs
            ->orderByDesc('za_jobs.sno')
            ->get();
    }

    return response()->json([
        'status'    => '1',
        'message'   => 'Successfully Retrieved Data',
        'error_msg' => null,
        'data'      => $job_details,
    ], 200);
}



   public function ApplyInterestStudent(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|integer', // single student ID
            'job_id' => 'required|integer',      // job ID
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }
    
        $user_id = $request->customer_id ?? 0;
        $job_id = $request->job_id;
        $student_id = $request->customer_id;
    
        // Get student data
        $student_data = DB::table('za_customer')->where('sno', $student_id)->first();
        if (!$student_data) {
            return response()->json([
                'status' => 402,
                'message' => 'Student Not Found',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    
        $branch_id = $student_data->branch_id;
    
        // Get job data
        $job = JobModel::where('sno', $job_id)->where('status', 0)->first();
        if (!$job) {
            return response()->json([
                'status' => 402,
                'message' => 'Job Not Found',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    
        // Assign single student
        $job->interest_student_ids = json_encode([$student_id]);
        $job->update();
    
      
    
        // Generate placement interview ID
        $last_interview = InterviewModel::where('status', '!=', 2)
            ->orderBy('sno', 'desc')
            ->first();
    
        if (!$last_interview) {
            $placement_interview_id = 'SIV-0001/' . substr(date('y'), -2);
        } else {
            $data = $last_interview->placement_interview_id;
            $number = (int) preg_replace('/[^0-9]/', '', explode('/', $data)[0]) + 1;
            $placement_interview_id = sprintf('SIV-%04d', $number) . '/' . substr(date('y'), -2);
        }
    
        $checklist_ids = json_decode($job->interview_checklist_id ?? '[]', true);
        $checklist_status = array_fill(0, count($checklist_ids), "0");
    
        // Create interview entry
        $interview = new InterviewModel();
        $interview->placement_interview_id = $placement_interview_id;
        $interview->customer_id = $student_id;
        $interview->job_id = $job_id;
        $interview->interview_checklist_status = json_encode($checklist_status);
        $interview->who = 1;
        $interview->branch_id = $branch_id;
        $interview->created_by = $user_id;
        $interview->updated_by = $user_id;
        $interview->save();
        
         $this->sendNotification(
                $branch_id,
                $student_id,
                "Job Applied Successfully.",
                "Student App",
                $user_id
            );
        return response()->json([
            'status' => 200,
            'message' => 'Interested Student Applied Successfully',
            'error_msg' => null,
            'data' => null
        ], 200);
        
      
  
    }
   public function JobSave(Request $request)
    {
        $customer_id = $request->customer_id;
        $job_ids = $request->job_id;  // new array from request
    
        // Fetch customer
        $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
        if (!$customer_data) {
            return response()->json([
                'status'    => '2',
                'message'   => 'Customer not found',
                'error_msg' => 'Invalid customer ID',
                'data'      => [],
            ], 404);
        }
    
        // Get existing jobs and merge with new jobs
        $current_jobs = json_decode($customer_data->job_ids, true) ?? [];
        $merged_jobs = array_values(array_unique(array_merge($current_jobs, $job_ids)));
    
        // Save back to database
        DB::table('za_customer')
            ->where('sno', $customer_id)
            ->update([
                'job_ids' => json_encode($merged_jobs)
            ]);
    
        return response()->json([
            'status'  => '1',
            'message' => 'Job IDs updated successfully',
            'data'    => [
                'customer_id' => $customer_id,
                'job_ids'     => $merged_jobs
            ]
        ]);
    }
   public function JobRemove(Request $request)
    {
        $customer_id = $request->customer_id;
        $job_ids_to_remove = $request->job_id;  // array of IDs to remove
    
        // Fetch customer
        $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
        if (!$customer_data) {
            return response()->json([
                'status'    => '2',
                'message'   => 'Customer not found',
                'error_msg' => 'Invalid customer ID',
                'data'      => [],
            ], 404);
        }
    
        // Get existing jobs
        $current_jobs = json_decode($customer_data->job_ids, true) ?? [];
    
        // Remove the IDs
        $updated_jobs = array_values(array_diff($current_jobs, $job_ids_to_remove));
    
        // Save back to database
        DB::table('za_customer')
            ->where('sno', $customer_id)
            ->update([
                'job_ids' => json_encode($updated_jobs)
            ]);
    
        return response()->json([
            'status'  => '1',
            'message' => 'Job IDs removed successfully',
            'data'    => [
                'customer_id' => $customer_id,
                'job_ids'     => $updated_jobs
            ]
        ]);
    }

   public function NotificationList(Request $request)
   {
    $studentId = $request->customer_id; // for Student App

    if (!$studentId) {
        return response()->json([
            'status' => 422,
            'message' => 'Student ID is required',
            'data' => null,
        ], 422);
    }

    $student_data = DB::table('za_customer')->where('sno', $studentId)->first();

    if (!$student_data) {
        return response()->json([
            'status' => 404,
            'message' => 'Student not found',
            'data' => null,
        ], 404);
    }

    // Fetch notifications
    $notifications = NotificationMobileModel::where('customer_id', $studentId)
        ->where('branch_id', $student_data->branch_id)
        ->where('status', 0)
        ->orderBy('notification_date', 'desc')
        ->get();

    // Add time_ago, formatted date & time fields
    $notifications = $notifications->map(function ($item) {
        // $dt = Carbon::parse($item->notification_date);
         $dt = Carbon::parse($item->notification_date, 'Asia/Kolkata');
        $item->time_ago = $dt->diffForHumans();
        $item->formated_date = $dt->format('d-M-Y'); // 08-Aug-2025
        $item->formated_time = $dt->format('h:i A');  // 11:12 AM
        return $item;
    });

    return response()->json([
        'status' => 200,
        'message' => 'Notification list fetched successfully',
        'data' => $notifications,
    ], 200);
}

  
   public function Notification(Request $request)
   {
    $cus_id = $request->customer_id;

    // Fetching payment and training data
    $training = PaymentModel::select(
            'za_payment.nextPayDate',
            'za_payment.amount',
            'za_payment.status',
            'za_payment.customer_id'
        )
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_training', 'za_training.customer_id', '=', 'za_payment.customer_id')
        ->where('za_training.status', '!=', 2)
        ->where('za_training.customer_id', $cus_id)
        ->where('za_payment.status', 0) // Unpaid
        ->orderBy('za_training.sno', 'desc')
        ->get();

    // If no training records found
    if ($training->isEmpty()) {
        return response()->json([
            'status' => 404,
            'message' => 'No data Found',
            'error_msg' => 'No data available',
            'data' => [],
        ], 404);
    }

    $today = Carbon::today();
    $notifications = [];

    // Fetch all customers once and map by customer_id for better performance
    $customers = \App\Models\CustomerModel::whereIn('sno', $training->pluck('customer_id'))->get()->keyBy('sno');

    foreach ($training as $payment) {
      if (!empty($payment->nextPayDate)) {
          $nextPayDate = Carbon::parse($payment->nextPayDate);
          $daysUntilPayDate = $today->diffInDays($nextPayDate, false);
          
          $customer = $customers->get($payment->customer_id);
          if ($customer) {
              $lastNotificationDate = $customer->last_notification_date;
              $notificationNotSentToday = !$lastNotificationDate || Carbon::parse($lastNotificationDate)->lt($today);
              
              // Notify only if due soon or overdue AND notification wasn't sent today
              if ($notificationNotSentToday) {
                  $notificationMessage = null;
             
                  if (($daysUntilPayDate == 2 || $daysUntilPayDate == 1) && $payment->status == 0) {
                      $notificationMessage = "You need to pay the amount before the next due date: {$nextPayDate->toFormattedDateString()}. Amount: {$payment->amount}";
                  }
  
                  if ($nextPayDate->lessThanOrEqualTo($today) && $payment->status == 0) {
                      $notificationMessage = "Your payment is overdue! Please pay the amount as soon as possible. Amount: {$payment->amount}. Date: {$payment->nextPayDate}";
                  }
                  
                  if ($notificationMessage) {
                      // Update only for next day (i.e. once per day)
                      $customer->last_notification_date = $today;
                      $customer->update();

                      $notifications[] = [
                          'customer_id' => $payment->customer_id,
                          'notification_message' => $notificationMessage,
                      ];
                  }
              } 
          }
      }
  }

    
    // If there are no notifications
    if (empty($notifications)) {
        return response()->json([
            'status' => 404,
            'message' => 'No valid payment records to notify',
            'error_msg' => 'No notification sent',
            'data' => [],
        ], 404);
    }

    // Return all notifications in the response
    return response()->json([
        'status' => 200,
        'message' => 'Notifications sent',
        'data' => $notifications,
    ], 200);
}

    
   public function ClearAllNotifications(Request $request)
    {
        $studentId = $request->customer_id;
    
        if (!$studentId) {
            return response()->json([
                'status' => 422,
                'message' => 'Student ID is required',
            ], 422);
        }
    
        $student = DB::table('za_customer')->where('sno', $studentId)->first();
    
        if (!$student) {
            return response()->json([
                'status' => 404,
                'message' => 'Student not found',
            ], 404);
        }
    
        NotificationMobileModel::where('customer_id', $studentId)
            ->where('branch_id', $student->branch_id)
            ->where('status', 0) // only unread
            ->update(['status' => 1]); // mark all as read
    
        return response()->json([
            'status' => 200,
            'message' => 'All notifications cleared successfully',
        ], 200);
    }
   public function ClearSingleNotification(Request $request,$id)
    {
        $notifyId = $id;
    
        if (!$notifyId) {
            return response()->json([
                'status' => 422,
                'message' => 'Notification ID is required',
            ], 422);
        }
    
        $notification = NotificationMobileModel::where('sno', $notifyId)
            ->where('status', 0) // only unread
            ->first();
    
        if (!$notification) {
            return response()->json([
                'status' => 404,
                'message' => 'Notification not found or already cleared',
            ], 404);
        }
    
        $notification->status = 1; // mark as read
        $notification->save();
    
        return response()->json([
            'status' => 200,
            'message' => 'Notification cleared successfully',
        ], 200);
    }

  public function TicketClose(Request $request)
   {
    $cus_id   = $request->customer_id;
    $issue_id = $request->issue_id;
    $status = 2;

    $today = Carbon::today();

    // Fetch the ticket
    $ticket = IssueNoteModel::select(
        'za_issue_note.sno as issue_sno',
        'za_issue_note.issue_id',
        'za_issue_note.created_at',
        'za_issue_note.issue',
        'za_issue_note.category',
        'za_issue_note.priority_level',
        'za_issue_note.status',
        'za_issue_note.description',
        'za_issue_note.closed_date',
        'za_staff.staff_name',
        'za_customer.cus_name',
        'za_customer.sno as cus_sno',
        'za_customer.branch_id as cus_branch_id',
        'za_customer.customer_id'
    )
    ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
    ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno')
    ->where('za_issue_note.customer_id', $cus_id)
    ->where('za_issue_note.sno', $issue_id)
    ->first();

    // Check if ticket exists
    if (!$ticket) {
        return response()->json([
            'status' => 'error',
            'message' => 'Issue not found.'
        ], 404);
    }

    $ticketnot = IssueNoteModel::find($issue_id);

        if (!$ticketnot || $ticketnot->customer_id != $cus_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'Issue not found.'
            ], 404);
        }
        
        // Update
        $ticketnot->status = $status;
        $ticketnot->closed_date = $today;
        $ticketnot->save();

    return response()->json([
        'status'  => 'closed',
        'message' => 'Issue closed successfully.',
        'ticket'  => $ticket
    ]);
}


  
  //   public function PaymentList(Request $request)
  //   {
//     $cus_id = $request->customer_id;
//     $course_id = $request->course_id;

//     // Get all payment records for the customer and course
//     $customer_training = PaymentModel::where('customer_id', $cus_id)
//         ->where('course_id', $course_id)
//         ->orderBy('nextPayDate', 'asc')
//         ->get();

//     if ($customer_training->isEmpty()) {
//         return response()->json(['message' => 'Payment not found.'], 404);
//     }
//     //  $branch_check = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
//     //  $branch_check->gst_percentage //18 percentage need calculat amount and get payable_amount amount + gst 
//     // Get the latest payment record for total_amount
//     $latest_payment = $customer_training->first();
//     $course_fee = $latest_payment->total_amount;

//     // Sum of all paid amounts
//     $paid_fee = $customer_training->sum('paidAmount');

//     // Calculate balance
//     $balance_fee = $course_fee - $paid_fee;

//     return response()->json([
//         'status'       => 'Success',
//         'message'      => 'Payment List successfully.',
//         'Course_fee'   => $course_fee,
//         'Paid_fee'     => $paid_fee,
//         'balance_fee'  => $balance_fee,
//         'payment_list' => $customer_training
//     ]);
// }
  

   public function AddCourseSave(Request $request)
   {
    $cus_id = $request->customer_id;
    $new_course_id = $request->course_id;

    // Fetch the user
    $user = CustomerModel::where('sno', $cus_id)->first();

    if (!$user) {
        return response()->json([
            'status'  => 'error',
            'message' => 'Customer not found.'
        ], 404);
    }

    // Decode existing courses or start with an empty array
    $existing_courses = $user->add_course ? json_decode($user->add_course, true) : [];

    // Ensure it's an array
    if (!is_array($existing_courses)) {
        $existing_courses = [];
    }

    // Add new course if not already in array
    if (!in_array($new_course_id, $existing_courses)) {
        $existing_courses[] = $new_course_id;
    }

    // Save updated course list
    $user->add_course = json_encode($existing_courses);
    $user->save();
     
        $this->sendNotification(
            $user->branch_id,
            $user->sno,
            "Interested Course is applied.",
            "Student App",
            $user->sno
        );

    return response()->json([
        'status'  => 'success',
        'message' => 'Successfully added course.'
    ]);
}
   public function RemoveCourseSave(Request $request)
   {
    $cus_id = $request->customer_id;
    $remove_course_id = $request->course_id;

    // Fetch the user
    $user = CustomerModel::where('sno', $cus_id)->first();

    if (!$user) {
        return response()->json([
            'status'  => 'error',
            'message' => 'Customer not found.'
        ], 404);
    }

    // Decode existing courses or start with an empty array
    $existing_courses = $user->add_course ? json_decode($user->add_course, true) : [];

    // Ensure it's an array
    if (!is_array($existing_courses)) {
        $existing_courses = [];
    }

    // Remove the course if it exists in array
    if (in_array($remove_course_id, $existing_courses)) {
        $existing_courses = array_filter($existing_courses, function ($course) use ($remove_course_id) {
            return $course != $remove_course_id;
        });

        // Reindex array to prevent JSON from having broken keys
        $existing_courses = array_values($existing_courses);

        // Save updated course list
        $user->add_course = json_encode($existing_courses);
        $user->save();

        // Send notification
        $this->sendNotification(
            $user->branch_id,
            $user->sno,
            "Interested course has been removed.",
            "Student App",
            $user->sno
        );

        return response()->json([
            'status'  => 'success',
            'message' => 'Course removed successfully.'
        ]);
    } else {
        return response()->json([
            'status'  => 'error',
            'message' => 'Course not found in the user’s list.'
        ]);
    }
}

   
   public function AddCourseList(Request $request)
   {
    $cus_id = $request->customer_id;
   

    // Fetch the user
    $user = CustomerModel::where('sno', $cus_id)->first();

    if (!$user) {
        return response()->json([
            'status'  => 'error',
            'message' => 'Customer not found.'
        ], 404);
    }

        $intrestedcourse = json_decode($user->add_course, true) ?? []; 
        $allCourseData = []; // To store data for each batch


        $oldCourses = ManageCoursesModel::select(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            DB::raw("DATE_FORMAT(za_course.created_at, '%d-%m-%Y') as created_date"),
            DB::raw('IFNULL(SUM(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE 0 END), "") as total_rating'),
            DB::raw('IFNULL(AVG(CASE WHEN za_student_course_feedback.rating IS NOT NULL THEN za_student_course_feedback.rating ELSE NULL END), "") as average_rating')
            // DB::raw('DATE(za_course.created_at) as created_date')

        )

        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
         ->leftJoin('za_student_course_feedback', function ($join) {
            $join->on('za_course.sno', '=', 'za_student_course_feedback.course_id');
        })
        ->where('za_course.status', '!=', 2)
        ->whereIn('za_course.sno', $intrestedcourse)
        ->groupBy(
            'za_course.sno',
            'za_course.course_name',
            'za_course.course_version',
            'za_course.course_partical_hours',
            'za_course.course_theory_hours',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_course.attachment',
            'za_course.thumbnail',
            'za_course.course_desc',
            'za_course.course_goals',
            'za_course.course_future_scope',
            'created_date'
        )
        ->orderBy('za_course.sno', 'desc')
        ->limit(40)
        ->get();

        // Base URLs for attachments and thumbnails
        $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
        $thumbnailBaseUrl  = 'https://erp.elysium.academy/course_thumbnail_image/';
        // return $Courses;
        // Add base URLs to the attachments and thumbnails
        $oldCourses->transform(function ($course) use ($attachmentBaseUrl, $thumbnailBaseUrl,$intrestedcourse) {
            $course->attachment = $attachmentBaseUrl . $course->attachment;
            $course->thumbnail  = $thumbnailBaseUrl . $course->thumbnail;
            $course->interested = in_array($course->sno, $intrestedcourse) ? 1 : 0;
            // 🎯 Random rating logic (if no rating data)
            
            // Generate random float between 4.0 and 5.0
            $course->average_rating = number_format(mt_rand(40, 50) / 10, 1);
            $course->total_rating = $course->average_rating * rand(5, 30); // fake total rating count
            return $course;
        });

        $allCourseData[] = [
            'coursesDetails' => $oldCourses,
        ];
        if ($allCourseData) {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        } else {
            return response()->json([
                'status'    => 200,
                'message'   => 'Data Retrieved Successfully',
                'error_msg' => null,
                'data'      => $allCourseData,
            ], 200);
        }
}
//   public function PaymentList(Request $request)
//   {
//     $cus_id = $request->customer_id;
//     $course_id = $request->course_id;
    
//     $redeemlist = DB::table('za_students_redeem')
//         ->where('student_id', $cus_id)
//         ->where('status', 0)
//         ->get();
//     $redeemSum = DB::table('za_students_redeem')
//         ->where('student_id', $cus_id)
//         ->where('status', 0)
//         ->sum('redeem_value');
        
//     // Get all payment records for the customer and course
//     $customer_training = PaymentModel::where('za_payment.customer_id', $cus_id)
//         ->where('za_payment.course_id', $course_id)
//         ->join('za_branch','za_branch.sno','=','za_payment.branch_id')
//         ->select('za_payment.*','za_branch.key_secret','za_branch.key_id')
//         ->orderBy('za_payment.nextPayDate', 'asc')
//         ->get();

//     if ($customer_training->isEmpty()) {
//         return response()->json(['message' => 'Payment not found.'], 404);
//     }

//     // Get branch info (assuming branch_id is stored in the first payment record)
//     $branch_id = $customer_training->first()->branch_id ?? null;
//     $branch_check = BranchModel::where('sno', $branch_id)->first();

//     // GST percentage (default to 0 if branch not found)
//     $gst_percentage = $branch_check->gst_percentage ?? 0;

//     // Add payable_amount (amount + GST)
//     $customer_training->transform(function ($payment) use ($gst_percentage) {
//         $amount = $payment->amount ?? 0;
//         $gst_amount = ($amount * $gst_percentage) / 100;
//         $payment->gst_percentage_new = $gst_percentage;
//         $payment->gst_amount = round($gst_amount, 2);
//         $payment->payable_amount = round($amount + $gst_amount, 2);
//         return $payment;
//     });

//     // Get the latest payment record for total_amount
//     $latest_payment = $customer_training->first();
//     $course_fee = $latest_payment->total_amount ?? 0;

//     // Sum of all paid amounts
//     $paid_fee = $customer_training->sum('paidAmount');

//     // Calculate balance
//     $balance_fee = $course_fee - $paid_fee;

//     return response()->json([
//         'status'        => 'Success',
//         'message'       => 'Payment List successfully retrieved.',
//         'redeemlist'    => $redeemlist,
//         'redeemValue'    => $redeemSum,
//         'Course_fee'    => $course_fee,
//         'Paid_fee'      => $paid_fee,
//         'Balance_fee'   => $balance_fee,
//         'payment_list'  => $customer_training
//     ]);
// }

public function PaymentList(Request $request)
  {
    $cus_id = $request->customer_id;
    $course_id = $request->course_id;
 
    $redeemlist = DB::table('za_students_redeem')
      ->where('student_id', $cus_id)
      ->where('status', 0)
      ->get();
    $redeemSum = DB::table('za_students_redeem')
      ->where('student_id', $cus_id)
      ->where('status', 0)
      ->sum('redeem_value');
 
    // Get all payment records for the customer and course
    $customer_training = PaymentModel::where('za_payment.customer_id', $cus_id)
      ->where('za_payment.course_id', $course_id)
      ->join('za_branch', 'za_branch.sno', '=', 'za_payment.branch_id')
      ->select('za_payment.*', 'za_branch.key_secret', 'za_branch.key_id')
      ->orderBy('za_payment.nextPayDate', 'asc')
      ->get();
 
    if ($customer_training->isEmpty()) {
      return response()->json(['message' => 'Payment not found.'], 404);
    }
 
    // Get branch info (assuming branch_id is stored in the first payment record)
    $branch_id = $customer_training->first()->branch_id ?? null;
    $branch_check = BranchModel::where('sno', $branch_id)->first();
 
    // GST percentage (default to 0 if branch not found)
    $gst_percentage = $branch_check->gst_percentage ?? 0;
 
    $applyGst = function ($amount) use ($gst_percentage) {
      return round($amount + (($amount * $gst_percentage) / 100), 2);
    };
    // Add payable_amount (amount + GST)
    $customer_training->transform(function ($payment) use ($gst_percentage, $applyGst) {
      $amount = $payment->amount ?? 0;
      $gst_amount = ($amount * $gst_percentage) / 100;
      $payment->amount = round($applyGst($payment->amount  ?? 0));
      $payment->paidAmount = round($applyGst($payment->paidAmount  ?? 0));
      $payment->balanceFee = round($applyGst($payment->balanceFee  ?? 0));
      $payment->gst_percentage_new = $gst_percentage;
      $payment->gst_amount = round($gst_amount, 2);
      $payment->payable_amount = round($amount + $gst_amount, 2);
      return $payment;
    });
 
    // Get the latest payment record for total_amount
    $latest_payment = $customer_training->first();
    $course_fee = $applyGst($latest_payment->total_amount ?? 0);
 
    // Sum of all paid amounts
    $paid_fee = $customer_training->sum('paidAmount');
 
    // Calculate balance
    $balance_fee = $course_fee - $paid_fee;
    
    return response()->json([
      'status'        => 'Success',
      'message'       => 'Payment List successfully retrieved.',
      'redeemlist'    => $redeemlist,
      'redeemValue'    => $redeemSum,
      'Course_fee'    => round($applyGst($course_fee)),
      'Paid_fee'      => round($paid_fee),
      'Balance_fee'   => round($balance_fee),
      'payment_list'  => $customer_training
    ]);
  }
  
   public function PaymentSave(Request $request)
   {
    $cus_id = $request->customer_id;
    $course_id  = $request->course_id;
    $payment_id = $request->payment_id;
    $pay_amount_gst = $request->pay_amount;
    $pay_mode   = $request->pay_mode;
    $transaction   = $request->transaction;
    $today      = Carbon::today();
    $coupon_ids   = $request->coupon_ids;
    $coupon_amount   = $request->coupon_amount;
     $initialPayDateFormatted = now()->format('Y-m-d');
    // return $request->all();
    $customer_training = PaymentModel::where('customer_id', $cus_id)
        ->where('course_id', $course_id)->where('sno', $payment_id)->first();
        
    $brancgGst = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
    $gstPercentage = $brancgGst->gst_percentage ?? 0;

         // GST calculation (exclusive)
        if ($gstPercentage > 0) {
            $gst_amount = round($pay_amount_gst * ($gstPercentage / 100), 2);
            $pay_amount_total = round($pay_amount_gst + $gst_amount, 2);
        } else {
            $pay_amount_total = $pay_amount_gst;
            $gst_amount = 0;
        }
        
        if($coupon_amount >0){
            $pay_amount = $pay_amount_total;
            $effectivePayAmount = $customer_training->amount;
        }else{
            $pay_amount =   $customer_training->amount;
            $effectivePayAmount = $customer_training->amount;
        }
    
    //  return $effectivePayAmount;
     
    $year = date("Y");
    
    $lastNumber = PaymentModel::where('status', 1)
        ->where('invoice_id', 'like', 'EA/' . $year . '/INV%')
        ->selectRaw("MAX(CAST(SUBSTRING(invoice_id, LENGTH('EA/$year/INV') + 1) AS UNSIGNED)) as max_inv")
        ->value('max_inv');
    
    $nextNumber = $lastNumber ? $lastNumber + 1 : 2005;
    
    $invoice_id = 'EA/' . $year . '/INV' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    $check_update = false;
    //  return $customer_trainin;
    if($customer_training->amount == $effectivePayAmount){ // equall amount apy
        // return "equall";
        try {
            DB::beginTransaction();
              $customer_training->initialPayDate = $today;
              $customer_training->paidAmount = $pay_amount;
              $customer_training->payment_mode_label = $pay_mode;
              $customer_training->invoice_id = $invoice_id;
              $customer_training->transaction = is_array($transaction) ? json_encode($transaction) : $transaction;
              $customer_training->status = 1;
              $customer_training->save();
               if($customer_training){
                      $branch_check = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
                
                      $training_id = TrainingModel::where('payment_id', $customer_training->payment_id)->first();
                      // Update or Create Training Model
                      $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                      $paidGst = $customer_training->paidAmount * ($gstPercentage / 100);
                
                      TrainingModel::where('payment_id', $customer_training->payment_id)
                        ->where('customer_id', $customer_training->customer_id)
                        ->update([
                            'paid_amount'    => DB::raw("paid_amount + {$customer_training->paidAmount}"),
                            'paid_gst'       => DB::raw("paid_gst + {$paidGst}"),
                            'balance_amount' => DB::raw("balance_amount - {$customer_training->paidAmount}"),
                            'balance_gst'    => DB::raw("balance_gst - {$paidGst}"),
                            'total_amount'   => DB::raw("total_amount + " . ($customer_training->paidAmount + $paidGst)),
                        ]);

                      
                     
                }
      
              $customer = CustomerModel::where('sno', $customer_training->customer_id)->first();
              $training_id = TrainingModel::where('payment_id', $customer_training->payment_id)->first();
              $branch_check = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
              $add_subledger->subledger_desc = 'Students App fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->traning_sno = $training_id->sno;
              $add_subledger->created_by = $cus_id;
              $add_subledger->updated_by = $cus_id;

              $add_subledger->save();

              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $pay_amount,
                      'invoice_id' => $invoice_id,
                      'receipt_id' => null,
                      'training_id' => $training_id->sno,
                      'debit' => null,
                      'tax' => $pay_amount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $pay_amount + $pay_amount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $cus_id,
                      'updated_by' => $cus_id,
                  ]
              );
               $check_update = true;
                if($customer->jumper_skiper == 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(20); 
          
                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
          
                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 20;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;
        
                  // return $newPointsFull;
                  $newPointsFull->save();
          
                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
          
                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper > 1){
              $pointsDataFullAttendance = $helper->get_points_by_id(21); 
      
              // Get points and reason for full attendance
              $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
              $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
      
              // Save new points for the student (full attendance)
              $newPointsFull = new StudentpointsModel();
              $newPointsFull->branch_id = $branch_id;
              $newPointsFull->student_id = $pay_customer_id;
              $newPointsFull->points_id = 21;
              $newPointsFull->points = $pointFull;
              $newPointsFull->reason = $reasonFull;
    
              // return $newPointsFull;
              $newPointsFull->save();
      
              // Update the student's available points in the CustomerModel
              $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
      
              if ($student_points) {
                  $student_points->points_score += $pointFull;
                  $student_points->save();
              }
            }
                $this->sendNotification(
                    $branch_check->sno,
                    $cus_id,
                    "your payment was successful.",
                    "Student App",
                    $cus_id
                );
                DB::commit();
                return response()->json([
                  'status'  => 'Success',
                  'message' => 'Successfully Payment Added.',
                  'Payment' => $customer_training
                ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => 'Payment failed', 'error' => $e->getMessage()], 500);
        }
      
    }
    else if($customer_training->amount > $effectivePayAmount){ // below amount pay
        //  return "below";
        try {
            DB::beginTransaction();
              $payment_up = new PaymentModel();
              $payment_up->payment_id = $customer_training->payment_id;
              $payment_up->customer_id = $customer_training->customer_id;
              $payment_up->course_id = $customer_training->course_id;
              $payment_up->initialPayDate = $customer_training->nextPayDate;
              $payment_up->nextPayDate = $customer_training->nextPayDate;
              $payment_up->amount = $customer_training->amount - $pay_amount;
        
              $payment_up->paidAmount = 0;
              $payment_up->gst_amount = $customer_training->amount - $pay_amount * 0.18;
              $payment_up->payment_mode_label = null;
              $payment_up->transaction = is_array($transaction) ? json_encode($transaction) : $transaction;
              $payment_up->balanceFee = $customer_training->balanceFee;
              $payment_up->total_amount = $customer_training->total_amount;
              $payment_up->created_by = $cus_id;
              $payment_up->updated_by = $cus_id;
              $payment_up->branch_id = $customer_training->branch_id;
              $payment_up->status = $customer_training->amount - $pay_amount < 0 ? 2:0;
              // return $payment_up;
              $payment_up->save(); // Save new record
          
               if($payment_up){
                      $customer_training->initialPayDate = $today;
                      $customer_training->paidAmount = $pay_amount;
                      $customer_training->balanceFee = $customer_training->balanceFee - $pay_amount;
                      $customer_training->payment_mode_label = $pay_mode;
                      $customer_training->invoice_id = $invoice_id;
                      $customer_training->status = 1;
                      $customer_training->save();
                      
                       $branch_check = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
                
                      $training_id = TrainingModel::where('payment_id', $customer_training->payment_id)->first();
                      // Update or Create Training Model
                      $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                      $paidGst = $customer_training->paidAmount * ($gstPercentage / 100);
                
                      TrainingModel::where('payment_id', $customer_training->payment_id)
                        ->where('customer_id', $customer_training->customer_id)
                        ->update([
                            'paid_amount'    => DB::raw("paid_amount + {$customer_training->paidAmount}"),
                            'paid_gst'       => DB::raw("paid_gst + {$paidGst}"),
                            'balance_amount' => DB::raw("balance_amount - {$customer_training->paidAmount}"),
                            'balance_gst'    => DB::raw("balance_gst - {$paidGst}"),
                            'total_amount'   => DB::raw("total_amount + " . ($customer_training->paidAmount + $paidGst)),
                        ]);

                      
                     
                }
      
              $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
              $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
              $branch_check = BranchModel::where('sno', $customer_training->branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
              $add_subledger->subledger_desc = 'Students App fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->traning_sno = $training_id->sno;
              $add_subledger->created_by = $cus_id;
              $add_subledger->updated_by = $cus_id;

              $add_subledger->save();

              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $pay_amount,
                      'invoice_id' => $invoice_id,
                      'receipt_id' => null,
                      'training_id' => $training_id->sno,
                      'debit' => null,
                      'tax' => $pay_amount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $pay_amount + $pay_amount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $cus_id,
                      'updated_by' => $cus_id,
                  ]
              );
                $check_update = true;
                if($customer->jumper_skiper == 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(20); 
          
                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
          
                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 20;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;
    
                  // return $newPointsFull;
                  $newPointsFull->save();
          
                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
          
                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                if($customer->jumper_skiper > 1){
                  $pointsDataFullAttendance = $helper->get_points_by_id(21); 
          
                  // Get points and reason for full attendance
                  $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                  $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
          
                  // Save new points for the student (full attendance)
                  $newPointsFull = new StudentpointsModel();
                  $newPointsFull->branch_id = $branch_id;
                  $newPointsFull->student_id = $pay_customer_id;
                  $newPointsFull->points_id = 21;
                  $newPointsFull->points = $pointFull;
                  $newPointsFull->reason = $reasonFull;
    
                  // return $newPointsFull;
                  $newPointsFull->save();
          
                  // Update the student's available points in the CustomerModel
                  $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
          
                  if ($student_points) {
                      $student_points->points_score += $pointFull;
                      $student_points->save();
                  }
                }
                 $this->sendNotification(
                    $branch_check->sno,
                    $cus_id,
                    "your payment was successful.",
                    "Student App",
                    $cus_id
                );
                DB::commit();
                return response()->json([
                  'status'  => 'Success',
                  'message' => 'Successfully Payment Added.',
                  'Payment' => $customer_training
                ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => 'Payment failed', 'error' => $e->getMessage()], 500);
        }
      
    }
    else if($customer_training->amount < $effectivePayAmount){ // higher amount pay 
        // return "higher";
       
    
            $payment_id = PaymentModel::where('sno', $id)->where('status','!=', 2)->first();
            $paymentsdetails = PaymentModel::where('customer_id', $cus_id)->where('status','!=', 2)->orderBy('nextPayDate','ASC')->get();
            if ($payment_id) {
                
                try {
                  DB::beginTransaction();
                  // return $paymentsdetails;
                  // Find the index of the current record
                  $currentIndex = $paymentsdetails->search(function ($item) use ($id) {
                      return $item->sno == $id;
                  });
                  // return $currentIndex;
    
    
                    $payment_up = $paymentsdetails[$currentIndex + 1]; // Next record
        
                    // Update the next record
                    $payment_up->amount =  $payment_up->amount + $request->balanceFees;
                    $payment_up->gst_amount = ($payment_up->amount * 0.18);
                    if ($payment_up->amount < 0) {
                        $payment_up->balanceFee -= abs($request->balanceFees);
                    }
                    $payment_up->updated_by = $cus_id;
                    $payment_up->status = $payment_up->amount + $request->balanceFees < 0 ? 2:0;
    
                    // return $payment_up;
                    $payment_up->update();
    
                     if($payment_up->amount < 0){
                      if (isset($paymentsdetails[$currentIndex + 2])) {
                          $next_payment_up = $paymentsdetails[$currentIndex + 2]; // Record after next
    
                          // Update the second next record
                          $next_payment_up->amount = $next_payment_up->amount + $request->balanceFees; // Adjust as needed
                          $next_payment_up->gst_amount = ($next_payment_up->amount * 0.18);
                          $next_payment_up->balanceFee = $next_payment_up->balanceFee + $request->balanceFees < 0 ? 0 : $next_payment_up->balanceFee + $request->balanceFees;
                          $next_payment_up->updated_by = $cus_id;
                          $next_payment_up->status = $next_payment_up->amount + $request->balanceFees < 0 ? 2:0;
                          // return $payment_up;
                          $next_payment_up->update();
                          // return $paymentsdetails;
                      }
                    }
                     if(isset($next_payment_up) && $next_payment_up->amount < 0){
                      if (isset($paymentsdetails[$currentIndex + 3])) {
                          $nexts_payment_up = $paymentsdetails[$currentIndex + 3]; // Record after next
    
                          // Update the second next record
                          $nexts_payment_up->amount = $nexts_payment_up->amount + $request->balanceFees; // Adjust as needed
                          $nexts_payment_up->gst_amount = ($nexts_payment_up->amount * 0.18);
                          $nexts_payment_up->balanceFee = $nexts_payment_up->balanceFee + $request->balanceFees < 0 ? 0 : $nexts_payment_up->balanceFee + $request->balanceFees;
                          $nexts_payment_up->updated_by = $cus_id;
                          $nexts_payment_up->status = $nexts_payment_up->amount + $request->balanceFees < 0 ? 2:0;
                          // return $payment_up;
                          $nexts_payment_up->update();
                          // return $paymentsdetails;
                      }
                    }
                     if (isset($nexts_payment_up) && $nexts_payment_up->amount < 0) {
                      if (isset($paymentsdetails[$currentIndex + 4])) {
                          $nexts_payment_up_f = $paymentsdetails[$currentIndex + 4]; // Record after next
    
                          // Update the second next record
                          $nexts_payment_up_f->amount = $nexts_payment_up_f->amount + $request->balanceFees ; // Adjust as needed
                          $nexts_payment_up_f->gst_amount = ($nexts_payment_up_f->amount * 0.18);
                          $nexts_payment_up_f->updated_by = $cus_id;
                          $nexts_payment_up_f->status = $nexts_payment_up_f->amount + $request->balanceFees < 0 ? 2:0;
                          // return $payment_up;
                          $nexts_payment_up_f->update();
                          // return $paymentsdetails;
                      }
                    }
    
        
                    if ($payment_up) {
                        $payment_id->initialPayDate = $initialPayDateFormatted;
                        $payment_id->paidAmount = $paidAmount;
                        $payment_id->invoice_id = $invoice_id;
                        $payment_id->gst_amount = $paidAmount * 0.18;
                        $payment_id->payment_mode_label = $paymentMode;
                        $payment_id->transaction = $transaction;
                        // $payment_id->balanceFee = $payment_id->balanceFee - $paidAmount;
                        $payment_id->balanceFee = $payment_id->balanceFee - abs($request->balanceFees);
        
                        $payment_id->status = 1;
                        // return $payment_id;
                        $payment_id->update(); // Save changes
                        // return $payment_id;
                        $check_update = true;
                        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        
                        $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                        // Update or Create Training Model
                        $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                        $paidGst = $payment_id->paidAmount * ($gstPercentage / 100);
        
                       
                        TrainingModel::where('payment_id', $payment_id->payment_id)
                            ->where('customer_id', $payment_id->customer_id)
                            ->update([
                                'paid_amount'    => DB::raw("paid_amount + {$payment_id->paidAmount}"),
                                'paid_gst'       => DB::raw("paid_gst + {$paidGst}"),
                                'balance_amount' => DB::raw("balance_amount - {$payment_id->paidAmount}"),
                                'balance_gst'    => DB::raw("balance_gst - {$paidGst}"),
                                'total_amount'   => DB::raw("total_amount + " . ($payment_id->paidAmount + $paidGst)),
                            ]);
                    }
        
                    $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
                    $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
                    $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                    $branch_code = $branch_check->city_short_code;
                    $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();
        
                    if (!$ledger_check) {
                        $year = date("Y");
                        $subledger_id = $year . '/' . $branch_code . '/' . "SUB0001";
                    } else {
                        $data = $ledger_check->subledger_id;
                        $slice = explode("/", $data);
                        $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                        $next_number_cos = (int) $result_cos + 1;
                        $request_cos = sprintf("SUB%04d", $next_number_cos);
                        $year = date("Y");
                        $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                    }
        
                    $add_subledger = new SubLedgerModel();
                    $add_subledger->ledger_id = 1;
                    $add_subledger->subledger_id = $subledger_id;
                    $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
                    $add_subledger->subledger_desc = 'Students App fees';
                    $add_subledger->branch_id = $branch_check->sno;
                    $add_subledger->traning_sno = $training_id->sno;
                    $add_subledger->created_by = $cus_id;
                    $add_subledger->updated_by = $cus_id;
        
                    $add_subledger->save();
        
                    $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                    if (!$tr_check) {
                        $year = date("Y");
                        $transaction_id = $year . '/' . $branch_code . '/' . "TRA0001";
                    } else {
                        $data = $tr_check->transaction_id;
                        $slice = explode("/", $data);
                        $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                        $next_number_cos = (int) $result_cos + 1;
                        $request_tr = sprintf("TRA%04d", $next_number_cos);
                        $year = date("Y");
                        $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                    }
                    TransactionModel::updateOrCreate(
                        [
                            'branch_id' => $branch_check->sno,
                            'transaction_id' => $transaction_id,
                            'transaction_type' => 'Credit',
                            'transaction_name' => 'Customer',
                            'trans_source_id' => $customer->customer_id,
                            'ledger_id' => 1,
                            'subledger_id' => $add_subledger->sno,
                            'credit' => $paidAmount,
                            'invoice_id' => $invoice_id,
                            'receipt_id' => $receipt_id,
                            'training_id' => $training_id->sno,
                            'debit' => null,
                            'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                            'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                            'created_by' => $cus_id,
                            'updated_by' => $cus_id,
                        ]
                    );
                    if($customer->jumper_skiper == 1){
                      $pointsDataFullAttendance = $helper->get_points_by_id(20); 
              
                      // Get points and reason for full attendance
                      $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                      $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
              
                      // Save new points for the student (full attendance)
                      $newPointsFull = new StudentpointsModel();
                      $newPointsFull->branch_id = $branch_id;
                      $newPointsFull->student_id = $pay_customer_id;
                      $newPointsFull->points_id = 20;
                      $newPointsFull->points = $pointFull;
                      $newPointsFull->reason = $reasonFull;
        
                      // return $newPointsFull;
                      $newPointsFull->save();
              
                      // Update the student's available points in the CustomerModel
                      $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
              
                      if ($student_points) {
                          $student_points->points_score += $pointFull;
                          $student_points->save();
                      }
                    }
                    if($customer->jumper_skiper > 1){
                      $pointsDataFullAttendance = $helper->get_points_by_id(21); 
              
                      // Get points and reason for full attendance
                      $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
                      $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';
              
                      // Save new points for the student (full attendance)
                      $newPointsFull = new StudentpointsModel();
                      $newPointsFull->branch_id = $branch_id;
                      $newPointsFull->student_id = $pay_customer_id;
                      $newPointsFull->points_id = 21;
                      $newPointsFull->points = $pointFull;
                      $newPointsFull->reason = $reasonFull;
        
                      // return $newPointsFull;
                      $newPointsFull->save();
              
                      // Update the student's available points in the CustomerModel
                      $student_points = CustomerModel::where('sno', $pay_customer_id)->first();
              
                      if ($student_points) {
                          $student_points->points_score += $pointFull;
                          $student_points->save();
                      }
                    }
                     $this->sendNotification(
                        $branch_check->sno,
                        $cus_id,
                        "your payment was successful.",
                        "Student App",
                        $cus_id
                    );
                    DB::commit();
                    return response()->json([
                          'status'  => 'Success',
                          'message' => 'Successfully Payment Added.',
                          'Payment' => $customer_training
                      ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => false, 'message' => 'Payment failed', 'error' => $e->getMessage()], 500);
                }
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
           
        }
        // communication to code
    if ($check_update) {
          $tempdate = PaymentModel::where('branch_id', $branch_id)->where('status','!=', 2)->where('customer_id', $customer->sno)->where('course_id', $pay_course_id)->orderBy('sno', 'desc')->first();
            //   Send Communication
            $branch_data = BranchModel::where('sno', $branch_id)->first();
            $branch_name = " ";
            if ($branch_data->branch_type == 1) {
                $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
                $branch_name = $branch_data->franchise_name;
            }

            //   SMS
            $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
            $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
            $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
            $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
            $totalAmount      = $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0;

            if ($transaction_id && $customer_mobiles) {
                $branch_data     = BranchModel::where('sno', $branch_id)->first();
                $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '005_PaymentSuccess')->first();
                $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
                $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
                $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
                $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
                $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
                $mobile_number   = $country_code . $customer_mobiles;

                // Replace placeholders with actual values
                $replacement_values = [$customer_names, $totalAmount, $transaction_id];
                $message_content    = preg_replace_callback(
                    '/\{#var#\}/',
                    function () use (&$replacement_values) {
                        return array_shift($replacement_values);
                    },
                    $message_content
                );

                $route    = "default";
                $postData = [
                    'authkey' => $authkey,
                    'mobiles' => $mobile_number,
                    'message' => $message_content,
                    'sender'  => $sender_id,
                    'route'   => $route,
                ];

                // API URL
                $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                // Initialize the resource
                $ch = curl_init();
                curl_setopt_array($ch, [
                    CURLOPT_URL            => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $postData,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSL_VERIFYPEER => 0,
                ]);
                // Get response
                $response = curl_exec($ch);
                // return $response;
                $err = curl_error($ch);
                curl_close($ch);

            }
            // Email
            if ($transaction_id && $customer_mails) {
                $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();

                $email_template_id = 18; // thank you template
                $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
                $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();

                $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);

                $helper             = new \App\Helpers\Helpers();
                $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                $paymentDate        = date($common_date_format);
                // $paymentDate        = $tempdate->initialPayDate;
                $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                $paymentAmount      = $paymentAmt . ". Rs";
                $content            = $emailTemplate->email_subject;
                $content            = str_replace('#name', $customer_names, $content);
                $content            = str_replace('#course', $coursename->course_name ?? 'Course', $content);
                $content            = str_replace('#transactionId', $transaction_id, $content);
                $content            = str_replace('#amount', $paymentAmount, $content);
                $content            = str_replace('#transactionDate', $paymentDate, $content);
                $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
                $branchNo           = $branch_data->mobile ?? '9677781155';
                $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
                $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
                $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
                $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

                $mailData = [
                    'url'         => 'Eapl.com',
                    'subject'     => $dynamicSubject,
                    'content'     => $content,
                    'branchNo'    => $branchNo,
                    'branchemail' => $branchemail, // Use the message content from the request
                    'fbLink'      => $fbLink,      // Use the message content from the request
                    'instaLink'   => $instaLink,   // Use the message content from the request
                    'salesMobile' => $branch_data->sales_mobile ?? '9677781155',
                ];

                $to_address   = $customer_mails;
                $from_address = 'elysiumacademy@elysium.community';
                $from_name    = 'Elysium Academy®';

                Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

            }
            // Whatsapp messages
            if ($transaction_id && $customer_mobiles) {
                $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
                $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
                $hasHeader  = false; // Example flag: set based on template
                $hasBody    = false; // Example flag: set based on template
                $components = [];
                $couponCode = " ";

                // Example flag: set based on template
                $components_trans = [];
                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                if ($currentHour >= 5 && $currentHour < 12) {
                    $greeting = 'Good Morning';
                } elseif ($currentHour >= 12 && $currentHour < 18) {
                    $greeting = 'Good Afternoon';
                } else {
                    $greeting = 'Good Evening';
                }
                 $helper             = new \App\Helpers\Helpers();
                $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                $paymentDate        = date($common_date_format);
                // $paymentDate        = $tempdate->initialPayDate;
                $paymentAmt         = number_format($totalAmount, 2, '.', ',');
                $paymentAmount      = $paymentAmt . ". Rs";

                $templateName = 'elysium_academy_pay_transaction2';
                $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
                $bodyText     = [
                    [
                        'type'           => 'text',
                        'text'           => $greeting,
                        'parameter_name' => 'greet_msg',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $customer_names,
                        'parameter_name' => 'customer_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $coursename->course_name ?? 'Course',
                        'parameter_name' => 'course_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $transaction_id,
                        'parameter_name' => 'transaction_id',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $paymentAmount,
                        'parameter_name' => 'amount',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $paymentDate,
                        'parameter_name' => 'pay_date',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->cre_mobile ?? '9677781155',
                        'parameter_name' => 'contact_no',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                        'parameter_name' => 'contact_email',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_name ?? 'Elysium Academy',
                        'parameter_name' => 'branch_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $branch_data->sales_mobile ?? '9677781155',
                        'parameter_name' => 'contact_no2',
                    ],

                ];
                $components_trans[] = [
                    'type'       => 'header',
                    'parameters' => [
                        [
                            'type'  => 'image',
                            'image' => [
                                'link' => $headerImage, // Dynamically set header image
                            ],
                        ],
                    ],
                ];

                $components_trans[] = [
                    'type'       => 'body',
                    'parameters' => $bodyText,
                ];
                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                $WhatsAppBusinessAccountId = $this->businessId;
                $accessToken               = $this->accessToken;
                $fromPhoneNumberId         = $this->phoneNumberId;

                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

                $to           = $customer_mobiles;
                $languageCode = 'en';

                if (strpos($to, '+91') !== 0) {
                    $to = '+91' . $to;
                }

                $message = 'test~message';

                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to'                => $to,
                    'type'              => 'template',
                    'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                            'code' => $languageCode,
                        ],
                        'components' => $components_trans,
                    ],
                ];

                $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

            }

        }
      
     
        
}
   private function sendRequestToWhatsApp($url, $token, $data)
   {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
  


public function couponAmount(Request $request)
{
    // Validate the incoming payload
    $request->validate([
        'customer_id'   => 'required|integer',
        'payment_id'    => 'required|integer',
        'course_id'     => 'required|integer',
        'coupon_amount' => 'required|numeric|min:0',
        'coupon_ids'    => 'required|array',
        'coupon_ids.*'  => 'integer',
    ]);

    $customer_id   = $request->customer_id;
    $payment_id    = $request->payment_id;
    $course_id     = $request->course_id;
    $coupon_amount = $request->coupon_amount;
    $coupon_ids    = $request->coupon_ids;

    // Fetch the payment record
    $customer_payment = PaymentModel::where('customer_id', $customer_id)
        ->where('course_id', $course_id)
        ->where('sno', $payment_id)
        ->first();

    if (!$customer_payment) {
        return response()->json([
            'status'  => 'error',
            'message' => 'Payment record not found',
        ], 404);
    }

    // Check if coupon amount exceeds payment amount
    if ($coupon_amount > $customer_payment->amount) {
        return response()->json([
            'status'  => 'error',
            'message' => 'Coupon amount cannot exceed payment amount',
        ], 400);
    }

    // Fetch branch to get GST percentage
    $branch = BranchModel::where('sno', $customer_payment->branch_id)->first();
    $gst_percentage = $branch->gst_percentage ?? 0;

    // Calculate amounts
    

    $gst_amount_original = ($customer_payment->amount * $gst_percentage) / 100;
    $original_amount = round($customer_payment->amount + $gst_amount_original);
    
    $payable_amount = round($original_amount - $coupon_amount);
    
    return response()->json([
        'status'  => 'success',
        'message' => 'Coupon applied successfully',
        'data'    => [
            'customer_id'    => $customer_id,
            'payment_id'     => $payment_id,
            'course_id'      => $course_id,
            'coupon_amount'  => $coupon_amount,
            'coupon_ids'     => $coupon_ids,
            'original_amount'=> $original_amount,
            'payable_amount' => $payable_amount,
        ],
    ], 200);
}


  
  public function coursePaymentCombo(Request $request)
  {
    // Retrieve the customer ID from the request
    $customerIdParam = $request->customer_id;
    // return  $customerIdParam;

    // Fetch training details for the customer
    $customer_training = TrainingModel::select('za_training.*', 'za_course.course_name')
      ->where('za_training.customer_id', $customerIdParam)
      ->join('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->where('za_training.status', 0)
      ->get();
    // return  $customer_training;

    $formattedPaymentHistory = [];

    // Iterate through each training record
    foreach ($customer_training as $ct_list) {
      // Fetch payment details for the current training record
      $payments_details = PaymentModel::select('*')
        ->where('payment_id', $ct_list->payment_id)
        ->where('status', 1)
        ->get();

      foreach ($payments_details as $p => $payment) {
        // Initialize the course entry in the formatted payment history if not already present
        if (!isset($formattedPaymentHistory[$payment->course_id])) {
          $formattedPaymentHistory[$payment->course_id] = [
            'course_name' => $ct_list->course_name,
            'course_id' => $ct_list->course_id,
            'total_amount' => $ct_list->overall_fees,
            'customer_id' => $ct_list->customer_id,
            'paidAmount' => $ct_list->paid_amount,
            'balanceFee' => $ct_list->balance_amount,
            'payment_history' => []
          ];
        }

        // Append the current payment details to the payment history
        $formattedPaymentHistory[$payment->course_id]['payment_history'][] = [
          'payment_date' => $payment->initialPayDate,
          'payment_historycustomer_id' => $payment->customer_id,
          'amount' => $payment->paidAmount,
          'paymentmode_name' => $payment->payment_mode_label ?? 'Cash',
          'payment_id' => $payment->payment_id
        ];
      }
    }

    // Return the formatted payment history
    // return $formattedPaymentHistory;

    $formattedPaymentHistory = array_values($formattedPaymentHistory);
    
     $customer_course_details = CustomerModel::select(
      'za_customer.sno',
      'za_training.customer_id',
      'za_training.course_id',
      'za_training.batch_id',
      'za_training.status',
      'za_course.sno as course_sno',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_slot.slot_type_id as slot_type',
      'za_course.course_version',
      'za_course.course_name',
      'za_course.course_code',
      'za_course.course_id',
      'za_course.attachment',
      'za_course.thumbnail',
      'za_course.course_duration',
      'za_course.course_partical_hours',
      'za_course.course_theory_hours',
      'za_course_type.course_type_name',
      'za_course_category.course_category_name',
      'za_course_subcategory.course_subcategory_name',
      DB::raw("IFNULL(za_student_course_feedback.rating, '') as rating"),
      DB::raw("IFNULL(za_student_course_feedback.description, '') as feedback_description")
    )
      ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->leftJoin('za_student_course_feedback', function ($join) {
            $join->on('za_training.customer_id', '=', 'za_student_course_feedback.customer_id')
                 ->on('za_training.course_id', '=', 'za_student_course_feedback.course_id');
        })
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
      ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
      ->where('za_customer.sno', $customerIdParam)
      ->where('za_course.status', 0)
    //   ->whereIn('za_training.course_id', $courseIds)
      ->get();
    // return $customer;
    $attachmentBaseUrl = 'https://erp.elysium.academy/course_attachments/';
    $thumbnailBaseUrl = 'https://erp.elysium.academy/course_thumbnail_image/';
    // Add base URLs to the attachments and thumbnails only if they are not empty
    $customer_course_details->transform(function ($customer) use ($attachmentBaseUrl, $thumbnailBaseUrl) {
      // Append base URL if the attachment is not null or empty
      if (!empty($customer->attachment)) {
        $customer->attachment = $attachmentBaseUrl . $customer->attachment;
      } else {
        $customer->attachment = null; // Don't send link if empty
      }

      // Append base URL if the thumbnail is not null or empty
      if (!empty($customer->thumbnail)) {
        $customer->thumbnail = $thumbnailBaseUrl . $customer->thumbnail;
      } else {
        $customer->thumbnail = null; // Don't send link if empty
      }

      return $customer;
    });

    $customer_course_details = $customer_course_details->map(function ($item){

        $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
        ->where('batch_id', $item->batch_id)
        ->where('attendance', 'P')
        ->get();
        $courseProgress = 0;

        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $item->course_sno)
                              ->count();
        if ($attendanceRecords->isNotEmpty()) {
          foreach ($attendanceRecords as $attendance) {
            $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $item->batch_id)
              ->whereDate('date', $attendance->att_date) // Check the attendance date
              ->get();
            if ($syllabusUpdates->isNotEmpty()) {
              foreach ($syllabusUpdates as $syllabusUpdate) {
                    if ($syllabusUpdate->percentage == 100) {
                        $topicCount++;
                    }
              }
            }
          }
          if ($course_topic_count > 0) {
              $courseProgress = ($topicCount / $course_topic_count) * 100;
          }
          if ($courseProgress > 100) {
              $courseProgress = 100;
          }
        }
        $courseProgress = number_format($courseProgress, 2);
        $item->course_complete_percentage = $courseProgress;

        $attendanceDate = AttendanceModel::select('att_date')->where('customer_id', $item->sno)
        ->where('batch_id', $item->batch_id)
        ->where('attendance', 'P')
        ->orderBy('created_at', 'desc') // Adjust 'created_at' to the appropriate column for ordering
        ->first();
        $course_completedDays=0;
        if($attendanceDate){
          $startDate = Carbon::parse($item->start_date);
          $lastAttendanceDate = Carbon::parse($attendanceDate->att_date);
            if ($startDate->lte($lastAttendanceDate)) {
              // Check the slot_type and apply the appropriate logic
              switch ($item->slot_type) {
                  case 1: // Monday to Friday
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isWeekday()) { // Weekday (Monday to Friday)
                              $course_completedDays++;
                          }
                      }
                      break;

                  case 2: // Saturday only
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isSaturday()) { // Saturday
                              $course_completedDays++;
                          }
                      }
                      break;

                  case 3: // Sunday only
                      for ($date = $startDate; $date->lte($lastAttendanceDate); $date->addDay()) {
                          if ($date->isSunday()) { // Sunday
                              $course_completedDays++;
                          }
                      }
                      break;

                  default:
                      // Handle other slot types if needed
                      break;
              }
            }
        }
        $item->course_completedDays = $course_completedDays;
        return $item;
    });

    // return $payments_details;

    // return $formattedPaymentHistory;

    if ($formattedPaymentHistory || $formattedPaymentHistory) {
      return response()->json([
        'status' => 200,
        'message' => 'Successfully Retrieved Data',
        'error_msg' => null,
        'data' => [
            'course_details' => $customer_course_details,
            'payment_details' => array_values($formattedPaymentHistory),
        ]
      ], 200);
    } else {
      return response()->json([
        'status' => 200,
        'message' => 'Data not found',
        'error_msg' => null,
        'data' => []
      ], 200);
    }
  }
  

//     public function feedbackAlert(Request $request)
//     {
//     $customer_id = $request->input('customer_id');
//     $today = Carbon::now()->format('Y-m-d');
//     $currentTime = Carbon::now('Asia/Kolkata')->format('H:i:s'); // for IS

//     // Fetch all today's batches for the customer
//     $batches = BatchModel::select(
//         'za_batch.sno as batch_sno',
//         'za_batch.batch_id as auto_increment_id',
//         'za_batch.batch_name',
//         'za_batch.course_id',
//         'za_slot.start_time',
//         'za_slot.end_time'
//     )
//     ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
//     ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
//     ->where('za_training.customer_id', $customer_id)
//     ->whereDate('za_batch.start_date', '<=', $today)
//     ->whereDate('za_batch.end_date', '>=', $today)
//     ->whereNotIn('za_batch.status', [2,3])
//     ->get();
   
//     if ($batches->isEmpty()) {
//         return response()->json([
//             'status' => 404,
//             'message' => 'No batch scheduled for today',
//             'alerts' => []
//         ]);
//     }

//     $alerts = [];
//     //   return $currentTime;
//     foreach ($batches as $batch) {
//         // Check if class finished
//         if ($currentTime < $batch->end_time) {
//             $alerts[] = [
//                 'batch_sno' => $batch->batch_sno,
//                 'sno' => null,
//                 'batch_name' => $batch->batch_name,
//                 'status' => 'Class in progress',
//                 'alert' => 0
//             ];
//             continue; // skip to next batch
//         }

//         // Get today's attendance
//         $attendance = AttendanceModel::where('customer_id', $customer_id)
//             ->where('batch_id', $batch->batch_sno)
//             ->whereDate('att_date', $today)
//             ->first();

//         if (!$attendance || $attendance->attendance !== 'P') {
//             $alerts[] = [
//                 'batch_sno' => $batch->batch_sno,
//                 'sno' => null,
//                 'batch_name' => $batch->batch_name,
//                 'status' => 'Attendance not marked Present',
//                 'alert' => 0
//             ];
//             continue;
//         }

//         // Get today's feedback
       
//             $feedback = AttendanceModel::where('customer_id', $customer_id)
//             ->where('batch_id', $batch->batch_sno)
//             ->whereDate('att_date', $today)->first();
//         // return $feedback;

//         if ($feedback && $feedback->feedback_score > 0 && !empty($feedback->feedback)) {
//             $alerts[] = [
//                 'batch_sno' => $batch->batch_sno,
//                  'sno' => $feedback ? $feedback->sno : null,
//                 'batch_name' => $batch->batch_name,
//                 'status' => 'Feedback available',
//                 'alert' => 0
//             ];
//         } else {
//             $alerts[] = [
//                 'batch_sno' => $batch->batch_sno,
//                  'sno' => $feedback ? $feedback->sno : null,
//                 'batch_name' => $batch->batch_name,
//                 'status' => 'No feedback yet',
//                 'alert' => 1
//             ];
//         }
//     }

//     return response()->json([
//         'status' => 200,
//         'message' => 'Daily feedback alerts retrieved',
//         'alerts' => $alerts
//     ]);
// }

public function feedbackAlert(Request $request)
  {
    $customer_id = $request->input('customer_id');
    $today = Carbon::now()->format('Y-m-d');
    $currentTime = Carbon::now('Asia/Kolkata')->format('H:i:s'); // for IS
    $todayDay = Carbon::now('Asia/Kolkata')->dayOfWeek; // 0–6
 
    // Fetch all today's batches for the customer
    $batches = BatchModel::select(
      'za_batch.sno as batch_sno',
      'za_batch.batch_id as auto_increment_id',
      'za_batch.batch_name',
      'za_batch.course_id',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days'
    )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
      ->where('za_training.customer_id', $customer_id)
      ->whereDate('za_batch.start_date', '<=', $today)
      ->whereDate('za_batch.end_date', '>=', $today)
      ->whereNotIn('za_batch.status', [2, 3])
      ->get();
 
    if ($batches->isEmpty()) {
      return response()->json([
        'status' => 404,
        'message' => 'No batch scheduled for today',
        'alerts' => []
      ]);
    }
 
    $alerts = [];
    //   return $currentTime;
    foreach ($batches as $batch) {
 
      $slotDays = json_decode($batch->slot_type_days, true) ?? [];
 
      // Convert to string because JSON contains strings
      $todayDayStr = (string) $todayDay;
 
      // ❌ If today is NOT a class day → skip alert
      if (!in_array($todayDayStr, $slotDays)) {
        continue;
      }
 
      // Check if class finished
      if ($currentTime < $batch->end_time) {
        $alerts[] = [
          'batch_sno' => $batch->batch_sno,
          'sno' => null,
          'course_id' => null,
          'batch_name' => $batch->batch_name,
          'status' => 'Class in progress',
          'alert' => 0
        ];
        continue; // skip to next batch
      }
 
      // Get today's attendance
      $attendance = AttendanceModel::where('customer_id', $customer_id)
        ->where('batch_id', $batch->batch_sno)
        ->whereDate('att_date', $today)
        ->first();
 
      if (!$attendance || $attendance->attendance !== 'P') {
        $alerts[] = [
          'batch_sno' => $batch->batch_sno,
          'sno' => null,
          'course_id' => null,
          'batch_name' => $batch->batch_name,
          'status' => 'Attendance not marked Present',
          'alert' => 0
        ];
        continue;
      }
 
      // Get today's feedback
 
      $feedback = AttendanceModel::where('customer_id', $customer_id)
        ->where('batch_id', $batch->batch_sno)
        ->whereDate('att_date', $today)->first();
      // return $feedback;
 
      if ($feedback && $feedback->feedback_score > 0 && !empty($feedback->feedback)) {
        $alerts[] = [
          'batch_sno' => $batch->batch_sno,
          'sno' => $feedback ? $feedback->sno : null,
          'course_id' => null,
          'batch_name' => $batch->batch_name,
          'status' => 'Feedback available',
          'alert' => 0
        ];
      } else {
        $alerts[] = [
          'batch_sno' => $batch->batch_sno,
          'sno' => $feedback ? $feedback->sno : null,
          'course_id' => $batch->course_id,
          'batch_name' => $batch->batch_name,
          'status' => 'No feedback yet',
          'alert' => 1
        ];
      }
    }
 
    return response()->json([
      'status' => 200,
      'message' => 'Daily feedback alerts retrieved',
      'alerts' => $alerts
    ]);
  }
  
    public function IssueNoteAdd(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|max:255',
            'issue' => 'required|string',
            'closed' => 'nullable', // 1 or 0
            'issue_id' => 'nullable|string', // optional for replies
            'sender_type' => 'nullable|in:customer,admin',
            'attachment' => 'nullable|string' // base64
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors()
            ], 422);
        }
    
        $customer_id = $request->customer_id;
        $issue = $request->issue;
        $closed = $request->closed;
        $sender_type = $request->sender_type ?? 'customer';
        $issue_id = $request->issue_id; // existing thread or null
    
        $customer = DB::table('za_customer')->where('sno', $customer_id)->first();
        if (!$customer) {
            return response()->json([
                'status' => 404,
                'message' => 'Customer not found'
            ]);
        }
    
        $branch_id = $customer->branch_id;
        $user_id = $customer_id;
    
        // Handle attachment
        $attachment = null;
        if ($request->attachment) {
            $base64 = explode(',', $request->attachment)[1] ?? $request->attachment;
            $decoded = base64_decode($base64);
            if ($decoded) {
                $imageName = 'issue_' . time() . '_' . rand(1000, 9999) . '.png';
                $dir = public_path('issue_attachment');
                if (!file_exists($dir)) mkdir($dir, 0777, true);
                file_put_contents($dir . '/' . $imageName, $decoded);
                $attachment = $imageName;
            }
        }
    
        // Generate new issue_id if not provided
        if (!$issue_id) {
            $last_issue = IssueNoteModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            if (!$last_issue) {
                $year = substr(date('y'), -2);
                $issue_id = 'ISN-0001/' . $year;
            } else {
                $data = $last_issue->issue_id;
                $slice = explode('/', $data);
                $num = preg_replace('/[^0-9]/', '', $slice[0]);
                $next = (int)$num + 1;
                $issue_id = sprintf('ISN-%04d/%s', $next, substr(date('y'), -2));
            }
        }
    
        // Save the message
        $add = new IssueNoteModel();
        $add->issue_id = $issue_id;
        $add->customer_id = $customer_id;
        $add->category = "customer";
        $add->resolved_type = $closed;
        $add->issue = $issue;
        $add->attachment = $attachment;
        $add->branch_id = $branch_id;
        $add->created_at = Carbon::now('Asia/Kolkata');
        $add->created_by = $user_id;
        $add->updated_by = $user_id;
        $add->save();
    
        // Get full conversation for this issue
        $conversation = IssueNoteModel::where('issue_id', $issue_id)
            ->orderBy('created_at', 'asc')
            ->get();
    
        return response()->json([
            'status' => 200,
            'message' => 'Message saved successfully',
            'issue_id' => $issue_id,
            // 'conversation' => $conversation
        ]);
    }
     public function IssueClosed(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|integer',
            'closed' => 'nullable|in:0,1', // only allow 0 or 1
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Incorrect format input fields',
                'errors' => $validator->errors()
            ], 422);
        }
    
        $customer_id = $request->customer_id;
        $closed = $request->closed ?? 1; // default to 1 (closed)
    
        // ✅ Check if customer exists
        $customer = DB::table('za_customer')->where('sno', $customer_id)->first();
        if (!$customer) {
            return response()->json([
                'status' => 404,
                'message' => 'Customer not found'
            ]);
        }
    
        $branch_id = $customer->branch_id;
    
        // ✅ Get latest issue record for this customer
        $record = IssueNoteModel::where('customer_id', $customer_id)
            ->where('category', 'customer')
            ->where('branch_id', $branch_id)
            ->latest('created_at')
            ->first();
        $recordStaff = IssueNoteModel::where('customer_id', $customer_id)
            ->where('category', 'admin')
            ->where('branch_id', $branch_id)
            ->latest('created_at')
            ->first();
    
        if (!$record) {
            return response()->json([
                'status' => 404,
                'message' => 'No issue found for this customer'
            ]);
        }
    
        // ✅ Update status to "closed" (2)
        $record->update(['status' => 2, 'closed_date' => now()]);
        $recordStaff->update(['status' => 2, 'closed_date' => now()]);
    
        return response()->json([
            'status' => 200,
            'message' => 'Issue closed successfully',
            'data' => [
                'issue_id' => $record->issue_id,
                'status' => 2,
                'closed_date' => $record->closed_date
            ]
        ]);
    }
    
    public function IssueNoteConversation(Request $request)
    {
        $customerId = $request->customer_id;
    
        $issues = IssueNoteModel::select(
            'za_issue_note.sno as issue_sno',
            'za_issue_note.issue_id',
            'za_issue_note.created_at',
            'za_issue_note.closed_date',
            'za_issue_note.issue as conversation', // student message
            'za_issue_note.description as reply',  // staff reply
            'za_issue_note.attachment',
            'za_issue_note.status',
             'za_issue_note.admin_seen',
            'za_staff.nick_name',
            'za_customer.cus_name',
            'za_customer.sno as cus_sno',
            'za_customer.branch_id as cus_branch_id'
        )
        ->leftJoin('za_staff', 'za_issue_note.created_by', '=', 'za_staff.sno')
        ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
        ->where('za_issue_note.customer_id', $customerId)
        ->orderBy('za_issue_note.created_at', 'asc')
        ->get();
    
        $baseUrl = 'https://erp.elysium.academy/issue_attachment/';
    
        $groupedConversations = [];
    
        foreach ($issues as $issue) {
            $issueId = $issue->cus_sno;
    
            // Initialize if not already
            if (!isset($groupedConversations[$issueId])) {
                $groupedConversations[$issueId] = [
                    'issue_id'   => $issueId,
                    'conversation_list' => [],
                ];
            }
    
            // Student message
            if (!empty($issue->conversation)) {
                $groupedConversations[$issueId]['conversation_list'][] = [
                    'sender'     => 'Student',
                    'name'       => $issue->cus_name,
                    'message'    => $issue->conversation,
                    'closed'    => $issue->status,
                    'seen'        => (int)$issue->admin_seen === 1,
                    'attachment' => $issue->attachment ? $baseUrl . $issue->attachment : null,
                    'timestamp'  => Carbon::parse($issue->created_at)
                                     ->format('d M Y, h:i A'),
                ];
            }
    
            // Staff reply
            if (!empty($issue->reply)) {
                $groupedConversations[$issueId]['conversation_list'][] = [
                    'sender'     => 'Staff',
                    'name'       => $issue->nick_name ?? '',
                    'message'    => $issue->reply,
                    'seen'        => false, 
                    'closed'    => $issue->status,
                    'attachment' => null, // Add later if staff uploads allowed
                    'timestamp'  => $issue->created_at
                        ? Carbon::parse($issue->created_at)->format('d M Y, h:i A')
                        : Carbon::parse($issue->created_at)->format('d M Y, h:i A'),
                ];
            }
        }
    
        // Reindex grouped data
        $groupedConversations = array_values($groupedConversations);
    
        if (empty($groupedConversations)) {
            return response()->json([
                'status'  => 200,
                'message' => 'No conversations found for this customer.',
                'data'    => [],
            ], 200);
        }
    
        return response()->json([
            'status'  => 200,
            'message' => 'Conversations retrieved successfully.',
            'data'    => $groupedConversations,
        ], 200);
    }
    public function markSeen(Request $request)
    {
        $customer_id = $request->customer_id;
    
        IssueNoteModel::where('customer_id', $customer_id)
            ->where('category', 'admin')
            ->where('admin_seen', 0) // only unseen ones
            ->update(['admin_seen' => 1]);
    
        return response()->json(['status' => 200, 'message' => 'Marked as seen']);
    }
    
    public function PlacementListInterview(Request $request)
    {
    $customer_id = $request->customer_id;

    $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
    if (!$customer_data) {
        return response()->json([
            'status'    => 2,
            'message'   => 'Customer not found',
            'error_msg' => 'Invalid customer ID',
            'data'      => [],
        ], 404);
    }

    $today = now()->format('Y-m-d');

    $job_details = JobModel::select(
            'za_jobs.sno',
            'za_jobs.branch_id',
            'za_jobs.interview_date',
            'za_job_category.job_category_name',
            'za_job_subcategory.job_subcategory_name as job_role_name',
            'za_interview_type.interview_type_name',
            'za_placement_company.company_name',
            'za_placement_company.company_address'
        )
        ->join('za_placement_company', 'za_placement_company.sno', '=', 'za_jobs.company_id')
        ->leftJoin('za_job_category', 'za_job_category.sno', '=', 'za_jobs.job_category_id')
        ->leftJoin('za_job_subcategory', 'za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')
        ->leftJoin('za_interview_type', 'za_interview_type.sno', '=', 'za_jobs.interview_mode_id')
        ->whereNotIn('za_jobs.status', [2])
        ->whereRaw('JSON_CONTAINS(za_jobs.interest_student_ids, ?)', [json_encode((string)$customer_id)])
        ->where('za_jobs.branch_id', $customer_data->branch_id)
        ->whereDate('za_jobs.interview_date', '>=', $today) // ✅ exclude past interviews
        ->orderBy('za_jobs.interview_date', 'asc')          // ✅ upcoming first
        ->get();

    // Transform data for display
    $job_details->transform(function ($job) use ($today) {
        $interview_date = $job->interview_date ? \Carbon\Carbon::parse($job->interview_date) : null;
        $today_date = \Carbon\Carbon::parse($today);

        if ($interview_date) {
            $days_remaining = $today_date->diffInDays($interview_date, false);

            if ($days_remaining > 0) {
                $job->interview_status = 'Upcoming';
                $job->days_remaining = $days_remaining . ' days remaining';
            } elseif ($days_remaining === 0) {
                $job->interview_status = 'On Day';
                $job->days_remaining = ''; // as you said, empty
            } else {
                // Shouldn’t appear because we already filtered past ones
                $job->interview_status = 'Past';
                $job->days_remaining = '';
            }
        } else {
            $job->interview_status = 'No Date';
            $job->days_remaining = '';
        }

        return $job;
    });

    return response()->json([
        'status'    => 200,
        'message'   => 'Successfully Retrieved Data',
        'error_msg' => null,
        'data'      => $job_details,
    ], 200);
}

public function overallFeedback(Request $request)
  {
    $customer_id = $request->customer_id;
    $rating = $request->rating;
    $desc = $request->desc;
 
    // Validate input
    if (empty($customer_id)) {
      return response()->json([
        'status'    => '2',
        'message'   => 'Customer ID is required',
        'error_msg' => 'Missing customer ID',
        'data'      => [],
      ], 400);
    }
 
    // Fetch customer
    $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
    if (!$customer_data) {
      return response()->json([
        'status'    => '2',
        'message'   => 'Customer not found',
        'error_msg' => 'Invalid customer ID',
        'data'      => [],
      ], 404);
    }
 
    // Prepare feedback data (single object, not array)
    $feedback_data = [
      'rating'     => $rating,
      'desc'       => $desc,
      'updated_at' => now()
    ];
 
    // Save directly as JSON object (not array)
    DB::table('za_customer')
      ->where('sno', $customer_id)
      ->update([
        'overall_feedback' => json_encode($feedback_data)
      ]);
 
    $newPointsFull = new StudentpointsModel();
    $newPointsFull->branch_id = $customer_data->branch_id;
    $newPointsFull->student_id = $customer_id;
    $newPointsFull->points_id = 25;
    $newPointsFull->points = 2;
    $newPointsFull->reason = 'Overall feedback submitted';
    $newPointsFull->save();
 
    // if($rating == 5){
    //  staff
 
    // }
 
    return response()->json([
      'status'  => '1',
      'message' => 'Feedback updated successfully',
      'data'    => [
        'customer_id'      => $customer_id,
        'overall_feedback' => $feedback_data,
        'points' => 2
      ]
    ]);
  }
  
  public function overallFeedbackget(Request $request)
  {
    $customer_id = $request->customer_id;
 
    // Validate input
    if (empty($customer_id)) {
      return response()->json([
        'status'    => '2',
        'message'   => 'Customer ID is required',
        'error_msg' => 'Missing customer ID',
        'data'      => [],
      ], 400);
    }
 
    // Fetch customer
    $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
    if (!$customer_data) {
      return response()->json([
        'status'    => '2',
        'message'   => 'Customer not found',
        'error_msg' => 'Invalid customer ID',
        'data'      => [],
      ], 404);
    }
 
    // Decode feedback data
    $feedback = json_decode($customer_data->overall_feedback, true) ?? [];
 
    return response()->json([
      'status'  => '1',
      'message' => 'Feedback retrieved successfully',
      'data'    => [
        'customer_id'      => $customer_id,
        'overall_feedback' => $feedback
      ]
    ]);
  }
  
  
    // logout Fuction
    public function StudentLogout(Request $request)
    {
    try {
      $user = $request->user()->token()->revoke();
      if ($user) {
        $response = [
          'status' => 200,
          'message' => 'You have been successfully logged out!',
          'error_msg' => null,
          'data' => null
        ];
        return response($response, 200);
      } else {
        return response()->json([
          'status' => 500,
          'message' => 'User Not Found',
          'error_msg' => null,
          'data' => null
        ], 500);
      }
    } catch (\Throwable $th) {
      return response()->json(['status' => 500, 'message' => 'Exception Error', 'error_msg' => $th->getMessage(), 'data' => null], 500);
    }
  }
  
  
   public function appUpdateCheck(Request $request)
  {
    return response()->json([
      'status' => 200,
      'message' => 'Data Retrieved Successfully',
      'data' => [
        'app_name'       => 'Class Name',
        'play_store_id'  => 'com.eapl.classmate',
        'apple_id'       => 'id6756341379',
        'android'        => '1.0.11',
        'android_build'  => 24,
        'ios'            => '1.0.13',
        'ios_build'      => 27,
      ]
    ], 200);
  }
  
   public function category_list(Request $request)
    {
        $notifications = DB::table('za_feedback_category')
            ->where('status','=',0)
            ->orderBy('sno', 'desc')
            ->select('sno','feedback_category','description')
            ->get();
 
        return response()->json([
            'status' => 200,
            'data' => $notifications
        ]);
    }
 
    public function feedback_request(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required',
            'category_id' => 'required',
            'priority'    => 'required',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->errors()
            ]);
        }
 
        $customer_id = $request->customer_id;
        $category_id = $request->category_id;
        $priority    = $request->priority;
        $description = $request->description;
 
        //  Generate Issue ID
        $last_issue = IssueNoteModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$last_issue) {
            $issue_id = 'ISN-0001/' . date('y');
        } else {
            $data  = $last_issue->issue_id;
            $slice = explode('/', $data);
            $num   = preg_replace('/[^0-9]/', '', $slice[0]);
            $next  = (int)$num + 1;
            $issue_id = sprintf('ISN-%04d/%s', $next, date('y'));
        }
 
        //  Get Customer
        $customer_data = DB::table('za_customer')->where('sno', $customer_id)->first();
        if (!$customer_data) {
            return response()->json([
                'status' => 2,
                'message' => 'Customer not found',
                'error_msg' => 'Invalid customer ID',
                'data' => [],
            ], 404);
        }
 
        $sno = $customer_data->sno;
        $branch_id = $customer_data->branch_id;
 
        //  FIXED ATTACHMENT LOGIC
        $attachments = [];
 
        if ($request->hasFile('attachments')) {
 
            $files = $request->file('attachments');
 
            // Handle single file (mobile sometimes sends single file not array)
            if (!is_array($files)) {
                $files = [$files];
            }
 
            $folderPath = public_path('feedback_attachments/' . $sno);
 
            // Create folder if not exists
            if (!file_exists($folderPath)) {
                mkdir($folderPath, 0777, true);
            }
 
            foreach ($files as $file) {
                if ($file->isValid()) {
 
                    $filename = 'feedback_' . time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
 
                    $file->move($folderPath, $filename);
 
                    $attachments[] = 'feedback_attachments/' . $sno . '/' . $filename;
                }
            }
        }
 
        // Convert array to string (store multiple files)
        $attachmentString = !empty($attachments) ? implode(',', $attachments) : "";
 
        //  Save Data
        $add = new IssueNoteModel();
        $add->issue_id = $issue_id;
        $add->category_id = $category_id;
        $add->is_feedback = 1;
        $add->customer_id = $customer_id;
        $add->category = "customer";
        $add->feedback_attachment = $attachmentString;
        $add->priority_level = $priority;
        $add->issue = $description;
        $add->branch_id = $branch_id;
        $add->created_at = Carbon::now('Asia/Kolkata');
        $add->created_by = $sno;
        $add->updated_by = $sno;
        $add->save();
 
        return response()->json([
            'status' => 200,
            'message' => 'Request Send successfully',
            'issue_id' => $issue_id,
        ]);
    }
 
    public function feedback_allList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'cus_id' => 'required',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->errors()
            ]);
        }
 
        $cus_id = $request->cus_id;
        $status = $request->Status;
 
        // return $status;
 
        if(empty($status)){
           $notifications = DB::table('za_issue_note')
            ->join('za_feedback_category','za_issue_note.category_id','=','za_feedback_category.sno')
            ->where('za_issue_note.is_feedback','=',1)
            ->where('za_issue_note.customer_id','=', $cus_id)
            ->orderBy('za_issue_note.sno', 'desc')
            ->select('za_issue_note.sno','za_issue_note.issue_id','za_feedback_category.feedback_category','za_issue_note.issue','za_issue_note.status')
            ->get();
 
        }
        else{
            $notifications = DB::table('za_issue_note')
            ->join('za_feedback_category','za_issue_note.category_id','=','za_feedback_category.sno')
            ->where('za_issue_note.is_feedback','=',1)
            ->where('za_issue_note.customer_id','=', $cus_id)
            ->where('za_issue_note.status','=', $status)
            ->orderBy('za_issue_note.sno', 'desc')
            ->select('za_issue_note.sno','za_issue_note.issue_id','za_feedback_category.feedback_category','za_issue_note.issue','za_issue_note.status')
            ->get();
        }
       
 
        return response()->json([
            'status' => 200,
            'data' => $notifications
        ]);
    }
    
    public function issue_list(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'issue_id' => 'required',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->errors()
            ]);
        }
 
        $issue_id = $request->issue_id;
 
        $notifications = DB::table('za_issue_note')
            ->join('za_feedback_category','za_issue_note.category_id','=','za_feedback_category.sno')
            ->where('za_issue_note.is_feedback', 1)
            ->where('za_issue_note.sno', $issue_id)
            ->select(
                'za_issue_note.sno',
                'za_issue_note.issue_id',
                'za_issue_note.feedback_attachment',
                'za_issue_note.priority_level',
                'za_feedback_category.feedback_category',
                'za_issue_note.issue',
                'za_issue_note.status',
                'za_issue_note.issue_reply',
                'za_issue_note.created_at',
                'za_issue_note.updated_at'
            )
            ->first();
 
        if (!$notifications) {
            return response()->json([
                'status' => 404,
                'message' => 'Issue not found',
                'data' => []
            ], 404);
        }
 
        //  Convert to array
        $notifications = (array) $notifications;
 
        //  Handle attachment URLs
        $attachments = [];
 
        if (!empty($notifications['feedback_attachment'])) {
 
            $files = explode(',', $notifications['feedback_attachment']);
 
            foreach ($files as $file) {
 
                $file = trim($file);
 
                if ($file && file_exists(public_path($file))) {
                    $attachments[] = asset($file); // full URL
                }
            }
        }
 
        $notifications['feedback_attachment'] = $attachments;
 
        //  Convert null to ""
        foreach ($notifications as $key => $value) {
            if (is_null($value)) {
                $notifications[$key] = "";
            }
        }
 
        return response()->json([
            'status' => 200,
            'data' => $notifications
        ]);
    }
 
      public function issue_rating(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'issue_id' => 'required',
            'issue_rating' => 'required',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->errors()
            ]);
        }
 
        $issue_id = $request->issue_id;
        $issue_rating = $request->issue_rating;
 
        //  Check if record exists
        $exists = DB::table('za_issue_note')
            ->where('sno', $issue_id)
            ->where('is_feedback', 1)
            ->exists();
 
        if (!$exists) {
            return response()->json([
                'status' => 404,
                'message' => 'Issue not found'
            ], 404);
        }
 
        //  Update directly
        DB::table('za_issue_note')
            ->where('sno', $issue_id)
            ->update([
                'issue_rating' => $issue_rating,
                'status' => 2,
                'updated_at' => now()
            ]);
 
        return response()->json([
            'status' => 200,
            'message' => 'Feedback Updated successfully',
            'issue_id' => $issue_id,
        ]);
    }
    
    public function saveFcmToken(Request $request)
    {
        $request->validate([
            'customer_id'=>'required',
            'fcm_token'=>'required'
        ]);
 
        CustomerModel::where(
            'sno',
            $request->customer_id
        )->update([
            'fcm_token'=>$request->fcm_token
        ]);
 
        return response()->json([
            'status'=>true,
            'message'=>'Token saved successfully'
        ]);
    }
    
  
}