<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PlacedStudent extends Controller
{
    // public function index()
    // {
    //   return view('content.customer.placed_student.placed_student_list');
    // }

    //   public function index(Request $request)
    //   {
    //     // return $request;
    //       $branch_id = $request->user()->branch_id;
    //       $perpage   = (int) $request->input('sorting_filter', 10);
    //       $search_fill = $request->input('search_fill', '');
    //       $customers  = DB::table('za_customer')->where('branch_id',$branch_id)->get();
    //       $course_types  = DB::table('za_course_type')->get();
    //       $courses  = DB::table('za_course')->where('branch_id',$branch_id)->get();

    //         $staffs  = DB::table('za_staff')->where('branch_id',$branch_id)->get();

    //         $cus_id = $request->input('cus_id');
    //         $cus_name  = $request->input('cus_name');
    //         $course_type    = $request->input('course_type');
    //         $course_name   = $request->input('course_name');
    //         $staff_name = $request->input('staff_name');
    //         $filter_on = $request->input('filter_on', 0);


    //       $students = DB::table('za_placement_interview')
    //           ->select(
    //               'za_placement_interview.sno as interview_id',
    //               'za_placement_interview.selected_date',
    //               'za_jobs.interview_date',
    //               'za_placement_company.company_name',
    //               'za_placement_company.company_address',
    //               'za_job_category.job_category_name',
    //               'za_job_subcategory.job_subcategory_name as job_role_name',
    //               'za_placement_interview.status',
    //               'za_placement_interview.job_salary',
    //               'za_placement_interview.job_position',
    //               'za_customer.cus_name',
    //               'za_customer.placement_status',
    //               'za_customer.cus_gender',
    //               'za_customer.cus_mobile',
    //               'za_customer.cus_email_id',
    //               'za_customer.cus_pic',
    //               'za_customer.customer_id',
    //               'za_placement_interview.interview_checklist_status',
    //               'za_customer.sno as cus_id',
    //               'za_course_type.course_type_name',
    //               'za_customer.batch_id',
    //                 DB::raw("(
    //                 SELECT GROUP_CONCAT(p.course_name SEPARATOR ', ')
    //                 FROM za_course p
    //                 WHERE za_customer.course_id LIKE CONCAT('%\"', p.sno, '\"%')
    //             ) as course_name"),
    //                DB::raw("(
    //                 SELECT GROUP_CONCAT(p.batch_name SEPARATOR ', ')
    //                 FROM za_batch p
    //                 WHERE za_customer.batch_id LIKE CONCAT('%\"', p.sno, '\"%')
    //             ) as batch_name")
    //           )
            

    //           ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
    //           ->leftJoin('za_jobs', 'za_jobs.sno', '=', 'za_placement_interview.job_id')

    //           ->leftJoin('za_job_category', 'za_job_category.sno', '=', 'za_jobs.job_category_id')
    //           ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_customer.course_type_id')
    //           ->leftJoin('za_job_subcategory', 'za_job_subcategory.sno', '=', 'za_jobs.job_subcategory_id')

    //           ->leftJoin('za_placement_company', 'za_placement_company.sno', '=', 'za_jobs.company_id')

    //           ->where('za_placement_interview.status', 4)
    //           ->where('za_customer.branch_id', $branch_id)

    //           ->orderBy('za_jobs.interview_date', 'desc');

    //       // Search
    //       if ($search_fill != '') {
    //           $students->where(function ($query) use ($search_fill) {
    //               $query->where('za_customer.cus_name', 'LIKE', "%{$search_fill}%")
    //                   ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
    //                   ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$search_fill}%")
    //                   ->orWhere('za_customer.customer_id', 'LIKE', "%{$search_fill}%")
    //                   ->orWhere('za_placement_company.company_name', 'LIKE', "%{$search_fill}%");
    //           });
    //       }

    

    //         if (!empty($cus_name)) {
    //                 $students->where('za_customer.sno', $cus_name);
    //             }

    //         if (!empty($cus_id)) {
    //             $students->where('za_customer.customer_id', $cus_id);
    //         }

    //         if (!empty($course_type)) {
    //             $students->where('za_course_type.course_type_name', $course_type);
    //         }
    //        if (!empty($course_name)) {

    //             $students->whereRaw("
    //                 EXISTS (
    //                     SELECT 1
    //                     FROM za_course c
    //                     WHERE za_customer.course_id LIKE CONCAT('%\"', c.sno, '\"%')
    //                     AND c.course_name = ?
    //                 )
    //             ", [$course_name]);
    //         }

    //         if (!empty($batch_name)) {

    //             $students->whereRaw("
    //                 EXISTS (
    //                     SELECT 1
    //                     FROM za_batch b
    //                     WHERE za_customer.batch_id LIKE CONCAT('%\"', b.sno, '\"%')
    //                     AND b.batch_name = ?
    //                 )
    //             ", [$batch_name]);
    //         }

    //         if (!empty($staff_name)) {

    //             $students->whereRaw("
    //                 EXISTS (
    //                     SELECT 1
    //                     FROM za_batch b
    //                     LEFT JOIN za_staff s
    //                     ON s.sno = b.staff_id

    //                     WHERE za_customer.batch_id LIKE CONCAT('%\"', b.sno, '\"%')
    //                     AND s.staff_name = ?
    //                 )
    //             ", [$staff_name]);
    //         }


    //       $students = $students->paginate($perpage);

        
    //       $finalStudents = collect();

    //       foreach ($students as $student) {

    //           $batchIds = json_decode($student->batch_id, true);

    //           if (!is_array($batchIds) || empty($batchIds)) {
    //               $batchIds = [];
    //           }

    //           // if no batch
    //           if (count($batchIds) == 0) {
    //               $student->batch_details = null;
    //               $finalStudents->push($student);
    //               continue;
    //           }

    //           foreach ($batchIds as $batchId) {

    //               $batch = DB::table('za_batch')
    //                   ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
    //                   ->leftJoin('za_batch_extension', 'za_batch_extension.batch_id', '=', 'za_batch.sno')

    //                   ->select(
    //                       'za_batch.sno',
    //                       'za_batch.batch_name',
    //                       'za_batch.start_date as batch_start_date',
    //                       DB::raw("
    //                           COALESCE(
    //                               za_batch_extension.change_date,
    //                               za_batch.end_date
    //                           ) as batch_end_date
    //                       "),
    //                       'za_staff.staff_name',
    //                       'za_staff.staff_image'
    //                   )

    //                   ->where('za_batch.sno', $batchId)
    //                   ->first();

    //               $newStudent = clone $student;

    //               $newStudent->batch_details = $batch;

    //               $finalStudents->push($newStudent);
    //           }
    //       }

    //       // Total Students
    //       $total_students = DB::table('za_customer')
    //           ->join('za_placement_interview', 'za_placement_interview.customer_id', '=', 'za_customer.sno')
    //           ->where('za_customer.branch_id', $branch_id)
    //           ->where('za_placement_interview.status', 4)
    //           ->count();

    //       // Placed Students
    //       $placed_students = DB::table('za_placement_interview')
    //           ->join('za_customer', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
    //           ->where('za_customer.branch_id', $branch_id)
    //           ->where('za_placement_interview.status', 4)
    //           ->distinct('za_customer.sno')
    //           ->count('za_customer.sno');

    //       // Extended Students
        
    //       $extended_students = DB::table('za_customer')
    //           ->join('za_batch_extension', function ($join) {

    //               $join->whereRaw("
    //                   JSON_CONTAINS(
    //                       za_customer.batch_id,
    //                       CONCAT('\"', za_batch_extension.batch_id, '\"')
    //                   )
    //               ");

    //           })
    //           ->join('za_placement_interview', 'za_customer.sno', '=', 'za_placement_interview.customer_id')
    //           ->where('za_customer.branch_id', $branch_id)
    //           ->where('za_placement_interview.status', 4)
    //           ->distinct('za_customer.sno')
    //           ->count('za_customer.sno');

    //       // return $students;

    //       return view('content.customer.placed_student.placed_student_list', [
    //           'students' => $finalStudents,
    //           'pagination' => $students,
    //           'search_fill' => $search_fill,
    //           'perpage' => $perpage,
            
    //               // dashboard
    //         'total_students'    => $total_students,
    //         'placed_students'   => $placed_students,
    //         'extended_students' => $extended_students,
    //         'customers'=>$customers,
    //         'course_types'=>$course_types,
    //         'courses'=>$courses,
    //         'staffs'=>$staffs,

    //         'course_name' => $course_name,
    //         'staff_name' => $staff_name,
    //         'course_type' => $course_type,
    //         'cus_name' => $cus_name, 
    //         'cus_id' => $cus_id,
    //         'filter_on' => $filter_on ? true : false,
    //       ]);
    //   }

    public function index(Request $request)
    {
        $branch_id   = $request->user()->branch_id;
        $perpage     = (int) $request->input('sorting_filter', 25);
        $search_fill = trim($request->input('search_fill', ''));

        // Filters
        $cus_id       = $request->input('cus_id');
        $cus_name     = $request->input('cus_name');
        $course_type  = $request->input('course_type');
        $course_name  = $request->input('course_name');
        $staff_name   = $request->input('staff_name');
        $batch_name   = $request->input('batch_name');
        $filter_on    = $request->input('filter_on', 0);

    

        $customers = DB::table('za_customer')
            ->select('sno', 'cus_name')
            ->where('branch_id', $branch_id)
            ->orderBy('cus_name')
            ->get();

        $course_type_list = DB::table('za_course_type')->select('sno', 'course_type_name')->where('status', 0)->orderBy('sno', 'desc')->get();
        $course_list = DB::table('za_course')->select('sno', 'course_name')->where('status', 0)->orderBy('sno', 'desc')->get();

        $staffs = DB::table('za_staff')
            ->select('sno', 'staff_name')
            ->where('branch_id', $branch_id)
            ->orderBy('staff_name')
            ->get();

        $batches = DB::table('za_batch')
            ->select('sno', 'batch_name')
            ->where('branch_id', $branch_id)
            ->orderBy('batch_name')
            ->get();

    
        $studentsQuery = DB::table('za_placement_interview as pi')

            ->select(
                'pi.sno as interview_id',
                'pi.selected_date',
                'pi.status',
                'pi.job_salary',
                'pi.job_position',
                'pi.interview_checklist_status',

                'jobs.interview_date',

                'company.company_name',
                'company.company_address',

                'jc.job_category_name',
                'js.job_subcategory_name as job_role_name',

                'customer.sno as cus_id',
                'customer.cus_name',
                'customer.customer_id',
                'customer.placement_status',
                'customer.cus_gender',
                'customer.cus_mobile',
                'customer.cus_email_id',
                'customer.cus_pic',
                'customer.batch_id',
                'customer.course_id',

                'ct.course_type_name'
            )

            ->leftJoin('za_customer as customer', 'customer.sno', '=', 'pi.customer_id')

            ->leftJoin('za_jobs as jobs', 'jobs.sno', '=', 'pi.job_id')

            ->leftJoin('za_job_category as jc', 'jc.sno', '=', 'jobs.job_category_id')

            ->leftJoin('za_job_subcategory as js', 'js.sno', '=', 'jobs.job_subcategory_id')

            ->leftJoin('za_course_type as ct', 'ct.sno', '=', 'customer.course_type_id')

            ->leftJoin('za_placement_company as company', 'company.sno', '=', 'jobs.company_id')

            ->where('pi.status', 4)

            ->where('customer.branch_id', $branch_id)

            ->orderByDesc('jobs.interview_date');


        if (!empty($search_fill)) {

            $studentsQuery->where(function ($query) use ($search_fill) {

                $query->where('customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('customer.cus_email_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('company.company_name', 'LIKE', "%{$search_fill}%");
            });
        }

    

        if (!empty($cus_name)) {
            $studentsQuery->where('customer.sno', $cus_name);
        }

        if (!empty($cus_id)) {
            $studentsQuery->where('customer.customer_id', $cus_id);
        }

        if (!empty($course_type)) {
            $studentsQuery->where('ct.course_type_name', $course_type);
        }

        // Course Filter
        if (!empty($course_name)) {

            $studentsQuery->whereRaw("
                EXISTS (
                    SELECT 1
                    FROM za_course c
                    WHERE customer.course_id LIKE CONCAT('%\"', c.sno, '\"%')
                    AND c.course_name = ?
                )
            ", [$course_name]);
        }

        // Batch Filter
        if (!empty($batch_name)) {

            $studentsQuery->whereRaw("
                EXISTS (
                    SELECT 1
                    FROM za_batch b
                    WHERE customer.batch_id LIKE CONCAT('%\"', b.sno, '\"%')
                    AND b.batch_name = ?
                )
            ", [$batch_name]);
        }

        // Staff Filter
        if (!empty($staff_name)) {

            $studentsQuery->whereRaw("
                EXISTS (
                    SELECT 1
                    FROM za_batch b
                    LEFT JOIN za_staff s
                        ON s.sno = b.staff_id

                    WHERE customer.batch_id LIKE CONCAT('%\"', b.sno, '\"%')
                    AND s.staff_name = ?
                )
            ", [$staff_name]);
        }

    

        $students = $studentsQuery->paginate($perpage);

    
        $allBatchIds = [];

        foreach ($students as $student) {

            $batchIds = json_decode($student->batch_id, true);

            if (is_array($batchIds)) {
                $allBatchIds = array_merge($allBatchIds, $batchIds);
            }
        }

        $allBatchIds = array_unique($allBatchIds);

    

        $batchesMap = DB::table('za_batch')

            ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')

            ->leftJoin(
                'za_batch_extension',
                'za_batch_extension.batch_id',
                '=',
                'za_batch.sno'
            )

            ->whereIn('za_batch.sno', $allBatchIds)

            ->select(
                'za_batch.sno',
                'za_batch.batch_name',

                'za_batch.start_date as batch_start_date',

                DB::raw("
                    COALESCE(
                        za_batch_extension.change_date,
                        za_batch.end_date
                    ) as batch_end_date
                "),

                'za_staff.staff_name',
                'za_staff.staff_image'
            )

            ->get()

            ->keyBy('sno');

    
        $finalStudents = collect();

        foreach ($students as $student) {

            $batchIds = json_decode($student->batch_id, true);

            if (!is_array($batchIds) || empty($batchIds)) {

                $student->batch_details = null;

                $finalStudents->push($student);

                continue;
            }

            foreach ($batchIds as $batchId) {

                $batch = $batchesMap[$batchId] ?? null;

                $newStudent = clone $student;

                $newStudent->batch_details = $batch;

                $finalStudents->push($newStudent);
            }
        }

    

        $total_students = DB::table('za_placement_interview as pi')

            ->join('za_customer as c', 'c.sno', '=', 'pi.customer_id')

            ->where('c.branch_id', $branch_id)

            ->where('pi.status', 4)

            ->distinct()

            ->count('c.sno');

        $placed_students =  DB::table('za_placement_interview as pi')
            ->join('za_customer as c', 'c.sno', '=', 'pi.customer_id')
            ->where('c.branch_id', $branch_id)
            ->where('pi.status', 4)
            ->where('pi.selected_date','!=', null)
            ->distinct()
            ->count('c.sno');

        $extended_students = DB::table('za_customer')

            ->join('za_batch_extension', function ($join) {

                $join->whereRaw("
                    JSON_CONTAINS(
                        za_customer.batch_id,
                        CONCAT('\"', za_batch_extension.batch_id, '\"')
                    )
                ");
            })

            ->join(
                'za_placement_interview',
                'za_customer.sno',
                '=',
                'za_placement_interview.customer_id'
            )

            ->where('za_customer.branch_id', $branch_id)

            ->where('za_placement_interview.status', 4)

            ->distinct()

            ->count('za_customer.sno');


        return view(
            'content.customer.placed_student.placed_student_list',
            [
                'students'           => $finalStudents,
                'pagination'         => $students,

                'search_fill'        => $search_fill,
                'perpage'            => $perpage,

                'total_students'     => $total_students,
                'placed_students'    => $placed_students,
                'extended_students'  => $extended_students,

                'customers'          => $customers,
                'course_type_list'       => $course_type_list,
                'course_list'            => $course_list,
                'staffs'             => $staffs,
                'batches'            => $batches,

                'course_name'        => $course_name,
                'staff_name'         => $staff_name,
                'course_type'        => $course_type,
                'cus_name'           => $cus_name,
                'cus_id'             => $cus_id,
                'batch_name'         => $batch_name,

                'filter_on'          => $filter_on ? true : false,
            ]
        );
    }
  
}
