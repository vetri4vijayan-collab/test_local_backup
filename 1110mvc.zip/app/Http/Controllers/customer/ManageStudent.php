<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ReviewModel;
use App\Models\CustomerModel;
use App\Models\AttendanceModel;
use App\Models\ReviewLinkModel;
use App\Models\BatchModel;
use App\Models\SlotModel;
use App\Models\User;
use Carbon\Carbon;
class ManageStudent extends Controller
{
  public function index(Request $request)
  {
    $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
    [$year, $month] = explode('-', $selectedMonth);
      // Generate all dates for the selected month
    $startDate = Carbon::createFromDate($year, $month, 1);
    $endDate = $startDate->copy()->endOfMonth();
    $dates = [];
    
    while ($startDate->lte($endDate)) {
        $dates[] = $startDate->copy()->toDateString();
        $startDate->addDay();
    }
    
    return view('content.customer.manage_student.student_list',compact('dates'));
  }
// public function studentList(Request $request)
// {
//     $branch_id = $request->user()->branch_id;
//     $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
//     [$year, $month] = explode('-', $selectedMonth);
//      $searchQuery = $request->input('search', '');
//     // Get all dates of the selected month
//     $startOfMonth = \Carbon\Carbon::create($year, $month, 1);
//     $endOfMonth = $startOfMonth->copy()->endOfMonth();
//     $dates = [];

//     while ($startOfMonth <= $endOfMonth) {
//         $dates[] = $startOfMonth->toDateString();
//         $startOfMonth->addDay();
//     }

//     // Get all customers in the branch
//     $customer_list = CustomerModel::where('branch_id', $branch_id)
//     ->where('status', 0);
    
//     if (!empty($searchQuery)) {
//         $customer_list->where('cus_name', 'like', "%$searchQuery%");
//     }
    
//     $customer_list = $customer_list->get();

//     // Get attendance grouped by customer_id
//     $managestudentlist = AttendanceModel::whereIn('customer_id', $customer_list->pluck('sno'))
//         ->whereYear('att_date', $year)
//         ->whereMonth('att_date', $month)
//         ->get()
//         ->groupBy('customer_id');

//     $studentAttendanceData = [];

//     foreach ($customer_list as $customer) {
//         if (!isset($managestudentlist[$customer->sno])) {
//             continue; // Skip customers with no attendance
//         }

//         // Fetch unique batch IDs for the student in the given month
//         $batchIds = AttendanceModel::where('customer_id', $customer->sno)
//             ->whereYear('att_date', $year)
//             ->whereMonth('att_date', $month)
//             ->pluck('batch_id')
//             ->unique();

//         foreach ($batchIds as $batchId) {
//             $batch = BatchModel::find($batchId);
//             if (!$batch) continue;

//             $attendanceData = [];
//             foreach ($dates as $date) {
//                 $attendanceData[$date] = optional($managestudentlist[$customer->sno]
//                     ->where('batch_id', $batchId)
//                     ->where('att_date', $date)
//                     ->first())->attendance ?? '-';
//             }

//             // Count attendance types
//             $total_P = array_count_values($attendanceData)['P'] ?? 0;
//             $total_L = array_count_values($attendanceData)['L'] ?? 0;
//             $total_A = array_count_values($attendanceData)['A'] ?? 0;
//             $total_H = array_count_values($attendanceData)['H'] ?? 0;

//             if ($total_P == 0 && $total_L == 0 && $total_A == 0 && $total_H == 0) {
//                 continue;
//             }

//             $studentAttendanceData[] = [
//                 'name' => $customer->cus_name,
//                 'gender' => $customer->cus_gender,
//                 'cus_pic' => $customer->cus_pic,
//                 'cus_mobile' => $customer->cus_mobile,
//                 'batch_id' => $batch->batch_id, 
//                 'batch_name' => $batch->batch_name, 
//                 'attendance' => $attendanceData,
//                 'total_P' => $total_P,
//                 'total_L' => $total_L,
//                 'total_A' => $total_A,
//                 'total_H' => $total_H,
//             ];
//         }
//     }

//     return response()->json([
//         'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
//         'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
//         'dates' => $dates,
//         'managestudentlist' => $studentAttendanceData
//     ]);
// }

public function studentList(Request $request)
{
    $branch_id = $request->user()->branch_id;
    $selectedMonth = $request->input('month', \Carbon\Carbon::now()->format('Y-m'));
    [$year, $month] = explode('-', $selectedMonth);
    $searchQuery = $request->input('search', '');
    $perPage = $request->input('per_page', 25); // Default to 25 per page

    // Get all dates of the selected month
    $startOfMonth = \Carbon\Carbon::create($year, $month, 1);
    $endOfMonth = $startOfMonth->copy()->endOfMonth();
    $dates = [];

    while ($startOfMonth <= $endOfMonth) {
        $dates[] = $startOfMonth->toDateString();
        $startOfMonth->addDay();
    }

    // Step 1: Get customer IDs with attendance in selected month
    $attendanceCustomerIds = AttendanceModel::whereYear('att_date', $year)
        ->whereMonth('att_date', $month)
        ->pluck('customer_id')
        ->unique();
    
    // Step 2: Fetch only customers who have attendance in this month
    $customer_list = CustomerModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->whereIn('sno', $attendanceCustomerIds);
    
    if (!empty($searchQuery)) {
        $customer_list->where('cus_name', 'like', "%$searchQuery%");
    }
    
    // Step 3: Apply pagination
    $customer_list = $customer_list->paginate($perPage);

    // Get attendance grouped by customer_id
    $managestudentlist = AttendanceModel::whereIn('za_attendance.customer_id', $customer_list->pluck('sno'))
        ->whereYear('za_attendance.att_date', $year)
        ->whereMonth('za_attendance.att_date', $month)
        ->get()
        ->groupBy('customer_id');

    $studentAttendanceData = [];

    foreach ($customer_list as $customer) {
            if (!isset($managestudentlist[$customer->sno])) {
                continue; // Skip customers with no attendance
            }
    
            $batchIds = AttendanceModel::where('customer_id', $customer->sno)
                ->whereYear('att_date', $year)
                ->whereMonth('att_date', $month)
                ->pluck('batch_id')
                ->unique();
    
       
        foreach ($batchIds as $batchId) {
        // Fetch batch details with course details
        $batch = BatchModel::where('za_batch.sno', $batchId)
            ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
            ->select('za_batch.*', 'za_course.course_name')
            ->first();
    
        if (!$batch) continue;
    
        // Get batch start and end dates
        $batchStartDate = \Carbon\Carbon::parse($batch->start_date);
        $batchEndDate = \Carbon\Carbon::parse($batch->end_date);
    
        // Get the slot type details
        $slot = SlotModel::find($batch->slot_id);
        if (!$slot) continue;
    
        // Convert slot_type_days JSON string into an array
        $slotDays = json_decode($slot->slot_type_days, true);
    
        // Calculate total working days within the batch period
        $totalWorkingDays = 0;
        $currentDate = $batchStartDate->copy();
    
        while ($currentDate->lte($batchEndDate)) {
            if (in_array($currentDate->dayOfWeek, $slotDays)) {
                $totalWorkingDays++;
            }
            $currentDate->addDay();
        }
    
        // Fetch attendance data
        $attendanceData = [];
        foreach ($dates as $date) {
            $attendanceData[$date] = optional(
                // $managestudentlist[$customer->sno]->where('batch_id', $batchId)->where('att_date', $date)->first()
                $managestudentlist[$customer->sno]->where('att_date', $date)->first()
            )->attendance ?? '-';
        }
    
        // Count attendance
        $total_P = array_count_values($attendanceData)['P'] ?? 0;
        $total_L = array_count_values($attendanceData)['L'] ?? 0;
        $total_A = array_count_values($attendanceData)['A'] ?? 0;
        $total_H = array_count_values($attendanceData)['H'] ?? 0;
    
        if ($total_P == 0 && $total_L == 0 && $total_A == 0 && $total_H == 0) {
            continue;
        }
    
        // **Calculate Attendance Percentage**
        $total_Attended = $total_P; // Considering 'P' as attended
        $attendancePercentage = ($totalWorkingDays > 0) ? round(($total_Attended / $totalWorkingDays) * 100) : 0;
    
        // Store Student Data
        $studentAttendanceData[] = [
            'name' => $customer->cus_name ?? 'Unknown',
            'course_name' => $batch->course_name ?? 'Unknown',
            'gender' => $customer->cus_gender ?? 'Unknown',
            'cus_pic' => $customer->cus_pic ?? '',
            'cus_mobile' => $customer->cus_mobile ?? 'Unknown',
            'batch_id' => $batch->sno,
            'batch_name' => $batch->batch_name ?? 'Unknown',
            'attendance' => $attendanceData,
            'total_P' => $total_P,
            'total_L' => $total_L,
            'total_A' => $total_A,
            'total_H' => $total_H,
            'total_working_days' => $totalWorkingDays,
            'attendance_percentage' => $attendancePercentage . '%',
        ];
    }


    }

    return response()->json([
        'selectedMonth' => \Carbon\Carbon::parse($selectedMonth)->format('F'),
        'selectedYear' => \Carbon\Carbon::parse($selectedMonth)->year,
        'dates' => $dates,
        'managestudentlist' => $studentAttendanceData,
        'pagination' => [
            'total' => $customer_list->total(),
            'per_page' => $customer_list->perPage(),
            'current_page' => $customer_list->currentPage(),
            'last_page' => $customer_list->lastPage(),
            'next_page_url' => $customer_list->nextPageUrl(),
            'prev_page_url' => $customer_list->previousPageUrl(),
        ]
    ]);
}







 
}