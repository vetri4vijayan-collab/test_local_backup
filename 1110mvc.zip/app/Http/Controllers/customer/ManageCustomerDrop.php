<?php

namespace App\Http\Controllers\customer;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\hr_management\Attendance;
use App\Http\Controllers\settings\course\CourseSubCategory;
use App\Http\Controllers\settings\course\CourseType;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CostingModel;
use App\Models\CourseSubCategoryModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerEducationModel;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use App\Models\GeneralSettingsModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\ReferralModel;
use App\Models\RefundChecklistModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\StaffModel;
use App\Models\SubLedgerModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingChangeModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;


class ManageCustomerDrop extends Controller
{

  public function Index(Request $request)
  {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        
        $customers = DropRefundModel::select(
          'za_drop_refund.*',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.doj',
          'za_customer.customer_id',
          'za_customer.sno AS cus_sno',
          'za_customer.cus_gender',
          'za_customer.cus_dob',
          'za_customer.cus_mobile',
          'za_customer.cus_alternate_mobile',
          'za_customer.cus_email_id',
          'za_batch.batch_name',
          'za_batch.start_date',
          'za_batch.end_date',
          'za_course_type.course_type_name',
          'za_course.course_name',
          'za_slot.slot_name',
          'za_staff.staff_name',
          'created_staff.staff_name AS created_staff_name',
          'bh_staff.staff_name AS bh_staff_name',
          'za_lead.registered_date',
          'lead_staff.staff_name AS sales_satff'
    
        )
      ->leftJoin('za_customer', 'za_drop_refund.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_course', 'za_drop_refund.course_id', '=', 'za_course.sno')
      ->leftJoin('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff AS lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
      ->leftJoin('za_staff AS created_staff', 'za_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('za_staff AS bh_staff', 'za_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->where('za_drop_refund.type', 0)
      ->where('za_drop_refund.status', 0)
      ->where('za_drop_refund.branch_id', $branch_id)
      ->orderBy('za_drop_refund.sno', 'desc')
      ->paginate($perpage);


    // return $customers;
    // $paidAmount = PaymentModel::where('customer_id', )->where('course_id', )->where('status', 1)->orderBy('sno', 'desc')->sum('paidAmount');
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    
    
     $customers_drop_count = DropRefundModel::where('type',0)->where('bh_status',0)->where('branch_id',$branch_id)->count();

    // return $get_course_change_days;
    return view('content.customer.customer_drop_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'customer_name_fill' => '',
      'customer_fill' => '',
      'course_type_list' => $course_type_list,
      'course_type_fill' => '',
      'course_list' => $course_list,
      'course_name_fill' => '',
      'date_filter' => '',
      'fin_yr_fill' => '',
    ])->with('filter_on', false);
  }

  public function list_filter(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $customer_fill = $request->customer_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';
    // return $request;
    $query = DropRefundModel::select(
      'za_drop_refund.*',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.sno AS cus_sno',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_staff.staff_name',
      'created_staff.staff_name AS created_staff_name',
      'bh_staff.staff_name AS bh_staff_name',

    )
      ->leftJoin('za_customer', 'za_drop_refund.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_course', 'za_drop_refund.course_id', '=', 'za_course.sno')
      ->leftJoin('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff AS created_staff', 'za_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('za_staff AS bh_staff', 'za_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->where('za_drop_refund.type', 0)
      ->where('za_drop_refund.status', 0)
      ->orderBy('za_drop_refund.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_drop_refund.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_drop_refund.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_drop_refund.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_drop_refund.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_drop_refund.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_drop_refund.created_at', '<=', $toDate);
      }
    }

    if ($branch_id > 0) {
      $query->where('za_drop_refund.branch_id', $branch_id);
    }

    if ($customer_fill) {
      $query->where(function ($customer) use ($customer_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$customer_fill}%");
      });
    }
    if ($customer_name_fill) {
      $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }


    // Fetch Branch list ordered by sno in descending order
    $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate(25);

    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();




    return view('content.customer.customer_drop_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'course_type_list' => $course_type_list,
      'course_list' => $course_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'customer_fill' => $customer_fill,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,

    ])->with('filter_on', true);
  }

  public function customer_drop_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();

    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'bh_status'        => $request->sts_change_type,
        'bh_reject_reason' => $request->bhreject_reason,
        'bh_status_date'   => now(),
        'bh_id'            => $user_id
      ]);

      if ($request->sts_change_type == 2) {
        $training_details = TrainingModel::where('sno', $drop_details->training_id)->first();
        $training_details->update([
          'status'           => 0,
          'drop_check'       => 0,
          'refund_amount'    => 0,
          'refund_date_drp'  => null,
          'drop_reason'      => null,
          'updated_by'       => $user_id
        ]);
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Customer Drop Rejected Successfully!'
        ]);
      } else {
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Customer Drop Accepted Successfully!'
        ]);
      }
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Drop Customer!'
      ]);
    }

    return redirect('/manage_customer_drop');
  }
}
