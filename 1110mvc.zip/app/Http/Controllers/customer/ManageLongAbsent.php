<?php

namespace App\Http\Controllers\customer;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\StaffModel;
use App\Models\HoldReasonModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Log;

class ManageLongAbsent extends Controller
{
    public function Index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);

        // Step 1: Get ALL fully paid customers
        $fullyPaidCustomerIds = $this->getFullyPaidCustomers($branch_id);
        
        // If no fully paid customers, return empty
        if (empty($fullyPaidCustomerIds)) {
            return $this->getEmptyView($perpage);
        }

        // Step 2: Get customers with active training
        $customersWithActiveTraining = $this->getCustomersWithActiveTraining($fullyPaidCustomerIds, $branch_id);
        
        // If no customers with active training, return empty
        if (empty($customersWithActiveTraining)) {
            return $this->getEmptyView($perpage);
        }

        // Step 3: Get customers with their details
        $customers = $this->getCustomersData($branch_id, $customersWithActiveTraining, $perpage, $page);

        // Step 4: Attach additional course data
        $this->attachCourseData($customers);

        // Step 5: Get training, attendance, payment data
        $customerIds = $customers->pluck('sno')->toArray();
        
        $trainingData = $this->getTrainingData($customerIds, $branch_id);
        $attendanceData = $this->getAttendanceData($customerIds);
        $paymentData = $this->getPaymentData($customerIds);
        $certificateData = $this->getCertificateData($customerIds);

        // Step 6: Process customers and check long absence
        $counters = [
            'active' => 0,
            'not_started' => 0,
            'inactive' => 0,
            'drop' => 0,
            'long_absent' => 0
        ];

        $customers->transform(function ($item) use (
            $trainingData, $attendanceData, $paymentData, $certificateData, &$counters
        ) {
            return $this->processCustomer(
                $item, $trainingData, $attendanceData, $paymentData, $certificateData, $counters
            );
        });

        // Step 7: Get dashboard data
        $dashboardData = $this->getDashboardData($branch_id);
        $appStats = $this->getAppStatistics($branch_id);
        $statusCounts = $this->getStatusCounts($branch_id);

        // Step 8: Get lists for filters
        $lists = $this->getFilterLists($branch_id);

        return view('content.customer.customer_long_absent_list', array_merge(
            [
                'customers' => $customers,
                'longAbsentCount' => $counters['long_absent'],
                'activeCount' => $statusCounts['active'],
                'scheduleCount' => $statusCounts['schedule'],
                'notYetStartedCount' => $statusCounts['not_started'],
                'inactiveCount' => $statusCounts['inactive'],
                'dropCount' => $statusCounts['drop'],
                'perpage' => $perpage,
                'percentageover' => $dashboardData['conversion_rate_overall'],
                'leadOriginalCount' => $dashboardData['lead_original_count'],
                'currentMonthCustomerCount' => $dashboardData['current_month_customer_count'],
                'conversionRateCurrentmonth' => $dashboardData['conversion_rate_current_month'],
                'average_business_value' => $dashboardData['average_business_value'],
                'average_collection_value' => $dashboardData['average_collection_value'],
                'total_appinstalled_count' => $appStats['total_app_installed'],
                'total_appnotinstalled_count' => $appStats['total_app_not_installed'],
                'course_change_count' => $dashboardData['course_change_days'],
                'reasonList_hold' => $this->getHoldReasons()
            ],
            $lists
        ))->with('filter_on', false);
    }

    /**
     * Get ONLY fully paid customers
     */
    private function getFullyPaidCustomers($branch_id)
    {
        // Get all customers with their total payments
        $customerPayments = DB::table('za_customer')
            ->leftJoin('za_payment', function($join) {
                $join->on('za_customer.sno', '=', 'za_payment.customer_id')
                     ->where('za_payment.status', '!=', 3);
            })
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->select(
                'za_customer.sno',
                DB::raw('COALESCE(SUM(za_payment.total_amount), 0) as total_amount'),
                DB::raw('COALESCE(SUM(za_payment.paidAmount), 0) as total_paid')
            )
            ->groupBy('za_customer.sno')
            ->get();

        $fullyPaidCustomerIds = [];

        foreach ($customerPayments as $customer) {
            if ($customer->total_amount > 0 && $customer->total_paid >= $customer->total_amount) {
                $fullyPaidCustomerIds[] = $customer->sno;
            }
        }

        return $fullyPaidCustomerIds;
    }

    /**
     * Get customers with training (any status except dropped)
     * No date filtering - show all customers with training
     */
    private function getCustomersWithActiveTraining($customerIds, $branch_id)
    {
        if (empty($customerIds)) {
            return [];
        }

        $customersWithTraining = DB::table('za_training')
            ->select('za_training.customer_id')
            ->whereIn('za_training.customer_id', $customerIds)
            ->where('za_training.branch_id', $branch_id)
            ->where('za_training.status', '!=', 2) // Not dropped
            ->groupBy('za_training.customer_id')
            ->pluck('za_training.customer_id')
            ->toArray();

        return $customersWithTraining;
    }

    /**
     * Get customers data with pagination
     */
    private function getCustomersData($branch_id, $customerIds, $perpage, $page)
    {
        return CustomerModel::select(
            'za_customer.sno',
            'za_customer.add_course',
            'za_customer.cus_name',
            'za_customer.cus_pic',
            'za_customer.customer_id',
            'za_customer.cus_gender',
            'za_customer.cus_dob',
            'za_customer.doj',
            'za_customer.cus_mobile',
            'za_customer.cus_alternate_mobile',
            'za_customer.cus_email_id',
            'za_customer.cus_marital_status',
            'za_customer.country',
            'za_customer.state',
            'za_customer.city',
            'za_customer.address',
            'za_customer.course_id',
            'za_course.course_name',
            'za_course.course_duration',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course_type.course_type_name',
            'za_customer.free_shd_count',
            'za_customer.request_count',
            'za_customer.reason_request',
            'za_customer.free_status',
            'za_customer.reason_reject',
            'za_customer.created_by',
            'za_customer.batch_id',
            'za_customer.is_placement',
            'za_lead.sno as lead_id',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_lead.created_by as lead_created_by',
            'lead_staff.staff_name as lead_staff_name',
            'za_slot.slot_name',
            'za_staff.staff_name',
            'za_staff.sno as staff_sno',
            'za_branch.min_prd_cost',
            DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
            DB::raw('MAX(za_payment.total_amount) as total_amount'),
            DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'),
            DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count'),
            DB::raw('MAX(IFNULL(otp_data.app_installed, 0)) AS app_installed'),
            DB::raw('MAX(IFNULL(points_sum.daily_points_sum, 0)) AS daily_points')
        )
        ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
        ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
        ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
        ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
        ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
        ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
        ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
        ->leftJoin('za_staff as lead_staff', 'za_lead.created_by', '=', 'lead_staff.sno')
        ->leftJoin(DB::raw("
            (SELECT user_id, 1 AS app_installed 
             FROM (SELECT user_id, MAX(sno) AS last_otp_id 
                   FROM za_otp GROUP BY user_id) mx) AS otp_data
        "), 'otp_data.user_id', '=', 'za_customer.sno')
        ->leftJoin(DB::raw("
            (SELECT student_id AS cust_ref, SUM(points) AS daily_points_sum 
             FROM za_students_points GROUP BY student_id) AS points_sum
        "), 'points_sum.cust_ref', '=', 'za_customer.sno')
        ->where('za_customer.branch_id', $branch_id)
        ->where('za_customer.status', 0)
        ->whereIn('za_customer.sno', $customerIds)
        ->groupBy(
            'za_customer.sno',
            'za_customer.add_course',
            'za_customer.cus_name',
            'za_customer.cus_pic',
            'za_customer.customer_id',
            'za_customer.cus_gender',
            'za_customer.cus_dob',
            'za_customer.doj',
            'za_customer.cus_mobile',
            'za_customer.cus_alternate_mobile',
            'za_customer.cus_email_id',
            'za_customer.cus_marital_status',
            'za_customer.country',
            'za_customer.state',
            'za_customer.city',
            'za_customer.address',
            'za_customer.course_id',
            'za_customer.free_shd_count',
            'za_customer.request_count',
            'za_customer.free_status',
            'za_customer.reason_request',
            'za_customer.reason_reject',
            'za_customer.created_by',
            'za_customer.batch_id',
            'za_customer.is_placement',
            'za_lead.sno',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_lead.created_by',
            'lead_staff.staff_name',
            'za_slot.slot_name',
            'za_staff.staff_name',
            'za_staff.sno',
            'za_branch.min_prd_cost',
            'za_course.course_name',
            'za_course.course_duration',
            'za_course.course_code',
            'za_course_subcategory.course_subcategory_name',
            'za_course_type.course_type_name'
        )
        ->orderBy('za_customer.sno', 'desc')
        ->paginate($perpage);
    }

    /**
     * Attach course data to customers
     */
    private function attachCourseData($customers)
    {
        $allCourseIds = [];
        foreach ($customers as $item) {
            $courseIds = json_decode($item->add_course, true);
            if (is_array($courseIds)) {
                $allCourseIds = array_merge($allCourseIds, $courseIds);
            }
        }
        $allCourseIds = array_unique($allCourseIds);

        if (empty($allCourseIds)) return;

        $courses = DB::table('za_course')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->leftJoin('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->whereIn('za_course.sno', $allCourseIds)
            ->select('za_course.*', 'za_course_type.course_type_name', 'za_course_subcategory.course_subcategory_name')
            ->get()
            ->keyBy('sno');

        foreach ($customers as $item) {
            $courseIds = json_decode($item->add_course, true);
            $itemCourses = [];
            if (is_array($courseIds)) {
                foreach ($courseIds as $id) {
                    if (isset($courses[$id])) {
                        $itemCourses[] = $courses[$id];
                    }
                }
            }
            $item->courses = $itemCourses;
            $item->course_count = count($itemCourses);
        }
    }

    /**
     * Get training data for customers - ALL trainings (including ended ones)
     */
    private function getTrainingData($customerIds, $branch_id)
    {
        if (empty($customerIds)) return [];
        
        return DB::table('za_training')
            ->join('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
            ->whereIn('za_training.customer_id', $customerIds)
            ->where('za_training.branch_id', $branch_id)
            ->where('za_training.status', '!=', 2) // Not dropped
            ->select('za_training.*', 'za_batch.start_date as batch_start_date', 'za_batch.end_date as batch_end_date')
            ->get()
            ->groupBy('customer_id');
    }

    /**
     * Get attendance data for customers
     */
    private function getAttendanceData($customerIds)
    {
        if (empty($customerIds)) return [];
        
        return AttendanceModel::whereIn('customer_id', $customerIds)
            ->orderBy('att_date', 'desc')
            ->get()
            ->groupBy('customer_id');
    }

    /**
     * Get payment data for customers
     */
    private function getPaymentData($customerIds)
    {
        if (empty($customerIds)) return [];
        
        return DB::table('za_payment')
            ->whereIn('customer_id', $customerIds)
            ->where('status', '!=', 3)
            ->get()
            ->groupBy('customer_id');
    }

    /**
     * Get certificate data for customers
     */
    private function getCertificateData($customerIds)
    {
        if (empty($customerIds)) return [];
        
        $batchIds = DB::table('za_training')
            ->whereIn('customer_id', $customerIds)
            ->whereNotNull('batch_id')
            ->pluck('batch_id')
            ->unique()
            ->toArray();
        
        if (empty($batchIds)) return [];
        
        return DB::table('za_manage_certificate')
            ->whereIn('za_manage_certificate.batch_id', $batchIds)
            ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
            ->select(
                'za_manage_certificate.*', 
                'za_certificate_status.certificate_status_name', 
                'za_certificate_status.bg_color', 
                'za_certificate_status.text_color'
            )
            ->get()
            ->groupBy('batch_id');
    }

    /**
     * Process single customer
     */
    private function processCustomer($item, $trainingData, $attendanceData, $paymentData, $certificateData, &$counters)
    {
        $carouselDetails = [];
        $isActive = false;
        $isDropped = false;
        $isNotStarted = true;
        $isInactive = false;
        $isSchedule = false;
        $isLongAbsent = false;
        $intern_eligible = 0;

        $customerTraining = $trainingData[$item->sno] ?? [];
        $customerAttendance = $attendanceData[$item->sno] ?? [];
        $customerPayment = $paymentData[$item->sno] ?? [];
        $customerCertificate = $certificateData[$item->sno] ?? [];

        $isFullyPaid = true;

        if (empty($customerTraining)) {
            $isInactive = true;
            $item->is_inactive = true;
            $item->carousel_details = [];
            $item->paymentDetailss = $this->getPaymentDetails($item->sno);
            $item->all_active = false;
            $item->all_cus_drop = false;
            $item->all_end_date = true;
            $item->all_schedule = false;
            $item->is_long_absent = false;
            $item->is_fully_paid = true;
            $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
            $item->payment_percentage = ($item->total_amount > 0) 
                ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1) 
                : 0;
            $counters['inactive']++;
            return $item;
        }

        foreach ($customerTraining as $training) {
            $batch = $this->getBatchDetails($training->batch_id);
            $course = $this->getCourseDetails($training->course_id);

            if (!$course) continue;

            if ($training->batch_id > 0) {
                $qualifiesForInternship = ($training->tesbo_check == 2) || ($course->course_type_id == 3);
                if ($qualifiesForInternship) {
                    $payments = $customerPayment->where('payment_id', $training->payment_id);
                    if ($payments->isNotEmpty()) {
                        $totalAmount = $payments->first()->total_amount ?? 0;
                        $totalPaid = $payments->sum('paidAmount');
                        if ($totalPaid >= $totalAmount) {
                            $intern_eligible = 1;
                        }
                    }
                }
            }

            if ($isFullyPaid && $training->batch_id > 0) {
                $isLongAbsent = $this->checkLongAbsence(
                    $item->sno, 
                    $training->batch_id, 
                    $batch, 
                    $customerAttendance
                );
                
                if ($isLongAbsent) {
                    $counters['long_absent']++;
                    break;
                }
            }

            $paymentPercentage = $this->calculatePaymentPercentage($training, $customerPayment);
            $courseProgress = $this->calculateCourseProgress($training, $customerAttendance);

            $status = $this->determineCustomerStatus($batch, $training);
            
            if ($status['isActive'] && !$status['isDropped'] && !$status['isInactive'] && !$status['isNotStarted']) {
                $isActive = true;
            } elseif ($status['isNotStarted'] && !$status['isActive'] && !$status['isDropped'] && !$status['isInactive']) {
                $isNotStarted = true;
            } elseif ($status['isDropped']) {
                $isDropped = true;
            } elseif ($status['isSchedule']) {
                $isSchedule = true;
            }

            $certStatus = null;
            if ($training->batch_id && isset($certificateData[$training->batch_id])) {
                $cert = $certificateData[$training->batch_id]->first();
                $certStatus = [
                    'id' => $cert->cert_status_id ?? null,
                    'name' => $cert->certificate_status_name ?? null,
                    'bg' => $cert->bg_color ?? null,
                    'color' => $cert->text_color ?? null
                ];
            }

            $carouselDetails[] = [
                'course_sno' => $training->course_id,
                'course_mode_id' => $training->course_mode_id ?? null,
                'online_course_fee' => $course->online_fee ?? null,
                'batch_sno' => $training->batch_id,
                'batch_count' => $this->getBatchCount($training->course_id),
                'traning_sno' => $training->sno,
                'traning_status' => $training->status,
                'course_name' => $course->course_name ?? null,
                'course_type_name' => $course->course_type_name ?? null,
                'batch_name' => $batch->batch_name ?? null,
                'start_date' => $batch->start_date ?? null,
                'end_date' => $batch->end_date ?? null,
                'slot_name' => $batch->slot_name ?? null,
                'staff_name' => $batch->staff_name ?? null,
                'payment_percentage' => $paymentPercentage,
                'course_progress' => $courseProgress,
                'cert_status_id' => $certStatus['id'] ?? null,
                'certificate_status_name' => $certStatus['name'] ?? null,
                'certificate_status_bg' => $certStatus['bg'] ?? null,
                'certificate_status_color' => $certStatus['color'] ?? null,
                'is_long_absent' => $isLongAbsent,
                'is_fully_paid' => $isFullyPaid,
            ];
        }

        if (!$isLongAbsent) {
            if ($isActive && !$isDropped && !$isInactive && !$isNotStarted) {
                $counters['active']++;
            } elseif ($isNotStarted && !$isActive && !$isDropped && !$isInactive) {
                $counters['not_started']++;
            } elseif ($isDropped) {
                $counters['drop']++;
            } elseif ($isSchedule) {
                $counters['inactive']++;
            }
        }

        $item->intern_eligible = $intern_eligible;
        $item->carousel_details = $carouselDetails;
        $item->paymentDetailss = $this->getPaymentDetails($item->sno);
        $item->all_active = $isActive;
        $item->all_cus_drop = $isDropped;
        $item->all_end_date = $isInactive;
        $item->all_schedule = $isSchedule;
        $item->is_long_absent = $isLongAbsent;
        $item->is_fully_paid = $isFullyPaid;
        $item->is_inactive = false;
        $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));
        $item->payment_percentage = ($item->total_amount > 0) 
            ? number_format(($item->total_paid_amount / $item->total_amount) * 100, 1) 
            : 0;

        return $item;
    }

    /**
     * Check for 3 consecutive days absence (checking LAST 3 records)
     * CRITERIA: The last 3 attendance records on class days must be 'A' (Absent)
     */
    private function checkLongAbsence($customerId, $batchId, $batch, $attendanceRecords)
    {
        if (!$batch) return false;
        
        // Get slot days (class days)
        $slotDays = json_decode($batch->slot_type_days ?? '[]', true);
        if (empty($slotDays)) {
            $slotDays = ['0', '1', '2', '3', '4', '5', '6'];
        }
        
        // Get attendance records for this customer and batch
        // Sort by date DESC (latest first)
        $records = $attendanceRecords->where('batch_id', $batchId)
            ->sortByDesc('att_date')
            ->values();
        
        // If no attendance records at all, return false (not long absent)
        if ($records->isEmpty()) {
            return false;
        }
        
        // Get ONLY class days attendance (filter by slot days)
        $classAttendance = collect();
        foreach ($records as $record) {
            $dayOfWeek = date('w', strtotime($record->att_date));
            if (in_array($dayOfWeek, $slotDays)) {
                $classAttendance->push($record);
            }
        }
        
        // If no attendance on class days, return false
        if ($classAttendance->isEmpty()) {
            return false;
        }
        
        // If there are less than 3 class day records, cannot be long absent
        if ($classAttendance->count() < 3) {
            return false;
        }
        
        // Get the LAST 3 records (most recent class days)
        $lastThreeRecords = $classAttendance->take(3);
        
        // Check if ALL of the last 3 records are 'A' (Absent)
        $allAbsent = true;
        foreach ($lastThreeRecords as $record) {
            if ($record->attendance != 'A') {
                $allAbsent = false;
                break;
            }
        }
        
        // Return true only if all last 3 are 'A'
        return $allAbsent;
    }

    private function getLastClassDays($slotDays, $fromDate, $count)
    {
        $classDays = [];
        $date = new \DateTime($fromDate);
        $date->modify('-1 day');
        
        while (count($classDays) < $count) {
            $dayOfWeek = $date->format('w');
            if (in_array($dayOfWeek, $slotDays)) {
                $classDays[] = $date->format('Y-m-d');
            }
            $date->modify('-1 day');
        }
        
        return $classDays;
    }

    private function getCourseDetails($courseId)
    {
        static $courseCache = [];
        
        if (!isset($courseCache[$courseId])) {
            $courseCache[$courseId] = DB::table('za_course')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course.sno', 'za_course.course_type_id', 'za_course_type.online_fee')
                ->where('za_course.sno', $courseId)
                ->first();
        }
        
        return $courseCache[$courseId];
    }

    private function getBatchDetails($batchId)
    {
        if (!$batchId) return null;
        
        static $batchCache = [];
        
        if (!isset($batchCache[$batchId])) {
            $batchCache[$batchId] = DB::table('za_batch')
                ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
                ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
                ->select(
                    'za_batch.batch_name', 
                    'za_batch.start_date', 
                    'za_batch.end_date', 
                    'za_slot.slot_name',
                    'za_slot.slot_type_days',
                    'za_staff.staff_name'
                )
                ->where('za_batch.sno', $batchId)
                ->first();
        }
        
        return $batchCache[$batchId];
    }

    private function calculatePaymentPercentage($training, $customerPayment)
    {
        $paymentDetails = $customerPayment->where('payment_id', $training->payment_id)->first();
        if (!$paymentDetails) return 0;
        
        $totalPaid = $customerPayment->where('payment_id', $training->payment_id)->sum('paidAmount');
        $totalAmount = $paymentDetails->total_amount ?? 0;
        
        if ($totalAmount > 0) {
            $percentage = number_format(($totalPaid / $totalAmount) * 100, 1);
            return min($percentage, 100);
        }
        return 0;
    }

    private function calculateCourseProgress($training, $customerAttendance)
    {
        $courseTopicCount = DB::table('za_course_chapter')
            ->where('course_id', $training->course_id)
            ->count();
            
        if ($courseTopicCount == 0) return 0;
        
        $helper = new Helpers();
        $progress = $helper->get_course_percentage($training->course_id, $training->customer_id);
        
        return number_format($progress, 2);
    }

    private function determineCustomerStatus($batch, $training)
    {
        $currentDate = date('Y-m-d');
        $start_date = $batch->start_date ?? null;
        $end_date = $batch->end_date ?? null;
        
        $isActive = false;
        $isDropped = false;
        $isInactive = false;
        $isNotStarted = false;
        $isSchedule = false;
        
        if ($start_date <= $currentDate && $start_date != null) {
            $isActive = true;
        }
        
        if ($training->status == 2) {
            $isDropped = true;
        }
        
        if (isset($end_date) && $end_date < $currentDate) {
            $isInactive = true;
        }
        
        if (isset($start_date) && $start_date > $currentDate) {
            $isSchedule = true;
        }
        
        return [
            'isActive' => $isActive,
            'isDropped' => $isDropped,
            'isInactive' => $isInactive,
            'isNotStarted' => $isNotStarted,
            'isSchedule' => $isSchedule
        ];
    }

    private function getPaymentDetails($customerId)
    {
        return DB::table('za_payment')
            ->select('za_payment.status', 'za_payment.nextPayDate')
            ->where('za_payment.customer_id', $customerId)
            ->where('za_payment.status', 0)
            ->get();
    }

    private function getBatchCount($courseId)
    {
        static $batchCounts = [];
        
        if (!isset($batchCounts[$courseId])) {
            $batchCounts[$courseId] = BatchModel::where('course_id', $courseId)->count();
        }
        
        return $batchCounts[$courseId];
    }

    private function getEmptyView($perpage)
    {
        $emptyPaginator = new LengthAwarePaginator(
            collect([]),
            0,
            $perpage,
            1,
            ['path' => Paginator::resolveCurrentPath()]
        );
        
        return view('content.customer.customer_long_absent_list', array_merge(
            $this->getDefaultViewData($perpage),
            ['customers' => $emptyPaginator]
        ))->with('filter_on', false);
    }

    private function getDefaultViewData($perpage)
    {
        return [
            'customers_list' => collect([]),
            'customer_name_fill' => '',
            'cus_fill' => '',
            'staff_fill' => '',
            'status_fill' => '',
            'course_type_list' => collect([]),
            'course_type_fill' => '',
            'leadOriginalCount' => 0,
            'course_list' => collect([]),
            'batch_list' => collect([]),
            'staff_list' => collect([]),
            'activeCount' => 0,
            'scheduleCount' => 0,
            'notYetStartedCount' => 0,
            'inactiveCount' => 0,
            'dropCount' => 0,
            'longAbsentCount' => 0,
            'percentageover' => '0%',
            'batch_name_fill' => '',
            'slot_list' => collect([]),
            'perpage' => $perpage,
            'slot_name_fill' => '',
            'slot_type_list' => collect([]),
            'slot_type_name_fill' => '',
            'course_name_fill' => '',
            'date_filter' => '',
            'fin_yr_fill' => '',
            'reasonList_hold' => collect([]),
            'gender_fill' => '',
            'currentMonthCustomerCount' => 0,
            'conversionRateCurrentmonth' => 0,
            'average_business_value' => 0,
            'average_collection_value' => 0,
            'total_appinstalled_count' => 0,
            'total_appnotinstalled_count' => 0,
            'course_change_count' => 0
        ];
    }

    private function getFilterLists($branch_id)
    {
        return [
            'customers_list' => CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'course_type_list' => CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'course_list' => ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'batch_list' => BatchModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'slot_list' => SlotModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'slot_type_list' => SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get(),
            'staff_list' => StaffModel::where('status', 0)->where('role_id', 22)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get()
        ];
    }

    private function getHoldReasons()
    {
        return HoldReasonModel::select('*')->where('status', '!=', 2)->get();
    }

    private function getAppStatistics($branch_id)
    {
        $app_result = CustomerModel::from('za_customer')
            ->leftJoin(DB::raw("
                (SELECT user_id, 1 AS app_installed 
                 FROM (SELECT user_id, MAX(sno) AS last_otp_id 
                       FROM za_otp GROUP BY user_id) mx) AS otp_data
            "), 'otp_data.user_id', '=', 'za_customer.sno')
            ->leftJoin(DB::raw("
                (SELECT student_id, SUM(points) AS daily_points 
                 FROM za_students_points GROUP BY student_id) AS points_sum
            "), 'points_sum.student_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->selectRaw("
                COUNT(*) AS total_customers,
                SUM(IF(IFNULL(otp_data.app_installed,0)=1,1,0)) AS total_app_installed,
                SUM(IF(IFNULL(otp_data.app_installed,0)=0,1,0)) AS total_app_not_installed,
                SUM(IFNULL(points_sum.daily_points,0)) AS total_daily_points
            ")
            ->first();

        return [
            'total_app_installed' => isset($app_result->total_app_installed) ? (int)$app_result->total_app_installed : 0,
            'total_app_not_installed' => isset($app_result->total_app_not_installed) ? (int)$app_result->total_app_not_installed : 0
        ];
    }

    private function getDashboardData($branch_id)
    {
        $currentMonthCustomer = CustomerModel::where('za_customer.status', 0)
            ->where('za_customer.branch_id', $branch_id)
            ->whereYear('za_customer.created_at', date('Y'))
            ->whereMonth('za_customer.created_at', date('m'))
            ->get();

        $currentMonthCustomerCount = $currentMonthCustomer->count();
        $total_payment = 0;
        $total_paid_payment = 0;

        foreach ($currentMonthCustomer as $customer) {
            $courseIds = json_decode($customer->course_id, true) ?? [];
            foreach ($courseIds as $courseId) {
                $payment = ManageCoursesModel::where('sno', $courseId)->value('course_max_price') ?? 0;
                $total_payment += $payment;
                
                $paid_payment = PaymentModel::where('customer_id', $customer->sno)
                    ->where('course_id', $courseId)
                    ->where('status', 1)
                    ->sum('paidAmount');
                $total_paid_payment += $paid_payment;
            }
        }

        $averageBusinessValue = $currentMonthCustomerCount > 0 ? $total_payment / $currentMonthCustomerCount : 0;
        $averageCollectionValue = $currentMonthCustomerCount > 0 ? $total_paid_payment / $currentMonthCustomerCount : 0;

        $totalLeadCounts = LeadModel::whereNotIn('za_lead.status', [3, 2, 6, 5, 7])
            ->where('za_lead.internal_status', '!=', 1);
        if ($branch_id != 0) {
            $totalLeadCounts->where('za_lead.branch_id', $branch_id);
        }
        $totalLeadCount = $totalLeadCounts->count();

        $totalCustomerCount = CustomerModel::where('status', 0)
            ->where('za_customer.created_by', '!=', 0);
        if ($branch_id != 0) {
            $totalCustomerCount->where('za_customer.branch_id', $branch_id);
        }
        $totalCustomerCount = $totalCustomerCount->count();

        $percentageover = 0;
        if ($totalLeadCount > 0) {
            $percentageover = round(($totalCustomerCount / $totalLeadCount) * 100) . '%';
        }

        $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
        if ($branch_id != 0) {
            $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
        }
        $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
            ->whereMonth('created_at', date('m'))
            ->count();

        $conversionRateCurrentmonth = 0;
        if ($currentMonthLeadCount > 0) {
            $conversionRateCurrentmonth = number_format(($currentMonthCustomerCount / $currentMonthLeadCount) * 100, 2);
        }

        $leadOriginalCount = DB::table('za_customer')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_customer.created_by', '!=', 0)
            ->where('za_customer.status', 0)
            ->count();

        $helper = new Helpers();
        $get_course_change_days = 0;
        if ($branch_id > 0) {
            $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
        }

        return [
            'current_month_customer_count' => $currentMonthCustomerCount,
            'average_business_value' => $averageBusinessValue,
            'average_collection_value' => $averageCollectionValue,
            'conversion_rate_overall' => $percentageover,
            'conversion_rate_current_month' => $conversionRateCurrentmonth,
            'lead_original_count' => $leadOriginalCount,
            'course_change_days' => $get_course_change_days
        ];
    }

    private function getStatusCounts($branch_id)
    {
        $dropCount = 0;
        $activeCount = 0;
        $notYetStartedCount = 0;
        $scheduleCount = 0;

        $batch_Data = DB::table('za_training')
            ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->where('za_training.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->get();

        $processed_drop_customers = [];
        $processed_active_customers = [];
        $processed_schedule_customers = [];
        $processed_not_started_customers = [];

        foreach ($batch_Data as $singledata) {
            if (in_array($singledata->customer_id, $processed_drop_customers)) {
                continue;
            }
            if ($singledata->status == "2") {
                $dropCount++;
                $processed_drop_customers[] = $singledata->customer_id;
            }
        }

        $batch_active_Data = DB::table('za_training')
            ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->whereNotNull('za_training.start_date')
            ->where('za_training.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->get();

        foreach ($batch_active_Data as $singledata) {
            if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (in_array($singledata->customer_id, $processed_active_customers)) {
                    continue;
                }
                if ($singledata->start_date <= \Carbon\Carbon::today()->startOfDay()) {
                    $activeCount++;
                    $processed_active_customers[] = $singledata->customer_id;
                }
            }
        }

        $batch_Data_old = DB::table('za_training')
            ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->where('za_training.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->get();

        foreach ($batch_Data_old as $singledata) {
            if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (!in_array($singledata->customer_id, $processed_active_customers)) {
                    if (in_array($singledata->customer_id, $processed_schedule_customers)) {
                        continue;
                    }
                    if ($singledata->start_date > \Carbon\Carbon::today()->startOfDay()) {
                        $scheduleCount++;
                        $processed_schedule_customers[] = $singledata->customer_id;
                    }
                }
            }
        }

        $batch_notyetStated = DB::table('za_training')
            ->select('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
            ->where('za_training.branch_id', $branch_id)
            ->where('za_customer.status', 0)
            ->groupBy('za_training.customer_id', 'za_training.status', 'za_training.start_date')
            ->get();

        foreach ($batch_notyetStated as $singledata) {
            if (!in_array($singledata->customer_id, $processed_drop_customers)) {
                if (!in_array($singledata->customer_id, $processed_active_customers)) {
                    if (!in_array($singledata->customer_id, $processed_schedule_customers)) {
                        if (in_array($singledata->customer_id, $processed_not_started_customers)) {
                            continue;
                        }
                        if ($singledata->start_date === null) {
                            $notYetStartedCount++;
                            $processed_not_started_customers[] = $singledata->customer_id;
                        }
                    }
                }
            }
        }

        return [
            'drop' => $dropCount,
            'active' => $activeCount,
            'not_started' => $notYetStartedCount,
            'schedule' => $scheduleCount,
            'inactive' => 0
        ];
    }
}