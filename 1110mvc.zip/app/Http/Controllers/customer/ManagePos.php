<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\PaymentModel;
use App\Models\PaymentOldModel;
use App\Models\TrainingModel;
use App\Models\SubLedgerModel;
use App\Models\OldCustomerModel;
use App\Models\TransactionModel;
use Illuminate\Support\Facades\Http;

class ManagePos extends Controller
{
   public function index(Request $request)
   {

        $branch_id = $request->user()->branch_id;

        $branch_details = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        return view('content.customer.customer_pos_payment', compact('branch_details'));;
    }
    
   public function customer_pos_payment_final(Request $request)
   {

      $branch_id = $request->user()->branch_id;


      return view('content.customer.customer_pos_payment_final');
  }
  
   public function autocomplete(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $search = $request->get('term');
      $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean

      if ($old_customer) {
          // Use a closure to properly group the orWhere condition
          $results = OldCustomerModel::where(function ($query) use ($search) {
              $query->where('cus_name', 'LIKE', '%' . $search . '%')
                    ->orWhere('cus_mobile', 'LIKE', '%' . $search . '%')
                    ->orWhere('customer_id', 'LIKE', '%' . $search . '%');
          })
          ->where('branch_id', $branch_id)
          ->get();
      } else {
          // Use a closure to properly group the orWhere condition
          $results = CustomerModel::where(function ($query) use ($search) {
              $query->where('cus_name', 'LIKE', '%' . $search . '%')
                    ->orWhere('cus_mobile', 'LIKE', '%' . $search . '%')
                    ->orWhere('customer_id', 'LIKE', '%' . $search . '%');
          })
          ->where('branch_id', $branch_id)
          ->get();
      }

      return response()->json($results->isNotEmpty() ? $results : []); // Return an empty array if no results
  }

   public function customerfind(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $customer_id = $request->customer_id;
      $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean

      if($old_customer){
                // Fetch the customer details
              $customer = OldCustomerModel::where('za_old_customer.customer_id', $customer_id)
              ->where('za_old_customer.branch_id', $branch_id)
              ->select(
                  'za_old_customer.customer_id', 'za_old_customer.sno', 'za_old_customer.cus_name',
                  'za_old_customer.cus_mobile','za_old_customer.cus_gender'
              )
              ->first();

          if (!$customer) {
              return response()->json(['error' => 'Customer not found'], 404);
          }

          // Fetch related payment records
          $payments = PaymentOldModel::where('customer_id', $customer->sno)
              ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
              ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
              ->select(
                  'za_old_payments.schedule_date as nextPayDate',
                  'za_old_payments.status',
                  'za_old_payments.sno',
                  'za_old_payments.amount',
                  'za_old_payments.invoice_id',
                  'za_old_payments.total_amount',
                  'za_old_payments.paidAmount',
                  'za_old_payments.balanceFee',
                  'za_course.course_name',
                  'za_course.course_id',
                  'za_course_type.course_type_name'
              )
              ->orderBy('schedule_date', 'asc')
              ->get();

          // Initialize the helper
          $helper = new \App\Helpers\Helpers();

          // Encrypt invoice_id and print_id
          $payments = $payments->map(function ($pay, $index) use ($helper) {
              return [
                  'sno' => $pay->sno,
                  'status' => $pay->status,
                  'nextPayDate' => $pay->nextPayDate,
                  'amount' => $pay->amount,
                  'paidAmount' => $pay->paidAmount,
                  'total_amount' => $pay->total_amount,
                  'balanceFee' => $pay->balanceFee,
                  'course_name' => $pay->course_name,
                  'course_id' => $pay->course_id,
                  'course_type_name' => $pay->course_type_name,
                  'invoice_id' => $pay->invoice_id ? $helper->encrypt_decrypt($pay->invoice_id, 'encrypt') : null,
                  'print_id' => $helper->encrypt_decrypt($index + 1, 'encrypt'),
              ];
          });
      }else{
                // Fetch the customer details
              $customer = CustomerModel::where('za_customer.customer_id', $customer_id)
                  ->where('za_customer.branch_id', $branch_id)
                  ->select(
                      'za_customer.customer_id', 'za_customer.sno', 'za_customer.cus_name',
                      'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_customer.cus_pic'
                  )
                  ->first();

              if (!$customer) {
                  return response()->json(['error' => 'Customer not found'], 404);
              }

              // Fetch related payment records
              $payments = PaymentModel::where('customer_id', $customer->sno)
                  ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                  ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                  ->select(
                      'za_payment.nextPayDate',
                      'za_payment.status',
                      'za_payment.sno',
                      'za_payment.amount',
                      'za_payment.invoice_id',
                      'za_payment.total_amount',
                      'za_payment.paidAmount',
                      'za_payment.balanceFee',
                      'za_course.course_name',
                      'za_course.course_id',
                      'za_course_type.course_type_name'
                  )
                  ->orderBy('nextPayDate', 'asc')
                  ->get();

              // Initialize the helper
              $helper = new \App\Helpers\Helpers();

              // Encrypt invoice_id and print_id
              $payments = $payments->map(function ($pay, $index) use ($helper) {
                  return [
                      'sno' => $pay->sno,
                      'status' => $pay->status,
                      'nextPayDate' => $pay->nextPayDate,
                      'amount' => $pay->amount,
                      'paidAmount' => $pay->paidAmount,
                      'total_amount' => $pay->total_amount,
                      'balanceFee' => $pay->balanceFee,
                      'course_name' => $pay->course_name,
                      'course_id' => $pay->course_id,
                      'course_type_name' => $pay->course_type_name,
                      'invoice_id' => $pay->invoice_id ? $helper->encrypt_decrypt($pay->invoice_id, 'encrypt') : null,
                      'print_id' => $helper->encrypt_decrypt($index + 1, 'encrypt'),
                  ];
              });
      }



      // Return structured JSON response
      return response()->json([
          'customer' => $customer,
          'payments' => $payments
      ]);
  }

   public function payment_particular(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $payment_id = $request->payment_id;
      $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean

      if($old_customer){
        // Fetch related payment records
        $payments = PaymentOldModel::where('za_old_payments.sno', $payment_id)
            ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->select(
                'za_old_payments.schedule_date as nextPayDate',
                'za_old_payments.status',
                'za_old_payments.sno',
                'za_old_payments.amount',
                'za_old_payments.paidAmount',
                'za_old_payments.total_amount',
                'za_old_payments.balanceFee',
                'za_course.course_name',
                'za_course.course_id',
                'za_course_type.course_type_name'
            )
            ->first();
      }else{
          // Fetch related payment records
          $payments = PaymentModel::where('za_payment.sno', $payment_id)
          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->select(
              'za_payment.nextPayDate',
              'za_payment.status',
              'za_payment.sno',
              'za_payment.amount',
              'za_payment.paidAmount',
              'za_payment.total_amount',
              'za_payment.balanceFee',
              'za_course.course_name',
              'za_course.course_id',
              'za_course_type.course_type_name'
          )
          ->first();
      }

      // Return structured JSON response
      return response()->json([
          'payments' => $payments
      ]);
  }

   public function paymentAmount(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $customer_id = $request->customer_id;
      $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean

      if($old_customer){


          // Fetch related payment records
          $payments = PaymentOldModel::where('za_old_payments.customer_id', $customer_id)
              ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
              ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
              ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
              ->select(
                  'za_old_payments.schedule_date as nextPayDate',
                  'za_old_payments.status',
                  'za_old_payments.sno',
                  'za_old_payments.amount',
                  'za_old_payments.paidAmount',
                  'za_old_payments.total_amount',
                  'za_old_payments.balanceFee',
                  'za_course.course_name',
                  'za_course.course_id',
                  'za_course_type.course_type_name'
              )
              ->first();
        }else{
          // Fetch related payment records
          $payments = PaymentModel::where('za_payment.customer_id', $customer_id)
          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->select(
              'za_payment.nextPayDate',
              'za_payment.status',
              'za_payment.sno',
              'za_payment.amount',
              'za_payment.paidAmount',
              'za_payment.total_amount',
              'za_payment.balanceFee',
              'za_course.course_name',
              'za_course.course_id',
              'za_course_type.course_type_name'
          )
          ->first();
        }

      // Return structured JSON response
      return response()->json([
          'payments' => $payments
      ]);
  }
  
   public function processPayment(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $pay_sno = $request->customer_id;
      $paymentMode = $request->payment_mode;
      $paidAmount = $request->amount;
      $remaining_days = $request->remaining_amount;
       $receipt_id = $request->reciptid;



      $initialPayDateFormatted = now()->format('Y-m-d');

      $check_update = false; // Initial
      $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean
       //  return $transaction;
       $transaction = json_encode($request->transaction_all);
      if($old_customer){
        
        
         $invoice_chk = PaymentOldModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
          $year = date("Y");
          if (!$invoice_chk) {
              $invoice_id = 'EA/' . $year . '/INV2005';
          } else {
              $data = $invoice_chk->invoice_id;
              $slice = explode("/", $data);
              if (count($slice) >= 3) {
                  $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
              } else {
                  $next_inv_number = 2005;
              }
              $invoice_id = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
          }

        // return $invoice_id;
        $get_ids = PaymentOldModel::where('sno', $pay_sno)->first();

        $pay_course_id = $get_ids->course_id;
        $pay_customer_id = $get_ids->customer_id;

        $total_course_amount = $get_ids->total_amount;
        $balance_Fees = $get_ids->amount - $paidAmount;
        $balanceFees = max(0,  $paidAmount - $get_ids->balanceFee);
        $balanceFeestotal = $get_ids->total_amount;
        $paid_amt = PaymentOldModel::where('course_id', $pay_course_id)
            ->where('customer_id', $pay_customer_id)
            ->pluck('paidAmount');

        $total_paid_amount = $paid_amt->sum();

        $total_bal = $total_course_amount - $total_paid_amount;
        // $total_balcurrent = round($get_ids->amount + $get_ids->amount * 18 / 100);
        $total_balcurrent = $get_ids->amount;

        // $check_update = false;

        // return $get_ids;

        if ($paidAmount == $total_balcurrent) { // Corrected comparison
            //   return '1';
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $payment_up = PaymentOldModel::where('sno', $pay_sno)->first();
            // return 'total';
            if ($payment_up) {


                $payment_up->paidAmount = $paidAmount;
                $payment_up->invoice_id = $invoice_id;
                $payment_up->balanceFee = $payment_up->balanceFee;
                $payment_up->payment_mode_label = $paymentMode;
                $payment_up->transaction = $transaction;
                $payment_up->status = 1;
                $payment_up->save(); // Save changes

                $check_update = true;

                $customer = OldCustomerModel::where('sno', $payment_up->customer_id)->first();
                // dd($training);
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                // Update or Create Training Model
                $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                $paidGst = $paidAmount * ($gstPercentage / 100);
                // return $paidAmount;

                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $customer->customer_id;
                $add_subledger->subledger_desc = 'Old Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();
                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                }
                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'ledger_id' => 1,
                        'customer_type' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                         'receipt_id' => $receipt_id,
                        'invoice_id' => $invoice_id,
                        'debit' => null,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );
                
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
        } else if ($paidAmount == $total_bal) {
        //   return '2';
            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $payment_up = PaymentOldModel::where('sno', $pay_sno)->first();
            // return 'paid=bal';
            $payment_all = PaymentOldModel::where('course_id', $pay_course_id)
                ->where('customer_id', $pay_customer_id)->get();
            if ($payment_up) {
                $payment_up->paidAmount = $paidAmount;
                $payment_up->invoice_id = $invoice_id;
                $payment_up->payment_mode_label = $paymentMode;
                $payment_up->transaction = $transaction;
                $payment_up->balanceFee = 0; ///here need correct the code rember
                $payment_up->status = 1;

                $payment_up->update();
                $check_update = true;
                $customer = OldCustomerModel::where('sno', $payment_up->customer_id)->first();
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                // Update or Create Training Model
                $gstPercentage = $branch->gst_percentage ?? 0; // Default GST percentage to 0 if null
                $paidGst = $payment_up->paidAmount * ($gstPercentage / 100);



                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $customer->customer_id;
                $add_subledger->subledger_desc = 'Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();
                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                }
                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'ledger_id' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                        'invoice_id' => $invoice_id,
                        'customer_type' => 1,
                         'receipt_id' => $receipt_id,
                        'debit' => null,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );
            }
            if ($payment_all->isNotEmpty()) {
                foreach ($payment_all as $payment) {
                    $payment->status = 1;
                    $payment->save(); // Save each updated payment record
                }
            }
        } else if ($paidAmount > $get_ids->amount) {
            //  return '3';
            //  return $invoice_id;
          $user_id = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;

          $payment_id = PaymentOldModel::where('sno', $pay_sno)->first();

          $paymentsdetails = PaymentOldModel::where('customer_id', $payment_id->customer_id)->orderBy('schedule_date','ASC')->get()->values();
          if ($payment_id) {
            // return $paymentsdetails;
            // Find the index of the current record
            $currentIndex = $paymentsdetails->search(function ($item) use ($pay_sno) {
                return $item->sno == $pay_sno;
            });
             // return $currentIndex;
             // Get the next record in the list
             // if ($currentIndex !== false && isset($paymentsdetails[$currentIndex + 1])) {
             if (isset($paymentsdetails[$currentIndex + 1])) {
                $payment_up = $paymentsdetails[$currentIndex + 1]; // Next record
    
                // Update the next record
                $payment_up->amount = $paidAmount - $get_ids->amount;
                $payment_up->gst_amount = ($payment_up->amount * 0.18);
                $payment_up->updated_by = $user_id;
                $payment_up->update();
             }
            // Check if there is another record after the updated one
            if (isset($paymentsdetails[$currentIndex + 2])) {
                $next_payment_up = $paymentsdetails[$currentIndex + 2]; // Record after next

                // Update the second next record
                $next_payment_up->amount = $payment_up->amount - $get_ids->amount; // Adjust as needed
                $next_payment_up->gst_amount = ($next_payment_up->amount * 0.18);
                $next_payment_up->updated_by = $user_id;
                $next_payment_up->update();
            }
           

              if ($payment_id) {
                  $payment_id->paidAmount = $paidAmount;
                  $payment_id->gst_amount = $paidAmount * 0.18;
                  $payment_id->payment_mode_label = $paymentMode;
                  $payment_id->balanceFee = $paidAmount - $get_ids->amount;
                  $payment_id->invoice_id = $invoice_id;
                  $payment_id->transaction = $transaction;
                  $payment_id->status = 1;
                  // return $payment_id;
                  $payment_id->update(); // Save changes

                  $check_update = true;

              }
              $customer = OldCustomerModel::where('sno', $payment_id->customer_id)->first();
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->branch_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB0001";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $customer->customer_id;
              $add_subledger->subledger_desc = 'Old Students fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->created_by = $user_id;
              $add_subledger->updated_by = $user_id;

              $add_subledger->save();

              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA0001";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $paidAmount,
                      'invoice_id' => $invoice_id,
                       'receipt_id' => $receipt_id,
                      'customer_type' => 1,
                      'debit' => null,
                      'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]
              );
          } else {
              return response([
                  'status' => 404,
                  'message' => 'Payment record not found',
                  'error_msg' => 'Payment record not found',
                  'data' => null,
              ], 404);
          }
        } else {

            $user_id = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            // return 'else';
            // return $user_id;
            $payment_id = PaymentOldModel::where('sno', $pay_sno)->first();
            if ($payment_id) {
                $payment_up = new PaymentOldModel();
                $payment_up->old_payment_id    = $payment_id->old_payment_id;
                $payment_up->customer_id   = $payment_id->customer_id;
                $payment_up->course_id     = $payment_id->course_id;
                $payment_up->schedule_date = $payment_id->schedule_date;
                $payment_up->amount        = $balance_Fees;

                $payment_up->paidAmount = 0;
                $payment_up->gst_amount = $balance_Fees * 0.18;
                $payment_up->payment_mode_label = $paymentMode;
                $payment_up->balanceFee = $payment_id->balanceFee;
                // $payment_up->balanceFee = $payment_id->balanceFee + $balance_Fees;

                $payment_up->total_amount = $payment_id->total_amount;
                $payment_up->created_by = $user_id;
                $payment_up->updated_by = $user_id;
                $payment_up->transaction = $transaction;
                $payment_up->branch_id = $request->user()->branch_id;
                $payment_up->status = 0;
                // return $payment_up;
                $payment_up->save(); // Save new record

                $check_update = true;

                if ($payment_up) {

                    $payment_id->paidAmount = $paidAmount;
                    $payment_id->invoice_id = $invoice_id;
                    $payment_id->gst_amount = $paidAmount * 0.18;
                    $payment_id->payment_mode_label = $paymentMode;
                    $payment_up->transaction = $transaction;
                    // $payment_id->balanceFee = $payment_id->balanceFee - $paidAmount;
                    $payment_id->balanceFee = $payment_id->balanceFee + $balance_Fees;

                    $payment_id->status = 1;
                    // return $payment_id;
                    $payment_id->update(); // Save changes

                    $check_update = true;
                    $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                }
                $customer = OldCustomerModel::where('sno', $payment_up->customer_id)->first();
                $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
                $branch_code = $branch_check->city_short_code;
                $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

                if (!$ledger_check) {
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
                } else {
                    $data = $ledger_check->subledger_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_cos = sprintf("SUB%04d", $next_number_cos);
                    $year = date("Y");
                    $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
                }

                $add_subledger = new SubLedgerModel();
                $add_subledger->ledger_id = 1;
                $add_subledger->subledger_id = $subledger_id;
                $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . 'old';
                $add_subledger->subledger_desc = 'Old Students fees';
                $add_subledger->branch_id = $branch_check->sno;
                $add_subledger->created_by = $user_id;
                $add_subledger->updated_by = $user_id;

                $add_subledger->save();

                $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
                if (!$tr_check) {
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
                } else {
                    $data = $tr_check->transaction_id;
                    $slice = explode("/", $data);
                    $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                    $next_number_cos = (int) $result_cos + 1;
                    $request_tr = sprintf("TRA%04d", $next_number_cos);
                    $year = date("Y");
                    $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
                }
                TransactionModel::updateOrCreate(
                    [
                        'branch_id' => $branch_check->sno,
                        'transaction_id' => $transaction_id,
                        'transaction_type' => 'Credit',
                        'transaction_name' => 'Customer',
                        'trans_source_id' => $customer->customer_id,
                        'ledger_id' => 1,
                        'subledger_id' => $add_subledger->sno,
                        'credit' => $paidAmount,
                        'invoice_id' => $invoice_id,
                        'customer_type' => 1,
                        'debit' => null,
                        'receipt_id' => $receipt_id,
                        'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                        'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]
                );
            } else {
                return response([
                    'status' => 404,
                    'message' => 'Payment record not found',
                    'error_msg' => 'Payment record not found',
                    'data' => null,
                ], 404);
            }
        }
        //   return '4';
         if($check_update){
          // return 'here';
          // update aftre related payment records
          $payments = PaymentOldModel::where('za_old_payments.sno', $pay_sno)
            ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->select(
                'za_old_payments.schedule_date as nextPayDate',
                'za_old_payments.status',
                'za_old_payments.sno',
                'za_old_payments.amount',
                'za_old_payments.paidAmount',
                'za_old_payments.total_amount',
                'za_old_payments.balanceFee',
                'za_old_payments.invoice_id',
                'za_course.course_name',
                'za_course.course_id',
                'za_course_type.course_type_name'
            )
            ->first();
              // Initialize the helper
              if (!$payments) {
                return response()->json(['status' => 404, 'message' => 'Payment record not found']);
            }

           // Initialize the helper
           $helper = new \App\Helpers\Helpers();
            // Encrypt invoice_id & generate print_id
            $responseData = [
                'sno' => $payments->sno,
                'status' => $payments->status,
                'nextPayDate' => $payments->nextPayDate,
                'amount' => $payments->amount,
                'paidAmount' => $payments->paidAmount,
                'balanceFee' => $payments->balanceFee,
                'course_name' => $payments->course_name,
                'course_id' => $payments->course_id,
                'course_type_name' => $payments->course_type_name,
                'invoice_id' => $payments->invoice_id ? $helper->encrypt_decrypt($payments->invoice_id, 'encrypt') : null,
                'print_id' => $helper->encrypt_decrypt(1, 'encrypt') // Encrypt 1 for print_id
            ];
             return response([
                  'status' => 200,
                  'message' => 'Successfully Updated!',
                  'payment_data' => $responseData,
                  'error_msg' => null,
                  'data' => null,
              ], 200);
        }

       
      }
      else{

      $invoice_chk = PaymentModel::where('status', 1)->orderBy('invoice_id', 'desc')->first();
      $year = date("Y");
      if (!$invoice_chk) {
          $invoice_id = 'EA/' . $year . '/INV2005';
      } else {
          $data = $invoice_chk->invoice_id;
          $slice = explode("/", $data);
          if (count($slice) >= 3) {
              $last_inv_number = preg_replace('/[^0-9]/', '', $slice[2]);
              $next_inv_number = $last_inv_number ? (int) $last_inv_number + 1 : 2005;
          } else {
              $next_inv_number = 2005;
          }
          $invoice_id = 'EA/' . $year . '/INV' . str_pad($next_inv_number, 4, '0', STR_PAD_LEFT);
      }
      // return $request->all();
      $get_ids = PaymentModel::where('sno', $pay_sno)->first();

      $pay_course_id = $get_ids->course_id;
      $pay_customer_id = $get_ids->customer_id;

      $total_course_amount = $get_ids->total_amount;
      $balance_Fees = $get_ids->amount - $paidAmount;
      $balanceFees = max(0,  $paidAmount - $get_ids->balanceFee);
      $balanceFeestotal = $get_ids->total_amount;
      $paid_amt = PaymentModel::where('course_id', $pay_course_id)
          ->where('customer_id', $pay_customer_id)
          ->pluck('paidAmount');

      $total_paid_amount = $paid_amt->sum();

      $total_bal = $total_course_amount - $total_paid_amount;


    //   $check_update = false;

      // return $total_bal;

      if ($total_bal == 0 ) { // Corrected comparison

          $user_id = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;
          $payment_up = PaymentModel::where('sno', $pay_sno)->first();
          return $payment_up;
          if ($payment_up) {

              $payment_up->initialPayDate = $initialPayDateFormatted;
              $payment_up->paidAmount = $paidAmount;
              $payment_up->invoice_id = $invoice_id;
              $payment_up->balanceFee = $payment_up->balanceFee;
              $payment_up->payment_mode_label = $paymentMode;
              $payment_up->status = 1;
              $payment_up->save(); // Save changes

              $check_update = true;

              $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
              $training = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
              // dd($training);
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

              // Update or Create Training Model
              $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
              $paidGst = $paidAmount * ($gstPercentage / 100);
              // return $paidAmount;
              TrainingModel::updateOrCreate(
                  ['payment_id' => $payment_up->payment_id],
                  [
                      'paid_amount' => $training->paid_amount + $paidAmount,
                      'paid_gst' => $training->paid_gst + $paidGst,
                      'balance_amount' => $training->balance_amount - $paidAmount,
                      'balance_gst' => $training->balance_gst - $paidGst,
                      'total_amount' => $training->paid_amount + $paidAmount + $paidGst,
                  ]
              );
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training->training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->traning_sno = $training->sno;
              $add_subledger->created_by = $user_id;
              $add_subledger->updated_by = $user_id;

              $add_subledger->save();
              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $paidAmount,
                      'invoice_id' => $invoice_id,
                       'receipt_id' => $receipt_id,
                       'training_id' => $training->sno,
                      'debit' => null,
                      'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]
              );
          } else {
              return response([
                  'status' => 404,
                  'message' => 'Payment record not found',
                  'error_msg' => 'Payment record not found',
                  'data' => null,
              ], 404);
          }
      } else if ($paidAmount == $total_bal) {

          $user_id = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;
          $payment_up = PaymentModel::where('sno', $pay_sno)->first();
          return $user_id;
          $payment_all = PaymentModel::where('course_id', $pay_course_id)
              ->where('customer_id', $pay_customer_id)->get();
          if ($payment_up) {
              $payment_up->initialPayDate = $initialPayDateFormatted;
              $payment_up->paidAmount = $paidAmount;
              $payment_up->invoice_id = $invoice_id;
              $payment_up->payment_mode_label = $paymentMode;
              $payment_up->balanceFee = 0;
              // $payment_up->status = 1;

              $payment_up->update();
               $check_update = true;
              $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
              $training_id = TrainingModel::where('sno', $payment_up->payment_id)->first();
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

              // Update or Create Training Model
              $gstPercentage = $branch->gst_percentage ?? 0; // Default GST percentage to 0 if null
              $paidGst = $payment_up->paidAmount * ($gstPercentage / 100);

              TrainingModel::updateOrCreate(
                  ['payment_id' => $payment_up->payment_id],
                  [
                      'paid_amount' => $training_id->paid_amount + $payment_up->paidAmount,
                      'paid_gst' => $training_id->paid_gst + $paidGst,
                      'balance_amount' => $training_id->balance_amount - $payment_up->paidAmount,
                      'balance_gst' => $training_id->balance_gst - $paidGst,
                      'total_amount' => $training_id->paid_amount + $payment_up->paidAmount + $paidGst,
                  ]
              );

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id = $branch_check->sno;
               $add_subledger->traning_sno = $training_id->sno;
              $add_subledger->created_by = $user_id;
              $add_subledger->updated_by = $user_id;

              $add_subledger->save();
              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $paidAmount,
                      'invoice_id' => $invoice_id,
                       'receipt_id' => $receipt_id,
                       'training_id' => $training_id->sno,
                      'debit' => null,
                      'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]
              );
          }
          if ($payment_all->isNotEmpty()) {
              foreach ($payment_all as $payment) {
                  $payment->status = 1;
                  $payment->save(); // Save each updated payment record
              }
          }
      } else if ($balanceFees <= 0) {
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        return $branch_id;
        $payment_id = PaymentModel::where('sno', $pay_sno)->first();

        $paymentsdetails = PaymentModel::where('customer_id', $payment_id->customer_id)->orderBy('nextPayDate','ASC')->get();
        if ($payment_id) {
          // return $paymentsdetails;
          // Find the index of the current record
          $currentIndex = $paymentsdetails->search(function ($item) use ($pay_sno) {
              return $item->sno == $pay_sno;
          });
          // return $currentIndex;
          // Get the next record in the list
          // if ($currentIndex !== false && isset($paymentsdetails[$currentIndex + 1])) {
          $payment_up = $paymentsdetails[$currentIndex + 1]; // Next record

          // Update the next record
          $payment_up->amount = $paidAmount - $original;
          $payment_up->gst_amount = ($payment_up->amount * 0.18);
           if ($payment_up->amount < 0) {
                    $payment_up->balanceFee -= abs($request->balanceFees);
                }
          $payment_up->status = $payment_up->amount + $request->balanceFees < 0 ? 2:0;
          $payment_up->updated_by = $user_id;
          $payment_up->update();

            if($payment_up->amount < 0){
                  if (isset($paymentsdetails[$currentIndex + 2])) {
                      $next_payment_up = $paymentsdetails[$currentIndex + 2]; // Record after next

                      // Update the second next record
                      $next_payment_up->amount = $next_payment_up->amount + $request->balanceFees; // Adjust as needed
                      $next_payment_up->gst_amount = ($next_payment_up->amount * 0.18);
                      $next_payment_up->balanceFee = $next_payment_up->balanceFee + $request->balanceFees < 0 ? 0 : $next_payment_up->balanceFee + $request->balanceFees;
                      $next_payment_up->updated_by = $user_id;
                      $next_payment_up->status = $next_payment_up->amount + $request->balanceFees < 0 ? 2:0;
                      // return $payment_up;
                      $next_payment_up->update();
                      // return $paymentsdetails;
                  }
                }
            if(isset($next_payment_up) && $next_payment_up->amount < 0){
                  if (isset($paymentsdetails[$currentIndex + 3])) {
                      $nexts_payment_up = $paymentsdetails[$currentIndex + 3]; // Record after next

                      // Update the second next record
                      $nexts_payment_up->amount = $nexts_payment_up->amount + $request->balanceFees; // Adjust as needed
                      $nexts_payment_up->gst_amount = ($nexts_payment_up->amount * 0.18);
                      $nexts_payment_up->balanceFee = $nexts_payment_up->balanceFee + $request->balanceFees < 0 ? 0 : $nexts_payment_up->balanceFee + $request->balanceFees;
                      $nexts_payment_up->updated_by = $user_id;
                      $nexts_payment_up->status = $nexts_payment_up->amount + $request->balanceFees < 0 ? 2:0;
                      // return $payment_up;
                      $nexts_payment_up->update();
                      // return $paymentsdetails;
                  }
                }
            if (isset($nexts_payment_up) && $nexts_payment_up->amount < 0) {
                  if (isset($paymentsdetails[$currentIndex + 4])) {
                      $nexts_payment_up_f = $paymentsdetails[$currentIndex + 4]; // Record after next

                      // Update the second next record
                      $nexts_payment_up_f->amount = $nexts_payment_up_f->amount + $request->balanceFees ; // Adjust as needed
                      $nexts_payment_up_f->gst_amount = ($nexts_payment_up_f->amount * 0.18);
                      $nexts_payment_up_f->updated_by = $user_id;
                      $nexts_payment_up_f->status = $nexts_payment_up_f->amount + $request->balanceFees < 0 ? 2:0;
                      // return $payment_up;
                      $nexts_payment_up_f->update();
                      // return $paymentsdetails;
                  }
                }
     
            if ($payment_up) {
                $payment_id->initialPayDate = $initialPayDateFormatted;
                $payment_id->paidAmount = $paidAmount;
                $payment_id->gst_amount = $paidAmount * 0.18;
                $payment_id->payment_mode_label = $paymentMode;
                // $payment_id->balanceFee = $payment_id->balanceFee - $paidAmount;
                $payment_id->balanceFee = $paidAmount - $original;

                $payment_id->status = 1;
                // return $payment_id;
                $payment_id->update(); // Save changes

                $check_update = true;
                $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                // Update or Create Training Model
                $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                $paidGst = $payment_id->paidAmount * ($gstPercentage / 100);

                TrainingModel::updateOrCreate(
                    ['payment_id' => $payment_id->payment_id],
                    [
                        'paid_amount' => $training_id->paid_amount + $payment_id->paidAmount,
                        'paid_gst' => $training_id->paid_gst + $paidGst,
                        'balance_amount' => $training_id->balance_amount - $payment_id->paidAmount,
                        'balance_gst' => $training_id->balance_gst - $paidGst,
                        'total_amount' => $training_id->total_amount + $payment_id->paidAmount + $paidGst,

                    ]
                );
            }
            $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
            $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
            $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
            $branch_code = $branch_check->branch_code;
            $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

            if (!$ledger_check) {
                $year = date("Y");
                $subledger_id = $year . '/' . $branch_code . '/' . "SUB0001";
            } else {
                $data = $ledger_check->subledger_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int) $result_cos + 1;
                $request_cos = sprintf("SUB%04d", $next_number_cos);
                $year = date("Y");
                $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
            }

            $add_subledger = new SubLedgerModel();
            $add_subledger->ledger_id = 1;
            $add_subledger->subledger_id = $subledger_id;
            $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
            $add_subledger->subledger_desc = 'Students fees';
            $add_subledger->branch_id = $branch_check->sno;
             $add_subledger->traning_sno = $training_id->sno;
            $add_subledger->created_by = $user_id;
            $add_subledger->updated_by = $user_id;

            $add_subledger->save();

            $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
            if (!$tr_check) {
                $year = date("Y");
                $transaction_id = $year . '/' . $branch_code . '/' . "TRA0001";
            } else {
                $data = $tr_check->transaction_id;
                $slice = explode("/", $data);
                $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number_cos = (int) $result_cos + 1;
                $request_tr = sprintf("TRA%04d", $next_number_cos);
                $year = date("Y");
                $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
            }
            TransactionModel::updateOrCreate(
                [
                    'branch_id' => $branch_check->sno,
                    'transaction_id' => $transaction_id,
                    'transaction_type' => 'Credit',
                    'transaction_name' => 'Customer',
                    'trans_source_id' => $customer->customer_id,
                    'ledger_id' => 1,
                    'subledger_id' => $add_subledger->sno,
                    'credit' => $paidAmount,
                    'invoice_id' => $invoice_id,
                     'receipt_id' => $receipt_id,
                     'training_id' => $training_id->sno,
                    'debit' => null,
                    'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                    'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]
            );
        } else {
            return response([
                'status' => 404,
                'message' => 'Payment record not found',
                'error_msg' => 'Payment record not found',
                'data' => null,
            ], 404);
        }
      } else {

          $user_id = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;
          // return 'else';
          $payment_id = PaymentModel::where('sno', $pay_sno)->first();
          if ($payment_id) {
              $payment_up = new PaymentModel();
              $payment_up->payment_id = $payment_id->payment_id;
              $payment_up->customer_id = $payment_id->customer_id;
              $payment_up->course_id = $payment_id->course_id;
              $payment_up->initialPayDate = $payment_id->nextPayDate;
              $payment_up->nextPayDate = $payment_id->nextPayDate;
              $payment_up->amount = $balance_Fees;

              $payment_up->paidAmount = 0;
              $payment_up->gst_amount = $balance_Fees * 0.18;
              $payment_up->payment_mode_label = $paymentMode;
              $payment_up->balanceFee = $payment_id->balanceFee;
              // $payment_up->balanceFee = $payment_id->balanceFee + $balance_Fees;

              $payment_up->total_amount = $payment_id->total_amount;
              $payment_up->created_by = $user_id;
              $payment_up->updated_by = $user_id;
              $payment_up->branch_id = $request->user()->branch_id;
               $payment_up->status = $balance_Fees < 0 ? 2:0;
              // return $payment_up;
              $payment_up->save(); // Save new record

               $check_update = true;

              if ($payment_up) {

                  $payment_id->initialPayDate = $initialPayDateFormatted;
                  $payment_id->paidAmount = $paidAmount;
                  $payment_id->invoice_id = $invoice_id;
                  $payment_id->gst_amount = $paidAmount * 0.18;
                  $payment_id->payment_mode_label = $paymentMode;
                  // $payment_id->balanceFee = $payment_id->balanceFee - $paidAmount;
                  $payment_id->balanceFee = $payment_id->balanceFee + $balance_Fees;

                  $payment_id->status = 1;
                  // return $payment_id;
                  $payment_id->update(); // Save changes

                   $check_update = true;
                  $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();

                  $training_id = TrainingModel::where('payment_id', $payment_id->payment_id)->first();
                  // Update or Create Training Model
                  $gstPercentage = $branch_check->gst_percentage ?? 0; // Default GST percentage to 0 if null
                  $paidGst = $payment_id->paidAmount * ($gstPercentage / 100);

                  TrainingModel::updateOrCreate(
                      ['payment_id' => $payment_id->payment_id],
                      [
                          'paid_amount' => $training_id->paid_amount + $payment_id->paidAmount,
                          'paid_gst' => $training_id->paid_gst + $paidGst,
                          'balance_amount' => $training_id->balance_amount - $payment_id->paidAmount,
                          'balance_gst' => $training_id->balance_gst - $paidGst,
                          'total_amount' => $training_id->total_amount + $payment_id->paidAmount + $paidGst,

                      ]
                  );
              }
              $customer = CustomerModel::where('sno', $payment_up->customer_id)->first();
              $training_id = TrainingModel::where('payment_id', $payment_up->payment_id)->first();
              $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
              $branch_code = $branch_check->city_short_code;
              $ledger_check = SubLedgerModel::where('status', '!=', 2)->where('ledger_id', 1)->orderBy('sno', 'desc')->first();

              if (!$ledger_check) {
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . "SUB2005";
              } else {
                  $data = $ledger_check->subledger_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_cos = sprintf("SUB%04d", $next_number_cos);
                  $year = date("Y");
                  $subledger_id = $year . '/' . $branch_code . '/' . $request_cos;
              }

              $add_subledger = new SubLedgerModel();
              $add_subledger->ledger_id = 1;
              $add_subledger->subledger_id = $subledger_id;
              $add_subledger->subledger_name = ucfirst($customer->cus_name) . ' - ' . $training_id->training_id;
              $add_subledger->subledger_desc = 'Students fees';
              $add_subledger->branch_id = $branch_check->sno;
              $add_subledger->traning_sno = $training_id->sno;
              $add_subledger->created_by = $user_id;
              $add_subledger->updated_by = $user_id;

              $add_subledger->save();

              $tr_check = TransactionModel::orderBy('sno', 'desc')->first();
              if (!$tr_check) {
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . "TRA2005";
              } else {
                  $data = $tr_check->transaction_id;
                  $slice = explode("/", $data);
                  $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
                  $next_number_cos = (int) $result_cos + 1;
                  $request_tr = sprintf("TRA%04d", $next_number_cos);
                  $year = date("Y");
                  $transaction_id = $year . '/' . $branch_code . '/' . $request_tr;
              }
              TransactionModel::updateOrCreate(
                  [
                      'branch_id' => $branch_check->sno,
                      'transaction_id' => $transaction_id,
                      'transaction_type' => 'Credit',
                      'transaction_name' => 'Customer',
                      'trans_source_id' => $customer->customer_id,
                      'ledger_id' => 1,
                      'subledger_id' => $add_subledger->sno,
                      'credit' => $paidAmount,
                       'receipt_id' => $receipt_id,
                      'invoice_id' => $invoice_id,
                       'training_id' => $training_id->sno,
                      'debit' => null,
                      'tax' => $paidAmount * $branch_check->gst_percentage / 100, // 18% tax calculation
                      'total_amount' => $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0,
                      'created_by' => $user_id,
                      'updated_by' => $user_id,
                  ]
              );
          } else {
              return response([
                  'status' => 404,
                  'message' => 'Payment record not found',
                  'error_msg' => 'Payment record not found',
                  'data' => null,
              ], 404);
          }
      }
      //payment list
        if($check_update){
          // update aftre related payment records
          $payments = PaymentModel::where('za_payment.sno', $pay_sno)
            ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->select(
                'za_payment.nextPayDate',
                'za_payment.status',
                'za_payment.sno',
                'za_payment.amount',
                'za_payment.paidAmount',
                'za_payment.total_amount',
                'za_payment.balanceFee',
                'za_course.course_name',
                'za_course.course_id',
                'za_course_type.course_type_name'
            )
            ->first();
              // Initialize the helper
              if (!$payments) {
                return response()->json(['status' => 404, 'message' => 'Payment record not found']);
            }

          // Initialize the helper
          $helper = new \App\Helpers\Helpers();

            // Encrypt invoice_id & generate print_id
            $responseData = [
                'sno' => $payments->sno,
                'status' => $payments->status,
                'nextPayDate' => $payments->nextPayDate,
                'amount' => $payments->amount,
                'paidAmount' => $payments->paidAmount,
                'balanceFee' => $payments->balanceFee,
                'course_name' => $payments->course_name,
                'course_id' => $payments->course_id,
                'course_type_name' => $payments->course_type_name,
                'invoice_id' => $payments->invoice_id ? $helper->encrypt_decrypt($payments->invoice_id, 'encrypt') : null,
                'print_id' => $helper->encrypt_decrypt(1, 'encrypt') // Encrypt 1 for print_id
            ];
             return response([
              'status' => 200,
              'message' => 'Successfully Updated!',
              'payment_data' => $responseData,
              'error_msg' => null,
              'data' => null,
          ], 200);
        }
        
        if ($check_update) {
         $tempdate = PaymentModel::where('branch_id', $branch_id)->where('customer_id', $customer->sno)->where('course_id', $pay_course_id)->orderBy('sno', 'desc')->first();
          //   Send Communication
          $branch_data = BranchModel::where('sno', $branch_id)->first();
          $branch_name = " ";
          if ($branch_data->branch_type == 1) {
              $branch_name = $branch_data->branch_name;
          } elseif ($branch_data->branch_type == 2) {
              $branch_name = $branch_data->franchise_name;
          }

          //   SMS
          $customer_mobiles = isset($customer->cus_mobile) ? $customer->cus_mobile : '';
          $customer_mails   = isset($customer->cus_email_id) ? $customer->cus_email_id : '';
          $customer_names   = isset($customer->cus_name) ? $customer->cus_name : 'Mr/Mrs';
          $cre_mobile       = isset($branch_data->cre_mobile) ? $branch_data->cre_mobile : '9677781155';
          $totalAmount      = $paidAmount + $paidAmount * $branch_check->gst_percentage / 100 ?? 0;

           if ($transaction_id && $customer_mobiles) {
               $branch_data     = BranchModel::where('sno', $branch_id)->first();
               $result_sms_pay  = SmsTemplateModel::where('status', 0)->where('template_name', '005_PaymentSuccess')->first();
               $authkey         = $result_sms_pay ? $result_sms_pay->authkey : '';
               $sender_id       = $result_sms_pay ? $result_sms_pay->sender_id : '';
               $template_id     = $result_sms_pay ? $result_sms_pay->template_id : '';
               $country_code    = $result_sms_pay ? $result_sms_pay->country_code : '';
               $message_content = $result_sms_pay ? $result_sms_pay->sms_template_messagecontent : '';
               $mobile_number   = $country_code . $customer_mobiles;

               // Replace placeholders with actual values
               $replacement_values = [$customer_names, $totalAmount, $transaction_id];
               $message_content    = preg_replace_callback(
                   '/\{#var#\}/',
                   function () use (&$replacement_values) {
                       return array_shift($replacement_values);
                   },
                   $message_content
               );

               $route    = "default";
               $postData = [
                   'authkey' => $authkey,
                   'mobiles' => $mobile_number,
                   'message' => $message_content,
                   'sender'  => $sender_id,
                   'route'   => $route,
               ];

               // API URL
               $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

               // Initialize the resource
               $ch = curl_init();
               curl_setopt_array($ch, [
                   CURLOPT_URL            => $url,
                   CURLOPT_RETURNTRANSFER => true,
                   CURLOPT_POST           => true,
                   CURLOPT_POSTFIELDS     => $postData,
                   CURLOPT_SSL_VERIFYHOST => 0,
                   CURLOPT_SSL_VERIFYPEER => 0,
               ]);
               // Get response
               $response = curl_exec($ch);
               // return $response;
               $err = curl_error($ch);
               curl_close($ch);

           }
           // Email
           if ($transaction_id && $customer_mails) {
               $cre = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();

               $email_template_id = 18; // thank you template
               $emailTemplate     = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
               $coursename        = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();

               $dynamicSubject = str_replace('#course', $coursename->course_name ?? 'Course', $emailTemplate->email_name);

               $helper             = new \App\Helpers\Helpers();
               $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
               $paymentDate        = date($common_date_format);
               // $paymentDate        = $tempdate->initialPayDate;
               $paymentAmt         = number_format($totalAmount, 2, '.', ',');
               $paymentAmount      = $paymentAmt . ". Rs";
               $content            = $emailTemplate->email_subject;
               $content            = str_replace('#name', $customer_names, $content);
               $content            = str_replace('#course', $coursename->course_name ?? 'Course', $content);
               $content            = str_replace('#transactionId', $transaction_id, $content);
               $content            = str_replace('#amount', $paymentAmount, $content);
               $content            = str_replace('#transactionDate', $paymentDate, $content);
               $content            = str_replace('#mail', $branch_data->mail ?? 'info@elysiumacademy.org', $content);
               $branchNo           = $branch_data->mobile ?? '9677781155';
               $branchemail        = $branch_data->mail ?? 'info@elysiumacademy.org';
               $fbLink             = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
               $instaLink          = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';
               $content            = str_replace('#CRENo', $branch_data->cre_mobile ?? '9677781155', $content);
               $content            = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);

               $mailData = [
                   'url'         => 'Eapl.com',
                   'subject'     => $dynamicSubject,
                   'content'     => $content,
                   'branchNo'    => $branchNo,
                   'branchemail' => $branchemail, // Use the message content from the request
                   'fbLink'      => $fbLink,      // Use the message content from the request
                   'instaLink'   => $instaLink,   // Use the message content from the request
                   'salesMobile' => $branch_data->sales_mobile ?? '9677781155',
               ];

               $to_address   = $customer_mails;
               $from_address = 'elysiumacademy@elysium.community';
               $from_name    = 'Elysium Academy®';

               Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

           }
           // Whatsapp messages
           if ($transaction_id && $customer_mobiles) {
               $coursename = ManageCoursesModel::where('status', 0)->where('sno', $pay_course_id)->first();
               $cre        = StaffModel::where('sno', $branch_data->cre_id)->orderBy('sno', 'desc')->first();
               $hasHeader  = false; // Example flag: set based on template
               $hasBody    = false; // Example flag: set based on template
               $components = [];
               $couponCode = " ";

               // Example flag: set based on template
               $components_trans = [];
               date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
               $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
               if ($currentHour >= 5 && $currentHour < 12) {
                   $greeting = 'Good Morning';
               } elseif ($currentHour >= 12 && $currentHour < 18) {
                   $greeting = 'Good Afternoon';
               } else {
                   $greeting = 'Good Evening';
               }
               $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
               $paymentDate        = date($common_date_format);
               // $paymentDate        = $tempdate->initialPayDate;
               $paymentAmt         = number_format($totalAmount, 2, '.', ',');
               $paymentAmount      = $paymentAmt . ". Rs";

               $templateName = 'elysium_academy_pay_transaction2';
               $headerImage  = 'https://erp.elysium.academy/public/assets/eapl_images/Payment_success.jpg';
               $bodyText     = [
                   [
                       'type'           => 'text',
                       'text'           => $greeting,
                       'parameter_name' => 'greet_msg',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $customer_names,
                       'parameter_name' => 'customer_name',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $coursename->course_name ?? 'Course',
                       'parameter_name' => 'course_name',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $transaction_id,
                       'parameter_name' => 'transaction_id',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $paymentAmount,
                       'parameter_name' => 'amount',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $paymentDate,
                       'parameter_name' => 'pay_date',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $branch_data->cre_mobile ?? '9677781155',
                       'parameter_name' => 'contact_no',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
                       'parameter_name' => 'contact_email',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $branch_name ?? 'Elysium Academy',
                       'parameter_name' => 'branch_name',
                   ],
                   [
                       'type'           => 'text',
                       'text'           => $branch_data->sales_mobile ?? '9677781155',
                       'parameter_name' => 'contact_no2',
                   ],

               ];
               $components_trans[] = [
                   'type'       => 'header',
                   'parameters' => [
                       [
                           'type'  => 'image',
                           'image' => [
                               'link' => $headerImage, // Dynamically set header image
                           ],
                       ],
                   ],
               ];

               $components_trans[] = [
                   'type'       => 'body',
                   'parameters' => $bodyText,
               ];
               $dynamicParameters         = $templateParameters[$templateName] ?? [];
               $WhatsAppBusinessAccountId = $this->businessId;
               $accessToken               = $this->accessToken;
               $fromPhoneNumberId         = $this->phoneNumberId;

               $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

               $to           = $customer_mobiles;
               $languageCode = 'en';

               if (strpos($to, '+91') !== 0) {
                   $to = '+91' . $to;
               }

               $message = 'test~message';

               $payload = [
                   'messaging_product' => 'whatsapp',
                   'to'                => $to,
                   'type'              => 'template',
                   'template'          => [
                       'name'       => $templateName,
                       'language'   => [
                           'code' => $languageCode,
                       ],
                       'components' => $components_trans,
                   ],
               ];

               $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

           }

        }
    }
    
      

  }
  
   public function finalpayresult(Request $request)
   {
      $branch_id = $request->user()->branch_id;
      $pay_sno = $request->data;

        // return $request->all();
        $old_customer = $request->input('old_customer') === 'true'; // Ensure it's a boolean

        if($old_customer){

          $payments = PaymentOldModel::where('za_old_payments.sno', $pay_sno['sno'])
            ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->select(
                'za_old_payments.schedule_date as nextPayDate',
                'za_old_payments.status',
                'za_old_payments.sno',
                'za_old_payments.amount',
                'za_old_payments.paidAmount',
                'za_old_payments.total_amount',
                'za_old_payments.balanceFee',
                'za_old_payments.invoice_id',
                'za_course.course_name',
                'za_course.course_id',
                'za_course_type.course_type_name'
            )
            ->first();
              // Initialize the helper
              if (!$payments) {
                return response()->json(['status' => 404, 'message' => 'Payment record not found']);
            }

          // Initialize the helper
          $helper = new \App\Helpers\Helpers();

            // Encrypt invoice_id & generate print_id
            $responseData = [
                'sno' => $payments->sno,
                'status' => $payments->status,
                'nextPayDate' => $payments->nextPayDate,
                'amount' => $payments->amount,
                'paidAmount' => $payments->paidAmount,
                'balanceFee' => $payments->balanceFee,
                'course_name' => $payments->course_name,
                'course_id' => $payments->course_id,
                'course_type_name' => $payments->course_type_name,
                'old_customer' => true,
               'invoice_id' => $pay_sno['invoice_id'] ?? null,
                'print_id' => $helper->encrypt_decrypt(1, 'encrypt') // Encrypt 1 for print_id
            ];
        }else{
                // update aftre related payment records
                $payments = PaymentModel::where('za_payment.sno', $pay_sno['sno'])
                ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
                ->select(
                    'za_payment.nextPayDate',
                    'za_payment.status',
                    'za_payment.sno',
                    'za_payment.amount',
                    'za_payment.paidAmount',
                    'za_payment.invoice_id',
                    'za_payment.total_amount',
                    'za_payment.balanceFee',
                    'za_course.course_name',
                    'za_course.course_id',
                    'za_course_type.course_type_name'
                )
                ->first();
                  // Initialize the helper
                  if (!$payments) {
                    return response()->json(['status' => 404, 'message' => 'Payment record not found']);
                }

                // Initialize the helper
                $helper = new \App\Helpers\Helpers();

                // Encrypt invoice_id & generate print_id
                $responseData = [
                    'sno' => $payments->sno,
                    'status' => $payments->status,
                    'nextPayDate' => $payments->nextPayDate,
                    'amount' => $payments->amount,
                    'paidAmount' => $payments->paidAmount,
                    'balanceFee' => $payments->balanceFee,
                    'course_name' => $payments->course_name,
                    'course_id' => $payments->course_id,
                    'course_type_name' => $payments->course_type_name,
                     'old_customer' => false,
                     'invoice_id' => $pay_sno['invoice_id'] ?? null,
                    'print_id' => $helper->encrypt_decrypt(1, 'encrypt') // Encrypt 1 for print_id
                ];
        }

          return response([
            'status' => 200,
            'message' => 'Successfully Updated!',
            'payment_data' => $responseData,
            'error_msg' => null,
            'data' => null,
        ], 200);
  }


}
