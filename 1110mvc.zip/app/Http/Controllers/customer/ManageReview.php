<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ReviewModel;
use App\Models\CustomerModel;
use App\Models\ReviewLinkModel;
use App\Models\GoalSetStaffModel;
use App\Models\StaffModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use App\Models\TrainingModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateInterval;
use DateTime;
use DatePeriod;

class ManageReview extends Controller
{
  public function index(Request $request)
  {
    $perpage = (int) $request->input('sorting_filter', 25);
        
    $pageConfigs = [
        'myLayout' => 'default'
    ];

    if(auth()->user()->hasPermission('Customer Management','List', 'Manage Review')) {
        return view('content.customer.manage_review.reviews_list', [
            'pageConfigs' => $pageConfigs,
            'perpage' => $perpage
        ]);
    }else{
        return view('content.bugs_list.unauth_list');
    }
  }

  public function manage_review_ajax(Request $request)
  {
      $branch_id = $request->user()->branch_id;

      $type = $request->input('type', 'monthly'); // monthly | yearly
      $perPage = (int) $request->input('sorting_filter', 25);
      $page = (int) $request->input('page', 1);

      $rating_filter = $request->rating_value ?? 0;
      $staff_filter  = $request->rating_staff_value ?? 'all';

      $helper     = new \App\Helpers\Helpers();

      // Review Query
      $query = ReviewModel::select(
              'za_review.*',
              'za_customer.customer_id as customer_code',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_gender',
              'za_customer.cus_pic'
          )
          ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_review.customer_id')
          ->where('za_review.branch_id', $branch_id)
          ->where('za_review.status', 0);

      // Summary Query
      $summary = ReviewModel::where('branch_id', $branch_id)
          ->where('status', 0);

      if ($type == 'monthly') {

          $request->validate([
          'month' => 'required|integer|min:1|max:12',
          'year'  => 'required|integer'
          ]);

          $query->whereMonth('za_review.created_at', $request->month)->whereYear('za_review.created_at', $request->year);

          $summary->whereMonth('created_at', $request->month)->whereYear('created_at', $request->year);

      } elseif ($type == 'yearly') {

          $request->validate([
          'year' => 'required|integer'
          ]);

          $query->whereYear('za_review.created_at', $request->year);

          $summary->whereYear('created_at', $request->year);
      }

      // Review Link Master
      $reviewLinks = ReviewLinkModel::select('sno', 'review_name')
      ->get()
      ->pluck('review_name', 'sno');

      $reviewLinksDesc = ReviewLinkModel::select('sno', 'review_name', 'review_desc')
      ->get()
      ->keyBy('sno');

      /*
      |--------------------------------------------------------------------------
      | Rating Filter
      |--------------------------------------------------------------------------
      */

      if ($rating_filter != 0) {
          $query->where('za_review.rating', (int)$rating_filter);
          // $summary->where('rating', (int)$rating_filter);
      }

      /*
      |--------------------------------------------------------------------------
      | Staff Filter
      |--------------------------------------------------------------------------
      */

      if ($staff_filter != 'all') {
          $query->where('za_review.created_by', (int)$staff_filter);
          $summary->where('created_by', (int)$staff_filter);
      }

      // Review List
      $reviews = $query
          ->orderByDesc('za_review.created_at')
          ->paginate($perPage, ['*'], 'page', $page);

      // Add review_links (sno => true/false)
      $reviews->getCollection()->transform(function ($review) use ($reviewLinks, $helper) {

          $selectedLinks = collect(json_decode($review->review_list, true) ?? [])
              ->pluck('link')
              ->map(fn($id) => (int) $id)
              ->flip();

          $review_encrypt_id  = $helper->encrypt_decrypt($review->sno,'encrypt');

          $review_links = [];
          $review_links_list = [];

          foreach ($reviewLinks as $sno => $name) {

              $selected = isset($selectedLinks[$sno]);

              $review_links[] = [
                  'sno'              => (int) $sno,
                  'review_link_name' => $name,
                  'selected'         => $selected,
              ];

              $review_links_list[$sno] = $selected;
          }

          // Assign once (don't modify Eloquent attributes directly)
          $review->review_links = $review_links;
          $review->review_links_list = $review_links_list;
          $review->review_encrypt_id = $review_encrypt_id;


          $customer_image_path = 'cus_pics/';

          $customer_image_full_path = !empty($review->cus_pic)
              ? $customer_image_path . $review->cus_pic
              : '';

          $customer_backgrounds = [];
          $customer_bg_color = '';
          $customer_bg_text_color = '';

          if (!$customer_image_full_path || !file_exists(public_path($customer_image_full_path))) {

              $customer_backgrounds = $this->generateAvatarColors((int) $review->customer_id);

              $customer_bg_color = $customer_backgrounds['bg'] ?? '#e4e6ef';
              $customer_bg_text_color = $customer_backgrounds['text'] ?? '#000';
          }

          if ($customer_image_full_path && file_exists(public_path($customer_image_full_path))) {

              $review->customer_img_html =
                  '<img src="' . asset($customer_image_full_path) . '" class="rounded-circle w-50px h-50px" style="object-fit:cover;box-shadow: rgba(0,0,0,.16) 0px 3px 6px, rgba(0,0,0,.23) 0px 3px 6px;">';

          } else {

              $review->customer_img_html =
                  '<div class="avatar">
                      <span class="avatar-initial rounded-circle"
                          style="background-color:' . $customer_bg_color . ';color:' . $customer_bg_text_color . ';">
                          ' . strtoupper(substr($review->cus_name ?? 'U', 0, 1)) . '
                      </span>
                  </div>';
          }

          $review_staff_details = StaffModel::select('sno', 'staff_name', 'staff_image')->where('sno', $review->created_by)->first();
          $review->review_staff_details = $review_staff_details;

          return $review;
      });

      // Rating Summary (Single Query)
      $counts = $summary->selectRaw("
          COUNT(*) as total_reviews,
          SUM(rating = 5) as star_5,
          SUM(rating = 4) as star_4,
          SUM(rating = 3) as star_3,
          SUM(rating = 2) as star_2,
          SUM(rating = 1) as star_1
      ")
      ->first();

      /*
      |--------------------------------------------------------------------------
      | Staff List
      |--------------------------------------------------------------------------
      */

      $staff_list = ReviewModel::select(
          'za_review.created_by',
          'za_staff.staff_name',
          'za_staff.staff_image'
      )
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_review.created_by')
      ->where('za_review.branch_id', $branch_id)
      ->where('za_review.status', 0)

      ->when($type == 'monthly', function ($q) use ($request) {
          $q->whereMonth('za_review.created_at', $request->month)
              ->whereYear('za_review.created_at', $request->year);
      })

      ->when($type == 'yearly', function ($q) use ($request) {
          $q->whereYear('za_review.created_at', $request->year);
      })

      ->when($rating_filter != '0', function ($q) use ($rating_filter) {
          $q->where('za_review.rating', $rating_filter);
      })

      ->groupBy(
          'za_review.created_by',
          'za_staff.staff_name',
          'za_staff.staff_image'
      )
      ->orderBy('za_staff.staff_name')
      ->get();

      $total_reviews = isset($counts->total_reviews) && !empty($counts->total_reviews) ? (int)$counts->total_reviews : 0;
      $star_5 = isset($counts->star_5) && !empty($counts->star_5) ? (int)$counts->star_5 : 0;
      $star_4 = isset($counts->star_4) && !empty($counts->star_4) ? (int)$counts->star_4 : 0;
      $star_3 = isset($counts->star_3) && !empty($counts->star_3) ? (int)$counts->star_3 : 0;
      $star_2 = isset($counts->star_2) && !empty($counts->star_2) ? (int)$counts->star_2 : 0;
      $star_1 = isset($counts->star_1) && !empty($counts->star_1) ? (int)$counts->star_1 : 0;

      foreach ($staff_list as $staff) {

          $staff_total_reviews = ReviewModel::where('branch_id', $branch_id)
          ->where('status', 0)
          ->where('created_by', $staff->created_by)
          ->when($type == 'monthly', function ($q) use ($request) {
              $q->whereMonth('created_at', $request->month)
              ->whereYear('created_at', $request->year);
          })
          ->when($type == 'yearly', function ($q) use ($request) {
              $q->whereYear('created_at', $request->year);
          })
          ->when($rating_filter != '0', function ($q) use ($rating_filter) {
              $q->where('rating', $rating_filter);
          })
          ->count();

          $staff->total_reviews = $staff_total_reviews ?? 0;

          $staff->review_percentage = $total_reviews > 0 ? round(($staff_total_reviews / $total_reviews) * 100, 1) : 0;

          $staff_image_path = 'staff_images/';

          $staff_image_full_path = !empty($staff->staff_image)
              ? $staff_image_path . $staff->staff_image
              : '';

          $staff_backgrounds = [];
          $staff_bg_color = '';
          $staff_bg_text_color = '';

          if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {

              $staff_backgrounds = $this->generateAvatarColors((int) $staff->sno);

              $staff_bg_color = $staff_backgrounds['bg'] ?? '#e4e6ef';
              $staff_bg_text_color = $staff_backgrounds['text'] ?? '#000';
          }

          if ($staff_image_full_path && file_exists(public_path($staff_image_full_path))) {

              $staff->staff_img_html =
                  '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="object-fit:cover;box-shadow: rgba(0,0,0,.16) 0px 3px 6px, rgba(0,0,0,.23) 0px 3px 6px;">';

          } else {

              $staff->staff_img_html =
                  '<div class="avatar">
                      <span class="avatar-initial rounded-circle"
                          style="background-color:' . $staff_bg_color . ';color:' . $staff_bg_text_color . ';">
                          ' . strtoupper(substr($staff->staff_name ?? 'U', 0, 1)) . '
                      </span>
                  </div>';
          }

          // Goal Target
          $goalQuery = GoalSetStaffModel::where('branch_id', $branch_id)
              ->where('staff_id', $staff->created_by)
              ->where('status', '!=', 2);

          if ($type == 'monthly') {
              $goalQuery->whereMonth('goal_date', $request->month)->whereYear('goal_date', $request->year);
          } else {
              $goalQuery->whereYear('goal_date', $request->year);
          }

          $target_reviews = (int) $goalQuery->selectRaw('goal_date, staff_id, status, no_of_reviews')->groupBy('goal_date', 'staff_id', 'status', 'no_of_reviews')->get()->sum('no_of_reviews');

          $staff->target_reviews = $target_reviews;
          $staff->achieved_reviews = $staff_total_reviews;
          $staff->remaining_reviews = max(0, $target_reviews - $staff_total_reviews);

          $staff->achievement_percentage = $target_reviews > 0
              ? round(($staff_total_reviews / $target_reviews) * 100, 1)
              : 0;

          $staff->goal_status = $staff_total_reviews >= $target_reviews
              ? 'Completed'
              : 'Pending';
      }

      return response()->json([
          'status'  => true,
          'message' => 'Review List',
          'link_list' => $reviewLinks,
          'link_list_desc' => $reviewLinksDesc,
          'filters' => [
              'rating_filter' => $rating_filter,
              'staff_filter' => $staff_filter,
              'staff_list' => $staff_list,
          ],
          'mini_dashboard' => [
              'total_reviews' => [
                  'label' => 'Total Reviews',
                  'value' => $total_reviews,
                  'icon'  => 'ki-outline ki-star',
                  'color' => 'primary',
                  'tooltip' => 'Total Reviews'
              ],
              'rating_breakdown' => [
                  [
                      'rating' => 5,
                      'count' => $star_5,
                      'label' => 'Excellent (5★)',
                      'color' => 'success',
                      'icon' => 'ki-outline ki-star',
                      'percentage' => $total_reviews > 0
                      ? round(($star_5 / $total_reviews) * 100, 1)
                      : 0
                  ],
                  [
                      'rating' => 4,
                      'count' => $star_4,
                      'label' => 'Good (4★)',
                      'color' => 'info',
                      'icon' => 'ki-outline ki-star',
                      'percentage' => $total_reviews > 0
                      ? round(($star_4 / $total_reviews) * 100, 1)
                      : 0
                  ],
                  [
                      'rating' => 3,
                      'count' => $star_3,
                      'label' => 'Average (3★)',
                      'color' => 'warning',
                      'icon' => 'ki-outline ki-star',
                      'percentage' => $total_reviews > 0
                      ? round(($star_3 / $total_reviews) * 100, 1)
                      : 0
                  ],
                  [
                      'rating' => 2,
                      'count' => $star_2,
                      'label' => 'Poor (2★)',
                      'color' => 'danger',
                      'icon' => 'ki-outline ki-star',
                      'percentage' => $total_reviews > 0
                      ? round(($star_2 / $total_reviews) * 100, 1)
                      : 0
                  ],
                  [
                      'rating' => 1,
                      'count' => $star_1,
                      'label' => 'Bad (1★)',
                      'color' => 'dark',
                      'icon' => 'ki-outline ki-star',
                      'percentage' => $total_reviews > 0
                      ? round(($star_1 / $total_reviews) * 100, 1)
                      : 0
                  ]
              ],
              'summary' => [
                  'total_reviews' => (int) ($total_reviews ?? 0),
                  'star_5'        => (int) ($star_5 ?? 0),
                  'star_4'        => (int) ($star_4 ?? 0),
                  'star_3'        => (int) ($star_3 ?? 0),
                  'star_2'        => (int) ($star_2 ?? 0),
                  'star_1'        => (int) ($star_1 ?? 0),
              ],
          ],
          'data' => $reviews
      ]);
  }

  public function Add(Request $request)
  {
    try {

        $validator = Validator::make($request->all(), [
            'review_action_type' => 'required|in:1,2',
            'customer_id'        => 'required|integer',
            'rating'             => 'required|integer|min:1|max:5',
            'goolgle_rv'         => 'required|string',
            'review_links'       => 'nullable|array',
        ]);

        if ($validator->fails()) {

            return response()->json([
                'status'    => 401,
                'message'   => 'Validation Failed',
                'error_msg' => $validator->errors()
            ]);
        }

        $action_type = (int)$request->review_action_type;

        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $customer_id  = $request->customer_id;
        $rating       = $request->rating;
        $review       = trim($request->goolgle_rv);
        $review_image = !empty($request->review_image) ? 1 : 0;

        $review_links = $request->review_links ?? [];

        if ($action_type == 1) {

            /*
            |--------------------------------------------------------------------------
            | Generate Review ID
            |--------------------------------------------------------------------------
            */

            $last = ReviewModel::where('status', '!=', 2)
                ->orderByDesc('sno')
                ->first();

            if (!$last) {

                $review_id = 'RV-0001/' . date('y');

            } else {

                preg_match('/RV-(\d+)/', $last->review_id, $match);

                $next = isset($match[1]) ? ((int)$match[1]) + 1 : 1;

                $review_id = 'RV-' . sprintf('%04d', $next) . '/' . date('y');
            }

            $reviewModel = new ReviewModel();

            $reviewModel->review_id = $review_id;
            $reviewModel->created_by = $user_id;

            $message = 'Review Successfully Added!';

        } else {

            /*
            |--------------------------------------------------------------------------
            | Update
            |--------------------------------------------------------------------------
            */

            $helper     = new \App\Helpers\Helpers();
            $review_id  = $helper->encrypt_decrypt($request->review_id,'decrypt');

            if (empty($review_id)) {

                return response()->json([
                    'status'  => 401,
                    'message' => 'Review ID is Required!'
                ]);
            }

            $reviewModel = ReviewModel::where('sno', $review_id)
                ->where('status', '!=', 2)
                ->first();

            if (!$reviewModel) {

                return response()->json([
                    'status'  => 404,
                    'message' => 'Review Not Found!'
                ]);
            }

            $message = 'Review Successfully Updated!';
        }

        /*
        |--------------------------------------------------------------------------
        | Save
        |--------------------------------------------------------------------------
        */

        $reviewModel->customer_id  = $customer_id;
        $reviewModel->rating       = $rating;
        $reviewModel->review       = $review;
        $reviewModel->review_image = $review_image;
        $reviewModel->review_list  = json_encode($review_links);

        $reviewModel->branch_id  = $branch_id;
        $reviewModel->updated_by = $user_id;

        $reviewModel->save();

        return response()->json([
            'status'  => 200,
            'message' => $message,
            'data'    => [
                'review_id' => $reviewModel->sno
            ]
        ]);

    } catch (\Exception $e) {

        return response()->json([
            'status'  => 500,
            'message' => $e->getMessage()
        ]);
    }
  }

  public function Edit($id, Request $request)
  {
      try {

          if (!$id) {
              return response()->json([
                  'status'  => 500,
                  'message' => 'Review ID Not Found!'
              ]);
          }

          $helper     = new \App\Helpers\Helpers();
          $review_id  = $helper->encrypt_decrypt($id,'decrypt');

          $review = ReviewModel::select(
              'za_review.*',
              'za_customer.customer_id as customer_code',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_gender',
              'za_customer.cus_pic'
          )
          ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_review.customer_id')
          ->where('za_review.sno', $review_id)
          ->where('za_review.status', '!=', 2)
          ->first();

          if (!$review) {

              return response()->json([
                  'status'  => 404,
                  'message' => 'Review Not Found!'
              ]);
          }

          /*
          |--------------------------------------------------------------------------
          | Review Link Master
          |--------------------------------------------------------------------------
          */

          $reviewLinks = ReviewLinkModel::select(
              'sno',
              'review_name',
              'review_desc'
          )
          ->where('status', '!=', 2)
        //   ->orderBy('review_name ', 'ASC')
          ->get();

          /*
          |--------------------------------------------------------------------------
          | Selected Links
          |--------------------------------------------------------------------------
          */

          $selectedLinks = collect(json_decode($review->review_list, true) ?? [])
              ->keyBy('link');

          $review_links = [];
          $review_links_list = [];

          foreach ($reviewLinks as $link) {

              $selected = $selectedLinks->has($link->sno);

              $review_links[] = [
                  'sno'              => $link->sno,
                  'review_link_name' => $link->review_name,
                  'review_link_desc' => $link->review_desc,
                  'selected'         => $selected,
                  'desc'             => $selected
                      ? ($selectedLinks[$link->sno]['desc'] ?? null)
                      : null,
              ];

              $review_links_list[$link->sno] = $selected;
          }

          $review->review_links = $review_links;
          $review->review_links_list = $review_links_list;
          
          $review_encrypt_id  = $helper->encrypt_decrypt($review->sno,'encrypt');
          $review->review_encrypt_id = $review_encrypt_id;

          return response()->json([
              'status'  => 200,
              'message' => 'Review Details Loaded Successfully!',
              'data'    => $review
          ]);

      } catch (\Exception $e) {

          return response()->json([
              'status'  => 500,
              'message' => $e->getMessage()
          ]);
      }
  }

  private function generateAvatarColors(int $id = 0)
  {
      // Generate hue based on ID (0 - 360)
      $hue = ($id * 137) % 360; // 137 gives better color distribution

      // Dark background color using HSL
      $bg = "hsl($hue, 45%, 30%)";   // 30% lightness = dark
      $text = "hsl($hue, 90%, 90%)"; // Light text for contrast

      return [
      'bg'   => $bg,
      'text' => $text,
      ];
  }
  public function review_customer_list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $results = CustomerModel::where('branch_id', $branch_id)->where('status', 0)->get();
    return response()->json([
      'status'  => 200,
      'message' => 'Reason is Found..!',
      'data'    => $results
    ]);
  }

    public function manage_batch_attendance(Request $request)
    {
        return view('content.production.manage_batch_attendance.manage_batch_att');
    }

    public function GetStaffList(Request $request)
    {
        try {

            $branch_id = $request->user()->branch_id;
            $perPage   = $request->input('per_page', 10);

            $staff = DB::table('za_staff')
                ->select(
                    'za_staff.sno',
                    'za_staff.staff_id',
                    'za_staff.staff_name',
                    'za_staff.staff_image',
                    'za_department.department_name',

                    DB::raw('COUNT(DISTINCT za_batch.sno) as batch_count'),
                    DB::raw('COUNT(DISTINCT za_training.customer_id) as student_count')
                )

                ->join('za_batch', function ($join) use ($branch_id) {

                    $join->on('za_batch.staff_id', '=', 'za_staff.sno')
                        ->where('za_batch.branch_id', $branch_id)
                        ->where('za_batch.status', 0)
                        ->whereDate('za_batch.end_date', '>=', now()->toDateString()); // Active Batch

                })

                ->leftJoin('za_training', function ($join) {

                    $join->on('za_training.batch_id', '=', 'za_batch.sno')
                        ->where('za_training.status', 0);

                })

                ->leftJoin(
                    'za_department',
                    'za_department.sno',
                    '=',
                    'za_staff.department_id'
                )

                ->where('za_staff.branch_id', $branch_id)
                ->where('za_staff.status', 0)->whereIn('za_staff.sub_department_id', [4, 5, 13])

                ->groupBy(
                    'za_staff.sno',
                    'za_staff.staff_id',
                    'za_staff.staff_name',
                    'za_staff.staff_image',
                    'za_department.department_name'
                )

                ->orderBy('za_staff.staff_name')

                ->get();

            $staff->transform(function ($row) {

                $staff_image_path = 'staff_images/';
                $staff_image_full_path = !empty($row->staff_image)
                    ? $staff_image_path . $row->staff_image
                    : '';

                $colors = $this->generateAvatarColors((int)$row->sno);

                $row->staff_bg_color = $colors['bg'] ?? '#e4e6ef';
                $row->staff_text_color = $colors['text'] ?? '#000';

                if (
                    !empty($row->staff_image) &&
                    file_exists(public_path($staff_image_full_path))
                ) {

                    $row->staff_img_html =
                        '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px object-fit-cover">';

                } else {

                    $row->staff_img_html =
                        '<div class="avatar">
                            <span class="avatar-initial rounded-circle"
                                style="background:' . $row->staff_bg_color . ';color:' . $row->staff_text_color . '">
                                ' . strtoupper(substr($row->staff_name, 0, 1)) . '
                            </span>
                        </div>';
                }

                return $row;
            });

            return response()->json([
                'status' => 200,
                'message' => 'Active Staff List',
                'data' => $staff
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'status' => 500,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function GetStaffBatches(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'staff_id' => 'required|integer|exists:za_staff,sno'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Validation Failed',
                    'errors' => $validator->errors()
                ]);
            }

            $branch_id = $request->user()->branch_id;
            $perPage   = $request->input('per_page', 10);

            $batchQuery = DB::table('za_batch')
                ->select(
                    'za_batch.sno',
                    'za_batch.batch_id',
                    'za_batch.batch_name',
                    'za_batch.start_date',
                    'za_batch.end_date',
                    'za_batch.max_students',
                    'za_batch.customer_count',

                    'za_course.course_name',

                    'za_slot.slot_name',
                    'za_slot.start_time',
                    'za_slot.end_time',

                    'za_slot_type.slot_type_name',

                    DB::raw('COUNT(DISTINCT za_training.customer_id) as student_count')
                )

                ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')

                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')

                ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')

                ->leftJoin('za_training', function ($join) {

                    $join->on('za_training.batch_id', '=', 'za_batch.sno')
                        ->where('za_training.status', 0);

                })

                ->where('za_batch.branch_id', $branch_id)

                ->where('za_batch.staff_id', $request->staff_id)

                ->where('za_batch.status', 0)

                ->whereDate('za_batch.end_date', '>=', today())

                ->groupBy(
                    'za_batch.sno',
                    'za_batch.batch_id',
                    'za_batch.batch_name',
                    'za_batch.start_date',
                    'za_batch.end_date',
                    'za_batch.max_students',
                    'za_batch.customer_count',
                    'za_course.course_name',
                    'za_slot.slot_name',
                    'za_slot.start_time',
                    'za_slot.end_time',
                    'za_slot_type.slot_type_name'
                )

                ->orderBy('za_batch.start_date');

            $batches = $batchQuery->get();

            $attendanceCounts = DB::table('za_attendance')
                ->selectRaw('batch_id,COUNT(*) total')
                ->whereIn(
                    'batch_id',
                    $batches->pluck('sno')
                )
                ->groupBy('batch_id')
                ->pluck('total', 'batch_id');

            $today = now();

            $batches->transform(function ($batch) use ($attendanceCounts, $today) {

                $batch->attendance_count = $attendanceCounts[$batch->sno] ?? 0;

                $start = \Carbon\Carbon::parse($batch->start_date);
                $end   = \Carbon\Carbon::parse($batch->end_date);

                $totalDays = max(1, $start->diffInDays($end));

                $completedDays = min(
                    $totalDays,
                    max(0, $start->diffInDays($today))
                );

                $batch->completion_percentage =
                    round(($completedDays / $totalDays) * 100);

                if ($today->lt($start)) {

                    $batch->batch_status = 'Upcoming';
                    $batch->status_color = 'warning';

                } elseif ($today->gt($end)) {

                    $batch->batch_status = 'Completed';
                    $batch->status_color = 'danger';

                } else {

                    $batch->batch_status = 'Running';
                    $batch->status_color = 'success';

                }

                $batch->duration =
                    $start->format('d M Y')
                    .' - '.
                    $end->format('d M Y');

                return $batch;

            });

            return response()->json([

                'status' => 200,

                'message' => 'Batch List',

                'data' => $batches

            ]);

        } catch (\Exception $e) {

            return response()->json([

                'status' => 500,

                'message' => $e->getMessage()

            ]);

        }
    }

    public function GetAttendanceMatrix(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'staff_id' => 'required|integer',
                'batch_id' => 'required|integer',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Validation Failed',
                    'errors' => $validator->errors()
                ]);
            }

            $branch_id = $request->user()->branch_id;

            /*
            |--------------------------------------------------------------------------
            | Batch Details
            |--------------------------------------------------------------------------
            */

            $batch = DB::table('za_batch')
                ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
                ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
                ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
                ->select(
                    'za_batch.sno',
                    'za_batch.batch_name',
                    'za_batch.start_date',
                    'za_batch.end_date',
                    'za_course.course_name',
                    'za_slot.slot_name',
                    'za_slot.start_time',
                    'za_slot.end_time',
                    'za_slot_type.slot_type_name',
                    'za_slot.slot_type_days'
                )
                ->where('za_batch.branch_id', $branch_id)
                ->where('za_batch.staff_id', $request->staff_id)
                ->where('za_batch.sno', $request->batch_id)
                ->where('za_batch.status', 0)
                ->first();

            if (!$batch) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Batch Not Found'
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | Students
            |--------------------------------------------------------------------------
            */

            $students = DB::table('za_training')
                ->join('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
                ->select(
                    'za_customer.sno',
                    'za_customer.customer_id',
                    'za_customer.cus_name',
                    'za_customer.cus_pic'
                )
                ->where('za_training.batch_id', $batch->sno)
                ->where('za_training.status', 0)
                ->orderBy('za_customer.cus_name')
                ->get();

            /*
            |--------------------------------------------------------------------------
            | Dates (Slot Type Filter)
            |--------------------------------------------------------------------------
            */

            $dates = [];

            $slot_days = json_decode($batch->slot_type_days, true);

            if (!is_array($slot_days)) {
                $slot_days = [];
            }

            $period = new DatePeriod(
                new DateTime($batch->start_date),
                new DateInterval('P1D'),
                (new DateTime($batch->end_date))->modify('+1 day')
            );

            foreach ($period as $date) {
                // 0 = Sunday, 1 = Monday ... 6 = Saturday
                $weekDay = $date->format('w');
                if (in_array((string)$weekDay, $slot_days)) {
                    $dates[] = $date->format('Y-m-d');
                }
            }

            /*
            |--------------------------------------------------------------------------
            | Attendance (Single Query)
            |--------------------------------------------------------------------------
            */

            $attendanceRows = DB::table('za_attendance')
                ->select(
                    'customer_id',
                    'att_date',
                    'attendance'
                )
                ->where('batch_id', $batch->sno)
                ->where('staff_id', $request->staff_id)
                ->whereBetween('att_date', [
                    $batch->start_date,
                    $batch->end_date
                ])
                ->get();

            $attendance = [];

            foreach ($attendanceRows as $row) {

                $attendance[$row->customer_id][$row->att_date] = $row->attendance;

            }

            /*
            |--------------------------------------------------------------------------
            | Matrix
            |--------------------------------------------------------------------------
            */

            foreach ($students as $student) {

                $student->attendance = [];

                $summary = [
                    'P' => 0,
                    'A' => 0,
                    'H' => 0,
                    'HD' => 0,
                    'L' => 0,
                    'NA' => 0,
                ];

                foreach ($dates as $date) {

                    $status = $attendance[$student->sno][$date] ?? 'NA';

                    $student->attendance[] = [
                        'date' => $date,
                        'status' => $status
                    ];

                    if (isset($summary[$status])) {
                        $summary[$status]++;
                    }

                }

                $student->summary = $summary;

                $img = 'cus_pics/' . $student->cus_pic;

                $cust_image_path = 'cus_pics/';
                $cust_image_full_path = !empty($student->cus_pic) ? $cust_image_path . $student->cus_pic : '';

                $colors = $this->generateAvatarColors((int)$student->sno);

                $student->cust_bg_color = $colors['bg'] ?? '#e4e6ef';
                $student->cust_text_color = $colors['text'] ?? '#000';

                if (
                    !empty($student->cus_pic) &&
                    file_exists(public_path($cust_image_full_path))
                ) {

                    $student->customer_image_url =
                        '<img src="' . asset($cust_image_full_path) . '" class="rounded-circle w-50px h-50px object-fit-cover">';

                } else {

                    $student->customer_image_url =
                        '<div class="avatar me-2">
                            <span class="avatar-initial rounded-circle"
                                style="background:' . $student->cust_bg_color . ';color:' . $student->cust_text_color . '">
                                ' . strtoupper(substr($student->cus_name, 0, 1)) . '
                            </span>
                        </div>';
                }

            }

            return response()->json([

                'status' => 200,

                'message' => 'Attendance Matrix',

                'batch' => $batch,

                'dates' => $dates,

                'students' => $students

            ]);

        } catch (\Exception $e) {

            return response()->json([
                'status' => 500,
                'message' => $e->getMessage()
            ]);

        }
    }

    public function UpdateAttendanceMatrix(Request $request)
    {
        DB::beginTransaction();

        try {

            $validator = Validator::make($request->all(), [

                'staff_id' => 'required|integer',
                'batch_id' => 'required|integer',

                'attendance' => 'required|array|min:1',

                'attendance.*.customer_id' => 'required|integer',
                'attendance.*.attendance' => 'required|array|min:1',

                'attendance.*.attendance.*.date' => 'required|date',
                'attendance.*.attendance.*.status' => 'required|in:P,A,H,HD,L,NA',

            ]);

            if ($validator->fails()) {

                return response()->json([
                    'status' => 422,
                    'message' => 'Validation Failed',
                    'errors' => $validator->errors()
                ]);

            }

            $branch_id = $request->user()->branch_id;
            $user_id   = $request->user()->user_id;
            $batch_id   = $request->batch_id;
            $staff_id   = $request->staff_id;

            /*
            |--------------------------------------------------------------------------
            | Batch Validation
            |--------------------------------------------------------------------------
            */

            $batch = BatchModel::where('sno', $request->batch_id)
                ->where('staff_id', $request->staff_id)
                ->where('branch_id', $branch_id)
                ->where('status', 0)
                ->first();

            if (!$batch) {

                return response()->json([
                    'status' => 404,
                    'message' => 'Batch Not Found.'
                ]);

            }

            /*
            |--------------------------------------------------------------------------
            | Branch Code
            |--------------------------------------------------------------------------
            */

            $branch = BranchModel::select('city_short_code')
                ->where('sno', $branch_id)
                ->first();

            $branch_code = $branch->city_short_code ?? 'MDU';

            /*
            |--------------------------------------------------------------------------
            | Last Attendance Number
            |--------------------------------------------------------------------------
            */

            $lastAttendance = AttendanceModel::orderByDesc('sno')->first();

            $lastNumber = 0;

            if ($lastAttendance && !empty($lastAttendance->attendance_id)) {

                $parts = explode('/', $lastAttendance->attendance_id);

                $lastNumber = intval(
                    preg_replace('/\D/', '', end($parts))
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Existing Attendance (Single Query)
            |--------------------------------------------------------------------------
            */

            $existingAttendance = AttendanceModel::where('branch_id', $branch_id)
                ->where('staff_id', $request->staff_id)
                ->where('batch_id', $request->batch_id)
                ->get()
                ->keyBy(function ($item) {
                    return $item->customer_id . '_' . $item->att_date;
                });

            /*
            |--------------------------------------------------------------------------
            | Save Attendance
            |--------------------------------------------------------------------------
            */

            foreach ($request->attendance as $student) {

                foreach ($student['attendance'] as $row) {

                    $key = $student['customer_id'] . '_' . $row['date'];

                    if (isset($existingAttendance[$key])) {

                        /*
                        |--------------------------------------------------------------------------
                        | Update
                        |--------------------------------------------------------------------------
                        */

                        $attendance = $existingAttendance[$key];

                        $attendance->attendance = $row['status'];
                        $attendance->updated_by = $user_id;
                        $attendance->updated_at = now();
                        $attendance->save();

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | Create
                        |--------------------------------------------------------------------------
                        */

                        $lastNumber++;

                        $attendance_id = date('Y') . '/' .
                            $branch_code . '/' .
                            sprintf('AT%04d', $lastNumber);

                        $attendance = new AttendanceModel();

                        $attendance->attendance_id = $attendance_id;
                        $attendance->branch_id = $branch_id;
                        $attendance->att_date = $row['date'];

                        $attendance->customer_id = $student['customer_id'];
                        $attendance->batch_id = $request->batch_id;
                        $attendance->staff_id = $request->staff_id;

                        $attendance->course_id = $batch->course_id ?? 0;

                        $attendance->attendance = $row['status'];

                        $attendance->total_duration = 0;
                        $attendance->per_hr_cost = 0;
                        $attendance->total_cost = 0;

                        $attendance->staff_att_status = 0;

                        $attendance->feedback = null;
                        $attendance->feedback_score = 0;

                        $attendance->created_by = $user_id;
                        $attendance->created_at = now();

                        $attendance->updated_by = $user_id;
                        $attendance->updated_at = now();

                        $attendance->status = 0;

                        $attendance->save();

                    }

                }

            }

            DB::commit();

            return response()->json([
                'status' => 200,
                'batch_id' => $batch_id,
                'staff_id' => $staff_id,
                'message' => 'Attendance Updated Successfully.'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => $e->getMessage()
            ]);

        }
    }
}