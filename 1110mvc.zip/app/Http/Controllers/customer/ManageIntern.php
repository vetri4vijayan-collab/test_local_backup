<?php

namespace App\Http\Controllers\customer;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\GeneralSettingsModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\ManageInternModel;
use App\Models\ManageTargetModel;
use App\Models\TransactionModel;
use App\Models\LedgerModel;
use App\Models\SubLedgerModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\FranchiseInternShareModel;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use PDF;

use App\Models\LetterPadModel;
use App\Models\CollegeModel;
use App\Models\FeedBackInternQuestionModel;
 
use App\Models\EmailTemplateModel;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Mail;
use App\Models\EducationModel;
use App\Models\TopicModel;
class ManageIntern extends Controller
{
 public function Index(Request $request)
 {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    // Fetch year and month from the request
    $year = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    // Get the current date
    $currentDate = now()->toDateString();

    // Fetch total intern count, total payment, total paid, total balance
    $allInternCount = ManageInternModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->count();

    $totalPayment = ManageInternModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->sum('payment');  // Assuming 'payment' is the field in your model

    $totalPaid = ManageInternModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->sum('paid');  // Assuming 'paid' is the field in your model

    $totalBalance = ManageInternModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->sum('balance');  // Assuming 'balance' is the field in your model

    // Get the filter for customer name, email, or mobile
    $customer_fill = $request->cus_fill ?? '';

    // Joining with the 'colleges' and 'za_staff' tables
    $interns = ManageInternModel::join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
        ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
        ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
        ->where('za_intern.branch_id', $branch_id)
        ->where('za_intern.status', 0)
        // ->whereYear('za_intern.start_date', $year)  // Filter by year
        // ->whereMonth('za_intern.start_date', $month) // Filter by month
        ->when(!empty($customer_fill), function ($query) use ($customer_fill) {
            return $query->where(function ($q) use ($customer_fill) {
                $q->where('za_intern.intern_name', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('za_intern.intern_email', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('za_intern.intern_mobile', 'LIKE', "%{$customer_fill}%");
            });
        })
        ->select(
            'za_intern.intern_name',
            'za_intern.intern_email',
             'za_intern.intern_id',
             'za_intern.user_type',
            'za_intern.intern_mobile',
            'za_intern.certificate_issue_date',
            'za_intern.college_id',
            'za_intern.staff_id',
            'za_intern.sno',
            'za_intern.topic',
            'za_intern.confirmation_date',
            'za_topic.title',
            'za_college.college_name',
            'za_intern.generate_status',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_intern.start_date',
            'za_intern.end_date',
            'za_intern.payment',
            'za_intern.paid',
            'za_intern.balance',
            'za_intern.transaction_all'
        )
        ->orderBy('za_intern.sno', 'desc')
        ->paginate($perpage);
        
        
        // Grouped college-course counts filtered by created_at month/year
        $collegeCourseCounts = ManageInternModel::leftJoin('za_college', 'za_intern.college_id', '=', 'za_college.sno')
            ->leftJoin('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
            ->where('za_intern.branch_id', $branch_id)
            ->where('za_intern.status', 0)
            ->whereYear('za_intern.created_at', $year)
            ->whereMonth('za_intern.created_at', $month)
            ->groupBy('za_college.college_name')
            ->selectRaw('
                za_college.college_name,
                COUNT(*) as intern_count,
                MIN(za_topic.title) as course_title
            ')
            ->orderByDesc('intern_count')
            ->get();

        // Total intern count filtered by created_at month/year
        $totalInternCount = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();

    // Fetch any other necessary details (like payment, training, etc.)
    // return $interns;
    // Return the data to the view
    return view('content.customer.manage_intern.manage_intern', [
        'perpage' => $perpage,
        'interns' => $interns,
        'allInternCount' => $allInternCount,
        'totalInternCount' => $totalInternCount,
        'collegeCourseCounts' => $collegeCourseCounts,
        'totalPayment' => $totalPayment,
        'totalPaid' => $totalPaid,
        'totalBalance' => $totalBalance,
        'year' => $year,
        'month' => $month,
        'customer_fill' => $customer_fill,
    ]);
}

  public function Add(Request $request){
    return view('content.customer.manage_intern.add_intern')->with('filter_on', false);
  }
  public function viewCertificate($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
    $branch_id = $request->user()->branch_id;

    $interns = ManageInternModel::where('za_intern.sno', $decryptedValue)
        ->join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
        ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
        ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
        ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
        ->join('za_education', 'za_intern.degree_id', '=', 'za_education.sno')
        ->join('za_branch', 'za_intern.branch_id', '=', 'za_branch.sno')
        ->join('za_states', 'za_branch.state_id', '=', 'za_states.id')
        ->join('za_cities', 'za_branch.city_id', '=', 'za_cities.id')
        ->where('za_intern.branch_id', $branch_id)
        ->where('za_intern.status', 0)
        ->select(
            'za_intern.intern_name',
            'za_intern.intern_email',
            'za_intern.intern_id',
            'za_intern.intern_mobile',
            'za_intern.college_id',
            'za_intern.staff_id',
            'za_intern.sno',
            'za_topic.title',
            'za_intern.topic',
            'za_intern.year',
            'za_intern.generate_status',
            'za_intern.certificate_issue_date',
            'za_education.education',
            'za_college.college_name',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_branch.area_street',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mail',
            'za_branch.comm_email_id',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.tax_no',
            'za_branch.cre_mobile',
            'za_letter_pad.email',
            'za_letter_pad.company',
            'za_letter_pad.letter_header',
            'za_letter_pad.letter_footer',
            'za_letter_pad.letter_logo',
            'za_letter_pad.logo_width',
            'za_letter_pad.logo_height',
            'za_letter_pad.signature',
            'za_letter_pad.phone',
            'za_letter_pad.letter_pad_desc',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_intern.start_date',
            'za_intern.end_date',
            'za_intern.payment',
            'za_intern.paid',
            'za_intern.balance'
        )
        ->first();

        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');
        
            $qrContent = "Name         : {$interns->intern_name}\n"
                       . "Start Date   : {$interns->start_date_formatted}\n"
                       . "End Date     : {$interns->end_date_formatted}\n"
                       . "Company      : {$interns->company}\n"
                       . "Issue Date   : {$issueDateFormatted}\n"
                       . "Certificate  : Verified";
        
           
        
            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
            
            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?
            
            // RECOMMENDED: Use API from https://api.qrserver.com/
            
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
            
            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
          

        }
          
    //   return $qrImageData;
       $pdf = PDF::loadView('content.customer.manage_intern.certificate', [
                'interns' => $interns,
                  'qrBase64' => $qrBase64
            ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)  
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
            // return $pdf;  
             return $pdf->download('certificate.pdf');  
    // return view('content.customer.manage_intern.certificate', ['interns' => $interns, 'qrBase64' => $qrBase64,
    // 'qrCodeUrl' => $qrCodeUrl ]);
}
  public function viewCertificateEmployee($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
    $branch_id = $request->user()->branch_id;

    $interns = ManageInternModel::where('za_intern.sno', $decryptedValue)
        ->join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
        ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
        ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
        ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
        // ->join('za_education', 'za_intern.degree_id', '=', 'za_education.sno')
        ->join('za_branch', 'za_intern.branch_id', '=', 'za_branch.sno')
        ->join('za_states', 'za_branch.state_id', '=', 'za_states.id')
        ->join('za_cities', 'za_branch.city_id', '=', 'za_cities.id')
        ->where('za_intern.branch_id', $branch_id)
        ->where('za_intern.status', 0)
        ->select(
            'za_intern.intern_name',
            'za_intern.intern_email',
            'za_intern.intern_id',
            'za_intern.intern_mobile',
            'za_intern.college_id',
            'za_intern.staff_id',
            'za_intern.sno',
            'za_topic.title',
            'za_intern.topic',
            'za_intern.year',
            'za_intern.certificate_issue_date',
            // 'za_education.education',
            'za_college.college_name',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_branch.area_street',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mail',
            'za_branch.comm_email_id',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.tax_no',
            'za_branch.cre_mobile',
            'za_letter_pad.email',
            'za_letter_pad.company',
            'za_letter_pad.letter_header',
            'za_letter_pad.letter_footer',
            'za_letter_pad.letter_logo',
            'za_letter_pad.logo_width',
            'za_letter_pad.logo_height',
            'za_letter_pad.signature',
            'za_letter_pad.phone',
            'za_letter_pad.letter_pad_desc',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_intern.start_date',
            'za_intern.end_date',
            'za_intern.payment',
            'za_intern.paid',
            'za_intern.balance'
        )
        ->first();
     // return $interns;
     // Format the dates
     if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');
        
            $qrContent = "Name         : {$interns->intern_name}\n"
                       . "Start Date   : {$interns->start_date_formatted}\n"
                       . "End Date     : {$interns->end_date_formatted}\n"
                       . "Company      : {$interns->company}\n"
                       . "Issue Date   : {$issueDateFormatted}\n"
                       . "Certificate  : Verified";
        
           
        
            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
            
            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?
            
            // RECOMMENDED: Use API from https://api.qrserver.com/
            
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
            
            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
          

        }
     // return $interns;
       $pdf = PDF::loadView('content.customer.manage_intern.Employee-Certificate', [
                'interns' => $interns,
                  'qrBase64' => $qrBase64
            ])
            ->setPaper('a4', 'portrait')
            ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
            ->setOption('isPhpEnabled', true)  
            ->setOption('isRemoteEnabled', true)  // now you can safely set false
            ->setPaper('a4');
            // return $pdf;  
             return $pdf->download('Employee-Certificate.pdf');
            
    // return view('content.customer.manage_intern.Employee-Certificate', ['interns' => $interns]);
}

  public function previewCertificate($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
    $branch_id = $request->user()->branch_id;
    // return $id;
    $interns = ManageInternModel::where('za_intern.sno', $id)
        ->join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
        ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
        ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
        ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
        ->join('za_education', 'za_intern.degree_id', '=', 'za_education.sno')
        ->join('za_branch', 'za_intern.branch_id', '=', 'za_branch.sno')
        ->join('za_states', 'za_branch.state_id', '=', 'za_states.id')
        ->join('za_cities', 'za_branch.city_id', '=', 'za_cities.id')
        ->where('za_intern.status', 0)
        ->select(
            'za_intern.intern_name',
            'za_intern.intern_email',
            'za_intern.intern_id',
            'za_intern.intern_mobile',
            'za_intern.college_id',
            'za_intern.staff_id',
            'za_intern.sno',
            'za_topic.title',
            'za_intern.topic',
            'za_intern.year',
            'za_intern.certificate_issue_date',
            'za_education.education',
            'za_college.college_name',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_branch.area_street',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mail',
            'za_branch.comm_email_id',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.tax_no',
            'za_branch.cre_mobile',
            'za_letter_pad.email',
            'za_letter_pad.company',
            'za_letter_pad.letter_header',
            'za_letter_pad.letter_footer',
            'za_letter_pad.letter_logo',
            'za_letter_pad.logo_width',
            'za_letter_pad.logo_height',
            'za_letter_pad.signature',
            'za_letter_pad.phone',
            'za_letter_pad.letter_pad_desc',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_intern.start_date',
            'za_intern.end_date',
            'za_intern.payment',
            'za_intern.paid',
            'za_intern.balance'
        )
        ->first();
        // return $interns;
        $qrBase64 = null;
        // Format the dates
        if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');
        
            $qrContent = "Name         : {$interns->intern_name}\n"
                       . "Start Date   : {$interns->start_date_formatted}\n"
                       . "End Date     : {$interns->end_date_formatted}\n"
                       . "Company      : {$interns->company}\n"
                       . "Issue Date   : {$issueDateFormatted}\n"
                       . "Certificate  : Verified";
        
           
        
            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
            
            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?
            
            // RECOMMENDED: Use API from https://api.qrserver.com/
            
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
            
            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
          

        }
         
       
        //   $pdf = PDF::loadView('content.customer.manage_intern.certificate', [
        //             'interns' => $interns,
        //               'qrBase64' => $qrBase64
        //         ])
        //         ->setPaper('a4', 'portrait')
        //         ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
        //         ->setOption('isPhpEnabled', true)  
        //         ->setOption('isRemoteEnabled', true)  // now you can safely set false
        //         ->setPaper('a4');
            // return $pdf;  
            //  return $pdf->download('certificate.pdf');  
    return view('content.customer.manage_intern.preview_certificate', ['interns' => $interns, 'qrBase64' => $qrBase64 ]);
}
  public function previewCertificateEmployee($id,Request $request){
      
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    
    $branch_id = $request->user()->branch_id;

    $interns = ManageInternModel::where('za_intern.sno', $id)
        ->join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
        ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
        ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
        ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
        // ->join('za_education', 'za_intern.degree_id', '=', 'za_education.sno')
        ->join('za_branch', 'za_intern.branch_id', '=', 'za_branch.sno')
        ->join('za_states', 'za_branch.state_id', '=', 'za_states.id')
        ->join('za_cities', 'za_branch.city_id', '=', 'za_cities.id')
        ->where('za_intern.status', 0)
        ->select(
            'za_intern.intern_name',
            'za_intern.intern_email',
            'za_intern.intern_id',
            'za_intern.intern_mobile',
            'za_intern.college_id',
            'za_intern.staff_id',
            'za_intern.sno',
            'za_topic.title',
            'za_intern.topic',
            'za_intern.year',
            'za_intern.certificate_issue_date',
            // 'za_education.education',
            'za_college.college_name',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_branch.area_street',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mail',
            'za_branch.comm_email_id',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.tax_no',
            'za_branch.cre_mobile',
            'za_letter_pad.email',
            'za_letter_pad.company',
            'za_letter_pad.letter_header',
            'za_letter_pad.letter_footer',
            'za_letter_pad.letter_logo',
            'za_letter_pad.logo_width',
            'za_letter_pad.logo_height',
            'za_letter_pad.signature',
            'za_letter_pad.phone',
            'za_letter_pad.letter_pad_desc',
            'za_cities.name as city_name',
            'za_states.name as state_name',
            'za_intern.start_date',
            'za_intern.end_date',
            'za_intern.payment',
            'za_intern.paid',
            'za_intern.balance'
        )
        ->first();
    //   return $interns;
     // Format the dates
     if ($interns) {
            $interns->start_date_formatted = Carbon::parse($interns->start_date)->format('jS F Y');
            $interns->end_date_formatted = Carbon::parse($interns->end_date)->format('jS F Y');
            $issueDateFormatted = Carbon::parse($interns->certificate_issue_date)->format('jS F Y');
        
            $qrContent = "Name         : {$interns->intern_name}\n"
                       . "Start Date   : {$interns->start_date_formatted}\n"
                       . "End Date     : {$interns->end_date_formatted}\n"
                       . "Company      : {$interns->company}\n"
                       . "Issue Date   : {$issueDateFormatted}\n"
                       . "Certificate  : Verified";
        
           
        
            // Create QR using PHP without installation
            $qrImage = imagecreate(200, 200);
            $white = imagecolorallocate($qrImage, 255, 255, 255);
            $black = imagecolorallocate($qrImage, 0, 0, 0);
            imagefilledrectangle($qrImage, 0, 0, 200, 200, $white);
            
            // Just a placeholder pattern (real QR not generated like this)
            // Since you don't want to install any package and can't rely on Google API,
            // we're forced to ask: are you open to use a **small local script** or CDN?
            
            // RECOMMENDED: Use API from https://api.qrserver.com/
            
            $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=200x200";
            
            // Convert to base64
            $qrImageData = @file_get_contents($qrServerUrl);
            $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
          

        }
        //   return $qrBase64;
        //   $pdf = PDF::loadView('content.customer.manage_intern.Employee-Certificate', [
        //             'interns' => $interns,
        //               'qrBase64' => $qrBase64
        //         ])
        //         ->setPaper('a4', 'portrait')
        //         ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
        //         ->setOption('isPhpEnabled', true)  
        //         ->setOption('isRemoteEnabled', true)  // now you can safely set false
        //         ->setPaper('a4');
            // return $pdf;  
            //  return $pdf->download('Employee-Certificate.pdf');
            // return $interns;
            
    return view('content.customer.manage_intern.preview_Employee_Certificate', ['interns' => $interns, 'qrBase64' => $qrBase64 ]);
}

 public function updateStatus(Request $request)
  {
    $intern_id = $request->intern_id;

    $student = ManageInternModel::find($intern_id);
    if (!$student) {
      return response()->json(['status' => 404, 'message' => 'Student not found']);
    }

    // Assuming there's a 'certificate_status' field
    $student->generate_status = 1; // or whatever value indicates "generated"
    $student->save();

    $branchData = BranchModel::where('status', 0)->where('sno', $student->branch_id)
      ->first();

    $customers = DB::table('za_intern')->select('za_intern.*', 'za_topic.title', 'za_letter_pad.company')
      ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
      ->join('za_letter_pad', 'za_intern.company_id', '=', 'za_letter_pad.sno')
      ->where('za_intern.sno', $student->sno)->first();

    $branch_name = $branchData
      ? ($branchData->branch_type == 1 ? $branchData->branch_name : $branchData->franchise_name)
      : 'Elysium Academy';

    $helper = new \App\Helpers\Helpers();


    $encrypted_values = $helper->encrypt_decrypt($student->sno, 'encrypt');
    $Link = url('intern_feedback/' . $encrypted_values);

    // Shorten the link if needed
    $channelId = 22;
    $shortUrlData = $this->shortenUrl($Link, $channelId);
    $shortUrl = $shortUrlData['shorturl'] ?? $Link; // fallback to full link

    // Save feedback link in DB
    DB::table('za_intern')->where('sno', $student->sno)->update(['feedback_link' => $shortUrl]);

    $shortcustomer = DB::table('za_intern')->where('sno', $customers->sno)->first();
    $shortsendUrl = $shortcustomer->feedback_link;
    $feedback_key = basename($shortsendUrl);

    //  Mail
    if ($customers->intern_email) {
      try {
        $email_template_id = 26; // Feedback email template
        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

        $startDate = $customers->start_date
          ? Carbon::parse($customers->start_date)->format('d-M-Y')
          : 'Start Date';

        $endDate = $customers->end_date
          ? Carbon::parse($customers->end_date)->format('d-M-Y')
          : 'End Date';

        $content = $emailTemplate->email_subject;
        $content = str_replace('#name', $customers->intern_name, $content);
        $content = str_replace('#CompanyName', $customers->company ?? 'CompanyName', $content);
        $content = str_replace('#StartDate', $startDate ?? 'StartDate', $content);
        $content = str_replace('#EndDate', $endDate ?? 'EndDate', $content);
        $content = str_replace('#LearningDomain', $customers->title ?? 'LearningDomain', $content);
        $content = str_replace('#link', $shortUrl, $content);
        $content = str_replace('#CRENo', $branchData->cre_mobile ?? '9677781155', $content);
        $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
        $content = str_replace('#mail', $branchData->mail ?? 'info@elysiumacademy.org', $content);

        $mailData = [
          'url' => 'Eapl.com',
          'subject' => $emailTemplate->email_name,
          'content' => $content,
          'branchNo' => $branchData->mobile,
          'branchemail' => $branchData->mail,
          'fbLink' => $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/',
          'instaLink' => $branchData->insta_link ?? 'https://www.instagram.com/elysiumacademy/',
          'salesMobile' => $branchData->sales_mobile,
        ];

        $to_address = $customers->intern_email;
        $from_address = 'elysiumacademy@elysium.community';
        $from_name = 'Elysium Academy ' . "\xC2\xAE";
        Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

        DB::table('za_intern')->where('sno', $customers->sno)->update(['email_send_feedback' => 1]);
      } catch (\Exception $e) {
        DB::table('za_intern')->where('sno', $customers->sno)->update(['email_send_feedback' => 2]);
      }
    }
    
     //  whatsapp
    if ($customers->intern_mobile) {
 
 
      // $templateName  = "hello_world";
      $templateName  = "feedback_common";
 
      $hasHeader  = false; // Example flag: set based on template
      $hasBody    = false; // Example flag: set based on template
      $hasFooter  = false; // Example flag: set based on template
      $hasButton  = false;
      $components = [];
      $couponCode = " ";
      date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
      $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
      // $currentHour = date('H'); // Get current hour in 24-hour format
      if ($currentHour >= 5 && $currentHour < 12) {
        $greeting = 'Good Morning';
      } elseif ($currentHour >= 12 && $currentHour < 18) {
        $greeting = 'Good Afternoon';
      } else {
        $greeting = 'Good Evening';
      }
 
      if ($templateName == 'feedback_common') {
        $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/OnBoard.jpg';
        // $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
        $couponCode  = 'NOOFFER';
        $buttonIndex = 1;
        $bodyText    = [
          [
            'type'           => 'text',
            'text'           => $customers->intern_name ?? "student",
            'parameter_name' => 'stu_name',
          ],
          [
            'type'           => 'text',
            'text'           => $customers->title ?? "title",
            'parameter_name' => 'complete_name',
          ],
          [
            'type'           => 'text',
            'text'           => "intership",
            'parameter_name' => 'type',
          ],
          [
            'type'           => 'text',
            'text'           => "interships",
            'parameter_name' => 'complete_type',
          ],
          [
            'type'           => 'text',
            'text'           => "interships",
            'parameter_name' => 'complete_type1',
          ],
          [
            'type'           => 'text',
            'text'           => $shortUrl,
            'parameter_name' => 'feed_link',
          ]
        ];
        $hasHeader = false;
        $hasBody   = true;
        $hasButton = true;
      }
 
      // Add Header if required
      if ($hasHeader) {
        $components[] = [
          'type'       => 'header',
          'parameters' => [
            [
              'type'  => 'image',
              'image' => [
                'link' => $headerImage, // Dynamically set header image
              ],
            ],
          ],
        ];
      }
 
      // Add Body if required
      if ($hasBody) {
        $components[] = [
          'type'       => 'body',
          'parameters' => $bodyText,
        ];
      }
 
      // Add Footer if required
      if ($hasButton) {
        $components[] = [
          'type'       => 'button',
          'sub_type'   => 'url',
          'index'      => 0,
          'parameters' => [
            [
              'type' => 'text',
              'text' => $feedback_key,
            ],
          ],
        ];
      }
 
 
      $dynamicParameters         = $templateParameters[$templateName] ?? [];
      $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
      $accessToken               = $this->accessData($request)->access_tokken;
      $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;
 
      $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
 
      $mobile = preg_replace('/\D/', '', $customers->intern_mobile); // remove any non-digits
      if (strpos($customers->intern_mobile, '+') === 0) {
        $to = $customers->intern_mobile;
      } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
        $to = '+' . $mobile;
      } else {
        $to = '+91' . $mobile;
      }
      $languageCode = 'en';
 
      // if (strpos($to, $countryCode) !== 0) {
      //     $to = $countryCode . $to;
      // }
 
      $message = 'test~message';
      if (empty($components)) {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $to,
          'type'              => 'template',
          'template'          => [
            'name'     => $templateName,
            'language' => [
              'code' => $languageCode,
            ],
          ],
        ];
      } else {
        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $to,
          'type'              => 'template',
          'template'          => [
            'name'       => $templateName,
            'language'   => [
              'code' => $languageCode,
            ],
            'components' => $components,
          ],
        ];
      }
 
      $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
      if ($response['status'] == 200) {
      } else {
 
        return response([
          'status' => 404,
          'message' => 'Failed to send message',
          'certificate_status' => 2,
          'error_msg' => $response['error'],
        ], 400);
      }
    } else {
      return response([
        'status' => 200,
        'message' => 'Mobile no not found',
        'error_msg' => 'mobile no not found',
        'certificate_status' => 0,
      ], 200);
    }
    return response()->json(['status' => 200, 'message' => 'Status updated']);
  }
  
    public function shortenUrl($longUrl, $channelId)
  {
    $response = Http::withToken('aFLQFlykraqpANsi')
      ->post('https://chotta.link/api/url/add', [
        'url' => $longUrl
      ]);
 
    if ($response->successful() && isset($response['shorturl'])) {
 
      $shortUrl = $response['shorturl'];
      $urlId = $response['id'];
 
      $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";
 
      $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
 
      if ($assignResponse->successful()) {
        return $response; // success
      }
    }
 
 
    return null;
  }

  public function StaffListIntern()
  {
      $branch_id = $request->user()->branch_id;
    $staff = StaffModel::where('status', 0)->where('department_id', 2)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
    // return $College;
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $staff
    ], 200);
  }
  public function intern_summary(Request $request)
  {
        $branch_id = $request->user()->branch_id;
    
        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));
    
        // College-wise intern count
        $collegeCounts = ManageInternModel::leftJoin('za_college', 'za_intern.college_id', '=', 'za_college.sno')
            ->where('za_intern.branch_id', $branch_id)
            ->where('za_intern.status', 0)
            ->whereYear('za_intern.created_at', $year)
            ->whereMonth('za_intern.created_at', $month)
            ->groupBy('za_college.college_name')
            ->selectRaw('za_college.college_name, COUNT(*) as intern_count')
            ->orderByDesc('intern_count')
            ->get();
    
        // Course-wise intern count
        $courseCounts = ManageInternModel::leftJoin('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
            ->where('za_intern.branch_id', $branch_id)
            ->where('za_intern.status', 0)
            ->whereYear('za_intern.created_at', $year)
            ->whereMonth('za_intern.created_at', $month)
            ->groupBy('za_topic.title')
            ->selectRaw('za_topic.title as course_title, COUNT(*) as course_count')
            ->orderByDesc('course_count')
            ->get();
    
        // Total intern count
        $totalInternCount = ManageInternModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
    
        return response()->json([
            'year' => $year,
            'month' => $month,
            'collegeCounts' => $collegeCounts,   // Clean college-wise data
            'courseCounts' => $courseCounts,     // Clean course-wise data
            'totalInternCount' => $totalInternCount
        ]);
    }
  public function CreateIntern(Request $request)
  {
        $branch_id = $request->user()->branch_id;
        
      
        // Step 1: Validate common fields
        $request->validate([
            'colleage_id'      => 'required',
            'topic_id'         => 'required',
            'payment'          => 'required',
            'start_date'       => 'required',
            'end_date'         => 'required',
            'staff_id'         => 'required',
            'intern_name'      => 'required',
            'intern_email_id'  => 'required',
            'intern_mobile_no' => 'required',
        ]);
    //   return $request;
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;
        $year = date("Y");
        
        // Get last intern_id for the same branch and format
        $intern_check = ManageInternModel::whereNotNull('intern_id')
            ->where('intern_id', 'LIKE', $year . '/' . $branch_code . '/IND%')
            ->orderByRaw("CAST(SUBSTRING_INDEX(intern_id, 'IND', -1) AS UNSIGNED) DESC")
            ->first();
        
        if (!$intern_check || !isset($intern_check->intern_id)) {
            $intern_id = $year . '/' . $branch_code . '/' . "IND2005";
        } else {
            $last_intern_id = $intern_check->intern_id; // e.g. 2025/MDU01/IND2042
            $parts = explode("/", $last_intern_id);
        
            if (isset($parts[2]) && preg_match('/IND(\d+)/', $parts[2], $matches)) {
                $next_number = (int)$matches[1] + 1;
            } else {
                $next_number = 2005;
            }
        
            $new_code = sprintf("IND%04d", $next_number);
            $intern_id = $year . '/' . $branch_code . '/' . $new_code;
        }

        $common = [
            'branch_id' => $branch_id,
            'college_id' => $request->colleage_id,
            'topic'       => $request->topic_id,
            'payment'     => $request->payment,
            'payment_gst' => round(($request->payment * 18) / 100, 2),
            'paid'        => 0,
            'balance'     => $request->payment,
            'start_date'   => \Carbon\Carbon::createFromFormat('d-M-Y', $request->start_date)->format('Y-m-d'),
             'end_date'    => \Carbon\Carbon::createFromFormat('d-M-Y', $request->end_date)->format('Y-m-d'),
            'staff_id'    => $request->staff_id,
            'created_by'  => $request->user()->id ?? null,
            'updated_by'  => $request->user()->id ?? null,
            'status'      => 0,
        ];
    
           // Save the main intern
            $internId = $intern_id;  
            ManageInternModel::create(array_merge($common, [
                'intern_id'    => $internId,
                'intern_name'  => $request->intern_name,
                'intern_email' => $request->intern_email_id,
                'intern_mobile'=> $request->intern_mobile_no,
            ]));
    
           // Save dynamic interns
            if ($request->has('interns')) {
                foreach ($request->interns as $intern) {
                    $internId = $intern_id;
                    ManageInternModel::create(array_merge($common, [
                        'intern_id'    => $internId,
                        'intern_name'  => $intern['name'],
                        'intern_email' => $intern['email'],
                        'intern_mobile'=> $intern['mobile'],
                    ]));
                }
            }
    
         if ($branch_check->branch_type == 2) {
 
          $monthStart = now()->startOfMonth()->toDateString(); // 2026-06-01
     
          $getInternShare = ManageTargetModel::where('branch_id', $branch_check->sno)
            ->whereDate('date', $monthStart)
            ->first();
     
          $sharePercentage = $getInternShare->inter_share ?? 0;
     
          $shareAmount = ($request->payment * $sharePercentage) / 100;
     
          $sharepay = FranchiseInternShareModel::create([
            'branch_id'        => $branch_check->sno,
            'month_year'       => $monthStart,
            'share_amount'     => $shareAmount,
            'share_percentage' => $sharePercentage,
            'created_by'       => $request->user()->user_id ?? null,
            'updated_by'       => $request->user()->user_id ?? null,
          ]);
        }
    
       return redirect('manage_intern')->with('success', 'Interns added successfully!');
    }

  public function update(Request $request)
   {
    $request->validate([
        'sno' => 'required',
        'college_id' => 'required',
        'topic_name' => 'required',
        'payment' => 'required',
        'start_date' => 'required',
        'end_date' => 'required',
        'staff_id' => 'required',
        'intern_name' => 'required',
        'intern_email' => 'required',
        'intern_mobile' => 'required',
    ]);

    $intern = ManageInternModel::find($request->sno);

    if (!$intern || $intern->status != 0) {
        return response()->json(['status' => 'error', 'message' => 'Intern not found or already inactive.']);
    }

    $intern->college_id = $request->college_id;
    $intern->topic = $request->topic_name;
    $intern->payment = $request->payment;
    $intern->start_date = $this->parseDate($request->start_date);
    $intern->end_date = $this->parseDate($request->end_date);
    $intern->staff_id = $request->staff_id;
    $intern->intern_name = $request->intern_name;
    $intern->intern_email = $request->intern_email;
    $intern->intern_mobile = $request->intern_mobile;

    $intern->save();

    return response()->json(['status' => 'success', 'message' => 'Intern updated successfully']);
}
private function parseDate($date)
{
    if (!$date) return null;

    // If already in Y-m-d format, just return
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return $date;
    }

    // Try parsing known other formats
    $formats = ['d-M-Y', 'd/m/Y', 'd-M-y'];

    foreach ($formats as $format) {
        try {
            return Carbon::createFromFormat($format, $date)->format('Y-m-d');
        } catch (\Exception $e) {
            continue;
        }
    }

    return null;
}

  public function View(Request $request)
    {
        $intern = ManageInternModel::join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
            ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
            ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
            ->select(
                'za_intern.intern_name',
                'za_intern.intern_email',
                'za_intern.intern_id',
                'za_intern.intern_mobile',
                'za_intern.college_id',
                'za_intern.staff_id',
                'za_intern.sno',
                'za_intern.topic as topic_id',
                'za_topic.title as topic',
                'za_college.college_name',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_intern.start_date',
                'za_intern.end_date',
                'za_intern.payment',
                'za_intern.paid',
                'za_intern.balance'
            )
            ->where('za_intern.sno', $request->sno)
            ->first();
            $intern->start_date = Carbon::parse($intern->start_date)->format('d-M-Y');
            $intern->end_date = Carbon::parse($intern->end_date)->format('d-M-Y');
        if (!$intern) {
            return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
        }
    
        return response()->json([
            'status' => 'success',
            'message' => 'Intern fetched successfully',
            'data' => $intern
        ]);
    }

  public function Payment(Request $request, $id)
    {
        $request->validate([
            'pay_amount' => 'required|numeric|min:1',
            'transaction_all' => 'required|array',
            'payment_mode' => 'required|string',
            // 'reciptid' => 'required|string',
        ]);
    
        DB::beginTransaction();
    
        try {
            $intern = ManageInternModel::findOrFail($id);
            $user_id = auth()->user()->id ?? 0;
            $branch_id = auth()->user()->branch_id;
            
            // STEP 1: Fetch all transaction_all fields from this branch
            $allInterns = ManageInternModel::where('branch_id', $branch_id)
                ->whereNotNull('transaction_all')
                ->get(['transaction_all']);
            
            // STEP 2: Loop through all invoices and find the max number
            $lastInvoiceNumber = 2004;
            foreach ($allInterns as $internEntry) {
                $transactions = json_decode($internEntry->transaction_all, true);
                if (is_array($transactions)) {
                    foreach ($transactions as $txn) {
                        if (!empty($txn['invoice_id']) && preg_match('/INV(\d+)/', $txn['invoice_id'], $matches)) {
                            $num = (int)$matches[1];
                            if ($num > $lastInvoiceNumber) {
                                $lastInvoiceNumber = $num;
                            }
                        }
                    }
                }
            }
            
            // STEP 3: Create next invoice number
            $prefix = "EA";
            $year = date("Y");
            $nextInvoiceNumber = $lastInvoiceNumber + 1;
            $newInvoiceId = $prefix . '/' . $year . '/' . sprintf("INV%04d", $nextInvoiceNumber);
            
            // STEP 4: Append new transaction to THIS intern
            $oldTransactions = [];
            if (!empty($intern->transaction_all)) {
                $decoded = json_decode($intern->transaction_all, true);
                if (is_array($decoded)) {
                    $oldTransactions = $decoded;
                }
            }
            
            $newTransaction = $request->transaction_all;
            $newTransaction['payment_mode'] = $request->payment_mode;
            $newTransaction['receipt_id'] = $request->reciptid;
            $newTransaction['invoice_id'] = $newInvoiceId;
            $newTransaction['timestamp'] = now();
            
            $oldTransactions[] = $newTransaction;
            
            // STEP 5: Update payment totals
            $newPaidAmount = floatval($intern->paid) + floatval($request->pay_amount);
            $newBalance    = floatval($intern->payment) - $newPaidAmount;
            
            $intern->paid = $newPaidAmount;
            $intern->balance = $newBalance;
            $intern->transaction_all = json_encode($oldTransactions);
            $intern->updated_by = $user_id;
            $intern->save();
    
    
            // Prepare subledger
            $branch = BranchModel::where('sno', $branch_id)->firstOrFail();
            $branch_code = $branch->city_short_code;
    
            $latestSubledger = SubLedgerModel::where('branch_id', $branch_id)->orderByDesc('sno')->first();
            if (!$latestSubledger) {
                $subledger_id = date("Y") . '/' . $branch_code . '/SUB2005';
            } else {
                $last = explode('/', $latestSubledger->subledger_id);
                $num = (int) preg_replace('/[^0-9]/', '', $last[2]) + 1;
                $subledger_id = date("Y") . '/' . $branch_code . '/' . sprintf("SUB%04d", $num);
            }
            //  return $branch_id;
            $subledger = SubLedgerModel::create([
                'ledger_id' => 1,
                'subledger_id' => $subledger_id,
                'subledger_name' => ucfirst($intern->intern_name) . ' - ' . $intern->intern_id,
                'subledger_desc' => 'Intern Students fees',
                'branch_id' => $branch_id,
                'traning_sno' => 0,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
    
            // Prepare transaction ID
            $latestTr = TransactionModel::orderByDesc('sno')->first();
            if (!$latestTr) {
                $transaction_id = date("Y") . '/' . $branch_code . '/TRA2005';
            } else {
                $last = explode('/', $latestTr->transaction_id);
                $num = (int) preg_replace('/[^0-9]/', '', $last[2]) + 1;
                $transaction_id = date("Y") . '/' . $branch_code . '/' . sprintf("TRA%04d", $num);
            }
    
            $paidAmount = $request->pay_amount;
            $tax = $paidAmount * ($branch->gst_percentage / 100);
            $total = $paidAmount + $tax;
    
            // Create transaction record
            TransactionModel::create([
                'branch_id' => $branch_id,
                'transaction_id' => $transaction_id,
                'transaction_type' => 'Credit',
                'transaction_name' => 'Customer',
                'trans_source_id' => $intern->intern_id,
                'ledger_id' => 1,
                'subledger_id' => $subledger->sno,
                'customer_type' => 2,
                'credit' => $paidAmount,
                'invoice_id' => null,
                'receipt_id' => $request->reciptid,
                'training_id' => 0,
                'debit' => null,
                'tax' => $tax,
                'total_amount' => $total,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
    
            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => 'Payment updated successfully',
            ]);
    
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => 'Payment update failed.',
                'error' => $e->getMessage(), // Actual error message
               ], 500);
        }
    }
  public function ViewInvoice(Request $request)
    {
        $intern = ManageInternModel::join('za_college', 'za_intern.college_id', '=', 'za_college.sno')
            ->join('za_staff', 'za_intern.staff_id', '=', 'za_staff.sno')
            ->join('za_topic', 'za_intern.topic', '=', 'za_topic.sno')
            ->select(
                'za_intern.intern_name',
                'za_intern.intern_email',
                'za_intern.intern_id',
                'za_intern.intern_mobile',
                'za_intern.college_id',
                'za_intern.staff_id',
                'za_intern.sno',
                'za_intern.topic as topic_id',
                'za_intern.transaction_all',
                'za_topic.title as topic',
                'za_college.college_name',
                'za_staff.staff_name',
                'za_staff.staff_image',
                'za_staff.nick_name',
                'za_staff.gender',
                'za_intern.start_date',
                'za_intern.end_date',
                'za_intern.payment',
                'za_intern.paid',
                'za_intern.balance'
            )
            ->where('za_intern.sno', $request->sno)
            ->first();
    
        if (!$intern) {
            return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
        }
    
        // Helper and settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'd-M-Y';
    
        // Format dates
        $intern->start_date = \Carbon\Carbon::parse($intern->start_date)->format($dateFormat);
        $intern->end_date = \Carbon\Carbon::parse($intern->end_date)->format($dateFormat);
    
        // Decode and enhance transaction list
        $transactions = json_decode($intern->transaction_all, true) ?? [];
    
        foreach ($transactions as $i => &$payment) {
            $payment['encryptedValue'] = $helper->encrypt_decrypt($payment['invoice_id'] ?? '', 'encrypt');
            $payment['printValue'] = $helper->encrypt_decrypt($i + 1, 'encrypt');
        }
    
        // Attach modified transactions back
        $intern->transactions = $transactions;
    
        return response()->json([
            'status' => 'success',
            'message' => 'Intern fetched successfully',
            'data' => $intern
        ]);
    }

    //intern_invoice
    
    public function intern_invoice($id = '', $print_id = '', $sno = '', Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        // return  $sno;
        // Decrypt values
        $decryptedInvoiceId = $helper->encrypt_decrypt($id, 'decrypt');
        $transactionIndex = (int) $helper->encrypt_decrypt($print_id, 'decrypt');
    
        // Fetch intern and related info
        $payment = ManageInternModel::select(
            'za_intern.paid as amount',
            'za_intern.transaction_all',
            'za_intern.intern_name',
            'za_intern.intern_id',
            'za_intern.intern_mobile',
            'za_topic.title',
            'za_branch.door_no',
            'za_branch.pincode',
            'za_branch.mobile',
            'za_branch.gst_no',
            'za_branch.branch_name',
            'za_branch.branch_type',
            'za_branch.business_name As franchise_name',
            'za_branch.mail',
            'za_branch.area_street',
            'za_states.name as state_name',
            'za_cities.name as city_name'
        )
        ->leftJoin('za_topic', 'za_topic.sno', '=', 'za_intern.topic')
        ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_intern.branch_id')
        ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
        ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')
        ->where('za_intern.sno', $sno)
        ->first();
    
        if (!$payment) {
            return response()->view('errors.404', [], 404);
        }
    
        // Initialize selected transaction
        $selectedTransaction = null;
    
        // Decode transactions
        $transactions = [];
        if (!empty($payment->transaction_all)) {
            $decoded = json_decode($payment->transaction_all, true);
            if (is_array($decoded)) {
                $transactions = $decoded;
    
                // First try using the index
                if (isset($transactions[$transactionIndex])) {
                    $txn = $transactions[$transactionIndex];
    
                    // Match invoice_id to confirm
                    if (!empty($txn['invoice_id']) && $txn['invoice_id'] === $decryptedInvoiceId) {
                        $selectedTransaction = $txn;
                    }
                }
    
                // Fallback: try finding by invoice_id
                if (!$selectedTransaction) {
                    foreach ($transactions as $txn) {
                        if (!empty($txn['invoice_id']) && $txn['invoice_id'] === $decryptedInvoiceId) {
                            $selectedTransaction = $txn;
                            break;
                        }
                    }
                }
            }
        }
    
        // Final check
        if (!$selectedTransaction) {
            return response()->view('errors.404', [], 404);
        }
    
    
        // Terms & conditions
        $terms_conditions = GeneralSettingsModel::select('terms_1', 'terms_2','terms_3','terms_4', 'terms_5')
            ->where('status', 0)
            ->get();
    
        // GST % from branch
        $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
      
        // QR Code data
        $qrCodeData = [
            'Customer Name' => $payment->intern_name,
            'Customer ID' => $payment->intern_id,
            'Paid Amount' => $selectedTransaction['payment_amount']
        ];
    // return $selectedTransaction;
        return view('content.customer.manage_intern.intern_print', [
            'payment' => $payment,
            'transaction' => $selectedTransaction,
            'print_decryptedValue' => $transactionIndex,
            'gstPercentage' => $branch->gst_percentage ?? 0,
            'terms' => $terms_conditions,
            'qrCodeData' => json_encode($qrCodeData)
        ]);
    }

   public function generate(Request $request)
    {
    // Basic required validation
    $rules = [
        // 'company_id' => 'required|integer',
        'certificate_issue_date' => 'required|date',
        'generate_id' => 'required|integer',
        // 'user_type' => 'required|string|in:Student,Employee',
    ];

    // // Conditional rules based on user_type
    // if ($request->user_type === 'Student') {
    //     $rules['degree_id'] = 'required|integer';
    //     // $rules['year'] = 'required|string';
    // }

    $request->validate($rules);

    try {
        // Find intern by ID
        $intern = ManageInternModel::where('sno', $request->generate_id)->first();

        if (!$intern) {
            return response()->json(['success' => false, 'message' => 'Intern not found']);
        }

        // Update intern fields
        // $intern->user_type = $request->user_type === 'Student' ? 1 : ($request->user_type === 'Employee' ? 2 : null);
        // $intern->company_id = $request->company_id;
        // $intern->degree_id = $request->degree_id ?? null; // null for Employee
        // $intern->year = $request->year ?? null;
        $intern->certificate_issue_date = $request->certificate_issue_date;
        $intern->save();

        return response()->json([
            'success' => true,
            'message' => 'Certificate generated successfully.',
            'user_type' => $intern->user_type, // 1 = Student, 2 = Employee
            'intern_id' => $intern->sno // 1 = Student, 2 = Employee
        ]);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => 'Failed to update certificate data.']);
    }
}

   public function lead_add($id, Request $request)
     {

      $helper = new \App\Helpers\Helpers();
      $id = $helper->encrypt_decrypt($id, 'decrypt');
        $exp = explode('~', $id);
    $id = str_replace(' ', '', $exp[0] ?? '');
    $branch_id = $request->user()->branch_id;
  
      // Check if decryption failed
      if ($id === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }
      $interns = ManageInternModel::where('lead_id', $id)
            ->first();
    
    //  return $interns;
      return view('content.customer.manage_intern.lead_add_intern',compact('interns'));
    }
   public function CustomerIntern(Request $request)
   {
    $validator = Validator::make($request->all(), [
      'lead_id' => 'required|max:255',
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    }
        $branch_id = $request->user()->branch_id;
        $lead_id = $request->lead_id;
        $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
        $branch_code = $branch_check->city_short_code;
        $year = date("Y");

        // Get last intern_id for the same branch and format
        $intern_check = ManageInternModel::whereNotNull('intern_id')
            ->where('intern_id', 'LIKE', $year . '/' . $branch_code . '/IND%')
            ->orderByRaw("CAST(SUBSTRING_INDEX(intern_id, 'IND', -1) AS UNSIGNED) DESC")
            ->first();

        if (!$intern_check || !isset($intern_check->intern_id)) {
            $intern_id = $year . '/' . $branch_code . '/' . "IND2005";
        } else {
            $last_intern_id = $intern_check->intern_id; // e.g. 2025/MDU01/IND2042
            $parts = explode("/", $last_intern_id);

            if (isset($parts[2]) && preg_match('/IND(\d+)/', $parts[2], $matches)) {
                $next_number = (int)$matches[1] + 1;
            } else {
                $next_number = 2005;
            }

            $new_code = sprintf("IND%04d", $next_number);
            $intern_id = $year . '/' . $branch_code . '/' . $new_code;
        }
    // Fetch lead details
    $upd_lead = LeadModel::where('sno', $lead_id)->first();
    if (!$upd_lead) {
      return response([
        'status'    => 404,
        'message'   => 'Lead not found',
        'data'      => null,
      ], 404);
    }

    // Prepare customer data
    $customerData = [
      'lead_id'                => $lead_id,
      'intern_id'                => $intern_id,
      'intern_name'            => ucfirst($upd_lead->lead_name),
      'intern_mobile'          => $upd_lead->lead_mobile,
      'intern_email'           => $upd_lead->lead_email_id,
      'start_date'             => date('Y-m-d'),
      'end_date'               => date('Y-m-d'),
      'branch_id'              => $branch_id,
      'created_by'             => $request->user()->user_id,
      'updated_by'             => $request->user()->user_id,
      'status'                 => 3, // Assuming status = 3 for a new intern
    ];

    // Update or create the customer record
    ManageInternModel::updateOrCreate(
      ['lead_id' => $lead_id], // Match condition
      $customerData            // Data to update or insert
    );

    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($lead_id . '~' . '1', 'encrypt');
    return redirect()->route('lead_add_intern', ['id' => $encrypted_values]);
  }
 public function UpdateInternLead(Request $request)
{
    $branch_id = $request->user()->branch_id;

    // Step 1: Validate request data
    $request->validate([
        'lead_id'           => 'required|integer',
        'college_id'        => 'required|integer',
        'topic_id'          => 'required',
        'payment'           => 'required|numeric',
        'start_date'        => 'required|date_format:d-M-Y',
        'end_date'          => 'required|date_format:d-M-Y',
        'staff_id'          => 'required|integer',
        'intern_name'       => 'required|string',
        'intern_email_id'   => 'required|email',
        'intern_mobile_no'  => 'required|digits:10',
    ]);

    // Fetch branch details
    $branch_check = BranchModel::where('sno', $branch_id)->first();
    $branch_code = $branch_check->city_short_code ?? '';

    // Find the intern record by lead_id
    $intern = ManageInternModel::where('lead_id', $request->lead_id)->first();

    if (!$intern) {
        return redirect()->back()->with('error', 'Intern record not found.');
    }

    // Prepare update data
    $updateData = [
        'branch_id'     => $branch_id,
        'college_id'    => $request->colleage_id,
        'topic'         => $request->topic_id,
        'intern_name'   => $request->intern_name,
        'intern_email'  => $request->intern_email_id,
        'intern_mobile' => $request->intern_mobile_no,
        'payment'       => $request->payment,
        'payment_gst'   => round(($request->payment * 18) / 100, 2),
        'paid'          => 0,
        'balance'       => $request->payment,
        'start_date'    => \Carbon\Carbon::createFromFormat('d-M-Y', $request->start_date)->format('Y-m-d'),
        'end_date'      => \Carbon\Carbon::createFromFormat('d-M-Y', $request->end_date)->format('Y-m-d'),
        'staff_id'      => $request->staff_id,
        'updated_by'    => $request->user()->id ?? null,
        'status'        => 0,
    ];

    // Update intern record
    $intern->update($updateData);

    return redirect('manage_intern')->with('success', 'Intern updated successfully!');
}

//  public function Change(Request $request)
// {
//     $intern = ManageInternModel::where('za_intern.status', '!=', 2)
//         ->where('za_intern.sno', $request->sno)
//         ->first();

//     if (!$intern) {
//         return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
//     }

//     // Reset the company and certificate issue date
//     $intern->company_id = null;
//     $intern->certificate_issue_date = null;
//     $intern->save();

//     return response()->json([
//         'status' => 'success',
//         'message' => 'Intern reset successfully',
//         'data' => $intern
//     ]);
// }

public function Change(Request $request)
{
    $intern = ManageInternModel::where('za_intern.status', '!=', 2)
        ->where('za_intern.sno', $request->sno)
        ->first();
 
    if (!$intern) {
        return response()->json(['status' => 'error', 'message' => 'Intern not found'], 404);
    }
 
    // Reset the company and certificate issue date
    $intern->user_type = NULL;
    $intern->company_id = NULL;
    $intern->degree_id = NULL;
    $intern->year = NULL;
    $intern->confirmation_date = NULL;
    $intern->college_to = NULL;
    $intern->certificate_issue_date = null;
    $intern->save();
 
    return response()->json([
        'status' => 'success',
        'message' => 'Intern reset successfully',
        'data' => $intern
    ]);
}
 

  public function internFeedback(Request $request, $id)
  {
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($id, 'decrypt');


    $customers = ManageInternModel::where('sno', $encrypted_values)
      ->select('intern_name', 'sno')
      ->first();


    if (!$customers) abort(404);

    // read last entry if exists
    $existing = DB::table('za_intern_feedback_answer')
      ->where('student_id', $encrypted_values)
      ->latest()
      ->first();

    $feedback_submitted = !empty($existing);

    // default
    $coupon = '';
    $percentage = '';

    if ($existing) {
      $coupon     = $existing->student_coupon;
      $percentage = $existing->student_percentage;
    }

    $languages = FeedBackInternQuestionModel::where('za_feedback_intern_question.status', 0)
      ->join('za_languages', 'za_languages.sno', '=', 'za_feedback_intern_question.language_id')
      ->select('za_languages.sno as language_id', 'za_languages.name', 'za_languages.native_name')
      ->distinct()
      ->get();
    // return $languages;

    return view('content.customer.manage_intern.intern_feedback', compact(
      'customers',
      'feedback_submitted',
      'coupon',
      'percentage',
      'languages'
    ));
  }

  public function ListFeedback(Request $request, $id)
  {
    $studentId = $request->input('student_id');
    $batchId   = $request->input('event_id');


    // Base query
    $leadquestion = FeedBackInternQuestionModel::select(
      'za_feedback_intern_question.sno as sno',
      'za_feedback_intern_question.category_question_name',
      'za_feedback_intern_question.category_question_option',
      'za_feedback_intern_question.category_question_type',
      'za_feedback_intern_question.language_id',
      'za_feedback_intern_question.section_id',
      // 'za_section.sno as section_sno',
      // 'za_section.section as section_name'
    )
      // ->join('za_section', 'za_section.sno', '=', 'za_feedback_intern_question.section_id')
      ->where('za_feedback_intern_question.status', 0)
      ->where('za_feedback_intern_question.language_id', $id);

    $leadquestion = $leadquestion
      ->orderBy('za_feedback_intern_question.section_id')
      ->orderBy('za_feedback_intern_question.sno')
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $leadquestion
    ], 200);
  }


  // ALTER TABLE `za_intern_feedback_answer` ADD `batch_id` INT NOT NULL AFTER `branch_id`;
  public function internFeedbackSubmit(Request $request, $id)
  {
    try {
      $student_id = $id;

      // Get the student
      $customer = ManageInternModel::where('sno', $student_id)->first();

      if (!$customer) {
        return response()->json([
          'status'  => 404,
          'message' => 'Student not found'
        ], 404);
      }

      // ---------------- CHECK ALREADY SUBMITTED ----------------
      $already = DB::table('za_intern_feedback_answer')
        ->where('student_id', $student_id)
        ->exists();

      if ($already) {
        return response()->json([
          'status'  => 409,
          'message' => 'Feedback already submitted.'
        ], 409);
      }

      // Get all answers from request
      $answers = $request->input('answers', []);

      if (empty($answers)) {
        return response()->json([
          'status'  => 400,
          'message' => 'No answers provided.'
        ], 400);
      }

      // Prepare feedback array
      $feedback = [];

      foreach ($answers as $index => $answer) {
        if (!isset($answer['question_id']) || !isset($answer['score'])) {
          continue; // Skip invalid entries
        }

        $feedback[] = [
          'question_id' => $answer['question_id'],
          'answer_value' => $answer['score'],
          'answer_score' => is_numeric($answer['score']) ? (int) $answer['score'] : ($answer['score'] === 'yes' ? 1 : 0)
        ];
      }

      // ---- FORMAT COMPLETE JSON STRUCTURE ----
      $saveJson = [
        "student" => [
          "id"   => $student_id,
          "name" => $customer->intern_name
        ],
        "branch_id" => $customer->branch_id,
        "submitted_at" => now()->toISOString(),
        "answers" => $feedback
      ];


      // ----- RANDOM COUPON -----
      function generateCoupon($length = 9)
      {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';

        for ($i = 0; $i < $length; $i++) {
          $code .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $code;
      }

      // ----- HANDLE RANGE -------
      $range = $customer->range_percentage;  // "5-10"
      $min = 0;
      $max = 0;

      if ($range && strpos($range, '-') !== false) {
        [$min, $max] = explode('-', $range);
      }

      $min = intval($min);
      $max = intval($max);

      // fallback if data wrong
      if ($max <= $min) {
        $min = 5;
        $max = 10;
      }

      // random percentage between min and max
      $percentage = rand($min, $max);

      // random coupon
      $couponCode = generateCoupon();

      // ---------------- INSERT JSON ----------------
      DB::table('za_intern_feedback_answer')->insert([
        'student_id'    => $student_id,
        'branch_id'     => $customer->branch_id,
        'language_id'      => $request->language_id,
        'feedback_json' => json_encode($saveJson, JSON_PRETTY_PRINT),
        'status' => 1,
        'student_coupon'     => $couponCode,
        'student_percentage' => $percentage,
        'created_at'    => now(),
        'updated_at'    => now(),
      ]);

      return response()->json([
        'status'  => 200,
        'coupon'  => $couponCode,
        'percentage' => $percentage,
        'message' => 'Thank you! Your feedback was submitted successfully.'
      ], 200);
    } catch (\Exception $e) {

      return response()->json([
        'status'  => 500,
        'message' => $e->getMessage(),
      ], 500);
    }
  }

  public function internWise(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $search = $request->search_data;
    $course_id   = $request->input('college_id', '');
    $batch_id = $request->input('company_id', '');
    $date        = $request->input('date', ''); // today, week, month, custom

    $completeListQuery = DB::table('za_intern_feedback_answer')
      ->where('za_intern_feedback_answer.branch_id', $branch_id)
      ->join('za_intern', 'za_intern.sno', '=', 'za_intern_feedback_answer.student_id')
      ->join('za_college', 'za_college.sno', '=', 'za_intern.college_id')
      ->join('za_letter_pad', 'za_letter_pad.sno', '=', 'za_intern.company_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_intern.staff_id')
      ->select(
        'za_intern_feedback_answer.sno as answer_sno',
        'za_intern_feedback_answer.feedback_json',
        'za_intern_feedback_answer.created_at',
        'za_intern.sno as event_id',
        'za_college.college_name',
        'za_letter_pad.company',
        'za_intern.user_type',
        'za_intern.start_date',
        'za_intern.end_date',
        'za_intern.branch_id as batch_branch_id',
        'za_intern.intern_name',
        'za_intern.intern_mobile',
        'za_intern.year',
        'za_intern.sno',
        'za_staff.staff_name',
        'za_staff.nick_name as staff_nick_name',
        'za_staff.staff_image'
      );

    // Course filter
    if ($course_id != '') {
      $completeListQuery->where('za_college.sno', $course_id);
    }
    // batch filter
    if ($batch_id != '') {
      $completeListQuery->where('za_letter_pad.sno', $batch_id);
    }

    // Date filter
    if ($date != '' && $date != 'all') {
      if ($date == 'today') {
        $completeListQuery->whereDate('za_intern.start_date', today());
      } elseif ($date == 'week') {
        $completeListQuery->whereBetween('za_intern.start_date', [now()->startOfWeek(), now()->endOfWeek()]);
      } elseif ($date == 'monthly') {
        $completeListQuery->whereMonth('za_intern.start_date', now()->month)
          ->whereYear('za_intern.start_date', now()->year);
      } elseif ($date == 'custom') {
        $from = $request->input('from_date');
        $to   = $request->input('to_date');
        if ($from && $to) {
          $completeListQuery->whereBetween('za_intern.start_date', [$from, $to]);
        }
      }
    }

    // Finally execute the query

    // ------------------ SEARCH FILTER ---------------------
    if (!empty($search)) {
      $completeListQuery->where(function ($q) use ($search) {
        $q->where('za_intern.intern_name', 'LIKE', "%$search%")
          ->orWhere('za_college.college_name', 'LIKE', "%$search%")
          ->orWhere('za_letter_pad.company', 'LIKE', "%$search%");
      });
    }

    $completeList = $completeListQuery->get();

    // ------------------ LOAD QUESTIONS --------------------
    $questions = DB::table('za_feedback_event_question')
      ->select('sno', 'section_id', 'language_id')
      ->get()
      ->keyBy('sno'); // Map by question_id

    // total overall questions
    $totalQuestions = $questions->where('language_id', 15)->count();

    // Count staff questions (section_id = 2 only as per your request)
    $totalStaffQuestions = $questions->where('section_id', 2)->count();
    $totalInfraQuestions = $questions->where('section_id', 1)->count(); // using this only
    $totalUnderQuestions = $questions->where('section_id', 3)->count();

    // ------------------ FORMAT OUTPUT --------------------
    $result = $completeList->map(function ($item) use ($questions, $totalQuestions, $totalStaffQuestions, $totalInfraQuestions, $totalUnderQuestions) {

      $answers = json_decode($item->feedback_json, true)['answers'] ?? [];

      $totalScore = 0;
      $totalScoreQuestion = 0;
      $staffScore = 0;
      $infraScore = 0;
      $underScore = 0;

      foreach ($answers as $answer) {
        $qId = $answer['question_id'];
        $score = $answer['answer_score'] ?? 0;
        $qust = $answer['question_id'] ?? 0;

        $totalScore += $score;
        $totalScoreQuestion = $qust;

        // staff-score: only section 2 questions
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 2 || $questions[$qId]->section_id == 8)) {
          $staffScore += $score;
        }
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 1 || $questions[$qId]->section_id == 7)) {
          $infraScore += $score;
        }
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 3 || $questions[$qId]->section_id == 9)) {
          $underScore += $score;
        }
      }

      // max marks
      $BatchTotalMark = 5 * $totalScoreQuestion;
      $StaffTotalMark = 5 * $totalStaffQuestions;
      $InfraTotalMark = 5 * $totalInfraQuestions;
      $UnderTotalMark = 5 * $totalUnderQuestions;

      // percentages
      $batchPercentage = ($BatchTotalMark > 0)
        ? round(($totalScore / $BatchTotalMark) * 100)
        : 0;

      $staffPercentage = ($StaffTotalMark > 0)
        ? round(($staffScore / $StaffTotalMark) * 100)
        : 0;

      $infraPercentage = ($InfraTotalMark > 0)
        ? round(($infraScore / $InfraTotalMark) * 100)
        : 0;

      $underPercentage = ($UnderTotalMark > 0)
        ? round(($underScore / $UnderTotalMark) * 100)
        : 0;

      // count unique students from za_intern
      $studentCount = DB::table('za_intern')
        // ->where('company_id', $item->company_id)
        ->distinct('sno')
        ->count('sno');

      $studentCountFormatted = str_pad($studentCount, 2, '0', STR_PAD_LEFT);
      $batchStartDate   = Carbon::parse($item->start_date)->format('d-M-Y');
      $batchEndDate   = Carbon::parse($item->end_date)->format('d-M-Y');
      return [
        "cus_name"         => $item->intern_name,
        "participant_id"         => $item->intern_mobile,
        "cus_sno"           => $item->sno,
        "batch_name"         => $item->college_name,
        "course_type_name"   => $item->company,

        "batch_start_date"   => $batchStartDate,
        "batch_end_date"   => $batchEndDate,

        "student_count"      => $studentCountFormatted,

        "batch_percentage"   => $batchPercentage,
        "batch_totalmark"    => $BatchTotalMark,
        "batchScore"         => $totalScore,


        "infra_percentage"   => $infraPercentage,
        "infra_totalmark"    => $InfraTotalMark,
        "infraScore"         => $infraScore,

        "staff_image"        => $item->staff_image,
        "staff_name"         => $item->staff_name,
        "staff_nick_name"    => $item->staff_nick_name,
      ];
    });
    // Convert back to indexed array

    // return $result;

    return view('content.customer.manage_intern.intern_wise', [
      'completeList' => $result
      // 'submittedCount' => $submittedCount,
      // 'pendingCount' => $pendingCount,
      // 'totalBatches' => $totalBatches
    ]);
  }


  public function FeedbackIntern(Request $request, $id)
  {
    $branch_id = $request->user()->branch_id;

    $completeListQuery = DB::table('za_intern_feedback_answer')
      ->where('za_intern_feedback_answer.branch_id', $branch_id)
      ->where('za_intern_feedback_answer.student_id', $id)
      ->where('za_intern_feedback_answer.branch_id', $branch_id)
      ->join('za_intern', 'za_intern.sno', '=', 'za_intern_feedback_answer.student_id')
      ->join('za_college', 'za_college.sno', '=', 'za_intern.college_id')
      ->join('za_letter_pad', 'za_letter_pad.sno', '=', 'za_intern.company_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_intern.staff_id');

    $completeList = $completeListQuery->get();

    // ✅ FIXED: Added language_id filter and select language_id
    $allQuestions = DB::table('za_feedback_event_question as q')
      ->join('za_section', 'za_section.sno', '=', 'q.section_id')
      ->select(
        'q.sno as question_id',
        'q.category_question_name',
        'q.category_question_option',
        'q.category_question_type',
        'q.section_id',
        'q.language_id',
        'za_section.section as section_name'
      )
      ->where('q.status', 0)
      ->where('q.language_id', 15) // ✅ CRITICAL: Add this filter
      ->orderBy('q.section_id')
      ->orderBy('q.sno')
      ->get();

    $questions = $allQuestions->groupBy('section_id');

    // ✅ FIXED: Correct count methods
    $totalQuestions = $allQuestions->count();
    $totalStaffQuestions = $questions->get(2)?->count() ?? 0;
    $totalInfraQuestions = $questions->get(1)?->count() ?? 0;
    $totalUnderQuestions = $questions->get(3)?->count() ?? 0;


    $result = $completeList->map(function ($item) use ($questions, $allQuestions, $totalQuestions, $totalStaffQuestions, $totalInfraQuestions, $totalUnderQuestions) {
      $answers = json_decode($item->feedback_json, true)['answers'] ?? [];

      // ✅ FIXED: Calculate scores BEFORE section answers
      $totalScore = 0;
      $totalScoreQuestion = 0;
      $staffScore = 0;
      $infraScore = 0;
      $underScore = 0;

      foreach ($answers as $answer) {
        $qId = $answer['question_id'];
        $score = (int) $answer['answer_score'];
        $qust = (int) $answer['question_id'];

        $totalScore += $score;
        $totalScoreQuestion = $qust;

        $questionSection = $allQuestions->firstWhere('question_id', $qId)?->section_id;
        if (in_array($questionSection, [2, 8])) $staffScore += $score;
        if (in_array($questionSection, [1, 7])) $infraScore += $score;
        if (in_array($questionSection, [3, 9])) $underScore += $score;
      }

      // ✅ Build section-wise answers (only answered questions)
      $sectionAnswers = [];
      foreach ($questions as $sectionId => $sectionQuestions) {
        $answeredQuestions = [];

        foreach ($sectionQuestions as $question) {
          $answered = collect($answers)->firstWhere('question_id', (string) $question->question_id); // ✅ Cast to string

          if ($answered) {
            $answeredQuestions[] = [
              'question_id' => $question->question_id,
              'question_text' => $question->category_question_name,
              'question_type' => $question->category_question_type,
              'answer' => $answered['answer_value'],
              'score' => (int) $answered['answer_score'], // ✅ Cast to int
              'answered' => true
            ];
          }
        }

        if (!empty($answeredQuestions)) {
          $sectionAnswers[] = [
            'section_name' => $sectionQuestions->first()->section_name,
            'questions' => $answeredQuestions
          ];
        }
      }

      // Calculate percentages
      $BatchTotalMark = 5 * $totalScoreQuestion;
      $StaffTotalMark = 5 * $totalStaffQuestions;
      $InfraTotalMark = 5 * $totalInfraQuestions;
      $UnderTotalMark = 5 * $totalUnderQuestions;

      $batchPercentage = $BatchTotalMark > 0 ? round(($totalScore / $BatchTotalMark) * 100) : 0;
      $staffPercentage = $StaffTotalMark > 0 ? round(($staffScore / $StaffTotalMark) * 100) : 0;
      $infraPercentage = $InfraTotalMark > 0 ? round(($infraScore / $InfraTotalMark) * 100) : 0;
      $underPercentage = $UnderTotalMark > 0 ? round(($underScore / $UnderTotalMark) * 100) : 0;

      return [
        "cus_name" => $item->intern_name,
        "participant_id"         => $item->intern_mobile,
        "cus_sno"           => $item->sno,
        "batch_name"         => $item->college_name,
        "course_type_name"   => $item->company,

        "batch_percentage" => $batchPercentage,
        "batch_totalmark" => $BatchTotalMark,
        "batchScore" => $totalScore,

        "staff_percentage" => $staffPercentage,
        "staff_totalmark" => $StaffTotalMark,
        "staffScore" => $staffScore,

        "infra_percentage" => $infraPercentage,
        "infra_totalmark" => $InfraTotalMark,
        "infraScore" => $infraScore,

        "under_percentage" => $underPercentage,
        "under_totalmark" => $UnderTotalMark,
        "underScore" => $underScore,

        "section_answers" => $sectionAnswers,
      ];
    });

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $result
    ]);
  }

  public function PreviewConfirmationCertificate(Request $request){

    // return $request;
    
    $is_update_confirm_date = isset($request->is_update_confirm_date) && !empty($request->is_update_confirm_date) ? $request->is_update_confirm_date : 2;

    if($is_update_confirm_date == 2){
      $rules = [
        'intern_id' => 'required|integer',
      ];
    }else{
      $rules = [
        'intern_id' => 'required|integer',
        'confirm_company_id' => 'required|integer',
        'confirm_user_type' => 'required',
        'confirm_date' => 'required',
      ];
    }

    // Basic required validation

    $request->validate($rules);

    try {
        // Find intern by ID
        $intern = ManageInternModel::where('sno', $request->intern_id)->first();

        if (!$intern) {
          return response()->json(['status' => false, 'message' => 'Intern not found']);
        }

       $is_html_enable = isset($request->is_html_enable) && !empty($request->is_html_enable) ? $request->is_html_enable : 2;
        // Update intern fields
        
        if($is_update_confirm_date == 1){

          $intern->user_type = $request->confirm_user_type === 'Student' ? 1 : ($request->confirm_user_type === 'Employee' ? 2 : null);
          $intern->company_id = $request->confirm_company_id;
          $intern->degree_id = $request->confirm_degree_id ?? null; // null for Employee
          $intern->year = $request->confirm_year ?? null;
          $intern->confirmation_date = isset($request->confirm_date) && !empty($request->confirm_date) ? date("Y-m-d", strtotime($request->confirm_date)) : NULL;
          $intern->college_to = isset($request->confirmation_letter_to) && !empty($request->confirmation_letter_to) ? $request->confirmation_letter_to : NULL;
          $intern->save();
        }
        
        $company_details = LetterPadModel::where('sno', $intern->company_id)->first();
        $education_details = EducationModel::where('sno', $intern->degree_id)->first();
        $college_details = CollegeModel::where('sno', $intern->college_id)->first();
        $topic_details = TopicModel::where('sno', $intern->topic)->first();

        $intern->letter_logo = isset($company_details->letter_logo) && !empty($company_details->letter_logo) ? $company_details->letter_logo : null;
        $intern->letter_header = isset($company_details->letter_header) && !empty($company_details->letter_header) ? $company_details->letter_header : null;
        $intern->education_name = isset($education_details->education) && !empty($education_details->education) ? $education_details->education : null;
        $intern->college_name = isset($college_details->college_name) && !empty($college_details->college_name) ? $college_details->college_name : null;
        $intern->company_name = isset($company_details->company) && !empty($company_details->company) ? $company_details->company : null;
        $intern->company_desc = isset($company_details->letter_pad_desc) && !empty($company_details->letter_pad_desc) ? $company_details->letter_pad_desc : null;
        $intern->company_signature = isset($company_details->signature) && !empty($company_details->signature) ? $company_details->signature : null;
        $intern->topic_name = isset($topic_details->title) && !empty($topic_details->title) ? $topic_details->title : null;

        $helper = new \App\Helpers\Helpers();
        $encrypt_intern_id = isset($intern->sno) && !empty($intern->sno) ? $helper->encrypt_decrypt($intern->sno, 'encrypt') : null;

        $intern->encrypt_intern_id = $encrypt_intern_id;

        $intern_company_name = isset($intern->company_name) && !empty($intern->company_name) ? $intern->company_name : 'None';
        $intern_name = isset($intern->intern_name) && !empty($intern->intern_name) ? $intern->intern_name : 'None';
        $intern_start_date = isset($intern->start_date) && !empty($intern->start_date) ? date("d-M-Y", strtotime($intern->start_date)) : 'None';
        $intern_certificate_issue_date = isset($intern->certificate_issue_date) && !empty($intern->certificate_issue_date) ? $intern->certificate_issue_date : 'None';
        $intern_end_date = isset($intern->end_date) && !empty($intern->end_date) ? date("d-M-Y", strtotime($intern->end_date)) : 'None';

        $certificate_html = null;

        if($is_html_enable == 1){
          // return $qrBase64;
          $qrBase64 = $this->generateQr($intern);
  
          $intern->qrBase64 = $qrBase64;

          $certificate_html = view('content.customer.manage_intern.preview_certificate_confirm',[
            'interns' => $intern,
            'confirm_date' => isset($intern->confirmation_date) && !empty($intern->confirmation_date) ? date("Y-m-d", strtotime($intern->confirmation_date)) : NULL
          ])->render();

        }

        // return $certificate_html;

        return response()->json([
          'status' => true,
          'message' => 'Certificate generated successfully.',
          'intern_data' => $intern, // 1 = Student, 2 = Employee
          'user_type' => $intern->user_type, // 1 = Student, 2 = Employee
          'intern_id' => $intern->sno, // 1 = Student, 2 = Employee
          'certificate_html' => $certificate_html // 1 = Student, 2 = Employee
        ]);
    } catch (\Exception $e) {
        return response()->json(['status' => false, 'message' => 'Failed to update certificate data.']);
    }
  }

  public function PrintConfirmationCertificate($intern_id, Request $request){

    try {

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($intern_id, 'decrypt');

      if (!$decryptedValue) {
        return response()->json(['status' => false, 'message' => 'Intern ID not found']);
      }

      // Find intern by ID
      $intern = ManageInternModel::where('sno', $decryptedValue)->first();

      if (!$intern) {
          return response()->json(['status' => false, 'message' => 'Intern not found']);
      }

      $company_details = LetterPadModel::where('sno', $intern->company_id)->first();
      $education_details = EducationModel::where('sno', $intern->degree_id)->first();
      $college_details = CollegeModel::where('sno', $intern->college_id)->first();
      $topic_details = TopicModel::where('sno', $intern->topic)->first();

      $intern->letter_logo = isset($company_details->letter_logo) && !empty($company_details->letter_logo) ? $company_details->letter_logo : null;
      $intern->letter_header = isset($company_details->letter_header) && !empty($company_details->letter_header) ? $company_details->letter_header : null;
      $intern->education_name = isset($education_details->education) && !empty($education_details->education) ? $education_details->education : null;
      $intern->college_name = isset($college_details->college_name) && !empty($college_details->college_name) ? $college_details->college_name : null;
      $intern->company_name = isset($company_details->company) && !empty($company_details->company) ? $company_details->company : null;
      $intern->company_desc = isset($company_details->letter_pad_desc) && !empty($company_details->letter_pad_desc) ? $company_details->letter_pad_desc : null;
      $intern->company_signature = isset($company_details->signature) && !empty($company_details->signature) ? $company_details->signature : null;
      $intern->topic_name = isset($topic_details->title) && !empty($topic_details->title) ? $topic_details->title : null;

      $encrypt_intern_id = isset($intern->sno) && !empty($intern->sno) ? $helper->encrypt_decrypt($intern->sno, 'encrypt') : null;

      $intern->encrypt_intern_id = $encrypt_intern_id;

      $intern_company_name = isset($intern->company_name) && !empty($intern->company_name) ? $intern->company_name : 'None';
      $intern_name = isset($intern->intern_name) && !empty($intern->intern_name) ? $intern->intern_name : 'None';
      $intern_start_date = isset($intern->start_date) && !empty($intern->start_date) ? date("d-M-Y", strtotime($intern->start_date)) : 'None';
      $intern_certificate_issue_date = isset($intern->certificate_issue_date) && !empty($intern->certificate_issue_date) ? $intern->certificate_issue_date : 'None';
      $intern_end_date = isset($intern->end_date) && !empty($intern->end_date) ? date("d-M-Y", strtotime($intern->end_date)) : 'None';

      $qrBase64 = $this->generateQr($intern);

      $intern->qrBase64 = $qrBase64;

      return view('content.customer.manage_intern.print_certificate_confirm',[
        'interns' => $intern,
        'confirm_date' => isset($intern->confirmation_date) && !empty($intern->confirmation_date) ? date("Y-m-d", strtotime($intern->confirmation_date)) : NULL
      ]);

    } catch (\Exception $e) {
      return response()->json(['status' => false, 'message' => 'Failed to update certificate data.']);
    }
  }

  private function generateQr($intern)
  {
    if (empty($intern) || empty($intern->sno)) {
      return null;
    }

    $helper = new \App\Helpers\Helpers();

    $serverType = $helper->getServerType(request()->getHost());

    $combinedId = $serverType . '|' . $intern->sno;

    $encryptedId = $this->encryptForCentral($combinedId);

    if (empty($encryptedId)) {
      return null;
    }

    $centralServerUrl = rtrim(
      env('CENTRAL_VERIFICATION_URL', 'https://verified.place'),
        '/'
    );

    $verificationUrl = $centralServerUrl . '/v/' . urlencode($encryptedId);

    $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data={$verificationUrl}&size=200x200";

    $context = stream_context_create([
      'http' => [
        'timeout' => 5
      ]
    ]);

    $qrImageData = @file_get_contents($qrServerUrl, false, $context);

    if ($qrImageData === false) {
      return null;
    }

    return 'data:image/png;base64,' . base64_encode($qrImageData);
  }

  private function encryptForCentral($data)
  {
    if (empty($data)) {
      return null;
    }

    $key = env('CENTRAL_SECRET_KEY', 'jsdefnhJHWGQWEQWEBK2026');

    if (empty($key)) {
      return null;
    }

    $cipher = 'AES-128-CBC';
    $iv = substr(md5($key), 0, 16);

    $encrypted = openssl_encrypt(
      $data,
      $cipher,
      $key,
      0,
      $iv
    );

    if ($encrypted === false) {
      return null;
    }

    return base64_encode($encrypted);
  }

  public function collegeList(Request $request)
  {
    $branch_id = (string) $request->user()->branch_id;
    $College = CollegeModel::where('status', 0)->orderBy('sno', 'desc')->get();

    $filtered = $College->filter(function ($item) use ($branch_id) {
      $branchIds = json_decode($item->branch_id, true); // decode the string
      return in_array((string)$branch_id, $branchIds ?? []);
    });
    $data = $filtered->values();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  public function companyList(Request $request)
  {
    $branch_id = (string) $request->user()->branch_id;

    $allPads = LetterPadModel::where('status', 0)
      ->orderBy('sno', 'desc')
      ->get();

    $filtered = $allPads->filter(function ($item) use ($branch_id) {
      $branchIds = json_decode($item->branch_id, true); // decode the string
      return in_array((string)$branch_id, $branchIds ?? []);
    });
    $data = $filtered->values();
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  
public function accessData(Request $request)
  {
 
    $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 6)->first();
    return $whatsappConfig;
  }
 
  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
 
      ]);
 
      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }

 public function getCustomerDetails($id)
  {
    $customer = DB::table('za_customer')
      ->select('sno as customer_id', 'customer_id as cus_id', 'cus_name', 'cus_mobile', 'cus_email_id')
      ->where('sno', $id)
      ->first();

    if (!$customer) {
      return response()->json(['error' => 'Customer not found'], 404);
    }

    return response()->json([
      'customer_id' => $customer->customer_id,
      'cus_id' => $customer->cus_id,
      'customer_name' => $customer->cus_name,
      'mobile' => $customer->cus_mobile,
      'email' => $customer->cus_email_id
    ]);
  }

  /**
   * Get all colleges
   */
  public function getColleges(Request $request)
  {
    $branch_id = (string) $request->user()->branch_id;
    $College = CollegeModel::where('status', 0)->orderBy('college_name')->get();

    $filtered = $College->filter(function ($item) use ($branch_id) {
      $branchIds = json_decode($item->branch_id, true); // decode the string
      return in_array((string)$branch_id, $branchIds ?? []);
    });
    $colleges = $filtered->values();

    return response()->json($colleges);
  }

  /**
   * Get all topics
   */
  public function getTopics()
  {
    $topics = DB::table('za_topic')
      ->select('sno', 'title')
      ->where('status', 0) // Assuming 1 = active
      ->orderBy('title')
      ->get();

    return response()->json($topics);
  }

  /**
   * Get all staff members
   */
  public function getStaff(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $staff = DB::table('za_staff')
      ->select('sno', 'staff_name')
      ->where('status', 0) // Assuming 0 = active
      ->where('za_staff.branch_id', $branch_id)
      ->where('za_staff.department_id', 2)
      ->orderBy('staff_name')
      ->get();

    return response()->json($staff);
  }

  /**
   * Create new internship
   */
  public function createInternship(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Validate request
    $validator = Validator::make($request->all(), [
      'customer_id' => 'required',
      'college_id' => 'required',
      'topic_id' => 'required',
      'start_date' => 'required',
      'end_date' => 'required',
      'staff_id' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'success' => false,
        'errors' => $validator->errors()
      ], 422);
    }

    try {
      // Begin transaction
      DB::beginTransaction();

      // Check if customer already has an active internship
      $existingInternship = DB::table('za_customer')
        ->where('sno', $request->customer_id)
        ->first();

      if (!$existingInternship) {
        return response()->json([
          'success' => false,
          'message' => 'Customer Not found'
        ]);
      }

      // Generate unique internship ID
      $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
      $branch_code = $branch_check->city_short_code;
      $year = date("Y");

      // Get last intern_id for the same branch and format
      $intern_check = ManageInternModel::whereNotNull('intern_id')
        ->where('intern_id', 'LIKE', $year . '/' . $branch_code . '/IND%')
        ->orderByRaw("CAST(SUBSTRING_INDEX(intern_id, 'IND', -1) AS UNSIGNED) DESC")
        ->first();

      if (!$intern_check || !isset($intern_check->intern_id)) {
        $internshipId = $year . '/' . $branch_code . '/' . "IND2005";
      } else {
        $last_intern_id = $intern_check->intern_id; // e.g. 2025/MDU01/IND2042
        $parts = explode("/", $last_intern_id);

        if (isset($parts[2]) && preg_match('/IND(\d+)/', $parts[2], $matches)) {
          $next_number = (int)$matches[1] + 1;
        } else {
          $next_number = 2005;
        }

        $new_code = sprintf("IND%04d", $next_number);
        $internshipId = $year . '/' . $branch_code . '/' . $new_code;
      }
      // Insert internship record
      $inserted = DB::table('za_intern')->insert([
        'intern_id' => $internshipId,
        'branch_id' => $branch_id,
        'user_type' => 1, //default
        'intern_name' => $existingInternship->cus_name,
        'intern_email' => $existingInternship->cus_email_id,
        'intern_mobile' => $existingInternship->cus_mobile,
        'customer_id' => $request->customer_id,
        'college_id' => $request->college_id,
        'topic' => $request->topic_id,
        'start_date' => $request->start_date,
        'end_date' => $request->end_date,
        'payment' => 0, //default
        'payment_gst' => 0, //default
        'paid' => 0, //default
        'balance' => 0, //default
        'staff_id' => $request->staff_id,
        'status' => 0,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'created_at' => now(),
        'updated_at' => now()
      ]);

      if (!$inserted) {
        throw new \Exception('Failed to create internship');
      }

      // Commit transaction
      DB::commit();

      return response()->json([
        'success' => true,
        'message' => 'Internship created successfully!',
        'internship_id' => $internshipId
      ]);
    } catch (\Exception $e) {
      // Rollback transaction
      DB::rollBack();

      return response()->json([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
      ], 500);
    }
  }
  
}
