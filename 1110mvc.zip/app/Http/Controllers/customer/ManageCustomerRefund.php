<?php

namespace App\Http\Controllers\customer;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModeModel;
use App\Models\SubLedgerModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageCustomerRefund extends Controller
{

  public function Index(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $customers = DropRefundModel::select(
      'za_drop_refund.*',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.sno AS cus_sno',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_staff.staff_name',
      'created_staff.staff_name AS created_staff_name',
      'bh_staff.staff_name AS bh_staff_name',
      'ac_staff.staff_name AS ac_staff_name',
      'za_payment_mode.paymentmode_name'
    )
      ->leftJoin('za_customer', 'za_drop_refund.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_course', 'za_drop_refund.course_id', '=', 'za_course.sno')
      ->leftJoin('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff AS created_staff', 'za_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('za_staff AS bh_staff', 'za_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('za_staff AS ac_staff', 'za_drop_refund.acc_id', '=', 'ac_staff.sno')
      ->leftJoin('za_payment_mode', 'za_drop_refund.refunded_payment_mode_id', '=', 'za_payment_mode.sno')
      ->leftJoin('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->where('za_drop_refund.type', 1)
      ->where('za_drop_refund.status', 0)
       ->where('za_drop_refund.branch_id', $branch_id)
      ->orderBy('za_drop_refund.sno', 'desc')
      ->paginate(25);


    // return $customers;

    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $pay_mode_list = PaymentModeModel::where('status', 0)->orderBy('paymentmode_name', 'ASC')->get();


    // return $pay_mode_list;
    return view('content.customer.customer_refund_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'pay_mode_list' => $pay_mode_list,
      'customer_name_fill' => '',
      'customer_fill' => '',
      'course_type_list' => $course_type_list,
      'course_type_fill' => '',
      'course_list' => $course_list,
      'course_name_fill' => '',
      'date_filter' => '',
      'fin_yr_fill' => '',
    ])->with('filter_on', false);
  }

  public function list_filter(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $customer_fill = $request->customer_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';
    // return $request;
    $query = DropRefundModel::select(
      'za_drop_refund.*',
      'za_training.paid_amount',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.sno AS cus_sno',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_staff.staff_name',
      'created_staff.staff_name AS created_staff_name',
      'bh_staff.staff_name AS bh_staff_name'
    )
      ->leftJoin('za_customer', 'za_drop_refund.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_course', 'za_drop_refund.course_id', '=', 'za_course.sno')
      ->leftJoin('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff AS created_staff', 'za_drop_refund.created_by', '=', 'created_staff.sno')
      ->leftJoin('za_staff AS bh_staff', 'za_drop_refund.bh_id', '=', 'bh_staff.sno')
      ->leftJoin('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->where('za_drop_refund.type', 1)
      ->where('za_drop_refund.status', 0)
       ->where('za_drop_refund.branch_id', $branch_id)
      ->orderBy('za_drop_refund.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_drop_refund.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_drop_refund.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_drop_refund.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_drop_refund.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_drop_refund.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_drop_refund.created_at', '<=', $toDate);
      }
    }

    if ($branch_id > 0) {
      $query->where('za_drop_refund.branch_id', $branch_id);
    }

    if ($customer_fill) {
      $query->where(function ($customer) use ($customer_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$customer_fill}%");
      });
    }
    if ($customer_name_fill) {
      $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }


    // Fetch Branch list ordered by sno in descending order
    $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate(25);

    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $pay_mode_list = PaymentModeModel::where('status', 0)->orderBy('paymentmode_name', 'ASC')->get();

    return view('content.customer.customer_refund_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'course_type_list' => $course_type_list,
      'pay_mode_list' => $pay_mode_list,
      'course_list' => $course_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'customer_fill' => $customer_fill,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,

    ])->with('filter_on', true);
  }

  public function customer_refund_bh_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();

    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'bh_status'        => $request->sts_change_type,
        'bh_reject_reason' => $request->bhreject_reason,
        'bh_status_date'   => now(),
        'bh_id'            => $user_id
      ]);

      if ($request->sts_change_type == 2) {
        $training_details = TrainingModel::where('sno', $drop_details->training_id)->first();
        $training_details->update([
          'status'           => 0,
          'drop_check'       => 0,
          'refund_amount'    => 0,
          'refund_date_drp'  => null,
          'drop_reason'      => null,
          'updated_by'       => $user_id
        ]);
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Authority Refund Rejected Successfully!'
        ]);
      } else {
        // Flash success message based on action type
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Authority Refund Accepted Successfully!'
        ]);
      }
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Authority Refund!'
      ]);
    }

    return redirect('/manage_customer_refund');
  }
  public function customer_refund_ac_status_change(Request $request)
  {
    // Fetch request data
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch old training details
    $drop_details = DropRefundModel::where('sno', $request->sts_change_id)->first();
    if ($drop_details) {
      // Update the training details
      $drop_details->update([
        'ac_status'        => $request->sts_change_type,
        // 'ac_reject_reason' => $request->bhreject_reason,
        'ac_status_date'   => now(),
        'acc_id'           => $user_id
      ]);

      // Flash success message based on action type
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'A/C Refund Accepted Successfully!'
      ]);
    } else {
      // Flash error message if drop details not found
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the A/C Refund!'
      ]);
    }

    return redirect('/manage_customer_refund');
  }
  public function customer_refunded_status_change(Request $request)
  {
    // Validate the required request inputs
    $request->validate([
      'sts_change_id' => 'required|integer',
      'refund_description' => 'required|string|max:255',
      'refunded_date' => 'required|date',
      'pay_mode_list' => 'required|integer',
    ]);
    // Fetch current user's branch and user ID
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    // Fetch related models and handle missing data cases
    $drop_details = DropRefundModel::find($request->sts_change_id);
    $training_details = TrainingModel::find($drop_details->training_id);
    // return $training_details;
    $customer_details = CustomerModel::find($training_details->customer_id);
    $subledger = SubLedgerModel::where('traning_sno', $training_details->sno)->first();
    if (!$subledger) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Subledger details not found!',
      ]);
      return redirect('/manage_customer_refund');
    }
    $branch = BranchModel::find($branch_id);
    $branch_code = $branch->city_short_code;
    // Generate a new transaction ID
    $last_transaction = TransactionModel::orderBy('sno', 'desc')->first();
    $next_number = $last_transaction
      ? sprintf("%04d", (int)preg_replace('/[^0-9]/', '', $last_transaction->sno) + 1)
      : "0001";
    $transaction_id = date('Y') . "/{$branch_code}/DR{$next_number}";
    // Start a database transaction to ensure atomicity
    $insert =
      TransactionModel::create([
        'ledger_id' => 2,
        'subledger_id' => $subledger->sno,
        'transaction_id' => $transaction_id,
        'transaction_name' => 'Refund',
        'trans_source_id' => $customer_details->customer_id,
        'credit' => 0,
        'debit' => $drop_details->refund_amount,
        'total_amount' => $drop_details->refund_amount,
        'tax' => 0,
        'transaction_type' => 'Debit',
        'trans_desc' => $request->refund_description,
        'status' => 1,
        'branch_id' => $branch_id,
        'created_by' => $user_id,
        'updated_by' => $user_id,
        'daily_acc_chk' => 0,
      ]);

    if ($insert) {
      // Update the drop refund details
      $drop_details->update([
        'ac_status' => 2,
        'ac_status_date' => now(),
        'acc_id' => $user_id,
        'refunded_reason' => $request->refund_description,
        'refunded_date' => date('Y-m-d', strtotime($request->refunded_date)),
        'refunded_payment_mode_id' => $request->pay_mode_list,
      ]);

      // Flash success message and redirect
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Amount Refund Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Amount Refund !',
      ]);
    }

    return redirect('/manage_customer_refund');
  }
}
