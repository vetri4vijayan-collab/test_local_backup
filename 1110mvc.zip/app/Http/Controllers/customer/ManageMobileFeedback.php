<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class ManageMobileFeedback extends Controller
{

  public static $menu_heading = 'Mobile Feedback';

  public function index(Request $request)
  {
    $perPage = $request->input('per_page', 25);
    return view('content.customer.manage_mob_feedback.manage_mob_feedback_list', ['menu_heading' => self::$menu_heading, 'perpage' => $perPage]);
  }


  public function getFeedbackAccordionAjax(Request $request)
  {
    try {

      $user = $request->user();
      $branch_id = $user->branch_id;

      if (!$branch_id) {
        return response()->json([
          'status'  => false,
          'message' => 'No Branch ID found'
        ], 200);
      }

      $perPage = (int) $request->input('perpage', 25);
      $page    = (int) $request->input('page', 1);

      $customer_name_fill = $request->customer_name_fill ?? '';
      $course_name_fill   = $request->course_name_fill ?? '';
      $dt_fill_issue_rpt  = $request->dt_fill_issue_rpt ?? '';
      $corp_custom_from_dt_fill = $request->corp_custom_from_dt_fill ?? '';
      $corp_custom_to_dt_fill   = $request->corp_custom_to_dt_fill ?? '';

      $helper = new \App\Helpers\Helpers();

      /* ===========================
            BASE QUERY
            =========================== */
      $query = DB::table('za_attendance as a')
        ->join('za_course as co', 'co.sno', '=', 'a.course_id')
        ->join('za_customer as cu', 'cu.sno', '=', 'a.customer_id')
        ->leftJoin('za_staff as s', 's.sno', '=', 'a.staff_id')
        ->leftJoin('za_batch as b', 'b.sno', '=', 'a.batch_id')
        ->where('a.branch_id', $branch_id)
        ->whereNotNull('a.feedback_score')
        ->whereNotNull('a.feedback');

      /* ===========================
            DATE FILTERS
            =========================== */
      if ($dt_fill_issue_rpt === 'today') {

        $query->whereDate('a.created_at', date('Y-m-d'));
      } elseif ($dt_fill_issue_rpt === 'week') {

        $today = date('l');
        if ($today === 'Sunday') {
          $weekFromDate = date('Y-m-d', strtotime('sunday 0 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 1 week'));
        } else {
          $weekFromDate = date('Y-m-d', strtotime('sunday -1 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 0 week'));
        }

        $query->whereBetween(DB::raw('DATE(a.created_at)'), [$weekFromDate, $weekToDate]);
      } elseif ($dt_fill_issue_rpt === 'monthly') {

        $query->whereBetween(DB::raw('DATE(a.created_at)'), [date('Y-m-01'), date('Y-m-t')]);
      } elseif ($dt_fill_issue_rpt === 'custom_date') {

        $fromDate = $corp_custom_from_dt_fill ? date('Y-m-d', strtotime($corp_custom_from_dt_fill)) : null;
        $toDate   = $corp_custom_to_dt_fill ? date('Y-m-d', strtotime($corp_custom_to_dt_fill)) : null;

        if ($fromDate && $toDate) {
          $query->whereBetween(DB::raw('DATE(a.created_at)'), [$fromDate, $toDate]);
        } elseif ($fromDate) {
          $query->whereDate('a.created_at', '>=', $fromDate);
        } elseif ($toDate) {
          $query->whereDate('a.created_at', '<=', $toDate);
        }
      }

      /* ===========================
            COURSE / CUSTOMER FILTER
            =========================== */
      if ($request->filled('course_id')) {
        $query->where('a.course_id', $request->course_id);
      }

      if ($request->filled('customer_id')) {
        $query->where('a.customer_id', $request->customer_id);
      }

      if (!empty($customer_name_fill)) {
        $query->where(function ($q) use ($customer_name_fill) {
          $q->where('cu.cus_name', 'LIKE', "%{$customer_name_fill}%")
            ->orWhere('cu.cus_mobile', 'LIKE', "%{$customer_name_fill}%");
        });
      }

      if (!empty($course_name_fill)) {
        $query->where('co.course_name', 'LIKE', "%{$course_name_fill}%");
      }

      /* ===========================
            ACCORDION PAGINATION QUERY
            =========================== */
      $accordionQuery = (clone $query)
        ->select(
          'co.course_name',
          'co.course_id',
          'cu.customer_id as cus_code',
          'cu.sno as cu_sno',
          'cu.cus_name',
          'cu.cus_gender',
          'cu.cus_mobile',
          'cu.cus_pic',
          'b.batch_name',
          'b.status as batch_status',
          DB::raw('MAX(a.created_at) as latest_date')
        )
        ->groupBy(
          'co.course_name',
          'co.course_id',
          'cu.customer_id',
          'cu.sno',
          'cu.cus_name',
          'cu.cus_gender',
          'cu.cus_mobile',
          'cu.cus_pic',
          'b.batch_name',
          'b.status'
        )
        ->orderByDesc('latest_date');

      $accordionRows = $accordionQuery->paginate($perPage, ['*'], 'page', $page);

      if ($accordionRows->isEmpty()) {
        return response()->json([
          'status'  => false,
          'message' => 'No feedback found'
        ], 200);
      }

      /* ===========================
            FETCH ALL FEEDBACK
            =========================== */
      $rows = (clone $query)
        ->select(
          'a.*',
          'co.course_name',
          'co.course_id',
          'cu.customer_id as cus_code',
          'cu.sno as cu_sno',
          'cu.cus_name',
          'cu.cus_gender',
          'cu.cus_mobile',
          'cu.cus_pic',
          's.sno as staff_sno',
          's.staff_name',
          's.mobile_no as staff_mobile_no',
          's.email_id as staff_email_id',
          's.staff_image',
          's.gender as staff_gender',
          'b.batch_name',
          'b.status as batch_status',
          DB::raw('DATE(a.created_at) as feedback_date')
        )
        ->orderBy('a.created_at', 'DESC')
        ->get();

      /* ===========================
            RESPONSE SHAPING
            =========================== */
      $data = [];
      $cus_image_path   = 'cus_images/';
      $staff_image_path = 'staff_images/';

      foreach ($accordionRows as $row) {

        $courseKey   = $row->course_name;
        $customerKey = $row->cus_name;
        $batchKey    = $row->batch_name ?? 'No Batch';

        /* Customer image */
        $cus_image_full_path = $cus_image_path && $row->cus_pic ? $cus_image_path . $row->cus_pic : null;

        $cus_backgrounds = '';
        $cus_bg_color = '';
        $cus_bg_text_color = '';

        if (!$cus_image_full_path || !file_exists(public_path($cus_image_full_path))) {
          $cus_backgrounds = isset($row->cu_sno) ? $this->generateAvatarColors((int)$row->cu_sno) : null;
          $cus_bg_color = isset($cus_backgrounds['bg']) ? $cus_backgrounds['bg'] : null;
          $cus_bg_text_color = isset($cus_backgrounds['text']) ? $cus_backgrounds['text'] : null;
        }

        $cus_img_html = ($cus_image_full_path && file_exists(public_path($cus_image_full_path)))
          ? '<img src="' . asset($cus_image_full_path) . '" class="rounded-circle w-40px h-40px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
          : '<div class="avatar">
                            <span class="avatar-initial rounded-circle" style="background-color:' . $cus_bg_color . ' !important;color:' . $cus_bg_text_color . ' !important">' . (isset($row->cus_name) && !empty($row->cus_name) ? strtoupper(substr(($row->cus_name ?? 'U'), 0, 1)) : 'U') . '</span>
                        </div>';

        /* Course */
        $data[$courseKey]['course_details'] ??= [
          'course_name' => $row->course_name,
          'course_id'   => $row->course_id
        ];

        /* Customer */
        $data[$courseKey]['customers'][$customerKey]['customer_details'] ??= [
          'customer_name' => $row->cus_name,
          'customer_code' => $row->cus_code,
          'cu_sno' => $row->cu_sno,
          'cus_mobile'    => $row->cus_mobile,
          'cus_gender'    => $row->cus_gender,
          'cus_img_html'  => $cus_img_html
        ];

        /* Batch */
        $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['batch_details'] ??= [
          'batch_name' => $batchKey,
          'batch_status' => $row->batch_status
        ];
      }

      $row_count = count($rows) ?? 0;
      $line_count = 0;
      foreach ($rows as $row_key => $row) {
        
        $line_count = ($row_key ?? 0) + 1;

        $courseKey   = $row->course_name;
        $customerKey = $row->cus_name;
        $batchKey    = $row->batch_name ?? 'No Batch';


        if (isset($data[$courseKey]['customers'][$customerKey]['batches'][$batchKey])) {

          /* INIT RATING TRACK */
          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['total_rating'] ??= 0;
          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['rating_count'] ??= 0;
          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['last_fb_date'] ??= null;
          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['staff_details'] ??= null;

          /* Staff image */
          $staff_image_full_path = $staff_image_path && $row->staff_image ? $staff_image_path . $row->staff_image : null;

          $staff_backgrounds = '';
          $staff_bg_color = '';
          $staff_bg_text_color = '';

          if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {
            $staff_backgrounds = isset($row->staff_sno) ? $this->generateAvatarColors((int)$row->staff_sno) : null;
            $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
            $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;
          }

          $staff_img_html = ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
            ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
            : '<div class="avatar">
                                <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($row->staff_name) && !empty($row->staff_name) ? strtoupper(substr(($row->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                            </div>';
          
          $staff_over_img_html = ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
            ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
            : '<div class="avatar">
                <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($row->staff_name) && !empty($row->staff_name) ? strtoupper(substr(($row->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
            </div>';

          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['total_rating'] += (int)$row->feedback_score;
          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['rating_count'] += 1;

          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['feedbacks'][] = [
            'rating'     => (int) $row->feedback_score,
            'feedback'   => $row->feedback,
            'date'       => date('d-M-Y', strtotime($row->feedback_date)),
            'staff_name' => $row->staff_name,
            'staff_mobile_no' => $row->staff_mobile_no,
            'staff_email_id'  => $row->staff_email_id,
            'staff_img_html'  => $staff_img_html,
            'created_at' => $row->created_at
          ];

          if(!isset($data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['staff_details'])){
            $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['staff_details'] = [];
          }

          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['staff_details'][$row->staff_sno] = [
            'staff_sno' => $row->staff_sno ?? null,
            'staff_name' => $row->staff_name ?? null,
            'staff_mobile_no' => $row->staff_mobile_no ?? null,
            'staff_email_id'  => $row->staff_email_id ?? null,
            'staff_img_html'  => $staff_over_img_html ?? null,
          ];

          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['last_fb_date'] = isset($data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['feedbacks'][0]['date']) && !empty($data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['feedbacks'][0]['date']) ? $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['feedbacks'][0]['date'] : null;
          /* CALCULATE OVERALL */
          $total = $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['total_rating'];
          $count = $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['rating_count'];

          $data[$courseKey]['customers'][$customerKey]['batches'][$batchKey]['overall_rating'] = $count > 0
            ? round($total / $count, 1)
            : 0;
        }
      }

      return response()->json([
        'status' => true,
        'data'   => $data,
        'pagination' => [
          'current_page' => $accordionRows->currentPage(),
          'last_page'    => $accordionRows->lastPage(),
          'per_page'     => $accordionRows->perPage(),
          'total'        => $accordionRows->total(),
          'has_more'     => $accordionRows->hasMorePages()
        ]
      ], 200);
    } catch (\Throwable $e) {

      Log::error('Feedback Accordion AJAX Error', [
        'message' => $e->getMessage(),
        'file'    => $e->getFile(),
        'line'    => $e->getLine(),
      ]);

      return response()->json([
        'status'  => false,
        'message' => 'Something went wrong while loading feedback'
      ], 500);
    }
  }

  public function getFeedbackAjaxStaff(Request $request)
  {
    try {
      $user = $request->user();
      $branch_id = $user->branch_id;

      if (!$branch_id) {
        return response()->json([
          'status'  => false,
          'message' => 'No Branch ID found'
        ], 200);
      }

      $perPage = (int) $request->input('perpage', 25);
      $page    = (int) $request->input('page', 1);

      $staff_name_fill = $request->staff_name_fill ?? '';
      $course_name_fill   = $request->course_name_fill ?? '';
      $dt_fill_issue_rpt  = $request->dt_fill_issue_rpt ?? '';
      $corp_custom_from_dt_fill = $request->corp_custom_from_dt_fill ?? '';
      $corp_custom_to_dt_fill   = $request->corp_custom_to_dt_fill ?? '';

      $helper = new \App\Helpers\Helpers();

      /* ===========================
                  BASE QUERY
                  =========================== */
      $query = DB::table('za_attendance as a')
        ->join('za_staff as s', 's.sno', '=', 'a.staff_id')
        ->leftJoin('za_course as co', 'co.sno', '=', 'a.course_id')
        ->leftJoin('za_customer as cu', 'cu.sno', '=', 'a.customer_id')
        ->leftJoin('za_batch as b', 'b.sno', '=', 'a.batch_id')
        ->where('a.branch_id', $branch_id)
        ->whereNotNull('a.feedback_score')
        ->whereNotNull('a.feedback');

      /* ===========================
                  DATE FILTERS
                  =========================== */
      if ($dt_fill_issue_rpt === 'today') {
        $query->whereDate('a.created_at', date('Y-m-d'));
      } elseif ($dt_fill_issue_rpt === 'week') {
        $today = date('l');
        if ($today === 'Sunday') {
          $weekFromDate = date('Y-m-d', strtotime('sunday 0 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 1 week'));
        } else {
          $weekFromDate = date('Y-m-d', strtotime('sunday -1 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 0 week'));
        }
        $query->whereBetween(DB::raw('DATE(a.created_at)'), [$weekFromDate, $weekToDate]);
      } elseif ($dt_fill_issue_rpt === 'monthly') {
        $query->whereBetween(DB::raw('DATE(a.created_at)'), [date('Y-m-01'), date('Y-m-t')]);
      } elseif ($dt_fill_issue_rpt === 'custom_date') {
        $fromDate = $corp_custom_from_dt_fill ? date('Y-m-d', strtotime($corp_custom_from_dt_fill)) : null;
        $toDate   = $corp_custom_to_dt_fill ? date('Y-m-d', strtotime($corp_custom_to_dt_fill)) : null;

        if ($fromDate && $toDate) {
          $query->whereBetween(DB::raw('DATE(a.created_at)'), [$fromDate, $toDate]);
        } elseif ($fromDate) {
          $query->whereDate('a.created_at', '>=', $fromDate);
        } elseif ($toDate) {
          $query->whereDate('a.created_at', '<=', $toDate);
        }
      }

      /* ===========================
                  COURSE / STAFF FILTER
                  =========================== */
      if ($request->filled('course_id')) {
        $query->where('a.course_id', $request->course_id);
      }

      if ($request->filled('staff_id')) {
        $query->where('a.staff_id', $request->staff_id);
      }

      if (!empty($staff_name_fill)) {
        $query->where(function ($q) use ($staff_name_fill) {
          $q->where('s.staff_name', 'LIKE', "%{$staff_name_fill}%")
            ->orWhere('s.mobile_no', 'LIKE', "%{$staff_name_fill}%");
        });
      }

      if (!empty($course_name_fill)) {
        $query->where('co.course_name', 'LIKE', "%{$course_name_fill}%");
      }

      /* ===========================
                  FETCH ALL FEEDBACK FOR CALCULATIONS
                  =========================== */
      $feedbackRows = (clone $query)
        ->select(
          'a.feedback_score',
          'a.feedback',
          'a.created_at',
          's.sno as staff_sno',
          's.staff_name',
          's.mobile_no as staff_mobile',
          's.email_id as staff_email',
          's.staff_image',
          's.gender as staff_gender',
          'cu.cus_name',
          'cu.customer_id as cus_code',
          'cu.cus_mobile',
          'cu.cus_pic',
          'cu.sno as customer_sno',
          'co.course_name',
          'b.batch_name'
        )
        ->orderBy('a.created_at', 'DESC')
        ->get();

      /* ===========================
                  CALCULATE STAFF RATINGS AND COUNTS
                  =========================== */
      $staffData = [];
      $staff_image_path = 'staff_images/';
      $cus_image_path   = 'cus_images/';

      // Initialize rating counters for mini-dashboard
      $ratingCounts = [
        'overall_avg' => 0,
        'rating_1' => 0,
        'rating_2' => 0,
        'rating_3' => 0,
        'rating_4' => 0,
        'rating_5' => 0,
        'total_staff_with_feedback' => 0,
        'total_feedbacks' => 0
      ];

      // Group feedback by staff and calculate
      foreach ($feedbackRows as $fb) {
        $staffId = $fb->staff_sno;

        if (!isset($staffData[$staffId])) {
          /* Staff image */
          $staff_image_full_path = $staff_image_path && $fb->staff_image ? $staff_image_path . $fb->staff_image : null;

          $staff_backgrounds = '';
          $staff_bg_color = '';
          $staff_bg_text_color = '';

          if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {
            $staff_backgrounds = isset($fb->staff_sno) ? $this->generateAvatarColors((int)$fb->staff_sno) : null;
            $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
            $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;
          }

          $staff_img_html = ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
            ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-50px h-50px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
            : '<div class="avatar">
                              <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($fb->staff_name) && !empty($fb->staff_name) ? strtoupper(substr(($fb->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                          </div>';

          $staffData[$staffId] = [
            'staff_name'     => $fb->staff_name,
            'staff_sno'      => $fb->staff_sno,
            'staff_mobile'   => $fb->staff_mobile,
            'staff_email'    => $fb->staff_email,
            'staff_gender'   => $fb->staff_gender,
            'staff_img_html' => $staff_img_html,
            'total_rating'   => 0,
            'rating_count'   => 0,
            'overall_rating' => 0,
            'last_fb_date'   => null,
            'feedbacks'      => []
          ];
        }

        // Customer image for feedback entry
        $cus_image_full_path = $cus_image_path && isset($fb->cus_pic) ? $cus_image_path . $fb->cus_pic : null;

        $cus_backgrounds = '';
        $cus_bg_color = '';
        $cus_bg_text_color = '';

        if (!$cus_image_full_path || !file_exists(public_path($cus_image_full_path))) {
          $cus_backgrounds = isset($fb->customer_sno) ? $this->generateAvatarColors((int)$fb->customer_sno) : null;
          $cus_bg_color = isset($cus_backgrounds['bg']) ? $cus_backgrounds['bg'] : null;
          $cus_bg_text_color = isset($cus_backgrounds['text']) ? $cus_backgrounds['text'] : null;
        }

        $cus_img_html = ($cus_image_full_path && file_exists(public_path($cus_image_full_path)))
          ? '<img src="' . asset($cus_image_full_path) . '" class="rounded-circle w-40px h-40px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
          : '<div class="avatar">
                          <span class="avatar-initial rounded-circle" style="background-color:' . $cus_bg_color . ' !important;color:' . $cus_bg_text_color . ' !important">' . (isset($fb->cus_name) && !empty($fb->cus_name) ? strtoupper(substr(($fb->cus_name ?? 'U'), 0, 1)) : 'U') . '</span>
                      </div>';

        // Update staff ratings
        $staffData[$staffId]['total_rating'] += (int)$fb->feedback_score;
        $staffData[$staffId]['rating_count'] += 1;
        $ratingCounts['total_feedbacks']++;

        // Add feedback
        $staffData[$staffId]['feedbacks'][] = [
          'rating'        => (int) $fb->feedback_score,
          'feedback'      => $fb->feedback,
          'date'          => date('d-M-Y', strtotime($fb->created_at)),
          'student_name'  => $fb->cus_name ?? 'Unknown',
          'student_code'  => $fb->cus_code ?? '',
          'student_mobile' => $fb->cus_mobile ?? '',
          'student_img'   => $cus_img_html,
          'course_name'   => $fb->course_name ?? '',
          'batch_name'    => $fb->batch_name ?? 'No Batch'
        ];

        // Update last feedback date
        $feedbackDate = date('d-M-Y', strtotime($fb->created_at));
        if (!$staffData[$staffId]['last_fb_date'] || strtotime($fb->created_at) > strtotime($staffData[$staffId]['last_fb_date'])) {
          $staffData[$staffId]['last_fb_date'] = $feedbackDate;
        }
      }

      // Calculate overall ratings and populate rating counts
      $totalRatingSum = 0;
      foreach ($staffData as &$staff) {
        if ($staff['rating_count'] > 0) {
          $staff['overall_rating'] = round($staff['total_rating'] / $staff['rating_count'], 1);
          $totalRatingSum += $staff['overall_rating'];
          $ratingCounts['total_staff_with_feedback']++;

          // Categorize by rating range
          $rating = $staff['overall_rating'];
          if ($rating >= 1 && $rating < 2) {
            $ratingCounts['rating_1']++;
          } elseif ($rating >= 2 && $rating < 3) {
            $ratingCounts['rating_2']++;
          } elseif ($rating >= 3 && $rating < 4) {
            $ratingCounts['rating_3']++;
          } elseif ($rating >= 4 && $rating < 5) {
            $ratingCounts['rating_4']++;
          } elseif ($rating >= 5) {
            $ratingCounts['rating_5']++;
          }
        }
      }

      // Calculate overall average rating
      $ratingCounts['overall_avg'] = $ratingCounts['total_staff_with_feedback'] > 0
        ? round($totalRatingSum / $ratingCounts['total_staff_with_feedback'], 1)
        : 0;

      // Apply pagination to staff data
      $staffCollection = collect(array_values($staffData));

      // 🎯 Apply Rating Filter (ONLY if not 0)
      if ($request->filled('rating_value') && $request->rating_value != 0) {
        $rating = (int) $request->rating_value;
        $staffCollection = $staffCollection->filter(function ($item) use ($rating) {
          return floor($item['overall_rating']) == $rating;
        });
      }

      $total = $staffCollection->count();
      $paginatedData = $staffCollection->forPage($page, $perPage)->values()->all();

      return response()->json([
        'status' => true,
        'data'   => $paginatedData,
        'mini_dashboard' => [
          'overall_average' => [
            'label' => 'Overall Avg Rating',
            'value' => $ratingCounts['overall_avg'],
            'icon'  => 'ki-outline ki-star',
            'color' => 'primary',
            'tooltip' => 'Average rating across all staff'
          ],
          'rating_breakdown' => [
            [
              'rating' => 5,
              'count' => $ratingCounts['rating_5'],
              'label' => 'Excellent (5★)',
              'color' => 'success',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_staff_with_feedback'] > 0
                ? round(($ratingCounts['rating_5'] / $ratingCounts['total_staff_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 4,
              'count' => $ratingCounts['rating_4'],
              'label' => 'Good (4★)',
              'color' => 'info',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_staff_with_feedback'] > 0
                ? round(($ratingCounts['rating_4'] / $ratingCounts['total_staff_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 3,
              'count' => $ratingCounts['rating_3'],
              'label' => 'Average (3★)',
              'color' => 'warning',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_staff_with_feedback'] > 0
                ? round(($ratingCounts['rating_3'] / $ratingCounts['total_staff_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 2,
              'count' => $ratingCounts['rating_2'],
              'label' => 'Poor (2★)',
              'color' => 'danger',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_staff_with_feedback'] > 0
                ? round(($ratingCounts['rating_2'] / $ratingCounts['total_staff_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 1,
              'count' => $ratingCounts['rating_1'],
              'label' => 'Bad (1★)',
              'color' => 'dark',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_staff_with_feedback'] > 0
                ? round(($ratingCounts['rating_1'] / $ratingCounts['total_staff_with_feedback']) * 100, 1)
                : 0
            ]
          ],
          'summary' => [
            'total_staff_with_feedback' => $ratingCounts['total_staff_with_feedback'],
            'total_feedbacks' => $ratingCounts['total_feedbacks'],
            'staff_without_feedback' => 0 // You can add this if you have total staff count
          ]
        ],
        'pagination' => [
          'current_page' => $page,
          'last_page'    => ceil($total / $perPage),
          'per_page'     => $perPage,
          'total'        => $total,
          'has_more'     => $page < ceil($total / $perPage)
        ]
      ], 200);
    } catch (\Throwable $e) {
      Log::error('Staff Feedback AJAX Error', [
        'message' => $e->getMessage(),
        'file'    => $e->getFile(),
        'line'    => $e->getLine(),
      ]);

      return response()->json([
        'status'  => false,
        'message' => 'Something went wrong while loading staff feedback'
      ], 500);
    }
  }

  public function getFeedbackAjaxBatch(Request $request)
  {
    try {
      $user = $request->user();
      $branch_id = $user->branch_id;

      if (!$branch_id) {
        return response()->json([
          'status'  => false,
          'message' => 'No Branch ID found'
        ], 200);
      }

      $perPage = (int) $request->input('perpage', 25);
      $page    = (int) $request->input('page', 1);

      $batch_name_fill = $request->batch_name_fill ?? '';
      $course_name_fill = $request->course_name_fill ?? '';
      $staff_name_fill = $request->staff_name_fill ?? '';
      $dt_fill_issue_rpt = $request->dt_fill_issue_rpt ?? '';
      $corp_custom_from_dt_fill = $request->corp_custom_from_dt_fill ?? '';
      $corp_custom_to_dt_fill = $request->corp_custom_to_dt_fill ?? '';

      $helper = new \App\Helpers\Helpers();

      /* ===========================
                BASE QUERY
                =========================== */
      $query = DB::table('za_attendance as a')
        ->join('za_batch as b', 'b.sno', '=', 'a.batch_id')
        ->leftJoin('za_course as co', 'co.sno', '=', 'a.course_id')
        ->leftJoin('za_staff as s', 's.sno', '=', 'a.staff_id')
        ->leftJoin('za_customer as cu', 'cu.sno', '=', 'a.customer_id')
        ->where('a.branch_id', $branch_id)
        ->whereNotNull('a.feedback_score')
        ->whereNotNull('a.feedback')
        ->whereNotNull('a.batch_id'); // Only include records with batch

      /* ===========================
                DATE FILTERS
                =========================== */
      if ($dt_fill_issue_rpt === 'today') {
        $query->whereDate('a.created_at', date('Y-m-d'));
      } elseif ($dt_fill_issue_rpt === 'week') {
        $today = date('l');
        if ($today === 'Sunday') {
          $weekFromDate = date('Y-m-d', strtotime('sunday 0 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 1 week'));
        } else {
          $weekFromDate = date('Y-m-d', strtotime('sunday -1 week'));
          $weekToDate   = date('Y-m-d', strtotime('saturday 0 week'));
        }
        $query->whereBetween(DB::raw('DATE(a.created_at)'), [$weekFromDate, $weekToDate]);
      } elseif ($dt_fill_issue_rpt === 'monthly') {
        $query->whereBetween(DB::raw('DATE(a.created_at)'), [date('Y-m-01'), date('Y-m-t')]);
      } elseif ($dt_fill_issue_rpt === 'custom_date') {
        $fromDate = $corp_custom_from_dt_fill ? date('Y-m-d', strtotime($corp_custom_from_dt_fill)) : null;
        $toDate   = $corp_custom_to_dt_fill ? date('Y-m-d', strtotime($corp_custom_to_dt_fill)) : null;

        if ($fromDate && $toDate) {
          $query->whereBetween(DB::raw('DATE(a.created_at)'), [$fromDate, $toDate]);
        } elseif ($fromDate) {
          $query->whereDate('a.created_at', '>=', $fromDate);
        } elseif ($toDate) {
          $query->whereDate('a.created_at', '<=', $toDate);
        }
      }

      /* ===========================
                FILTERS
                =========================== */
      if ($request->filled('course_id')) {
        $query->where('a.course_id', $request->course_id);
      }

      if ($request->filled('batch_id')) {
        $query->where('a.batch_id', $request->batch_id);
      }

      if ($request->filled('staff_id')) {
        $query->where('a.staff_id', $request->staff_id);
      }

      if (!empty($batch_name_fill)) {
        $query->where('b.batch_name', 'LIKE', "%{$batch_name_fill}%");
      }

      if (!empty($course_name_fill)) {
        $query->where('co.course_name', 'LIKE', "%{$course_name_fill}%");
      }

      if (!empty($staff_name_fill)) {
        $query->where('s.staff_name', 'LIKE', "%{$staff_name_fill}%");
      }

      /* ===========================
                FETCH ALL FEEDBACK FOR CALCULATIONS
                =========================== */
      $feedbackRows = (clone $query)
        ->select(
          'a.feedback_score',
          'a.feedback',
          'a.created_at',
          'b.sno as batch_sno',
          'b.batch_name',
          'b.status as batch_status',
          'b.start_date',
          'b.end_date',
          'co.course_name',
          'co.course_id',
          's.sno as staff_sno',
          's.staff_name',
          's.mobile_no as staff_mobile',
          's.email_id as staff_email',
          's.staff_image',
          's.gender as staff_gender',
          'cu.cus_name',
          'cu.customer_id as cus_code',
          'cu.cus_mobile',
          'cu.cus_pic',
          'cu.sno as customer_sno'
        )
        ->orderBy('a.created_at', 'DESC')
        ->get();

      /* ===========================
                CALCULATE BATCH RATINGS AND COUNTS
                =========================== */
      $batchData = [];
      $staff_image_path = 'staff_images/';
      $cus_image_path = 'cus_images/';

      // Initialize rating counters for mini-dashboard
      $ratingCounts = [
        'overall_avg' => 0,
        'rating_1' => 0,
        'rating_2' => 0,
        'rating_3' => 0,
        'rating_4' => 0,
        'rating_5' => 0,
        'total_batches_with_feedback' => 0,
        'total_feedbacks' => 0,
        'active_batches' => 0,
        'completed_batches' => 0
      ];

      // Group feedback by batch and calculate
      foreach ($feedbackRows as $fb) {
        $batchId = $fb->batch_sno;

        if (!isset($batchData[$batchId])) {
          $batchData[$batchId] = [
            'batch_sno'      => $fb->batch_sno,
            'batch_name'     => $fb->batch_name,
            'batch_status'   => $fb->batch_status,
            'course_name'    => $fb->course_name,
            'course_id'      => $fb->course_id,
            'start_date'     => $fb->start_date ? date('d-M-Y', strtotime($fb->start_date)) : null,
            'end_date'       => $fb->end_date ? date('d-M-Y', strtotime($fb->end_date)) : null,
            'total_rating'   => 0,
            'rating_count'   => 0,
            'overall_rating' => 0,
            'unique_students' => [],
            'unique_staff'    => [],
            'last_fb_date'   => null,
            'feedbacks'      => []
          ];

          // Count batch status
          if ($fb->batch_status == 1) {
            $ratingCounts['active_batches']++;
          } elseif ($fb->batch_status == 0) {
            $ratingCounts['completed_batches']++;
          }
        }

        // Track unique students and staff
        if (!in_array($fb->customer_sno, $batchData[$batchId]['unique_students'])) {
          $batchData[$batchId]['unique_students'][] = $fb->customer_sno;
        }
        if (!in_array($fb->staff_sno, $batchData[$batchId]['unique_staff'])) {
          $batchData[$batchId]['unique_staff'][] = $fb->staff_sno;
        }

        // Staff image for feedback entry
        $staff_image_full_path = $staff_image_path && $fb->staff_image ? $staff_image_path . $fb->staff_image : null;

        $staff_backgrounds = '';
        $staff_bg_color = '';
        $staff_bg_text_color = '';

        if (!$staff_image_full_path || !file_exists(public_path($staff_image_full_path))) {
          $staff_backgrounds = isset($fb->staff_sno) ? $this->generateAvatarColors((int)$fb->staff_sno) : null;
          $staff_bg_color = isset($staff_backgrounds['bg']) ? $staff_backgrounds['bg'] : null;
          $staff_bg_text_color = isset($staff_backgrounds['text']) ? $staff_backgrounds['text'] : null;
        }

        $staff_img_html = ($staff_image_full_path && file_exists(public_path($staff_image_full_path)))
          ? '<img src="' . asset($staff_image_full_path) . '" class="rounded-circle w-40px h-40px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
          : '<div class="avatar">
                        <span class="avatar-initial rounded-circle" style="background-color:' . $staff_bg_color . ' !important;color:' . $staff_bg_text_color . ' !important">' . (isset($fb->staff_name) && !empty($fb->staff_name) ? strtoupper(substr(($fb->staff_name ?? 'U'), 0, 1)) : 'U') . '</span>
                    </div>';

        // Customer image for feedback entry
        $cus_image_full_path = $cus_image_path && isset($fb->cus_pic) ? $cus_image_path . $fb->cus_pic : null;

        $cus_backgrounds = '';
        $cus_bg_color = '';
        $cus_bg_text_color = '';

        if (!$cus_image_full_path || !file_exists(public_path($cus_image_full_path))) {
          $cus_backgrounds = isset($fb->customer_sno) ? $this->generateAvatarColors((int)$fb->customer_sno) : null;
          $cus_bg_color = isset($cus_backgrounds['bg']) ? $cus_backgrounds['bg'] : null;
          $cus_bg_text_color = isset($cus_backgrounds['text']) ? $cus_backgrounds['text'] : null;
        }

        $cus_img_html = ($cus_image_full_path && file_exists(public_path($cus_image_full_path)))
          ? '<img src="' . asset($cus_image_full_path) . '" class="rounded-circle w-40px h-40px" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;">'
          : '<div class="avatar">
                        <span class="avatar-initial rounded-circle" style="background-color:' . $cus_bg_color . ' !important;color:' . $cus_bg_text_color . ' !important">' . (isset($fb->cus_name) && !empty($fb->cus_name) ? strtoupper(substr(($fb->cus_name ?? 'U'), 0, 1)) : 'U') . '</span>
                    </div>';

        // Update batch ratings
        $batchData[$batchId]['total_rating'] += (int)$fb->feedback_score;
        $batchData[$batchId]['rating_count'] += 1;
        $ratingCounts['total_feedbacks']++;

        $batchData[$batchId]['staff_details'] ??= [];

        if(!isset($batchData[$batchId]['staff_details'])){
          $batchData[$batchId]['staff_details'] = [];
        }

        $batchData[$batchId]['staff_details'][$fb->staff_sno] = [
          'staff_sno' => $fb->staff_sno ?? null,
          'staff_name' => $fb->staff_name ?? null,
          'staff_mobile_no' => $fb->staff_mobile ?? null,
          'staff_email_id'  => $fb->staff_email ?? null,
          'staff_img_html'  => $staff_img_html ?? null,
        ];

        // Add feedback
        $batchData[$batchId]['feedbacks'][] = [
          'rating'         => (int) $fb->feedback_score,
          'feedback'       => $fb->feedback,
          'date'           => date('d-M-Y', strtotime($fb->created_at)),
          'student_name'   => $fb->cus_name ?? 'Unknown',
          'student_code'   => $fb->cus_code ?? '',
          'student_mobile' => $fb->cus_mobile ?? '',
          'student_img'    => $cus_img_html,
          'staff_name'     => $fb->staff_name ?? '',
          'staff_mobile'   => $fb->staff_mobile ?? '',
          'staff_img'      => $staff_img_html,
          'created_at'     => $fb->created_at
        ];

        // Update last feedback date
        $feedbackDate = date('d-M-Y', strtotime($fb->created_at));
        if (!$batchData[$batchId]['last_fb_date'] || strtotime($fb->created_at) > strtotime($batchData[$batchId]['last_fb_date'])) {
          $batchData[$batchId]['last_fb_date'] = $feedbackDate;
        }
      }

      // Calculate overall ratings and populate rating counts
      $totalRatingSum = 0;
      foreach ($batchData as &$batch) {
        if ($batch['rating_count'] > 0) {
          $batch['overall_rating'] = round($batch['total_rating'] / $batch['rating_count'], 1);
          $batch['student_count'] = count($batch['unique_students']);
          $batch['staff_count'] = count($batch['unique_staff']);

          // Remove temporary arrays
          unset($batch['unique_students']);
          unset($batch['unique_staff']);

          $totalRatingSum += $batch['overall_rating'];
          $ratingCounts['total_batches_with_feedback']++;

          // Categorize by rating range
          $rating = $batch['overall_rating'];
          if ($rating >= 1 && $rating < 2) {
            $ratingCounts['rating_1']++;
          } elseif ($rating >= 2 && $rating < 3) {
            $ratingCounts['rating_2']++;
          } elseif ($rating >= 3 && $rating < 4) {
            $ratingCounts['rating_3']++;
          } elseif ($rating >= 4 && $rating < 5) {
            $ratingCounts['rating_4']++;
          } elseif ($rating >= 5) {
            $ratingCounts['rating_5']++;
          }
        }
      }

      // Calculate overall average rating
      $ratingCounts['overall_avg'] = $ratingCounts['total_batches_with_feedback'] > 0
        ? round($totalRatingSum / $ratingCounts['total_batches_with_feedback'], 1)
        : 0;

      // Apply pagination to batch data
      $batchCollection = collect(array_values($batchData));

      // 🎯 Apply Rating Filter (ONLY if not 0)
      if ($request->filled('rating_value') && $request->rating_value != 0) {
        $rating = (int) $request->rating_value;
        $batchCollection = $batchCollection->filter(function ($item) use ($rating) {
          return floor($item['overall_rating']) == $rating;
        });
      }

      $total = $batchCollection->count();
      $paginatedData = $batchCollection->forPage($page, $perPage)->values()->all();

      return response()->json([
        'status' => true,
        'data'   => $paginatedData,
        'mini_dashboard' => [
          'overall_average' => [
            'label' => 'Overall Avg Batch Rating',
            'value' => $ratingCounts['overall_avg'],
            'icon'  => 'ki-outline ki-star',
            'color' => 'primary',
            'tooltip' => 'Average rating across all batches'
          ],
          'rating_breakdown' => [
            [
              'rating' => 5,
              'count' => $ratingCounts['rating_5'],
              'label' => 'Excellent (5★)',
              'color' => 'success',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_batches_with_feedback'] > 0
                ? round(($ratingCounts['rating_5'] / $ratingCounts['total_batches_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 4,
              'count' => $ratingCounts['rating_4'],
              'label' => 'Good (4★)',
              'color' => 'info',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_batches_with_feedback'] > 0
                ? round(($ratingCounts['rating_4'] / $ratingCounts['total_batches_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 3,
              'count' => $ratingCounts['rating_3'],
              'label' => 'Average (3★)',
              'color' => 'warning',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_batches_with_feedback'] > 0
                ? round(($ratingCounts['rating_3'] / $ratingCounts['total_batches_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 2,
              'count' => $ratingCounts['rating_2'],
              'label' => 'Poor (2★)',
              'color' => 'danger',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_batches_with_feedback'] > 0
                ? round(($ratingCounts['rating_2'] / $ratingCounts['total_batches_with_feedback']) * 100, 1)
                : 0
            ],
            [
              'rating' => 1,
              'count' => $ratingCounts['rating_1'],
              'label' => 'Bad (1★)',
              'color' => 'dark',
              'icon' => 'ki-outline ki-star',
              'percentage' => $ratingCounts['total_batches_with_feedback'] > 0
                ? round(($ratingCounts['rating_1'] / $ratingCounts['total_batches_with_feedback']) * 100, 1)
                : 0
            ]
          ],
          'summary' => [
            'total_batches_with_feedback' => $ratingCounts['total_batches_with_feedback'],
            'total_feedbacks' => $ratingCounts['total_feedbacks'],
            'active_batches' => $ratingCounts['active_batches'],
            'completed_batches' => $ratingCounts['completed_batches'],
            'avg_students_per_batch' => $total > 0
              ? round(collect($batchData)->avg('student_count'), 1)
              : 0,
            'avg_staff_per_batch' => $total > 0
              ? round(collect($batchData)->avg('staff_count'), 1)
              : 0
          ]
        ],
        'pagination' => [
          'current_page' => $page,
          'last_page'    => ceil($total / $perPage),
          'per_page'     => $perPage,
          'total'        => $total,
          'has_more'     => $page < ceil($total / $perPage)
        ]
      ], 200);
    } catch (\Throwable $e) {
      Log::error('Batch Feedback AJAX Error', [
        'message' => $e->getMessage(),
        'file'    => $e->getFile(),
        'line'    => $e->getLine(),
      ]);

      return response()->json([
        'status'  => false,
        'message' => 'Something went wrong while loading batch feedback'
      ], 500);
    }
  }

  private function generateAvatarColors(int $id = 0)
  {
    // Generate hue based on ID (0 - 360)
    $hue = ($id * 137) % 360; // 137 gives better color distribution

    // Dark background color using HSL
    $bg = "hsl($hue, 45%, 30%)";   // 30% lightness = dark
    $text = "hsl($hue, 90%, 90%)"; // Light text for contrast

    return [
      'bg'   => $bg,
      'text' => $text,
    ];
  }
}
