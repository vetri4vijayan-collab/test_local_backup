<?php

namespace App\Http\Controllers\staff_attendance;

use App\Http\Controllers\Controller;
use App\Models\DepartmentModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StaffAttendanceToday extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
    
        // Staff query
        $query = StaffModel::select(
            'za_staff.sno as staff_id',
            'za_staff.staff_name',
            'za_staff.nick_name',
            'za_staff.gender',
            'za_staff.staff_image',
            'za_staff.mobile_no',
            'za_staff.email_id',
            'za_department.department_name',
            'za_sub_department.sub_department_name',
            'za_branch.branch_name',
            'za_branch.franchise_name',
            'za_job_roll.job_roll_name',
            'za_staff_attendance.date',
            'za_staff_attendance.attendance',
            'za_staff_attendance.staff_id',
            'za_staff_attendance.time_start',
            'za_staff_attendance.time_end',
            'za_staff_attendance.reason'
        )
        ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
        ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
        ->leftJoin('za_staff_attendance', 'za_staff_attendance.staff_id', '=', 'za_staff.sno')
        ->leftJoin('za_job_roll', 'za_job_roll.sno', '=', 'za_staff.position_role')
        ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
        ->where('za_staff.status', 0)
        ->whereDate('za_staff_attendance.date', now()->toDateString());
    
        // Apply branch filter if needed
        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }
    
        // Staff pagination query
        $staffs = $query->paginate(10);
    
        // Calculate the total unique staff count
        $totalStaffCount = StaffModel::selectRaw('COUNT(DISTINCT za_staff.sno) as total_staff_count')
            ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
            ->leftJoin('za_staff_attendance', 'za_staff_attendance.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_job_roll', 'za_job_roll.sno', '=', 'za_staff.position_role')
            ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->where('za_staff.status', 0);
    
        // Apply branch filter for total count as well
        if ($branch_id != 0) {
            $totalStaffCount->where('za_staff.branch_id', $branch_id);
        }
    
        // Get the total staff count
        $totalStaffCount = $totalStaffCount->value('total_staff_count');
    
        // Attendance summary query
        $att = StaffAttendanceModel::select('branch_id',
            DB::raw("SUM(CASE WHEN attendance = 'P' THEN 1 ELSE 0 END) AS present_count"),
            DB::raw("SUM(CASE WHEN attendance = 'A' THEN 1 ELSE 0 END) AS absent_count"),
            DB::raw("SUM(CASE WHEN attendance = 'L' THEN 1 ELSE 0 END) AS leave_count"),
            DB::raw("SUM(CASE WHEN attendance = 'OD' THEN 1 ELSE 0 END) AS od_count"),
            DB::raw("SUM(CASE WHEN attendance = 'PR' THEN 1 ELSE 0 END) AS pr_count")
        )
        ->where('status', 0)
        ->whereDate('date', today())
        ->groupBy('branch_id');
    
        if ($branch_id != 0) {
            $att->where('branch_id', $branch_id);
        }
    
        $attendanceSummary = $att->get();
    
        // Department query
        $depart = DepartmentModel::select('*')->where('status', 0)->get();
    
        // Time difference calculation for specific attendance types
        $timeDifferences = StaffAttendanceModel::select(
            'staff_id',
            DB::raw('TIMEDIFF(time_end, time_start) AS time_difference')
        )
        ->whereIn('attendance', ['Od', 'PR'])
        ->whereDate('date', now()->toDateString())
        ->get();
    
        // Return the view with all necessary data
        return view('content.staff_attendance.staff_attendance', [
            'depart' => $depart,
            'staffs' => $staffs,
            'att' => $attendanceSummary,
            'time_differences' => $timeDifferences,
            'staff_fill' => '',
            'dept_fill' => '',
            'att_status_fill' => '',
            'pageConfigs' => ['myLayout' => 'default'],
            'totalStaffCount' => $totalStaffCount  // Pass the total count to the view
        ])->with('filter_on', false);
    }

    public function att_filter(Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $staff_fill = $request->staff_fill ?? '';
        $dept_fill = $request->dept_fill ?? '';
        $att_status_fill = $request->att_status_fill ?? '';


        $query = StaffModel::select(
            'za_staff.sno as staff_id', 
            'za_staff.staff_name', 
            'za_staff.nick_name', 
            'za_staff.gender', 
            'za_staff.staff_image', 
            'za_staff.mobile_no', 
            'za_staff.email_id', 
            'za_department.department_name', 
            'za_sub_department.sub_department_name', 
            'za_branch.branch_name', 
            'za_branch.franchise_name', 
            'za_job_roll.job_roll_name', 
            'za_staff_attendance.date',  
            'za_staff_attendance.attendance', 
            'za_staff_attendance.staff_id', 
            'za_staff_attendance.time_start', 
            'za_staff_attendance.time_end',  
            'za_staff_attendance.reason'
        )
        ->join('za_department', 'za_department.sno', '=', 'za_staff.department_id')
        ->join('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
        ->join('za_staff_attendance', 'za_staff_attendance.staff_id', '=', 'za_staff.sno')
        ->join('za_job_roll', 'za_job_roll.sno', '=', 'za_staff.position_role')
        ->join('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
        ->where('za_staff.status', 0)
        ->whereDate('za_staff_attendance.date', now()->toDateString()); // Filter for current date
    

        if ($staff_fill) {
            $query->where(function($query) use ($staff_fill) {
                $query->where('za_staff.staff_name', 'LIKE', "%{$staff_fill}%")
                        ->orWhere('za_staff.mobile_no', 'LIKE', "%{$staff_fill}%");
            });
        }
        if ($dept_fill) {
            $query->where('za_staff.department_id', $dept_fill);
        }
        if ($att_status_fill) {
            $query->where('za_staff_attendance.attendance', 'like', "%{$att_status_fill}%");
        }
        if ($branch_id != 0) {
            $query->where('za_staff.branch_id', $branch_id);
        }
        
        $staffs = $query->paginate(10);

        
        // Attendance summary query
        $att = StaffAttendanceModel::select('branch_id',
            DB::raw("SUM(CASE WHEN attendance = 'P' THEN 1 ELSE 0 END) AS present_count"),
            DB::raw("SUM(CASE WHEN attendance = 'A' THEN 1 ELSE 0 END) AS absent_count"),
            DB::raw("SUM(CASE WHEN attendance = 'L' THEN 1 ELSE 0 END) AS leave_count"),
            DB::raw("SUM(CASE WHEN attendance = 'OD' THEN 1 ELSE 0 END) AS od_count"),
            DB::raw("SUM(CASE WHEN attendance = 'PR' THEN 1 ELSE 0 END) AS pr_count")
        )
        ->where('status', 0)
        ->whereDate('date', today())
        ->groupBy('branch_id');
    
        if ($branch_id != 0) {
            $att->where('branch_id', $branch_id);
        }
    
        $attendanceSummary = $att->get();
        
        $depart = DepartmentModel::select('*')->where('status', 0)->get();
        // return $depart; 
         $pageConfigs = ['myLayout' => 'default'];
         
         
         // Calculate the total unique staff count
        $totalStaffCount = StaffModel::selectRaw('COUNT(DISTINCT za_staff.sno) as total_staff_count')
            ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
            ->leftJoin('za_sub_department', 'za_sub_department.sno', '=', 'za_staff.sub_department_id')
            ->leftJoin('za_staff_attendance', 'za_staff_attendance.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_job_roll', 'za_job_roll.sno', '=', 'za_staff.position_role')
            ->leftJoin('za_branch', 'za_branch.sno', '=', 'za_staff.branch_id')
            ->where('za_staff.status', 0);
    
        // Apply branch filter for total count as well
        if ($branch_id != 0) {
            $totalStaffCount->where('za_staff.branch_id', $branch_id);
        }
    
        // Get the total staff count
        $totalStaffCount = $totalStaffCount->value('total_staff_count');


        return view('content.staff_attendance.staff_attendance', [
            'depart' => $depart,
            'staffs' => $staffs,
            'att' => $attendanceSummary,
            'staff_fill' => $staff_fill,
            'dept_fill' => $dept_fill,
            'att_status_fill' => $att_status_fill,
            'pageConfigs' => $pageConfigs,
             'totalStaffCount' => $totalStaffCount  // Pass the total count to the view
        ])->with('filter_on', true);
    }
}