<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\CronjobMonitorModel;

class CronjobMonitor extends Controller
{

  public function index(Request $request)
  {
      $entity_id   = $request->user()->entity_id;
      $user_id   = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $search_fill = $request->search_fill ?? '';
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $List = CronjobMonitorModel::where('status', '!=', 2);
      
      // Filters:
      if ($search_fill != '') {
        $List->where(function ($query) use ($search_fill) {
          $query->where('cronjob_name', 'LIKE', "%{$search_fill}%")
            ->orWhere('cronjb_link', 'LIKE', "%{$search_fill}%");
        });
      }
      
      $ListTable = $List->orderBy('cronjob_run_duration', 'DESC')->paginate($perpage);
      
      if($request->ajax()){
          return view('content.branch_management.cronjob_monitor_table', compact('ListTable'))->render();
      }
      
      return view('content.branch_management.cronjob_monitor', [
        'ListTable' => $ListTable,
        'perpage' => $perpage,
        'search_fill' => $search_fill,
      ]);
  }

  public function cronjobHistory(Request $request, $cronjobId)
  {
      $perpage = (int) $request->input('perpage', 10);
      
      $crons = CronjobMonitorModel::where('sno', $cronjobId)->first();
      
      $logs = \DB::table('et_cronjob_logs')
          ->where('cronjob_id', $cronjobId)
          ->orderBy('sno', 'desc')
          ->paginate($perpage);
  
      if ($request->ajax()) {
          return view('content.branch_management.cronjob_monitor_history_table', compact('logs','crons'))->render();
      }
  
      return view('content.branch_management.cronjob_monitor_history', compact('logs'));
  }

  public function Status($id, Request $request)
  {
      $upd_DepartmentModel = CronjobMonitorModel::where('sno', $id)->first();
      $upd_DepartmentModel->status = $request->input('status', 0);
      $upd_DepartmentModel->update();
      if ($upd_DepartmentModel) {
        return response([
          'status' => 200,
          'message' => 'Successfully Status Updated!',
          'error_msg' => null,
          'data' => null,
        ], 200);
      } else {
        return response([
          'status' => 400,
          'message' => 'Successfully Status Updated!',
          'error_msg' => null,
          'data' => null,
        ], 400);
      }
  }

  public function Add(Request $request)
  {
    //  return $request;
    $validator = Validator::make($request->all(), [
      'Cronjob' => 'required',
      'Cronjob_Link' => 'required'

    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $Cronjob           = $request->Cronjob;
      $Cronjob_Link = $request->Cronjob_Link;
      $Cronjob_run         = $request->Cronjob_run;
      $Cronjob_desc           = $request->Cronjob_desc;
      $Cronjob_std_date =  isset($request->Cronjob_std_date) ? date('Y-m-d', strtotime($request->Cronjob_std_date)) : null;
      $Cronjob_end_date         =  isset($request->Cronjob_end_date) ? date('Y-m-d', strtotime($request->Cronjob_end_date)) : null;
      $Sync_dur       = $request->Sync_dur;

      $user_id            = $request->user()->user_id ?? 1;
      // dd($request);
      $chk = CronjobMonitorModel::where('cronjob_name', ucwords($Cronjob))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Cronjob Name already created!'
        ]);
      } else {
      

        $add_category = new CronjobMonitorModel();
        $add_category->cronjob_name                 = ucwords($Cronjob);
        $add_category->cronjb_link          = $Cronjob_Link;
        $add_category->cronjob_run_duration               = $Cronjob_run;
        $add_category->cronjob_desc                 = $Cronjob_desc;
        $add_category->sync_start_date_time             = $Cronjob_std_date;
        $add_category->sync_end_date_time             = $Cronjob_end_date;
        $add_category->sync_duration   = $Sync_dur;
        $add_category->created_by   = $user_id;
        $add_category->updated_by   = $user_id;
        $add_category->running_status   = 0;
        $add_category->status   = 0;

        $add_category->save();

      
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'CronJob added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the CronJob!'
          ]);
        }
      }
      // return $result;
      return redirect('Cronjob_Monitor');
    }
  }

  public function Edit($id)
  {
    
    $editcategory = CronjobMonitorModel::where('sno', $id)->first();
    $editcategory->sync_start_date_time = \Carbon\Carbon::parse($editcategory->sync_start_date_time)->format('Y-m-d H:i:S');
    $editcategory->sync_end_date_time   = \Carbon\Carbon::parse($editcategory->sync_end_date_time)->format('Y-m-d H:i:S');

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'Cronjob' => 'required|max:255',
      'Cronjob_Link' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
       $Cronjob_id          = $request->Cronjob_id;
      $add_category =  CronjobMonitorModel::where('sno', $Cronjob_id)->first();

     
      $Cronjob           = $request->Cronjob;
      $Cronjob_Link      = $request->Cronjob_Link;
      $Cronjob_run       = $request->Cronjob_run;
      $Cronjob_desc      = $request->Cronjob_desc;
      $Cronjob_std_date  =  isset($request->Cronjob_std_date) ? date('Y-m-d', strtotime($request->Cronjob_std_date)) : null;
      $Cronjob_end_date  =  isset($request->Cronjob_end_date) ? date('Y-m-d', strtotime($request->Cronjob_end_date)) : null;
      $Sync_dur          = $request->Sync_dur;

      $user_id   = $request->user()->user_id;
      $chk = CronjobMonitorModel::where('cronjob_name', ucwords($Cronjob))->where('status', '!=', 2)->first();

      if ($chk) {
        if ($chk->sno != $Cronjob_id) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
        } else {
        }
      }

      $add_category->cronjob_name                 = ucwords($Cronjob);
      $add_category->cronjb_link          = $Cronjob_Link;
      $add_category->cronjob_run_duration               = $Cronjob_run;
      $add_category->cronjob_desc                 = $Cronjob_desc;
      $add_category->sync_start_date_time             = $Cronjob_std_date;
      $add_category->sync_end_date_time             = $Cronjob_end_date;
      $add_category->sync_duration   = $Sync_dur;
   
      $add_category->updated_by   = $user_id;
      $add_category->running_status   = 0;
      $add_category->status   = 0;
      
      $add_category->update();

  
      if ($add_category) {
         session()->flash('toastr', [
          'type' => 'success',
          'message' => 'CronJob Updated Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Update the CronJob!'
        ]);
      }
      // return $result;
    }

    return redirect('Cronjob_Monitor');
  }


}
