<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use Carbon\Carbon;
class BranchMetrics extends Controller
{


  public function index()
    {
        return view('content.branch_management.branch_metrics.branch_metrics');
    }

       public function getTargets(Request $request)
    {
        // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    
        // Fetch target record for given branch and date
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->first();
    
        return response()->json(['status' => 200, 'data' => $targets]);
    }
    
   public function getTargetsMetrics(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
    
        // Fetch all targets for the month
        $targets = ManageTargetModel::join('za_branch', 'branch_target.branch_id', '=', 'za_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*', 'za_branch.branch_name', 'za_branch.franchise_name', 'za_branch.branch_type')
                    ->get();
                    
                    // return $targets;
    
        $results = [];
         $user_id = auth()->user()->user_id;
        $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id); 
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
        
        $allowedBranchIds = $branches->merge($franchises)->toArray();
        // return $branchControlList;
        foreach ($targets as $target) {
            $branchId = $target->branch_id;
            
                if (!in_array($branchId, $allowedBranchIds)) {
                    continue; // filter out unauthorized branches
                }
            
           $lastLogin = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id') // table alias must match
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User') // ensure it's filtering correct model
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->limit(1)
            ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));
            
            if ($lastLogin) {
                $lastLoginCarbon = Carbon::parse($lastLogin);
                
                $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
                $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true); // more accurate format
            } else {
                $lastLoginFormatted = 'N/A';
                $lastLoginDiff = 'N/A';
            }
             $totalLeads = DB::table('za_lead')
                ->where('branch_id', $branchId)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
            // Actual payments (old)
            $totalPaidAmountOld = DB::table('za_old_payments')
                ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
                ->where('za_old_payments.status', '!=', 2)
                ->where('za_old_customer.branch_id', $branchId)
                ->whereIn('za_old_customer.status', [1, 4])
                ->where('za_old_payments.amount', '>', 0)
                ->whereYear('za_old_payments.created_at', $year)
                ->whereMonth('za_old_payments.created_at', $month)
                ->sum('za_old_payments.paidAmount');
    
            // Actual payments (new)
            $totalPaidAmountNew = DB::table('za_payment')
                ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
                ->where('za_customer.branch_id', $branchId)
                ->where('za_payment.status', 1)
                ->where('za_customer.status', 0)
                ->where('za_payment.amount', '>', 0)
                ->whereYear('za_payment.initialPayDate', $year)
                ->whereMonth('za_payment.initialPayDate', $month)
                ->sum('za_payment.paidAmount');
             $transaction = DB::table('za_transaction')
                     ->where('za_transaction.branch_id', $branchId)
                      ->whereYear('za_transaction.transaction_date', $year)
                    ->whereMonth('za_transaction.transaction_date', $month)
                     ->sum('za_transaction.credit');
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $transaction;
    
            // Post-sale & pre-sale actuals
            $postSaleActual = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', 1)
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
    
            $preSaleActual = CustomerModel::whereIn('status', [0, 6])
                // ->where('post_sale_check', 0)
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
                
               
    
            $results[] = [
                'branch_name' => $target->branch_type == 1 ? $target->branch_name : $target->franchise_name,
                 'branch_type' => $target->branch_type,
                  'branch_id' => $target->branch_id,
                'date' => $target->date,
                'target'             => '₹' . number_format($target->monthly_target),
                'post_sale_target' => $target->post_sale,
                'pre_sale_target' => $target->no_of_registrations,
                 'target_actual'      => '₹' . number_format($targetActual),
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                 'lead_total'         => $totalLeads,
                 'last_login' => $lastLogin ? date('d-M-Y h:i A', strtotime($lastLogin)) : 'N/A',
                 'last_login_ago' => $lastLoginDiff,
                 
            ];
        }
    
        return response()->json([
            'status' => 200,
            'data' => $results
        ]);
    }



    public function updateTargets(Request $request)
{
    $request->validate([
        'branch_id' => 'required|integer',
        'no_of_registrations' => 'required|integer|min:0',
        'post_sale' => 'required|integer|min:0',
        'monthly_target' => 'required|integer|min:0',
    ]);

    // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    $userId = auth()->user()->user_id ?? 0; // Get current logged-in user

    // Check if record already exists
    $existing = ManageTargetModel::where('branch_id', $request->branch_id)
                ->where('date', $targetDate)
                ->first();

    if ($existing) {
        // Update path
        $existing->no_of_registrations = $request->no_of_registrations;
        $existing->post_sale = $request->post_sale;
        $existing->monthly_target = $request->monthly_target;
        $existing->updated_by = $userId;
        $existing->save();
    } else {
        // Insert path
        ManageTargetModel::create([
            'branch_id' => $request->branch_id,
            'date' => $targetDate,
            'no_of_registrations' => $request->no_of_registrations,
             'post_sale' => $request->post_sale,
            'monthly_target' => $request->monthly_target,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Target saved successfully.'
    ]);
}



}
