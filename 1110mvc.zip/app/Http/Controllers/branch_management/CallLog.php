<?php
namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\DropReasonModel;
use App\Models\FollowupReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadMetricsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Shared\Date;
class CallLog extends Controller
{
  public function index()
  {
    
    return view('content.branch_management.call_log.call_log');
  }
  
 public function List(Request $request, $month = null, $year = null)
{
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));

    $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;
    $lead_fill = $request->input('lead_fill', '');

    // Base staff query
    $salesStaff = DB::table('za_staff')
        ->select(
            'za_staff.sno',
            'za_staff.staff_name',
            'za_staff.staff_image',
            'za_staff.gender',
            'za_staff.mobile_no',
            'za_staff.lead_bank_count',
            'za_staff.status as staff_status',
            'za_cug_management.staff_mobile as cug_mobile',
            'za_department.department_name',
            'za_department.sno as dept_id',
            'za_job_position.job_position_name'
        )
        ->join('za_cug_management', 'za_staff.sno', '=', 'za_cug_management.staff_id')
        ->join('za_department', 'za_staff.department_id', '=', 'za_department.sno')
        ->join('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_cug_management.status', 0)
        ->where(function ($query) use ($year, $month) {
            $query->where(function ($query) use ($year, $month) {
                    $query->where('za_staff.status', 4)
                        ->whereYear('za_staff.notice_end_date', '>=', $year)
                        ->whereMonth('za_staff.notice_end_date', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('za_staff.status', 5)
                        ->whereYear('za_staff.updated_at', '>=', $year)
                        ->whereMonth('za_staff.updated_at', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('za_staff.status', 6)
                        ->whereYear('za_staff.staff_last_date', '>=', $year)
                        ->whereMonth('za_staff.staff_last_date', '>=', $month);
                })
                ->orWhere(function ($query) use ($year, $month) {
                    $query->where('za_staff.status', 7)
                        ->whereYear('za_staff.updated_at', '>=', $year)
                        ->whereMonth('za_staff.updated_at', '>=', $month);
                })
                ->orWhere('za_staff.status', 0);
        });

    if ($lead_fill != '') {
        $salesStaff->where(function ($query) use ($lead_fill) {
            $query->where('staff_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('nick_name', 'LIKE', "%{$lead_fill}%")
                ->orWhere('mobile_no', 'LIKE', "%{$lead_fill}%")
                ->orWhere('email_id', 'LIKE', "%{$lead_fill}%");
        });
    }

    $salesStaff = $salesStaff->orderBy('sno', 'desc')->paginate($perpage);

    // Date range
    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month)
        ? $currentDate
        : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;

    // --- Call Stats ---
    $callData = DB::table('za_call_tracker')
        ->select(
            'branch_staff_id',
            DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
            DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
            DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
            DB::raw("SUM(CASE WHEN customer_status = 0 THEN 1 ELSE 0 END) AS unknown_count")
        )
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray())
        ->groupBy('branch_staff_id')
        ->get()
        ->keyBy('branch_staff_id');

    // Totals
    $total_incoming_call_count = $total_outgoingcall_count = $total_missedcall_count = $total_rejected_call_count = $total_unknown_count = 0;

    // instantiate helper for last-login lookups
    $helper = new \App\Helpers\Helpers();

    $salesStaff->getCollection()->transform(function ($staff) use ($callData, $dayCount, $helper, &$total_incoming_call_count, &$total_outgoingcall_count, &$total_missedcall_count, &$total_rejected_call_count, &$total_unknown_count) {
        $data = $callData[$staff->sno] ?? (object) [
            'incoming_call_count' => 0,
            'outgoingcall_count' => 0,
            'missedcall_count' => 0,
            'rejected_call_count' => 0,
            'unknown_count' => 0
        ];

        $staff->incoming_call_count = $data->incoming_call_count;
        $staff->outgoingcall_count = $data->outgoingcall_count;
        $staff->missedcall_count = $data->missedcall_count;
        $staff->rejected_call_count = $data->rejected_call_count;
        $staff->unknown_count = $data->unknown_count;

        // Ratios
        $staff->outgoing_call_ratio = $dayCount > 0 ? round($data->outgoingcall_count / $dayCount, 2) : 0;
        $staff->incoming_call_ratio = $dayCount > 0 ? round($data->incoming_call_count / $dayCount, 2) : 0;
        $staff->missed_call_rate = $dayCount > 0 ? round($data->missedcall_count / $dayCount, 2) : 0;

        $total_calls = $data->incoming_call_count + $data->missedcall_count + $data->rejected_call_count;
        $staff->missed_call_ratio = $total_calls > 0 ? round(($data->missedcall_count / $total_calls) * 100, 2) : 0;

        // Update totals
        $total_incoming_call_count += $data->incoming_call_count;
        $total_outgoingcall_count += $data->outgoingcall_count;
        $total_missedcall_count += $data->missedcall_count;
        $total_rejected_call_count += $data->rejected_call_count;
        $total_unknown_count += $data->unknown_count;

        // -----------------------
        // LAST LOGIN + DURATION
        // -----------------------
        $last_login_data = $helper->get_tracker_last_login_data($staff->cug_mobile ?? null);
        $last_login_date = $last_login_data->last_sync_date ?? null;
        $last_login_time = $last_login_data->last_sync_time ?? null;

        $duration = '-';
        $last_login_display = null;

        if ($last_login_date && $last_login_time) {
            try {
                // parse and convert to Asia/Kolkata for display
                $dt = Carbon::parse($last_login_date . ' ' . $last_login_time);
                $last_login_display = $dt->timezone('Asia/Kolkata')->format('d M Y h:i A');

                // compute human readable duration (difference from now)
                $now = Carbon::now('Asia/Kolkata');
                $diff = $now->diff($dt); // DateInterval

                $parts = [];
                if ($diff->y > 0) $parts[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
                if ($diff->m > 0) $parts[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
                if ($diff->d > 0) $parts[] = $diff->d . ' day' . ($diff->d > 1 ? 's' : '');
                if ($diff->h > 0) $parts[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
                if ($diff->i > 0) $parts[] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
                if ($diff->s > 0 && empty($parts)) $parts[] = $diff->s . ' second' . ($diff->s > 1 ? 's' : '');
                if (empty($parts)) $parts[] = 'Just now';

                $duration = implode(' ', $parts);
            } catch (\Exception $e) {
                $duration = '-';
                $last_login_display = null;
            }
        }

        // attach to staff row for frontend AJAX consumption
        $staff->last_login_date = $last_login_date;
        $staff->last_login_time = $last_login_time;
        $staff->last_login_display = $last_login_display;
        $staff->duration = $duration;

        return $staff;
    });

    // Totals & Ratios
    $total_staff = $salesStaff->total() ?? 0;
    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_outgoingcall_count / ($total_staff * $dayCount), 2) : 0;
    $total_incoming_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_incoming_call_count / ($total_staff * $dayCount), 2) : 0;
    $total_missed_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($total_missedcall_count / ($total_staff * $dayCount), 2) : 0;

    $Lead_metric_list = LeadMetricsModel::where('status', 0)->orderBy('sno', 'ASC')->first();

    // --- JSON Response ---
    return response()->json([
        'status' => 200,
        'message' => 'Team Call Monthly Report',
        'filters' => [
            'branch_id' => $branch_id,
            'month' => $month,
            'year' => $year,
            'month_chk' => $month_chk,
            'day_count' => $dayCount,
            'lead_fill' => $lead_fill,
            'per_page' => $perpage,
            'current_page' => $page,
        ],
        'totals' => [
            'incoming' => $total_incoming_call_count,
            'outgoing' => $total_outgoingcall_count,
            'missed' => $total_missedcall_count,
            'rejected' => $total_rejected_call_count,
            'unknown' => $total_unknown_count,
            'incoming_ratio' => $total_incoming_call_ratio,
            'outgoing_ratio' => $total_outgoing_call_ratio,
            'missed_ratio' => $total_missed_call_ratio,
        ],
        'lead_metric' => $Lead_metric_list,
        'data' => $salesStaff,
    ]);
}


  
 
    
 



}