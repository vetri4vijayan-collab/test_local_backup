<?php

namespace App\Http\Controllers\branch_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\HolidayModel;
use App\Models\BranchModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceModel;
use Illuminate\Support\Facades\DB;



class BranchHoliday extends Controller
{
   
    public function index()
    {
       
     
      $holi_list = HolidayModel::select('*')
        ->where('status', '!=', 2)
        ->orderBy('sno', 'desc')->get();
         // Decode branch_id from JSON to an array (or object)
            foreach ($holi_list as $holiday) {
                $holiday->branch_id = json_decode($holiday->branch_id);
            }
        // return $holi_list;

      return view('content.branch_management.holiday.holiday_list', [
        'holi_list' => $holi_list
      ]);
    }

    public function List()
    {  
      $branch_id = $request->user()->branch_id;
      $CourseSubCategory = HolidayModel::where('branch_id', $branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $CourseSubCategory
      ], 200);
    }
  
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'hol_date_add' => 'required|date|max:255'
        ]);
    
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
    
        $hol_date       = date('Y-m-d', strtotime($request->hol_date_add));
        $hol_reason     = $request->hol_reason_add;
        $branches       = $request->input('branch_id');
        $holiday_targets= $request->input('holiday_target');
        $user_id        = $request->user()->user_id;
    
        $chk = HolidayModel::where('hol_date', $hol_date)
            ->whereIn('branch_id', $branches)
            ->where('status', '!=', 2)
            ->first();
    
        if ($chk) {
            session()->flash('toastr', [
                'status'  => 401,
                'type'    => 'error',
                'message' => 'Date has already been created!'
            ]);
            return redirect()->back();
        }
    
        DB::beginTransaction();
    
        try {
            $add_category = new HolidayModel();
            $add_category->hol_date       = $hol_date;
            $add_category->hol_reason     = $hol_reason;
            $add_category->branch_id      = json_encode($branches);
            $add_category->staff_check    = in_array('staff', $holiday_targets) ? 1 : 0;
            $add_category->student_check  = in_array('student', $holiday_targets) ? 1 : 0;
            $add_category->created_by     = $user_id;
            $add_category->updated_by     = $user_id;
            $add_category->save();
    
            foreach ($branches as $branchId) {
                $branch_check = \App\Models\BranchModel::where('sno', $branchId)->first();
                $branch_code = $branch_check->city_short_code ?? 'MDU';
    
                if ($add_category->staff_check) {
                    $staffs = \App\Models\StaffModel::where('status', 0)->where('branch_id', $branchId)->get();
    
                    foreach ($staffs as $staff) {
                        $cos_check = \App\Models\StaffAttendanceModel::orderBy('sno', 'desc')->first();
                        $last_id = $cos_check ? explode("/", $cos_check->staff_attendance_id)[2] : "SAT0000";
                        $next_number = sprintf("SAT%04d", intval(preg_replace('/\D/', '', $last_id)) + 1);
                        $staff_attendance_id = date("Y") . '/' . $branch_code . '/' . $next_number;
    
                        \App\Models\StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'staff_id'            => $staff->sno,
                            'branch_id'           => $staff->branch_id,
                            'date'                => $hol_date,
                            'attendance'          => 'HD',
                            'created_by'          => $user_id,
                            'updated_by'          => $user_id,
                        ]);
                    }
                }
    
                if ($add_category->student_check) {
                    $students = \App\Models\CustomerModel::where('status', 0)
                                ->where('branch_id', $branchId)
                                ->get();
                
                    // Get last attendance number for this branch once
                    $last_attendance = \App\Models\AttendanceModel::where('branch_id', $branchId)
                                        ->orderBy('sno', 'desc')
                                        ->first();
                    $last_number = $last_attendance 
                                    ? intval(preg_replace('/\D/', '', explode("/", $last_attendance->attendance_id)[2])) 
                                    : 0;
                
                    foreach ($students as $student) {
                        $trainings = \App\Models\TrainingModel::where('status', 0)
                                        ->where('branch_id', $branchId)
                                        ->where('customer_id', $student->sno)
                                        ->whereNotNull('batch_id')
                                        ->where('batch_id', '!=', 0)
                                        ->whereNotNull('staff_id')
                                        ->where('staff_id', '!=', 0)
                                        ->get();
                
                        foreach ($trainings as $training) {
                            $last_number++;
                            $attendance_id = date("Y") . '/' . $branch_code . '/' . sprintf("AT%04d", $last_number);
                
                            \App\Models\AttendanceModel::create([
                                'attendance_id' => $attendance_id,
                                'customer_id'   => $student->sno,
                                'branch_id'     => $student->branch_id,
                                'staff_id'      => $training->staff_id,
                                'batch_id'      => $training->batch_id,
                                'course_id'     => $training->course_id,
                                'total_duration'=> 1,
                                'att_date'      => $hol_date,
                                'attendance'    => 'HD',
                                'created_by'    => $user_id,
                                'updated_by'    => $user_id,
                            ]);
                        }
                    }
                }

            }
    
            DB::commit();
    
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Holiday added successfully!'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
    
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to add holiday: ' . $e->getMessage()
            ]);
        }
    
        return redirect()->back();
    }

  
  public function Update(Request $request)
  {
    $validator = Validator::make($request->all(), [
        'hol_date_edit' => 'required|date|max:255',
    ]);

    if ($validator->fails()) {
        return response([
            'status' => 401,
            'message' => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data' => null,
        ], 200);
    }

    DB::beginTransaction();

    try {
        $holiday_id = $request->holiday_id;
        $new_date = date('Y-m-d', strtotime($request->hol_date_edit));
        $new_reason = $request->hol_reason_edit;
        $new_branches = $request->input('branch_id');
        $new_targets = $request->input('holiday_target');
        $user_id = $request->user()->user_id;

        $holiday = HolidayModel::where('sno', $holiday_id)->first();

        if (!$holiday) {
            throw new \Exception('Holiday not found.');
        }

        $old_date = $holiday->hol_date;
        $old_branches = json_decode($holiday->branch_id, true) ?? [];
        $old_staff_check = $holiday->staff_check;
        $old_student_check = $holiday->student_check;

        $new_staff_check = in_array('staff', $new_targets) ? 1 : 0;
        $new_student_check = in_array('student', $new_targets) ? 1 : 0;

        $removed_branches = array_diff($old_branches, $new_branches);
        $added_branches = array_diff($new_branches, $old_branches); // <-- added branch detection

        // 1. If holiday date changed
        if ($old_date !== $new_date) {
            if ($old_staff_check) {
                StaffAttendanceModel::where('date', $old_date)
                    ->whereIn('branch_id', $old_branches)
                    ->where('attendance', 'HD')
                    ->update(['date' => $new_date]);
            }

            if ($old_student_check) {
                AttendanceModel::where('att_date', $old_date)
                    ->whereIn('branch_id', $old_branches)
                    ->where('attendance', 'HD')
                    ->update(['att_date' => $new_date]);
            }
        }

        // 2. If branch removed
        if (!empty($removed_branches)) {
            if ($old_staff_check) {
                StaffAttendanceModel::where('date', $new_date)
                    ->whereIn('branch_id', $removed_branches)
                    ->where('attendance', 'HD')
                    ->delete();
            }

            if ($old_student_check) {
                AttendanceModel::where('att_date', $new_date)
                    ->whereIn('branch_id', $removed_branches)
                    ->where('attendance', 'HD')
                    ->delete();
            }
        }

        // 3. If staff unchecked
        if ($old_staff_check && !$new_staff_check) {
            StaffAttendanceModel::where('date', $new_date)
                ->whereIn('branch_id', $new_branches)
                ->where('attendance', 'HD')
                ->delete();
        }

        // 4. If student unchecked
        if ($old_student_check && !$new_student_check) {
            AttendanceModel::where('att_date', $new_date)
                ->whereIn('branch_id', $new_branches)
                ->where('attendance', 'HD')
                ->delete();
        }

        // 5. If new branch added - Create attendance
        foreach ($added_branches as $branchId) {
            $branch_check = \App\Models\BranchModel::where('sno', $branchId)->first();
            $branch_code = $branch_check->city_short_code ?? 'MDU';

            if ($new_staff_check) {
                $staffs = \App\Models\StaffModel::where('status', 0)->where('branch_id', $branchId)->get();
                foreach ($staffs as $staff) {
                    $cos_check = \App\Models\StaffAttendanceModel::orderBy('sno', 'desc')->first();
                    $last_id = $cos_check ? explode("/", $cos_check->staff_attendance_id)[2] : "SAT0000";
                    $next_number = sprintf("SAT%04d", intval(preg_replace('/\D/', '', $last_id)) + 1);
                    $staff_attendance_id = date("Y") . '/' . $branch_code . '/' . $next_number;

                    \App\Models\StaffAttendanceModel::create([
                        'staff_attendance_id' => $staff_attendance_id,
                        'staff_id' => $staff->sno,
                        'branch_id' => $staff->branch_id,
                        'date' => $new_date,
                        'attendance' => 'HD',
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]);
                }
            }

            if ($new_student_check) {
                $students = \App\Models\CustomerModel::where('status', 0)->where('branch_id', $branchId)->get();
                foreach ($students as $student) {
                    $training = \App\Models\TrainingModel::where('status', 0)
                        ->where('branch_id', $branchId)
                        ->where('customer_id', $student->sno)
                        ->whereNotNull('batch_id')
                        ->where('batch_id', '!=', 0)
                        ->whereNotNull('staff_id')
                        ->where('staff_id', '!=', 0)
                        ->first();

                    if ($training) {
                        $cos_check = \App\Models\AttendanceModel::orderBy('sno', 'desc')->first();
                        $last_id = $cos_check ? explode("/", $cos_check->attendance_id)[2] : "AT0000";
                        $next_number = sprintf("AT%04d", intval(preg_replace('/\D/', '', $last_id)) + 1);
                        $attendance_id = date("Y") . '/' . $branch_code . '/' . $next_number;

                        \App\Models\AttendanceModel::create([
                            'attendance_id' => $attendance_id,
                            'customer_id' => $student->sno,
                            'branch_id' => $student->branch_id,
                            'staff_id' => $training->staff_id,
                            'batch_id' => $training->batch_id,
                            'course_id' => $training->course_id,
                            'total_duration' => 1,
                            'att_date' => $new_date,
                            'attendance' => 'HD',
                            'created_by' => $user_id,
                            'updated_by' => $user_id,
                        ]);
                    }
                }
            }
        }
        
        

        // 6. Finally Update Holiday Data
        $holiday->hol_date = $new_date;
        $holiday->hol_reason = $new_reason;
        $holiday->branch_id = json_encode($new_branches);
        $holiday->staff_check = $new_staff_check;
        $holiday->student_check = $new_student_check;
        $holiday->updated_by = $user_id;
        $holiday->save();
        
        // 7. If staff checked again newly
        if (!$old_staff_check && $new_staff_check) {
            foreach ($new_branches as $branchId) {
                $branch_check = \App\Models\BranchModel::where('sno', $branchId)->first();
                $branch_code = $branch_check->city_short_code ?? 'MDU';
        
                $staffs = \App\Models\StaffModel::where('status', 0)->where('branch_id', $branchId)->get();
                foreach ($staffs as $staff) {
                    $cos_check = \App\Models\StaffAttendanceModel::orderBy('sno', 'desc')->first();
                    $last_id = $cos_check ? explode("/", $cos_check->staff_attendance_id)[2] : "SAT0000";
                    $next_number = sprintf("SAT%04d", intval(preg_replace('/\D/', '', $last_id)) + 1);
                    $staff_attendance_id = date("Y") . '/' . $branch_code . '/' . $next_number;
        
                    \App\Models\StaffAttendanceModel::create([
                        'staff_attendance_id' => $staff_attendance_id,
                        'staff_id' => $staff->sno,
                        'branch_id' => $staff->branch_id,
                        'date' => $new_date,
                        'attendance' => 'HD',
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                    ]);
                }
            }
        }
        
        // 8. If student checked again newly
        if (!$old_student_check && $new_student_check) {
            foreach ($new_branches as $branchId) {
                $branch_check = \App\Models\BranchModel::where('sno', $branchId)->first();
                $branch_code = $branch_check->city_short_code ?? 'MDU';
        
                $students = \App\Models\CustomerModel::where('status', 0)->where('branch_id', $branchId)->get();
                foreach ($students as $student) {
                    $training = \App\Models\TrainingModel::where('status', 0)
                        ->where('branch_id', $branchId)
                        ->where('customer_id', $student->sno)
                        ->whereNotNull('batch_id')
                        ->where('batch_id', '!=', 0)
                        ->whereNotNull('staff_id')
                        ->where('staff_id', '!=', 0)
                        ->first();
        
                    if ($training) {
                        $cos_check = \App\Models\AttendanceModel::orderBy('sno', 'desc')->first();
                        $last_id = $cos_check ? explode("/", $cos_check->attendance_id)[2] : "AT0000";
                        $next_number = sprintf("AT%04d", intval(preg_replace('/\D/', '', $last_id)) + 1);
                        $attendance_id = date("Y") . '/' . $branch_code . '/' . $next_number;
        
                        \App\Models\AttendanceModel::create([
                            'attendance_id' => $attendance_id,
                            'customer_id' => $student->sno,
                            'branch_id' => $student->branch_id,
                            'staff_id' => $training->staff_id,
                            'batch_id' => $training->batch_id,
                            'course_id' => $training->course_id,
                            'total_duration' => 1,
                            'att_date' => $new_date,
                            'attendance' => 'HD',
                            'created_by' => $user_id,
                            'updated_by' => $user_id,
                        ]);
                    }
                }
            }
        }


        DB::commit();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Holiday updated successfully!'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();
        
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Failed to update holiday: ' . $e->getMessage()
        ]);
    }

    return redirect()->back();
}

    public function Delete($id)
    {
      $upd_CourseCategoryModel =  HolidayModel::where('sno', $id)->first();
      $upd_CourseCategoryModel->status  = 2;
      // return $upd_CourseCategoryModel;
      $upd_CourseCategoryModel->Update();
  
  
      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  
    // public function Status($id, Request $request)
    // {
  
    //   $summary_reason =  HolidayModel::where('sno', $id)->first();
    //   $summary_reason->status = $request->input('status', 0);
    //   $summary_reason->update();
  
    //   return response([
    //     'status'    => 200,
    //     'message'   => 'Successfully Status Updated!',
    //     'error_msg' => null,
    //     'data'      => null,
    //   ], 200);
    // }
  }