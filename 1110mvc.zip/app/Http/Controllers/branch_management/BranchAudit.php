<?php

namespace App\Http\Controllers\branch_management;

use App\Helpers\Helpers;

use App\Http\Controllers\Controller;
use App\Models\BranchAuditModel;
use App\Models\CourseAssigne_model;
use App\Models\FranchiseDocumentModel;
use App\Models\ManageCoursesModel;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
use App\Models\StaffModel;
use App\Traits\AuditNodfiableTrait;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;


class BranchAudit extends Controller
{
    
  use AuditNodfiableTrait;
  public function index(Request $request)
  {
        $page         = $request->input('page', 1);
        $perpage      = (int) $request->input('sorting_filter', 25);
        $offset       = ($page - 1) * $perpage;
        $branch_id    = $request->user()->branch_id;


         // Filters
         $audit_status_fill      = $request->input('audit_status_fill', '');
         $staff_fill      = $request->input('staff_fill', '');
         $branch_fill      = $request->input('branch_fill', '');
         $branch_search_fill      = $request->input('branch_search_fill', '');
         $date_filter      = $request->input('dt_fill_issue_rpt');
         $from_date_filter = $request->input('from_date_fillter_textbox');
         $to_date_filter   = $request->input('to_date_fillter_textbox');
        

        $audit_list = BranchAuditModel::select(
            'za_branch_audit.*', 'za_audit_staff.audit_staff_name as staff_name','za_branch.branch_name','za_branch.branch_type','za_branch.franchise_name')
            ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
            ->join('za_branch', 'za_branch.sno', '=', 'za_branch_audit.branch_id')
            ->where('za_branch_audit.status', '!=', "2")
            ->orderBy('za_branch_audit.audit_status', 'asc')
            ->orderBy('za_branch_audit.audit_date', 'desc')  // second order by for audit_date
            ->orderBy('za_branch_audit.audit_time', 'desc');;

            

        // Date Filtering
        if ($date_filter === "today") {
          $audit_list->whereDate('za_branch_audit.audit_date', now()->toDateString());
        } elseif ($date_filter === "week") {
            $audit_list->whereBetween('za_branch_audit.audit_date', [now()->startOfWeek(), now()->endOfWeek()]);
        } elseif ($date_filter === "monthly") {
            $audit_list->whereMonth('za_branch_audit.audit_date', now()->month)
                ->whereYear('za_branch_audit.audit_date', now()->year);
        } elseif ($date_filter === "custom_date") {
            if ($from_date_filter && $to_date_filter) {
                $audit_list->whereBetween('za_branch_audit.audit_date', [Carbon::parse($from_date_filter), Carbon::parse($to_date_filter)]);
            } elseif ($from_date_filter) {
                $audit_list->where('za_branch_audit.audit_date', '>=', Carbon::parse($from_date_filter));
            } elseif ($to_date_filter) {
                $audit_list->where('za_branch_audit.audit_date', '<=', Carbon::parse($to_date_filter));
            }
        }

          if ($audit_status_fill != '') {
              $audit_list->where('za_branch_audit.audit_status', $audit_status_fill);
          } if ($staff_fill != '') {
              $audit_list->where('za_branch_audit.staff_id', $staff_fill);
          } if ($branch_fill != '') {
              $audit_list->where('za_branch_audit.branch_id', $branch_fill);
          }
      if ($branch_search_fill != '') {
          $audit_list->where(function ($query) use ($branch_search_fill) {
              $query->where('za_branch.branch_name', 'LIKE', "%{$branch_search_fill}%")
                  ->orWhere('za_audit_staff.audit_staff_name', 'LIKE', "%{$branch_search_fill}%")
                  ->orWhere('za_branch.franchise_name', 'LIKE', "%{$branch_search_fill}%");
          });
      }

        $audit_list = $audit_list->paginate($perpage);

        foreach ($audit_list as $singleAudit) {
            $department_ids = json_decode($singleAudit->department_ids, true); // Decode JSON to array
            $department_name = [];
        
            if (is_array($department_ids)) { // Ensure it's an array before looping
                foreach ($department_ids as $depart_id) {
                    $departmentData = DB::table('za_audit_category')
                        ->where('status', 0)
                        ->where('sno', $depart_id)
                        ->select('audit_category_name as department_name')
                        ->first();
        
                    if ($departmentData) {
                        $department_name[] = $departmentData->department_name; // Append to array
                    }
                }
            }
        
            $singleAudit->department_name = $department_name; // Return the department names
            $questions = DB::table('za_audit_question')
            ->select('za_audit_question.audit_question_name as question_name',
                    'za_audit_question.audit_question_option',
                    'za_audit_question.audit_question_type',
                    'za_audit_question.audit_category_id as department_id',
                    'za_audit_question_save.score',
                    'za_audit_question_save.audit_question_answer')
            ->leftJoin('za_audit_question_save', 'za_audit_question.sno', '=', 'za_audit_question_save.department_question_id')
            ->where('za_audit_question.status', 0)
            ->whereIn('za_audit_question.audit_category_id', $department_ids)
            ->get();
            
            $allTotalScore =0;
            $getTotalScore =0;
            foreach ($questions as $singleQuestion) {
                // Decode the answer (if it's stored as JSON)
                $answer = json_decode($singleQuestion->audit_question_answer);
                if (!is_array($answer)) {
                    $answer = [$answer]; // If not an array, convert it to an array with a single value
                }
                $singleQuestion->answer = implode(', ', $answer);

                $options = json_decode($singleQuestion->audit_question_option);
                $total_score = 0;
            
                // Handle checkbox type
                if ($singleQuestion->audit_question_type == 'checkbox') {
                    foreach ($options as $option) {
                        if ($option->value) {
                            $score = (int)$option->score[0]; // Assuming score is a single element array
                            $total_score += $score; // Sum the score
                        }
                    }
                }
                // Handle radio_button and list_box types
                elseif ($singleQuestion->audit_question_type == 'radio_button' || $singleQuestion->audit_question_type == 'list_box') {
                    $max_score = 0;
                    foreach ($options as $option) {
                        if ($option->value) {
                            // Convert score to integer
                            $score = (int)$option->score[0]; // Assuming score is a single element array
                            $max_score = max($max_score, $score); // Get the maximum score
                        }
                    }
                    $total_score = $max_score;
                }
                // Handle text_field type
                elseif ($singleQuestion->audit_question_type == 'text_field') {
                    $total_score = 5;
                }
            
                $allTotalScore += $total_score;
                $getTotalScore += $singleQuestion->score;
            }
            $singleAudit->total_score= $allTotalScore;
            $singleAudit->get_score= $getTotalScore;

            $get_score_percentage= $allTotalScore > 0  ? ($getTotalScore/$allTotalScore)*100 :0;
            $singleAudit->get_score_percentage= number_format($get_score_percentage, 1);
            
            $totalScoreColor="";
            $scoreBgColor="";

            $scoreColor = DB::table('za_audit_score')
            ->select('za_audit_score.*')
            ->where('za_audit_score.status', 0)
            ->get();
            foreach ($scoreColor as $color) {
                if($color->score_min_value <= $get_score_percentage && $color->score_max_value >= $get_score_percentage){
                    $scoreBgColor=$color->score_color;
                }
                if($color->score_max_value == '100'){
                    $totalScoreColor=$color->score_color;
                }

            }

            $singleAudit->score_bgColor=$scoreBgColor;
            $singleAudit->total_bgColor=$totalScoreColor;
           
        }
        
        $pageConfigs  = ['myLayout' => 'default'];

        $staff_filter_list = DB::table('za_audit_staff')->where('status', 0)->orderBy('audit_staff_name', 'ASC')->get();

    $branch_list = BranchModel::where('status', '!=', 2)->where('sno','!=',1)->orderBy('sno', 'desc')->get();
    // return $Branch_list;
    return view('content.branch_management.branch_audit.branch_audit', compact(
      'audit_list',
      'perpage',
      'audit_status_fill',
      'branch_search_fill',
      'branch_fill',
      'from_date_filter',
      'date_filter',
      'to_date_filter',
      'staff_filter_list',
      'branch_list',
      'staff_fill',
    ))->with('filter_on', false);
  }
   //Add Appointment
   public function Add(Request $request)
   {
    //   return $request;
       $validator = Validator::make($request->all(), [
           'assg_branch_add' => 'required|max:255',
       ]);
       if ($validator->fails()) {
           return response([
               'status'    => 401,
               'message'   => 'Incorrect format input feilds',
               'error_msg' => $validator->messages()->get('*'),
               'data'      => null,
           ], 200);
       } else {
           $branch_id              = $request->assg_branch_add;
           $audit_date     = date('Y-m-d', strtotime($request->audit_dt_add));
           $staff_id             = $request->assg_staff_add;
            $audit_time = date('H:i:s', strtotime($request->audit_time_add));
           $department_ids      = $request->assg_dept_add;
           $user_id              = $request->user()->user_id;

           $branch_audit_chk = BranchAuditModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

           if (! $branch_audit_chk) {

               $year                = substr(date('y'), -2);
               $branch_audit_id = 'BRAD-0001/' . $year;
           } else {

               $data   = $branch_audit_chk->branch_audit_id;
               $slice  = explode('/', $data);
               $result = preg_replace('/[^0-9]/', '', $slice[0]);

               $next_number = (int) $result + 1;
               $request     = sprintf('BRAD-%04d', $next_number);

               $year                = substr(date('y'), -2);
               $branch_audit_id = $request . '/' . $year;
           }

           $branch_ad_add                       = new BranchAuditModel();
           $branch_ad_add->branch_audit_id  = $branch_audit_id;
           $branch_ad_add->branch_id            = $branch_id;
           $branch_ad_add->staff_id             = $staff_id;
           $branch_ad_add->audit_time             = $audit_time;
           $branch_ad_add->department_ids  = json_encode($department_ids);
           $branch_ad_add->audit_date     = $audit_date;
           $branch_ad_add->created_by           = $user_id;
           $branch_ad_add->updated_by           = $user_id;
           $branch_ad_add->notification_time = date('Y-m-d H:i:s');
           $branch_ad_add->status           = 0;

           $branch_ad_add->save();
           
               $this->sendAuditNotification(
                    $branch_ad_add->sno,
                    $branch_ad_add->staff_id,
                    "New Audit Created",
                    $user_id,
                    1
                );


           if ($branch_ad_add) {
               // If category added successfully, return success response and display Toastr message
               session()->flash('toastr', [
                   'type'    => 'success',
                   'message' => 'Branch Audit added Successfully!',
               ]);
           } else {
               session()->flash('toastr', [
                   'type'    => 'error',
                   'message' => 'Could not add the Branch Audit!',
               ]);
           }

           return redirect('branch_audit');
       }
   }
  
   // update Appointment
   public function Update(Request $request)
   {
      
       $validator = Validator::make($request->all(), [
           'audit_id_edit'    => 'required|max:255',

       ]);

       if ($validator->fails()) {
           return response([
               'status'    => 401,
               'message'   => 'Incorrect format input feilds',
               'error_msg' => $validator->messages()->get('*'),
               'data'      => null,
           ], 200);
       } else {

           $audit_id              = $request->audit_id_edit;
           $branch_id   = $request->assg_branch_edit;
           $audit_date     = date('Y-m-d H:i:s', strtotime($request->audit_dt_edit));
            $audit_time = date('H:i:s', strtotime($request->audit_time_edit));
           $staff_id             = $request->assgn_staff_edit;
           $department_ids      = $request->assg_dept_edit;

           $user_id     = $request->user()->user_id;

           $upd_audit = BranchAuditModel::where('sno', $audit_id)->first();

           $upd_audit->branch_id              = $branch_id;
           $upd_audit->audit_date     = $audit_date;
           $upd_audit->audit_time     = $audit_time;
           $upd_audit->staff_id             = $staff_id;
           $upd_audit->department_ids  = json_encode($department_ids);
           $upd_audit->updated_by           = $user_id;
           $upd_audit->update();

          

           if ($upd_audit) {
               // If category added successfully, return success response and display Toastr message
               session()->flash('toastr', [
                   'type'    => 'success',
                   'message' => 'Branch Audit Update Successfully!',
               ]);
           } else {
               session()->flash('toastr', [
                   'type'    => 'error',
                   'message' => 'Could not update the Branch Audit!',
               ]);
           }
           // }
       }
       return redirect()->back();
   }


   public function auditStaffList(Request $request)
   {
       $branch_id = $request->user()->branch_id;
       $dept_id   = 1;
       $staff     = StaffModel::select('za_staff.*', 'za_job_position.job_position_name as position_name')
       ->join('za_user_role_permission', 'za_user_role_permission.role_id', "=", "za_staff.role_id")
       ->where('za_staff.status', '!=', 2)
       ->join('za_job_position', 'za_job_position.sno', "=", "za_staff.position_role")
       ->where('za_user_role_permission.manage_branch', 2);
       $staff = $staff->orderBy('za_staff.department_id', 'desc')
           ->distinct() // Ensure unique rows
           ->get();

       return response([
           'status'    => 200,
           'message'   => null,
           'error_msg' => null,
           'data'      => $staff,
       ], 200);
   }

   public function auditBranchList(Request $request)
   {
       $branch_id = $request->user()->branch_id;
       $dept_id   = 1;
       $branch     = BranchModel::select('za_branch.*')->where('za_branch.status', '!=', 2)->where('za_branch.sno', '!=', 1)
                    ->orderBy('za_branch.branch_type', 'asc')
                    ->get();

       return response([
           'status'    => 200,
           'message'   => null,
           'error_msg' => null,
           'data'      => $branch,
       ], 200);
   }

   
   public function auditDepartmentList(Request $request)
   {
       $branch_id = $request->user()->branch_id;
       $dept_id   = 1;
       $branch     = DB::table('za_audit_category')->select('za_audit_category.*')->where('za_audit_category.status', 0)
                    ->orderBy('za_audit_category.audit_category_name', 'asc')
                    ->get();

       return response([
           'status'    => 200,
           'message'   => null,
           'error_msg' => null,
           'data'      => $branch,
       ], 200);
   }

   public function ReviewAudit($id,Request $request)
   {   
    //    $branch_id = $request->user()->branch_id;
       $audit_data = DB::table('za_branch_audit')->select('za_audit_staff.audit_staff_name as staff_name','za_audit_staff.audit_staff_mobile as staff_mobile','za_branch_audit.*')
       ->join('za_audit_staff', 'za_branch_audit.staff_id', '=', 'za_audit_staff.sno')
       ->where('za_branch_audit.status', '!=', 2)
       ->where('za_branch_audit.sno', $id)
       ->first(); 

       $helper = new Helpers();
       $generalSettings = $helper->general_setting_data();
       $dateFormat = $generalSettings->date_format ?? 'd-M-y';
       $audit_data->audit_date= $audit_data->audit_date ? Carbon::parse($audit_data->audit_date)->format($dateFormat) : null;

       $branch_data = BranchModel::where('sno', $audit_data->branch_id)->first();
       $branch_name = " ";
       if ($branch_data->branch_type == 1) {
           $branch_name = $branch_data->branch_name;
       } elseif ($branch_data->branch_type == 2) {
           $branch_name = $branch_data->franchise_name;
       }
       $audit_data->branch_name =$branch_name ;
       $audit_data->branch_latitude =$branch_data->latitude ?? '';
       $audit_data->branch_longitude =$branch_data->longitude ??'' ;
       $audit_data->branch_type = $branch_data->branch_type == 1 ? 'Branch' : 'Franchise' ;

       
       $department_ids = json_decode($audit_data->department_ids, true); 

        $depart_list = DB::table('za_audit_category')
            ->select('za_audit_category.audit_category_name','za_audit_category.sno as id')
            ->where('za_audit_category.status', '!=', 2)
            ->whereIn('za_audit_category.sno', $department_ids)
            ->get();
       

            $questions = DB::table('za_audit_question')
            ->select('za_audit_question.audit_question_name as question_name',
                    'za_audit_question.audit_question_option',
                    'za_audit_question.audit_question_type',
                    'za_audit_question.audit_category_id as department_id',
                    'za_audit_question_save.score',
                    'za_audit_question_save.audit_question_answer')
            ->join('za_audit_question_save', 'za_audit_question.sno', '=', 'za_audit_question_save.department_question_id')
            ->where('za_audit_question_save.audit_id', $id)
            ->where('za_audit_question.status', 0)
            ->whereIn('za_audit_question.audit_category_id', $department_ids)
            ->get();

            // foreach ($questions as $singleQuestion) {
            //     // Decode the answer (if it's stored as JSON)
            //     $answer = json_decode($singleQuestion->audit_question_answer);
            //     if (!is_array($answer)) {
            //         $answer = [$answer]; // If not an array, convert it to an array with a single value
            //     }
            //     $singleQuestion->answer = implode(', ', $answer);
            //     $options = json_decode($singleQuestion->audit_question_option);
                
            //     $total_score = 0;
            //     if ($singleQuestion->audit_question_type == 'checkbox') {
            //         foreach ($options as $option) {
            //             if (in_array($option->value, $answer)) {
            //                 $total_score += array_sum($option->score);
            //             }
            //         }
            //     } elseif ($singleQuestion->audit_question_type == 'radio_button') {
            //         $max_score = 0;
            //         foreach ($options as $option) {
            //             if (in_array($option->value, $answer)) {
            //                 // Get the maximum score of the selected option
            //                 $max_score = max($max_score, max($option->score));
            //             }
            //         }
            //         $total_score = $max_score;
            //     } elseif ($singleQuestion->audit_question_type == 'list_box') {
            //         $max_score = 0;
            //         foreach ($options as $option) {
            //             if (in_array($option->value, $answer)) {
            //                 $max_score = max($max_score, max($option->score));
            //             }
            //         }
            //         $total_score = $max_score;
            //     } elseif ($singleQuestion->audit_question_type == 'text_field') {
            //         $total_score = 5;
            //     }
            //     $singleQuestion->total_score = $total_score;
            // }

            foreach ($questions as $singleQuestion) {
                // Decode the answer (if it's stored as JSON)
                $answer = json_decode($singleQuestion->audit_question_answer);
                if (!is_array($answer)) {
                    $answer = [$answer]; // If not an array, convert it to an array with a single value
                }
                $singleQuestion->answer = implode(', ', $answer);

                $options = json_decode($singleQuestion->audit_question_option);
                $total_score = 0;
            
                // Handle checkbox type
                if ($singleQuestion->audit_question_type == 'checkbox') {
                    foreach ($options as $option) {
                        if ($option->value) {
                            $score = (int)$option->score[0]; // Assuming score is a single element array
                            $total_score += $score; // Sum the score
                        }
                    }
                }
                // Handle radio_button and list_box types
                elseif ($singleQuestion->audit_question_type == 'radio_button' || $singleQuestion->audit_question_type == 'list_box') {
                    $max_score = 0;
                    foreach ($options as $option) {
                        if ($option->value) {
                            // Convert score to integer
                            $score = (int)$option->score[0]; // Assuming score is a single element array
                            $max_score = max($max_score, $score); // Get the maximum score
                        }
                    }
                    $total_score = $max_score;
                }
                // Handle text_field type
                elseif ($singleQuestion->audit_question_type == 'text_field') {
                    $total_score = 5;
                }
            
                $singleQuestion->total_score = $total_score;
            }

        
        $depart_names = $depart_list->pluck('audit_category_name')->toArray(); 
        $audit_data->department_name = implode(', ', $depart_names);
        $audit_data->department_list = $depart_list;
        // $questions=[];
        $audit_data->questions = $questions;
       
       return response()->json([
           'status' => 200,
           'success' => true,
           'message' => null,
           'error_msg' => null,
           'data' => $audit_data ,
       ], 200);
   }
   
   public function AuditCancel(Request $request){
        // return $request;
        $validator = Validator::make($request->all(), [
            'cancel_audit_id'    => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $audit_id              = $request->cancel_audit_id;
            $cancel_reason   = $request->cancel_reason;
            $audit_status      = 4;
            $user_id     = $request->user()->user_id;
            $upd_audit = BranchAuditModel::where('sno', $audit_id)->first();

            $upd_audit->cancel_reason     = $cancel_reason;
            $upd_audit->audit_status             = $audit_status;
            $upd_audit->audit_notification             = 4;
            $upd_audit->notification_time = date('Y-m-d H:i:s');
            $upd_audit->updated_by           = $user_id;
            $upd_audit->update();
            
                $this->sendAuditNotification(
                    $audit_id,
                    $upd_audit->staff_id,
                    "Audit Cancelled",
                    $user_id,
                    $audit_status
                );
            if ($upd_audit) {
                // If category added successfully, return success response and display Toastr message
                session()->flash('toastr', [
                    'type'    => 'success',
                    'message' => 'Audit Cancelled Successfully!',
                ]);
            } else {
                session()->flash('toastr', [
                    'type'    => 'error',
                    'message' => 'Could not Cancelled the Audit!',
                ]);
            }

        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_Audit = BranchAuditModel::where('sno', $id)->first();
        $upd_Audit->status = 2;
        $upd_Audit->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}