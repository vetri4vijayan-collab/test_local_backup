<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\DB;
class WhatsappTemplateLog extends Controller
{
  public function index()
  {
     $whatsappTempList = DB::table('za_whatsapp_template')->where('status',0)->orderBy('sno','desc')->get();
    return view('content.branch_management.whatsapp_template_log.whatsapp_template_log',
    [
        "whatsappTempList"=>$whatsappTempList,
    ]
    );
  }

  public function historyLog()
  {
     $whatsappTempList = DB::table('za_whatsapp_template')->where('status',0)->orderBy('sno','desc')->get();
    return view('content.branch_management.whatsapp_template_log.whatsapp_template_history_log',
    [
        "whatsappTempList"=>$whatsappTempList,
    ]
    );
  }
  

public function List(Request $request)
{
    $query = DB::table('za_wb_template as ull')
     ->where('ull.status', '=', 0)
        // ->leftJoin('users as u', 'u.id', '=', 'ull.user_id')
        ->leftJoin('za_branch as b', function ($join) {
            $join->on('b.sno', '=', 'ull.branch_id')
                 ->where('b.status', '=', 0);
        })
        ->select('ull.*', 'ull.branch_id', 'b.branch_name', 'b.franchise_name');

    // 🔍 Search filter (IP or username)
    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('ull.template_name', 'LIKE', "%{$search}%")
              ->orWhere('ull.phone_no', 'LIKE', "%{$search}%")
              ->orWhere('ull.id_source', 'LIKE', "%{$search}%");
        });
    }

    // ⚙️ Type filter (Success / Failed)
    if ($request->filled('type') && $request->type !== '') {
        $query->where('ull.message_status', $request->type);
    }
    if ($request->filled('templateTypeFilter') && $request->templateTypeFilter !== '') {
        $query->where('ull.template_name', $request->templateTypeFilter);
    }

    // 🏢 Branch filter
    if ($request->filled('branch_id') && $request->branch_id != '0') {
        $query->where('ull.branch_id', $request->branch_id);
    }

    
    // ✅ Sort by latest login
    $query->orderBy('ull.sno', 'desc');

    // ✅ Paginate + format
    $logs = $query->paginate(20)->through(function ($log) {
        $message_date_time = \Carbon\Carbon::parse($log->message_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $delivered_date_time = \Carbon\Carbon::parse($log->delivered_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $read_date_time = \Carbon\Carbon::parse($log->read_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $failed_date_time = \Carbon\Carbon::parse($log->failed_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');

        $branchName = 'Unknown';
        $branchId = null;

        if (!empty($log->branch_id)) {
            $branchId = $log->branch_id;
            $branchName = $log->franchise_name ?: $log->branch_name;
        } else {
            // fallback: lookup last success for IP
            // $lastSuccess = DB::table('za_wb_template')
            //     ->where('ip_address', $log->ip_address)
            //     ->where('type', 0)
            //     ->orderBy('login_at', 'desc')
            //     ->first();

            // if ($lastSuccess && $lastSuccess->user_id) {
            //     $user = \App\Models\User::select('branch_id')->find($lastSuccess->user_id);
            //     if ($user && $user->branch_id) {
            //         $branch = \App\Models\BranchModel::where('status', 0)
            //             ->where('sno', $user->branch_id)
            //             ->first();
            //         if ($branch) {
            //             $branchId = $branch->sno;
            //             $branchName = $branch->franchise_name ?: $branch->branch_name;
            //         }
            //     }
            // }

            $branchId = 0;
            $branchName = 'Unknown';
        }

        $template =DB::table('za_whatsapp_template')->where('za_whatsapp_template.whatsapp_title_name','=',$log->template_name)->first();
        $receiver_name=NULL;
        if($log->id_source == 'Customer'){
            $sourceData =DB::table('za_customer')->where('za_customer.sno',$log->unique_id)->first();
           
            $receiver_name=$sourceData ? $sourceData->cus_name : NULL;
        }elseif($log->id_source == 'Lead'){
            $sourceData =DB::table('za_lead')->where('za_lead.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->lead_name : NULL;
        }elseif($log->id_source == 'Event'){
            $sourceData =DB::table('za_event_participant')->where('za_event_participant.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->participant_name : NULL;
        }elseif($log->id_source == 'Branch'){
            $sourceData =DB::table('za_branch')->where('za_branch.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->branch_head_name : NULL;
        }else{
            $receiver_name=NULL;
        }

        $tpl = null;
        if ($template && $template->template_content) {
            $tpl = json_decode($template->template_content, true);

            // handle double-encoded JSON
            if (is_string($tpl)) {
                $tpl = json_decode($tpl, true);
            }
        }
        
        return [
            'sno'  => $log->sno,
            'template_name'  => $log->template_name,
            'whatsapp_template_name'  => $template->whatsapp_template_name,
            'template_module'  => $log->module_name,
            'message_date_time'   => $message_date_time,
            'delivered_date_time'   => $delivered_date_time,
            'read_date_time'   => $read_date_time,
            'failed_date_time'   => $failed_date_time,
            'unique_id'   => $log->unique_id,
            'receiver_no'   => $log->phone_no,
            'receiver_name'   => $receiver_name,
            'reaction_emoji'   => $log->reaction_emoji,
            'payload'    => json_decode($log->payload),
            'message_type'    => $log->type,
            'message_status'  => $log->message_status,
            'errorData'    => json_decode($log->failed_data),
            'template_payload' => $tpl,
            'branch_id'   => $branchId,
            'branch_name' => $branchName,
        ];
    });

    return response()->json([
        'status'  => 200,
        'message' => 'Whatsapp template logs list',
        'data'    => $logs
    ]);
}

public function TemplateList(Request $request)
{
    $query = DB::table('za_whatsapp_template as ull')
    ->where('ull.status', '!=', 2)
        ->select('ull.*');

    // 🔍 Search filter (IP or username)
    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function ($q) use ($search) {
            $q->where('ull.whatsapp_title_name', 'LIKE', "%{$search}%");
        });
    }
    if ($request->filled('templateTypeFilter') && $request->templateTypeFilter !== '') {
        $query->where('ull.whatsapp_title_name', $request->templateTypeFilter);
    }

    // ✅ Sort by latest login
    $query->orderBy('ull.sno', 'desc');

    $date_filter      = $request->dt_fill_issue_rpt ?? 'current_month';
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter   = $request->to_date_fillter_textbox;

    // ✅ Paginate + format
    $logs = $query->paginate(30)->through(function ($log)  use ($date_filter, $from_date_filter, $to_date_filter, $request) {

            $branchName = 'Unknown';
            $branchId = null;
            $total_count= 0;

            $templateQuery = DB::table('za_wb_template')
            ->where('template_name', $log->whatsapp_title_name)
            ->where('status', 0);

        if ($request->filled('branch_id') && $request->branch_id != '0') {
            $templateQuery->where('branch_id', $request->branch_id);
        }

        // ---------- Date Filter ----------
        $templateQuery = $this->applyDateFilter($templateQuery, $date_filter, $from_date_filter, $to_date_filter);

        // ---------- Counts using single query ----------
        $counts = (clone $templateQuery)
            ->selectRaw("
                COUNT(*) as total_count,
                COUNT(CASE WHEN message_status = 'sent' AND message_date_time IS NOT NULL THEN 1 END) as sent_count,
                COUNT(CASE WHEN message_status = 'delivered' AND delivered_date_time IS NOT NULL THEN 1 END) as delivered_count,
                COUNT(CASE WHEN message_status = 'read' AND read_date_time IS NOT NULL THEN 1 END) as read_count,
                COUNT(CASE WHEN message_status = 'failed' AND failed_date_time IS NOT NULL THEN 1 END) as failed_count
            ")
            ->first();

        // ---------- Template content ----------
        $tpl = null;
        if ($log && $log->template_content) {
            $tpl = json_decode($log->template_content, true);
            // handle double-encoded JSON
            if (is_string($tpl)) {
                $tpl = json_decode($tpl, true);
            }
        }
        

        
        
        return [
            'sno'              => $log->sno,
            'template_name'    => $log->whatsapp_title_name,
             'whatsapp_template_name'    => $log->whatsapp_template_name,
            'template_modules'    => json_decode($log->template_use_modals),
            'total_count'      => $counts->total_count ?? 0,
            'sent_count'       => $counts->sent_count ?? 0,
            'delivered_count'  => $counts->delivered_count ?? 0,
            'read_count'       => $counts->read_count ?? 0,
            'failed_count'     => $counts->failed_count ?? 0,
            'template_content' => $tpl,
            'branch_id'        => $branchId,
        ];
    });

    return response()->json([
        'status'  => 200,
        'message' => 'Whatsapp template logs list',
        'data'    => $logs
    ]);
}

private function applyDateFilter($query, $date_filter, $from_date_filter, $to_date_filter)
{
    if ($date_filter == 'today') {
        $query->whereDate('message_date_time', date('Y-m-d'));
    } elseif ($date_filter == 'week') {
        $today = date('l');
        $weekFromDate = ($today == 'Sunday') ? date('Y-m-d', strtotime("sunday 0 week")) : date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = ($today == 'Sunday') ? date('Y-m-d', strtotime("saturday 1 week")) : date('Y-m-d', strtotime("saturday 0 week"));
        $query->whereBetween('message_date_time', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == 'monthly' || $date_filter == null || $date_filter == 'current_month') {
        // Default: current month
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth  = date('Y-m-t');
        $query->whereBetween('message_date_time', [$firstDayOfMonth, $lastDayOfMonth]);
    }  elseif ($date_filter == 'yearly') {
        $query->whereYear('message_date_time', date('Y'));
    } elseif ($date_filter == 'custom_date') {
        if ($from_date_filter && $to_date_filter) {
            $query->whereBetween('message_date_time', [date('Y-m-d', strtotime($from_date_filter)), date('Y-m-d', strtotime($to_date_filter))]);
        } elseif ($from_date_filter) {
            $query->where('message_date_time', '>=', date('Y-m-d', strtotime($from_date_filter)));
        } elseif ($to_date_filter) {
            $query->where('message_date_time', '<=', date('Y-m-d', strtotime($to_date_filter)));
        }
    }

    return $query;
}

public function MessageListByTemplate(Request $request)
{
    $template_id=$request->name;
    $status=$request->status;
    $query = DB::table('za_wb_template as ull')
        ->leftJoin('za_branch as b', function ($join) {
            $join->on('b.sno', '=', 'ull.branch_id')
                 ->where('b.status', '=', 0);
        })
       ->where('ull.template_name',$template_id)
        ->select('ull.*', 'ull.branch_id', 'b.branch_name', 'b.franchise_name');

    // ✅ Sort by latest login
    $query->where('ull.status',0)->orderBy('ull.sno', 'desc');

    $date_filter      = $request->dt_fill_issue_rpt ?? 'current_month';
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter   = $request->to_date_fillter_textbox;

    if($status != 'all'){
         $query->where('ull.message_status',$status);
    }

    if ($date_filter == 'today') {
        $query->whereDate('ull.message_date_time', date('Y-m-d'));
    } elseif ($date_filter == 'week') {
        $today = date('l');
        $weekFromDate = ($today == 'Sunday') ? date('Y-m-d', strtotime("sunday 0 week")) : date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate   = ($today == 'Sunday') ? date('Y-m-d', strtotime("saturday 1 week")) : date('Y-m-d', strtotime("saturday 0 week"));
        $query->whereBetween('ull.message_date_time', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == 'monthly' || $date_filter == null || $date_filter == 'current_month') {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth  = date('Y-m-t');
        $query->whereBetween('ull.message_date_time', [$firstDayOfMonth, $lastDayOfMonth]);
    }  elseif ($date_filter == 'yearly') {
        $query->whereYear('ull.message_date_time', date('Y'));
    } elseif ($date_filter == 'custom_date') {
        if ($from_date_filter && $to_date_filter) {
            $query->whereBetween('ull.message_date_time', [date('Y-m-d', strtotime($from_date_filter)), date('Y-m-d', strtotime($to_date_filter))]);
        } elseif ($from_date_filter) {
            $query->where('ull.message_date_time', '>=', date('Y-m-d', strtotime($from_date_filter)));
        } elseif ($to_date_filter) {
            $query->where('ull.message_date_time', '<=', date('Y-m-d', strtotime($to_date_filter)));
        }
    }

    $template =DB::table('za_whatsapp_template')->where('za_whatsapp_template.whatsapp_title_name',$template_id)->first();

    $logs = $query->paginate(20)->through(function ($log) use($template) {
        $message_date_time = \Carbon\Carbon::parse($log->message_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $delivered_date_time = \Carbon\Carbon::parse($log->delivered_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $read_date_time = \Carbon\Carbon::parse($log->read_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');
        $failed_date_time = \Carbon\Carbon::parse($log->failed_date_time)
            // ->timezone('Asia/Kolkata')
            ->format('d M Y h:i A');

        $branchName = 'Unknown';
        $branchId = null;

        if (!empty($log->branch_id)) {
            $branchId = $log->branch_id;
            $branchName = $log->franchise_name ?: $log->branch_name;
        } else {

            $branchId = 0;
            $branchName = 'Unknown';
        }
       
        $receiver_name=NULL;
        if($log->id_source == 'Customer'){
            $sourceData =DB::table('za_customer')->where('za_customer.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->cus_name : NULL;
        }elseif($log->id_source == 'Lead'){
            $sourceData =DB::table('za_lead')->where('za_lead.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->lead_name : NULL;
        }elseif($log->id_source == 'Event'){
            $sourceData =DB::table('za_event_participant')->where('za_event_participant.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->participant_name : NULL;
        }elseif($log->id_source == 'Branch'){
            $sourceData =DB::table('za_branch')->where('za_branch.sno',$log->unique_id)->first();
            $receiver_name=$sourceData ? $sourceData->branch_head_name : NULL;
        }else{
            $receiver_name=NULL;
        }

        $tpl = null;
        if ($template && $template->template_content) {
            $tpl = json_decode($template->template_content, true);

            // handle double-encoded JSON
            if (is_string($tpl)) {
                $tpl = json_decode($tpl, true);
            }
        }
        
        return [
            'sno'  => $log->sno,
            'template_name'  => $log->template_name,
            'message_date_time'   => $message_date_time,
            'delivered_date_time'   => $delivered_date_time,
            'read_date_time'   => $read_date_time,
            'failed_date_time'   => $failed_date_time,
            'unique_id'   => $log->unique_id,
            'receiver_no'   => $log->phone_no,
            'receiver_name'   => $receiver_name,
            'reaction_emoji'   => $log->reaction_emoji,
            'payload'    => json_decode($log->payload),
            'message_type'    => $log->type,
            'message_status'  => $log->message_status,
            'template_payload' => $tpl,
            'branch_id'   => $branchId,
            'branch_name' => $branchName,
        ];
    });

    return response()->json([
        'status'  => 200,
        'message' => 'Whatsapp template logs list',
        'data'    => $logs,
        'template'    => $template,
        'date_filter'    => $request->dt_fill_issue_rpt,
        'from_date_filter'    => $from_date_filter,
        'to_date_filter'    => $to_date_filter,
    ]);
}
   

}