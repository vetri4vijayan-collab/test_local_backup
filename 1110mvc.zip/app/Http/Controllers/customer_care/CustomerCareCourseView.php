<?php



namespace App\Http\Controllers\customer_care;

use App\Http\Controllers\Controller;
use App\Models\CertificateChecklistModel;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\CostingModel;
use App\Models\TrainingModel;
use App\Helpers\Helpers;
use App\Models\AttendanceModel;
use App\Models\CustomerEducationModel;
use App\Models\ManageCertificateModel;
use App\Models\RequestCertificateModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\PaymentModel;
use App\Models\CourseTypeModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\BatchModel;
use App\Models\LeadModel;
use App\Models\User;
use function Laravel\Prompts\select;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CustomerCareCourseView extends Controller
{
    // public function customer_course_view($id = '')
    // {
    //     $helper = new \App\Helpers\Helpers();
    //     $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    //     $cus_course_id = CustomerModel::where('sno', $decryptedValue)
    //         ->pluck('course_id')
    //         ->first();


    //     $courseIds = json_decode($cus_course_id);
    //     return $courseIds;

    //     $customer_course = CustomerModel::select(
    //         'za_customer.sno',
    //         'za_customer.cus_name',
    //         'za_customer.cus_mobile',
    //         'za_customer.cus_gender',
    //         'za_training.customer_id',
    //         'za_training.course_id',
    //         'za_training.batch_id',
    //         'za_course.sno as course_sno',
    //         'za_batch.batch_name',
    //         'za_batch.start_date',
    //         'za_batch.end_date',
    //         'za_course.course_version',
    //         'za_course.course_name',
    //         'za_course.course_id',
    //         'za_course_type.course_type_name',
    //         'za_course_category.course_category_name',
    //         'za_course_subcategory.course_subcategory_name'
    //     )
    //         ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
    //         ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
    //         ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
    //         ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
    //         ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
    //         ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
    //         ->where('za_customer.sno', $decryptedValue)
    //         ->whereIn('za_training.course_id', $courseIds)
    //         ->groupBy(
    //             'za_customer.sno',
    //             'za_customer.cus_name',
    //             'za_customer.cus_mobile',
    //             'za_customer.cus_gender',
    //             'za_training.customer_id',
    //             'za_training.course_id',
    //             'za_training.batch_id',
    //             'za_course.sno as course_sno',
    //             'za_batch.batch_name',
    //             'za_batch.start_date',
    //             'za_batch.end_date',
    //             'za_course.course_version',
    //             'za_course.course_name',
    //             'za_course.course_id',
    //             'za_course_type.course_type_name',
    //             'za_course_category.course_category_name',
    //             'za_course_subcategory.course_subcategory_name'
    //         )
    //         ->orderBy('za_customer.sno', 'desc')
    //         ->get();
    //     return $customer_course;

    //     $payments_array = PaymentModel::where('customer_id', $decryptedValue)->where('status', 0)->get();
    //     //D:\Xampp_8.2.4\htdocs\elysium_erp_18-10-2024\resources\views\content\customer_care\customer_care_course_view.blade.php
    //     return view('content.customer_care.customer_care_course_view', [
    //         'customer_course' => $customer_course,
    //         'payment_details' => $payments_array,
    //     ]);
    // }
    public function customer_course_view($id = '')
    {
        // Helper for decrypting the id
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        // Fetch course_ids from the customer record
        $cus_course_id = CustomerModel::select(
            'za_customer.sno',
            'za_customer.cus_name',
            'za_customer.cus_mobile',
            'za_customer.cus_gender',
            'course_id',
        )
            ->where('sno', $decryptedValue)
            ->first();
        // return $cus_course_id;

        // Decode course IDs (assumed to be a JSON string)
        $courseIds = json_decode($cus_course_id->course_id);
        // return $courseIds;

        // Check if courseIds are valid (not null or empty)
        if (!$courseIds) {
            return response()->json(['message' => 'No courses found for this customer.'], 404);
        }

        // Fetch customer course data
        $customer_course = CustomerModel::select(
            'za_training.customer_id',
            'za_training.course_id',
            'za_training.batch_id',
            'za_course.sno as course_sno',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_course.course_version',
            'za_course.course_name',
            'za_course.course_id',
            'za_course.course_duration',
            'za_course.course_days',
            'za_course_type.course_type_name',
            'za_slot.slot_name',
            'za_slot.start_time',
            'za_slot.end_time',
            'za_slot.slot_type_days',
            'za_slot_type.slot_type_name',
            'za_staff.staff_name',
            'za_class_room.class_room_name',
        )
            ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
            ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
            ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
            ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
            ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
            ->where('za_customer.sno', $decryptedValue)
            ->whereIn('za_training.course_id', $courseIds)
            ->groupBy(
                'za_training.customer_id',
                'za_training.course_id',
                'za_training.batch_id',
                'za_course.sno',
                'za_batch.batch_name',
                'za_batch.start_date',
                'za_batch.end_date',
                'za_course.course_version',
                'za_course.course_name',
                'za_course.course_duration',
                'za_course.course_days',
                'za_course.course_id',
                'za_course_type.course_type_name',
                'za_slot.slot_name',
                'za_slot.start_time',
                'za_slot.end_time',
                'za_slot.slot_type_days',
                'za_slot_type.slot_type_name',
                'za_staff.staff_name',
                'za_class_room.class_room_name'
            )
            ->orderBy('za_customer.sno', 'desc')
            ->get();
        // return $customer_course;
        // return $courseIds;
        // Fetch payment 
        $paymentDetails = [];

        foreach ($courseIds as $ids) {
            $payments_for_courses = PaymentModel::where('customer_id', $decryptedValue)
                ->where('course_id', $ids)
                ->get();

            if ($payments_for_courses) {
                $paymentDetails[] = $payments_for_courses;
            }
        }

        // return $paymentDetails;


        // $payments_for_courses = PaymentModel::where('customer_id', $decryptedValue)
        //     ->where('status', 0)
        //     ->whereIn('course_id', $courseIds)
        //     // ->groupBy('course_id')
        //     ->get();


        // return $payments_for_courses;

        // Return the view with customer course and payment details
        return view('content.customer_care.customer_care_course_view', [
            'customer_course' => $customer_course,
            'paymentDetails' => $paymentDetails,
            'cus_course_id' => $cus_course_id,
        ]);
    }
}