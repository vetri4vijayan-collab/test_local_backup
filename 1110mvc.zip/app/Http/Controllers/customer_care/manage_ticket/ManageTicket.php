<?php

namespace App\Http\Controllers\customer_care\manage_ticket;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\IssueNoteModel;
use App\Models\CustomerModel;
use App\Models\JobPositionModel;
use App\Models\StaffModel;
use App\Models\User;
use Illuminate\Support\Facades\DB;

use Carbon\Carbon;
class ManageTicket extends Controller
{

 public function index(Request $request)
{
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $customer_fill = $request->cus_fill ?? '';

    // 🔹 Subquery: Get last issue per customer
    $latestIssueSub = DB::table('za_issue_note as zin1')
      ->select('zin1.customer_id', 'zin1.status', 'zin1.created_at', 'zin1.issue_id', 'zin1.category','zin1.branch_id')
      
      ->where('zin1.category', 'customer') // ✅ only customer issues
      ->whereRaw('zin1.created_at = (
          SELECT MAX(zin2.created_at)
          FROM za_issue_note as zin2
          WHERE zin2.customer_id = zin1.customer_id
            AND zin2.category = "customer"     -- ✅ match category
      )');


    // 🔹 Main Query: Join the subquery with customers
    $ManageTicketQuery = DB::table(DB::raw("({$latestIssueSub->toSql()}) as last_issues"))
        ->mergeBindings($latestIssueSub)
        ->join('za_customer as c', 'last_issues.customer_id', '=', 'c.sno')
        ->select(
            'last_issues.customer_id',
            'last_issues.created_at as last_issue_time',
            'last_issues.status',
            'last_issues.category',
            'last_issues.issue_id as last_issue_id',
            'c.cus_name',
            'c.cus_pic',
            'c.cus_gender',
            'c.customer_id as cus_id',
           DB::raw('(SELECT COUNT(*) 
                    FROM za_issue_note 
                    WHERE za_issue_note.customer_id = last_issues.customer_id
                    AND za_issue_note.status = 0
                    AND za_issue_note.is_feedback = 1
            ) as total_issues')
            
        )
        ->where('last_issues.branch_id', $branch_id)
        ->orderBy('last_issues.created_at', 'desc');

    // 🔹 Apply search filter
    if (!empty($customer_fill)) {
        $ManageTicketQuery->where(function ($query) use ($customer_fill) {
            $query->where('c.cus_name', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('c.cus_mobile', 'LIKE', "%{$customer_fill}%")
                  ->orWhere('c.customer_id', 'LIKE', "%{$customer_fill}%");
        });
    }

    // 🔹 Paginate
    $ManageTicket = $ManageTicketQuery->paginate($perpage);

    // 🔹 Count open, closed, and pending tickets
    $openTicketCount = $ManageTicket->where('status', 0)->count();
    $closedTicketCount = $ManageTicket->where('status', 2)->count();
    $pendingTicketCount = $ManageTicket->where('status', 1)->count();

    // 🔹 Fetch customers and staff data
    $customer = CustomerModel::where('branch_id', $branch_id)
        ->where('status', 0)
        ->orderBy('cus_name', 'ASC')
        ->get();

    $staff = StaffModel::select(
            'za_staff.*',
            'za_job_position.job_position_name',
            'za_job_position.sno as job_sno'
        )
        ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno')
        ->where('za_staff.branch_id', $branch_id)
        ->where('za_staff.status', 0)
        ->orderBy('staff_name', 'ASC')
        ->get();

    // 🔹 Return view
    $pageConfigs = ['myLayout' => 'default'];

    // return $ManageTicket;
    return view('content.customer_care.manage_ticket.manage_ticket', [
        'ManageTicket' => $ManageTicket,
        'customer_list' => $customer,
        'staff_list' => $staff,
        'pageConfigs' => $pageConfigs,
        'perpage' => $perpage,
        'cus_fill' => $customer_fill,
        'openTicketCount' => $openTicketCount,
        'closedTicketCount' => $closedTicketCount,
        'pendingTicketCount' => $pendingTicketCount
    ]);
}



 public function fetchChatMessages(Request $request)
{
    $customer_id = $request->customer_id;

    $issues = IssueNoteModel::select(
        'za_issue_note.sno as issue_sno',
        'za_issue_note.issue_id',
        'za_issue_note.created_at',
        'za_issue_note.closed_date',
        'za_issue_note.issue as conversation', // student's message
        'za_issue_note.description as reply',  // staff's reply
        'za_issue_note.attachment',
        'za_issue_note.status',
        'za_issue_note.admin_seen',
        'za_staff.staff_name',
        'za_customer.cus_name',
        'za_customer.sno as cus_sno',
        'za_customer.branch_id as cus_branch_id'
    )
    ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno')
    ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
    ->where('za_issue_note.customer_id', $customer_id)
    ->orderBy('za_issue_note.created_at', 'asc')
    ->get()
    ->map(function($msg) {
        $messages = [];

        // ✅ Customer message (student)
        if (!empty($msg->conversation)) {
            $messages[] = [
                'sender_type' => 'customer',
                'name'        => $msg->cus_name ?? '',
                'message'     => $msg->conversation,
                 'seen'        => false,
                'timestamp'   => Carbon::parse($msg->created_at)
                    ->setTimezone('Asia/Kolkata')
                    ->format('d M Y, h:i A'),
                'attachment'  => $msg->attachment ? asset('issue_attachment/' . $msg->attachment) : null,
            ];
        }

        // ✅ Staff reply (admin/staff)
        if (!empty($msg->reply)) {
            $messages[] = [
                'sender_type' => 'staff',
                'name'        => $msg->staff_name ?? '',
                'message'     => $msg->reply,
                 'seen'        => (int)$msg->admin_seen === 1,
                'timestamp'   => Carbon::parse($msg->created_at)
                    ->setTimezone('Asia/Kolkata')
                    ->format('d M Y, h:i A'),
                'attachment'  => $msg->attachment ? asset('issue_attachment/' . $msg->attachment) : null,
            ];
        }

        return $messages;
    })
    ->flatten(1)
    ->values();

    return response()->json([
        'status' => 200,
        'data'   => $issues
    ]);
}



public function sendChatMessage(Request $request)
{
    $customer_id = $request->customer_id;
    $message = $request->message;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
     $last_issue = IssueNoteModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$last_issue) {
            $year = substr(date('y'), -2);
            $issue_id = 'ISN-0001/' . $year;
        } else {
            $data = $last_issue->issue_id;
            $slice = explode('/', $data);
            $num = preg_replace('/[^0-9]/', '', $slice[0]);
            $next = (int)$num + 1;
            $issue_id = sprintf('ISN-%04d/%s', $next, substr(date('y'), -2));
        }

    $chat = new IssueNoteModel();
    $chat->customer_id = $customer_id;
     $chat->issue_id = $issue_id;
     $chat->branch_id = $branch_id;
     $chat->created_by = $user_id;
    $chat->updated_by = $user_id;
    $chat->description = $message;
    $chat->category = 'admin';
    $chat->save();

    return response()->json([
        'status' => 200,
        'message' => 'Message sent successfully'
    ]);
}

    // In your ChatController or same controller handling chats
public function markSeen(Request $request)
{
    $customer_id = $request->customer_id;

    IssueNoteModel::where('customer_id', $customer_id)
        ->where('category', 'customer')
        ->where('admin_seen', 0) // only unseen ones
        ->update(['admin_seen' => 1]);

    return response()->json(['status' => 200, 'message' => 'Marked as seen']);
}

public function Add_Assignee(Request $request)
{
    // return $request;
    // Validate incoming request data
    $validator = Validator::make($request->all(), [
        'staff_sno' => 'required|integer|exists:za_staff,sno', // Ensure the staff exists in the database
        'authority_sno' => 'required|integer|exists:za_staff,sno', // Ensure the staff exists in the database

    ]);


    $user_id = $request->user()->user_id;


    // $add_category = new IssueNoteModel();
    $add_category = IssueNoteModel::where('sno',$request->issue_sno)->first();
    $add_category->staff_id = $request->staff_sno; // Use the fetched staff name
    $add_category->authority_id = $request->authority_sno; // Use the fetched staff name

    $add_category->attended_by = $user_id; // Use the fetched staff name
    $add_category->updated_by  = $user_id; // Use the fetched staff name
    $add_category->Status = 1;



    // return $add_category;
    $add_category->update();



    // Return success response
    if ($add_category) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff successfully added!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the staff!'
        ]);
    }

    return redirect()->back();
}
public function getTicketDetails(Request $request)
{
    // return $request;
    $id = $request->id;
    // Assuming 'Ticket' is the model for the tickets and it has a 'status' column
    $tickets = IssueNoteModel::select(
        'za_issue_note.*',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.customer_id As cus_id',

        'za_staff.staff_name',  // Adding the staff_name
        'za_staff.staff_image',  // Adding the staff_name
        'za_staff.sno as staff_sno',  // Adding the staff_name
        'za_staff.staff_id',  // You can add more staff details if needed
        'za_job_position.job_position_name',

        'att.staff_name AS attended_staff',  // Adding the staff_name
        'att.staff_image AS attended_staff_img',  // Adding the staff_name
        'att.sno as AS attended_staff_sno',  // Adding the staff_name
        'att.staff_id AS attended_staff_id',    // You can add more staff details if needed
        'att_pos.job_position_name AS attended_staff_position_name',

        'auth.staff_name AS authority_staff_name',  // Adding the staff_name
        'auth.staff_image AS authority_staff_image',  // Adding the staff_name
        'auth.sno as AS authority_staff_sno',  // Adding the staff_name
        'auth.staff_id AS authority_staff_id',    // You can add more staff details if needed
        'auth_pos.job_position_name AS authority_job_position_name',
    )
    ->leftJoin('za_customer', 'za_issue_note.customer_id', '=', 'za_customer.sno')
    ->leftJoin('za_staff', 'za_issue_note.staff_id', '=', 'za_staff.sno') // Adding the join with za_staff table
    ->leftJoin('za_job_position', 'za_staff.position_role', '=', 'za_job_position.sno') // Adding the join with za_staff table

    ->leftJoin('za_staff as auth', 'za_issue_note.authority_id', '=', 'auth.sno')
    ->leftJoin('za_job_position as auth_pos', 'auth.position_role', '=', 'auth_pos.sno')


    ->leftJoin('za_staff as att', 'za_issue_note.attended_by', '=', 'att.sno')
    ->leftJoin('za_job_position as att_pos', 'att.position_role', '=', 'att_pos.sno')
    ->orderBy('za_issue_note.sno', 'desc')
    ->where('za_issue_note.sno',$id)
    ->first();

    // return $tickets;
    // Return the tickets as a JSON response
    return response()->json($tickets);
}

public function Close_ticket(Request $request)
{
    // return $request;
    $validator = Validator::make($request->all(), [
        'viewid' => 'required|integer|exists:sno', // Ensure the staff exists in the database
    ]);

    // return $validator;

    $add_category = IssueNoteModel::where('sno',$request->viewid)->first();
    $add_category->status = 1;
    $add_category->staff_done = true;

    $add_category->description = $request->review_descr;

    $add_category->update();

    if ($add_category) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff successfully added!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the staff!'
        ]);
    }

    return redirect()->back();


}

public function Confirm_ticket(Request $request)
{
    // return $request;
    $validator = Validator::make($request->all(), [
        'viewid' => 'required|integer|exists:sno', // Ensure the staff exists in the database
    ]);

    // return $validator;

    $add_category = IssueNoteModel::where('sno',$request->viewid)->first();
    $add_category->status = 1;
    $add_category->authority_done = true;
    $add_category->description = $request->review_descr;

    $add_category->confirm_date = now();



    $add_category->update();

    if ($add_category) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff successfully added!'
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the staff!'
        ]);
    }

    return redirect()->back();


}
  public function issue_list($cus_id)
{
    $issues = DB::table('za_issue_note')
        ->join('za_feedback_category','za_issue_note.category_id','=','za_feedback_category.sno')
        ->where('za_issue_note.is_feedback', 1)
        ->where('za_issue_note.status', 0)
        ->where('za_issue_note.customer_id', $cus_id)
        ->select(
            'za_issue_note.sno',
            'za_issue_note.issue_id',
            'za_issue_note.feedback_attachment',
            'za_issue_note.priority_level',
            'za_feedback_category.feedback_category',
            'za_issue_note.issue',
            'za_issue_note.status',
            'za_issue_note.issue_reply',
            'za_issue_note.created_at'
        )
        ->get();

    if ($issues->isEmpty()) {
        return response()->json([
            'status' => 404,
            'message' => 'No issues found',
            'data' => []
        ]);
    }

    // Format each issue
    $issues = $issues->map(function ($item) {

        // attachments
        $attachments = [];
        if (!empty($item->feedback_attachment)) {
            $files = explode(',', $item->feedback_attachment);
            foreach ($files as $file) {
                $file = trim($file);
                if ($file && file_exists(public_path($file))) {
                    $attachments[] = asset($file);
                }
            }
        }

        $item->feedback_attachment = $attachments;

        // null to ""
        foreach ($item as $key => $val) {
            if (is_null($val)) {
                $item->$key = "";
            }
        }

        return $item;
    });

    return response()->json([
        'status' => 200,
        'data' => $issues
    ]);
}

public function issue_reply(Request $request)
{
    $request->validate([
        'sno' => 'required',
        'reply' => 'required'
    ]);

    DB::table('za_issue_note')
        ->where('sno', $request->sno)
        ->update([
            'issue_reply' => $request->reply,
            'status' => 1,
            'updated_at' => now()
        ]);

    return response()->json([
        'status' => 200,
        'message' => 'Reply updated successfully'
    ]);
}
}
