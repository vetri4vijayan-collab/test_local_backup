<?php



namespace App\Http\Controllers\customer_care;

use App\Http\Controllers\Controller;
use App\Models\CertificateChecklistModel;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\CostingModel;
use App\Models\TrainingModel;
use App\Helpers\Helpers;
use App\Models\AttendanceModel;
use App\Models\CustomerEducationModel;
use App\Models\ManageCertificateModel;
use App\Models\RequestCertificateModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\PaymentModel;
use App\Models\CourseTypeModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\BatchModel;
use App\Models\LeadModel;
use App\Models\User;
use function Laravel\Prompts\select;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CustomerCare extends Controller
{


  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;

    // return $branch_id;

    $customers = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_staff.staff_name',
      'za_branch.min_prd_cost',
      'za_batch_extension.status AS extended_status',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count') // Count of course_id
    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_branch.min_prd_cost',
        'extended_status'
      )
      ->where('za_customer.status', 0)
      ->orderBy('za_customer.sno', 'desc')
      ->paginate(10);
    // $customers = $customers->unique('payment_id');

    $customers->transform(function ($item, $key) {
      // Initialize an array to hold course and batch details
      $carouselDetails = [];

      // Decode the JSON arrays for course_id and batch_id
      $courseIds = json_decode($item->course_id);
      $batchIds = json_decode($item->batch_id);

      // Check if both arrays are the same length
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      foreach ($courseIds as $index => $courseId) {
        $batchId = $batchIds[$index] ?? [];

        // Retrieve course details
        $course = DB::table('za_course')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->select('za_course.course_name', 'za_course_type.course_type_name')
          ->where('za_course.sno', $courseId)
          ->first();

        // Get date format from general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

        // Retrieve batch details
        $batch = DB::table('za_batch')
          ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
          ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
          ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
          ->where('za_batch.sno', $batchId)
          ->first();

        // Format start_date and end_date
        $startDate = !empty($batch->start_date) ? \Carbon\Carbon::parse($batch->start_date)->format($dateFormat) : null;
        $endDate = !empty($batch->end_date) ? \Carbon\Carbon::parse($batch->end_date)->format($dateFormat) : null;

        // Retrieve summed paidAmount and total_amount for the specific course and batch
        $paymentDetails = DB::table('za_training')
          ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
          ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
          ->where('za_training.customer_id', $item->sno)
          ->where('za_training.course_id', $courseId)
          ->where('za_training.status', '!=', 3)
          ->where('za_payment.status', '!=', 3)
          //   ->where('za_training.batch_id', $batchId)
          ->groupBy('za_payment.total_amount') // Since total_amount remains constant, group by it
          ->first();

        // Calculate payment percentage for the specific course and batch
        $paymentPercentage = 0;
        if ($paymentDetails && $paymentDetails->total_amount > 0) {
          $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
        }

        // Check if attendance exists for the specific batch and customer
        // $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
        //   ->where('batch_id', $batchId)
        //   ->where('attendance', 'P')
        //   ->get();

        // Initialize course progress percentage
        $courseProgress = 0;

        // If attendance exists, check for syllabus update percentage for each attendance record
        // if ($attendanceRecords->isNotEmpty()) {
        //   foreach ($attendanceRecords as $attendance) {
        //     // Check for all syllabus updates that match the batch_id and attendance date
        //     $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchId)
        //       ->whereDate('date', $attendance->att_date) // Check the attendance date
        //       ->get(); // Get all syllabus updates for that date

        //     // If syllabus updates exist, sum the percentages
        //     if ($syllabusUpdates->isNotEmpty()) {
        //       foreach ($syllabusUpdates as $syllabusUpdate) {
        //         $courseProgress += $syllabusUpdate->percentage; // Accumulate all percentages
        //       }
        //     }
        //   }

        //   // Limit the course progress to a maximum of 100%
        //   if ($courseProgress > 100) {
        //     $courseProgress = 100; // Cap the maximum value at 100%
        //   }

        //   // Format the course progress to 2 decimal places
        //   $courseProgress = number_format($courseProgress, 2);
        // }

        // Add the course and batch details to the array
        $carouselDetails[] = [
          'course_sno' => $courseId ?? null,
          'batch_sno' => $batchId ?? null,
          'course_name' => $course->course_name ?? null,
          'course_type_name' => $course->course_type_name ?? null,
          'batch_name' => $batch->batch_name ?? null,
          'start_date' => $startDate, // Use formatted start date
          'end_date' => $endDate, // Use formatted end date
          'slot_name' => $batch->slot_name ?? null,
          'staff_name' => $batch->staff_name ?? null,
          'payment_percentage' => $paymentPercentage, // Include calculated payment percentage here
          'course_progress' => $courseProgress, // Include course progress percentage here
        ];
      }
      // }

      // Attach the carousel details to the customer item
      $item->carousel_details = $carouselDetails;

      // Calculate initial letter
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));

      // Calculate overall payment percentage if total amount is not zero
      if ($item->total_amount > 0) {
        $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
      } else {
        $item->payment_percentage = number_format(0, 1);
      }

      return $item;
    });
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();



    // alagu
    // current month customer
    $currentMonthCustomerCount = CustomerModel::where('za_customer.status', 0)
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->when($branch_id != 0, function ($query) use ($branch_id) {
        return $query->where('za_customer.branch_id', $branch_id);
      })
      ->whereYear('za_customer.created_at', date('Y'))
      ->whereMonth('za_customer.created_at', date('m'))
      ->count();


    // coversion rate current month
    // Get the count of leads for the current month
    $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
    if ($branch_id != 0) {
      $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->count();
    $percentagecurrentmonth = 0;
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }


    $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);



    // get all lead courses
    $allCourses_ids = LeadModel::whereNotIn('status', [3, 2])
      ->where('branch_id', $branch_id)
      ->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->pluck('course_id');
    $allCourses_ids = collect($allCourses_ids)->flatMap(function ($item) {
      return json_decode($item);
    })->values()->all();

    // get all payments
    $payments = [];
    foreach ($allCourses_ids as $id) {
      $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');
      // return  $payment;
      if ($payment !== null) {
        $payments[] = $payment[0];
      } else {
        $payments[] = 0;
      }
    }

    // sum total course amount
    $total_business_value = array_sum($payments);

    $average_business_value = 0;
    // formula for average business
    if ($currentMonthLeadCount > 0) {
      $average_business_value = $total_business_value / $currentMonthLeadCount;
    }

    // calculation for average collection value
    $allCourses_cus = CustomerModel::where('status', 0)->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))->pluck('course_id');
    $allCourses_cus = collect($allCourses_cus)->flatMap(function ($item) {
      return json_decode($item);
    })->values()->all();

    // get all payments
    $payments_cus = [];
    foreach ($allCourses_cus as $id) {
      $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');

      if ($payment !== null) {
        $payments_cus[] = $payment[0];
      } else {
        $payments_cus[] = 0;
      }
    }

    // sum total collection course amount
    $total_collection_value = array_sum($payments_cus);

    // formula for average collection
    $average_collection_value = 0;
    if ($currentMonthCustomerCount > 0) {
      $average_collection_value = $total_collection_value / $currentMonthCustomerCount;
    }
    //  return $conversionRateCurrentmonth;
    // exit;

    // return $customers; customer_care/customer_care_list
    return view('content.customer_care.customer_care_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'customer_name_fill' => '',
      'customer_fill' => '',
      'course_type_list' => $course_type_list,
      'course_type_fill' => '',
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'batch_name_fill' => '',
      'slot_list' => $slot_list,
      'slot_name_fill' => '',
      'slot_type_list' => $slot_type_list,
      'slot_type_name_fill' => '',
      'course_name_fill' => '',
      'date_filter' => '',
      'currentMonthCustomerCount' => $currentMonthCustomerCount,
      'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
      'average_business_value' => $average_business_value,
      'average_collection_value' => $average_collection_value,
    ])->with('filter_on', false);
  }

  public function customer_view($id = '')
  {
    // dd($id);
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    $customer = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_pic',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.contact_person',
      'za_customer.c_p_mobile',
      'za_customer.cus_marital_status',
      'za_customer.created_at',
      'za_countries.name as country_name',
      'za_states.name as state_name',
      'za_cities.name as city_name',
      'za_customer.address',
      'za_customer.door_no',
      'za_customer.pincode',
      'za_customer.customer_ref',
      'za_customer.final_fee',
      DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]")) as course_id'),
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_lead.qualification',
      'za_lead_type.lead_type_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_course.course_duration',
      'za_course.course_days',
      'za_slot.slot_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_slot_type.slot_type_name',
      'za_staff.staff_name',
      'za_class_room.class_room_name',
      'za_branch.min_prd_cost',
      'za_customer.status',
      'za_customer_education.datas',

      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount') // Assuming you want the maximum total_amount for each customer
    )
      ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
      ->leftJoin('za_countries', 'za_customer.country', '=', 'za_countries.id')
      ->leftJoin('za_states', 'za_customer.state', '=', 'za_states.id')
      ->leftJoin('za_cities', 'za_customer.city', '=', 'za_cities.id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->leftjoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_class_room', 'za_batch.classroom_id', '=', 'za_class_room.sno')
      ->leftJoin('za_staff as staff_created_by', 'za_customer.created_by', '=', 'staff_created_by.sno')
      ->leftJoin('za_branch', 'staff_created_by.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id') // Join with payments
      ->leftJoin('za_customer_education', 'za_customer.sno', '=', 'za_customer_education.customer_id') // Join with payments
      ->where('za_customer.sno', $decryptedValue)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_pic',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.contact_person',
        'za_customer.c_p_mobile',
        'za_customer.cus_marital_status',
        'za_customer.created_at',
        'za_countries.name',
        'za_states.name',
        'za_cities.name',
        'za_customer.address',
        'za_customer.door_no',
        'za_customer.pincode',
        'za_customer.final_fee',
        'za_customer.course_id',
        'za_customer.customer_ref',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_lead.qualification',
        'za_lead_type.lead_type_name',
        'za_course.course_name',
        'za_course.course_duration',
        'za_course.course_days',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_slot_type.slot_type_name',
        'za_staff.staff_name',
        'za_class_room.class_room_name',
        'za_branch.min_prd_cost',
        'za_customer.status',
        'za_customer_education.datas',
      )
      ->orderBy('za_customer.sno', 'desc')
      ->first();

    // $customer_eduaction = CustomerModel::select()->where()->get();
    // dd($customer_eduaction);
    // dd($customer);
    $ref_person = CustomerModel::where('status', '!=', 2)
      ->where('customer_id', $customer->customer_ref)
      ->value('cus_name');

    $course_ids = TrainingModel::where('status', '!=', 2)
      ->where('customer_id', $decryptedValue)
      ->pluck('course_id');

    $course_amounts = ManageCoursesModel::whereIn('sno', $course_ids)
      ->pluck('course_max_price');
    $total_amount = $course_amounts->sum();


    $educationDetails = CustomerEducationModel::where('customer_id', $decryptedValue)
      ->leftJoin('za_customer_type', 'za_customer_type.sno', '=', 'za_customer_education.customer_type_id')
      ->select('za_customer_type.customer_type_name', 'datas')
      ->first();


    if ($educationDetails && $educationDetails->datas) {
      $decodedDatas = json_decode($educationDetails->datas, true);

      $formattedData = [];
      foreach ($decodedDatas as $data) {
        if (isset($data['label_name']) && isset($data['label_value'])) {
          $formattedData[] = [
            'field_name' => $data['label_name'],
            'field_value' => $data['label_value']
          ];
        }
      }
      $educationDetails->formatted_data = $formattedData;
    } else {
      $educationDetails->label_ids = [];
    }


    // return $customer_attend_view;  
    // $customer_course_ids = CustomerModel::select('za_customer.course_id')
    //   ->where('status', '!=', 2)
    //   ->where('sno', $decryptedValue)
    //   ->first();
    // // dd($customer_course_ids);
    // $courseIds = json_decode($customer_course_ids->course_id); // Assuming $decryptedValue contains the course_id as a JSON string
    // // return  $courseIds;
    // // Initialize arrays for chapters, sections, and topics
    // $chapters = [];
    // $sections = [];
    // $topics = [];

    // // Fetch unique chapters with their latest section based on maximum sno
    // $chapter_views = ManageCoursesSyllabusModel::where('course_id', $courseIds)
    //   ->select('course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
    //   ->groupBy('course_chapter_id', 'course_chapter_name')
    //   ->get();

    // foreach ($chapter_views as $chapter) {
    //   // Fetch the latest section for each chapter
    //   $latest_sections = ManageCoursesSyllabusModel::where('course_id', $courseIds)
    //     ->where('course_chapter_id', $chapter->course_chapter_id)
    //     ->select('session_id', DB::raw('MAX(sno) as max_sno'))
    //     ->where('status', 0)
    //     ->groupBy('session_id')
    //     ->get();

    //   foreach ($latest_sections as $sec) {
    //     // Fetch the latest topics for each section
    //     $latest_topics = ManageCoursesSyllabusModel::where('course_id', $courseIds)
    //       ->where('course_chapter_id', $chapter->course_chapter_id)
    //       ->where('session_id', $sec->session_id)
    //       ->where('status', 0)
    //       ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
    //       ->groupBy('topic_id')
    //       ->get();

    //     // Store topics under each section
    //     $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
    //   }
    // }
    // return $topics;
    // $unique_results = $customer_attend_view->unique('za_training.sno')->values();
    // return $unique_results;
    // return $customer_attend_view;






    // $att = CostingModel::where('za_costing.batch_id', $customer_attend_view->sno)
    //   ->where('za_costing.staff_id', $customer_attend_view->staff_id)
    //   ->where('za_costing.course_id', $customer_attend_view->course_id)
    //   ->where('za_costing.status', 0)
    //   ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration', 'za_attendance.batch_id', 'za_attendance.course_id', 'za_attendance.staff_id', 'za_attendance.attendance', 'za_attendance.att_date')
    //   ->join('za_customer', 'za_costing.customer_id', '=', 'za_customer.sno')
    //   ->join('za_course', 'za_costing.course_id', '=', 'za_course.sno')
    //   ->leftjoin('za_attendance', 'za_attendance.batch_id', '=', 'za_costing.batch_id')
    //   ->groupBy('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration', 'za_attendance.batch_id', 'za_attendance.staff_id', 'za_attendance.course_id', 'za_attendance.attendance', 'za_attendance.att_date')
    //   ->where('za_attendance.staff_id', $customer_attend_view->staff_id)
    //   ->get();




    // return $customer_attend_view;
    // dd($customer_attend_view);

    return view('content.customer_care.customer_care_view', [
      'customer' => $customer,
      'total_amount' => $total_amount,
      'ref_person' => $ref_person,
      'educationDetails' => $educationDetails,
      // 'unique_results' => $unique_results,
      // 'customer_attend_view' => $customer_attend_view,

    ]);
  }
  // {{***********working but for single course*************}}
  // public function customer_course_view($id = '')
  // {
  //   $helper = new \App\Helpers\Helpers();
  //   $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

  //   $cus_course_id = CustomerModel::where('sno', $decryptedValue)
  //     ->pluck('course_id')
  //     ->first();

  //   // Assume $customerIdParam is the customer ID and $courseIds is an array of course IDs
  //   $courseIds = json_decode($cus_course_id);

  //   // return $courseIds;


  //   $customer_course = CustomerModel::select(
  //     'za_customer.sno',
  //     'za_customer.cus_name',
  //     'za_customer.customer_id',
  //     'za_customer.cus_gender',
  //     'za_customer.cus_dob',
  //     'za_customer.cus_pic',
  //     'za_customer.cus_mobile',
  //     'za_customer.cus_alternate_mobile',
  //     'za_customer.cus_email_id',
  //     'za_customer.contact_person',
  //     'za_customer.c_p_mobile',
  //     'za_customer.cus_marital_status',
  //     'za_countries.name as country_name',
  //     'za_states.name as state_name',
  //     'za_cities.name as city_name',
  //     'za_customer.address',
  //     'za_customer.door_no',
  //     'za_customer.pincode',
  //     'za_customer.customer_ref',
  //     'za_customer.final_fee',
  //     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]")) as course_id'),
  //     'za_customer.free_shd_count',
  //     'za_customer.request_count',
  //     'za_customer.reason_request',
  //     'za_customer.free_status',
  //     'za_customer.reason_reject',
  //     'za_customer.created_by',
  //     'za_customer.batch_id',
  //     'za_lead.sno as lead_id',
  //     'za_lead.qualification',
  //     'za_lead_type.lead_type_name',
  //     'za_batch.batch_name',
  //     'za_batch.start_date',
  //     'za_batch.end_date',
  //     'za_course_type.course_type_name',
  //     'za_course.course_name',
  //     'za_course.course_duration',
  //     'za_course.course_days',
  //     'za_slot.slot_name',
  //     'za_slot.start_time',
  //     'za_slot.end_time',
  //     'za_slot.slot_type_days',
  //     'za_slot_type.slot_type_name',
  //     'za_staff.staff_name',
  //     'za_class_room.class_room_name',
  //     'za_branch.min_prd_cost',
  //     'za_customer.status',
  //     'za_customer_education.datas',

  //     DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
  //     DB::raw('MAX(za_payment.total_amount) as total_amount') // Assuming you want the maximum total_amount for each customer
  //   )
  //     ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
  //     ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
  //     ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
  //     ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
  //     ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
  //     ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
  //     ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
  //     ->leftJoin('za_countries', 'za_customer.country', '=', 'za_countries.id')
  //     ->leftJoin('za_states', 'za_customer.state', '=', 'za_states.id')
  //     ->leftJoin('za_cities', 'za_customer.city', '=', 'za_cities.id')
  //     ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
  //     ->leftjoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
  //     ->leftJoin('za_class_room', 'za_batch.classroom_id', '=', 'za_class_room.sno')
  //     ->leftJoin('za_staff as staff_created_by', 'za_customer.created_by', '=', 'staff_created_by.sno')
  //     ->leftJoin('za_branch', 'staff_created_by.branch_id', '=', 'za_branch.sno')
  //     ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id') // Join with payments
  //     ->leftJoin('za_customer_education', 'za_customer.sno', '=', 'za_customer_education.customer_id') // Join with payments
  //     ->whereIn('za_training.course_id', $courseIds)
  //     ->where('za_customer.sno', $decryptedValue)
  //     ->groupBy(
  //       'za_customer.sno',
  //       'za_customer.cus_name',
  //       'za_customer.customer_id',
  //       'za_customer.cus_gender',
  //       'za_customer.cus_dob',
  //       'za_customer.cus_mobile',
  //       'za_customer.cus_pic',
  //       'za_customer.cus_alternate_mobile',
  //       'za_customer.cus_email_id',
  //       'za_customer.contact_person',
  //       'za_customer.c_p_mobile',
  //       'za_customer.cus_marital_status',
  //       'za_countries.name',
  //       'za_states.name',
  //       'za_cities.name',
  //       'za_customer.address',
  //       'za_customer.door_no',
  //       'za_customer.pincode',
  //       'za_customer.final_fee',
  //       'za_customer.course_id',
  //       'za_customer.customer_ref',
  //       'za_customer.free_shd_count',
  //       'za_customer.request_count',
  //       'za_customer.free_status',
  //       'za_customer.reason_request',
  //       'za_customer.reason_reject',
  //       'za_customer.created_by',
  //       'za_customer.batch_id',
  //       'za_lead.sno',
  //       'za_lead.qualification',
  //       'za_lead_type.lead_type_name',
  //       'za_course.course_name',
  //       'za_course.course_duration',
  //       'za_course.course_days',
  //       'za_batch.batch_name',
  //       'za_batch.start_date',
  //       'za_batch.end_date',
  //       'za_course_type.course_type_name',
  //       'za_slot.slot_name',
  //       'za_slot.start_time',
  //       'za_slot.end_time',
  //       'za_slot.slot_type_days',
  //       'za_slot_type.slot_type_name',
  //       'za_staff.staff_name',
  //       'za_class_room.class_room_name',
  //       'za_branch.min_prd_cost',
  //       'za_customer.status',
  //       'za_customer_education.datas',
  //     )
  //     ->orderBy('za_customer.sno', 'desc')
  //     ->first();
  //   // return $customer_course;

  //   $payments_array = PaymentModel::where('customer_id', $decryptedValue)->where('status', 0)->get();
  //   //D:\Xampp_8.2.4\htdocs\elysium_erp_18-10-2024\resources\views\content\customer_care\customer_care_course_view.blade.php
  //   return view('content.customer_care.customer_care_course_view', [
  //     'customer_course' => $customer_course,
  //     'payment_details' => $payments_array,
  //   ]);
  // }
  // public function customer_course_view($id = '')
  // {
  //   $helper = new \App\Helpers\Helpers();
  //   $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

  //   $cus_course_id = CustomerModel::where('sno', $decryptedValue)
  //     ->pluck('course_id')
  //     ->first();

  //   $courseIds = json_decode($cus_course_id);
  //   $customer_course = CustomerModel::select(
  //     'za_customer.sno',
  //     'za_customer.cus_name',
  //     'za_customer.customer_id',
  //     'za_customer.cus_gender',
  //     'za_customer.cus_dob',
  //     'za_customer.cus_pic',
  //     'za_customer.cus_mobile',
  //     'za_customer.cus_alternate_mobile',
  //     'za_customer.cus_email_id',
  //     'za_customer.customer_ref',
  //     'za_customer.final_fee',
  //     'za_customer.free_shd_count',
  //     'za_customer.request_count',
  //     'za_customer.reason_request',
  //     'za_customer.free_status',
  //     'za_customer.reason_reject',
  //     'za_customer.created_by',
  //     'za_customer.batch_id',
  //     'za_lead.sno as lead_id',
  //     'za_lead.qualification',
  //     'za_lead_type.lead_type_name',
  //     'za_batch.batch_name',
  //     'za_batch.start_date',
  //     'za_batch.end_date',
  //     'za_course_type.course_type_name',
  //     'za_course.course_name',
  //     'za_course.course_duration',
  //     'za_course.course_days',
  //     'za_slot.slot_name',
  //     'za_slot.start_time',
  //     'za_slot.end_time',
  //     'za_slot.slot_type_days',
  //     'za_slot_type.slot_type_name',
  //     'za_class_room.class_room_name',
  //     'za_branch.min_prd_cost',
  //     'za_customer.status',

  //     DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
  //     DB::raw('MAX(za_payment.total_amount) as total_amount')
  //   )
  //     // ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
  //     ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
  //     ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
  //     ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
  //     ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
  //     ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
  //     ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
  //     ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
  //     ->leftJoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
  //     ->leftJoin('za_class_room', 'za_batch.classroom_id', '=', 'za_class_room.sno')
  //     ->leftJoin('za_staff as staff_created_by', 'za_customer.created_by', '=', 'staff_created_by.sno')
  //     ->leftJoin('za_branch', 'staff_created_by.branch_id', '=', 'za_branch.sno')
  //     ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
  //     ->leftJoin('za_customer_education', 'za_customer.sno', '=', 'za_customer_education.customer_id')
  //     ->whereIn('za_training.course_id', $courseIds)  // Ensure the course ID is in the provided $courseIds
  //     ->where('za_customer.sno', $decryptedValue)  // Use the decrypted customer ID
  //     ->groupBy(
  //       'za_customer.sno',
  //       'za_customer.cus_name',
  //       'za_customer.customer_id',
  //       'za_customer.cus_gender',
  //       'za_customer.cus_dob',
  //       'za_customer.cus_mobile',
  //       'za_customer.cus_pic',
  //       'za_customer.cus_alternate_mobile',
  //       'za_customer.cus_email_id',
  //       'za_customer.customer_ref',
  //       'za_customer.final_fee',
  //       'za_customer.free_shd_count',
  //       'za_customer.request_count',
  //       'za_customer.reason_request',
  //       'za_customer.free_status',
  //       'za_customer.reason_reject',
  //       'za_customer.created_by',
  //       'za_customer.batch_id',
  //       'za_lead.sno',
  //       'za_lead.qualification',
  //       'za_lead_type.lead_type_name',
  //       'za_course.course_name',
  //       'za_course.course_duration',
  //       'za_course.course_days',
  //       'za_batch.batch_name',
  //       'za_batch.start_date',
  //       'za_batch.end_date',
  //       'za_course_type.course_type_name',
  //       'za_slot.slot_name',
  //       'za_slot.start_time',
  //       'za_slot.end_time',
  //       'za_slot.slot_type_days',
  //       'za_slot_type.slot_type_name',
  //       'za_class_room.class_room_name',
  //       'za_branch.min_prd_cost',
  //       'za_customer.status'
  //     )
  //     ->orderBy('za_customer.sno', 'desc')
  //     ->get();
  //   $payments_array = PaymentModel::where('customer_id', $decryptedValue)->where('status', 0)->get();
  //   return view('content.customer_care.customer_care_course_view', [
  //     'customer_course' => $customer_course,
  //     'payment_details' => $payments_array,
  //   ]);
  // }

  // public function customer_attendance_view($id = '')
  // {
  //   // return $id;
  //   $helper = new \App\Helpers\Helpers();
  //   $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

  //   $cus_course_id = CustomerModel::where('sno', $decryptedValue)
  //     ->pluck('course_id') // Use pluck to get an array of values
  //     ->first(); // Get the first value directly

  //   $courseIds = json_decode($cus_course_id);
  //   // return $courseIds;


  //   $customer = CustomerModel::select(
  //     'za_customer.sno',
  //     'za_customer.cus_name',
  //     'za_customer.cus_mobile',
  //     'za_customer.cus_gender',
  //     'za_training.customer_id',
  //     'za_training.course_id',
  //     'za_training.batch_id',
  //     'za_course.sno as course_sno',
  //     'za_batch.batch_name',
  //     'za_batch.start_date',
  //     'za_batch.end_date',
  //     'za_course.course_version',
  //     'za_course.course_name',
  //     'za_course.course_id',
  //     'za_course_type.course_type_name',
  //     'za_course_category.course_category_name',
  //     'za_course_subcategory.course_subcategory_name'
  //   )
  //     ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
  //     ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
  //     ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
  //     ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
  //     ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
  //     ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
  //     ->where('za_customer.sno', $decryptedValue)
  //     ->whereIn('za_training.course_id', $courseIds)
  //     ->get();
  //   // return $customer;

  //   // // Decode the course_ids from the JSON string
  //   // $courseIds = json_decode($cus_course_id);
  //   // return $courseIds;

  //   // Initialize an array to store the topics
  //   $topics = [];

  //   // Fetch unique chapters for all courses based on course_id
  //   $chapter_views = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
  //     ->select('course_id', 'course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
  //     ->groupBy('course_id', 'course_chapter_id', 'course_chapter_name')
  //     ->get();

  //   // Iterate through each chapter to fetch the latest sections and topics
  //   foreach ($chapter_views as $chapter) {
  //     // Initialize array for storing sections
  //     $sections = [];

  //     // Fetch the latest sections for the current chapter across all courses
  //     $latest_sections = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
  //       ->where('course_chapter_id', $chapter->course_chapter_id)
  //       ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
  //       ->where('status', 0)
  //       ->groupBy('session_id', 'session_name')
  //       ->get();

  //     // Loop through each section and fetch the latest topics for each section
  //     foreach ($latest_sections as $sec) {
  //       // Fetch the latest topics for the current section
  //       $latest_topics = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
  //         ->where('course_chapter_id', $chapter->course_chapter_id)
  //         ->where('session_id', $sec->session_id)
  //         ->where('status', 0)
  //         ->select('topic_id', 'topic_name', DB::raw('MAX(sno) as max_sno'))
  //         ->groupBy('topic_id', 'topic_name')
  //         ->get();

  //       // Store the topics under the corresponding section
  //       $sections[$sec->session_id] = [
  //         'section_name' => $sec->session_name,
  //         'topics' => $latest_topics  // The topics for this section
  //       ];
  //     }

  //     // Store the sections (and associated topics) under the corresponding chapter
  //     $topics[$chapter->course_chapter_id] = [
  //       'chapter_name' => $chapter->course_chapter_name,
  //       'sections' => $sections  // The sections and their topics
  //     ];
  //   }

  //   // Return the final result containing all chapters, sections, and topics
  //   // return $topics;


  //   return view('content.customer_care.customer_attendance_view', [
  //     'summary_list' => $topics,
  //     'customer' => $customer,
  //     // 'customer_attend_view' => $customer_attend_view,

  //   ]);
  // }
  // Course List Start
  public function Course_List()
  {

    $managecourses_list = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', '!=', 2)->orderBy('za_course.sno', 'desc')->get();

    $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.customer_care.course_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'course_fill' => '',
      'course_type_fill' => '',
      'min_price_fill' => '',
      'max_price_fill' => '',
      'pageConfigs' => $pageConfigs
    ])->with('filter_on', false);
  }

  public function Course_list_filter(Request $request)
  {
    $course_fill = $request->course_fill ?? '';
    $course_type_fill = $request->course_type_fill ?? '';
    $min_price_fill = $request->min_price_fill ?? '';
    $max_price_fill = $request->max_price_fill ?? ''; // Fix for branch_type_fill

    // Initialize query without fetching data yet
    $query = ManageCoursesModel::select('za_course.*', 'za_course_type.course_type_name', 'za_course_type.sno as category_id')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', '!=', 2)
      ->orderBy('za_course.sno', 'desc');

    // Apply filters dynamically
    if ($course_fill) {
      $query->where('za_course.course_name', 'LIKE', "%{$course_fill}%");
    }
    if ($course_type_fill) {
      $query->where('za_course.course_type_id', $course_type_fill);
    }
    if ($min_price_fill) {
      $query->where('za_course.course_min_price', 'LIKE', "%{$min_price_fill}%");
    }
    if ($max_price_fill) {
      $query->where('za_course.course_max_price', 'LIKE', "%{$max_price_fill}%");
    }

    // Fetch the filtered and ordered results
    $managecourses_list = $query->get();

    // Fetch course types for filter options
    $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    $pageConfigs = ['myLayout' => 'default'];

    // Return view with data
    return view('content.customer_care.course_list', [
      'managecourses_list' => $managecourses_list,
      'course_type_fill_list' => $course_type,
      'course_fill' => $course_fill,
      'course_type_fill' => $course_type_fill,
      'min_price_fill' => $min_price_fill,
      'max_price_fill' => $max_price_fill,
      'pageConfigs' => $pageConfigs
    ])->with('filter_on', true);
  }

  // Course List End

  // Batch List Start
  public function Batch_List(Request $request)
  {

    $branch_id = $request->user()->branch_id;

    $batchQuery = BatchModel::select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftjoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->where('za_batch.status', '!=', [2, 3]);

    if ($branch_id != 0) {
      $batchQuery->where('za_batch.branch_id', $branch_id);
    }

    $batch = $batchQuery->orderBy('sno', 'desc')->paginate(10);

    // Get the student count for each batch
    foreach ($batch as $singleBatch) {
      $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
        // Uncomment the next line if you want to filter by course_id
        // ->where('course_id', $singleBatch->course_id)
        ->count('customer_id');
    }
    // return $batch;

    // Prepare the course types
    $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();

    return view('content.customer_care.batch_list', [
      'batch' => $batch,
      'course_Type_list' => $course_type,
      'course_type_fill' => '',
      'course_fill' => '',
      'batch_name_fill' => '',
      'fin_yr_fill' => '',
      'date_filter' => '',
    ])->with('filter_on', false);
  }

  public function Batch_list_filter(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    // return $request;
    // Retrieve request parameters with default values
    $course_type_fill = $request->course_type_fill ?? '';
    $course_fill = $request->course_fill ?? '';
    $batch_name_fill = $request->batch_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // Initialize query with base conditions
    $query = BatchModel::where('za_batch.status', '!=', 2);

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_batch.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_batch.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_batch.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_batch.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_batch.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_batch.created_at', '<=', $toDate);
      }
    }
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);

      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true);

        if (is_array($monthsArray) && !empty($monthsArray)) {
          $monthConditions = [];

          foreach ($monthsArray as $month) {
            if (is_numeric($month) && $month >= 1 && $month <= 12) {
              $monthConditions[] = [
                'year' => date('Y'),
                'month' => (int) $month,
              ];
            }
          }
          if (!empty($monthConditions)) {
            $query->where(function ($query) use ($monthConditions) {
              foreach ($monthConditions as $condition) {
                $query->orWhere(function ($q) use ($condition) {
                  $q->whereYear('za_batch.created_at', $condition['year'])
                    ->whereMonth('za_batch.created_at', $condition['month']);
                });
              }
            });
          }
        }
      }
    }

    if ($course_type_fill) {
      $query->where('za_batch.course_type_id', $course_type_fill);
    }
    if ($course_fill) {
      $query->where('za_batch.course_id', $course_fill);
    }
    if ($batch_name_fill) {
      $query->where('batch_name', 'like', "%{$batch_name_fill}%");
    }
    if ($branch_id != 0) {
      $query->where('za_batch.branch_id', $branch_id);
    }

    // Fetch Branch list ordered by sno in descending order

    $query->select('za_batch.*', 'za_slot.slot_name', 'za_course.course_name', 'za_course_type.course_type_name', 'za_class_room.class_room_name', 'za_slot_type.slot_type_name', 'za_slot.start_time', 'za_slot.end_time', 'za_staff.staff_name', 'za_batch_extension.status AS exten_status')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->orderBy('za_batch.sno', 'desc');

    if ($branch_id != 0) {
      $query->where('za_batch.branch_id', $branch_id);
    }

    $batch_list = $query->paginate(10);

    // Get the student count for each batch
    foreach ($batch_list as $singleBatch) {
      $singleBatch->student_count = TrainingModel::where('batch_id', $singleBatch->sno)
        // Uncomment the next line if you want to filter by course_id
        // ->where('course_id', $singleBatch->course_id)
        ->count('customer_id');
    }
    // return $batch_list;
    $course_type = CourseTypeModel::select('*')->where('status', 0)->orderBy('sno', 'desc')->get();
    // Return the view with filter variables and session flash for filter_on
    return view('content.customer_care.batch_list', [
      'batch' => $batch_list,
      'course_Type_list' => $course_type,
      'course_type_fill' => $course_type_fill,
      'course_fill' => $course_fill,
      'batch_name_fill' => $batch_name_fill,
      'date_filter' => $date_filter,
      'fin_yr_fill' => $fin_yr_fill,
    ])->with('filter_on', true);
  }

  // Course List End



  // certificate
  public function ManageCertificate()
  {
    $manage_certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.status as batch_status',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text'
    )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', self::$branch_id) // Assuming branch_id is a field in za_manage_certificate table
      ->orderBy('za_manage_certificate.sno', 'desc')
      ->get();

    // return $manage_certificate;
    // dd($manage_certificate);
    return view('content.customer_care.manage_certificate_list', [
      'manage_certificate' => $manage_certificate
    ]);
  }
  public function List()
  {
    $cert_list = ManageCertificateModel::where('status', 0)->where('cert_status_id >=', 4)->where('cert_status_id >=', 1)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $cert_list
    ], 200);

    // dd($cert_list);
  }

  public function View($id = '')
  {

    // return $id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Find the Certificate  by decrypted ID
    $certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.created_at as batch_created',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text'
    )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', self::$branch_id)->where('za_manage_certificate.sno', $decryptedValue)->first();

    $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->distinct('za_training.customer_id')  // Ensure unique customers
      ->count('za_training.customer_id');

    // dd($totalStudents);
    $checklistView = CertificateChecklistModel::where('status', 0)->get();
    // Check if the course is not found
    if (!$certificate) {
      return redirect()->back()->with('error', 'Certificate View not found');
    }

    return view('content.customer_care.manage_certificate_view', [
      'view' => $certificate,
      'stud_view' => $totalStudents,
      'checklist' => $checklistView
    ]);
  }

  public function CertificateRequest($id = '')
  {
    return $id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $certificate = ManageCertificateModel::select(
      'za_manage_certificate.*',
      'za_slot.slot_name',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_batch.max_students',
      'za_batch.created_at as batch_created',
      'za_course.course_name',
      'za_course.course_version',
      'za_course_type.course_type_name',
      'za_course_type.course_days',
      'za_class_room.class_room_name',
      'za_slot_type.slot_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_certificate_status.certificate_status_name',
      'za_certificate_status.bg_color as cert_status_bg',
      'za_certificate_status.text_color as cert_status_text',
      'za_certificate_authority_status.certificate_authority_status_name',
      'za_certificate_authority_status.bg_color as authority_status_bg',
      'za_certificate_authority_status.text_color as authority_status_text',
      'za_certificate_checklist.certificate_checklist_name',
      'za_certificate_checklist.certificate_checklist_desc',
    )
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_manage_certificate.batch_id')
      ->leftJoin('za_certificate_status', 'za_certificate_status.sno', '=', 'za_manage_certificate.cert_status_id')
      ->leftJoin('za_certificate_checklist', 'za_certificate_checklist.sno', '=', 'za_manage_certificate.certificate_checklist_id')
      ->leftJoin('za_certificate_authority_status', 'za_certificate_authority_status.sno', '=', 'za_manage_certificate.certificate_authority_status_id')
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_manage_certificate.status', '!=', 2)
      ->where('za_manage_certificate.branch_id', '=', self::$branch_id)->where('za_manage_certificate.sno', $decryptedValue)->first();

    // Check if the course is not found
    if (!$certificate) {
      return redirect()->back()->with('error', 'Certificate Request not found');
    }

    $totalStudents = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->distinct('za_training.customer_id')  // Ensure unique customers
      ->count('za_training.customer_id');

    $lists = TrainingModel::where('za_training.batch_id', $certificate->batch_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.cus_pic', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();

    // dd($totalStudents);

    // dd($certificate);
    $checklist = CertificateChecklistModel::where('status', 0)->get();
    return view('content.courses.manage_certificate.request', [
      'request' => $certificate,
      'checklist' => $checklist,
      'stud_view' => $totalStudents,
      'stud_list' => $lists,
    ]);
  }

  public function AddRequest(Request $request)
  {
    // return $request;

    $checklistData = $request->input('checklist', []);
    $eligibleAll = $request->input('eligible_all', false);
    $reason = $request->input('reason', '');
    $batch_id = $request->input('batch_id');
    $eligibleStudIds = $request->input('eligible_stud_id', []);
    // dd($eligibleStudIds);
    $student_ids = $eligibleStudIds;

    $formattedChecklistData = [];
    foreach ($checklistData as $sno => $value) {
      $formattedChecklistData[] = [
        'sno' => $sno,
        'value' => $value
      ];
    }

    $certificateRequest = new RequestCertificateModel();
    $certificateRequest->branch_id = 1;
    $certificateRequest->batch_id = $batch_id;
    $certificateRequest->student_id = json_encode($student_ids);
    $certificateRequest->certificate_checklist_id = json_encode($formattedChecklistData); // Convert to JSON
    $certificateRequest->eligibility = $eligibleAll ? 1 : 0;
    $certificateRequest->reason = $reason;
    $certificateRequest->created_at = now();
    $certificateRequest->created_by = 1; // Set the user ID or handle accordingly
    $certificateRequest->updated_at = now();
    $certificateRequest->updated_by = 1; // Set the user ID or handle accordingly
    $certificateRequest->status = 0; // Set status to 2 as required
    // return $certificateRequest;
    $certificateRequest->save();



    if ($certificateRequest) {
      $manageCertificate = ManageCertificateModel::where('batch_id', $certificateRequest->batch_id)->first();

      //  dd($manageCertificate);

      if ($manageCertificate) {
        $manageCertificate->cert_status_id = 2; // Set status to 2 or any other field updates based on your logic
        $manageCertificate->req_cert_date = $certificateRequest->updated_at;
        $studentIdsArray = json_decode($certificateRequest->student_id, true);
        if (is_array($studentIdsArray)) {
          $manageCertificate->req_stud_count = count($studentIdsArray);
          $manageCertificate->confirm_stud_count = count($studentIdsArray);
        } else {
          $manageCertificate->req_stud_count = 0;
          $manageCertificate->confirm_stud_count = 0;
        }
        $manageCertificate->save();
      }
    }
    // Redirect to the specified route
    return redirect()->route('courses_manage_certificate')->with('success', 'Certificate request submitted successfully.');
  }

  public function CourseSummaryPrint($id)
  {


    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;

    $exp = explode('~', $decryptedValue);
    $customer_id = str_replace(' ', '', $exp[0] ?? '');
    $course_id = str_replace(' ', '', $exp[1] ?? '');




    $customer_details_print = TrainingModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.customer_id',
      'za_training.customer_id as customer_sno',
      'za_customer.cus_mobile',
      'za_customer.cus_email_id',
      'za_customer.course_id',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_course.course_duration',
      'za_course.course_days',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_staff.staff_name',
      'za_slot.slot_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_slot.slot_type_days',
      'za_slot_type.slot_type_name',

    )
      ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_training.customer_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_training.course_id')
      ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->leftJoin('za_batch', 'za_batch.sno', '=', 'za_training.batch_id')
      ->leftJoin('za_staff', 'za_staff.sno', '=', 'za_training.staff_id')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
      ->where('za_training.customer_id', $customer_id)
      ->where('za_training.course_id', $course_id)
      ->first();
    // return  $customer_details_print;
    $payments_array_print = PaymentModel::where('customer_id', $customer_id)->where('course_id', $course_id)->get();
    // dd($customer_details_print, $payments_array_print);
    // return ($customer_details_print, $payments_array_print);

    $paymentDetails = DB::table('za_training')
      ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
      ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->where('za_training.customer_id', $customer_id)
      ->where('za_training.course_id', $course_id)
      ->where('za_training.status', '!=', 3)
      ->where('za_payment.status', '!=', 3)
      ->groupBy('za_payment.total_amount')
      ->first();
    // return  $paymentDetails;

    $paymentPercentage = 0;
    if ($paymentDetails && $paymentDetails->total_amount > 0) {
      $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
    }
    // return $paymentPercentage;



    // Then, join this subquery with your main query
    // First, get the total counts in a subquery
    $totalCounts = DB::table('za_course_chapter')
      ->select(
        DB::raw('COUNT(DISTINCT topic_id) as total_topics'),
        DB::raw('COUNT(DISTINCT session_id) as total_sessions'),
        DB::raw('COUNT(DISTINCT course_chapter_id) as total_chapters')
      )
      ->join('za_course', 'za_course_chapter.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_training.course_id', '=', 'za_course.sno')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->where('za_training.sno', $customer_id)
      ->where('za_training.course_id', $course_id)
      ->first();
    // return  $totalCounts;
    $completed_total_Counts = DB::table('za_syllabus_update')
      ->select(
        DB::raw('COUNT(DISTINCT za_syllabus_update.topic_id) as completed_total_topics'),
        DB::raw('COUNT(DISTINCT za_syllabus_update.section_id) as completed_total_sessions'),
        DB::raw('COUNT(DISTINCT za_syllabus_update.chapter_id) as completed_total_chapters')
      )
      ->join('za_training', 'za_training.course_id', '=', 'za_syllabus_update.course_id')
      ->join('za_batch', 'za_batch.sno', '=', 'za_syllabus_update.batch_id')
      ->where('za_training.customer_id', $customer_id)
      ->where('za_training.course_id', $course_id)
      ->first();


    // return $completed_total_Counts;
    // Main query
    // $customer_attend_view_print = CustomerModel::select(
    //   'za_customer.sno as customer_id',
    //   'za_training.sno as training_id',
    //   'za_training.course_id',
    //   'za_training.batch_id',
    //   'za_customer.status',
    //   'za_customer.cus_name',
    //   'za_course.sno',
    //   'za_course.course_name',
    //   'za_attendance.attendance',
    //   DB::raw('SUM(CASE WHEN za_attendance.attendance = "P" THEN 1 ELSE 0 END) as present_count'),
    //   DB::raw('SUM(CASE WHEN za_attendance.attendance = "A" THEN 1 ELSE 0 END) as absent_count'),
    //   DB::raw('SUM(CASE WHEN za_attendance.attendance = "L" THEN 1 ELSE 0 END) as leave_count'),
    //   'za_attendance.customer_id as att_cus_id',
    //   'za_attendance.att_date',
    //   'za_course_chapter.course_chapter_name',
    //   'za_course_chapter.course_chapter_id',
    //   'za_course_chapter.session_id',
    //   'za_course_chapter.topic_id',
    //   'za_course_chapter.session_name',
    //   'za_syllabus_update.percentage',
    //   DB::raw('GROUP_CONCAT(DISTINCT za_course_chapter.topic_name ORDER BY za_course_chapter.topic_id) as topic_names')
    // )
    //   ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
    //   ->leftJoin('za_course', 'za_training.course_id', '=',  'za_course.sno')
    //   ->leftJoin('za_batch', 'za_training.batch_id', '=',  'za_batch.sno')
    //   ->join('za_course_chapter', 'za_course.sno', '=', 'za_course_chapter.course_id')
    //   ->join('za_attendance', 'za_customer.sno', '=', 'za_attendance.customer_id')
    //   ->Join('za_syllabus_update', function ($join) {
    //     $join->on('za_course_chapter.topic_id', '=', 'za_syllabus_update.topic_id')
    //       ->on('za_attendance.att_date', '=', 'za_syllabus_update.date');
    //   })
    //   ->where('za_training.customer_id', $customer_id)
    //   ->where('za_training.course_id', $course_id)
    //   // ->where('za_training.batch_Id', $batch_id)
    //   ->groupBy(
    //     'za_customer.sno',
    //     'za_training.sno',
    //     'za_training.course_id',
    //     'za_training.batch_id',
    //     'za_customer.status',
    //     'za_customer.cus_name',
    //     'za_course.sno',
    //     'za_course.course_name',
    //     'za_attendance.attendance',
    //     'za_attendance.customer_id',
    //     'za_attendance.att_date',
    //     'za_course_chapter.course_chapter_name',
    //     'za_course_chapter.course_chapter_id',
    //     'za_course_chapter.session_id',
    //     'za_course_chapter.topic_id',
    //     'za_course_chapter.session_name',
    //     'za_syllabus_update.percentage'
    //   )
    //   // ->orderBy('za_syllabus_update.session_id', 'desc')
    //   // ->orderBy('za_course_chapter.sno', 'asc')
    //   ->get();


    // $unique_results_print = $customer_attend_view_print->unique('za_syllabus_update.topic_id')->values();
    // return $customer_attend_view_print;
    // return $unique_results_print;
    // dd($customer_attend_view_print);

    $topics = [];


    // Fetch unique chapters for all courses based on course_id
    $chapter_views = ManageCoursesSyllabusModel::where('course_id', $course_id)
      ->select('course_id', 'course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
      ->groupBy('course_id', 'course_chapter_id', 'course_chapter_name')
      ->get();


    // Iterate through each chapter to fetch the latest sections and topics
    foreach ($chapter_views as $chapter) {
      // Initialize array for storing sections
      $sections = [];

      // Fetch the latest sections for the current chapter across all courses
      $latest_sections = ManageCoursesSyllabusModel::where('course_id', $course_id)
        ->where('course_chapter_id', $chapter->course_chapter_id)
        ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
        ->where('status', 0)
        ->groupBy('session_id', 'session_name')
        ->get();


      // Loop through each section and fetch the latest topics for each section
      foreach ($latest_sections as $sec) {
        // Fetch the latest topics for the current section
        $latest_topics = ManageCoursesSyllabusModel::where('course_id', $course_id)
          ->where('course_chapter_id', $chapter->course_chapter_id)
          ->where('session_id', $sec->session_id)
          ->where('status', 0)
          ->select('topic_id', 'topic_name', 'topic_id', DB::raw('MAX(sno) as max_sno'))
          ->groupBy('topic_id', 'topic_name', 'topic_id')
          ->get();

        // Store the topics under the corresponding section
        $sections[$sec->session_id] = [
          'section_name' => $sec->session_name,
          'topics' => $latest_topics  // The topics for this section
        ];
      }

      // Store the sections (and associated topics) under the corresponding chapter
      $topics[$chapter->course_chapter_id] = [
        'chapter_name' => $chapter->course_chapter_name,
        'course_id' => $chapter->course_id,
        'sections' => $sections  // The sections and their topics
      ];
    }
    // return $topics;
    return view('content.customer_care.customer_indiv_course_attend_print', [
      // 'customer_print' => $customer_print,
      'customer_details_print' => $customer_details_print,
      'payment_details_print' => $payments_array_print,
      // 'unique_results_print' => $unique_results_print,
      'unique_results_print' => $topics,
      'completed_total_Counts' => $completed_total_Counts,
      // 'customer_attend_view_print' => $customer_attend_view_print,

      'totalCounts' => $totalCounts,
      'paymentPercentage' => $paymentPercentage,
    ]);
  }
  
  
  public function Course_List_JSON()
  {
      $courses = ManageCoursesModel::select(
          'za_course.course_name',
          'za_course.course_code',
          'za_course.course_days',
          'za_course.course_duration',
          'za_course.course_min_price',
          'za_course.course_max_price',
          'za_course_type.course_type_name'

      )
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->where('za_course.status', '!=', 2)
      ->orderBy('za_course_type.course_type_name', 'desc')
      ->get();

      return response()->json($courses);
  }

    public function getCourseTypes()
  {
      $courseTypes = DB::table('za_course_type')
          ->select('sno', 'course_type_name')
          ->where('status','=',0)
          ->orderBy('course_type_name', 'desc')
          ->get();

      return response()->json($courseTypes);
  }
  
  // public function CourseSummaryPrint($id = '')
  // {

  //   // return $id;
  //   $helper = new \App\Helpers\Helpers();
  //   $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

  //   $customer_print = CustomerModel::select(
  //     'za_customer.sno',
  //     'za_customer.cus_name',
  //     'za_customer.customer_id',
  //     'za_customer.cus_gender',
  //     'za_customer.cus_dob',
  //     'za_customer.cus_pic',
  //     'za_customer.cus_mobile',
  //     'za_customer.cus_alternate_mobile',
  //     'za_customer.cus_email_id',
  //     'za_customer.contact_person',
  //     'za_customer.c_p_mobile',
  //     'za_customer.cus_marital_status',
  //     'za_countries.name as country_name',
  //     'za_states.name as state_name',
  //     'za_cities.name as city_name',
  //     'za_customer.address',
  //     'za_customer.door_no',
  //     'za_customer.pincode',
  //     'za_customer.customer_ref',
  //     'za_customer.final_fee',
  //     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]")) as course_id'),
  //     'za_customer.free_shd_count',
  //     'za_customer.request_count',
  //     'za_customer.reason_request',
  //     'za_customer.free_status',
  //     'za_customer.reason_reject',
  //     'za_customer.created_by',
  //     'za_customer.batch_id',
  //     'za_lead.sno as lead_id',
  //     'za_lead.qualification',
  //     'za_lead_type.lead_type_name',
  //     'za_batch.batch_name',
  //     'za_batch.start_date',
  //     'za_batch.end_date',
  //     'za_course_type.course_type_name',
  //     'za_course.course_name',
  //     'za_course.course_duration',
  //     'za_course.course_days',
  //     'za_slot.slot_name',
  //     'za_slot.start_time',
  //     'za_slot.end_time',
  //     'za_slot.slot_type_days',
  //     'za_slot_type.slot_type_name',
  //     'za_staff.staff_name',
  //     'za_class_room.class_room_name',
  //     'za_branch.min_prd_cost',
  //     'za_customer.status',

  //     DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
  //     DB::raw('MAX(za_payment.total_amount) as total_amount') // Assuming you want the maximum total_amount for each customer
  //   )
  //     ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
  //     ->leftJoin('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
  //     ->leftJoin('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
  //     ->leftJoin('za_lead_type', 'za_lead.lead_type_id', '=', 'za_lead_type.sno')
  //     ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
  //     ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
  //     ->leftJoin('za_slot_type', 'za_slot.slot_type_id', '=', 'za_slot_type.sno')
  //     ->leftJoin('za_countries', 'za_customer.country', '=', 'za_countries.id')
  //     ->leftJoin('za_states', 'za_customer.state', '=', 'za_states.id')
  //     ->leftJoin('za_cities', 'za_customer.city', '=', 'za_cities.id')
  //     ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
  //     ->leftjoin('za_training', 'za_training.customer_id', '=', 'za_customer.sno')
  //     ->leftJoin('za_class_room', 'za_batch.classroom_id', '=', 'za_class_room.sno')
  //     ->leftJoin('za_staff as staff_created_by', 'za_customer.created_by', '=', 'staff_created_by.sno')
  //     ->leftJoin('za_branch', 'staff_created_by.branch_id', '=', 'za_branch.sno')
  //     ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id') // Join with payments
  //     ->where('za_customer.sno', $decryptedValue)
  //     ->groupBy(
  //       'za_customer.sno',
  //       'za_customer.cus_name',
  //       'za_customer.customer_id',
  //       'za_customer.cus_gender',
  //       'za_customer.cus_dob',
  //       'za_customer.cus_mobile',
  //       'za_customer.cus_pic',
  //       'za_customer.cus_alternate_mobile',
  //       'za_customer.cus_email_id',
  //       'za_customer.contact_person',
  //       'za_customer.c_p_mobile',
  //       'za_customer.cus_marital_status',
  //       'za_countries.name',
  //       'za_states.name',
  //       'za_cities.name',
  //       'za_customer.address',
  //       'za_customer.door_no',
  //       'za_customer.pincode',
  //       'za_customer.final_fee',
  //       'za_customer.course_id',
  //       'za_customer.customer_ref',
  //       'za_customer.free_shd_count',
  //       'za_customer.request_count',
  //       'za_customer.free_status',
  //       'za_customer.reason_request',
  //       'za_customer.reason_reject',
  //       'za_customer.created_by',
  //       'za_customer.batch_id',
  //       'za_lead.sno',
  //       'za_lead.qualification',
  //       'za_lead_type.lead_type_name',
  //       'za_course.course_name',
  //       'za_course.course_duration',
  //       'za_course.course_days',
  //       'za_batch.batch_name',
  //       'za_batch.start_date',
  //       'za_batch.end_date',
  //       'za_course_type.course_type_name',
  //       'za_slot.slot_name',
  //       'za_slot.start_time',
  //       'za_slot.end_time',
  //       'za_slot.slot_type_days',
  //       'za_slot_type.slot_type_name',
  //       'za_staff.staff_name',
  //       'za_class_room.class_room_name',
  //       'za_branch.min_prd_cost',
  //       'za_customer.status'
  //     )
  //     ->orderBy('za_customer.sno', 'desc')
  //     ->first();


  //   // Then, join this subquery with your main query
  //   // First, get the total counts in a subquery
  //   $totalCounts = DB::table('za_course_chapter')
  //     ->select(
  //       DB::raw('COUNT(DISTINCT topic_id) as total_topics'),
  //       DB::raw('COUNT(DISTINCT session_id) as total_sessions'),
  //       DB::raw('COUNT(DISTINCT course_chapter_id) as total_chapters')
  //     )
  //     ->join('za_course', 'za_course_chapter.course_id', '=', 'za_course.sno')
  //     ->join('za_training', 'za_training.course_id', '=', 'za_course.sno')
  //     ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
  //     ->where('za_customer.sno', $decryptedValue)
  //     ->first();
  //   // return  $totalCounts;
  //   // Main query
  //   $customer_attend_view_print = CustomerModel::select(
  //     'za_customer.sno as customer_id',
  //     'za_training.sno as training_id',
  //     'za_customer.status',
  //     'za_customer.course_id',
  //     'za_customer.cus_name',
  //     'za_course.sno as course_id',
  //     'za_course.course_name',
  //     'za_attendance.attendance',
  //     DB::raw('SUM(CASE WHEN za_attendance.attendance = "P" THEN 1 ELSE 0 END) as present_count'),
  //     DB::raw('SUM(CASE WHEN za_attendance.attendance = "A" THEN 1 ELSE 0 END) as absent_count'),
  //     DB::raw('SUM(CASE WHEN za_attendance.attendance = "L" THEN 1 ELSE 0 END) as leave_count'),
  //     'za_attendance.customer_id as att_cus_id',
  //     'za_attendance.att_date',
  //     'za_course_chapter.course_chapter_name',
  //     'za_course_chapter.course_chapter_id',
  //     'za_course_chapter.session_id',
  //     'za_course_chapter.topic_id',
  //     'za_course_chapter.session_name',
  //     'za_syllabus_update.percentage',
  //     DB::raw('GROUP_CONCAT(DISTINCT za_course_chapter.topic_name ORDER BY za_course_chapter.topic_id) as topic_names')
  //   )
  //     ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
  //     ->leftJoin('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
  //     ->join('za_course_chapter', 'za_course.sno', '=', 'za_course_chapter.course_id')
  //     ->join('za_attendance', 'za_customer.sno', '=', 'za_attendance.customer_id')
  //     ->Join('za_syllabus_update', function ($join) {
  //       $join->on('za_course_chapter.course_chapter_id', '=', 'za_syllabus_update.chapter_id')
  //         ->on('za_attendance.att_date', '=', 'za_syllabus_update.date');
  //     })
  //     ->where('za_customer.sno', $decryptedValue)
  //     ->groupBy(
  //       'za_customer.sno',
  //       'za_training.sno',
  //       'za_customer.status',
  //       'za_customer.course_id',
  //       'za_customer.cus_name',
  //       'za_course.sno',
  //       'za_course.course_name',
  //       'za_attendance.attendance',
  //       'za_attendance.customer_id',
  //       'za_attendance.att_date',
  //       'za_course_chapter.course_chapter_name',
  //       'za_course_chapter.course_chapter_id',
  //       'za_course_chapter.session_id',
  //       'za_course_chapter.topic_id',
  //       'za_course_chapter.session_name',
  //       'za_syllabus_update.percentage'
  //     )
  //     ->orderBy('za_syllabus_update.section_id', 'desc')
  //     ->orderBy('za_course_chapter.sno', 'asc')
  //     ->get();
  //   $unique_results_print = $customer_attend_view_print->unique('za_syllabus_update.topic_id')->values();
  //   // return $customer_attend_view_print;
  //   // return $unique_results_print;
  //   // dd($customer_attend_view_print);

  //   $payments_array_print = PaymentModel::where('customer_id', $decryptedValue)->where('status', 0)->get();

  //   // dd($payments_array_print);
  //   // dd($customer_print);
  //   return view('content.customer_care.customer_indiv_course_attend_print', [
  //     'customer_print' => $customer_print,
  //     'payment_details_print' => $payments_array_print,
  //     'unique_results_print' => $unique_results_print,
  //     'totalCounts' => $totalCounts,
  //   ]);
  // }
}