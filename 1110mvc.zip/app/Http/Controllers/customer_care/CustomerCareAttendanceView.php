<?php



namespace App\Http\Controllers\customer_care;

use App\Http\Controllers\Controller;
use App\Models\CertificateChecklistModel;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use function Laravel\Prompts\select;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CustomerCareAttendanceView extends Controller
{
    public function customer_attendance_view($id = '')
    {
        // return $id;
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        $cus_course_id = CustomerModel::where('sno', $decryptedValue)
            ->pluck('course_id') // Use pluck to get an array of values
            ->first(); // Get the first value directly

        $courseIds = json_decode($cus_course_id);
        // return $courseIds;


        $customer = CustomerModel::select(
            'za_customer.sno',
            'za_customer.cus_name',
            'za_customer.cus_mobile',
            'za_customer.cus_gender',
            'za_training.customer_id',
            'za_training.course_id',
            'za_training.batch_id',
            'za_course.sno as course_sno',
            'za_batch.sno AS batch_sno',
            'za_batch.batch_name',
            'za_batch.start_date',
            'za_batch.end_date',
            'za_course.course_version',
            'za_course.course_name',
            'za_course.course_id',
            'za_course_type.course_type_name',
            'za_course_category.course_category_name',
            'za_course_subcategory.course_subcategory_name'
        )
            ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
            ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
            ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
            ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
            ->join('za_course_category', 'za_course.course_category_id', '=', 'za_course_category.sno')
            ->join('za_course_subcategory', 'za_course.course_subcategory_id', '=', 'za_course_subcategory.sno')
            ->where('za_customer.sno', $decryptedValue)
            ->whereIn('za_training.course_id', $courseIds)
            ->get();
        // return $customer;

        // // Decode the course_ids from the JSON string
        // $courseIds = json_decode($cus_course_id);
        // return $courseIds;

        // Initialize an array to store the topics
        $topics = [];

        // Fetch unique chapters for all courses based on course_id
        $chapter_views = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
            ->select('course_id', 'course_chapter_id', 'course_chapter_name', DB::raw('MAX(sno) as max_sno'))
            ->groupBy('course_id', 'course_chapter_id', 'course_chapter_name')
            ->get();

        // Iterate through each chapter to fetch the latest sections and topics
        foreach ($chapter_views as $chapter) {
            // Initialize array for storing sections
            $sections = [];

            // Fetch the latest sections for the current chapter across all courses
            $latest_sections = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
                ->where('course_chapter_id', $chapter->course_chapter_id)
                ->select('session_id', 'session_name', DB::raw('MAX(sno) as max_sno'))
                ->where('status', 0)
                ->groupBy('session_id', 'session_name')
                ->get();

            // Loop through each section and fetch the latest topics for each section
            foreach ($latest_sections as $sec) {
                // Fetch the latest topics for the current section
                $latest_topics = ManageCoursesSyllabusModel::whereIn('course_id', $courseIds)
                    ->where('course_chapter_id', $chapter->course_chapter_id)
                    ->where('session_id', $sec->session_id)
                    ->where('status', 0)
                    ->select('topic_id', 'topic_name', 'topic_id', DB::raw('MAX(sno) as max_sno'))
                    ->groupBy('topic_id', 'topic_name', 'topic_id')
                    ->get();

                // Store the topics under the corresponding section
                $sections[$sec->session_id] = [
                    'section_name' => $sec->session_name,
                    'topics' => $latest_topics  // The topics for this section
                ];
            }

            // Store the sections (and associated topics) under the corresponding chapter
            $topics[$chapter->course_chapter_id] = [
                'chapter_name' => $chapter->course_chapter_name,
                'course_id' => $chapter->course_id,
                'sections' => $sections  // The sections and their topics
            ];
        }

        // Return the final result containing all chapters, sections, and topics
        // return $topics;
        // $filteredData = collect($customer)->filter(function ($value) use ($course_id) {
        //     return $value->course_id == $course_id;
        // });

        //student attendance



        return view('content.customer_care.customer_attendance_view', [
            'summary_list' => $topics,
            'customer' => $customer,
            // 'customer_attend_view' => $customer_attend_view,

        ]);
    }
}