<?php

namespace App\Http\Controllers\Payment;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\CustomerModel;
use App\Models\GeneralSettingsModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\PaymentOldModel;
use App\Models\SlotModel;
use App\Models\SlotTypeModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TransactionModel;
use App\Models\LedgerModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageHarvesting extends Controller
{
 public function Index(Request $request, $month = null, $year = null ,$day = null)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year  = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));
    $day = $request->input('day', $day ?? null); // optional
    $balance_payment = $request->get('balance_payment', $balance_payment ?? '');
    
    if($month.$year == date('mY') || $year > date('Y')){
      $month_chk = 0;
    }else{
      $month_chk = 1;
    }
     
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.customer_id');
    // paid amount
    $sumPaidAmount = DB::table('za_payment')
      ->where('za_payment.status', 1)
      ->sum('za_payment.paidAmount');
    $customer_fill = $request->cus_fill ?? '';

     $firstIds = DB::table('za_payment')
                ->where('za_payment.branch_id', $branch_id)
                ->select(DB::raw('MIN(za_payment.sno) as first_id'))
                ->groupBy('za_payment.payment_id')
                ->orderBy('first_id', 'asc')
                ->pluck('first_id');

    $previousCount=0;

    $previous_unpaid_Data = PaymentModel::join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
    ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    ->where('za_payment.branch_id', $branch_id)
    ->whereNotIn('za_payment.sno',$firstIds)
    ->where('za_payment.status', 0)
    ->whereNotIn('za_customer.sno', $drop_ids)
    ->where('za_payment.paidAmount', 0)
    ->where(function($query) use ($year, $month) {
          $query->whereYear('za_payment.nextPayDate', '<', $year)
                ->orWhere(function($query2) use ($year, $month) {
                    $query2->whereYear('za_payment.nextPayDate', '=', $year)
                          ->whereMonth('za_payment.nextPayDate', '<', $month);
                });
      })
      
    // ->whereYear('za_payment.initialPayDate', $year)
    // ->whereYear('za_payment.nextPayDate', '<', $year) // Before the year 2025
    // ->orWhere(function ($query) use ($month, $year,$firstIds,$branch_id,$drop_ids) {
    //     $query->whereYear('za_payment.nextPayDate', '=', $year) // Year = 2025
    //           ->where('za_payment.status', 0)
    //           ->where('za_payment.paidAmount', 0)
    //           ->where('za_payment.branch_id', $branch_id)
    //           ->whereNotIn('za_customer.sno', $drop_ids)
    //           ->whereNotIn('za_payment.sno',$firstIds)
    //           ->whereMonth('za_payment.nextPayDate', '<', $month); // Before month 11 (October or earlier)
    // })
    ->select(
        'za_payment.payment_id',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.status AS payment_status',
        'za_payment.amount AS payment_amount',
        'za_payment.paidAmount AS payment_paid_amt',
        'za_payment.gst_amount AS payment_gst_amount',
        'za_payment.balanceFee',
        'za_customer.sno as customer_sno',
        'za_customer.customer_id',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_course.course_name',
        'za_course.sno as course_sno',
        'za_training.training_id',
        \DB::raw('MAX(za_training.overall_fees) as overall_fees'),
        \DB::raw('MAX(za_training.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(za_training.paid_amount) AS tot_pay_amt'),
        \DB::raw('MAX(za_training.paid_gst) AS tot_pay_gst_amt'),
        \DB::raw('MAX(za_training.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(za_training.balance_gst) AS tot_bal_gst_amt'),
        \DB::raw("'1' AS is_previous"),
        )->whereNotIn('za_customer.sno', $drop_ids)
        ->whereNotIn('za_training.status', [2])
        ->groupBy('za_payment.payment_id', 'za_customer.sno', 'za_customer.customer_id','za_payment.initialPayDate', 'za_customer.cus_name', 
              'za_customer.cus_pic', 'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_customer.doj', 
              'za_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 'za_training.training_id',
              'za_payment.nextPayDate', 'za_payment.status', 'za_payment.amount', 'za_payment.paidAmount', 
              'za_payment.gst_amount', 'za_payment.balanceFee');

    $previousCount=count($previous_unpaid_Data->get());

   $HistoryPayment = PaymentModel::join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
    ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    ->where('za_payment.branch_id', $branch_id)
    ->whereNotIn('za_payment.sno',$firstIds)
    ->whereYear('za_payment.initialPayDate', $year)
    ->whereMonth('za_payment.initialPayDate', $month)
    ->select(
        'za_payment.payment_id',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.status AS payment_status',
        'za_payment.amount AS payment_amount',
        'za_payment.paidAmount AS payment_paid_amt',
        'za_payment.gst_amount AS payment_gst_amount',
        'za_payment.balanceFee',
        'za_customer.sno as customer_sno',
        'za_customer.customer_id',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_course.course_name',
        'za_course.sno as course_sno',
        'za_training.training_id',
        \DB::raw('MAX(za_training.overall_fees) as overall_fees'),
        \DB::raw('MAX(za_training.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(za_training.paid_amount) AS tot_pay_amt'),
        \DB::raw('MAX(za_training.paid_gst) AS tot_pay_gst_amt'),
        \DB::raw('MAX(za_training.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(za_training.balance_gst) AS tot_bal_gst_amt'),
          \DB::raw("'0' AS is_previous")
        )->whereNotIn('za_customer.sno', $drop_ids)
        ->whereNotIn('za_training.status', [2])
        ->groupBy('za_payment.payment_id', 'za_customer.sno', 'za_customer.customer_id','za_payment.initialPayDate', 'za_customer.cus_name', 
              'za_customer.cus_pic', 'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_customer.doj', 
              'za_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 'za_training.training_id',
              'za_payment.nextPayDate', 'za_payment.status', 'za_payment.amount', 'za_payment.paidAmount', 
              'za_payment.gst_amount', 'za_payment.balanceFee');
              
        if (!empty($customer_fill)) {
              $HistoryPayment->where(function ($query) use ($customer_fill) {
                  $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment
        //   ->whereDate('za_payment.nextPayDate', '<', $currentDate)
                        ->where('za_payment.status',0)->where('za_payment.amount','>', 0) ;
        }

         if($request->pending == 1){
              $finalData=$previous_unpaid_Data->get();
          }else{
            $previous = $previous_unpaid_Data->getQuery(); 
            $history  = $HistoryPayment->getQuery(); 
            $combined = $previous->unionAll($history);
          $finalData = DB::table(DB::raw("({$combined->toSql()}) as combined"))
              ->mergeBindings($combined)
              ->orderBy('is_previous', 'desc')
              ->orderBy('nextPayDate', 'asc')
              ->get();
          }
      // Assign paginated result
      // $HistoryPayment = $HistoryPayment->orderBy('za_payment.nextPayDate', 'ASC')->paginate($perpage);
      
      // return $finalData;

    if($finalData->isNotEmpty()){
      foreach ($finalData as $final) {
        $training = DB::table('za_training')->where('branch_id', $branch_id)->where('customer_id', $final->customer_sno)->first();
        $batch = BatchModel::where('sno', $training->batch_id)->first();
        $final->outstanding_batch_name = isset($batch->batch_name) && !empty($batch->batch_name) ? $batch->batch_name : null;
      }
    }

    $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->orderBy('za_payment.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->where('za_payment.status', 0)
      ->whereDate('za_payment.nextPayDate', $currentDate)->count();



    // common mini dashboard
       // Current Month
    $outstandingAmountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_payment.status', '!=',2) // not paid amount
    ->where('za_customer.status', 0)
    ->where('za_payment.amount','>', 0) 
    ->whereYear('za_payment.nextPayDate', $year)
    ->whereMonth('za_payment.nextPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.amount');
    
     $outstandingAmountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->where('za_old_payments.status', '!=',2) // not paid amount
    ->where('za_old_customer.status', 0)
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.amount');
    
     $totalPaidAmountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_payment.status', 1) // paid amount
    ->where('za_customer.status', 0)
    ->where('za_payment.amount','>', 0) 
    ->whereYear('za_payment.initialPayDate', $year)
    ->whereMonth('za_payment.initialPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.paidAmount');
    
    $totalPaidAmountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->where('za_old_payments.status', '!=',2) // paid amount
    ->whereIn('za_old_customer.status', [1,4])
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.created_at', $year)
    ->whereMonth('za_old_payments.created_at', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.paidAmount');
    
     $totalscheduleamountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->whereNotIn('za_payment.status', [2])
    ->where('za_payment.amount','>', 0) 
    ->where('za_customer.status', 0)
    ->whereYear('za_payment.nextPayDate', $year)
    ->whereMonth('za_payment.nextPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.amount');
    
    
    $totalscheduleamountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->whereNotIn('za_old_payments.status', [1, 2])
    ->where('za_old_customer.status', 0)
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.amount');
    
     $notpaidamount = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_payment.status', 0) // paid amount
            ->where('za_customer.status', 0)
            ->where('za_payment.amount','>', 0) 
            ->whereYear('za_payment.nextPayDate', $year)
            ->whereMonth('za_payment.nextPayDate', $month)
            ->where('za_payment.branch_id', $branch_id)
            ->sum('za_payment.amount');
            
    //  return $totalPaidAmountold;
    $totalPaidAmount = $totalPaidAmountnew + $totalPaidAmountold;
    // $totalscheduleamount = $totalscheduleamountnew + $totalscheduleamountold;
    $totalscheduleamount = $notpaidamount + $totalPaidAmount;
    $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
    // Calculate Total Amount
    $totalAmount = $notpaidamount + $totalPaidAmount;
    
    // Calculate Outstanding Percentage (Handle division by zero)
    $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;
    
    
    
    
    $HistoryPayment2 = PaymentModel::join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
    ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    ->where('za_payment.branch_id', $branch_id)
    ->whereNotIn('za_payment.sno',$firstIds)
    ->whereYear('za_payment.initialPayDate', $year)
    ->whereMonth('za_payment.initialPayDate', $month)
    ->select(
        'za_payment.payment_id',
        'za_payment.nextPayDate',
        'za_payment.initialPayDate',
        'za_payment.status AS payment_status',
        'za_payment.amount AS payment_amount',
        'za_payment.paidAmount AS payment_paid_amt',
        'za_payment.gst_amount AS payment_gst_amount',
        'za_payment.balanceFee',
        'za_customer.sno as customer_sno',
        'za_customer.customer_id',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.doj',
        'za_customer.cus_gender',
        'za_course.course_name',
        'za_course.sno as course_sno',
        'za_training.training_id',
        \DB::raw('MAX(za_training.overall_fees) as overall_fees'),
        \DB::raw('MAX(za_training.gst_amount) AS overall_gst_fees'),
        \DB::raw('MAX(za_training.paid_amount) AS tot_pay_amt'),
        \DB::raw('MAX(za_training.paid_gst) AS tot_pay_gst_amt'),
        \DB::raw('MAX(za_training.balance_amount) AS tot_bal_amt'),
        \DB::raw('MAX(za_training.balance_gst) AS tot_bal_gst_amt')
    )->whereNotIn('za_payment.payment_id', $drop_ids)
    ->groupBy('za_payment.payment_id', 'za_customer.sno', 'za_customer.customer_id','za_payment.initialPayDate', 'za_customer.cus_name', 
              'za_customer.cus_pic', 'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_customer.doj', 
              'za_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 'za_training.training_id',
              'za_payment.nextPayDate', 'za_payment.status', 'za_payment.amount', 'za_payment.paidAmount', 
              'za_payment.gst_amount', 'za_payment.balanceFee');
              
        if (!empty($customer_fill)) {
              $HistoryPayment2->where(function ($query) use ($customer_fill) {
                  $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment2
        //   ->whereDate('za_payment.nextPayDate', '<', $currentDate)
                        ->where('za_payment.status',0)->where('za_payment.amount','>', 0) ;
        }
      // Assign paginated result
      $HistoryPayment2 = $HistoryPayment2->orderBy('za_payment.nextPayDate', 'ASC')->get();
      
    //   return count($HistoryPayment2);
    $total_paid = 0;
    $total_gst = 0;
    foreach ($HistoryPayment2 as $i=> $pay){
        if($pay->payment_status == 0){
            $total_paid += $pay->payment_amount;
            $total_gst += $pay->payment_gst_amount;
        }else{
            $total_paid += $pay->payment_paid_amt;
            $total_gst += $pay->payment_gst_amount;
        }
    }
    //  return $total_gst;
      
    
    // return $outstandingAmount;
    // Return the view with the data and total count
    return view('content.payment.harvesting_sheet', [
      'perpage' => $perpage,
      'month_chk' =>$month_chk,
      'month' =>$month,
      'year' =>$year,
      'previousCount' => $previousCount,
      'HistoryPayment' => $finalData,
      'outstandingAmount' => $outstandingAmount,
      'outstandingPercentage' => $outstandingPercentage,
      'totalPaidAmount' => $totalPaidAmount,
      'totalscheduleamount' => $totalscheduleamount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'cus_fill' => $customer_fill,
      'total_paid' => $total_paid,
      'total_gst' => $total_gst,
      'gstPercentage' => $gstPercentage,
    ])->with('filter_on', false);
  }
  public function oldHarvesting(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $year  = $request->get('year', $year ?? date('Y'));
    $month = $request->get('month', $month ?? date('m'));
    $balance_payment = $request->get('balance_payment', $balance_payment ?? '');
    
    if($month.$year == date('mY') || $year > date('Y')){
      $month_chk = 0;
    }else{
      $month_chk = 1;
    }
     
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.payment_id');
    // paid amount
    $sumPaidAmount = DB::table('za_old_payments')
      ->where('za_old_payments.status', 1)
      ->sum('za_old_payments.paidAmount');
    $customer_fill = $request->cus_fill ?? '';

   $HistoryPayment = PaymentOldModel::join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
    ->where('za_old_payments.branch_id', $branch_id)
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->select(
        'za_old_payments.old_payment_id',
        'za_old_payments.schedule_date AS nextPayDate',
        'za_old_payments.status AS payment_status',
        'za_old_payments.amount AS payment_amount',
        'za_old_payments.paidAmount AS payment_paid_amt',
        'za_old_payments.gst_amount AS payment_gst_amount',
        'za_old_payments.balanceFee',
        'za_old_customer.sno as customer_sno',
        'za_old_customer.customer_id',
        'za_old_customer.cus_name',
        'za_old_customer.cus_mobile',
        'za_old_customer.cus_gender',
        'za_course.course_name',
        'za_course.sno as course_sno'
    )->whereNotIn('za_old_payments.old_payment_id', $drop_ids)
    ->groupBy('za_old_payments.old_payment_id', 'za_old_customer.sno', 'za_old_customer.customer_id','za_old_payments.schedule_date', 'za_old_customer.cus_name', 
               'za_old_customer.cus_mobile','za_old_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 
              'za_old_payments.schedule_date', 'za_old_payments.status', 'za_old_payments.amount', 'za_old_payments.paidAmount', 
              'za_old_payments.gst_amount', 'za_old_payments.balanceFee');
              
        if (!empty($customer_fill)) {
              $HistoryPayment->where(function ($query) use ($customer_fill) {
                  $query->where('za_old_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_old_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_old_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment
        //   ->whereDate('za_old_payments.nextPayDate', '<', $currentDate)
                        ->where('za_old_payments.status',0)->where('za_old_payments.amount','>', 0) ;
        }
      // Assign paginated result
      $HistoryPayment = $HistoryPayment->orderBy('za_old_payments.schedule_date', 'ASC')->paginate($perpage);
      
    //   return $HistoryPayment;

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.payment_id');

    $OutstandingPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->where('za_old_payments.status', 0)
      ->where('za_old_customer.status', 0)
      ->whereNotIn('za_old_payments.old_payment_id', $drop_ids)
      ->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
      ->orderBy('za_old_payments.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
      ->where('za_old_payments.status', 0)
      ->whereDate('za_old_payments.schedule_date', $currentDate)->count();
      /// mini dashboard common


       // Current Month
    $outstandingAmountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_payment.status', '!=',2) // not paid amount
    ->where('za_customer.status', 0)
    ->where('za_payment.amount','>', 0) 
    ->whereYear('za_payment.nextPayDate', $year)
    ->whereMonth('za_payment.nextPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.amount');
    
     $outstandingAmountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->where('za_old_payments.status', '!=',2) // not paid amount
    ->where('za_old_customer.status', 0)
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.amount');
    
     $totalPaidAmountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_payment.status', 1) // paid amount
    ->where('za_customer.status', 0)
    ->where('za_payment.amount','>', 0) 
    ->whereYear('za_payment.initialPayDate', $year)
    ->whereMonth('za_payment.initialPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.paidAmount');
    
    $totalPaidAmountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->where('za_old_payments.status', '!=',2) // not  paid amount
    ->where('za_old_customer.status', 0)
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.paidAmount');
    
     $totalscheduleamountnew = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->where('za_customer.branch_id', $branch_id)
    ->where('za_payment.status', '!=',2) // not paid amount
    ->where('za_payment.amount','>', 0) 
    ->where('za_customer.status', 0)
    ->whereYear('za_payment.nextPayDate', $year)
    ->whereMonth('za_payment.nextPayDate', $month)
    ->where('za_payment.branch_id', $branch_id)
    ->sum('za_payment.amount');
    
    
    $totalscheduleamountold = DB::table('za_old_payments')
    ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->where('za_old_customer.branch_id', $branch_id)
    ->where('za_old_payments.status', '!=',2) // not paid amount
    ->where('za_old_customer.status', 0)
    ->where('za_old_payments.amount','>', 0) 
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->where('za_old_payments.branch_id', $branch_id)
    ->sum('za_old_payments.amount');
    $notpaidamount = DB::table('za_payment')
            ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
            ->where('za_customer.branch_id', $branch_id)
            ->where('za_payment.status', 0) // paid amount
            ->where('za_customer.status', 0)
            ->where('za_payment.amount','>', 0) 
            ->whereYear('za_payment.nextPayDate', $year)
            ->whereMonth('za_payment.nextPayDate', $month)
            ->where('za_payment.branch_id', $branch_id)
            ->sum('za_payment.amount');
    $totalPaidAmount = $totalPaidAmountnew + $totalPaidAmountold;
    $totalscheduleamount = $notpaidamount + $totalPaidAmount;
    // $outstandingAmount =  $outstandingAmountnew - $totalPaidAmount;
    $outstandingAmount =  $totalscheduleamount - $totalPaidAmount;
    // Calculate Total Amount
    // $totalAmount = $outstandingAmount + $totalPaidAmount;
      $totalAmount = $notpaidamount + $totalPaidAmount;
    // Calculate Outstanding Percentage (Handle division by zero)
    $outstandingPercentage = ($totalAmount > 0) ? ($outstandingAmount / $totalAmount) * 100 : 0;
    
     $HistoryPayment2 = PaymentOldModel::join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
    ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
    ->where('za_old_payments.branch_id', $branch_id)
    ->whereYear('za_old_payments.schedule_date', $year)
    ->whereMonth('za_old_payments.schedule_date', $month)
    ->select(
        'za_old_payments.old_payment_id',
        'za_old_payments.schedule_date AS nextPayDate',
        'za_old_payments.status AS payment_status',
        'za_old_payments.amount AS payment_amount',
        'za_old_payments.paidAmount AS payment_paid_amt',
        'za_old_payments.gst_amount AS payment_gst_amount',
        'za_old_payments.balanceFee',
        'za_old_customer.sno as customer_sno',
        'za_old_customer.customer_id',
        'za_old_customer.cus_name',
        'za_old_customer.cus_mobile',
        'za_old_customer.cus_gender',
        'za_course.course_name',
        'za_course.sno as course_sno'
    )->whereNotIn('za_old_payments.old_payment_id', $drop_ids)
    ->groupBy('za_old_payments.old_payment_id', 'za_old_customer.sno', 'za_old_customer.customer_id','za_old_payments.schedule_date', 'za_old_customer.cus_name', 
               'za_old_customer.cus_mobile','za_old_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 
              'za_old_payments.schedule_date', 'za_old_payments.status', 'za_old_payments.amount', 'za_old_payments.paidAmount', 
              'za_old_payments.gst_amount', 'za_old_payments.balanceFee');
              
        if (!empty($customer_fill)) {
              $HistoryPayment2->where(function ($query) use ($customer_fill) {
                  $query->where('za_old_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_old_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                      ->orWhere('za_old_customer.customer_id', 'LIKE', "%{$customer_fill}%");
              });
        }
      
        if (!empty($balance_payment)) {
          $HistoryPayment2
        //   ->whereDate('za_old_payments.nextPayDate', '<', $currentDate)
                        ->where('za_old_payments.status',0)->where('za_old_payments.amount','>', 0) ;
        }
      // Assign paginated result
      $HistoryPayment2 = $HistoryPayment2->orderBy('za_old_payments.schedule_date', 'ASC')->get();
      
      //   return count($HistoryPayment2);
        $total_paid = 0;
        $total_gst = 0;
        foreach ($HistoryPayment2 as $i=> $pay){
            if($pay->payment_status == 0){
                $total_paid += $pay->payment_amount;
                $total_gst += $pay->payment_gst_amount;
            }else{
                $total_paid += $pay->payment_paid_amt;
                $total_gst += $pay->payment_gst_amount;
            }
        }
    
    // return $outstandingAmount;
    // Return the view with the data and total count
    return view('content.payment.old_harvesting_sheet', [
      'perpage' => $perpage,
      'month_chk' =>$month_chk,
      'HistoryPayment' => $HistoryPayment,
      'outstandingAmount' => $outstandingAmount,
      'outstandingPercentage' => $outstandingPercentage,
      'totalPaidAmount' => $totalPaidAmount,
      'totalscheduleamount' => $totalscheduleamount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'gstPercentage' => $gstPercentage,
      'total_paid' => $total_paid,
      'total_gst' => $total_gst,
    ])->with('filter_on', false);
  }
  
//   public function PaymentRemainder(Request $request)
//   {
//       $branch_id = $request->user()->branch_id;
//       $page = $request->input('page', 1);
//       $perpage = (int) $request->input('sorting_filter', 25);
//       $offset = ($page - 1) * $perpage;
  
//       // Get the selected filter date
//       $payRemFill = $request->input('pay_rem_fill', 'today');
//       $currentDate = now()->toDateString(); // Get today's date in 'YYYY-MM-DD' format
  
//       // Handle the filter date
//       switch ($payRemFill) {
//           case 'next_day':
//               $filterDate = now()->addDay()->toDateString();
//               break;
//           case '3rd_day':
//               $filterDate = now()->addDays(2)->toDateString();
//               break;
//           case '4th_day':
//               $filterDate = now()->addDays(3)->toDateString();
//               break;
//           case '5th_day':
//               $filterDate = now()->addDays(4)->toDateString();
//               break;
//           case '6th_day':
//               $filterDate = now()->addDays(5)->toDateString();
//               break;
//           case '7th_day':
//               $filterDate = now()->addDays(6)->toDateString();
//               break;
//           default:
//               $filterDate = $currentDate;
//       }
  
//       // Fetch the History Payment data based on the filtered date
//       $HistoryPayment = PaymentModel::join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
//           ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
//           ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
//           ->where('za_payment.branch_id', $branch_id)
//           ->whereDate('za_payment.nextPayDate', $filterDate)  // Filter by the calculated date
//           ->select(
//               'za_customer.sno as customer_sno',
//               'za_customer.customer_id',
//               'za_customer.cus_name',
//               'za_customer.cus_pic',
//               'za_customer.cus_mobile',
//               'za_customer.cus_email_id',
//               'za_customer.doj',
//               'za_customer.cus_gender',
//               'za_course.course_name',
//               'za_course.sno as course_sno',
//               'za_training.training_id',
//               'za_training.overall_fees',
//               'za_training.gst_amount AS overall_gst_fees',
//               'za_training.paid_amount AS tot_pay_amt',        
//               'za_training.paid_gst AS tot_pay_gst_amt',
//               'za_training.balance_amount AS tot_bal_amt',
//               'za_training.balance_gst AS tot_bal_gst_amt',
//               'za_payment.balanceFee',
//               'za_payment.payment_id',
//               'za_payment.nextPayDate',
//               'za_payment.initialPayDate',
//               'za_payment.status AS payment_status',
//               'za_payment.amount AS payment_amount',
//               'za_payment.paidAmount AS payment_paid_amt',
//               'za_payment.gst_amount AS payment_gst_amount'
//           )
//           ->orderBy('za_payment.nextPayDate', 'ASC')
//           ->paginate($perpage);
  
//       // Calculate the total paid amount
//       $sumPaidAmount = DB::table('za_payment')
//           ->where('za_payment.status', 1)
//           ->sum('za_payment.paidAmount');
  
//       // Fetch dropped refund IDs
//       $drop_ids = DB::table('za_drop_refund')
//           ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
//           ->where('za_drop_refund.bh_status', 1)
//           ->pluck('za_training.payment_id');
  
//       // Count outstanding payments
//       $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
//           ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
//           ->whereNotIn('za_payment.payment_id', $drop_ids)
//           ->where('za_payment.status', 0)
//           ->where('za_customer.status', 0)
//           ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
//           ->orderBy('za_payment.sno', 'asc')->count();
  
//       // Fetch the branch details
//       $branch = BranchModel::where('sno', $branch_id)
//           ->where('status', 0)
//           ->orderBy('sno', 'desc')
//           ->first();
  
//       // Get the GST percentage from the branch
//       $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
  
//       // Count today's payments
//       $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
//           ->where('za_payment.status', 0)
//           ->whereDate('za_payment.nextPayDate', $currentDate)->count();
  
//       // Calculate the total outstanding amount for the current month
//       $outstandingAmount = DB::table('za_payment')
//           ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
//           ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
//           ->whereNotIn('za_payment.payment_id', $drop_ids)
//           ->where('za_payment.status', 0)
//           ->where('za_customer.status', 0)
//           ->where('za_payment.branch_id', $branch_id)
//           ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
//           ->sum('za_payment.amount');
  
//       // Return the view with the updated data
//       return view('content.payment.payment_remainder', [
//           'perpage' => $perpage,
//           'HistoryPayment' => $HistoryPayment,
//           'sumPaidAmount' => $sumPaidAmount,
//           'OutstandingPaymentCount' => $OutstandingPayment,
//           'TodayPaymentCount' => $TodayPayment,
//           'gstPercentage' => $gstPercentage,
//           'filterDate' => $filterDate,  // Pass the filter date to the view if needed
//       ])->with('filter_on', false);
//   }  

public function PaymentRemainder(Request $request)

  {

      $branch_id = $request->user()->branch_id;

      $page = $request->input('page', 1);

      $perpage = (int) $request->input('sorting_filter', 25);

      $offset = ($page - 1) * $perpage;

 

      // Get the selected filter date

      $payRemFill = $request->input('pay_rem_fill', 'today');

      $currentDate = now()->toDateString(); // Get today's date in 'YYYY-MM-DD' format

 

      // Handle the filter date

      switch ($payRemFill) {

          case 'next_day':

              $filterDate = now()->addDay()->toDateString();

              break;

          case '3rd_day':

              $filterDate = now()->addDays(2)->toDateString();

              break;

          case '4th_day':

              $filterDate = now()->addDays(3)->toDateString();

              break;

          case '5th_day':

              $filterDate = now()->addDays(4)->toDateString();

              break;

          case '6th_day':

              $filterDate = now()->addDays(5)->toDateString();

              break;

          case '7th_day':

              $filterDate = now()->addDays(6)->toDateString();

              break;

          default:

              $filterDate = $currentDate;

      }

       $drop_ids = DB::table('za_drop_refund')

        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')

        ->where('za_drop_refund.bh_status', 1)

        ->pluck('za_training.customer_id');

 

      $firstIds = DB::table('za_payment')

                ->where('za_payment.branch_id', $branch_id)

                ->select(DB::raw('MIN(za_payment.sno) as first_id'))

                ->groupBy('za_payment.payment_id')

                ->orderBy('first_id', 'asc')

                ->pluck('first_id');

 

      // Fetch the History Payment data based on the filtered date

      $HistoryPayment = PaymentModel::join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')

          ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')

          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')

          ->where('za_payment.branch_id', $branch_id)

          ->whereDate('za_payment.nextPayDate', $filterDate)  // Filter by the calculated date

          ->whereNotIn('za_customer.sno', $drop_ids)

          ->whereNotIn('za_payment.sno',$firstIds)

          ->select(

            'za_payment.payment_id',

            'za_payment.nextPayDate',

            'za_payment.initialPayDate',

            'za_payment.status AS payment_status',

            'za_payment.amount AS payment_amount',

            'za_payment.paidAmount AS payment_paid_amt',

            'za_payment.gst_amount AS payment_gst_amount',

            'za_payment.balanceFee',

            'za_customer.sno as customer_sno',

            'za_customer.customer_id',

            'za_customer.cus_name',

            'za_customer.cus_pic',

            'za_customer.cus_mobile',

            'za_customer.cus_email_id',

            'za_customer.doj',

            'za_customer.cus_gender',

            'za_course.course_name',

            'za_course.sno as course_sno',

            'za_training.training_id',

            \DB::raw('MAX(za_training.overall_fees) as overall_fees'),

            \DB::raw('MAX(za_training.gst_amount) AS overall_gst_fees'),

            \DB::raw('MAX(za_training.paid_amount) AS tot_pay_amt'),

            \DB::raw('MAX(za_training.paid_gst) AS tot_pay_gst_amt'),

            \DB::raw('MAX(za_training.balance_amount) AS tot_bal_amt'),

            \DB::raw('MAX(za_training.balance_gst) AS tot_bal_gst_amt'),

            )

            ->groupBy('za_payment.payment_id', 'za_customer.sno', 'za_customer.customer_id','za_payment.initialPayDate', 'za_customer.cus_name',

              'za_customer.cus_pic', 'za_customer.cus_mobile', 'za_customer.cus_email_id', 'za_customer.doj',

              'za_customer.cus_gender', 'za_course.course_name', 'za_course.sno', 'za_training.training_id',

              'za_payment.nextPayDate', 'za_payment.status', 'za_payment.amount', 'za_payment.paidAmount',

              'za_payment.gst_amount', 'za_payment.balanceFee')

          ->orderBy('za_payment.nextPayDate', 'ASC')

          ->paginate($perpage);

 

      // Calculate the total paid amount

      $sumPaidAmount = DB::table('za_payment')

          ->where('za_payment.status', 1)

          ->sum('za_payment.paidAmount');

 

      // Fetch dropped refund IDs

      $drop_ids = DB::table('za_drop_refund')

          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')

          ->where('za_drop_refund.bh_status', 1)

          ->pluck('za_training.payment_id');

 

      // Count outstanding payments

      $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)

          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')

          ->whereNotIn('za_payment.payment_id', $drop_ids)

          ->where('za_payment.status', 0)

          ->where('za_customer.status', 0)

          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)

          ->orderBy('za_payment.sno', 'asc')->count();

 

      // Fetch the branch details

      $branch = BranchModel::where('sno', $branch_id)

          ->where('status', 0)

          ->orderBy('sno', 'desc')

          ->first();

 

      // Get the GST percentage from the branch

      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

 

      // Count today's payments

      $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)

          ->where('za_payment.status', 0)

          ->whereDate('za_payment.nextPayDate', $currentDate)->count();

 

      // Calculate the total outstanding amount for the current month

      $outstandingAmount = DB::table('za_payment')

          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')

          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')

          ->whereNotIn('za_payment.payment_id', $drop_ids)

          ->where('za_payment.status', 0)

          ->where('za_customer.status', 0)

          ->where('za_payment.branch_id', $branch_id)

          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)

          ->sum('za_payment.amount');

 

      // Return the view with the updated data

      return view('content.payment.payment_remainder', [

          'perpage' => $perpage,

          'HistoryPayment' => $HistoryPayment,

          'sumPaidAmount' => $sumPaidAmount,

          'OutstandingPaymentCount' => $OutstandingPayment,

          'TodayPaymentCount' => $TodayPayment,

          'gstPercentage' => $gstPercentage,

          'filterDate' => $filterDate,  // Pass the filter date to the view if needed

      ])->with('filter_on', false);

  }



  
}