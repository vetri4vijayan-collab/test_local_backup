<?php

namespace App\Http\Controllers\Payment;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchModel;
use App\Models\BranchModel;
use App\Models\CourseTypeModel;
use App\Models\TrainingModel;
use App\Models\CustomerModel;
use App\Models\GeneralSettingsModel;
use App\Models\LeadModel;
use App\Models\ManageCoursesModel;
use App\Models\PaymentModel;
use App\Models\SlotModel;
use App\Models\OldCustomerModel;
use App\Models\PaymentOldModel;
use App\Models\SlotTypeModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TransactionModel;
use App\Models\LedgerModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class ManagePayment extends Controller
{
  public function TodayPayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_payment')
      ->where('za_payment.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      ->whereDate('za_payment.nextPayDate', $currentDate)
      ->sum('za_payment.amount');
    //   return $currentDate;

    // Retrieve data where nextPayDate is today's date and status is 0
      $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
      ->select(
          'za_payment.payment_id',
          'za_payment.sno as payment_sno',
          'za_payment.branch_id',
          'za_customer.customer_id',
          'za_customer.sno as customer_sno',
          'za_course.course_id',
          'za_payment.initialPayDate',
          'za_payment.nextPayDate',
          'za_payment.amount',
          'za_payment.paidAmount',
          'za_payment.gst_amount',
          'za_payment.balanceFee',
          'za_payment.total_amount',
          'za_payment.payment_mode_label',
          'za_payment.status as payment_status',
          'za_customer.cus_name',
          'za_customer.cus_pic',
          'za_customer.cus_mobile',
          'za_customer.cus_gender',
          'za_customer.cus_email_id',
          'za_customer.jumper_skiper',
          'za_training.training_id',
          'za_course.course_name',
          'za_course.sno as course_sno'
      )
      ->distinct('za_customer.customer_id') // Ensures unique rows
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_training.status', 0)
      ->where('za_payment.amount', '>',0)
      ->whereDate('za_payment.nextPayDate', $currentDate)
      ->orderBy('za_payment.sno', 'desc');
      $TodayPaymentCount = $TodayPayment->count();
      if ($cus_fill) {
        $TodayPayment->where(function ($customer) use ($cus_fill) {
          $customer->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
        });
      }
      $TodayPayment= $TodayPayment->paginate($perpage);

      
      // Get the total count of records
      
      $branch = BranchModel::where('sno', $branch_id)
        ->where('status', 0)
        ->orderBy('sno', 'desc')
        ->first();
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

      $drop_ids = DB::table('za_drop_refund')
        ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->where('za_drop_refund.bh_status', 1)
        ->pluck('za_training.payment_id');

      $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        // ->where('za_payment.reschedule_payment', 0)
        ->where('za_customer.status', 0)
        ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
        ->orderBy('za_payment.sno', 'asc')->count();
        
      $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
      
      $outstandingAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->sum('za_payment.amount');
      // return $TodayPayment;
      // Return the view with the data and total count
      return view('content.payment.today_payment', [
        'perpage' => $perpage,
        'TodayPayment' => $TodayPayment,
        'cus_fill' => $cus_fill,
        'sumScheduleAmount' => $sumScheduleAmount,
        'outstandingAmount' => $outstandingAmount,
        'OutstandingPaymentCount' => $OutstandingPayment,
        'TodayPaymentCount' => $TodayPaymentCount,
        'gstPercentage' => $gstPercentage,
        'genaral_settings' => $genaral_settings,
      ])->with('filter_on', false);
  }
  public function Payment_reschedule(Request $request)
  {
    $branch_id = $request->user()->branch_id; // This line is unused, consider removing if not needed.
    $resch_date = date('Y-m-d', strtotime($request->max_reschedule_date)); // Corrected date format.

    $get_payment = PaymentModel::where('sno', $request->cus_payment_sno)->first();

    if ($get_payment) {
      // Update the next payment date
      $get_payment->nextPayDate = $resch_date;
      $get_payment->reschedule_payment = ($get_payment->reschedule_payment ?? 0) + 1;
      $get_payment->save();

      // Update the customer record
      $get_customer = CustomerModel::where('sno', $get_payment->customer_id)->first();
      if ($get_customer) {
        // Correctly increment the jumper_skiper count
        $get_customer->jumper_skiper = ($get_customer->jumper_skiper ?? 0) + 1;
        $get_customer->save();
      }
    }
    if ($get_customer) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Payment Reschduled Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Reschdule the Payment!'
      ]);
    }
    return redirect('/today_payment');
  }
  public function Payment_reschedule_again(Request $request)
  {
    $branch_id = $request->user()->branch_id; // This line is unused, consider removing if not needed.
    $resch_date = date('Y-m-d', strtotime($request->max_reschedule_date)); // Corrected date format.

    $get_payment = PaymentModel::where('sno', $request->cus_payment_sno)->first();

    if ($get_payment) {
      // Update the next payment date
      $get_payment->nextPayDate = $resch_date;
      $get_payment->reschedule_payment = ($get_payment->reschedule_payment ?? 0) + 1;
      $get_payment->save();

      // Update the customer record
      $get_customer = CustomerModel::where('sno', $get_payment->customer_id)->first();
      if ($get_customer) {
        // Correctly increment the jumper_skiper count
        $get_customer->jumper_skiper = ($get_customer->jumper_skiper ?? 0) + 1;
        $get_customer->save();
      }
    }
    if ($get_customer) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Payment Reschduled Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Reschdule the Payment!'
      ]);
    }
    return redirect('/reschedule_payment');
  }
  public function OutstandingPayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 100);
    $offset = ($page - 1) * $perpage;

    // $drop_ids = DB::table('za_drop_refund')
    //   ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
    //   ->where('za_drop_refund.bh_status', 1)
    //   ->pluck('za_training.payment_id');
      $drop_ids = DB::table('za_drop_refund')
            ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
            ->where('za_drop_refund.bh_status', 1)
            ->where('za_drop_refund.branch_id', $branch_id)
            ->pluck('za_training.customer_id');

    // Get the current date
    $currentDate = now()->subDay()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->whereNotIn('za_payment.customer_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)->where('za_payment.branch_id', $branch_id)->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->sum('za_payment.amount');
    
    $sumBalanceFee = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->whereNotIn('za_payment.customer_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)->where('za_payment.branch_id', $branch_id)->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->sum('za_payment.balanceFee');
      
    $currentMonthStart = now()->startOfMonth();
    $currentMonthEnd = now()->endOfMonth();
    $nextMonthStart = now()->addMonth()->startOfMonth();
    $nextMonthEnd = now()->addMonth()->endOfMonth();
    $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();
    
    // Current Month
    $currentMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$currentMonthStart, $currentMonthEnd])
        ->sum('za_payment.amount');
    
    // Next Month
    $nextMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$nextMonthStart, $nextMonthEnd])
        ->sum('za_payment.amount');
    
    // Greater than 3 Months
    $greaterThanThreeMonthsAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.customer_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->where('za_payment.nextPayDate', '>=', $threeMonthsLaterStart)
        ->sum('za_payment.amount');
    //   $OutstandingPaymentss = DB::table('za_payment')
    //         ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    //         ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    //         ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
    //         ->where('za_payment.branch_id', $branch_id)
    //         ->whereNotIn('za_payment.customer_id', $drop_ids)
    //         ->where('za_payment.status', 0)
    //         ->where('za_payment.amount', '>', 0)
    //         ->where('za_customer.status', 0)
    //         ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
    //         ->select('za_training.training_id')
    //         ->groupBy('za_training.training_id')
    //         ->orderBy('za_payment.nextPayDate', 'DESC')
    //         ->get();

        $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->leftJoin('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->leftJoin('za_batch', 'za_training.batch_id', '=', 'za_batch.sno')
        ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
        ->select(
            'za_training.training_id',
            \DB::raw('MAX(za_payment.payment_id) AS payment_id'),
            \DB::raw('MAX(za_training.sno) AS tran_sno'),
            \DB::raw('MAX(za_training.batch_id) AS batch_id'),
            \DB::raw('MAX(za_payment.sno) AS payment_sno'),
            \DB::raw('MAX(za_payment.branch_id) AS branch_id'),
            \DB::raw('MAX(za_customer.customer_id) AS customer_id'),
            \DB::raw('MAX(za_customer.sno) AS customer_sno'),
            \DB::raw('MAX(za_course.course_id) AS course_id'),
            \DB::raw('MAX(za_payment.initialPayDate) AS initialPayDate'),
            \DB::raw('MAX(za_payment.nextPayDate) AS nextPayDate'),
            \DB::raw('MAX(za_payment.amount) AS amount'),
            \DB::raw('MAX(za_payment.paidAmount) AS paidAmount'),
            \DB::raw('MAX(za_payment.gst_amount) AS gst_amount'),
            \DB::raw('MAX(za_payment.balanceFee) AS balanceFee'),
            \DB::raw('MAX(za_payment.total_amount) AS total_amount'),
            \DB::raw('MAX(za_payment.payment_mode_label) AS payment_mode_label'),
            \DB::raw('MAX(za_payment.status) AS payment_status'),
            \DB::raw('MIN(za_customer.cus_name) AS cus_name'),
            \DB::raw('MAX(za_customer.cus_pic) AS cus_pic'),
            \DB::raw('MAX(za_customer.cus_gender) AS cus_gender'),
            \DB::raw('MAX(za_customer.jumper_skiper) AS jumper_skiper'),
            \DB::raw('MAX(za_customer.cus_mobile) AS cus_mobile'),
            \DB::raw('MAX(za_customer.cus_email_id) AS cus_email_id'),
            \DB::raw('MAX(za_customer.status) AS cus_status'),
            \DB::raw('MAX(za_course.course_name) AS course_name'),
            \DB::raw('MAX(za_course.sno) AS course_sno'),
            \DB::raw('MAX(za_staff.staff_name) AS pro_staff_name')
        )
        ->whereNotIn('za_payment.customer_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount', '>',0)
        ->where('za_customer.status', 0)
        ->where('za_training.status', '!=',  2)
        ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
        ->groupBy('za_training.training_id')
        ->orderBy('za_payment.nextPayDate', 'DESC')
        ->paginate($perpage);
        
        foreach($OutstandingPayment as $pay){
          $firstUnpaidRecord = DB::table('za_payment')
                  ->where('payment_id', $pay->payment_id)
                  ->where('course_id', $pay->course_sno)
                  ->where('branch_id', $pay->branch_id)
                  ->where('status', 0)
                  ->orderBy('nextPayDate', 'asc')
                  ->first();
          $pay->firstUnpaidRecord = $firstUnpaidRecord;
        }


// return $count;
      

    // Get the total count of records
    $OutstandingPaymentCount = $OutstandingPayment->total();
    
    // return $OutstandingPayment;

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->where('za_payment.status', 0)
      ->whereDate('za_payment.nextPayDate', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();

    if($OutstandingPayment->isNotEmpty()){
      foreach ($OutstandingPayment as $OutstandingPaymentData) {
        $training = DB::table('za_training')->where('branch_id', $branch_id)->where('customer_id', $OutstandingPaymentData->customer_sno)->first();
        $batch = BatchModel::where('sno', $training->batch_id)->first();
        $OutstandingPaymentData->outstanding_batch_name = isset($batch->batch_name) && !empty($batch->batch_name) ? $batch->batch_name : null;
      }
    }

    // return $OutstandingPaymentData;

    // Return the view with the data and total count
    return view('content.payment.outstanding_payment', [
      'perpage' => $perpage,
      'sumScheduleAmount' => $sumScheduleAmount,
      'sumBalanceFee' => $sumBalanceFee,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gstPercentage,
      'currentMonthAmount' => $currentMonthAmount,
      'nextMonthAmount' => $nextMonthAmount,
      'greaterThanThreeMonthsAmount' => $greaterThanThreeMonthsAmount,
    ])->with('filter_on', false);
  }
  
   public function OldOutstandingPayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

   

    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
      ->where('za_old_payments.status', 0)
      ->whereIn('za_old_customer.status', [1, 4])->where('za_old_payments.branch_id', $branch_id)->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
      ->sum('za_old_payments.amount');
    
    $sumBalanceFee = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
      ->where('za_old_payments.status', 0)
      ->whereIn('za_old_customer.status', [1, 4])->where('za_old_payments.branch_id', $branch_id)->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
      ->sum('za_old_payments.balanceFee');
      
    $currentMonthStart = now()->startOfMonth();
    $currentMonthEnd = now()->endOfMonth();
    $nextMonthStart = now()->addMonth()->startOfMonth();
    $nextMonthEnd = now()->addMonth()->endOfMonth();
    $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();
    
    // Current Month
    $currentMonthAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        // ->where('za_old_customer.status', 4)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->whereBetween('za_old_payments.schedule_date', [$currentMonthStart, $currentMonthEnd])
        ->sum('za_old_payments.amount');
    
    // Next Month
    $nextMonthAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->whereBetween('za_old_payments.schedule_date', [$nextMonthStart, $nextMonthEnd])
        ->sum('za_old_payments.amount');
    
    // Greater than 3 Months
    $greaterThanThreeMonthsAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->where('za_old_payments.schedule_date', '>=', $threeMonthsLaterStart)
        ->sum('za_old_payments.amount');
      
        $OutstandingPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->select(
            \DB::raw('MAX(za_old_payments.old_payment_id) AS payment_id'),
            \DB::raw('MAX(za_old_payments.sno) AS payment_sno'),
            \DB::raw('MAX(za_old_payments.branch_id) AS branch_id'),
            \DB::raw('MAX(za_old_customer.customer_id) AS customer_id'),
            \DB::raw('MAX(za_old_customer.sno) AS customer_sno'),
            \DB::raw('MAX(za_course.course_id) AS course_id'),
            \DB::raw('MAX(za_old_payments.schedule_date) AS nextPayDate'),
            \DB::raw('MAX(za_old_payments.amount) AS amount'),
            \DB::raw('MAX(za_old_payments.paidAmount) AS paidAmount'),
            \DB::raw('MAX(za_old_payments.gst_amount) AS gst_amount'),
            \DB::raw('MAX(za_old_payments.balanceFee) AS balanceFee'),
            \DB::raw('MAX(za_old_payments.total_amount) AS total_amount'),
            \DB::raw('MAX(za_old_payments.payment_mode_label) AS payment_mode_label'),
            \DB::raw('MAX(za_old_payments.status) AS payment_status'),
            \DB::raw('MAX(za_old_customer.cus_name) AS cus_name'),
            \DB::raw('MAX(za_old_customer.status) AS cus_status'),
            \DB::raw('MAX(za_old_customer.cus_gender) AS cus_gender'),
            // \DB::raw('MAX(za_old_customer.jumper_skiper) AS jumper_skiper'),
            \DB::raw('MAX(za_old_customer.cus_mobile) AS cus_mobile'),
            \DB::raw('MAX(za_course.course_name) AS course_name'),
            \DB::raw('MAX(za_course.sno) AS course_sno')
        )
        ->where('za_old_payments.status', 0)
        // ->where('za_old_payments.amount', '>',0)
        ->whereIn('za_old_customer.status', [1, 4])
        ->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
        ->groupBy('za_old_customer.sno')
        ->orderBy('za_old_payments.schedule_date', 'DESC')
        ->paginate($perpage);



      

    // Get the total count of records
    $OutstandingPaymentCount = $OutstandingPayment->total();
    
    // return $OutstandingPayment;

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
      ->where('za_old_payments.status', 0)
      ->whereDate('za_old_payments.schedule_date', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();
    //  return $OutstandingPayment;
    // Return the view with the data and total count
    return view('content.payment.old_outstanding_payment', [
      'perpage' => $perpage,
      'sumScheduleAmount' => $sumScheduleAmount,
      'sumBalanceFee' => $sumBalanceFee,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gstPercentage,
      'currentMonthAmount' => $currentMonthAmount,
      'nextMonthAmount' => $nextMonthAmount,
      'greaterThanThreeMonthsAmount' => $greaterThanThreeMonthsAmount,
    ])->with('filter_on', false);
  }
  
   public function OldOutstanding(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

   

    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
      ->where('za_old_payments.status', 0)
      ->whereIn('za_old_customer.status', [1, 4])->where('za_old_payments.branch_id', $branch_id)->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
      ->sum('za_old_payments.amount');
    
    $sumBalanceFee = DB::table('za_old_payments')
      ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
      ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
      ->where('za_old_payments.status', 0)
      ->whereIn('za_old_customer.status', [1, 4])->where('za_old_payments.branch_id', $branch_id)->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
      ->sum('za_old_payments.balanceFee');
      
    $currentMonthStart = now()->startOfMonth();
    $currentMonthEnd = now()->endOfMonth();
    $nextMonthStart = now()->addMonth()->startOfMonth();
    $nextMonthEnd = now()->addMonth()->endOfMonth();
    $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();
    
    // Current Month
    $currentMonthAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        // ->where('za_old_customer.status', 4)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->whereBetween('za_old_payments.schedule_date', [$currentMonthStart, $currentMonthEnd])
        ->sum('za_old_payments.amount');
    
    // Next Month
    $nextMonthAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->whereBetween('za_old_payments.schedule_date', [$nextMonthStart, $nextMonthEnd])
        ->sum('za_old_payments.amount');
    
    // Greater than 3 Months
    $greaterThanThreeMonthsAmount = DB::table('za_old_payments')
        ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        ->where('za_old_payments.status', 0)
        ->whereIn('za_old_customer.status', [1, 4])
        ->where('za_old_payments.branch_id', $branch_id)
        ->where('za_old_payments.schedule_date', '>=', $threeMonthsLaterStart)
        ->sum('za_old_payments.amount');
      
        // $OutstandingPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
        // ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
        // ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
        // ->select(
        //     \DB::raw('MAX(za_old_payments.old_payment_id) AS payment_id'),
        //     \DB::raw('MAX(za_old_payments.sno) AS payment_sno'),
        //     \DB::raw('MAX(za_old_payments.branch_id) AS branch_id'),
        //     \DB::raw('MAX(za_old_customer.customer_id) AS customer_id'),
        //     \DB::raw('MAX(za_old_customer.sno) AS customer_sno'),
        //     \DB::raw('MAX(za_course.course_id) AS course_id'),
        //     \DB::raw('MAX(za_old_payments.schedule_date) AS nextPayDate'),
        //     \DB::raw('MAX(za_old_payments.amount) AS amount'),
        //     \DB::raw('MAX(za_old_payments.paidAmount) AS paidAmount'),
        //     \DB::raw('MAX(za_old_payments.gst_amount) AS gst_amount'),
        //     \DB::raw('MAX(za_old_payments.balanceFee) AS balanceFee'),
        //     \DB::raw('MAX(za_old_payments.total_amount) AS total_amount'),
        //     \DB::raw('MAX(za_old_payments.payment_mode_label) AS payment_mode_label'),
        //     \DB::raw('MAX(za_old_payments.status) AS payment_status'),
        //     \DB::raw('MAX(za_old_customer.cus_name) AS cus_name'),
        //     \DB::raw('MAX(za_old_customer.status) AS cus_status'),
        //     \DB::raw('MAX(za_old_customer.cus_gender) AS cus_gender'),
        //     // \DB::raw('MAX(za_old_customer.jumper_skiper) AS jumper_skiper'),
        //     \DB::raw('MAX(za_old_customer.cus_mobile) AS cus_mobile'),
        //     \DB::raw('MAX(za_course.course_name) AS course_name'),
        //     \DB::raw('MAX(za_course.sno) AS course_sno')
        // )
        // ->where('za_old_payments.status', 0)
        // // ->where('za_old_payments.amount', '>',0)
        // ->whereIn('za_old_customer.status', [1, 4])
        // ->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
        // ->groupBy('za_old_customer.sno')
        // ->orderBy('za_old_payments.schedule_date', 'DESC')
        // ->paginate($perpage);
        $OutstandingPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
            ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
            ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
            ->select(
                'za_old_payments.old_payment_id AS payment_id',
                'za_old_payments.sno AS payment_sno',
                'za_old_payments.branch_id AS branch_id',
                'za_old_customer.customer_id AS customer_id',
                'za_old_customer.sno AS customer_sno',
                'za_course.course_id AS course_id',
                'za_old_payments.schedule_date AS nextPayDate',
                'za_old_payments.amount AS amount',
                'za_old_payments.paidAmount AS paidAmount',
                'za_old_payments.gst_amount AS gst_amount',
                'za_old_payments.balanceFee AS balanceFee',
                'za_old_payments.total_amount AS total_amount',
                'za_old_payments.payment_mode_label AS payment_mode_label',
                'za_old_payments.status AS payment_status',
                'za_old_customer.cus_name AS cus_name',
                'za_old_customer.status AS cus_status',
                'za_old_customer.cus_gender AS cus_gender',
                'za_old_customer.cus_mobile AS cus_mobile',
                'za_course.course_name AS course_name',
                'za_course.sno AS course_sno'
            )
            ->where('za_old_payments.status', 0)
            ->whereIn('za_old_customer.status', [1, 4])
            ->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
            ->orderBy('za_old_payments.schedule_date', 'DESC')
            ->paginate($perpage);


//  $OutstandingPaymentc = DB::table('za_old_payments')->where('za_old_payments.branch_id', $branch_id)
//         ->join('za_old_customer', 'za_old_payments.customer_id', '=', 'za_old_customer.sno')
//         ->join('za_course', 'za_old_payments.course_id', '=', 'za_course.sno')
//         ->where('za_old_payments.status', 0)
//         // ->where('za_old_payments.amount', '>',0)
//         ->whereIn('za_old_customer.status', [1, 4])
//         ->whereDate('za_old_payments.schedule_date', '<=', $currentDate)
//         ->orderBy('za_old_payments.schedule_date', 'DESC')
//         ->count();

      

    // Get the total count of records
    $OutstandingPaymentCount = $OutstandingPayment->total();
    
    // return $OutstandingPaymentc;

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentOldModel::where('za_old_payments.branch_id', $branch_id)
      ->where('za_old_payments.status', 0)
      ->whereDate('za_old_payments.schedule_date', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();
    //  return $OutstandingPayment;
    // Return the view with the data and total count
    return view('content.payment.old_outstanding', [
      'perpage' => $perpage,
      'sumScheduleAmount' => $sumScheduleAmount,
      'sumBalanceFee' => $sumBalanceFee,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gstPercentage,
      'currentMonthAmount' => $currentMonthAmount,
      'nextMonthAmount' => $nextMonthAmount,
      'greaterThanThreeMonthsAmount' => $greaterThanThreeMonthsAmount,
    ])->with('filter_on', false);
  }
  public function OutstandingPayment_filter(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;

    $customer_fill = $request->customer_fill ?? '';

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.payment_id');

    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)->where('za_payment.branch_id', $branch_id)->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->sum('za_payment.amount');
    
    $sumBalanceFee = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)->where('za_payment.branch_id', $branch_id)->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->sum('za_payment.balanceFee');
      
    $currentMonthStart = now()->startOfMonth();
    $currentMonthEnd = now()->endOfMonth();
    $nextMonthStart = now()->addMonth()->startOfMonth();
    $nextMonthEnd = now()->addMonth()->endOfMonth();
    $threeMonthsLaterStart = now()->addMonths(3)->startOfMonth();
    
    // Current Month
    $currentMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$currentMonthStart, $currentMonthEnd])
        ->sum('za_payment.amount');
    
    // Next Month
    $nextMonthAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->whereBetween('za_payment.nextPayDate', [$nextMonthStart, $nextMonthEnd])
        ->sum('za_payment.amount');
    
    // Greater than 3 Months
    $greaterThanThreeMonthsAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->where('za_payment.nextPayDate', '>=', $threeMonthsLaterStart)
        ->sum('za_payment.amount');
        
      
      
      $greaterThanThreeMonthsAmount = DB::table('za_payment')
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->where('za_payment.branch_id', $branch_id)
        ->where('za_payment.nextPayDate', '>=', $threeMonthsLaterStart)
        ->sum('za_payment.amount');
      
        $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_training.payment_id', '=', 'za_payment.payment_id')
        ->select(
            'za_training.training_id',
            \DB::raw('MAX(za_payment.payment_id) AS payment_id'),
            \DB::raw('MAX(za_training.sno) AS tran_sno'),
            \DB::raw('MAX(za_training.batch_id) AS batch_id'),
            \DB::raw('MAX(za_payment.sno) AS payment_sno'),
            \DB::raw('MAX(za_payment.branch_id) AS branch_id'),
            \DB::raw('MAX(za_customer.customer_id) AS customer_id'),
            \DB::raw('MAX(za_customer.sno) AS customer_sno'),
            \DB::raw('MAX(za_course.course_id) AS course_id'),
            \DB::raw('MAX(za_payment.initialPayDate) AS initialPayDate'),
            \DB::raw('MAX(za_payment.nextPayDate) AS nextPayDate'),
            \DB::raw('MAX(za_payment.amount) AS amount'),
            \DB::raw('MAX(za_payment.paidAmount) AS paidAmount'),
            \DB::raw('MAX(za_payment.gst_amount) AS gst_amount'),
            \DB::raw('MAX(za_payment.balanceFee) AS balanceFee'),
            \DB::raw('MAX(za_payment.total_amount) AS total_amount'),
            \DB::raw('MAX(za_payment.payment_mode_label) AS payment_mode_label'),
            \DB::raw('MAX(za_payment.status) AS payment_status'),
            \DB::raw('MAX(za_customer.cus_name) AS cus_name'),
            \DB::raw('MAX(za_customer.cus_pic) AS cus_pic'),
            \DB::raw('MAX(za_customer.cus_gender) AS cus_gender'),
            \DB::raw('MAX(za_customer.jumper_skiper) AS jumper_skiper'),
            \DB::raw('MAX(za_customer.cus_mobile) AS cus_mobile'),
            \DB::raw('MAX(za_customer.cus_email_id) AS cus_email_id'),
            \DB::raw('MAX(za_course.course_name) AS course_name'),
            \DB::raw('MAX(za_course.sno) AS course_sno')
        )
        ->whereNotIn('za_payment.payment_id', $drop_ids)
        ->where('za_payment.status', 0)
        ->where('za_customer.status', 0)
        ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
        ->groupBy('za_training.training_id');
        
        if ($customer_fill  != '') {
            $OutstandingPayment->where(function ($query) use ($customer_fill) {
              $query->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%");
            });
          }
         $OutstandingPayment = $OutstandingPayment->orderBy('za_payment.nextPayDate', 'DESC')
            ->paginate($perpage);

    // Get the total count of records
    $OutstandingPaymentCount = $OutstandingPayment->total();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->where('za_payment.status', 0)
      ->whereDate('za_payment.nextPayDate', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();

    // Return the view with the data and total count
    return view('content.payment.outstanding_payment', [
      'perpage' => $perpage,
      'sumScheduleAmount' => $sumScheduleAmount,
      'sumBalanceFee' => $sumBalanceFee,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gstPercentage,
      'currentMonthAmount' => $currentMonthAmount,
      'nextMonthAmount' => $nextMonthAmount,
      'customer_fill' => $customer_fill,
      'greaterThanThreeMonthsAmount' => $greaterThanThreeMonthsAmount,
    ])->with('filter_on', true);
  }
  public function PaymentHistory(Request $request)
  {
      
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    // paid amount
    $sumPaidAmount = DB::table('za_payment')
      ->where('za_payment.status', 1)
       ->where('za_payment.branch_id', $branch_id)
      ->sum('za_payment.paidAmount');
    $HistoryPayment = TrainingModel::where('za_training.branch_id', $branch_id)
    ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')

    // Join to get total_paid (sum of paidAmount for each customer)
    ->leftJoin(\DB::raw('(
        SELECT customer_id, SUM(paidAmount) as total_paid
        FROM za_payment
        WHERE status = 1
        GROUP BY customer_id
    ) as total_p'), function($join) {
        $join->on('za_customer.sno', '=', 'total_p.customer_id');
    })

    // Join to get total_amount (sum of MAX total_amount per course for each customer)
    ->leftJoin(\DB::raw('(
        SELECT customer_id, SUM(max_total) as total_amount
        FROM (
            SELECT customer_id, course_id, MAX(total_amount) as max_total
            FROM za_payment
            WHERE status = 1
            GROUP BY customer_id, course_id
        ) as subquery
        GROUP BY customer_id
    ) as total_a'), function($join) {
        $join->on('za_customer.sno', '=', 'total_a.customer_id');
    })

    ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
    ->select(
        'za_customer.sno as customer_sno',
        'za_customer.customer_id',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_gender',
        \DB::raw('MAX(za_training.training_id) as training_id'),
        \DB::raw('COALESCE(MAX(total_p.total_paid), 0) as total_paid'),  
        \DB::raw('COALESCE(MAX(total_a.total_amount), 0) as total_amount'),
        \DB::raw('(COALESCE(MAX(total_a.total_amount), 0) - COALESCE(MAX(total_p.total_paid), 0)) as total_balance'),
        \DB::raw('GROUP_CONCAT(DISTINCT za_course.course_name ORDER BY za_course.sno SEPARATOR ", ") as courses'),
        \DB::raw('DATEDIFF(NOW(), (SELECT MAX(p.initialPayDate) FROM za_payment p WHERE p.customer_id = za_training.customer_id AND p.status = 1)) as last_since_payment')
    )
    ->where('za_training.status', 0);

// Apply course_id condition
if (!empty($course_id)) {
    $HistoryPayment->where('za_training.course_id', $course_id);
}

// Apply customer filter if available
if (!empty($cus_fill)) {
    $HistoryPayment->where(function ($query) use ($cus_fill) {
        $query->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
              ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
    });
}

// Fix MySQL's strict mode issue by ensuring all non-aggregated fields are grouped
$HistoryPayment = $HistoryPayment
    ->groupBy(
        'za_customer.sno',
        'za_customer.customer_id',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_gender',
        'za_training.customer_id'
    )
    ->orderBy('za_customer.sno', 'desc')
    ->paginate($perpage);

// return $HistoryPayment;











  

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.payment_id');

    $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->orderBy('za_payment.sno', 'asc')->count();

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->where('za_payment.status', 0)
      ->whereDate('za_payment.nextPayDate', $currentDate)->count();

       // Current Month
    $outstandingAmount = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    ->whereNotIn('za_payment.payment_id', $drop_ids)
    ->where('za_payment.status', 0)
    ->where('za_customer.status', 0)
    ->where('za_payment.branch_id', $branch_id)
    ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
    ->sum('za_payment.amount');
    // return $HistoryPayment;
    // Return the view with the data and total count
    return view('content.payment.payment_history', [
      'perpage' => $perpage,
      'cus_fill' => $cus_fill,
      'HistoryPayment' => $HistoryPayment,
      'outstandingAmount' => $outstandingAmount,
      'sumPaidAmount' => $sumPaidAmount,
      'TodayPaymentCount' => $TodayPayment,
      'OutstandingPaymentCount' => $OutstandingPayment,
      'gstPercentage' => $gstPercentage,
    ])->with('filter_on', false);
  }
  public function PaidUnder(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perPage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perPage;
      $cus_fill = $request->cus_fill ?? '';
    
      // Get the current date
      $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    
      // Get branch details
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
  
      // Handle case where no branch is found
      if (!$branch) {
          return redirect()->back()->with('error', 'Branch not found.');
      }
  
      // Sum of the amounts
      $sumScheduleAmount = DB::table('za_payment')
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.amount');
  
      $sumBalanceFee = DB::table('za_payment')
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.balanceFee');
  
      // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_training')
          ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
          ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
          ->select(
              'za_customer.customer_id',
              'za_payment.course_id',
              'za_customer.sno as customer_sno',
              'za_course.sno as course_sno',
              'za_customer.cus_name',
              'za_customer.cus_gender',
              'za_customer.cus_pic',
              'za_customer.cus_mobile',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
              'za_training.paid_amount as total_paid_amount',
             'za_training.balance_amount as total_balance_fee',
             'za_training.overall_fees as total_amount',
              DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate'
          )
          ->where('za_payment.branch_id', $branch_id)
          ->groupBy(
              'za_customer.customer_id',
              'za_customer.sno',
              'za_course.sno',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_pic',
              'za_customer.cus_gender',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
               'za_training.paid_amount',
             'za_training.balance_amount',
             'za_training.overall_fees',
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate',
              'za_payment.course_id'
          )
          ->orderByDesc('za_payment.sno')
          ->get()
          ->unique('payment_id'); // Keep only unique customer records;
    
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->total_paid_amount < $branch->min_prd_cost;
      });
    
      // Apply search condition if 'cus_fill' is provided
      if ($cus_fill) {
          $result = $result->filter(function ($payment) use ($cus_fill) {
              return strpos(strtolower($payment->cus_name), strtolower($cus_fill)) !== false ||
                     strpos(strtolower($payment->cus_mobile), strtolower($cus_fill)) !== false;
          });
      }
    
      // Group by customer_id
      $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          // Filter payments where paidAmount is greater than 0
          $filteredPayments = $payments->filter(function ($payment) {
              return $payment->total_paid_amount > 0;
          });
    
          // If no valid payments exist after filtering, exclude this customer
          if ($filteredPayments->isEmpty()) {
              return null;
          }
    
          $payment = $payments->first();
    
          // Return structured data for each customer
          return [
              'customer_name' => $payment->cus_name,
              'customer_sno' => $payment->customer_sno,
              'total_paid' => $payment->total_paid_amount,
              'min_required' => $branch->min_prd_cost,
              'status' => 'Pending',
              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                  return [
                      'course_name' => $payment->course_name,
                      'cus_gender' => $payment->cus_gender,
                      'cus_pic' => $payment->cus_pic,
                      'training_id' => $payment->training_id,
                      'payment_id' => $payment->payment_id,
                      'cus_name' => $payment->cus_name,
                      'cus_mobile' => $payment->cus_mobile,
                      'amount' => $payment->total_amount,
                      'paidAmount' => $payment->total_paid_amount,
                      'balanceFee' => $payment->total_balance_fee,
                      'gst_amount' => $payment->total_gst_amount,
                      'nextPayDate' => $payment->nextPayDate,
                      'payment_mode_label' => $payment->payment_mode_label,
                  ];
              })->values(), // Reset array keys
          ];
      })->filter();
  
      // Paginate the results
      $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
    
      // Calculate the total number of pages
      $totalItems = $finalResult->count();
      $totalPages = ceil($totalItems / $perPage);
  
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    
      // Get the count of payments that are due (nextPayDate is past or today)
      $drop_ids = DB::table('za_drop_refund')
          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
          ->where('za_drop_refund.bh_status', 1)
          ->pluck('za_training.payment_id');
    
      $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->whereNotIn('za_payment.payment_id', $drop_ids)
          ->where('za_payment.status', 0)
          ->where('za_customer.status', 0)
          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
          ->orderBy('za_payment.sno', 'asc')->count();
    
      // Get today's payments (nextPayDate equals today)
      $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
          ->where('za_payment.status', 0)
          ->whereDate('za_payment.nextPayDate', $currentDate)
          ->count();
    
      $outstandingAmount = DB::table('za_payment')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
          ->whereNotIn('za_payment.payment_id', $drop_ids)
          ->where('za_payment.status', 0)
          ->where('za_customer.status', 0)
          ->where('za_payment.branch_id', $branch_id)
          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
          ->sum('za_payment.amount');
 
      // Return the view with the data
      return view('content.payment.paid_under', [
          'perpage' => $perPage,
          'cus_fill' => $cus_fill,
          'sumScheduleAmount' => $sumScheduleAmount,
          'outstandingAmount' => $outstandingAmount,
          'sumBalanceFee' => $sumBalanceFee,
          'PaidUnderPayment' => $paginatedResult,
          'PaidUnderPaymentCount' => $totalItems,
          'TodayPaymentCount' => $TodayPayment,
          'OutstandingPaymentCount' => $OutstandingPayment,
          'gstPercentage' => $gstPercentage,
          'branch' => $branch,
          'pagination' => [
              'current_page' => $page,
              'total_pages' => $totalPages,
              'total_items' => $totalItems,
              'per_page' => $perPage,
          ]
      ])->with('filter_on', true);
  }
//   public function getCustomerDetails($id, Request $request)
//   {
//     $branch_id = $request->user()->branch_id;
//     $customer = CustomerModel::find($id);

//     // Get branch details and calculate GST percentage
//     $branch = BranchModel::where('sno', $branch_id)
//       ->where('status', 0)
//       ->orderBy('sno', 'desc')
//       ->first();
//     $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

//     // Helper to get general settings
//     $helper = new Helpers();
//     $generalSettings = $helper->general_setting_data();
//     $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

//     // Fetch payments and format dates based on the general setting
//     $payments = PaymentModel::where('customer_id', $id)->get()->map(function ($payment) use ($dateFormat) {
//       // Format the date fields
//       $payment->initialPayDate = $payment->initialPayDate ? \Carbon\Carbon::parse($payment->initialPayDate)->format($dateFormat) : null;
//       $payment->nextPayDate = $payment->nextPayDate ? \Carbon\Carbon::parse($payment->nextPayDate)->format($dateFormat) : null;
//       return $payment;
//     });
    
    // $paymentss = PaymentModel::where('customer_id', $id)
    // ->orderBy('created_at', 'desc') // Get latest records first
    // ->get()
    // ->unique('payment_id'); // Get only the last record for each payment_id
    
    // // Sum total_amount from the latest records of each payment_id
    // $grandTotal = $paymentss->sum('total_amount');
   

//     return response()->json([
//       'customer' => $customer,
//       'grandTotal' => $grandTotal,
//       'payments' => $payments,
//       'gstPercentage' => $gstPercentage,
//     ]);
//   }
    public function getCustomerDetails($id, Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $customer = CustomerModel::find($id);

      // Get branch details and calculate GST percentage
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

      // Helper to get general settings
      $helper = new Helpers();
      $generalSettings = $helper->general_setting_data();
      $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

      // Fetch payments and format dates + add encrypted values
      $payments = PaymentModel::where('customer_id', $id)->where('za_payment.amount', '>',0)->where('za_payment.status', '!=',2)->get()->map(function ($payment, $index) use ($dateFormat, $helper) {
          // Format dates
          $payment->initialPayDate = $payment->initialPayDate ? \Carbon\Carbon::parse($payment->initialPayDate)->format($dateFormat) : null;
          $payment->nextPayDate = $payment->nextPayDate ? \Carbon\Carbon::parse($payment->nextPayDate)->format($dateFormat) : null;

          // Add encrypted fields
          $payment->encryptedValue = $helper->encrypt_decrypt($payment->invoice_id, 'encrypt');
          $payment->printValue = $helper->encrypt_decrypt($index + 1, 'encrypt');

          return $payment;
      });
      $paidamount = $payments->sum('paidAmount');
      $paymentss = PaymentModel::where('customer_id', $id)
        ->orderBy('created_at', 'desc') // Get latest records first
        ->get()
        ->unique('payment_id'); // Get only the last record for each payment_id
    
        // Sum total_amount from the latest records of each payment_id
         $grandTotal = $paymentss->sum('total_amount');
         $balanceAmount = $grandTotal- $paidamount;
      return response()->json([
          'customer' => $customer,
          'payments' => $payments,
          'grandTotal' => $grandTotal,
           'paidamount' => $paidamount,
            'balanceAmount' => $balanceAmount,
          'gstPercentage' => $gstPercentage,
      ]);
  }
  
   public function getoldCustomerDetails($id, Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $customer = OldCustomerModel::find($id);

      // Get branch details and calculate GST percentage
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

      // Helper to get general settings
      $helper = new Helpers();
      $generalSettings = $helper->general_setting_data();
      $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

      // Fetch payments and format dates + add encrypted values
      $payments = PaymentOldModel::where('customer_id', $id)->where('za_old_payments.amount', '>',0)->where('za_old_payments.status', '!=',2)->get()->map(function ($payment, $index) use ($dateFormat, $helper) {
          // Format dates
          $payment->formatted_updated_at = $payment->updated_at
          ? \Carbon\Carbon::parse($payment->updated_at)->format($dateFormat)
          : null;

          $payment->schedule_date = $payment->schedule_date ? \Carbon\Carbon::parse($payment->schedule_date)->format($dateFormat) : null;

          // Add encrypted fields
          $payment->encryptedValue = $helper->encrypt_decrypt($payment->invoice_id, 'encrypt');
          $payment->printValue = $helper->encrypt_decrypt($index + 1, 'encrypt');

          return $payment;
      });

      return response()->json([
          'customer' => $customer,
          'payments' => $payments,
          'gstPercentage' => $gstPercentage,
      ]);
  }
  public function list_filter(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type = 0;
    }
    $customer_fill = $request->customer_fill ?? '';
    $customer_name_fill = $request->customer_name_fill_sno ?? '';
    $mobile_fill = $request->mobile_fill ?? '';
    $gender_fill = $request->gender_fill ?? '';
    $course_type_fill = $request->course_type_fill_sno ?? '';
    $course_name_fill = $request->course_name_fill_sno ?? '';
    $batch_name_fill = $request->batch_name_fill_sno ?? '';
    $slot_name_fill = $request->slot_name_fill_sno ?? '';
    $slot_type_name_fill = $request->slot_type_name_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;
    $fin_yr_fill = $request->fin_yr_fill ?? '';

    // return $request;
    $query = CustomerModel::select(
      'za_customer.sno',
      'za_customer.cus_name',
      'za_customer.cus_pic',
      'za_customer.customer_id',
      'za_customer.cus_gender',
      'za_customer.cus_dob',
      'za_customer.cus_mobile',
      'za_customer.cus_alternate_mobile',
      'za_customer.cus_email_id',
      'za_customer.cus_marital_status',
      'za_customer.country',
      'za_customer.state',
      'za_customer.city',
      'za_customer.address',
      'za_customer.course_id',
      'za_customer.free_shd_count',
      'za_customer.request_count',
      'za_customer.reason_request',
      'za_customer.free_status',
      'za_customer.reason_reject',
      'za_customer.created_by',
      'za_customer.batch_id',
      'za_lead.sno as lead_id',
      'za_batch.batch_name',
      'za_batch.start_date',
      'za_batch.end_date',
      'za_course_type.course_type_name',
      'za_course.course_name',
      'za_slot.slot_name',
      'za_training.course_mode_id',
      'za_staff.staff_name',
      'za_branch.min_prd_cost',
      DB::raw('SUM(za_payment.paidAmount) as total_paid_amount'),
      DB::raw('MAX(za_payment.total_amount) as total_amount'),
      DB::raw('JSON_LENGTH(za_customer.course_id) as course_id_count'), // Count of course_id
      DB::raw('JSON_LENGTH(za_customer.batch_id) as batch_id_count')

    )
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->leftJoin('za_batch', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.batch_id, "$[0]"))'), '=', 'za_batch.sno')
      ->leftJoin('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->leftJoin('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_branch', 'za_customer.branch_id', '=', 'za_branch.sno')
      ->leftJoin('za_payment', 'za_customer.sno', '=', 'za_payment.customer_id')
      ->leftJoin('za_training', 'za_customer.sno', '=', 'za_training.customer_id')
      ->where('za_customer.status', 0)
      ->where('za_customer.branch_id', $branch_id)
      ->groupBy(
        'za_customer.sno',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.customer_id',
        'za_customer.cus_gender',
        'za_customer.cus_dob',
        'za_customer.cus_mobile',
        'za_customer.cus_alternate_mobile',
        'za_customer.cus_email_id',
        'za_customer.cus_marital_status',
        'za_customer.country',
        'za_customer.state',
        'za_customer.city',
        'za_customer.address',
        'za_customer.course_id',
        'za_customer.free_shd_count',
        'za_customer.request_count',
        'za_training.course_mode_id',
        'za_customer.free_status',
        'za_customer.reason_request',
        'za_customer.reason_reject',
        'za_customer.created_by',
        'za_customer.batch_id',
        'za_lead.sno',
        'za_course.course_name',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_course_type.course_type_name',
        'za_slot.slot_name',
        'za_staff.staff_name',
        'za_branch.min_prd_cost'

      )
      ->orderBy('za_customer.sno', 'desc');
    // date filter query
    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('za_customer.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('za_customer.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('za_customer.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('za_customer.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('za_customer.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('za_customer.created_at', '<=', $toDate);
      }
    }
    // Financial year filter
    if ($fin_yr_fill) {
      $helper = new \App\Helpers\Helpers();
      $selected_fin_year = $helper->get_fin_year_by_sno($fin_yr_fill);
      if ($selected_fin_year) {
        $monthsArray = json_decode($selected_fin_year->financial_month, true) ?? [];
        foreach ($monthsArray as $month) {
          if (is_numeric($month) && $month >= 1 && $month <= 12) {
            $query->orWhere(function ($q) use ($month) {
              $q->whereYear('za_customer.created_at', now()->year)
                ->whereMonth('za_customer.created_at', (int) $month);
            });
          }
        }
      }
    }

    if ($branch_id > 0) {
      $query->where('za_customer.branch_id', $branch_id);
    }

    if ($customer_fill) {
      $query->where(function ($customer) use ($customer_fill) {
        $customer->where('za_customer.cus_name', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
          ->orWhere('za_customer.cus_email_id', 'LIKE', "%{$customer_fill}%");
      });
    }
    if ($customer_name_fill) {
      $query->where('za_customer.sno', 'LIKE', "%{$customer_name_fill}%");
    }
    if ($mobile_fill) {
      $query->where('za_customer.cus_mobile', 'LIKE', "%{$mobile_fill}%");
    }
    if ($gender_fill) {
      $query->where('za_customer.cus_gender', $gender_fill);
    }
    if ($course_type_fill) {
      $query->where('za_course_type.sno', $course_type_fill);
    }
    if ($course_name_fill) {
      $query->where('za_course.sno', $course_name_fill);
    }
    if ($batch_name_fill) {
      $query->where('za_batch.sno', $batch_name_fill);
    }
    if ($slot_name_fill) {
      $query->where('za_slot.sno', $slot_name_fill);
    }
    if ($slot_type_name_fill) {
      $query->where('za_slot_type.sno', $slot_type_name_fill);
    }

    // Fetch Branch list ordered by sno in descending order
    $customers = $query->orderBy('za_customer.sno', 'desc')->distinct()->paginate(10);

    // $customers = $customers->unique('payment_id');

    $customers->transform(function ($item, $key) {
      // Initialize an array to hold course and batch details
      $carouselDetails = [];

      $paymentDetailss = DB::table('za_payment')
        ->select('za_payment.status', 'za_payment.nextPayDate')
        ->where('za_payment.customer_id', $item->sno)
        ->where('za_payment.status', 0)
        ->get();
      $paymentget = DB::table('za_training')
        ->where('customer_id', $item->sno)
        ->whereIn('status', [0, 2]) // Use an array for the values
        ->get();

      // Decode the JSON arrays for course_id and batch_id
      $courseIds = $paymentget;
      $batchIds = json_decode($item->batch_id);

      // Check if both arrays are the same length
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      // if (is_array($courseIds) && is_array($batchIds) && count($courseIds) === count($batchIds)) {
      foreach ($courseIds as $index => $courseId) {
        // $batchId = $batchIds[$index];
        $batchId = $batchIds[$index] ?? [];

        // Retrieve course details
        $course = DB::table('za_course')
          ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
          ->select('za_course.course_name', 'za_course_type.course_type_name', 'za_course_type.online_fee')
          ->where('za_course.sno', $courseId->course_id)
          ->first();

        // Get date format from general settings
        $helper = new Helpers();
        $generalSettings = $helper->general_setting_data();
        $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d';

        // Retrieve batch details
        $batch = DB::table('za_batch')
          ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
          ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
          ->select('za_batch.batch_name', 'za_batch.start_date', 'za_batch.end_date', 'za_slot.slot_name', 'za_staff.staff_name')
          ->where('za_batch.sno', $batchId)
          ->first();

        // Format start_date and end_date
        $startDate = !empty($batch->start_date) ? \Carbon\Carbon::parse($batch->start_date)->format($dateFormat) : null;
        $endDate = !empty($batch->end_date) ? \Carbon\Carbon::parse($batch->end_date)->format($dateFormat) : null;

        // Retrieve summed paidAmount and total_amount for the specific course and batch
        $paymentDetails = DB::table('za_training')
          ->selectRaw('SUM(za_payment.paidAmount) as total_paid_amount, za_payment.total_amount')
          ->join('za_payment', 'za_training.payment_id', '=', 'za_payment.payment_id')
          ->where('za_training.customer_id', $item->sno)
          ->where('za_training.course_id', $courseId->course_id)
          ->where('za_training.status', '!=', 3)
          ->where('za_payment.status', '!=', 3)
          //   ->where('za_training.batch_id', $batchId)
          ->groupBy('za_payment.total_amount') // Since total_amount remains constant, group by it
          ->first();

        // Calculate payment percentage for the specific course and batch
        $paymentPercentage = 0;
        if ($paymentDetails && $paymentDetails->total_amount > 0) {
          $paymentPercentage = number_format(($paymentDetails->total_paid_amount / $paymentDetails->total_amount) * 100, 1);
        }

        // Check if attendance exists for the specific batch and customer
        $attendanceRecords = AttendanceModel::where('customer_id', $item->sno)
          ->where('batch_id', $batchId)
          ->where('attendance', 'P')
          ->get();

        // Initialize course progress percentage
        $courseProgress = 0;

        $topicCount = 0;
        $course_topic_count = DB::table('za_course_chapter')->where('za_course_chapter.course_id', $courseId->course_id)
          ->count();

        // If attendance exists, check for syllabus update percentage for each attendance record
        if ($attendanceRecords->isNotEmpty()) {
          foreach ($attendanceRecords as $attendance) {
            // Check for all syllabus updates that match the batch_id and attendance date
            $syllabusUpdates = SyllabusUpdateModel::where('batch_id', $batchId)
              ->whereDate('date', $attendance->att_date) // Check the attendance date
              ->get(); // Get all syllabus updates for that date

            // If syllabus updates exist, sum the percentages
            if ($syllabusUpdates->isNotEmpty()) {
              foreach ($syllabusUpdates as $syllabusUpdate) {
                if ($syllabusUpdate->percentage == 100) {
                  $topicCount++;
                }
              }
            }
          }
          if ($course_topic_count > 0) {
            $courseProgress = ($topicCount / $course_topic_count) * 100;
          }
          // Limit the course progress to a maximum of 100%
          if ($courseProgress > 100) {
            $courseProgress = 100; // Cap the maximum value at 100%
          }

          // Format the course progress to 2 decimal places
          $courseProgress = number_format($courseProgress, 2);
        }

        // batch count by course id
        $batch_count = BatchModel::where('za_batch.course_id', $courseId->course_id)->count();
        // Add the course and batch details to the array
        $carouselDetails[] = [
          'course_sno' => $courseId->course_id ?? null,
          'course_mode_id' => $courseId->course_mode_id ?? null,
          'online_course_fee' => $course->online_fee ?? null,
          'batch_sno' => $batchId ?? null,
          'batch_count' => $batch_count ?? 0,
          'traning_status' => $courseId->status ?? null,
          'traning_sno' => $courseId->sno ?? null,
          'course_name' => $course->course_name ?? null,
          'course_type_name' => $course->course_type_name ?? null,
          'batch_name' => $batch->batch_name ?? null,
          'start_date' => $startDate, // Use formatted start date
          'end_date' => $endDate, // Use formatted end date
          'slot_name' => $batch->slot_name ?? null,
          'staff_name' => $batch->staff_name ?? null,
          'payment_percentage' => $paymentPercentage, // Include calculated payment percentage here
          'course_progress' => $courseProgress, // Include course progress percentage here
        ];
      }
      // }

      // Attach the carousel details to the customer item
      $item->carousel_details = $carouselDetails;
      $item->paymentDetailss = $paymentDetailss;

      // Calculate initial letter
      $item->cus_initial = strtoupper(substr($item->cus_name, 0, 1));

      // Calculate overall payment percentage if total amount is not zero
      if ($item->total_amount > 0) {
        $item->payment_percentage = number_format(($item->total_paid_amount / $item->total_amount) * 100, 1);
      } else {
        $item->payment_percentage = number_format(0, 1);
      }

      return $item;
    });

    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');
    $customers_list = CustomerModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_type_list = CourseTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $course_list = ManageCoursesModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $batch_list = BatchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_list = SlotModel::where('status', 0)->orderBy('sno', 'desc')->get();
    $slot_type_list = SlotTypeModel::where('status', 0)->orderBy('sno', 'desc')->get();

    // alagu
    // current month customer
    $currentMonthCustomerCount = CustomerModel::where('za_customer.status', 0)
      ->join('za_course', DB::raw('JSON_UNQUOTE(JSON_EXTRACT(za_customer.course_id, "$[0]"))'), '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
      ->when($branch_id != 0, function ($query) use ($branch_id) {
        return $query->where('za_customer.branch_id', $branch_id);
      })
      ->whereYear('za_customer.created_at', date('Y'))
      ->whereMonth('za_customer.created_at', date('m'))
      ->count();

    // coversion rate current month
    // Get the count of leads for the current month
    $currentMonthLeadCount = LeadModel::whereNotIn('status', [3, 2, 6]);
    if ($branch_id != 0) {
      $currentMonthLeadCount->where('za_lead.branch_id', $branch_id);
    }
    $currentMonthLeadCount = $currentMonthLeadCount->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->count();
    $percentagecurrentmonth = 0;
    if ($currentMonthLeadCount > 0) {
      $percentagecurrentmonth = ($currentMonthCustomerCount / $currentMonthLeadCount) * 100;
    }

    $conversionRateCurrentmonth = number_format($percentagecurrentmonth, 2);

    // get all lead courses
    $allCourses_ids = LeadModel::whereNotIn('status', [3, 2])
      ->where('branch_id', $branch_id)
      ->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))
      ->pluck('course_id');
    $allCourses_ids = collect($allCourses_ids)->flatMap(function ($item) {
      return json_decode($item);
    })->values()->all();

    // get all payments
    $payments = [];
    foreach ($allCourses_ids as $id) {
      $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');
      // return  $payment;
      if ($payment !== null) {
        $payments[] = $payment[0];
      } else {
        $payments[] = 0;
      }
    }

    // sum total course amount
    $total_business_value = array_sum($payments);

    $average_business_value = 0;
    // formula for average business
    if ($currentMonthLeadCount > 0) {
      $average_business_value = $total_business_value / $currentMonthLeadCount;
    }

    // calculation for average collection value
    $allCourses_cus = CustomerModel::where('status', 0)->whereYear('created_at', date('Y'))
      ->whereMonth('created_at', date('m'))->pluck('course_id');
    $allCourses_cus = collect($allCourses_cus)->flatMap(function ($item) {
      return json_decode($item);
    })->values()->all();

    // get all payments
    $payments_cus = [];
    foreach ($allCourses_cus as $id) {
      $payment = ManageCoursesModel::where('sno', $id)->pluck('course_max_price');

      if ($payment !== null) {
        $payments_cus[] = $payment[0];
      } else {
        $payments_cus[] = 0;
      }
    }

    // sum total collection course amount
    $total_collection_value = array_sum($payments_cus);

    // formula for average collection
    $average_collection_value = 0;
    if ($currentMonthCustomerCount > 0) {
      $average_collection_value = $total_collection_value / $currentMonthCustomerCount;
    }
    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    if ($branch_id > 0) {
      $get_course_change_days = $helper->get_branch_id($branch_id)->min_course_change_days ?? 0;
    } else {
      $get_course_change_days = 0;
    }

    return view('content.customer.customer_list', [
      'customers' => $customers,
      'customers_list' => $customers_list,
      'course_type_list' => $course_type_list,
      'course_list' => $course_list,
      'batch_list' => $batch_list,
      'slot_list' => $slot_list,
      'slot_type_list' => $slot_type_list,
      'login_branch_id' => $branch_id,
      'login_branch_type' => $get_branch_type,
      'customer_fill' => $customer_fill,
      'customer_name_fill' => $customer_name_fill,
      'mobile_fill' => $mobile_fill,
      'gender_fill' => $gender_fill,
      'course_type_fill' => $course_type_fill,
      'course_name_fill' => $course_name_fill,
      'batch_name_fill' => $batch_name_fill,
      'slot_name_fill' => $slot_name_fill,
      'slot_type_name_fill' => $slot_type_name_fill,
      'date_filter' => $date_filter,
      'from_date_filter' => $from_date_filter,
      'to_date_filter' => $to_date_filter,
      'fin_yr_fill' => $fin_yr_fill,
      'currentMonthCustomerCount' => $currentMonthCustomerCount,
      'conversionRateCurrentmonth' => $conversionRateCurrentmonth,
      'average_business_value' => $average_business_value,
      'average_collection_value' => $average_collection_value,
      'course_change_count' => $get_course_change_days,

    ])->with('filter_on', true);
  }
  public function DropPayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $drop_ids = DB::table('za_drop_refund')
    ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
    ->where('za_drop_refund.bh_status', 1)
    ->pluck('za_training.payment_id');

    $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
        ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
        ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
        ->join('za_training', 'za_payment.payment_id', '=', 'za_training.payment_id')
        ->join('za_drop_refund', 'za_drop_refund.training_id', '=', 'za_training.sno')
        ->select(
            'za_payment.payment_id',
            'za_payment.sno as payment_sno',
            'za_payment.branch_id',
            'za_customer.customer_id',
            'za_customer.sno as customer_sno',
            'za_course.course_id',
            'za_payment.initialPayDate',
            'za_payment.nextPayDate',
            'za_payment.amount',
            'za_payment.paidAmount',
            'za_payment.gst_amount',
            'za_payment.balanceFee',
            'za_payment.total_amount',
            'za_payment.payment_mode_label',
            'za_payment.status as payment_status',
            'za_customer.cus_name',
            'za_customer.cus_pic',
            'za_customer.cus_gender',
            'za_customer.cus_mobile',
            'za_customer.cus_email_id',
            'za_course.course_name',
            'za_course.sno as course_sno',
            'za_training.status as training_status',
            'za_training.training_id',
            'za_training.sno as training_ID'
        )
        ->where('za_drop_refund.bh_status', 1)
        ->where('za_training.status', 2)
        ->where('za_customer.status', 0)
        ->where('za_payment.status', 0)
        ->where('za_payment.amount','>', 0)
        ->whereIn('za_payment.payment_id', $drop_ids);  // This filters payments related to the drop refund entries
    
    // Apply customer filter if provided
    if ($cus_fill) {
        $OutstandingPayment->where(function ($payment_fill) use ($cus_fill) {
            $payment_fill->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
                         ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
        });
    }
    
    // Paginate results
    $OutstandingPayment = $OutstandingPayment->orderBy('za_payment.sno', 'asc')->paginate($perpage);



    // return $OutstandingPayment;
    // return response()->json($OutstandingPayment);

    // Get the total count of records

    $OutstandingPaymentCount = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->orderBy('za_payment.sno', 'asc')->count();
      
      
    //   return $drop_ids;
    
    // Retrieve data where nextPayDate is today's date and status is 0
    $sumScheduleAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_drop_refund', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      ->sum('za_payment.amount');
    $sumBalanceFee = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->join('za_training', 'za_payment.payment_id', '=', 'za_training.payment_id')
      ->join('za_drop_refund', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      ->sum('za_payment.balanceFee');

    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();

    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->where('za_payment.status', 0)
      ->whereDate('za_payment.nextPayDate', $currentDate)->get();

    // Get the total count of records
    $TodayPaymentCount = $TodayPayment->count();
    
      $outstandingAmount = DB::table('za_payment')
    ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
    ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
    ->whereNotIn('za_payment.payment_id', $drop_ids)
    ->where('za_payment.status', 0)
    ->where('za_customer.status', 0)
    ->where('za_payment.branch_id', $branch_id)
    ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
    ->sum('za_payment.amount');
    // return $OutstandingPaymentCount;
    // Return the view with the data and total count
    return view('content.payment.drop_payment', [
      'perpage' => $perpage,
      'cus_fill' => $cus_fill,
      'sumScheduleAmount' => $sumScheduleAmount,
       'outstandingAmount' => $outstandingAmount,
      'sumBalanceFee' => $sumBalanceFee,
      'OutstandingPayment' => $OutstandingPayment,
      'TodayPaymentCount' => $TodayPaymentCount,
      'OutstandingPaymentCount' => $OutstandingPaymentCount,
      'gstPercentage' => $gstPercentage,
    ])->with('filter_on', false);
  }
  public function ReschedulePayment(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';
    // Get the current date
    $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format

    $sumScheduleAmount = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->where('za_payment.reschedule_payment', '>', 0)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      // ->whereDate('za_payment.nextPayDate', $currentDate)
      ->sum('za_payment.amount');

    $sumBalanceFee = DB::table('za_payment')
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->where('za_payment.reschedule_payment', '>', 0)
      ->where('za_payment.status', 0)
      ->where('za_customer.status', 0)
      ->where('za_payment.branch_id', $branch_id)
      // ->whereDate('za_payment.nextPayDate', $currentDate)
      ->sum('za_payment.balanceFee');

    // Retrieve data where nextPayDate is today's date and status is 0
    $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
      ->select(
        'za_payment.payment_id',
        'za_payment.sno as payment_sno',
        'za_payment.branch_id',
        'za_customer.customer_id',
        'za_customer.sno as customer_sno',
        'za_course.course_id',
        'za_payment.initialPayDate',
        'za_payment.nextPayDate',
        'za_payment.amount',
        'za_payment.paidAmount',
        'za_payment.gst_amount',
        'za_payment.balanceFee',
        'za_payment.total_amount',
        'za_payment.payment_mode_label',
        'za_payment.status as payment_status',
        'za_customer.cus_name',
        'za_customer.cus_pic',
        'za_customer.cus_mobile',
        'za_customer.cus_email_id',
        'za_customer.jumper_skiper',
        'za_course.course_name',
        'za_course.sno as course_sno'
      )
      ->where('za_payment.status', 0)
      ->where('za_payment.reschedule_payment', '>', 0)
      ->where('za_customer.status', 0);
      // ->whereDate('za_payment.nextPayDate', $currentDate) // Compare nextPayDate with today's date
      if ($cus_fill) {
        $TodayPayment->where(function ($payment_fill) use ($cus_fill) {
            $payment_fill->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
                ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
        });
      }
      $TodayPaymentResult = $TodayPayment->orderBy('za_payment.sno', 'desc')->paginate($perpage);

      $TodayPaymentCount = $TodayPaymentResult->total();
    $branch = BranchModel::where('sno', $branch_id)
      ->where('status', 0)
      ->orderBy('sno', 'desc')
      ->first();
    $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;

    $drop_ids = DB::table('za_drop_refund')
      ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
      ->where('za_drop_refund.bh_status', 1)
      ->pluck('za_training.payment_id');

    $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
      ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
      ->whereNotIn('za_payment.payment_id', $drop_ids)
      ->where('za_payment.status', 0)
      ->where('za_payment.reschedule_payment', 0)
      ->where('za_customer.status', 0)
      // ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
      ->orderBy('za_payment.sno', 'asc')->count();
    $genaral_settings = GeneralSettingsModel::where('sno', 1)->first();
    // return $TodayPayment;
    // Return the view with the data and total count
    return view('content.payment.reschedule_payment', [
        'perpage' => $perpage,
        'cus_fill' => $cus_fill,
        'TodayPayment' => $TodayPaymentResult,
        'sumBalanceFee' => $sumBalanceFee,
        'sumScheduleAmount' => $sumScheduleAmount,
        'OutstandingPaymentCount' => $OutstandingPayment,
        'TodayPaymentCount' => $TodayPaymentCount,
        'gstPercentage' => $gstPercentage,
        'genaral_settings' => $genaral_settings,
    ])->with('filter_on', true);
    
  }
    //   public function PaymentTransaction(Request $request) 
    //   {
          
    //       $year  = $request->get('year', $year ?? date('Y'));
    //     $month = $request->get('month', $month ?? date('m'));
        
    //     if($month.$year == date('mY') || $year > date('Y')){
    //       $month_chk = 0;
    //     }else{
    //       $month_chk = 1;
    //     }
         
    //     // Get the current date
    //     $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
          
          
    //       $branch_id = $request->user()->branch_id;
    //       $page = $request->input('page', 1);
    //       $perpage = (int) $request->input('sorting_filter', 25);
    //       $offset = ($page - 1) * $perpage;
    //       $cus_fill = $request->cus_fill ?? '';
    
    //     // if($branch_id==1){
    //       $trans_list = TransactionModel::where('za_transaction.branch_id', $branch_id)
    //         ->select(
    //             'za_transaction.sno AS trans_sno', 
    //             'za_transaction.customer_type',
    //             'za_subledger.subledger_name',
    //             DB::raw("COALESCE(za_customer.customer_id, za_old_customer.customer_id) AS customer_id"),
    //             DB::raw("COALESCE(za_customer.sno, za_old_customer.sno) AS customer_sno"),
    //             DB::raw("COALESCE(za_customer.cus_mobile, za_old_customer.cus_mobile) AS cus_mobile"),
    //             DB::raw("COALESCE(za_customer.cus_name, za_old_customer.cus_name) AS cus_name"),
    //             // 'za_training.training_id',
    //             // Aggregate functions
    //             DB::raw('MAX(za_transaction.daily_acc_chk) as daily_acc_chk'),
    //             DB::raw('MAX(za_transaction.transaction_id) as transaction_id'),
    //             DB::raw('MAX(za_transaction.receipt_id) as receipt_id'),
    //             DB::raw('MAX(za_transaction.transaction_date) as transaction_date'),
    //             DB::raw('MAX(za_transaction.transaction_type) as transaction_type'),
    //             DB::raw('MAX(za_transaction.transaction_name) as transaction_name'),
    //             DB::raw('MAX(za_transaction.trans_source_id) as trans_source_id'),
    //             DB::raw('MAX(za_transaction.ledger_id) as ledger_id'),
    //             DB::raw('MAX(za_transaction.subledger_id) as subledger_id'),
    //             DB::raw('MAX(za_transaction.credit) as credit'),
    //             DB::raw('MAX(za_transaction.debit) as debit'),
    //             DB::raw('MAX(za_transaction.tax) as tax'),
    //             DB::raw('MAX(za_transaction.total_amount) as total_amount'),
    //             DB::raw('MAX(za_transaction.invoice_id) as invoice_id'),
    //             DB::raw('MAX(za_transaction.trans_desc) as trans_desc'),
    //             DB::raw('MAX(za_transaction.created_at) as created_at'),
    //             DB::raw('MAX(za_transaction.created_by) as created_by'),
    //             DB::raw('MAX(za_transaction.updated_at) as updated_at'),
    //             DB::raw('MAX(za_transaction.updated_by) as updated_by'),
    //             DB::raw('MAX(za_transaction.status) as status'),
    //             DB::raw('MAX(za_transaction.payment_status) as payment_status')
    //         )
    //         ->join('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
            
    //         // Left Join to get customer details based on customer_type
    //         ->leftJoin('za_customer', function ($join) {
    //             $join->on('za_transaction.trans_source_id', '=', 'za_customer.customer_id')
    //                  ->where('za_transaction.customer_type', '=', 0);
    //         })
    //         ->leftJoin('za_old_customer', function ($join) {
    //             $join->on('za_transaction.trans_source_id', '=', 'za_old_customer.customer_id')
    //                  ->where('za_transaction.customer_type', '=', 1);
    //         });
    //         // ->join('za_training', function ($join) {
    //         //     $join->on('za_training.training_id', '=', DB::raw("SUBSTRING_INDEX(za_subledger.subledger_name, ' - ', -1)"));
    //         // });
    
    //         // Apply cus_fill filter if provided
    //         if (!empty($cus_fill)) {
    //             $trans_list->where(function ($query) use ($cus_fill) {
    //                 $query->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
    //                       ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
    //                       ->orWhere('za_old_customer.cus_name', 'LIKE', "%{$cus_fill}%")
    //                       ->orWhere('za_transaction.trans_source_id', 'LIKE', "%{$cus_fill}%")
    //                       ->orWhere('za_old_customer.cus_mobile', 'LIKE', "%{$cus_fill}%");
    //             });
    //         } else {
    //             $trans_list->whereYear('za_transaction.transaction_date', $year);
    //             $trans_list->whereMonth('za_transaction.transaction_date', $month);
    //         }
            
    //         // Apply status filter and ordering
    //         $trans_list->where('za_transaction.status', 0)->where('za_transaction.customer_type', '!=',2)
    //                   ->orderBy('za_transaction.sno', 'desc');
            
    //         // Group by all the non-aggregated columns using COALESCE()
    //         $trans_list->groupBy(
    //             'za_transaction.sno',
    //             'za_transaction.customer_type',
    //             'za_transaction.transaction_id',
    //             'za_subledger.subledger_name',
    //             // 'za_training.training_id',
    //             DB::raw("COALESCE(za_customer.customer_id, za_old_customer.customer_id)"),
    //             DB::raw("COALESCE(za_customer.sno, za_old_customer.sno)"),
    //             DB::raw("COALESCE(za_customer.cus_mobile, za_old_customer.cus_mobile)"),
    //             DB::raw("COALESCE(za_customer.cus_name, za_old_customer.cus_name)")
    //         );
            
    //         // Paginate after all filters
    //         $trans_list = $trans_list->paginate($perpage);
            
            
    //         // }
    
    
    
    
    
    //     //   return  $trans_list;
    //       $ledger_list = LedgerModel::where('status', 0)->where('sno', '>', 1)->orderBy('sno', 'desc')->get();
      
    //       $sum_credit = TransactionModel::selectRaw('SUM(credit) AS total_credit')
    //                                     ->where('branch_id', $branch_id)
    //                                     ->whereYear('transaction_date', $year)
    //                                     ->whereMonth('transaction_date', $month)
    //                                     ->first();
                                        
    //       $sum_debit = TransactionModel::selectRaw('SUM(debit) AS total_debit')
    //                                   ->where('branch_id', $branch_id)
    //                                     ->whereYear('transaction_date', $year)
    //                                   ->whereMonth('transaction_date', $month)
    //                                   ->first();
      
    //       $sum_tax = TransactionModel::selectRaw('SUM(tax) AS total_tax')
    //                                  ->where('branch_id', $branch_id)
    //                                   ->whereYear('transaction_date', $year)
    //                                   ->whereMonth('transaction_date', $month)
    //                                  ->first();
      
    //       return view('content.payment.payment_transaction', compact(
    //           'trans_list', 'ledger_list', 'sum_debit','month_chk', 'sum_credit', 'sum_tax', 'perpage', 'cus_fill'
    //       ))->with('filter_on', true);
    //   }
    public function PaymentTransaction(Request $request)
  {
    $year = $request->get('year', date('Y'));
    $month = $request->get('month', date('m'));

    $month_chk = ($month . $year == date('mY') || $year > date('Y')) ? 0 : 1;

    $branch_id = $request->user()->branch_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $cus_fill = trim($request->cus_fill ?? '');

    // 🔹 Subquery: first transaction per customer
    $firstTrans = DB::table('za_transaction as t')
      ->select('t.trans_source_id as customer_id', DB::raw('MIN(t.sno) as first_sno'))
      ->where('t.branch_id', $branch_id)
      ->groupBy('t.trans_source_id');

    // 🔹 Base Query (shared for totals + list)
    $baseQuery = TransactionModel::from('za_transaction')
      ->join('za_subledger', 'za_subledger.sno', '=', 'za_transaction.subledger_id')
       ->leftJoin('za_payment', 'za_payment.invoice_id', '=', 'za_transaction.invoice_id')
      ->leftJoin('za_customer', function ($join) {
        $join->on('za_transaction.trans_source_id', '=', 'za_customer.customer_id')
          ->where('za_transaction.customer_type', '=', 0);
      })
      ->leftJoin('za_old_customer', function ($join) {
        $join->on('za_transaction.trans_source_id', '=', 'za_old_customer.customer_id')
          ->where('za_transaction.customer_type', '=', 1);
      })
      ->leftJoinSub($firstTrans, 'first_trans', function ($join) {
        $join->on('first_trans.customer_id', '=', 'za_transaction.trans_source_id');
      })
      ->where('za_transaction.branch_id', $branch_id)
      ->where('za_transaction.status', 0)
      ->where('za_transaction.customer_type', '!=', 2);

    // 🔹 Optional: Search Filter
    if (!empty($cus_fill)) {
      $baseQuery->where(function ($query) use ($cus_fill) {
        $query->where('za_customer.cus_name', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_old_customer.cus_name', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_old_customer.cus_mobile', 'LIKE', "%{$cus_fill}%")
          ->orWhere('za_transaction.trans_source_id', 'LIKE', "%{$cus_fill}%");
      });
    }
    else{
      $baseQuery->where(function ($query) use ($year, $month) {
        $query->whereYear('za_transaction.transaction_date', $year);
        $query->whereMonth('za_transaction.transaction_date', $month);
      });
    }

    // 🔹 Clone for totals (same filters applied)
    $totalsQuery = clone $baseQuery;
    $totals = $totalsQuery->selectRaw("
          COALESCE(SUM(za_transaction.debit), 0) AS total_debit,
          COALESCE(SUM(za_transaction.credit), 0) AS total_credit,
          COALESCE(SUM(za_transaction.tax), 0) AS total_tax
      ")->first();

    // 🔹 Fetch Transaction List (paginated)
    $trans_list = $baseQuery
      ->select(
        'za_transaction.sno AS trans_sno',
        'za_transaction.customer_type',
        'za_subledger.subledger_name',
         'za_payment.transaction as transaction_all',
        'za_payment.invoice_id as payment_invoice',
        'za_payment.payment_mode_label',
        'za_transaction.attachments as transaction_attachments',

        DB::raw("COALESCE(za_customer.customer_id, za_old_customer.customer_id) AS customer_id"),
        DB::raw("COALESCE(za_customer.sno, za_old_customer.sno) AS customer_sno"),
        DB::raw("COALESCE(za_customer.cus_mobile, za_old_customer.cus_mobile) AS cus_mobile"),
        DB::raw("COALESCE(za_customer.cus_name, za_old_customer.cus_name) AS cus_name"),
        DB::raw('MAX(za_transaction.daily_acc_chk) as daily_acc_chk'),
        DB::raw('MAX(za_transaction.transaction_id) as transaction_id'),
        DB::raw('MAX(za_transaction.receipt_id) as receipt_id'),
        DB::raw('MAX(za_transaction.transaction_date) as transaction_date'),
        DB::raw('MAX(za_transaction.transaction_type) as transaction_type'),
        DB::raw('MAX(za_transaction.transaction_name) as transaction_name'),
        DB::raw('MAX(za_transaction.trans_source_id) as trans_source_id'),
        DB::raw('MAX(za_transaction.ledger_id) as ledger_id'),
        DB::raw('MAX(za_transaction.subledger_id) as subledger_id'),
        DB::raw('MAX(za_transaction.credit) as credit'),
        DB::raw('MAX(za_transaction.debit) as debit'),
        DB::raw('MAX(za_transaction.tax) as tax'),
        DB::raw('MAX(za_transaction.total_amount) as total_amount'),
        DB::raw('MAX(za_transaction.invoice_id) as invoice_id'),
        DB::raw('MAX(za_transaction.trans_desc) as trans_desc'),
        DB::raw('MAX(za_transaction.transaction_desc) as transaction_desc'),
        DB::raw('MAX(za_transaction.created_at) as created_at'),
        DB::raw('MAX(za_transaction.created_by) as created_by'),
        DB::raw('MAX(za_transaction.updated_at) as updated_at'),
        DB::raw('MAX(za_transaction.updated_by) as updated_by'),
        DB::raw('MAX(za_transaction.status) as status'),
        DB::raw('MAX(za_transaction.payment_status) as payment_status'),
        DB::raw("
                  CASE
                      WHEN za_transaction.sno = first_trans.first_sno THEN 'New Paid'
                      ELSE 'Harvesting Paid'
                  END AS payment_flag
              ")
      )
      ->groupBy(
        'za_transaction.sno',
        'za_transaction.customer_type',
        'za_transaction.transaction_id',
        'za_subledger.subledger_name',
         'za_payment.invoice_id',
          'za_payment.transaction',
        'za_payment.payment_mode_label',
        'za_transaction.attachments',
          
        DB::raw("COALESCE(za_customer.customer_id, za_old_customer.customer_id)"),
        DB::raw("COALESCE(za_customer.sno, za_old_customer.sno)"),
        DB::raw("COALESCE(za_customer.cus_mobile, za_old_customer.cus_mobile)"),
        DB::raw("COALESCE(za_customer.cus_name, za_old_customer.cus_name)"),
        'first_trans.first_sno'
      )
      ->orderBy('za_transaction.sno', 'desc')
      ->paginate($perpage);

      $trans_list->getCollection()->transform(function ($trans_data) {
        $trans_data->attachments_list = !empty($trans_data->transaction_attachments) ? json_decode($trans_data->transaction_attachments, true) : [];
        return $trans_data;
      });
    // 🔹 Ledger List
    $ledger_list = LedgerModel::where('status', 0)
      ->where('sno', '>', 1)
      ->orderBy('sno', 'desc')
      ->get();

    // 🔹 Return View
    return view('content.payment.payment_transaction', compact(
      'trans_list',
      'ledger_list',
      'month_chk',
      'perpage',
      'year',
      'month',
      'cus_fill'
    ) + [
      'sum_credit' => $totals,
      'sum_debit' => $totals,
      'sum_tax' => $totals,
    ])->with('filter_on', true);
  }



  public function payment_history_status_change(Request $request)
  {
    $id = $request->sts_change_id;
    $sts = $request->sts_change_type;
    $sts_change_description = $request->sts_change_description ?? NULL;
    $receipt_id = $request->rept_id ?? null;
    $current_page_url = $request->current_page_url ?? 'payment_transaction';

    // Find the record
    $OldCustomerModel = TransactionModel::where('sno', $id)->select('sno', 'payment_status')->first();

    if ($OldCustomerModel) {
      $OldCustomerModel->payment_status = $sts;
      if($sts == 1){
      $OldCustomerModel->receipt_id = $receipt_id;
      }
      if($sts == 2){
        $OldCustomerModel->transaction_desc = $sts_change_description;
      }else{
        $OldCustomerModel->transaction_desc = NULL;
      }
      $OldCustomerModel->save(); // Use save() instead of update()
      // return $OldCustomerModel;
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Successfully Status Updated!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not Update Status!'
      ]);
    }
    return redirect($current_page_url);
  }
  
  // low mpc page
  
  public function LowMPC(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $page = $request->input('page', 1);
      $perPage = (int) $request->input('sorting_filter', 100);
      $offset = ($page - 1) * $perPage;
      $cus_fill = $request->cus_fill ?? '';
    
      // Get the current date
      $currentDate = now()->toDateString(); // Get the date in 'YYYY-MM-DD' format
    
      // Get branch details
      $branch = BranchModel::where('sno', $branch_id)
          ->where('status', 0)
          ->orderBy('sno', 'desc')
          ->first();
  
      // Handle case where no branch is found
      if (!$branch) {
          return redirect()->back()->with('error', 'Branch not found.');
      }
       $drop_ids = DB::table('za_drop_refund')
          ->join('za_training', 'za_drop_refund.training_id', '=', 'za_training.sno')
          ->where('za_drop_refund.bh_status', 1)
          ->pluck('za_training.customer_id');
 
      // Sum of the amounts
      $sumScheduleAmount = DB::table('za_payment')
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.amount');
  
      $sumBalanceFee = DB::table('za_payment')
          ->where('za_payment.branch_id', $branch_id)
          ->sum('za_payment.balanceFee');
      $min = $branch->min_prd_cost;
      // Retrieve payments for the given branch and group by customer and course with aggregation
      $PaidUnderPayment = DB::table('za_training')
          ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
          ->join('za_payment', 'za_payment.payment_id', '=', 'za_training.payment_id')
          ->join('za_lead', 'za_customer.lead_id', '=', 'za_lead.sno')
          ->leftJoin('za_staff', 'za_lead.created_by', '=', 'za_staff.sno')
          ->select(
              'za_customer.customer_id',
              'za_payment.course_id',
              'za_customer.sno as customer_sno',
              'za_course.sno as course_sno',
              'za_customer.cus_name',
              'za_customer.cus_gender',
              'za_customer.cus_pic',
              'za_customer.cus_mobile',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_staff.staff_name',
              'za_training.training_id',
              'za_training.batch_id',
              'za_training.payment_id',
              'za_payment.initialPayDate',
              'za_training.paid_amount as total_paid_amount',
             'za_training.balance_amount as total_balance_fee',
             'za_training.overall_fees as total_amount',
              DB::raw('SUM(za_payment.gst_amount) as total_gst_amount'),
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate'
          )
          ->where('za_payment.branch_id', $branch_id)
           ->whereNotIn('za_customer.sno', $drop_ids)
          ->where('za_training.status', 0)
        //   ->where('za_training.balance_amount', '!=',0)
            ->where(function ($q) use ($min) {
                $q->where('za_training.overall_fees', '>', $min)
                  ->orWhere(function ($q2) use ($min) {
                      $q2->where('za_training.overall_fees', '<=', $min)
                         ->whereColumn('za_training.overall_fees', '!=', 'za_training.paid_amount');
                  });
            })

          ->groupBy(
              'za_customer.customer_id',
              'za_customer.sno',
              'za_course.sno',
              'za_customer.cus_name',
              'za_customer.cus_mobile',
              'za_customer.cus_pic',
              'za_customer.cus_gender',
              'za_customer.cus_email_id',
              'za_course.course_name',
              'za_training.training_id',
              'za_training.payment_id',
               'za_staff.staff_name',
                'za_training.batch_id',
               'za_training.paid_amount',
             'za_training.balance_amount',
             'za_training.overall_fees',
              'za_payment.payment_mode_label',
              'za_payment.nextPayDate',
              'za_payment.initialPayDate',
              'za_payment.course_id'
          )
        //   ->orderByDesc('za_payment.sno')
        ->orderBy('za_payment.nextPayDate', 'asc')
          ->get()
          ->unique('payment_id'); // Keep only unique customer records;
    //   return $PaidUnderPayment;
      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
      $result = $PaidUnderPayment->filter(function ($payment) use ($branch) {
          return $payment->total_paid_amount < $branch->min_prd_cost;
      });
    
      // Apply search condition if 'cus_fill' is provided
      if ($cus_fill) {
          $result = $result->filter(function ($payment) use ($cus_fill) {
              return strpos(strtolower($payment->cus_name), strtolower($cus_fill)) !== false ||
                     strpos(strtolower($payment->cus_mobile), strtolower($cus_fill)) !== false;
          });
      }
    
      // Group by customer_id
      $finalResult = $result->groupBy('customer_id')->map(function ($payments) use ($branch) {
          // Filter payments where paidAmount is greater than 0
          $filteredPayments = $payments->filter(function ($payment) {
              return $payment->total_paid_amount > 0;
          });
    
          // If no valid payments exist after filtering, exclude this customer
          if ($filteredPayments->isEmpty()) {
              return null;
          }
    
          $payment = $payments->first();
          // Return structured data for each customer
          return [
              'customer_name' => $payment->cus_name,
              'customer_sno' => $payment->customer_sno,
              'total_paid' => $payment->total_paid_amount,
              'min_required' => $branch->min_prd_cost,
              'status' => 'Pending',
              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                  return [
                      'course_name' => $payment->course_name,
                      'cus_gender' => $payment->cus_gender,
                      'cus_pic' => $payment->cus_pic,
                      'staff_name' => $payment->staff_name,
                      'batch_id' => $payment->batch_id,
                      'training_id' => $payment->training_id,
                      'payment_id' => $payment->payment_id,
                      'cus_name' => $payment->cus_name,
                      'cus_mobile' => $payment->cus_mobile,
                      'amount' => $payment->total_amount,
                      'paidAmount' => $payment->total_paid_amount,
                      'balanceFee' => $payment->total_balance_fee,
                      'gst_amount' => $payment->total_gst_amount,
                      'nextPayDate' => $payment->nextPayDate,
                      'initialPayDate' => $payment->initialPayDate,
                      'payment_mode_label' => $payment->payment_mode_label,
                  ];
              })->values(), // Reset array keys
          ];
      })->filter();
  
      // Paginate the results
      $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
    
      // Calculate the total number of pages
      $totalItems = $finalResult->count();
    //   return $totalItems;
      $totalPages = ceil($totalItems / $perPage);
    //   return $totalItems;
      $gstPercentage = $branch ? $branch->gst_percentage / 100 : 0;
    
      // Get the count of payments that are due (nextPayDate is past or today)
     
    
      $OutstandingPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->whereNotIn('za_payment.payment_id', $drop_ids)
          ->where('za_payment.status', 0)
          ->where('za_customer.status', 0)
          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
          ->orderBy('za_payment.sno', 'asc')->count();
    
      // Get today's payments (nextPayDate equals today)
      $TodayPayment = PaymentModel::where('za_payment.branch_id', $branch_id)
          ->where('za_payment.status', 0)
          ->whereDate('za_payment.nextPayDate', $currentDate)
          ->count();
    
      $outstandingAmount = DB::table('za_payment')
          ->join('za_customer', 'za_payment.customer_id', '=', 'za_customer.sno')
          ->join('za_course', 'za_payment.course_id', '=', 'za_course.sno')
          ->whereNotIn('za_payment.payment_id', $drop_ids)
          ->where('za_payment.status', 0)
          ->where('za_customer.status', 0)
          ->where('za_payment.branch_id', $branch_id)
          ->whereDate('za_payment.nextPayDate', '<=', $currentDate)
          ->sum('za_payment.amount');
    //   return $paginatedResult;
      // Return the view with the data
      return view('content.payment.low_mpc', [
          'perpage' => $perPage,
          'cus_fill' => $cus_fill,
          'sumScheduleAmount' => $sumScheduleAmount,
          'outstandingAmount' => $outstandingAmount,
          'sumBalanceFee' => $sumBalanceFee,
          'PaidUnderPayment' => $paginatedResult,
          'PaidUnderPaymentCount' => $totalItems,
          'TodayPaymentCount' => $TodayPayment,
          'OutstandingPaymentCount' => $OutstandingPayment,
          'gstPercentage' => $gstPercentage,
          'branch' => $branch,
          'pagination' => [
              'current_page' => $page,
              'total_pages' => $totalPages,
              'total_items' => $totalItems,
              'perPage' => $perPage,
          ]
      ])->with('filter_on', true);
  }
 public function attendanceDetails(Request $request)
{
    $id = $request->student_id;
    $branch_id = auth()->user()->branch_id;

    $training = TrainingModel::where('branch_id', $branch_id)
        ->where('customer_id', $id)
        ->first();

    if (!$training) {
        return response()->json([
            'status' => 'error',
            'message' => 'Training data not found.'
        ]);
    }

    $batch = BatchModel::where('sno', $training->batch_id)->first();

    if (!$batch) {
        return response()->json([
            'status' => 'error',
            'message' => 'No Batch Added.'
        ]);
    }
    $startDate = Carbon::parse($batch->start_date);
    $endDate = Carbon::parse($batch->end_date);
    $totalDays = $startDate->diffInDays($endDate) + 1; // include end date
    
    $lastAttendance = AttendanceModel::where('customer_id', $id)
        ->where('batch_id', $batch->sno)
        ->where('attendance', 'P')
        ->orderBy('att_date', 'desc')
        ->first();

    if ($lastAttendance) {
        $lastDate = Carbon::parse($lastAttendance->att_date);
        $today = Carbon::now();
        $daysSinceLast = $lastDate->diffInDays($today);
        $withinRange = $daysSinceLast <= 12;
        $lastDateFormatted = $lastDate->format('d-M-Y');
    } else {
        $lastDateFormatted = null;
        $daysSinceLast = null;
        $withinRange = false;
    }

    return response()->json([
        'status' => 'success',
        'data' => [
            'batch_name' => $batch->batch_name,
            'last_attendance_date' => $lastDateFormatted,
            'days_since_last' => $daysSinceLast,
            'within_12_days' => $withinRange,
            'current_date' => Carbon::now()->format('d-M-Y'),
             'total_days' => $totalDays,
        ]
    ]);
}

public function GetTransactionDetails($id, Request $request)
  {
    if (!$id) {
      return response()->json([
        'status' => 'error',
        'message' => 'Transaction Sno is Required!'
      ]);
    }

    $TransactionModelData = TransactionModel::where('sno', $id)->first();

    if (!$TransactionModelData) {
      return response()->json([
        'status' => 'error',
        'message' => 'Transaction data Not Found!.'
      ]);
    }
    
    return response()->json([
      'status' => 'success',
      'data' => $TransactionModelData
    ]);
  }

  public function UpdateTransactionDetails(Request $request)
  {
    $update_trans_sno = $request->update_trans_sno ?? null;
    
    $UpdateTransactionModelData = TransactionModel::where('sno', $update_trans_sno)->first();
    
    if (!$UpdateTransactionModelData) {
      return response()->json([
        'status' => 500,
        'message' => 'Transaction data Not Updated!.',
        'error_msg' => null,
        'data' => null
      ]);
    }

    $update_branch_id = $request->update_branch_id ?? null;
    $update_transaction_id = $request->update_transaction_id ?? null;
    $update_transaction_date = $request->update_transaction_date ?? null;
    $update_trans_source_id = $request->update_trans_source_id ?? null;
    $update_ledger_id = $request->update_ledger_id ?? null;
    $update_subledger_id = $request->update_subledger_id ?? null;
    $update_customer_type = $request->update_customer_type ?? null;
    $update_credit = $request->update_credit ?? null;
    $update_debit = $request->update_debit ?? null;
    $update_tax = $request->update_tax ?? null;
    $update_total_amount = $request->update_total_amount ?? null;
    $update_invoice_id = $request->update_invoice_id ?? null;
    $update_receipt_id = $request->update_receipt_id ?? null;
    $update_training_id = $request->update_training_id ?? null;
    $update_status = $request->update_status ?? null;
    $update_payment_status = $request->update_payment_status ?? null;

    $UpdateTransactionModelData->branch_id = $update_branch_id;
    $UpdateTransactionModelData->transaction_id = $update_transaction_id;
    $UpdateTransactionModelData->transaction_date = $update_transaction_date;
    $UpdateTransactionModelData->trans_source_id = $update_trans_source_id;
    $UpdateTransactionModelData->ledger_id = $update_ledger_id;
    $UpdateTransactionModelData->subledger_id = $update_subledger_id;
    $UpdateTransactionModelData->customer_type = $update_customer_type;
    $UpdateTransactionModelData->credit = $update_credit;
    $UpdateTransactionModelData->debit = $update_debit;
    $UpdateTransactionModelData->tax = $update_tax;
    $UpdateTransactionModelData->total_amount = $update_total_amount;
    $UpdateTransactionModelData->invoice_id = $update_invoice_id;
    $UpdateTransactionModelData->receipt_id = $update_receipt_id;
    $UpdateTransactionModelData->training_id = $update_training_id;
    $UpdateTransactionModelData->status = $update_status;
    $UpdateTransactionModelData->payment_status = $update_payment_status;
    
    if($UpdateTransactionModelData->update()){
      return response()->json([
        'status' => 200,
        'message' => 'Transaction details Updated Successfully.',
        'error_msg' => null,
        'data' => $UpdateTransactionModelData
      ], 200);
    }else{
      return response()->json([
        'status' => 500,
        'message' => 'Transaction details Updated Unsuccessfully.',
        'error_msg' => null,
        'data' => $UpdateTransactionModelData
      ], 200);
    }
  }


}