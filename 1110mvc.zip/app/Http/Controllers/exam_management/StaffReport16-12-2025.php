<?php

namespace App\Http\Controllers\exam_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\StaffModel;
use App\Models\ManageExamModel;
use App\Models\ExamStaffBadgeModel;
use Illuminate\Support\Facades\DB;

class StaffReport extends Controller
{
  public function index()
  {
    return view('content.exam_management.staff_report');
  }

  public function staffReport(Request $request)
  {
    $branch_id = $request->user()->branch_id;

    $staff = DB::table('za_staff AS s')
      ->leftJoin('za_process_exam AS pe', 'pe.staff_id', '=', 's.sno')
      ->leftJoin('za_user_role', 'za_user_role.sno', '=', 's.role_id')
      ->select(
        's.sno as staff_id',
        's.staff_name',
        's.staff_image',
        's.role_id',
        'za_user_role.role_name',
        DB::raw('SUM(CASE WHEN pe.status="passed" THEN 1 ELSE 0 END) as passed')
      )
      ->where('s.branch_id', $branch_id)
      ->where('s.status', 0)
      ->groupBy(
        's.sno',
        's.staff_name',
        's.role_id',
        's.staff_image',
        'za_user_role.role_name'
      )
      ->get();

    foreach ($staff as $st) {

      /** total exams required for this role */
      $st->total_required = DB::table('za_manage_exam')
        ->whereJsonContains('role_id', (string) $st->role_id)
        ->count();

      /**
       * Achieved badges (group first!)
       */
      $achieved_badges = DB::table('za_exam_staff_badges')
        ->select(
          'za_manage_exam.badge',
          'za_manage_exam.sno AS exam_id',
          'za_exam_badge.badge_name',
          'za_exam_badge.badge_image',
          'za_manage_exam.exam_name',
          'za_manage_exam.duration AS exam_duration',
          'za_manage_exam.question_count',
          'za_manage_exam.level_id'
        )
        ->leftJoin('za_manage_exam', 'za_manage_exam.sno', '=', 'za_exam_staff_badges.exam_id')
        ->leftJoin('za_exam_badge', 'za_exam_badge.sno', '=', 'za_manage_exam.badge')
        ->where('za_exam_staff_badges.staff_id', $st->staff_id)
        ->where('za_exam_staff_badges.status', 0)
        ->get();

      /** group achieved */
      $groupedBadges = $achieved_badges
        ->groupBy('exam_id')
        ->map(function ($g) {
          $first = $g->first();

          return [
            'exam_id'        => $first->exam_id,
            'badge_id'       => $first->badge,
            'badge_name'     => $first->badge_name,
            'exam_name'     => $first->exam_name,
            'exam_duration'     => $first->exam_duration,
            'question_count'     => $first->question_count,
            'level' => match ($first->level_id) {
              0 => 'Beginner',
              1 => 'Intermediate',
              2 => 'Expert',
              default => 'Beginner'
            },
            'badge_image_url' => asset('exam/badges/' . $first->badge_image),
            'count'          => str_pad($g->count(), 2, '0', STR_PAD_LEFT)
          ];
        });


      $st->badge_counts = array_values($groupedBadges->toArray());
      $st->passed_exam_count = count($achieved_badges);

      /**
       * required badge list (show achieved or grey)
       */
      $badgeRows = DB::table('za_manage_exam')
        ->leftJoin('za_exam_badge', 'za_exam_badge.sno', '=', 'za_manage_exam.badge')
        ->whereJsonContains('za_manage_exam.role_id', (string)$st->role_id)
        ->select('za_exam_badge.sno AS badge_id', 'za_exam_badge.badge_image', 'za_manage_exam.sno AS exam_id', 'za_manage_exam.exam_name', 'za_manage_exam.duration AS exam_duration', 'za_manage_exam.question_count', 'za_manage_exam.level_id')
        ->get();

      $badgeFinal = [];
      foreach ($badgeRows as $b) {

        // if achieved then exists
        $exists = $groupedBadges[$b->exam_id] ?? null;

        // always use original badge image (UI will grayscale if not passed)
        $img = file_exists(public_path('exam/badges/' . $b->badge_image))
          ? asset('exam/badges/' . $b->badge_image)
          : asset('assets/eapl_images/gray-badge.png');

        $badgeFinal[] = [
          'badge_id'        => $b->badge_id,
          'exam_id'        => $b->exam_id,
          'exam_name'       => $b->exam_name,
          'exam_duration'   => $b->exam_duration,
          'question_count'  => $b->question_count,
          'level' => match ($b->level_id) {
            0 => 'Beginner',
            1 => 'Intermediate',
            2 => 'Expert',
            default => 'Beginner'
          },

          'badge_image_url' => $img,
          'count'           => $exists['count'] ?? '00',
          'passed'          => $exists ? true : false
        ];
      }

      $st->badges = $badgeFinal;

      /** staff image */
      $st->staff_image_url = file_exists(public_path('staff_images/' . $st->staff_image))
        ? asset('staff_images/' . $st->staff_image)
        : asset('assets/eapl_images/default-user.jpg');
    }

    return response()->json([
      'status' => 200,
      'data'   => $staff
    ]);
  }


  public function getExamReport(Request $request)
  {
    $examId  = $request->input('exam_id');
    $staffId = $request->input('staff_id');

    // Fetch exam details
    $exam = DB::table('za_manage_exam')
      ->leftJoin('za_exam_badge', 'za_exam_badge.sno', '=', 'za_manage_exam.badge')
      ->leftJoin('za_user_role', function ($join) {
        $join->on(DB::raw("JSON_CONTAINS(za_manage_exam.role_id, JSON_QUOTE(CAST(za_user_role.sno AS CHAR)))"), '=', DB::raw('1'));
      })
      ->select(
        'za_manage_exam.sno AS exam_id',
        'za_manage_exam.exam_name',
        'za_manage_exam.duration AS exam_duration',
        'za_manage_exam.level_id',
        'za_manage_exam.pass_mark',
        'za_manage_exam.exam_attempt',
        'za_user_role.role_name',
        'za_manage_exam.question_count',
        'za_manage_exam.badge',
        'za_exam_badge.badge_image'
      )
      ->where('za_manage_exam.sno', $examId)
      ->first();


    if (!$exam) {
      return response()->json(['status' => 404, 'message' => 'Exam not found']);
    }

    // Fetch all attempts by this staff for this exam
    $attempts = DB::table('za_process_exam')
      ->join('za_manage_exam', 'za_manage_exam.sno', '=', 'za_process_exam.exam_id')
      ->where('za_process_exam.exam_id', $examId)
      ->where('za_process_exam.staff_id', $staffId)
      ->orderBy('za_process_exam.created_at', 'asc')
      ->get()
      ->map(function ($a, $key) {

        $positiveMarks  = $a->positive_mark;
        $negativeMarks  = $a->negative_mark;
        $totalQuestions = $a->question_count;

        // Decode the JSON
        $answers = json_decode($a->exam_question_answers_datas, true);

        if (!is_array($answers)) {
          return [
            'attempt' => $this->getOrdinalSuffix($key + 1),
            'scored'  => 0,
            'time'    => '-',
            'result'  => 'Invalid Answers'
          ];
        }

        // Count correctness
        $correctCount   = collect($answers)->where('correctness', 'correct')->count();
        $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();

        // Marks calculation
        $marksScored = ($positiveMarks * $correctCount) - ($negativeMarks * $incorrectCount);

        $marksScored = max(0, $marksScored); // never negative

        // final result
        $result = $marksScored >= $a->pass_mark ? 'Pass' : 'Fail';

        return [
          'attempt' => $this->getOrdinalSuffix($key + 1),
          'scored'  => $marksScored,
          'time'    => $this->formatDuration($a->total_attended_duration),
          'result'  => $result
        ];
      });


    // Calculate total marks
    $totalMarks = $attempts->sum('scored');

    $level = match ($exam->level_id) {
      0 => 'Beginner',
      1 => 'Intermediate',
      2 => 'Expert',
      default => 'Beginner'
    };

    return response()->json([
      'status' => 200,
      'data' => [
        'exam_id' => $exam->exam_id,
        'badge_id' => $exam->badge,
        'exam_name' => $exam->exam_name,
        'duration' => $exam->exam_duration,
        'pass_mark' => $exam->pass_mark,
        'exam_attempt' => $exam->exam_attempt,
        'role_name' => $exam->role_name,
        'level' => $level,
        'total_marks' => $totalMarks, // <-- added total marks
        'question_count' => $exam->question_count,
        'badge_image_url' => file_exists(public_path('exam/badges/' . $exam->badge_image))
          ? asset('exam/badges/' . $exam->badge_image)
          : asset('assets/eapl_images/gray-badge.png'),
        'attempts' => $attempts
      ]
    ]);
  }

  /** Helper to convert numbers to ordinal (1st, 2nd, 3rd, ...) */
  private function getOrdinalSuffix($number)
  {
    $ends = ['th', 'st', 'nd', 'rd', 'th', 'th', 'th', 'th', 'th', 'th'];
    if (($number % 100) >= 11 && ($number % 100) <= 13)
      return $number . 'th';
    else
      return $number . $ends[$number % 10];
  }

  private function formatDuration($time)
  {
    if (!$time) return '-';

    [$h, $m, $s] = explode(':', $time);

    $result = '';

    if ($h > 0) $result .= $h . ' hr ';
    if ($m > 0) $result .= $m . ' min ';
    if ($s > 0) $result .= $s . ' sec';

    return trim($result);
  }
}
