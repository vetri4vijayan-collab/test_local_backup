<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\ComposeEmail; // Import the Mailable class
use Illuminate\Http\Request;
use App\Models\CugManagementModel;
use App\Models\GmailModel;
use Illuminate\Support\Facades\Mail; // Import the Mail facade
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class ManageGmail extends Controller
{
    public function index(Request $request)
    {
        $branchId = $request->user()->branch_id;
    
        $staff_mail = CugManagementModel::where('za_cug_management.branch_id', $branchId)
            ->where('za_cug_management.status', 0)
            ->get();
    
        $groupedByCreId = $staff_mail->groupBy('cre_id');
    
        return view('content.manage_gmail.manage_gmail_list', ['groupedByCreId' => $groupedByCreId]);
    }   
    
    public function getToMails(Request $request)
    {
        $mailId = $request->mail_id;
        // return $mailId;

        $toMails = DB::table('za_gmail')
            ->where('to_mail', $mailId)->orderBy('sent_date', 'DESC')->get();
            // ->pluck('to_mail');

        // return $toMails;

        return response()->json($toMails);
    }

    public function showComposeForm()
    {

        // Assuming $groupedByCreId is passed here from the controller
        return view('content.manage_gmail.compose', [
            'groupedByCreId' => $this->getGroupedEmailAddresses(),  // Replace with actual data fetching logic
        ]);
    }

    
    public function sendEmail(Request $request)
    {
        $branch_id = $request->user()->branch_id;
    
        // 1. Validate selected emails
        $selectedEmails = $request->emailContacts ?? [];
        $selectedEmails = array_filter($selectedEmails, function ($email) {
            return filter_var($email, FILTER_VALIDATE_EMAIL);
        });
    
        // 2. Fetch allowed emails for branch
        $allowedEmails = CugManagementModel::where('branch_id', $branch_id)
            ->where('status', 0)
            ->get()
            ->flatMap(function ($contact) {
                return array_filter([
                    $contact->cre_mail_id,
                    $contact->staff_mail_id
                ], fn($email) => filter_var($email, FILTER_VALIDATE_EMAIL));
            })->toArray();
    
        // 3. Filter selected by allowed
        $email_addresses = array_values(array_intersect($selectedEmails, $allowedEmails));
    
        if (empty($email_addresses)) {
            return response()->json(['message' => 'No valid email addresses found for this branch.'], 404);
        }
    
        // 4. Get other request data
        $subject = $request->subject ?? '';
        $messageContent = $request->email_body ?? '';
        $senderEmail = $request->user()->email;
    
        $attachmentNames = [];
        $storedFilePaths = [];
        
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('attachments');
                $storedFilePaths[] = $path;
                $attachmentNames[] = basename($path);
            }
        }

        $attachmentType = count($attachmentNames) > 1 ? 'multiple' : (count($attachmentNames) === 1 ? 'single' : 'none');
    
        // 6. CC/BCC (filter + assign)
        $cc = array_filter($request->cc ?? [], fn($email) => filter_var($email, FILTER_VALIDATE_EMAIL));
        $bcc = array_filter($request->bcc ?? [], fn($email) => filter_var($email, FILTER_VALIDATE_EMAIL));
    
        try {
            // 7. Send email (To, CC, BCC)
            Mail::send([], [], function ($message) use ($email_addresses, $subject, $messageContent, $storedFilePaths, $cc, $bcc) {
                $message->to($email_addresses)
                        ->subject($subject)
                        ->html($messageContent);
            
                if (!empty($cc)) {
                    $message->cc($cc);
                }
            
                if (!empty($bcc)) {
                    $message->bcc($bcc);
                }
            
                if (!empty($storedFilePaths)) {
                    foreach ($storedFilePaths as $path) {
                        $message->attach(storage_path("app/{$path}"));
                    }
                }
            });            
    
            // 8. Save to DB
            foreach ($email_addresses as $email) {
                \DB::table('za_gmail')->insert([
                    'to_mail' => $email,
                    'subject_mail' => $subject,
                    'body_mail' => $messageContent,
                    'sent_date' => now(),
                    'attachment' => json_encode($attachmentNames),
                    'from_mail' => $senderEmail,
                    'attachment_type' => $attachmentType,
                    'cc_mail' => json_encode($cc),
                    'bcc_mail' => json_encode($bcc),
                ]);
            }
    
            return redirect('/manage_gmail');
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Mail sent successfully!'
            ]);
    
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to send email: ' . $e->getMessage()
            ], 500);
        }
    }

    public function inboxView(Request $request)
    {
        $mail_sno = $request->id;
        $mail_details = GmailModel::where('sno', $mail_sno)->first();
    
        if ($mail_details) {
            return response()->json($mail_details);
        } else {
            return response()->json(['error' => 'Mail not found.'], 404);
        }
    }
    
    
 
}