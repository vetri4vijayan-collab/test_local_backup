<?php

namespace App\Http\Controllers\corporate_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CollegeModel;
use App\Models\StaffModel;
use App\Models\TrainingDatabaseModel;
use App\Models\CorporateSettingsModel;
use App\Models\CorporateModel;
use App\Models\CorporateSwappStaffHistoryModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\TransactionModel;
use App\Models\LedgerModel;
use App\Models\SubLedgerModel;
use App\Models\BranchModel;

use App\Models\CorporateParticipateModel;
use App\Models\CorporateParticipateAttModel;

use App\Models\Student;
use App\Models\ExamModel;
use App\Models\TypeofExamModel;

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use App\Models\WhatsappApiConfigureModel;
use DateTime;
use App\Models\EmailTemplateModel;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

use App\Models\LetterPadModel;

class ManageCorporate extends Controller
{
  
  private static $CORPORATE_TYPE_ID = 2;
  private static $CORPORATE_EMAIL_TEMPLATE_ID = 22;
  private static $CORPORATE_FEEDBACK_EMAIL_TEMPLATE_ID = 23;
  private static $CORPORATE_CERTIFICATE_EMAIL_TEMPLATE_ID = 24;
  private static $CORPORATE_JOIN_TRAINING_EMAIL_TEMPLATE_ID = 27;
   
  private static $CORPORATE_ASSESSMENT_CHOTTA_LINK_ID = 20;
  private static $CORPORATE_FEEDBACK_CHOTTA_LINK_ID = 19;
  private static $CORPORATE_CERTIFICATE_CHOTTA_LINK_ID = 15;
 private static $CORPORATE_QR_PART_ADD_CHOTTA_LINK_ID = 19;

  public function index(Request $request)
  {

    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $pageConfigs = ['myLayout' => 'default'];
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $filter_on = $request->input('filter_on', '0');
    $current_date = date('Y-m-d');
    
    $filter_fill = $request->filter_fill ?? '';
    $search_org_type = $request->search_org_type ?? null;
    $search_assign_staff_type = $request->search_assign_staff_type ?? '';
    $search_staff_id = $request->search_staff_id ?? '';
    $dt_fill_issue_rpt = $request->dt_fill_issue_rpt ?? '';
    $corp_custom_from_dt_fill = $request->corp_custom_from_dt_fill ?? '';
    $corp_custom_to_dt_fill = $request->corp_custom_to_dt_fill ?? '';

    $requirements = CorporateModel::select('za_corporate.*')->where('branch_id',$branch_id)->where('status','!=',2)->orderBy('za_corporate.sno', 'desc');



    // Handle joins carefully depending on filters
    if ($search_org_type == 2) {
      $requirements->where('za_corporate.organization_type', 2);
      if ($filter_fill != '') {
        $requirements->join('za_corporate_settings', 'za_corporate.corporate_id', '=', 'za_corporate_settings.sno')
        ->where('za_corporate_settings.corporate_name', 'LIKE', "%{$filter_fill}%");
      }
    } else if ($search_org_type == 1) {
      $requirements->where('za_corporate.organization_type', 1);
      if ($filter_fill != '') {
        $requirements->join('za_college', 'za_corporate.college_id', '=', 'za_college.sno')
        ->where('za_college.college_name', 'LIKE', "%{$filter_fill}%");
      }
    } else {
      if ($filter_fill != '') {
        $requirements->where('za_corporate.training_name', 'LIKE', "%{$filter_fill}%");
      }
    }

    // Staff assignment filter (uncomment and adjust if needed)
    if ($search_assign_staff_type == 1) {
        $requirements->where('za_corporate.staff_assign_type', '=', 1);
        if ($search_staff_id != '') {
          $requirements->whereJsonContains('za_corporate.staff_id', $search_staff_id);
        }
    } elseif ($search_assign_staff_type == 2) {
        $requirements->where('za_corporate.staff_assign_type', '=', 2);
        if ($search_staff_id != '') {
          $requirements->whereJsonContains('za_corporate.staff_id', $search_staff_id);
        }
    }

    // Date filters
    if ($dt_fill_issue_rpt == "today") {
        $todayDate = date("Y-m-d");
        $requirements->whereDate('za_corporate.start_date', $todayDate);
    } elseif ($dt_fill_issue_rpt == "week") {
        $today = date('l');
        if ($today == "Sunday") {
            $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
        } else {
            $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
            $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
        }
        $requirements->whereBetween('za_corporate.start_date', [$weekFromDate, $weekToDate]);
    } elseif ($dt_fill_issue_rpt == "monthly") {
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        $requirements->whereBetween('za_corporate.start_date', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($dt_fill_issue_rpt == "custom_date") {
        if ($corp_custom_from_dt_fill && $corp_custom_to_dt_fill) {
            $fromDate = date('Y-m-d', strtotime($corp_custom_from_dt_fill));
            $toDate = date('Y-m-d', strtotime($corp_custom_to_dt_fill));
            $requirements->whereBetween('za_corporate.start_date', [$fromDate, $toDate]);
        } elseif ($corp_custom_from_dt_fill) {
            $fromDate = date('Y-m-d', strtotime($corp_custom_from_dt_fill));
            $requirements->where('za_corporate.start_date', '>=', $fromDate);
        } elseif ($corp_custom_to_dt_fill) {
            $toDate = date('Y-m-d', strtotime($corp_custom_to_dt_fill));
            $requirements->where('za_corporate.start_date', '<=', $toDate);
        }
    }

    // If you have joins that can cause duplicates, add distinct()
    $requirements = $requirements->distinct()->paginate($perpage);

    $total_payment_amount = $total_paid_amount = $total_balance_amount = 0;

    if($requirements->isNotEmpty()){
      foreach ($requirements as $key => $requirements_data) {

        $payment_amount = isset($requirements_data->payment) && !empty($requirements_data->payment) ? $requirements_data->payment : 0;
        $total_payment_amount += $payment_amount ?? 0;
        $paid_amount = isset($requirements_data->paid) && !empty($requirements_data->paid) ? $requirements_data->paid : 0;
        $total_paid_amount += $paid_amount ?? 0;
        $total_balance_amount += $total_payment_amount - $total_paid_amount;
        $balance_amount = max($payment_amount - $paid_amount, 0);
        $requirements_data->balance = $balance_amount;
        
        $train_status = isset($requirements_data->status) && !empty($requirements_data->status) ? $requirements_data->status : 0;

        // Avoid division by zero
        $payment_percentage = ($payment_amount > 0) ? round(($paid_amount / $payment_amount) * 100, 2) : 0;

        if ($payment_percentage >= 100) {
            $payment_bar_color = 'bg-success';      // Fully paid
        } elseif ($payment_percentage >= 70) {
            $payment_bar_color = 'bg-warning';      // Partially paid
        } elseif ($payment_percentage > 0) {
            $payment_bar_color = 'bg-danger';       // Low payment
        } else {
            $payment_bar_color = 'bg-secondary';    // No payment
        }

        $requirements_data->payment_percentage = $payment_percentage;
        $requirements_data->payment_bar_color = $payment_bar_color;

        $startDate = strtotime($requirements_data->start_date);
        $endDate   = strtotime($requirements_data->end_date);
        $today     = strtotime(date('Y-m-d'));

        /* ---------- ATTENDANCE BASED CALCULATION ---------- */

        // Total expected training days
        $total_training_days = (int) ($requirements_data->total_days ?? 0);

        // Count unique attendance dates
        $attended_days = CorporateParticipateAttModel::where('corp_campus_id', $requirements_data->sno)
            ->where('status', '!=', 2)
            ->distinct('att_date')
            ->count('att_date');

        // Calculate percentage
        $trainingPercentage = ($total_training_days > 0) ? round(($attended_days / $total_training_days) * 100, 2) : 0;

        // Cap at 100%
        $trainingPercentage = min($trainingPercentage, 100);

        /* ---------- PROGRESS UI STATUS ---------- */

        $training_bar_color = 'bg-secondary';
        $training_bar_status = 'None';

        if ($train_status < 3) {
          if ($trainingPercentage >= 100) {
            $training_bar_color  = 'bg-success';
            $training_bar_status = 'Completed';
          } elseif ($trainingPercentage >= 70) {
              $training_bar_color  = 'bg-info';
              $training_bar_status = 'Ongoing';

          } elseif ($trainingPercentage >= 25) {
              $training_bar_color  = 'bg-warning';
              $training_bar_status = 'Ongoing';

          } elseif ($trainingPercentage > 0) {
              $training_bar_color  = 'bg-danger';
              $training_bar_status = 'Just Started';

          } else {
              $training_bar_color  = 'bg-secondary';
              $training_bar_status = 'Not yet Started';
          }
        }else if($train_status == 3){
          $training_bar_color  = 'bg-warning';
          $training_bar_status = 'Is Hold';
        }else if($train_status == 4){
          $training_bar_color  = 'bg-danger';
          $training_bar_status = 'Is Cancelled';
        }else if($train_status == 5){
          $training_bar_color  = 'bg-success';
          $training_bar_status = 'Completed';
        }else if($train_status == 6){
          $training_bar_color  = 'bg-success';
          $training_bar_status = 'Completed';
        }else if($train_status == 7){
          $training_bar_color  = 'bg-success';
          $training_bar_status = 'Completed';
        }

        $training_status_text = 'text-black';

        /* ---------- SAVE ---------- */

        $requirements_data->training_percentage  = $trainingPercentage;
        $requirements_data->training_bar_color   = $training_bar_color;
        $requirements_data->training_bar_status  = $training_bar_status;
        $requirements_data->training_status_text = $training_status_text;

        $requirements_staff_details = [];

        // Decode staff_id JSON
        $staffIds = isset($requirements_data->staff_id) && !empty($requirements_data->staff_id)
            ? json_decode($requirements_data->staff_id, true)
            : [];

        // Decode assign type JSON
        $assignTypes = isset($requirements_data->staff_assign_type) && !empty($requirements_data->staff_assign_type)
            ? json_decode($requirements_data->staff_assign_type, true)
            : [];

        $staff_image_path = null;

        // Loop through assign types
        foreach ($assignTypes as $assignType) {

            if ($assignType == "1" && !empty($staffIds['internal_staff_ids'])) {
                // Internal staff
                $assign_staff_details = StaffModel::whereIn('za_staff.sno', $staffIds['internal_staff_ids'])
                    ->get([
                        'za_staff.sno',
                        'za_staff.staff_name',
                        'za_staff.staff_image',
                        'za_staff.mobile_no',
                        'za_staff.email_id'
                    ]);
                $staff_image_path = 'staff_images/';
            } elseif ($assignType == "2" && !empty($staffIds['external_staff_ids'])) {
                // External staff
                $assign_staff_details = TrainingDatabaseModel::whereIn('za_training_database.sno', $staffIds['external_staff_ids'])
                    ->get([
                        'za_training_database.sno',
                        'za_training_database.trainer_name as staff_name',
                        'za_training_database.mobile_no',
                        'za_training_database.email_id',
                        'za_training_database.training_staff_image as staff_image'
                    ]);
                $staff_image_path = 'trainer_staff_images/';
            } else {
                $assign_staff_details = collect();
            }

            foreach ($assign_staff_details as $assign_staff_data) {
                $requirements_staff_details[] = [
                    'staff_sno' => $assign_staff_data->sno ?? null,
                    'staff_name' => $assign_staff_data->staff_name ?? null,
                    'staff_mobile_no' => $assign_staff_data->mobile_no ?? null,
                    'staff_email_id' => $assign_staff_data->email_id ?? null,
                    'staff_gender' => $assign_staff_data->gender ?? 1,
                    'staff_image' => $assign_staff_data->staff_image ?? null,
                    'staff_image_path' => $staff_image_path && isset($assign_staff_data->staff_image)
                        ? $staff_image_path . $assign_staff_data->staff_image
                        : null
                ];
            }
        }

        // Add to requirements_data
        $requirements_data->staff_details = $requirements_staff_details;

        $participate_list = CorporateParticipateModel::where('corp_campus_id', $requirements_data->sno)
        ->where('status', '!=', 2);
        
        $baseQuery = CorporateParticipateAttModel::where('corp_campus_id', $requirements_data->sno)->where('status', '!=', 2);

        $participate_att_count = (clone $baseQuery)->where('att_date', $current_date)->count();

        $add_att_count = $baseQuery->count();
        
        // Get all participants
        $participate_details = $participate_list->get();

        // Count participants
        $participate_count = $participate_details->count();

        // Total allowed participants from CorporateSettings
        $participate_total_count = isset($requirements_data->participate_count) && !empty($requirements_data->participate_count) ? (int)$requirements_data->participate_count : 0;
        $participate_start_date = isset($requirements_data->start_date) && !empty($requirements_data->start_date) ? date('Y-m-d', strtotime($requirements_data->start_date)) : '';
        $participate_end_date = isset($requirements_data->end_date) && !empty($requirements_data->end_date) ? date('Y-m-d', strtotime($requirements_data->end_date)) : '';
        $participate_start_time = isset($requirements_data->start_time) && !empty($requirements_data->start_time) ? date('H:i:s',strtotime($requirements_data->start_time)) : '';
        $participate_end_time = isset($requirements_data->end_time) && !empty($requirements_data->end_time) ? date('H:i:s',strtotime($requirements_data->end_time)) : '';

        $requirements_data->participate_details = $participate_details;
        $requirements_data->participate_total_count = $participate_total_count;
        $requirements_data->participate_added_count = $participate_count;
        
        // Available balance limit
        $participate_bal_count = $participate_total_count - $participate_count;

        $requirements_data->participate_bal_count = $participate_bal_count;

        $requirements_data->attendence_enabled = 0;
        $requirements_data->add_part_enabled = 0;
        $requirements_data->add_att_count_enabled = 0;
        $requirements_data->add_att_count = $add_att_count ?? 0;

        if (!empty($participate_start_date) && !empty($participate_end_date)) {
          if ($current_date >= $participate_start_date && $current_date <= $participate_end_date){ 
            $requirements_data->attendence_enabled = 1;
          }
        }
        
        if (!empty($participate_start_date)) {
          if ($current_date < $participate_start_date){ 
            $requirements_data->add_part_enabled = 1;
          }
        }
        
        if (!empty($participate_att_count)) {
          $requirements_data->add_att_count_enabled = 1;
        }

      }
    }

    // return $requirements;

    return view('content.corporate_management.manage_coporate_list', [
        'CorporateList' => $requirements,
        'pageConfigs' => $pageConfigs,
        'perpage' => $perpage,
        'filter_on' => $filter_on,
        'filter_fill' => $filter_fill,
        'search_org_type' => $search_org_type,
        'search_assign_staff_type' => $search_assign_staff_type,
        'search_staff_id' => $search_staff_id,
        'dt_fill_issue_rpt' => $dt_fill_issue_rpt,
        'corp_custom_from_dt_fill' => $corp_custom_from_dt_fill,
        'corp_custom_to_dt_fill' => $corp_custom_to_dt_fill,
        'total_payment_amount' => $total_payment_amount,
        'total_paid_amount' => $total_paid_amount,
        'total_balance_amount' => $total_balance_amount,
    ]);
  }

  public function certificate()
  {
    return view('content.corporate_management.certificate');
  }

  public function Add(Request $request)
  {
      /* =======================
        VALIDATION
      ======================= */
      $rules = [
          'organization_type' => 'required',
          'training_name' => 'required',
          'total_days' => 'required',
          'hours_per_day' => 'required',
          'start_date' => 'required',
          'end_date' => 'required',
          'start_time' => 'required',
          'end_time' => 'required',
          'pay_cost' => 'required',
          'session_type' => 'required',
          'gst_type' => 'required',
          'assign_staff' => 'required',
          'training_location' => 'required',
          'location_url' => 'required',
          'participate_count' => 'required',
          'program_details' => 'required',
      ];

      $validator = Validator::make($request->all(), $rules);

      if ($validator->fails()) {
          return response()->json([
              'status' => 'error',
              'errors' => $validator->errors(),
          ], 422);
      }

      /* =======================
        REQUEST DATA
      ======================= */
      $organization_type = $request->organization_type;
      $college_id   = $request->collage_id ?? null;
      $corporate_id = $request->corporate_id ?? null;

      $training_name = $request->training_name;
      $total_days    = $request->total_days ?? 0;
      $hours_per_day = $request->hours_per_day ?? 0;

      $start_date = $request->start_date;
      $end_date   = $request->end_date;
      $start_time = $request->start_time;
      $end_time   = $request->end_time;

      $pay_cost              = $request->pay_cost ?? 0;
      $total_base_payment    = $request->total_base_payment ?? 0;
      $total_gst_payment     = $request->total_gst_payment ?? 0;
      $total_overall_payment = $request->total_overall_payment ?? 0;

      $per_person_cost       = 0;
      $is_accessment_verify  = $request->is_accessment_verify ?? 0;
      $is_certificate_verify = $request->is_certificate_verify ?? 0;

      $session_type = $request->session_type ?? 1;
      $gst_type     = $request->gst_type ?? 1;

      $assign_staff = $request->assign_staff ?? null;

      /* =======================
        NORMALIZE STAFF JSON (IMPORTANT FIX)
      ======================= */
      $assigned_staff_json = $request->assigned_staff_json ?? null;
      if (is_string($assigned_staff_json)) {
          $assigned_staff_json = json_decode($assigned_staff_json, true);
      }

      $financial_staff_json = $request->selected_spoc_details ?? null;
      if (is_string($financial_staff_json)) {
          $financial_staff_json = json_decode($financial_staff_json, true);
      }

      $train_location    = $request->training_location ?? null;
      $location_url      = $request->location_url ?? null;
      $program_details   = $request->program_details ?? null;
      $participate_count = $request->participate_count ?? 0;

      $user_id   = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;

      /* =======================
        TRAINING CODE GENERATE
      ======================= */
      $category_check = CorporateModel::where('status', '!=', 2)
          ->orderBy('sno', 'desc')
          ->first();

      if (!$category_check) {
          $year = substr(date('y'), -2);
          $cor_training_id = 'CORP-0001/' . $year;
      } else {
          $slice = explode('/', $category_check->cor_training_id);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);
          $next_number = (int)$result + 1;
          $corp_code = sprintf('CORP-%04d', $next_number);
          $year = substr(date('y'), -2);
          $cor_training_id = $corp_code . '/' . $year;
      }

      DB::beginTransaction();

      try {

          /* =======================
            SAVE TRAINING
          ======================= */
          $newModule = new CorporateModel();
          $newModule->cor_training_id = $cor_training_id;
          $newModule->branch_id = $branch_id;
          $newModule->organization_type = $organization_type;

          if ($organization_type == 1) {
              $newModule->college_id = $college_id;
              $newModule->corporate_id = null;
          } else {
              $newModule->corporate_id = $corporate_id;
              $newModule->college_id = null;
          }

          $newModule->training_name = $training_name;
          $newModule->training_mobile = null;
          $newModule->is_assessment = $is_accessment_verify;
          $newModule->is_certification = $is_certificate_verify;
          $newModule->training_location = $train_location;
          $newModule->training_location_url = $location_url;
          $newModule->total_days = $total_days;
          $newModule->hours_per_day = $hours_per_day;
          $newModule->start_date = date('Y-m-d', strtotime($start_date));
          $newModule->end_date   = date('Y-m-d', strtotime($end_date));
          $newModule->start_time = date('H:i:s', strtotime($start_time));
          $newModule->end_time   = date('H:i:s', strtotime($end_time));
          $newModule->pay_cost = $pay_cost;
          $newModule->session_type = $session_type;
          $newModule->per_person_cost = $per_person_cost;
          $newModule->payment = $total_base_payment;
          $newModule->payment_gst = $total_gst_payment;
          $newModule->total_payment = $total_overall_payment;
          $newModule->gst_type = $gst_type;
          $newModule->staff_assign_type = !empty($assign_staff) ? json_encode($assign_staff) : null;
          $newModule->staff_id = !empty($assigned_staff_json) ? json_encode($assigned_staff_json) : null;
          $newModule->financial_auth_id = !empty($financial_staff_json) ? json_encode($financial_staff_json) : null;
          $newModule->participate_count = $participate_count;
          $newModule->program_details = $program_details;
          $newModule->created_by = $user_id;
          $newModule->status = 0;

          $newModule->save();

          /* =====================================================
            ✅ STAFF HISTORY (NORMAL SAVE)
          ===================================================== */

          if (!empty($assigned_staff_json) && is_array($assigned_staff_json)) {

              /* ---------- INTERNAL STAFF ---------- */
              if (
                  isset($assigned_staff_json['internal_staff_ids']) &&
                  is_array($assigned_staff_json['internal_staff_ids'])
              ) {

                  // Debug if needed
                  // dd($assigned_staff_json['internal_staff_ids']);

                  foreach ($assigned_staff_json['internal_staff_ids'] as $staffId) {

                      $history = new CorporateSwappStaffHistoryModel();
                      $history->branch_id = $branch_id;
                      $history->training_id = $newModule->sno;
                      $history->start_date = $newModule->start_date;
                      $history->end_date = $newModule->end_date;
                      $history->previous_staff_id = null;
                      $history->previous_staff_type = null;
                      $history->swap_staff_id = (int) $staffId;
                      $history->swap_staff_type = 1; // Internal
                      $history->created_by = $user_id;
                      $history->save();
                  }
              }

              /* ---------- EXTERNAL STAFF ---------- */
              if (
                  isset($assigned_staff_json['external_staff_ids']) &&
                  is_array($assigned_staff_json['external_staff_ids'])
              ) {

                  foreach ($assigned_staff_json['external_staff_ids'] as $staffId) {

                      $history = new CorporateSwappStaffHistoryModel();
                      $history->branch_id = $branch_id;
                      $history->training_id = $newModule->sno;
                      $history->start_date = $newModule->start_date;
                      $history->end_date = $newModule->end_date;
                      $history->previous_staff_id = null;
                      $history->previous_staff_type = null;
                      $history->swap_staff_id = (int) $staffId;
                      $history->swap_staff_type = 2; // External
                      $history->created_by = $user_id;
                      $history->save();
                  }
              }
          }

          DB::commit();

          session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Corporate & Campus added successfully!'
          ]);

          return redirect()->back();

      } catch (\Exception $e) {

          DB::rollBack();

          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not add the Corporate & Campus!'
          ]);

          return redirect()->back();
      }
  }

  public function Edit($id)
  {
    // return $id;
    $CorporateSettings = CorporateModel::where('sno', $id)
    ->where('status', '!=', 2)
    ->first();

    $current_date = date('Y-m-d');

    if ($CorporateSettings) {


      $CorporateListOptions = isset($CorporateSettings->participate_details) && !empty($CorporateSettings->participate_details) ? json_decode($CorporateSettings->participate_details, true) : [];
      $CorporateListStaffs = isset($CorporateSettings->staff_id) && !empty($CorporateSettings->staff_id) ? json_decode($CorporateSettings->staff_id, true) : [];
      $CorporateListStafftypes = isset($CorporateSettings->staff_assign_type) && !empty($CorporateSettings->staff_assign_type) ? json_decode($CorporateSettings->staff_assign_type, true) : [];
      $CorporateListSpocDetails = isset($CorporateSettings->financial_auth_id) && !empty($CorporateSettings->financial_auth_id) ? json_decode($CorporateSettings->financial_auth_id, true) : [];
      $train_start_date = isset($CorporateSettings->start_date) && !empty($CorporateSettings->start_date) ? date("Y-m-d",strtotime($CorporateSettings->start_date)) : '';
      $train_end_date = isset($CorporateSettings->end_date) && !empty($CorporateSettings->end_date) ? date("Y-m-d",strtotime($CorporateSettings->end_date)) : '';

      $participate_list = [];
      if(!empty($CorporateListOptions)){
        foreach ($CorporateListOptions as $item) {
          foreach ($item as $key => $details) {
            $participate_list[$key] = $details;  // append inner arrays
          }
        }
      }

      $CorporateSettings->selected_spoc_details = $CorporateListSpocDetails;
      $CorporateSettings->participate_details = $participate_list;
      $CorporateSettings->staff_assign_type = $CorporateListStafftypes;
      $CorporateSettings->staff_id = $CorporateListStaffs ?? null;
      $CorporateSettings->start_time = isset($CorporateSettings->start_time) && !empty($CorporateSettings->start_time) ? date("h:i A",strtotime($CorporateSettings->start_time)) : null;
      $CorporateSettings->end_time = isset($CorporateSettings->end_time) && !empty($CorporateSettings->end_time) ? date("h:i A",strtotime($CorporateSettings->end_time)) : null;
      $CorporateSettings->start_status = $current_date < $train_start_date ?? false;

      $CorporateSettings->attendence_enabled = 0;
      if (!empty($train_start_date) && !empty($train_end_date)) {
        if ($current_date >= $train_start_date && $current_date <= $train_end_date){ 
          $CorporateSettings->attendence_enabled = 1;
        }
      }

      return response()->json([
        'status' => 200,
        'data' => $CorporateSettings,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Corporate & Campus not found',
      ]);
    }
  }

  public function Update(Request $request)
  {
      $rules = [
          'cor_train_sno' => 'required',
          'update_organization_type' => 'required',
          'training_name' => 'required',
          'total_days' => 'required',
          'hours_per_day' => 'required',
          'pay_cost' => 'required',
          'session_type' => 'required',
          'update_gst_type' => 'required',
          'training_location' => 'required',
          'location_url' => 'required',
          'participate_count' => 'required',
          'program_details' => 'required',
      ];

      $validator = Validator::make($request->all(), $rules);

      if ($validator->fails()) {
          return response()->json([
              'status' => 'error',
              'errors' => $validator->errors(),
          ], 422);
      }

      DB::beginTransaction();

      try {

          $cor_train_sno = $request->cor_train_sno;
          $organization_type = $request->update_organization_type;
          $college_id = $request->collage_id ?? null;
          $corporate_id = $request->corporate_id ?? null;
          $training_name = $request->training_name;
          $total_days = $request->total_days ?? 0;
          $hours_per_day = $request->hours_per_day ?? 0;
          $start_date = $request->start_date;
          $end_date = $request->end_date;
          $start_time = $request->start_time;
          $end_time = $request->end_time;
          $pay_cost = $request->pay_cost ?? 0;
          $total_base_payment = $request->total_base_payment ?? 0;
          $total_gst_payment = $request->total_gst_payment ?? 0;
          $total_overall_payment = $request->total_overall_payment ?? 0;
          $per_person_cost = 0;
          $is_accessment_verify = $request->is_accessment_verify ?? 0;
          $is_certificate_verify = $request->is_certificate_verify ?? 0;
          $session_type = $request->session_type ?? 1;
          $gst_type = $request->update_gst_type ?? 1;
          $train_location = $request->training_location ?? null;
          $location_url = $request->location_url ?? null;
          $assign_staff = $request->update_assign_staff ?? null;

          $today = date('Y-m-d');

          /* ===== assigned staff ===== */
          $assigned_staff_json = isset($request->assigned_staff_json) && !empty($request->assigned_staff_json)
              ? json_decode($request->assigned_staff_json, true)
              : null;

          /* ===== financial staff ===== */
          $financial_staff_json = isset($request->selected_spoc_details) && !empty($request->selected_spoc_details)
              ? json_decode($request->selected_spoc_details, true)
              : null;

          $program_details = $request->program_details ?? null;
          $participate_count = $request->participate_count ?? 0;

          $user_id   = $request->user()->user_id;
          $branch_id = $request->user()->branch_id;

          $update_modal = CorporateModel::where('sno', $cor_train_sno)
              ->where('status', '!=', 2)
              ->lockForUpdate()
              ->firstOrFail();

          /* ===== update values ===== */

          $update_modal->organization_type = $organization_type;

          if ($organization_type == 1) {
              $update_modal->college_id = $college_id;
              $update_modal->corporate_id = null;
          } else {
              $update_modal->corporate_id = $corporate_id;
              $update_modal->college_id = null;
          }

          $update_modal->training_name = $training_name;
          $update_modal->training_mobile = null;
          $update_modal->is_assessment = $is_accessment_verify;
          $update_modal->is_certification = $is_certificate_verify;
          $update_modal->training_location = $train_location;
          $update_modal->training_location_url = $location_url;
          $update_modal->total_days = $total_days;
          $update_modal->hours_per_day = $hours_per_day;
          $update_modal->pay_cost = $pay_cost;
          $update_modal->payment = $total_base_payment;
          $update_modal->payment_gst = $total_gst_payment;
          $update_modal->total_payment = $total_overall_payment;
          $update_modal->session_type = $session_type;
          $update_modal->per_person_cost = $per_person_cost;
          $update_modal->gst_type = $gst_type;


          if ($today < $update_modal->start_date && !empty($assigned_staff_json)) {

            $update_modal->start_date = date('Y-m-d', strtotime($start_date));
            $update_modal->end_date = date('Y-m-d', strtotime($end_date));
            $update_modal->start_time = date('H:i:s', strtotime($start_time));
            $update_modal->end_time = date('H:i:s', strtotime($end_time));

            $update_modal->staff_assign_type = !empty($assign_staff) ? json_encode($assign_staff) : null;

            /* ===== save staff jsons ===== */
            $update_modal->staff_id = !empty($assigned_staff_json)
                ? json_encode($assigned_staff_json)
                : null;

          }

          $update_modal->financial_auth_id = !empty($financial_staff_json)
              ? json_encode($financial_staff_json)
              : null;

          $update_modal->participate_count = $participate_count;
          $update_modal->program_details = $program_details;
          $update_modal->updated_by = $user_id;

          $update_modal->save();

          /* =====================================================
            ✅ STAFF HISTORY (NORMAL SAVE)
          ===================================================== */

          if ($today <= $update_modal->start_date && !empty($assigned_staff_json)) {

              $staffTypes = [
                  'internal_staff_ids' => 1,
                  'external_staff_ids' => 2,
              ];

              foreach ($staffTypes as $key => $type) {

                  if (!empty($assigned_staff_json[$key]) && is_array($assigned_staff_json[$key])) {

                      // Deactivate old staff of this type
                      CorporateSwappStaffHistoryModel::where([
                          'training_id' => $update_modal->sno,
                          'swap_staff_type' => $type,
                          'status' => 0,
                          'branch_id' => $branch_id,
                      ])->update([
                          'status' => 2,
                          'updated_at' => now(),
                          'updated_by' => $user_id,
                      ]);

                      foreach ($assigned_staff_json[$key] as $staffId) {

                          $history = CorporateSwappStaffHistoryModel::where([
                              'branch_id' => $branch_id,
                              'training_id' => $update_modal->sno,
                              'swap_staff_id' => (int) $staffId,
                              'swap_staff_type' => $type,
                              'status' => 2,
                          ])->first();

                          if ($history) {
                              // Update existing
                              $history->start_date = $update_modal->start_date;
                              $history->end_date = $update_modal->end_date;
                              $history->updated_by = $user_id;
                              $history->status = 0;
                              $history->save();
                          } else {
                              $history = new CorporateSwappStaffHistoryModel();
                              $history->branch_id = $branch_id;
                              $history->training_id = $update_modal->sno;
                              $history->start_date = $update_modal->start_date;
                              $history->end_date = $update_modal->end_date;
                              $history->previous_staff_id = null;
                              $history->previous_staff_type = null;
                              $history->swap_staff_id = (int) $staffId; // must not be null
                              $history->swap_staff_type = $type;
                              $history->created_by = $user_id;
                              $history->created_at = now();
                              $history->save();
                          }
                      }
                  }
              }
          }

          DB::commit();

          session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Corporate & Campus Updated successfully!'
          ]);

      } catch (\Throwable $e) {

          DB::rollBack();

          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not update the Corporate & Campus!'
          ]);

          throw $e; // remove if you don’t want exception bubbling
      }

      return redirect()->back();
  }

  public function View_details($id, Request $request)
  {
    $CorporateSettings = CorporateModel::where('sno', $id)
    ->where('status', '!=', 2)
    ->first();
    
    $details_type = $request->details_type ?? 1;

    $helper = new \App\Helpers\Helpers();
    
    if ($CorporateSettings) {

      $CorporateListOptions = isset($CorporateSettings->participate_details) && !empty($CorporateSettings->participate_details) ? json_decode($CorporateSettings->participate_details, true) : [];
      $CorporateTrans_details = isset($CorporateSettings->transaction_all) && !empty($CorporateSettings->transaction_all) ? json_decode($CorporateSettings->transaction_all, true) : null;

      $participate_list = CorporateParticipateModel::where('corp_campus_id', $CorporateSettings->sno)
    ->where('status', '!=', 2);

      // Get all participants
      $participate_details = $participate_list->get();

      // Count participants
      $participate_count = $participate_details->count();

      // Total allowed participants from CorporateSettings
      $participate_total_count = !empty($CorporateSettings->participate_count)
          ? (int)$CorporateSettings->participate_count
          : 0;

      // Available balance limit
      $participate_bal_count = $participate_total_count - $participate_count;

      $requirements_staff_details = [];

      // Decode assign types and staff IDs
      $staffIds = isset($CorporateSettings->staff_id) && !empty($CorporateSettings->staff_id) 
          ? json_decode($CorporateSettings->staff_id, true) 
          : [];

      $assignTypes = isset($CorporateSettings->staff_assign_type) && !empty($CorporateSettings->staff_assign_type) 
          ? json_decode($CorporateSettings->staff_assign_type, true) 
          : [];

      $staffAssignTypeLabels = array_map(function ($typeId) use ($helper) {
        return $helper->getCorpAssignStaffType($typeId) ?? 'Unknown';
      }, $assignTypes);

      foreach ($assignTypes as $assignType) {

          if ($assignType == "1" && !empty($staffIds['internal_staff_ids'])) {
              // Internal staff
              $staffList = StaffModel::whereIn('za_staff.sno', $staffIds['internal_staff_ids'])
                  ->get([
                      'za_staff.sno',
                      'za_staff.staff_name',
                      'za_staff.staff_image',
                      'za_staff.mobile_no',
                      'za_staff.email_id'
                  ]);

              $prefix = 'internal_';
              $image_path = 'staff_images/';
          } elseif ($assignType == "2" && !empty($staffIds['external_staff_ids'])) {
              // External staff
              $staffList = TrainingDatabaseModel::whereIn('za_training_database.sno', $staffIds['external_staff_ids'])
                  ->get([
                      'za_training_database.sno',
                      'za_training_database.trainer_name as staff_name',
                      'za_training_database.mobile_no',
                      'za_training_database.email_id',
                      'za_training_database.training_staff_image as staff_image'
                  ]);

              $prefix = 'external_';
              $image_path = 'trainer_staff_images/';
          } else {
              $staffList = collect();
              $prefix = '';
              $image_path = '';
          }

          foreach ($staffList as $staff) {
              $slugId = $prefix . $staff->sno;

              $image_full_path = $image_path && isset($staff->staff_image) ? $image_path . $staff->staff_image : null;

              $requirements_staff_details[] = [
                  'staff_sno' => $staff->sno ?? null,
                  'staff_slug_id' => $slugId,
                  'staff_name' => $staff->staff_name ?? null,
                  'staff_mobile_no' => $staff->mobile_no ?? null,
                  'staff_email_id' => $staff->email_id ?? null,
                  'staff_image' => $staff->staff_image ?? null,
                  'staff_image_path' => $image_full_path,
                  'staff_img_html' => $image_full_path && file_exists(public_path($image_full_path))
                      ? '<div class="image-input image-input-circle me-1" data-kt-image-input="true">
                              <img src="' . asset($image_full_path) . '" alt="avatar" class="rounded-circle image-input-wrapper w-150px h-150px"/>
                        </div>'
                      : $helper->name_image(strtoupper(substr(($staff->staff_name ?? 'UN'), 0, 1)), 2),
                  'staff_type' => $assignType == 1 ? 'Internal Trainers' : 'External Trainers',
                  'staff_type_id' => $assignType
              ];
          }
      }


      $internalTrainers = [];
      $externalTrainers = [];

      foreach ($requirements_staff_details as $staff) {
        if (isset($staff['staff_type'])) {
          if ($staff['staff_type'] === 'Internal Trainers') {
              $internalTrainers[] = $staff;
          } elseif ($staff['staff_type'] === 'External Trainers') {
              $externalTrainers[] = $staff;
          }
        }
      }

      $attended_days = CorporateParticipateAttModel::where('corp_campus_id', $CorporateSettings->sno)
                      ->where('status', '!=', 2)
                      ->select('att_date')
                      ->distinct()
                      ->pluck('att_date');


      $details_array = [
        'sno' => $CorporateSettings->sno ?? 0,
        'training_id' => $CorporateSettings->cor_training_id ?? null,
        'training_name' => $CorporateSettings->training_name ?? null,
        'total_days' => isset($CorporateSettings->total_days) && $CorporateSettings->total_days > 0 ? str_pad($CorporateSettings->total_days, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->total_days == 1 ? ' Day ' : ' Days ') : '00',
        'hours_per_day' => isset($CorporateSettings->hours_per_day) && $CorporateSettings->hours_per_day > 0 ? str_pad($CorporateSettings->hours_per_day, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->hours_per_day == 1 ? ' Hour ' : ' Hours ') : '00',
        'start_date' => date('d-M-Y', strtotime($CorporateSettings->start_date)) ?? null,
        'end_date' => date('d-M-Y', strtotime($CorporateSettings->end_date)) ?? null,
        'start_time' => date('h:i A', strtotime($CorporateSettings->start_time)) ?? null,
        'end_time' => date('h:i A', strtotime($CorporateSettings->end_time)) ?? null,
        'pay_cost' => isset($CorporateSettings->pay_cost) && !empty($CorporateSettings->pay_cost) ? number_format($CorporateSettings->pay_cost, 0) : '0',
        'total_amount' => isset($CorporateSettings->payment) && !empty($CorporateSettings->payment) ? $CorporateSettings->payment : '0',
        'total_paid' => isset($CorporateSettings->paid) && !empty($CorporateSettings->paid) ? $CorporateSettings->paid : '0',
        'total_balance' => isset($CorporateSettings->balance) && !empty($CorporateSettings->balance) ? $CorporateSettings->balance : '0',
        'per_person_cost' => isset($CorporateSettings->per_person_cost) && !empty($CorporateSettings->per_person_cost) ? number_format($CorporateSettings->per_person_cost, 0) : '0',
        'session_type' => strtolower($helper->getCorpSessionType($CorporateSettings->session_type)) ?? null, //helper
        'organization_type' => $helper->getCorpOrgType($CorporateSettings->organization_type) ?? null, //helper
        'gst_type' => $helper->getCorpGstType($CorporateSettings->gst_type) ?? null, //helper
        'staff_assign_type' => $staffAssignTypeLabels ?? null, //helper
        'staff_assign_type_id' => isset($CorporateSettings->staff_assign_type) && !empty($CorporateSettings->staff_assign_type) ? json_decode($CorporateSettings->staff_assign_type, true) : ["1"],
        'staff_id' => $CorporateSettings->staff_id ?? null,
        'training_mobile' => $CorporateSettings->training_mobile ?? null,
        'program_details' => $CorporateSettings->program_details ?? null,
        // 'financial_staff_id' => $CorporateSettings->financial_auth_id ?? null,
        'participate_details' => $participate_details,
        'participate_added_count' => $participate_count,
        'transaction_details' => $CorporateTrans_details,
        'participate_count' => !empty($participate_total_count) ? $participate_total_count : 0,
        'participate_total_count' => !empty($participate_total_count) ? $participate_total_count : 0,
        'participate_bal_count' => !empty($participate_bal_count) ? $participate_bal_count : 0,
        'venue_id' => $CorporateSettings->venue_id ?? null,
        'staff_details' => $requirements_staff_details ?? null,
        'internalTrainers' => $internalTrainers ?? null,
        'externalTrainers' => $externalTrainers ?? null,
      ];

      $details_array['attended_days'] = $attended_days;

      
      $oraganization_name = null;

      if(isset($CorporateSettings->organization_type) && !empty($CorporateSettings->organization_type)){
        if($CorporateSettings->organization_type == 2){
          $oraganization_name = $helper->getCorporateSettingName($CorporateSettings->corporate_id) ?? null; //helper
        }else if($CorporateSettings->organization_type == 1){
          $oraganization_name = $helper->getCollegeName($CorporateSettings->college_id) ?? null; //helper
        }
      }

      $details_array['oraganization_name'] = $oraganization_name;

      return response()->json([
        'status' => 200,
        'data' => $details_array,
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'message' => 'Corporate & Campus not found',
      ]);
    }
  }

  public function College_list(Request $request)
  {
    $user_branch_id = (string) $request->user()->branch_id;

    // Get all colleges with status = 0
    $colleges = CollegeModel::where('status', 0)->orderBy('sno', 'desc')->get();

    // Filter colleges whose branch_id contains the user's branch_id
    $filtered_colleges = $colleges->filter(function ($college) use ($user_branch_id) {
        $branch_ids = json_decode($college->branch_id, true);
        return in_array($user_branch_id, $branch_ids);
    })->values(); // reset array keys

    if(!$filtered_colleges) {
      return response([
        'status' => 400,
        'message' => 'No Such Records !',
        'error_msg' => null,
        'data' => null
      ], 404);
    } else {
      return response([
        'status' => 200,
        'message' => 'College Fetched Successfully',
        'error_msg' => null,
        'data' => $filtered_colleges
      ], 200);
    }
  }

  public function Internal_staff_list(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $corpcampus_id = $request->corpcampus_id;

      // Get already assigned internal staff IDs
      $CorporateSettings = CorporateModel::where('sno', $corpcampus_id)
          ->where('status', '!=', 2)
          ->first();

      $assigned_staff_ids = isset($CorporateSettings->staff_id) && !empty($CorporateSettings->staff_id)
          ? json_decode($CorporateSettings->staff_id, true)['internal_staff_ids'] ?? []
          : [];

      // Fetch all internal staff except already assigned
      $staffs = StaffModel::where('status', 0)
          ->where('department_id', 1)
          ->where('branch_id', $branch_id)
          ->when(!empty($assigned_staff_ids), function ($q) use ($assigned_staff_ids) {
              $q->whereNotIn('sno', $assigned_staff_ids);
          })
          ->get();

      return response([
          'status' => $staffs->count() ? 200 : 400,
          'message' => $staffs->count() ? 'Internal Staffs Fetched Successfully' : 'No Such Records !',
          'data' => $staffs
      ]);
  }
  
  public function External_staff_list(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $corpcampus_id = $request->corpcampus_id;

      // Get already assigned external staff IDs
      $CorporateSettings = CorporateModel::where('sno', $corpcampus_id)
          ->where('status', '!=', 2)
          ->first();

      $assigned_staff_ids = isset($CorporateSettings->staff_id) && !empty($CorporateSettings->staff_id)
          ? json_decode($CorporateSettings->staff_id, true)['external_staff_ids'] ?? []
          : [];

      // Fetch all external staff except already assigned
      $staffs = TrainingDatabaseModel::where('status', 0)
          ->where('branch_id', $branch_id)
          ->when(!empty($assigned_staff_ids), function ($q) use ($assigned_staff_ids) {
              $q->whereNotIn('sno', $assigned_staff_ids);
          })
          ->get();

      return response([
          'status' => $staffs->count() ? 200 : 400,
          'message' => $staffs->count() ? 'External Staffs Fetched Successfully' : 'No Such Records !',
          'data' => $staffs
      ]);
  }

  public function Corporate_list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $staffs = CorporateSettingsModel::where('status', 0)->get();

    if(!$staffs) {
      return response([
        'status' => 400,
        'message' => 'No Such Records !',
        'error_msg' => null,
        'data' => null
      ], 404);
    } else {
      return response([
        'status' => 200,
        'message' => 'Corpoprate Fetched Successfully',
        'error_msg' => null,
        'data' => $staffs
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_CorporateModel         = CorporateModel::where('sno', $id)->first();
    $upd_CorporateModel->status = 2;
    $upd_CorporateModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Corporate & Campus Deleted Successfully!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {
    $upd_CorporateModel         = CorporateModel::where('sno', $id)->first();
    $upd_CorporateModel->status = $request->input('status', 0);
    $upd_CorporateModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Payment(Request $request, $id)
  {
    // return $request;
    $rules = [
      'pay_amount' => 'required|numeric|min:1',
      'transaction_all' => 'required|array',
      'payment_mode' => 'required|string',
      // 'reciptid' => 'required|string',
    ];

    $validator = Validator::make($request->all(), $rules);
    
    if ($validator->fails()) {
      return response()->json([
        'status' => 'error',
        'errors' => $validator->errors(),
      ], 422);
    }
  
    DB::beginTransaction();
  
    try {

      $intern = CorporateModel::findOrFail($id);
      $user_id = auth()->user()->id ?? 0;
      $branch_id = auth()->user()->branch_id;
      
      // STEP 1: Fetch all transaction_all fields from this branch
      $allInterns = CorporateModel::where('branch_id', $branch_id)
        ->whereNotNull('transaction_all')
        ->get(['transaction_all']);
      
      // STEP 2: Loop through all invoices and find the max number
      $lastInvoiceNumber = 2004;
      foreach ($allInterns as $internEntry) {
        $transactions = isset($internEntry->transaction_all) && !empty($internEntry->transaction_all) ? json_decode($internEntry->transaction_all, true) : [];
        if (is_array($transactions)) {
          foreach ($transactions as $txn) {
            if (!empty($txn['invoice_id']) && preg_match('/INV(\d+)/', $txn['invoice_id'], $matches)) {
              $num = (int)$matches[1];
              if ($num > $lastInvoiceNumber) {
                $lastInvoiceNumber = $num;
              }
            }
          }
        }
      }
      
      // STEP 3: Create next invoice number
      $prefix = "EA";
      $year = date("Y");
      $nextInvoiceNumber = (int)$lastInvoiceNumber + 1;
      $newInvoiceId = $prefix . '/' . $year . '/' . sprintf("INV%04d", $nextInvoiceNumber);
      
      // STEP 4: Append new transaction to THIS intern
      // $oldTransactions = [];
      $decoded = isset($intern->transaction_all) && !empty($intern->transaction_all) ? json_decode($intern->transaction_all, true) : [];
      $oldTransactions = !empty($decoded) && is_array($decoded) ? $decoded : [];
      
      $newTransaction = isset($request->transaction_all) && !empty($request->transaction_all) && is_array($request->transaction_all) ? $request->transaction_all : [];
      $newTransaction['payment_mode'] = isset($request->payment_mode) ? $request->payment_mode : 'NULL';
      $newTransaction['receipt_id'] = isset($request->reciptid) && !empty($request->reciptid) ? $request->reciptid : 'NULL';
      $newTransaction['invoice_id'] = $newInvoiceId;
      $newTransaction['timestamp'] = now();
      
      $oldTransactions[] = $newTransaction;
      
      // STEP 5: Update payment totals
      $inter_paid = isset($intern->paid) && !empty($intern->paid) ? floatval($intern->paid) : 0;
      $inter_payment = isset($intern->total_payment) && !empty($intern->total_payment) ? floatval($intern->total_payment) : 0;
      $req_pay_amount = isset($request->pay_amount) && !empty($request->pay_amount) ? floatval($request->pay_amount) : 0;

      $newPaidAmount = $req_pay_amount + $inter_paid;
      $newBalance    = $inter_payment - $newPaidAmount;

      $intern->paid = floatval($newPaidAmount);
      $intern->balance = floatval($newBalance);
      $intern->transaction_all = json_encode($oldTransactions);
      $intern->updated_by = $user_id;
      $intern->save();

      // Prepare subledger
      $branch = BranchModel::where('sno', $branch_id)->firstOrFail();
      $branch_code = isset($branch->city_short_code) && !empty($branch->city_short_code) ? $branch->city_short_code : 'NONE';

      $latestSubledger = SubLedgerModel::where('branch_id', $branch_id)->orderByDesc('sno')->first();
      if (empty($latestSubledger)) {
        $subledger_id = date("Y") . '/' . $branch_code . '/SUB2005';
      } else {
        $last = isset($latestSubledger->subledger_id) && !empty($latestSubledger->subledger_id) && is_string($latestSubledger->subledger_id) ? explode('/', $latestSubledger->subledger_id) : [date("Y"),'NONE','SUB2005'];
        $num = (int)preg_replace('/[^0-9]/', '', $last[2]) + 1;
        $subledger_id = date("Y") . '/' . $branch_code . '/' . sprintf("SUB%04d", $num);
      }

      $inter_name = isset($intern->training_name) && !empty($intern->training_name) ? ucfirst($intern->training_name) : 'UNKNOWN TRAINING NAME';
      $intern_id = isset($intern->cor_training_id) && !empty($intern->cor_training_id) ? $intern->cor_training_id : 'UNKNOWN TRAINING ID';
      
      //  return $branch_id;
      $subledger = SubLedgerModel::create([
        'ledger_id' => 1,
        'subledger_id' => $subledger_id,
        'subledger_name' => $inter_name . ' - ' . $intern_id,
        'subledger_desc' => 'Corporate & Campus Students fees',
        'branch_id' => $branch_id,
        'traning_sno' => $id,
        'created_by' => $user_id,
        'updated_by' => $user_id,
      ]);

      // Prepare transaction ID
      $latestTr = TransactionModel::where('customer_type', 3)->orderByDesc('sno')->first();
      if (empty($latestTr)) {
        $transaction_id = date("Y") . '/' . $branch_code . '/TRA2005';
      } else {
        $last = isset($latestTr->transaction_id) && !empty($latestTr->transaction_id) && is_string($latestTr->transaction_id) ? explode('/', $latestTr->transaction_id) : [date("Y"),'NONE','TRA2005'];
        $num = (int)preg_replace('/[^0-9]/', '', $last[2]) + 1;
        $transaction_id = date("Y") . '/' . $branch_code . '/' . sprintf("TRA%04d", $num);
      }

      $paidAmount = $request->pay_amount ?? 0;
      $tax = $paidAmount * (($branch->gst_percentage ?? 0) / 100);
      $total = $paidAmount + $tax;

      // Create transaction record
      TransactionModel::create([
        'branch_id' => $branch_id,
        'transaction_id' => $transaction_id,
        'transaction_type' => 'Credit',
        'transaction_name' => 'Corporate & Campus',
        'trans_source_id' => $intern_id,
        'ledger_id' => 1,
        'subledger_id' => isset($subledger->sno) && !empty($subledger->sno) ? $subledger->sno : NULL,
        'customer_type' => 3,
        'credit' => $paidAmount,
        'invoice_id' => $newInvoiceId,
        'receipt_id' => isset($request->reciptid) && !empty($request->reciptid) ? $request->reciptid : NULL,
        'training_id' => $id,
        'debit' => null,
        'tax' => $tax,
        'total_amount' => $total,
        'created_by' => $user_id,
        'updated_by' => $user_id,
      ]);

      DB::commit();

      return response()->json([
        'status' => 'success',
        'message' => 'Payment updated successfully',
      ]);

    } catch (\Throwable $e) {
      DB::rollBack();
      return response()->json([
        'status' => 'error',
        'message' => 'Payment update failed.',
        'error' => $e->getMessage(), // Actual error message
      ], 500);
    }
  }
  
  public function add_college_settings(Request $request)
  {
    // Validation
    $validator = Validator::make($request->all(), [
        'college_name'    => 'required|string',
        // 'college_mob_no'  => 'required|digits:10',
        // 'college_mail_id' => 'required|email',
        // 'auth_name'       => 'required|string',
        // 'auth_mob_no'     => 'required|digits:10',
        // 'auth_position'     => 'required',
        // 'branch_id'       => 'required|array|min:1',
        'spoc_details' => 'required|array',
        'spoc_details.*.spoc_name' => 'required',
        'spoc_details.*.spoc_mob_no' => 'required',
        'spoc_details.*.spoc_position' => 'required',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 400,
            'message'   => 'Validation failed',
            'error_msg' => $validator->messages(),
            'data'      => null,
        ], 400);
    }

    // Inputs
    $collegeName     = ucwords($request->college_name);
    // $collegeMobile   = $request->college_mob_no;
    // $collegeMailId   = $request->college_mail_id;
    // $authorityName   = $request->auth_name;
    // $authorityMobile = $request->auth_mob_no;
    // $authorityPosition = $request->auth_position;
    $branchId        = [(string)$request->user()->branch_id];
    // $collegeDesc     = $request->college_desc ?? NULL;
    $userId          = $request->user()->user_id;

    /* -------------------------------------------------------
      ✅ CHECK - Prevent Duplicate College for ANY Branch
      ------------------------------------------------------- */
    $chk = CollegeModel::where('college_name', $collegeName)
            ->where('status', '!=', 2)
            ->get()
            ->first(function ($item) use ($branchId) {

                $existingBranchIds = json_decode($item->branch_id, true) ?? [];

                // if ANY branch matches → existing record found
                return count(array_intersect($existingBranchIds, $branchId)) > 0;
            });

    if ($chk) {
      return response()->json([
        'status'    => 400,
        'message'   => 'College already exists for selected branch!',
        'error_msg' => 'Duplicate entry',
        'data'      => null,
      ], 400);
    }

    $user_details   = $request->input('spoc_details');
    // Process HR details
    $deliverablesJson = null;

    if (is_array($user_details)) {
      $indexed_options = [];
      foreach ($user_details as $index => $value) {
        if ($value !== '') {
            $indexed_options[] = [
                (string)((int)$index + 1) => $value
            ];
        }
      }
      $deliverablesJson = json_encode($indexed_options);
    }

    /* -------------------------------------------------------
      ✅ SAVE NEW RECORD
    ------------------------------------------------------- */

    $college = new CollegeModel();
    $college->college_name     = ucfirst($collegeName);
    // $college->college_mobile   = $collegeMobile;
    // $college->college_mail_id  = $collegeMailId;
    // $college->authority_name   = $authorityName;
    // $college->authority_mobile = $authorityMobile;
    $college->spoc_details     = $deliverablesJson;
    $college->branch_id        = json_encode($branchId);
    // $college->college_desc     = NULL;
    $college->created_by       = $userId;
    $college->updated_by       = $userId;
    $college->save();

    return response()->json([
      'status'    => 200,
      'message'   => 'College successfully added!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function add_corporate_settings(Request $request)
  {
    // Validation rules
    $rules = [
        'cmpy_name' => 'required',
        'cmpy_mob_no' => 'required',
        'cmpy_mail_id' => 'required',
        // 'cmpy_website' => 'required',
        'cmpy_address' => 'required',
        // 'auth_name' => 'required',
        // 'auth_mob_no' => 'required',
        'hr_details' => 'required|array',
        'hr_details.*.spoc_name' => 'required',
        'hr_details.*.spoc_mob_no' => 'required',
        'hr_details.*.spoc_position' => 'required',
    ];

    $validator = Validator::make($request->all(), $rules);

    if ($validator->fails()) {
      return response()->json([
        'status'    => 400,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->errors(),
        'data'      => null,
      ], 400);
    }

    // Inputs
    $cmpy_name      = $request->input('cmpy_name');
    $cmpy_mob_no    = $request->input('cmpy_mob_no');
    $cmpy_mail_id   = $request->input('cmpy_mail_id');
    // $cmpy_website   = $request->input('cmpy_website');
    $cmpy_address   = $request->input('cmpy_address');
    // $auth_name      = $request->input('auth_name');
    // $auth_mob_no    = $request->input('auth_mob_no');
    $user_details   = $request->input('hr_details');
    $user_id        = $request->user()->user_id;

    // Process HR details
    $deliverablesJson = null;

    if (is_array($user_details)) {
      $indexed_options = [];
      foreach ($user_details as $index => $value) {
        if ($value !== '') {
            $indexed_options[] = [
                (string)((int)$index + 1) => $value
            ];
        }
      }
      $deliverablesJson = json_encode($indexed_options);
    }

    // Check duplicate
    $existingModule = CorporateSettingsModel::where('corporate_name', ucwords($cmpy_name))
        ->where('mail_id', $cmpy_mail_id)
        ->where('mobile_no', $cmpy_mob_no)
        ->where('status', '!=', 2)
        ->first();

    if ($existingModule) {
        return response()->json([
            'status'    => 400,
            'message'   => 'Corporate already exists!',
            'error_msg' => 'Corporate already exists!',
            'data'      => null,
        ], 400);
    }

    // Insert
    $newModule = new CorporateSettingsModel();
    $newModule->corporate_name   = ucfirst($cmpy_name);
    $newModule->mail_id          = $cmpy_mail_id;
    $newModule->mobile_no        = $cmpy_mob_no;
    $newModule->address          = $cmpy_address;
    // $newModule->authority_name   = $auth_name;
    // $newModule->authority_mobile = $auth_mob_no;
    // $newModule->website_url      = $cmpy_website;
    $newModule->hr_details       = $deliverablesJson;
    $newModule->created_by       = $user_id;
    $newModule->status           = 0;

    if ($newModule->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Corporate added successfully!',
            'error_msg' => '',
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 400,
            'message'   => 'Failed to add corporate!',
            'error_msg' => 'Failed to add corporate!',
            'data'      => null,
        ], 400);
    }
  }

  public function Assign_participate_details(Request $request)
  {
      /* -------------------------------------------------
      | 1. VALIDATION
      * -------------------------------------------------*/
      $rules = [
          'assign_corpcampus_id' => 'required',
          'participate_details' => 'required|array',
          'participate_details.*.participate_name'   => 'required',
          'participate_details.*.participate_mob_no' => 'required',
          'participate_details.*.participate_mail'   => 'required|email',
          'participate_details.*.participate_dob'    => 'required',
          'participate_details.*.department_name'    => 'required',
          'participate_details.*.staff_id'            => 'required'
      ];

      $validator = Validator::make($request->all(), $rules);

      if ($validator->fails()) {
          return response()->json([
              'status'    => 422,
              'message'   => 'Incorrect format input fields',
              'error_msg' => $validator->errors(),
              'data'      => null
          ], 422);
      }

      /* -------------------------------------------------
      | 2. BASIC DATA
      * -------------------------------------------------*/
      $user_id   = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;

      $corp_campus_id = $request->assign_corpcampus_id;
      $participants   = $request->participate_details;

      $CorporateSettings = CorporateModel::where('sno', $corp_campus_id)
          ->where('status', '!=', 2)
          ->first();

      /* -------------------------------------------------
      | 3. PARTICIPATE CODE GENERATION
      * -------------------------------------------------*/
      $last = CorporateParticipateModel::orderBy('sno', 'desc')->first();

      $nextNumber = $last
          ? intval(preg_replace('/[^0-9]/', '', explode('/', $last->participate_id)[0])) + 1
          : 1;

      $year = date('y');

      /* -------------------------------------------------
      | 4. RESPONSE COLLECTION
      * -------------------------------------------------*/
      $successList = [];
      $errorList   = [];

      $branch_data = BranchModel::where('sno', $branch_id)->first();

      $branch_name = match ($branch_data->branch_type) {
        1 => $branch_data->branch_name,
        2 => $branch_data->franchise_name,
        default => ''
      };

      /* -------------------------------------------------
      | 5. PROCESS PARTICIPANTS
      * -------------------------------------------------*/
      foreach ($participants as $row) {

          $successMsg = [];
          $errorMsg   = [];

          $whatsappStatus = false;
          $emailStatus    = false;

          /* ---------------------------------------------
          | SAVE PARTICIPANT
          * ---------------------------------------------*/
          $participate_code = sprintf('CORPCAMP-%04d', $nextNumber) . '/' . $year;

          $participant = new CorporateParticipateModel();
          $participant->branch_id        = $branch_id;
          $participant->corp_campus_id   = $corp_campus_id;
          $participant->participate_id   = $participate_code;
          $participant->participate_name = $row['participate_name'];
          $participant->participate_mobile = $row['participate_mob_no'];
          $participant->participate_mail = $row['participate_mail'];
          $participant->participate_department = $row['department_name'];
          $participant->staff_id         = $row['staff_id'];
          $participant->staff_type       = $row['staff_type'] ?? null;
          $participant->participate_dob  = date('Y-m-d', strtotime($row['participate_dob']));
          $participant->created_by       = $user_id;
          $participant->created_at       = now();
          $participant->save();

          /* ---------------------------------------------
          | SEND WHATSAPP
          * ---------------------------------------------*/
          if (!empty($row['whatsapp_enabled'])) {

              try {

                if (isset($participant->participate_mobile) && !empty($participant->participate_mobile)) {

                  $participate_mobile = $participant->participate_mobile;

                  $templateName  = "corporate_training_information";

                  $hasHeader  = false; // Example flag: set based on template
                  $hasBody    = false; // Example flag: set based on template
                  $hasFooter  = false; // Example flag: set based on template
                  $hasButton  = false;
                  $components = [];
                  $couponCode = " ";

                  date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')

                  $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer

                  if ($templateName == 'corporate_training_information') {

                      $wtbranchNo    = $branch_data->mobile ?? '9677781155';
                      $wtbranchemail = $branch_data->mail ?? 'info@elysiumacademy.org';

                      $Link = $CorporateSettings->training_location_url;

                      $shortUrlData = $this->shortenUrl($Link, self::$CORPORATE_QR_PART_ADD_CHOTTA_LINK_ID ?? 19); //chennal_ID
                      $shortUrl     = $shortUrlData['shorturl'] ?? $Link;
                      $location_key = basename($shortUrl);

                      $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
                      $couponCode  = 'NOOFFER';
                      $buttonIndex = 1;
                      $bodyText    = [
                        [
                          'type'           => 'text',
                          'text'           =>  $participant->participate_name,
                          'parameter_name' => 'stu_name',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => $CorporateSettings->training_name ?? 'Corporate Training',
                          'parameter_name' => 'complete_name',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => $branch_name ?? 'Elysium Academy',
                          'parameter_name' => 'branch_name',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => date('d-M-Y', strtotime($CorporateSettings->start_date)),
                          'parameter_name' => 'start_date',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => date('d-M-Y', strtotime($CorporateSettings->end_date)),
                          'parameter_name' => 'end_date',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => $Link ?? '-',
                          'parameter_name' => 'location_url',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => $branch_data->cre_mobile ?? $branchNo,
                          'parameter_name' => 'contact_no',
                        ],
                        [
                          'type'           => 'text',
                          'text'           => $branch_data->cre_mail_id ?? $branchemail,
                          'parameter_name' => 'email_id',
                        ]
                      ];

                      $hasHeader = false;
                      $hasBody   = true;
                      $hasButton = true;
                  }

                  // return $bodyText;

                  // Add Header if required
                  if ($hasHeader) {
                    $components[] = [
                      'type'       => 'header',
                      'parameters' => [
                        [
                          'type'  => 'image',
                          'image' => [
                            'link' => $headerImage, // Dynamically set header image
                          ],
                        ],
                      ],
                    ];
                  }

                  // Add Body if required
                  if ($hasBody) {
                    $components[] = [
                      'type'       => 'body',
                      'parameters' => $bodyText,
                    ];
                  }

                  // Add Footer if required
                  if ($hasButton) {
                      $components[] = [
                          'type'       => 'button',
                          'sub_type'   => 'url',
                          'index'      => 0,
                          'parameters' => [
                              [
                                'type' => 'text',
                                'text' => $location_key,
                              ],
                          ],
                      ];
                  }
                  
                  $dynamicParameters         = $templateParameters[$templateName] ?? [];
                  $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
                  $accessToken               = $this->accessData($request)->access_tokken;
                  $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

                  $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

                  $mobile = preg_replace('/\D/', '', $participate_mobile); // remove any non-digits

                  if (strpos($participate_mobile, '+') === 0) {
                      $to = $participate_mobile;
                  } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                      $to = '+' . $mobile;
                  } else {
                      $to = '+91' . $mobile;
                  }

                  $languageCode = 'en';

                  $message = 'test~message';
                  if (empty($components)) {
                      $payload = [
                          'messaging_product' => 'whatsapp',
                          'to'                => $to,
                          'type'              => 'template',
                          'template'          => [
                              'name'     => $templateName,
                              'language' => [
                                  'code' => $languageCode,
                              ],
                          ],
                      ];
                  } else {
                      $payload = [
                          'messaging_product' => 'whatsapp',
                          'to'                => $to,
                          'type'              => 'template',
                          'template'          => [
                              'name'       => $templateName,
                              'language'   => [
                                  'code' => $languageCode,
                              ],
                              'components' => $components,
                          ],
                      ];
                  }

                  //  return $payload;
                  $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

                  if ($response['status'] == 200) {
                    $whatsappStatus = true;
                    $successMsg[] = 'WhatsApp sent';
                  } else {
                    $whatsappStatus = false;
                    $errorMsg[] = $response['error'];
                  }
                }
              } catch (\Exception $e) {
                $whatsappStatus = false;
                $errorMsg[] = 'WhatsApp failed';
              }
          }

          /* ---------------------------------------------
          | SEND EMAIL
          * ---------------------------------------------*/
          if (!empty($row['email_enabled'])) {
              try {

                if (isset($participant->participate_mail) && !empty($participant->participate_mail)) {

                  $email_template_id = self::$CORPORATE_JOIN_TRAINING_EMAIL_TEMPLATE_ID; // Feedback email template
                  $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

                  $Link = $CorporateSettings->training_location_url;

                  $shortUrlData = $this->shortenUrl($Link, self::$CORPORATE_QR_PART_ADD_CHOTTA_LINK_ID ?? 19); //chennal_ID
                  $shortUrl     = $shortUrlData['shorturl'] ?? $Link;

                  $content = $emailTemplate->email_subject;
                  $content = str_replace('#name', $participant->participate_name, $content);
                  $content = str_replace('#TrainingName', (!empty( $CorporateSettings->training_name) ? $CorporateSettings->training_name : '-'), $content);
                  $content = str_replace('#start_date', (date('d-M-Y', strtotime($CorporateSettings->start_date)) ?? '-'), $content);
                  $content = str_replace('#end_date', (date('d-M-Y', strtotime($CorporateSettings->end_date)) ?? '-'), $content);
                  $content = str_replace('#mode_location', ($Link ?? $shortUrl), $content);

                  
                  $branchNo    = $branch_data->mobile ?? '9677781155';
                  $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
                  $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                  $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';

                  $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? $branchNo, $content);
                  $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
                  $content = str_replace('#mail', $branch_data->cre_mail_id ?? $branchemail, $content);

                  $mailData = [
                    'url' => null,
                    'subject' => $emailTemplate->email_name,
                    'content' => $content,
                    'branchNo'    => $branchNo,
                    'branchemail' => $branchemail, // Use the message content from the request
                    'fbLink'      => $fbLink,      // Use the message content from the request
                    'instaLink'   => $instaLink,   // Use the message content from the request
                    'salesMobile' => $branch_data->sales_mobile ?? $branchNo,
                  ];

                  $to_address   = $participant->participate_mail;
                  $from_address = 'elysiumacademy@elysium.community';
                  $from_name    = 'Elysium Academy®';

                  Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
                  
                }

                $emailStatus = true;
                $successMsg[] = 'Email sent';
                
              } catch (\Exception $e) {
                $emailStatus = false;
                $errorMsg[] = 'Email failed';
              }
          }

          /* ---------------------------------------------
          | PARTICIPATE STATUS
          * ---------------------------------------------*/
          if (empty($row['whatsapp_enabled']) && empty($row['email_enabled'])) {
              $participateStatus = 'saved';
              $successMsg[] = 'Participant saved';
          } elseif ($whatsappStatus && $emailStatus) {
              $participateStatus = 'whatsapp_email_sent';
          } elseif ($whatsappStatus) {
              $participateStatus = 'whatsapp_sent';
          } elseif ($emailStatus) {
              $participateStatus = 'email_sent';
          } else {
              $participateStatus = 'failed';
          }

          /* ---------------------------------------------
          | RESPONSE ROW
          * ---------------------------------------------*/
          $rowResult = [
              'sno'                => $participant->sno,
              'participate_id'     => $participant->participate_id,
              'participate_name'   => $participant->participate_name,

              'whatsapp_enabled'   => !empty($row['whatsapp_enabled']),
              'email_enabled'      => !empty($row['email_enabled']),

              'whatsapp'           => $whatsappStatus,
              'email'              => $emailStatus,

              'participateStatus'  => $participateStatus,

              'success_msg'        => implode(', ', $successMsg),
              'error_msg'          => implode(', ', $errorMsg)
          ];

          if ($participateStatus !== 'failed') {
            $successList[] = $rowResult;
          } else {
            $errorList[] = $rowResult;
          }

        $nextNumber++;
      }

      /* -------------------------------------------------
      | 6. FINAL RESPONSE
      * -------------------------------------------------*/
      return response()->json([
          'status'  => 200,
          'message' => 'Participants processed successfully',
          'success_list' => $successList,
          'error_list'   => $errorList
      ], 200);
  }

  public function CorpParticipateDetails(Request $request)
  {
      /* ---------- Validation ---------- */
      if (empty($request->corp_campus_id)) {
          return response()->json([
              'status' => 422,
              'message' => 'corp_campus_id is required',
              'errors' => [
                  'corp_campus_id' => ['Corporate campus ID is missing']
              ]
          ], 422);
      }

      $helper = new \App\Helpers\Helpers();

      $perpage       = (int) $request->input('sorting_filter', 25);
      $filter_fill   = trim($request->att_search_fill ?? '');
      $staff_id      = $request->staff_id ?? '';
      $holiday_check = $request->holiday_check ?? 0;
      $corp_campus_id = $request->corp_campus_id ?? 0;

      /* ---------- Safe Date ---------- */
      $att_date = '';
      if (!empty($request->att_date)) {
          $att_date = date('Y-m-d', strtotime($request->att_date));
      }

      /* ---------- Base Query ---------- */
      $query = CorporateParticipateModel::select('za_corp_participate.*')
          ->where('za_corp_participate.status', 0)
          ->where('za_corp_participate.corp_campus_id', $corp_campus_id);

      /* ---------- Conditional JOIN ---------- */
      if ($corp_campus_id !== '' && $att_date !== '') {

          $query->leftJoin('za_corp_participate_attendance as ad', function ($join) use ($corp_campus_id, $att_date) {
              $join->on('ad.participate_id', '=', 'za_corp_participate.sno')
                  ->where('ad.corp_campus_id', $corp_campus_id)
                  ->whereDate('ad.att_date', '=', $att_date);
          });

          // Optional: select attendance fields
          $query->addSelect([
            'ad.attendance',
            'ad.att_date as attendance_date'
          ]);
      }

      /* ---------- Search Filter ---------- */
      if ($filter_fill !== '') {
        $query->where(function ($q) use ($filter_fill) {
            $q->where('za_corp_participate.participate_name', 'LIKE', "%{$filter_fill}%")
              ->orWhere('za_corp_participate.participate_mobile', 'LIKE', "%{$filter_fill}%")
              ->orWhere('za_corp_participate.participate_department', 'LIKE', "%{$filter_fill}%");
        });
      }

      /* ---------- Execute ---------- */
      $requirements = $query
          ->orderBy('za_corp_participate.participate_name', 'desc')
          ->paginate($perpage);

      /* ---------- Image Helper ---------- */
      if ($requirements->isNotEmpty()) {
        foreach ($requirements as $requirements_data) {
          $initial = strtoupper(substr($requirements_data->participate_name, 0, 1));
          $requirements_data->participate_image = $helper->name_image($initial, 2);
        }
      }

      /* ---------- Success ---------- */
      return response()->json([
          'status' => 200,
          'message' => 'Participant list fetched successfully',
          'data' => $requirements->items(),
          'filter_fill' => $filter_fill,
          'staff_id' => $staff_id,
          'att_date' => $att_date,
          'holiday_check' => $holiday_check,
          'pagination' => [
              'current_page' => $requirements->currentPage(),
              'per_page' => $requirements->perPage(),
              'total' => $requirements->total(),
              'last_page' => $requirements->lastPage(),
          ]
      ], 200);
  }

  public function AttCorpParticipateUpdate(Request $request)
  {    
    // Validation
    $rules = [
      'assign_corpcampus_id' => 'required',
      'att_date' => 'required',
      // 'staff_id' => 'required',
      'participate_details' => 'required|array',
      'participate_details.*.attendance' => 'required',
      'participate_details.*.part_att_id' => 'required',
    ];

    $validator = Validator::make($request->all(), $rules);

    if ($validator->fails()) {
      return response()->json([
        'status'    => 422,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->errors(),
        'data'      => null,
      ], 422);
    }

    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $corp_campus_id = $request->assign_corpcampus_id;
    $corp_att_date = $request->att_date;
    // $corp_staff_id = $request->staff_id;
    $participants   = $request->participate_details;

    foreach ($participants as $key => $row) {

      $existingModule = CorporateParticipateAttModel::where('branch_id', $branch_id)
        ->where('corp_campus_id', $corp_campus_id)
        ->where('participate_id', $row['part_att_id'])
        ->where('att_date', date('Y-m-d', strtotime($corp_att_date)))
        ->where('status', '!=', 2)
        ->first();

      if(!$existingModule){
        $save = new CorporateParticipateAttModel();
        $save->branch_id         = (int)$branch_id;
        $save->corp_campus_id    = (int)$corp_campus_id;
        $save->participate_id    = (int)$row['part_att_id'];
        $save->att_date           = date('Y-m-d', strtotime($corp_att_date));
        $save->staff_id          = 0;
        $save->attendance        = $row['attendance'];
        $save->created_at        = now();
        $save->created_by        = $user_id;
        $save->save();
      }else{
        $existingModule->attendance = $row['attendance'];
        $existingModule->updated_at        = now();
        $existingModule->updated_by        = $user_id;
        $existingModule->update();
      }
    }

    return response()->json([
      'status'    => 200,
      'message'   => 'Participants Attendance Updated successfully!',
      'error_msg' => '',
      'data'      => null,
    ], 200);
  }
  
  public function SwapStaffTrainers(Request $request)
  {
      $request->validate([
        'swap_staff_assign_corpcampus_id' => 'required|integer',
        'swap_staff_list' => 'required|array|min:1',
      ]);

      $swapList   = $request->swap_staff_list;
      $trainingId = $request->swap_staff_assign_corpcampus_id;

      $userId   = $request->user()->user_id;
      $branchId = $request->user()->branch_id;

      $training = CorporateModel::where('sno', $trainingId)->firstOrFail();

      DB::beginTransaction();

      try {

          /* ===========================
            EXISTING ACTIVE STAFF
          =========================== */
          $existingStaff = json_decode($training->staff_id, true) ?? [
              'internal_staff_ids' => [],
              'external_staff_ids' => [],
          ];

          $existingTypes = json_decode($training->staff_assign_type, true) ?? [];

          $internalIds = $existingStaff['internal_staff_ids'];
          $externalIds = $existingStaff['external_staff_ids'];

          /* ===========================
            PROCESS EACH SWAP
          =========================== */
          foreach ($swapList as $row) {

              /* ---------- EXPIRE OLD ---------- */
              CorporateSwappStaffHistoryModel::where([
                  'branch_id'       => $branchId,
                  'training_id'     => $trainingId,
                  'swap_staff_id'   => $row['previous_staff_id'],
                  'swap_staff_type' => $row['previous_staff_type'],
                  'status'          => 0,
              ])->update([
                  'status'     => 3,
                  'end_date'   => now()->toDateString(),
                  'updated_by' => $userId,
                  'updated_at' => now(),
              ]);

              CorporateParticipateModel::where([
                'branch_id'       => $branchId,
                'corp_campus_id'     => $trainingId,
                'staff_id'   => $row['previous_staff_id'],
                'staff_type' => $row['previous_staff_type'],
                'status'          => 0,
              ])->update([
                'staff_id'   => $row['swap_staff_id'],
                'staff_type' => $row['swap_staff_type'],
                'updated_by' => $userId,
                'updated_at' => now(),
              ]);


              /* ---------- INSERT NEW ---------- */
              $history = new CorporateSwappStaffHistoryModel();
              $history->branch_id           = $branchId;
              $history->training_id         = $trainingId;
              $history->start_date          = now()->toDateString();
              $history->end_date            = $training->end_date;
              $history->previous_staff_id   = $row['previous_staff_id'];
              $history->previous_staff_type = $row['previous_staff_type'];
              $history->swap_staff_id       = $row['swap_staff_id'];
              $history->swap_staff_type     = $row['swap_staff_type'];
              $history->status              = 0;
              $history->created_by          = $userId;
              $history->created_at          = now();
              $history->save();

              /* ---------- UPDATE ACTIVE LIST ---------- */

              if ($row['previous_staff_type'] == 1) {
                  $internalIds = array_diff($internalIds, [(string)$row['previous_staff_id']]);
              } else {
                  $externalIds = array_diff($externalIds, [(string)$row['previous_staff_id']]);
              }

              if ($row['swap_staff_type'] == 1) {
                  $internalIds[] = (string)$row['swap_staff_id'];
                  $existingTypes[] = "1";
              } else {
                  $externalIds[] = (string)$row['swap_staff_id'];
                  $existingTypes[] = "2";
              }
          }

          /* ===========================
            FINAL JSON UPDATE
          =========================== */
          $training->staff_id = json_encode([
              'internal_staff_ids' => array_values(array_unique($internalIds)),
              'external_staff_ids' => array_values(array_unique($externalIds)),
          ]);

          $training->staff_assign_type = json_encode(
              array_values(array_unique($existingTypes))
          );

          $training->save();

          DB::commit();

          return response()->json([
              'status'  => 200,
              'message' => 'Staff swapped successfully'
          ]);

      } catch (\Exception $e) {

          DB::rollBack();

          return response()->json([
              'status'  => 500,
              'message' => 'Swap failed',
              'error'   => $e->getMessage()
          ], 500);
      }
  }

  public function autocomplete_collage_corp(Request $request)
  {
    $assign_type = (int) ($request->assign_type ?? 2);
    $search = trim($request->term ?? '');

    if ($search === '') {
        return response()->json([]);
    }

    if ($assign_type === 2) {
        // Corporate autocomplete
        $results = CorporateSettingsModel::where('status', 0)
            ->where('corporate_name', 'LIKE', "%{$search}%")
            // ->limit(20)
            ->get([
                'sno',
                'corporate_name as name',
                'mobile_no as mobile',
                'mail_id as email',
                DB::raw("'corporate' as type")
            ]);
    } else {
        // College autocomplete
        $results = CollegeModel::where('status', 0)
            ->where('college_name', 'LIKE', "%{$search}%")
            // ->limit(20)
            ->get([
                'sno',
                'college_name as name',
                DB::raw("'college' as type")
            ]);
    }

    return response()->json($results);
  }

  public function get_spoc_details(Request $request)
  {
      $id = (int) ($request->id ?? 0);
      $assign_type = (int) ($request->type ?? 1);

      if (!$id) {
          return response()->json([
              'status'    => 400,
              'message'   => 'No Data Found',
              'error_msg' => 'Invalid ID',
              'data'      => null,
          ], 400);
      }

      /* ==============================
        FETCH DATA
      ============================== */

      if ($assign_type === 2) {
          // Corporate
          $results = CorporateSettingsModel::where('status', 0)
              ->where('sno', $id)
              ->first([
                  'sno',
                  'hr_details',
                  DB::raw("'corporate' as type")
              ]);

          $spoc_details = !empty($results?->hr_details)
              ? json_decode($results->hr_details, true)
              : [];
      } else {
          // College
          $results = CollegeModel::where('status', 0)
              ->where('sno', $id)
              ->first([
                  'sno',
                  'spoc_details',
                  DB::raw("'college' as type")
              ]);

          $spoc_details = !empty($results?->spoc_details)
              ? json_decode($results->spoc_details, true)
              : [];
      }

      /* ==============================
        POSITION MASTER (ONE QUERY)
      ============================== */

      if ($assign_type === 2) {
        $positions = DB::table('za_corporate_positions')
            ->where('status', 0)
            ->pluck('position_name', 'sno') // [sno => position_name]
            ->toArray();
      }else{
        $positions = DB::table('za_college_positions')
            ->where('status', 0)
            ->pluck('position_name', 'sno') // [sno => position_name]
            ->toArray();
      }

      /* ==============================
        MAP POSITION NAME
      ============================== */

      if (!empty($spoc_details)) {
          foreach ($spoc_details as &$spocItem) {
              foreach ($spocItem as $spocId => &$spoc) {

                  $positionId = $spoc['spoc_position'] ?? null;

                  $spoc['spoc_position_name'] =
                      $positions[$positionId] ?? null;
              }
          }
          unset($spocItem, $spoc); // good practice
      }

      /* ==============================
        RESPONSE
      ============================== */

      return response()->json([
          'status'    => 200,
          'message'   => 'Spoc Details Fetched!',
          'error_msg' => '',
          'data'      => [
              'sno'          => $results->sno,
              'type'         => $results->type,
              'spoc_details' => !empty($spoc_details) ? $spoc_details : null
          ]
      ], 200);
  }

  public function view_corp_campus($id, Request $request)
  {
      $helper = new \App\Helpers\Helpers();

      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

      if (!$decryptedValue) {
          abort(404, 'Invalid Campus ID');
      }

      $CorporateSettings = CorporateModel::where('sno', $decryptedValue)
          ->where('status', '!=', 2)
          ->first();

      if (!$CorporateSettings) {
          abort(404, 'Corporate Campus Not Found');
      }
      
      $details_type = $request->details_type ?? 1;

      $CorporateListOptions = !empty($CorporateSettings->participate_details)
          ? json_decode($CorporateSettings->participate_details, true)
          : [];

      $CorporateTrans_details = !empty($CorporateSettings->transaction_all)
          ? json_decode($CorporateSettings->transaction_all, true)
          : null;

      /* ---------------- PARTICIPANTS ---------------- */

      $participate_details = CorporateParticipateModel::where('corp_campus_id', $CorporateSettings->sno)
          ->where('status', '!=', 2)
          ->get();

      $participate_count = $participate_details->count();

      $participate_total_count = (int) ($CorporateSettings->participate_count ?? 0);
      $participate_bal_count   = max(0, $participate_total_count - $participate_count);

      /* ---------------- STAFF ASSIGNMENT ---------------- */

      $staffIds = !empty($CorporateSettings->staff_id)
          ? json_decode($CorporateSettings->staff_id, true)
          : [];

      $assignTypes = !empty($CorporateSettings->staff_assign_type)
          ? json_decode($CorporateSettings->staff_assign_type, true)
          : [];

      $staffAssignTypeLabels = array_map(fn ($typeId) =>
          $helper->getCorpAssignStaffType($typeId) ?? 'Unknown',
          $assignTypes
      );

      $requirements_staff_details = [];

      foreach ($assignTypes as $assignType) {

          if ($assignType == "1" && !empty($staffIds['internal_staff_ids'])) {

              $staffList = StaffModel::whereIn('sno', $staffIds['internal_staff_ids'])->get();
              $prefix = 'internal_';
              $image_path = 'staff_images/';

          } elseif ($assignType == "2" && !empty($staffIds['external_staff_ids'])) {

              $staffList = TrainingDatabaseModel::whereIn('sno', $staffIds['external_staff_ids'])->get();
              $prefix = 'external_';
              $image_path = 'trainer_staff_images/';

          } else {
              continue;
          }

          foreach ($staffList as $staff) {

              $image_full_path = !empty($staff->staff_image)
                  ? $image_path . $staff->staff_image
                  : null;

              $requirements_staff_details[] = [
                  'staff_sno'        => $staff->sno,
                  'staff_slug_id'   => $prefix . $staff->sno,
                  'staff_name'      => $staff->staff_name ?? $staff->trainer_name ?? null,
                  'staff_mobile_no' => $staff->mobile_no ?? null,
                  'staff_email_id'  => $staff->email_id ?? null,
                  'staff_image'     => $staff->staff_image ?? null,
                  'staff_image_path'=> $image_full_path,
                  'staff_img_html'  => ($image_full_path && file_exists(public_path($image_full_path)))
                      ? '<img src="'.asset($image_full_path).'" class="rounded-circle w-50 h-50">'
                      : $helper->name_image(strtoupper(substr($staff->staff_name ?? 'U', 0, 1)), 2),
                  'staff_type'      => $assignType == 1 ? 'Internal Trainers' : 'External Trainers',
                  'staff_type_id'   => $assignType
              ];
          }
      }

      $internalTrainers = array_values(array_filter($requirements_staff_details,
          fn($s) => $s['staff_type'] === 'Internal Trainers'
      ));

      $externalTrainers = array_values(array_filter($requirements_staff_details,
          fn($s) => $s['staff_type'] === 'External Trainers'
      ));

      /* ---------------- ORGANIZATION NAME ---------------- */

      $oraganization_name = null;

      if ($CorporateSettings->organization_type == 2) {
          $oraganization_name = $helper->getCorporateSettingName($CorporateSettings->corporate_id);
      } elseif ($CorporateSettings->organization_type == 1) {
          $oraganization_name = $helper->getCollegeName($CorporateSettings->college_id);
      }

      /* ---------------- FINAL DATA ---------------- */

      $details_array = [
          'sno'                     => $CorporateSettings->sno,
          'training_id'             => $CorporateSettings->cor_training_id,
          'training_name'           => $CorporateSettings->training_name,
          'start_date'              => date('d-M-Y', strtotime($CorporateSettings->start_date)),
          'end_date'                => date('d-M-Y', strtotime($CorporateSettings->end_date)),
          'start_time'              => date('h:i A', strtotime($CorporateSettings->start_time)),
          'end_time'                => date('h:i A', strtotime($CorporateSettings->end_time)),
          'staff_assign_type'       => $staffAssignTypeLabels,
          'staff_assign_type_id'    => $assignTypes,
          'staff_details'           => $requirements_staff_details,
          'internalTrainers'        => $internalTrainers,
          'externalTrainers'        => $externalTrainers,
          'participate_details'     => $participate_details,
          'participate_added_count' => $participate_count,
          'participate_total_count' => $participate_total_count,
          'participate_bal_count'   => $participate_bal_count,
          'transaction_details'     => $CorporateTrans_details,
          'oraganization_name'      => $oraganization_name,
          'total_days' => isset($CorporateSettings->total_days) && $CorporateSettings->total_days > 0 ? str_pad($CorporateSettings->total_days, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->total_days == 1 ? ' Day ' : ' Days ') : '00',
          'hours_per_day' => isset($CorporateSettings->hours_per_day) && $CorporateSettings->hours_per_day > 0 ? str_pad($CorporateSettings->hours_per_day, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->hours_per_day == 1 ? ' Hour ' : ' Hours ') : '00',
          'pay_cost' => isset($CorporateSettings->pay_cost) && !empty($CorporateSettings->pay_cost) ? number_format($CorporateSettings->pay_cost, 0) : '0',
          'total_amount' => isset($CorporateSettings->payment) && !empty($CorporateSettings->payment) ? $CorporateSettings->payment : '0',
          'total_paid' => isset($CorporateSettings->paid) && !empty($CorporateSettings->paid) ? $CorporateSettings->paid : '0',
          'total_balance' => isset($CorporateSettings->balance) && !empty($CorporateSettings->balance) ? $CorporateSettings->balance : '0',
          'per_person_cost' => isset($CorporateSettings->per_person_cost) && !empty($CorporateSettings->per_person_cost) ? number_format($CorporateSettings->per_person_cost, 0) : '0',
          'session_type' => strtolower($helper->getCorpSessionType($CorporateSettings->session_type)) ?? null, //helper
          'organization_type' => $helper->getCorpOrgType($CorporateSettings->organization_type) ?? null, //helper
          'gst_type' => $helper->getCorpGstType($CorporateSettings->gst_type) ?? null, //helper
          'staff_id' => $CorporateSettings->staff_id ?? null,
          'training_mobile' => $CorporateSettings->training_mobile ?? null,
          'program_details' => $CorporateSettings->program_details ?? null,
          'participate_count' => !empty($participate_total_count) ? $participate_total_count : 0
      ];

      return view(
          'content.corporate_management.corp_training_view',
          compact('details_array')
      );
  }

  public function training_ishold($id, Request $request)
  {
      $status        = (int) $request->input('hold_status');
      $reason_id     = $request->input('reason_id');
      $other_reason  = trim($request->input('other_reason'));
      $user_id       = $request->user()->id ?? null;

      $corporate = CorporateModel::where('sno', $id)->firstOrFail();

      $now = now()->format('Y-m-d H:i:s');

      // Casted JSON or fallback
      $holdStatus = is_string($corporate->hold_status) ? json_decode($corporate->hold_status,true) : ($corporate->hold_status ?? ['history' => []]);

      if (!isset($holdStatus['history']) || !is_array($holdStatus['history'])) {
          $holdStatus['history'] = [];
      }

      $action = ($status === 3) ? 'hold' : 'unhold';

      // Prevent duplicate consecutive actions
      $lastAction = end($holdStatus['history'])['action'] ?? null;

      if ($lastAction !== $action) {

          $historyRow = [
              'action'    => $action,
              'datetime'  => $now,
              'user_id'   => $user_id,
              'reason_id' => is_numeric($reason_id) ? (int) $reason_id : null,
              'other_reason' => null
          ];

          // If reason type is "other"
          if (empty($reason_id) && !empty($other_reason)) {
              $historyRow['other_reason'] = $other_reason;
          }

          $holdStatus['history'][] = $historyRow;
      }

      $corporate->status = $status;
      $corporate->hold_status = $holdStatus;
      $corporate->save();

      return response()->json([
          'status'  => 200,
          'message' => 'Status updated successfully',
          'data'    => $holdStatus
      ]);
  }

  public function training_isunhold($id, Request $request)
  {
      $status        = (int) $request->input('hold_status');
      $user_id       = $request->user()->id ?? null;

      $corporate = CorporateModel::where('sno', $id)->firstOrFail();

      $now = date('Y-m-d H:i:s');

      // Casted JSON or fallback
      $holdStatus = is_string($corporate->hold_status) ? json_decode($corporate->hold_status,true) : ($corporate->hold_status ?? ['history' => []]);

      if (!isset($holdStatus['history']) || !is_array($holdStatus['history'])) {
        $holdStatus['history'] = [];
      }

      $action = ($status === 3) ? 'hold' : 'unhold';

      // Prevent duplicate consecutive actions
      $lastAction = end($holdStatus['history'])['action'] ?? null;

      if ($lastAction !== $action) {

          $historyRow = [
              'action'    => $action,
              'datetime'  => $now,
              'user_id'   => $user_id,
              'reason_id' => null,
              'other_reason' => null
          ];

          $holdStatus['history'][] = $historyRow;
      }

      $corporate->status = $status;
      $corporate->hold_status = $holdStatus;
      $corporate->save();

      return response()->json([
          'status'  => 200,
          'message' => 'Status updated successfully',
          'data'    => $holdStatus
      ]);
  }

  public function training_iscancel($id, Request $request)
  {
    $status        = (int) $request->input('cancel_status');
    $reason_id     = $request->input('reason_id');
    $other_reason  = trim($request->input('other_reason'));
    $user_id       = $request->user()->id ?? null;

    $corporate = CorporateModel::where('sno', $id)->firstOrFail();

    $now = date('Y-m-d H:i:s');

    if (empty($reason_id) && !empty($other_reason)) {
      $corporate->cancel_reason_id = NULL;
      $corporate->cancel_reason = $other_reason;
    }else{
      $corporate->cancel_reason_id = $reason_id;
      $corporate->cancel_reason = NULL;
    }

    $corporate->status = $status;
    $corporate->updated_at = $now;
    $corporate->updated_by = $user_id;
    $corporate->save();

    return response()->json([
      'status'  => 200,
      'message' => 'Status updated successfully',
      'data'    => $corporate
    ]);
  }

  public function corporate_reasons_list(Request $request)
  {
    $assign_type = (int) ($request->type ?? 2);

    if ($assign_type === '') {
      return response()->json([
        'status'  => 400,
        'message' => 'Reason Not Found..!',
        'data'    => null
      ]);
    }

    $results = DB::table('za_corporate_reasons')->where('status', 0)
        ->where('za_corporate_reasons.reason_type', $assign_type)
        // ->limit(20)
        ->get([
            'za_corporate_reasons.sno',
            'za_corporate_reasons.reason'
        ]);

    return response()->json([
      'status'  => 200,
      'message' => 'Reason is Found..!',
      'data'    => $results
    ]);
  }

  public function get_corporate_exam_type_list(Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    if (!$user_id) {
      return response()->json([
        'status'  => 400,
        'message' => 'Exam Type Not Found..!',
        'data'    => null
      ]);
    }

    $results = DB::table('za_type_of_exam')->where('status', 0)
        // ->limit(20)
        ->get([
            'za_type_of_exam.sno',
            'za_type_of_exam.type_of_exam_name as exam_type_name'
        ]);

    return response()->json([
      'status'  => 200,
      'message' => 'Exam Type is Found..!',
      'data'    => $results
    ]);
  }

  public function get_corporate_exam_list(Request $request)
  {
    $assign_type = (int) ($request->type ?? 2);
    if ($assign_type === '') {
      return response()->json([
        'status'  => 400,
        'message' => 'Exams Not Found..!',
        'data'    => null
      ]);
    }

    $results = DB::table('za_exam')->where('status', 0)
        ->where('za_exam.exam_type', $assign_type)
        // ->limit(20)
        ->get([
            'za_exam.sno',
            'za_exam.exam_name'
        ]);

    return response()->json([
      'status'  => 200,
      'message' => 'Exams is Found..!',
      'data'    => $results
    ]);
  }
  
  public function add_assessment_students(Request $request)
  {
    $helper = new \App\Helpers\Helpers();

    // ---------------- Validation ----------------
    $validator = Validator::make($request->all(), [
      'corp_campus_id' => 'required',
      'exam_type_id'        => 'required',
      'exam_id'        => 'required',
    ]);
    
    if ($validator->fails()) {
      return response()->json([
        'status'  => 400,
        'message' => $validator->errors(),
      ], 400);
    }

    DB::beginTransaction();

    try {

      $corp_campus_id = $request->corp_campus_id;
      $exam_id        = $request->exam_id;
      $assess_exam_type_id        = $request->exam_type_id;
      $branch_id      = $request->user()->branch_id;
      $user_id        = $request->user()->id;

      $branch_data = BranchModel::where('sno', $branch_id)->first();
      $branch_name = " ";
      if ($branch_data->branch_type == 1) {
        $branch_name = $branch_data->branch_name;
      } elseif ($branch_data->branch_type == 2) {
        $branch_name = $branch_data->franchise_name;
      }

      // ---------------- Exam Details ----------------
      $exam_details = ExamModel::where('sno', $exam_id)->first();
      $exam_type_details = TypeofExamModel::where('sno', $assess_exam_type_id)->first();

      if (!$exam_details) {
        DB::rollBack();
        return response()->json([
          'status'  => 404,
          'message' => 'Exam not found',
        ], 404);
      }

      // ---------------- Exam Status (Group Exam) ----------------
      $exam_status = [];

      if ($exam_details->is_group == 1) {
          $multi_exam_ids = $exam_details->multi_exam_ids
            ? json_decode($exam_details->multi_exam_ids, true)
            : [];

          $exam_status = array_map(function ($id) {
            return [
              'exam_id'     => (int) $id,
              'exam_status' => 0,
            ];
          }, $multi_exam_ids);
      }

      // ---------------- Fetch Participants ----------------
      $participants = DB::table('za_corp_participate')
        ->where('corp_campus_id', $corp_campus_id)
        ->where('branch_id', $branch_id)
        ->where('status', 0)
        ->get();

      if ($participants->isEmpty()) {
        DB::rollBack();
        return response()->json([
          'status'  => 404,
          'message' => 'No participants found for this campus',
        ], 404);
      }

      $added = 0;
      $skipped = 0;
      $email_sent = 0;
      $email_failed = 0;

      $CorporateSettings = CorporateModel::where('sno', $corp_campus_id)
        ->where('status', '!=', 2)
        ->first();

      // ---------------- Insert into Students ----------------
      foreach ($participants as $participant) {

        $token = null;

        // Duplicate check (students table)
        $student = Student::where('exam_id', $exam_id)
            ->where('examiner_id', $participant->sno)
            ->where('status', '!=', 2)
            ->first();

        if ($student) {

            // UPDATE EXISTING
            $student->user_name   = ucfirst($participant->participate_name);
            $student->email_id    = $participant->participate_mail;
            $student->phone_no    = $participant->participate_mobile ?? null;
            $student->updated_by  = $user_id;
            $student->updated_at  = now();
            $student->save();

            $skipped++; // or $updated++

        } else {

            // CREATE NEW
            $token = $this->generateMixedToken(8);

            $student = new Student();
            $student->user_name = ucfirst($participant->participate_name);
            $student->branch_id = $branch_id;
            $student->exam_id = $exam_id;
            $student->email_id = $participant->participate_mail;
            $student->phone_no = $participant->participate_mobile ?? null;
            $student->type = self::$CORPORATE_TYPE_ID;
            $student->password_token = $token;
            $student->examiner_id = $participant->sno;
            $student->place_name = $exam_type_details->type_of_exam_name ?? null;
            $student->exam_status = empty($exam_status) ? null : json_encode($exam_status);
            $student->status = 0;
            $student->created_by = $user_id;
            $student->created_at = now();
            $student->updated_by = $user_id;
            $student->save();

            $added++;
        }

        // ---------------- Generate Feedback Link ----------------
        $encrypted_values = $helper->encrypt_decrypt($participant->sno, 'encrypt');
        $encrypted_batch_id = $helper->encrypt_decrypt($exam_id, 'encrypt'); // can be batch id
        $Link = 'https://assessment.erp.elysium.academy/';

        // $channelId = self::$CORPORATE_ASSESSMENT_CHOTTA_LINK_ID ?? 20;

        // $shortUrlData = $this->shortenUrl($Link, $channelId);
        $shortUrl = $Link;

        DB::table('za_corp_participate')
            ->where('sno', $participant->sno)
            ->update(['assessment_link' => $shortUrl]);

        // ---------------- Send Feedback Email ----------------
        if ($participant->participate_mail) {

          try {

            $email_template_id = self::$CORPORATE_EMAIL_TEMPLATE_ID; // Feedback email template
            $emailTemplate = EmailTemplateModel::where('status', 0)
                ->where('sno', $email_template_id)
                ->first();

            if (!$emailTemplate) {
              continue;
            }

            $trainer_details = [
              $CorporateSettings->training_name,
              $CorporateSettings->program_details
            ];

            $trainer_details = array_filter($trainer_details);

            $content = $emailTemplate->email_subject;
            $content = str_replace('#name', $participant->participate_name, $content);
            $content = str_replace('#link', $shortUrl, $content);
            $content = str_replace('#username', $participant->participate_name ?? '-', $content);
            $content = str_replace('#password', $student->password_token ?? '-', $content);
            $content = str_replace('#trainingdetails', (!empty($trainer_details) ? implode('/',$trainer_details) : '-'), $content);

            $branchNo    = $branch_data->mobile ?? '9677781155';
            $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
            $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
            $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';

            $content     = str_replace('#creno', $branch_data->cre_mobile ?? $branchNo, $content);
            $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
            $content = str_replace('#cremail', $branch_data->cre_mail_id ?? $branchemail, $content);

            $mailData = [
              'url' => $Link,
              'subject' => $emailTemplate->email_name,
              'content' => $content,
              'branchNo'    => $branchNo,
              'branchemail' => $branchemail, // Use the message content from the request
              'fbLink'      => $fbLink,      // Use the message content from the request
              'instaLink'   => $instaLink,   // Use the message content from the request
              'salesMobile' => $branch_data->sales_mobile ?? $branchNo,
            ];

            $to_address   = $participant->participate_mail;
            $from_address = 'elysiumacademy@elysium.community';
            $from_name    = 'Elysium Academy®';

            Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

            DB::table('za_corp_participate')->where('sno', $participant->sno)->update(['email_send' => 1]);

            $email_sent++;

          } catch (\Exception $e) {
            DB::table('za_corp_participate')
                ->where('sno', $participant->sno)
                ->update(['email_send' => 2]);

            $email_failed++;
          }
        }
      }

      if($email_sent){
        DB::table('za_corporate')->where('sno', $corp_campus_id)->update(['status' => 5]);
      }
      

      DB::commit();

      // ---------------- Final Response ----------------
      return response()->json([
        'status'  => 200,
        'message' => 'Assessment students processed successfully',
        'added'       => $added,
        'skipped'     => $skipped,
        'email_sent'  => $email_sent,
        'email_failed'=> $email_failed
      ], 200);

    } catch (\Exception $e) {

      DB::rollBack();

      return response()->json([
        'status'  => 500,
        'message' => 'Internal server error',
        'error'   => $e->getMessage(),
      ], 500);
    }
  }


  public function add_feedback_students(Request $request)
  {
    $helper = new \App\Helpers\Helpers();

    // ---------------- Validation ----------------
    $validator = Validator::make($request->all(), [
        'corp_campus_id' => 'required',
        'bulk_data'      => 'required|array|min:1',
        'bulk_data.*.sno' => 'required'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'  => 400,
            'message' => $validator->errors(),
        ], 400);
    }

    DB::beginTransaction();

    try {
        $corp_campus_id = $request->corp_campus_id;
        $branch_id      = $request->user()->branch_id;
        $user_id        = $request->user()->id;

        $branch_data = BranchModel::where('sno', $branch_id)->first();

        $branch_name = match ($branch_data->branch_type) {
            1 => $branch_data->branch_name,
            2 => $branch_data->franchise_name,
            default => ''
        };

        $CorporateSettings = CorporateModel::where('sno', $corp_campus_id)
            ->where('status', '!=', 2)
            ->first();

        $successList = [];
        $errorList   = [];

        // ---------------- Process each participant ----------------
        foreach ($request->bulk_data as $row) {

          $participant = DB::table('za_corp_participate')
              ->where('sno', $row['sno'])
              ->where('corp_campus_id', $corp_campus_id)
              ->where('branch_id', $branch_id)
              ->where('status', 0)
              ->first();

          if (!$participant) {
              $errorList[] = [
                'sno' => $row['sno'],
                'whatsapp_enabled' => false,
                'email_enabled'    => false,
                'whatsapp' => false,
                'email'    => false,
                'success_msg' => '',
                'error_msg'   => 'Participant not found'
              ];
              continue;
          }

          // Convert string → boolean safely
          $whatsappEnabled = filter_var($row['whatsapp_enabled'], FILTER_VALIDATE_BOOLEAN);
          $emailEnabled    = filter_var($row['email_enabled'], FILTER_VALIDATE_BOOLEAN);

          $whatsappStatus = true;
          $emailStatus    = true;
          $successMsg     = [];
          $errorMsg       = [];

          // ---------------- Generate Feedback Link ----------------
          $encrypted_values = $helper->encrypt_decrypt($participant->sno, 'encrypt');

          $Link = url('training_feedback/' . $encrypted_values);

          $shortUrlData = $this->shortenUrl($Link, self::$CORPORATE_FEEDBACK_CHOTTA_LINK_ID ?? 19); //chennal_ID
          $shortUrl     = $shortUrlData['shorturl'] ?? $Link;

          DB::table('za_corp_participate')
              ->where('sno', $participant->sno)
              ->update(['feedback_link' => $shortUrl]);

          // ---------------- EMAIL SEND ----------------
          if ($emailEnabled && !empty($participant->participate_mail)) {
            try {
                $emailTemplate = EmailTemplateModel::where('status', 0)
                    ->where('sno', self::$CORPORATE_FEEDBACK_EMAIL_TEMPLATE_ID)
                    ->first();

                if ($emailTemplate) {

                    $content = $emailTemplate->email_subject;
                    $content = str_replace(
                        ['#name', '#feedbacklink', '#TrainingName', '#TrainProgramDetails'],
                        [$participant->participate_name, $shortUrl, $CorporateSettings->training_name, $CorporateSettings->program_details],
                        $content
                    );

                    $branchNo    = $branch_data->mobile ?? '9677781155';
                    $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
                    $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                    $instaLink   = $branch_data->insta_link ?? 'https://www.instagram.com/elysiumacademy/';

                    $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? $branchNo, $content);
                    $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
                    $content = str_replace('#mail', $branch_data->cre_mail_id ?? $branchemail, $content);

                    $mailData = [
                        'url' => $Link,
                        'subject' => $emailTemplate->email_name,
                        'content' => $content,
                        'branchNo' => $branchNo,
                        'branchemail' => $branchemail,
                        'fbLink' => $fbLink,
                        'instaLink' => $instaLink,
                        'salesMobile' => $branch_data->sales_mobile ?? $branchNo,
                    ];

                    $to_address   = $participant->participate_mail;
                    $from_address = 'elysiumacademy@elysium.community';
                    $from_name    = 'Elysium Academy®';

                    Mail::to($to_address)
                        ->send(new EAPLMail($mailData, $from_address, $from_name));

                    DB::table('za_corp_participate')
                        ->where('sno', $participant->sno)
                        ->update(['feedback_send' => 1]);

                    $emailStatus = true;
                    $successMsg[] = 'Email sent successfully';
                }

            } catch (\Exception $e) {
              DB::table('za_corp_participate')
                  ->where('sno', $participant->sno)
                  ->update(['feedback_send' => 2]);
              $errorMsg[] = 'Email sending failed';
            }
          }

          // ---------------- WHATSAPP SEND (placeholder) ----------------
          if ($whatsappEnabled && !empty($participant->participate_mobile)) {

            $participate_mobile = $participant->participate_mobile;

            // $response = '';
            try {

              $templateName  = "feedback_common";

              $hasHeader  = false; // Example flag: set based on template
              $hasBody    = false; // Example flag: set based on template
              $hasFooter  = false; // Example flag: set based on template
              $hasButton  = false;
              $components = [];
              $couponCode = " ";

              date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')

              $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer

              if ($templateName == 'feedback_common') {

                $wtbranchNo    = $branch_data->mobile ?? '9677781155';
                $wtbranchemail = $branch_data->mail ?? 'info@elysiumacademy.org';

                $feedback_key = basename($shortUrl);

                $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/OnBoard.jpg';

                // $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
                $couponCode  = 'NOOFFER';
                $buttonIndex = 1;
                $bodyText    = [
                  [
                    'type'           => 'text',
                    'text'           => $participant->participate_name ?? "student",
                    'parameter_name' => 'stu_name',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $CorporateSettings->training_name ?? "name",
                    'parameter_name' => 'complete_name',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => "training",
                    'parameter_name' => 'type',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => "trainings",
                    'parameter_name' => 'complete_type',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => "trainings",
                    'parameter_name' => 'complete_type1',
                  ],
                  [
                    'type'           => 'text',
                    'text'           => $shortUrl,
                    'parameter_name' => 'feed_link',
                  ]
                ];
                $hasHeader = false;
                $hasBody   = true;
                $hasButton = true;
              }

              // Add Header if required
              if ($hasHeader) {
                $components[] = [
                  'type'       => 'header',
                  'parameters' => [
                    [
                      'type'  => 'image',
                      'image' => [
                        'link' => $headerImage, // Dynamically set header image
                      ],
                    ],
                  ],
                ];
              }

              // Add Body if required
              if ($hasBody) {
                $components[] = [
                  'type'       => 'body',
                  'parameters' => $bodyText,
                ];
              }

              // Add Footer if required
              if ($hasButton) {
                $components[] = [
                  'type'       => 'button',
                  'sub_type'   => 'url',
                  'index'      => 0,
                  'parameters' => [
                    [
                      'type' => 'text',
                      'text' => $feedback_key,
                    ],
                  ],
                ];
              }
              
              $dynamicParameters         = $templateParameters[$templateName] ?? [];
              $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
              $accessToken               = $this->accessData($request)->access_tokken;
              $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

              $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

              $mobile = preg_replace('/\D/', '', $participate_mobile); // remove any non-digits

              if (strpos($participate_mobile, '+') === 0) {
                  $to = $participate_mobile;
              } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                  $to = '+' . $mobile;
              } else {
                  $to = '+91' . $mobile;
              }

              $languageCode = 'en';

              $message = 'test~message';
              if (empty($components)) {
                  $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                          'name'     => $templateName,
                          'language' => [
                              'code' => $languageCode,
                          ],
                      ],
                  ];
              } else {
                  $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                          'name'       => $templateName,
                          'language'   => [
                              'code' => $languageCode,
                          ],
                          'components' => $components,
                      ],
                  ];
              }

              $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

              if((int)$response['status'] == 200){
                $whatsappStatus = true;
                $successMsg[] = 'Whatsapp sent successfully';
              }else{
                $whatsappStatus = false;
                $errorMsg[] = $response['error'];
              }

            } catch (\Exception $e) {
              $whatsappStatus = false;
              $errorMsg[] = 'Whatsapp sending failed';
            }
          }

          /* ---------------- Final Participant Result ---------------- */
          $rowResult = [
            'sno'              => $participant->sno,
            'whatsapp_enabled' => $whatsappEnabled,
            'email_enabled'    => $emailEnabled,
            'whatsapp'         => $whatsappStatus,
            'email'            => $emailStatus,
            'success_msg'      => implode(', ', $successMsg),
            'error_msg'        => implode(', ', $errorMsg)
          ];

          if ($emailStatus || $whatsappStatus) {
            $successList[] = $rowResult;
            DB::table('za_corporate')->where('sno', $corp_campus_id)->update(['status' => 7]);
          } else {
            $errorList[] = $rowResult;
          }
        }

        DB::commit();

        return response()->json([
            'status'       => 200,
            'message'      => 'Feedback notifications processed',
            'success_list' => $successList,
            'error_list'   => $errorList
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'status'  => 500,
            'message' => 'Internal server error',
            'error'   => $e->getMessage(),
        ], 500);
    }
  }

  private function generateMixedToken($length = 8)
  {
    // Define the pool of characters: uppercase, lowercase, and digits
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $token = '';
    // Generate the token by randomly selecting characters from the pool
    for ($i = 0; $i < $length; $i++) {
      $token .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $token;
  }

  public function shortenUrl($longUrl, $channelId)
  {
    $response = Http::withToken('aFLQFlykraqpANsi')
      ->post('https://chotta.link/api/url/add', [
        'url' => $longUrl
      ]);

    if ($response->successful() && isset($response['shorturl'])) {

      $shortUrl = $response['shorturl'];
      $urlId = $response['id'];

      $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

      $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);

      if ($assignResponse->successful()) {
        return $response; // success
      }
    }


    return null;
 }
 
  public function view_corp_campus_staff_info($id, Request $request)
  {
    $user = $request->user();
    $branch_id = $user->branch_id;

    $helper = new \App\Helpers\Helpers();
    $campus_id = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$campus_id) {
        abort(404, 'Invalid Campus ID');
    }

    $CorporateSettings = CorporateModel::where('sno', $campus_id)
        ->where('status', '!=', 2)
        ->firstOrFail();

    /* =========================================
       STAFF ASSIGNMENT (INTERNAL + EXTERNAL)
    ========================================= */
    $requirements_data = $CorporateSettings;

    $requirements_staff_details = [];

    $staffIds = !empty($requirements_data->staff_id)
        ? json_decode($requirements_data->staff_id, true)
        : [];

    $assignTypes = !empty($requirements_data->staff_assign_type)
        ? json_decode($requirements_data->staff_assign_type, true)
        : [];

    foreach ($assignTypes as $assignType) {

        // INTERNAL STAFF
        if ($assignType == "1" && !empty($staffIds['internal_staff_ids'])) {
            $staffList = StaffModel::whereIn('sno', $staffIds['internal_staff_ids'])
                ->get(['sno','staff_name','staff_image','mobile_no','email_id','gender']);

            foreach ($staffList as $staff) {
                $requirements_staff_details[] = [
                    'staff_type'       => 'internal',
                    'staff_type_id' => 1,
                    'staff_sno'        => $staff->sno,
                    'staff_name'       => $staff->staff_name,
                    'staff_mobile_no'  => $staff->mobile_no,
                    'staff_email_id'   => $staff->email_id,
                    'staff_gender'     => $staff->gender ?? 1,
                    'staff_image' => $staff->staff_image ?? null,
                    'staff_image_path' => $staff->staff_image
                        ? 'staff_images/'.$staff->staff_image
                        : null,
                ];
            }
        }

        // EXTERNAL STAFF
        if ($assignType == "2" && !empty($staffIds['external_staff_ids'])) {
            $trainerList = TrainingDatabaseModel::whereIn('sno', $staffIds['external_staff_ids'])
                ->get([
                    'sno',
                    'trainer_name as staff_name',
                    'training_staff_image as staff_image',
                    'mobile_no',
                    'email_id'
                ]);

            foreach ($trainerList as $trainer) {
                $requirements_staff_details[] = [
                    'staff_type'       => 'external',
                    'staff_type_id' => 2,
                    'staff_sno'        => $trainer->sno,
                    'staff_name'       => $trainer->staff_name,
                    'staff_mobile_no'  => $trainer->mobile_no,
                    'staff_email_id'   => $trainer->email_id,
                    'staff_gender'     => 1,
                    'staff_image' => $trainer->staff_image ?? null,
                    'staff_image_path' => $trainer->staff_image
                        ? 'trainer_staff_images/'.$trainer->staff_image
                        : null,
                ];
            }
        }
    }

    $requirements_data->staff_details = $requirements_staff_details;

    /* =========================================
       STAFF SWAP HISTORY → TIMELINE
    ========================================= */
    $historyRows = CorporateSwappStaffHistoryModel::where('training_id', $requirements_data->sno)
        ->where('branch_id', $branch_id)
        ->where('status', '!=', 2)
        ->whereNotNull('previous_staff_id')
        ->orderBy('start_date')
        ->get();

    $staffTimeline = [];


    foreach ($historyRows as $row) {

        // PREVIOUS STAFF
        $prevStaff = null;
        if ($row->previous_staff_id) {
            if ($row->previous_staff_type == 1) {
                $s = StaffModel::find($row->previous_staff_id);
                $prevStaff = [
                    'type'  => 'internal',
                    'sno'  => $s->sno ?? null,
                    'name'  => $s->staff_name ?? null,
                    'image' => $s->staff_image ??  null,
                    'image_path' => $s->staff_image ? 'staff_images/'.$s->staff_image : null,
                    'mobile_no' => $s->mobile_no ?? null,
                    'type_id' => 1,
                    'email_id' => $s->email_id ?? null,
                    'gender' => 1
                ];
            } else {
              $s = TrainingDatabaseModel::find($row->previous_staff_id);
              $prevStaff = [
                'type'  => 'external',
                'sno'  => $s->sno ?? null,
                'name'  => $s->trainer_name ?? null,
                'image' => $s->training_staff_image ?? null,
                'type_id' => 2,
                'image_path' => $s->training_staff_image ? 'trainer_staff_images/'.$s->training_staff_image : null,
                'mobile_no' => $s->mobile_no ?? null,
                'email_id' => $s->email_id ?? null,
                'gender' => 2
              ];
            }
        }

        // SWAP STAFF
        $swapStaff = null;
        if ($row->swap_staff_id) {
          if ($row->swap_staff_type == 1) {
            $s = StaffModel::find($row->swap_staff_id);
            $swapStaff = [
              'type'  => 'internal',
              'type_id' => 1,
              'sno'  => $s->sno ?? null,
              'name'  => $s->staff_name ?? null,
              'image' => $s->staff_image ??  null,
              'image_path' => $s->staff_image ? 'staff_images/'.$s->staff_image : null,
              'mobile_no' => $s->mobile_no ?? null,
              'email_id' => $s->email_id ?? null,
              'gender' => 1
            ];
          } else {
            $s = TrainingDatabaseModel::find($row->swap_staff_id);
            $swapStaff = [
              'type'  => 'external',
              'type_id' => 2,
              'sno'  => $s->sno ?? null,
              'name'  => $s->trainer_name ?? null,
              'image' => $s->training_staff_image ?? null,
              'image_path' => $s->training_staff_image ? 'trainer_staff_images/'.$s->training_staff_image : null,
              'mobile_no' => $s->mobile_no ?? null,
              'email_id' => $s->email_id ?? null,
              'gender' => 2
            ];
          }
        }

        $staffTimeline[] = [
            'period'         => date('d M Y', strtotime($row->start_date))
                                .' - '.
                                date('d M Y', strtotime($row->end_date)),
            'previous_staff' => $prevStaff,
            'swap_staff'     => $swapStaff,
            'start_date'     => date('d M Y', strtotime($row->start_date)),
            'end_date'       => date('d M Y', strtotime($row->end_date)),
            'status'         => $row->status,
        ];
    }

    $requirements_data->staff_timeline = $staffTimeline;

    // return $requirements_data;
    
    return view(
        'content.corporate_management.corp_training_staff_view',
        compact('CorporateSettings','requirements_data')
    );
  }

  public function view_corp_campus_part_info($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $campus_id = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$campus_id) {
        abort(404, 'Invalid Campus ID');
    }

    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $CorporateSettings = CorporateModel::where('sno', $campus_id)
        ->where('status', '!=', 2)
        ->firstOrFail();

    /* ===============================
       Training date range
    ================================ */
    $startDate = Carbon::parse($CorporateSettings->start_date);
    $endDate   = Carbon::parse($CorporateSettings->end_date);

    $dates = [];
    foreach (CarbonPeriod::create($startDate, $endDate) as $date) {
      $dates[] = $date->format('Y-m-d');
    }

    // return $dates;

    /* ===============================
       Participants (FULL DETAILS)
    ================================ */
    $participants = DB::table('za_corp_participate')
      ->where('branch_id', $branch_id)
      ->where('corp_campus_id', $campus_id)
      ->where('status', '!=', 2)
      ->get();

    /*===============================
      Attendance
    ================================ */

    $attendanceRows = DB::table('za_corp_participate_attendance')
        ->where('branch_id', $branch_id)
        ->where('corp_campus_id', $campus_id)
        ->whereBetween('att_date', [$startDate, $endDate])
        ->where('status', '!=', 2)
        ->get()
        ->groupBy(fn($r) => $r->participate_id.'_'.$r->att_date);

    /* ===============================
       Build table data
    ================================ */
    $tableData = [];

    foreach ($participants as $p) {

        $row = [
            'participant_id' => $p->sno,
            'name'           => $p->participate_name,
            'mobile'         => $p->participate_mobile,
            'email'          => $p->participate_mail,
            'dob'            => $p->participate_dob,
            'department'     => $p->participate_department,
            'attendance'     => [],
            'P' => 0,
            'L' => 0,
            'H' => 0,
        ];

        foreach ($dates as $dt) {
            $key = $p->sno.'_'.$dt;
            $att = $attendanceRows[$key][0]->attendance ?? '-';

            $row['attendance'][$dt] = $att;

            if (in_array($att, ['P','L','H'])) {
                $row[$att]++;
            }
        }

        $tableData[] = $row;
    }

    $groups_data = [];

    // Group participants by group_id
    $grouped = $participants->groupBy('group_id');

    foreach ($grouped as $group_id => $members) {

        if (empty($group_id)) {
            continue;
        }

        /* ===============================
           GROUP NAME (A, B, C...)
        ================================ */
        $group_name = 'Group ' . chr(64 + (int)$group_id);

        /* ===============================
           FIXED RANDOM DARK COLORS
        ================================ */
        $hash = crc32($group_id);

        $color1 = sprintf(
            '#%02X%02X%02X',
            ($hash & 0xFF) % 120,
            (($hash >> 8) & 0xFF) % 120,
            (($hash >> 16) & 0xFF) % 120
        );

        $hash2 = crc32($group_id . '_x');

        $color2 = sprintf(
            '#%02X%02X%02X',
            ($hash2 & 0xFF) % 120,
            (($hash2 >> 8) & 0xFF) % 120,
            (($hash2 >> 16) & 0xFF) % 120
        );

        /* ===============================
           PUSH FINAL GROUP DATA
        ================================ */
        $groups_data[] = (object)[
            'group_id'    => $group_id,
            'group_name'  => $group_name,
            'color1'      => $color1,
            'color2'      => $color2,
            'participants_count'=> $members->count() ?? 0,  // ✅ COUNT ADDED
            'participants'=> $members->map(function ($p) {
                return (object)[
                    'id'                 => $p->sno,
                    'participate_name'   => $p->participate_name,
                    'participate_mobile' => $p->participate_mobile,
                ];
            })->values()->toArray(),
        ];
    }

    // return $groups_data;

    return view(
        'content.corporate_management.corp_training_part_view',[
          'CorporateSettings' => $CorporateSettings,
          'AttendancetableData' => $tableData,
          'training_dates' => $dates,
          'groups_data' => $groups_data
        ]
    );
  }

  public function view_corp_campus_payment_info($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $campus_id = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$campus_id) {
        abort(404, 'Invalid Campus ID');
    }

    $user = $request->user();
    $branch_id = $user->branch_id;

    $CorporateSettings = CorporateModel::where('sno', $campus_id)
        ->where('status', '!=', 2)
        ->firstOrFail();

    /* =========================================
       TRANSACTION DATA (JSON + NORMAL COLUMNS)
    ========================================= */
    $transactions = DB::table('za_transaction')
        ->where('customer_type', 3)          // Corporate
        ->where('training_id', $campus_id)
        ->where('branch_id', $branch_id)
        ->where('status', '!=', 2)
        ->where('payment_status', '=', 0)
        ->orderBy('created_at', 'desc')
        ->get();

    $paymentHistory = [];

    foreach ($transactions as $txn) {

      /* ===============================
          Decode JSON safely
      ================================ */
      $jsonPayments = [];
      if (!empty($CorporateSettings->transaction_all)) {
        $jsonPayments = json_decode($CorporateSettings->transaction_all, true);
      }

      // If JSON has multiple payments
      if (is_array($jsonPayments) && count($jsonPayments)) {

        foreach ($jsonPayments as $pay) {
          $paymentHistory[$pay['receipt_id']] = [
            'date'          => $pay['timestamp'] ?? (isset($txn->created_at) && !empty($txn->created_at) ? $txn->created_at : null),
            'receipt_id'    => $pay['receipt_id'] ?? (isset($txn->receipt_id) && !empty($txn->receipt_id) ? $txn->receipt_id : null),
            'invoice_id'    => $pay['invoice_id'] ?? (isset($txn->invoice_id) && !empty($txn->invoice_id) ? $txn->invoice_id : null),
            'payment_mode'  => $pay['payment_mode'] ?? (isset($txn->payment_mode) && !empty($txn->payment_mode) ? $txn->payment_mode : null),
            'payment_amount'=> $pay['payment_amount'] ?? (isset($txn->payment_amount) && !empty($txn->payment_amount) ? $txn->payment_amount : null),
            'bank_name'     => $pay['Bank Name'] ?? (isset($txn->bank_name) && !empty($txn->bank_name) ? $txn->bank_name : null),
            'account_no'    => $pay['Account No'] ?? (isset($txn->account_no) && !empty($txn->account_no) ? $txn->account_no : null),
            'cheque_no'     => $pay['Cheque No'] ?? (isset($txn->cheque_no) && !empty($txn->cheque_no) ? $txn->cheque_no : null),
            'cheque_entry'  => $pay['Cheque Entry Date'] ?? (isset($txn->cheque_entry_date) && !empty($txn->cheque_entry_date) ? $txn->cheque_entry_date : null),
            'cheque_expiry' => $pay['Cheque Expiry Date'] ?? (isset($txn->cheque_expiry_date) && !empty($txn->cheque_expiry_date) ? $txn->cheque_expiry_date : null),
            'holder_name'   => $pay['Holder Name'] ?? (isset($txn->holder_name) && !empty($txn->holder_name) ? $txn->holder_name : null),
            'description'   => $pay['Description'] ?? (isset($txn->description) && !empty($txn->description) ? $txn->description : null),
            'pay_status'    => $pay['payment_status'] ?? (isset($txn->payment_status) ? $txn->payment_status : null),
          ];
        }

      }
    }

    // $paymentHistory = [];
    
    return view(
      'content.corporate_management.corp_training_payment_view',
      compact('CorporateSettings', 'paymentHistory')
    );
  }

  public function confirm_bulk_certification(Request $request)
  {
    $helper = new \App\Helpers\Helpers();

    // ---------------- Validation ----------------
    $validator = Validator::make($request->all(), [
        'corp_campus_id' => 'required',
        'corp_company_id' => 'required',
        'bulk_data'      => 'required|array|min:1',
        'bulk_data.*.sno' => 'required'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'  => 400,
            'message' => $validator->errors(),
        ], 400);
    }

    DB::beginTransaction();

    try {
        $corp_campus_id = $request->corp_campus_id;
        $corp_company_id = $request->corp_company_id;
        $branch_id      = $request->user()->branch_id;
        $user_id        = $request->user()->id;

        $branch_data = BranchModel::where('sno', $branch_id)->first();

        $branch_name = match ($branch_data->branch_type) {
            1 => $branch_data->branch_name,
            2 => $branch_data->franchise_name,
            default => ''
        };

        $CorporateSettings = CorporateModel::where('sno', $corp_campus_id)
            ->where('status', '!=', 2)
            ->first();

        $successList = [];
        $errorList   = [];

        // ---------------- Process each participant ----------------
        foreach ($request->bulk_data as $row) {

          $participant = DB::table('za_corp_participate')
              ->where('sno', $row['sno'])
              ->where('corp_campus_id', $corp_campus_id)
              ->where('branch_id', $branch_id)
              ->where('status', 0)
              ->first();

          if (!$participant) {
              $errorList[] = [
                'sno' => $row['sno'],
                'whatsapp_enabled' => false,
                'email_enabled'    => false,
                'whatsapp' => false,
                'email'    => false,
                'success_msg' => '',
                'error_msg'   => 'Participant not found'
              ];
              continue;
          }

          // Convert string → boolean safely
          $whatsappEnabled = filter_var($row['whatsapp_enabled'], FILTER_VALIDATE_BOOLEAN);
          $emailEnabled    = filter_var($row['email_enabled'], FILTER_VALIDATE_BOOLEAN);

          $whatsappStatus = true;
          $emailStatus    = true;
          $successMsg     = [];
          $errorMsg       = [];

          // ---------------- Generate Feedback Link ----------------
          $encrypted_values = $helper->encrypt_decrypt($participant->sno, 'encrypt');

          $Link = url('training_certification/' . $encrypted_values);

          $shortUrlData = $this->shortenUrl($Link, self::$CORPORATE_CERTIFICATE_CHOTTA_LINK_ID ?? 15); //chennal_ID
          $shortUrl     = $shortUrlData['shorturl'] ?? $Link;

          DB::table('za_corp_participate')
            ->where('sno', $participant->sno)
            ->update(['certification_link' => $shortUrl,'corp_company_id'=>$corp_company_id]);

          // ---------------- EMAIL SEND ----------------
          if ($emailEnabled && !empty($participant->participate_mail)) {

            try {

                $emailTemplate = EmailTemplateModel::where('status', 0)
                    ->where('sno', self::$CORPORATE_CERTIFICATE_EMAIL_TEMPLATE_ID)
                    ->first();

                if ($emailTemplate) {

                    $content = $emailTemplate->email_subject;
                    $content = str_replace(
                        ['#name', '#CertificateLink', '#TrainingName', '#TrainProgramDetails'],
                        [$participant->participate_name, $shortUrl, $CorporateSettings->training_name, $CorporateSettings->program_details],
                        $content
                    );

                    $branchNo    = $branch_data->mobile ?? '9677781155';
                    $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
                    $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
                    $instaLink   = $branch_data->insta_link ?? 'https://www.instagram.com/elysiumacademy/';

                    $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? $branchNo, $content);
                    $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
                    $content = str_replace('#mail', $branch_data->cre_mail_id ?? $branchemail, $content);

                    $mailData = [
                        'url' => $Link,
                        'subject' => $emailTemplate->email_name,
                        'content' => $content,
                        'branchNo' => $branchNo,
                        'branchemail' => $branchemail,
                        'fbLink' => $fbLink,
                        'instaLink' => $instaLink,
                        'salesMobile' => $branch_data->sales_mobile ?? $branchNo,
                    ];

                    $to_address   = $participant->participate_mail;
                    $from_address = 'elysiumacademy@elysium.community';
                    $from_name    = 'Elysium Academy®';

                    Mail::to($to_address)
                        ->send(new EAPLMail($mailData, $from_address, $from_name));

                    DB::table('za_corp_participate')
                        ->where('sno', $participant->sno)
                        ->update(['certification_send' => 1]);

                    $emailStatus = true;
                    $successMsg[] = 'Email sent successfully';
                }

            } catch (\Exception $e) {
              DB::table('za_corp_participate')
                  ->where('sno', $participant->sno)
                  ->update(['certification_send' => 2]);
              $errorMsg[] = 'Email sending failed';
            }
          }

          // ---------------- WHATSAPP SEND (placeholder) ----------------
          if ($whatsappEnabled && !empty($participant->participate_mobile)) {

            $participate_mobile = $participant->participate_mobile;

            // $response = '';
            try {

              $templateName  = "corporate_certificate";

              $hasHeader  = false; // Example flag: set based on template
              $hasBody    = false; // Example flag: set based on template
              $hasFooter  = false; // Example flag: set based on template
              $hasButton  = false;
              $components = [];
              $couponCode = " ";

              date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')

              $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer

              if ($templateName == 'corporate_certificate') {

                  $wtbranchNo    = $branch_data->mobile ?? '9677781155';
                  $wtbranchemail = $branch_data->mail ?? 'info@elysiumacademy.org';

                  $location_key = basename($shortUrl);

                  $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
                  $couponCode  = 'NOOFFER';
                  $buttonIndex = 1;
                  $bodyText    = [
                    [
                      'type'           => 'text',
                      'text'           =>  $participant->participate_name,
                      'parameter_name' => 'stu_name',
                    ],
                    [
                      'type'           => 'text',
                      'text'           => $CorporateSettings->training_name ?? 'Corporate Training',
                      'parameter_name' => 'complete_name',
                    ],
                    [
                      'type'           => 'text',
                      'text'           => $branch_name ?? 'Elysium Academy',
                      'parameter_name' => 'branch_name',
                    ],
                    [
                      'type'           => 'text',
                      'text'           => $shortUrl ?? '',
                      'parameter_name' => 'certificate_link',
                    ]
                  ];

                  $hasHeader = false;
                  $hasBody   = true;
                  $hasButton = true;
              }

              // Add Header if required
              if ($hasHeader) {
                $components[] = [
                  'type'       => 'header',
                  'parameters' => [
                    [
                      'type'  => 'image',
                      'image' => [
                        'link' => $headerImage, // Dynamically set header image
                      ],
                    ],
                  ],
                ];
              }

              // // Add Body if required
              if ($hasBody) {
                $components[] = [
                  'type'       => 'body',
                  'parameters' => $bodyText,
                ];
              }

              // Add Footer if required
              if ($hasButton) {
                  $components[] = [
                      'type'       => 'button',
                      'sub_type'   => 'url',
                      'index'      => 0,
                      'parameters' => [
                          [
                            'type' => 'text',
                            'text' => $location_key,
                          ],
                      ],
                  ];
              }
              
              $dynamicParameters         = $templateParameters[$templateName] ?? [];
              $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
              $accessToken               = $this->accessData($request)->access_tokken;
              $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

              $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

              $mobile = preg_replace('/\D/', '', $participate_mobile); // remove any non-digits

              if (strpos($participate_mobile, '+') === 0) {
                  $to = $participate_mobile;
              } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                  $to = '+' . $mobile;
              } else {
                  $to = '+91' . $mobile;
              }

              $languageCode = 'en';

              $message = 'test~message';
              if (empty($components)) {
                  $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                          'name'     => $templateName,
                          'language' => [
                              'code' => $languageCode,
                          ],
                      ],
                  ];
              } else {
                  $payload = [
                      'messaging_product' => 'whatsapp',
                      'to'                => $to,
                      'type'              => 'template',
                      'template'          => [
                          'name'       => $templateName,
                          'language'   => [
                              'code' => $languageCode,
                          ],
                          'components' => $components,
                      ],
                  ];
              }

              $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

              if((int)$response['status'] == 200){
                $whatsappStatus = true;
                $successMsg[] = 'Whatsapp sent successfully';
              }else{
                $whatsappStatus = false;
                $errorMsg[] = $response['error'];
              }

            } catch (\Exception $e) {
              $whatsappStatus = false;
            }
          }

          /* ---------------- Final Participant Result ---------------- */
          $rowResult = [
            'sno'              => $participant->sno,
            'whatsapp_enabled' => $whatsappEnabled,
            'email_enabled'    => $emailEnabled,
            'whatsapp'         => $whatsappStatus,
            'email'            => $emailStatus,
            'success_msg'      => implode(', ', $successMsg),
            'error_msg'        => implode(', ', $errorMsg)
          ];

          if ($emailStatus || $whatsappStatus) {
            $successList[] = $rowResult;
            DB::table('za_corporate')->where('sno', $corp_campus_id)->update(['status' => 6]);
          } else {
            $errorList[] = $rowResult;
          }
        }

        DB::commit();

        return response()->json([
          'status'       => 200,
          'message'      => 'Certification notifications processed',
          'success_list' => $successList,
          'error_list'   => $errorList
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'status'  => 500,
            'message' => 'Internal server error',
            'error'   => $e->getMessage(),
        ], 500);
    }
  }
  public function generateQrEvent($id, Request $request)
  {
    try {
      $helper = new \App\Helpers\Helpers();

      // Encrypt event/session ID
      $encryptedId = $helper->encrypt_decrypt($id, 'encrypt');

      // Participation URL (intent is explicit)
      $qrContent = url("/corp_training_qr/participate/{$encryptedId}");

      // External QR API (API LINK ONLY)
      $qrApiUrl = "https://api.qrserver.com/v1/create-qr-code/?" . http_build_query([
        'data' => $qrContent,
        'size' => '300x300'
      ]);

      // Fetch QR image
      $qrImageData = @file_get_contents($qrApiUrl);

      if (!$qrImageData) {
          return response()->json([
              'status'  => 500,
              'message' => 'QR service unavailable'
          ], 500);
      }

      // Convert to Base64 (modal-friendly)
      $qrBase64 = 'data:image/png;base64,' . base64_encode($qrImageData);

      return response()->json([
          'status'    => 200,
          'qr_base64' => $qrBase64,
          'link'      => $qrContent,
      ]);

    } catch (\Exception $e) {
        return response()->json([
            'status'  => 500,
            'message' => 'QR generation failed',
            'error'   => $e->getMessage()
        ], 500);
    }
  }
  public function GroupingParticipate($id, Request $request)
  {
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $helper = new \App\Helpers\Helpers();

    $current_date = date('Y-m-d');
    
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$decryptedValue) {
        abort(404, 'Invalid Campus ID');
    }

    $CorporateSettings = CorporateModel::where('sno', $decryptedValue)
        ->where('status', '!=', 2)
        ->first();

    if (!$CorporateSettings) {
      abort(404, 'Corporate Campus Not Found');
    }else{
      if ($current_date < $CorporateSettings->start_date) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Training has not started yet!'
        ]);
        return redirect('/manage_corporate/corporate_training');
      } elseif ($current_date > $CorporateSettings->end_date) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Training has already ended!'
        ]);
        return redirect('/manage_corporate/corporate_training');
      }
    }

    
    $details_type = $request->details_type ?? 1;

    $CorporateListOptions = !empty($CorporateSettings->participate_details)
        ? json_decode($CorporateSettings->participate_details, true)
        : [];

    $CorporateTrans_details = !empty($CorporateSettings->transaction_all)
        ? json_decode($CorporateSettings->transaction_all, true)
        : null;

    /* ---------------- PARTICIPANTS ---------------- */

    $participate_details = CorporateParticipateModel::where('corp_campus_id', $CorporateSettings->sno)
        ->where('status', '!=', 2)
        ->get();

    $participate_count = $participate_details->count();

    $participate_total_count = (int) ($CorporateSettings->participate_count ?? 0);
    $participate_bal_count   = max(0, $participate_total_count - $participate_count);

    /* ---------------- STAFF ASSIGNMENT ---------------- */

    $staffIds = !empty($CorporateSettings->staff_id)
        ? json_decode($CorporateSettings->staff_id, true)
        : [];

    $assignTypes = !empty($CorporateSettings->staff_assign_type)
        ? json_decode($CorporateSettings->staff_assign_type, true)
        : [];

    $staffAssignTypeLabels = array_map(fn ($typeId) =>
        $helper->getCorpAssignStaffType($typeId) ?? 'Unknown',
        $assignTypes
    );

    $requirements_staff_details = [];

    foreach ($assignTypes as $assignType) {

        if ($assignType == "1" && !empty($staffIds['internal_staff_ids'])) {

            $staffList = StaffModel::whereIn('sno', $staffIds['internal_staff_ids'])->get();
            $prefix = 'internal_';
            $image_path = 'staff_images/';

        } elseif ($assignType == "2" && !empty($staffIds['external_staff_ids'])) {

            $staffList = TrainingDatabaseModel::whereIn('sno', $staffIds['external_staff_ids'])->get();
            $prefix = 'external_';
            $image_path = 'trainer_staff_images/';

        } else {
            continue;
        }

        foreach ($staffList as $staff) {

            $image_full_path = !empty($staff->staff_image)
                ? $image_path . $staff->staff_image
                : null;

            $requirements_staff_details[] = [
                'staff_sno'        => $staff->sno,
                'staff_slug_id'   => $prefix . $staff->sno,
                'staff_name'      => $staff->staff_name ?? $staff->trainer_name ?? null,
                'staff_mobile_no' => $staff->mobile_no ?? null,
                'staff_email_id'  => $staff->email_id ?? null,
                'staff_image'     => $staff->staff_image ?? null,
                'staff_image_path'=> $image_full_path,
                'staff_img_html'  => ($image_full_path && file_exists(public_path($image_full_path)))
                    ? '<img src="'.asset($image_full_path).'" class="rounded-circle w-50 h-50">'
                    : $helper->name_image(strtoupper(substr($staff->staff_name ?? 'U', 0, 1)), 2),
                'staff_type'      => $assignType == 1 ? 'Internal Trainers' : 'External Trainers',
                'staff_type_id'   => $assignType
            ];
        }
    }

    $internalTrainers = array_values(array_filter($requirements_staff_details,
        fn($s) => $s['staff_type'] === 'Internal Trainers'
    ));

    $externalTrainers = array_values(array_filter($requirements_staff_details,
        fn($s) => $s['staff_type'] === 'External Trainers'
    ));

    /* ---------------- ORGANIZATION NAME ---------------- */

    $oraganization_name = null;

    if ($CorporateSettings->organization_type == 2) {
        $oraganization_name = $helper->getCorporateSettingName($CorporateSettings->corporate_id);
    } elseif ($CorporateSettings->organization_type == 1) {
        $oraganization_name = $helper->getCollegeName($CorporateSettings->college_id);
    }

    // Fetch all participants for this training
    $participants = CorporateParticipateModel::where([
        'branch_id'      => $branch_id,
        'corp_campus_id' => $decryptedValue,
        'status'         => 0
    ])->get();

    $groups_data = [];

    // Group participants by group_id
    $grouped = $participants->groupBy('group_id');

    foreach ($grouped as $group_id => $members) {

        if(!empty($group_id)){
          $group_name = 'Group ' . chr(64 + (int)$group_id); // 1 => A, 2 => B
          $groups_data[] = (object)[
              'group_name'  => $group_name,
              'participants_count'=> $members->count() ?? 0,  // ✅ COUNT ADDED
              'participants'=> $members->map(function($p) {
                  return (object)[
                      'id'              => $p->sno,
                      'participate_name'=> $p->participate_name,
                      'participate_mobile'=> $p->participate_mobile,
                  ];
              })->toArray(),
          ];
        }

    }

    // return $groups_data;

    /* ---------------- FINAL DATA ---------------- */

    $details_array = [
        'sno'                     => $CorporateSettings->sno,
        'training_id'             => $CorporateSettings->cor_training_id,
        'training_name'           => $CorporateSettings->training_name,
        'start_date'              => date('d-M-Y', strtotime($CorporateSettings->start_date)),
        'end_date'                => date('d-M-Y', strtotime($CorporateSettings->end_date)),
        'start_time'              => date('h:i A', strtotime($CorporateSettings->start_time)),
        'end_time'                => date('h:i A', strtotime($CorporateSettings->end_time)),
        'staff_assign_type'       => $staffAssignTypeLabels,
        'staff_assign_type_id'    => $assignTypes,
        'staff_details'           => $requirements_staff_details,
        'internalTrainers'        => $internalTrainers,
        'externalTrainers'        => $externalTrainers,
        'participate_details'     => $participate_details,
        'participate_added_count' => $participate_count,
        'participate_total_count' => $participate_total_count,
        'participate_bal_count'   => $participate_bal_count,
        'transaction_details'     => $CorporateTrans_details,
        'oraganization_name'      => $oraganization_name,
        'total_days' => isset($CorporateSettings->total_days) && $CorporateSettings->total_days > 0 ? str_pad($CorporateSettings->total_days, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->total_days == 1 ? ' Day ' : ' Days ') : '00',
        'hours_per_day' => isset($CorporateSettings->hours_per_day) && $CorporateSettings->hours_per_day > 0 ? str_pad($CorporateSettings->hours_per_day, 2, '0', STR_PAD_LEFT) . ($CorporateSettings->hours_per_day == 1 ? ' Hour ' : ' Hours ') : '00',
        'pay_cost' => isset($CorporateSettings->pay_cost) && !empty($CorporateSettings->pay_cost) ? number_format($CorporateSettings->pay_cost, 0) : '0',
        'total_amount' => isset($CorporateSettings->payment) && !empty($CorporateSettings->payment) ? $CorporateSettings->payment : '0',
        'total_paid' => isset($CorporateSettings->paid) && !empty($CorporateSettings->paid) ? $CorporateSettings->paid : '0',
        'total_balance' => isset($CorporateSettings->balance) && !empty($CorporateSettings->balance) ? $CorporateSettings->balance : '0',
        'per_person_cost' => isset($CorporateSettings->per_person_cost) && !empty($CorporateSettings->per_person_cost) ? number_format($CorporateSettings->per_person_cost, 0) : '0',
        'session_type' => strtolower($helper->getCorpSessionType($CorporateSettings->session_type)) ?? null, //helper
        'organization_type' => $helper->getCorpOrgType($CorporateSettings->organization_type) ?? null, //helper
        'gst_type' => $helper->getCorpGstType($CorporateSettings->gst_type) ?? null, //helper
        'staff_id' => $CorporateSettings->staff_id ?? null,
        'training_mobile' => $CorporateSettings->training_mobile ?? null,
        'program_details' => $CorporateSettings->program_details ?? null,
        'participate_count' => !empty($participate_total_count) ? $participate_total_count : 0
    ];

    return view('content.corporate_management.manage_grouping_participate',['details_array'=>$details_array, 'encry_id'=>$id, 'groups_data'=>$groups_data]);
  }

  public function GroupingParticipateSave(Request $request)
  {
    //  return $request;

      $validator = Validator::make($request->all(), [
          'trining_id' => 'required',
          'groups'     => 'required|array|min:1',
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status' => false,
              'type'   => 'validation',
              'errors' => $validator->errors(),
          ], 422);
      }

      $user       = $request->user();
      $user_id    = $user->user_id;
      $branch_id  = $user->branch_id;

      $helper = new \App\Helpers\Helpers();
      $corpCampusId = $helper->encrypt_decrypt($request->trining_id, 'decrypt');

      DB::beginTransaction();

      try {

          $assignedParticipantIds = [];
          $updatedCount = 0;

          /* ============================
            STEP 1: ASSIGN GROUP IDS
          ============================ */
          foreach ($request->groups as $group_id => $participants) {

              if (!is_numeric($group_id) || empty($participants)) {
                  continue;
              }

              foreach ($participants as $participant) {

                  if (empty($participant['participant_id'])) {
                      continue;
                  }

                  $assignedParticipantIds[] = $participant['participant_id'];

                  $affected = CorporateParticipateModel::where([
                      'branch_id'        => $branch_id,
                      'corp_campus_id'   => $corpCampusId,
                      'sno'              => $participant['participant_id'],
                      'status'           => 0,
                  ])->update([
                      'group_id'   => (int) $group_id,
                      'updated_by' => $user_id,
                      'updated_at' => now(),
                  ]);

                  if ($affected) {
                      $updatedCount++;
                  }
              }
          }

          /* ============================
            STEP 2: UNASSIGN OTHERS
          ============================ */
          CorporateParticipateModel::where([
              'branch_id'      => $branch_id,
              'corp_campus_id' => $corpCampusId,
              'status'         => 0,
          ])
          ->whereNotIn('sno', $assignedParticipantIds)
          ->update([
              'group_id'   => null,
              'updated_by' => $user_id,
              'updated_at' => now(),
          ]);

          DB::commit();

          return response()->json([
              'status'  => true,
              'message' => 'Group assignment updated successfully',
              'updated' => $updatedCount,
          ]);

      } catch (\Throwable $e) {

          DB::rollBack();

          return response()->json([
              'status'  => false,
              'type'    => 'exception',
              'message' => 'Something went wrong',
              'debug'   => config('app.debug') ? $e->getMessage() : null,
          ], 500);
      }
  }

  public function TrainingAddPartQrForm($id, Request $request)
  {
    $user       = $request->user();
    $user_id    = $user->user_id;
    $branch_id  = $user->branch_id;

    $helper = new \App\Helpers\Helpers();

    $decodeId = $helper->encrypt_decrypt($id, 'decrypt');

    if (!$decodeId) {
      return view('errors.invalid_coupon');
    }
    
    //  $scanTracked = session('event_scan_tracked_' . $decodeId);

    // if (!$scanTracked) {
    //     // Save the scan details if not tracked already
    //     $this->saveScanDetails($decodeId, $request);

    //     // Set a session flag to indicate that the scan has been tracked for this event
    //     session(['event_scan_tracked_' . $decodeId => true]);
    // }

    $today = date('Y-m-d');

    $QR_data = CorporateModel::where('sno', $decodeId)->where('status', '!=', 2)->first();

    if (!$QR_data) {
      return view('errors.invalid_coupon');
    }

    $applied_count = CorporateParticipateModel::where([
      'branch_id'      => $branch_id,
      'corp_campus_id' => $decodeId,
      'status'         => 0
    ])->count();

    if($applied_count){
      $QR_data->applied_count = $applied_count ?? 0;
    }else{
      $QR_data->applied_count = 0;
    }

    $branch_data = BranchModel::where('sno', $QR_data->branch_id)
      ->select(
        'za_branch.door_no',
        'za_branch.pincode',
        'za_branch.mobile',
        'za_branch.branch_name',
        'za_branch.sno AS branch_id',
        'za_branch.branch_type',
        'za_branch.franchise_name',
        'za_branch.mail',
        'za_branch.area_street',
        'za_states.name as state_name',
        'za_cities.name as city_name'
      )
      ->leftJoin('za_cities', 'za_cities.id', '=', 'za_branch.city_id')
      ->leftJoin('za_states', 'za_states.id', '=', 'za_branch.state_id')->first();
        
    if (!$branch_data) {
      return view('errors.invalid_coupon');
    }

    return view('content.corporate_management.training_qr_add_page', [
      'Branch_details' => $branch_data,
      'QR_data' =>  $QR_data
    ]);
  }

  public function checkCorpTrainingMobileExists(Request $request)
  {
    $lead_mobile      = $request->input('mobile');
    $corp_training_id = (int) $request->input('corp_training_id');
    $part_campus_id   = (int) $request->input('part_campus_id') ?? null;

    $query = CorporateParticipateModel::where('participate_mobile', $lead_mobile)
        ->where('corp_campus_id', $corp_training_id)
        ->where('status', '!=', 2);

    // exclude current participant while editing
    if (!empty($part_campus_id)) {
        $query->where('sno', '!=', $part_campus_id);
    }

    $exists = $query->exists(); // ✅ important

    return response()->json([
        'exists' => $exists
    ]);
  }
  public function AddQrParticipant(Request $request)
  {
    try {

      /* ---------------- VALIDATION ---------------- */
      $validator = Validator::make($request->all(), [
          'corp_training_id' => 'required|integer',
          'lead_mobile'      => 'required|digits_between:8,15',
          'lead_name'        => 'required|string|max:255',
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status'    => 422,
              'message'   => 'Validation failed',
              'error_msg' => $validator->errors(),
              'data'      => null,
          ], 422);
      }

      $user      = $request->user();
      $user_id   = $user->user_id;
      $branch_id = $user->branch_id;

      $helper = new \App\Helpers\Helpers();
      
      $corp_campus_id     = $request->corp_training_id;
      $encry_corp_campus_id = $helper->encrypt_decrypt($corp_campus_id, 'encrypt');
      $participate_mobile = $request->lead_mobile;
      $participate_mail = $request->lead_email;
      $participate_name   = $request->lead_name;

      /* ---------------- CORPORATE SETTINGS ---------------- */
      $CorporateSettings = CorporateModel::where('sno', $corp_campus_id)
          ->where('status', '!=', 2)
          ->first();

      if (!$CorporateSettings) {
          return response()->json([
              'status'    => 404,
              'message'   => 'Training not found',
              'error_msg' => '',
              'data'      => null,
          ], 404);
      }

      $max_participate_count = !empty($CorporateSettings->participate_count)
          ? (int) $CorporateSettings->participate_count
          : 0; // 0 = Unlimited

      /* ---------------- TRANSACTION START ---------------- */
      DB::beginTransaction();

      /* ---------------- DUPLICATE CHECK ---------------- */
      $exists = CorporateParticipateModel::where('corp_campus_id', $corp_campus_id)
          ->where('participate_mobile', $participate_mobile)->where('status', '!=', 2)
          ->lockForUpdate()
          ->exists();

      if ($exists) {
          DB::rollBack();
          return response()->json([
              'status'    => 409,
              'message'   => 'You Already Applied This training',
              'error_msg' => '',
              'data'      => null,
          ], 409);
      }

      /* ---------------- AVAILABILITY CHECK ---------------- */
      $current_participate_count = CorporateParticipateModel::where('corp_campus_id', $corp_campus_id)->where('status', '!=', 2)
          ->lockForUpdate()
          ->count();

      if ($max_participate_count > 0 && $current_participate_count >= $max_participate_count) {
          DB::rollBack();
          return response()->json([
              'status'    => 409,
              'message'   => 'Participant limit reached. No more slots available.',
              'error_msg' => '',
              'data'      => [
                  'max_limit'     => $max_participate_count,
                  'current_count' => $current_participate_count,
              ],
          ], 409);
      }

      /* ---------------- PARTICIPATE CODE ---------------- */
      $last = CorporateParticipateModel::orderBy('sno', 'desc')
          ->lockForUpdate()
          ->first();

      $nextNumber = 1;
      if ($last && isset($last->participate_id)) {
          $slice = explode('/', $last->participate_id);
          $num   = preg_replace('/[^0-9]/', '', $slice[0]);
          $nextNumber = intval($num) + 1;
      }

      $year = date('y');
      $participate_code = sprintf('CORPCAMP-%04d', $nextNumber) . '/' . $year;

      /* ---------------- SAVE PARTICIPANT ---------------- */
      $save = new CorporateParticipateModel();
      $save->branch_id              = $branch_id;
      $save->corp_campus_id         = $corp_campus_id;
      $save->participate_id         = $participate_code;
      $save->participate_name       = $participate_name;
      $save->participate_mobile     = $participate_mobile;
      $save->participate_mail       = $participate_mail ?? null;
      $save->participate_department = null;
      $save->staff_id               = null;
      $save->staff_type             = null;
      $save->participate_dob        = null;
      $save->created_by             = $user_id;
      $save->created_at             = now();
      if($save->save()){

        $participant = DB::table('za_corp_participate')->where('sno', $save->sno)
          ->where('corp_campus_id', $corp_campus_id)
          ->where('branch_id', $branch_id)
          ->where('status', 0)
          ->first();

        $branch_data = BranchModel::where('sno', $branch_id)->first();
        $branch_name = " ";
        if ($branch_data->branch_type == 1) {
          $branch_name = $branch_data->branch_name;
        } elseif ($branch_data->branch_type == 2) {
          $branch_name = $branch_data->franchise_name;
        }

        if (isset($participant->participate_mail) && !empty($participant->participate_mail)) {

          $email_template_id = self::$CORPORATE_JOIN_TRAINING_EMAIL_TEMPLATE_ID; // Feedback email template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $participant->participate_name, $content);
          $content = str_replace('#TrainingName', (!empty( $CorporateSettings->training_name) ? $CorporateSettings->training_name : '-'), $content);
          $content = str_replace('#start_date', (date('d-M-Y', strtotime($CorporateSettings->start_date)) ?? '-'), $content);
          $content = str_replace('#end_date', (date('d-M-Y', strtotime($CorporateSettings->end_date)) ?? '-'), $content);
          $content = str_replace('#mode_location', ($CorporateSettings->training_location_url ?? '-'), $content);

          $branchNo    = $branch_data->mobile ?? '9677781155';
          $branchemail = $branch_data->mail ?? 'info@elysiumacademy.org';
          $fbLink      = $branch_data->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/';
          $instaLink   = $branch_data->insta_link ?? ' https://www.instagram.com/elysiumacademy/';

          $content     = str_replace('#CRENo', $branch_data->cre_mobile ?? $branchNo, $content);
          $content     = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branch_data->cre_mail_id ?? $branchemail, $content);

          $mailData = [
            'url' => null,
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo'    => $branchNo,
            'branchemail' => $branchemail, // Use the message content from the request
            'fbLink'      => $fbLink,      // Use the message content from the request
            'instaLink'   => $instaLink,   // Use the message content from the request
            'salesMobile' => $branch_data->sales_mobile ?? $branchNo,
          ];

          $to_address   = $participant->participate_mail;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name    = 'Elysium Academy®';

          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));
          
        }

        if (isset($participant->participate_mobile) && !empty($participant->participate_mobile)) {

          $templateName  = "corporate_training_information";

          $hasHeader  = false; // Example flag: set based on template
          $hasBody    = false; // Example flag: set based on template
          $hasFooter  = false; // Example flag: set based on template
          $hasButton  = false;
          $components = [];
          $couponCode = " ";

          date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')

          $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer

          if ($templateName == 'corporate_training_information') {

              $wtbranchNo    = $branch_data->mobile ?? '9677781155';
              $wtbranchemail = $branch_data->mail ?? 'info@elysiumacademy.org';

              $Link = $CorporateSettings->training_location_url;

              $shortUrlData = $this->shortenUrl($Link, self::$CORPORATE_QR_PART_ADD_CHOTTA_LINK_ID ?? 19); //chennal_ID
              $shortUrl     = $shortUrlData['shorturl'] ?? $Link;
              $location_key = basename($shortUrl);

              $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
              $couponCode  = 'NOOFFER';
              $buttonIndex = 1;
              $bodyText    = [
                [
                  'type'           => 'text',
                  'text'           =>  $participant->participate_name,
                  'parameter_name' => 'stu_name',
                ],
                [
                  'type'           => 'text',
                  'text'           => $CorporateSettings->training_name ?? 'Corporate Training',
                  'parameter_name' => 'complete_name',
                ],
                [
                  'type'           => 'text',
                  'text'           => $branch_name ?? 'Elysium Academy',
                  'parameter_name' => 'branch_name',
                ],
                [
                  'type'           => 'text',
                  'text'           => date('d-M-Y', strtotime($CorporateSettings->start_date)),
                  'parameter_name' => 'start_date',
                ],
                [
                  'type'           => 'text',
                  'text'           => date('d-M-Y', strtotime($CorporateSettings->end_date)),
                  'parameter_name' => 'end_date',
                ],
                [
                  'type'           => 'text',
                  'text'           => $Link ?? '-',
                  'parameter_name' => 'location_url',
                ],
                [
                  'type'           => 'text',
                  'text'           => $branch_data->cre_mobile ?? $branchNo,
                  'parameter_name' => 'contact_no',
                ],
                [
                  'type'           => 'text',
                  'text'           => $branch_data->cre_mail_id ?? $branchemail,
                  'parameter_name' => 'email_id',
                ]
              ];

              $hasHeader = false;
              $hasBody   = true;
              $hasButton = true;
          }

          // return $bodyText;

          // Add Header if required
          if ($hasHeader) {
            $components[] = [
              'type'       => 'header',
              'parameters' => [
                [
                  'type'  => 'image',
                  'image' => [
                    'link' => $headerImage, // Dynamically set header image
                  ],
                ],
              ],
            ];
          }

          // Add Body if required
          if ($hasBody) {
            $components[] = [
              'type'       => 'body',
              'parameters' => $bodyText,
            ];
          }

          // Add Footer if required
          if ($hasButton) {
              $components[] = [
                  'type'       => 'button',
                  'sub_type'   => 'url',
                  'index'      => 0,
                  'parameters' => [
                      [
                        'type' => 'text',
                        'text' => $location_key,
                      ],
                  ],
              ];
          }
          
          $dynamicParameters         = $templateParameters[$templateName] ?? [];
          $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
          $accessToken               = $this->accessData($request)->access_tokken;
          $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

          $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

          $mobile = preg_replace('/\D/', '', $participate_mobile); // remove any non-digits

          if (strpos($participate_mobile, '+') === 0) {
              $to = $participate_mobile;
          } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
              $to = '+' . $mobile;
          } else {
              $to = '+91' . $mobile;
          }

          $languageCode = 'en';

          $message = 'test~message';
          if (empty($components)) {
              $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                      'name'     => $templateName,
                      'language' => [
                          'code' => $languageCode,
                      ],
                  ],
              ];
          } else {
              $payload = [
                  'messaging_product' => 'whatsapp',
                  'to'                => $to,
                  'type'              => 'template',
                  'template'          => [
                      'name'       => $templateName,
                      'language'   => [
                          'code' => $languageCode,
                      ],
                      'components' => $components,
                  ],
              ];
          }
          //  return $payload;
          $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);

          if ($response['status'] == 200) {
          } else {
            return response()->json([
              'status' => 404,
              'message' => 'Failed to send message',
              // 'certificate_status' => 2,
              'error_msg' => $response['error'],
            ], 400);
          }

        }
      }

      DB::commit();

      return response()->json([
          'status'    => 200,
          'message'   => 'Participant added successfully',
          'error_msg' => '',
          'link' => $encry_corp_campus_id,
          'data'      => [
              'participate_id' => $participate_code,
              'remaining_slots' => $max_participate_count > 0
                  ? ($max_participate_count - ($current_participate_count + 1))
                  : 'Unlimited',
          ],
      ], 200);

    } catch (\Exception $e) {

      DB::rollBack();

      return response()->json([
          'status'    => 500,
          'message'   => 'Something went wrong',
          'error_msg' => $e->getMessage(),
          'data'      => null,
      ], 500);
    }
  }

  public function accessData(Request $request){
    $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 6)->first();
    return $whatsappConfig;
  }
  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
        
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
  public function TrainingAppliedSuccess($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    $QR_data = CorporateModel::where('sno', $decryptedValue)->first();

    return view('content.corporate_management.training_applied_success', [
      'QR_data' =>  $QR_data,
    ]);
  }
  public function UpdateParticipateDetails(Request $request)
  {
    // return $request;
      /* -------------------------------------------------
      | 1. VALIDATION
      * -------------------------------------------------*/
      $validator = Validator::make($request->all(), [
          'update_part_corpcampus_id' => 'required',
          'participate_details' => 'required|array',
          'participate_details.*.participate_name'   => 'required',
          'participate_details.*.participate_mob_no' => 'required',
          'participate_details.*.participate_mail'   => 'required|email',
          'participate_details.*.participate_dob'    => 'required',
          'participate_details.*.department_name'    => 'required',
          'participate_details.*.staff_id'           => 'required'
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status'    => 422,
              'message'   => 'Validation failed',
              'error_msg' => $validator->errors()
          ], 422);
      }

      /* -------------------------------------------------
      | 2. BASIC DATA
      * -------------------------------------------------*/
      $user_id   = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;

      $corp_campus_id = $request->update_part_corpcampus_id;
      $participants   = $request->participate_details;

      $successList = [];
      $errorList   = [];

      /* -------------------------------------------------
      | 3. UPDATE PARTICIPANTS
      * -------------------------------------------------*/
      foreach ($participants as $part_id => $row) {

          $participant = CorporateParticipateModel::where('sno', $part_id)
              ->where('branch_id', $branch_id)
              ->where('corp_campus_id', $corp_campus_id)
              ->first();

          if (!$participant) {
              $errorList[] = [
                  'sno' => $part_id,
                  'participateStatus' => 'not_found'
              ];
              continue;
          }

          try {
            
              $participant->participate_name       = $row['participate_name'];
              $participant->participate_mobile     = $row['participate_mob_no'];
              $participant->participate_mail       = $row['participate_mail'];
              $participant->participate_department = $row['department_name'];
              $participant->staff_id               = $row['staff_id'];
              $participant->staff_type             = $row['staff_type'] ?? null;
              $participant->participate_dob        = date('Y-m-d', strtotime($row['participate_dob']));
              $participant->updated_by             = $user_id;
              $participant->updated_at             = now();
              $participant->save();

              $successList[] = [
                'sno'              => $participant->sno,
                'participate_id'   => $participant->participate_id,
                'participate_name' => $participant->participate_name,
                'participateStatus'=> 'updated'
              ];

          } catch (\Exception $e) {

              $errorList[] = [
                  'sno'              => $part_id,
                  'participateStatus'=> 'failed'
              ];
          }
      }

      /* -------------------------------------------------
      | 4. FINAL RESPONSE
      * -------------------------------------------------*/
      return response()->json([
          'status'        => 200,
          'message'       => 'Participants updated successfully',
          'success_list'  => $successList,
          'error_list'    => $errorList
      ], 200);
  }

  public function Company_list(Request $request)
  {
    $user_branch_id = (string) $request->user()->branch_id;

    // Get all colleges with status = 0
    $colleges = LetterPadModel::where('status', 0)->orderBy('sno', 'desc')->get();

    // Filter colleges whose branch_id contains the user's branch_id
    $filtered_colleges = $colleges->filter(function ($college) use ($user_branch_id) {
      $branch_ids = json_decode($college->branch_id, true);
      return in_array($user_branch_id, $branch_ids);
    })->values(); // reset array keys

    if(!$filtered_colleges) {
      return response([
        'status' => 400,
        'message' => 'No Such Records !',
        'error_msg' => null,
        'data' => null
      ], 404);
    } else {
      return response([
        'status' => 200,
        'message' => 'Company Fetched Successfully',
        'error_msg' => null,
        'data' => $filtered_colleges
      ], 200);
    }
  }

}