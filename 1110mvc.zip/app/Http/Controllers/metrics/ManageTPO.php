<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use App\Models\CustomerModel;
use App\Models\TransactionModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class ManageTPO extends Controller
{
  public function index()
  {
    return view('content.metrics.manage_tpo');
  }

  public function tpoList(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $year = $request->year ?? Carbon::now()->year;

    // Get customer IDs for branch
    $customers = CustomerModel::where('branch_id', $branch_id)
      ->where('status', 0)
      ->pluck('sno');

    // --------------------------------------------
    // 1) TESBO (tesbo_check = 2) => UNIQUE customer per month
    // --------------------------------------------
    $tesboData = DB::table('za_training')
      ->whereIn('customer_id', $customers)
      ->where('tesbo_check', 2)
      ->whereYear('created_at', $year)
      ->select(
        DB::raw('MONTH(created_at) AS month'),
        DB::raw('COUNT(DISTINCT customer_id) AS count')
      )
      ->groupBy('month')
      ->get()
      ->keyBy('month');

    // --------------------------------------------
    // 2) PROFESSIONAL & OTHERS (Normal count)
    // --------------------------------------------
    $otherData = DB::table('za_training as t')
      ->join('za_course as c', 't.course_id', '=', 'c.sno')
      ->join('za_course_type as ct', 'c.course_type_id', '=', 'ct.sno')
      ->whereIn('t.customer_id', $customers)
      ->whereYear('t.created_at', $year)
      ->where('t.tesbo_check', '!=', 2) // EXCLUDE TESBO here
      ->where('c.course_type_id', '!=', 7) // EXCLUDE TESBO here
      ->select(
        DB::raw('MONTH(t.created_at) as month'),
        'ct.sno as course_type_sno',
        DB::raw('COUNT(*) as count')
      )
      ->groupBy('month', 'course_type_sno')
      ->get();


    // new traction month
    $monthTotal = TransactionModel::where('branch_id', $branch_id)
      ->where('status', 0)
      ->where('customer_type', '!=', 2)
      ->whereYear('transaction_date', $year)
      ->select(
        DB::raw('MONTH(transaction_date) as month'),
        DB::raw('SUM(credit) as total')
      )
      ->groupBy('month')
      ->get()
      ->keyBy('month');


    // --------------------------------------------
    // Prepare month structure
    // --------------------------------------------
    $months = [];
    for ($m = 1; $m <= 12; $m++) {
      $months[$m] = [
        'TESBO' => 0,
        'Professional' => 0,
        'Others' => 0,
        'total' => 0,
        'TESBO_percent' => 0,
        'Professional_percent' => 0,
        'Others_percent' => 0,
        'month_achieved' => 0,
      ];
    }

    // --------------------------------------------
    // Insert TESBO data
    // --------------------------------------------
    foreach ($tesboData as $month => $row) {
      $months[$month]['TESBO'] = $row->count;  // unique customers
    }

    // --------------------------------------------
    // Insert Professional & Others
    // --------------------------------------------
    foreach ($otherData as $row) {

      if ($row->course_type_sno == 3) {
        $months[$row->month]['Professional'] += $row->count;
      } else {
        $months[$row->month]['Others'] += $row->count;
      }
    }

    // --------------------------------------------
    // Totals & Percentages
    // --------------------------------------------
    foreach ($months as $month => $vals) {

      // insert month achieved amount
      $months[$month]['month_achieved'] = $monthTotal[$month]->total ?? 0;

      $total = $vals['TESBO'] + $vals['Professional'] + $vals['Others'];
      $months[$month]['total'] = $total;

      $months[$month]['TESBO_percent'] =
        $total ? round($vals['TESBO'] / $total * 100, 2) : 0;

      $months[$month]['Professional_percent'] =
        $total ? round($vals['Professional'] / $total * 100, 2) : 0;

      $months[$month]['Others_percent'] =
        $total ? round($vals['Others'] / $total * 100, 2) : 0;
    }


    // --------------------------------------------
    // Format Response (Month Name)
    // --------------------------------------------
    $tpoList = [];
    foreach ($months as $num => $data) {
      $tpoList[] = array_merge([
        'month' => Carbon::createFromDate($year, $num, 1)->format('M')
      ], $data);
    }

    return response()->json([
      'status' => 200,
      'data' => $tpoList,
    ]);
  }
}
